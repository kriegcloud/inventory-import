import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BackupInUseException_base: S.TaggedErrorClass<"BackupInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class BackupInUseException extends /*@__PURE__*/ BackupInUseException_base {
}
declare const BackupNotFoundException_base: S.TaggedErrorClass<"BackupNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class BackupNotFoundException extends /*@__PURE__*/ BackupNotFoundException_base {
}
declare const ConditionalCheckFailedException_base: S.TaggedErrorClass<"ConditionalCheckFailedException", {
    readonly message: any;
    readonly Item: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConditionalCheckFailedException extends /*@__PURE__*/ ConditionalCheckFailedException_base {
}
declare const ContinuousBackupsUnavailableException_base: S.TaggedErrorClass<"ContinuousBackupsUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ContinuousBackupsUnavailableException extends /*@__PURE__*/ ContinuousBackupsUnavailableException_base {
}
declare const DuplicateItemException_base: S.TaggedErrorClass<"DuplicateItemException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateItemException extends /*@__PURE__*/ DuplicateItemException_base {
}
declare const ExportConflictException_base: S.TaggedErrorClass<"ExportConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ExportConflictException extends /*@__PURE__*/ ExportConflictException_base {
}
declare const ExportNotFoundException_base: S.TaggedErrorClass<"ExportNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ExportNotFoundException extends /*@__PURE__*/ ExportNotFoundException_base {
}
declare const GlobalTableAlreadyExistsException_base: S.TaggedErrorClass<"GlobalTableAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalTableAlreadyExistsException extends /*@__PURE__*/ GlobalTableAlreadyExistsException_base {
}
declare const GlobalTableNotFoundException_base: S.TaggedErrorClass<"GlobalTableNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class GlobalTableNotFoundException extends /*@__PURE__*/ GlobalTableNotFoundException_base {
}
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const ImportConflictException_base: S.TaggedErrorClass<"ImportConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ImportConflictException extends /*@__PURE__*/ ImportConflictException_base {
}
declare const ImportNotFoundException_base: S.TaggedErrorClass<"ImportNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ImportNotFoundException extends /*@__PURE__*/ ImportNotFoundException_base {
}
declare const IndexNotFoundException_base: S.TaggedErrorClass<"IndexNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class IndexNotFoundException extends /*@__PURE__*/ IndexNotFoundException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidEndpointException_base: S.TaggedErrorClass<"InvalidEndpointException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEndpointException extends /*@__PURE__*/ InvalidEndpointException_base {
}
declare const InvalidExportTimeException_base: S.TaggedErrorClass<"InvalidExportTimeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportTimeException extends /*@__PURE__*/ InvalidExportTimeException_base {
}
declare const InvalidRestoreTimeException_base: S.TaggedErrorClass<"InvalidRestoreTimeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreTimeException extends /*@__PURE__*/ InvalidRestoreTimeException_base {
}
declare const ItemCollectionSizeLimitExceededException_base: S.TaggedErrorClass<"ItemCollectionSizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ItemCollectionSizeLimitExceededException extends /*@__PURE__*/ ItemCollectionSizeLimitExceededException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PointInTimeRecoveryUnavailableException_base: S.TaggedErrorClass<"PointInTimeRecoveryUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PointInTimeRecoveryUnavailableException extends /*@__PURE__*/ PointInTimeRecoveryUnavailableException_base {
}
declare const PolicyNotFoundException_base: S.TaggedErrorClass<"PolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class PolicyNotFoundException extends /*@__PURE__*/ PolicyNotFoundException_base {
}
declare const ProvisionedThroughputExceededException_base: S.TaggedErrorClass<"ProvisionedThroughputExceededException", {
    readonly message: any;
    readonly ThrottlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ProvisionedThroughputExceededException extends /*@__PURE__*/ ProvisionedThroughputExceededException_base {
}
declare const ReplicaAlreadyExistsException_base: S.TaggedErrorClass<"ReplicaAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReplicaAlreadyExistsException extends /*@__PURE__*/ ReplicaAlreadyExistsException_base {
}
declare const ReplicaNotFoundException_base: S.TaggedErrorClass<"ReplicaNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ReplicaNotFoundException extends /*@__PURE__*/ ReplicaNotFoundException_base {
}
declare const ReplicatedWriteConflictException_base: S.TaggedErrorClass<"ReplicatedWriteConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ReplicatedWriteConflictException extends /*@__PURE__*/ ReplicatedWriteConflictException_base {
}
declare const RequestLimitExceeded_base: S.TaggedErrorClass<"RequestLimitExceeded", {
    readonly message: any;
    readonly ThrottlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestLimitExceeded extends /*@__PURE__*/ RequestLimitExceeded_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TableAlreadyExistsException_base: S.TaggedErrorClass<"TableAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TableAlreadyExistsException extends /*@__PURE__*/ TableAlreadyExistsException_base {
}
declare const TableInUseException_base: S.TaggedErrorClass<"TableInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TableInUseException extends /*@__PURE__*/ TableInUseException_base {
}
declare const TableNotFoundException_base: S.TaggedErrorClass<"TableNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TableNotFoundException extends /*@__PURE__*/ TableNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TransactionCanceledException_base: S.TaggedErrorClass<"TransactionCanceledException", {
    readonly message: any;
    readonly CancellationReasons: any;
}>;
export declare class TransactionCanceledException extends /*@__PURE__*/ TransactionCanceledException_base {
}
declare const TransactionConflictException_base: S.TaggedErrorClass<"TransactionConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TransactionConflictException extends /*@__PURE__*/ TransactionConflictException_base {
}
declare const TransactionInProgressException_base: S.TaggedErrorClass<"TransactionInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TransactionInProgressException extends /*@__PURE__*/ TransactionInProgressException_base {
}
export type PartiQLStatement = string;
export type StringAttributeValue = string;
export type NumberAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type StringSetAttributeValue = string[];
export type NumberSetAttributeValue = string[];
export type BinarySetAttributeValue = Uint8Array[];
export type AttributeName = string;
export type MapAttributeValue = {
    [key: string]: AttributeValue | undefined;
};
export type ListAttributeValue = AttributeValue[];
export type NullAttributeValue = boolean;
export type BooleanAttributeValue = boolean;
export type AttributeValue = {
    S: string;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N: string;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B: Uint8Array;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS: string[];
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS: string[];
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS: Uint8Array[];
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M: {
        [key: string]: AttributeValue | undefined;
    };
    L?: undefined;
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L: AttributeValue[];
    NULL?: undefined;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL: boolean;
    BOOL?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    B?: undefined;
    SS?: undefined;
    NS?: undefined;
    BS?: undefined;
    M?: undefined;
    L?: undefined;
    NULL?: undefined;
    BOOL: boolean;
};
export type PreparedStatementParameters = AttributeValue[];
export type ConsistentRead = boolean;
export type ReturnValuesOnConditionCheckFailure = "ALL_OLD" | "NONE" | (string & {});
export interface BatchStatementRequest {
    Statement: string;
    Parameters?: AttributeValue[] | undefined;
    ConsistentRead?: boolean | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export type PartiQLBatchRequest = BatchStatementRequest[];
export type ReturnConsumedCapacity = "INDEXES" | "TOTAL" | "NONE" | (string & {});
export interface BatchExecuteStatementInput {
    Statements: BatchStatementRequest[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
}
export type BatchStatementErrorCodeEnum = "ConditionalCheckFailed" | "ItemCollectionSizeLimitExceeded" | "RequestLimitExceeded" | "ValidationError" | "ProvisionedThroughputExceeded" | "TransactionConflict" | "ThrottlingError" | "InternalServerError" | "ResourceNotFound" | "AccessDenied" | "DuplicateItem" | (string & {});
export type AttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export interface BatchStatementError {
    Code?: BatchStatementErrorCodeEnum | undefined;
    Message?: string | undefined;
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export type TableName = string;
export interface BatchStatementResponse {
    Error?: BatchStatementError | undefined;
    TableName?: string | undefined;
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export type PartiQLBatchResponse = BatchStatementResponse[];
export type TableArn = string;
export type ConsumedCapacityUnits = number;
export interface Capacity {
    ReadCapacityUnits?: number | undefined;
    WriteCapacityUnits?: number | undefined;
    CapacityUnits?: number | undefined;
}
export type IndexName = string;
export type SecondaryIndexesCapacityMap = {
    [key: string]: Capacity | undefined;
};
export interface VectorCapacity {
    VectorSearchRequestBytes?: number | undefined;
    VectorWriteRequestBytes?: number | undefined;
}
export type VectorIndexesCapacityMap = {
    [key: string]: VectorCapacity | undefined;
};
export interface ConsumedCapacity {
    TableName?: string | undefined;
    CapacityUnits?: number | undefined;
    ReadCapacityUnits?: number | undefined;
    WriteCapacityUnits?: number | undefined;
    Table?: Capacity | undefined;
    LocalSecondaryIndexes?: {
        [key: string]: Capacity | undefined;
    } | undefined;
    GlobalSecondaryIndexes?: {
        [key: string]: Capacity | undefined;
    } | undefined;
    VectorIndexes?: {
        [key: string]: VectorCapacity | undefined;
    } | undefined;
}
export type ConsumedCapacityMultiple = ConsumedCapacity[];
export interface BatchExecuteStatementOutput {
    Responses?: BatchStatementResponse[] | undefined;
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
}
export type Key = {
    [key: string]: AttributeValue | undefined;
};
export type KeyList = {
    [key: string]: AttributeValue | undefined;
}[];
export type AttributeNameList = string[];
export type ProjectionExpression = string;
export type ExpressionAttributeNameVariable = string;
export type ExpressionAttributeNameMap = {
    [key: string]: string | undefined;
};
export interface KeysAndAttributes {
    Keys: {
        [key: string]: AttributeValue | undefined;
    }[];
    AttributesToGet?: string[] | undefined;
    ConsistentRead?: boolean | undefined;
    ProjectionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type BatchGetRequestMap = {
    [key: string]: KeysAndAttributes | undefined;
};
export interface BatchGetItemInput {
    RequestItems: {
        [key: string]: KeysAndAttributes | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
}
export type ItemList = {
    [key: string]: AttributeValue | undefined;
}[];
export type BatchGetResponseMap = {
    [key: string]: {
        [key: string]: AttributeValue | undefined;
    }[] | undefined;
};
export interface BatchGetItemOutput {
    Responses?: {
        [key: string]: {
            [key: string]: AttributeValue | undefined;
        }[] | undefined;
    } | undefined;
    UnprocessedKeys?: {
        [key: string]: KeysAndAttributes | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
}
export type PutItemInputAttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export interface PutRequest {
    Item: {
        [key: string]: AttributeValue | undefined;
    };
}
export interface DeleteRequest {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
}
export interface WriteRequest {
    PutRequest?: PutRequest | undefined;
    DeleteRequest?: DeleteRequest | undefined;
}
export type WriteRequests = WriteRequest[];
export type BatchWriteItemRequestMap = {
    [key: string]: WriteRequest[] | undefined;
};
export type ReturnItemCollectionMetrics = "SIZE" | "NONE" | (string & {});
export interface BatchWriteItemInput {
    RequestItems: {
        [key: string]: WriteRequest[] | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics | undefined;
}
export type ItemCollectionKeyAttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export type ItemCollectionSizeEstimateBound = number;
export type ItemCollectionSizeEstimateRange = number[];
export interface ItemCollectionMetrics {
    ItemCollectionKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    SizeEstimateRangeGB?: number[] | undefined;
}
export type ItemCollectionMetricsMultiple = ItemCollectionMetrics[];
export type ItemCollectionMetricsPerTable = {
    [key: string]: ItemCollectionMetrics[] | undefined;
};
export interface BatchWriteItemOutput {
    UnprocessedItems?: {
        [key: string]: WriteRequest[] | undefined;
    } | undefined;
    ItemCollectionMetrics?: {
        [key: string]: ItemCollectionMetrics[] | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
}
export type BulkOperationArn = string;
export interface CancelBulkOperationInput {
    BulkOperationArn: string;
}
export type BulkOperationStatus = "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "CANCELLING" | "CANCELLED" | "FAILED" | (string & {});
export interface CancelBulkOperationOutput {
    BulkOperationArn: string;
    BulkOperationStatus: BulkOperationStatus;
}
export type BackupName = string;
export interface CreateBackupInput {
    TableName: string;
    BackupName: string;
}
export type BackupArn = string;
export type BackupSizeBytes = number;
export type BackupStatus = "CREATING" | "DELETED" | "AVAILABLE" | (string & {});
export type BackupType = "USER" | "SYSTEM" | "AWS_BACKUP" | (string & {});
export type BackupCreationDateTime = Date;
export interface BackupDetails {
    BackupArn: string;
    BackupName: string;
    BackupSizeBytes?: number | undefined;
    BackupStatus: BackupStatus;
    BackupType: BackupType;
    BackupCreationDateTime: Date;
    BackupExpiryDateTime?: Date | undefined;
}
export interface CreateBackupOutput {
    BackupDetails?: BackupDetails | undefined;
}
export type RegionName = string;
export interface Replica {
    RegionName?: string | undefined;
}
export type ReplicaList = Replica[];
export interface CreateGlobalTableInput {
    GlobalTableName: string;
    ReplicationGroup: Replica[];
}
export type ReplicaStatus = "CREATING" | "CREATION_FAILED" | "UPDATING" | "DELETING" | "ACTIVE" | "REGION_DISABLED" | "INACCESSIBLE_ENCRYPTION_CREDENTIALS" | "ARCHIVING" | "ARCHIVED" | "REPLICATION_NOT_AUTHORIZED" | (string & {});
export type ReplicaStatusDescription = string;
export type ReplicaStatusPercentProgress = string;
export type KMSMasterKeyId = string;
export type PositiveLongObject = number;
export interface ProvisionedThroughputOverride {
    ReadCapacityUnits?: number | undefined;
}
export type LongObject = number;
export interface OnDemandThroughputOverride {
    MaxReadRequestUnits?: number | undefined;
}
export type TableStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | "INACCESSIBLE_ENCRYPTION_CREDENTIALS" | "ARCHIVING" | "ARCHIVED" | "REPLICATION_NOT_AUTHORIZED" | (string & {});
export interface TableWarmThroughputDescription {
    ReadUnitsPerSecond?: number | undefined;
    WriteUnitsPerSecond?: number | undefined;
    Status?: TableStatus | undefined;
}
export type IndexStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | (string & {});
export interface GlobalSecondaryIndexWarmThroughputDescription {
    ReadUnitsPerSecond?: number | undefined;
    WriteUnitsPerSecond?: number | undefined;
    Status?: IndexStatus | undefined;
}
export interface ReplicaGlobalSecondaryIndexDescription {
    IndexName?: string | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride | undefined;
    OnDemandThroughputOverride?: OnDemandThroughputOverride | undefined;
    WarmThroughput?: GlobalSecondaryIndexWarmThroughputDescription | undefined;
}
export type ReplicaGlobalSecondaryIndexDescriptionList = ReplicaGlobalSecondaryIndexDescription[];
export type TableClass = "STANDARD" | "STANDARD_INFREQUENT_ACCESS" | (string & {});
export interface TableClassSummary {
    TableClass?: TableClass | undefined;
    LastUpdateDateTime?: Date | undefined;
}
export type GlobalTableSettingsReplicationMode = "ENABLED" | "DISABLED" | "ENABLED_WITH_OVERRIDES" | (string & {});
export interface ReplicaDescription {
    RegionName?: string | undefined;
    ReplicaStatus?: ReplicaStatus | undefined;
    ReplicaArn?: string | undefined;
    ReplicaStatusDescription?: string | undefined;
    ReplicaStatusPercentProgress?: string | undefined;
    KMSMasterKeyId?: string | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride | undefined;
    OnDemandThroughputOverride?: OnDemandThroughputOverride | undefined;
    WarmThroughput?: TableWarmThroughputDescription | undefined;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndexDescription[] | undefined;
    ReplicaInaccessibleDateTime?: Date | undefined;
    ReplicaTableClassSummary?: TableClassSummary | undefined;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode | undefined;
}
export type ReplicaDescriptionList = ReplicaDescription[];
export type GlobalTableArnString = string;
export type GlobalTableStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | (string & {});
export interface GlobalTableDescription {
    ReplicationGroup?: ReplicaDescription[] | undefined;
    GlobalTableArn?: string | undefined;
    CreationDateTime?: Date | undefined;
    GlobalTableStatus?: GlobalTableStatus | undefined;
    GlobalTableName?: string | undefined;
}
export interface CreateGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription | undefined;
}
export type KeySchemaAttributeName = string;
export type ScalarAttributeType = "S" | "N" | "B" | (string & {});
export interface AttributeDefinition {
    AttributeName: string;
    AttributeType: ScalarAttributeType;
}
export type AttributeDefinitions = AttributeDefinition[];
export type KeyType = "HASH" | "RANGE" | (string & {});
export interface KeySchemaElement {
    AttributeName: string;
    KeyType: KeyType;
}
export type KeySchema = KeySchemaElement[];
export type ProjectionType = "ALL" | "KEYS_ONLY" | "INCLUDE" | (string & {});
export type NonKeyAttributeName = string;
export type NonKeyAttributeNameList = string[];
export interface Projection {
    ProjectionType?: ProjectionType | undefined;
    NonKeyAttributes?: string[] | undefined;
}
export interface LocalSecondaryIndex {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
}
export type LocalSecondaryIndexList = LocalSecondaryIndex[];
export interface ProvisionedThroughput {
    ReadCapacityUnits: number;
    WriteCapacityUnits: number;
}
export interface OnDemandThroughput {
    MaxReadRequestUnits?: number | undefined;
    MaxWriteRequestUnits?: number | undefined;
}
export interface WarmThroughput {
    ReadUnitsPerSecond?: number | undefined;
    WriteUnitsPerSecond?: number | undefined;
}
export interface GlobalSecondaryIndex {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: WarmThroughput | undefined;
}
export type GlobalSecondaryIndexList = GlobalSecondaryIndex[];
export type BillingMode = "PROVISIONED" | "PAY_PER_REQUEST" | (string & {});
export type StreamEnabled = boolean;
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export interface StreamSpecification {
    StreamEnabled: boolean;
    StreamViewType?: StreamViewType | undefined;
}
export type SSEEnabled = boolean;
export type SSEType = "AES256" | "KMS" | (string & {});
export interface SSESpecification {
    Enabled?: boolean | undefined;
    SSEType?: SSEType | undefined;
    KMSMasterKeyId?: string | undefined;
}
export type TagKeyString = string;
export type TagValueString = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type DeletionProtectionEnabled = boolean;
export type ResourcePolicy = string;
export type VectorAttributeName = string;
export interface VectorAttributeDefinition {
    AttributeName: string;
}
export type SearchSchemaElementType = "HASH" | "INLINE_FILTER" | (string & {});
export interface SearchSchemaElement {
    AttributeName: string;
    SearchSchemaElementType: SearchSchemaElementType;
}
export type SearchSchema = SearchSchemaElement[];
export type VectorDistanceFunction = "COSINE" | "DOT_PRODUCT" | "EUCLIDEAN" | (string & {});
export interface VectorIndex {
    IndexName: string;
    VectorAttribute: VectorAttributeDefinition;
    SearchSchema?: SearchSchemaElement[] | undefined;
    Projection: Projection;
    Dimensions: number;
    DistanceFunction: VectorDistanceFunction;
}
export type VectorIndexList = VectorIndex[];
export interface CreateTableInput {
    AttributeDefinitions?: AttributeDefinition[] | undefined;
    TableName: string;
    KeySchema?: KeySchemaElement[] | undefined;
    LocalSecondaryIndexes?: LocalSecondaryIndex[] | undefined;
    GlobalSecondaryIndexes?: GlobalSecondaryIndex[] | undefined;
    BillingMode?: BillingMode | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    StreamSpecification?: StreamSpecification | undefined;
    SSESpecification?: SSESpecification | undefined;
    Tags?: Tag[] | undefined;
    TableClass?: TableClass | undefined;
    DeletionProtectionEnabled?: boolean | undefined;
    WarmThroughput?: WarmThroughput | undefined;
    ResourcePolicy?: string | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    GlobalTableSourceArn?: string | undefined;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode | undefined;
    VectorIndexes?: VectorIndex[] | undefined;
}
export type NonNegativeLongObject = number;
export interface ProvisionedThroughputDescription {
    LastIncreaseDateTime?: Date | undefined;
    LastDecreaseDateTime?: Date | undefined;
    NumberOfDecreasesToday?: number | undefined;
    ReadCapacityUnits?: number | undefined;
    WriteCapacityUnits?: number | undefined;
}
export type TableId = string;
export interface BillingModeSummary {
    BillingMode?: BillingMode | undefined;
    LastUpdateToPayPerRequestDateTime?: Date | undefined;
}
export interface LocalSecondaryIndexDescription {
    IndexName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    Projection?: Projection | undefined;
    IndexSizeBytes?: number | undefined;
    ItemCount?: number | undefined;
    IndexArn?: string | undefined;
}
export type LocalSecondaryIndexDescriptionList = LocalSecondaryIndexDescription[];
export type Backfilling = boolean;
export interface GlobalSecondaryIndexDescription {
    IndexName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    Projection?: Projection | undefined;
    IndexStatus?: IndexStatus | undefined;
    Backfilling?: boolean | undefined;
    ProvisionedThroughput?: ProvisionedThroughputDescription | undefined;
    IndexSizeBytes?: number | undefined;
    ItemCount?: number | undefined;
    IndexArn?: string | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: GlobalSecondaryIndexWarmThroughputDescription | undefined;
}
export type GlobalSecondaryIndexDescriptionList = GlobalSecondaryIndexDescription[];
export type StreamArn = string;
export type WitnessStatus = "CREATING" | "DELETING" | "ACTIVE" | (string & {});
export interface GlobalTableWitnessDescription {
    RegionName?: string | undefined;
    WitnessStatus?: WitnessStatus | undefined;
}
export type GlobalTableWitnessDescriptionList = GlobalTableWitnessDescription[];
export type RestoreInProgress = boolean;
export interface RestoreSummary {
    SourceBackupArn?: string | undefined;
    SourceTableArn?: string | undefined;
    RestoreDateTime: Date;
    RestoreInProgress: boolean;
}
export type SSEStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "UPDATING" | (string & {});
export type KMSMasterKeyArn = string;
export interface SSEDescription {
    Status?: SSEStatus | undefined;
    SSEType?: SSEType | undefined;
    KMSMasterKeyArn?: string | undefined;
    InaccessibleEncryptionDateTime?: Date | undefined;
}
export type ArchivalReason = string;
export interface ArchivalSummary {
    ArchivalDateTime?: Date | undefined;
    ArchivalReason?: string | undefined;
    ArchivalBackupArn?: string | undefined;
}
export type DisassociationProtectionEnabled = boolean;
export type MultiRegionConsistency = "EVENTUAL" | "STRONG" | (string & {});
export interface VectorIndexDescription {
    IndexName?: string | undefined;
    SearchSchema?: SearchSchemaElement[] | undefined;
    Projection?: Projection | undefined;
    VectorAttribute?: VectorAttributeDefinition | undefined;
    Dimensions?: number | undefined;
    DistanceFunction?: VectorDistanceFunction | undefined;
    IndexStatus?: IndexStatus | undefined;
    Backfilling?: boolean | undefined;
    IndexSizeBytes?: number | undefined;
    ItemCount?: number | undefined;
    IndexArn?: string | undefined;
}
export type VectorIndexDescriptionList = VectorIndexDescription[];
export interface TableDescription {
    AttributeDefinitions?: AttributeDefinition[] | undefined;
    TableName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    TableStatus?: TableStatus | undefined;
    CreationDateTime?: Date | undefined;
    ProvisionedThroughput?: ProvisionedThroughputDescription | undefined;
    TableSizeBytes?: number | undefined;
    ItemCount?: number | undefined;
    TableArn?: string | undefined;
    TableId?: string | undefined;
    BillingModeSummary?: BillingModeSummary | undefined;
    LocalSecondaryIndexes?: LocalSecondaryIndexDescription[] | undefined;
    GlobalSecondaryIndexes?: GlobalSecondaryIndexDescription[] | undefined;
    StreamSpecification?: StreamSpecification | undefined;
    LatestStreamLabel?: string | undefined;
    LatestStreamArn?: string | undefined;
    GlobalTableVersion?: string | undefined;
    Replicas?: ReplicaDescription[] | undefined;
    GlobalTableWitnesses?: GlobalTableWitnessDescription[] | undefined;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode | undefined;
    RestoreSummary?: RestoreSummary | undefined;
    SSEDescription?: SSEDescription | undefined;
    ArchivalSummary?: ArchivalSummary | undefined;
    TableClassSummary?: TableClassSummary | undefined;
    DeletionProtectionEnabled?: boolean | undefined;
    DisassociationProtectionEnabled?: boolean | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: TableWarmThroughputDescription | undefined;
    MultiRegionConsistency?: MultiRegionConsistency | undefined;
    VectorIndexes?: VectorIndexDescription[] | undefined;
}
export interface CreateTableOutput {
    TableDescription?: TableDescription | undefined;
}
export interface DeleteBackupInput {
    BackupArn: string;
}
export type TableCreationDateTime = Date;
export type ItemCount = number;
export interface SourceTableDetails {
    TableName: string;
    TableId: string;
    TableArn?: string | undefined;
    TableSizeBytes?: number | undefined;
    KeySchema: KeySchemaElement[];
    TableCreationDateTime: Date;
    ProvisionedThroughput: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    ItemCount?: number | undefined;
    BillingMode?: BillingMode | undefined;
}
export interface LocalSecondaryIndexInfo {
    IndexName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    Projection?: Projection | undefined;
}
export type LocalSecondaryIndexes = LocalSecondaryIndexInfo[];
export interface GlobalSecondaryIndexInfo {
    IndexName?: string | undefined;
    KeySchema?: KeySchemaElement[] | undefined;
    Projection?: Projection | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
}
export type GlobalSecondaryIndexes = GlobalSecondaryIndexInfo[];
export type TimeToLiveStatus = "ENABLING" | "DISABLING" | "ENABLED" | "DISABLED" | (string & {});
export type TimeToLiveAttributeName = string;
export interface TimeToLiveDescription {
    TimeToLiveStatus?: TimeToLiveStatus | undefined;
    AttributeName?: string | undefined;
}
export interface VectorIndexInfo {
    IndexName?: string | undefined;
    VectorAttribute?: VectorAttributeDefinition | undefined;
    SearchSchema?: SearchSchemaElement[] | undefined;
    Projection?: Projection | undefined;
    Dimensions?: number | undefined;
    DistanceFunction?: VectorDistanceFunction | undefined;
}
export type VectorIndexes = VectorIndexInfo[];
export interface SourceTableFeatureDetails {
    LocalSecondaryIndexes?: LocalSecondaryIndexInfo[] | undefined;
    GlobalSecondaryIndexes?: GlobalSecondaryIndexInfo[] | undefined;
    StreamDescription?: StreamSpecification | undefined;
    TimeToLiveDescription?: TimeToLiveDescription | undefined;
    SSEDescription?: SSEDescription | undefined;
    VectorIndexes?: VectorIndexInfo[] | undefined;
}
export interface BackupDescription {
    BackupDetails?: BackupDetails | undefined;
    SourceTableDetails?: SourceTableDetails | undefined;
    SourceTableFeatureDetails?: SourceTableFeatureDetails | undefined;
}
export interface DeleteBackupOutput {
    BackupDescription?: BackupDescription | undefined;
}
export type ComparisonOperator = "EQ" | "NE" | "IN" | "LE" | "LT" | "GE" | "GT" | "BETWEEN" | "NOT_NULL" | "NULL" | "CONTAINS" | "NOT_CONTAINS" | "BEGINS_WITH" | (string & {});
export type AttributeValueList = AttributeValue[];
export interface ExpectedAttributeValue {
    Value?: AttributeValue | undefined;
    Exists?: boolean | undefined;
    ComparisonOperator?: ComparisonOperator | undefined;
    AttributeValueList?: AttributeValue[] | undefined;
}
export type ExpectedAttributeMap = {
    [key: string]: ExpectedAttributeValue | undefined;
};
export type ConditionalOperator = "AND" | "OR" | (string & {});
export type ReturnValue = "NONE" | "ALL_OLD" | "UPDATED_OLD" | "ALL_NEW" | "UPDATED_NEW" | (string & {});
export type ConditionExpression = string;
export type ExpressionAttributeValueVariable = string;
export type ExpressionAttributeValueMap = {
    [key: string]: AttributeValue | undefined;
};
export interface DeleteItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    } | undefined;
    ConditionalOperator?: ConditionalOperator | undefined;
    ReturnValues?: ReturnValue | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics | undefined;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface DeleteItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
    ItemCollectionMetrics?: ItemCollectionMetrics | undefined;
}
export type ResourceArnString = string;
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyInput {
    ResourceArn: string;
    ExpectedRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyOutput {
    RevisionId?: string | undefined;
}
export interface DeleteTableInput {
    TableName: string;
}
export interface DeleteTableOutput {
    TableDescription?: TableDescription | undefined;
}
export interface DescribeBackupInput {
    BackupArn: string;
}
export interface DescribeBackupOutput {
    BackupDescription?: BackupDescription | undefined;
}
export interface DescribeBulkOperationInput {
    BulkOperationArn: string;
}
export interface BulkOperationTableDetail {
    TableName?: string | undefined;
    TableId?: string | undefined;
}
export type BulkOperationTableDetails = BulkOperationTableDetail[];
export type ClientToken = string;
export type S3BucketOwner = string;
export type S3Bucket = string;
export type S3Prefix = string;
export type BulkOperationInputFormat = "DYNAMODB_JSON" | "ION" | (string & {});
export type InputCompressionType = "GZIP" | "ZSTD" | "NONE" | (string & {});
export interface InputS3Configuration {
    S3BucketOwner?: string | undefined;
    S3Bucket: string;
    S3KeyPrefix?: string | undefined;
    InputFormat: BulkOperationInputFormat;
    InputCompressionType?: InputCompressionType | undefined;
}
export type S3SseAlgorithm = "AES256" | "KMS" | (string & {});
export type S3SseKmsKeyId = string;
export type OutputTypeEnum = "ERROR" | "CONDITION_CHECK_FAILURE" | (string & {});
export type OutputTypeList = OutputTypeEnum[];
export interface OutputS3Configuration {
    S3BucketOwner?: string | undefined;
    S3Bucket?: string | undefined;
    S3KeyPrefix?: string | undefined;
    S3SseAlgorithm?: S3SseAlgorithm | undefined;
    S3SseKmsKeyId?: string | undefined;
    OutputType: OutputTypeEnum[];
}
export type BulkOperationStartTime = Date;
export type BulkOperationEndTime = Date;
export type BulkOperationItemCount = number;
export type ProcessedInputBytes = number;
export type TotalInputBytes = number;
export interface BulkOperationBytes {
    BulkPutBytes?: number | undefined;
}
export type SecondaryIndexesBulkBytesMap = {
    [key: string]: BulkOperationBytes | undefined;
};
export interface BulkOperationVectorBytes {
    BulkPutVectorBytes?: number | undefined;
}
export type VectorIndexesBulkVectorBytesMap = {
    [key: string]: BulkOperationVectorBytes | undefined;
};
export interface BulkOperationUsage {
    TableName?: string | undefined;
    BulkPutBytes?: number | undefined;
    Table?: BulkOperationBytes | undefined;
    LocalSecondaryIndexes?: {
        [key: string]: BulkOperationBytes | undefined;
    } | undefined;
    GlobalSecondaryIndexes?: {
        [key: string]: BulkOperationBytes | undefined;
    } | undefined;
    VectorIndexes?: {
        [key: string]: BulkOperationVectorBytes | undefined;
    } | undefined;
}
export type BulkOperationUsageMultiple = BulkOperationUsage[];
export type FailureCode = string;
export type FailureMessage = string;
export type BulkOperationMaxWriteRequestUnits = number;
export type BulkOperationPerformanceTier = "STANDARD" | "ACCELERATED" | (string & {});
export interface BulkOperationDescription {
    BulkOperationArn?: string | undefined;
    BulkOperationStatus?: BulkOperationStatus | undefined;
    TableDetails?: BulkOperationTableDetail[] | undefined;
    ClientToken?: string | undefined;
    InputS3Configuration?: InputS3Configuration | undefined;
    OutputS3Configuration?: OutputS3Configuration | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ProcessedItemCount?: number | undefined;
    ProcessedInputBytes?: number | undefined;
    TotalInputBytes?: number | undefined;
    BulkOperationUsage?: BulkOperationUsage[] | undefined;
    FailedItemCount?: number | undefined;
    FailureCode?: string | undefined;
    FailureMessage?: string | undefined;
    MaxWriteRequestUnits?: number | undefined;
    PerformanceTier?: BulkOperationPerformanceTier | undefined;
}
export interface DescribeBulkOperationOutput {
    BulkOperationDescription: BulkOperationDescription;
}
export interface DescribeContinuousBackupsInput {
    TableName: string;
}
export type ContinuousBackupsStatus = "ENABLED" | "DISABLED" | (string & {});
export type PointInTimeRecoveryStatus = "ENABLED" | "DISABLED" | (string & {});
export type RecoveryPeriodInDays = number;
export interface PointInTimeRecoveryDescription {
    PointInTimeRecoveryStatus?: PointInTimeRecoveryStatus | undefined;
    RecoveryPeriodInDays?: number | undefined;
    EarliestRestorableDateTime?: Date | undefined;
    LatestRestorableDateTime?: Date | undefined;
}
export interface ContinuousBackupsDescription {
    ContinuousBackupsStatus: ContinuousBackupsStatus;
    PointInTimeRecoveryDescription?: PointInTimeRecoveryDescription | undefined;
}
export interface DescribeContinuousBackupsOutput {
    ContinuousBackupsDescription?: ContinuousBackupsDescription | undefined;
}
export interface DescribeContributorInsightsInput {
    TableName: string;
    IndexName?: string | undefined;
}
export type ContributorInsightsRule = string;
export type ContributorInsightsRuleList = string[];
export type ContributorInsightsStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "FAILED" | (string & {});
export type LastUpdateDateTime = Date;
export type ExceptionName = string;
export type ExceptionDescription = string;
export interface FailureException {
    ExceptionName?: string | undefined;
    ExceptionDescription?: string | undefined;
}
export type ContributorInsightsMode = "ACCESSED_AND_THROTTLED_KEYS" | "THROTTLED_KEYS" | (string & {});
export interface DescribeContributorInsightsOutput {
    TableName?: string | undefined;
    IndexName?: string | undefined;
    ContributorInsightsRuleList?: string[] | undefined;
    ContributorInsightsStatus?: ContributorInsightsStatus | undefined;
    LastUpdateDateTime?: Date | undefined;
    FailureException?: FailureException | undefined;
    ContributorInsightsMode?: ContributorInsightsMode | undefined;
}
export interface DescribeEndpointsRequest {
}
export interface Endpoint {
    Address: string;
    CachePeriodInMinutes: number;
}
export type Endpoints = Endpoint[];
export interface DescribeEndpointsResponse {
    Endpoints: Endpoint[];
}
export type ExportArn = string;
export interface DescribeExportInput {
    ExportArn: string;
}
export type ExportStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type ExportStartTime = Date;
export type ExportEndTime = Date;
export type ExportManifest = string;
export type ExportTime = Date;
export type ExportFormat = "DYNAMODB_JSON" | "ION" | (string & {});
export type BilledSizeBytes = number;
export type ExportType = "FULL_EXPORT" | "INCREMENTAL_EXPORT" | (string & {});
export type ExportFromTime = Date;
export type ExportToTime = Date;
export type ExportViewType = "NEW_IMAGE" | "NEW_AND_OLD_IMAGES" | (string & {});
export interface IncrementalExportSpecification {
    ExportFromTime?: Date | undefined;
    ExportToTime?: Date | undefined;
    ExportViewType?: ExportViewType | undefined;
}
export type KeyExpression = string;
export interface FilterSpecification {
    FilterExpression?: string | undefined;
    ProjectionExpression?: string | undefined;
    KeyConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface ExportDescription {
    ExportArn?: string | undefined;
    ExportStatus?: ExportStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ExportManifest?: string | undefined;
    TableArn?: string | undefined;
    TableId?: string | undefined;
    ExportTime?: Date | undefined;
    ClientToken?: string | undefined;
    S3Bucket?: string | undefined;
    S3BucketOwner?: string | undefined;
    S3Prefix?: string | undefined;
    S3SseAlgorithm?: S3SseAlgorithm | undefined;
    S3SseKmsKeyId?: string | undefined;
    FailureCode?: string | undefined;
    FailureMessage?: string | undefined;
    ExportFormat?: ExportFormat | undefined;
    BilledSizeBytes?: number | undefined;
    ItemCount?: number | undefined;
    ExportType?: ExportType | undefined;
    IncrementalExportSpecification?: IncrementalExportSpecification | undefined;
    FilterSpecification?: FilterSpecification | undefined;
}
export interface DescribeExportOutput {
    ExportDescription?: ExportDescription | undefined;
}
export interface DescribeGlobalTableInput {
    GlobalTableName: string;
}
export interface DescribeGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription | undefined;
}
export interface DescribeGlobalTableSettingsInput {
    GlobalTableName: string;
}
export type AutoScalingPolicyName = string;
export type IntegerObject = number;
export type DoubleObject = number;
export interface AutoScalingTargetTrackingScalingPolicyConfigurationDescription {
    DisableScaleIn?: boolean | undefined;
    ScaleInCooldown?: number | undefined;
    ScaleOutCooldown?: number | undefined;
    TargetValue: number;
}
export interface AutoScalingPolicyDescription {
    PolicyName?: string | undefined;
    TargetTrackingScalingPolicyConfiguration?: AutoScalingTargetTrackingScalingPolicyConfigurationDescription | undefined;
}
export type AutoScalingPolicyDescriptionList = AutoScalingPolicyDescription[];
export interface AutoScalingSettingsDescription {
    MinimumUnits?: number | undefined;
    MaximumUnits?: number | undefined;
    AutoScalingDisabled?: boolean | undefined;
    AutoScalingRoleArn?: string | undefined;
    ScalingPolicies?: AutoScalingPolicyDescription[] | undefined;
}
export interface ReplicaGlobalSecondaryIndexSettingsDescription {
    IndexName: string;
    IndexStatus?: IndexStatus | undefined;
    ProvisionedReadCapacityUnits?: number | undefined;
    ProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ProvisionedWriteCapacityUnits?: number | undefined;
    ProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
}
export type ReplicaGlobalSecondaryIndexSettingsDescriptionList = ReplicaGlobalSecondaryIndexSettingsDescription[];
export interface ReplicaSettingsDescription {
    RegionName: string;
    ReplicaStatus?: ReplicaStatus | undefined;
    ReplicaBillingModeSummary?: BillingModeSummary | undefined;
    ReplicaProvisionedReadCapacityUnits?: number | undefined;
    ReplicaProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ReplicaProvisionedWriteCapacityUnits?: number | undefined;
    ReplicaProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ReplicaGlobalSecondaryIndexSettings?: ReplicaGlobalSecondaryIndexSettingsDescription[] | undefined;
    ReplicaTableClassSummary?: TableClassSummary | undefined;
}
export type ReplicaSettingsDescriptionList = ReplicaSettingsDescription[];
export interface DescribeGlobalTableSettingsOutput {
    GlobalTableName?: string | undefined;
    ReplicaSettings?: ReplicaSettingsDescription[] | undefined;
}
export type ImportArn = string;
export interface DescribeImportInput {
    ImportArn: string;
}
export type ImportStatus = "IN_PROGRESS" | "COMPLETED" | "CANCELLING" | "CANCELLED" | "FAILED" | (string & {});
export interface S3BucketSource {
    S3BucketOwner?: string | undefined;
    S3Bucket: string;
    S3KeyPrefix?: string | undefined;
}
export type ErrorCount = number;
export type CloudWatchLogGroupArn = string;
export type InputFormat = "DYNAMODB_JSON" | "ION" | "CSV" | (string & {});
export type CsvDelimiter = string;
export type CsvHeader = string;
export type CsvHeaderList = string[];
export interface CsvOptions {
    Delimiter?: string | undefined;
    HeaderList?: string[] | undefined;
}
export interface InputFormatOptions {
    Csv?: CsvOptions | undefined;
}
export interface TableCreationParameters {
    TableName: string;
    AttributeDefinitions: AttributeDefinition[];
    KeySchema: KeySchemaElement[];
    BillingMode?: BillingMode | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    SSESpecification?: SSESpecification | undefined;
    GlobalSecondaryIndexes?: GlobalSecondaryIndex[] | undefined;
    VectorIndexes?: VectorIndex[] | undefined;
}
export type ImportStartTime = Date;
export type ImportEndTime = Date;
export type ProcessedItemCount = number;
export type ImportedItemCount = number;
export interface ImportTableDescription {
    ImportArn?: string | undefined;
    ImportStatus?: ImportStatus | undefined;
    TableArn?: string | undefined;
    TableId?: string | undefined;
    ClientToken?: string | undefined;
    S3BucketSource?: S3BucketSource | undefined;
    ErrorCount?: number | undefined;
    CloudWatchLogGroupArn?: string | undefined;
    InputFormat?: InputFormat | undefined;
    InputFormatOptions?: InputFormatOptions | undefined;
    InputCompressionType?: InputCompressionType | undefined;
    TableCreationParameters?: TableCreationParameters | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ProcessedSizeBytes?: number | undefined;
    ProcessedItemCount?: number | undefined;
    ImportedItemCount?: number | undefined;
    FailureCode?: string | undefined;
    FailureMessage?: string | undefined;
}
export interface DescribeImportOutput {
    ImportTableDescription: ImportTableDescription;
}
export interface DescribeKinesisStreamingDestinationInput {
    TableName: string;
}
export type DestinationStatus = "ENABLING" | "ACTIVE" | "DISABLING" | "DISABLED" | "ENABLE_FAILED" | "UPDATING" | (string & {});
export type ApproximateCreationDateTimePrecision = "MILLISECOND" | "MICROSECOND" | (string & {});
export interface KinesisDataStreamDestination {
    StreamArn?: string | undefined;
    DestinationStatus?: DestinationStatus | undefined;
    DestinationStatusDescription?: string | undefined;
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision | undefined;
}
export type KinesisDataStreamDestinations = KinesisDataStreamDestination[];
export interface DescribeKinesisStreamingDestinationOutput {
    TableName?: string | undefined;
    KinesisDataStreamDestinations?: KinesisDataStreamDestination[] | undefined;
}
export interface DescribeLimitsInput {
}
export interface DescribeLimitsOutput {
    AccountMaxReadCapacityUnits?: number | undefined;
    AccountMaxWriteCapacityUnits?: number | undefined;
    TableMaxReadCapacityUnits?: number | undefined;
    TableMaxWriteCapacityUnits?: number | undefined;
}
export interface DescribeTableInput {
    TableName: string;
}
export interface DescribeTableOutput {
    Table?: TableDescription | undefined;
}
export interface DescribeTableReplicaAutoScalingInput {
    TableName: string;
}
export interface ReplicaGlobalSecondaryIndexAutoScalingDescription {
    IndexName?: string | undefined;
    IndexStatus?: IndexStatus | undefined;
    ProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
}
export type ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = ReplicaGlobalSecondaryIndexAutoScalingDescription[];
export interface ReplicaAutoScalingDescription {
    RegionName?: string | undefined;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndexAutoScalingDescription[] | undefined;
    ReplicaProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ReplicaProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription | undefined;
    ReplicaStatus?: ReplicaStatus | undefined;
}
export type ReplicaAutoScalingDescriptionList = ReplicaAutoScalingDescription[];
export interface TableAutoScalingDescription {
    TableName?: string | undefined;
    TableStatus?: TableStatus | undefined;
    Replicas?: ReplicaAutoScalingDescription[] | undefined;
}
export interface DescribeTableReplicaAutoScalingOutput {
    TableAutoScalingDescription?: TableAutoScalingDescription | undefined;
}
export interface DescribeTimeToLiveInput {
    TableName: string;
}
export interface DescribeTimeToLiveOutput {
    TimeToLiveDescription?: TimeToLiveDescription | undefined;
}
export interface EnableKinesisStreamingConfiguration {
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision | undefined;
}
export interface KinesisStreamingDestinationInput {
    TableName: string;
    StreamArn: string;
    EnableKinesisStreamingConfiguration?: EnableKinesisStreamingConfiguration | undefined;
}
export interface KinesisStreamingDestinationOutput {
    TableName?: string | undefined;
    StreamArn?: string | undefined;
    DestinationStatus?: DestinationStatus | undefined;
    EnableKinesisStreamingConfiguration?: EnableKinesisStreamingConfiguration | undefined;
}
export type PartiQLNextToken = string;
export type PositiveIntegerObject = number;
export interface ExecuteStatementInput {
    Statement: string;
    Parameters?: AttributeValue[] | undefined;
    ConsistentRead?: boolean | undefined;
    NextToken?: string | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    Limit?: number | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface ExecuteStatementOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[] | undefined;
    NextToken?: string | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface ParameterizedStatement {
    Statement: string;
    Parameters?: AttributeValue[] | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export type ParameterizedStatements = ParameterizedStatement[];
export type ClientRequestToken = string;
export interface ExecuteTransactionInput {
    TransactStatements: ParameterizedStatement[];
    ClientRequestToken?: string | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
}
export interface ItemResponse {
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export type ItemResponseList = ItemResponse[];
export interface ExecuteTransactionOutput {
    Responses?: ItemResponse[] | undefined;
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
}
export interface ExportTableToPointInTimeInput {
    TableArn: string;
    ExportTime?: Date | undefined;
    ClientToken?: string | undefined;
    S3Bucket: string;
    S3BucketOwner?: string | undefined;
    S3Prefix?: string | undefined;
    S3SseAlgorithm?: S3SseAlgorithm | undefined;
    S3SseKmsKeyId?: string | undefined;
    ExportFormat?: ExportFormat | undefined;
    ExportType?: ExportType | undefined;
    IncrementalExportSpecification?: IncrementalExportSpecification | undefined;
    FilterSpecification?: FilterSpecification | undefined;
}
export interface ExportTableToPointInTimeOutput {
    ExportDescription?: ExportDescription | undefined;
}
export interface GetItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    AttributesToGet?: string[] | undefined;
    ConsistentRead?: boolean | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ProjectionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetItemOutput {
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
}
export interface GetResourcePolicyInput {
    ResourceArn: string;
}
export interface GetResourcePolicyOutput {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface ImportTableInput {
    ClientToken?: string | undefined;
    S3BucketSource: S3BucketSource;
    InputFormat: InputFormat;
    InputFormatOptions?: InputFormatOptions | undefined;
    InputCompressionType?: InputCompressionType | undefined;
    TableCreationParameters: TableCreationParameters;
}
export interface ImportTableOutput {
    ImportTableDescription: ImportTableDescription;
}
export type BackupsInputLimit = number;
export type TimeRangeLowerBound = Date;
export type TimeRangeUpperBound = Date;
export type BackupTypeFilter = "USER" | "SYSTEM" | "AWS_BACKUP" | "ALL" | (string & {});
export interface ListBackupsInput {
    TableName?: string | undefined;
    Limit?: number | undefined;
    TimeRangeLowerBound?: Date | undefined;
    TimeRangeUpperBound?: Date | undefined;
    ExclusiveStartBackupArn?: string | undefined;
    BackupType?: BackupTypeFilter | undefined;
}
export interface BackupSummary {
    TableName?: string | undefined;
    TableId?: string | undefined;
    TableArn?: string | undefined;
    BackupArn?: string | undefined;
    BackupName?: string | undefined;
    BackupCreationDateTime?: Date | undefined;
    BackupExpiryDateTime?: Date | undefined;
    BackupStatus?: BackupStatus | undefined;
    BackupType?: BackupType | undefined;
    BackupSizeBytes?: number | undefined;
}
export type BackupSummaries = BackupSummary[];
export interface ListBackupsOutput {
    BackupSummaries?: BackupSummary[] | undefined;
    LastEvaluatedBackupArn?: string | undefined;
}
export type ListBulkOperationsMaxLimit = number;
export type BulkOperationNextToken = string;
export interface ListBulkOperationsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface BulkOperationSummary {
    BulkOperationArn: string;
    BulkOperationStatus: BulkOperationStatus;
    StartTime: Date;
    EndTime?: Date | undefined;
}
export type BulkOperationsSummaryList = BulkOperationSummary[];
export interface ListBulkOperationsOutput {
    BulkOperationsSummaryList?: BulkOperationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type NextTokenString = string;
export type ListContributorInsightsLimit = number;
export interface ListContributorInsightsInput {
    TableName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ContributorInsightsSummary {
    TableName?: string | undefined;
    IndexName?: string | undefined;
    ContributorInsightsStatus?: ContributorInsightsStatus | undefined;
    ContributorInsightsMode?: ContributorInsightsMode | undefined;
}
export type ContributorInsightsSummaries = ContributorInsightsSummary[];
export interface ListContributorInsightsOutput {
    ContributorInsightsSummaries?: ContributorInsightsSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ListExportsMaxLimit = number;
export type ExportNextToken = string;
export interface ListExportsInput {
    TableArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ExportSummary {
    ExportArn?: string | undefined;
    ExportStatus?: ExportStatus | undefined;
    ExportType?: ExportType | undefined;
}
export type ExportSummaries = ExportSummary[];
export interface ListExportsOutput {
    ExportSummaries?: ExportSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGlobalTablesInput {
    ExclusiveStartGlobalTableName?: string | undefined;
    Limit?: number | undefined;
    RegionName?: string | undefined;
}
export interface GlobalTable {
    GlobalTableName?: string | undefined;
    ReplicationGroup?: Replica[] | undefined;
}
export type GlobalTableList = GlobalTable[];
export interface ListGlobalTablesOutput {
    GlobalTables?: GlobalTable[] | undefined;
    LastEvaluatedGlobalTableName?: string | undefined;
}
export type ListImportsMaxLimit = number;
export type ImportNextToken = string;
export interface ListImportsInput {
    TableArn?: string | undefined;
    PageSize?: number | undefined;
    NextToken?: string | undefined;
}
export interface ImportSummary {
    ImportArn?: string | undefined;
    ImportStatus?: ImportStatus | undefined;
    TableArn?: string | undefined;
    S3BucketSource?: S3BucketSource | undefined;
    CloudWatchLogGroupArn?: string | undefined;
    InputFormat?: InputFormat | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type ImportSummaryList = ImportSummary[];
export interface ListImportsOutput {
    ImportSummaryList?: ImportSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ListTablesInputLimit = number;
export interface ListTablesInput {
    ExclusiveStartTableName?: string | undefined;
    Limit?: number | undefined;
}
export type TableNameList = string[];
export interface ListTablesOutput {
    TableNames?: string[] | undefined;
    LastEvaluatedTableName?: string | undefined;
}
export interface ListTagsOfResourceInput {
    ResourceArn: string;
    NextToken?: string | undefined;
}
export interface ListTagsOfResourceOutput {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export interface PutItemInput {
    TableName: string;
    Item: {
        [key: string]: AttributeValue | undefined;
    };
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    } | undefined;
    ReturnValues?: ReturnValue | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics | undefined;
    ConditionalOperator?: ConditionalOperator | undefined;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface PutItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
    ItemCollectionMetrics?: ItemCollectionMetrics | undefined;
}
export type ConfirmRemoveSelfResourceAccess = boolean;
export interface PutResourcePolicyInput {
    ResourceArn: string;
    Policy: string;
    ExpectedRevisionId?: string | undefined;
    ConfirmRemoveSelfResourceAccess?: boolean | undefined;
}
export interface PutResourcePolicyOutput {
    RevisionId?: string | undefined;
}
export type Select = "ALL_ATTRIBUTES" | "ALL_PROJECTED_ATTRIBUTES" | "SPECIFIC_ATTRIBUTES" | "COUNT" | (string & {});
export interface Condition {
    AttributeValueList?: AttributeValue[] | undefined;
    ComparisonOperator: ComparisonOperator;
}
export type KeyConditions = {
    [key: string]: Condition | undefined;
};
export type FilterConditionMap = {
    [key: string]: Condition | undefined;
};
export interface QueryInput {
    TableName: string;
    IndexName?: string | undefined;
    Select?: Select | undefined;
    AttributesToGet?: string[] | undefined;
    Limit?: number | undefined;
    ConsistentRead?: boolean | undefined;
    KeyConditions?: {
        [key: string]: Condition | undefined;
    } | undefined;
    QueryFilter?: {
        [key: string]: Condition | undefined;
    } | undefined;
    ConditionalOperator?: ConditionalOperator | undefined;
    ScanIndexForward?: boolean | undefined;
    ExclusiveStartKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ProjectionExpression?: string | undefined;
    FilterExpression?: string | undefined;
    KeyConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface QueryOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[] | undefined;
    Count?: number | undefined;
    ScannedCount?: number | undefined;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
}
export interface RestoreTableFromBackupInput {
    TargetTableName: string;
    BackupArn: string;
    BillingModeOverride?: BillingMode | undefined;
    GlobalSecondaryIndexOverride?: GlobalSecondaryIndex[] | undefined;
    LocalSecondaryIndexOverride?: LocalSecondaryIndex[] | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughput | undefined;
    OnDemandThroughputOverride?: OnDemandThroughput | undefined;
    SSESpecificationOverride?: SSESpecification | undefined;
    VectorIndexOverride?: VectorIndex[] | undefined;
}
export interface RestoreTableFromBackupOutput {
    TableDescription?: TableDescription | undefined;
}
export interface RestoreTableToPointInTimeInput {
    SourceTableArn?: string | undefined;
    SourceTableName?: string | undefined;
    TargetTableName: string;
    UseLatestRestorableTime?: boolean | undefined;
    RestoreDateTime?: Date | undefined;
    BillingModeOverride?: BillingMode | undefined;
    GlobalSecondaryIndexOverride?: GlobalSecondaryIndex[] | undefined;
    LocalSecondaryIndexOverride?: LocalSecondaryIndex[] | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughput | undefined;
    OnDemandThroughputOverride?: OnDemandThroughput | undefined;
    SSESpecificationOverride?: SSESpecification | undefined;
    VectorIndexOverride?: VectorIndex[] | undefined;
}
export interface RestoreTableToPointInTimeOutput {
    TableDescription?: TableDescription | undefined;
}
export type ScanTotalSegments = number;
export type ScanSegment = number;
export interface ScanInput {
    TableName: string;
    IndexName?: string | undefined;
    AttributesToGet?: string[] | undefined;
    Limit?: number | undefined;
    Select?: Select | undefined;
    ScanFilter?: {
        [key: string]: Condition | undefined;
    } | undefined;
    ConditionalOperator?: ConditionalOperator | undefined;
    ExclusiveStartKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    TotalSegments?: number | undefined;
    Segment?: number | undefined;
    ProjectionExpression?: string | undefined;
    FilterExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsistentRead?: boolean | undefined;
}
export interface ScanOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[] | undefined;
    Count?: number | undefined;
    ScannedCount?: number | undefined;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
}
export type SearchVectorList = AttributeValue[];
export type TopKInteger = number;
export interface SearchVectorsInput {
    TableName: string;
    IndexName: string;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ProjectionExpression?: string | undefined;
    SearchVector: AttributeValue[];
    SearchConditionExpression?: string | undefined;
    TopK: number;
}
export type ScoreNumber = number;
export interface SearchResultItem {
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    Score?: number | undefined;
}
export type SearchResultList = SearchResultItem[];
export interface SearchVectorsOutput {
    ConsumedCapacity?: VectorCapacity | undefined;
    SearchResults?: SearchResultItem[] | undefined;
}
export interface StartBulkPutItemsInput {
    ClientToken?: string | undefined;
    InputS3Configuration: InputS3Configuration;
    OutputS3Configuration: OutputS3Configuration;
    TableName: string;
    MaxWriteRequestUnits?: number | undefined;
    PerformanceTier?: BulkOperationPerformanceTier | undefined;
}
export interface StartBulkPutItemsOutput {
    BulkOperationDescription: BulkOperationDescription;
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface Get {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ProjectionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TransactGetItem {
    Get: Get;
}
export type TransactGetItemList = TransactGetItem[];
export interface TransactGetItemsInput {
    TransactItems: TransactGetItem[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
}
export interface TransactGetItemsOutput {
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
    Responses?: ItemResponse[] | undefined;
}
export interface ConditionCheck {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface Put {
    Item: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface Delete {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export type UpdateExpression = string;
export interface Update {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    UpdateExpression: string;
    TableName: string;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface TransactWriteItem {
    ConditionCheck?: ConditionCheck | undefined;
    Put?: Put | undefined;
    Delete?: Delete | undefined;
    Update?: Update | undefined;
}
export type TransactWriteItemList = TransactWriteItem[];
export interface TransactWriteItemsInput {
    TransactItems: TransactWriteItem[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics | undefined;
    ClientRequestToken?: string | undefined;
}
export interface TransactWriteItemsOutput {
    ConsumedCapacity?: ConsumedCapacity[] | undefined;
    ItemCollectionMetrics?: {
        [key: string]: ItemCollectionMetrics[] | undefined;
    } | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface PointInTimeRecoverySpecification {
    PointInTimeRecoveryEnabled: boolean;
    RecoveryPeriodInDays?: number | undefined;
}
export interface UpdateContinuousBackupsInput {
    TableName: string;
    PointInTimeRecoverySpecification: PointInTimeRecoverySpecification;
}
export interface UpdateContinuousBackupsOutput {
    ContinuousBackupsDescription?: ContinuousBackupsDescription | undefined;
}
export type ContributorInsightsAction = "ENABLE" | "DISABLE" | (string & {});
export interface UpdateContributorInsightsInput {
    TableName: string;
    IndexName?: string | undefined;
    ContributorInsightsAction: ContributorInsightsAction;
    ContributorInsightsMode?: ContributorInsightsMode | undefined;
}
export interface UpdateContributorInsightsOutput {
    TableName?: string | undefined;
    IndexName?: string | undefined;
    ContributorInsightsStatus?: ContributorInsightsStatus | undefined;
    ContributorInsightsMode?: ContributorInsightsMode | undefined;
}
export interface CreateReplicaAction {
    RegionName: string;
}
export interface DeleteReplicaAction {
    RegionName: string;
}
export interface ReplicaUpdate {
    Create?: CreateReplicaAction | undefined;
    Delete?: DeleteReplicaAction | undefined;
}
export type ReplicaUpdateList = ReplicaUpdate[];
export interface UpdateGlobalTableInput {
    GlobalTableName: string;
    ReplicaUpdates: ReplicaUpdate[];
}
export interface UpdateGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription | undefined;
}
export type AutoScalingRoleArn = string;
export interface AutoScalingTargetTrackingScalingPolicyConfigurationUpdate {
    DisableScaleIn?: boolean | undefined;
    ScaleInCooldown?: number | undefined;
    ScaleOutCooldown?: number | undefined;
    TargetValue: number;
}
export interface AutoScalingPolicyUpdate {
    PolicyName?: string | undefined;
    TargetTrackingScalingPolicyConfiguration: AutoScalingTargetTrackingScalingPolicyConfigurationUpdate;
}
export interface AutoScalingSettingsUpdate {
    MinimumUnits?: number | undefined;
    MaximumUnits?: number | undefined;
    AutoScalingDisabled?: boolean | undefined;
    AutoScalingRoleArn?: string | undefined;
    ScalingPolicyUpdate?: AutoScalingPolicyUpdate | undefined;
}
export interface GlobalTableGlobalSecondaryIndexSettingsUpdate {
    IndexName: string;
    ProvisionedWriteCapacityUnits?: number | undefined;
    ProvisionedWriteCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate | undefined;
}
export type GlobalTableGlobalSecondaryIndexSettingsUpdateList = GlobalTableGlobalSecondaryIndexSettingsUpdate[];
export interface ReplicaGlobalSecondaryIndexSettingsUpdate {
    IndexName: string;
    ProvisionedReadCapacityUnits?: number | undefined;
    ProvisionedReadCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate | undefined;
}
export type ReplicaGlobalSecondaryIndexSettingsUpdateList = ReplicaGlobalSecondaryIndexSettingsUpdate[];
export interface ReplicaSettingsUpdate {
    RegionName: string;
    ReplicaProvisionedReadCapacityUnits?: number | undefined;
    ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate | undefined;
    ReplicaGlobalSecondaryIndexSettingsUpdate?: ReplicaGlobalSecondaryIndexSettingsUpdate[] | undefined;
    ReplicaTableClass?: TableClass | undefined;
}
export type ReplicaSettingsUpdateList = ReplicaSettingsUpdate[];
export interface UpdateGlobalTableSettingsInput {
    GlobalTableName: string;
    GlobalTableBillingMode?: BillingMode | undefined;
    GlobalTableProvisionedWriteCapacityUnits?: number | undefined;
    GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate | undefined;
    GlobalTableGlobalSecondaryIndexSettingsUpdate?: GlobalTableGlobalSecondaryIndexSettingsUpdate[] | undefined;
    ReplicaSettingsUpdate?: ReplicaSettingsUpdate[] | undefined;
}
export interface UpdateGlobalTableSettingsOutput {
    GlobalTableName?: string | undefined;
    ReplicaSettings?: ReplicaSettingsDescription[] | undefined;
}
export type AttributeAction = "ADD" | "PUT" | "DELETE" | (string & {});
export interface AttributeValueUpdate {
    Value?: AttributeValue | undefined;
    Action?: AttributeAction | undefined;
}
export type AttributeUpdates = {
    [key: string]: AttributeValueUpdate | undefined;
};
export interface UpdateItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    AttributeUpdates?: {
        [key: string]: AttributeValueUpdate | undefined;
    } | undefined;
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    } | undefined;
    ConditionalOperator?: ConditionalOperator | undefined;
    ReturnValues?: ReturnValue | undefined;
    ReturnConsumedCapacity?: ReturnConsumedCapacity | undefined;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics | undefined;
    UpdateExpression?: string | undefined;
    ConditionExpression?: string | undefined;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    } | undefined;
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure | undefined;
}
export interface UpdateItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ConsumedCapacity?: ConsumedCapacity | undefined;
    ItemCollectionMetrics?: ItemCollectionMetrics | undefined;
}
export interface UpdateKinesisStreamingConfiguration {
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision | undefined;
}
export interface UpdateKinesisStreamingDestinationInput {
    TableName: string;
    StreamArn: string;
    UpdateKinesisStreamingConfiguration?: UpdateKinesisStreamingConfiguration | undefined;
}
export interface UpdateKinesisStreamingDestinationOutput {
    TableName?: string | undefined;
    StreamArn?: string | undefined;
    DestinationStatus?: DestinationStatus | undefined;
    UpdateKinesisStreamingConfiguration?: UpdateKinesisStreamingConfiguration | undefined;
}
export interface UpdateGlobalSecondaryIndexAction {
    IndexName: string;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: WarmThroughput | undefined;
}
export interface CreateGlobalSecondaryIndexAction {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: WarmThroughput | undefined;
}
export interface DeleteGlobalSecondaryIndexAction {
    IndexName: string;
}
export interface GlobalSecondaryIndexUpdate {
    Update?: UpdateGlobalSecondaryIndexAction | undefined;
    Create?: CreateGlobalSecondaryIndexAction | undefined;
    Delete?: DeleteGlobalSecondaryIndexAction | undefined;
}
export type GlobalSecondaryIndexUpdateList = GlobalSecondaryIndexUpdate[];
export interface ReplicaGlobalSecondaryIndex {
    IndexName: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride | undefined;
    OnDemandThroughputOverride?: OnDemandThroughputOverride | undefined;
}
export type ReplicaGlobalSecondaryIndexList = ReplicaGlobalSecondaryIndex[];
export interface CreateReplicationGroupMemberAction {
    RegionName: string;
    KMSMasterKeyId?: string | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride | undefined;
    OnDemandThroughputOverride?: OnDemandThroughputOverride | undefined;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndex[] | undefined;
    TableClassOverride?: TableClass | undefined;
}
export interface UpdateReplicationGroupMemberAction {
    RegionName: string;
    KMSMasterKeyId?: string | undefined;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride | undefined;
    OnDemandThroughputOverride?: OnDemandThroughputOverride | undefined;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndex[] | undefined;
    TableClassOverride?: TableClass | undefined;
}
export interface DeleteReplicationGroupMemberAction {
    RegionName: string;
}
export type DisassociationMode = "WAIT_FOR_REPLICATION" | (string & {});
export interface DisassociateReplicationGroupMemberAction {
    RegionName: string;
    DisassociationMode: DisassociationMode;
}
export interface ReplicationGroupUpdate {
    Create?: CreateReplicationGroupMemberAction | undefined;
    Update?: UpdateReplicationGroupMemberAction | undefined;
    Delete?: DeleteReplicationGroupMemberAction | undefined;
    Disassociate?: DisassociateReplicationGroupMemberAction | undefined;
}
export type ReplicationGroupUpdateList = ReplicationGroupUpdate[];
export interface CreateGlobalTableWitnessGroupMemberAction {
    RegionName: string;
}
export interface DeleteGlobalTableWitnessGroupMemberAction {
    RegionName: string;
}
export interface GlobalTableWitnessGroupUpdate {
    Create?: CreateGlobalTableWitnessGroupMemberAction | undefined;
    Delete?: DeleteGlobalTableWitnessGroupMemberAction | undefined;
}
export type GlobalTableWitnessGroupUpdateList = GlobalTableWitnessGroupUpdate[];
export interface CreateVectorIndexAction {
    IndexName: string;
    VectorAttribute: VectorAttributeDefinition;
    SearchSchema?: SearchSchemaElement[] | undefined;
    Projection: Projection;
    Dimensions: number;
    DistanceFunction: VectorDistanceFunction;
}
export interface DeleteVectorIndexAction {
    IndexName: string;
}
export interface VectorIndexUpdate {
    Create?: CreateVectorIndexAction | undefined;
    Delete?: DeleteVectorIndexAction | undefined;
}
export type VectorIndexUpdateList = VectorIndexUpdate[];
export interface UpdateTableInput {
    AttributeDefinitions?: AttributeDefinition[] | undefined;
    TableName: string;
    BillingMode?: BillingMode | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    GlobalSecondaryIndexUpdates?: GlobalSecondaryIndexUpdate[] | undefined;
    StreamSpecification?: StreamSpecification | undefined;
    SSESpecification?: SSESpecification | undefined;
    ReplicaUpdates?: ReplicationGroupUpdate[] | undefined;
    TableClass?: TableClass | undefined;
    DeletionProtectionEnabled?: boolean | undefined;
    MultiRegionConsistency?: MultiRegionConsistency | undefined;
    GlobalTableWitnessUpdates?: GlobalTableWitnessGroupUpdate[] | undefined;
    OnDemandThroughput?: OnDemandThroughput | undefined;
    WarmThroughput?: WarmThroughput | undefined;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode | undefined;
    DisassociationProtectionEnabled?: boolean | undefined;
    VectorIndexUpdates?: VectorIndexUpdate[] | undefined;
}
export interface UpdateTableOutput {
    TableDescription?: TableDescription | undefined;
}
export interface GlobalSecondaryIndexAutoScalingUpdate {
    IndexName?: string | undefined;
    ProvisionedWriteCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate | undefined;
}
export type GlobalSecondaryIndexAutoScalingUpdateList = GlobalSecondaryIndexAutoScalingUpdate[];
export interface ReplicaGlobalSecondaryIndexAutoScalingUpdate {
    IndexName?: string | undefined;
    ProvisionedReadCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate | undefined;
}
export type ReplicaGlobalSecondaryIndexAutoScalingUpdateList = ReplicaGlobalSecondaryIndexAutoScalingUpdate[];
export interface ReplicaAutoScalingUpdate {
    RegionName: string;
    ReplicaGlobalSecondaryIndexUpdates?: ReplicaGlobalSecondaryIndexAutoScalingUpdate[] | undefined;
    ReplicaProvisionedReadCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate | undefined;
}
export type ReplicaAutoScalingUpdateList = ReplicaAutoScalingUpdate[];
export interface UpdateTableReplicaAutoScalingInput {
    GlobalSecondaryIndexUpdates?: GlobalSecondaryIndexAutoScalingUpdate[] | undefined;
    TableName: string;
    ProvisionedWriteCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate | undefined;
    ReplicaUpdates?: ReplicaAutoScalingUpdate[] | undefined;
}
export interface UpdateTableReplicaAutoScalingOutput {
    TableAutoScalingDescription?: TableAutoScalingDescription | undefined;
}
export type TimeToLiveEnabled = boolean;
export interface TimeToLiveSpecification {
    Enabled: boolean;
    AttributeName: string;
}
export interface UpdateTimeToLiveInput {
    TableName: string;
    TimeToLiveSpecification: TimeToLiveSpecification;
}
export interface UpdateTimeToLiveOutput {
    TimeToLiveSpecification?: TimeToLiveSpecification | undefined;
}
export type ErrorMessage = string;
export type Reason = string;
export type Resource = string;
export interface ThrottlingReason {
    reason?: string | undefined;
    resource?: string | undefined;
}
export type ThrottlingReasonList = ThrottlingReason[];
export type AvailabilityErrorMessage = string;
export type Code = string;
export interface CancellationReason {
    Item?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type CancellationReasonList = CancellationReason[];
export type BatchExecuteStatementError = InternalServerError | RequestLimitExceeded | ThrottlingException | CommonErrors;
/**
 * This operation allows you to perform batch reads or writes on data stored in DynamoDB,
 * using PartiQL. Each read statement in a `BatchExecuteStatement` must specify
 * an equality condition on all key attributes. This enforces that each `SELECT`
 * statement in a batch returns at most a single item. For more information, see Running batch operations with PartiQL for DynamoDB .
 *
 * The entire batch must consist of either read statements or write statements, you
 * cannot mix both in one batch.
 *
 * A HTTP 200 response does not mean that all statements in the BatchExecuteStatement
 * succeeded. Error details for individual statements can be found under the Error field of the `BatchStatementResponse` for each
 * statement.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementInput & RegionInput, BatchExecuteStatementOutput, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type BatchGetItemError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `BatchGetItem` operation returns the attributes of one or more items
 * from one or more tables. You identify requested items by primary key.
 *
 * A single operation can retrieve up to 16 MB of data, which can contain as many as 100
 * items. `BatchGetItem` returns a partial result if the response size limit is
 * exceeded, the table's provisioned throughput is exceeded, more than 1MB per partition is
 * requested, or an internal processing failure occurs. If a partial result is returned,
 * the operation returns a value for `UnprocessedKeys`. You can use this value
 * to retry the operation starting with the next item to get.
 *
 * If you request more than 100 items, `BatchGetItem` returns a
 * `ValidationException` with the message "Too many items requested for
 * the BatchGetItem call."
 *
 * For example, if you ask to retrieve 100 items, but each individual item is 300 KB in
 * size, the system returns 52 items (so as not to exceed the 16 MB limit). It also returns
 * an appropriate `UnprocessedKeys` value so you can get the next page of
 * results. If desired, your application can include its own logic to assemble the pages of
 * results into one dataset.
 *
 * If *none* of the items can be processed due to insufficient
 * provisioned throughput on all of the tables in the request, then
 * `BatchGetItem` returns a
 * `ProvisionedThroughputExceededException`. If at least
 * one of the items is successfully processed, then
 * `BatchGetItem` completes successfully, while returning the keys of the
 * unread items in `UnprocessedKeys`.
 *
 * If DynamoDB returns any unprocessed items, you should retry the batch operation on
 * those items. However, we strongly recommend that you use an exponential
 * backoff algorithm. If you retry the batch operation immediately, the
 * underlying read or write requests can still fail due to throttling on the individual
 * tables. If you delay the batch operation using exponential backoff, the individual
 * requests in the batch are much more likely to succeed.
 *
 * For more information, see Batch Operations and Error Handling in the Amazon DynamoDB
 * Developer Guide.
 *
 * By default, `BatchGetItem` performs eventually consistent reads on every
 * table in the request. If you want strongly consistent reads instead, you can set
 * `ConsistentRead` to `true` for any or all tables.
 *
 * In order to minimize response latency, `BatchGetItem` may retrieve items in
 * parallel.
 *
 * When designing your application, keep in mind that DynamoDB does not return items in
 * any particular order. To help parse the response by item, include the primary key values
 * for the items in your request in the `ProjectionExpression` parameter.
 *
 * If a requested item does not exist, it is not returned in the result. Requests for
 * nonexistent items consume the minimum read capacity units according to the type of read.
 * For more information, see Working with Tables in the Amazon DynamoDB Developer
 * Guide.
 *
 * `BatchGetItem` will result in a `ValidationException` if the
 * same key is specified multiple times.
 */
export declare const batchGetItem: API.OperationMethod<BatchGetItemInput & RegionInput, BatchGetItemOutput, BatchGetItemError, Credentials | HttpClient.HttpClient>;
export type BatchWriteItemError = InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `BatchWriteItem` operation puts or deletes multiple items in one or
 * more tables. A single call to `BatchWriteItem` can transmit up to 16MB of
 * data over the network, consisting of up to 25 item put or delete operations. While
 * individual items can be up to 400 KB once stored, it's important to note that an item's
 * representation might be greater than 400KB while being sent in DynamoDB's JSON format
 * for the API call. For more details on this distinction, see Naming Rules and Data Types.
 *
 * `BatchWriteItem` cannot update items. If you perform a
 * `BatchWriteItem` operation on an existing item, that item's values
 * will be overwritten by the operation and it will appear like it was updated. To
 * update items, we recommend you use the `UpdateItem` action.
 *
 * The individual `PutItem` and `DeleteItem` operations specified
 * in `BatchWriteItem` are atomic; however `BatchWriteItem` as a
 * whole is not. If any requested operations fail because the table's provisioned
 * throughput is exceeded or an internal processing failure occurs, the failed operations
 * are returned in the `UnprocessedItems` response parameter. You can
 * investigate and optionally resend the requests. Typically, you would call
 * `BatchWriteItem` in a loop. Each iteration would check for unprocessed
 * items and submit a new `BatchWriteItem` request with those unprocessed items
 * until all items have been processed.
 *
 * If `BatchWriteItem` cannot process any items due to throttling (for
 * example, insufficient provisioned throughput on the tables in the request, or
 * partition-level or account-level limits), it returns a
 * `ProvisionedThroughputExceededException` or a
 * `ThrottlingException`. Both indicate that the request was throttled;
 * check the `ThrottlingReason` field in the returned exception for details.
 *
 * If DynamoDB returns any unprocessed items, you should retry the batch operation on
 * those items. However, we strongly recommend that you use an exponential
 * backoff algorithm. If you retry the batch operation immediately, the
 * underlying read or write requests can still fail due to throttling on the individual
 * tables. If you delay the batch operation using exponential backoff, the individual
 * requests in the batch are much more likely to succeed.
 *
 * For more information, see Batch Operations and Error Handling in the Amazon DynamoDB
 * Developer Guide.
 *
 * With `BatchWriteItem`, you can efficiently write or delete large amounts of
 * data, such as from Amazon EMR, or copy data from another database into DynamoDB. In
 * order to improve performance with these large-scale operations,
 * `BatchWriteItem` does not behave in the same way as individual
 * `PutItem` and `DeleteItem` calls would. For example, you
 * cannot specify conditions on individual put and delete requests, and
 * `BatchWriteItem` does not return deleted items in the response.
 *
 * If you use a programming language that supports concurrency, you can use threads to
 * write items in parallel. Your application must include the necessary logic to manage the
 * threads. With languages that don't support threading, you must update or delete the
 * specified items one at a time. In both situations, `BatchWriteItem` performs
 * the specified put and delete operations in parallel, giving you the power of the thread
 * pool approach without having to introduce complexity into your application.
 *
 * Parallel processing reduces latency, but each specified put and delete request
 * consumes the same number of write capacity units whether it is processed in parallel or
 * not. Delete operations on nonexistent items consume one write capacity unit.
 *
 * If one or more of the following is true, DynamoDB rejects the entire batch write
 * operation:
 *
 * - One or more tables specified in the `BatchWriteItem` request does
 * not exist.
 *
 * - Primary key attributes specified on an item in the request do not match those
 * in the corresponding table's primary key schema.
 *
 * - You try to perform multiple operations on the same item in the same
 * `BatchWriteItem` request. For example, you cannot put and delete
 * the same item in the same `BatchWriteItem` request.
 *
 * - Your request contains at least two items with identical hash and range keys
 * (which essentially is two put operations).
 *
 * - There are more than 25 requests in the batch.
 *
 * - Any individual item in a batch exceeds 400 KB.
 *
 * - The total request size exceeds 16 MB.
 *
 * - Any individual items with keys exceeding the key length limits. For a
 * partition key, the limit is 2048 bytes and for a sort key, the limit is 1024
 * bytes.
 */
export declare const batchWriteItem: API.OperationMethod<BatchWriteItemInput & RegionInput, BatchWriteItemOutput, BatchWriteItemError, Credentials | HttpClient.HttpClient>;
export type CancelBulkOperationError = InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels an in-progress bulk operation asynchronously. Cancellation doesn't remove
 * items that the operation has already written. Use `DescribeBulkOperation` to
 * monitor the operation until it reaches a terminal status.
 */
export declare const cancelBulkOperation: API.OperationMethod<CancelBulkOperationInput & RegionInput, CancelBulkOperationOutput, CancelBulkOperationError, Credentials | HttpClient.HttpClient>;
export type CreateBackupError = BackupInUseException | ContinuousBackupsUnavailableException | InternalServerError | InvalidEndpointException | LimitExceededException | TableInUseException | TableNotFoundException | CommonErrors;
/**
 * Creates a backup for an existing table.
 *
 * Each time you create an on-demand backup, the entire table data is backed up. There
 * is no limit to the number of on-demand backups that can be taken.
 *
 * When you create an on-demand backup, a time marker of the request is cataloged, and
 * the backup is created asynchronously, by applying all changes until the time of the
 * request to the last full table snapshot. Backup requests are processed instantaneously
 * and become available for restore within minutes.
 *
 * You can call `CreateBackup` at a maximum rate of 50 times per
 * second.
 *
 * All backups in DynamoDB work without consuming any provisioned throughput on the
 * table.
 *
 * If you submit a backup request on 2018-12-14 at 14:25:00, the backup is guaranteed to
 * contain all data committed to the table up to 14:24:00, and data committed after
 * 14:26:00 will not be. The backup might contain data modifications made between 14:24:00
 * and 14:26:00. On-demand backup does not support causal consistency.
 *
 * Along with data, the following are also included on the backups:
 *
 * - Global secondary indexes (GSIs)
 *
 * - Local secondary indexes (LSIs)
 *
 * - Streams
 *
 * - Provisioned read and write capacity
 */
export declare const createBackup: API.OperationMethod<CreateBackupInput & RegionInput, CreateBackupOutput, CreateBackupError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalTableError = GlobalTableAlreadyExistsException | InternalServerError | InvalidEndpointException | LimitExceededException | TableNotFoundException | CommonErrors;
/**
 * Creates a global table from an existing table. A global table creates a replication
 * relationship between two or more DynamoDB tables with the same table name in the
 * provided Regions.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 *
 * If you want to add a new replica table to a global table, each of the following
 * conditions must be true:
 *
 * - The table must have the same primary key as all of the other replicas.
 *
 * - The table must have the same name as all of the other replicas.
 *
 * - The table must have DynamoDB Streams enabled, with the stream containing both
 * the new and the old images of the item.
 *
 * - None of the replica tables in the global table can contain any data.
 *
 * If global secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The global secondary indexes must have the same name.
 *
 * - The global secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * If local secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The local secondary indexes must have the same name.
 *
 * - The local secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * Write capacity settings should be set consistently across your replica tables and
 * secondary indexes. DynamoDB strongly recommends enabling auto scaling to manage the
 * write capacity settings for all of your global tables replicas and indexes.
 *
 * If you prefer to manage write capacity settings manually, you should provision
 * equal replicated write capacity units to your replica tables. You should also
 * provision equal replicated write capacity units to matching secondary indexes across
 * your global table.
 */
export declare const createGlobalTable: API.OperationMethod<CreateGlobalTableInput & RegionInput, CreateGlobalTableOutput, CreateGlobalTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | CommonErrors;
/**
 * The `CreateTable` operation adds a new table to your account. In an Amazon Web Services account, table names must be unique within each Region. That is, you can
 * have two tables with same name if you create the tables in different Regions.
 *
 * `CreateTable` is an asynchronous operation. Upon receiving a
 * `CreateTable` request, DynamoDB immediately returns a response with a
 * `TableStatus` of `CREATING`. After the table is created,
 * DynamoDB sets the `TableStatus` to `ACTIVE`. You can perform read
 * and write operations only on an `ACTIVE` table.
 *
 * You can optionally define secondary indexes on the new table, as part of the
 * `CreateTable` operation. If you want to create multiple tables with
 * secondary indexes on them, you must create the tables sequentially. Only one table with
 * secondary indexes can be in the `CREATING` state at any given time.
 *
 * You can use the `DescribeTable` action to check the table status.
 */
export declare const createTable: API.OperationMethod<CreateTableInput & RegionInput, CreateTableOutput, CreateTableError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupError = BackupInUseException | BackupNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | CommonErrors;
/**
 * Deletes an existing backup of a table.
 *
 * You can call `DeleteBackup` at a maximum rate of 10 times per
 * second.
 */
export declare const deleteBackup: API.OperationMethod<DeleteBackupInput & RegionInput, DeleteBackupOutput, DeleteBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Deletes a single item in a table by primary key. You can perform a conditional delete
 * operation that deletes the item if it exists, or if it has an expected attribute
 * value.
 *
 * In addition to deleting an item, you can also return the item's attribute values in
 * the same operation, using the `ReturnValues` parameter.
 *
 * Unless you specify conditions, the `DeleteItem` is an idempotent operation;
 * running it multiple times on the same item or attribute does *not*
 * result in an error response.
 *
 * Conditional deletes are useful for deleting items only if specific conditions are met.
 * If those conditions are met, DynamoDB performs the delete. Otherwise, the item is not
 * deleted.
 */
export declare const deleteItem: API.OperationMethod<DeleteItemInput & RegionInput, DeleteItemOutput, DeleteItemError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerError | InvalidEndpointException | LimitExceededException | PolicyNotFoundException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the resource-based policy attached to the resource, which can be a table or
 * stream.
 *
 * `DeleteResourcePolicy` is an idempotent operation; running it multiple
 * times on the same resource *doesn't* result in an error response,
 * unless you specify an `ExpectedRevisionId`, which will then return a
 * `PolicyNotFoundException`.
 *
 * To make sure that you don't inadvertently lock yourself out of your own resources,
 * the root principal in your Amazon Web Services account can perform
 * `DeleteResourcePolicy` requests, even if your resource-based policy
 * explicitly denies the root principal's access.
 *
 * `DeleteResourcePolicy` is an asynchronous operation. If you issue a
 * `GetResourcePolicy` request immediately after running the
 * `DeleteResourcePolicy` request, DynamoDB might still return
 * the deleted policy. This is because the policy for your resource might not have been
 * deleted yet. Wait for a few seconds, and then try the `GetResourcePolicy`
 * request again.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyInput & RegionInput, DeleteResourcePolicyOutput, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The `DeleteTable` operation deletes a table and all of its items. After a
 * `DeleteTable` request, the specified table is in the
 * `DELETING` state until DynamoDB completes the deletion. If the table is
 * in the `ACTIVE` state, you can delete it. If a table is in
 * `CREATING` or `UPDATING` states, then DynamoDB returns a
 * `ResourceInUseException`. If the specified table does not exist, DynamoDB
 * returns a `ResourceNotFoundException`. If table is already in the
 * `DELETING` state, no error is returned.
 *
 * DynamoDB might continue to accept data read and write operations, such as
 * `GetItem` and `PutItem`, on a table in the
 * `DELETING` state until the table deletion is complete. For the full
 * list of table states, see TableStatus.
 *
 * When you delete a table, any indexes on that table are also deleted.
 *
 * If you have DynamoDB Streams enabled on the table, then the corresponding stream on
 * that table goes into the `DISABLED` state, and the stream is automatically
 * deleted after 24 hours.
 *
 * Use the `DescribeTable` action to check the status of the table.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableInput & RegionInput, DeleteTableOutput, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupError = BackupNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Describes an existing backup of a table.
 *
 * You can call `DescribeBackup` at a maximum rate of 10 times per
 * second.
 */
export declare const describeBackup: API.OperationMethod<DescribeBackupInput & RegionInput, DescribeBackupOutput, DescribeBackupError, Credentials | HttpClient.HttpClient>;
export type DescribeBulkOperationError = InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified bulk operation.
 */
export declare const describeBulkOperation: API.OperationMethod<DescribeBulkOperationInput & RegionInput, DescribeBulkOperationOutput, DescribeBulkOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeContinuousBackupsError = InternalServerError | InvalidEndpointException | TableNotFoundException | CommonErrors;
/**
 * Checks the status of continuous backups and point in time recovery on the specified
 * table. Continuous backups are `ENABLED` on all tables at table creation. If
 * point in time recovery is enabled, `PointInTimeRecoveryStatus` will be set to
 * ENABLED.
 *
 * After continuous backups and point in time recovery are enabled, you can restore to
 * any point in time within `EarliestRestorableDateTime` and
 * `LatestRestorableDateTime`.
 *
 * `LatestRestorableDateTime` is typically 5 minutes before the current time.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * recovery period to any value between 1 and 35 days.
 *
 * You can call `DescribeContinuousBackups` at a maximum rate of 10 times per
 * second.
 */
export declare const describeContinuousBackups: API.OperationMethod<DescribeContinuousBackupsInput & RegionInput, DescribeContinuousBackupsOutput, DescribeContinuousBackupsError, Credentials | HttpClient.HttpClient>;
export type DescribeContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about contributor insights for a given table or global secondary
 * index.
 */
export declare const describeContributorInsights: API.OperationMethod<DescribeContributorInsightsInput & RegionInput, DescribeContributorInsightsOutput, DescribeContributorInsightsError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointsError = CommonErrors;
/**
 * Returns the regional endpoint information. For more information on policy permissions,
 * please see Internetwork traffic privacy.
 */
export declare const describeEndpoints: API.OperationMethod<DescribeEndpointsRequest & RegionInput, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient>;
export type DescribeExportError = ExportNotFoundException | InternalServerError | LimitExceededException | CommonErrors;
/**
 * Describes an existing table export.
 */
export declare const describeExport: API.OperationMethod<DescribeExportInput & RegionInput, DescribeExportOutput, DescribeExportError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalTableError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns information about the specified global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const describeGlobalTable: API.OperationMethod<DescribeGlobalTableInput & RegionInput, DescribeGlobalTableOutput, DescribeGlobalTableError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalTableSettingsError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Describes Region-specific settings for a global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const describeGlobalTableSettings: API.OperationMethod<DescribeGlobalTableSettingsInput & RegionInput, DescribeGlobalTableSettingsOutput, DescribeGlobalTableSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeImportError = ImportNotFoundException | CommonErrors;
/**
 * Represents the properties of the import.
 */
export declare const describeImport: API.OperationMethod<DescribeImportInput & RegionInput, DescribeImportOutput, DescribeImportError, Credentials | HttpClient.HttpClient>;
export type DescribeKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the status of Kinesis streaming.
 */
export declare const describeKinesisStreamingDestination: API.OperationMethod<DescribeKinesisStreamingDestinationInput & RegionInput, DescribeKinesisStreamingDestinationOutput, DescribeKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type DescribeLimitsError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns the current provisioned-capacity quotas for your Amazon Web Services account in
 * a Region, both for the Region as a whole and for any one DynamoDB table that you create
 * there.
 *
 * When you establish an Amazon Web Services account, the account has initial quotas on
 * the maximum read capacity units and write capacity units that you can provision across
 * all of your DynamoDB tables in a given Region. Also, there are per-table
 * quotas that apply when you create a table there. For more information, see Service,
 * Account, and Table Quotas page in the Amazon DynamoDB
 * Developer Guide.
 *
 * Although you can increase these quotas by filing a case at Amazon Web Services Support Center, obtaining the
 * increase is not instantaneous. The `DescribeLimits` action lets you write
 * code to compare the capacity you are currently using to those quotas imposed by your
 * account so that you have enough time to apply for an increase before you hit a
 * quota.
 *
 * For example, you could use one of the Amazon Web Services SDKs to do the
 * following:
 *
 * - Call `DescribeLimits` for a particular Region to obtain your
 * current account quotas on provisioned capacity there.
 *
 * - Create a variable to hold the aggregate read capacity units provisioned for
 * all your tables in that Region, and one to hold the aggregate write capacity
 * units. Zero them both.
 *
 * - Call `ListTables` to obtain a list of all your DynamoDB
 * tables.
 *
 * - For each table name listed by `ListTables`, do the
 * following:
 *
 * - Call `DescribeTable` with the table name.
 *
 * - Use the data returned by `DescribeTable` to add the read
 * capacity units and write capacity units provisioned for the table itself
 * to your variables.
 *
 * - If the table has one or more global secondary indexes (GSIs), loop
 * over these GSIs and add their provisioned capacity values to your
 * variables as well.
 *
 * - Report the account quotas for that Region returned by
 * `DescribeLimits`, along with the total current provisioned
 * capacity levels you have calculated.
 *
 * This will let you see whether you are getting close to your account-level
 * quotas.
 *
 * The per-table quotas apply only when you are creating a new table. They restrict the
 * sum of the provisioned capacity of the new table itself and all its global secondary
 * indexes.
 *
 * For existing tables and their GSIs, DynamoDB doesn't let you increase provisioned
 * capacity extremely rapidly, but the only quota that applies is that the aggregate
 * provisioned capacity over all your tables and GSIs cannot exceed either of the
 * per-account quotas.
 *
 * `DescribeLimits` should only be called periodically. You can expect
 * throttling errors if you call it more than once in a minute.
 *
 * The `DescribeLimits` Request element has no content.
 */
export declare const describeLimits: API.OperationMethod<DescribeLimitsInput & RegionInput, DescribeLimitsOutput, DescribeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeTableError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the table, including the current status of the table, when
 * it was created, the primary key schema, and any indexes on the table.
 *
 * If you issue a `DescribeTable` request immediately after a
 * `CreateTable` request, DynamoDB might return a
 * `ResourceNotFoundException`. This is because
 * `DescribeTable` uses an eventually consistent query, and the metadata
 * for your table might not be available at that moment. Wait for a few seconds, and
 * then try the `DescribeTable` request again.
 */
export declare const describeTable: API.OperationMethod<DescribeTableInput & RegionInput, DescribeTableOutput, DescribeTableError, Credentials | HttpClient.HttpClient>;
export type DescribeTableReplicaAutoScalingError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Describes auto scaling settings across replicas of the global table at once.
 */
export declare const describeTableReplicaAutoScaling: API.OperationMethod<DescribeTableReplicaAutoScalingInput & RegionInput, DescribeTableReplicaAutoScalingOutput, DescribeTableReplicaAutoScalingError, Credentials | HttpClient.HttpClient>;
export type DescribeTimeToLiveError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Gives a description of the Time to Live (TTL) status on the specified table.
 */
export declare const describeTimeToLive: API.OperationMethod<DescribeTimeToLiveInput & RegionInput, DescribeTimeToLiveOutput, DescribeTimeToLiveError, Credentials | HttpClient.HttpClient>;
export type DisableKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Stops replication from the DynamoDB table to the Kinesis data stream. This
 * is done without deleting either of the resources.
 */
export declare const disableKinesisStreamingDestination: API.OperationMethod<KinesisStreamingDestinationInput & RegionInput, KinesisStreamingDestinationOutput, DisableKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type EnableKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Starts table data replication to the specified Kinesis data stream at a timestamp
 * chosen during the enable workflow. If this operation doesn't return results immediately,
 * use DescribeKinesisStreamingDestination to check if streaming to the Kinesis data stream
 * is ACTIVE.
 */
export declare const enableKinesisStreamingDestination: API.OperationMethod<KinesisStreamingDestinationInput & RegionInput, KinesisStreamingDestinationOutput, EnableKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type ExecuteStatementError = ConditionalCheckFailedException | DuplicateItemException | InternalServerError | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * This operation allows you to perform reads and singleton writes on data stored in
 * DynamoDB, using PartiQL.
 *
 * For PartiQL reads (`SELECT` statement), if the total number of processed
 * items exceeds the maximum dataset size limit of 1 MB, the read stops and results are
 * returned to the user as a `LastEvaluatedKey` value to continue the read in a
 * subsequent operation. If the filter criteria in `WHERE` clause does not match
 * any data, the read will return an empty result set.
 *
 * A single `SELECT` statement response can return up to the maximum number of
 * items (if using the Limit parameter) or a maximum of 1 MB of data (and then apply any
 * filtering to the results using `WHERE` clause). If
 * `LastEvaluatedKey` is present in the response, you need to paginate the
 * result set. If `NextToken` is present, you need to paginate the result set
 * and include `NextToken`.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementInput & RegionInput, ExecuteStatementOutput, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type ExecuteTransactionError = IdempotentParameterMismatchException | InternalServerError | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | TransactionInProgressException | CommonErrors;
/**
 * This operation allows you to perform transactional reads or writes on data stored in
 * DynamoDB, using PartiQL.
 *
 * The entire transaction must consist of either read statements or write statements,
 * you cannot mix both in one transaction. The EXISTS function is an exception and can
 * be used to check the condition of specific attributes of the item in a similar
 * manner to `ConditionCheck` in the TransactWriteItems API.
 */
export declare const executeTransaction: API.OperationMethod<ExecuteTransactionInput & RegionInput, ExecuteTransactionOutput, ExecuteTransactionError, Credentials | HttpClient.HttpClient>;
export type ExportTableToPointInTimeError = ExportConflictException | InternalServerError | InvalidExportTimeException | LimitExceededException | PointInTimeRecoveryUnavailableException | TableNotFoundException | CommonErrors;
/**
 * Exports table data to an S3 bucket. The table must have point in time recovery
 * enabled, and you can export data from any time within the point in time recovery
 * window.
 */
export declare const exportTableToPointInTime: API.OperationMethod<ExportTableToPointInTimeInput & RegionInput, ExportTableToPointInTimeOutput, ExportTableToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type GetItemError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `GetItem` operation returns a set of attributes for the item with the
 * given primary key. If there is no matching item, `GetItem` does not return
 * any data and there will be no `Item` element in the response.
 *
 * `GetItem` provides an eventually consistent read by default. If your
 * application requires a strongly consistent read, set `ConsistentRead` to
 * `true`. Although a strongly consistent read might take more time than an
 * eventually consistent read, it always returns the last updated value.
 */
export declare const getItem: API.OperationMethod<GetItemInput & RegionInput, GetItemOutput, GetItemError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServerError | InvalidEndpointException | PolicyNotFoundException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the resource-based policy document attached to the resource, which can be a
 * table or stream, in JSON format.
 *
 * `GetResourcePolicy` follows an
 * *eventually consistent*
 * model. The following list
 * describes the outcomes when you issue the `GetResourcePolicy` request
 * immediately after issuing another request:
 *
 * - If you issue a `GetResourcePolicy` request immediately after a
 * `PutResourcePolicy` request, DynamoDB might return a
 * `PolicyNotFoundException`.
 *
 * - If you issue a `GetResourcePolicy`request immediately after a
 * `DeleteResourcePolicy` request, DynamoDB might return
 * the policy that was present before the deletion request.
 *
 * - If you issue a `GetResourcePolicy` request immediately after a
 * `CreateTable` request, which includes a resource-based policy,
 * DynamoDB might return a `ResourceNotFoundException` or
 * a `PolicyNotFoundException`.
 *
 * Because `GetResourcePolicy` uses an eventually
 * consistent query, the metadata for your policy or table might not be
 * available at that moment. Wait for a few seconds, and then retry the
 * `GetResourcePolicy` request.
 *
 * After a `GetResourcePolicy` request returns a policy created using the
 * `PutResourcePolicy` request, the policy will be applied in the
 * authorization of requests to the resource. Because this process is eventually
 * consistent, it will take some time to apply the policy to all requests to a resource.
 * Policies that you attach while creating a table using the `CreateTable`
 * request will always be applied to all requests for that table.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput & RegionInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ImportTableError = ImportConflictException | LimitExceededException | ResourceInUseException | CommonErrors;
/**
 * Imports table data from an S3 bucket.
 */
export declare const importTable: API.OperationMethod<ImportTableInput & RegionInput, ImportTableOutput, ImportTableError, Credentials | HttpClient.HttpClient>;
export type ListBackupsError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * List DynamoDB backups that are associated with an Amazon Web Services account and
 * weren't made with Amazon Web Services Backup. To list these backups for a given table,
 * specify `TableName`. `ListBackups` returns a paginated list of
 * results with at most 1 MB worth of items in a page. You can also specify a maximum
 * number of entries to be returned in a page.
 *
 * In the request, start time is inclusive, but end time is exclusive. Note that these
 * boundaries are for the time at which the original backup was requested.
 *
 * You can call `ListBackups` a maximum of five times per second.
 *
 * If you want to retrieve the complete list of backups made with Amazon Web Services
 * Backup, use the Amazon Web Services Backup
 * list API.
 */
export declare const listBackups: API.OperationMethod<ListBackupsInput & RegionInput, ListBackupsOutput, ListBackupsError, Credentials | HttpClient.HttpClient>;
export type ListBulkOperationsError = InvalidEndpointException | CommonErrors;
/**
 * Lists bulk operations that started within the past 90 days for the current Amazon Web Services account and Amazon Web Services Region, with the most recent operations
 * first. Results are paginated. Use the `NextToken` parameter to retrieve
 * additional results.
 */
export declare const listBulkOperations: API.PaginatedOperationMethod<ListBulkOperationsInput & RegionInput, ListBulkOperationsOutput, ListBulkOperationsError, Credentials | HttpClient.HttpClient, BulkOperationSummary>;
export type ListContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of ContributorInsightsSummary for a table and all its global secondary
 * indexes.
 */
export declare const listContributorInsights: API.PaginatedOperationMethod<ListContributorInsightsInput & RegionInput, ListContributorInsightsOutput, ListContributorInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExportsError = InternalServerError | LimitExceededException | CommonErrors;
/**
 * Lists completed exports within the past 90 days, in reverse alphanumeric order of `ExportArn`.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsInput & RegionInput, ListExportsOutput, ListExportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGlobalTablesError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Lists all global tables that have a replica in the specified Region.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const listGlobalTables: API.OperationMethod<ListGlobalTablesInput & RegionInput, ListGlobalTablesOutput, ListGlobalTablesError, Credentials | HttpClient.HttpClient>;
export type ListImportsError = LimitExceededException | CommonErrors;
/**
 * Lists completed imports within the past 90 days.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsInput & RegionInput, ListImportsOutput, ListImportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTablesError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns an array of table names associated with the current account and endpoint. The
 * output from `ListTables` is paginated, with each page returning a maximum of
 * 100 table names.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesInput & RegionInput, ListTablesOutput, ListTablesError, Credentials | HttpClient.HttpClient, TableName>;
export type ListTagsOfResourceError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * List all tags on an Amazon DynamoDB resource. You can call ListTagsOfResource up to 10
 * times per second, per account.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const listTagsOfResource: API.OperationMethod<ListTagsOfResourceInput & RegionInput, ListTagsOfResourceOutput, ListTagsOfResourceError, Credentials | HttpClient.HttpClient>;
export type PutItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Creates a new item, or replaces an old item with a new item. If an item that has the
 * same primary key as the new item already exists in the specified table, the new item
 * completely replaces the existing item. You can perform a conditional put operation (add
 * a new item if one with the specified primary key doesn't exist), or replace an existing
 * item if it has certain attribute values. You can return the item's attribute values in
 * the same operation, using the `ReturnValues` parameter.
 *
 * When you add an item, the primary key attributes are the only required attributes.
 *
 * Empty String and Binary attribute values are allowed. Attribute values of type String
 * and Binary must have a length greater than zero if the attribute is used as a key
 * attribute for a table or index. Set type attributes cannot be empty.
 *
 * Invalid Requests with empty values will be rejected with a
 * `ValidationException` exception.
 *
 * To prevent a new item from replacing an existing item, use a conditional
 * expression that contains the `attribute_not_exists` function with the
 * name of the attribute being used as the partition key for the table. Since every
 * record must contain that attribute, the `attribute_not_exists` function
 * will only succeed if no matching item exists.
 *
 * To determine whether `PutItem` overwrote an existing item, use
 * `ReturnValues` set to `ALL_OLD`. If the response includes
 * the `Attributes` element, an existing item was overwritten.
 *
 * For more information about `PutItem`, see Working with
 * Items in the *Amazon DynamoDB Developer Guide*.
 */
export declare const putItem: API.OperationMethod<PutItemInput & RegionInput, PutItemOutput, PutItemError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InternalServerError | InvalidEndpointException | LimitExceededException | PolicyNotFoundException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based policy document to the resource, which can be a table or
 * stream. When you attach a resource-based policy using this API, the policy application
 * is
 * *eventually consistent*
 * .
 *
 * `PutResourcePolicy` is an idempotent operation; running it multiple times
 * on the same resource using the same policy document will return the same revision ID. If
 * you specify an `ExpectedRevisionId` that doesn't match the current policy's
 * `RevisionId`, the `PolicyNotFoundException` will be
 * returned.
 *
 * `PutResourcePolicy` is an asynchronous operation. If you issue a
 * `GetResourcePolicy` request immediately after a
 * `PutResourcePolicy` request, DynamoDB might return your
 * previous policy, if there was one, or return the
 * `PolicyNotFoundException`. This is because
 * `GetResourcePolicy` uses an eventually consistent query, and the
 * metadata for your policy or table might not be available at that moment. Wait for a
 * few seconds, and then try the `GetResourcePolicy` request again.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyInput & RegionInput, PutResourcePolicyOutput, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type QueryError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * You must provide the name of the partition key attribute and a single value for that
 * attribute. `Query` returns all items with that partition key value.
 * Optionally, you can provide a sort key attribute and use a comparison operator to refine
 * the search results.
 *
 * Use the `KeyConditionExpression` parameter to provide a specific value for
 * the partition key. The `Query` operation will return all of the items from
 * the table or index with that partition key value. You can optionally narrow the scope of
 * the `Query` operation by specifying a sort key value and a comparison
 * operator in `KeyConditionExpression`. To further refine the
 * `Query` results, you can optionally provide a
 * `FilterExpression`. A `FilterExpression` determines which
 * items within the results should be returned to you. All of the other results are
 * discarded.
 *
 * A `Query` operation always returns a result set. If no matching items are
 * found, the result set will be empty. Queries that do not return results consume the
 * minimum number of read capacity units for that type of read operation.
 *
 * DynamoDB calculates the number of read capacity units consumed based on item
 * size, not on the amount of data that is returned to an application. The number of
 * capacity units consumed will be the same whether you request all of the attributes
 * (the default behavior) or just some of them (using a projection expression). The
 * number will also be the same whether or not you use a `FilterExpression`.
 *
 * `Query` results are always sorted by the sort key value. If the data type of
 * the sort key is Number, the results are returned in numeric order; otherwise, the
 * results are returned in order of UTF-8 bytes. By default, the sort order is ascending.
 * To reverse the order, set the `ScanIndexForward` parameter to false.
 *
 * A single `Query` operation will read up to the maximum number of items set
 * (if using the `Limit` parameter) or a maximum of 1 MB of data and then apply
 * any filtering to the results using `FilterExpression`. If
 * `LastEvaluatedKey` is present in the response, you will need to paginate
 * the result set. For more information, see Paginating
 * the Results in the *Amazon DynamoDB Developer Guide*.
 *
 * `FilterExpression` is applied after a `Query` finishes, but before
 * the results are returned. A `FilterExpression` cannot contain partition key
 * or sort key attributes. You need to specify those attributes in the
 * `KeyConditionExpression`.
 *
 * A `Query` operation can return an empty result set and a
 * `LastEvaluatedKey` if all the items read for the page of results are
 * filtered out.
 *
 * You can query a table, a local secondary index, or a global secondary index. For a
 * query on a table or on a local secondary index, you can set the
 * `ConsistentRead` parameter to `true` and obtain a strongly
 * consistent result. Global secondary indexes support eventually consistent reads only, so
 * do not specify `ConsistentRead` when querying a global secondary
 * index.
 */
export declare const query: API.PaginatedOperationMethod<QueryInput & RegionInput, QueryOutput, QueryError, Credentials | HttpClient.HttpClient, {
    [key: string]: AttributeValue | undefined;
}>;
export type RestoreTableFromBackupError = BackupInUseException | BackupNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | TableAlreadyExistsException | TableInUseException | CommonErrors;
/**
 * Creates a new table from an existing backup. Any number of users can execute up to 50
 * concurrent restores (any type of restore) in a given account.
 *
 * You can call `RestoreTableFromBackup` at a maximum rate of 10 times per
 * second.
 *
 * You must manually set up the following on the restored table:
 *
 * - Auto scaling policies
 *
 * - IAM policies
 *
 * - Amazon CloudWatch metrics and alarms
 *
 * - Tags
 *
 * - Stream settings
 *
 * - Time to Live (TTL) settings
 */
export declare const restoreTableFromBackup: API.OperationMethod<RestoreTableFromBackupInput & RegionInput, RestoreTableFromBackupOutput, RestoreTableFromBackupError, Credentials | HttpClient.HttpClient>;
export type RestoreTableToPointInTimeError = InternalServerError | InvalidEndpointException | InvalidRestoreTimeException | LimitExceededException | PointInTimeRecoveryUnavailableException | TableAlreadyExistsException | TableInUseException | TableNotFoundException | CommonErrors;
/**
 * Restores the specified table to the specified point in time within
 * `EarliestRestorableDateTime` and `LatestRestorableDateTime`.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * recovery period to any value between 1 and 35 days. Any number of users can execute up
 * to 50 concurrent restores (any type of restore) in a given account.
 *
 * When you restore using point in time recovery, DynamoDB restores your table data to
 * the state based on the selected date and time (day:hour:minute:second) to a new table.
 *
 * Along with data, the following are also included on the new restored table using point
 * in time recovery:
 *
 * - Global secondary indexes (GSIs)
 *
 * - Local secondary indexes (LSIs)
 *
 * - Provisioned read and write capacity
 *
 * - Encryption settings
 *
 * All these settings come from the current settings of the source table at
 * the time of restore.
 *
 * You must manually set up the following on the restored table:
 *
 * - Auto scaling policies
 *
 * - IAM policies
 *
 * - Amazon CloudWatch metrics and alarms
 *
 * - Tags
 *
 * - Stream settings
 *
 * - Time to Live (TTL) settings
 *
 * - Point in time recovery settings
 */
export declare const restoreTableToPointInTime: API.OperationMethod<RestoreTableToPointInTimeInput & RegionInput, RestoreTableToPointInTimeOutput, RestoreTableToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type ScanError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `Scan` operation returns one or more items and item attributes by
 * accessing every item in a table or a secondary index. To have DynamoDB return fewer
 * items, you can provide a `FilterExpression` operation.
 *
 * If the total size of scanned items exceeds the maximum dataset size limit of 1 MB, the
 * scan completes and results are returned to the user. The `LastEvaluatedKey`
 * value is also returned and the requestor can use the `LastEvaluatedKey` to
 * continue the scan in a subsequent operation. Each scan response also includes number of
 * items that were scanned (ScannedCount) as part of the request. If using a
 * `FilterExpression`, a scan result can result in no items meeting the
 * criteria and the `Count` will result in zero. If you did not use a
 * `FilterExpression` in the scan request, then `Count` is the
 * same as `ScannedCount`.
 *
 * `Count` and `ScannedCount` only return the count of items
 * specific to a single scan request and, unless the table is less than 1MB, do not
 * represent the total number of items in the table.
 *
 * A single `Scan` operation first reads up to the maximum number of items set
 * (if using the `Limit` parameter) or a maximum of 1 MB of data and then
 * applies any filtering to the results if a `FilterExpression` is provided. If
 * `LastEvaluatedKey` is present in the response, pagination is required to
 * complete the full table scan. For more information, see Paginating the
 * Results in the *Amazon DynamoDB Developer Guide*.
 *
 * `Scan` operations proceed sequentially; however, for faster performance on
 * a large table or secondary index, applications can request a parallel `Scan`
 * operation by providing the `Segment` and `TotalSegments`
 * parameters. For more information, see Parallel
 * Scan in the *Amazon DynamoDB Developer Guide*.
 *
 * By default, a `Scan` uses eventually consistent reads when accessing the
 * items in a table. Therefore, the results from an eventually consistent `Scan`
 * may not include the latest item changes at the time the scan iterates through each item
 * in the table. If you require a strongly consistent read of each item as the scan
 * iterates through the items in the table, you can set the `ConsistentRead`
 * parameter to true. Strong consistency only relates to the consistency of the read at the
 * item level.
 *
 * DynamoDB does not provide snapshot isolation for a scan operation when the
 * `ConsistentRead` parameter is set to true. Thus, a DynamoDB scan
 * operation does not guarantee that all reads in a scan see a consistent snapshot of
 * the table when the scan operation was requested.
 */
export declare const scan: API.PaginatedOperationMethod<ScanInput & RegionInput, ScanOutput, ScanError, Credentials | HttpClient.HttpClient, {
    [key: string]: AttributeValue | undefined;
}>;
export type SearchVectorsError = InternalServerError | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Performs a vector similarity search on a vector index associated with an Amazon
 * DynamoDB table, and returns the most similar items sorted by similarity score
 * based on the distance function configured for the index.
 *
 * Score interpretation depends on the distance function:
 *
 * - `COSINE` - Returns the items with the k
 * smallest scores. Scores range from 0 (identical) to 2 (opposite).
 * Lower scores indicate higher similarity.
 *
 * - `EUCLIDEAN` - Returns the items with the k
 * smallest scores. Scores represent the Euclidean distance between
 * vectors. Lower scores indicate higher similarity.
 *
 * - `DOT_PRODUCT` - Returns the items with the k
 * highest scores. Higher scores indicate higher similarity.
 */
export declare const searchVectors: API.OperationMethod<SearchVectorsInput & RegionInput, SearchVectorsOutput, SearchVectorsError, Credentials | HttpClient.HttpClient>;
export type StartBulkPutItemsError = IdempotentParameterMismatchException | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Starts an asynchronous bulk operation that reads items from Amazon S3 and
 * writes them to an existing DynamoDB table, so you can efficiently load or
 * migrate large datasets.
 */
export declare const startBulkPutItems: API.OperationMethod<StartBulkPutItemsInput & RegionInput, StartBulkPutItemsOutput, StartBulkPutItemsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Associate a set of tags with an Amazon DynamoDB resource. You can then activate these
 * user-defined tags so that they appear on the Billing and Cost Management console for
 * cost allocation tracking. You can call TagResource up to five times per second, per
 * account.
 *
 * - `TagResource` is an asynchronous operation. If you issue a ListTagsOfResource request immediately after a
 * `TagResource` request, DynamoDB might return your
 * previous tag set, if there was one, or an empty tag set. This is because
 * `ListTagsOfResource` uses an eventually consistent query, and the
 * metadata for your tags or table might not be available at that moment. Wait for
 * a few seconds, and then try the `ListTagsOfResource` request
 * again.
 *
 * - The application or removal of tags using `TagResource` and
 * `UntagResource` APIs is eventually consistent.
 * `ListTagsOfResource` API will only reflect the changes after a
 * few seconds.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TransactGetItemsError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | CommonErrors;
/**
 * `TransactGetItems` is a synchronous operation that atomically retrieves
 * multiple items from one or more tables (but not from indexes) in a single account and
 * Region. A `TransactGetItems` call can contain up to 100
 * `TransactGetItem` objects, each of which contains a `Get`
 * structure that specifies an item to retrieve from a table in the account and Region. A
 * call to `TransactGetItems` cannot retrieve items from tables in more than one
 * Amazon Web Services account or Region. The aggregate size of the items in the
 * transaction cannot exceed 4 MB.
 *
 * DynamoDB rejects the entire `TransactGetItems` request if any of
 * the following is true:
 *
 * - A conflicting operation is in the process of updating an item to be
 * read.
 *
 * - There is insufficient provisioned capacity for the transaction to be
 * completed.
 *
 * - There is a user error, such as an invalid data format.
 *
 * - The aggregate size of the items in the transaction exceeded 4 MB.
 */
export declare const transactGetItems: API.OperationMethod<TransactGetItemsInput & RegionInput, TransactGetItemsOutput, TransactGetItemsError, Credentials | HttpClient.HttpClient>;
export type TransactWriteItemsError = IdempotentParameterMismatchException | InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | TransactionInProgressException | CommonErrors;
/**
 * `TransactWriteItems` is a synchronous write operation that groups up to 100
 * action requests. These actions can target items in different tables, but not in
 * different Amazon Web Services accounts or Regions, and no two actions can target the same
 * item. For example, you cannot both `ConditionCheck` and `Update`
 * the same item. The aggregate size of the items in the transaction cannot exceed 4
 * MB.
 *
 * The actions are completed atomically so that either all of them succeed, or all of
 * them fail. They are defined by the following objects:
 *
 * - `Put`  --   Initiates a `PutItem`
 * operation to write a new item. This structure specifies the primary key of the
 * item to be written, the name of the table to write it in, an optional condition
 * expression that must be satisfied for the write to succeed, a list of the item's
 * attributes, and a field indicating whether to retrieve the item's attributes if
 * the condition is not met.
 *
 * - `Update`  --   Initiates an `UpdateItem`
 * operation to update an existing item. This structure specifies the primary key
 * of the item to be updated, the name of the table where it resides, an optional
 * condition expression that must be satisfied for the update to succeed, an
 * expression that defines one or more attributes to be updated, and a field
 * indicating whether to retrieve the item's attributes if the condition is not
 * met.
 *
 * - `Delete`  --   Initiates a `DeleteItem`
 * operation to delete an existing item. This structure specifies the primary key
 * of the item to be deleted, the name of the table where it resides, an optional
 * condition expression that must be satisfied for the deletion to succeed, and a
 * field indicating whether to retrieve the item's attributes if the condition is
 * not met.
 *
 * - `ConditionCheck`  --   Applies a condition to an item
 * that is not being modified by the transaction. This structure specifies the
 * primary key of the item to be checked, the name of the table where it resides, a
 * condition expression that must be satisfied for the transaction to succeed, and
 * a field indicating whether to retrieve the item's attributes if the condition is
 * not met.
 *
 * DynamoDB rejects the entire `TransactWriteItems` request if any of the
 * following is true:
 *
 * - A condition in one of the condition expressions is not met.
 *
 * - An ongoing operation is in the process of updating the same item.
 *
 * - There is insufficient provisioned capacity for the transaction to be
 * completed.
 *
 * - An item size becomes too large (bigger than 400 KB), a local secondary index
 * (LSI) becomes too large, or a similar validation error occurs because of changes
 * made by the transaction.
 *
 * - The aggregate size of the items in the transaction exceeds 4 MB.
 *
 * - There is a user error, such as an invalid data format.
 */
export declare const transactWriteItems: API.OperationMethod<TransactWriteItemsInput & RegionInput, TransactWriteItemsOutput, TransactWriteItemsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the association of tags from an Amazon DynamoDB resource. You can call
 * `UntagResource` up to five times per second, per account.
 *
 * - `UntagResource` is an asynchronous operation. If you issue a ListTagsOfResource request immediately after an
 * `UntagResource` request, DynamoDB might return your
 * previous tag set, if there was one, or an empty tag set. This is because
 * `ListTagsOfResource` uses an eventually consistent query, and the
 * metadata for your tags or table might not be available at that moment. Wait for
 * a few seconds, and then try the `ListTagsOfResource` request
 * again.
 *
 * - The application or removal of tags using `TagResource` and
 * `UntagResource` APIs is eventually consistent.
 * `ListTagsOfResource` API will only reflect the changes after a
 * few seconds.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateContinuousBackupsError = ContinuousBackupsUnavailableException | InternalServerError | InvalidEndpointException | TableNotFoundException | CommonErrors;
/**
 * `UpdateContinuousBackups` enables or disables point in time recovery for
 * the specified table. A successful `UpdateContinuousBackups` call returns the
 * current `ContinuousBackupsDescription`. Continuous backups are
 * `ENABLED` on all tables at table creation. If point in time recovery is
 * enabled, `PointInTimeRecoveryStatus` will be set to ENABLED.
 *
 * Once continuous backups and point in time recovery are enabled, you can restore to
 * any point in time within `EarliestRestorableDateTime` and
 * `LatestRestorableDateTime`.
 *
 * `LatestRestorableDateTime` is typically 5 minutes before the current time.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * `RecoveryPeriodInDays` to any value between 1 and 35 days.
 */
export declare const updateContinuousBackups: API.OperationMethod<UpdateContinuousBackupsInput & RegionInput, UpdateContinuousBackupsOutput, UpdateContinuousBackupsError, Credentials | HttpClient.HttpClient>;
export type UpdateContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Updates the status for contributor insights for a specific table or index. CloudWatch
 * Contributor Insights for DynamoDB graphs display the partition key and (if applicable)
 * sort key of frequently accessed items and frequently throttled items in plaintext. If
 * you require the use of Amazon Web Services Key Management Service (KMS) to encrypt this
 * table's partition key and sort key data with an Amazon Web Services managed key or
 * customer managed key, you should not enable CloudWatch Contributor Insights for DynamoDB
 * for this table.
 */
export declare const updateContributorInsights: API.OperationMethod<UpdateContributorInsightsInput & RegionInput, UpdateContributorInsightsOutput, UpdateContributorInsightsError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalTableError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | ReplicaAlreadyExistsException | ReplicaNotFoundException | TableNotFoundException | CommonErrors;
/**
 * Adds or removes replicas in the specified global table. The global table must already
 * exist to be able to use this operation. Any replica to be added must be empty, have the
 * same name as the global table, have the same key schema, have DynamoDB Streams enabled,
 * and have the same provisioned and maximum write capacity units.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 *
 * If you are using global tables Version
 * 2019.11.21 (Current) you can use UpdateTable instead.
 *
 * Although you can use `UpdateGlobalTable` to add replicas and remove
 * replicas in a single request, for simplicity we recommend that you issue separate
 * requests for adding or removing replicas.
 *
 * If global secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The global secondary indexes must have the same name.
 *
 * - The global secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * - The global secondary indexes must have the same provisioned and maximum write
 * capacity units.
 */
export declare const updateGlobalTable: API.OperationMethod<UpdateGlobalTableInput & RegionInput, UpdateGlobalTableOutput, UpdateGlobalTableError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalTableSettingsError = GlobalTableNotFoundException | IndexNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | ReplicaNotFoundException | ResourceInUseException | CommonErrors;
/**
 * Updates settings for a global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const updateGlobalTableSettings: API.OperationMethod<UpdateGlobalTableSettingsInput & RegionInput, UpdateGlobalTableSettingsOutput, UpdateGlobalTableSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Edits an existing item's attributes, or adds a new item to the table if it does not
 * already exist. You can put, delete, or add attribute values. You can also perform a
 * conditional update on an existing item (insert a new attribute name-value pair if it
 * doesn't exist, or replace an existing name-value pair if it has certain expected
 * attribute values).
 *
 * You can also return the item's attribute values in the same `UpdateItem`
 * operation using the `ReturnValues` parameter.
 */
export declare const updateItem: API.OperationMethod<UpdateItemInput & RegionInput, UpdateItemOutput, UpdateItemError, Credentials | HttpClient.HttpClient>;
export type UpdateKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The command to update the Kinesis stream destination.
 */
export declare const updateKinesisStreamingDestination: API.OperationMethod<UpdateKinesisStreamingDestinationInput & RegionInput, UpdateKinesisStreamingDestinationOutput, UpdateKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the provisioned throughput settings, global secondary indexes, DynamoDB
 * Streams settings, or global table replica settings for a given table.
 *
 * You can only perform one of the following operations at once:
 *
 * - Modify the provisioned throughput settings of the table.
 *
 * - Remove a global secondary index from the table.
 *
 * - Create a new global secondary index on the table. After the index begins
 * backfilling, you can use `UpdateTable` to perform other
 * operations.
 *
 * - Enable or disable disassociation protection for the local global table
 * replica.
 *
 * - Disassociate the local global table replica and keep it as a standalone
 * regional table. The `Disassociate` action must be the only
 * replica update in the request. If the request includes any other update,
 * `UpdateTable` fails with a `ValidationException` and
 * the disassociation does not start.
 *
 * `UpdateTable` is an asynchronous operation; while it's executing, the table
 * status changes from `ACTIVE` to `UPDATING`. While it's
 * `UPDATING`, you can't issue another `UpdateTable` request.
 * Use `DescribeTable` to monitor the table's status.
 *
 * To use this operation to disassociate a local replica, you must have the
 * `dynamodb:UpdateTable` and `dynamodb:DisassociateTableReplica`
 * IAM permissions on the local replica. Send disassociation and disassociation
 * protection requests to the replica's Region using credentials for the account that
 * owns the replica. For prerequisites and the procedure, see
 * Disassociating a global table replica in the Amazon DynamoDB
 * Developer Guide.
 *
 * To confirm successful disassociation, call `DescribeTable` in the
 * replica's Region and verify that `TableStatus` is `ACTIVE`
 * and `Replicas` is absent or empty. If `TableStatus` returns to
 * `ACTIVE` but the response still includes a `Replicas` list, the
 * disassociation did not complete. Check `ReplicaStatus` for a
 * replication-permission or encryption-access problem, resolve it, and retry.
 */
export declare const updateTable: API.OperationMethod<UpdateTableInput & RegionInput, UpdateTableOutput, UpdateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateTableReplicaAutoScalingError = InternalServerError | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates auto scaling settings on your global tables at once.
 */
export declare const updateTableReplicaAutoScaling: API.OperationMethod<UpdateTableReplicaAutoScalingInput & RegionInput, UpdateTableReplicaAutoScalingOutput, UpdateTableReplicaAutoScalingError, Credentials | HttpClient.HttpClient>;
export type UpdateTimeToLiveError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The `UpdateTimeToLive` method enables or disables Time to Live (TTL) for
 * the specified table. A successful `UpdateTimeToLive` call returns the current
 * `TimeToLiveSpecification`. It can take up to one hour for the change to
 * fully process. Any additional `UpdateTimeToLive` calls for the same table
 * during this one hour duration result in a `ValidationException`.
 *
 * TTL compares the current time in epoch time format to the time stored in the TTL
 * attribute of an item. If the epoch time value stored in the attribute is less than the
 * current time, the item is marked as expired and subsequently deleted.
 *
 * The epoch time format is the number of seconds elapsed since 12:00:00 AM January
 * 1, 1970 UTC.
 *
 * DynamoDB deletes expired items on a best-effort basis to ensure availability of
 * throughput for other data operations.
 *
 * DynamoDB typically deletes expired items within two days of expiration. The exact
 * duration within which an item gets deleted after expiration is specific to the
 * nature of the workload. Items that have expired and not been deleted will still show
 * up in reads, queries, and scans.
 *
 * As items are deleted, they are removed from any local secondary index and global
 * secondary index immediately in the same eventually consistent way as a standard delete
 * operation.
 *
 * For more information, see Time To Live in the
 * Amazon DynamoDB Developer Guide.
 */
export declare const updateTimeToLive: API.OperationMethod<UpdateTimeToLiveInput & RegionInput, UpdateTimeToLiveOutput, UpdateTimeToLiveError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dynamodb.d.ts.map