import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CreateChimeWebhookConfigurationException_base: S.TaggedErrorClass<"CreateChimeWebhookConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class CreateChimeWebhookConfigurationException extends /*@__PURE__*/ CreateChimeWebhookConfigurationException_base {
}
declare const CreateSlackChannelConfigurationException_base: S.TaggedErrorClass<"CreateSlackChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class CreateSlackChannelConfigurationException extends /*@__PURE__*/ CreateSlackChannelConfigurationException_base {
}
declare const CreateTeamsChannelConfigurationException_base: S.TaggedErrorClass<"CreateTeamsChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class CreateTeamsChannelConfigurationException extends /*@__PURE__*/ CreateTeamsChannelConfigurationException_base {
}
declare const DeleteChimeWebhookConfigurationException_base: S.TaggedErrorClass<"DeleteChimeWebhookConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteChimeWebhookConfigurationException extends /*@__PURE__*/ DeleteChimeWebhookConfigurationException_base {
}
declare const DeleteMicrosoftTeamsUserIdentityException_base: S.TaggedErrorClass<"DeleteMicrosoftTeamsUserIdentityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteMicrosoftTeamsUserIdentityException extends /*@__PURE__*/ DeleteMicrosoftTeamsUserIdentityException_base {
}
declare const DeleteSlackChannelConfigurationException_base: S.TaggedErrorClass<"DeleteSlackChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteSlackChannelConfigurationException extends /*@__PURE__*/ DeleteSlackChannelConfigurationException_base {
}
declare const DeleteSlackUserIdentityException_base: S.TaggedErrorClass<"DeleteSlackUserIdentityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteSlackUserIdentityException extends /*@__PURE__*/ DeleteSlackUserIdentityException_base {
}
declare const DeleteSlackWorkspaceAuthorizationFault_base: S.TaggedErrorClass<"DeleteSlackWorkspaceAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteSlackWorkspaceAuthorizationFault extends /*@__PURE__*/ DeleteSlackWorkspaceAuthorizationFault_base {
}
declare const DeleteTeamsChannelConfigurationException_base: S.TaggedErrorClass<"DeleteTeamsChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteTeamsChannelConfigurationException extends /*@__PURE__*/ DeleteTeamsChannelConfigurationException_base {
}
declare const DeleteTeamsConfiguredTeamException_base: S.TaggedErrorClass<"DeleteTeamsConfiguredTeamException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DeleteTeamsConfiguredTeamException extends /*@__PURE__*/ DeleteTeamsConfiguredTeamException_base {
}
declare const DescribeChimeWebhookConfigurationsException_base: S.TaggedErrorClass<"DescribeChimeWebhookConfigurationsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DescribeChimeWebhookConfigurationsException extends /*@__PURE__*/ DescribeChimeWebhookConfigurationsException_base {
}
declare const DescribeSlackChannelConfigurationsException_base: S.TaggedErrorClass<"DescribeSlackChannelConfigurationsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DescribeSlackChannelConfigurationsException extends /*@__PURE__*/ DescribeSlackChannelConfigurationsException_base {
}
declare const DescribeSlackUserIdentitiesException_base: S.TaggedErrorClass<"DescribeSlackUserIdentitiesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DescribeSlackUserIdentitiesException extends /*@__PURE__*/ DescribeSlackUserIdentitiesException_base {
}
declare const DescribeSlackWorkspacesException_base: S.TaggedErrorClass<"DescribeSlackWorkspacesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DescribeSlackWorkspacesException extends /*@__PURE__*/ DescribeSlackWorkspacesException_base {
}
declare const GetAccountPreferencesException_base: S.TaggedErrorClass<"GetAccountPreferencesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GetAccountPreferencesException extends /*@__PURE__*/ GetAccountPreferencesException_base {
}
declare const GetTeamsChannelConfigurationException_base: S.TaggedErrorClass<"GetTeamsChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GetTeamsChannelConfigurationException extends /*@__PURE__*/ GetTeamsChannelConfigurationException_base {
}
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ListMicrosoftTeamsConfiguredTeamsException_base: S.TaggedErrorClass<"ListMicrosoftTeamsConfiguredTeamsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ListMicrosoftTeamsConfiguredTeamsException extends /*@__PURE__*/ ListMicrosoftTeamsConfiguredTeamsException_base {
}
declare const ListMicrosoftTeamsUserIdentitiesException_base: S.TaggedErrorClass<"ListMicrosoftTeamsUserIdentitiesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ListMicrosoftTeamsUserIdentitiesException extends /*@__PURE__*/ ListMicrosoftTeamsUserIdentitiesException_base {
}
declare const ListTeamsChannelConfigurationsException_base: S.TaggedErrorClass<"ListTeamsChannelConfigurationsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ListTeamsChannelConfigurationsException extends /*@__PURE__*/ ListTeamsChannelConfigurationsException_base {
}
declare const MicrosoftTeamsTeamNotConfigured_base: S.TaggedErrorClass<"MicrosoftTeamsTeamNotConfigured", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MicrosoftTeamsTeamNotConfigured extends /*@__PURE__*/ MicrosoftTeamsTeamNotConfigured_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const SlackWorkspaceNotAuthorized_base: S.TaggedErrorClass<"SlackWorkspaceNotAuthorized", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SlackWorkspaceNotAuthorized extends /*@__PURE__*/ SlackWorkspaceNotAuthorized_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UpdateAccountPreferencesException_base: S.TaggedErrorClass<"UpdateAccountPreferencesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateAccountPreferencesException extends /*@__PURE__*/ UpdateAccountPreferencesException_base {
}
declare const UpdateChimeWebhookConfigurationException_base: S.TaggedErrorClass<"UpdateChimeWebhookConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateChimeWebhookConfigurationException extends /*@__PURE__*/ UpdateChimeWebhookConfigurationException_base {
}
declare const UpdateSlackChannelConfigurationException_base: S.TaggedErrorClass<"UpdateSlackChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateSlackChannelConfigurationException extends /*@__PURE__*/ UpdateSlackChannelConfigurationException_base {
}
declare const UpdateTeamsChannelConfigurationException_base: S.TaggedErrorClass<"UpdateTeamsChannelConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateTeamsChannelConfigurationException extends /*@__PURE__*/ UpdateTeamsChannelConfigurationException_base {
}
export type ResourceIdentifier = string;
export type ChatConfigurationArn = string;
export interface AssociateToConfigurationRequest {
    Resource: string;
    ChatConfiguration: string;
}
export interface AssociateToConfigurationResult {
}
export type ChimeWebhookDescription = string | redacted.Redacted<string>;
export type ChimeWebhookUrl = string | redacted.Redacted<string>;
export type Arn = string;
export type SnsTopicArnList = string[];
export type ConfigurationName = string;
export type CustomerCwLogLevel = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    TagKey: string;
    TagValue: string;
}
export type Tags = Tag[];
export interface CreateChimeWebhookConfigurationRequest {
    WebhookDescription: string | redacted.Redacted<string>;
    WebhookUrl: string | redacted.Redacted<string>;
    SnsTopicArns: string[];
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ResourceState = string;
export interface ChimeWebhookConfiguration {
    WebhookDescription: string | redacted.Redacted<string>;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string | undefined;
    LoggingLevel?: string | undefined;
    Tags?: Tag[] | undefined;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export interface CreateChimeWebhookConfigurationResult {
    WebhookConfiguration?: ChimeWebhookConfiguration | undefined;
}
export interface CustomActionDefinition {
    CommandText: string;
}
export type CustomActionAliasName = string;
export type CustomActionAttachmentNotificationType = string;
export type CustomActionButtonText = string;
export type CustomActionAttachmentCriteriaOperator = "HAS_VALUE" | "EQUALS" | (string & {});
export interface CustomActionAttachmentCriteria {
    Operator: CustomActionAttachmentCriteriaOperator;
    VariableName: string;
    Value?: string | undefined;
}
export type CustomActionAttachmentCriteriaList = CustomActionAttachmentCriteria[];
export type CustomActionAttachmentVariables = {
    [key: string]: string | undefined;
};
export interface CustomActionAttachment {
    NotificationType: string;
    ButtonText?: string | undefined;
    Criteria?: CustomActionAttachmentCriteria[] | undefined;
    Variables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CustomActionAttachmentList = CustomActionAttachment[];
export type TagList = Tag[];
export type ClientToken = string;
export type CustomActionName = string;
export interface CreateCustomActionRequest {
    Definition: CustomActionDefinition;
    AliasName?: string | undefined;
    Attachments?: CustomActionAttachment[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
    ActionName: string;
}
export type CustomActionArn = string;
export interface CreateCustomActionResult {
    CustomActionArn: string;
}
export type TeamsChannelId = string;
export type TeamsChannelName = string | redacted.Redacted<string>;
export type UUID = string;
export type TeamName = string | redacted.Redacted<string>;
export type GuardrailPolicyArn = string;
export type GuardrailPolicyArnList = string[];
export type BooleanAccountPreference = boolean;
export interface CreateTeamsChannelConfigurationRequest {
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string> | undefined;
    TeamId: string;
    TeamName?: string | redacted.Redacted<string> | undefined;
    TenantId: string;
    SnsTopicArns?: string[] | undefined;
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface TeamsChannelConfiguration {
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string> | undefined;
    TeamId: string;
    TeamName?: string | redacted.Redacted<string> | undefined;
    TenantId: string;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string | undefined;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
    Tags?: Tag[] | undefined;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export interface CreateTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration | undefined;
}
export type SlackTeamId = string;
export type SlackChannelId = string;
export type SlackChannelDisplayName = string | redacted.Redacted<string>;
export interface CreateSlackChannelConfigurationRequest {
    SlackTeamId: string;
    SlackChannelId: string;
    SlackChannelName?: string | redacted.Redacted<string> | undefined;
    SnsTopicArns?: string[] | undefined;
    IamRoleArn: string;
    ConfigurationName: string;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type SlackTeamName = string;
export interface SlackChannelConfiguration {
    SlackTeamName: string;
    SlackTeamId: string;
    SlackChannelId: string;
    SlackChannelName: string | redacted.Redacted<string>;
    ChatConfigurationArn: string;
    IamRoleArn: string;
    SnsTopicArns: string[];
    ConfigurationName?: string | undefined;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
    Tags?: Tag[] | undefined;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export interface CreateSlackChannelConfigurationResult {
    ChannelConfiguration?: SlackChannelConfiguration | undefined;
}
export interface DeleteChimeWebhookConfigurationRequest {
    ChatConfigurationArn: string;
}
export interface DeleteChimeWebhookConfigurationResult {
}
export interface DeleteCustomActionRequest {
    CustomActionArn: string;
}
export interface DeleteCustomActionResult {
}
export interface DeleteTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export interface DeleteTeamsChannelConfigurationResult {
}
export interface DeleteTeamsConfiguredTeamRequest {
    TeamId: string;
}
export interface DeleteTeamsConfiguredTeamResult {
}
export interface DeleteMicrosoftTeamsUserIdentityRequest {
    ChatConfigurationArn: string;
    UserId: string;
}
export interface DeleteMicrosoftTeamsUserIdentityResult {
}
export interface DeleteSlackChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export interface DeleteSlackChannelConfigurationResult {
}
export type SlackUserId = string;
export interface DeleteSlackUserIdentityRequest {
    ChatConfigurationArn: string;
    SlackTeamId: string;
    SlackUserId: string;
}
export interface DeleteSlackUserIdentityResult {
}
export interface DeleteSlackWorkspaceAuthorizationRequest {
    SlackTeamId: string;
}
export interface DeleteSlackWorkspaceAuthorizationResult {
}
export type MaxResults = number;
export type PaginationToken = string;
export interface DescribeChimeWebhookConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ChatConfigurationArn?: string | undefined;
}
export type ChimeWebhookConfigurationList = ChimeWebhookConfiguration[];
export interface DescribeChimeWebhookConfigurationsResult {
    NextToken?: string | undefined;
    WebhookConfigurations?: ChimeWebhookConfiguration[] | undefined;
}
export interface DescribeSlackChannelConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ChatConfigurationArn?: string | undefined;
}
export type SlackChannelConfigurationList = SlackChannelConfiguration[];
export interface DescribeSlackChannelConfigurationsResult {
    NextToken?: string | undefined;
    SlackChannelConfigurations?: SlackChannelConfiguration[] | undefined;
}
export interface DescribeSlackUserIdentitiesRequest {
    ChatConfigurationArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AwsUserIdentity = string;
export interface SlackUserIdentity {
    IamRoleArn: string;
    ChatConfigurationArn: string;
    SlackTeamId: string;
    SlackUserId: string;
    AwsUserIdentity?: string | undefined;
}
export type SlackUserIdentitiesList = SlackUserIdentity[];
export interface DescribeSlackUserIdentitiesResult {
    SlackUserIdentities?: SlackUserIdentity[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeSlackWorkspacesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SlackWorkspace {
    SlackTeamId: string;
    SlackTeamName: string;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export type SlackWorkspacesList = SlackWorkspace[];
export interface DescribeSlackWorkspacesResult {
    SlackWorkspaces?: SlackWorkspace[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateFromConfigurationRequest {
    Resource: string;
    ChatConfiguration: string;
}
export interface DisassociateFromConfigurationResult {
}
export interface GetAccountPreferencesRequest {
}
export interface AccountPreferences {
    UserAuthorizationRequired?: boolean | undefined;
    TrainingDataCollectionEnabled?: boolean | undefined;
}
export interface GetAccountPreferencesResult {
    AccountPreferences?: AccountPreferences | undefined;
}
export interface GetCustomActionRequest {
    CustomActionArn: string;
}
export interface CustomAction {
    CustomActionArn: string;
    Definition: CustomActionDefinition;
    AliasName?: string | undefined;
    Attachments?: CustomActionAttachment[] | undefined;
    ActionName?: string | undefined;
}
export interface GetCustomActionResult {
    CustomAction?: CustomAction | undefined;
}
export interface GetTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
}
export interface GetTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration | undefined;
}
export interface ListAssociationsRequest {
    ChatConfiguration: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AssociationListing {
    Resource: string;
}
export type AssociationList = AssociationListing[];
export interface ListAssociationsResult {
    Associations: AssociationListing[];
    NextToken?: string | undefined;
}
export interface ListCustomActionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type CustomActionArnList = string[];
export interface ListCustomActionsResult {
    CustomActions: string[];
    NextToken?: string | undefined;
}
export interface ListTeamsChannelConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    TeamId?: string | undefined;
}
export type TeamChannelConfigurationsList = TeamsChannelConfiguration[];
export interface ListTeamsChannelConfigurationsResult {
    NextToken?: string | undefined;
    TeamChannelConfigurations?: TeamsChannelConfiguration[] | undefined;
}
export interface ListMicrosoftTeamsConfiguredTeamsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ConfiguredTeam {
    TenantId: string;
    TeamId: string;
    TeamName?: string | undefined;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export type ConfiguredTeamsList = ConfiguredTeam[];
export interface ListMicrosoftTeamsConfiguredTeamsResult {
    ConfiguredTeams?: ConfiguredTeam[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMicrosoftTeamsUserIdentitiesRequest {
    ChatConfigurationArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TeamsUserIdentity {
    IamRoleArn: string;
    ChatConfigurationArn: string;
    TeamId: string;
    UserId?: string | undefined;
    AwsUserIdentity?: string | undefined;
    TeamsChannelId?: string | undefined;
    TeamsTenantId?: string | undefined;
}
export type TeamsUserIdentitiesList = TeamsUserIdentity[];
export interface ListMicrosoftTeamsUserIdentitiesResult {
    TeamsUserIdentities?: TeamsUserIdentity[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccountPreferencesRequest {
    UserAuthorizationRequired?: boolean | undefined;
    TrainingDataCollectionEnabled?: boolean | undefined;
}
export interface UpdateAccountPreferencesResult {
    AccountPreferences?: AccountPreferences | undefined;
}
export interface UpdateChimeWebhookConfigurationRequest {
    ChatConfigurationArn: string;
    WebhookDescription?: string | redacted.Redacted<string> | undefined;
    WebhookUrl?: string | redacted.Redacted<string> | undefined;
    SnsTopicArns?: string[] | undefined;
    IamRoleArn?: string | undefined;
    LoggingLevel?: string | undefined;
}
export interface UpdateChimeWebhookConfigurationResult {
    WebhookConfiguration?: ChimeWebhookConfiguration | undefined;
}
export interface UpdateCustomActionRequest {
    CustomActionArn: string;
    Definition: CustomActionDefinition;
    AliasName?: string | undefined;
    Attachments?: CustomActionAttachment[] | undefined;
}
export interface UpdateCustomActionResult {
    CustomActionArn: string;
}
export interface UpdateTeamsChannelConfigurationRequest {
    ChatConfigurationArn: string;
    ChannelId: string;
    ChannelName?: string | redacted.Redacted<string> | undefined;
    SnsTopicArns?: string[] | undefined;
    IamRoleArn?: string | undefined;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
}
export interface UpdateTeamsChannelConfigurationResult {
    ChannelConfiguration?: TeamsChannelConfiguration | undefined;
}
export interface UpdateSlackChannelConfigurationRequest {
    ChatConfigurationArn: string;
    SlackChannelId: string;
    SlackChannelName?: string | redacted.Redacted<string> | undefined;
    SnsTopicArns?: string[] | undefined;
    IamRoleArn?: string | undefined;
    LoggingLevel?: string | undefined;
    GuardrailPolicyArns?: string[] | undefined;
    UserAuthorizationRequired?: boolean | undefined;
}
export interface UpdateSlackChannelConfigurationResult {
    ChannelConfiguration?: SlackChannelConfiguration | undefined;
}
export type ErrorMessage = string;
export type AssociateToConfigurationError = InternalServiceError | InvalidRequestException | UnauthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Links a resource (for example, a custom action) to a channel configuration.
 */
export declare const associateToConfiguration: API.OperationMethod<AssociateToConfigurationRequest & RegionInput, AssociateToConfigurationResult, AssociateToConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateChimeWebhookConfigurationError = ConflictException | CreateChimeWebhookConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | CommonErrors;
/**
 * Creates an AWS Chatbot configuration for Amazon Chime.
 */
export declare const createChimeWebhookConfiguration: API.OperationMethod<CreateChimeWebhookConfigurationRequest & RegionInput, CreateChimeWebhookConfigurationResult, CreateChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateCustomActionError = ConflictException | InternalServiceError | InvalidRequestException | LimitExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom action that can be invoked as an alias or as a button on a notification.
 */
export declare const createCustomAction: API.OperationMethod<CreateCustomActionRequest & RegionInput, CreateCustomActionResult, CreateCustomActionError, Credentials | HttpClient.HttpClient>;
export type CreateMicrosoftTeamsChannelConfigurationError = ConflictException | CreateTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | MicrosoftTeamsTeamNotConfigured | CommonErrors;
/**
 * Creates an AWS Chatbot configuration for Microsoft Teams.
 */
export declare const createMicrosoftTeamsChannelConfiguration: API.OperationMethod<CreateTeamsChannelConfigurationRequest & RegionInput, CreateTeamsChannelConfigurationResult, CreateMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSlackChannelConfigurationError = ConflictException | CreateSlackChannelConfigurationException | InvalidParameterException | InvalidRequestException | LimitExceededException | SlackWorkspaceNotAuthorized | CommonErrors;
/**
 * Creates an AWS Chatbot confugration for Slack.
 */
export declare const createSlackChannelConfiguration: API.OperationMethod<CreateSlackChannelConfigurationRequest & RegionInput, CreateSlackChannelConfigurationResult, CreateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteChimeWebhookConfigurationError = DeleteChimeWebhookConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Amazon Chime webhook configuration for AWS Chatbot.
 */
export declare const deleteChimeWebhookConfiguration: API.OperationMethod<DeleteChimeWebhookConfigurationRequest & RegionInput, DeleteChimeWebhookConfigurationResult, DeleteChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a custom action.
 */
export declare const deleteCustomAction: API.OperationMethod<DeleteCustomActionRequest & RegionInput, DeleteCustomActionResult, DeleteCustomActionError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsChannelConfigurationError = DeleteTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Microsoft Teams channel configuration for AWS Chatbot
 */
export declare const deleteMicrosoftTeamsChannelConfiguration: API.OperationMethod<DeleteTeamsChannelConfigurationRequest & RegionInput, DeleteTeamsChannelConfigurationResult, DeleteMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsConfiguredTeamError = DeleteTeamsConfiguredTeamException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the Microsoft Teams team authorization allowing for channels to be configured in that Microsoft Teams team. Note that the Microsoft Teams team must have no channels configured to remove it.
 */
export declare const deleteMicrosoftTeamsConfiguredTeam: API.OperationMethod<DeleteTeamsConfiguredTeamRequest & RegionInput, DeleteTeamsConfiguredTeamResult, DeleteMicrosoftTeamsConfiguredTeamError, Credentials | HttpClient.HttpClient>;
export type DeleteMicrosoftTeamsUserIdentityError = DeleteMicrosoftTeamsUserIdentityException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Identifes a user level permission for a channel configuration.
 */
export declare const deleteMicrosoftTeamsUserIdentity: API.OperationMethod<DeleteMicrosoftTeamsUserIdentityRequest & RegionInput, DeleteMicrosoftTeamsUserIdentityResult, DeleteMicrosoftTeamsUserIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackChannelConfigurationError = DeleteSlackChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Slack channel configuration for AWS Chatbot
 */
export declare const deleteSlackChannelConfiguration: API.OperationMethod<DeleteSlackChannelConfigurationRequest & RegionInput, DeleteSlackChannelConfigurationResult, DeleteSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackUserIdentityError = DeleteSlackUserIdentityException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a user level permission for a Slack channel configuration.
 */
export declare const deleteSlackUserIdentity: API.OperationMethod<DeleteSlackUserIdentityRequest & RegionInput, DeleteSlackUserIdentityResult, DeleteSlackUserIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteSlackWorkspaceAuthorizationError = DeleteSlackWorkspaceAuthorizationFault | InvalidParameterException | CommonErrors;
/**
 * Deletes the Slack workspace authorization that allows channels to be configured in that workspace. This requires all configured channels in the workspace to be deleted.
 */
export declare const deleteSlackWorkspaceAuthorization: API.OperationMethod<DeleteSlackWorkspaceAuthorizationRequest & RegionInput, DeleteSlackWorkspaceAuthorizationResult, DeleteSlackWorkspaceAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DescribeChimeWebhookConfigurationsError = DescribeChimeWebhookConfigurationsException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists Amazon Chime webhook configurations optionally filtered by ChatConfigurationArn
 */
export declare const describeChimeWebhookConfigurations: API.PaginatedOperationMethod<DescribeChimeWebhookConfigurationsRequest & RegionInput, DescribeChimeWebhookConfigurationsResult, DescribeChimeWebhookConfigurationsError, Credentials | HttpClient.HttpClient, ChimeWebhookConfiguration>;
export type DescribeSlackChannelConfigurationsError = DescribeSlackChannelConfigurationsException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists Slack channel configurations optionally filtered by ChatConfigurationArn
 */
export declare const describeSlackChannelConfigurations: API.PaginatedOperationMethod<DescribeSlackChannelConfigurationsRequest & RegionInput, DescribeSlackChannelConfigurationsResult, DescribeSlackChannelConfigurationsError, Credentials | HttpClient.HttpClient, SlackChannelConfiguration>;
export type DescribeSlackUserIdentitiesError = DescribeSlackUserIdentitiesException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * Lists all Slack user identities with a mapped role.
 */
export declare const describeSlackUserIdentities: API.PaginatedOperationMethod<DescribeSlackUserIdentitiesRequest & RegionInput, DescribeSlackUserIdentitiesResult, DescribeSlackUserIdentitiesError, Credentials | HttpClient.HttpClient, SlackUserIdentity>;
export type DescribeSlackWorkspacesError = DescribeSlackWorkspacesException | InvalidParameterException | InvalidRequestException | CommonErrors;
/**
 * List all authorized Slack workspaces connected to the AWS Account onboarded with AWS Chatbot.
 */
export declare const describeSlackWorkspaces: API.PaginatedOperationMethod<DescribeSlackWorkspacesRequest & RegionInput, DescribeSlackWorkspacesResult, DescribeSlackWorkspacesError, Credentials | HttpClient.HttpClient, SlackWorkspace>;
export type DisassociateFromConfigurationError = InternalServiceError | InvalidRequestException | UnauthorizedException | ResourceNotFoundException | CommonErrors;
/**
 * Unlink a resource, for example a custom action, from a channel configuration.
 */
export declare const disassociateFromConfiguration: API.OperationMethod<DisassociateFromConfigurationRequest & RegionInput, DisassociateFromConfigurationResult, DisassociateFromConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAccountPreferencesError = GetAccountPreferencesException | InvalidRequestException | CommonErrors;
/**
 * Returns AWS Chatbot account preferences.
 */
export declare const getAccountPreferences: API.OperationMethod<GetAccountPreferencesRequest & RegionInput, GetAccountPreferencesResult, GetAccountPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a custom action.
 */
export declare const getCustomAction: API.OperationMethod<GetCustomActionRequest & RegionInput, GetCustomActionResult, GetCustomActionError, Credentials | HttpClient.HttpClient>;
export type GetMicrosoftTeamsChannelConfigurationError = GetTeamsChannelConfigurationException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a Microsoft Teams channel configuration in an AWS account.
 */
export declare const getMicrosoftTeamsChannelConfiguration: API.OperationMethod<GetTeamsChannelConfigurationRequest & RegionInput, GetTeamsChannelConfigurationResult, GetMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAssociationsError = InvalidRequestException | CommonErrors;
/**
 * Lists resources associated with a channel configuration.
 */
export declare const listAssociations: API.PaginatedOperationMethod<ListAssociationsRequest & RegionInput, ListAssociationsResult, ListAssociationsError, Credentials | HttpClient.HttpClient, AssociationListing>;
export type ListCustomActionsError = InternalServiceError | InvalidRequestException | UnauthorizedException | CommonErrors;
/**
 * Lists custom actions defined in this account.
 */
export declare const listCustomActions: API.PaginatedOperationMethod<ListCustomActionsRequest & RegionInput, ListCustomActionsResult, ListCustomActionsError, Credentials | HttpClient.HttpClient, CustomActionArn>;
export type ListMicrosoftTeamsChannelConfigurationsError = InvalidParameterException | InvalidRequestException | ListTeamsChannelConfigurationsException | CommonErrors;
/**
 * Lists all AWS Chatbot Microsoft Teams channel configurations in an AWS account.
 */
export declare const listMicrosoftTeamsChannelConfigurations: API.PaginatedOperationMethod<ListTeamsChannelConfigurationsRequest & RegionInput, ListTeamsChannelConfigurationsResult, ListMicrosoftTeamsChannelConfigurationsError, Credentials | HttpClient.HttpClient, TeamsChannelConfiguration>;
export type ListMicrosoftTeamsConfiguredTeamsError = InvalidParameterException | InvalidRequestException | ListMicrosoftTeamsConfiguredTeamsException | CommonErrors;
/**
 * Lists all authorized Microsoft Teams for an AWS Account
 */
export declare const listMicrosoftTeamsConfiguredTeams: API.PaginatedOperationMethod<ListMicrosoftTeamsConfiguredTeamsRequest & RegionInput, ListMicrosoftTeamsConfiguredTeamsResult, ListMicrosoftTeamsConfiguredTeamsError, Credentials | HttpClient.HttpClient, ConfiguredTeam>;
export type ListMicrosoftTeamsUserIdentitiesError = InvalidParameterException | InvalidRequestException | ListMicrosoftTeamsUserIdentitiesException | CommonErrors;
/**
 * A list all Microsoft Teams user identities with a mapped role.
 */
export declare const listMicrosoftTeamsUserIdentities: API.PaginatedOperationMethod<ListMicrosoftTeamsUserIdentitiesRequest & RegionInput, ListMicrosoftTeamsUserIdentitiesResult, ListMicrosoftTeamsUserIdentitiesError, Credentials | HttpClient.HttpClient, TeamsUserIdentity>;
export type ListTagsForResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all of the tags associated with the Amazon Resource Name (ARN) that you specify. The resource can be a user, server, or role.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | TooManyTagsException | CommonErrors;
/**
 * Attaches a key-value pair to a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Detaches a key-value pair from a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountPreferencesError = InvalidParameterException | InvalidRequestException | UpdateAccountPreferencesException | CommonErrors;
/**
 * Updates AWS Chatbot account preferences.
 */
export declare const updateAccountPreferences: API.OperationMethod<UpdateAccountPreferencesRequest & RegionInput, UpdateAccountPreferencesResult, UpdateAccountPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateChimeWebhookConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateChimeWebhookConfigurationException | CommonErrors;
/**
 * Updates a Amazon Chime webhook configuration.
 */
export declare const updateChimeWebhookConfiguration: API.OperationMethod<UpdateChimeWebhookConfigurationRequest & RegionInput, UpdateChimeWebhookConfigurationResult, UpdateChimeWebhookConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomActionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a custom action.
 */
export declare const updateCustomAction: API.OperationMethod<UpdateCustomActionRequest & RegionInput, UpdateCustomActionResult, UpdateCustomActionError, Credentials | HttpClient.HttpClient>;
export type UpdateMicrosoftTeamsChannelConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateTeamsChannelConfigurationException | CommonErrors;
/**
 * Updates an Microsoft Teams channel configuration.
 */
export declare const updateMicrosoftTeamsChannelConfiguration: API.OperationMethod<UpdateTeamsChannelConfigurationRequest & RegionInput, UpdateTeamsChannelConfigurationResult, UpdateMicrosoftTeamsChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSlackChannelConfigurationError = InvalidParameterException | InvalidRequestException | ResourceNotFoundException | UpdateSlackChannelConfigurationException | CommonErrors;
/**
 * Updates a Slack channel configuration.
 */
export declare const updateSlackChannelConfiguration: API.OperationMethod<UpdateSlackChannelConfigurationRequest & RegionInput, UpdateSlackChannelConfigurationResult, UpdateSlackChannelConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chatbot.d.ts.map