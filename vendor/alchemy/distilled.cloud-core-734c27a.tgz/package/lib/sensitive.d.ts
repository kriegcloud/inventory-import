import type * as AST from "effect/SchemaAST";
export declare const sensitiveValueSymbol: unique symbol;
/** What the plain form of a value that can hold a secret is shown as. */
export declare const REDACTED = "[REDACTED]";
/** Whether `ast` is marked sensitive (through optional, Suspend and encoding wrappers). */
export declare const isSensitive: (ast: AST.AST) => boolean;
/**
 * Whether a value of the type `ast` can hold a sensitive value, at any depth:
 * the type itself, members, map values, list elements and union arms.
 */
export declare const holdsSensitive: (ast: AST.AST) => boolean;
/** `plain`, the plain form of a value of the type `ast`: {@link REDACTED} when it can hold a secret. */
export declare const redactPlain: <A>(ast: AST.AST, plain: A) => A | typeof REDACTED;
/**
 * `value`, a parsed value of the type `ast`, as a log shows it: every
 * sensitive value `Redacted` whole, whatever its type, and the rest as is.
 */
export declare const redactParsed: (ast: AST.AST, value: unknown) => unknown;
/**
 * Walk a decoded (TS-named) value alongside its schema AST, wrapping values
 * marked sensitive (members, map values, list elements) in `Redacted`: a
 * string, or any non-null value of an untyped (`S.Unknown`) schema. A typed
 * struct is walked so its own sensitive members are wrapped and its type
 * stays accurate. Keys the schema doesn't model pass through. A union
 * applies every arm in turn; a map arm skips keys a sibling arm names.
 */
export declare const wrapSensitive: (ast: AST.AST, value: unknown, siblingNames?: ReadonlySet<string>) => unknown;
//# sourceMappingURL=sensitive.d.ts.map