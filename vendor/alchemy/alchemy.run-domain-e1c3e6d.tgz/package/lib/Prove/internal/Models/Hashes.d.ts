import type { Kit, Models } from "../Kit.ts";
/**
 * `HashSet` and `HashMap`. A set is its items, and a map its pairs, with no
 * two items and no two keys equal on a path: whether a value is one of them
 * is a formula, and adding or removing one splits the path on it. The order
 * the library gives them in is the order of their hashes, so code that reads
 * them in order is read once for every order.
 */
export declare const make: (kit: Kit) => {
    models: Models;
};
//# sourceMappingURL=Hashes.d.ts.map