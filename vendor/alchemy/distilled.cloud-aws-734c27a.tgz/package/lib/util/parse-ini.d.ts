import * as Effect from "effect/Effect";
import { SharedConfigError } from "../credentials-service.ts";
/** Section prefixes the shared config files use (`[profile x]`, `[sso-session x]`, `[services x]`). */
export declare const IniSectionType: {
    readonly PROFILE: "profile";
    readonly SSO_SESSION: "sso-session";
    readonly SERVICES: "services";
};
export type IniSectionType = (typeof IniSectionType)[keyof typeof IniSectionType];
export type IniSection = Record<string, string | undefined>;
export type ParsedIniData = Record<string, IniSection>;
export interface SharedConfigFiles {
    credentialsFile: ParsedIniData;
    configFile: ParsedIniData;
}
/** Parses the ini text of the shared file at `path`. */
export declare const parseIni: (iniData: string, path: string) => Effect.Effect<ParsedIniData, SharedConfigError>;
export declare const parseSSOSessionData: (data: ParsedIniData) => ParsedIniData;
//# sourceMappingURL=parse-ini.d.ts.map