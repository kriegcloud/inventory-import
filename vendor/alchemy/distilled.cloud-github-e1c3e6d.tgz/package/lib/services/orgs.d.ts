import * as API from "@distilled.cloud/core/api";
import type * as Redacted from "effect/Redacted";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AssignTeamToOrgRoleRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The unique identifier of the role. */
    role_id: number;
}
export interface AssignTeamToOrgRoleResponse {
}
export interface AssignUserToOrgRoleRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the role. */
    role_id: number;
}
export interface AssignUserToOrgRoleResponse {
}
export interface BlockUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface BlockUserResponse {
}
/** Unique identifiers of the requests for access via fine-grained personal access token. Must be formed of between 1 and 100 `pat_request_id` values. */
export type BulkReviewPatGrantRequestsInRequestPatRequestIdsList = Array<number>;
/** Action to apply to the requests. */
export type BulkReviewPatGrantRequestsInRequestAction = "approve" | "deny";
export interface BulkReviewPatGrantRequestsInRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifiers of the requests for access via fine-grained personal access token. Must be formed of between 1 and 100 `pat_request_id` values. */
    pat_request_ids?: BulkReviewPatGrantRequestsInRequestPatRequestIdsList | undefined;
    /** Action to apply to the requests. */
    action: BulkReviewPatGrantRequestsInRequestAction | (string & {});
    /** Reason for approving or denying the requests. Max 1024 characters. */
    reason?: string | null | undefined;
}
export interface BulkReviewPatGrantRequestsInResponse {
}
export interface CancelInvitationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the invitation. */
    invitation_id: number;
}
export interface CancelInvitationResponse {
}
export interface CheckBlockedUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckBlockedUserResponse {
}
export interface CheckMembershipForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckMembershipForUserResponse {
}
export interface CheckPublicMembershipForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckPublicMembershipForUserResponse {
}
export interface ConvertMemberToOutsideCollaboratorRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** When set to `true`, the request will be performed asynchronously. Returns a 202 status code when the job is successfully queued. */
    async?: boolean | undefined;
}
export interface ConvertMemberToOutsideCollaboratorResponse {
}
/** The status of the artifact. Can be either deployed or decommissioned. */
export type CreateArtifactDeploymentRecordRequestStatus = "deployed" | "decommissioned";
/** The tags associated with the deployment. */
export type CreateArtifactDeploymentRecordRequestTagsMap = {
    [key: string]: string | undefined;
};
export type CreateArtifactDeploymentRecordRequestRuntimeRisksItem = "critical-resource" | "internet-exposed" | "lateral-movement" | "sensitive-data";
/** A list of runtime risks associated with the deployment. */
export type CreateArtifactDeploymentRecordRequestRuntimeRisksList = Array<CreateArtifactDeploymentRecordRequestRuntimeRisksItem | (string & {})>;
export interface CreateArtifactDeploymentRecordRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the artifact. */
    name: string;
    /** The hex encoded digest of the artifact. */
    digest: string;
    /** The artifact version. */
    version?: string | undefined;
    /** The status of the artifact. Can be either deployed or decommissioned. */
    status: CreateArtifactDeploymentRecordRequestStatus | (string & {});
    /** The stage of the deployment. */
    logical_environment: string;
    /** The physical region of the deployment. */
    physical_environment?: string | undefined;
    /** The deployment cluster. */
    cluster?: string | undefined;
    /** The unique identifier for the deployment represented by the new record. To accommodate differing containers and namespaces within a cluster, the following format is recommended: {namespaceName}-{deploymentName}-{containerName}. */
    deployment_name: string;
    /** The tags associated with the deployment. */
    tags?: CreateArtifactDeploymentRecordRequestTagsMap | undefined;
    /** A list of runtime risks associated with the deployment. */
    runtime_risks?: CreateArtifactDeploymentRecordRequestRuntimeRisksList | undefined;
    /** The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter. */
    github_repository?: string | undefined;
    /** If true, the endpoint will return the created or updated record in the response body. */
    return_records?: boolean | undefined;
}
export type ArtifactDeploymentRecordTagsMap = {
    [key: string]: string | undefined;
};
export type ArtifactDeploymentRecordRuntimeRisksItem = "critical-resource" | "internet-exposed" | "lateral-movement" | "sensitive-data";
/** A list of runtime risks associated with the deployment. */
export type ArtifactDeploymentRecordRuntimeRisksList = Array<ArtifactDeploymentRecordRuntimeRisksItem>;
/** Artifact Metadata Deployment Record */
export interface ArtifactDeploymentRecord {
    id?: number | undefined;
    digest?: string | undefined;
    logical_environment?: string | undefined;
    physical_environment?: string | undefined;
    cluster?: string | undefined;
    deployment_name?: string | undefined;
    tags?: ArtifactDeploymentRecordTagsMap | undefined;
    /** A list of runtime risks associated with the deployment. */
    runtime_risks?: ArtifactDeploymentRecordRuntimeRisksList | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
    /** The ID of the provenance attestation associated with the deployment record. */
    attestation_id?: number | null | undefined;
}
export type CreateArtifactDeploymentRecordResponseDeploymentRecordsList = Array<ArtifactDeploymentRecord>;
export interface CreateArtifactDeploymentRecordResponse {
    /** The number of deployment records created */
    total_count: number;
    deployment_records?: CreateArtifactDeploymentRecordResponseDeploymentRecordsList | undefined;
}
/** The status of the artifact (e.g., active, inactive). */
export type CreateArtifactStorageRecordRequestStatus = "active" | "eol" | "deleted";
export interface CreateArtifactStorageRecordRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the artifact. */
    name: string;
    /** The digest of the artifact (algorithm:hex-encoded-digest). */
    digest: string;
    /** The artifact version. */
    version?: string | undefined;
    /** The URL where the artifact is stored. */
    artifact_url?: string | undefined;
    /** The path of the artifact. */
    path?: string | undefined;
    /** The base URL of the artifact registry. */
    registry_url: string;
    /** The repository name within the registry. */
    repository?: string | undefined;
    /** The status of the artifact (e.g., active, inactive). */
    status?: CreateArtifactStorageRecordRequestStatus | (string & {}) | undefined;
    /** The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter. */
    github_repository?: string | undefined;
    /** If true, the endpoint will return the created record in the response body. */
    return_records?: boolean | undefined;
}
export interface CreateArtifactStorageRecordResponseStorageRecordsItem {
    id?: number | undefined;
    name?: string | undefined;
    digest?: string | undefined;
    artifact_url?: string | null | undefined;
    registry_url?: string | undefined;
    repository?: string | null | undefined;
    status?: string | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
export type CreateArtifactStorageRecordResponseStorageRecordsList = Array<CreateArtifactStorageRecordResponseStorageRecordsItem>;
export interface CreateArtifactStorageRecordResponse {
    total_count: number;
    storage_records?: CreateArtifactStorageRecordResponseStorageRecordsList | undefined;
}
/** The deployment status of the artifact. */
export type CreateClusterDeploymentRecordsJobRequestDeploymentsItemStatus = "deployed" | "decommissioned";
/** Key-value pairs to tag the deployment record. */
export type CreateClusterDeploymentRecordsJobRequestDeploymentsItemTagsMap = {
    [key: string]: string | undefined;
};
export type CreateClusterDeploymentRecordsJobRequestDeploymentsItemRuntimeRisksItem = "critical-resource" | "internet-exposed" | "lateral-movement" | "sensitive-data";
/** A list of runtime risks associated with the deployment. */
export type CreateClusterDeploymentRecordsJobRequestDeploymentsItemRuntimeRisksList = Array<CreateClusterDeploymentRecordsJobRequestDeploymentsItemRuntimeRisksItem | (string & {})>;
export interface CreateClusterDeploymentRecordsJobRequestDeploymentsItem {
    /** The name of the artifact. */
    name: string;
    /** The hex encoded digest of the artifact. */
    digest: string;
    /** The artifact version. */
    version?: string | undefined;
    /** The deployment status of the artifact. */
    status?: CreateClusterDeploymentRecordsJobRequestDeploymentsItemStatus | (string & {}) | undefined;
    /** The unique identifier for the deployment represented by the new record. */
    deployment_name: string;
    /** The name of the GitHub repository associated with the artifact. */
    github_repository?: string | undefined;
    /** Key-value pairs to tag the deployment record. */
    tags?: CreateClusterDeploymentRecordsJobRequestDeploymentsItemTagsMap | undefined;
    /** A list of runtime risks associated with the deployment. */
    runtime_risks?: CreateClusterDeploymentRecordsJobRequestDeploymentsItemRuntimeRisksList | undefined;
}
/** The list of deployments to record. */
export type CreateClusterDeploymentRecordsJobRequestDeploymentsList = Array<CreateClusterDeploymentRecordsJobRequestDeploymentsItem>;
export interface CreateClusterDeploymentRecordsJobRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The cluster name. */
    cluster: string;
    /** The stage of the deployment. */
    logical_environment: string;
    /** The physical region of the deployment. */
    physical_environment?: string | undefined;
    /** The list of deployments to record. */
    deployments: CreateClusterDeploymentRecordsJobRequestDeploymentsList;
}
export interface CreateClusterDeploymentRecordsJobResponse {
}
/** The role for the new member. * `admin` - Organization owners with full administrative rights to the organization and complete access to all repositories and teams. * `direct_member` - Non-owner organization members with ability to see other members and join teams by invitation. * `billing_manager` - Non-owner organization members with ability to manage the billing settings of your organization. * `reinstate` - The previous role assigned to the invitee before they were removed from your organization. Can be one of the roles listed above. Only works if the invitee was previously part of your organization. */
export type CreateInvitationRequestRole = "admin" | "direct_member" | "billing_manager" | "reinstate";
/** Specify IDs for the teams you want to invite new members to. */
export type CreateInvitationRequestTeamIdsList = Array<number>;
export interface CreateInvitationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** **Required unless you provide `email`**. GitHub user ID for the person you are inviting. */
    invitee_id?: number | undefined;
    /** **Required unless you provide `invitee_id`**. Email address of the person you are inviting, which can be an existing GitHub user. */
    email?: string | undefined;
    /** The role for the new member. * `admin` - Organization owners with full administrative rights to the organization and complete access to all repositories and teams. * `direct_member` - Non-owner organization members with ability to see other members and join teams by invitation. * `billing_manager` - Non-owner organization members with ability to manage the billing settings of your organization. * `reinstate` - The previous role assigned to the invitee before they were removed from your organization. Can be one of the roles listed above. Only works if the invitee was previously part of your organization. */
    role?: CreateInvitationRequestRole | (string & {}) | undefined;
    /** Specify IDs for the teams you want to invite new members to. */
    team_ids?: CreateInvitationRequestTeamIdsList | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** Organization Invitation */
export interface OrganizationInvitation {
    id: number;
    login: string | null;
    email: string | null;
    role: string;
    created_at: string;
    failed_at?: string | null | undefined;
    failed_reason?: string | null | undefined;
    inviter: SimpleUser;
    team_count: number;
    node_id: string;
    invitation_teams_url: string;
    invitation_source?: string | undefined;
}
/** The data type of the issue field. */
export type CreateIssueFieldRequestDataType = "text" | "date" | "single_select" | "multi_select" | "number";
/** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled. Defaults to `organization_members_only`. */
export type CreateIssueFieldRequestVisibility = "organization_members_only" | "all";
/** Color for the option. */
export type CreateIssueFieldRequestOptionsItemColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
export interface CreateIssueFieldRequestOptionsItem {
    /** Name of the option. */
    name: string;
    /** Description of the option. */
    description?: string | null | undefined;
    /** Color for the option. */
    color: CreateIssueFieldRequestOptionsItemColor | (string & {});
    /** Priority of the option for ordering. */
    priority: number;
}
/** Options for select fields. Required when data_type is 'single_select' or 'multi_select'. */
export type CreateIssueFieldRequestOptionsList = Array<CreateIssueFieldRequestOptionsItem>;
export interface CreateIssueFieldRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Name of the issue field. */
    name: string;
    /** Description of the issue field. */
    description?: string | null | undefined;
    /** The data type of the issue field. */
    data_type: CreateIssueFieldRequestDataType | (string & {});
    /** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled. Defaults to `organization_members_only`. */
    visibility?: CreateIssueFieldRequestVisibility | (string & {}) | undefined;
    /** Options for select fields. Required when data_type is 'single_select' or 'multi_select'. */
    options?: CreateIssueFieldRequestOptionsList | null | undefined;
}
/** The data type of the issue field. */
export type IssueFieldDataType = "text" | "date" | "single_select" | "multi_select" | "number";
/** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). */
export type IssueFieldVisibility = "organization_members_only" | "all";
/** The color of the option. */
export type IssueFieldOptionsItemColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
export interface IssueFieldOptionsItem {
    /** The unique identifier of the option. */
    id: number;
    /** The name of the option. */
    name: string;
    /** The description of the option. */
    description?: string | null | undefined;
    /** The color of the option. */
    color?: IssueFieldOptionsItemColor | null | undefined;
    /** The priority of the option for ordering. */
    priority?: number | null | undefined;
    /** The time the option was created. */
    created_at?: string | undefined;
    /** The time the option was last updated. */
    updated_at?: string | undefined;
}
/** Available options for single select and multi select fields. */
export type IssueFieldOptionsList = Array<IssueFieldOptionsItem>;
/** A custom attribute defined at the organization level for attaching structured data to issues. */
export interface IssueField {
    /** The unique identifier of the issue field. */
    id: number;
    /** The node identifier of the issue field. */
    node_id: string;
    /** The name of the issue field. */
    name: string;
    /** The description of the issue field. */
    description?: string | null | undefined;
    /** The data type of the issue field. */
    data_type: IssueFieldDataType;
    /** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). */
    visibility?: IssueFieldVisibility | undefined;
    /** Available options for single select and multi select fields. */
    options?: IssueFieldOptionsList | null | undefined;
    /** The time the issue field was created. */
    created_at?: string | undefined;
    /** The time the issue field was last updated. */
    updated_at?: string | undefined;
}
/** Color for the issue type. */
export type CreateIssueTypeRequestColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
export interface CreateIssueTypeRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Name of the issue type. */
    name: string;
    /** Whether or not the issue type is enabled at the organization level. */
    is_enabled: boolean;
    /** Description of the issue type. */
    description?: string | null | undefined;
    /** Color for the issue type. */
    color?: CreateIssueTypeRequestColor | (string & {}) | null | undefined;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
export type WebhookConfigInsecureSsl = string | number;
/** Key/value pairs to provide settings for this webhook. */
export interface CreateWebhookRequestConfig {
    url: string;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
    username?: string | undefined;
    password?: string | Redacted.Redacted<string> | undefined;
}
/** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. Set to `["*"]` to receive all possible events. */
export type CreateWebhookRequestEventsList = Array<string>;
export interface CreateWebhookRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Must be passed as "web". */
    name: string;
    /** Key/value pairs to provide settings for this webhook. */
    config: CreateWebhookRequestConfig;
    /** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. Set to `["*"]` to receive all possible events. */
    events?: CreateWebhookRequestEventsList | undefined;
    /** Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. */
    active?: boolean | undefined;
}
export type OrgHookEventsList = Array<string>;
export interface OrgHookConfig {
    url?: string | undefined;
    insecure_ssl?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
}
/** Org Hook */
export interface OrgHook {
    id: number;
    url: string;
    ping_url: string;
    deliveries_url?: string | undefined;
    name: string;
    events: OrgHookEventsList;
    active: boolean;
    config: OrgHookConfig;
    updated_at: string;
    created_at: string;
    type: string;
}
/** The type of the value for the property */
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestValueType = "string" | "single_select" | "multi_select" | "true_false" | "url";
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestDefaultValueCase1List = Array<string>;
/** Default value of the property */
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestDefaultValue = string | CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestDefaultValueCase1List;
/** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestAllowedValuesList = Array<string>;
/** Who can edit the values of the property */
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestValuesEditableBy = "org_actors" | "org_and_repo_actors";
export interface CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The custom property name */
    custom_property_name: string;
    /** The type of the value for the property */
    value_type: CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestValueType | (string & {});
    /** Whether the property is required. */
    required?: boolean | undefined;
    /** Default value of the property */
    default_value?: CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestDefaultValue | null | undefined;
    /** Short description of the property */
    description?: string | null | undefined;
    /** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
    allowed_values?: CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestAllowedValuesList | null | undefined;
    /** Who can edit the values of the property */
    values_editable_by?: CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequestValuesEditableBy | (string & {}) | null | undefined;
    /** A regular expression (RE2 syntax) that values of the property must match. Only supported for properties with a `value_type` of `string`. */
    regex?: string | null | undefined;
    /** Whether setting properties values is mandatory */
    require_explicit_values?: boolean | undefined;
}
/** The source type of the property */
export type CustomPropertySourceType = "organization" | "enterprise";
/** The type of the value for the property */
export type CustomPropertyValueType = "string" | "single_select" | "multi_select" | "true_false" | "url";
export type CustomPropertyDefaultValueCase1List = Array<string>;
/** Default value of the property */
export type CustomPropertyDefaultValue = string | CustomPropertyDefaultValueCase1List;
/** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
export type CustomPropertyAllowedValuesList = Array<string>;
/** Who can edit the values of the property */
export type CustomPropertyValuesEditableBy = "org_actors" | "org_and_repo_actors";
/** Custom property defined on an organization */
export interface CustomProperty {
    /** The name of the property */
    property_name: string;
    /** The URL that can be used to fetch, update, or delete info about this property via the API. */
    url?: string | undefined;
    /** The source type of the property */
    source_type?: CustomPropertySourceType | undefined;
    /** The type of the value for the property */
    value_type: CustomPropertyValueType;
    /** Whether the property is required. */
    required?: boolean | undefined;
    /** Default value of the property */
    default_value?: CustomPropertyDefaultValue | null | undefined;
    /** Short description of the property */
    description?: string | null | undefined;
    /** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
    allowed_values?: CustomPropertyAllowedValuesList | null | undefined;
    /** Who can edit the values of the property */
    values_editable_by?: CustomPropertyValuesEditableBy | null | undefined;
    /** A regular expression (RE2 syntax) that values of the property must match. Only present for properties with a `value_type` of `string` that define a regular expression. */
    regex?: string | null | undefined;
    /** Whether setting properties values is mandatory */
    require_explicit_values?: boolean | undefined;
}
/** The type of the value for the property */
export type CustomPropertyBatchItemPayloadValueType = "string" | "single_select" | "multi_select" | "true_false" | "url";
export type CustomPropertyBatchItemPayloadDefaultValueCase1List = Array<string>;
/** Default value of the property */
export type CustomPropertyBatchItemPayloadDefaultValue = string | CustomPropertyBatchItemPayloadDefaultValueCase1List;
/** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
export type CustomPropertyBatchItemPayloadAllowedValuesList = Array<string>;
/** Who can edit the values of the property */
export type CustomPropertyBatchItemPayloadValuesEditableBy = "org_actors" | "org_and_repo_actors";
/** Payload for a single custom property definition when creating or updating custom properties in a batch */
export interface CustomPropertyBatchItemPayload {
    /** The name of the property */
    property_name: string;
    /** The type of the value for the property */
    value_type: CustomPropertyBatchItemPayloadValueType | (string & {});
    /** Whether the property is required. */
    required?: boolean | undefined;
    /** Default value of the property */
    default_value?: CustomPropertyBatchItemPayloadDefaultValue | null | undefined;
    /** Short description of the property */
    description?: string | null | undefined;
    /** An ordered list of the allowed values of the property. The property can have up to 200 allowed values. */
    allowed_values?: CustomPropertyBatchItemPayloadAllowedValuesList | null | undefined;
    /** Who can edit the values of the property */
    values_editable_by?: CustomPropertyBatchItemPayloadValuesEditableBy | (string & {}) | null | undefined;
    /** A regular expression (RE2 syntax) that values of the property must match. Only supported for properties with a `value_type` of `string`. */
    regex?: string | null | undefined;
    /** Whether setting properties values is mandatory */
    require_explicit_values?: boolean | undefined;
}
/** The array of custom properties to create or update. */
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsRequestPropertiesList = Array<CustomPropertyBatchItemPayload>;
export interface CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The array of custom properties to create or update. */
    properties: CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsRequestPropertiesList;
}
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsResponseBodyList = Array<CustomProperty>;
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsResponse = CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsResponseBodyList;
/** The names of repositories that the custom property values will be applied to. */
export type CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequestRepositoryNamesList = Array<string>;
export type CustomPropertyValueValueCase1List = Array<string>;
/** The value assigned to the property */
export type CustomPropertyValueValue = string | CustomPropertyValueValueCase1List;
/** Custom property name and associated value */
export interface CustomPropertyValue {
    /** The name of the property */
    property_name: string;
    /** The value assigned to the property */
    value: CustomPropertyValueValue | null;
}
/** List of custom property names and associated values to apply to the repositories. */
export type CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequestPropertiesList = Array<CustomPropertyValue>;
export interface CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The names of repositories that the custom property values will be applied to. */
    repository_names: CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequestRepositoryNamesList;
    /** List of custom property names and associated values to apply to the repositories. */
    properties: CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequestPropertiesList;
}
export interface CustomPropertiesForReposCreateOrUpdateOrganizationValuesResponse {
}
export interface CustomPropertiesForReposDeleteOrganizationDefinitionRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The custom property name */
    custom_property_name: string;
}
export interface CustomPropertiesForReposDeleteOrganizationDefinitionResponse {
}
export interface CustomPropertiesForReposGetOrganizationDefinitionRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The custom property name */
    custom_property_name: string;
}
export interface CustomPropertiesForReposGetOrganizationDefinitionsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type CustomPropertiesForReposGetOrganizationDefinitionsResponseBodyList = Array<CustomProperty>;
export type CustomPropertiesForReposGetOrganizationDefinitionsResponse = CustomPropertiesForReposGetOrganizationDefinitionsResponseBodyList;
export interface CustomPropertiesForReposGetOrganizationValuesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Finds repositories in the organization with a query containing one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching for repositories](https://docs.github.com/articles/searching-for-repositories/)" for a detailed list of qualifiers. */
    repository_query?: string | undefined;
}
/** List of custom property names and associated values */
export type OrgRepoCustomPropertyValuesPropertiesList = Array<CustomPropertyValue>;
/** List of custom property values for a repository */
export interface OrgRepoCustomPropertyValues {
    repository_id: number;
    repository_name: string;
    repository_full_name: string;
    /** List of custom property names and associated values */
    properties: OrgRepoCustomPropertyValuesPropertiesList;
}
export type CustomPropertiesForReposGetOrganizationValuesResponseBodyList = Array<OrgRepoCustomPropertyValues>;
export type CustomPropertiesForReposGetOrganizationValuesResponse = CustomPropertiesForReposGetOrganizationValuesResponseBodyList;
export interface DeleteRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface DeleteResponse {
}
/** List of subject digests associated with the artifact attestations to delete. */
export type DeleteAttestationsBulkRequestBodyCase0SubjectDigestsList = Array<string>;
export interface DeleteAttestationsBulkRequestBodyCase0 {
    /** List of subject digests associated with the artifact attestations to delete. */
    subject_digests: DeleteAttestationsBulkRequestBodyCase0SubjectDigestsList;
}
/** List of unique IDs associated with the artifact attestations to delete. */
export type DeleteAttestationsBulkRequestBodyCase1AttestationIdsList = Array<number>;
export interface DeleteAttestationsBulkRequestBodyCase1 {
    /** List of unique IDs associated with the artifact attestations to delete. */
    attestation_ids: DeleteAttestationsBulkRequestBodyCase1AttestationIdsList;
}
/** The request body must include either `subject_digests` or `attestation_ids`, but not both. */
export type DeleteAttestationsBulkRequestBody = DeleteAttestationsBulkRequestBodyCase0 | DeleteAttestationsBulkRequestBodyCase1;
export interface DeleteAttestationsBulkRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    body: DeleteAttestationsBulkRequestBody;
}
export interface DeleteAttestationsBulkResponse {
}
export interface DeleteAttestationsByIdRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Attestation ID */
    attestation_id: number;
}
export interface DeleteAttestationsByIdResponse {
}
export interface DeleteAttestationsBySubjectDigestRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Subject Digest */
    subject_digest: string;
}
export interface DeleteAttestationsBySubjectDigestResponse {
}
export interface DeleteIssueFieldRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the issue field. */
    issue_field_id: number;
}
export interface DeleteIssueFieldResponse {
}
export interface DeleteIssueTypeRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the issue type. */
    issue_type_id: number;
}
export interface DeleteIssueTypeResponse {
}
export interface DeleteWebhookRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface DeleteWebhookResponse {
}
export interface DisableSelectedRepositoryImmutableReleasesOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface DisableSelectedRepositoryImmutableReleasesOrganizationResponse {
}
export interface EnableSelectedRepositoryImmutableReleasesOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface EnableSelectedRepositoryImmutableReleasesOrganizationResponse {
}
/** The names of repositories that the external custom property values will be applied to. */
export type ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequestRepositoryNamesList = Array<string>;
/** List of external custom property names and associated values to apply to the repositories. */
export type ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequestPropertiesList = Array<CustomPropertyValue>;
export interface ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The names of repositories that the external custom property values will be applied to. */
    repository_names: ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequestRepositoryNamesList;
    /** List of external custom property names and associated values to apply to the repositories. */
    properties: ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequestPropertiesList;
}
export interface ExternalPropertiesForReposCreateOrUpdateOrganizationValuesResponse {
}
/** Repository name and associated external custom property value */
export interface RepositoryExternalPropertyPayload {
    /** The name of the repository */
    repository_name: string;
    /** The value assigned to the repository. Set to `null` to unset the value for this repository. */
    value: string | null;
}
/** The names of repositories and the values that the named external custom property will be set to. */
export type ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyRequestRepositoryValuesList = Array<RepositoryExternalPropertyPayload>;
export interface ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the external custom property */
    property_name: string;
    /** The names of repositories and the values that the named external custom property will be set to. */
    repository_values: ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyRequestRepositoryValuesList;
}
export interface ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyResponse {
}
export interface ExternalPropertiesForReposDeleteOrganizationValuesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the external custom property */
    property_name: string;
}
export interface ExternalPropertiesForReposDeleteOrganizationValuesResponse {
}
export interface ExternalPropertiesForReposGetOrganizationAppInstallationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The GitHub App installation that was registered. */
export interface OrganizationExternalPropertyInstallationInstallation {
    /** The unique identifier of the GitHub App installation. */
    id: number;
}
/** A GitHub App installation that has been registered to read and write an organization's external custom properties, together with the display name assigned to it. */
export interface OrganizationExternalPropertyInstallation {
    /** The display name assigned to the app installation's external custom properties in the organization. */
    display_name: string;
    /** The GitHub App installation that was registered. */
    installation: OrganizationExternalPropertyInstallationInstallation;
}
export type ExternalPropertiesForReposGetOrganizationAppInstallationsResponseBodyList = Array<OrganizationExternalPropertyInstallation>;
export type ExternalPropertiesForReposGetOrganizationAppInstallationsResponse = ExternalPropertiesForReposGetOrganizationAppInstallationsResponseBodyList;
export interface ExternalPropertiesForReposGetOrganizationDefinitionsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** External custom property defined for a GitHub App installation */
export interface ExternalProperty {
    /** The name of the external property */
    property_name: string;
}
export type ExternalPropertiesForReposGetOrganizationDefinitionsResponseBodyList = Array<ExternalProperty>;
export type ExternalPropertiesForReposGetOrganizationDefinitionsResponse = ExternalPropertiesForReposGetOrganizationDefinitionsResponseBodyList;
export interface ExternalPropertiesForReposRegisterOrganizationAppInstallationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the GitHub App installation to register for managing external custom properties. When authenticating as a GitHub App installation, this defaults to the authenticated installation and can be omitted. It is required for all other callers (users and fine-grained personal access tokens). */
    installation_id?: number | undefined;
    /** The display name for this app installation's external custom properties in the organization. Must be 1 to 15 characters and contain only letters and numbers. Capitalization is preserved as entered. This can't be changed after the app installation is registered. */
    display_name: string;
}
export interface GetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface OrganizationFullPlan {
    name: string;
    space: number;
    private_repos: number;
    filled_seats?: number | undefined;
    seats?: number | undefined;
}
/** Organization Full */
export interface OrganizationFull {
    login: string;
    id: number;
    node_id: string;
    url: string;
    repos_url: string;
    events_url: string;
    hooks_url: string;
    issues_url: string;
    members_url: string;
    public_members_url: string;
    avatar_url: string;
    description: string | null;
    name?: string | undefined;
    company?: string | null | undefined;
    blog?: string | null | undefined;
    location?: string | null | undefined;
    email?: string | null | undefined;
    twitter_username?: string | null | undefined;
    is_verified?: boolean | undefined;
    has_organization_projects: boolean;
    has_repository_projects: boolean;
    public_repos: number;
    public_gists: number;
    followers: number;
    following: number;
    html_url: string;
    type: string;
    total_private_repos?: number | undefined;
    owned_private_repos?: number | undefined;
    private_gists?: number | null | undefined;
    disk_usage?: number | null | undefined;
    /** The number of collaborators on private repositories. This field may be null if the number of private repositories is over 50,000. */
    collaborators?: number | null | undefined;
    billing_email?: string | null | undefined;
    plan?: OrganizationFullPlan | undefined;
    default_repository_permission?: string | null | undefined;
    /** The default branch for repositories created in this organization. */
    default_repository_branch?: string | null | undefined;
    members_can_create_repositories?: boolean | null | undefined;
    two_factor_requirement_enabled?: boolean | null | undefined;
    members_allowed_repository_creation_type?: string | undefined;
    members_can_create_public_repositories?: boolean | undefined;
    members_can_create_private_repositories?: boolean | undefined;
    members_can_create_internal_repositories?: boolean | undefined;
    members_can_create_pages?: boolean | undefined;
    members_can_create_public_pages?: boolean | undefined;
    members_can_create_private_pages?: boolean | undefined;
    members_can_delete_repositories?: boolean | undefined;
    members_can_change_repo_visibility?: boolean | undefined;
    members_can_invite_outside_collaborators?: boolean | undefined;
    members_can_delete_issues?: boolean | undefined;
    display_commenter_full_name_setting_enabled?: boolean | undefined;
    readers_can_create_discussions?: boolean | undefined;
    members_can_create_teams?: boolean | undefined;
    members_can_view_dependency_insights?: boolean | undefined;
    members_can_fork_private_repositories?: boolean | null | undefined;
    web_commit_signoff_required?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether GitHub Advanced Security is enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    advanced_security_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot alerts are automatically enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    dependabot_alerts_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot security updates are automatically enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    dependabot_security_updates_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether dependency graph is automatically enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    dependency_graph_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning is automatically enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    secret_scanning_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning push protection is automatically enabled for new repositories and repositories transferred to this organization. This field is only visible to organization owners or members of a team with the security manager role. */
    secret_scanning_push_protection_enabled_for_new_repositories?: boolean | undefined;
    /** Whether a custom link is shown to contributors who are blocked from pushing a secret by push protection. */
    secret_scanning_push_protection_custom_link_enabled?: boolean | undefined;
    /** An optional URL string to display to contributors who are blocked from pushing a secret. */
    secret_scanning_push_protection_custom_link?: string | null | undefined;
    created_at: string;
    updated_at: string;
    archived_at: string | null;
    /** Controls whether or not deploy keys may be added and used for repositories in the organization. */
    deploy_keys_enabled_for_repositories?: boolean | undefined;
}
export type GetApiInsightRouteStatsByActorRequestActorType = "installation" | "classic_pat" | "fine_grained_pat" | "oauth_app" | "github_app_user_to_server";
export type GetApiInsightRouteStatsByActorRequestDirection = "asc" | "desc";
export type GetApiInsightRouteStatsByActorRequestSortItem = "last_rate_limited_timestamp" | "last_request_timestamp" | "rate_limited_request_count" | "http_method" | "api_route" | "total_request_count";
export type GetApiInsightRouteStatsByActorRequestSortList = Array<GetApiInsightRouteStatsByActorRequestSortItem | (string & {})>;
export interface GetApiInsightRouteStatsByActorRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of the actor */
    actor_type: GetApiInsightRouteStatsByActorRequestActorType | (string & {});
    /** The ID of the actor */
    actor_id: number;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: GetApiInsightRouteStatsByActorRequestDirection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: GetApiInsightRouteStatsByActorRequestSortList | undefined;
    /** Providing a substring will filter results where the API route contains the substring. This is a case-insensitive search. */
    api_route_substring?: string | undefined;
}
export interface ApiInsightsRouteStatsItem {
    /** The HTTP method */
    http_method?: string | undefined;
    /** The API path's route template */
    api_route?: string | undefined;
    /** The total number of requests within the queried time period */
    total_request_count?: number | undefined;
    /** The total number of requests that were rate limited within the queried time period */
    rate_limited_request_count?: number | undefined;
    last_rate_limited_timestamp?: string | null | undefined;
    last_request_timestamp?: string | undefined;
}
/** API Insights usage route stats for an actor */
export type ApiInsightsRouteStats = Array<ApiInsightsRouteStatsItem>;
export type GetApiInsightRouteStatsByActorResponse = ApiInsightsRouteStats;
export type GetApiInsightSubjectStatsRequestDirection = "asc" | "desc";
export type GetApiInsightSubjectStatsRequestSortItem = "last_rate_limited_timestamp" | "last_request_timestamp" | "rate_limited_request_count" | "subject_name" | "total_request_count";
export type GetApiInsightSubjectStatsRequestSortList = Array<GetApiInsightSubjectStatsRequestSortItem | (string & {})>;
export interface GetApiInsightSubjectStatsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: GetApiInsightSubjectStatsRequestDirection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: GetApiInsightSubjectStatsRequestSortList | undefined;
    /** Providing a substring will filter results where the subject name contains the substring. This is a case-insensitive search. */
    subject_name_substring?: string | undefined;
}
export interface ApiInsightsSubjectStatsItem {
    subject_type?: string | undefined;
    subject_name?: string | undefined;
    subject_id?: number | undefined;
    total_request_count?: number | undefined;
    rate_limited_request_count?: number | undefined;
    last_rate_limited_timestamp?: string | null | undefined;
    last_request_timestamp?: string | undefined;
}
/** API Insights usage subject stats for an organization */
export type ApiInsightsSubjectStats = Array<ApiInsightsSubjectStatsItem>;
export type GetApiInsightSubjectStatsResponse = ApiInsightsSubjectStats;
export interface GetApiInsightSummaryStatsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
}
/** API Insights usage summary stats for an organization */
export interface ApiInsightsSummaryStats {
    /** The total number of requests within the queried time period */
    total_request_count?: number | undefined;
    /** The total number of requests that were rate limited within the queried time period */
    rate_limited_request_count?: number | undefined;
}
export type GetApiInsightSummaryStatsByActorRequestActorType = "installation" | "classic_pat" | "fine_grained_pat" | "oauth_app" | "github_app_user_to_server";
export interface GetApiInsightSummaryStatsByActorRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of the actor */
    actor_type: GetApiInsightSummaryStatsByActorRequestActorType | (string & {});
    /** The ID of the actor */
    actor_id: number;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
}
export interface GetApiInsightSummaryStatsByUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the user to query for stats */
    user_id: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
}
export interface GetApiInsightTimeStatsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The increment of time used to breakdown the query results (5m, 10m, 1h, etc.) */
    timestamp_increment: string;
}
export interface ApiInsightsTimeStatsItem {
    timestamp?: string | undefined;
    total_request_count?: number | undefined;
    rate_limited_request_count?: number | undefined;
}
/** API Insights usage time stats for an organization */
export type ApiInsightsTimeStats = Array<ApiInsightsTimeStatsItem>;
export type GetApiInsightTimeStatsResponse = ApiInsightsTimeStats;
export type GetApiInsightTimeStatsByActorRequestActorType = "installation" | "classic_pat" | "fine_grained_pat" | "oauth_app" | "github_app_user_to_server";
export interface GetApiInsightTimeStatsByActorRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of the actor */
    actor_type: GetApiInsightTimeStatsByActorRequestActorType | (string & {});
    /** The ID of the actor */
    actor_id: number;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The increment of time used to breakdown the query results (5m, 10m, 1h, etc.) */
    timestamp_increment: string;
}
export type GetApiInsightTimeStatsByActorResponse = ApiInsightsTimeStats;
export interface GetApiInsightTimeStatsByUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the user to query for stats */
    user_id: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The increment of time used to breakdown the query results (5m, 10m, 1h, etc.) */
    timestamp_increment: string;
}
export type GetApiInsightTimeStatsByUserResponse = ApiInsightsTimeStats;
export type GetApiInsightUserStatsRequestDirection = "asc" | "desc";
export type GetApiInsightUserStatsRequestSortItem = "last_rate_limited_timestamp" | "last_request_timestamp" | "rate_limited_request_count" | "subject_name" | "total_request_count";
export type GetApiInsightUserStatsRequestSortList = Array<GetApiInsightUserStatsRequestSortItem | (string & {})>;
export interface GetApiInsightUserStatsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the user to query for stats */
    user_id: string;
    /** The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    min_timestamp: string;
    /** The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    max_timestamp?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: GetApiInsightUserStatsRequestDirection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: GetApiInsightUserStatsRequestSortList | undefined;
    /** Providing a substring will filter results where the actor name contains the substring. This is a case-insensitive search. */
    actor_name_substring?: string | undefined;
}
export interface ApiInsightsUserStatsItem {
    actor_type?: string | undefined;
    actor_name?: string | undefined;
    actor_id?: number | undefined;
    integration_id?: number | null | undefined;
    oauth_application_id?: number | null | undefined;
    total_request_count?: number | undefined;
    rate_limited_request_count?: number | undefined;
    last_rate_limited_timestamp?: string | null | undefined;
    last_request_timestamp?: string | undefined;
}
/** API Insights usage stats for a user */
export type ApiInsightsUserStats = Array<ApiInsightsUserStatsItem>;
export type GetApiInsightUserStatsResponse = ApiInsightsUserStats;
export interface GetClusterDeploymentRecordsJobRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The cluster name. */
    cluster: string;
    /** The ID of the job. */
    job_id: number;
}
/** The current status of the job. */
export type GetClusterDeploymentRecordsJobResponseStatus = "pending" | "processing" | "completed" | "failed";
/** Processing errors (only present when completed or failed). */
export type GetClusterDeploymentRecordsJobResponseErrorsList = Array<unknown>;
export interface GetClusterDeploymentRecordsJobResponse {
    /** The ID of the job. */
    job_id: number;
    /** The current status of the job. */
    status: GetClusterDeploymentRecordsJobResponseStatus;
    /** When the job started processing (only present when processing, completed, or failed). */
    started_at?: string | undefined;
    /** The number of records successfully mutated (only present when completed). */
    total_count?: number | undefined;
    /** Processing errors (only present when completed or failed). */
    errors?: GetClusterDeploymentRecordsJobResponseErrorsList | undefined;
}
export interface GetImmutableReleasesSettingsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy that controls how immutable releases are enforced in the organization. */
export type ImmutableReleasesOrganizationSettingsEnforcedRepositories = "all" | "none" | "selected";
/** Check immutable releases settings for an organization. */
export interface ImmutableReleasesOrganizationSettings {
    /** The policy that controls how immutable releases are enforced in the organization. */
    enforced_repositories: ImmutableReleasesOrganizationSettingsEnforcedRepositories;
    /** The API URL to use to get or set the selected repositories for immutable releases enforcement, when `enforced_repositories` is set to `selected`. */
    selected_repositories_url?: string | undefined;
}
export interface GetImmutableReleasesSettingsRepositoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type GetImmutableReleasesSettingsRepositoriesResponseRepositoriesList = Array<MinimalRepository>;
export interface GetImmutableReleasesSettingsRepositoriesResponse {
    total_count: number;
    repositories: GetImmutableReleasesSettingsRepositoriesResponseRepositoriesList;
}
export interface GetMembershipForAuthenticatedUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The state of the member in the organization. The `pending` state indicates the user has not yet accepted an invitation. */
export type OrgMembershipState = "active" | "pending";
/** The user's membership type in the organization. */
export type OrgMembershipRole = "admin" | "member" | "billing_manager";
/** The slugs of the enterprise teams providing the user with indirect membership in the organization. A limit of 100 enterprise team slugs is returned. */
export type OrgMembershipEnterpriseTeamsProvidingIndirectMembershipList = Array<string>;
/** A GitHub organization. */
export interface OrganizationSimple {
    login: string;
    id: number;
    node_id: string;
    url: string;
    repos_url: string;
    events_url: string;
    hooks_url: string;
    issues_url: string;
    members_url: string;
    public_members_url: string;
    avatar_url: string;
    description: string | null;
}
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
export interface OrgMembershipPermissions {
    can_create_repository: boolean;
}
/** Org Membership */
export interface OrgMembership {
    url: string;
    /** The state of the member in the organization. The `pending` state indicates the user has not yet accepted an invitation. */
    state: OrgMembershipState;
    /** The user's membership type in the organization. */
    role: OrgMembershipRole;
    /** Whether the user has direct membership in the organization. */
    direct_membership?: boolean | undefined;
    /** The slugs of the enterprise teams providing the user with indirect membership in the organization. A limit of 100 enterprise team slugs is returned. */
    enterprise_teams_providing_indirect_membership?: OrgMembershipEnterpriseTeamsProvidingIndirectMembershipList | undefined;
    organization_url: string;
    organization: OrganizationSimple;
    user: SimpleUser | null;
    permissions?: OrgMembershipPermissions | undefined;
}
export interface GetMembershipForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface GetOrgRoleRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the role. */
    role_id: number;
}
/** The system role from which this role inherits permissions. */
export type OrganizationRoleBaseRole = "read" | "triage" | "write" | "maintain" | "admin";
/** Source answers the question, "where did this role come from?" */
export type OrganizationRoleSource = "Organization" | "Enterprise" | "Predefined";
/** A list of permissions included in this role. */
export type OrganizationRolePermissionsList = Array<string>;
/** Organization roles */
export interface OrganizationRole {
    /** The unique identifier of the role. */
    id: number;
    /** The name of the role. */
    name: string;
    /** A short description about who this role is for or what permissions it grants. */
    description?: string | null | undefined;
    /** The system role from which this role inherits permissions. */
    base_role?: OrganizationRoleBaseRole | null | undefined;
    /** Source answers the question, "where did this role come from?" */
    source?: OrganizationRoleSource | null | undefined;
    /** A list of permissions included in this role. */
    permissions: OrganizationRolePermissionsList;
    organization: SimpleUser | null;
    /** The date and time the role was created. */
    created_at: string;
    /** The date and time the role was last updated. */
    updated_at: string;
}
export interface GetOrgRulesetHistoryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The actor who updated the ruleset */
export interface RulesetVersionActor {
    id?: number | undefined;
    type?: string | undefined;
}
/** The historical version of a ruleset */
export interface RulesetVersion {
    /** The ID of the previous version of the ruleset */
    version_id: number;
    /** The actor who updated the ruleset */
    actor: RulesetVersionActor;
    updated_at: string;
}
export type GetOrgRulesetHistoryResponseBodyList = Array<RulesetVersion>;
export type GetOrgRulesetHistoryResponse = GetOrgRulesetHistoryResponseBodyList;
export interface GetOrgRulesetVersionRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The ID of the version */
    version_id: number;
}
/** The actor who updated the ruleset */
export type GetOrgRulesetVersionResponseActor = RulesetVersionActor;
export interface GetOrgRulesetVersionResponse {
    /** The ID of the previous version of the ruleset */
    version_id: number;
    /** The actor who updated the ruleset */
    actor: RulesetVersionActor;
    updated_at: string;
    /** The state of the ruleset version */
    state: unknown;
}
export interface GetWebhookRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface GetWebhookConfigForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
/** Configuration object of the webhook */
export interface WebhookConfig {
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export interface GetWebhookDeliveryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    delivery_id: number;
}
/** The request headers sent with the webhook delivery. */
export type HookDeliveryRequestHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The webhook payload. */
export type HookDeliveryRequestPayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryRequest {
    /** The request headers sent with the webhook delivery. */
    headers: HookDeliveryRequestHeadersMap | null;
    /** The webhook payload. */
    payload: HookDeliveryRequestPayloadMap | null;
}
/** The response headers received when the delivery was made. */
export type HookDeliveryResponseHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The response payload received. */
export type HookDeliveryResponsePayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryResponse {
    /** The response headers received when the delivery was made. */
    headers: HookDeliveryResponseHeadersMap | null;
    /** The response payload received. */
    payload: HookDeliveryResponsePayloadMap | null;
}
/** Delivery made by a webhook. */
export interface HookDelivery {
    /** Unique identifier of the delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the delivery was delivered. */
    delivered_at: string;
    /** Whether the delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Description of the status of the attempted delivery */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
    /** The URL target of the delivery. */
    url?: string | undefined;
    request: HookDeliveryRequest;
    response: HookDeliveryResponse;
}
export interface ListRequest {
    /** An organization ID. Only return organizations with an ID greater than this ID. */
    since?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListResponseBodyList = Array<OrganizationSimple>;
export type ListResponse = ListResponseBodyList;
export interface ListAppInstallationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type InstallationAccount = SimpleUser | Enterprise;
/** Describe whether all repositories have been selected or there's a selection involved */
export type InstallationRepositorySelection = "all" | "selected";
/** The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. */
export type AppPermissionsActions = "read" | "write";
/** The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. */
export type AppPermissionsAdministration = "read" | "write";
/** The level of permission to grant the access token to create and retrieve build artifact metadata records. */
export type AppPermissionsArtifactMetadata = "read" | "write";
/** The level of permission to create and retrieve the access token for repository attestations. */
export type AppPermissionsAttestations = "read" | "write";
/** The level of permission to grant the access token for checks on code. */
export type AppPermissionsChecks = "read" | "write";
/** The level of permission to grant the access token to view and manage code quality data. */
export type AppPermissionsCodeQuality = "read" | "write";
/** The level of permission to grant the access token to create, edit, delete, and list Codespaces. */
export type AppPermissionsCodespaces = "read" | "write";
/** The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. */
export type AppPermissionsContents = "read" | "write";
/** The level of permission to grant the access token to manage Dependabot secrets. */
export type AppPermissionsDependabotSecrets = "read" | "write";
/** The level of permission to grant the access token for deployments and deployment statuses. */
export type AppPermissionsDeployments = "read" | "write";
/** The level of permission to grant the access token for discussions and related comments and labels. */
export type AppPermissionsDiscussions = "read" | "write";
/** The level of permission to grant the access token for managing repository environments. */
export type AppPermissionsEnvironments = "read" | "write";
/** The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. */
export type AppPermissionsIssues = "read" | "write";
/** The level of permission to grant the access token to manage the merge queues for a repository. */
export type AppPermissionsMergeQueues = "read" | "write";
/** The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. */
export type AppPermissionsMetadata = "read" | "write";
/** The level of permission to grant the access token for packages published to GitHub Packages. */
export type AppPermissionsPackages = "read" | "write";
/** The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. */
export type AppPermissionsPages = "read" | "write";
/** The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. */
export type AppPermissionsPullRequests = "read" | "write";
/** The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. */
export type AppPermissionsRepositoryCustomProperties = "read" | "write";
/** The level of permission to grant the access token to manage the post-receive hooks for a repository. */
export type AppPermissionsRepositoryHooks = "read" | "write";
/** The level of permission to grant the access token to manage repository projects, columns, and cards. */
export type AppPermissionsRepositoryProjects = "read" | "write" | "admin";
/** The level of permission to grant the access token to view and manage secret scanning alerts. */
export type AppPermissionsSecretScanningAlerts = "read" | "write";
/** The level of permission to grant the access token to manage repository secrets. */
export type AppPermissionsSecrets = "read" | "write";
/** The level of permission to grant the access token to view and manage security events like code scanning alerts. */
export type AppPermissionsSecurityEvents = "read" | "write";
/** The level of permission to grant the access token to manage just a single file. */
export type AppPermissionsSingleFile = "read" | "write";
/** The level of permission to grant the access token for commit statuses. */
export type AppPermissionsStatuses = "read" | "write";
/** The level of permission to grant the access token to manage Dependabot alerts. */
export type AppPermissionsVulnerabilityAlerts = "read" | "write";
/** The level of permission to grant the access token to update GitHub Actions workflow files. */
export type AppPermissionsWorkflows = "write";
/** The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. */
export type AppPermissionsCustomPropertiesForOrganizations = "read" | "write";
/** The level of permission to grant the access token for organization teams and members. */
export type AppPermissionsMembers = "read" | "write";
/** The level of permission to grant the access token to manage access to an organization. */
export type AppPermissionsOrganizationAdministration = "read" | "write";
/** The level of permission to grant the access token for custom repository roles management. */
export type AppPermissionsOrganizationCustomRoles = "read" | "write";
/** The level of permission to grant the access token for custom organization roles management. */
export type AppPermissionsOrganizationCustomOrgRoles = "read" | "write";
/** The level of permission to grant the access token for repository custom properties management at the organization level. */
export type AppPermissionsOrganizationCustomProperties = "read" | "write" | "admin";
/** The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. */
export type AppPermissionsOrganizationCopilotSeatManagement = "read" | "write";
/** The level of permission to grant the access token to view and manage Copilot cloud agent settings for an organization. */
export type AppPermissionsOrganizationCopilotAgentSettings = "read" | "write";
/** The level of permission to grant the access token to make Copilot requests billed to the organization where the app is installed. This property is in public preview and is subject to change. */
export type AppPermissionsOrganizationCopilotRequests = "read";
/** The level of permission to grant the access token for managing external custom properties for repositories in an organization. */
export type AppPermissionsOrganizationExternalPropertiesForRepos = "read" | "write" | "admin";
/** The level of permission to grant the access token to view and manage announcement banners for an organization. */
export type AppPermissionsOrganizationAnnouncementBanners = "read" | "write";
/** The level of permission to grant the access token to view events triggered by an activity in an organization. */
export type AppPermissionsOrganizationEvents = "read";
/** The level of permission to grant the access token to manage the post-receive hooks for an organization. */
export type AppPermissionsOrganizationHooks = "read" | "write";
/** The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. */
export type AppPermissionsOrganizationPersonalAccessTokens = "read" | "write";
/** The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. */
export type AppPermissionsOrganizationPersonalAccessTokenRequests = "read" | "write";
/** The level of permission to grant the access token for viewing an organization's plan. */
export type AppPermissionsOrganizationPlan = "read";
/** The level of permission to grant the access token to manage organization projects and projects public preview (where available). */
export type AppPermissionsOrganizationProjects = "read" | "write" | "admin";
/** The level of permission to grant the access token for organization packages published to GitHub Packages. */
export type AppPermissionsOrganizationPackages = "read" | "write";
/** The level of permission to grant the access token to manage organization secrets. */
export type AppPermissionsOrganizationSecrets = "read" | "write";
/** The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. */
export type AppPermissionsOrganizationSelfHostedRunners = "read" | "write";
/** The level of permission to grant the access token to view and manage users blocked by the organization. */
export type AppPermissionsOrganizationUserBlocking = "read" | "write";
/** The level of permission to grant the access token to manage the email addresses belonging to a user. */
export type AppPermissionsEmailAddresses = "read" | "write";
/** The level of permission to grant the access token to manage the followers belonging to a user. */
export type AppPermissionsFollowers = "read" | "write";
/** The level of permission to grant the access token to manage git SSH keys. */
export type AppPermissionsGitSshKeys = "read" | "write";
/** The level of permission to grant the access token to view and manage GPG keys belonging to a user. */
export type AppPermissionsGpgKeys = "read" | "write";
/** The level of permission to grant the access token to view and manage interaction limits on a repository. */
export type AppPermissionsInteractionLimits = "read" | "write";
/** The level of permission to grant the access token to manage the profile settings belonging to a user. */
export type AppPermissionsProfile = "write";
/** The level of permission to grant the access token to list and manage repositories a user is starring. */
export type AppPermissionsStarring = "read" | "write";
/** The level of permission to grant the access token for organization custom properties management at the enterprise level. */
export type AppPermissionsEnterpriseCustomPropertiesForOrganizations = "read" | "write" | "admin";
/** The permissions granted to the fine-grained access token. */
export interface AppPermissions {
    /** The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. */
    actions?: AppPermissionsActions | undefined;
    /** The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. */
    administration?: AppPermissionsAdministration | undefined;
    /** The level of permission to grant the access token to create and retrieve build artifact metadata records. */
    artifact_metadata?: AppPermissionsArtifactMetadata | undefined;
    /** The level of permission to create and retrieve the access token for repository attestations. */
    attestations?: AppPermissionsAttestations | undefined;
    /** The level of permission to grant the access token for checks on code. */
    checks?: AppPermissionsChecks | undefined;
    /** The level of permission to grant the access token to view and manage code quality data. */
    code_quality?: AppPermissionsCodeQuality | undefined;
    /** The level of permission to grant the access token to create, edit, delete, and list Codespaces. */
    codespaces?: AppPermissionsCodespaces | undefined;
    /** The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. */
    contents?: AppPermissionsContents | undefined;
    /** The level of permission to grant the access token to manage Dependabot secrets. */
    dependabot_secrets?: AppPermissionsDependabotSecrets | undefined;
    /** The level of permission to grant the access token for deployments and deployment statuses. */
    deployments?: AppPermissionsDeployments | undefined;
    /** The level of permission to grant the access token for discussions and related comments and labels. */
    discussions?: AppPermissionsDiscussions | undefined;
    /** The level of permission to grant the access token for managing repository environments. */
    environments?: AppPermissionsEnvironments | undefined;
    /** The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. */
    issues?: AppPermissionsIssues | undefined;
    /** The level of permission to grant the access token to manage the merge queues for a repository. */
    merge_queues?: AppPermissionsMergeQueues | undefined;
    /** The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. */
    metadata?: AppPermissionsMetadata | undefined;
    /** The level of permission to grant the access token for packages published to GitHub Packages. */
    packages?: AppPermissionsPackages | undefined;
    /** The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. */
    pages?: AppPermissionsPages | undefined;
    /** The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. */
    pull_requests?: AppPermissionsPullRequests | undefined;
    /** The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. */
    repository_custom_properties?: AppPermissionsRepositoryCustomProperties | undefined;
    /** The level of permission to grant the access token to manage the post-receive hooks for a repository. */
    repository_hooks?: AppPermissionsRepositoryHooks | undefined;
    /** The level of permission to grant the access token to manage repository projects, columns, and cards. */
    repository_projects?: AppPermissionsRepositoryProjects | undefined;
    /** The level of permission to grant the access token to view and manage secret scanning alerts. */
    secret_scanning_alerts?: AppPermissionsSecretScanningAlerts | undefined;
    /** The level of permission to grant the access token to manage repository secrets. */
    secrets?: AppPermissionsSecrets | undefined;
    /** The level of permission to grant the access token to view and manage security events like code scanning alerts. */
    security_events?: AppPermissionsSecurityEvents | undefined;
    /** The level of permission to grant the access token to manage just a single file. */
    single_file?: AppPermissionsSingleFile | undefined;
    /** The level of permission to grant the access token for commit statuses. */
    statuses?: AppPermissionsStatuses | undefined;
    /** The level of permission to grant the access token to manage Dependabot alerts. */
    vulnerability_alerts?: AppPermissionsVulnerabilityAlerts | undefined;
    /** The level of permission to grant the access token to update GitHub Actions workflow files. */
    workflows?: AppPermissionsWorkflows | undefined;
    /** The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. */
    custom_properties_for_organizations?: AppPermissionsCustomPropertiesForOrganizations | undefined;
    /** The level of permission to grant the access token for organization teams and members. */
    members?: AppPermissionsMembers | undefined;
    /** The level of permission to grant the access token to manage access to an organization. */
    organization_administration?: AppPermissionsOrganizationAdministration | undefined;
    /** The level of permission to grant the access token for custom repository roles management. */
    organization_custom_roles?: AppPermissionsOrganizationCustomRoles | undefined;
    /** The level of permission to grant the access token for custom organization roles management. */
    organization_custom_org_roles?: AppPermissionsOrganizationCustomOrgRoles | undefined;
    /** The level of permission to grant the access token for repository custom properties management at the organization level. */
    organization_custom_properties?: AppPermissionsOrganizationCustomProperties | undefined;
    /** The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. */
    organization_copilot_seat_management?: AppPermissionsOrganizationCopilotSeatManagement | undefined;
    /** The level of permission to grant the access token to view and manage Copilot cloud agent settings for an organization. */
    organization_copilot_agent_settings?: AppPermissionsOrganizationCopilotAgentSettings | undefined;
    /** The level of permission to grant the access token to make Copilot requests billed to the organization where the app is installed. This property is in public preview and is subject to change. */
    organization_copilot_requests?: AppPermissionsOrganizationCopilotRequests | undefined;
    /** The level of permission to grant the access token for managing external custom properties for repositories in an organization. */
    organization_external_properties_for_repos?: AppPermissionsOrganizationExternalPropertiesForRepos | undefined;
    /** The level of permission to grant the access token to view and manage announcement banners for an organization. */
    organization_announcement_banners?: AppPermissionsOrganizationAnnouncementBanners | undefined;
    /** The level of permission to grant the access token to view events triggered by an activity in an organization. */
    organization_events?: AppPermissionsOrganizationEvents | undefined;
    /** The level of permission to grant the access token to manage the post-receive hooks for an organization. */
    organization_hooks?: AppPermissionsOrganizationHooks | undefined;
    /** The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. */
    organization_personal_access_tokens?: AppPermissionsOrganizationPersonalAccessTokens | undefined;
    /** The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. */
    organization_personal_access_token_requests?: AppPermissionsOrganizationPersonalAccessTokenRequests | undefined;
    /** The level of permission to grant the access token for viewing an organization's plan. */
    organization_plan?: AppPermissionsOrganizationPlan | undefined;
    /** The level of permission to grant the access token to manage organization projects and projects public preview (where available). */
    organization_projects?: AppPermissionsOrganizationProjects | undefined;
    /** The level of permission to grant the access token for organization packages published to GitHub Packages. */
    organization_packages?: AppPermissionsOrganizationPackages | undefined;
    /** The level of permission to grant the access token to manage organization secrets. */
    organization_secrets?: AppPermissionsOrganizationSecrets | undefined;
    /** The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. */
    organization_self_hosted_runners?: AppPermissionsOrganizationSelfHostedRunners | undefined;
    /** The level of permission to grant the access token to view and manage users blocked by the organization. */
    organization_user_blocking?: AppPermissionsOrganizationUserBlocking | undefined;
    /** The level of permission to grant the access token to manage the email addresses belonging to a user. */
    email_addresses?: AppPermissionsEmailAddresses | undefined;
    /** The level of permission to grant the access token to manage the followers belonging to a user. */
    followers?: AppPermissionsFollowers | undefined;
    /** The level of permission to grant the access token to manage git SSH keys. */
    git_ssh_keys?: AppPermissionsGitSshKeys | undefined;
    /** The level of permission to grant the access token to view and manage GPG keys belonging to a user. */
    gpg_keys?: AppPermissionsGpgKeys | undefined;
    /** The level of permission to grant the access token to view and manage interaction limits on a repository. */
    interaction_limits?: AppPermissionsInteractionLimits | undefined;
    /** The level of permission to grant the access token to manage the profile settings belonging to a user. */
    profile?: AppPermissionsProfile | undefined;
    /** The level of permission to grant the access token to list and manage repositories a user is starring. */
    starring?: AppPermissionsStarring | undefined;
    /** The level of permission to grant the access token for organization custom properties management at the enterprise level. */
    enterprise_custom_properties_for_organizations?: AppPermissionsEnterpriseCustomPropertiesForOrganizations | undefined;
}
export type InstallationEventsList = Array<string>;
export type InstallationSingleFilePathsList = Array<string>;
/** Installation */
export interface Installation {
    /** The ID of the installation. */
    id: number;
    account: InstallationAccount | null;
    /** Describe whether all repositories have been selected or there's a selection involved */
    repository_selection: InstallationRepositorySelection;
    access_tokens_url: string;
    repositories_url: string;
    html_url: string;
    app_id: number;
    client_id?: string | undefined;
    /** The ID of the user or organization this token is being scoped to. */
    target_id: number;
    target_type: string;
    permissions: AppPermissions;
    events: InstallationEventsList;
    created_at: string;
    updated_at: string;
    single_file_name: string | null;
    has_multiple_single_files?: boolean | undefined;
    single_file_paths?: InstallationSingleFilePathsList | undefined;
    app_slug: string;
    suspended_by: SimpleUser | null;
    suspended_at: string | null;
    contact_email?: string | null | undefined;
}
export type ListAppInstallationsResponseInstallationsList = Array<Installation>;
export interface ListAppInstallationsResponse {
    total_count: number;
    installations: ListAppInstallationsResponseInstallationsList;
}
export interface ListArtifactDeploymentRecordsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The SHA256 digest of the artifact, in the form `sha256:HEX_DIGEST`. */
    subject_digest: string;
}
export type ListArtifactDeploymentRecordsResponseDeploymentRecordsList = Array<ArtifactDeploymentRecord>;
export interface ListArtifactDeploymentRecordsResponse {
    /** The number of deployment records for this digest and organization */
    total_count?: number | undefined;
    deployment_records?: ListArtifactDeploymentRecordsResponseDeploymentRecordsList | undefined;
}
export interface ListArtifactStorageRecordsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`. */
    subject_digest: string;
}
export interface ListArtifactStorageRecordsResponseStorageRecordsItem {
    id?: number | undefined;
    name?: string | undefined;
    digest?: string | undefined;
    artifact_url?: string | undefined;
    registry_url?: string | undefined;
    repository?: string | undefined;
    status?: string | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
export type ListArtifactStorageRecordsResponseStorageRecordsList = Array<ListArtifactStorageRecordsResponseStorageRecordsItem>;
export interface ListArtifactStorageRecordsResponse {
    /** The number of storage records for this digest and organization */
    total_count?: number | undefined;
    storage_records?: ListArtifactStorageRecordsResponseStorageRecordsList | undefined;
}
export interface ListAttestationRepositoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export interface ListAttestationRepositoriesResponseBodyItem {
    id?: number | undefined;
    name?: string | undefined;
}
export type ListAttestationRepositoriesResponseBodyList = Array<ListAttestationRepositoriesResponseBodyItem>;
export type ListAttestationRepositoriesResponse = ListAttestationRepositoriesResponseBodyList;
export interface ListAttestationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`. */
    subject_digest: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export type ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
export interface ListAttestationsResponseAttestationsItemBundle {
    mediaType?: string | undefined;
    verificationMaterial?: ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap | undefined;
}
export interface ListAttestationsResponseAttestationsItem {
    /** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
    bundle?: ListAttestationsResponseAttestationsItemBundle | null | undefined;
    repository_id?: number | undefined;
    bundle_url?: string | undefined;
    initiator?: string | undefined;
}
export type ListAttestationsResponseAttestationsList = Array<ListAttestationsResponseAttestationsItem>;
export interface ListAttestationsResponse {
    attestations?: ListAttestationsResponseAttestationsList | undefined;
}
/** List of subject digests to fetch attestations for. */
export type ListAttestationsBulkRequestSubjectDigestsList = Array<string>;
export interface ListAttestationsBulkRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** List of subject digests to fetch attestations for. */
    subject_digests: ListAttestationsBulkRequestSubjectDigestsList;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The bundle of the attestation. */
export interface ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundle {
    mediaType?: string | undefined;
    verificationMaterial?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundleDsseEnvelopeMap | undefined;
}
export interface ListAttestationsBulkResponseAttestationsSubjectDigestsValueItem {
    /** The bundle of the attestation. */
    bundle?: ListAttestationsBulkResponseAttestationsSubjectDigestsValueItemBundle | undefined;
    repository_id?: number | undefined;
    bundle_url?: string | undefined;
}
export type ListAttestationsBulkResponseAttestationsSubjectDigestsValueList = Array<ListAttestationsBulkResponseAttestationsSubjectDigestsValueItem>;
/** Mapping of subject digest to bundles. */
export type ListAttestationsBulkResponseAttestationsSubjectDigestsMap = {
    [key: string]: ListAttestationsBulkResponseAttestationsSubjectDigestsValueList | null | undefined;
};
/** Information about the current page. */
export interface ListAttestationsBulkResponsePageInfo {
    /** Indicates whether there is a next page. */
    has_next?: boolean | undefined;
    /** Indicates whether there is a previous page. */
    has_previous?: boolean | undefined;
    /** The cursor to the next page. */
    next?: string | undefined;
    /** The cursor to the previous page. */
    previous?: string | undefined;
}
export interface ListAttestationsBulkResponse {
    /** Mapping of subject digest to bundles. */
    attestations_subject_digests?: ListAttestationsBulkResponseAttestationsSubjectDigestsMap | undefined;
    /** Information about the current page. */
    page_info?: ListAttestationsBulkResponsePageInfo | undefined;
}
export interface ListBlockedUsersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListBlockedUsersResponseBodyList = Array<SimpleUser>;
export type ListBlockedUsersResponse = ListBlockedUsersResponseBodyList;
export interface ListFailedInvitationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListFailedInvitationsResponseBodyList = Array<OrganizationInvitation>;
export type ListFailedInvitationsResponse = ListFailedInvitationsResponseBodyList;
export interface ListForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForAuthenticatedUserResponseBodyList = Array<OrganizationSimple>;
export type ListForAuthenticatedUserResponse = ListForAuthenticatedUserResponseBodyList;
export interface ListForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForUserResponseBodyList = Array<OrganizationSimple>;
export type ListForUserResponse = ListForUserResponseBodyList;
export interface ListInvitationTeamsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the invitation. */
    invitation_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type ListInvitationTeamsResponseBodyList = Array<Team>;
export type ListInvitationTeamsResponse = ListInvitationTeamsResponseBodyList;
export interface ListIssueFieldsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type ListIssueFieldsResponseBodyList = Array<IssueField | null>;
export type ListIssueFieldsResponse = ListIssueFieldsResponseBodyList;
export interface ListIssueTypesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type ListIssueTypesResponseBodyList = Array<IssueType | null>;
export type ListIssueTypesResponse = ListIssueTypesResponseBodyList;
export type ListMembersRequestFilter = "2fa_disabled" | "2fa_insecure" | "all";
export type ListMembersRequestRole = "all" | "admin" | "member";
export interface ListMembersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Filter members returned in the list. `2fa_disabled` means that only members without [two-factor authentication](https://github.com/blog/1614-two-factor-authentication) enabled will be returned. `2fa_insecure` means that only members with [insecure 2FA methods](https://docs.github.com/organizations/keeping-your-organization-secure/managing-two-factor-authentication-for-your-organization/requiring-two-factor-authentication-in-your-organization#requiring-secure-methods-of-two-factor-authentication-in-your-organization) will be returned. These options are only available for organization owners. */
    filter?: ListMembersRequestFilter | (string & {}) | undefined;
    /** Filter members returned by their role. */
    role?: ListMembersRequestRole | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListMembersResponseBodyList = Array<SimpleUser>;
export type ListMembersResponse = ListMembersResponseBodyList;
export type ListMembershipsForAuthenticatedUserRequestState = "active" | "pending";
export interface ListMembershipsForAuthenticatedUserRequest {
    /** Indicates the state of the memberships to return. If not specified, the API returns both active and pending memberships. */
    state?: ListMembershipsForAuthenticatedUserRequestState | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListMembershipsForAuthenticatedUserResponseBodyList = Array<OrgMembership>;
export type ListMembershipsForAuthenticatedUserResponse = ListMembershipsForAuthenticatedUserResponseBodyList;
export interface ListOrgRolesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The list of organization roles available to the organization. */
export type ListOrgRolesResponseRolesList = Array<OrganizationRole>;
export interface ListOrgRolesResponse {
    /** The total number of organization roles available to the organization. */
    total_count?: number | undefined;
    /** The list of organization roles available to the organization. */
    roles?: ListOrgRolesResponseRolesList | undefined;
}
export interface ListOrgRoleTeamsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the role. */
    role_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Determines if the team has a direct, indirect, or mixed relationship to a role */
export type TeamRoleAssignmentAssignment = "direct" | "indirect" | "mixed";
export type TeamRoleAssignmentPermissions = TeamPermissions;
/** The ownership type of the team */
export type TeamRoleAssignmentType = "enterprise" | "organization";
/** The Relationship a Team has with a role. */
export interface TeamRoleAssignment {
    /** Determines if the team has a direct, indirect, or mixed relationship to a role */
    assignment?: TeamRoleAssignmentAssignment | undefined;
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    parent: NullableTeamSimple | null;
    /** The ownership type of the team */
    type: TeamRoleAssignmentType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** List of teams assigned to the organization role */
export type ListOrgRoleTeamsResponseBodyList = Array<TeamRoleAssignment>;
export type ListOrgRoleTeamsResponse = ListOrgRoleTeamsResponseBodyList;
export interface ListOrgRoleUsersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the role. */
    role_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Determines if the user has a direct, indirect, or mixed relationship to a role */
export type UserRoleAssignmentAssignment = "direct" | "indirect" | "mixed";
/** The ownership type of the team */
export type TeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface TeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: TeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Team the user has gotten the role through */
export type UserRoleAssignmentInheritedFromList = Array<TeamSimple>;
/** The Relationship a User has with a role. */
export interface UserRoleAssignment {
    /** Determines if the user has a direct, indirect, or mixed relationship to a role */
    assignment?: UserRoleAssignmentAssignment | undefined;
    /** Team the user has gotten the role through */
    inherited_from?: UserRoleAssignmentInheritedFromList | undefined;
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** List of users assigned to the organization role */
export type ListOrgRoleUsersResponseBodyList = Array<UserRoleAssignment>;
export type ListOrgRoleUsersResponse = ListOrgRoleUsersResponseBodyList;
export type ListOutsideCollaboratorsRequestFilter = "2fa_disabled" | "2fa_insecure" | "all";
export interface ListOutsideCollaboratorsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Filter the list of outside collaborators. `2fa_disabled` means that only outside collaborators without [two-factor authentication](https://github.com/blog/1614-two-factor-authentication) enabled will be returned. `2fa_insecure` means that only outside collaborators with [insecure 2FA methods](https://docs.github.com/organizations/keeping-your-organization-secure/managing-two-factor-authentication-for-your-organization/requiring-two-factor-authentication-in-your-organization#requiring-secure-methods-of-two-factor-authentication-in-your-organization) will be returned. */
    filter?: ListOutsideCollaboratorsRequestFilter | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOutsideCollaboratorsResponseBodyList = Array<SimpleUser>;
export type ListOutsideCollaboratorsResponse = ListOutsideCollaboratorsResponseBodyList;
export interface ListPatGrantRepositoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the fine-grained personal access token. */
    pat_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPatGrantRepositoriesResponseBodyList = Array<MinimalRepository>;
export type ListPatGrantRepositoriesResponse = ListPatGrantRepositoriesResponseBodyList;
export interface ListPatGrantRequestRepositoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the request for access via fine-grained personal access token. */
    pat_request_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPatGrantRequestRepositoriesResponseBodyList = Array<MinimalRepository>;
export type ListPatGrantRequestRepositoriesResponse = ListPatGrantRequestRepositoriesResponseBodyList;
export type ListPatGrantRequestsRequestSort = "created_at";
export type ListPatGrantRequestsRequestDirection = "asc" | "desc";
export type ListPatGrantRequestsRequestOwnerList = Array<string>;
export type ListPatGrantRequestsRequestTokenIdList = Array<string>;
export interface ListPatGrantRequestsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The property by which to sort the results. */
    sort?: ListPatGrantRequestsRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListPatGrantRequestsRequestDirection | (string & {}) | undefined;
    /** A list of owner usernames to use to filter the results. */
    owner?: ListPatGrantRequestsRequestOwnerList | undefined;
    /** The name of the repository to use to filter the results. */
    repository?: string | undefined;
    /** The permission to use to filter the results. */
    permission?: string | undefined;
    /** Only show fine-grained personal access tokens used before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    last_used_before?: string | undefined;
    /** Only show fine-grained personal access tokens used after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    last_used_after?: string | undefined;
    /** The ID of the token */
    token_id?: ListPatGrantRequestsRequestTokenIdList | undefined;
}
/** Type of repository selection requested. */
export type OrganizationProgrammaticAccessGrantRequestRepositorySelection = "none" | "all" | "subset";
export type OrganizationProgrammaticAccessGrantRequestPermissionsOrganizationMap = {
    [key: string]: string | undefined;
};
export type OrganizationProgrammaticAccessGrantRequestPermissionsRepositoryMap = {
    [key: string]: string | undefined;
};
export type OrganizationProgrammaticAccessGrantRequestPermissionsOtherMap = {
    [key: string]: string | undefined;
};
/** Permissions requested, categorized by type of permission. */
export interface OrganizationProgrammaticAccessGrantRequestPermissions {
    organization?: OrganizationProgrammaticAccessGrantRequestPermissionsOrganizationMap | undefined;
    repository?: OrganizationProgrammaticAccessGrantRequestPermissionsRepositoryMap | undefined;
    other?: OrganizationProgrammaticAccessGrantRequestPermissionsOtherMap | undefined;
}
/** Minimal representation of an organization programmatic access grant request for enumerations */
export interface OrganizationProgrammaticAccessGrantRequest {
    /** Unique identifier of the request for access via fine-grained personal access token. The `pat_request_id` used to review PAT requests. */
    id: number;
    /** Reason for requesting access. */
    reason: string | null;
    owner: SimpleUser;
    /** Type of repository selection requested. */
    repository_selection: OrganizationProgrammaticAccessGrantRequestRepositorySelection;
    /** URL to the list of repositories requested to be accessed via fine-grained personal access token. Should only be followed when `repository_selection` is `subset`. */
    repositories_url: string;
    /** Permissions requested, categorized by type of permission. */
    permissions: OrganizationProgrammaticAccessGrantRequestPermissions;
    /** Date and time when the request for access was created. */
    created_at: string;
    /** Unique identifier of the user's token. This field can also be found in audit log events and the organization's settings for their PAT grants. */
    token_id: number;
    /** The name given to the user's token. This field can also be found in an organization's settings page for Active Tokens. */
    token_name: string;
    /** Whether the associated fine-grained personal access token has expired. */
    token_expired: boolean;
    /** Date and time when the associated fine-grained personal access token expires. */
    token_expires_at: string | null;
    /** Date and time when the associated fine-grained personal access token was last used for authentication. */
    token_last_used_at: string | null;
}
export type ListPatGrantRequestsResponseBodyList = Array<OrganizationProgrammaticAccessGrantRequest>;
export type ListPatGrantRequestsResponse = ListPatGrantRequestsResponseBodyList;
export type ListPatGrantsRequestSort = "created_at";
export type ListPatGrantsRequestDirection = "asc" | "desc";
export type ListPatGrantsRequestOwnerList = Array<string>;
export type ListPatGrantsRequestTokenIdList = Array<string>;
export interface ListPatGrantsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The property by which to sort the results. */
    sort?: ListPatGrantsRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListPatGrantsRequestDirection | (string & {}) | undefined;
    /** A list of owner usernames to use to filter the results. */
    owner?: ListPatGrantsRequestOwnerList | undefined;
    /** The name of the repository to use to filter the results. */
    repository?: string | undefined;
    /** The permission to use to filter the results. */
    permission?: string | undefined;
    /** Only show fine-grained personal access tokens used before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    last_used_before?: string | undefined;
    /** Only show fine-grained personal access tokens used after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    last_used_after?: string | undefined;
    /** The ID of the token */
    token_id?: ListPatGrantsRequestTokenIdList | undefined;
}
/** Type of repository selection requested. */
export type OrganizationProgrammaticAccessGrantRepositorySelection = "none" | "all" | "subset";
export type OrganizationProgrammaticAccessGrantPermissionsOrganizationMap = {
    [key: string]: string | undefined;
};
export type OrganizationProgrammaticAccessGrantPermissionsRepositoryMap = {
    [key: string]: string | undefined;
};
export type OrganizationProgrammaticAccessGrantPermissionsOtherMap = {
    [key: string]: string | undefined;
};
/** Permissions requested, categorized by type of permission. */
export interface OrganizationProgrammaticAccessGrantPermissions {
    organization?: OrganizationProgrammaticAccessGrantPermissionsOrganizationMap | undefined;
    repository?: OrganizationProgrammaticAccessGrantPermissionsRepositoryMap | undefined;
    other?: OrganizationProgrammaticAccessGrantPermissionsOtherMap | undefined;
}
/** Minimal representation of an organization programmatic access grant for enumerations */
export interface OrganizationProgrammaticAccessGrant {
    /** Unique identifier of the fine-grained personal access token grant. The `pat_id` used to get details about an approved fine-grained personal access token. */
    id: number;
    owner: SimpleUser;
    /** Type of repository selection requested. */
    repository_selection: OrganizationProgrammaticAccessGrantRepositorySelection;
    /** URL to the list of repositories the fine-grained personal access token can access. Only follow when `repository_selection` is `subset`. */
    repositories_url: string;
    /** Permissions requested, categorized by type of permission. */
    permissions: OrganizationProgrammaticAccessGrantPermissions;
    /** Date and time when the fine-grained personal access token was approved to access the organization. */
    access_granted_at: string;
    /** Unique identifier of the user's token. This field can also be found in audit log events and the organization's settings for their PAT grants. */
    token_id: number;
    /** The name given to the user's token. This field can also be found in an organization's settings page for Active Tokens. */
    token_name: string;
    /** Whether the associated fine-grained personal access token has expired. */
    token_expired: boolean;
    /** Date and time when the associated fine-grained personal access token expires. */
    token_expires_at: string | null;
    /** Date and time when the associated fine-grained personal access token was last used for authentication. */
    token_last_used_at: string | null;
}
export type ListPatGrantsResponseBodyList = Array<OrganizationProgrammaticAccessGrant>;
export type ListPatGrantsResponse = ListPatGrantsResponseBodyList;
export type ListPendingInvitationsRequestRole = "all" | "admin" | "direct_member" | "billing_manager" | "hiring_manager";
export type ListPendingInvitationsRequestInvitationSource = "all" | "member" | "scim";
export interface ListPendingInvitationsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Filter invitations by their member role. */
    role?: ListPendingInvitationsRequestRole | (string & {}) | undefined;
    /** Filter invitations by their invitation source. */
    invitation_source?: ListPendingInvitationsRequestInvitationSource | (string & {}) | undefined;
}
export type ListPendingInvitationsResponseBodyList = Array<OrganizationInvitation>;
export type ListPendingInvitationsResponse = ListPendingInvitationsResponseBodyList;
export interface ListPublicMembersRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicMembersResponseBodyList = Array<SimpleUser>;
export type ListPublicMembersResponse = ListPublicMembersResponseBodyList;
export type ListWebhookDeliveriesRequestStatus = "success" | "failure";
export interface ListWebhookDeliveriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors. */
    cursor?: string | undefined;
    /** Returns webhook deliveries filtered by delivery outcome classification based on `status_code` range. A `status` of `success` returns deliveries with a `status_code` in the 200-399 range (inclusive). A `status` of `failure` returns deliveries with a `status_code` in the 400-599 range (inclusive). */
    status?: ListWebhookDeliveriesRequestStatus | (string & {}) | undefined;
}
/** Delivery made by a webhook, without request and response information. */
export interface HookDeliveryItem {
    /** Unique identifier of the webhook delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the webhook delivery occurred. */
    delivered_at: string;
    /** Whether the webhook delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Describes the response returned after attempting the delivery. */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
}
export type ListWebhookDeliveriesResponseBodyList = Array<HookDeliveryItem>;
export type ListWebhookDeliveriesResponse = ListWebhookDeliveriesResponseBodyList;
export interface ListWebhooksRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListWebhooksResponseBodyList = Array<OrgHook>;
export type ListWebhooksResponse = ListWebhooksResponseBodyList;
export interface PingWebhookRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface PingWebhookResponse {
}
export interface RedeliverWebhookDeliveryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    delivery_id: number;
}
export interface RedeliverWebhookDeliveryResponse {
}
export interface RemoveMemberRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemoveMemberResponse {
}
export interface RemoveMembershipForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemoveMembershipForUserResponse {
}
export interface RemoveOutsideCollaboratorRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemoveOutsideCollaboratorResponse {
}
export interface RemovePublicMembershipForAuthenticatedUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemovePublicMembershipForAuthenticatedUserResponse {
}
/** Action to apply to the request. */
export type ReviewPatGrantRequestRequestAction = "approve" | "deny";
export interface ReviewPatGrantRequestRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the request for access via fine-grained personal access token. */
    pat_request_id: number;
    /** Action to apply to the request. */
    action: ReviewPatGrantRequestRequestAction | (string & {});
    /** Reason for approving or denying the request. Max 1024 characters. */
    reason?: string | null | undefined;
}
export interface ReviewPatGrantRequestResponse {
}
export interface RevokeAllOrgRolesTeamRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
}
export interface RevokeAllOrgRolesTeamResponse {
}
export interface RevokeAllOrgRolesUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RevokeAllOrgRolesUserResponse {
}
export interface RevokeOrgRoleTeamRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The unique identifier of the role. */
    role_id: number;
}
export interface RevokeOrgRoleTeamResponse {
}
export interface RevokeOrgRoleUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The unique identifier of the role. */
    role_id: number;
}
export interface RevokeOrgRoleUserResponse {
}
/** The deployment status of the artifact. */
export type SetClusterDeploymentRecordsRequestDeploymentsItemStatus = "deployed" | "decommissioned";
/** Key-value pairs to tag the deployment record. */
export type SetClusterDeploymentRecordsRequestDeploymentsItemTagsMap = {
    [key: string]: string | undefined;
};
export type SetClusterDeploymentRecordsRequestDeploymentsItemRuntimeRisksItem = "critical-resource" | "internet-exposed" | "lateral-movement" | "sensitive-data";
/** A list of runtime risks associated with the deployment. */
export type SetClusterDeploymentRecordsRequestDeploymentsItemRuntimeRisksList = Array<SetClusterDeploymentRecordsRequestDeploymentsItemRuntimeRisksItem | (string & {})>;
export interface SetClusterDeploymentRecordsRequestDeploymentsItem {
    /** The name of the artifact. */
    name: string;
    /** The hex encoded digest of the artifact. */
    digest: string;
    /** The artifact version. */
    version?: string | undefined;
    /** The deployment status of the artifact. */
    status?: SetClusterDeploymentRecordsRequestDeploymentsItemStatus | (string & {}) | undefined;
    /** The unique identifier for the deployment represented by the new record. To accommodate differing containers and namespaces within a record set, the following format is recommended: {namespaceName}-{deploymentName}-{containerName}. The deployment_name must be unique across all entries in the deployments array. */
    deployment_name: string;
    /** The name of the GitHub repository associated with the artifact. This should be used when there are no provenance attestations available for the artifact. The repository must belong to the organization specified in the path parameter. If a provenance attestation is available for the artifact, the API will use the repository information from the attestation instead of this parameter. */
    github_repository?: string | undefined;
    /** Key-value pairs to tag the deployment record. */
    tags?: SetClusterDeploymentRecordsRequestDeploymentsItemTagsMap | undefined;
    /** A list of runtime risks associated with the deployment. */
    runtime_risks?: SetClusterDeploymentRecordsRequestDeploymentsItemRuntimeRisksList | undefined;
}
/** The list of deployments to record. */
export type SetClusterDeploymentRecordsRequestDeploymentsList = Array<SetClusterDeploymentRecordsRequestDeploymentsItem>;
export interface SetClusterDeploymentRecordsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The cluster name. */
    cluster: string;
    /** The stage of the deployment. */
    logical_environment: string;
    /** The physical region of the deployment. */
    physical_environment?: string | undefined;
    /** The list of deployments to record. */
    deployments: SetClusterDeploymentRecordsRequestDeploymentsList;
    /** When enabled, deployments associated with repositories the actor can write to are processed while deployments associated with repositories that cannot be resolved or written to by the actor are skipped and reported in the `errors` array. When false (the default), the endpoint returns an error if any targeted repository cannot be resolved, the actor lacks write access, or no matching attestation can be found. */
    partial_success?: boolean | undefined;
    /** If true, the endpoint will return the set records in the response body */
    return_records?: boolean | undefined;
}
export type SetClusterDeploymentRecordsResponseDeploymentRecordsList = Array<ArtifactDeploymentRecord>;
export interface SetClusterDeploymentRecordsResponse {
    /** The number of deployment records created */
    total_count: number;
    deployment_records?: SetClusterDeploymentRecordsResponseDeploymentRecordsList | undefined;
}
/** The policy that controls how immutable releases are enforced in the organization. */
export type SetImmutableReleasesSettingsRequestEnforcedRepositories = "all" | "none" | "selected";
/** An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints. */
export type SetImmutableReleasesSettingsRequestSelectedRepositoryIdsList = Array<number>;
export interface SetImmutableReleasesSettingsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The policy that controls how immutable releases are enforced in the organization. */
    enforced_repositories: SetImmutableReleasesSettingsRequestEnforcedRepositories | (string & {});
    /** An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints. */
    selected_repository_ids?: SetImmutableReleasesSettingsRequestSelectedRepositoryIdsList | undefined;
}
export interface SetImmutableReleasesSettingsResponse {
}
/** An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints. */
export type SetImmutableReleasesSettingsRepositoriesRequestSelectedRepositoryIdsList = Array<number>;
export interface SetImmutableReleasesSettingsRepositoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints. */
    selected_repository_ids: SetImmutableReleasesSettingsRepositoriesRequestSelectedRepositoryIdsList;
}
export interface SetImmutableReleasesSettingsRepositoriesResponse {
}
/** The role to give the user in the organization. Can be one of: * `admin` - The user will become an owner of the organization. * `member` - The user will become a non-owner member of the organization. */
export type SetMembershipForUserRequestRole = "admin" | "member";
export interface SetMembershipForUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The role to give the user in the organization. Can be one of: * `admin` - The user will become an owner of the organization. * `member` - The user will become a non-owner member of the organization. */
    role?: SetMembershipForUserRequestRole | (string & {}) | undefined;
}
export interface SetPublicMembershipForAuthenticatedUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface SetPublicMembershipForAuthenticatedUserResponse {
}
export interface UnblockUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface UnblockUserResponse {
}
/** Default permission level members have for organization repositories. */
export type UpdateRequestDefaultRepositoryPermission = "read" | "write" | "admin" | "none";
/** Specifies which types of repositories non-admin organization members can create. `private` is only available to repositories that are part of an organization on GitHub Enterprise Cloud. **Note:** This parameter is closing down and will be removed in the future. Its return value ignores internal repositories. Using this parameter overrides values set in `members_can_create_repositories`. See the parameter deprecation notice in the operation description for details. */
export type UpdateRequestMembersAllowedRepositoryCreationType = "all" | "private" | "none";
export interface UpdateRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Billing email address. This address is not publicized. */
    billing_email?: string | undefined;
    /** The company name. */
    company?: string | undefined;
    /** The publicly visible email address. */
    email?: string | undefined;
    /** The Twitter username of the company. */
    twitter_username?: string | undefined;
    /** The location. */
    location?: string | undefined;
    /** The shorthand name of the company. */
    name?: string | undefined;
    /** The description of the company. The maximum size is 160 characters. */
    description?: string | undefined;
    /** Whether an organization can use organization projects. */
    has_organization_projects?: boolean | undefined;
    /** Whether repositories that belong to the organization can use repository projects. */
    has_repository_projects?: boolean | undefined;
    /** Default permission level members have for organization repositories. */
    default_repository_permission?: UpdateRequestDefaultRepositoryPermission | (string & {}) | undefined;
    /** Whether of non-admin organization members can create repositories. **Note:** A parameter can override this parameter. See `members_allowed_repository_creation_type` in this table for details. */
    members_can_create_repositories?: boolean | undefined;
    /** Whether organization members can create internal repositories, which are visible to all enterprise members. You can only allow members to create internal repositories if your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation. */
    members_can_create_internal_repositories?: boolean | undefined;
    /** Whether organization members can create private repositories, which are visible to organization members with permission. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation. */
    members_can_create_private_repositories?: boolean | undefined;
    /** Whether organization members can create public repositories, which are visible to anyone. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation. */
    members_can_create_public_repositories?: boolean | undefined;
    /** Specifies which types of repositories non-admin organization members can create. `private` is only available to repositories that are part of an organization on GitHub Enterprise Cloud. **Note:** This parameter is closing down and will be removed in the future. Its return value ignores internal repositories. Using this parameter overrides values set in `members_can_create_repositories`. See the parameter deprecation notice in the operation description for details. */
    members_allowed_repository_creation_type?: UpdateRequestMembersAllowedRepositoryCreationType | (string & {}) | undefined;
    /** Whether organization members can create GitHub Pages sites. Existing published sites will not be impacted. */
    members_can_create_pages?: boolean | undefined;
    /** Whether organization members can create public GitHub Pages sites. Existing published sites will not be impacted. */
    members_can_create_public_pages?: boolean | undefined;
    /** Whether organization members can create private GitHub Pages sites. Existing published sites will not be impacted. */
    members_can_create_private_pages?: boolean | undefined;
    /** Whether organization members can fork private organization repositories. */
    members_can_fork_private_repositories?: boolean | undefined;
    /** Whether contributors to organization repositories are required to sign off on commits they make through GitHub's web interface. */
    web_commit_signoff_required?: boolean | undefined;
    blog?: string | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether GitHub Advanced Security is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    advanced_security_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot alerts are automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    dependabot_alerts_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether Dependabot security updates are automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    dependabot_security_updates_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether dependency graph is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    dependency_graph_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    secret_scanning_enabled_for_new_repositories?: boolean | undefined;
    /** **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead. Whether secret scanning push protection is automatically enabled for new repositories and repositories transferred to this organization. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request. */
    secret_scanning_push_protection_enabled_for_new_repositories?: boolean | undefined;
    /** Whether a custom link is shown to contributors who are blocked from pushing a secret by push protection. */
    secret_scanning_push_protection_custom_link_enabled?: boolean | undefined;
    /** If `secret_scanning_push_protection_custom_link_enabled` is true, the URL that will be displayed to contributors who are blocked from pushing a secret. */
    secret_scanning_push_protection_custom_link?: string | undefined;
    /** Controls whether or not deploy keys may be added and used for repositories in the organization. */
    deploy_keys_enabled_for_repositories?: boolean | undefined;
}
/** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled. */
export type UpdateIssueFieldRequestVisibility = "organization_members_only" | "all";
/** Color for the option. */
export type UpdateIssueFieldRequestOptionsItemColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
export interface UpdateIssueFieldRequestOptionsItem {
    /** The id of an existing option to retain or update. Omit this when creating a new option. */
    id?: number | undefined;
    /** Name of the option. */
    name: string;
    /** Description of the option. */
    description?: string | null | undefined;
    /** Color for the option. */
    color: UpdateIssueFieldRequestOptionsItemColor | (string & {});
    /** Priority of the option for ordering. */
    priority: number;
}
/** Options for select fields. Only applicable when updating single_select or multi_select fields. When provided, this array **replaces** the entire existing set of options rather than adding to or updating individual options. To retain or update an existing option, include it in the array with its `id`. Options sent without an `id` are treated as new options and may cause existing options to be deleted and recreated. */
export type UpdateIssueFieldRequestOptionsList = Array<UpdateIssueFieldRequestOptionsItem>;
export interface UpdateIssueFieldRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the issue field. */
    issue_field_id: number;
    /** Name of the issue field. */
    name?: string | undefined;
    /** Description of the issue field. */
    description?: string | null | undefined;
    /** The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled. */
    visibility?: UpdateIssueFieldRequestVisibility | (string & {}) | undefined;
    /** Options for select fields. Only applicable when updating single_select or multi_select fields. When provided, this array **replaces** the entire existing set of options rather than adding to or updating individual options. To retain or update an existing option, include it in the array with its `id`. Options sent without an `id` are treated as new options and may cause existing options to be deleted and recreated. */
    options?: UpdateIssueFieldRequestOptionsList | undefined;
}
/** Color for the issue type. */
export type UpdateIssueTypeRequestColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
export interface UpdateIssueTypeRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the issue type. */
    issue_type_id: number;
    /** Name of the issue type. */
    name: string;
    /** Whether or not the issue type is enabled at the organization level. */
    is_enabled: boolean;
    /** Description of the issue type. */
    description?: string | null | undefined;
    /** Color for the issue type. */
    color?: UpdateIssueTypeRequestColor | (string & {}) | null | undefined;
}
/** The state that the membership should be in. Only `"active"` will be accepted. */
export type UpdateMembershipForAuthenticatedUserRequestState = "active";
export interface UpdateMembershipForAuthenticatedUserRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The state that the membership should be in. Only `"active"` will be accepted. */
    state: UpdateMembershipForAuthenticatedUserRequestState | (string & {});
}
/** Action to apply to the fine-grained personal access token. */
export type UpdatePatAccessRequestAction = "revoke";
export interface UpdatePatAccessRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the fine-grained personal access token. */
    pat_id: number;
    /** Action to apply to the fine-grained personal access token. */
    action: UpdatePatAccessRequestAction | (string & {});
}
export interface UpdatePatAccessResponse {
}
/** Action to apply to the fine-grained personal access token. */
export type UpdatePatAccessesRequestAction = "revoke";
/** The IDs of the fine-grained personal access tokens. */
export type UpdatePatAccessesRequestPatIdsList = Array<number>;
export interface UpdatePatAccessesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Action to apply to the fine-grained personal access token. */
    action: UpdatePatAccessesRequestAction | (string & {});
    /** The IDs of the fine-grained personal access tokens. */
    pat_ids: UpdatePatAccessesRequestPatIdsList;
}
export interface UpdatePatAccessesResponse {
}
/** Key/value pairs to provide settings for this webhook. */
export interface UpdateWebhookRequestConfig {
    url: string;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
/** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. */
export type UpdateWebhookRequestEventsList = Array<string>;
export interface UpdateWebhookRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    /** Key/value pairs to provide settings for this webhook. */
    config?: UpdateWebhookRequestConfig | undefined;
    /** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. */
    events?: UpdateWebhookRequestEventsList | undefined;
    /** Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. */
    active?: boolean | undefined;
    name?: string | undefined;
}
export interface UpdateWebhookConfigForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export type AssignTeamToOrgRoleError = GithubOpError;
/** Assign an organization role to a team Assigns an organization role to a team in an organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const assignTeamToOrgRole: API.OperationMethod<AssignTeamToOrgRoleRequest, AssignTeamToOrgRoleResponse, AssignTeamToOrgRoleError, GithubOpContext>;
export type AssignUserToOrgRoleError = GithubOpError;
/** Assign an organization role to a user Assigns an organization role to a member of an organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const assignUserToOrgRole: API.OperationMethod<AssignUserToOrgRoleRequest, AssignUserToOrgRoleResponse, AssignUserToOrgRoleError, GithubOpContext>;
export type BlockUserError = GithubOpError;
/** Block a user from an organization Blocks the given user on behalf of the specified organization and returns a 204. If the organization cannot block the given user a 422 is returned. */
export declare const blockUser: API.OperationMethod<BlockUserRequest, BlockUserResponse, BlockUserError, GithubOpContext>;
export type BulkReviewPatGrantRequestsInError = GithubOpError;
/** Review requests to access organization resources with fine-grained personal access tokens Approves or denies multiple pending requests to access organization resources via a fine-grained personal access token. Only GitHub Apps can use this endpoint. */
export declare const bulkReviewPatGrantRequestsIn: API.OperationMethod<BulkReviewPatGrantRequestsInRequest, BulkReviewPatGrantRequestsInResponse, BulkReviewPatGrantRequestsInError, GithubOpContext>;
export type CancelInvitationError = GithubOpError;
/** Cancel an organization invitation Cancel an organization invitation. In order to cancel an organization invitation, the authenticated user must be an organization owner. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). */
export declare const cancelInvitation: API.OperationMethod<CancelInvitationRequest, CancelInvitationResponse, CancelInvitationError, GithubOpContext>;
export type CheckBlockedUserError = GithubOpError;
/** Check if a user is blocked by an organization Returns a 204 if the given user is blocked by the given organization. Returns a 404 if the organization is not blocking the user, or if the user account has been identified as spam by GitHub. */
export declare const checkBlockedUser: API.OperationMethod<CheckBlockedUserRequest, CheckBlockedUserResponse, CheckBlockedUserError, GithubOpContext>;
export type CheckMembershipForUserError = GithubOpError;
/** Check organization membership for a user Check if a user is, publicly or privately, a member of the organization. */
export declare const checkMembershipForUser: API.OperationMethod<CheckMembershipForUserRequest, CheckMembershipForUserResponse, CheckMembershipForUserError, GithubOpContext>;
export type CheckPublicMembershipForUserError = GithubOpError;
/** Check public organization membership for a user Check if the provided user is a public member of the organization. */
export declare const checkPublicMembershipForUser: API.OperationMethod<CheckPublicMembershipForUserRequest, CheckPublicMembershipForUserResponse, CheckPublicMembershipForUserError, GithubOpContext>;
export type ConvertMemberToOutsideCollaboratorError = GithubOpError;
/** Convert an organization member to outside collaborator When an organization member is converted to an outside collaborator, they'll only have access to the repositories that their current team membership allows. The user will no longer be a member of the organization. For more information, see "[Converting an organization member to an outside collaborator](https://docs.github.com/articles/converting-an-organization-member-to-an-outside-collaborator/)". Converting an organization member to an outside collaborator may be restricted by enterprise administrators. For more information, see "[Enforcing repository management policies in your enterprise](https://docs.github.com/admin/policies/enforcing-policies-for-your-enterprise/enforcing-repository-management-policies-in-your-enterprise#enforcing-a-policy-for-inviting-outside-collaborators-to-repositories)." */
export declare const convertMemberToOutsideCollaborator: API.OperationMethod<ConvertMemberToOutsideCollaboratorRequest, ConvertMemberToOutsideCollaboratorResponse, ConvertMemberToOutsideCollaboratorError, GithubOpContext>;
export type CreateArtifactDeploymentRecordError = GithubOpError;
/** Create an artifact deployment record Create or update deployment records for an artifact associated with an organization. This endpoint allows you to record information about a specific artifact, such as its name, digest, environments, cluster, and deployment. The deployment name has to be uniqe within a cluster (i.e a combination of logical, physical environment and cluster) as it identifies unique deployment. Multiple requests for the same combination of logical, physical environment, cluster and deployment name will only create one record, successive request will update the existing record. This allows for a stable tracking of a deployment where the actual deployed artifact can change over time. */
export declare const createArtifactDeploymentRecord: API.OperationMethod<CreateArtifactDeploymentRecordRequest, CreateArtifactDeploymentRecordResponse, CreateArtifactDeploymentRecordError, GithubOpContext>;
export type CreateArtifactStorageRecordError = GithubOpError;
/** Create artifact metadata storage record Create metadata storage records for artifacts associated with an organization. This endpoint will create a new artifact storage record on behalf of any artifact matching the provided digest and associated with a repository owned by the organization. */
export declare const createArtifactStorageRecord: API.OperationMethod<CreateArtifactStorageRecordRequest, CreateArtifactStorageRecordResponse, CreateArtifactStorageRecordError, GithubOpContext>;
export type CreateClusterDeploymentRecordsJobError = GithubOpError;
/** Create a cluster deployment records job Create a background job to set deployment records for a given cluster. Performs validation and permission checks synchronously, returning rejected deployments immediately, then enqueues a background job for the actual deployment updates. Use the companion GET endpoint to poll for job status. */
export declare const createClusterDeploymentRecordsJob: API.OperationMethod<CreateClusterDeploymentRecordsJobRequest, CreateClusterDeploymentRecordsJobResponse, CreateClusterDeploymentRecordsJobError, GithubOpContext>;
export type CreateInvitationError = GithubOpError;
/** Create an organization invitation Invite people to an organization by using their GitHub user ID or their email address. In order to create invitations in an organization, the authenticated user must be an organization owner. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const createInvitation: API.OperationMethod<CreateInvitationRequest, OrganizationInvitation, CreateInvitationError, GithubOpContext>;
export type CreateIssueFieldError = GithubOpError;
/** Create issue field for an organization Creates a new issue field for an organization. You can find out more about issue fields in [Managing issue fields in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/using-issues/managing-issue-fields-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createIssueField: API.OperationMethod<CreateIssueFieldRequest, IssueField, CreateIssueFieldError, GithubOpContext>;
export type CreateIssueTypeError = GithubOpError;
/** Create issue type for an organization Create a new issue type for an organization. You can find out more about issue types in [Managing issue types in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/configuring-issues/managing-issue-types-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createIssueType: API.OperationMethod<CreateIssueTypeRequest, IssueType, CreateIssueTypeError, GithubOpContext>;
export type CreateWebhookError = GithubOpError;
/** Create an organization webhook Create a hook that posts payloads in JSON format. You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const createWebhook: API.OperationMethod<CreateWebhookRequest, OrgHook, CreateWebhookError, GithubOpContext>;
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionError = GithubOpError;
/** Create or update a custom property for an organization Creates a new or updates an existing custom property that is defined for an organization. To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - A user, or a user on a team, with the fine-grained permission of `custom_properties_org_definitions_manager` in the organization. */
export declare const customPropertiesForReposCreateOrUpdateOrganizationDefinition: API.OperationMethod<CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionRequest, CustomProperty, CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionError, GithubOpContext>;
export type CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsError = GithubOpError;
/** Create or update custom properties for an organization Creates new or updates existing custom properties defined for an organization in a batch. If the property already exists, the existing property will be replaced with the new values. Missing optional values will fall back to default values, previous values will be overwritten. E.g. if a property exists with `values_editable_by: org_and_repo_actors` and it's updated without specifying `values_editable_by`, it will be updated to default value `org_actors`. To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - A user, or a user on a team, with the fine-grained permission of `custom_properties_org_definitions_manager` in the organization. */
export declare const customPropertiesForReposCreateOrUpdateOrganizationDefinitions: API.OperationMethod<CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsRequest, CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsResponse, CustomPropertiesForReposCreateOrUpdateOrganizationDefinitionsError, GithubOpContext>;
export type CustomPropertiesForReposCreateOrUpdateOrganizationValuesError = GithubOpError;
/** Create or update custom property values for organization repositories Create new or update existing custom property values for repositories in a batch that belong to an organization. Each target repository will have its custom property values updated to match the values provided in the request. A maximum of 30 repositories can be updated in a single request. Using a value of `null` for a custom property will remove or 'unset' the property value from the repository. To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - A user, or a user on a team, with the fine-grained permission of `custom_properties_org_values_editor` in the organization. */
export declare const customPropertiesForReposCreateOrUpdateOrganizationValues: API.OperationMethod<CustomPropertiesForReposCreateOrUpdateOrganizationValuesRequest, CustomPropertiesForReposCreateOrUpdateOrganizationValuesResponse, CustomPropertiesForReposCreateOrUpdateOrganizationValuesError, GithubOpContext>;
export type CustomPropertiesForReposDeleteOrganizationDefinitionError = GithubOpError;
/** Remove a custom property for an organization Removes a custom property that is defined for an organization. To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - A user, or a user on a team, with the fine-grained permission of `custom_properties_org_definitions_manager` in the organization. */
export declare const customPropertiesForReposDeleteOrganizationDefinition: API.OperationMethod<CustomPropertiesForReposDeleteOrganizationDefinitionRequest, CustomPropertiesForReposDeleteOrganizationDefinitionResponse, CustomPropertiesForReposDeleteOrganizationDefinitionError, GithubOpContext>;
export type CustomPropertiesForReposGetOrganizationDefinitionError = GithubOpError;
/** Get a custom property for an organization Gets a custom property that is defined for an organization. Organization members can read these properties. */
export declare const customPropertiesForReposGetOrganizationDefinition: API.OperationMethod<CustomPropertiesForReposGetOrganizationDefinitionRequest, CustomProperty, CustomPropertiesForReposGetOrganizationDefinitionError, GithubOpContext>;
export type CustomPropertiesForReposGetOrganizationDefinitionsError = GithubOpError;
/** Get all custom properties for an organization Gets all custom properties defined for an organization. Organization members can read these properties. */
export declare const customPropertiesForReposGetOrganizationDefinitions: API.OperationMethod<CustomPropertiesForReposGetOrganizationDefinitionsRequest, CustomPropertiesForReposGetOrganizationDefinitionsResponse, CustomPropertiesForReposGetOrganizationDefinitionsError, GithubOpContext>;
export type CustomPropertiesForReposGetOrganizationValuesError = GithubOpError;
/** List custom property values for organization repositories Lists organization repositories with all of their custom property values. Organization members can read these properties. */
export declare const customPropertiesForReposGetOrganizationValues: API.PaginatedOperationMethod<CustomPropertiesForReposGetOrganizationValuesRequest, CustomPropertiesForReposGetOrganizationValuesResponse, CustomPropertiesForReposGetOrganizationValuesError, GithubOpContext, OrgRepoCustomPropertyValues>;
export type DeleteError = GithubOpError;
/** Delete an organization Deletes an organization and all its repositories. The organization login will be unavailable for 90 days after deletion. Please review the Terms of Service regarding account deletion before using this endpoint: https://docs.github.com/site-policy/github-terms/github-terms-of-service */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, GithubOpContext>;
export type DeleteAttestationsBulkError = GithubOpError;
/** Delete attestations in bulk Delete artifact attestations in bulk by either subject digests or unique ID. */
export declare const deleteAttestationsBulk: API.OperationMethod<DeleteAttestationsBulkRequest, DeleteAttestationsBulkResponse, DeleteAttestationsBulkError, GithubOpContext>;
export type DeleteAttestationsByIdError = GithubOpError;
/** Delete attestations by ID Delete an artifact attestation by unique ID that is associated with a repository owned by an org. */
export declare const deleteAttestationsById: API.OperationMethod<DeleteAttestationsByIdRequest, DeleteAttestationsByIdResponse, DeleteAttestationsByIdError, GithubOpContext>;
export type DeleteAttestationsBySubjectDigestError = GithubOpError;
/** Delete attestations by subject digest Delete an artifact attestation by subject digest. */
export declare const deleteAttestationsBySubjectDigest: API.OperationMethod<DeleteAttestationsBySubjectDigestRequest, DeleteAttestationsBySubjectDigestResponse, DeleteAttestationsBySubjectDigestError, GithubOpContext>;
export type DeleteIssueFieldError = GithubOpError;
/** Delete issue field for an organization Deletes an issue field for an organization. You can find out more about issue fields in [Managing issue fields in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/using-issues/managing-issue-fields-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteIssueField: API.OperationMethod<DeleteIssueFieldRequest, DeleteIssueFieldResponse, DeleteIssueFieldError, GithubOpContext>;
export type DeleteIssueTypeError = GithubOpError;
/** Delete issue type for an organization Deletes an issue type for an organization. You can find out more about issue types in [Managing issue types in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/configuring-issues/managing-issue-types-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteIssueType: API.OperationMethod<DeleteIssueTypeRequest, DeleteIssueTypeResponse, DeleteIssueTypeError, GithubOpContext>;
export type DeleteWebhookError = GithubOpError;
/** Delete an organization webhook Delete a webhook for an organization. The authenticated user must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResponse, DeleteWebhookError, GithubOpContext>;
export type DisableSelectedRepositoryImmutableReleasesOrganizationError = GithubOpError;
/** Disable a selected repository for immutable releases in an organization Removes a repository from the list of selected repositories that are enforced for immutable releases in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const disableSelectedRepositoryImmutableReleasesOrganization: API.OperationMethod<DisableSelectedRepositoryImmutableReleasesOrganizationRequest, DisableSelectedRepositoryImmutableReleasesOrganizationResponse, DisableSelectedRepositoryImmutableReleasesOrganizationError, GithubOpContext>;
export type EnableSelectedRepositoryImmutableReleasesOrganizationError = GithubOpError;
/** Enable a selected repository for immutable releases in an organization Adds a repository to the list of selected repositories that are enforced for immutable releases in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const enableSelectedRepositoryImmutableReleasesOrganization: API.OperationMethod<EnableSelectedRepositoryImmutableReleasesOrganizationRequest, EnableSelectedRepositoryImmutableReleasesOrganizationResponse, EnableSelectedRepositoryImmutableReleasesOrganizationError, GithubOpContext>;
export type ExternalPropertiesForReposCreateOrUpdateOrganizationValuesError = GithubOpError;
/** Create or update external custom property values for organization repositories Create new or update existing external custom property values for repositories in a batch that belong to an organization. Each target repository will have its external custom property values updated to match the values provided in the request. A maximum of 30 repositories can be updated in a single request. Using a value of `null` for an external custom property will remove or 'unset' the property value from the repository. To use this endpoint, the authenticated GitHub App must have the `organization_external_properties_for_repos:write` permission. */
export declare const externalPropertiesForReposCreateOrUpdateOrganizationValues: API.OperationMethod<ExternalPropertiesForReposCreateOrUpdateOrganizationValuesRequest, ExternalPropertiesForReposCreateOrUpdateOrganizationValuesResponse, ExternalPropertiesForReposCreateOrUpdateOrganizationValuesError, GithubOpContext>;
export type ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyError = GithubOpError;
/** Create or update external custom property values for a property across organization repositories Create new or update existing external custom property values for a single named property across repositories that belong to an organization. Up to 100 repository values can be updated in a single request. Repositories not included in the request are left unchanged. Using a value of `null` for a repository will remove or 'unset' the property value for that repository. A request that only contains `null` values for a property that does not yet exist is a no-op. To use this endpoint, the authenticated GitHub App must have the `organization_external_properties_for_repos:write` permission. */
export declare const externalPropertiesForReposCreateOrUpdateValuesForOrganizationProperty: API.OperationMethod<ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyRequest, ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyResponse, ExternalPropertiesForReposCreateOrUpdateValuesForOrganizationPropertyError, GithubOpContext>;
export type ExternalPropertiesForReposDeleteOrganizationValuesError = GithubOpError;
/** Remove all external custom property values for a property across all organization repositories Removes all external custom property values for a specified property name across all repositories that belong to an organization. To use this endpoint, the authenticated GitHub App must have the `organization_external_properties_for_repos:write` permission. */
export declare const externalPropertiesForReposDeleteOrganizationValues: API.OperationMethod<ExternalPropertiesForReposDeleteOrganizationValuesRequest, ExternalPropertiesForReposDeleteOrganizationValuesResponse, ExternalPropertiesForReposDeleteOrganizationValuesError, GithubOpContext>;
export type ExternalPropertiesForReposGetOrganizationAppInstallationsError = GithubOpError;
/** Get registered app installations for external custom properties Gets the registered GitHub App installations used to read and write external custom properties for an organization. A GitHub App installation token will only be able to see its own registration info, whereas an authenticated user will be able to see all registrations for the organization. To use this endpoint, the authenticated caller must have the `organization_external_properties_for_repos:admin` permission. */
export declare const externalPropertiesForReposGetOrganizationAppInstallations: API.OperationMethod<ExternalPropertiesForReposGetOrganizationAppInstallationsRequest, ExternalPropertiesForReposGetOrganizationAppInstallationsResponse, ExternalPropertiesForReposGetOrganizationAppInstallationsError, GithubOpContext>;
export type ExternalPropertiesForReposGetOrganizationDefinitionsError = GithubOpError;
/** Get all external custom properties for a GitHub App installation in an organization Gets all external custom properties defined for the authenticated GitHub App installation on an organization. To use this endpoint, the authenticated GitHub App must have the `organization_external_properties_for_repos:read` permission. */
export declare const externalPropertiesForReposGetOrganizationDefinitions: API.OperationMethod<ExternalPropertiesForReposGetOrganizationDefinitionsRequest, ExternalPropertiesForReposGetOrganizationDefinitionsResponse, ExternalPropertiesForReposGetOrganizationDefinitionsError, GithubOpContext>;
export type ExternalPropertiesForReposRegisterOrganizationAppInstallationError = GithubOpError;
/** Register an app installation for external custom properties Registers a GitHub App installation so it can read and write external custom properties for an organization, and assigns it a display name. The display name must be 1 to 15 characters and contain only letters and numbers. Capitalization is preserved as entered. An app installation can only be registered once, and its display name can't be changed afterward. Calling with an app installation that has already been registered returns a `422` response with an `already_exists` error code for `installation_id`. If the display name is already in use by another app installation in the organization, the response is `422` with an `already_exists` error code for `display_name`. An invalid display name also returns `422`. The app installation being registered must have write or admin permission for organization external custom properties for repositories. If it doesn't, the response is `422`. This is the permission of the installation being registered, which isn't necessarily the caller. Uninstalling the GitHub App unregisters it, and removes the external custom properties it created. To use this endpoint, the authenticated caller must have the `organization_external_properties_for_repos:admin` permission. */
export declare const externalPropertiesForReposRegisterOrganizationAppInstallation: API.OperationMethod<ExternalPropertiesForReposRegisterOrganizationAppInstallationRequest, OrganizationExternalPropertyInstallation, ExternalPropertiesForReposRegisterOrganizationAppInstallationError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get an organization Gets information about an organization. When the value of `two_factor_requirement_enabled` is `true`, the organization requires all members, billing managers, outside collaborators, guest collaborators, repository collaborators, or everyone with access to any repository within the organization to enable [two-factor authentication](https://docs.github.com/articles/securing-your-account-with-two-factor-authentication-2fa/). To see the full details about an organization, the authenticated user must be an organization owner. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to see the full details about an organization. To see information about an organization's GitHub plan, GitHub Apps need the `Organization plan` permission. */
export declare const get: API.OperationMethod<GetRequest, OrganizationFull, GetError, GithubOpContext>;
export type GetApiInsightRouteStatsByActorError = GithubOpError;
/** Get route stats by actor Get API request count statistics for an actor broken down by route within a specified time frame. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightRouteStatsByActor: API.PaginatedOperationMethod<GetApiInsightRouteStatsByActorRequest, GetApiInsightRouteStatsByActorResponse, GetApiInsightRouteStatsByActorError, GithubOpContext, ApiInsightsRouteStatsItem>;
export type GetApiInsightSubjectStatsError = GithubOpError;
/** Get subject stats Get API request statistics for all subjects within an organization within a specified time frame. Subjects can be users or GitHub Apps. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightSubjectStats: API.PaginatedOperationMethod<GetApiInsightSubjectStatsRequest, GetApiInsightSubjectStatsResponse, GetApiInsightSubjectStatsError, GithubOpContext, ApiInsightsSubjectStatsItem>;
export type GetApiInsightSummaryStatsError = GithubOpError;
/** Get summary stats Get overall statistics of API requests made within an organization by all users and apps within a specified time frame. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightSummaryStats: API.OperationMethod<GetApiInsightSummaryStatsRequest, ApiInsightsSummaryStats, GetApiInsightSummaryStatsError, GithubOpContext>;
export type GetApiInsightSummaryStatsByActorError = GithubOpError;
/** Get summary stats by actor Get overall statistics of API requests within the organization made by a specific actor. Actors can be GitHub App installations, OAuth apps or other tokens on behalf of a user. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightSummaryStatsByActor: API.OperationMethod<GetApiInsightSummaryStatsByActorRequest, ApiInsightsSummaryStats, GetApiInsightSummaryStatsByActorError, GithubOpContext>;
export type GetApiInsightSummaryStatsByUserError = GithubOpError;
/** Get summary stats by user Get overall statistics of API requests within the organization for a user. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightSummaryStatsByUser: API.OperationMethod<GetApiInsightSummaryStatsByUserRequest, ApiInsightsSummaryStats, GetApiInsightSummaryStatsByUserError, GithubOpContext>;
export type GetApiInsightTimeStatsError = GithubOpError;
/** Get time stats Get the number of API requests and rate-limited requests made within an organization over a specified time period. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightTimeStats: API.OperationMethod<GetApiInsightTimeStatsRequest, GetApiInsightTimeStatsResponse, GetApiInsightTimeStatsError, GithubOpContext>;
export type GetApiInsightTimeStatsByActorError = GithubOpError;
/** Get time stats by actor Get the number of API requests and rate-limited requests made within an organization by a specific actor within a specified time period. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightTimeStatsByActor: API.OperationMethod<GetApiInsightTimeStatsByActorRequest, GetApiInsightTimeStatsByActorResponse, GetApiInsightTimeStatsByActorError, GithubOpContext>;
export type GetApiInsightTimeStatsByUserError = GithubOpError;
/** Get time stats by user Get the number of API requests and rate-limited requests made within an organization by a specific user over a specified time period. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightTimeStatsByUser: API.OperationMethod<GetApiInsightTimeStatsByUserRequest, GetApiInsightTimeStatsByUserResponse, GetApiInsightTimeStatsByUserError, GithubOpContext>;
export type GetApiInsightUserStatsError = GithubOpError;
/** Get user stats Get API usage statistics within an organization for a user broken down by the type of access. Under normal conditions, you can expect API data to appear within 4-6 hours after making a request. During incidents or periods of unusually high volume, it may take longer to show up. */
export declare const getApiInsightUserStats: API.PaginatedOperationMethod<GetApiInsightUserStatsRequest, GetApiInsightUserStatsResponse, GetApiInsightUserStatsError, GithubOpContext, ApiInsightsUserStatsItem>;
export type GetClusterDeploymentRecordsJobError = GithubOpError;
/** Get cluster deployment records job status Get the status and results of a previously created cluster deployment records job. */
export declare const getClusterDeploymentRecordsJob: API.OperationMethod<GetClusterDeploymentRecordsJobRequest, GetClusterDeploymentRecordsJobResponse, GetClusterDeploymentRecordsJobError, GithubOpContext>;
export type GetImmutableReleasesSettingsError = GithubOpError;
/** Get immutable releases settings for an organization Gets the immutable releases policy for repositories in an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getImmutableReleasesSettings: API.OperationMethod<GetImmutableReleasesSettingsRequest, ImmutableReleasesOrganizationSettings, GetImmutableReleasesSettingsError, GithubOpContext>;
export type GetImmutableReleasesSettingsRepositoriesError = GithubOpError;
/** List selected repositories for immutable releases enforcement List all of the repositories that have been selected for immutable releases enforcement in an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getImmutableReleasesSettingsRepositories: API.PaginatedOperationMethod<GetImmutableReleasesSettingsRepositoriesRequest, GetImmutableReleasesSettingsRepositoriesResponse, GetImmutableReleasesSettingsRepositoriesError, GithubOpContext, MinimalRepository>;
export type GetMembershipForAuthenticatedUserError = GithubOpError;
/** Get an organization membership for the authenticated user If the authenticated user is an active or pending member of the organization, this endpoint will return the user's membership. If the authenticated user is not affiliated with the organization, a `404` is returned. This endpoint will return a `403` if the request is made by a GitHub App that is blocked by the organization. */
export declare const getMembershipForAuthenticatedUser: API.OperationMethod<GetMembershipForAuthenticatedUserRequest, OrgMembership, GetMembershipForAuthenticatedUserError, GithubOpContext>;
export type GetMembershipForUserError = GithubOpError;
/** Get organization membership for a user In order to get a user's membership with an organization, the authenticated user must be an organization member. The `state` parameter in the response can be used to identify the user's membership status. */
export declare const getMembershipForUser: API.OperationMethod<GetMembershipForUserRequest, OrgMembership, GetMembershipForUserError, GithubOpContext>;
export type GetOrgRoleError = GithubOpError;
/** Get an organization role Gets an organization role that is available to this organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - An organization member (or a member of a team) assigned a custom organization role that includes the **View organization roles** (`read_organization_custom_org_role`) permission. For more information, see "[Permissions for organization access](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/permissions-of-custom-organization-roles#permissions-for-organization-access)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgRole: API.OperationMethod<GetOrgRoleRequest, OrganizationRole, GetOrgRoleError, GithubOpContext>;
export type GetOrgRulesetHistoryError = GithubOpError;
/** Get organization ruleset history Get the history of an organization ruleset. */
export declare const getOrgRulesetHistory: API.PaginatedOperationMethod<GetOrgRulesetHistoryRequest, GetOrgRulesetHistoryResponse, GetOrgRulesetHistoryError, GithubOpContext, RulesetVersion>;
export type GetOrgRulesetVersionError = GithubOpError;
/** Get organization ruleset version Get a version of an organization ruleset. */
export declare const getOrgRulesetVersion: API.OperationMethod<GetOrgRulesetVersionRequest, GetOrgRulesetVersionResponse, GetOrgRulesetVersionError, GithubOpContext>;
export type GetWebhookError = GithubOpError;
/** Get an organization webhook Returns a webhook configured in an organization. To get only the webhook `config` properties, see "[Get a webhook configuration for an organization](/rest/orgs/webhooks#get-a-webhook-configuration-for-an-organization). You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, OrgHook, GetWebhookError, GithubOpContext>;
export type GetWebhookConfigForOrgError = GithubOpError;
/** Get a webhook configuration for an organization Returns the webhook configuration for an organization. To get more information about the webhook, including the `active` state and `events`, use "[Get an organization webhook ](/rest/orgs/webhooks#get-an-organization-webhook)." You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const getWebhookConfigForOrg: API.OperationMethod<GetWebhookConfigForOrgRequest, WebhookConfig, GetWebhookConfigForOrgError, GithubOpContext>;
export type GetWebhookDeliveryError = GithubOpError;
/** Get a webhook delivery for an organization webhook Returns a delivery for a webhook configured in an organization. You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const getWebhookDelivery: API.OperationMethod<GetWebhookDeliveryRequest, HookDelivery, GetWebhookDeliveryError, GithubOpContext>;
export type ListError = GithubOpError;
/** List organizations Lists all organizations, in the order that they were created. > [!NOTE] > Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of organizations. */
export declare const list: API.OperationMethod<ListRequest, ListResponse, ListError, GithubOpContext>;
export type ListAppInstallationsError = GithubOpError;
/** List app installations for an organization Lists all GitHub Apps in an organization. The installation count includes all GitHub Apps installed on repositories in the organization. The authenticated user must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:read` scope to use this endpoint. */
export declare const listAppInstallations: API.PaginatedOperationMethod<ListAppInstallationsRequest, ListAppInstallationsResponse, ListAppInstallationsError, GithubOpContext, Installation>;
export type ListArtifactDeploymentRecordsError = GithubOpError;
/** List artifact deployment records List deployment records for an artifact metadata associated with an organization. */
export declare const listArtifactDeploymentRecords: API.OperationMethod<ListArtifactDeploymentRecordsRequest, ListArtifactDeploymentRecordsResponse, ListArtifactDeploymentRecordsError, GithubOpContext>;
export type ListArtifactStorageRecordsError = GithubOpError;
/** List artifact storage records List artifact storage records with a given subject digest for repositories owned by an organization. Results are filtered by the authenticated user's permissions; records for repositories the user cannot read are omitted. Fine-grained access tokens require the `artifact-metadata:read` permission. */
export declare const listArtifactStorageRecords: API.OperationMethod<ListArtifactStorageRecordsRequest, ListArtifactStorageRecordsResponse, ListArtifactStorageRecordsError, GithubOpContext>;
export type ListAttestationRepositoriesError = GithubOpError;
/** List attestation repositories List repositories owned by the provided organization that have created at least one attested artifact Results will be sorted in ascending order by repository ID */
export declare const listAttestationRepositories: API.OperationMethod<ListAttestationRepositoriesRequest, ListAttestationRepositoriesResponse, ListAttestationRepositoriesError, GithubOpContext>;
export type ListAttestationsError = GithubOpError;
/** List attestations List a collection of artifact attestations with a given subject digest that are associated with repositories owned by an organization. The collection of attestations returned by this endpoint is filtered according to the authenticated user's permissions; if the authenticated user cannot read a repository, the attestations associated with that repository will not be included in the response. In addition, when using a fine-grained access token the `attestations:read` permission is required. **Please note:** in order to offer meaningful security benefits, an attestation's signature and timestamps **must** be cryptographically verified, and the identity of the attestation signer **must** be validated. Attestations can be verified using the [GitHub CLI `attestation verify` command](https://cli.github.com/manual/gh_attestation_verify). For more information, see [our guide on how to use artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const listAttestations: API.OperationMethod<ListAttestationsRequest, ListAttestationsResponse, ListAttestationsError, GithubOpContext>;
export type ListAttestationsBulkError = GithubOpError;
/** List attestations by bulk subject digests List a collection of artifact attestations associated with any entry in a list of subject digests owned by an organization. The collection of attestations returned by this endpoint is filtered according to the authenticated user's permissions; if the authenticated user cannot read a repository, the attestations associated with that repository will not be included in the response. In addition, when using a fine-grained access token the `attestations:read` permission is required. **Please note:** in order to offer meaningful security benefits, an attestation's signature and timestamps **must** be cryptographically verified, and the identity of the attestation signer **must** be validated. Attestations can be verified using the [GitHub CLI `attestation verify` command](https://cli.github.com/manual/gh_attestation_verify). For more information, see [our guide on how to use artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const listAttestationsBulk: API.OperationMethod<ListAttestationsBulkRequest, ListAttestationsBulkResponse, ListAttestationsBulkError, GithubOpContext>;
export type ListBlockedUsersError = GithubOpError;
/** List users blocked by an organization List the users blocked by an organization. */
export declare const listBlockedUsers: API.PaginatedOperationMethod<ListBlockedUsersRequest, ListBlockedUsersResponse, ListBlockedUsersError, GithubOpContext, SimpleUser>;
export type ListFailedInvitationsError = GithubOpError;
/** List failed organization invitations The return hash contains `failed_at` and `failed_reason` fields which represent the time at which the invitation failed and the reason for the failure. */
export declare const listFailedInvitations: API.PaginatedOperationMethod<ListFailedInvitationsRequest, ListFailedInvitationsResponse, ListFailedInvitationsError, GithubOpContext, OrganizationInvitation>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List organizations for the authenticated user List organizations for the authenticated user. For OAuth app tokens and personal access tokens (classic), this endpoint only lists organizations that your authorization allows you to operate on in some way (e.g., you can list teams with `read:org` scope, you can publicize your organization membership with `user` scope, etc.). Therefore, this API requires at least `user` or `read:org` scope for OAuth app tokens and personal access tokens (classic). Requests with insufficient scope will receive a `403 Forbidden` response. > [!NOTE] > Requests using a fine-grained access token will receive a `200 Success` response with an empty list. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, OrganizationSimple>;
export type ListForUserError = GithubOpError;
/** List organizations for a user List [public organization memberships](https://docs.github.com/articles/publicizing-or-concealing-organization-membership) for the specified user. This method only lists _public_ memberships, regardless of authentication. If you need to fetch all of the organization memberships (public and private) for the authenticated user, use the [List organizations for the authenticated user](https://docs.github.com/rest/orgs/orgs#list-organizations-for-the-authenticated-user) API instead. */
export declare const listForUser: API.PaginatedOperationMethod<ListForUserRequest, ListForUserResponse, ListForUserError, GithubOpContext, OrganizationSimple>;
export type ListInvitationTeamsError = GithubOpError;
/** List organization invitation teams List all teams associated with an invitation. In order to see invitations in an organization, the authenticated user must be an organization owner. */
export declare const listInvitationTeams: API.PaginatedOperationMethod<ListInvitationTeamsRequest, ListInvitationTeamsResponse, ListInvitationTeamsError, GithubOpContext, Team>;
export type ListIssueFieldsError = GithubOpError;
/** List issue fields for an organization Lists all issue fields for an organization. OAuth app tokens and personal access tokens (classic) need the read:org scope to use this endpoint. */
export declare const listIssueFields: API.OperationMethod<ListIssueFieldsRequest, ListIssueFieldsResponse, ListIssueFieldsError, GithubOpContext>;
export type ListIssueTypesError = GithubOpError;
/** List issue types for an organization Lists all issue types for an organization. OAuth app tokens and personal access tokens (classic) need the read:org scope to use this endpoint. */
export declare const listIssueTypes: API.OperationMethod<ListIssueTypesRequest, ListIssueTypesResponse, ListIssueTypesError, GithubOpContext>;
export type ListMembersError = GithubOpError;
/** List organization members List all users who are members of an organization. If the authenticated user is also a member of this organization then both concealed and public members will be returned. */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, GithubOpContext, SimpleUser>;
export type ListMembershipsForAuthenticatedUserError = GithubOpError;
/** List organization memberships for the authenticated user Lists all of the authenticated user's organization memberships. */
export declare const listMembershipsForAuthenticatedUser: API.PaginatedOperationMethod<ListMembershipsForAuthenticatedUserRequest, ListMembershipsForAuthenticatedUserResponse, ListMembershipsForAuthenticatedUserError, GithubOpContext, OrgMembership>;
export type ListOrgRolesError = GithubOpError;
/** Get all organization roles for an organization Lists the organization roles available in this organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." To use this endpoint, the authenticated user must be one of: - An administrator for the organization. - An organization member (or a member of a team) assigned a custom organization role that includes the **View organization roles** (`read_organization_custom_org_role`) permission. For more information, see "[Permissions for organization access](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/permissions-of-custom-organization-roles#permissions-for-organization-access)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgRoles: API.OperationMethod<ListOrgRolesRequest, ListOrgRolesResponse, ListOrgRolesError, GithubOpContext>;
export type ListOrgRoleTeamsError = GithubOpError;
/** List teams that are assigned to an organization role Lists the teams that are assigned to an organization role. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." To use this endpoint, you must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgRoleTeams: API.PaginatedOperationMethod<ListOrgRoleTeamsRequest, ListOrgRoleTeamsResponse, ListOrgRoleTeamsError, GithubOpContext, TeamRoleAssignment>;
export type ListOrgRoleUsersError = GithubOpError;
/** List users that are assigned to an organization role Lists organization members that are assigned to an organization role. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." To use this endpoint, you must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgRoleUsers: API.PaginatedOperationMethod<ListOrgRoleUsersRequest, ListOrgRoleUsersResponse, ListOrgRoleUsersError, GithubOpContext, UserRoleAssignment>;
export type ListOutsideCollaboratorsError = GithubOpError;
/** List outside collaborators for an organization List all users who are outside collaborators of an organization. */
export declare const listOutsideCollaborators: API.PaginatedOperationMethod<ListOutsideCollaboratorsRequest, ListOutsideCollaboratorsResponse, ListOutsideCollaboratorsError, GithubOpContext, SimpleUser>;
export type ListPatGrantRepositoriesError = GithubOpError;
/** List repositories a fine-grained personal access token has access to Lists the repositories a fine-grained personal access token has access to. Only GitHub Apps can use this endpoint. */
export declare const listPatGrantRepositories: API.PaginatedOperationMethod<ListPatGrantRepositoriesRequest, ListPatGrantRepositoriesResponse, ListPatGrantRepositoriesError, GithubOpContext, MinimalRepository>;
export type ListPatGrantRequestRepositoriesError = GithubOpError;
/** List repositories requested to be accessed by a fine-grained personal access token Lists the repositories a fine-grained personal access token request is requesting access to. Only GitHub Apps can use this endpoint. */
export declare const listPatGrantRequestRepositories: API.PaginatedOperationMethod<ListPatGrantRequestRepositoriesRequest, ListPatGrantRequestRepositoriesResponse, ListPatGrantRequestRepositoriesError, GithubOpContext, MinimalRepository>;
export type ListPatGrantRequestsError = GithubOpError;
/** List requests to access organization resources with fine-grained personal access tokens Lists requests from organization members to access organization resources with a fine-grained personal access token. Only GitHub Apps can use this endpoint. */
export declare const listPatGrantRequests: API.PaginatedOperationMethod<ListPatGrantRequestsRequest, ListPatGrantRequestsResponse, ListPatGrantRequestsError, GithubOpContext, OrganizationProgrammaticAccessGrantRequest>;
export type ListPatGrantsError = GithubOpError;
/** List fine-grained personal access tokens with access to organization resources Lists approved fine-grained personal access tokens owned by organization members that can access organization resources. Only GitHub Apps can use this endpoint. */
export declare const listPatGrants: API.PaginatedOperationMethod<ListPatGrantsRequest, ListPatGrantsResponse, ListPatGrantsError, GithubOpContext, OrganizationProgrammaticAccessGrant>;
export type ListPendingInvitationsError = GithubOpError;
/** List pending organization invitations The return hash contains a `role` field which refers to the Organization Invitation role and will be one of the following values: `direct_member`, `admin`, `billing_manager`, or `hiring_manager`. If the invitee is not a GitHub member, the `login` field in the return hash will be `null`. */
export declare const listPendingInvitations: API.PaginatedOperationMethod<ListPendingInvitationsRequest, ListPendingInvitationsResponse, ListPendingInvitationsError, GithubOpContext, OrganizationInvitation>;
export type ListPublicMembersError = GithubOpError;
/** List public organization members Members of an organization can choose to have their membership publicized or not. */
export declare const listPublicMembers: API.PaginatedOperationMethod<ListPublicMembersRequest, ListPublicMembersResponse, ListPublicMembersError, GithubOpContext, SimpleUser>;
export type ListWebhookDeliveriesError = GithubOpError;
/** List deliveries for an organization webhook Returns a list of webhook deliveries for a webhook configured in an organization. You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const listWebhookDeliveries: API.OperationMethod<ListWebhookDeliveriesRequest, ListWebhookDeliveriesResponse, ListWebhookDeliveriesError, GithubOpContext>;
export type ListWebhooksError = GithubOpError;
/** List organization webhooks List webhooks for an organization. The authenticated user must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const listWebhooks: API.PaginatedOperationMethod<ListWebhooksRequest, ListWebhooksResponse, ListWebhooksError, GithubOpContext, OrgHook>;
export type PingWebhookError = GithubOpError;
/** Ping an organization webhook This will trigger a [ping event](https://docs.github.com/webhooks/#ping-event) to be sent to the hook. You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const pingWebhook: API.OperationMethod<PingWebhookRequest, PingWebhookResponse, PingWebhookError, GithubOpContext>;
export type RedeliverWebhookDeliveryError = GithubOpError;
/** Redeliver a delivery for an organization webhook Redeliver a delivery for a webhook configured in an organization. You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const redeliverWebhookDelivery: API.OperationMethod<RedeliverWebhookDeliveryRequest, RedeliverWebhookDeliveryResponse, RedeliverWebhookDeliveryError, GithubOpContext>;
export type RemoveMemberError = GithubOpError;
/** Remove an organization member Removing a user from this list will remove them from all teams and they will no longer have any access to the organization's repositories. > [!NOTE] > If a user has both direct membership in the organization as well as indirect membership via an enterprise team, only their direct membership will be removed. Their indirect membership via an enterprise team remains until the user is removed from the enterprise team. */
export declare const removeMember: API.OperationMethod<RemoveMemberRequest, RemoveMemberResponse, RemoveMemberError, GithubOpContext>;
export type RemoveMembershipForUserError = GithubOpError;
/** Remove organization membership for a user In order to remove a user's membership with an organization, the authenticated user must be an organization owner. If the specified user is an active member of the organization, this will remove them from the organization. If the specified user has been invited to the organization, this will cancel their invitation. The specified user will receive an email notification in both cases. > [!NOTE] > If a user has both direct membership in the organization as well as indirect membership via an enterprise team, only their direct membership will be removed. Their indirect membership via an enterprise team remains until the user is removed from the enterprise team. */
export declare const removeMembershipForUser: API.OperationMethod<RemoveMembershipForUserRequest, RemoveMembershipForUserResponse, RemoveMembershipForUserError, GithubOpContext>;
export type RemoveOutsideCollaboratorError = GithubOpError;
/** Remove outside collaborator from an organization Removing a user from this list will remove them from all the organization's repositories. */
export declare const removeOutsideCollaborator: API.OperationMethod<RemoveOutsideCollaboratorRequest, RemoveOutsideCollaboratorResponse, RemoveOutsideCollaboratorError, GithubOpContext>;
export type RemovePublicMembershipForAuthenticatedUserError = GithubOpError;
/** Remove public organization membership for the authenticated user Removes the public membership for the authenticated user from the specified organization, unless public visibility is enforced by default. */
export declare const removePublicMembershipForAuthenticatedUser: API.OperationMethod<RemovePublicMembershipForAuthenticatedUserRequest, RemovePublicMembershipForAuthenticatedUserResponse, RemovePublicMembershipForAuthenticatedUserError, GithubOpContext>;
export type ReviewPatGrantRequestError = GithubOpError;
/** Review a request to access organization resources with a fine-grained personal access token Approves or denies a pending request to access organization resources via a fine-grained personal access token. Only GitHub Apps can use this endpoint. */
export declare const reviewPatGrantRequest: API.OperationMethod<ReviewPatGrantRequestRequest, ReviewPatGrantRequestResponse, ReviewPatGrantRequestError, GithubOpContext>;
export type RevokeAllOrgRolesTeamError = GithubOpError;
/** Remove all organization roles for a team Removes all assigned organization roles from a team. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const revokeAllOrgRolesTeam: API.OperationMethod<RevokeAllOrgRolesTeamRequest, RevokeAllOrgRolesTeamResponse, RevokeAllOrgRolesTeamError, GithubOpContext>;
export type RevokeAllOrgRolesUserError = GithubOpError;
/** Remove all organization roles for a user Revokes all assigned organization roles from a user. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const revokeAllOrgRolesUser: API.OperationMethod<RevokeAllOrgRolesUserRequest, RevokeAllOrgRolesUserResponse, RevokeAllOrgRolesUserError, GithubOpContext>;
export type RevokeOrgRoleTeamError = GithubOpError;
/** Remove an organization role from a team Removes an organization role from a team. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const revokeOrgRoleTeam: API.OperationMethod<RevokeOrgRoleTeamRequest, RevokeOrgRoleTeamResponse, RevokeOrgRoleTeamError, GithubOpContext>;
export type RevokeOrgRoleUserError = GithubOpError;
/** Remove an organization role from a user Remove an organization role from a user. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)." The authenticated user must be an administrator for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const revokeOrgRoleUser: API.OperationMethod<RevokeOrgRoleUserRequest, RevokeOrgRoleUserResponse, RevokeOrgRoleUserError, GithubOpContext>;
export type SetClusterDeploymentRecordsError = GithubOpError;
/** Set cluster deployment records Set deployment records for a given cluster. If proposed records in the 'deployments' field have identical 'cluster', 'logical_environment', 'physical_environment', and 'deployment_name' values as existing records, the existing records will be updated. If no existing records match, new records will be created. Note: Artifacts are uniquely identified by the combination of their repository and digest fields. If two entries in the deployments array resolve to the same repository and have identical digest fields but differing name and version fields, the endpoint will use the artifact name and version from the record processed first, since a single artifact (identified by repository and digest) can only have one name and version. */
export declare const setClusterDeploymentRecords: API.OperationMethod<SetClusterDeploymentRecordsRequest, SetClusterDeploymentRecordsResponse, SetClusterDeploymentRecordsError, GithubOpContext>;
export type SetImmutableReleasesSettingsError = GithubOpError;
/** Set immutable releases settings for an organization Sets the immutable releases policy for repositories in an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setImmutableReleasesSettings: API.OperationMethod<SetImmutableReleasesSettingsRequest, SetImmutableReleasesSettingsResponse, SetImmutableReleasesSettingsError, GithubOpContext>;
export type SetImmutableReleasesSettingsRepositoriesError = GithubOpError;
/** Set selected repositories for immutable releases enforcement Replaces all repositories that have been selected for immutable releases enforcement in an organization. To use this endpoint, the organization immutable releases policy for `enforced_repositories` must be configured to `selected`. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setImmutableReleasesSettingsRepositories: API.OperationMethod<SetImmutableReleasesSettingsRepositoriesRequest, SetImmutableReleasesSettingsRepositoriesResponse, SetImmutableReleasesSettingsRepositoriesError, GithubOpContext>;
export type SetMembershipForUserError = GithubOpError;
/** Set organization membership for a user Only authenticated organization owners can add a member to the organization or update the member's role. * If the authenticated user is _adding_ a member to the organization, the invited user will receive an email inviting them to the organization. The user's [membership status](https://docs.github.com/rest/orgs/members#get-organization-membership-for-a-user) will be `pending` until they accept the invitation. * Authenticated users can _update_ a user's membership by passing the `role` parameter. If the authenticated user changes a member's role to `admin`, the affected user will receive an email notifying them that they've been made an organization owner. If the authenticated user changes an owner's role to `member`, no email will be sent. **Rate limits** To prevent abuse, organization owners are limited to creating 50 organization invitations for an organization within a 24 hour period. If the organization is more than one month old or on a paid plan, the limit is 500 invitations per 24 hour period. */
export declare const setMembershipForUser: API.OperationMethod<SetMembershipForUserRequest, OrgMembership, SetMembershipForUserError, GithubOpContext>;
export type SetPublicMembershipForAuthenticatedUserError = GithubOpError;
/** Set public organization membership for the authenticated user The user can publicize their own membership. (A user cannot publicize the membership for another user.) Note that you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." */
export declare const setPublicMembershipForAuthenticatedUser: API.OperationMethod<SetPublicMembershipForAuthenticatedUserRequest, SetPublicMembershipForAuthenticatedUserResponse, SetPublicMembershipForAuthenticatedUserError, GithubOpContext>;
export type UnblockUserError = GithubOpError;
/** Unblock a user from an organization Unblocks the given user on behalf of the specified organization. */
export declare const unblockUser: API.OperationMethod<UnblockUserRequest, UnblockUserResponse, UnblockUserError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update an organization > [!WARNING] > **Closing down notice:** GitHub will replace and discontinue `members_allowed_repository_creation_type` in favor of more granular permissions. The new input parameters are `members_can_create_public_repositories`, `members_can_create_private_repositories` for all organizations and `members_can_create_internal_repositories` for organizations associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+. For more information, see the [blog post](https://developer.github.com/changes/2019-12-03-internal-visibility-changes). > [!WARNING] > **Closing down notice:** Code security product enablement for new repositories through the organization API is closing down. Please use [code security configurations](https://docs.github.com/rest/code-security/configurations#set-a-code-security-configuration-as-a-default-for-an-organization) to set defaults instead. For more information on setting a default security configuration, see the [changelog](https://github.blog/changelog/2024-07-09-sunsetting-security-settings-defaults-parameters-in-the-organizations-rest-api/). Updates the organization's profile and member privileges. The authenticated user must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` or `repo` scope to use this endpoint. */
export declare const update: API.OperationMethod<UpdateRequest, OrganizationFull, UpdateError, GithubOpContext>;
export type UpdateIssueFieldError = GithubOpError;
/** Update issue field for an organization Updates an issue field for an organization. You can find out more about issue fields in [Managing issue fields in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/using-issues/managing-issue-fields-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const updateIssueField: API.OperationMethod<UpdateIssueFieldRequest, IssueField, UpdateIssueFieldError, GithubOpContext>;
export type UpdateIssueTypeError = GithubOpError;
/** Update issue type for an organization Updates an issue type for an organization. You can find out more about issue types in [Managing issue types in an organization](https://docs.github.com/issues/tracking-your-work-with-issues/configuring-issues/managing-issue-types-in-an-organization). To use this endpoint, the authenticated user must be an administrator for the organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const updateIssueType: API.OperationMethod<UpdateIssueTypeRequest, IssueType, UpdateIssueTypeError, GithubOpContext>;
export type UpdateMembershipForAuthenticatedUserError = GithubOpError;
/** Update an organization membership for the authenticated user Converts the authenticated user to an active member of the organization, if that user has a pending invitation from the organization. */
export declare const updateMembershipForAuthenticatedUser: API.OperationMethod<UpdateMembershipForAuthenticatedUserRequest, OrgMembership, UpdateMembershipForAuthenticatedUserError, GithubOpContext>;
export type UpdatePatAccessError = GithubOpError;
/** Update the access a fine-grained personal access token has to organization resources Updates the access an organization member has to organization resources via a fine-grained personal access token. Limited to revoking the token's existing access. Limited to revoking a token's existing access. Only GitHub Apps can use this endpoint. */
export declare const updatePatAccess: API.OperationMethod<UpdatePatAccessRequest, UpdatePatAccessResponse, UpdatePatAccessError, GithubOpContext>;
export type UpdatePatAccessesError = GithubOpError;
/** Update the access to organization resources via fine-grained personal access tokens Updates the access organization members have to organization resources via fine-grained personal access tokens. Limited to revoking a token's existing access. Only GitHub Apps can use this endpoint. */
export declare const updatePatAccesses: API.OperationMethod<UpdatePatAccessesRequest, UpdatePatAccessesResponse, UpdatePatAccessesError, GithubOpContext>;
export type UpdateWebhookError = GithubOpError;
/** Update an organization webhook Updates a webhook configured in an organization. When you update a webhook, the `secret` will be overwritten. If you previously had a `secret` set, you must provide the same `secret` or set a new `secret` or the secret will be removed. If you are only updating individual webhook `config` properties, use "[Update a webhook configuration for an organization](/rest/orgs/webhooks#update-a-webhook-configuration-for-an-organization)". You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookRequest, OrgHook, UpdateWebhookError, GithubOpContext>;
export type UpdateWebhookConfigForOrgError = GithubOpError;
/** Update a webhook configuration for an organization Updates the webhook configuration for an organization. To update more information about the webhook, including the `active` state and `events`, use "[Update an organization webhook ](/rest/orgs/webhooks#update-an-organization-webhook)." You must be an organization owner to use this endpoint. OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps. */
export declare const updateWebhookConfigForOrg: API.OperationMethod<UpdateWebhookConfigForOrgRequest, WebhookConfig, UpdateWebhookConfigForOrgError, GithubOpContext>;
//# sourceMappingURL=orgs.d.ts.map