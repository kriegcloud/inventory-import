import * as Layer from "effect/Layer";
import { Database } from "./Database.ts";
/**
 * Local `bun:sqlite` database layer for Better Auth — development and
 * tests on the bun runtime only (a deployed Worker/Lambda cannot open a
 * local SQLite file).
 *
 * Data persists in the file across runs; migrations run against the same
 * file at deploy time.
 *
 *
 * ### Local development
 * **Example:** File-backed auth for `alchemy dev`
 * ```typescript
 * import { BetterAuth } from "@alchemy.run/better-auth";
 * import { SQLite } from "@alchemy.run/better-auth/SQLite";
 *
 * Effect.gen(function* () {
 *   const auth = yield* BetterAuth({ emailAndPassword: { enabled: true } });
 *   // ...
 * }).pipe(Effect.provide(SQLite(".alchemy/auth.sqlite")))
 * ```
 *
 * @param filename SQLite file path (parent directory must exist). Defaults to
 * `better-auth.sqlite` under the resolved `AlchemyContext.dotAlchemy` directory.
 * @default ".alchemy/better-auth.sqlite"
 *
 * @layer
 * @provides BetterAuth.Database
 * @product SQLite
 */
export declare const SQLite: (filename?: string) => Layer.Layer<Database>;
//# sourceMappingURL=SQLite.d.ts.map