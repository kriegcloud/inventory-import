import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as Aggregate from "./Aggregate.ts";
import type * as Decision from "./Decision.ts";
import type { Verdict } from "./Prove/internal/Check.ts";
import * as Suggest from "./Prove/internal/Suggest.ts";
export type { Counterexample, Verdict } from "./Prove/internal/Check.ts";
export type { Suggestion } from "./Prove/internal/Suggest.ts";
export interface Options {
    /** The file the aggregate is declared in: `new URL("../src/Account.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
    /**
     * The decisions that record on the aggregate, each with the file it is
     * declared in. An aggregate that folds an event none of its own commands
     * records is proved only with the decision that records it.
     */
    readonly decisions?: ReadonlyArray<{
        readonly decision: Decision.Any;
        readonly source: URL | string;
    }>;
    /**
     * Look for an invariant to add where a proof fails from a state the rules
     * allow.
     * @default true
     */
    readonly suggest?: boolean;
}
/** Where a decision is declared. */
export interface DecisionOptions {
    /** The file the decision is declared in: `new URL("../src/Transfer.decision.ts", import.meta.url)`, or a path. */
    readonly source: URL | string;
}
declare const DecisionNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DecisionNotProved";
} & Readonly<A>;
/** At least one rule a decision must keep is not proved. The message is the report. */
export declare class DecisionNotProved extends DecisionNotProved_base<{
    readonly message: string;
    readonly report: DecisionReport;
}> {
}
export interface DecisionReport {
    /** The tag of the command the decision implements. */
    readonly decision: string;
    /** The aggregates it reads, each under the name `decide` reads it by. */
    readonly reads: ReadonlyArray<{
        readonly name: string;
        readonly aggregate: string;
    }>;
    /** The paths through the decision that were checked. */
    readonly paths: number;
    /** Whether every state the decision leaves is one its aggregate's schema allows. */
    readonly schema: Verdict;
    /**
     * Whether some states let the decision record an event. `false` when none
     * does, `undefined` when the prover could not tell.
     */
    readonly accepted: boolean | undefined;
    /**
     * Every rule the decision must keep: the invariants and transitions of the
     * aggregates it reads, named `Account.NeverOverdrawn`, then its own
     * transitions.
     */
    readonly rules: ReadonlyArray<{
        readonly name: string;
        readonly kind: "invariant" | "transition" | "decision";
        readonly verdict: Verdict;
    }>;
    /** The checks of the schemas the prover does not read. */
    readonly unread: ReadonlyArray<string>;
    /** What the decision writes to a part of a state whose schema has a check the prover does not read. */
    readonly unkept: ReadonlyArray<string>;
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
declare const ProveError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ProveError";
} & Readonly<A>;
/** The prover could not start: a file did not load, or the solver is missing. */
export declare class ProveError extends ProveError_base<{
    readonly message: string;
}> {
}
declare const InvariantsNotProved_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvariantsNotProved";
} & Readonly<A>;
/** At least one invariant is not proved. The message is the report. */
export declare class InvariantsNotProved extends InvariantsNotProved_base<{
    readonly message: string;
    readonly report: Report;
}> {
}
export interface Report {
    readonly aggregate: string;
    /** Whether the aggregate's initial state is one its state's schema allows. */
    readonly initial: boolean;
    readonly commands: ReadonlyArray<{
        readonly command: string;
        /** The paths through the command that were checked. */
        readonly paths: number;
        /**
         * Whether every state the command leaves is one the state's schema allows.
         * Each proof starts from a state in the schema, so the proofs follow one
         * another only when every command keeps the state there.
         */
        readonly schema: Verdict;
        /**
         * Whether some state lets the command record an event. `false` when none
         * does: the command is proved to keep every invariant only because it
         * never does anything. `undefined` when the prover could not tell.
         */
        readonly accepted: boolean | undefined;
    }>;
    readonly invariants: ReadonlyArray<{
        readonly name: string;
        /** Whether the invariant holds on the aggregate's initial state. */
        readonly initial: boolean;
        readonly commands: ReadonlyArray<{
            readonly command: string;
            readonly verdict: Verdict;
            /** The paths through the command that were checked. */
            readonly paths: number;
        }>;
        /**
         * Where the proof fails from a state the rules allow: an invariant that
         * rules that state out and that every command keeps. With it written
         * down, this one is proved. `undefined` where no simple one does.
         */
        readonly suggested: Suggest.Suggestion | undefined;
    }>;
    /** The aggregate's transitions: what each command may do in one step. */
    readonly transitions: ReadonlyArray<{
        readonly name: string;
        readonly commands: ReadonlyArray<{
            readonly command: string;
            readonly verdict: Verdict;
            /** The paths through the command that were checked. */
            readonly paths: number;
        }>;
        /** An invariant that makes it proved, as for an invariant. */
        readonly suggested: Suggest.Suggestion | undefined;
    }>;
    /**
     * The checks of the state's and the commands' schemas the prover does not
     * read, each with the part it is on. A value such a check refuses may be
     * tried, so a counterexample that needs one is not confirmed.
     */
    readonly unread: ReadonlyArray<string>;
    /**
     * What a command writes to a part of the state whose schema has a check
     * the prover does not read: the new value is not proved to pass it.
     */
    readonly unkept: ReadonlyArray<string>;
    /**
     * The events the aggregate folds that none of its commands records, and no
     * decision given in `decisions` does: a decision records them, and nothing
     * here says what it does to the invariants.
     */
    readonly outside: ReadonlyArray<string>;
    /**
     * How far the prover's reading was held against the real code: on inputs
     * picked for each path through a command, the real `decide` and `evolve`
     * were run. `differs` names each path where they did something else.
     */
    readonly agreement: {
        /** The paths inputs were picked and run for. */
        readonly compared: number;
        /** The paths inputs take that could not be run on the real code. */
        readonly uncompared: number;
        readonly differs: ReadonlyArray<string>;
    };
    /** What the proof takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
/** What a decision's proof takes for granted of the platform that commits it. */
export declare const ATOMIC = "a decision's events commit on every instance it recorded on, or on none: how a platform commits them is not checked";
/**
 * Check every invariant of an aggregate against every command, and say what
 * was proved, what was broken, and what the prover could not read.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.report(Account, {
 *   source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 * });
 * console.log(Prove.render(report));
 * ```
 */
export declare const report: (aggregate: Aggregate.Any, options: Options) => Effect.Effect<Report, ProveError, FileSystem.FileSystem | Path.Path>;
/**
 * Whether a report proves every invariant for every command: each command
 * keeps the state in its schema and keeps every invariant, and each can
 * record an event from some state.
 */
export declare const proved: (report: Report) => boolean;
/**
 * Prove every invariant of an aggregate, or fail with the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("the account's invariants hold", () =>
 *   Prove.invariants(Account, {
 *     source: new URL("../src/Account/Account.aggregate.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const invariants: (aggregate: Aggregate.Any, options: Options) => Effect.Effect<Report, ProveError | InvariantsNotProved, FileSystem.FileSystem | Path.Path>;
/** A report as text, one invariant after another. */
export declare const render: (report: Report) => string;
/** An invariant to add, as lines of a report. */
export declare const suggestion: (suggested: Suggest.Suggestion, indent: string) => ReadonlyArray<string>;
/** How far a report's reading was held against the real code, as a line. */
export declare const agreed: (agreement: {
    readonly compared: number;
    readonly uncompared: number;
    readonly differs: ReadonlyArray<string>;
}) => string;
/**
 * Check a decision against every rule it must keep, and say what was proved,
 * what was broken, and what the prover could not read. The rules are the
 * invariants and transitions of each aggregate it reads, on the instance it
 * recorded on, and its own transitions, on all of them together.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Prove.decisionReport(Transfer, {
 *   source: new URL("../src/Transfer/Transfer.decision.ts", import.meta.url),
 * });
 * console.log(Prove.renderDecision(report));
 * ```
 */
export declare const decisionReport: (decision: Decision.Any, options: DecisionOptions) => Effect.Effect<DecisionReport, ProveError, FileSystem.FileSystem | Path.Path>;
/**
 * Whether a report proves a decision: it keeps every state in its schema,
 * keeps every rule, and can record an event from some states.
 */
export declare const decisionProved: (report: DecisionReport) => boolean;
/**
 * Prove that a decision keeps every rule of the aggregates it reads, and its
 * own, or fail with the report.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("a transfer keeps both accounts' rules", () =>
 *   Prove.decision(Transfer, {
 *     source: new URL("../src/Transfer/Transfer.decision.ts", import.meta.url),
 *   }).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const decision: (decision: Decision.Any, options: DecisionOptions) => Effect.Effect<DecisionReport, ProveError | DecisionNotProved, FileSystem.FileSystem | Path.Path>;
/** A decision's report as text, one rule after another. */
export declare const renderDecision: (report: DecisionReport) => string;
//# sourceMappingURL=Prove.d.ts.map