import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ADAssessmentLimitExceededException_base: S.TaggedErrorClass<"ADAssessmentLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class ADAssessmentLimitExceededException extends /*@__PURE__*/ ADAssessmentLimitExceededException_base {
}
declare const AuthenticationFailedException_base: S.TaggedErrorClass<"AuthenticationFailedException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class AuthenticationFailedException extends /*@__PURE__*/ AuthenticationFailedException_base {
}
declare const CertificateAlreadyExistsException_base: S.TaggedErrorClass<"CertificateAlreadyExistsException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CertificateAlreadyExistsException extends /*@__PURE__*/ CertificateAlreadyExistsException_base {
}
declare const CertificateDoesNotExistException_base: S.TaggedErrorClass<"CertificateDoesNotExistException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class CertificateDoesNotExistException extends /*@__PURE__*/ CertificateDoesNotExistException_base {
}
declare const CertificateInUseException_base: S.TaggedErrorClass<"CertificateInUseException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class CertificateInUseException extends /*@__PURE__*/ CertificateInUseException_base {
}
declare const CertificateLimitExceededException_base: S.TaggedErrorClass<"CertificateLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class CertificateLimitExceededException extends /*@__PURE__*/ CertificateLimitExceededException_base {
}
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const DirectoryAlreadyInRegionException_base: S.TaggedErrorClass<"DirectoryAlreadyInRegionException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryAlreadyInRegionException extends /*@__PURE__*/ DirectoryAlreadyInRegionException_base {
}
declare const DirectoryAlreadySharedException_base: S.TaggedErrorClass<"DirectoryAlreadySharedException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryAlreadySharedException extends /*@__PURE__*/ DirectoryAlreadySharedException_base {
}
declare const DirectoryDoesNotExistException_base: S.TaggedErrorClass<"DirectoryDoesNotExistException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryDoesNotExistException extends /*@__PURE__*/ DirectoryDoesNotExistException_base {
}
declare const DirectoryInDesiredStateException_base: S.TaggedErrorClass<"DirectoryInDesiredStateException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryInDesiredStateException extends /*@__PURE__*/ DirectoryInDesiredStateException_base {
}
declare const DirectoryLimitExceededException_base: S.TaggedErrorClass<"DirectoryLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryLimitExceededException extends /*@__PURE__*/ DirectoryLimitExceededException_base {
}
declare const DirectoryNotSharedException_base: S.TaggedErrorClass<"DirectoryNotSharedException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryNotSharedException extends /*@__PURE__*/ DirectoryNotSharedException_base {
}
declare const DirectoryUnavailableException_base: S.TaggedErrorClass<"DirectoryUnavailableException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DirectoryUnavailableException extends /*@__PURE__*/ DirectoryUnavailableException_base {
}
declare const DisableAlreadyInProgressException_base: S.TaggedErrorClass<"DisableAlreadyInProgressException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DisableAlreadyInProgressException extends /*@__PURE__*/ DisableAlreadyInProgressException_base {
}
declare const DomainControllerLimitExceededException_base: S.TaggedErrorClass<"DomainControllerLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class DomainControllerLimitExceededException extends /*@__PURE__*/ DomainControllerLimitExceededException_base {
}
declare const EnableAlreadyInProgressException_base: S.TaggedErrorClass<"EnableAlreadyInProgressException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class EnableAlreadyInProgressException extends /*@__PURE__*/ EnableAlreadyInProgressException_base {
}
declare const EntityAlreadyExistsException_base: S.TaggedErrorClass<"EntityAlreadyExistsException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntityAlreadyExistsException extends /*@__PURE__*/ EntityAlreadyExistsException_base {
}
declare const EntityDoesNotExistException_base: S.TaggedErrorClass<"EntityDoesNotExistException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class EntityDoesNotExistException extends /*@__PURE__*/ EntityDoesNotExistException_base {
}
declare const IncompatibleSettingsException_base: S.TaggedErrorClass<"IncompatibleSettingsException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class IncompatibleSettingsException extends /*@__PURE__*/ IncompatibleSettingsException_base {
}
declare const InsufficientPermissionsException_base: S.TaggedErrorClass<"InsufficientPermissionsException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InsufficientPermissionsException extends /*@__PURE__*/ InsufficientPermissionsException_base {
}
declare const InvalidCertificateException_base: S.TaggedErrorClass<"InvalidCertificateException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidCertificateException extends /*@__PURE__*/ InvalidCertificateException_base {
}
declare const InvalidClientAuthStatusException_base: S.TaggedErrorClass<"InvalidClientAuthStatusException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidClientAuthStatusException extends /*@__PURE__*/ InvalidClientAuthStatusException_base {
}
declare const InvalidLDAPSStatusException_base: S.TaggedErrorClass<"InvalidLDAPSStatusException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidLDAPSStatusException extends /*@__PURE__*/ InvalidLDAPSStatusException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPasswordException_base: S.TaggedErrorClass<"InvalidPasswordException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidPasswordException extends /*@__PURE__*/ InvalidPasswordException_base {
}
declare const InvalidTargetException_base: S.TaggedErrorClass<"InvalidTargetException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class InvalidTargetException extends /*@__PURE__*/ InvalidTargetException_base {
}
declare const IpRouteLimitExceededException_base: S.TaggedErrorClass<"IpRouteLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class IpRouteLimitExceededException extends /*@__PURE__*/ IpRouteLimitExceededException_base {
}
declare const NoAvailableCertificateException_base: S.TaggedErrorClass<"NoAvailableCertificateException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class NoAvailableCertificateException extends /*@__PURE__*/ NoAvailableCertificateException_base {
}
declare const OrganizationsException_base: S.TaggedErrorClass<"OrganizationsException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class OrganizationsException extends /*@__PURE__*/ OrganizationsException_base {
}
declare const RegionLimitExceededException_base: S.TaggedErrorClass<"RegionLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class RegionLimitExceededException extends /*@__PURE__*/ RegionLimitExceededException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ShareLimitExceededException_base: S.TaggedErrorClass<"ShareLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class ShareLimitExceededException extends /*@__PURE__*/ ShareLimitExceededException_base {
}
declare const SimpleADClosedToNewCustomers_base: S.TaggedErrorClass<"SimpleADClosedToNewCustomers", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SimpleADClosedToNewCustomers extends /*@__PURE__*/ SimpleADClosedToNewCustomers_base {
}
declare const SnapshotLimitExceededException_base: S.TaggedErrorClass<"SnapshotLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class SnapshotLimitExceededException extends /*@__PURE__*/ SnapshotLimitExceededException_base {
}
declare const TagLimitExceededException_base: S.TaggedErrorClass<"TagLimitExceededException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const UnsupportedSettingsException_base: S.TaggedErrorClass<"UnsupportedSettingsException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class UnsupportedSettingsException extends /*@__PURE__*/ UnsupportedSettingsException_base {
}
declare const UserDoesNotExistException_base: S.TaggedErrorClass<"UserDoesNotExistException", {
    readonly message: any;
    readonly RequestId: any;
}>;
export declare class UserDoesNotExistException extends /*@__PURE__*/ UserDoesNotExistException_base {
}
export type DirectoryId = string;
export interface AcceptSharedDirectoryRequest {
    SharedDirectoryId: string;
}
export type CustomerId = string;
export type ShareMethod = "ORGANIZATIONS" | "HANDSHAKE" | (string & {});
export type ShareStatus = "Shared" | "PendingAcceptance" | "Rejected" | "Rejecting" | "RejectFailed" | "Sharing" | "ShareFailed" | "Deleted" | "Deleting" | (string & {});
export type Notes = string | redacted.Redacted<string>;
export type CreatedDateTime = Date;
export type LastUpdatedDateTime = Date;
export interface SharedDirectory {
    OwnerAccountId?: string | undefined;
    OwnerDirectoryId?: string | undefined;
    ShareMethod?: ShareMethod | undefined;
    SharedAccountId?: string | undefined;
    SharedDirectoryId?: string | undefined;
    ShareStatus?: ShareStatus | undefined;
    ShareNotes?: string | redacted.Redacted<string> | undefined;
    CreatedDateTime?: Date | undefined;
    LastUpdatedDateTime?: Date | undefined;
}
export interface AcceptSharedDirectoryResult {
    SharedDirectory?: SharedDirectory | undefined;
}
export type CidrIp = string;
export type CidrIpv6 = string;
export type Description = string;
export interface IpRoute {
    CidrIp?: string | undefined;
    CidrIpv6?: string | undefined;
    Description?: string | undefined;
}
export type IpRoutes = IpRoute[];
export type UpdateSecurityGroupForDirectoryControllers = boolean;
export interface AddIpRoutesRequest {
    DirectoryId: string;
    IpRoutes: IpRoute[];
    UpdateSecurityGroupForDirectoryControllers?: boolean | undefined;
}
export interface AddIpRoutesResult {
}
export type RegionName = string;
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export interface DirectoryVpcSettings {
    VpcId: string;
    SubnetIds: string[];
}
export interface AddRegionRequest {
    DirectoryId: string;
    RegionName: string;
    VPCSettings: DirectoryVpcSettings;
}
export interface AddRegionResult {
}
export type ResourceId = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export interface AddTagsToResourceRequest {
    ResourceId: string;
    Tags: Tag[];
}
export interface AddTagsToResourceResult {
}
export type SchemaExtensionId = string;
export interface CancelSchemaExtensionRequest {
    DirectoryId: string;
    SchemaExtensionId: string;
}
export interface CancelSchemaExtensionResult {
}
export type DirectoryName = string;
export type DirectoryShortName = string;
export type ConnectPassword = string | redacted.Redacted<string>;
export type DirectorySize = "Small" | "Large" | (string & {});
export type IpAddr = string;
export type DnsIpAddrs = string[];
export type Ipv6Addr = string;
export type DnsIpv6Addrs = string[];
export type UserName = string;
export interface DirectoryConnectSettings {
    VpcId: string;
    SubnetIds: string[];
    CustomerDnsIps?: string[] | undefined;
    CustomerDnsIpsV6?: string[] | undefined;
    CustomerUserName: string;
}
export type NetworkType = "Dual-stack" | "IPv4" | "IPv6" | (string & {});
export interface ConnectDirectoryRequest {
    Name: string;
    ShortName?: string | undefined;
    Password: string | redacted.Redacted<string>;
    Description?: string | undefined;
    Size: DirectorySize;
    ConnectSettings: DirectoryConnectSettings;
    Tags?: Tag[] | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface ConnectDirectoryResult {
    DirectoryId?: string | undefined;
}
export type AliasName = string;
export interface CreateAliasRequest {
    DirectoryId: string;
    Alias: string;
}
export interface CreateAliasResult {
    DirectoryId?: string | undefined;
    Alias?: string | undefined;
}
export type ComputerName = string;
export type ComputerPassword = string | redacted.Redacted<string>;
export type OrganizationalUnitDN = string;
export type AttributeName = string;
export type AttributeValue = string;
export interface Attribute {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type Attributes = Attribute[];
export interface CreateComputerRequest {
    DirectoryId: string;
    ComputerName: string;
    Password: string | redacted.Redacted<string>;
    OrganizationalUnitDistinguishedName?: string | undefined;
    ComputerAttributes?: Attribute[] | undefined;
}
export type SID = string;
export interface Computer {
    ComputerId?: string | undefined;
    ComputerName?: string | undefined;
    ComputerAttributes?: Attribute[] | undefined;
}
export interface CreateComputerResult {
    Computer?: Computer | undefined;
}
export type RemoteDomainName = string;
export interface CreateConditionalForwarderRequest {
    DirectoryId: string;
    RemoteDomainName: string;
    DnsIpAddrs?: string[] | undefined;
    DnsIpv6Addrs?: string[] | undefined;
}
export interface CreateConditionalForwarderResult {
}
export type Password = string | redacted.Redacted<string>;
export interface CreateDirectoryRequest {
    Name: string;
    ShortName?: string | undefined;
    Password: string | redacted.Redacted<string>;
    Description?: string | undefined;
    Size: DirectorySize;
    VpcSettings?: DirectoryVpcSettings | undefined;
    Tags?: Tag[] | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateDirectoryResult {
    DirectoryId?: string | undefined;
}
export type SecretArn = string;
export type AssessmentId = string;
export interface CreateHybridADRequest {
    SecretArn: string;
    AssessmentId: string;
    Tags?: Tag[] | undefined;
}
export interface CreateHybridADResult {
    DirectoryId?: string | undefined;
}
export type LogGroupName = string;
export interface CreateLogSubscriptionRequest {
    DirectoryId: string;
    LogGroupName: string;
}
export interface CreateLogSubscriptionResult {
}
export type DirectoryEdition = "Enterprise" | "Standard" | "Hybrid" | (string & {});
export interface CreateMicrosoftADRequest {
    Name: string;
    ShortName?: string | undefined;
    Password: string | redacted.Redacted<string>;
    Description?: string | undefined;
    VpcSettings: DirectoryVpcSettings;
    Edition?: DirectoryEdition | undefined;
    Tags?: Tag[] | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateMicrosoftADResult {
    DirectoryId?: string | undefined;
}
export type SnapshotName = string;
export interface CreateSnapshotRequest {
    DirectoryId: string;
    Name?: string | undefined;
}
export type SnapshotId = string;
export interface CreateSnapshotResult {
    SnapshotId?: string | undefined;
}
export type TrustPassword = string | redacted.Redacted<string>;
export type TrustDirection = "One-Way: Outgoing" | "One-Way: Incoming" | "Two-Way" | (string & {});
export type TrustType = "Forest" | "External" | (string & {});
export type SelectiveAuth = "Enabled" | "Disabled" | (string & {});
export interface CreateTrustRequest {
    DirectoryId: string;
    RemoteDomainName: string;
    TrustPassword: string | redacted.Redacted<string>;
    TrustDirection: TrustDirection;
    TrustType?: TrustType | undefined;
    ConditionalForwarderIpAddrs?: string[] | undefined;
    ConditionalForwarderIpv6Addrs?: string[] | undefined;
    SelectiveAuth?: SelectiveAuth | undefined;
}
export type TrustId = string;
export interface CreateTrustResult {
    TrustId?: string | undefined;
}
export interface DeleteADAssessmentRequest {
    AssessmentId: string;
}
export interface DeleteADAssessmentResult {
    AssessmentId?: string | undefined;
}
export interface DeleteConditionalForwarderRequest {
    DirectoryId: string;
    RemoteDomainName: string;
}
export interface DeleteConditionalForwarderResult {
}
export interface DeleteDirectoryRequest {
    DirectoryId: string;
}
export interface DeleteDirectoryResult {
    DirectoryId?: string | undefined;
}
export interface DeleteLogSubscriptionRequest {
    DirectoryId: string;
}
export interface DeleteLogSubscriptionResult {
}
export interface DeleteSnapshotRequest {
    SnapshotId: string;
}
export interface DeleteSnapshotResult {
    SnapshotId?: string | undefined;
}
export type DeleteAssociatedConditionalForwarder = boolean;
export interface DeleteTrustRequest {
    TrustId: string;
    DeleteAssociatedConditionalForwarder?: boolean | undefined;
}
export interface DeleteTrustResult {
    TrustId?: string | undefined;
}
export type CertificateId = string;
export interface DeregisterCertificateRequest {
    DirectoryId: string;
    CertificateId: string;
}
export interface DeregisterCertificateResult {
}
export type TopicName = string;
export interface DeregisterEventTopicRequest {
    DirectoryId: string;
    TopicName: string;
}
export interface DeregisterEventTopicResult {
}
export interface DescribeADAssessmentRequest {
    AssessmentId: string;
}
export type AssessmentStartTime = Date;
export type LastUpdateDateTime = Date;
export type AssessmentStatus = string;
export type AssessmentStatusCode = string;
export type AssessmentStatusReason = string;
export type CustomerDnsIps = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type AssessmentInstanceId = string;
export type AssessmentInstanceIds = string[];
export type AssessmentReportType = string;
export type AssessmentVersion = string;
export interface Assessment {
    AssessmentId?: string | undefined;
    DirectoryId?: string | undefined;
    DnsName?: string | undefined;
    StartTime?: Date | undefined;
    LastUpdateDateTime?: Date | undefined;
    Status?: string | undefined;
    StatusCode?: string | undefined;
    StatusReason?: string | undefined;
    CustomerDnsIps?: string[] | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    SelfManagedInstanceIds?: string[] | undefined;
    ReportType?: string | undefined;
    Version?: string | undefined;
}
export type AssessmentValidationCategory = string;
export type AssessmentValidationName = string;
export type AssessmentValidationStatus = string;
export type AssessmentValidationStatusCode = string;
export type AssessmentValidationStatusReason = string;
export type AssessmentValidationTimeStamp = Date;
export interface AssessmentValidation {
    Category?: string | undefined;
    Name?: string | undefined;
    Status?: string | undefined;
    StatusCode?: string | undefined;
    StatusReason?: string | undefined;
    StartTime?: Date | undefined;
    LastUpdateDateTime?: Date | undefined;
}
export type AssessmentValidations = AssessmentValidation[];
export interface AssessmentReport {
    DomainControllerIp?: string | undefined;
    Validations?: AssessmentValidation[] | undefined;
}
export type AssessmentReports = AssessmentReport[];
export interface DescribeADAssessmentResult {
    Assessment?: Assessment | undefined;
    AssessmentReports?: AssessmentReport[] | undefined;
}
export interface DescribeCAEnrollmentPolicyRequest {
    DirectoryId: string;
}
export type PcaConnectorArn = string;
export type CaEnrollmentPolicyStatus = "InProgress" | "Success" | "Failed" | "Disabling" | "Disabled" | "Impaired" | (string & {});
export type CaEnrollmentPolicyStatusReason = string;
export interface DescribeCAEnrollmentPolicyResult {
    DirectoryId?: string | undefined;
    PcaConnectorArn?: string | undefined;
    CaEnrollmentPolicyStatus?: CaEnrollmentPolicyStatus | undefined;
    LastUpdatedDateTime?: Date | undefined;
    CaEnrollmentPolicyStatusReason?: string | undefined;
}
export interface DescribeCertificateRequest {
    DirectoryId: string;
    CertificateId: string;
}
export type CertificateState = "Registering" | "Registered" | "RegisterFailed" | "Deregistering" | "Deregistered" | "DeregisterFailed" | (string & {});
export type CertificateStateReason = string;
export type CertificateCN = string;
export type CertificateRegisteredDateTime = Date;
export type CertificateExpiryDateTime = Date;
export type CertificateType = "ClientCertAuth" | "ClientLDAPS" | (string & {});
export type OCSPUrl = string;
export interface ClientCertAuthSettings {
    OCSPUrl?: string | undefined;
}
export interface Certificate {
    CertificateId?: string | undefined;
    State?: CertificateState | undefined;
    StateReason?: string | undefined;
    CommonName?: string | undefined;
    RegisteredDateTime?: Date | undefined;
    ExpiryDateTime?: Date | undefined;
    Type?: CertificateType | undefined;
    ClientCertAuthSettings?: ClientCertAuthSettings | undefined;
}
export interface DescribeCertificateResult {
    Certificate?: Certificate | undefined;
}
export type ClientAuthenticationType = "SmartCard" | "SmartCardOrPassword" | (string & {});
export type NextToken = string;
export type PageLimit = number;
export interface DescribeClientAuthenticationSettingsRequest {
    DirectoryId: string;
    Type?: ClientAuthenticationType | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type ClientAuthenticationStatus = "Enabled" | "Disabled" | (string & {});
export interface ClientAuthenticationSettingInfo {
    Type?: ClientAuthenticationType | undefined;
    Status?: ClientAuthenticationStatus | undefined;
    LastUpdatedDateTime?: Date | undefined;
}
export type ClientAuthenticationSettingsInfo = ClientAuthenticationSettingInfo[];
export interface DescribeClientAuthenticationSettingsResult {
    ClientAuthenticationSettingsInfo?: ClientAuthenticationSettingInfo[] | undefined;
    NextToken?: string | undefined;
}
export type RemoteDomainNames = string[];
export interface DescribeConditionalForwardersRequest {
    DirectoryId: string;
    RemoteDomainNames?: string[] | undefined;
}
export type ReplicationScope = "Domain" | (string & {});
export interface ConditionalForwarder {
    RemoteDomainName?: string | undefined;
    DnsIpAddrs?: string[] | undefined;
    DnsIpv6Addrs?: string[] | undefined;
    ReplicationScope?: ReplicationScope | undefined;
}
export type ConditionalForwarders = ConditionalForwarder[];
export interface DescribeConditionalForwardersResult {
    ConditionalForwarders?: ConditionalForwarder[] | undefined;
}
export type DirectoryIds = string[];
export type Limit = number;
export interface DescribeDirectoriesRequest {
    DirectoryIds?: string[] | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type AccessUrl = string;
export type DirectoryStage = "Requested" | "Creating" | "Created" | "Active" | "Inoperable" | "Impaired" | "Restoring" | "RestoreFailed" | "Deleting" | "Deleted" | "Failed" | "Updating" | (string & {});
export type LaunchTime = Date;
export type DirectoryType = "SimpleAD" | "ADConnector" | "MicrosoftAD" | "SharedMicrosoftAD" | (string & {});
export type AvailabilityZone = string;
export type AvailabilityZones = string[];
export interface DirectoryVpcSettingsDescription {
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupId?: string | undefined;
    AvailabilityZones?: string[] | undefined;
}
export type IpAddrs = string[];
export type IpV6Addrs = string[];
export interface DirectoryConnectSettingsDescription {
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    CustomerUserName?: string | undefined;
    SecurityGroupId?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    ConnectIps?: string[] | undefined;
    ConnectIpsV6?: string[] | undefined;
}
export type Server = string;
export type Servers = string[];
export type PortNumber = number;
export type RadiusTimeout = number;
export type RadiusRetries = number;
export type RadiusSharedSecret = string | redacted.Redacted<string>;
export type RadiusAuthenticationProtocol = "PAP" | "CHAP" | "MS-CHAPv1" | "MS-CHAPv2" | (string & {});
export type RadiusDisplayLabel = string;
export type UseSameUsername = boolean;
export interface RadiusSettings {
    RadiusServers?: string[] | undefined;
    RadiusServersIpv6?: string[] | undefined;
    RadiusPort?: number | undefined;
    RadiusTimeout?: number | undefined;
    RadiusRetries?: number | undefined;
    SharedSecret?: string | redacted.Redacted<string> | undefined;
    AuthenticationProtocol?: RadiusAuthenticationProtocol | undefined;
    DisplayLabel?: string | undefined;
    UseSameUsername?: boolean | undefined;
}
export type RadiusStatus = "Creating" | "Completed" | "Failed" | (string & {});
export type StageReason = string;
export type SsoEnabled = boolean;
export type DesiredNumberOfDomainControllers = number;
export interface OwnerDirectoryDescription {
    DirectoryId?: string | undefined;
    AccountId?: string | undefined;
    DnsIpAddrs?: string[] | undefined;
    DnsIpv6Addrs?: string[] | undefined;
    VpcSettings?: DirectoryVpcSettingsDescription | undefined;
    RadiusSettings?: RadiusSettings | undefined;
    RadiusStatus?: RadiusStatus | undefined;
    NetworkType?: NetworkType | undefined;
}
export type AdditionalRegions = string[];
export interface RegionsInfo {
    PrimaryRegion?: string | undefined;
    AdditionalRegions?: string[] | undefined;
}
export type OSVersion = "SERVER_2012" | "SERVER_2019" | (string & {});
export interface HybridSettingsDescription {
    SelfManagedDnsIpAddrs?: string[] | undefined;
    SelfManagedInstanceIds?: string[] | undefined;
}
export interface DirectoryDescription {
    DirectoryId?: string | undefined;
    Name?: string | undefined;
    ShortName?: string | undefined;
    Size?: DirectorySize | undefined;
    Edition?: DirectoryEdition | undefined;
    Alias?: string | undefined;
    AccessUrl?: string | undefined;
    Description?: string | undefined;
    DnsIpAddrs?: string[] | undefined;
    DnsIpv6Addrs?: string[] | undefined;
    Stage?: DirectoryStage | undefined;
    ShareStatus?: ShareStatus | undefined;
    ShareMethod?: ShareMethod | undefined;
    ShareNotes?: string | redacted.Redacted<string> | undefined;
    LaunchTime?: Date | undefined;
    StageLastUpdatedDateTime?: Date | undefined;
    Type?: DirectoryType | undefined;
    VpcSettings?: DirectoryVpcSettingsDescription | undefined;
    ConnectSettings?: DirectoryConnectSettingsDescription | undefined;
    RadiusSettings?: RadiusSettings | undefined;
    RadiusStatus?: RadiusStatus | undefined;
    StageReason?: string | undefined;
    SsoEnabled?: boolean | undefined;
    DesiredNumberOfDomainControllers?: number | undefined;
    OwnerDirectoryDescription?: OwnerDirectoryDescription | undefined;
    RegionsInfo?: RegionsInfo | undefined;
    OsVersion?: OSVersion | undefined;
    HybridSettings?: HybridSettingsDescription | undefined;
    NetworkType?: NetworkType | undefined;
}
export type DirectoryDescriptions = DirectoryDescription[];
export interface DescribeDirectoriesResult {
    DirectoryDescriptions?: DirectoryDescription[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeDirectoryDataAccessRequest {
    DirectoryId: string;
}
export type DataAccessStatus = "Disabled" | "Disabling" | "Enabled" | "Enabling" | "Failed" | (string & {});
export interface DescribeDirectoryDataAccessResult {
    DataAccessStatus?: DataAccessStatus | undefined;
}
export type DomainControllerId = string;
export type DomainControllerIds = string[];
export interface DescribeDomainControllersRequest {
    DirectoryId: string;
    DomainControllerIds?: string[] | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type DomainControllerStatus = "Creating" | "Active" | "Impaired" | "Restoring" | "Deleting" | "Deleted" | "Failed" | "Updating" | (string & {});
export type DomainControllerStatusReason = string;
export interface DomainController {
    DirectoryId?: string | undefined;
    DomainControllerId?: string | undefined;
    DnsIpAddr?: string | undefined;
    DnsIpv6Addr?: string | undefined;
    VpcId?: string | undefined;
    SubnetId?: string | undefined;
    AvailabilityZone?: string | undefined;
    Status?: DomainControllerStatus | undefined;
    StatusReason?: string | undefined;
    LaunchTime?: Date | undefined;
    StatusLastUpdatedDateTime?: Date | undefined;
}
export type DomainControllers = DomainController[];
export interface DescribeDomainControllersResult {
    DomainControllers?: DomainController[] | undefined;
    NextToken?: string | undefined;
}
export type TopicNames = string[];
export interface DescribeEventTopicsRequest {
    DirectoryId?: string | undefined;
    TopicNames?: string[] | undefined;
}
export type TopicArn = string;
export type TopicStatus = "Registered" | "Topic not found" | "Failed" | "Deleted" | (string & {});
export interface EventTopic {
    DirectoryId?: string | undefined;
    TopicName?: string | undefined;
    TopicArn?: string | undefined;
    CreatedDateTime?: Date | undefined;
    Status?: TopicStatus | undefined;
}
export type EventTopics = EventTopic[];
export interface DescribeEventTopicsResult {
    EventTopics?: EventTopic[] | undefined;
}
export type HybridUpdateType = "SelfManagedInstances" | "HybridAdministratorAccount" | (string & {});
export interface DescribeHybridADUpdateRequest {
    DirectoryId: string;
    UpdateType?: HybridUpdateType | undefined;
    NextToken?: string | undefined;
}
export type UpdateStatus = "Updated" | "Updating" | "UpdateFailed" | (string & {});
export type UpdateStatusReason = string;
export type InitiatedBy = string;
export interface HybridUpdateValue {
    InstanceIds?: string[] | undefined;
    DnsIps?: string[] | undefined;
}
export type StartDateTime = Date;
export interface HybridUpdateInfoEntry {
    Status?: UpdateStatus | undefined;
    StatusReason?: string | undefined;
    InitiatedBy?: string | undefined;
    NewValue?: HybridUpdateValue | undefined;
    PreviousValue?: HybridUpdateValue | undefined;
    StartTime?: Date | undefined;
    LastUpdatedDateTime?: Date | undefined;
    AssessmentId?: string | undefined;
}
export type HybridUpdateInfoEntries = HybridUpdateInfoEntry[];
export interface HybridUpdateActivities {
    SelfManagedInstances?: HybridUpdateInfoEntry[] | undefined;
    HybridAdministratorAccount?: HybridUpdateInfoEntry[] | undefined;
}
export interface DescribeHybridADUpdateResult {
    UpdateActivities?: HybridUpdateActivities | undefined;
    NextToken?: string | undefined;
}
export type LDAPSType = "Client" | (string & {});
export interface DescribeLDAPSSettingsRequest {
    DirectoryId: string;
    Type?: LDAPSType | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type LDAPSStatus = "Enabling" | "Enabled" | "EnableFailed" | "Disabled" | (string & {});
export type LDAPSStatusReason = string;
export interface LDAPSSettingInfo {
    LDAPSStatus?: LDAPSStatus | undefined;
    LDAPSStatusReason?: string | undefined;
    LastUpdatedDateTime?: Date | undefined;
}
export type LDAPSSettingsInfo = LDAPSSettingInfo[];
export interface DescribeLDAPSSettingsResult {
    LDAPSSettingsInfo?: LDAPSSettingInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeRegionsRequest {
    DirectoryId: string;
    RegionName?: string | undefined;
    NextToken?: string | undefined;
}
export type RegionType = "Primary" | "Additional" | (string & {});
export type StateLastUpdatedDateTime = Date;
export interface RegionDescription {
    DirectoryId?: string | undefined;
    RegionName?: string | undefined;
    RegionType?: RegionType | undefined;
    Status?: DirectoryStage | undefined;
    VpcSettings?: DirectoryVpcSettings | undefined;
    DesiredNumberOfDomainControllers?: number | undefined;
    LaunchTime?: Date | undefined;
    StatusLastUpdatedDateTime?: Date | undefined;
    LastUpdatedDateTime?: Date | undefined;
}
export type RegionsDescription = RegionDescription[];
export interface DescribeRegionsResult {
    RegionsDescription?: RegionDescription[] | undefined;
    NextToken?: string | undefined;
}
export type DirectoryConfigurationStatus = "Requested" | "Updating" | "Updated" | "Failed" | "Default" | (string & {});
export interface DescribeSettingsRequest {
    DirectoryId: string;
    Status?: DirectoryConfigurationStatus | undefined;
    NextToken?: string | undefined;
}
export type DirectoryConfigurationSettingType = string;
export type DirectoryConfigurationSettingName = string;
export type DirectoryConfigurationSettingAllowedValues = string;
export type DirectoryConfigurationSettingValue = string;
export type DirectoryConfigurationSettingRequestDetailedStatus = {
    [key: string]: DirectoryConfigurationStatus | undefined;
};
export type DirectoryConfigurationSettingRequestStatusMessage = string;
export type DirectoryConfigurationSettingLastUpdatedDateTime = Date;
export type DirectoryConfigurationSettingLastRequestedDateTime = Date;
export type DirectoryConfigurationSettingDataType = string;
export interface SettingEntry {
    Type?: string | undefined;
    Name?: string | undefined;
    AllowedValues?: string | undefined;
    AppliedValue?: string | undefined;
    RequestedValue?: string | undefined;
    RequestStatus?: DirectoryConfigurationStatus | undefined;
    RequestDetailedStatus?: {
        [key: string]: DirectoryConfigurationStatus | undefined;
    } | undefined;
    RequestStatusMessage?: string | undefined;
    LastUpdatedDateTime?: Date | undefined;
    LastRequestedDateTime?: Date | undefined;
    DataType?: string | undefined;
}
export type SettingEntries = SettingEntry[];
export interface DescribeSettingsResult {
    DirectoryId?: string | undefined;
    SettingEntries?: SettingEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeSharedDirectoriesRequest {
    OwnerDirectoryId: string;
    SharedDirectoryIds?: string[] | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type SharedDirectories = SharedDirectory[];
export interface DescribeSharedDirectoriesResult {
    SharedDirectories?: SharedDirectory[] | undefined;
    NextToken?: string | undefined;
}
export type SnapshotIds = string[];
export interface DescribeSnapshotsRequest {
    DirectoryId?: string | undefined;
    SnapshotIds?: string[] | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type SnapshotType = "Auto" | "Manual" | (string & {});
export type SnapshotStatus = "Creating" | "Completed" | "Failed" | (string & {});
export type StartTime = Date;
export interface Snapshot {
    DirectoryId?: string | undefined;
    SnapshotId?: string | undefined;
    Type?: SnapshotType | undefined;
    Name?: string | undefined;
    Status?: SnapshotStatus | undefined;
    StartTime?: Date | undefined;
}
export type Snapshots = Snapshot[];
export interface DescribeSnapshotsResult {
    Snapshots?: Snapshot[] | undefined;
    NextToken?: string | undefined;
}
export type TrustIds = string[];
export interface DescribeTrustsRequest {
    DirectoryId?: string | undefined;
    TrustIds?: string[] | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type TrustState = "Creating" | "Created" | "Verifying" | "VerifyFailed" | "Verified" | "Updating" | "UpdateFailed" | "Updated" | "Deleting" | "Deleted" | "Failed" | (string & {});
export type TrustStateReason = string;
export interface Trust {
    DirectoryId?: string | undefined;
    TrustId?: string | undefined;
    RemoteDomainName?: string | undefined;
    TrustType?: TrustType | undefined;
    TrustDirection?: TrustDirection | undefined;
    TrustState?: TrustState | undefined;
    CreatedDateTime?: Date | undefined;
    LastUpdatedDateTime?: Date | undefined;
    StateLastUpdatedDateTime?: Date | undefined;
    TrustStateReason?: string | undefined;
    SelectiveAuth?: SelectiveAuth | undefined;
}
export type Trusts = Trust[];
export interface DescribeTrustsResult {
    Trusts?: Trust[] | undefined;
    NextToken?: string | undefined;
}
export type UpdateType = "OS" | "NETWORK" | "SIZE" | (string & {});
export interface DescribeUpdateDirectoryRequest {
    DirectoryId: string;
    UpdateType: UpdateType;
    RegionName?: string | undefined;
    NextToken?: string | undefined;
}
export interface OSUpdateSettings {
    OSVersion?: OSVersion | undefined;
}
export interface UpdateValue {
    OSUpdateSettings?: OSUpdateSettings | undefined;
}
export interface UpdateInfoEntry {
    Region?: string | undefined;
    Status?: UpdateStatus | undefined;
    StatusReason?: string | undefined;
    InitiatedBy?: string | undefined;
    NewValue?: UpdateValue | undefined;
    PreviousValue?: UpdateValue | undefined;
    StartTime?: Date | undefined;
    LastUpdatedDateTime?: Date | undefined;
}
export type UpdateActivities = UpdateInfoEntry[];
export interface DescribeUpdateDirectoryResult {
    UpdateActivities?: UpdateInfoEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface DisableCAEnrollmentPolicyRequest {
    DirectoryId: string;
}
export interface DisableCAEnrollmentPolicyResult {
}
export interface DisableClientAuthenticationRequest {
    DirectoryId: string;
    Type: ClientAuthenticationType;
}
export interface DisableClientAuthenticationResult {
}
export interface DisableDirectoryDataAccessRequest {
    DirectoryId: string;
}
export interface DisableDirectoryDataAccessResult {
}
export interface DisableLDAPSRequest {
    DirectoryId: string;
    Type: LDAPSType;
}
export interface DisableLDAPSResult {
}
export interface DisableRadiusRequest {
    DirectoryId: string;
}
export interface DisableRadiusResult {
}
export interface DisableSsoRequest {
    DirectoryId: string;
    UserName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export interface DisableSsoResult {
}
export interface EnableCAEnrollmentPolicyRequest {
    DirectoryId: string;
    PcaConnectorArn: string;
}
export interface EnableCAEnrollmentPolicyResult {
}
export interface EnableClientAuthenticationRequest {
    DirectoryId: string;
    Type: ClientAuthenticationType;
}
export interface EnableClientAuthenticationResult {
}
export interface EnableDirectoryDataAccessRequest {
    DirectoryId: string;
}
export interface EnableDirectoryDataAccessResult {
}
export interface EnableLDAPSRequest {
    DirectoryId: string;
    Type: LDAPSType;
}
export interface EnableLDAPSResult {
}
export interface EnableRadiusRequest {
    DirectoryId: string;
    RadiusSettings: RadiusSettings;
}
export interface EnableRadiusResult {
}
export interface EnableSsoRequest {
    DirectoryId: string;
    UserName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export interface EnableSsoResult {
}
export interface GetDirectoryLimitsRequest {
}
export type CloudOnlyDirectoriesLimitReached = boolean;
export type ConnectedDirectoriesLimitReached = boolean;
export interface DirectoryLimits {
    CloudOnlyDirectoriesLimit?: number | undefined;
    CloudOnlyDirectoriesCurrentCount?: number | undefined;
    CloudOnlyDirectoriesLimitReached?: boolean | undefined;
    CloudOnlyMicrosoftADLimit?: number | undefined;
    CloudOnlyMicrosoftADCurrentCount?: number | undefined;
    CloudOnlyMicrosoftADLimitReached?: boolean | undefined;
    ConnectedDirectoriesLimit?: number | undefined;
    ConnectedDirectoriesCurrentCount?: number | undefined;
    ConnectedDirectoriesLimitReached?: boolean | undefined;
}
export interface GetDirectoryLimitsResult {
    DirectoryLimits?: DirectoryLimits | undefined;
}
export interface GetSnapshotLimitsRequest {
    DirectoryId: string;
}
export type ManualSnapshotsLimitReached = boolean;
export interface SnapshotLimits {
    ManualSnapshotsLimit?: number | undefined;
    ManualSnapshotsCurrentCount?: number | undefined;
    ManualSnapshotsLimitReached?: boolean | undefined;
}
export interface GetSnapshotLimitsResult {
    SnapshotLimits?: SnapshotLimits | undefined;
}
export type AssessmentLimit = number;
export interface ListADAssessmentsRequest {
    DirectoryId?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface AssessmentSummary {
    AssessmentId?: string | undefined;
    DirectoryId?: string | undefined;
    DnsName?: string | undefined;
    StartTime?: Date | undefined;
    LastUpdateDateTime?: Date | undefined;
    Status?: string | undefined;
    CustomerDnsIps?: string[] | undefined;
    ReportType?: string | undefined;
}
export type Assessments = AssessmentSummary[];
export interface ListADAssessmentsResult {
    Assessments?: AssessmentSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCertificatesRequest {
    DirectoryId: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface CertificateInfo {
    CertificateId?: string | undefined;
    CommonName?: string | undefined;
    State?: CertificateState | undefined;
    ExpiryDateTime?: Date | undefined;
    Type?: CertificateType | undefined;
}
export type CertificatesInfo = CertificateInfo[];
export interface ListCertificatesResult {
    NextToken?: string | undefined;
    CertificatesInfo?: CertificateInfo[] | undefined;
}
export interface ListIpRoutesRequest {
    DirectoryId: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type IpRouteStatusMsg = "Adding" | "Added" | "Removing" | "Removed" | "AddFailed" | "RemoveFailed" | (string & {});
export type AddedDateTime = Date;
export type IpRouteStatusReason = string;
export interface IpRouteInfo {
    DirectoryId?: string | undefined;
    CidrIp?: string | undefined;
    CidrIpv6?: string | undefined;
    IpRouteStatusMsg?: IpRouteStatusMsg | undefined;
    AddedDateTime?: Date | undefined;
    IpRouteStatusReason?: string | undefined;
    Description?: string | undefined;
}
export type IpRoutesInfo = IpRouteInfo[];
export interface ListIpRoutesResult {
    IpRoutesInfo?: IpRouteInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLogSubscriptionsRequest {
    DirectoryId?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type SubscriptionCreatedDateTime = Date;
export interface LogSubscription {
    DirectoryId?: string | undefined;
    LogGroupName?: string | undefined;
    SubscriptionCreatedDateTime?: Date | undefined;
}
export type LogSubscriptions = LogSubscription[];
export interface ListLogSubscriptionsResult {
    LogSubscriptions?: LogSubscription[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSchemaExtensionsRequest {
    DirectoryId: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type SchemaExtensionStatus = "Initializing" | "CreatingSnapshot" | "UpdatingSchema" | "Replicating" | "CancelInProgress" | "RollbackInProgress" | "Cancelled" | "Failed" | "Completed" | (string & {});
export type SchemaExtensionStatusReason = string;
export type EndDateTime = Date;
export interface SchemaExtensionInfo {
    DirectoryId?: string | undefined;
    SchemaExtensionId?: string | undefined;
    Description?: string | undefined;
    SchemaExtensionStatus?: SchemaExtensionStatus | undefined;
    SchemaExtensionStatusReason?: string | undefined;
    StartDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export type SchemaExtensionsInfo = SchemaExtensionInfo[];
export interface ListSchemaExtensionsResult {
    SchemaExtensionsInfo?: SchemaExtensionInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceId: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface ListTagsForResourceResult {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export type CertificateData = string;
export interface RegisterCertificateRequest {
    DirectoryId: string;
    CertificateData: string;
    Type?: CertificateType | undefined;
    ClientCertAuthSettings?: ClientCertAuthSettings | undefined;
}
export interface RegisterCertificateResult {
    CertificateId?: string | undefined;
}
export interface RegisterEventTopicRequest {
    DirectoryId: string;
    TopicName: string;
}
export interface RegisterEventTopicResult {
}
export interface RejectSharedDirectoryRequest {
    SharedDirectoryId: string;
}
export interface RejectSharedDirectoryResult {
    SharedDirectoryId?: string | undefined;
}
export type CidrIps = string[];
export type CidrIpv6s = string[];
export interface RemoveIpRoutesRequest {
    DirectoryId: string;
    CidrIps?: string[] | undefined;
    CidrIpv6s?: string[] | undefined;
}
export interface RemoveIpRoutesResult {
}
export interface RemoveRegionRequest {
    DirectoryId: string;
}
export interface RemoveRegionResult {
}
export type TagKeys = string[];
export interface RemoveTagsFromResourceRequest {
    ResourceId: string;
    TagKeys: string[];
}
export interface RemoveTagsFromResourceResult {
}
export type CustomerUserName = string;
export type UserPassword = string | redacted.Redacted<string>;
export interface ResetUserPasswordRequest {
    DirectoryId: string;
    UserName: string;
    NewPassword: string | redacted.Redacted<string>;
}
export interface ResetUserPasswordResult {
}
export interface RestoreFromSnapshotRequest {
    SnapshotId: string;
}
export interface RestoreFromSnapshotResult {
}
export type TargetId = string;
export type TargetType = "ACCOUNT" | (string & {});
export interface ShareTarget {
    Id: string;
    Type: TargetType;
}
export interface ShareDirectoryRequest {
    DirectoryId: string;
    ShareNotes?: string | redacted.Redacted<string> | undefined;
    ShareTarget: ShareTarget;
    ShareMethod: ShareMethod;
}
export interface ShareDirectoryResult {
    SharedDirectoryId?: string | undefined;
}
export interface AssessmentConfiguration {
    CustomerDnsIps: string[];
    DnsName: string;
    VpcSettings: DirectoryVpcSettings;
    InstanceIds: string[];
    SecurityGroupIds?: string[] | undefined;
}
export interface StartADAssessmentRequest {
    AssessmentConfiguration?: AssessmentConfiguration | undefined;
    DirectoryId?: string | undefined;
}
export interface StartADAssessmentResult {
    AssessmentId?: string | undefined;
}
export type CreateSnapshotBeforeSchemaExtension = boolean;
export type LdifContent = string;
export interface StartSchemaExtensionRequest {
    DirectoryId: string;
    CreateSnapshotBeforeSchemaExtension: boolean;
    LdifContent: string;
    Description: string;
}
export interface StartSchemaExtensionResult {
    SchemaExtensionId?: string | undefined;
}
export interface UnshareTarget {
    Id: string;
    Type: TargetType;
}
export interface UnshareDirectoryRequest {
    DirectoryId: string;
    UnshareTarget: UnshareTarget;
}
export interface UnshareDirectoryResult {
    SharedDirectoryId?: string | undefined;
}
export interface UpdateConditionalForwarderRequest {
    DirectoryId: string;
    RemoteDomainName: string;
    DnsIpAddrs?: string[] | undefined;
    DnsIpv6Addrs?: string[] | undefined;
}
export interface UpdateConditionalForwarderResult {
}
export interface DirectorySizeUpdateSettings {
    DirectorySize?: DirectorySize | undefined;
}
export interface NetworkUpdateSettings {
    NetworkType?: NetworkType | undefined;
    CustomerDnsIpsV6?: string[] | undefined;
}
export type CreateSnapshotBeforeUpdate = boolean;
export interface UpdateDirectorySetupRequest {
    DirectoryId: string;
    UpdateType: UpdateType;
    OSUpdateSettings?: OSUpdateSettings | undefined;
    DirectorySizeUpdateSettings?: DirectorySizeUpdateSettings | undefined;
    NetworkUpdateSettings?: NetworkUpdateSettings | undefined;
    CreateSnapshotBeforeUpdate?: boolean | undefined;
}
export interface UpdateDirectorySetupResult {
}
export interface HybridAdministratorAccountUpdate {
    SecretArn: string;
}
export interface HybridCustomerInstancesSettings {
    CustomerDnsIps: string[];
    InstanceIds: string[];
}
export interface UpdateHybridADRequest {
    DirectoryId: string;
    HybridAdministratorAccountUpdate?: HybridAdministratorAccountUpdate | undefined;
    SelfManagedInstancesSettings?: HybridCustomerInstancesSettings | undefined;
}
export interface UpdateHybridADResult {
    DirectoryId?: string | undefined;
    AssessmentId?: string | undefined;
}
export interface UpdateNumberOfDomainControllersRequest {
    DirectoryId: string;
    DesiredNumber: number;
}
export interface UpdateNumberOfDomainControllersResult {
}
export interface UpdateRadiusRequest {
    DirectoryId: string;
    RadiusSettings: RadiusSettings;
}
export interface UpdateRadiusResult {
}
export interface Setting {
    Name: string;
    Value: string;
}
export type Settings = Setting[];
export interface UpdateSettingsRequest {
    DirectoryId: string;
    Settings: Setting[];
}
export interface UpdateSettingsResult {
    DirectoryId?: string | undefined;
}
export interface UpdateTrustRequest {
    TrustId: string;
    SelectiveAuth?: SelectiveAuth | undefined;
}
export type RequestId = string;
export interface UpdateTrustResult {
    RequestId?: string | undefined;
    TrustId?: string | undefined;
}
export interface VerifyTrustRequest {
    TrustId: string;
}
export interface VerifyTrustResult {
    TrustId?: string | undefined;
}
export type ExceptionMessage = string;
export type AcceptSharedDirectoryError = ClientException | DirectoryAlreadySharedException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Accepts a directory sharing request that was sent from the directory owner account.
 */
export declare const acceptSharedDirectory: API.OperationMethod<AcceptSharedDirectoryRequest & RegionInput, AcceptSharedDirectoryResult, AcceptSharedDirectoryError, Credentials | HttpClient.HttpClient>;
export type AddIpRoutesError = ClientException | DirectoryUnavailableException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | IpRouteLimitExceededException | ServiceException | CommonErrors;
/**
 * If the DNS server for your self-managed domain uses a publicly addressable IP address,
 * you must add a CIDR address block to correctly route traffic to and from your Microsoft AD
 * on Amazon Web Services. *AddIpRoutes* adds this address block. You can
 * also use *AddIpRoutes* to facilitate routing traffic that uses public IP
 * ranges from your Microsoft AD on Amazon Web Services to a peer VPC.
 *
 * Before you call *AddIpRoutes*, ensure that all of the required
 * permissions have been explicitly granted through a policy. For details about what
 * permissions are required to run the *AddIpRoutes* operation, see Directory Service API Permissions: Actions, Resources, and Conditions Reference.
 */
export declare const addIpRoutes: API.OperationMethod<AddIpRoutesRequest & RegionInput, AddIpRoutesResult, AddIpRoutesError, Credentials | HttpClient.HttpClient>;
export type AddRegionError = AccessDeniedException | ClientException | DirectoryAlreadyInRegionException | DirectoryDoesNotExistException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | RegionLimitExceededException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Adds two domain controllers in the specified Region for the specified directory.
 */
export declare const addRegion: API.OperationMethod<AddRegionRequest & RegionInput, AddRegionResult, AddRegionError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | TagLimitExceededException | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified directory. Each directory can
 * have a maximum of 50 tags. Each tag consists of a key and optional value. Tag keys must be
 * unique to each resource.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceRequest & RegionInput, AddTagsToResourceResult, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type CancelSchemaExtensionError = ClientException | EntityDoesNotExistException | ServiceException | CommonErrors;
/**
 * Cancels an in-progress schema extension to a Microsoft AD directory. Once a schema
 * extension has started replicating to all domain controllers, the task can no longer be
 * canceled. A schema extension can be canceled during any of the following states;
 * `Initializing`, `CreatingSnapshot`, and
 * `UpdatingSchema`.
 */
export declare const cancelSchemaExtension: API.OperationMethod<CancelSchemaExtensionRequest & RegionInput, CancelSchemaExtensionResult, CancelSchemaExtensionError, Credentials | HttpClient.HttpClient>;
export type ConnectDirectoryError = ClientException | DirectoryLimitExceededException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Creates an AD Connector to connect to a self-managed directory.
 *
 * Before you call `ConnectDirectory`, ensure that all of the required permissions
 * have been explicitly granted through a policy. For details about what permissions are required
 * to run the `ConnectDirectory` operation, see Directory Service API Permissions: Actions, Resources, and Conditions Reference.
 */
export declare const connectDirectory: API.OperationMethod<ConnectDirectoryRequest & RegionInput, ConnectDirectoryResult, ConnectDirectoryError, Credentials | HttpClient.HttpClient>;
export type CreateAliasError = ClientException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Creates an alias for a directory and assigns the alias to the directory. The alias is used
 * to construct the access URL for the directory, such as
 * `http://.awsapps.com`.
 *
 * After an alias has been created, it cannot be deleted or reused, so this operation should only be used when absolutely necessary.
 */
export declare const createAlias: API.OperationMethod<CreateAliasRequest & RegionInput, CreateAliasResult, CreateAliasError, Credentials | HttpClient.HttpClient>;
export type CreateComputerError = AuthenticationFailedException | ClientException | DirectoryUnavailableException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Creates an Active Directory computer object in the specified directory.
 */
export declare const createComputer: API.OperationMethod<CreateComputerRequest & RegionInput, CreateComputerResult, CreateComputerError, Credentials | HttpClient.HttpClient>;
export type CreateConditionalForwarderError = ClientException | DirectoryUnavailableException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a conditional forwarder associated with your Amazon Web Services directory. Conditional
 * forwarders are required in order to set up a trust relationship with another domain. The
 * conditional forwarder points to the trusted domain.
 */
export declare const createConditionalForwarder: API.OperationMethod<CreateConditionalForwarderRequest & RegionInput, CreateConditionalForwarderResult, CreateConditionalForwarderError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryError = ClientException | DirectoryLimitExceededException | InvalidParameterException | ServiceException | SimpleADClosedToNewCustomers | CommonErrors;
/**
 * Creates a Simple AD directory. For more information, see Simple Active Directory in the *Directory Service Admin Guide*.
 *
 * Before you call `CreateDirectory`, ensure that all of the required permissions
 * have been explicitly granted through a policy. For details about what permissions are required
 * to run the `CreateDirectory` operation, see Directory Service API Permissions: Actions, Resources, and Conditions Reference.
 */
export declare const createDirectory: API.OperationMethod<CreateDirectoryRequest & RegionInput, CreateDirectoryResult, CreateDirectoryError, Credentials | HttpClient.HttpClient>;
export type CreateHybridADError = ADAssessmentLimitExceededException | ClientException | DirectoryLimitExceededException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a hybrid directory that connects your self-managed Active Directory (AD)
 * infrastructure and Amazon Web Services.
 *
 * You must have a successful directory assessment using StartADAssessment to validate your environment compatibility before you
 * use this operation.
 *
 * Updates are applied asynchronously. Use DescribeDirectories to
 * monitor the progress of directory creation.
 */
export declare const createHybridAD: API.OperationMethod<CreateHybridADRequest & RegionInput, CreateHybridADResult, CreateHybridADError, Credentials | HttpClient.HttpClient>;
export type CreateLogSubscriptionError = ClientException | EntityAlreadyExistsException | EntityDoesNotExistException | InsufficientPermissionsException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a subscription to forward real-time Directory Service domain controller security
 * logs to the specified Amazon CloudWatch log group in your Amazon Web Services account.
 */
export declare const createLogSubscription: API.OperationMethod<CreateLogSubscriptionRequest & RegionInput, CreateLogSubscriptionResult, CreateLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateMicrosoftADError = ClientException | DirectoryLimitExceededException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a Microsoft AD directory in the Amazon Web Services Cloud. For more information, see Managed Microsoft AD in the *Directory Service Admin Guide*.
 *
 * Before you call *CreateMicrosoftAD*, ensure that all of the required
 * permissions have been explicitly granted through a policy. For details about what permissions
 * are required to run the *CreateMicrosoftAD* operation, see Directory Service API Permissions: Actions, Resources, and Conditions Reference.
 */
export declare const createMicrosoftAD: API.OperationMethod<CreateMicrosoftADRequest & RegionInput, CreateMicrosoftADResult, CreateMicrosoftADError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | SnapshotLimitExceededException | CommonErrors;
/**
 * Creates a snapshot of a Simple AD or Microsoft AD directory in the Amazon Web Services cloud.
 *
 * You cannot take snapshots of AD Connector directories.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest & RegionInput, CreateSnapshotResult, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateTrustError = ClientException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Directory Service for Microsoft Active Directory allows you to configure trust relationships. For
 * example, you can establish a trust between your Managed Microsoft AD directory, and your existing
 * self-managed Microsoft Active Directory. This would allow you to provide users and groups
 * access to resources in either domain, with a single set of credentials.
 *
 * This action initiates the creation of the Amazon Web Services side of a trust relationship between an
 * Managed Microsoft AD directory and an external domain. You can create either a forest trust or an
 * external trust.
 */
export declare const createTrust: API.OperationMethod<CreateTrustRequest & RegionInput, CreateTrustResult, CreateTrustError, Credentials | HttpClient.HttpClient>;
export type DeleteADAssessmentError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a directory assessment and all associated data. This operation permanently
 * removes the assessment results, validation reports, and configuration
 * information.
 *
 * You cannot delete system-initiated assessments. You can delete customer-created
 * assessments even if they are in progress.
 */
export declare const deleteADAssessment: API.OperationMethod<DeleteADAssessmentRequest & RegionInput, DeleteADAssessmentResult, DeleteADAssessmentError, Credentials | HttpClient.HttpClient>;
export type DeleteConditionalForwarderError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a conditional forwarder that has been set up for your Amazon Web Services
 * directory.
 */
export declare const deleteConditionalForwarder: API.OperationMethod<DeleteConditionalForwarderRequest & RegionInput, DeleteConditionalForwarderResult, DeleteConditionalForwarderError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryError = ClientException | EntityDoesNotExistException | ServiceException | CommonErrors;
/**
 * Deletes an Directory Service directory.
 *
 * Before you call `DeleteDirectory`, ensure that all of the required permissions
 * have been explicitly granted through a policy. For details about what permissions are required
 * to run the `DeleteDirectory` operation, see Directory Service API Permissions: Actions, Resources, and Conditions Reference.
 */
export declare const deleteDirectory: API.OperationMethod<DeleteDirectoryRequest & RegionInput, DeleteDirectoryResult, DeleteDirectoryError, Credentials | HttpClient.HttpClient>;
export type DeleteLogSubscriptionError = ClientException | EntityDoesNotExistException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified log subscription.
 */
export declare const deleteLogSubscription: API.OperationMethod<DeleteLogSubscriptionRequest & RegionInput, DeleteLogSubscriptionResult, DeleteLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Deletes a directory snapshot.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest & RegionInput, DeleteSnapshotResult, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes an existing trust relationship between your Managed Microsoft AD directory and an external
 * domain.
 */
export declare const deleteTrust: API.OperationMethod<DeleteTrustRequest & RegionInput, DeleteTrustResult, DeleteTrustError, Credentials | HttpClient.HttpClient>;
export type DeregisterCertificateError = CertificateDoesNotExistException | CertificateInUseException | ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes from the system the certificate that was registered for secure LDAP or client
 * certificate authentication.
 */
export declare const deregisterCertificate: API.OperationMethod<DeregisterCertificateRequest & RegionInput, DeregisterCertificateResult, DeregisterCertificateError, Credentials | HttpClient.HttpClient>;
export type DeregisterEventTopicError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Removes the specified directory as a publisher to the specified Amazon SNS topic.
 */
export declare const deregisterEventTopic: API.OperationMethod<DeregisterEventTopicRequest & RegionInput, DeregisterEventTopicResult, DeregisterEventTopicError, Credentials | HttpClient.HttpClient>;
export type DescribeADAssessmentError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves detailed information about a directory assessment, including its current
 * status, validation results, and configuration details. Use this operation to monitor
 * assessment progress and review results.
 */
export declare const describeADAssessment: API.OperationMethod<DescribeADAssessmentRequest & RegionInput, DescribeADAssessmentResult, DescribeADAssessmentError, Credentials | HttpClient.HttpClient>;
export type DescribeCAEnrollmentPolicyError = ClientException | DirectoryDoesNotExistException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves detailed information about the certificate authority (CA) enrollment policy for
 * the specified directory. This policy determines how client certificates are automatically enrolled and
 * managed through Amazon Web Services Private Certificate Authority.
 */
export declare const describeCAEnrollmentPolicy: API.OperationMethod<DescribeCAEnrollmentPolicyRequest & RegionInput, DescribeCAEnrollmentPolicyResult, DescribeCAEnrollmentPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateError = CertificateDoesNotExistException | ClientException | DirectoryDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Displays information about the certificate registered for secure LDAP or client
 * certificate authentication.
 */
export declare const describeCertificate: API.OperationMethod<DescribeCertificateRequest & RegionInput, DescribeCertificateResult, DescribeCertificateError, Credentials | HttpClient.HttpClient>;
export type DescribeClientAuthenticationSettingsError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about the type of client authentication for the specified directory,
 * if the type is specified. If no type is specified, information about all client authentication
 * types that are supported for the specified directory is retrieved. Currently, only
 * `SmartCard` is supported.
 */
export declare const describeClientAuthenticationSettings: API.PaginatedOperationMethod<DescribeClientAuthenticationSettingsRequest & RegionInput, DescribeClientAuthenticationSettingsResult, DescribeClientAuthenticationSettingsError, Credentials | HttpClient.HttpClient, ClientAuthenticationSettingInfo>;
export type DescribeConditionalForwardersError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Obtains information about the conditional forwarders for this account.
 *
 * If no input parameters are provided for RemoteDomainNames, this request describes all
 * conditional forwarders for the specified directory ID.
 */
export declare const describeConditionalForwarders: API.OperationMethod<DescribeConditionalForwardersRequest & RegionInput, DescribeConditionalForwardersResult, DescribeConditionalForwardersError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectoriesError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Obtains information about the directories that belong to this account.
 *
 * You can retrieve information about specific directories by passing the directory
 * identifiers in the `DirectoryIds` parameter. Otherwise, all directories that belong
 * to the current account are returned.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the
 * `DescribeDirectoriesResult.NextToken` member contains a token that you pass in
 * the next call to DescribeDirectories to retrieve the next set of
 * items.
 *
 * You can also specify a maximum number of return results with the `Limit`
 * parameter.
 */
export declare const describeDirectories: API.PaginatedOperationMethod<DescribeDirectoriesRequest & RegionInput, DescribeDirectoriesResult, DescribeDirectoriesError, Credentials | HttpClient.HttpClient, DirectoryDescription>;
export type DescribeDirectoryDataAccessError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Obtains status of directory data access enablement through the Directory Service Data API for the
 * specified directory.
 */
export declare const describeDirectoryDataAccess: API.OperationMethod<DescribeDirectoryDataAccessRequest & RegionInput, DescribeDirectoryDataAccessResult, DescribeDirectoryDataAccessError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainControllersError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Provides information about any domain controllers in your directory.
 */
export declare const describeDomainControllers: API.PaginatedOperationMethod<DescribeDomainControllersRequest & RegionInput, DescribeDomainControllersResult, DescribeDomainControllersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventTopicsError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Obtains information about which Amazon SNS topics receive status messages from the specified
 * directory.
 *
 * If no input parameters are provided, such as DirectoryId or TopicName, this request
 * describes all of the associations in the account.
 */
export declare const describeEventTopics: API.OperationMethod<DescribeEventTopicsRequest & RegionInput, DescribeEventTopicsResult, DescribeEventTopicsError, Credentials | HttpClient.HttpClient>;
export type DescribeHybridADUpdateError = ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about update activities for a hybrid directory. This operation
 * provides details about configuration changes, administrator account updates, and
 * self-managed instance settings (IDs and DNS IPs).
 */
export declare const describeHybridADUpdate: API.OperationMethod<DescribeHybridADUpdateRequest & RegionInput, DescribeHybridADUpdateResult, DescribeHybridADUpdateError, Credentials | HttpClient.HttpClient>;
export type DescribeLDAPSSettingsError = ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Describes the status of LDAP security for the specified directory.
 */
export declare const describeLDAPSSettings: API.PaginatedOperationMethod<DescribeLDAPSSettingsRequest & RegionInput, DescribeLDAPSSettingsResult, DescribeLDAPSSettingsError, Credentials | HttpClient.HttpClient, LDAPSSettingInfo>;
export type DescribeRegionsError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Provides information about the Regions that are configured for multi-Region
 * replication.
 */
export declare const describeRegions: API.PaginatedOperationMethod<DescribeRegionsRequest & RegionInput, DescribeRegionsResult, DescribeRegionsError, Credentials | HttpClient.HttpClient, RegionDescription>;
export type DescribeSettingsError = ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about the configurable settings for the specified directory.
 */
export declare const describeSettings: API.OperationMethod<DescribeSettingsRequest & RegionInput, DescribeSettingsResult, DescribeSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeSharedDirectoriesError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Returns the shared directories in your account.
 */
export declare const describeSharedDirectories: API.PaginatedOperationMethod<DescribeSharedDirectoriesRequest & RegionInput, DescribeSharedDirectoriesResult, DescribeSharedDirectoriesError, Credentials | HttpClient.HttpClient, SharedDirectory>;
export type DescribeSnapshotsError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Obtains information about the directory snapshots that belong to this account.
 *
 * This operation supports pagination with the use of the *NextToken* request and
 * response parameters. If more results are available, the *DescribeSnapshots.NextToken*
 * member contains a token that you pass in the next call to DescribeSnapshots to
 * retrieve the next set of items.
 *
 * You can also specify a maximum number of return results with the *Limit*
 * parameter.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsRequest & RegionInput, DescribeSnapshotsResult, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeTrustsError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Obtains information about the trust relationships for this account.
 *
 * If no input parameters are provided, such as DirectoryId or TrustIds, this request
 * describes all the trust relationships belonging to the account.
 */
export declare const describeTrusts: API.PaginatedOperationMethod<DescribeTrustsRequest & RegionInput, DescribeTrustsResult, DescribeTrustsError, Credentials | HttpClient.HttpClient, Trust>;
export type DescribeUpdateDirectoryError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Describes the updates of a directory for a particular update type.
 */
export declare const describeUpdateDirectory: API.PaginatedOperationMethod<DescribeUpdateDirectoryRequest & RegionInput, DescribeUpdateDirectoryResult, DescribeUpdateDirectoryError, Credentials | HttpClient.HttpClient, UpdateInfoEntry>;
export type DisableCAEnrollmentPolicyError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | DisableAlreadyInProgressException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Disables the certificate authority (CA) enrollment policy for the specified directory. This stops
 * automatic certificate enrollment and management for domain-joined clients, but does not affect
 * existing certificates.
 *
 * Disabling the CA enrollment policy prevents new certificates from being automatically
 * enrolled, but existing certificates remain valid and functional until they expire.
 */
export declare const disableCAEnrollmentPolicy: API.OperationMethod<DisableCAEnrollmentPolicyRequest & RegionInput, DisableCAEnrollmentPolicyResult, DisableCAEnrollmentPolicyError, Credentials | HttpClient.HttpClient>;
export type DisableClientAuthenticationError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | InvalidClientAuthStatusException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Disables alternative client authentication methods for the specified directory.
 */
export declare const disableClientAuthentication: API.OperationMethod<DisableClientAuthenticationRequest & RegionInput, DisableClientAuthenticationResult, DisableClientAuthenticationError, Credentials | HttpClient.HttpClient>;
export type DisableDirectoryDataAccessError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryInDesiredStateException | DirectoryUnavailableException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deactivates access to directory data via the Directory Service Data API for the specified directory. For
 * more information, see Directory Service Data API Reference.
 */
export declare const disableDirectoryDataAccess: API.OperationMethod<DisableDirectoryDataAccessRequest & RegionInput, DisableDirectoryDataAccessResult, DisableDirectoryDataAccessError, Credentials | HttpClient.HttpClient>;
export type DisableLDAPSError = ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | InvalidLDAPSStatusException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Deactivates LDAP secure calls for the specified directory.
 */
export declare const disableLDAPS: API.OperationMethod<DisableLDAPSRequest & RegionInput, DisableLDAPSResult, DisableLDAPSError, Credentials | HttpClient.HttpClient>;
export type DisableRadiusError = ClientException | EntityDoesNotExistException | ServiceException | CommonErrors;
/**
 * Disables multi-factor authentication (MFA) with the Remote Authentication Dial In User
 * Service (RADIUS) server for an AD Connector or Microsoft AD directory.
 */
export declare const disableRadius: API.OperationMethod<DisableRadiusRequest & RegionInput, DisableRadiusResult, DisableRadiusError, Credentials | HttpClient.HttpClient>;
export type DisableSsoError = AuthenticationFailedException | ClientException | EntityDoesNotExistException | InsufficientPermissionsException | ServiceException | CommonErrors;
/**
 * Disables single-sign on for a directory.
 */
export declare const disableSso: API.OperationMethod<DisableSsoRequest & RegionInput, DisableSsoResult, DisableSsoError, Credentials | HttpClient.HttpClient>;
export type EnableCAEnrollmentPolicyError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | EnableAlreadyInProgressException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Enables certificate authority (CA) enrollment policy for the specified directory. This allows
 * domain-joined clients to automatically request and receive certificates from the specified
 * Amazon Web Services Private Certificate Authority.
 *
 * Before enabling CA enrollment, ensure that the PCA connector is properly configured and
 * accessible from the directory. The connector must be in an active state and have the
 * necessary permissions.
 */
export declare const enableCAEnrollmentPolicy: API.OperationMethod<EnableCAEnrollmentPolicyRequest & RegionInput, EnableCAEnrollmentPolicyResult, EnableCAEnrollmentPolicyError, Credentials | HttpClient.HttpClient>;
export type EnableClientAuthenticationError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | InvalidClientAuthStatusException | NoAvailableCertificateException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Enables alternative client authentication methods for the specified directory.
 */
export declare const enableClientAuthentication: API.OperationMethod<EnableClientAuthenticationRequest & RegionInput, EnableClientAuthenticationResult, EnableClientAuthenticationError, Credentials | HttpClient.HttpClient>;
export type EnableDirectoryDataAccessError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryInDesiredStateException | DirectoryUnavailableException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Enables access to directory data via the Directory Service Data API for the specified directory. For
 * more information, see Directory Service Data API Reference.
 */
export declare const enableDirectoryDataAccess: API.OperationMethod<EnableDirectoryDataAccessRequest & RegionInput, EnableDirectoryDataAccessResult, EnableDirectoryDataAccessError, Credentials | HttpClient.HttpClient>;
export type EnableLDAPSError = ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | InvalidLDAPSStatusException | InvalidParameterException | NoAvailableCertificateException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Activates the switch for the specific directory to always use LDAP secure calls.
 */
export declare const enableLDAPS: API.OperationMethod<EnableLDAPSRequest & RegionInput, EnableLDAPSResult, EnableLDAPSError, Credentials | HttpClient.HttpClient>;
export type EnableRadiusError = ClientException | EntityAlreadyExistsException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Enables multi-factor authentication (MFA) with the Remote Authentication Dial In User
 * Service (RADIUS) server for an AD Connector or Microsoft AD directory.
 */
export declare const enableRadius: API.OperationMethod<EnableRadiusRequest & RegionInput, EnableRadiusResult, EnableRadiusError, Credentials | HttpClient.HttpClient>;
export type EnableSsoError = AuthenticationFailedException | ClientException | EntityDoesNotExistException | InsufficientPermissionsException | ServiceException | CommonErrors;
/**
 * Enables single sign-on for a directory. Single sign-on allows users in your directory to
 * access certain Amazon Web Services services from a computer joined to the directory without having to enter
 * their credentials separately.
 */
export declare const enableSso: API.OperationMethod<EnableSsoRequest & RegionInput, EnableSsoResult, EnableSsoError, Credentials | HttpClient.HttpClient>;
export type GetDirectoryLimitsError = ClientException | EntityDoesNotExistException | ServiceException | CommonErrors;
/**
 * Obtains directory limit information for the current Region.
 */
export declare const getDirectoryLimits: API.OperationMethod<GetDirectoryLimitsRequest & RegionInput, GetDirectoryLimitsResult, GetDirectoryLimitsError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotLimitsError = ClientException | EntityDoesNotExistException | ServiceException | CommonErrors;
/**
 * Obtains the manual snapshot limits for a directory.
 */
export declare const getSnapshotLimits: API.OperationMethod<GetSnapshotLimitsRequest & RegionInput, GetSnapshotLimitsResult, GetSnapshotLimitsError, Credentials | HttpClient.HttpClient>;
export type ListADAssessmentsError = ClientException | DirectoryDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves a list of directory assessments for the specified directory or all
 * assessments in your account. Use this operation to monitor assessment status and manage
 * multiple assessments.
 */
export declare const listADAssessments: API.PaginatedOperationMethod<ListADAssessmentsRequest & RegionInput, ListADAssessmentsResult, ListADAssessmentsError, Credentials | HttpClient.HttpClient, AssessmentSummary>;
export type ListCertificatesError = ClientException | DirectoryDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * For the specified directory, lists all the certificates registered for a secure LDAP or
 * client certificate authentication.
 */
export declare const listCertificates: API.PaginatedOperationMethod<ListCertificatesRequest & RegionInput, ListCertificatesResult, ListCertificatesError, Credentials | HttpClient.HttpClient, CertificateInfo>;
export type ListIpRoutesError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Lists the address blocks that you have added to a directory.
 */
export declare const listIpRoutes: API.PaginatedOperationMethod<ListIpRoutesRequest & RegionInput, ListIpRoutesResult, ListIpRoutesError, Credentials | HttpClient.HttpClient, IpRouteInfo>;
export type ListLogSubscriptionsError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | ServiceException | CommonErrors;
/**
 * Lists the active log subscriptions for the Amazon Web Services account.
 */
export declare const listLogSubscriptions: API.PaginatedOperationMethod<ListLogSubscriptionsRequest & RegionInput, ListLogSubscriptionsResult, ListLogSubscriptionsError, Credentials | HttpClient.HttpClient, LogSubscription>;
export type ListSchemaExtensionsError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | ServiceException | CommonErrors;
/**
 * Lists all schema extensions applied to a Microsoft AD Directory.
 */
export declare const listSchemaExtensions: API.PaginatedOperationMethod<ListSchemaExtensionsRequest & RegionInput, ListSchemaExtensionsResult, ListSchemaExtensionsError, Credentials | HttpClient.HttpClient, SchemaExtensionInfo>;
export type ListTagsForResourceError = ClientException | EntityDoesNotExistException | InvalidNextTokenException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Lists all tags on a directory.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type RegisterCertificateError = CertificateAlreadyExistsException | CertificateLimitExceededException | ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | InvalidCertificateException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Registers a certificate for a secure LDAP or client certificate authentication.
 */
export declare const registerCertificate: API.OperationMethod<RegisterCertificateRequest & RegionInput, RegisterCertificateResult, RegisterCertificateError, Credentials | HttpClient.HttpClient>;
export type RegisterEventTopicError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Associates a directory with an Amazon SNS topic. This establishes the directory as a
 * publisher to the specified Amazon SNS topic. You can then receive email or text (SMS) messages when
 * the status of your directory changes. You get notified if your directory goes from an Active
 * status to an Impaired or Inoperable status. You also receive a notification when the directory
 * returns to an Active status.
 */
export declare const registerEventTopic: API.OperationMethod<RegisterEventTopicRequest & RegionInput, RegisterEventTopicResult, RegisterEventTopicError, Credentials | HttpClient.HttpClient>;
export type RejectSharedDirectoryError = ClientException | DirectoryAlreadySharedException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Rejects a directory sharing request that was sent from the directory owner account.
 */
export declare const rejectSharedDirectory: API.OperationMethod<RejectSharedDirectoryRequest & RegionInput, RejectSharedDirectoryResult, RejectSharedDirectoryError, Credentials | HttpClient.HttpClient>;
export type RemoveIpRoutesError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Removes IP address blocks from a directory.
 */
export declare const removeIpRoutes: API.OperationMethod<RemoveIpRoutesRequest & RegionInput, RemoveIpRoutesResult, RemoveIpRoutesError, Credentials | HttpClient.HttpClient>;
export type RemoveRegionError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Stops all replication and removes the domain controllers from the specified Region. You
 * cannot remove the primary Region with this operation. Instead, use the
 * `DeleteDirectory` API.
 */
export declare const removeRegion: API.OperationMethod<RemoveRegionRequest & RegionInput, RemoveRegionResult, RemoveRegionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Removes tags from a directory.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceRequest & RegionInput, RemoveTagsFromResourceResult, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetUserPasswordError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidPasswordException | ServiceException | UnsupportedOperationException | UserDoesNotExistException | CommonErrors;
/**
 * Resets the password for any user in your Managed Microsoft AD or Simple AD directory. Disabled
 * users will become enabled and can be authenticated following the API call.
 *
 * You can reset the password for any user in your directory with the following
 * exceptions:
 *
 * - For Simple AD, you cannot reset the password for any user that is a member of either
 * the **Domain Admins** or Enterprise
 * Admins group except for the administrator user.
 *
 * - For Managed Microsoft AD, you can only reset the password for a user that is in an OU based
 * off of the NetBIOS name that you typed when you created your directory. For example, you
 * cannot reset the password for a user in the Amazon Web Services
 * Reserved OU. For more information about the OU structure for an Managed Microsoft AD
 * directory, see What Gets Created in the Directory Service Administration
 * Guide.
 */
export declare const resetUserPassword: API.OperationMethod<ResetUserPasswordRequest & RegionInput, ResetUserPasswordResult, ResetUserPasswordError, Credentials | HttpClient.HttpClient>;
export type RestoreFromSnapshotError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Restores a directory using an existing directory snapshot.
 *
 * When you restore a directory from a snapshot, any changes made to the directory after the snapshot date are overwritten.
 *
 * This action returns as soon as the restore operation is initiated. You can monitor the
 * progress of the restore operation by calling the DescribeDirectories operation with
 * the directory identifier. When the **DirectoryDescription.Stage** value changes to
 * `Active`, the restore operation is complete.
 */
export declare const restoreFromSnapshot: API.OperationMethod<RestoreFromSnapshotRequest & RegionInput, RestoreFromSnapshotResult, RestoreFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type ShareDirectoryError = AccessDeniedException | ClientException | DirectoryAlreadySharedException | EntityDoesNotExistException | InvalidParameterException | InvalidTargetException | OrganizationsException | ServiceException | ShareLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Shares a specified directory (`DirectoryId`) in your Amazon Web Services account (directory
 * owner) with another Amazon Web Services account (directory consumer). With this operation you can use your
 * directory from any Amazon Web Services account and from any Amazon VPC within an Amazon Web Services Region.
 *
 * When you share your Managed Microsoft AD directory, Directory Service creates a shared directory in the
 * directory consumer account. This shared directory contains the metadata to provide access to
 * the directory within the directory owner account. The shared directory is visible in all VPCs
 * in the directory consumer account.
 *
 * The `ShareMethod` parameter determines whether the specified directory can be
 * shared between Amazon Web Services accounts inside the same Amazon Web Services organization (`ORGANIZATIONS`).
 * It also determines whether you can share the directory with any other Amazon Web Services account either
 * inside or outside of the organization (`HANDSHAKE`).
 *
 * The `ShareNotes` parameter is only used when `HANDSHAKE` is called,
 * which sends a directory sharing request to the directory consumer.
 */
export declare const shareDirectory: API.OperationMethod<ShareDirectoryRequest & RegionInput, ShareDirectoryResult, ShareDirectoryError, Credentials | HttpClient.HttpClient>;
export type StartADAssessmentError = ADAssessmentLimitExceededException | ClientException | DirectoryDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Initiates a directory assessment to validate your self-managed AD environment for
 * hybrid domain join. The assessment checks compatibility and connectivity of the
 * self-managed AD environment.
 *
 * A directory assessment is automatically created when you create a hybrid directory.
 * There are two types of assessments: `CUSTOMER` and `SYSTEM`. Your
 * Amazon Web Services account has a limit of 100 `CUSTOMER` directory assessments.
 *
 * The assessment process typically takes 30 minutes or more to complete. The assessment
 * process is asynchronous and you can monitor it with
 * `DescribeADAssessment`.
 *
 * The `InstanceIds` must have a one-to-one correspondence with
 * `CustomerDnsIps`, meaning that if the IP address for instance i-10243410
 * is 10.24.34.100 and the IP address for instance i-10243420 is 10.24.34.200, then the
 * input arrays must maintain the same order relationship, either [10.24.34.100,
 * 10.24.34.200] paired with [i-10243410, i-10243420] or [10.24.34.200, 10.24.34.100]
 * paired with [i-10243420, i-10243410].
 *
 * Note: You must provide exactly one `DirectoryId` or
 * `AssessmentConfiguration`.
 */
export declare const startADAssessment: API.OperationMethod<StartADAssessmentRequest & RegionInput, StartADAssessmentResult, StartADAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartSchemaExtensionError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | ServiceException | SnapshotLimitExceededException | CommonErrors;
/**
 * Applies a schema extension to a Microsoft AD directory.
 */
export declare const startSchemaExtension: API.OperationMethod<StartSchemaExtensionRequest & RegionInput, StartSchemaExtensionResult, StartSchemaExtensionError, Credentials | HttpClient.HttpClient>;
export type UnshareDirectoryError = ClientException | DirectoryNotSharedException | EntityDoesNotExistException | InvalidTargetException | ServiceException | CommonErrors;
/**
 * Stops the directory sharing between the directory owner and consumer accounts.
 */
export declare const unshareDirectory: API.OperationMethod<UnshareDirectoryRequest & RegionInput, UnshareDirectoryResult, UnshareDirectoryError, Credentials | HttpClient.HttpClient>;
export type UpdateConditionalForwarderError = ClientException | DirectoryUnavailableException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Updates a conditional forwarder that has been set up for your Amazon Web Services
 * directory.
 */
export declare const updateConditionalForwarder: API.OperationMethod<UpdateConditionalForwarderRequest & RegionInput, UpdateConditionalForwarderResult, UpdateConditionalForwarderError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectorySetupError = AccessDeniedException | ClientException | DirectoryDoesNotExistException | DirectoryInDesiredStateException | DirectoryUnavailableException | InvalidParameterException | ServiceException | SnapshotLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Updates directory configuration for the specified update type.
 */
export declare const updateDirectorySetup: API.OperationMethod<UpdateDirectorySetupRequest & RegionInput, UpdateDirectorySetupResult, UpdateDirectorySetupError, Credentials | HttpClient.HttpClient>;
export type UpdateHybridADError = ADAssessmentLimitExceededException | ClientException | DirectoryDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the configuration of an existing hybrid directory. You can recover hybrid
 * directory administrator account or modify self-managed instance settings.
 *
 * Updates are applied asynchronously. Use DescribeHybridADUpdate to
 * monitor the progress of configuration changes.
 *
 * The `InstanceIds` must have a one-to-one correspondence with
 * `CustomerDnsIps`, meaning that if the IP address for instance i-10243410
 * is 10.24.34.100 and the IP address for instance i-10243420 is 10.24.34.200, then the
 * input arrays must maintain the same order relationship, either [10.24.34.100,
 * 10.24.34.200] paired with [i-10243410, i-10243420] or [10.24.34.200, 10.24.34.100]
 * paired with [i-10243420, i-10243410].
 *
 * You must provide at least one update to UpdateHybridADRequest$HybridAdministratorAccountUpdate or UpdateHybridADRequest$SelfManagedInstancesSettings.
 */
export declare const updateHybridAD: API.OperationMethod<UpdateHybridADRequest & RegionInput, UpdateHybridADResult, UpdateHybridADError, Credentials | HttpClient.HttpClient>;
export type UpdateNumberOfDomainControllersError = ClientException | DirectoryUnavailableException | DomainControllerLimitExceededException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Adds or removes domain controllers to or from the directory. Based on the difference
 * between current value and new value (provided through this API call), domain controllers will
 * be added or removed. It may take up to 45 minutes for any new domain controllers to become
 * fully active once the requested number of domain controllers is updated. During this time, you
 * cannot make another update request.
 */
export declare const updateNumberOfDomainControllers: API.OperationMethod<UpdateNumberOfDomainControllersRequest & RegionInput, UpdateNumberOfDomainControllersResult, UpdateNumberOfDomainControllersError, Credentials | HttpClient.HttpClient>;
export type UpdateRadiusError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Updates the Remote Authentication Dial In User Service (RADIUS) server information for
 * an AD Connector or Microsoft AD directory.
 */
export declare const updateRadius: API.OperationMethod<UpdateRadiusRequest & RegionInput, UpdateRadiusResult, UpdateRadiusError, Credentials | HttpClient.HttpClient>;
export type UpdateSettingsError = ClientException | DirectoryDoesNotExistException | DirectoryUnavailableException | IncompatibleSettingsException | InvalidParameterException | ServiceException | UnsupportedOperationException | UnsupportedSettingsException | CommonErrors;
/**
 * Updates the configurable settings for the specified directory.
 */
export declare const updateSettings: API.OperationMethod<UpdateSettingsRequest & RegionInput, UpdateSettingsResult, UpdateSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | CommonErrors;
/**
 * Updates the trust that has been set up between your Managed Microsoft AD directory and an
 * self-managed Active Directory.
 */
export declare const updateTrust: API.OperationMethod<UpdateTrustRequest & RegionInput, UpdateTrustResult, UpdateTrustError, Credentials | HttpClient.HttpClient>;
export type VerifyTrustError = ClientException | EntityDoesNotExistException | InvalidParameterException | ServiceException | UnsupportedOperationException | CommonErrors;
/**
 * Directory Service for Microsoft Active Directory allows you to configure and verify trust
 * relationships.
 *
 * This action verifies a trust relationship between your Managed Microsoft AD directory and an
 * external domain.
 */
export declare const verifyTrust: API.OperationMethod<VerifyTrustRequest & RegionInput, VerifyTrustResult, VerifyTrustError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=directory-service.d.ts.map