import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type __listOf__string = string[];
export interface CreateApplicationRequest {
    Author?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    Labels?: string[] | undefined;
    LicenseBody?: string | undefined;
    LicenseUrl?: string | undefined;
    Name?: string | undefined;
    ReadmeBody?: string | undefined;
    ReadmeUrl?: string | undefined;
    SemanticVersion?: string | undefined;
    SourceCodeArchiveUrl?: string | undefined;
    SourceCodeUrl?: string | undefined;
    SpdxLicenseId?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateUrl?: string | undefined;
}
export interface ParameterDefinition {
    AllowedPattern?: string | undefined;
    AllowedValues?: string[] | undefined;
    ConstraintDescription?: string | undefined;
    DefaultValue?: string | undefined;
    Description?: string | undefined;
    MaxLength?: number | undefined;
    MaxValue?: number | undefined;
    MinLength?: number | undefined;
    MinValue?: number | undefined;
    Name?: string | undefined;
    NoEcho?: boolean | undefined;
    ReferencedByResources?: string[] | undefined;
    Type?: string | undefined;
}
export type __listOfParameterDefinition = ParameterDefinition[];
export type Capability = "CAPABILITY_IAM" | "CAPABILITY_NAMED_IAM" | "CAPABILITY_AUTO_EXPAND" | "CAPABILITY_RESOURCE_POLICY" | (string & {});
export type __listOfCapability = Capability[];
export interface Version {
    ApplicationId?: string | undefined;
    CreationTime?: string | undefined;
    ParameterDefinitions?: ParameterDefinition[] | undefined;
    RequiredCapabilities?: Capability[] | undefined;
    ResourcesSupported?: boolean | undefined;
    SemanticVersion?: string | undefined;
    SourceCodeArchiveUrl?: string | undefined;
    SourceCodeUrl?: string | undefined;
    TemplateUrl?: string | undefined;
}
export interface CreateApplicationResponse {
    ApplicationId?: string | undefined;
    Author?: string | undefined;
    CreationTime?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    IsVerifiedAuthor?: boolean | undefined;
    Labels?: string[] | undefined;
    LicenseUrl?: string | undefined;
    Name?: string | undefined;
    ReadmeUrl?: string | undefined;
    SpdxLicenseId?: string | undefined;
    VerifiedAuthorUrl?: string | undefined;
    Version?: (Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    }) | undefined;
}
export interface CreateApplicationVersionRequest {
    ApplicationId: string;
    SemanticVersion: string;
    SourceCodeArchiveUrl?: string | undefined;
    SourceCodeUrl?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateUrl?: string | undefined;
}
export interface CreateApplicationVersionResponse {
    ApplicationId?: string | undefined;
    CreationTime?: string | undefined;
    ParameterDefinitions?: (ParameterDefinition & {
        Name: string;
        ReferencedByResources: __listOf__string;
    })[] | undefined;
    RequiredCapabilities?: Capability[] | undefined;
    ResourcesSupported?: boolean | undefined;
    SemanticVersion?: string | undefined;
    SourceCodeArchiveUrl?: string | undefined;
    SourceCodeUrl?: string | undefined;
    TemplateUrl?: string | undefined;
}
export interface ParameterValue {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type __listOfParameterValue = ParameterValue[];
export interface RollbackTrigger {
    Arn?: string | undefined;
    Type?: string | undefined;
}
export type __listOfRollbackTrigger = RollbackTrigger[];
export interface RollbackConfiguration {
    MonitoringTimeInMinutes?: number | undefined;
    RollbackTriggers?: RollbackTrigger[] | undefined;
}
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type __listOfTag = Tag[];
export interface CreateCloudFormationChangeSetRequest {
    ApplicationId: string;
    Capabilities?: string[] | undefined;
    ChangeSetName?: string | undefined;
    ClientToken?: string | undefined;
    Description?: string | undefined;
    NotificationArns?: string[] | undefined;
    ParameterOverrides?: ParameterValue[] | undefined;
    ResourceTypes?: string[] | undefined;
    RollbackConfiguration?: RollbackConfiguration | undefined;
    SemanticVersion?: string | undefined;
    StackName?: string | undefined;
    Tags?: Tag[] | undefined;
    TemplateId?: string | undefined;
}
export interface CreateCloudFormationChangeSetResponse {
    ApplicationId?: string | undefined;
    ChangeSetId?: string | undefined;
    SemanticVersion?: string | undefined;
    StackId?: string | undefined;
}
export interface CreateCloudFormationTemplateRequest {
    ApplicationId: string;
    SemanticVersion?: string | undefined;
}
export type Status = "PREPARING" | "ACTIVE" | "EXPIRED" | (string & {});
export interface CreateCloudFormationTemplateResponse {
    ApplicationId?: string | undefined;
    CreationTime?: string | undefined;
    ExpirationTime?: string | undefined;
    SemanticVersion?: string | undefined;
    Status?: Status | undefined;
    TemplateId?: string | undefined;
    TemplateUrl?: string | undefined;
}
export interface DeleteApplicationRequest {
    ApplicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface GetApplicationRequest {
    ApplicationId: string;
    SemanticVersion?: string | undefined;
}
export interface GetApplicationResponse {
    ApplicationId?: string | undefined;
    Author?: string | undefined;
    CreationTime?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    IsVerifiedAuthor?: boolean | undefined;
    Labels?: string[] | undefined;
    LicenseUrl?: string | undefined;
    Name?: string | undefined;
    ReadmeUrl?: string | undefined;
    SpdxLicenseId?: string | undefined;
    VerifiedAuthorUrl?: string | undefined;
    Version?: (Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    }) | undefined;
}
export interface GetApplicationPolicyRequest {
    ApplicationId: string;
}
export interface ApplicationPolicyStatement {
    Actions?: string[] | undefined;
    PrincipalOrgIDs?: string[] | undefined;
    Principals?: string[] | undefined;
    StatementId?: string | undefined;
}
export type __listOfApplicationPolicyStatement = ApplicationPolicyStatement[];
export interface GetApplicationPolicyResponse {
    Statements?: (ApplicationPolicyStatement & {
        Actions: __listOf__string;
        Principals: __listOf__string;
    })[] | undefined;
}
export interface GetCloudFormationTemplateRequest {
    ApplicationId: string;
    TemplateId: string;
}
export interface GetCloudFormationTemplateResponse {
    ApplicationId?: string | undefined;
    CreationTime?: string | undefined;
    ExpirationTime?: string | undefined;
    SemanticVersion?: string | undefined;
    Status?: Status | undefined;
    TemplateId?: string | undefined;
    TemplateUrl?: string | undefined;
}
export type MaxItems = number;
export interface ListApplicationDependenciesRequest {
    ApplicationId: string;
    MaxItems?: number | undefined;
    NextToken?: string | undefined;
    SemanticVersion?: string | undefined;
}
export interface ApplicationDependencySummary {
    ApplicationId?: string | undefined;
    SemanticVersion?: string | undefined;
}
export type __listOfApplicationDependencySummary = ApplicationDependencySummary[];
export interface ListApplicationDependenciesResponse {
    Dependencies?: (ApplicationDependencySummary & {
        ApplicationId: string;
        SemanticVersion: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListApplicationsRequest {
    MaxItems?: number | undefined;
    NextToken?: string | undefined;
}
export interface ApplicationSummary {
    ApplicationId?: string | undefined;
    Author?: string | undefined;
    CreationTime?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    Labels?: string[] | undefined;
    Name?: string | undefined;
    SpdxLicenseId?: string | undefined;
}
export type __listOfApplicationSummary = ApplicationSummary[];
export interface ListApplicationsResponse {
    Applications?: (ApplicationSummary & {
        ApplicationId: string;
        Author: string;
        Description: string;
        Name: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListApplicationVersionsRequest {
    ApplicationId: string;
    MaxItems?: number | undefined;
    NextToken?: string | undefined;
}
export interface VersionSummary {
    ApplicationId?: string | undefined;
    CreationTime?: string | undefined;
    SemanticVersion?: string | undefined;
    SourceCodeUrl?: string | undefined;
}
export type __listOfVersionSummary = VersionSummary[];
export interface ListApplicationVersionsResponse {
    NextToken?: string | undefined;
    Versions?: (VersionSummary & {
        ApplicationId: string;
        CreationTime: string;
        SemanticVersion: string;
    })[] | undefined;
}
export interface PutApplicationPolicyRequest {
    ApplicationId: string;
    Statements?: ApplicationPolicyStatement[] | undefined;
}
export interface PutApplicationPolicyResponse {
    Statements?: (ApplicationPolicyStatement & {
        Actions: __listOf__string;
        Principals: __listOf__string;
    })[] | undefined;
}
export interface UnshareApplicationRequest {
    ApplicationId: string;
    OrganizationId?: string | undefined;
}
export interface UnshareApplicationResponse {
}
export interface UpdateApplicationRequest {
    ApplicationId: string;
    Author?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    Labels?: string[] | undefined;
    ReadmeBody?: string | undefined;
    ReadmeUrl?: string | undefined;
}
export interface UpdateApplicationResponse {
    ApplicationId?: string | undefined;
    Author?: string | undefined;
    CreationTime?: string | undefined;
    Description?: string | undefined;
    HomePageUrl?: string | undefined;
    IsVerifiedAuthor?: boolean | undefined;
    Labels?: string[] | undefined;
    LicenseUrl?: string | undefined;
    Name?: string | undefined;
    ReadmeUrl?: string | undefined;
    SpdxLicenseId?: string | undefined;
    VerifiedAuthorUrl?: string | undefined;
    Version?: (Version & {
        ApplicationId: string;
        CreationTime: string;
        ParameterDefinitions: (ParameterDefinition & {
            Name: string;
            ReferencedByResources: __listOf__string;
        })[];
        RequiredCapabilities: __listOfCapability;
        ResourcesSupported: boolean;
        SemanticVersion: string;
        TemplateUrl: string;
    }) | undefined;
}
export type CreateApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application, optionally including an AWS SAM file to create the first application version in the same call.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationVersionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an application version.
 */
export declare const createApplicationVersion: API.OperationMethod<CreateApplicationVersionRequest & RegionInput, CreateApplicationVersionResponse, CreateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFormationChangeSetError = BadRequestException | ForbiddenException | InternalServerErrorException | TooManyRequestsException | CommonErrors;
/**
 * Creates an AWS CloudFormation change set for the given application.
 */
export declare const createCloudFormationChangeSet: API.OperationMethod<CreateCloudFormationChangeSetRequest & RegionInput, CreateCloudFormationChangeSetResponse, CreateCloudFormationChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFormationTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an AWS CloudFormation template.
 */
export declare const createCloudFormationTemplate: API.OperationMethod<CreateCloudFormationTemplateRequest & RegionInput, CreateCloudFormationTemplateResponse, CreateCloudFormationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the specified application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the policy for the application.
 */
export declare const getApplicationPolicy: API.OperationMethod<GetApplicationPolicyRequest & RegionInput, GetApplicationPolicyResponse, GetApplicationPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCloudFormationTemplateError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the specified AWS CloudFormation template.
 */
export declare const getCloudFormationTemplate: API.OperationMethod<GetCloudFormationTemplateRequest & RegionInput, GetCloudFormationTemplateResponse, GetCloudFormationTemplateError, Credentials | HttpClient.HttpClient>;
export type ListApplicationDependenciesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the list of applications nested in the containing application.
 */
export declare const listApplicationDependencies: API.PaginatedOperationMethod<ListApplicationDependenciesRequest & RegionInput, ListApplicationDependenciesResponse, ListApplicationDependenciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists applications owned by the requester.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListApplicationVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists versions for the specified application.
 */
export declare const listApplicationVersions: API.PaginatedOperationMethod<ListApplicationVersionsRequest & RegionInput, ListApplicationVersionsResponse, ListApplicationVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutApplicationPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the permission policy for an application. For the list of actions supported for this operation, see
 * Application
 * Permissions
 * .
 */
export declare const putApplicationPolicy: API.OperationMethod<PutApplicationPolicyRequest & RegionInput, PutApplicationPolicyResponse, PutApplicationPolicyError, Credentials | HttpClient.HttpClient>;
export type UnshareApplicationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Unshares an application from an AWS Organization.
 *
 * This operation can be called only from the organization's master account.
 */
export declare const unshareApplication: API.OperationMethod<UnshareApplicationRequest & RegionInput, UnshareApplicationResponse, UnshareApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the specified application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=serverlessapplicationrepository.d.ts.map