import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type NsLcmOpOccId = string;
export interface CancelSolNetworkOperationInput {
    nsLcmOpOccId: string;
}
export interface CancelSolNetworkOperationResponse {
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateSolFunctionPackageInput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VnfPkgId = string;
export type VnfPkgArn = string;
export type OnboardingState = "CREATED" | "ONBOARDED" | "ERROR" | (string & {});
export type OperationalState = "ENABLED" | "DISABLED" | (string & {});
export type UsageState = "IN_USE" | "NOT_IN_USE" | (string & {});
export interface CreateSolFunctionPackageOutput {
    id: string;
    arn: string;
    onboardingState: OnboardingState;
    operationalState: OperationalState;
    usageState: UsageState;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NsdInfoId = string;
export interface CreateSolNetworkInstanceInput {
    nsdInfoId: string;
    nsName: string;
    nsDescription?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NsInstanceId = string;
export type NsInstanceArn = string;
export interface CreateSolNetworkInstanceOutput {
    id: string;
    arn: string;
    nsdInfoId: string;
    nsInstanceName: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSolNetworkPackageInput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NsdInfoArn = string;
export type NsdOnboardingState = "CREATED" | "ONBOARDED" | "ERROR" | (string & {});
export type NsdOperationalState = "ENABLED" | "DISABLED" | (string & {});
export type NsdUsageState = "IN_USE" | "NOT_IN_USE" | (string & {});
export interface CreateSolNetworkPackageOutput {
    id: string;
    arn: string;
    nsdOnboardingState: NsdOnboardingState;
    nsdOperationalState: NsdOperationalState;
    nsdUsageState: NsdUsageState;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteSolFunctionPackageInput {
    vnfPkgId: string;
}
export interface DeleteSolFunctionPackageResponse {
}
export interface DeleteSolNetworkInstanceInput {
    nsInstanceId: string;
}
export interface DeleteSolNetworkInstanceResponse {
}
export interface DeleteSolNetworkPackageInput {
    nsdInfoId: string;
}
export interface DeleteSolNetworkPackageResponse {
}
export type VnfInstanceId = string;
export interface GetSolFunctionInstanceInput {
    vnfInstanceId: string;
}
export type VnfInstanceArn = string;
export type VnfdId = string;
export type VnfInstantiationState = "INSTANTIATED" | "NOT_INSTANTIATED" | (string & {});
export type VnfOperationalState = "STARTED" | "STOPPED" | (string & {});
export interface GetSolVnfcResourceInfoMetadata {
    nodeGroup?: string | undefined;
    cluster?: string | undefined;
    helmChart?: string | undefined;
}
export interface GetSolVnfcResourceInfo {
    metadata?: GetSolVnfcResourceInfoMetadata | undefined;
}
export type GetSolVnfcResourceInfoList = GetSolVnfcResourceInfo[];
export interface GetSolVnfInfo {
    vnfState?: VnfOperationalState | undefined;
    vnfcResourceInfo?: GetSolVnfcResourceInfo[] | undefined;
}
export interface GetSolFunctionInstanceMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface GetSolFunctionInstanceOutput {
    id: string;
    arn: string;
    nsInstanceId: string;
    vnfPkgId: string;
    vnfdId: string;
    vnfProvider?: string | undefined;
    vnfProductName?: string | undefined;
    vnfdVersion?: string | undefined;
    instantiationState: VnfInstantiationState;
    instantiatedVnfInfo?: GetSolVnfInfo | undefined;
    metadata: GetSolFunctionInstanceMetadata;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSolFunctionPackageInput {
    vnfPkgId: string;
}
export interface ToscaOverride {
    name?: string | undefined;
    defaultValue?: string | undefined;
}
export type OverrideList = ToscaOverride[];
export interface FunctionArtifactMeta {
    overrides?: ToscaOverride[] | undefined;
}
export interface GetSolFunctionPackageMetadata {
    vnfd?: FunctionArtifactMeta | undefined;
    createdAt: Date;
    lastModified: Date;
}
export interface GetSolFunctionPackageOutput {
    id: string;
    arn: string;
    onboardingState: OnboardingState;
    operationalState: OperationalState;
    usageState: UsageState;
    vnfdId?: string | undefined;
    vnfProvider?: string | undefined;
    vnfProductName?: string | undefined;
    vnfdVersion?: string | undefined;
    metadata?: GetSolFunctionPackageMetadata | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PackageContentType = "application/zip" | (string & {});
export interface GetSolFunctionPackageContentInput {
    vnfPkgId: string;
    accept: PackageContentType;
}
export interface GetSolFunctionPackageContentOutput {
    contentType?: PackageContentType | undefined;
    packageContent?: Uint8Array | undefined;
}
export type DescriptorContentType = "text/plain" | (string & {});
export interface GetSolFunctionPackageDescriptorInput {
    vnfPkgId: string;
    accept: DescriptorContentType;
}
export interface GetSolFunctionPackageDescriptorOutput {
    contentType?: DescriptorContentType | undefined;
    vnfd?: Uint8Array | undefined;
}
export interface GetSolNetworkInstanceInput {
    nsInstanceId: string;
}
export type NsdId = string;
export type NsState = "INSTANTIATED" | "NOT_INSTANTIATED" | "UPDATED" | "IMPAIRED" | "UPDATE_FAILED" | "STOPPED" | "DELETED" | "INSTANTIATE_IN_PROGRESS" | "INTENT_TO_UPDATE_IN_PROGRESS" | "UPDATE_IN_PROGRESS" | "TERMINATE_IN_PROGRESS" | (string & {});
export interface LcmOperationInfo {
    nsLcmOpOccId: string;
}
export interface GetSolNetworkInstanceMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface GetSolNetworkInstanceOutput {
    id: string;
    arn: string;
    nsInstanceName: string;
    nsInstanceDescription: string;
    nsdId: string;
    nsdInfoId: string;
    nsState?: NsState | undefined;
    lcmOpInfo?: LcmOperationInfo | undefined;
    metadata: GetSolNetworkInstanceMetadata;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSolNetworkOperationInput {
    nsLcmOpOccId: string;
}
export type NsLcmOpOccArn = string;
export type NsLcmOperationState = "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLING" | "CANCELLED" | (string & {});
export type LcmOperationType = "INSTANTIATE" | "UPDATE" | "TERMINATE" | (string & {});
export type UpdateSolNetworkType = "MODIFY_VNF_INFORMATION" | "UPDATE_NS" | (string & {});
export interface ProblemDetails {
    detail: string;
    title?: string | undefined;
}
export interface UpdateNsMetadata {
    nsdInfoId: string;
    additionalParamsForNs?: any | undefined;
}
export interface ModifyVnfInfoMetadata {
    vnfInstanceId: string;
    vnfConfigurableProperties: any;
}
export interface InstantiateMetadata {
    nsdInfoId: string;
    additionalParamsForNs?: any | undefined;
}
export interface GetSolNetworkOperationMetadata {
    updateNsMetadata?: UpdateNsMetadata | undefined;
    modifyVnfInfoMetadata?: ModifyVnfInfoMetadata | undefined;
    instantiateMetadata?: InstantiateMetadata | undefined;
    createdAt: Date;
    lastModified: Date;
}
export type StringMap = {
    [key: string]: string | undefined;
};
export type ErrorCause = string;
export type ErrorDetails = string;
export interface ErrorInfo {
    cause?: string | undefined;
    details?: string | undefined;
}
export type TaskStatus = "SCHEDULED" | "STARTED" | "IN_PROGRESS" | "COMPLETED" | "ERROR" | "SKIPPED" | "CANCELLED" | (string & {});
export interface GetSolNetworkOperationTaskDetails {
    taskName?: string | undefined;
    taskContext?: {
        [key: string]: string | undefined;
    } | undefined;
    taskErrorDetails?: ErrorInfo | undefined;
    taskStatus?: TaskStatus | undefined;
    taskStartTime?: Date | undefined;
    taskEndTime?: Date | undefined;
}
export type GetSolNetworkOperationTasksList = GetSolNetworkOperationTaskDetails[];
export interface GetSolNetworkOperationOutput {
    id?: string | undefined;
    arn: string;
    operationState?: NsLcmOperationState | undefined;
    nsInstanceId?: string | undefined;
    lcmOperationType?: LcmOperationType | undefined;
    updateType?: UpdateSolNetworkType | undefined;
    error?: ProblemDetails | undefined;
    metadata?: GetSolNetworkOperationMetadata | undefined;
    tasks?: GetSolNetworkOperationTaskDetails[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSolNetworkPackageInput {
    nsdInfoId: string;
}
export type VnfPkgIdList = string[];
export interface NetworkArtifactMeta {
    overrides?: ToscaOverride[] | undefined;
}
export interface GetSolNetworkPackageMetadata {
    nsd?: NetworkArtifactMeta | undefined;
    createdAt: Date;
    lastModified: Date;
}
export interface GetSolNetworkPackageOutput {
    id: string;
    arn: string;
    nsdOnboardingState: NsdOnboardingState;
    nsdOperationalState: NsdOperationalState;
    nsdUsageState: NsdUsageState;
    nsdId: string;
    nsdName: string;
    nsdVersion: string;
    vnfPkgIds: string[];
    metadata: GetSolNetworkPackageMetadata;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSolNetworkPackageContentInput {
    nsdInfoId: string;
    accept: PackageContentType;
}
export interface GetSolNetworkPackageContentOutput {
    contentType?: PackageContentType | undefined;
    nsdContent?: Uint8Array | undefined;
}
export interface GetSolNetworkPackageDescriptorInput {
    nsdInfoId: string;
}
export interface GetSolNetworkPackageDescriptorOutput {
    contentType?: DescriptorContentType | undefined;
    nsd?: Uint8Array | undefined;
}
export interface InstantiateSolNetworkInstanceInput {
    nsInstanceId: string;
    dryRun?: boolean | undefined;
    additionalParamsForNs?: any | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface InstantiateSolNetworkInstanceOutput {
    nsLcmOpOccId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PaginationToken = string;
export interface ListSolFunctionInstancesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GetSolInstantiatedVnfInfo {
    vnfState?: VnfOperationalState | undefined;
}
export interface ListSolFunctionInstanceMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface ListSolFunctionInstanceInfo {
    id: string;
    arn: string;
    nsInstanceId: string;
    vnfPkgId: string;
    vnfPkgName?: string | undefined;
    instantiationState: VnfInstantiationState;
    instantiatedVnfInfo?: GetSolInstantiatedVnfInfo | undefined;
    metadata: ListSolFunctionInstanceMetadata;
}
export type ListSolFunctionInstanceResources = ListSolFunctionInstanceInfo[];
export interface ListSolFunctionInstancesOutput {
    nextToken?: string | undefined;
    functionInstances?: ListSolFunctionInstanceInfo[] | undefined;
}
export interface ListSolFunctionPackagesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSolFunctionPackageMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface ListSolFunctionPackageInfo {
    id: string;
    arn: string;
    onboardingState: OnboardingState;
    operationalState: OperationalState;
    usageState: UsageState;
    vnfdId?: string | undefined;
    vnfProvider?: string | undefined;
    vnfProductName?: string | undefined;
    vnfdVersion?: string | undefined;
    metadata?: ListSolFunctionPackageMetadata | undefined;
}
export type ListSolFunctionPackageResources = ListSolFunctionPackageInfo[];
export interface ListSolFunctionPackagesOutput {
    nextToken?: string | undefined;
    functionPackages: ListSolFunctionPackageInfo[];
}
export interface ListSolNetworkInstancesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSolNetworkInstanceMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface ListSolNetworkInstanceInfo {
    id: string;
    arn: string;
    nsInstanceName: string;
    nsInstanceDescription: string;
    nsdId: string;
    nsdInfoId: string;
    nsState: NsState;
    metadata: ListSolNetworkInstanceMetadata;
}
export type ListSolNetworkInstanceResources = ListSolNetworkInstanceInfo[];
export interface ListSolNetworkInstancesOutput {
    nextToken?: string | undefined;
    networkInstances?: ListSolNetworkInstanceInfo[] | undefined;
}
export interface ListSolNetworkOperationsInput {
    nsInstanceId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSolNetworkOperationsMetadata {
    nsdInfoId?: string | undefined;
    vnfInstanceId?: string | undefined;
    createdAt: Date;
    lastModified: Date;
}
export interface ListSolNetworkOperationsInfo {
    id: string;
    arn: string;
    operationState: NsLcmOperationState;
    nsInstanceId: string;
    lcmOperationType: LcmOperationType;
    updateType?: UpdateSolNetworkType | undefined;
    error?: ProblemDetails | undefined;
    metadata?: ListSolNetworkOperationsMetadata | undefined;
}
export type ListSolNetworkOperationsResources = ListSolNetworkOperationsInfo[];
export interface ListSolNetworkOperationsOutput {
    nextToken?: string | undefined;
    networkOperations?: ListSolNetworkOperationsInfo[] | undefined;
}
export interface ListSolNetworkPackagesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSolNetworkPackageMetadata {
    createdAt: Date;
    lastModified: Date;
}
export interface ListSolNetworkPackageInfo {
    id: string;
    arn: string;
    nsdOnboardingState: NsdOnboardingState;
    nsdOperationalState: NsdOperationalState;
    nsdUsageState: NsdUsageState;
    nsdId?: string | undefined;
    nsdName?: string | undefined;
    nsdVersion?: string | undefined;
    nsdDesigner?: string | undefined;
    nsdInvariantId?: string | undefined;
    vnfPkgIds?: string[] | undefined;
    metadata: ListSolNetworkPackageMetadata;
}
export type ListSolNetworkPackageResources = ListSolNetworkPackageInfo[];
export interface ListSolNetworkPackagesOutput {
    nextToken?: string | undefined;
    networkPackages: ListSolNetworkPackageInfo[];
}
export type TNBResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface PutSolFunctionPackageContentInput {
    vnfPkgId: string;
    contentType?: PackageContentType | undefined;
    file: T.StreamingInputBody;
}
export interface PutSolFunctionPackageContentMetadata {
    vnfd?: FunctionArtifactMeta | undefined;
}
export interface PutSolFunctionPackageContentOutput {
    id: string;
    vnfdId: string;
    vnfProductName: string;
    vnfProvider: string;
    vnfdVersion: string;
    metadata: PutSolFunctionPackageContentMetadata;
}
export interface PutSolNetworkPackageContentInput {
    nsdInfoId: string;
    contentType?: PackageContentType | undefined;
    file: T.StreamingInputBody;
}
export interface PutSolNetworkPackageContentMetadata {
    nsd?: NetworkArtifactMeta | undefined;
}
export interface PutSolNetworkPackageContentOutput {
    id: string;
    arn: string;
    nsdId: string;
    nsdName: string;
    nsdVersion: string;
    vnfPkgIds: string[];
    metadata: PutSolNetworkPackageContentMetadata;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export interface TerminateSolNetworkInstanceInput {
    nsInstanceId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TerminateSolNetworkInstanceOutput {
    nsLcmOpOccId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateSolFunctionPackageInput {
    vnfPkgId: string;
    operationalState: OperationalState;
}
export interface UpdateSolFunctionPackageOutput {
    operationalState: OperationalState;
}
export interface UpdateSolNetworkModify {
    vnfInstanceId: string;
    vnfConfigurableProperties: any;
}
export interface UpdateSolNetworkServiceData {
    nsdInfoId: string;
    additionalParamsForNs?: any | undefined;
}
export interface UpdateSolNetworkInstanceInput {
    nsInstanceId: string;
    updateType: UpdateSolNetworkType;
    modifyVnfInfoData?: UpdateSolNetworkModify | undefined;
    updateNs?: UpdateSolNetworkServiceData | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSolNetworkInstanceOutput {
    nsLcmOpOccId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSolNetworkPackageInput {
    nsdInfoId: string;
    nsdOperationalState: NsdOperationalState;
}
export interface UpdateSolNetworkPackageOutput {
    nsdOperationalState: NsdOperationalState;
}
export interface ValidateSolFunctionPackageContentInput {
    vnfPkgId: string;
    contentType?: PackageContentType | undefined;
    file: T.StreamingInputBody;
}
export interface ValidateSolFunctionPackageContentMetadata {
    vnfd?: FunctionArtifactMeta | undefined;
}
export interface ValidateSolFunctionPackageContentOutput {
    id: string;
    vnfdId: string;
    vnfProductName: string;
    vnfProvider: string;
    vnfdVersion: string;
    metadata: ValidateSolFunctionPackageContentMetadata;
}
export interface ValidateSolNetworkPackageContentInput {
    nsdInfoId: string;
    contentType?: PackageContentType | undefined;
    file: T.StreamingInputBody;
}
export interface ValidateSolNetworkPackageContentMetadata {
    nsd?: NetworkArtifactMeta | undefined;
}
export interface ValidateSolNetworkPackageContentOutput {
    id: string;
    arn: string;
    nsdId: string;
    nsdName: string;
    nsdVersion: string;
    vnfPkgIds: string[];
    metadata: ValidateSolNetworkPackageContentMetadata;
}
export type CancelSolNetworkOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a network operation.
 *
 * A network operation is any operation that is done to your network, such as network instance instantiation or termination.
 */
export declare const cancelSolNetworkOperation: API.OperationMethod<CancelSolNetworkOperationInput & RegionInput, CancelSolNetworkOperationResponse, CancelSolNetworkOperationError, Credentials | HttpClient.HttpClient>;
export type CreateSolFunctionPackageError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a function package.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network. For more information, see Function packages in the
 * *Amazon Web Services Telco Network Builder User Guide*.
 *
 * Creating a function package is the first step for creating a network in AWS TNB. This
 * request creates an empty container with an ID. The next step is to upload the actual CSAR
 * zip file into that empty container. To upload function package content, see PutSolFunctionPackageContent.
 */
export declare const createSolFunctionPackage: API.OperationMethod<CreateSolFunctionPackageInput & RegionInput, CreateSolFunctionPackageOutput, CreateSolFunctionPackageError, Credentials | HttpClient.HttpClient>;
export type CreateSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed. Creating a network instance is the third step after creating a network
 * package. For more information about network instances, Network instances in the
 * *Amazon Web Services Telco Network Builder User Guide*.
 *
 * Once you create a network instance, you can instantiate it. To instantiate a network,
 * see InstantiateSolNetworkInstance.
 */
export declare const createSolNetworkInstance: API.OperationMethod<CreateSolNetworkInstanceInput & RegionInput, CreateSolNetworkInstanceOutput, CreateSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateSolNetworkPackageError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on. For more information, see Network instances in the
 * *Amazon Web Services Telco Network Builder User Guide*.
 *
 * A network package consists of a network service descriptor (NSD) file (required) and any
 * additional files (optional), such as scripts specific to your needs. For example, if you
 * have multiple function packages in your network package, you can use the NSD to define
 * which network functions should run in certain VPCs, subnets, or EKS clusters.
 *
 * This request creates an empty network package container with an ID. Once you create a
 * network package, you can upload the network package content using PutSolNetworkPackageContent.
 */
export declare const createSolNetworkPackage: API.OperationMethod<CreateSolNetworkPackageInput & RegionInput, CreateSolNetworkPackageOutput, CreateSolNetworkPackageError, Credentials | HttpClient.HttpClient>;
export type DeleteSolFunctionPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a function package.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 *
 * To delete a function package, the package must be in a disabled state. To disable a
 * function package, see UpdateSolFunctionPackage.
 */
export declare const deleteSolFunctionPackage: API.OperationMethod<DeleteSolFunctionPackageInput & RegionInput, DeleteSolFunctionPackageResponse, DeleteSolFunctionPackageError, Credentials | HttpClient.HttpClient>;
export type DeleteSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 *
 * To delete a network instance, the instance must be in a stopped or terminated state. To
 * terminate a network instance, see TerminateSolNetworkInstance.
 */
export declare const deleteSolNetworkInstance: API.OperationMethod<DeleteSolNetworkInstanceInput & RegionInput, DeleteSolNetworkInstanceResponse, DeleteSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteSolNetworkPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 *
 * To delete a network package, the package must be in a disable state. To disable a
 * network package, see UpdateSolNetworkPackage.
 */
export declare const deleteSolNetworkPackage: API.OperationMethod<DeleteSolNetworkPackageInput & RegionInput, DeleteSolNetworkPackageResponse, DeleteSolNetworkPackageError, Credentials | HttpClient.HttpClient>;
export type GetSolFunctionInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a network function instance, including the instantiation state and
 * metadata from the function package descriptor in the network function package.
 *
 * A network function instance is a function in a function package .
 */
export declare const getSolFunctionInstance: API.OperationMethod<GetSolFunctionInstanceInput & RegionInput, GetSolFunctionInstanceOutput, GetSolFunctionInstanceError, Credentials | HttpClient.HttpClient>;
export type GetSolFunctionPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of an individual function package, such as the operational state and
 * whether the package is in use.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network..
 */
export declare const getSolFunctionPackage: API.OperationMethod<GetSolFunctionPackageInput & RegionInput, GetSolFunctionPackageOutput, GetSolFunctionPackageError, Credentials | HttpClient.HttpClient>;
export type GetSolFunctionPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the contents of a function package.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const getSolFunctionPackageContent: API.OperationMethod<GetSolFunctionPackageContentInput & RegionInput, GetSolFunctionPackageContentOutput, GetSolFunctionPackageContentError, Credentials | HttpClient.HttpClient>;
export type GetSolFunctionPackageDescriptorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a function package descriptor in a function package.
 *
 * A function package descriptor is a .yaml file in a function package that uses the TOSCA standard to describe how the network function in the function package should run on your network.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const getSolFunctionPackageDescriptor: API.OperationMethod<GetSolFunctionPackageDescriptorInput & RegionInput, GetSolFunctionPackageDescriptorOutput, GetSolFunctionPackageDescriptorError, Credentials | HttpClient.HttpClient>;
export type GetSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 */
export declare const getSolNetworkInstance: API.OperationMethod<GetSolNetworkInstanceInput & RegionInput, GetSolNetworkInstanceOutput, GetSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type GetSolNetworkOperationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a network operation, including the tasks involved in the network
 * operation and the status of the tasks.
 *
 * A network operation is any operation that is done to your network, such as network instance instantiation or termination.
 */
export declare const getSolNetworkOperation: API.OperationMethod<GetSolNetworkOperationInput & RegionInput, GetSolNetworkOperationOutput, GetSolNetworkOperationError, Credentials | HttpClient.HttpClient>;
export type GetSolNetworkPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 */
export declare const getSolNetworkPackage: API.OperationMethod<GetSolNetworkPackageInput & RegionInput, GetSolNetworkPackageOutput, GetSolNetworkPackageError, Credentials | HttpClient.HttpClient>;
export type GetSolNetworkPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the contents of a network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 */
export declare const getSolNetworkPackageContent: API.OperationMethod<GetSolNetworkPackageContentInput & RegionInput, GetSolNetworkPackageContentOutput, GetSolNetworkPackageContentError, Credentials | HttpClient.HttpClient>;
export type GetSolNetworkPackageDescriptorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the content of the network service descriptor.
 *
 * A network service descriptor is a .yaml file in a network package that uses the TOSCA standard to describe the network functions you want to deploy and the Amazon Web Services infrastructure you want to deploy the network functions on.
 */
export declare const getSolNetworkPackageDescriptor: API.OperationMethod<GetSolNetworkPackageDescriptorInput & RegionInput, GetSolNetworkPackageDescriptorOutput, GetSolNetworkPackageDescriptorError, Credentials | HttpClient.HttpClient>;
export type InstantiateSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Instantiates a network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 *
 * Before you can instantiate a network instance, you have to create a network instance.
 * For more information, see CreateSolNetworkInstance.
 */
export declare const instantiateSolNetworkInstance: API.OperationMethod<InstantiateSolNetworkInstanceInput & RegionInput, InstantiateSolNetworkInstanceOutput, InstantiateSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type ListSolFunctionInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network function instances.
 *
 * A network function instance is a function in a function package .
 */
export declare const listSolFunctionInstances: API.PaginatedOperationMethod<ListSolFunctionInstancesInput & RegionInput, ListSolFunctionInstancesOutput, ListSolFunctionInstancesError, Credentials | HttpClient.HttpClient, ListSolFunctionInstanceInfo>;
export type ListSolFunctionPackagesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about function packages.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const listSolFunctionPackages: API.PaginatedOperationMethod<ListSolFunctionPackagesInput & RegionInput, ListSolFunctionPackagesOutput, ListSolFunctionPackagesError, Credentials | HttpClient.HttpClient, ListSolFunctionPackageInfo>;
export type ListSolNetworkInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your network instances.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 */
export declare const listSolNetworkInstances: API.PaginatedOperationMethod<ListSolNetworkInstancesInput & RegionInput, ListSolNetworkInstancesOutput, ListSolNetworkInstancesError, Credentials | HttpClient.HttpClient, ListSolNetworkInstanceInfo>;
export type ListSolNetworkOperationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details for a network operation, including when the operation started and the
 * status of the operation.
 *
 * A network operation is any operation that is done to your network, such as network instance instantiation or termination.
 */
export declare const listSolNetworkOperations: API.PaginatedOperationMethod<ListSolNetworkOperationsInput & RegionInput, ListSolNetworkOperationsOutput, ListSolNetworkOperationsError, Credentials | HttpClient.HttpClient, ListSolNetworkOperationsInfo>;
export type ListSolNetworkPackagesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network packages.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 */
export declare const listSolNetworkPackages: API.PaginatedOperationMethod<ListSolNetworkPackagesInput & RegionInput, ListSolNetworkPackagesOutput, ListSolNetworkPackagesError, Credentials | HttpClient.HttpClient, ListSolNetworkPackageInfo>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags for AWS TNB resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutSolFunctionPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads the contents of a function package.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const putSolFunctionPackageContent: API.OperationMethod<PutSolFunctionPackageContentInput & RegionInput, PutSolFunctionPackageContentOutput, PutSolFunctionPackageContentError, Credentials | HttpClient.HttpClient>;
export type PutSolNetworkPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads the contents of a network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 */
export declare const putSolNetworkPackageContent: API.OperationMethod<PutSolNetworkPackageContentInput & RegionInput, PutSolNetworkPackageContentOutput, PutSolNetworkPackageContentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags an AWS TNB resource.
 *
 * A tag is a label that you assign to an Amazon Web Services resource. Each tag consists of a key and an optional value. You can use tags to search and filter your resources or track your Amazon Web Services costs.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates a network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 *
 * You must terminate a network instance before you can delete it.
 */
export declare const terminateSolNetworkInstance: API.OperationMethod<TerminateSolNetworkInstanceInput & RegionInput, TerminateSolNetworkInstanceOutput, TerminateSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untags an AWS TNB resource.
 *
 * A tag is a label that you assign to an Amazon Web Services resource. Each tag consists of a key and an optional value. You can use tags to search and filter your resources or track your Amazon Web Services costs.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSolFunctionPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the operational state of function package.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const updateSolFunctionPackage: API.OperationMethod<UpdateSolFunctionPackageInput & RegionInput, UpdateSolFunctionPackageOutput, UpdateSolFunctionPackageError, Credentials | HttpClient.HttpClient>;
export type UpdateSolNetworkInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a network instance.
 *
 * A network instance is a single network created in Amazon Web Services TNB that can be deployed and on which life-cycle operations (like terminate, update, and delete) can be performed.
 *
 * Choose the *updateType* parameter to target the necessary update of the network instance.
 */
export declare const updateSolNetworkInstance: API.OperationMethod<UpdateSolNetworkInstanceInput & RegionInput, UpdateSolNetworkInstanceOutput, UpdateSolNetworkInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateSolNetworkPackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the operational state of a network package.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 *
 * A network service descriptor is a .yaml file in a network package that uses the TOSCA standard to describe the network functions you want to deploy and the Amazon Web Services infrastructure you want to deploy the network functions on.
 */
export declare const updateSolNetworkPackage: API.OperationMethod<UpdateSolNetworkPackageInput & RegionInput, UpdateSolNetworkPackageOutput, UpdateSolNetworkPackageError, Credentials | HttpClient.HttpClient>;
export type ValidateSolFunctionPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates function package content. This can be used as a dry run before uploading
 * function package content with PutSolFunctionPackageContent.
 *
 * A function package is a .zip file in CSAR (Cloud Service Archive) format that contains a network function (an ETSI standard telecommunication application) and function package descriptor that uses the TOSCA standard to describe how the network functions should run on your network.
 */
export declare const validateSolFunctionPackageContent: API.OperationMethod<ValidateSolFunctionPackageContentInput & RegionInput, ValidateSolFunctionPackageContentOutput, ValidateSolFunctionPackageContentError, Credentials | HttpClient.HttpClient>;
export type ValidateSolNetworkPackageContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates network package content. This can be used as a dry run before uploading
 * network package content with PutSolNetworkPackageContent.
 *
 * A network package is a .zip file in CSAR (Cloud Service Archive) format defines the function packages you want to deploy and the Amazon Web Services infrastructure you want to deploy them on.
 */
export declare const validateSolNetworkPackageContent: API.OperationMethod<ValidateSolNetworkPackageContentInput & RegionInput, ValidateSolNetworkPackageContentOutput, ValidateSolNetworkPackageContentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=tnb.d.ts.map