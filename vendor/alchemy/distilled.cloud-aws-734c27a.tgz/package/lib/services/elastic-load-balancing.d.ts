import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessPointNotFoundException_base: S.TaggedErrorClass<"AccessPointNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccessPointNotFoundException extends /*@__PURE__*/ AccessPointNotFoundException_base {
}
declare const CertificateNotFoundException_base: S.TaggedErrorClass<"CertificateNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundException extends /*@__PURE__*/ CertificateNotFoundException_base {
}
declare const DependencyThrottleException_base: S.TaggedErrorClass<"DependencyThrottleException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DependencyThrottleException extends /*@__PURE__*/ DependencyThrottleException_base {
}
declare const DuplicateAccessPointNameException_base: S.TaggedErrorClass<"DuplicateAccessPointNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateAccessPointNameException extends /*@__PURE__*/ DuplicateAccessPointNameException_base {
}
declare const DuplicateListenerException_base: S.TaggedErrorClass<"DuplicateListenerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateListenerException extends /*@__PURE__*/ DuplicateListenerException_base {
}
declare const DuplicatePolicyNameException_base: S.TaggedErrorClass<"DuplicatePolicyNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicatePolicyNameException extends /*@__PURE__*/ DuplicatePolicyNameException_base {
}
declare const DuplicateTagKeysException_base: S.TaggedErrorClass<"DuplicateTagKeysException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateTagKeysException extends /*@__PURE__*/ DuplicateTagKeysException_base {
}
declare const InvalidConfigurationRequestException_base: S.TaggedErrorClass<"InvalidConfigurationRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidConfigurationRequestException extends /*@__PURE__*/ InvalidConfigurationRequestException_base {
}
declare const InvalidEndPointException_base: S.TaggedErrorClass<"InvalidEndPointException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEndPointException extends /*@__PURE__*/ InvalidEndPointException_base {
}
declare const InvalidSchemeException_base: S.TaggedErrorClass<"InvalidSchemeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSchemeException extends /*@__PURE__*/ InvalidSchemeException_base {
}
declare const InvalidSecurityGroupException_base: S.TaggedErrorClass<"InvalidSecurityGroupException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSecurityGroupException extends /*@__PURE__*/ InvalidSecurityGroupException_base {
}
declare const InvalidSubnetException_base: S.TaggedErrorClass<"InvalidSubnetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnetException extends /*@__PURE__*/ InvalidSubnetException_base {
}
declare const ListenerNotFoundException_base: S.TaggedErrorClass<"ListenerNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ListenerNotFoundException extends /*@__PURE__*/ ListenerNotFoundException_base {
}
declare const LoadBalancerAttributeNotFoundException_base: S.TaggedErrorClass<"LoadBalancerAttributeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LoadBalancerAttributeNotFoundException extends /*@__PURE__*/ LoadBalancerAttributeNotFoundException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const PolicyNotFoundException_base: S.TaggedErrorClass<"PolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyNotFoundException extends /*@__PURE__*/ PolicyNotFoundException_base {
}
declare const PolicyTypeNotFoundException_base: S.TaggedErrorClass<"PolicyTypeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyTypeNotFoundException extends /*@__PURE__*/ PolicyTypeNotFoundException_base {
}
declare const SubnetNotFoundException_base: S.TaggedErrorClass<"SubnetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotFoundException extends /*@__PURE__*/ SubnetNotFoundException_base {
}
declare const TooManyAccessPointsException_base: S.TaggedErrorClass<"TooManyAccessPointsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyAccessPointsException extends /*@__PURE__*/ TooManyAccessPointsException_base {
}
declare const TooManyPoliciesException_base: S.TaggedErrorClass<"TooManyPoliciesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPoliciesException extends /*@__PURE__*/ TooManyPoliciesException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedProtocolException_base: S.TaggedErrorClass<"UnsupportedProtocolException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedProtocolException extends /*@__PURE__*/ UnsupportedProtocolException_base {
}
export type AccessPointName = string;
export type LoadBalancerNames = string[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsInput {
    LoadBalancerNames: string[];
    Tags: Tag[];
}
export interface AddTagsOutput {
}
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export interface ApplySecurityGroupsToLoadBalancerInput {
    LoadBalancerName: string;
    SecurityGroups: string[];
}
export interface ApplySecurityGroupsToLoadBalancerOutput {
    SecurityGroups?: string[] | undefined;
}
export type SubnetId = string;
export type Subnets = string[];
export interface AttachLoadBalancerToSubnetsInput {
    LoadBalancerName: string;
    Subnets: string[];
}
export interface AttachLoadBalancerToSubnetsOutput {
    Subnets?: string[] | undefined;
}
export type HealthCheckTarget = string;
export type HealthCheckInterval = number;
export type HealthCheckTimeout = number;
export type UnhealthyThreshold = number;
export type HealthyThreshold = number;
export interface HealthCheck {
    Target: string;
    Interval: number;
    Timeout: number;
    UnhealthyThreshold: number;
    HealthyThreshold: number;
}
export interface ConfigureHealthCheckInput {
    LoadBalancerName: string;
    HealthCheck: HealthCheck;
}
export interface ConfigureHealthCheckOutput {
    HealthCheck?: HealthCheck | undefined;
}
export type PolicyName = string;
export type CookieName = string;
export interface CreateAppCookieStickinessPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    CookieName: string;
}
export interface CreateAppCookieStickinessPolicyOutput {
}
export type CookieExpirationPeriod = number;
export interface CreateLBCookieStickinessPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    CookieExpirationPeriod?: number | undefined;
}
export interface CreateLBCookieStickinessPolicyOutput {
}
export type Protocol = string;
export type AccessPointPort = number;
export type InstancePort = number;
export type SSLCertificateId = string;
export interface Listener {
    Protocol: string;
    LoadBalancerPort: number;
    InstanceProtocol?: string | undefined;
    InstancePort: number;
    SSLCertificateId?: string | undefined;
}
export type Listeners = Listener[];
export type AvailabilityZone = string;
export type AvailabilityZones = string[];
export type LoadBalancerScheme = string;
export interface CreateAccessPointInput {
    LoadBalancerName: string;
    Listeners: Listener[];
    AvailabilityZones?: string[] | undefined;
    Subnets?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    Scheme?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DNSName = string;
export interface CreateAccessPointOutput {
    DNSName?: string | undefined;
}
export interface CreateLoadBalancerListenerInput {
    LoadBalancerName: string;
    Listeners: Listener[];
}
export interface CreateLoadBalancerListenerOutput {
}
export type PolicyTypeName = string;
export type AttributeName = string;
export type AttributeValue = string;
export interface PolicyAttribute {
    AttributeName?: string | undefined;
    AttributeValue?: string | undefined;
}
export type PolicyAttributes = PolicyAttribute[];
export interface CreateLoadBalancerPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
    PolicyTypeName: string;
    PolicyAttributes?: PolicyAttribute[] | undefined;
}
export interface CreateLoadBalancerPolicyOutput {
}
export interface DeleteAccessPointInput {
    LoadBalancerName: string;
}
export interface DeleteAccessPointOutput {
}
export type Ports = number[];
export interface DeleteLoadBalancerListenerInput {
    LoadBalancerName: string;
    LoadBalancerPorts: number[];
}
export interface DeleteLoadBalancerListenerOutput {
}
export interface DeleteLoadBalancerPolicyInput {
    LoadBalancerName: string;
    PolicyName: string;
}
export interface DeleteLoadBalancerPolicyOutput {
}
export type InstanceId = string;
export interface Instance {
    InstanceId?: string | undefined;
}
export type Instances = Instance[];
export interface DeregisterEndPointsInput {
    LoadBalancerName: string;
    Instances: Instance[];
}
export interface DeregisterEndPointsOutput {
    Instances?: Instance[] | undefined;
}
export type Marker = string;
export type PageSize = number;
export interface DescribeAccountLimitsInput {
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export type Name = string;
export type Max = string;
export interface Limit {
    Name?: string | undefined;
    Max?: string | undefined;
}
export type Limits = Limit[];
export interface DescribeAccountLimitsOutput {
    Limits?: Limit[] | undefined;
    NextMarker?: string | undefined;
}
export interface DescribeEndPointStateInput {
    LoadBalancerName: string;
    Instances?: Instance[] | undefined;
}
export type State = string;
export type ReasonCode = string;
export type Description = string;
export interface InstanceState {
    InstanceId?: string | undefined;
    State?: string | undefined;
    ReasonCode?: string | undefined;
    Description?: string | undefined;
}
export type InstanceStates = InstanceState[];
export interface DescribeEndPointStateOutput {
    InstanceStates?: InstanceState[] | undefined;
}
export interface DescribeLoadBalancerAttributesInput {
    LoadBalancerName: string;
}
export type CrossZoneLoadBalancingEnabled = boolean;
export interface CrossZoneLoadBalancing {
    Enabled: boolean;
}
export type AccessLogEnabled = boolean;
export type S3BucketName = string;
export type AccessLogInterval = number;
export type AccessLogPrefix = string;
export interface AccessLog {
    Enabled: boolean;
    S3BucketName?: string | undefined;
    EmitInterval?: number | undefined;
    S3BucketPrefix?: string | undefined;
}
export type ConnectionDrainingEnabled = boolean;
export type ConnectionDrainingTimeout = number;
export interface ConnectionDraining {
    Enabled: boolean;
    Timeout?: number | undefined;
}
export type IdleTimeout = number;
export interface ConnectionSettings {
    IdleTimeout: number;
}
export type AdditionalAttributeKey = string;
export type AdditionalAttributeValue = string;
export interface AdditionalAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type AdditionalAttributes = AdditionalAttribute[];
export interface LoadBalancerAttributes {
    CrossZoneLoadBalancing?: CrossZoneLoadBalancing | undefined;
    AccessLog?: AccessLog | undefined;
    ConnectionDraining?: ConnectionDraining | undefined;
    ConnectionSettings?: ConnectionSettings | undefined;
    AdditionalAttributes?: AdditionalAttribute[] | undefined;
}
export interface DescribeLoadBalancerAttributesOutput {
    LoadBalancerAttributes?: LoadBalancerAttributes | undefined;
}
export type PolicyNames = string[];
export interface DescribeLoadBalancerPoliciesInput {
    LoadBalancerName?: string | undefined;
    PolicyNames?: string[] | undefined;
}
export interface PolicyAttributeDescription {
    AttributeName?: string | undefined;
    AttributeValue?: string | undefined;
}
export type PolicyAttributeDescriptions = PolicyAttributeDescription[];
export interface PolicyDescription {
    PolicyName?: string | undefined;
    PolicyTypeName?: string | undefined;
    PolicyAttributeDescriptions?: PolicyAttributeDescription[] | undefined;
}
export type PolicyDescriptions = PolicyDescription[];
export interface DescribeLoadBalancerPoliciesOutput {
    PolicyDescriptions?: PolicyDescription[] | undefined;
}
export type PolicyTypeNames = string[];
export interface DescribeLoadBalancerPolicyTypesInput {
    PolicyTypeNames?: string[] | undefined;
}
export type AttributeType = string;
export type DefaultValue = string;
export type Cardinality = string;
export interface PolicyAttributeTypeDescription {
    AttributeName?: string | undefined;
    AttributeType?: string | undefined;
    Description?: string | undefined;
    DefaultValue?: string | undefined;
    Cardinality?: string | undefined;
}
export type PolicyAttributeTypeDescriptions = PolicyAttributeTypeDescription[];
export interface PolicyTypeDescription {
    PolicyTypeName?: string | undefined;
    Description?: string | undefined;
    PolicyAttributeTypeDescriptions?: PolicyAttributeTypeDescription[] | undefined;
}
export type PolicyTypeDescriptions = PolicyTypeDescription[];
export interface DescribeLoadBalancerPolicyTypesOutput {
    PolicyTypeDescriptions?: PolicyTypeDescription[] | undefined;
}
export interface DescribeAccessPointsInput {
    LoadBalancerNames?: string[] | undefined;
    Marker?: string | undefined;
    PageSize?: number | undefined;
}
export interface ListenerDescription {
    Listener?: Listener | undefined;
    PolicyNames?: string[] | undefined;
}
export type ListenerDescriptions = ListenerDescription[];
export interface AppCookieStickinessPolicy {
    PolicyName?: string | undefined;
    CookieName?: string | undefined;
}
export type AppCookieStickinessPolicies = AppCookieStickinessPolicy[];
export interface LBCookieStickinessPolicy {
    PolicyName?: string | undefined;
    CookieExpirationPeriod?: number | undefined;
}
export type LBCookieStickinessPolicies = LBCookieStickinessPolicy[];
export interface Policies {
    AppCookieStickinessPolicies?: AppCookieStickinessPolicy[] | undefined;
    LBCookieStickinessPolicies?: LBCookieStickinessPolicy[] | undefined;
    OtherPolicies?: string[] | undefined;
}
export interface BackendServerDescription {
    InstancePort?: number | undefined;
    PolicyNames?: string[] | undefined;
}
export type BackendServerDescriptions = BackendServerDescription[];
export type VPCId = string;
export type SecurityGroupOwnerAlias = string;
export type SecurityGroupName = string;
export interface SourceSecurityGroup {
    OwnerAlias?: string | undefined;
    GroupName?: string | undefined;
}
export type CreatedTime = Date;
export interface LoadBalancerDescription {
    LoadBalancerName?: string | undefined;
    DNSName?: string | undefined;
    CanonicalHostedZoneName?: string | undefined;
    CanonicalHostedZoneNameID?: string | undefined;
    ListenerDescriptions?: ListenerDescription[] | undefined;
    Policies?: Policies | undefined;
    BackendServerDescriptions?: BackendServerDescription[] | undefined;
    AvailabilityZones?: string[] | undefined;
    Subnets?: string[] | undefined;
    VPCId?: string | undefined;
    Instances?: Instance[] | undefined;
    HealthCheck?: HealthCheck | undefined;
    SourceSecurityGroup?: SourceSecurityGroup | undefined;
    SecurityGroups?: string[] | undefined;
    CreatedTime?: Date | undefined;
    Scheme?: string | undefined;
}
export type LoadBalancerDescriptions = LoadBalancerDescription[];
export interface DescribeAccessPointsOutput {
    LoadBalancerDescriptions?: LoadBalancerDescription[] | undefined;
    NextMarker?: string | undefined;
}
export type LoadBalancerNamesMax20 = string[];
export interface DescribeTagsInput {
    LoadBalancerNames: string[];
}
export interface TagDescription {
    LoadBalancerName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type TagDescriptions = TagDescription[];
export interface DescribeTagsOutput {
    TagDescriptions?: TagDescription[] | undefined;
}
export interface DetachLoadBalancerFromSubnetsInput {
    LoadBalancerName: string;
    Subnets: string[];
}
export interface DetachLoadBalancerFromSubnetsOutput {
    Subnets?: string[] | undefined;
}
export interface RemoveAvailabilityZonesInput {
    LoadBalancerName: string;
    AvailabilityZones: string[];
}
export interface RemoveAvailabilityZonesOutput {
    AvailabilityZones?: string[] | undefined;
}
export interface AddAvailabilityZonesInput {
    LoadBalancerName: string;
    AvailabilityZones: string[];
}
export interface AddAvailabilityZonesOutput {
    AvailabilityZones?: string[] | undefined;
}
export interface ModifyLoadBalancerAttributesInput {
    LoadBalancerName: string;
    LoadBalancerAttributes: LoadBalancerAttributes;
}
export interface ModifyLoadBalancerAttributesOutput {
    LoadBalancerName?: string | undefined;
    LoadBalancerAttributes?: LoadBalancerAttributes | undefined;
}
export interface RegisterEndPointsInput {
    LoadBalancerName: string;
    Instances: Instance[];
}
export interface RegisterEndPointsOutput {
    Instances?: Instance[] | undefined;
}
export interface TagKeyOnly {
    Key?: string | undefined;
}
export type TagKeyList = TagKeyOnly[];
export interface RemoveTagsInput {
    LoadBalancerNames: string[];
    Tags: TagKeyOnly[];
}
export interface RemoveTagsOutput {
}
export interface SetLoadBalancerListenerSSLCertificateInput {
    LoadBalancerName: string;
    LoadBalancerPort: number;
    SSLCertificateId: string;
}
export interface SetLoadBalancerListenerSSLCertificateOutput {
}
export type EndPointPort = number;
export interface SetLoadBalancerPoliciesForBackendServerInput {
    LoadBalancerName: string;
    InstancePort: number;
    PolicyNames: string[];
}
export interface SetLoadBalancerPoliciesForBackendServerOutput {
}
export interface SetLoadBalancerPoliciesOfListenerInput {
    LoadBalancerName: string;
    LoadBalancerPort: number;
    PolicyNames: string[];
}
export interface SetLoadBalancerPoliciesOfListenerOutput {
}
export type ErrorDescription = string;
export type AddTagsError = AccessPointNotFoundException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified load balancer. Each load balancer can have a maximum of 10 tags.
 *
 * Each tag consists of a key and an optional value. If a tag with the same key is already associated
 * with the load balancer, `AddTags` updates its value.
 *
 * For more information, see Tag Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const addTags: API.OperationMethod<AddTagsInput & RegionInput, AddTagsOutput, AddTagsError, Credentials | HttpClient.HttpClient>;
export type ApplySecurityGroupsToLoadBalancerError = AccessPointNotFoundException | InvalidConfigurationRequestException | InvalidSecurityGroupException | CommonErrors;
/**
 * Associates one or more security groups with your load balancer in a virtual private cloud (VPC). The specified security groups override the previously associated security groups.
 *
 * For more information, see Security Groups for Load Balancers in a VPC
 * in the *Classic Load Balancers Guide*.
 */
export declare const applySecurityGroupsToLoadBalancer: API.OperationMethod<ApplySecurityGroupsToLoadBalancerInput & RegionInput, ApplySecurityGroupsToLoadBalancerOutput, ApplySecurityGroupsToLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type AttachLoadBalancerToSubnetsError = AccessPointNotFoundException | InvalidConfigurationRequestException | InvalidSubnetException | SubnetNotFoundException | CommonErrors;
/**
 * Adds one or more subnets to the set of configured subnets for the specified load balancer.
 *
 * The load balancer evenly distributes requests across all registered subnets.
 * For more information, see Add or Remove Subnets for Your Load Balancer in a VPC
 * in the *Classic Load Balancers Guide*.
 */
export declare const attachLoadBalancerToSubnets: API.OperationMethod<AttachLoadBalancerToSubnetsInput & RegionInput, AttachLoadBalancerToSubnetsOutput, AttachLoadBalancerToSubnetsError, Credentials | HttpClient.HttpClient>;
export type ConfigureHealthCheckError = AccessPointNotFoundException | CommonErrors;
/**
 * Specifies the health check settings to use when evaluating the health state of your EC2 instances.
 *
 * For more information, see Configure Health Checks for Your Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const configureHealthCheck: API.OperationMethod<ConfigureHealthCheckInput & RegionInput, ConfigureHealthCheckOutput, ConfigureHealthCheckError, Credentials | HttpClient.HttpClient>;
export type CreateAppCookieStickinessPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | TooManyPoliciesException | CommonErrors;
/**
 * Generates a stickiness policy with sticky session lifetimes that follow that of an application-generated cookie. This policy can be associated only with HTTP/HTTPS listeners.
 *
 * This policy is similar to the policy created by CreateLBCookieStickinessPolicy,
 * except that the lifetime of the special Elastic Load Balancing cookie, `AWSELB`,
 * follows the lifetime of the application-generated cookie specified in the policy configuration.
 * The load balancer only inserts a new stickiness cookie when the application response
 * includes a new application cookie.
 *
 * If the application cookie is explicitly removed or expires, the session stops being sticky until a new application cookie is issued.
 *
 * For more information, see Application-Controlled Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const createAppCookieStickinessPolicy: API.OperationMethod<CreateAppCookieStickinessPolicyInput & RegionInput, CreateAppCookieStickinessPolicyOutput, CreateAppCookieStickinessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateLBCookieStickinessPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | TooManyPoliciesException | CommonErrors;
/**
 * Generates a stickiness policy with sticky session lifetimes controlled by the lifetime of the browser (user-agent) or a specified expiration period. This policy can be associated only with HTTP/HTTPS listeners.
 *
 * When a load balancer implements this policy, the load balancer uses a special cookie to track the instance for each request. When the load balancer receives a request, it first checks to see if this cookie is present in the request.
 * If so, the load balancer sends the request to the application server specified in the cookie. If not, the load balancer sends the request to a server that is chosen based on the existing load-balancing algorithm.
 *
 * A cookie is inserted into the response for binding subsequent requests from the same user to that server. The validity of the cookie is based on the cookie expiration time, which is specified in the policy configuration.
 *
 * For more information, see Duration-Based Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLBCookieStickinessPolicy: API.OperationMethod<CreateLBCookieStickinessPolicyInput & RegionInput, CreateLBCookieStickinessPolicyOutput, CreateLBCookieStickinessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerError = CertificateNotFoundException | DuplicateAccessPointNameException | DuplicateTagKeysException | InvalidConfigurationRequestException | InvalidSchemeException | InvalidSecurityGroupException | InvalidSubnetException | OperationNotPermittedException | SubnetNotFoundException | TooManyAccessPointsException | TooManyTagsException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates a Classic Load Balancer.
 *
 * You can add listeners, security groups, subnets, and tags when you create your load balancer,
 * or you can add them later using CreateLoadBalancerListeners,
 * ApplySecurityGroupsToLoadBalancer, AttachLoadBalancerToSubnets,
 * and AddTags.
 *
 * To describe your current load balancers, see DescribeLoadBalancers.
 * When you are finished with a load balancer, you can delete it using
 * DeleteLoadBalancer.
 *
 * You can create up to 20 load balancers per region per account.
 * You can request an increase for the number of load balancers for your account.
 * For more information, see Limits for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLoadBalancer: API.OperationMethod<CreateAccessPointInput & RegionInput, CreateAccessPointOutput, CreateLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerListenersError = AccessPointNotFoundException | CertificateNotFoundException | DuplicateListenerException | InvalidConfigurationRequestException | UnsupportedProtocolException | CommonErrors;
/**
 * Creates one or more listeners for the specified load balancer. If a listener with the specified port does not already exist, it is created; otherwise, the properties of the new listener must match the properties of the existing listener.
 *
 * For more information, see Listeners for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const createLoadBalancerListeners: API.OperationMethod<CreateLoadBalancerListenerInput & RegionInput, CreateLoadBalancerListenerOutput, CreateLoadBalancerListenersError, Credentials | HttpClient.HttpClient>;
export type CreateLoadBalancerPolicyError = AccessPointNotFoundException | DuplicatePolicyNameException | InvalidConfigurationRequestException | PolicyTypeNotFoundException | TooManyPoliciesException | CommonErrors;
/**
 * Creates a policy with the specified attributes for the specified load balancer.
 *
 * Policies are settings that are saved for your load balancer and that can be applied to the listener or the application server, depending on the policy type.
 */
export declare const createLoadBalancerPolicy: API.OperationMethod<CreateLoadBalancerPolicyInput & RegionInput, CreateLoadBalancerPolicyOutput, CreateLoadBalancerPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerError = CommonErrors;
/**
 * Deletes the specified load balancer.
 *
 * If you are attempting to recreate a load balancer, you must reconfigure all settings. The DNS name associated with a deleted load balancer are no longer usable. The name and associated DNS record of the deleted load balancer no longer exist and traffic sent to any of its IP addresses is no longer delivered to your instances.
 *
 * If the load balancer does not exist or has already been deleted, the call to
 * `DeleteLoadBalancer` still succeeds.
 */
export declare const deleteLoadBalancer: API.OperationMethod<DeleteAccessPointInput & RegionInput, DeleteAccessPointOutput, DeleteLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerListenersError = AccessPointNotFoundException | CommonErrors;
/**
 * Deletes the specified listeners from the specified load balancer.
 */
export declare const deleteLoadBalancerListeners: API.OperationMethod<DeleteLoadBalancerListenerInput & RegionInput, DeleteLoadBalancerListenerOutput, DeleteLoadBalancerListenersError, Credentials | HttpClient.HttpClient>;
export type DeleteLoadBalancerPolicyError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Deletes the specified policy from the specified load balancer. This policy must not be enabled for any listeners.
 */
export declare const deleteLoadBalancerPolicy: API.OperationMethod<DeleteLoadBalancerPolicyInput & RegionInput, DeleteLoadBalancerPolicyOutput, DeleteLoadBalancerPolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterInstancesFromLoadBalancerError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Deregisters the specified instances from the specified load balancer. After the instance is deregistered, it no longer receives traffic from the load balancer.
 *
 * You can use DescribeLoadBalancers to verify that the instance is deregistered from the load balancer.
 *
 * For more information, see Register or De-Register EC2 Instances
 * in the *Classic Load Balancers Guide*.
 */
export declare const deregisterInstancesFromLoadBalancer: API.OperationMethod<DeregisterEndPointsInput & RegionInput, DeregisterEndPointsOutput, DeregisterInstancesFromLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = CommonErrors;
/**
 * Describes the current Elastic Load Balancing resource limits for your AWS account.
 *
 * For more information, see Limits for Your Classic Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const describeAccountLimits: API.OperationMethod<DescribeAccountLimitsInput & RegionInput, DescribeAccountLimitsOutput, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeInstanceHealthError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Describes the state of the specified instances with respect to the specified load balancer. If no instances are specified, the call describes the state of all instances that are currently registered with the load balancer. If instances are specified, their state is returned even if they are no longer registered with the load balancer. The state of terminated instances is not returned.
 */
export declare const describeInstanceHealth: API.OperationMethod<DescribeEndPointStateInput & RegionInput, DescribeEndPointStateOutput, DescribeInstanceHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerAttributesError = AccessPointNotFoundException | LoadBalancerAttributeNotFoundException | CommonErrors;
/**
 * Describes the attributes for the specified load balancer.
 */
export declare const describeLoadBalancerAttributes: API.OperationMethod<DescribeLoadBalancerAttributesInput & RegionInput, DescribeLoadBalancerAttributesOutput, DescribeLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerPoliciesError = AccessPointNotFoundException | PolicyNotFoundException | CommonErrors;
/**
 * Describes the specified policies.
 *
 * If you specify a load balancer name, the action returns the descriptions of all policies created for the load balancer.
 * If you specify a policy name associated with your load balancer, the action returns the description of that policy.
 * If you don't specify a load balancer name, the action returns descriptions of the specified sample policies, or descriptions of all sample policies.
 * The names of the sample policies have the `ELBSample-` prefix.
 */
export declare const describeLoadBalancerPolicies: API.OperationMethod<DescribeLoadBalancerPoliciesInput & RegionInput, DescribeLoadBalancerPoliciesOutput, DescribeLoadBalancerPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancerPolicyTypesError = PolicyTypeNotFoundException | CommonErrors;
/**
 * Describes the specified load balancer policy types or all load balancer policy types.
 *
 * The description of each type indicates how it can be used. For example,
 * some policies can be used only with layer 7 listeners,
 * some policies can be used only with layer 4 listeners,
 * and some policies can be used only with your EC2 instances.
 *
 * You can use CreateLoadBalancerPolicy to create a policy configuration for any of these policy types.
 * Then, depending on the policy type, use either SetLoadBalancerPoliciesOfListener or
 * SetLoadBalancerPoliciesForBackendServer to set the policy.
 */
export declare const describeLoadBalancerPolicyTypes: API.OperationMethod<DescribeLoadBalancerPolicyTypesInput & RegionInput, DescribeLoadBalancerPolicyTypesOutput, DescribeLoadBalancerPolicyTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeLoadBalancersError = AccessPointNotFoundException | DependencyThrottleException | CommonErrors;
/**
 * Describes the specified the load balancers. If no load balancers are specified, the call describes all of your load balancers.
 */
export declare const describeLoadBalancers: API.PaginatedOperationMethod<DescribeAccessPointsInput & RegionInput, DescribeAccessPointsOutput, DescribeLoadBalancersError, Credentials | HttpClient.HttpClient, LoadBalancerDescription>;
export type DescribeTagsError = AccessPointNotFoundException | CommonErrors;
/**
 * Describes the tags associated with the specified load balancers.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsInput & RegionInput, DescribeTagsOutput, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DetachLoadBalancerFromSubnetsError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Removes the specified subnets from the set of configured subnets for the load balancer.
 *
 * After a subnet is removed, all EC2 instances registered with the load balancer
 * in the removed subnet go into the `OutOfService` state. Then,
 * the load balancer balances the traffic among the remaining routable subnets.
 */
export declare const detachLoadBalancerFromSubnets: API.OperationMethod<DetachLoadBalancerFromSubnetsInput & RegionInput, DetachLoadBalancerFromSubnetsOutput, DetachLoadBalancerFromSubnetsError, Credentials | HttpClient.HttpClient>;
export type DisableAvailabilityZonesForLoadBalancerError = AccessPointNotFoundException | InvalidConfigurationRequestException | CommonErrors;
/**
 * Removes the specified Availability Zones from the set of Availability Zones for the specified load balancer
 * in EC2-Classic or a default VPC.
 *
 * For load balancers in a non-default VPC, use DetachLoadBalancerFromSubnets.
 *
 * There must be at least one Availability Zone registered with a load balancer at all times.
 * After an Availability Zone is removed, all instances registered with the load balancer that are in the removed
 * Availability Zone go into the `OutOfService` state. Then, the load balancer attempts to equally balance
 * the traffic among its remaining Availability Zones.
 *
 * For more information, see Add or Remove Availability Zones
 * in the *Classic Load Balancers Guide*.
 */
export declare const disableAvailabilityZonesForLoadBalancer: API.OperationMethod<RemoveAvailabilityZonesInput & RegionInput, RemoveAvailabilityZonesOutput, DisableAvailabilityZonesForLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type EnableAvailabilityZonesForLoadBalancerError = AccessPointNotFoundException | CommonErrors;
/**
 * Adds the specified Availability Zones to the set of Availability Zones for the specified load balancer
 * in EC2-Classic or a default VPC.
 *
 * For load balancers in a non-default VPC, use AttachLoadBalancerToSubnets.
 *
 * The load balancer evenly distributes requests across all its registered Availability Zones
 * that contain instances. For more information, see Add or Remove Availability Zones
 * in the *Classic Load Balancers Guide*.
 */
export declare const enableAvailabilityZonesForLoadBalancer: API.OperationMethod<AddAvailabilityZonesInput & RegionInput, AddAvailabilityZonesOutput, EnableAvailabilityZonesForLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type ModifyLoadBalancerAttributesError = AccessPointNotFoundException | InvalidConfigurationRequestException | LoadBalancerAttributeNotFoundException | CommonErrors;
/**
 * Modifies the attributes of the specified load balancer.
 *
 * You can modify the load balancer attributes, such as `AccessLogs`, `ConnectionDraining`, and
 * `CrossZoneLoadBalancing` by either enabling or disabling them. Or, you can modify the load balancer attribute
 * `ConnectionSettings` by specifying an idle connection timeout value for your load balancer.
 *
 * For more information, see the following in the *Classic Load Balancers Guide*:
 *
 * - Cross-Zone Load Balancing
 *
 * - Connection Draining
 *
 * - Access Logs
 *
 * - Idle Connection Timeout
 */
export declare const modifyLoadBalancerAttributes: API.OperationMethod<ModifyLoadBalancerAttributesInput & RegionInput, ModifyLoadBalancerAttributesOutput, ModifyLoadBalancerAttributesError, Credentials | HttpClient.HttpClient>;
export type RegisterInstancesWithLoadBalancerError = AccessPointNotFoundException | InvalidEndPointException | CommonErrors;
/**
 * Adds the specified instances to the specified load balancer.
 *
 * The instance must be a running instance in the same network as the load balancer (EC2-Classic or the same VPC). If you have EC2-Classic instances and a load balancer in a VPC with ClassicLink enabled, you can link the EC2-Classic instances to that VPC and then register the linked EC2-Classic instances with the load balancer in the VPC.
 *
 * Note that `RegisterInstanceWithLoadBalancer` completes when the request has been registered.
 * Instance registration takes a little time to complete. To check the state of the registered instances, use
 * DescribeLoadBalancers or DescribeInstanceHealth.
 *
 * After the instance is registered, it starts receiving traffic
 * and requests from the load balancer. Any instance that is not
 * in one of the Availability Zones registered for the load balancer
 * is moved to the `OutOfService` state. If an Availability Zone
 * is added to the load balancer later, any instances registered with the
 * load balancer move to the `InService` state.
 *
 * To deregister instances from a load balancer, use DeregisterInstancesFromLoadBalancer.
 *
 * For more information, see Register or De-Register EC2 Instances
 * in the *Classic Load Balancers Guide*.
 */
export declare const registerInstancesWithLoadBalancer: API.OperationMethod<RegisterEndPointsInput & RegionInput, RegisterEndPointsOutput, RegisterInstancesWithLoadBalancerError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = AccessPointNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified load balancer.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsInput & RegionInput, RemoveTagsOutput, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerListenerSSLCertificateError = AccessPointNotFoundException | CertificateNotFoundException | InvalidConfigurationRequestException | ListenerNotFoundException | UnsupportedProtocolException | CommonErrors;
/**
 * Sets the certificate that terminates the specified listener's SSL connections. The specified certificate replaces any prior certificate that was used on the same load balancer and port.
 *
 * For more information about updating your SSL certificate, see
 * Replace the SSL Certificate for Your Load Balancer
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerListenerSSLCertificate: API.OperationMethod<SetLoadBalancerListenerSSLCertificateInput & RegionInput, SetLoadBalancerListenerSSLCertificateOutput, SetLoadBalancerListenerSSLCertificateError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerPoliciesForBackendServerError = AccessPointNotFoundException | InvalidConfigurationRequestException | PolicyNotFoundException | CommonErrors;
/**
 * Replaces the set of policies associated with the specified port on which the EC2 instance is listening with a new set of policies.
 * At this time, only the back-end server authentication policy type can be applied to the instance ports; this policy type is composed of multiple public key policies.
 *
 * Each time you use `SetLoadBalancerPoliciesForBackendServer` to enable the policies,
 * use the `PolicyNames` parameter to list the policies that you want to enable.
 *
 * You can use DescribeLoadBalancers or DescribeLoadBalancerPolicies to verify that the policy
 * is associated with the EC2 instance.
 *
 * For more information about enabling back-end instance authentication, see Configure Back-end Instance Authentication
 * in the *Classic Load Balancers Guide*. For more information about Proxy Protocol, see
 * Configure Proxy Protocol Support
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerPoliciesForBackendServer: API.OperationMethod<SetLoadBalancerPoliciesForBackendServerInput & RegionInput, SetLoadBalancerPoliciesForBackendServerOutput, SetLoadBalancerPoliciesForBackendServerError, Credentials | HttpClient.HttpClient>;
export type SetLoadBalancerPoliciesOfListenerError = AccessPointNotFoundException | InvalidConfigurationRequestException | ListenerNotFoundException | PolicyNotFoundException | CommonErrors;
/**
 * Replaces the current set of policies for the specified load balancer port with the specified set of policies.
 *
 * To enable back-end server authentication, use SetLoadBalancerPoliciesForBackendServer.
 *
 * For more information about setting policies, see
 * Update the SSL Negotiation Configuration,
 * Duration-Based Session Stickiness, and
 * Application-Controlled Session Stickiness
 * in the *Classic Load Balancers Guide*.
 */
export declare const setLoadBalancerPoliciesOfListener: API.OperationMethod<SetLoadBalancerPoliciesOfListenerInput & RegionInput, SetLoadBalancerPoliciesOfListenerOutput, SetLoadBalancerPoliciesOfListenerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elastic-load-balancing.d.ts.map