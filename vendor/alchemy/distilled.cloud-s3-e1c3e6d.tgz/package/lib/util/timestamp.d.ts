/**
 * Timestamp Formatting Utilities
 *
 * Handles formatting of Date objects according to AWS timestamp format types.
 */
import type { TimestampFormatType } from "../traits.ts";
/**
 * An ISO 8601 date-time without fractional seconds when they are zero
 * (`2019-12-16T23:48:18Z`), as the AWS SDKs send it.
 */
export declare const formatDateTime: (date: Date) => string;
/**
 * Format a timestamp according to the specified format.
 *
 * @param date - The date to format
 * @param format - The format type: "http-date", "epoch-seconds", or "date-time" (default)
 */
export declare function formatTimestamp(date: Date, format?: TimestampFormatType): string;
//# sourceMappingURL=timestamp.d.ts.map