import * as API from "@distilled.cloud/core/api";
import { type InvalidInput } from "@distilled.cloud/core/protocol-http";
import type { SdkError } from "@distilled.cloud/core/sdk-error";
import * as Effect from "effect/Effect";
import type * as HttpClient from "effect/http/HttpClient";
import * as Credentials from "./credentials.ts";
import type { EndpointError, ParseError } from "./errors.ts";
import * as Region from "./region.ts";
import * as SigV4 from "./sigv4.ts";
/**
 * Errors returned when resolving credentials or signing a URL, and the
 * `InvalidInput` of an S3 bucket or key that would address another resource.
 */
export type PresignError = Credentials.ProviderError | SigV4.SigningError | InvalidInput;
export { CryptoError, InvalidSigningHeaders, InvalidSigningUrl } from "./sigv4.ts";
/** Services required by the presigning helpers. */
export type PresignContext = Credentials.Credentials | Region.Region;
/**
 * Options for {@link presignUrl}.
 */
export interface PresignUrlOptions {
    /**
     * HTTP method the presigned URL authorizes.
     * @default "GET"
     */
    readonly method?: string;
    /**
     * Full URL to presign (scheme + host + path + any query parameters that
     * should be part of the signature).
     */
    readonly url: string;
    /**
     * SigV4 signing service name (e.g. `s3`, `execute-api`, `lambda`).
     */
    readonly service: string;
    /**
     * SigV4 signing region. Defaults to the {@link Region.Region} service.
     */
    readonly region?: string;
    /**
     * Number of seconds the URL remains valid.
     * @default 900
     */
    readonly expiresIn?: number;
    /**
     * Headers to sign into the URL (`X-Amz-SignedHeaders`). The consumer of
     * the presigned URL must send these headers verbatim or the signature
     * fails to validate.
     */
    readonly headers?: Record<string, string>;
    /**
     * Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now.
     * Signing is deterministic for a fixed datetime + credentials, which
     * makes this useful for tests.
     */
    readonly datetime?: string;
}
/**
 * SigV4 query-string presigning for an arbitrary AWS URL.
 *
 * Pure client-side computation -- no AWS API call is made. Credentials are
 * resolved from the {@link Credentials.Credentials} service (the presigned
 * URL inherits that identity's IAM permissions) and the signing region
 * defaults to the {@link Region.Region} service.
 */
export declare const presignUrl: (options: PresignUrlOptions) => Effect.Effect<string, PresignError, PresignContext>;
/**
 * Options for {@link presignS3Url}.
 */
export interface PresignS3UrlOptions {
    /**
     * HTTP method the presigned URL authorizes.
     * @default "GET"
     */
    readonly method?: "GET" | "PUT" | "HEAD" | "DELETE" | undefined;
    /**
     * Name of the bucket the object lives in.
     */
    readonly bucket: string;
    /**
     * Key of the object.
     */
    readonly key: string;
    /**
     * Specific object version to access, signed as the `versionId` query
     * parameter. If omitted, S3 uses the current version.
     */
    readonly versionId?: string | undefined;
    /**
     * Region the bucket lives in (used for both the endpoint and the SigV4
     * credential scope). Defaults to the {@link Region.Region} service.
     */
    readonly region?: string | undefined;
    /**
     * Number of seconds the URL remains valid.
     * @default 900
     */
    readonly expiresIn?: number | undefined;
    /**
     * `Content-Type` header to sign into the URL. The consumer (e.g. a PUT
     * uploader) must send exactly this `Content-Type` or S3 rejects the
     * request with a signature mismatch.
     */
    readonly contentType?: string | undefined;
    /**
     * `response-content-type` override for GET URLs -- S3 responds with this
     * `Content-Type` regardless of the stored object's metadata.
     */
    readonly responseContentType?: string | undefined;
    /**
     * Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now.
     */
    readonly datetime?: string | undefined;
}
/**
 * SigV4 query-string presigning for S3 objects.
 *
 * Produces a virtual-hosted-style URL
 * (`https://{bucket}.s3.{region}.{dnsSuffix}/{key}`, with the DNS suffix of
 * the region's partition, e.g. `amazonaws.eu` in `aws-eusc`), or a
 * path-style URL under the custom {@link Endpoint.Endpoint} when one is
 * provided (e.g. LocalStack or S3-compatible stores).
 *
 * Pure client-side computation -- no AWS API call is made. The URL inherits
 * the IAM permissions of the identity resolved from the
 * {@link Credentials.Credentials} service.
 *
 * Fails with `InvalidInput`, before anything is signed, for a bucket or key
 * that would address another resource: an empty value, a `.` or `..` bucket
 * or key segment, or (without a custom endpoint) a bucket that is not
 * plain host-name text.
 */
export declare const presignS3Url: (options: PresignS3UrlOptions) => Effect.Effect<string, PresignError, PresignContext>;
/**
 * Options for {@link presignRequest}.
 */
export interface PresignRequestOptions {
    /**
     * Number of seconds the URL remains valid.
     * @default 900
     */
    readonly expiresIn?: number;
    /**
     * Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now.
     */
    readonly datetime?: string;
}
/**
 * A request presigned by {@link presignRequest}.
 */
export interface PresignedRequest {
    /** HTTP method the URL authorizes. */
    readonly method: string;
    /** The URL, with the signature and the input's `x-amz-*` fields in its query string. */
    readonly url: string;
    /**
     * Headers (lower-case names) the request must be sent with, each covered
     * by the signature. Empty when every field went into the URL.
     */
    readonly headers: Record<string, string>;
}
/**
 * Errors returned by {@link presignRequest}: {@link PresignError}, an input
 * the operation's serializer or endpoint rules refuse, and `SdkError` when
 * the operation can't be loaded.
 */
export type PresignRequestError = PresignError | ParseError | EndpointError | SdkError;
/**
 * SigV4 query-string presigning for any operation, from its typed input,
 * like the AWS SDK's `getSignedUrl(client, command)`.
 *
 * The request is the one a call to `operation` would send -- the same
 * serializer, middleware and endpoint rules -- signed into its query string
 * instead of its headers, so every member the input sets is pinned:
 *
 * - query members (`versionId`, `partNumber`, the `response-*` overrides)
 *   are signed into the URL;
 * - `x-amz-*` header members (`x-amz-meta-*`, `x-amz-tagging`,
 *   `x-amz-storage-class`, ...) are signed into the URL as query parameters,
 *   except the server-side encryption and checksum headers, which S3 reads
 *   only as headers;
 * - every other header member (`Content-Type`, `Content-Length`,
 *   `Content-MD5`, `If-None-Match`, `Range`, ...) and those exceptions are
 *   returned in `headers`. The request must send exactly these: a PUT with
 *   `ContentLength: 1024` accepts only a 1024-byte body.
 *
 * A member left out of the input is not signed, and the client may send it.
 * The body is not part of the signature (`UNSIGNED-PAYLOAD`); pin it with
 * `ContentLength`, `ContentMD5` or a `Checksum*` member. An input that
 * serializes into a body (an XML payload such as `PutObjectTagging`'s tag
 * set, or any JSON or query-protocol operation) fails with `InvalidInput`,
 * since a URL cannot carry it, as does an endpoint that signs with SigV4A
 * (an S3 Multi-Region Access Point).
 *
 * Pure client-side computation -- no API call is made. The URL inherits the
 * IAM permissions of the identity resolved from the
 * {@link Credentials.Credentials} service. The region is the input's
 * `region`, else the `Region` layer, else the credentials' region, and a
 * custom `Endpoint` is used as for any call.
 *
 * @example
 * ```ts
 * const upload = yield* Presign.presignRequest(
 *   S3.putObject,
 *   { Bucket: "uploads", Key: "avatar.png", ContentType: "image/png", ContentLength: 1024, IfNoneMatch: "*" },
 *   { expiresIn: 300 },
 * );
 * // fetch(upload.url, { method: upload.method, headers: upload.headers, body })
 * ```
 */
export declare const presignRequest: <I, O, E, R>(operation: API.OperationMethod<I, O, E, R>, input: Omit<I, "Body">, options?: PresignRequestOptions) => Effect.Effect<PresignedRequest, PresignRequestError, Exclude<R, HttpClient.HttpClient>>;
/**
 * A condition in an S3 POST policy: an exact field match (`{ acl: "private" }`),
 * a prefix match (`["starts-with", "$key", "uploads/"]`), or a size range
 * in bytes (`["content-length-range", 0, 10485760]`).
 */
export type PostPolicyCondition = Readonly<Record<string, string>> | readonly ["eq" | "starts-with", string, string] | readonly ["content-length-range", number, number];
/**
 * Options for {@link presignPost}.
 */
export interface PresignPostOptions {
    /** Bucket the form uploads into. */
    readonly bucket: string;
    /**
     * Key of the uploaded object. A key ending in `${filename}` lets the
     * browser fill in the file's name: the policy then allows any key that
     * starts with the text before it.
     */
    readonly key: string;
    /**
     * Region the bucket lives in (used for both the endpoint and the SigV4
     * credential scope). Defaults to the {@link Region.Region} service.
     */
    readonly region?: string;
    /**
     * Number of seconds the policy remains valid.
     * @default 900
     */
    readonly expiresIn?: number;
    /**
     * Conditions the upload must meet besides the returned fields, for example
     * `["content-length-range", 0, 10485760]` or
     * `["starts-with", "$Content-Type", "image/"]`.
     */
    readonly conditions?: ReadonlyArray<PostPolicyCondition>;
    /**
     * Form fields to send with exactly these values (`Content-Type`, `acl`,
     * `x-amz-meta-*`, `success_action_status`, ...). Each one is also added to
     * the policy as an exact match.
     */
    readonly fields?: Readonly<Record<string, string>>;
    /** Fixed signing datetime in `YYYYMMDDTHHMMSSZ` format. Defaults to now. */
    readonly datetime?: string;
}
/**
 * A browser upload form presigned by {@link presignPost}.
 */
export interface PresignedPost {
    /** The form's `action`: the bucket's URL. */
    readonly url: string;
    /**
     * Fields to send, in this order, before the `file` field, including the
     * policy and its signature.
     */
    readonly fields: Record<string, string>;
}
/**
 * Presign an S3 POST policy for a browser form upload, like the AWS SDK's
 * `createPresignedPost`. The browser sends a `multipart/form-data` POST to
 * `url` with `fields` and then the `file` field; S3 accepts it while the
 * policy is valid and the upload meets every condition.
 *
 * A policy can allow ranges and prefixes that a presigned URL can't, such as
 * any size up to 10 MB or any key under `uploads/`. For one exact request,
 * use {@link presignS3Url}.
 *
 * Pure client-side computation -- no AWS API call is made. The upload
 * inherits the IAM permissions of the identity resolved from the
 * {@link Credentials.Credentials} service. Fails with `InvalidInput` for a
 * bucket or key that would address another resource, as
 * {@link presignS3Url} does.
 *
 * @example
 * ```ts
 * const post = yield* Presign.presignPost({
 *   bucket: "uploads",
 *   key: "avatars/${filename}",
 *   conditions: [["content-length-range", 0, 10 * 1024 * 1024]],
 *   fields: { "Content-Type": "image/png" },
 * });
 * const form = new FormData();
 * for (const [name, value] of Object.entries(post.fields)) form.append(name, value);
 * form.append("file", file);
 * // fetch(post.url, { method: "POST", body: form })
 * ```
 */
export declare const presignPost: (options: PresignPostOptions) => Effect.Effect<PresignedPost, PresignError, PresignContext>;
//# sourceMappingURL=presign.d.ts.map