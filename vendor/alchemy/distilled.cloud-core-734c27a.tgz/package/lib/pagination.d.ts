import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Stream from "effect/Stream";
/**
 * Get a value from an object using a dot-separated path (e.g.
 * `"resultInfo.page"`). Used for pagination traits and nested access.
 */
export declare const getPath: (obj: unknown, path: string) => unknown;
/**
 * Collect the items a dot-separated path selects, flattening arrays as it
 * goes. Unlike {@link getPath} (which walks a single value and is used for
 * cursors/tokens), every segment here fans out over whatever the previous one
 * produced, so a path may cross a list:
 *
 * - `"items"` on `{ items: [a, b] }` -> `[a, b]` (the common flat case)
 * - `"edges.node"` on a Relay connection -> every edge's `node`
 *
 * `null`/`undefined` links are dropped rather than propagated, so a partially
 * null page yields the items it does have instead of nothing.
 */
export declare const getItems: (obj: unknown, path: string) => readonly unknown[];
/** Pagination trait describing how to navigate between pages. */
export interface PaginatedTrait {
    /** Pagination strategy */
    readonly mode?: "token" | "page" | "cursor" | "relay" | "link" | "keyset" | "single";
    /**
     * The name of the input member containing the page/cursor token. In link
     * mode it is also the query parameter read from the `rel="next"` URL.
     */
    readonly inputToken?: string;
    /**
     * The path to the output member containing the next page/cursor token. In
     * keyset mode it is a path within one item: the key the next page starts
     * after.
     */
    readonly outputToken?: string;
    /**
     * The path to the output member containing the paginated items. Segments
     * may cross arrays -- `"edges.node"` walks every edge and collects its
     * `node` (see {@link getItems}).
     */
    readonly items?: string;
    /** The name of the input member that limits page size */
    readonly pageSize?: string;
    /**
     * Relay extension: the path to the boolean that says whether another page
     * exists (`"pageInfo.hasNextPage"`). Relay connections keep returning the
     * last page's `endCursor` after the end, so the cursor alone can't
     * terminate traversal -- see {@link paginateRelay}.
     */
    readonly hasNextPage?: string;
}
export type PaginationStrategy = <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * The stream of a paginated operation whose trait lacks a field its
 * strategy reads: it fails with {@link SdkError} (part of every
 * operation's error channel, so the strategy's `E` is cast to hold it).
 * The generator refuses such traits.
 */
export declare const missingPaginationConfig: (message: string) => Stream.Stream<never>;
/**
 * Whether a continuation token/cursor returned by a paginated operation
 * means "no more pages".
 *
 * APIs mark the terminal page by omitting the output token, returning it
 * as `null`, or -- for several services (e.g. SSM, CloudWatch Logs) -- as an
 * empty string. Treating `""` as a live token re-requests the first page
 * forever (or fails with a ValidationException). Object tokens (e.g.
 * DynamoDB's `LastEvaluatedKey`) are always truthy and unaffected.
 */
export declare const isTerminalToken: (token: unknown) => boolean;
/**
 * Stream for single-shot list endpoints that still expose the paginated
 * surface -- emits exactly one page.
 */
export declare const paginateSingle: PaginationStrategy;
/**
 * Stream of pages using page-number pagination. The next page is taken from
 * `outputToken` when it advances; otherwise the page number is incremented,
 * terminating when a page comes back with no items (or no token).
 */
export declare const paginatePageNumber: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Stream of pages using cursor-based pagination -- follow `outputToken`
 * cursors until one comes back absent or repeats a previously requested cursor.
 * Empty pages still advance when they return a new cursor.
 */
export declare const paginateCursor: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Stream of pages using token-based pagination -- pass `outputToken` back as
 * `inputToken` until it comes back absent.
 */
export declare const paginateToken: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Stream of pages using keyset pagination: the next request starts after
 * the key of the page's last item. `inputToken` is the input member the key
 * goes to and `outputToken` the key's path within an item (both may be
 * dot-separated: Modal's `List*` calls take `pagination.createdBefore` and
 * key on each item's `createdAt`). Traversal ends on an empty page, a page
 * smaller than the requested `pageSize`, or a key that doesn't advance.
 */
export declare const paginateKeyset: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Stream of pages over a Relay connection -- pass `pageInfo.endCursor` back as
 * `after` for as long as `pageInfo.hasNextPage` is true.
 *
 * Relay is cursor pagination with one twist that breaks
 * {@link paginateCursor}: the terminal page still carries an `endCursor` (it
 * points at the last edge, not at "nothing left"). Only `hasNextPage`
 * distinguishes "more to fetch" from "that was everything", so this strategy
 * reads the boolean and treats the cursor as a pure position marker. A
 * connection that omits `pageInfo` entirely (or returns an empty page) also
 * terminates, so a malformed response can't spin forever.
 */
export declare const paginateRelay: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Hand a response's headers to the link traversal running on this fiber, if
 * any. Protocols call it for every response they decode; outside
 * {@link paginateLink} it does nothing.
 */
export declare const recordPageHeaders: (context: Context.Context<never>, headers: Readonly<Record<string, string | undefined>>) => void;
/**
 * The URL of the `rel="next"` link in a `Link` header value, e.g.
 * `<https://api.github.com/repositories/1/issues?page=2>; rel="next", <...>; rel="last"`.
 */
export declare const nextLink: (header: string | undefined) => string | undefined;
/**
 * Stream of pages that follows the `Link` response header: each request
 * takes `inputToken` from the query of the previous response's `rel="next"`
 * URL, and traversal ends when a response has no next link (or its token
 * repeats the current one). The response body carries no token, so this
 * works for APIs whose list responses are bare arrays.
 *
 * The protocol must report response headers through
 * {@link recordPageHeaders} (the REST protocol does); otherwise traversal
 * stops after the first page.
 */
export declare const paginateLink: <Input extends Record<string, unknown>, Output, E, R>(operation: (input: Input) => Effect.Effect<Output, E, R>, input: Input, pagination: PaginatedTrait) => Stream.Stream<Output, E, R>;
/**
 * Shared default pagination dispatcher for SDKs that use generic
 * token/cursor/page traversal.
 */
export declare const paginateWithDefaults: PaginationStrategy;
/**
 * Extracts individual items from a page stream.
 *
 * @param pages - A stream of page responses
 * @param itemsPath - Dot-separated path to the items in the page; segments may
 *   cross arrays (see {@link getItems})
 * @returns A Stream of individual items
 */
export declare const extractItems: <Output, Item, E, R>(pages: Stream.Stream<Output, E, R>, itemsPath: string) => Stream.Stream<Item, E, R>;
/**
 * The items of a stream of pages that are themselves the lists (bare-array
 * responses).
 */
export declare const extractArrayItems: <Output, Item, E, R>(pages: Stream.Stream<Output, E, R>) => Stream.Stream<Item, E, R>;
//# sourceMappingURL=pagination.d.ts.map