/** Unscaled numeric magnitude, or undefined for invalid/overflowing values. */
export declare const parseDockerByteSizeMagnitude: (value: string) => number | undefined;
/** Dockerfile size grammar allows zero; container shared memory does not. */
export declare const isDockerByteSize: (value: string) => boolean;
//# sourceMappingURL=DockerByteSize.d.ts.map