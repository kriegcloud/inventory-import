import { type Interaction } from "../../../Interaction.ts";
import type { TerminalCapabilities, TerminalOptions } from "../types.ts";
export interface SigilRuntime {
    readonly service: Interaction["Service"];
    readonly dispose: () => Promise<void>;
}
export declare const makeRuntime: (options: TerminalOptions, capabilities: TerminalCapabilities) => SigilRuntime;
//# sourceMappingURL=Runtime.d.ts.map