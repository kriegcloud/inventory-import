/**
 * AWS-Specific Rules Engine Functions
 *
 * Implementation of AWS extension functions for the rules engine.
 * @see https://smithy.io/2.0/aws/rules-engine/library-functions.html
 */
import type { ParsedArn, PartitionInfo, RulesValue } from "./expression.ts";
import partitionsData from "./partitions.json" with { type: "json" };
/** The partition data the rules read; the generator and its tests list regions from it. */
export { partitionsData };
/** Returns partition information for a given region. */
export declare function partition(region: RulesValue): PartitionInfo | undefined;
/**
 * The DNS suffix of the partition a region belongs to: `amazonaws.com` in
 * `aws`, `amazonaws.eu` in `aws-eusc`, `amazonaws.com.cn` in `aws-cn`.
 */
export declare const dnsSuffix: (region: string) => string;
/**
 * The DNS suffix of a region listed by name in partitions.json, or
 * `undefined` for a region known only by a partition's regex.
 */
export declare function regionDnsSuffix(region: string): string | undefined;
/** Parses an ARN string into its components. */
export declare function parseArn(value: RulesValue): ParsedArn | undefined;
/** Checks if a string is a valid virtual-hostable S3 bucket name. */
export declare function isVirtualHostableS3Bucket(value: RulesValue, allowSubDomains?: RulesValue): boolean;
//# sourceMappingURL=aws-functions.d.ts.map