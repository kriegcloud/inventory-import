import * as Context from "effect/Context";
import * as Layer from "effect/Layer";
import type { AuthProvider } from "./AuthProvider.ts";
declare const AuthProviders_base: Context.ServiceClass<AuthProviders, "AuthProviders", {
    [providerName: string]: AuthProvider<{
        method: string;
    }, unknown>;
}>;
/** Every registered {@link AuthProvider}, by provider name. */
export declare class AuthProviders extends AuthProviders_base {
}
/**
 * The registry a provider layer registers into: the ambient one when the
 * caller supplies it (to read the registrations back, as `alchemy profile`
 * does), otherwise a fresh one for this build. `Stack.build` provides it,
 * so callers never supply an empty registry.
 */
export declare const AuthProvidersLive: Layer.Layer<AuthProviders, never, never>;
export {};
//# sourceMappingURL=Registry.d.ts.map