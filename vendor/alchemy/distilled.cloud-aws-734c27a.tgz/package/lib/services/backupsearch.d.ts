import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GenericId = string;
export interface GetSearchJobInput {
    SearchJobIdentifier: string;
}
export interface SearchScopeSummary {
    TotalRecoveryPointsToScanCount?: number | undefined;
    TotalItemsToScanCount?: number | undefined;
}
export interface CurrentSearchProgress {
    RecoveryPointsScannedCount?: number | undefined;
    ItemsScannedCount?: number | undefined;
    ItemsMatchedCount?: number | undefined;
}
export type EncryptionKeyArn = string;
export type SearchJobState = "RUNNING" | "COMPLETED" | "STOPPING" | "STOPPED" | "FAILED" | (string & {});
export type ResourceType = "S3" | "EBS" | (string & {});
export type ResourceTypeList = ResourceType[];
export interface BackupCreationTimeFilter {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
}
export type ResourceArnList = string[];
export type RecoveryPoint = string;
export type RecoveryPointArnList = string[];
export type TagMap = {
    [key: string]: string | null | undefined;
};
export interface SearchScope {
    BackupResourceTypes: ResourceType[];
    BackupResourceCreationTime?: BackupCreationTimeFilter | undefined;
    SourceResourceArns?: string[] | undefined;
    BackupResourceArns?: string[] | undefined;
    BackupResourceTags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export type StringConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "CONTAINS" | "DOES_NOT_CONTAIN" | "BEGINS_WITH" | "ENDS_WITH" | "DOES_NOT_BEGIN_WITH" | "DOES_NOT_END_WITH" | (string & {});
export interface StringCondition {
    Value: string;
    Operator?: StringConditionOperator | undefined;
}
export type StringConditionList = StringCondition[];
export type LongConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export interface LongCondition {
    Value: number;
    Operator?: LongConditionOperator | undefined;
}
export type LongConditionList = LongCondition[];
export type TimeConditionOperator = "EQUALS_TO" | "NOT_EQUALS_TO" | "LESS_THAN_EQUAL_TO" | "GREATER_THAN_EQUAL_TO" | (string & {});
export interface TimeCondition {
    Value: Date;
    Operator?: TimeConditionOperator | undefined;
}
export type TimeConditionList = TimeCondition[];
export interface S3ItemFilter {
    ObjectKeys?: StringCondition[] | undefined;
    Sizes?: LongCondition[] | undefined;
    CreationTimes?: TimeCondition[] | undefined;
    VersionIds?: StringCondition[] | undefined;
    ETags?: StringCondition[] | undefined;
}
export type S3ItemFilters = S3ItemFilter[];
export interface EBSItemFilter {
    FilePaths?: StringCondition[] | undefined;
    Sizes?: LongCondition[] | undefined;
    CreationTimes?: TimeCondition[] | undefined;
    LastModificationTimes?: TimeCondition[] | undefined;
}
export type EBSItemFilters = EBSItemFilter[];
export interface ItemFilters {
    S3ItemFilters?: S3ItemFilter[] | undefined;
    EBSItemFilters?: EBSItemFilter[] | undefined;
}
export type SearchJobArn = string;
export interface GetSearchJobOutput {
    Name?: string | undefined;
    SearchScopeSummary?: SearchScopeSummary | undefined;
    CurrentSearchProgress?: CurrentSearchProgress | undefined;
    StatusMessage?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    CompletionTime?: Date | undefined;
    Status: SearchJobState;
    SearchScope: SearchScope;
    ItemFilters: ItemFilters;
    CreationTime: Date;
    SearchJobIdentifier: string;
    SearchJobArn: string;
}
export interface GetSearchResultExportJobInput {
    ExportJobIdentifier: string;
}
export type ExportJobArn = string;
export type ExportJobStatus = "RUNNING" | "FAILED" | "COMPLETED" | (string & {});
export interface S3ExportSpecification {
    DestinationBucket: string;
    DestinationPrefix?: string | undefined;
}
export type ExportSpecification = {
    s3ExportSpecification: S3ExportSpecification;
};
export interface GetSearchResultExportJobOutput {
    ExportJobIdentifier: string;
    ExportJobArn?: string | undefined;
    Status?: ExportJobStatus | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    StatusMessage?: string | undefined;
    ExportSpecification?: ExportSpecification | undefined;
    SearchJobArn?: string | undefined;
}
export interface ListSearchJobBackupsInput {
    SearchJobIdentifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchJobBackupsResult {
    Status?: SearchJobState | undefined;
    StatusMessage?: string | undefined;
    ResourceType?: ResourceType | undefined;
    BackupResourceArn?: string | undefined;
    SourceResourceArn?: string | undefined;
    IndexCreationTime?: Date | undefined;
    BackupCreationTime?: Date | undefined;
}
export type SearchJobBackupsResults = SearchJobBackupsResult[];
export interface ListSearchJobBackupsOutput {
    Results: SearchJobBackupsResult[];
    NextToken?: string | undefined;
}
export interface ListSearchJobResultsInput {
    SearchJobIdentifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ObjectKey = string | redacted.Redacted<string>;
export interface S3ResultItem {
    BackupResourceArn?: string | undefined;
    SourceResourceArn?: string | undefined;
    BackupVaultName?: string | undefined;
    ObjectKey?: string | redacted.Redacted<string> | undefined;
    ObjectSize?: number | undefined;
    CreationTime?: Date | undefined;
    ETag?: string | undefined;
    VersionId?: string | undefined;
}
export type FilePath = string | redacted.Redacted<string>;
export interface EBSResultItem {
    BackupResourceArn?: string | undefined;
    SourceResourceArn?: string | undefined;
    BackupVaultName?: string | undefined;
    FileSystemIdentifier?: string | undefined;
    FilePath?: string | redacted.Redacted<string> | undefined;
    FileSize?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ResultItem = {
    S3ResultItem: S3ResultItem;
    EBSResultItem?: undefined;
} | {
    S3ResultItem?: undefined;
    EBSResultItem: EBSResultItem;
};
export type Results = ResultItem[];
export interface ListSearchJobResultsOutput {
    Results: ResultItem[];
    NextToken?: string | undefined;
}
export interface ListSearchJobsInput {
    ByStatus?: SearchJobState | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchJobSummary {
    SearchJobIdentifier?: string | undefined;
    SearchJobArn?: string | undefined;
    Name?: string | undefined;
    Status?: SearchJobState | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    SearchScopeSummary?: SearchScopeSummary | undefined;
    StatusMessage?: string | undefined;
}
export type SearchJobs = SearchJobSummary[];
export interface ListSearchJobsOutput {
    SearchJobs: SearchJobSummary[];
    NextToken?: string | undefined;
}
export interface ListSearchResultExportJobsInput {
    Status?: ExportJobStatus | undefined;
    SearchJobIdentifier?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ExportJobSummary {
    ExportJobIdentifier: string;
    ExportJobArn?: string | undefined;
    Status?: ExportJobStatus | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    StatusMessage?: string | undefined;
    SearchJobArn?: string | undefined;
}
export type ExportJobSummaries = ExportJobSummary[];
export interface ListSearchResultExportJobsOutput {
    ExportJobs: ExportJobSummary[];
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export interface StartSearchJobInput {
    Tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    Name?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    ClientToken?: string | undefined;
    SearchScope: SearchScope;
    ItemFilters?: ItemFilters | undefined;
}
export interface StartSearchJobOutput {
    SearchJobArn?: string | undefined;
    CreationTime?: Date | undefined;
    SearchJobIdentifier?: string | undefined;
}
export type IamRoleArn = string;
export interface StartSearchResultExportJobInput {
    SearchJobIdentifier: string;
    ExportSpecification: ExportSpecification;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    RoleArn?: string | undefined;
}
export interface StartSearchResultExportJobOutput {
    ExportJobArn?: string | undefined;
    ExportJobIdentifier: string;
}
export interface StopSearchJobInput {
    SearchJobIdentifier: string;
}
export interface StopSearchJobOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | null | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type GetSearchJobError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation retrieves metadata of a search job, including its progress.
 */
export declare const getSearchJob: API.OperationMethod<GetSearchJobInput & RegionInput, GetSearchJobOutput, GetSearchJobError, Credentials | HttpClient.HttpClient>;
export type GetSearchResultExportJobError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation retrieves the metadata of an export job.
 *
 * An export job is an operation that transmits the results of a search job to a specified S3 bucket in a .csv file.
 *
 * An export job allows you to retain results of a search beyond the search job's scheduled retention of 7 days.
 */
export declare const getSearchResultExportJob: API.OperationMethod<GetSearchResultExportJobInput & RegionInput, GetSearchResultExportJobOutput, GetSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type ListSearchJobBackupsError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns a list of all backups (recovery points) in a paginated format that were included in the search job.
 *
 * If a search does not display an expected backup in the results, you can call this operation to display each backup included in the search. Any backups that were not included because they have a `FAILED` status from a permissions issue will be displayed, along with a status message.
 *
 * Only recovery points with a backup index that has a status of `ACTIVE` will be included in search results. If the index has any other status, its status will be displayed along with a status message.
 */
export declare const listSearchJobBackups: API.PaginatedOperationMethod<ListSearchJobBackupsInput & RegionInput, ListSearchJobBackupsOutput, ListSearchJobBackupsError, Credentials | HttpClient.HttpClient, SearchJobBackupsResult>;
export type ListSearchJobResultsError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns a list of a specified search job.
 */
export declare const listSearchJobResults: API.PaginatedOperationMethod<ListSearchJobResultsInput & RegionInput, ListSearchJobResultsOutput, ListSearchJobResultsError, Credentials | HttpClient.HttpClient, ResultItem>;
export type ListSearchJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns a list of search jobs belonging to an account.
 */
export declare const listSearchJobs: API.PaginatedOperationMethod<ListSearchJobsInput & RegionInput, ListSearchJobsOutput, ListSearchJobsError, Credentials | HttpClient.HttpClient, SearchJobSummary>;
export type ListSearchResultExportJobsError = ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation exports search results of a search job to a specified destination S3 bucket.
 */
export declare const listSearchResultExportJobs: API.PaginatedOperationMethod<ListSearchResultExportJobsInput & RegionInput, ListSearchResultExportJobsOutput, ListSearchResultExportJobsError, Credentials | HttpClient.HttpClient, ExportJobSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns the tags for a resource type.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSearchJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a search job which returns recovery points filtered by SearchScope and items filtered by ItemFilters.
 *
 * You can optionally include ClientToken, EncryptionKeyArn, Name, and/or Tags.
 */
export declare const startSearchJob: API.OperationMethod<StartSearchJobInput & RegionInput, StartSearchJobOutput, StartSearchJobError, Credentials | HttpClient.HttpClient>;
export type StartSearchResultExportJobError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operations starts a job to export the results of search job to a designated S3 bucket.
 */
export declare const startSearchResultExportJob: API.OperationMethod<StartSearchResultExportJobInput & RegionInput, StartSearchResultExportJobOutput, StartSearchResultExportJobError, Credentials | HttpClient.HttpClient>;
export type StopSearchJobError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operations ends a search job.
 *
 * Only a search job with a status of `RUNNING` can be stopped.
 */
export declare const stopSearchJob: API.OperationMethod<StopSearchJobInput & RegionInput, StopSearchJobOutput, StopSearchJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation puts tags on the resource you indicate.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backupsearch.d.ts.map