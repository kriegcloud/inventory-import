import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
import * as Contributions from "../Contributions.ts";
import * as State from "../State/index.ts";
import { StackEntrypointError, type Target } from "./Entrypoint.ts";
/** Which store a state request addresses. */
export type StateSource = 
/** `.alchemy/` on this machine, ignoring whatever the project configures. */
{
    readonly type: "local";
}
/** Whatever the project's entrypoint configures. */
 | ({
    readonly type: "configured";
    /** Stage the store is opened for. @default "placeholder" */
    readonly stage?: string;
} & Target)
/** A provider's state store, without loading a project entrypoint. */
 | ({
    readonly type: "provider";
    readonly backend: string;
} & Pick<Target, "profile" | "envFile"> & 
/**
 * The store's own options alongside, such as `name` for a store other
 * than the account's default or `domain` for where it is served. Each
 * must be one the backend has a flag for.
 */
Contributions.StateStoreOptions);
/** What lifecycle operations act on. */
export type ProviderSource = Extract<StateSource, {
    readonly type: "provider";
}>;
/**
 * What a provider's store runs under, its layer and lifecycle alike: the
 * profile's config and an auth registry with the provider's auth.
 *
 * @internal exported for tests.
 */
export declare const providerContext: (provider: Contributions.Contributions, target: Pick<Target, "envFile" | "profile">) => Effect.Effect<Layer.Layer<import("../index.ts").AuthProviders, never, Contributions.HostServices>, Contributions.ContributionError | import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem>;
/**
 * Resolve the state service a source addresses, in the caller's `Scope`: the
 * store's resources live until that scope closes. The tree operations
 * (`State.listState`, `State.readState`, `State.deleteState`) take `State`
 * from context — provide the resolved service (or {@link layer}) to run
 * them against the chosen store:
 *
 * ```ts
 * const state = yield* Alchemist.State.store({ type: "local" });
 * const items = yield* State.listState({ path }).pipe(
 *   Effect.provideService(State.State, Effect.succeed(state)),
 * );
 * ```
 */
export declare const store: (source: StateSource) => Effect.Effect<State.StateService, Contributions.ContributionFailure, import("effect/Scope").Scope | Contributions.HostServices>;
/** The chosen store as a `State` layer. */
export declare const layer: (source: StateSource) => Layer.Layer<State.State, Contributions.ContributionFailure, Contributions.HostServices>;
/** Provision (or adopt) a state store. */
export declare const bootstrap: (args_0: {
    readonly type: "provider";
    readonly backend: string;
} & Pick<Target, "envFile" | "profile"> & Readonly<Record<string, unknown>> & {
    readonly force?: boolean;
}) => Effect.Effect<Contributions.StateStoreBootstrap, Contributions.ContributionFailure, Contributions.HostServices>;
/**
 * Provision (or upgrade) the store a project's entrypoint configures, with
 * every option it sets, such as a custom name, a pinned account or a domain.
 */
export declare const bootstrapConfigured: (source: {
    readonly type: "configured";
    /** Stage the store is opened for. @default "placeholder" */
    readonly stage?: string;
} & Target) => Effect.Effect<{
    version: number;
}, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError | StackEntrypointError | State.StateStoreError, import("../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
/** Delete a state store and its backing resources. */
export declare const teardown: (source: {
    readonly type: "provider";
    readonly backend: string;
} & Pick<Target, "envFile" | "profile"> & Readonly<Record<string, unknown>>) => Effect.Effect<Contributions.StateStoreTeardown, Contributions.ContributionFailure, Contributions.HostServices>;
/**
 * Move stages into a state store from the one it replaces, or back. The
 * configured source migrates exactly the store the project's entrypoint
 * configures, options included.
 */
export declare const migrate: (source: StateSource, request?: State.StateMigrationRequest | undefined) => Effect.Effect<{
    stages: readonly State.StateMigration[];
}, Contributions.ContributionFailure, Contributions.HostServices>;
/** Past log entries from a state store, oldest first. */
export declare const logs: (args_0: {
    readonly type: "provider";
    readonly backend: string;
} & Pick<Target, "envFile" | "profile"> & Readonly<Record<string, unknown>> & {
    readonly limit?: number;
    readonly since?: Date;
}) => Effect.Effect<readonly Contributions.StateStoreLogEntry[], Contributions.ContributionFailure, Contributions.HostServices>;
/** Live log entries from a state store. */
export declare const tailLogs: (source: ProviderSource) => Stream.Stream<Contributions.StateStoreLogEntry, Contributions.ContributionError | Contributions.ContributionFailure | import("effect/PlatformError").PlatformError, Contributions.HostServices>;
//# sourceMappingURL=State.d.ts.map