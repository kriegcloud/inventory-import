import { WebhookHost } from "alchemy/WebhookHost";
import * as Layer from "effect/Layer";
import { NotificationEventSource } from "./NotificationEventSource.ts";
/**
 * `Cloudflare.Alerting.consumeNotifications` on any {@link WebhookHost}.
 *
 * Deploy-time: creates a {@link NotificationWebhook} destination pointing at
 * the host (at a per-policy path) and binds it onto the policy, so the policy
 * notifies the host. The webhook secret (yours, or a generated one) is bound
 * onto the host. Under `alchemy dev` the host is on localhost, which
 * Cloudflare can't reach, so no destination is created.
 *
 * Runtime: claims requests on the policy's path, rejects any without the
 * secret in `cf-webhook-auth`, acknowledges Cloudflare's test message, and
 * runs the handler once per notification.
 *
 * @layer
 * @product Alerting
 * @provides Cloudflare.Alerting.NotificationEventSource
 */
export declare const NotificationEventSourceLive: Layer.Layer<NotificationEventSource, never, WebhookHost>;
//# sourceMappingURL=NotificationEventSourceLive.d.ts.map