import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type Arn = string;
export type UserID = string;
export type NumResults = number;
export type FilterAttributeName = string;
export type FilterAttributeValue = string | redacted.Redacted<string>;
export type FilterValues = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface GetActionRecommendationsRequest {
    campaignArn?: string | undefined;
    userId?: string | undefined;
    numResults?: number | undefined;
    filterArn?: string | undefined;
    filterValues?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type ActionID = string;
export type Score = number;
export interface PredictedAction {
    actionId?: string | undefined;
    score?: number | undefined;
}
export type ActionList = PredictedAction[];
export type RecommendationID = string;
export interface GetActionRecommendationsResponse {
    actionList?: PredictedAction[] | undefined;
    recommendationId?: string | undefined;
}
export type ItemID = string;
export type InputList = string[];
export type AttributeName = string;
export type AttributeValue = string | redacted.Redacted<string>;
export type Context = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type DatasetType = string;
export type ColumnName = string;
export type ColumnNamesList = string[];
export type MetadataColumns = {
    [key: string]: string[] | undefined;
};
export interface GetPersonalizedRankingRequest {
    campaignArn: string;
    inputList: string[];
    userId: string;
    context?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    filterArn?: string | undefined;
    filterValues?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    metadataColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type Name = string;
export type ColumnValue = string;
export type Metadata = {
    [key: string]: string | undefined;
};
export type Reason = string;
export type ReasonList = string[];
export interface PredictedItem {
    itemId?: string | undefined;
    score?: number | undefined;
    promotionName?: string | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    reason?: string[] | undefined;
}
export type ItemList = PredictedItem[];
export interface GetPersonalizedRankingResponse {
    personalizedRanking?: PredictedItem[] | undefined;
    recommendationId?: string | undefined;
}
export type PercentPromotedItems = number;
export interface Promotion {
    name?: string | undefined;
    percentPromotedItems?: number | undefined;
    filterArn?: string | undefined;
    filterValues?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type PromotionList = Promotion[];
export interface GetRecommendationsRequest {
    campaignArn?: string | undefined;
    itemId?: string | undefined;
    userId?: string | undefined;
    numResults?: number | undefined;
    context?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    filterArn?: string | undefined;
    filterValues?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    recommenderArn?: string | undefined;
    promotions?: Promotion[] | undefined;
    metadataColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface GetRecommendationsResponse {
    itemList?: PredictedItem[] | undefined;
    recommendationId?: string | undefined;
}
export type ErrorMessage = string;
export type GetActionRecommendationsError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of recommended actions in sorted in descending order by prediction score.
 * Use the `GetActionRecommendations` API if you have a custom
 * campaign that deploys a solution version trained with a PERSONALIZED_ACTIONS recipe.
 *
 * For more information about PERSONALIZED_ACTIONS recipes, see PERSONALIZED_ACTIONS recipes.
 * For more information about getting action recommendations, see Getting action recommendations.
 */
export declare const getActionRecommendations: API.OperationMethod<GetActionRecommendationsRequest & RegionInput, GetActionRecommendationsResponse, GetActionRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetPersonalizedRankingError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Re-ranks a list of recommended items for the given user. The first item in the list is
 * deemed the most likely item to be of interest to the user.
 *
 * The solution backing the campaign must have been created using a recipe of type
 * PERSONALIZED_RANKING.
 */
export declare const getPersonalizedRanking: API.OperationMethod<GetPersonalizedRankingRequest & RegionInput, GetPersonalizedRankingResponse, GetPersonalizedRankingError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationsError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of recommended items. For campaigns, the campaign's Amazon Resource Name (ARN) is required and the required user and item input depends on the recipe type used to
 * create the solution backing the campaign as follows:
 *
 * - USER_PERSONALIZATION - `userId` required, `itemId` not used
 *
 * - RELATED_ITEMS - `itemId` required, `userId` not used
 *
 * Campaigns that are backed by a solution created using a recipe of type
 * PERSONALIZED_RANKING use the API.
 *
 * For recommenders, the recommender's ARN is required and the required item and user input depends on the use case (domain-based recipe) backing the recommender.
 * For information on use case requirements see Choosing recommender use cases.
 */
export declare const getRecommendations: API.OperationMethod<GetRecommendationsRequest & RegionInput, GetRecommendationsResponse, GetRecommendationsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=personalize-runtime.d.ts.map