import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ARN = string;
export interface AssociateBrowserSettingsRequest {
    portalArn: string;
    browserSettingsArn: string;
}
export interface AssociateBrowserSettingsResponse {
    portalArn: string;
    browserSettingsArn: string;
}
export interface AssociateDataProtectionSettingsRequest {
    portalArn: string;
    dataProtectionSettingsArn: string;
}
export interface AssociateDataProtectionSettingsResponse {
    portalArn: string;
    dataProtectionSettingsArn: string;
}
export interface AssociateIpAccessSettingsRequest {
    portalArn: string;
    ipAccessSettingsArn: string;
}
export interface AssociateIpAccessSettingsResponse {
    portalArn: string;
    ipAccessSettingsArn: string;
}
export interface AssociateNetworkSettingsRequest {
    portalArn: string;
    networkSettingsArn: string;
}
export interface AssociateNetworkSettingsResponse {
    portalArn: string;
    networkSettingsArn: string;
}
export interface AssociateSessionLoggerRequest {
    portalArn: string;
    sessionLoggerArn: string;
}
export interface AssociateSessionLoggerResponse {
    portalArn: string;
    sessionLoggerArn: string;
}
export interface AssociateTrustStoreRequest {
    portalArn: string;
    trustStoreArn: string;
}
export interface AssociateTrustStoreResponse {
    portalArn: string;
    trustStoreArn: string;
}
export interface AssociateUserAccessLoggingSettingsRequest {
    portalArn: string;
    userAccessLoggingSettingsArn: string;
}
export interface AssociateUserAccessLoggingSettingsResponse {
    portalArn: string;
    userAccessLoggingSettingsArn: string;
}
export interface AssociateUserSettingsRequest {
    portalArn: string;
    userSettingsArn: string;
}
export interface AssociateUserSettingsResponse {
    portalArn: string;
    userSettingsArn: string;
}
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export type KeyArn = string;
export type StringType = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export type BrowserPolicy = string | redacted.Redacted<string>;
export type ClientToken = string;
export type Category = "Cults" | "Gambling" | "Nudity" | "Pornography" | "SexEducation" | "Tasteless" | "Violence" | "DownloadSites" | "ImageSharing" | "PeerToPeer" | "StreamingMediaAndDownloads" | "GenerativeAI" | "CriminalActivity" | "Hacking" | "HateAndIntolerance" | "IllegalDrug" | "IllegalSoftware" | "SchoolCheating" | "SelfHarm" | "Weapons" | "Chat" | "Games" | "InstantMessaging" | "ProfessionalNetwork" | "SocialNetworking" | "WebBasedEmail" | "ParkedDomains" | (string & {});
export type BlockedCategories = Category[];
export type UrlPattern = string | redacted.Redacted<string>;
export type UrlPatternList = (string | redacted.Redacted<string>)[];
export interface WebContentFilteringPolicy {
    blockedCategories?: Category[] | undefined;
    allowedUrls?: (string | redacted.Redacted<string>)[] | undefined;
    blockedUrls?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface CreateBrowserSettingsRequest {
    tags?: Tag[] | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    browserPolicy?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
    webContentFilteringPolicy?: WebContentFilteringPolicy | undefined;
}
export interface CreateBrowserSettingsResponse {
    browserSettingsArn: string;
}
export type DisplayNameSafe = string | redacted.Redacted<string>;
export type DescriptionSafe = string | redacted.Redacted<string>;
export type BuiltInPatternId = string | redacted.Redacted<string>;
export type PatternName = string | redacted.Redacted<string>;
export type Regex = string | redacted.Redacted<string>;
export interface CustomPattern {
    patternName: string | redacted.Redacted<string>;
    patternRegex: string | redacted.Redacted<string>;
    patternDescription?: string | redacted.Redacted<string> | undefined;
    keywordRegex?: string | redacted.Redacted<string> | undefined;
}
export type RedactionPlaceHolderType = string;
export type RedactionPlaceHolderText = string | redacted.Redacted<string>;
export interface RedactionPlaceHolder {
    redactionPlaceHolderType: string;
    redactionPlaceHolderText?: string | redacted.Redacted<string> | undefined;
}
export type InlineRedactionUrl = string | redacted.Redacted<string>;
export type InlineRedactionUrls = (string | redacted.Redacted<string>)[];
export type ConfidenceLevel = number;
export interface InlineRedactionPattern {
    builtInPatternId?: string | redacted.Redacted<string> | undefined;
    customPattern?: CustomPattern | undefined;
    redactionPlaceHolder: RedactionPlaceHolder;
    enforcedUrls?: (string | redacted.Redacted<string>)[] | undefined;
    exemptUrls?: (string | redacted.Redacted<string>)[] | undefined;
    confidenceLevel?: number | undefined;
}
export type InlineRedactionPatterns = InlineRedactionPattern[];
export type GlobalInlineRedactionUrls = (string | redacted.Redacted<string>)[];
export interface InlineRedactionConfiguration {
    inlineRedactionPatterns: InlineRedactionPattern[];
    globalEnforcedUrls?: (string | redacted.Redacted<string>)[] | undefined;
    globalExemptUrls?: (string | redacted.Redacted<string>)[] | undefined;
    globalConfidenceLevel?: number | undefined;
}
export interface CreateDataProtectionSettingsRequest {
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    tags?: Tag[] | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    inlineRedactionConfiguration?: InlineRedactionConfiguration | undefined;
    clientToken?: string | undefined;
}
export interface CreateDataProtectionSettingsResponse {
    dataProtectionSettingsArn: string;
}
export type IdentityProviderName = string | redacted.Redacted<string>;
export type IdentityProviderType = string;
export type IdentityProviderDetails = {
    [key: string]: string | undefined;
};
export interface CreateIdentityProviderRequest {
    portalArn: string;
    identityProviderName: string | redacted.Redacted<string>;
    identityProviderType: string;
    identityProviderDetails: {
        [key: string]: string | undefined;
    };
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export type SubresourceARN = string;
export interface CreateIdentityProviderResponse {
    identityProviderArn: string;
}
export type DisplayName = string | redacted.Redacted<string>;
export type Description = string | redacted.Redacted<string>;
export type IpRange = string | redacted.Redacted<string>;
export interface IpRule {
    ipRange: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
}
export type IpRuleList = IpRule[];
export interface CreateIpAccessSettingsRequest {
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    tags?: Tag[] | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    ipRules: IpRule[];
    clientToken?: string | undefined;
}
export interface CreateIpAccessSettingsResponse {
    ipAccessSettingsArn: string;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export interface CreateNetworkSettingsRequest {
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateNetworkSettingsResponse {
    networkSettingsArn: string;
}
export type AuthenticationType = string;
export type InstanceType = string;
export type MaxConcurrentSessions = number;
export type PortalCustomDomain = string;
export interface CreatePortalRequest {
    displayName?: string | redacted.Redacted<string> | undefined;
    tags?: Tag[] | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
    authenticationType?: string | undefined;
    instanceType?: string | undefined;
    maxConcurrentSessions?: number | undefined;
    portalCustomDomain?: string | undefined;
}
export type PortalEndpoint = string;
export interface CreatePortalResponse {
    portalArn: string;
    portalEndpoint: string;
}
export type Event = "WebsiteInteract" | "FileDownloadFromSecureBrowserToRemoteDisk" | "FileTransferFromRemoteToLocalDisk" | "FileTransferFromLocalToRemoteDisk" | "FileUploadFromRemoteDiskToSecureBrowser" | "ContentPasteToWebsite" | "ContentTransferFromLocalToRemoteClipboard" | "ContentCopyFromWebsite" | "UrlLoad" | "TabOpen" | "TabClose" | "PrintJobSubmit" | "SessionConnect" | "SessionStart" | "SessionDisconnect" | "SessionEnd" | "UrlBlockByContentFilter" | (string & {});
export type Events = Event[];
export type EventFilter = {
    all: Record<string, never>;
    include?: undefined;
} | {
    all?: undefined;
    include: Event[];
};
export type S3Bucket = string | redacted.Redacted<string>;
export type S3KeyPrefix = string | redacted.Redacted<string>;
export type S3BucketOwner = string;
export type LogFileFormat = "JSONLines" | "Json" | (string & {});
export type FolderStructure = "Flat" | "NestedByDate" | (string & {});
export interface S3LogConfiguration {
    bucket: string | redacted.Redacted<string>;
    keyPrefix?: string | redacted.Redacted<string> | undefined;
    bucketOwner?: string | undefined;
    logFileFormat: LogFileFormat;
    folderStructure: FolderStructure;
}
export interface LogConfiguration {
    s3?: S3LogConfiguration | undefined;
}
export interface CreateSessionLoggerRequest {
    eventFilter: EventFilter;
    logConfiguration: LogConfiguration;
    displayName?: string | redacted.Redacted<string> | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateSessionLoggerResponse {
    sessionLoggerArn: string;
}
export type CertificateAuthorityBody = Uint8Array;
export type CertificateList = Uint8Array[];
export interface CreateTrustStoreRequest {
    certificateList: Uint8Array[];
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateTrustStoreResponse {
    trustStoreArn: string;
}
export type KinesisStreamArn = string;
export interface CreateUserAccessLoggingSettingsRequest {
    kinesisStreamArn: string;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateUserAccessLoggingSettingsResponse {
    userAccessLoggingSettingsArn: string;
}
export type EnabledType = string;
export type DisconnectTimeoutInMinutes = number;
export type IdleDisconnectTimeoutInMinutes = number;
export type CookieDomain = string | redacted.Redacted<string>;
export type CookieName = string | redacted.Redacted<string>;
export type CookiePath = string | redacted.Redacted<string>;
export interface CookieSpecification {
    domain: string | redacted.Redacted<string>;
    name?: string | redacted.Redacted<string> | undefined;
    path?: string | redacted.Redacted<string> | undefined;
}
export type CookieSpecifications = CookieSpecification[];
export interface CookieSynchronizationConfiguration {
    allowlist: CookieSpecification[];
    blocklist?: CookieSpecification[] | undefined;
}
export type ToolbarType = string;
export type VisualMode = string;
export type ToolbarItem = string;
export type HiddenToolbarItemList = string[];
export type MaxDisplayResolution = string;
export interface ToolbarConfiguration {
    toolbarType?: string | undefined;
    visualMode?: string | undefined;
    hiddenToolbarItems?: string[] | undefined;
    maxDisplayResolution?: string | undefined;
}
export type IconImage = Uint8Array;
export type S3Uri = string;
export type IconImageInput = {
    blob: Uint8Array;
    s3Uri?: undefined;
} | {
    blob?: undefined;
    s3Uri: string;
};
export type WallpaperImage = Uint8Array;
export type WallpaperImageInput = {
    blob: Uint8Array;
    s3Uri?: undefined;
} | {
    blob?: undefined;
    s3Uri: string;
};
export type Locale = "de-DE" | "en-US" | "es-ES" | "fr-FR" | "id-ID" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "zh-CN" | "zh-TW" | (string & {});
export type BrandingSafeStringType = string;
export type ContactLinkUrl = string;
export interface LocalizedBrandingStrings {
    browserTabTitle: string;
    welcomeText: string;
    loginTitle?: string | undefined;
    loginDescription?: string | undefined;
    loginButtonText?: string | undefined;
    contactLink?: string | undefined;
    contactButtonText?: string | undefined;
    loadingText?: string | undefined;
}
export type LocalizedBrandingStringMap = {
    [key in Locale]?: LocalizedBrandingStrings | undefined;
};
export type ColorTheme = "Light" | "Dark" | (string & {});
export type Markdown = string | redacted.Redacted<string>;
export interface BrandingConfigurationCreateInput {
    logo: IconImageInput;
    wallpaper?: WallpaperImageInput | undefined;
    favicon: IconImageInput;
    localizedStrings: {
        [key: string]: LocalizedBrandingStrings | undefined;
    };
    colorTheme: ColorTheme;
    termsOfService?: string | redacted.Redacted<string> | undefined;
}
export interface CreateUserSettingsRequest {
    copyAllowed: string;
    pasteAllowed: string;
    downloadAllowed: string;
    uploadAllowed: string;
    printAllowed: string;
    tags?: Tag[] | undefined;
    disconnectTimeoutInMinutes?: number | undefined;
    idleDisconnectTimeoutInMinutes?: number | undefined;
    clientToken?: string | undefined;
    cookieSynchronizationConfiguration?: CookieSynchronizationConfiguration | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    deepLinkAllowed?: string | undefined;
    toolbarConfiguration?: ToolbarConfiguration | undefined;
    brandingConfigurationInput?: BrandingConfigurationCreateInput | undefined;
    webAuthnAllowed?: string | undefined;
}
export interface CreateUserSettingsResponse {
    userSettingsArn: string;
}
export interface DeleteBrowserSettingsRequest {
    browserSettingsArn: string;
}
export interface DeleteBrowserSettingsResponse {
}
export interface DeleteDataProtectionSettingsRequest {
    dataProtectionSettingsArn: string;
}
export interface DeleteDataProtectionSettingsResponse {
}
export interface DeleteIdentityProviderRequest {
    identityProviderArn: string;
}
export interface DeleteIdentityProviderResponse {
}
export interface DeleteIpAccessSettingsRequest {
    ipAccessSettingsArn: string;
}
export interface DeleteIpAccessSettingsResponse {
}
export interface DeleteNetworkSettingsRequest {
    networkSettingsArn: string;
}
export interface DeleteNetworkSettingsResponse {
}
export interface DeletePortalRequest {
    portalArn: string;
}
export interface DeletePortalResponse {
}
export interface DeleteSessionLoggerRequest {
    sessionLoggerArn: string;
}
export interface DeleteSessionLoggerResponse {
}
export interface DeleteTrustStoreRequest {
    trustStoreArn: string;
}
export interface DeleteTrustStoreResponse {
}
export interface DeleteUserAccessLoggingSettingsRequest {
    userAccessLoggingSettingsArn: string;
}
export interface DeleteUserAccessLoggingSettingsResponse {
}
export interface DeleteUserSettingsRequest {
    userSettingsArn: string;
}
export interface DeleteUserSettingsResponse {
}
export interface DisassociateBrowserSettingsRequest {
    portalArn: string;
}
export interface DisassociateBrowserSettingsResponse {
}
export interface DisassociateDataProtectionSettingsRequest {
    portalArn: string;
}
export interface DisassociateDataProtectionSettingsResponse {
}
export interface DisassociateIpAccessSettingsRequest {
    portalArn: string;
}
export interface DisassociateIpAccessSettingsResponse {
}
export interface DisassociateNetworkSettingsRequest {
    portalArn: string;
}
export interface DisassociateNetworkSettingsResponse {
}
export interface DisassociateSessionLoggerRequest {
    portalArn: string;
}
export interface DisassociateSessionLoggerResponse {
}
export interface DisassociateTrustStoreRequest {
    portalArn: string;
}
export interface DisassociateTrustStoreResponse {
}
export interface DisassociateUserAccessLoggingSettingsRequest {
    portalArn: string;
}
export interface DisassociateUserAccessLoggingSettingsResponse {
}
export interface DisassociateUserSettingsRequest {
    portalArn: string;
}
export interface DisassociateUserSettingsResponse {
}
export type PortalId = string;
export type SessionId = string;
export interface ExpireSessionRequest {
    portalId: string;
    sessionId: string;
}
export interface ExpireSessionResponse {
}
export interface GetBrowserSettingsRequest {
    browserSettingsArn: string;
}
export type ArnList = string[];
export interface BrowserSettings {
    browserSettingsArn: string;
    associatedPortalArns?: string[] | undefined;
    browserPolicy?: string | redacted.Redacted<string> | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    webContentFilteringPolicy?: WebContentFilteringPolicy | undefined;
}
export interface GetBrowserSettingsResponse {
    browserSettings?: BrowserSettings | undefined;
}
export interface GetDataProtectionSettingsRequest {
    dataProtectionSettingsArn: string;
}
export interface DataProtectionSettings {
    dataProtectionSettingsArn: string;
    inlineRedactionConfiguration?: InlineRedactionConfiguration | undefined;
    associatedPortalArns?: string[] | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDataProtectionSettingsResponse {
    dataProtectionSettings?: DataProtectionSettings | undefined;
}
export interface GetIdentityProviderRequest {
    identityProviderArn: string;
}
export interface IdentityProvider {
    identityProviderArn: string;
    identityProviderName?: string | redacted.Redacted<string> | undefined;
    identityProviderType?: string | undefined;
    identityProviderDetails?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetIdentityProviderResponse {
    identityProvider?: IdentityProvider | undefined;
}
export interface GetIpAccessSettingsRequest {
    ipAccessSettingsArn: string;
}
export interface IpAccessSettings {
    ipAccessSettingsArn: string;
    associatedPortalArns?: string[] | undefined;
    ipRules?: IpRule[] | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetIpAccessSettingsResponse {
    ipAccessSettings?: IpAccessSettings | undefined;
}
export interface GetNetworkSettingsRequest {
    networkSettingsArn: string;
}
export interface NetworkSettings {
    networkSettingsArn: string;
    associatedPortalArns?: string[] | undefined;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
}
export interface GetNetworkSettingsResponse {
    networkSettings?: NetworkSettings | undefined;
}
export interface GetPortalRequest {
    portalArn: string;
}
export type RendererType = string;
export type BrowserType = string;
export type PortalStatus = string;
export type StatusReason = string;
export interface Portal {
    portalArn: string;
    rendererType?: string | undefined;
    browserType?: string | undefined;
    portalStatus?: string | undefined;
    portalEndpoint?: string | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
    browserSettingsArn?: string | undefined;
    dataProtectionSettingsArn?: string | undefined;
    userSettingsArn?: string | undefined;
    networkSettingsArn?: string | undefined;
    sessionLoggerArn?: string | undefined;
    trustStoreArn?: string | undefined;
    statusReason?: string | undefined;
    userAccessLoggingSettingsArn?: string | undefined;
    authenticationType?: string | undefined;
    ipAccessSettingsArn?: string | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    instanceType?: string | undefined;
    maxConcurrentSessions?: number | undefined;
    portalCustomDomain?: string | undefined;
}
export interface GetPortalResponse {
    portal?: Portal | undefined;
}
export interface GetPortalServiceProviderMetadataRequest {
    portalArn: string;
}
export type SamlMetadata = string;
export interface GetPortalServiceProviderMetadataResponse {
    portalArn: string;
    serviceProviderSamlMetadata?: string | undefined;
}
export interface GetSessionRequest {
    portalId: string;
    sessionId: string;
}
export type Username = string | redacted.Redacted<string>;
export type IpAddress = string | redacted.Redacted<string>;
export type IpAddressList = (string | redacted.Redacted<string>)[];
export type SessionStatus = "Active" | "Terminated" | (string & {});
export interface Session {
    portalArn?: string | undefined;
    sessionId?: string | undefined;
    username?: string | redacted.Redacted<string> | undefined;
    clientIpAddresses?: (string | redacted.Redacted<string>)[] | undefined;
    status?: SessionStatus | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface GetSessionResponse {
    session?: Session | undefined;
}
export interface GetSessionLoggerRequest {
    sessionLoggerArn: string;
}
export interface SessionLogger {
    sessionLoggerArn: string;
    eventFilter?: EventFilter | undefined;
    logConfiguration?: LogConfiguration | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    associatedPortalArns?: string[] | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
}
export interface GetSessionLoggerResponse {
    sessionLogger?: SessionLogger | undefined;
}
export interface GetTrustStoreRequest {
    trustStoreArn: string;
}
export interface TrustStore {
    associatedPortalArns?: string[] | undefined;
    trustStoreArn: string;
}
export interface GetTrustStoreResponse {
    trustStore?: TrustStore | undefined;
}
export type CertificateThumbprint = string;
export interface GetTrustStoreCertificateRequest {
    trustStoreArn: string;
    thumbprint: string;
}
export type CertificatePrincipal = string;
export interface Certificate {
    thumbprint?: string | undefined;
    subject?: string | undefined;
    issuer?: string | undefined;
    notValidBefore?: Date | undefined;
    notValidAfter?: Date | undefined;
    body?: Uint8Array | undefined;
}
export interface GetTrustStoreCertificateResponse {
    trustStoreArn: string;
    certificate?: Certificate | undefined;
}
export interface GetUserAccessLoggingSettingsRequest {
    userAccessLoggingSettingsArn: string;
}
export interface UserAccessLoggingSettings {
    userAccessLoggingSettingsArn: string;
    associatedPortalArns?: string[] | undefined;
    kinesisStreamArn?: string | undefined;
}
export interface GetUserAccessLoggingSettingsResponse {
    userAccessLoggingSettings?: UserAccessLoggingSettings | undefined;
}
export interface GetUserSettingsRequest {
    userSettingsArn: string;
}
export type MimeType = "image/png" | "image/jpeg" | "image/x-icon" | (string & {});
export interface ImageMetadata {
    mimeType: MimeType;
    fileExtension: string;
    lastUploadTimestamp: Date;
}
export interface BrandingConfiguration {
    logo: ImageMetadata;
    wallpaper?: ImageMetadata | undefined;
    favicon: ImageMetadata;
    localizedStrings: {
        [key: string]: LocalizedBrandingStrings | undefined;
    };
    colorTheme: ColorTheme;
    termsOfService?: string | redacted.Redacted<string> | undefined;
}
export interface UserSettings {
    userSettingsArn: string;
    associatedPortalArns?: string[] | undefined;
    copyAllowed?: string | undefined;
    pasteAllowed?: string | undefined;
    downloadAllowed?: string | undefined;
    uploadAllowed?: string | undefined;
    printAllowed?: string | undefined;
    disconnectTimeoutInMinutes?: number | undefined;
    idleDisconnectTimeoutInMinutes?: number | undefined;
    cookieSynchronizationConfiguration?: CookieSynchronizationConfiguration | undefined;
    customerManagedKey?: string | undefined;
    additionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    deepLinkAllowed?: string | undefined;
    toolbarConfiguration?: ToolbarConfiguration | undefined;
    brandingConfiguration?: BrandingConfiguration | undefined;
    webAuthnAllowed?: string | undefined;
}
export interface GetUserSettingsResponse {
    userSettings?: UserSettings | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListBrowserSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BrowserSettingsSummary {
    browserSettingsArn: string;
}
export type BrowserSettingsList = BrowserSettingsSummary[];
export interface ListBrowserSettingsResponse {
    browserSettings?: BrowserSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataProtectionSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataProtectionSettingsSummary {
    dataProtectionSettingsArn: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
}
export type DataProtectionSettingsList = DataProtectionSettingsSummary[];
export interface ListDataProtectionSettingsResponse {
    dataProtectionSettings?: DataProtectionSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListIdentityProvidersRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    portalArn: string;
}
export interface IdentityProviderSummary {
    identityProviderArn: string;
    identityProviderName?: string | redacted.Redacted<string> | undefined;
    identityProviderType?: string | undefined;
}
export type IdentityProviderList = IdentityProviderSummary[];
export interface ListIdentityProvidersResponse {
    nextToken?: string | undefined;
    identityProviders?: IdentityProviderSummary[] | undefined;
}
export interface ListIpAccessSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IpAccessSettingsSummary {
    ipAccessSettingsArn: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
}
export type IpAccessSettingsList = IpAccessSettingsSummary[];
export interface ListIpAccessSettingsResponse {
    ipAccessSettings?: IpAccessSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListNetworkSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface NetworkSettingsSummary {
    networkSettingsArn: string;
    vpcId?: string | undefined;
}
export type NetworkSettingsList = NetworkSettingsSummary[];
export interface ListNetworkSettingsResponse {
    networkSettings?: NetworkSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPortalsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PortalSummary {
    portalArn: string;
    rendererType?: string | undefined;
    browserType?: string | undefined;
    portalStatus?: string | undefined;
    portalEndpoint?: string | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
    browserSettingsArn?: string | undefined;
    dataProtectionSettingsArn?: string | undefined;
    userSettingsArn?: string | undefined;
    networkSettingsArn?: string | undefined;
    sessionLoggerArn?: string | undefined;
    trustStoreArn?: string | undefined;
    userAccessLoggingSettingsArn?: string | undefined;
    authenticationType?: string | undefined;
    ipAccessSettingsArn?: string | undefined;
    instanceType?: string | undefined;
    maxConcurrentSessions?: number | undefined;
    portalCustomDomain?: string | undefined;
}
export type PortalList = PortalSummary[];
export interface ListPortalsResponse {
    portals?: PortalSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSessionLoggersRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SessionLoggerSummary {
    sessionLoggerArn: string;
    logConfiguration?: LogConfiguration | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    creationDate?: Date | undefined;
}
export type SessionLoggerList = SessionLoggerSummary[];
export interface ListSessionLoggersResponse {
    sessionLoggers?: SessionLoggerSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SessionSortBy = "StartTimeAscending" | "StartTimeDescending" | (string & {});
export interface ListSessionsRequest {
    portalId: string;
    username?: string | redacted.Redacted<string> | undefined;
    sessionId?: string | undefined;
    sortBy?: SessionSortBy | undefined;
    status?: SessionStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SessionSummary {
    portalArn?: string | undefined;
    sessionId?: string | undefined;
    username?: string | redacted.Redacted<string> | undefined;
    status?: SessionStatus | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type SessionSummaryList = SessionSummary[];
export interface ListSessionsResponse {
    sessions: SessionSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface ListTrustStoreCertificatesRequest {
    trustStoreArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CertificateSummary {
    thumbprint?: string | undefined;
    subject?: string | undefined;
    issuer?: string | undefined;
    notValidBefore?: Date | undefined;
    notValidAfter?: Date | undefined;
}
export type CertificateSummaryList = CertificateSummary[];
export interface ListTrustStoreCertificatesResponse {
    certificateList?: CertificateSummary[] | undefined;
    trustStoreArn: string;
    nextToken?: string | undefined;
}
export interface ListTrustStoresRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface TrustStoreSummary {
    trustStoreArn?: string | undefined;
}
export type TrustStoreSummaryList = TrustStoreSummary[];
export interface ListTrustStoresResponse {
    trustStores?: TrustStoreSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListUserAccessLoggingSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface UserAccessLoggingSettingsSummary {
    userAccessLoggingSettingsArn: string;
    kinesisStreamArn?: string | undefined;
}
export type UserAccessLoggingSettingsList = UserAccessLoggingSettingsSummary[];
export interface ListUserAccessLoggingSettingsResponse {
    userAccessLoggingSettings?: UserAccessLoggingSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListUserSettingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface UserSettingsSummary {
    userSettingsArn: string;
    copyAllowed?: string | undefined;
    pasteAllowed?: string | undefined;
    downloadAllowed?: string | undefined;
    uploadAllowed?: string | undefined;
    printAllowed?: string | undefined;
    disconnectTimeoutInMinutes?: number | undefined;
    idleDisconnectTimeoutInMinutes?: number | undefined;
    cookieSynchronizationConfiguration?: CookieSynchronizationConfiguration | undefined;
    deepLinkAllowed?: string | undefined;
    toolbarConfiguration?: ToolbarConfiguration | undefined;
    brandingConfiguration?: BrandingConfiguration | undefined;
    webAuthnAllowed?: string | undefined;
}
export type UserSettingsList = UserSettingsSummary[];
export interface ListUserSettingsResponse {
    userSettings?: UserSettingsSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
    clientToken?: string | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateBrowserSettingsRequest {
    browserSettingsArn: string;
    browserPolicy?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
    webContentFilteringPolicy?: WebContentFilteringPolicy | undefined;
}
export interface UpdateBrowserSettingsResponse {
    browserSettings: BrowserSettings;
}
export interface UpdateDataProtectionSettingsRequest {
    dataProtectionSettingsArn: string;
    inlineRedactionConfiguration?: InlineRedactionConfiguration | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export interface UpdateDataProtectionSettingsResponse {
    dataProtectionSettings: DataProtectionSettings;
}
export interface UpdateIdentityProviderRequest {
    identityProviderArn: string;
    identityProviderName?: string | redacted.Redacted<string> | undefined;
    identityProviderType?: string | undefined;
    identityProviderDetails?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface UpdateIdentityProviderResponse {
    identityProvider: IdentityProvider;
}
export interface UpdateIpAccessSettingsRequest {
    ipAccessSettingsArn: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    ipRules?: IpRule[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdateIpAccessSettingsResponse {
    ipAccessSettings: IpAccessSettings;
}
export interface UpdateNetworkSettingsRequest {
    networkSettingsArn: string;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdateNetworkSettingsResponse {
    networkSettings: NetworkSettings;
}
export interface UpdatePortalRequest {
    portalArn: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    authenticationType?: string | undefined;
    instanceType?: string | undefined;
    maxConcurrentSessions?: number | undefined;
    portalCustomDomain?: string | undefined;
}
export interface UpdatePortalResponse {
    portal?: Portal | undefined;
}
export interface UpdateSessionLoggerRequest {
    sessionLoggerArn: string;
    eventFilter?: EventFilter | undefined;
    logConfiguration?: LogConfiguration | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateSessionLoggerResponse {
    sessionLogger: SessionLogger;
}
export type CertificateThumbprintList = string[];
export interface UpdateTrustStoreRequest {
    trustStoreArn: string;
    certificatesToAdd?: Uint8Array[] | undefined;
    certificatesToDelete?: string[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdateTrustStoreResponse {
    trustStoreArn: string;
}
export interface UpdateUserAccessLoggingSettingsRequest {
    userAccessLoggingSettingsArn: string;
    kinesisStreamArn?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateUserAccessLoggingSettingsResponse {
    userAccessLoggingSettings: UserAccessLoggingSettings;
}
export interface BrandingConfigurationUpdateInput {
    logo?: IconImageInput | undefined;
    wallpaper?: WallpaperImageInput | undefined;
    favicon?: IconImageInput | undefined;
    localizedStrings?: {
        [key: string]: LocalizedBrandingStrings | undefined;
    } | undefined;
    colorTheme?: ColorTheme | undefined;
    termsOfService?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateUserSettingsRequest {
    userSettingsArn: string;
    copyAllowed?: string | undefined;
    pasteAllowed?: string | undefined;
    downloadAllowed?: string | undefined;
    uploadAllowed?: string | undefined;
    printAllowed?: string | undefined;
    disconnectTimeoutInMinutes?: number | undefined;
    idleDisconnectTimeoutInMinutes?: number | undefined;
    clientToken?: string | undefined;
    cookieSynchronizationConfiguration?: CookieSynchronizationConfiguration | undefined;
    deepLinkAllowed?: string | undefined;
    toolbarConfiguration?: ToolbarConfiguration | undefined;
    brandingConfigurationInput?: BrandingConfigurationUpdateInput | undefined;
    webAuthnAllowed?: string | undefined;
}
export interface UpdateUserSettingsResponse {
    userSettings: UserSettings;
}
export type ExceptionMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type RetryAfterSeconds = number;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = string;
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type TagExceptionMessage = string;
export type AssociateBrowserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a browser settings resource with a web portal.
 */
export declare const associateBrowserSettings: API.OperationMethod<AssociateBrowserSettingsRequest & RegionInput, AssociateBrowserSettingsResponse, AssociateBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type AssociateDataProtectionSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a data protection settings resource with a web portal.
 */
export declare const associateDataProtectionSettings: API.OperationMethod<AssociateDataProtectionSettingsRequest & RegionInput, AssociateDataProtectionSettingsResponse, AssociateDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type AssociateIpAccessSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an IP access settings resource with a web portal.
 */
export declare const associateIpAccessSettings: API.OperationMethod<AssociateIpAccessSettingsRequest & RegionInput, AssociateIpAccessSettingsResponse, AssociateIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type AssociateNetworkSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a network settings resource with a web portal.
 */
export declare const associateNetworkSettings: API.OperationMethod<AssociateNetworkSettingsRequest & RegionInput, AssociateNetworkSettingsResponse, AssociateNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type AssociateSessionLoggerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a session logger with a portal.
 */
export declare const associateSessionLogger: API.OperationMethod<AssociateSessionLoggerRequest & RegionInput, AssociateSessionLoggerResponse, AssociateSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type AssociateTrustStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a trust store with a web portal.
 */
export declare const associateTrustStore: API.OperationMethod<AssociateTrustStoreRequest & RegionInput, AssociateTrustStoreResponse, AssociateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type AssociateUserAccessLoggingSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a user access logging settings resource with a web portal.
 */
export declare const associateUserAccessLoggingSettings: API.OperationMethod<AssociateUserAccessLoggingSettingsRequest & RegionInput, AssociateUserAccessLoggingSettingsResponse, AssociateUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type AssociateUserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a user settings resource with a web portal.
 */
export declare const associateUserSettings: API.OperationMethod<AssociateUserSettingsRequest & RegionInput, AssociateUserSettingsResponse, AssociateUserSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateBrowserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a browser settings resource that can be associated with a web portal. Once associated with a web portal, browser settings control how the browser will behave once a user starts a streaming session for the web portal.
 */
export declare const createBrowserSettings: API.OperationMethod<CreateBrowserSettingsRequest & RegionInput, CreateBrowserSettingsResponse, CreateBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateDataProtectionSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data protection settings resource that can be associated with a web portal.
 */
export declare const createDataProtectionSettings: API.OperationMethod<CreateDataProtectionSettingsRequest & RegionInput, CreateDataProtectionSettingsResponse, CreateDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateIdentityProviderError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an identity provider resource that is then associated with a web portal.
 */
export declare const createIdentityProvider: API.OperationMethod<CreateIdentityProviderRequest & RegionInput, CreateIdentityProviderResponse, CreateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateIpAccessSettingsError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an IP access settings resource that can be associated with a web portal.
 */
export declare const createIpAccessSettings: API.OperationMethod<CreateIpAccessSettingsRequest & RegionInput, CreateIpAccessSettingsResponse, CreateIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkSettingsError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a network settings resource that can be associated with a web portal. Once associated with a web portal, network settings define how streaming instances will connect with your specified VPC.
 */
export declare const createNetworkSettings: API.OperationMethod<CreateNetworkSettingsRequest & RegionInput, CreateNetworkSettingsResponse, CreateNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a web portal.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest & RegionInput, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreateSessionLoggerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a session logger.
 */
export declare const createSessionLogger: API.OperationMethod<CreateSessionLoggerRequest & RegionInput, CreateSessionLoggerResponse, CreateSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type CreateTrustStoreError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a trust store that can be associated with a web portal. A trust store contains certificate authority (CA) certificates. Once associated with a web portal, the browser in a streaming session will recognize certificates that have been issued using any of the CAs in the trust store. If your organization has internal websites that use certificates issued by private CAs, you should add the private CA certificate to the trust store.
 */
export declare const createTrustStore: API.OperationMethod<CreateTrustStoreRequest & RegionInput, CreateTrustStoreResponse, CreateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type CreateUserAccessLoggingSettingsError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a user access logging settings resource that can be associated with a web portal.
 */
export declare const createUserAccessLoggingSettings: API.OperationMethod<CreateUserAccessLoggingSettingsRequest & RegionInput, CreateUserAccessLoggingSettingsResponse, CreateUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateUserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a user settings resource that can be associated with a web portal. Once associated with a web portal, user settings control how users can transfer data between a streaming session and the their local devices.
 */
export declare const createUserSettings: API.OperationMethod<CreateUserSettingsRequest & RegionInput, CreateUserSettingsResponse, CreateUserSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteBrowserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes browser settings.
 */
export declare const deleteBrowserSettings: API.OperationMethod<DeleteBrowserSettingsRequest & RegionInput, DeleteBrowserSettingsResponse, DeleteBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProtectionSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes data protection settings.
 */
export declare const deleteDataProtectionSettings: API.OperationMethod<DeleteDataProtectionSettingsRequest & RegionInput, DeleteDataProtectionSettingsResponse, DeleteDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityProviderError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the identity provider.
 */
export declare const deleteIdentityProvider: API.OperationMethod<DeleteIdentityProviderRequest & RegionInput, DeleteIdentityProviderResponse, DeleteIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteIpAccessSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes IP access settings.
 */
export declare const deleteIpAccessSettings: API.OperationMethod<DeleteIpAccessSettingsRequest & RegionInput, DeleteIpAccessSettingsResponse, DeleteIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes network settings.
 */
export declare const deleteNetworkSettings: API.OperationMethod<DeleteNetworkSettingsRequest & RegionInput, DeleteNetworkSettingsResponse, DeleteNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a web portal.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest & RegionInput, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeleteSessionLoggerError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a session logger resource.
 */
export declare const deleteSessionLogger: API.OperationMethod<DeleteSessionLoggerRequest & RegionInput, DeleteSessionLoggerResponse, DeleteSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustStoreError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the trust store.
 */
export declare const deleteTrustStore: API.OperationMethod<DeleteTrustStoreRequest & RegionInput, DeleteTrustStoreResponse, DeleteTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteUserAccessLoggingSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes user access logging settings.
 */
export declare const deleteUserAccessLoggingSettings: API.OperationMethod<DeleteUserAccessLoggingSettingsRequest & RegionInput, DeleteUserAccessLoggingSettingsResponse, DeleteUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteUserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes user settings.
 */
export declare const deleteUserSettings: API.OperationMethod<DeleteUserSettingsRequest & RegionInput, DeleteUserSettingsResponse, DeleteUserSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateBrowserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates browser settings from a web portal.
 */
export declare const disassociateBrowserSettings: API.OperationMethod<DisassociateBrowserSettingsRequest & RegionInput, DisassociateBrowserSettingsResponse, DisassociateBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateDataProtectionSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates data protection settings from a web portal.
 */
export declare const disassociateDataProtectionSettings: API.OperationMethod<DisassociateDataProtectionSettingsRequest & RegionInput, DisassociateDataProtectionSettingsResponse, DisassociateDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateIpAccessSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates IP access settings from a web portal.
 */
export declare const disassociateIpAccessSettings: API.OperationMethod<DisassociateIpAccessSettingsRequest & RegionInput, DisassociateIpAccessSettingsResponse, DisassociateIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateNetworkSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates network settings from a web portal.
 */
export declare const disassociateNetworkSettings: API.OperationMethod<DisassociateNetworkSettingsRequest & RegionInput, DisassociateNetworkSettingsResponse, DisassociateNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateSessionLoggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a session logger from a portal.
 */
export declare const disassociateSessionLogger: API.OperationMethod<DisassociateSessionLoggerRequest & RegionInput, DisassociateSessionLoggerResponse, DisassociateSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type DisassociateTrustStoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a trust store from a web portal.
 */
export declare const disassociateTrustStore: API.OperationMethod<DisassociateTrustStoreRequest & RegionInput, DisassociateTrustStoreResponse, DisassociateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DisassociateUserAccessLoggingSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates user access logging settings from a web portal.
 */
export declare const disassociateUserAccessLoggingSettings: API.OperationMethod<DisassociateUserAccessLoggingSettingsRequest & RegionInput, DisassociateUserAccessLoggingSettingsResponse, DisassociateUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type DisassociateUserSettingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates user settings from a web portal.
 */
export declare const disassociateUserSettings: API.OperationMethod<DisassociateUserSettingsRequest & RegionInput, DisassociateUserSettingsResponse, DisassociateUserSettingsError, Credentials | HttpClient.HttpClient>;
export type ExpireSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Expires an active secure browser session.
 */
export declare const expireSession: API.OperationMethod<ExpireSessionRequest & RegionInput, ExpireSessionResponse, ExpireSessionError, Credentials | HttpClient.HttpClient>;
export type GetBrowserSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets browser settings.
 */
export declare const getBrowserSettings: API.OperationMethod<GetBrowserSettingsRequest & RegionInput, GetBrowserSettingsResponse, GetBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type GetDataProtectionSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the data protection settings.
 */
export declare const getDataProtectionSettings: API.OperationMethod<GetDataProtectionSettingsRequest & RegionInput, GetDataProtectionSettingsResponse, GetDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type GetIdentityProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the identity provider.
 */
export declare const getIdentityProvider: API.OperationMethod<GetIdentityProviderRequest & RegionInput, GetIdentityProviderResponse, GetIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type GetIpAccessSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the IP access settings.
 */
export declare const getIpAccessSettings: API.OperationMethod<GetIpAccessSettingsRequest & RegionInput, GetIpAccessSettingsResponse, GetIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type GetNetworkSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the network settings.
 */
export declare const getNetworkSettings: API.OperationMethod<GetNetworkSettingsRequest & RegionInput, GetNetworkSettingsResponse, GetNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type GetPortalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the web portal.
 */
export declare const getPortal: API.OperationMethod<GetPortalRequest & RegionInput, GetPortalResponse, GetPortalError, Credentials | HttpClient.HttpClient>;
export type GetPortalServiceProviderMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the service provider metadata.
 */
export declare const getPortalServiceProviderMetadata: API.OperationMethod<GetPortalServiceProviderMetadataRequest & RegionInput, GetPortalServiceProviderMetadataResponse, GetPortalServiceProviderMetadataError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information for a secure browser session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionLoggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a specific session logger resource.
 */
export declare const getSessionLogger: API.OperationMethod<GetSessionLoggerRequest & RegionInput, GetSessionLoggerResponse, GetSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the trust store.
 */
export declare const getTrustStore: API.OperationMethod<GetTrustStoreRequest & RegionInput, GetTrustStoreResponse, GetTrustStoreError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the trust store certificate.
 */
export declare const getTrustStoreCertificate: API.OperationMethod<GetTrustStoreCertificateRequest & RegionInput, GetTrustStoreCertificateResponse, GetTrustStoreCertificateError, Credentials | HttpClient.HttpClient>;
export type GetUserAccessLoggingSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets user access logging settings.
 */
export declare const getUserAccessLoggingSettings: API.OperationMethod<GetUserAccessLoggingSettingsRequest & RegionInput, GetUserAccessLoggingSettingsResponse, GetUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type GetUserSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets user settings.
 */
export declare const getUserSettings: API.OperationMethod<GetUserSettingsRequest & RegionInput, GetUserSettingsResponse, GetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type ListBrowserSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of browser settings.
 */
export declare const listBrowserSettings: API.PaginatedOperationMethod<ListBrowserSettingsRequest & RegionInput, ListBrowserSettingsResponse, ListBrowserSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataProtectionSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of data protection settings.
 */
export declare const listDataProtectionSettings: API.PaginatedOperationMethod<ListDataProtectionSettingsRequest & RegionInput, ListDataProtectionSettingsResponse, ListDataProtectionSettingsError, Credentials | HttpClient.HttpClient, DataProtectionSettingsSummary>;
export type ListIdentityProvidersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of identity providers for a specific web portal.
 */
export declare const listIdentityProviders: API.PaginatedOperationMethod<ListIdentityProvidersRequest & RegionInput, ListIdentityProvidersResponse, ListIdentityProvidersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIpAccessSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of IP access settings.
 */
export declare const listIpAccessSettings: API.PaginatedOperationMethod<ListIpAccessSettingsRequest & RegionInput, ListIpAccessSettingsResponse, ListIpAccessSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNetworkSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of network settings.
 */
export declare const listNetworkSettings: API.PaginatedOperationMethod<ListNetworkSettingsRequest & RegionInput, ListNetworkSettingsResponse, ListNetworkSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPortalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list or web portals.
 */
export declare const listPortals: API.PaginatedOperationMethod<ListPortalsRequest & RegionInput, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSessionLoggersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available session logger resources.
 */
export declare const listSessionLoggers: API.PaginatedOperationMethod<ListSessionLoggersRequest & RegionInput, ListSessionLoggersResponse, ListSessionLoggersError, Credentials | HttpClient.HttpClient, SessionLoggerSummary>;
export type ListSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information for multiple secure browser sessions from a specific portal.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrustStoreCertificatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of trust store certificates.
 */
export declare const listTrustStoreCertificates: API.PaginatedOperationMethod<ListTrustStoreCertificatesRequest & RegionInput, ListTrustStoreCertificatesResponse, ListTrustStoreCertificatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTrustStoresError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of trust stores.
 */
export declare const listTrustStores: API.PaginatedOperationMethod<ListTrustStoresRequest & RegionInput, ListTrustStoresResponse, ListTrustStoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListUserAccessLoggingSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of user access logging settings.
 */
export declare const listUserAccessLoggingSettings: API.PaginatedOperationMethod<ListUserAccessLoggingSettingsRequest & RegionInput, ListUserAccessLoggingSettingsResponse, ListUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListUserSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of user settings.
 */
export declare const listUserSettings: API.PaginatedOperationMethod<ListUserSettingsRequest & RegionInput, ListUserSettingsResponse, ListUserSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBrowserSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates browser settings.
 */
export declare const updateBrowserSettings: API.OperationMethod<UpdateBrowserSettingsRequest & RegionInput, UpdateBrowserSettingsResponse, UpdateBrowserSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateDataProtectionSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates data protection settings.
 */
export declare const updateDataProtectionSettings: API.OperationMethod<UpdateDataProtectionSettingsRequest & RegionInput, UpdateDataProtectionSettingsResponse, UpdateDataProtectionSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityProviderError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the identity provider.
 */
export declare const updateIdentityProvider: API.OperationMethod<UpdateIdentityProviderRequest & RegionInput, UpdateIdentityProviderResponse, UpdateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateIpAccessSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates IP access settings.
 */
export declare const updateIpAccessSettings: API.OperationMethod<UpdateIpAccessSettingsRequest & RegionInput, UpdateIpAccessSettingsResponse, UpdateIpAccessSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates network settings.
 */
export declare const updateNetworkSettings: API.OperationMethod<UpdateNetworkSettingsRequest & RegionInput, UpdateNetworkSettingsResponse, UpdateNetworkSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a web portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest & RegionInput, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdateSessionLoggerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the details of a session logger.
 */
export declare const updateSessionLogger: API.OperationMethod<UpdateSessionLoggerRequest & RegionInput, UpdateSessionLoggerResponse, UpdateSessionLoggerError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustStoreError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the trust store.
 */
export declare const updateTrustStore: API.OperationMethod<UpdateTrustStoreRequest & RegionInput, UpdateTrustStoreResponse, UpdateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateUserAccessLoggingSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the user access logging settings.
 */
export declare const updateUserAccessLoggingSettings: API.OperationMethod<UpdateUserAccessLoggingSettingsRequest & RegionInput, UpdateUserAccessLoggingSettingsResponse, UpdateUserAccessLoggingSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateUserSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the user settings.
 */
export declare const updateUserSettings: API.OperationMethod<UpdateUserSettingsRequest & RegionInput, UpdateUserSettingsResponse, UpdateUserSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workspaces-web.d.ts.map