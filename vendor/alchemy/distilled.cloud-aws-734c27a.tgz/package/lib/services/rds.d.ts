import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AuthorizationAlreadyExistsFault_base: S.TaggedErrorClass<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const AuthorizationQuotaExceededFault_base: S.TaggedErrorClass<"AuthorizationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationQuotaExceededFault extends /*@__PURE__*/ AuthorizationQuotaExceededFault_base {
}
declare const BackupPolicyNotFoundFault_base: S.TaggedErrorClass<"BackupPolicyNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BackupPolicyNotFoundFault extends /*@__PURE__*/ BackupPolicyNotFoundFault_base {
}
declare const BlueGreenDeploymentAlreadyExistsFault_base: S.TaggedErrorClass<"BlueGreenDeploymentAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class BlueGreenDeploymentAlreadyExistsFault extends /*@__PURE__*/ BlueGreenDeploymentAlreadyExistsFault_base {
}
declare const BlueGreenDeploymentNotFoundFault_base: S.TaggedErrorClass<"BlueGreenDeploymentNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BlueGreenDeploymentNotFoundFault extends /*@__PURE__*/ BlueGreenDeploymentNotFoundFault_base {
}
declare const CertificateNotFoundFault_base: S.TaggedErrorClass<"CertificateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundFault extends /*@__PURE__*/ CertificateNotFoundFault_base {
}
declare const CreateCustomDBEngineVersionFault_base: S.TaggedErrorClass<"CreateCustomDBEngineVersionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CreateCustomDBEngineVersionFault extends /*@__PURE__*/ CreateCustomDBEngineVersionFault_base {
}
declare const CustomAvailabilityZoneNotFoundFault_base: S.TaggedErrorClass<"CustomAvailabilityZoneNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomAvailabilityZoneNotFoundFault extends /*@__PURE__*/ CustomAvailabilityZoneNotFoundFault_base {
}
declare const CustomDBEngineVersionAlreadyExistsFault_base: S.TaggedErrorClass<"CustomDBEngineVersionAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CustomDBEngineVersionAlreadyExistsFault extends /*@__PURE__*/ CustomDBEngineVersionAlreadyExistsFault_base {
}
declare const CustomDBEngineVersionNotFoundFault_base: S.TaggedErrorClass<"CustomDBEngineVersionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomDBEngineVersionNotFoundFault extends /*@__PURE__*/ CustomDBEngineVersionNotFoundFault_base {
}
declare const CustomDBEngineVersionQuotaExceededFault_base: S.TaggedErrorClass<"CustomDBEngineVersionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomDBEngineVersionQuotaExceededFault extends /*@__PURE__*/ CustomDBEngineVersionQuotaExceededFault_base {
}
declare const DBCapacityReservationAlreadyExistsFault_base: S.TaggedErrorClass<"DBCapacityReservationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBCapacityReservationAlreadyExistsFault extends /*@__PURE__*/ DBCapacityReservationAlreadyExistsFault_base {
}
declare const DBCapacityReservationNotFoundFault_base: S.TaggedErrorClass<"DBCapacityReservationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBCapacityReservationNotFoundFault extends /*@__PURE__*/ DBCapacityReservationNotFoundFault_base {
}
declare const DBCapacityReservationUnsupportedFault_base: S.TaggedErrorClass<"DBCapacityReservationUnsupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBCapacityReservationUnsupportedFault extends /*@__PURE__*/ DBCapacityReservationUnsupportedFault_base {
}
declare const DBClusterAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterAlreadyExistsFault extends /*@__PURE__*/ DBClusterAlreadyExistsFault_base {
}
declare const DBClusterAutomatedBackupNotFoundFault_base: S.TaggedErrorClass<"DBClusterAutomatedBackupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterAutomatedBackupNotFoundFault extends /*@__PURE__*/ DBClusterAutomatedBackupNotFoundFault_base {
}
declare const DBClusterAutomatedBackupQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterAutomatedBackupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterAutomatedBackupQuotaExceededFault extends /*@__PURE__*/ DBClusterAutomatedBackupQuotaExceededFault_base {
}
declare const DBClusterBacktrackNotFoundFault_base: S.TaggedErrorClass<"DBClusterBacktrackNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterBacktrackNotFoundFault extends /*@__PURE__*/ DBClusterBacktrackNotFoundFault_base {
}
declare const DBClusterDeletionProtected_base: S.TaggedErrorClass<"DBClusterDeletionProtected", {
    readonly message: any;
}>;
export declare class DBClusterDeletionProtected extends /*@__PURE__*/ DBClusterDeletionProtected_base {
}
declare const DBClusterEndpointAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterEndpointAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterEndpointAlreadyExistsFault extends /*@__PURE__*/ DBClusterEndpointAlreadyExistsFault_base {
}
declare const DBClusterEndpointNotFoundFault_base: S.TaggedErrorClass<"DBClusterEndpointNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterEndpointNotFoundFault extends /*@__PURE__*/ DBClusterEndpointNotFoundFault_base {
}
declare const DBClusterEndpointQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterEndpointQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DBClusterEndpointQuotaExceededFault extends /*@__PURE__*/ DBClusterEndpointQuotaExceededFault_base {
}
declare const DBClusterNotFoundFault_base: S.TaggedErrorClass<"DBClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBClusterNotFoundFault extends /*@__PURE__*/ DBClusterNotFoundFault_base {
}
declare const DBClusterParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBClusterParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterParameterGroupNotFoundFault extends /*@__PURE__*/ DBClusterParameterGroupNotFoundFault_base {
}
declare const DBClusterQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class DBClusterQuotaExceededFault extends /*@__PURE__*/ DBClusterQuotaExceededFault_base {
}
declare const DBClusterRoleAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterRoleAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterRoleAlreadyExistsFault extends /*@__PURE__*/ DBClusterRoleAlreadyExistsFault_base {
}
declare const DBClusterRoleNotFoundFault_base: S.TaggedErrorClass<"DBClusterRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterRoleNotFoundFault extends /*@__PURE__*/ DBClusterRoleNotFoundFault_base {
}
declare const DBClusterRoleQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterRoleQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterRoleQuotaExceededFault extends /*@__PURE__*/ DBClusterRoleQuotaExceededFault_base {
}
declare const DBClusterSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBClusterSnapshotAlreadyExistsFault_base {
}
declare const DBClusterSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBClusterSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterSnapshotNotFoundFault extends /*@__PURE__*/ DBClusterSnapshotNotFoundFault_base {
}
declare const DBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceAlreadyExistsFault extends /*@__PURE__*/ DBInstanceAlreadyExistsFault_base {
}
declare const DBInstanceAutomatedBackupNotFoundFault_base: S.TaggedErrorClass<"DBInstanceAutomatedBackupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceAutomatedBackupNotFoundFault extends /*@__PURE__*/ DBInstanceAutomatedBackupNotFoundFault_base {
}
declare const DBInstanceAutomatedBackupQuotaExceededFault_base: S.TaggedErrorClass<"DBInstanceAutomatedBackupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceAutomatedBackupQuotaExceededFault extends /*@__PURE__*/ DBInstanceAutomatedBackupQuotaExceededFault_base {
}
declare const DBInstanceDeletionProtected_base: S.TaggedErrorClass<"DBInstanceDeletionProtected", {
    readonly message: any;
}>;
export declare class DBInstanceDeletionProtected extends /*@__PURE__*/ DBInstanceDeletionProtected_base {
}
declare const DBInstanceNotFoundFault_base: S.TaggedErrorClass<"DBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotFoundFault extends /*@__PURE__*/ DBInstanceNotFoundFault_base {
}
declare const DBInstanceNotReadyFault_base: S.TaggedErrorClass<"DBInstanceNotReadyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotReadyFault extends /*@__PURE__*/ DBInstanceNotReadyFault_base {
}
declare const DBInstanceRoleAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceRoleAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceRoleAlreadyExistsFault extends /*@__PURE__*/ DBInstanceRoleAlreadyExistsFault_base {
}
declare const DBInstanceRoleNotFoundFault_base: S.TaggedErrorClass<"DBInstanceRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceRoleNotFoundFault extends /*@__PURE__*/ DBInstanceRoleNotFoundFault_base {
}
declare const DBInstanceRoleQuotaExceededFault_base: S.TaggedErrorClass<"DBInstanceRoleQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceRoleQuotaExceededFault extends /*@__PURE__*/ DBInstanceRoleQuotaExceededFault_base {
}
declare const DBLogFileNotFoundFault_base: S.TaggedErrorClass<"DBLogFileNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBLogFileNotFoundFault extends /*@__PURE__*/ DBLogFileNotFoundFault_base {
}
declare const DBParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBParameterGroupAlreadyExistsFault extends /*@__PURE__*/ DBParameterGroupAlreadyExistsFault_base {
}
declare const DBParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBParameterGroupNotFoundFault extends /*@__PURE__*/ DBParameterGroupNotFoundFault_base {
}
declare const DBParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupQuotaExceededFault extends /*@__PURE__*/ DBParameterGroupQuotaExceededFault_base {
}
declare const DBProxyAlreadyExistsFault_base: S.TaggedErrorClass<"DBProxyAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBProxyAlreadyExistsFault extends /*@__PURE__*/ DBProxyAlreadyExistsFault_base {
}
declare const DBProxyEndpointAlreadyExistsFault_base: S.TaggedErrorClass<"DBProxyEndpointAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBProxyEndpointAlreadyExistsFault extends /*@__PURE__*/ DBProxyEndpointAlreadyExistsFault_base {
}
declare const DBProxyEndpointNotFoundFault_base: S.TaggedErrorClass<"DBProxyEndpointNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyEndpointNotFoundFault extends /*@__PURE__*/ DBProxyEndpointNotFoundFault_base {
}
declare const DBProxyEndpointQuotaExceededFault_base: S.TaggedErrorClass<"DBProxyEndpointQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyEndpointQuotaExceededFault extends /*@__PURE__*/ DBProxyEndpointQuotaExceededFault_base {
}
declare const DBProxyNotFoundFault_base: S.TaggedErrorClass<"DBProxyNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyNotFoundFault extends /*@__PURE__*/ DBProxyNotFoundFault_base {
}
declare const DBProxyQuotaExceededFault_base: S.TaggedErrorClass<"DBProxyQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyQuotaExceededFault extends /*@__PURE__*/ DBProxyQuotaExceededFault_base {
}
declare const DBProxyTargetAlreadyRegisteredFault_base: S.TaggedErrorClass<"DBProxyTargetAlreadyRegisteredFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetAlreadyRegisteredFault extends /*@__PURE__*/ DBProxyTargetAlreadyRegisteredFault_base {
}
declare const DBProxyTargetGroupNotFoundFault_base: S.TaggedErrorClass<"DBProxyTargetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetGroupNotFoundFault extends /*@__PURE__*/ DBProxyTargetGroupNotFoundFault_base {
}
declare const DBProxyTargetNotFoundFault_base: S.TaggedErrorClass<"DBProxyTargetNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBProxyTargetNotFoundFault extends /*@__PURE__*/ DBProxyTargetNotFoundFault_base {
}
declare const DBSecurityGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ DBSecurityGroupAlreadyExistsFault_base {
}
declare const DBSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"DBSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBSecurityGroupNotFoundFault extends /*@__PURE__*/ DBSecurityGroupNotFoundFault_base {
}
declare const DBSecurityGroupNotSupportedFault_base: S.TaggedErrorClass<"DBSecurityGroupNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupNotSupportedFault extends /*@__PURE__*/ DBSecurityGroupNotSupportedFault_base {
}
declare const DBSecurityGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSecurityGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupQuotaExceededFault extends /*@__PURE__*/ DBSecurityGroupQuotaExceededFault_base {
}
declare const DBShardGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBShardGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBShardGroupAlreadyExistsFault extends /*@__PURE__*/ DBShardGroupAlreadyExistsFault_base {
}
declare const DBShardGroupNotFoundFault_base: S.TaggedErrorClass<"DBShardGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBShardGroupNotFoundFault extends /*@__PURE__*/ DBShardGroupNotFoundFault_base {
}
declare const DBSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBSnapshotAlreadyExistsFault_base {
}
declare const DBSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotNotFoundFault extends /*@__PURE__*/ DBSnapshotNotFoundFault_base {
}
declare const DBSnapshotTenantDatabaseNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotTenantDatabaseNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotTenantDatabaseNotFoundFault extends /*@__PURE__*/ DBSnapshotTenantDatabaseNotFoundFault_base {
}
declare const DBSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ DBSubnetGroupAlreadyExistsFault_base {
}
declare const DBSubnetGroupDoesNotCoverEnoughAZs_base: S.TaggedErrorClass<"DBSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ DBSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const DBSubnetGroupNotAllowedFault_base: S.TaggedErrorClass<"DBSubnetGroupNotAllowedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupNotAllowedFault extends /*@__PURE__*/ DBSubnetGroupNotAllowedFault_base {
}
declare const DBSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"DBSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DBSubnetGroupNotFoundFault extends /*@__PURE__*/ DBSubnetGroupNotFoundFault_base {
}
declare const DBSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class DBSubnetGroupQuotaExceededFault extends /*@__PURE__*/ DBSubnetGroupQuotaExceededFault_base {
}
declare const DBSubnetQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetQuotaExceededFault extends /*@__PURE__*/ DBSubnetQuotaExceededFault_base {
}
declare const DBUpgradeDependencyFailureFault_base: S.TaggedErrorClass<"DBUpgradeDependencyFailureFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBUpgradeDependencyFailureFault extends /*@__PURE__*/ DBUpgradeDependencyFailureFault_base {
}
declare const DomainNotFoundFault_base: S.TaggedErrorClass<"DomainNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DomainNotFoundFault extends /*@__PURE__*/ DomainNotFoundFault_base {
}
declare const Ec2ImagePropertiesNotSupportedFault_base: S.TaggedErrorClass<"Ec2ImagePropertiesNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Ec2ImagePropertiesNotSupportedFault extends /*@__PURE__*/ Ec2ImagePropertiesNotSupportedFault_base {
}
declare const EventSubscriptionQuotaExceededFault_base: S.TaggedErrorClass<"EventSubscriptionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventSubscriptionQuotaExceededFault extends /*@__PURE__*/ EventSubscriptionQuotaExceededFault_base {
}
declare const ExportTaskAlreadyExistsFault_base: S.TaggedErrorClass<"ExportTaskAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ExportTaskAlreadyExistsFault extends /*@__PURE__*/ ExportTaskAlreadyExistsFault_base {
}
declare const ExportTaskNotFoundFault_base: S.TaggedErrorClass<"ExportTaskNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExportTaskNotFoundFault extends /*@__PURE__*/ ExportTaskNotFoundFault_base {
}
declare const GlobalClusterAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalClusterAlreadyExistsFault extends /*@__PURE__*/ GlobalClusterAlreadyExistsFault_base {
}
declare const GlobalClusterNotFoundFault_base: S.TaggedErrorClass<"GlobalClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterNotFoundFault extends /*@__PURE__*/ GlobalClusterNotFoundFault_base {
}
declare const GlobalClusterQuotaExceededFault_base: S.TaggedErrorClass<"GlobalClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterQuotaExceededFault extends /*@__PURE__*/ GlobalClusterQuotaExceededFault_base {
}
declare const IamRoleMissingPermissionsFault_base: S.TaggedErrorClass<"IamRoleMissingPermissionsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IamRoleMissingPermissionsFault extends /*@__PURE__*/ IamRoleMissingPermissionsFault_base {
}
declare const IamRoleNotFoundFault_base: S.TaggedErrorClass<"IamRoleNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IamRoleNotFoundFault extends /*@__PURE__*/ IamRoleNotFoundFault_base {
}
declare const InstanceQuotaExceededFault_base: S.TaggedErrorClass<"InstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceQuotaExceededFault extends /*@__PURE__*/ InstanceQuotaExceededFault_base {
}
declare const InsufficientAvailableIPsInSubnetFault_base: S.TaggedErrorClass<"InsufficientAvailableIPsInSubnetFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientAvailableIPsInSubnetFault extends /*@__PURE__*/ InsufficientAvailableIPsInSubnetFault_base {
}
declare const InsufficientDBClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class InsufficientDBClusterCapacityFault extends /*@__PURE__*/ InsufficientDBClusterCapacityFault_base {
}
declare const InsufficientDBInstanceCapacityFault_base: S.TaggedErrorClass<"InsufficientDBInstanceCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDBInstanceCapacityFault extends /*@__PURE__*/ InsufficientDBInstanceCapacityFault_base {
}
declare const InsufficientStorageClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientStorageClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientStorageClusterCapacityFault extends /*@__PURE__*/ InsufficientStorageClusterCapacityFault_base {
}
declare const IntegrationAlreadyExistsFault_base: S.TaggedErrorClass<"IntegrationAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class IntegrationAlreadyExistsFault extends /*@__PURE__*/ IntegrationAlreadyExistsFault_base {
}
declare const IntegrationConflictOperationFault_base: S.TaggedErrorClass<"IntegrationConflictOperationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationConflictOperationFault extends /*@__PURE__*/ IntegrationConflictOperationFault_base {
}
declare const IntegrationNotFoundFault_base: S.TaggedErrorClass<"IntegrationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationNotFoundFault extends /*@__PURE__*/ IntegrationNotFoundFault_base {
}
declare const IntegrationQuotaExceededFault_base: S.TaggedErrorClass<"IntegrationQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationQuotaExceededFault extends /*@__PURE__*/ IntegrationQuotaExceededFault_base {
}
declare const InvalidBlueGreenDeploymentStateFault_base: S.TaggedErrorClass<"InvalidBlueGreenDeploymentStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidBlueGreenDeploymentStateFault extends /*@__PURE__*/ InvalidBlueGreenDeploymentStateFault_base {
}
declare const InvalidCustomDBEngineVersionStateFault_base: S.TaggedErrorClass<"InvalidCustomDBEngineVersionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCustomDBEngineVersionStateFault extends /*@__PURE__*/ InvalidCustomDBEngineVersionStateFault_base {
}
declare const InvalidDBCapacityReservationStateFault_base: S.TaggedErrorClass<"InvalidDBCapacityReservationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBCapacityReservationStateFault extends /*@__PURE__*/ InvalidDBCapacityReservationStateFault_base {
}
declare const InvalidDBClusterAutomatedBackupStateFault_base: S.TaggedErrorClass<"InvalidDBClusterAutomatedBackupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterAutomatedBackupStateFault extends /*@__PURE__*/ InvalidDBClusterAutomatedBackupStateFault_base {
}
declare const InvalidDBClusterCapacityFault_base: S.TaggedErrorClass<"InvalidDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterCapacityFault extends /*@__PURE__*/ InvalidDBClusterCapacityFault_base {
}
declare const InvalidDBClusterEndpointStateFault_base: S.TaggedErrorClass<"InvalidDBClusterEndpointStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterEndpointStateFault extends /*@__PURE__*/ InvalidDBClusterEndpointStateFault_base {
}
declare const InvalidDBClusterSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBClusterSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterSnapshotStateFault extends /*@__PURE__*/ InvalidDBClusterSnapshotStateFault_base {
}
declare const InvalidDBClusterStateFault_base: S.TaggedErrorClass<"InvalidDBClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidDBClusterStateFault extends /*@__PURE__*/ InvalidDBClusterStateFault_base {
}
declare const InvalidDBInstanceAutomatedBackupStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceAutomatedBackupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceAutomatedBackupStateFault extends /*@__PURE__*/ InvalidDBInstanceAutomatedBackupStateFault_base {
}
declare const InvalidDBInstanceStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceStateFault extends /*@__PURE__*/ InvalidDBInstanceStateFault_base {
}
declare const InvalidDBParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidDBParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBParameterGroupStateFault extends /*@__PURE__*/ InvalidDBParameterGroupStateFault_base {
}
declare const InvalidDBProxyEndpointStateFault_base: S.TaggedErrorClass<"InvalidDBProxyEndpointStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBProxyEndpointStateFault extends /*@__PURE__*/ InvalidDBProxyEndpointStateFault_base {
}
declare const InvalidDBProxyStateFault_base: S.TaggedErrorClass<"InvalidDBProxyStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBProxyStateFault extends /*@__PURE__*/ InvalidDBProxyStateFault_base {
}
declare const InvalidDBSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSecurityGroupStateFault extends /*@__PURE__*/ InvalidDBSecurityGroupStateFault_base {
}
declare const InvalidDBShardGroupStateFault_base: S.TaggedErrorClass<"InvalidDBShardGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBShardGroupStateFault extends /*@__PURE__*/ InvalidDBShardGroupStateFault_base {
}
declare const InvalidDBSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSnapshotStateFault extends /*@__PURE__*/ InvalidDBSnapshotStateFault_base {
}
declare const InvalidDBSubnetGroupFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupFault extends /*@__PURE__*/ InvalidDBSubnetGroupFault_base {
}
declare const InvalidDBSubnetGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupStateFault extends /*@__PURE__*/ InvalidDBSubnetGroupStateFault_base {
}
declare const InvalidDBSubnetStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetStateFault extends /*@__PURE__*/ InvalidDBSubnetStateFault_base {
}
declare const InvalidEventSubscriptionStateFault_base: S.TaggedErrorClass<"InvalidEventSubscriptionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSubscriptionStateFault extends /*@__PURE__*/ InvalidEventSubscriptionStateFault_base {
}
declare const InvalidExportOnlyFault_base: S.TaggedErrorClass<"InvalidExportOnlyFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportOnlyFault extends /*@__PURE__*/ InvalidExportOnlyFault_base {
}
declare const InvalidExportSourceStateFault_base: S.TaggedErrorClass<"InvalidExportSourceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportSourceStateFault extends /*@__PURE__*/ InvalidExportSourceStateFault_base {
}
declare const InvalidExportTaskStateFault_base: S.TaggedErrorClass<"InvalidExportTaskStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportTaskStateFault extends /*@__PURE__*/ InvalidExportTaskStateFault_base {
}
declare const InvalidGlobalClusterStateFault_base: S.TaggedErrorClass<"InvalidGlobalClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalClusterStateFault extends /*@__PURE__*/ InvalidGlobalClusterStateFault_base {
}
declare const InvalidIntegrationStateFault_base: S.TaggedErrorClass<"InvalidIntegrationStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIntegrationStateFault extends /*@__PURE__*/ InvalidIntegrationStateFault_base {
}
declare const InvalidOptionGroupStateFault_base: S.TaggedErrorClass<"InvalidOptionGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOptionGroupStateFault extends /*@__PURE__*/ InvalidOptionGroupStateFault_base {
}
declare const InvalidParameterCombination_base: S.TaggedErrorClass<"InvalidParameterCombination", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombination extends /*@__PURE__*/ InvalidParameterCombination_base {
}
declare const InvalidParameterValue_base: S.TaggedErrorClass<"InvalidParameterValue", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValue extends /*@__PURE__*/ InvalidParameterValue_base {
}
declare const InvalidResourceStateFault_base: S.TaggedErrorClass<"InvalidResourceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResourceStateFault extends /*@__PURE__*/ InvalidResourceStateFault_base {
}
declare const InvalidRestoreFault_base: S.TaggedErrorClass<"InvalidRestoreFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreFault extends /*@__PURE__*/ InvalidRestoreFault_base {
}
declare const InvalidS3BucketFault_base: S.TaggedErrorClass<"InvalidS3BucketFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketFault extends /*@__PURE__*/ InvalidS3BucketFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const MaxDBShardGroupLimitReached_base: S.TaggedErrorClass<"MaxDBShardGroupLimitReached", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaxDBShardGroupLimitReached extends /*@__PURE__*/ MaxDBShardGroupLimitReached_base {
}
declare const NetworkTypeNotSupported_base: S.TaggedErrorClass<"NetworkTypeNotSupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkTypeNotSupported extends /*@__PURE__*/ NetworkTypeNotSupported_base {
}
declare const OptionGroupAlreadyExistsFault_base: S.TaggedErrorClass<"OptionGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OptionGroupAlreadyExistsFault extends /*@__PURE__*/ OptionGroupAlreadyExistsFault_base {
}
declare const OptionGroupNotFoundFault_base: S.TaggedErrorClass<"OptionGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OptionGroupNotFoundFault extends /*@__PURE__*/ OptionGroupNotFoundFault_base {
}
declare const OptionGroupQuotaExceededFault_base: S.TaggedErrorClass<"OptionGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OptionGroupQuotaExceededFault extends /*@__PURE__*/ OptionGroupQuotaExceededFault_base {
}
declare const PointInTimeRestoreNotEnabledFault_base: S.TaggedErrorClass<"PointInTimeRestoreNotEnabledFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PointInTimeRestoreNotEnabledFault extends /*@__PURE__*/ PointInTimeRestoreNotEnabledFault_base {
}
declare const ProvisionedIopsNotAvailableInAZFault_base: S.TaggedErrorClass<"ProvisionedIopsNotAvailableInAZFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ProvisionedIopsNotAvailableInAZFault extends /*@__PURE__*/ ProvisionedIopsNotAvailableInAZFault_base {
}
declare const ReservedDBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"ReservedDBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedDBInstanceAlreadyExistsFault extends /*@__PURE__*/ ReservedDBInstanceAlreadyExistsFault_base {
}
declare const ReservedDBInstanceNotFoundFault_base: S.TaggedErrorClass<"ReservedDBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstanceNotFoundFault extends /*@__PURE__*/ ReservedDBInstanceNotFoundFault_base {
}
declare const ReservedDBInstanceQuotaExceededFault_base: S.TaggedErrorClass<"ReservedDBInstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstanceQuotaExceededFault extends /*@__PURE__*/ ReservedDBInstanceQuotaExceededFault_base {
}
declare const ReservedDBInstancesOfferingNotFoundFault_base: S.TaggedErrorClass<"ReservedDBInstancesOfferingNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedDBInstancesOfferingNotFoundFault extends /*@__PURE__*/ ReservedDBInstancesOfferingNotFoundFault_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const SharedSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SharedSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SharedSnapshotQuotaExceededFault extends /*@__PURE__*/ SharedSnapshotQuotaExceededFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const SNSTopicArnNotFoundFault_base: S.TaggedErrorClass<"SNSTopicArnNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSTopicArnNotFoundFault extends /*@__PURE__*/ SNSTopicArnNotFoundFault_base {
}
declare const SourceClusterNotSupportedFault_base: S.TaggedErrorClass<"SourceClusterNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceClusterNotSupportedFault extends /*@__PURE__*/ SourceClusterNotSupportedFault_base {
}
declare const SourceDatabaseNotSupportedFault_base: S.TaggedErrorClass<"SourceDatabaseNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceDatabaseNotSupportedFault extends /*@__PURE__*/ SourceDatabaseNotSupportedFault_base {
}
declare const SourceNotFoundFault_base: S.TaggedErrorClass<"SourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceNotFoundFault extends /*@__PURE__*/ SourceNotFoundFault_base {
}
declare const StorageQuotaExceededFault_base: S.TaggedErrorClass<"StorageQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const StorageTypeNotAvailableFault_base: S.TaggedErrorClass<"StorageTypeNotAvailableFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotAvailableFault extends /*@__PURE__*/ StorageTypeNotAvailableFault_base {
}
declare const StorageTypeNotSupportedFault_base: S.TaggedErrorClass<"StorageTypeNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotSupportedFault extends /*@__PURE__*/ StorageTypeNotSupportedFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const SubscriptionAlreadyExistFault_base: S.TaggedErrorClass<"SubscriptionAlreadyExistFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionAlreadyExistFault extends /*@__PURE__*/ SubscriptionAlreadyExistFault_base {
}
declare const SubscriptionCategoryNotFoundFault_base: S.TaggedErrorClass<"SubscriptionCategoryNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionCategoryNotFoundFault extends /*@__PURE__*/ SubscriptionCategoryNotFoundFault_base {
}
declare const SubscriptionNotFoundFault_base: S.TaggedErrorClass<"SubscriptionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionNotFoundFault extends /*@__PURE__*/ SubscriptionNotFoundFault_base {
}
declare const TenantDatabaseAlreadyExistsFault_base: S.TaggedErrorClass<"TenantDatabaseAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TenantDatabaseAlreadyExistsFault extends /*@__PURE__*/ TenantDatabaseAlreadyExistsFault_base {
}
declare const TenantDatabaseNotFoundFault_base: S.TaggedErrorClass<"TenantDatabaseNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TenantDatabaseNotFoundFault extends /*@__PURE__*/ TenantDatabaseNotFoundFault_base {
}
declare const TenantDatabaseQuotaExceededFault_base: S.TaggedErrorClass<"TenantDatabaseQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TenantDatabaseQuotaExceededFault extends /*@__PURE__*/ TenantDatabaseQuotaExceededFault_base {
}
declare const UnsupportedDBEngineVersionFault_base: S.TaggedErrorClass<"UnsupportedDBEngineVersionFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDBEngineVersionFault extends /*@__PURE__*/ UnsupportedDBEngineVersionFault_base {
}
declare const VpcEncryptionControlViolationException_base: S.TaggedErrorClass<"VpcEncryptionControlViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class VpcEncryptionControlViolationException extends /*@__PURE__*/ VpcEncryptionControlViolationException_base {
}
export type IAMRoleArn = string;
export interface AddRoleToDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
}
export interface AddRoleToDBClusterResponse {
}
export interface AddRoleToDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
}
export interface AddRoleToDBInstanceResponse {
}
export interface AddSourceIdentifierToSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SourceIdentifier?: string | undefined;
}
export type SourceIdsList = string[];
export type EventCategoriesList = string[];
export interface EventSubscription {
    CustomerAwsId?: string | undefined;
    CustSubscriptionId?: string | undefined;
    SnsTopicArn?: string | undefined;
    Status?: string | undefined;
    SubscriptionCreationTime?: string | undefined;
    SourceType?: string | undefined;
    SourceIdsList?: string[] | undefined;
    EventCategoriesList?: string[] | undefined;
    Enabled?: boolean | undefined;
    EventSubscriptionArn?: string | undefined;
}
export interface AddSourceIdentifierToSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface AddTagsToResourceResponse {
}
export interface ApplyPendingMaintenanceActionMessage {
    ResourceIdentifier?: string | undefined;
    ApplyAction?: string | undefined;
    OptInType?: string | undefined;
}
export interface PendingMaintenanceAction {
    Action?: string | undefined;
    AutoAppliedAfterDate?: Date | undefined;
    ForcedApplyDate?: Date | undefined;
    OptInStatus?: string | undefined;
    CurrentApplyDate?: Date | undefined;
    Description?: string | undefined;
}
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string | undefined;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[] | undefined;
}
export interface ApplyPendingMaintenanceActionResult {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions | undefined;
}
export interface AuthorizeDBSecurityGroupIngressMessage {
    DBSecurityGroupName?: string | undefined;
    CIDRIP?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupId?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export interface EC2SecurityGroup {
    Status?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupId?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export type EC2SecurityGroupList = EC2SecurityGroup[];
export interface IPRange {
    Status?: string | undefined;
    CIDRIP?: string | undefined;
}
export type IPRangeList = IPRange[];
export interface DBSecurityGroup {
    OwnerId?: string | undefined;
    DBSecurityGroupName?: string | undefined;
    DBSecurityGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    EC2SecurityGroups?: EC2SecurityGroup[] | undefined;
    IPRanges?: IPRange[] | undefined;
    DBSecurityGroupArn?: string | undefined;
}
export interface AuthorizeDBSecurityGroupIngressResult {
    DBSecurityGroup?: DBSecurityGroup | undefined;
}
export interface BacktrackDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    BacktrackTo?: Date | undefined;
    Force?: boolean | undefined;
    UseEarliestTimeOnPointInTimeUnavailable?: boolean | undefined;
}
export interface DBClusterBacktrack {
    DBClusterIdentifier?: string | undefined;
    BacktrackIdentifier?: string | undefined;
    BacktrackTo?: Date | undefined;
    BacktrackedFrom?: Date | undefined;
    BacktrackRequestCreationTime?: Date | undefined;
    Status?: string | undefined;
}
export type DBCapacityReservationIdentifier = string;
export interface CancelDBCapacityReservationRequest {
    DBCapacityReservationIdentifier?: string | undefined;
}
export type DBCapacityReservationName = string;
export type DBInstanceClass = string;
export interface AvailableCapacityPerAvailabilityZone {
    AvailabilityZone?: string | undefined;
    AvailableCapacity?: number | undefined;
}
export type AvailableCapacityPerAvailabilityZoneList = AvailableCapacityPerAvailabilityZone[];
export interface DBCapacityReservationCommitmentInfo {
    CommittedCapacityPerAvailabilityZone?: number | undefined;
    CommitmentEndDate?: Date | undefined;
}
export type DBCapacityReservationState = "active" | "expired" | "cancelled" | "pending" | "failed" | "assessing" | "scheduled" | "delayed" | "unsupported" | (string & {});
export interface DBCapacityReservation {
    DBCapacityReservationName?: string | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    LicenseModel?: string | undefined;
    ReservedCapacityPerAvailabilityZone?: number | undefined;
    AvailableCapacityPerAvailabilityZoneList?: AvailableCapacityPerAvailabilityZone[] | undefined;
    EndDate?: Date | undefined;
    CreateDate?: Date | undefined;
    StartDate?: Date | undefined;
    CommitmentInfo?: DBCapacityReservationCommitmentInfo | undefined;
    State?: DBCapacityReservationState | undefined;
    DBCapacityReservationArn?: string | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    TagList?: Tag[] | undefined;
}
export interface CancelDBCapacityReservationResponse {
    DBCapacityReservation?: DBCapacityReservation | undefined;
}
export interface CancelExportTaskMessage {
    ExportTaskIdentifier?: string | undefined;
}
export type StringList = string[];
export type ExportSourceType = "SNAPSHOT" | "CLUSTER" | (string & {});
export interface ExportTask {
    ExportTaskIdentifier?: string | undefined;
    SourceArn?: string | undefined;
    ExportOnly?: string[] | undefined;
    SnapshotTime?: Date | undefined;
    TaskStartTime?: Date | undefined;
    TaskEndTime?: Date | undefined;
    S3Bucket?: string | undefined;
    S3Prefix?: string | undefined;
    IamRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    Status?: string | undefined;
    PercentProgress?: number | undefined;
    TotalExtractedDataInGB?: number | undefined;
    FailureCause?: string | undefined;
    WarningMessage?: string | undefined;
    SourceType?: ExportSourceType | undefined;
}
export interface CopyDBClusterParameterGroupMessage {
    SourceDBClusterParameterGroupIdentifier?: string | undefined;
    TargetDBClusterParameterGroupIdentifier?: string | undefined;
    TargetDBClusterParameterGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DBClusterParameterGroup {
    DBClusterParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    DBClusterParameterGroupArn?: string | undefined;
}
export interface CopyDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface CopyDBClusterSnapshotMessage {
    SourceDBClusterSnapshotIdentifier?: string | undefined;
    TargetDBClusterSnapshotIdentifier?: string | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | redacted.Redacted<string> | undefined;
    CopyTags?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type AvailabilityZones = string[];
export type StorageEncryptionType = "none" | "sse-kms" | "sse-rds" | (string & {});
export interface DBClusterSnapshot {
    AvailabilityZones?: string[] | undefined;
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    SnapshotCreateTime?: Date | undefined;
    Engine?: string | undefined;
    EngineMode?: string | undefined;
    AllocatedStorage?: number | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    VpcId?: string | undefined;
    ClusterCreateTime?: Date | undefined;
    MasterUsername?: string | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    SnapshotType?: string | undefined;
    PercentProgress?: number | undefined;
    StorageEncrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    KmsKeyId?: string | undefined;
    DBClusterSnapshotArn?: string | undefined;
    SourceDBClusterSnapshotArn?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    TagList?: Tag[] | undefined;
    StorageType?: string | undefined;
    StorageThroughput?: number | undefined;
    DbClusterResourceId?: string | undefined;
    DBSystemId?: string | undefined;
}
export interface CopyDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export interface CopyDBParameterGroupMessage {
    SourceDBParameterGroupIdentifier?: string | undefined;
    TargetDBParameterGroupIdentifier?: string | undefined;
    TargetDBParameterGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DBParameterGroup {
    DBParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    DBParameterGroupArn?: string | undefined;
}
export interface CopyDBParameterGroupResult {
    DBParameterGroup?: DBParameterGroup | undefined;
}
export interface TagSpecification {
    ResourceType?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type TagSpecificationList = TagSpecification[];
export interface CopyDBSnapshotMessage {
    SourceDBSnapshotIdentifier?: string | undefined;
    TargetDBSnapshotIdentifier?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
    CopyTags?: boolean | undefined;
    PreSignedUrl?: string | redacted.Redacted<string> | undefined;
    OptionGroupName?: string | undefined;
    TargetCustomAvailabilityZone?: string | undefined;
    SnapshotTarget?: string | undefined;
    CopyOptionGroup?: boolean | undefined;
    SnapshotAvailabilityZone?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
}
export interface ProcessorFeature {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type ProcessorFeatureList = ProcessorFeature[];
export interface AdditionalStorageVolume {
    VolumeName?: string | undefined;
    AllocatedStorage?: number | undefined;
    IOPS?: number | undefined;
    MaxAllocatedStorage?: number | undefined;
    StorageThroughput?: number | undefined;
    StorageType?: string | undefined;
}
export type AdditionalStorageVolumesList = AdditionalStorageVolume[];
export interface DBSnapshot {
    DBSnapshotIdentifier?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    SnapshotCreateTime?: Date | undefined;
    Engine?: string | undefined;
    AllocatedStorage?: number | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    VpcId?: string | undefined;
    InstanceCreateTime?: Date | undefined;
    MasterUsername?: string | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    SnapshotType?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    PercentProgress?: number | undefined;
    SourceRegion?: string | undefined;
    SourceDBSnapshotIdentifier?: string | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    Encrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    KmsKeyId?: string | undefined;
    DBSnapshotArn?: string | undefined;
    Timezone?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    DbiResourceId?: string | undefined;
    TagList?: Tag[] | undefined;
    SnapshotTarget?: string | undefined;
    OriginalSnapshotCreateTime?: Date | undefined;
    SnapshotDatabaseTime?: Date | undefined;
    DBSystemId?: string | undefined;
    MultiTenant?: boolean | undefined;
    DedicatedLogVolume?: boolean | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    SnapshotAvailabilityZone?: string | undefined;
    FullSnapshotSizeInBytes?: number | undefined;
}
export interface CopyDBSnapshotResult {
    DBSnapshot?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export interface CopyOptionGroupMessage {
    SourceOptionGroupIdentifier?: string | undefined;
    TargetOptionGroupIdentifier?: string | undefined;
    TargetOptionGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type PotentiallySensitiveOptionSettingValue = string | redacted.Redacted<string>;
export interface OptionSetting {
    Name?: string | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    DefaultValue?: string | undefined;
    Description?: string | undefined;
    ApplyType?: string | undefined;
    DataType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    IsCollection?: boolean | undefined;
}
export type OptionSettingConfigurationList = OptionSetting[];
export interface DBSecurityGroupMembership {
    DBSecurityGroupName?: string | undefined;
    Status?: string | undefined;
}
export type DBSecurityGroupMembershipList = DBSecurityGroupMembership[];
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string | undefined;
    Status?: string | undefined;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface Option {
    OptionName?: string | undefined;
    OptionDescription?: string | undefined;
    Persistent?: boolean | undefined;
    Permanent?: boolean | undefined;
    Port?: number | undefined;
    OptionVersion?: string | undefined;
    OptionSettings?: OptionSetting[] | undefined;
    DBSecurityGroupMemberships?: DBSecurityGroupMembership[] | undefined;
    VpcSecurityGroupMemberships?: VpcSecurityGroupMembership[] | undefined;
}
export type OptionsList = Option[];
export interface OptionGroup {
    OptionGroupName?: string | undefined;
    OptionGroupDescription?: string | undefined;
    EngineName?: string | undefined;
    MajorEngineVersion?: string | undefined;
    Options?: Option[] | undefined;
    AllowsVpcAndNonVpcInstanceMemberships?: boolean | undefined;
    VpcId?: string | undefined;
    OptionGroupArn?: string | undefined;
    SourceOptionGroup?: string | undefined;
    SourceAccountId?: string | undefined;
    CopyTimestamp?: Date | undefined;
    SourceRegion?: string | undefined;
}
export interface CopyOptionGroupResult {
    OptionGroup?: OptionGroup | undefined;
}
export type BlueGreenDeploymentName = string;
export type DatabaseArn = string;
export type TargetEngineVersion = string;
export type TargetDBParameterGroupName = string;
export type TargetDBClusterParameterGroupName = string;
export type TargetDBInstanceClass = string;
export type TargetStorageType = string;
export type DBAndClusterArn = string;
export type KmsKeyIdOrArn = string;
export interface TargetResourceConfiguration {
    SourceArn: string;
    TargetKmsKeyId?: string | undefined;
}
export type TargetResourceConfigurationList = TargetResourceConfiguration[];
export interface CreateBlueGreenDeploymentRequest {
    BlueGreenDeploymentName?: string | undefined;
    Source?: string | undefined;
    TargetEngineVersion?: string | undefined;
    TargetDBParameterGroupName?: string | undefined;
    TargetDBClusterParameterGroupName?: string | undefined;
    Tags?: Tag[] | undefined;
    TargetDBInstanceClass?: string | undefined;
    UpgradeTargetStorageConfig?: boolean | undefined;
    TargetIops?: number | undefined;
    TargetStorageType?: string | undefined;
    TargetAllocatedStorage?: number | undefined;
    TargetStorageThroughput?: number | undefined;
    TargetResourceConfigurations?: TargetResourceConfiguration[] | undefined;
}
export type BlueGreenDeploymentIdentifier = string;
export type SwitchoverDetailStatus = string;
export interface SwitchoverDetail {
    SourceMember?: string | undefined;
    TargetMember?: string | undefined;
    Status?: string | undefined;
}
export type SwitchoverDetailList = SwitchoverDetail[];
export type BlueGreenDeploymentTaskName = string;
export type BlueGreenDeploymentTaskStatus = string;
export interface BlueGreenDeploymentTask {
    Name?: string | undefined;
    Status?: string | undefined;
}
export type BlueGreenDeploymentTaskList = BlueGreenDeploymentTask[];
export type BlueGreenDeploymentStatus = string;
export type BlueGreenDeploymentStatusDetails = string;
export interface BlueGreenDeployment {
    BlueGreenDeploymentIdentifier?: string | undefined;
    BlueGreenDeploymentName?: string | undefined;
    Source?: string | undefined;
    Target?: string | undefined;
    SwitchoverDetails?: SwitchoverDetail[] | undefined;
    Tasks?: BlueGreenDeploymentTask[] | undefined;
    Status?: string | undefined;
    StatusDetails?: string | undefined;
    CreateTime?: Date | undefined;
    DeleteTime?: Date | undefined;
    TagList?: Tag[] | undefined;
}
export interface CreateBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment | undefined;
}
export type CustomEngineName = string;
export type CustomEngineVersion = string;
export type BucketName = string;
export type String255 = string;
export type Description = string;
export type CustomDBEngineVersionManifest = string;
export interface CreateCustomDBEngineVersionMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DatabaseInstallationFilesS3BucketName?: string | undefined;
    DatabaseInstallationFilesS3Prefix?: string | undefined;
    DatabaseInstallationFiles?: string[] | undefined;
    ImageId?: string | undefined;
    KMSKeyId?: string | undefined;
    SourceCustomDbEngineVersionIdentifier?: string | undefined;
    UseAwsProvidedLatestImage?: boolean | undefined;
    Description?: string | undefined;
    Manifest?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CharacterSet {
    CharacterSetName?: string | undefined;
    CharacterSetDescription?: string | undefined;
}
export interface CustomDBEngineVersionAMI {
    ImageId?: string | undefined;
    Status?: string | undefined;
}
export type SupportedCharacterSetsList = CharacterSet[];
export type EngineModeList = string[];
export interface UpgradeTarget {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Description?: string | undefined;
    AutoUpgrade?: boolean | undefined;
    IsMajorVersionUpgrade?: boolean | undefined;
    SupportedEngineModes?: string[] | undefined;
    SupportsParallelQuery?: boolean | undefined;
    SupportsGlobalDatabases?: boolean | undefined;
    SupportsBabelfish?: boolean | undefined;
    SupportsLimitlessDatabase?: boolean | undefined;
    SupportsLocalWriteForwarding?: boolean | undefined;
    SupportsIntegrations?: boolean | undefined;
}
export type ValidUpgradeTargetList = UpgradeTarget[];
export interface Timezone {
    TimezoneName?: string | undefined;
}
export type SupportedTimezonesList = Timezone[];
export type LogTypeList = string[];
export type FeatureNameList = string[];
export type CACertificateIdentifiersList = string[];
export interface ServerlessV2FeaturesSupport {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
}
export interface DBEngineVersion {
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
    EngineVersion?: string | undefined;
    DatabaseInstallationFilesS3BucketName?: string | undefined;
    DatabaseInstallationFilesS3Prefix?: string | undefined;
    DatabaseInstallationFiles?: string[] | undefined;
    CustomDBEngineVersionManifest?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    DBEngineDescription?: string | undefined;
    DBEngineVersionArn?: string | undefined;
    DBEngineVersionDescription?: string | undefined;
    DefaultCharacterSet?: CharacterSet | undefined;
    FailureReason?: string | undefined;
    Image?: CustomDBEngineVersionAMI | undefined;
    DBEngineMediaType?: string | undefined;
    KMSKeyId?: string | undefined;
    CreateTime?: Date | undefined;
    SupportedCharacterSets?: CharacterSet[] | undefined;
    SupportedNcharCharacterSets?: CharacterSet[] | undefined;
    ValidUpgradeTarget?: UpgradeTarget[] | undefined;
    SupportedTimezones?: Timezone[] | undefined;
    ExportableLogTypes?: string[] | undefined;
    SupportsLogExportsToCloudwatchLogs?: boolean | undefined;
    SupportsReadReplica?: boolean | undefined;
    SupportedEngineModes?: string[] | undefined;
    SupportedFeatureNames?: string[] | undefined;
    Status?: string | undefined;
    SupportsParallelQuery?: boolean | undefined;
    SupportsGlobalDatabases?: boolean | undefined;
    TagList?: Tag[] | undefined;
    SupportsBabelfish?: boolean | undefined;
    SupportsLimitlessDatabase?: boolean | undefined;
    SupportsCertificateRotationWithoutRestart?: boolean | undefined;
    SupportedCACertificateIdentifiers?: string[] | undefined;
    SupportsLocalWriteForwarding?: boolean | undefined;
    SupportsIntegrations?: boolean | undefined;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport | undefined;
}
export interface CreateDBCapacityReservationRequest {
    DBCapacityReservationName?: string | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    CapacityPerAvailabilityZone?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    EndDate?: Date | undefined;
    StartDate?: Date | undefined;
    CommitmentDuration?: number | undefined;
    LicenseModel?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBCapacityReservationResponse {
    DBCapacityReservation?: DBCapacityReservation | undefined;
}
export type VpcSecurityGroupIdList = string[];
export interface ScalingConfiguration {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
    AutoPause?: boolean | undefined;
    SecondsUntilAutoPause?: number | undefined;
    TimeoutAction?: string | undefined;
    SecondsBeforeTimeout?: number | undefined;
}
export type ReplicaMode = "open-read-only" | "mounted" | (string & {});
export interface RdsCustomClusterConfiguration {
    InterconnectSubnetId?: string | undefined;
    TransitGatewayMulticastDomainId?: string | undefined;
    ReplicaMode?: ReplicaMode | undefined;
}
export type GlobalClusterIdentifier = string;
export interface ServerlessV2ScalingConfiguration {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
    SecondsUntilAutoPause?: number | undefined;
}
export type DatabaseInsightsMode = "standard" | "advanced" | (string & {});
export type ClusterScalabilityType = "standard" | "limitless" | (string & {});
export type MasterUserAuthenticationType = "password" | "iam-db-auth" | (string & {});
export interface DBClusterAssociatedRole {
    RoleArn: string;
    FeatureName?: string | undefined;
}
export type DBClusterAssociatedRoles = DBClusterAssociatedRole[];
export interface CreateDBClusterMessage {
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    CharacterSetName?: string | undefined;
    DatabaseName?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterParameterGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    DBSubnetGroupName?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    OptionGroupName?: string | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    ReplicationSourceIdentifier?: string | undefined;
    Tags?: Tag[] | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | redacted.Redacted<string> | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    BacktrackWindow?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    EngineMode?: string | undefined;
    ScalingConfiguration?: ScalingConfiguration | undefined;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration | undefined;
    DBClusterInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    StorageType?: string | undefined;
    Iops?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    GlobalClusterIdentifier?: string | undefined;
    EnableHttpEndpoint?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    EnableGlobalWriteForwarding?: boolean | undefined;
    NetworkType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnableLimitlessDatabase?: boolean | undefined;
    ClusterScalabilityType?: ClusterScalabilityType | undefined;
    DBSystemId?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    EnableLocalWriteForwarding?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    MasterUserAuthenticationType?: MasterUserAuthenticationType | undefined;
    WithExpressConfiguration?: boolean | undefined;
    AssociatedRoles?: DBClusterAssociatedRole[] | undefined;
}
export interface DBClusterOptionGroupStatus {
    DBClusterOptionGroupName?: string | undefined;
    Status?: string | undefined;
}
export type DBClusterOptionGroupMemberships = DBClusterOptionGroupStatus[];
export type UpgradeRolloutOrder = "first" | "second" | "last" | (string & {});
export type ReadReplicaIdentifierList = string[];
export interface DBClusterStatusInfo {
    StatusType?: string | undefined;
    Normal?: boolean | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
}
export type DBClusterStatusInfoList = DBClusterStatusInfo[];
export interface DBClusterMember {
    DBInstanceIdentifier?: string | undefined;
    IsClusterWriter?: boolean | undefined;
    DBClusterParameterGroupStatus?: string | undefined;
    PromotionTier?: number | undefined;
}
export type DBClusterMemberList = DBClusterMember[];
export interface DBClusterRole {
    RoleArn?: string | undefined;
    Status?: string | undefined;
    FeatureName?: string | undefined;
}
export type DBClusterRoles = DBClusterRole[];
export interface PendingCloudwatchLogsExports {
    LogTypesToEnable?: string[] | undefined;
    LogTypesToDisable?: string[] | undefined;
}
export interface CertificateDetails {
    CAIdentifier?: string | undefined;
    ValidTill?: Date | undefined;
}
export interface ClusterPendingModifiedValues {
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports | undefined;
    DBClusterIdentifier?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    EngineVersion?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    StorageType?: string | undefined;
    AllocatedStorage?: number | undefined;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration | undefined;
    Iops?: number | undefined;
    CertificateDetails?: CertificateDetails | undefined;
}
export interface ScalingConfigurationInfo {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
    AutoPause?: boolean | undefined;
    SecondsUntilAutoPause?: number | undefined;
    TimeoutAction?: string | undefined;
    SecondsBeforeTimeout?: number | undefined;
}
export type ActivityStreamMode = "sync" | "async" | (string & {});
export type ActivityStreamStatus = "stopped" | "starting" | "started" | "stopping" | (string & {});
export interface DomainMembership {
    Domain?: string | undefined;
    Status?: string | undefined;
    FQDN?: string | undefined;
    IAMRoleName?: string | undefined;
    OU?: string | undefined;
    AuthSecretArn?: string | undefined;
    DnsIps?: string[] | undefined;
}
export type DomainMembershipList = DomainMembership[];
export type WriteForwardingStatus = "enabled" | "disabled" | "enabling" | "disabling" | "unknown" | (string & {});
export interface ServerlessV2ScalingConfigurationInfo {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
    SecondsUntilAutoPause?: number | undefined;
}
export interface MasterUserSecret {
    SecretArn?: string | undefined;
    SecretStatus?: string | undefined;
    KmsKeyId?: string | undefined;
}
export type LocalWriteForwardingStatus = "enabled" | "disabled" | "enabling" | "disabling" | "requested" | (string & {});
export type LimitlessDatabaseStatus = "active" | "not-in-use" | "enabled" | "disabled" | "enabling" | "disabling" | "modifying-max-capacity" | "error" | (string & {});
export interface LimitlessDatabase {
    Status?: LimitlessDatabaseStatus | undefined;
    MinRequiredACU?: number | undefined;
}
export interface DBCluster {
    AllocatedStorage?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    CharacterSetName?: string | undefined;
    DatabaseName?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterParameterGroup?: string | undefined;
    DBSubnetGroup?: string | undefined;
    Status?: string | undefined;
    PercentProgress?: string | undefined;
    EarliestRestorableTime?: Date | undefined;
    Endpoint?: string | undefined;
    ReaderEndpoint?: string | undefined;
    CustomEndpoints?: string[] | undefined;
    MultiAZ?: boolean | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    LatestRestorableTime?: Date | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    DBClusterOptionGroupMemberships?: DBClusterOptionGroupStatus[] | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    UpgradeRolloutOrder?: UpgradeRolloutOrder | undefined;
    ReplicationSourceIdentifier?: string | undefined;
    ReadReplicaIdentifiers?: string[] | undefined;
    StatusInfos?: DBClusterStatusInfo[] | undefined;
    DBClusterMembers?: DBClusterMember[] | undefined;
    VpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    HostedZoneId?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    KmsKeyId?: string | undefined;
    DbClusterResourceId?: string | undefined;
    DBClusterArn?: string | undefined;
    AssociatedRoles?: DBClusterRole[] | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    CloneGroupId?: string | undefined;
    ClusterCreateTime?: Date | undefined;
    EarliestBacktrackTime?: Date | undefined;
    BacktrackWindow?: number | undefined;
    BacktrackConsumedChangeRecords?: number | undefined;
    EnabledCloudwatchLogsExports?: string[] | undefined;
    Capacity?: number | undefined;
    PendingModifiedValues?: ClusterPendingModifiedValues | undefined;
    EngineMode?: string | undefined;
    ScalingConfigurationInfo?: ScalingConfigurationInfo | undefined;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration | undefined;
    DBClusterInstanceClass?: string | undefined;
    StorageType?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    IOOptimizedNextAllowedModificationTime?: Date | undefined;
    PubliclyAccessible?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    HttpEndpointEnabled?: boolean | undefined;
    ActivityStreamMode?: ActivityStreamMode | undefined;
    ActivityStreamStatus?: ActivityStreamStatus | undefined;
    ActivityStreamKmsKeyId?: string | undefined;
    ActivityStreamKinesisStreamName?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    CrossAccountClone?: boolean | undefined;
    DomainMemberships?: DomainMembership[] | undefined;
    TagList?: Tag[] | undefined;
    GlobalClusterIdentifier?: string | undefined;
    GlobalWriteForwardingStatus?: WriteForwardingStatus | undefined;
    GlobalWriteForwardingRequested?: boolean | undefined;
    NetworkType?: string | undefined;
    AutomaticRestartTime?: Date | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfigurationInfo | undefined;
    ServerlessV2PlatformVersion?: string | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    PerformanceInsightsEnabled?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    DBSystemId?: string | undefined;
    MasterUserSecret?: MasterUserSecret | undefined;
    LocalWriteForwardingStatus?: LocalWriteForwardingStatus | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    LimitlessDatabase?: LimitlessDatabase | undefined;
    ClusterScalabilityType?: ClusterScalabilityType | undefined;
    CertificateDetails?: CertificateDetails | undefined;
    EngineLifecycleSupport?: string | undefined;
    VPCNetworkingEnabled?: boolean | undefined;
    InternetAccessGatewayEnabled?: boolean | undefined;
}
export interface CreateDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface CreateDBClusterEndpointMessage {
    DBClusterIdentifier?: string | undefined;
    DBClusterEndpointIdentifier?: string | undefined;
    EndpointType?: string | undefined;
    StaticMembers?: string[] | undefined;
    ExcludedMembers?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface DBClusterEndpoint {
    DBClusterEndpointIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterEndpointResourceIdentifier?: string | undefined;
    Endpoint?: string | undefined;
    Status?: string | undefined;
    EndpointType?: string | undefined;
    CustomEndpointType?: string | undefined;
    StaticMembers?: string[] | undefined;
    ExcludedMembers?: string[] | undefined;
    DBClusterEndpointArn?: string | undefined;
}
export interface CreateDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup | undefined;
}
export interface CreateDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export type DBSecurityGroupNameList = string[];
export interface CreateDBInstanceMessage {
    DBName?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    AllocatedStorage?: number | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    DBSecurityGroups?: string[] | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    DBParameterGroupName?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    Port?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    CharacterSetName?: string | undefined;
    NcharCharacterSetName?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Tags?: Tag[] | undefined;
    DBClusterIdentifier?: string | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    TdeCredentialPassword?: string | redacted.Redacted<string> | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    Domain?: string | undefined;
    DomainFqdn?: string | undefined;
    DomainOu?: string | undefined;
    DomainAuthSecretArn?: string | undefined;
    DomainDnsIps?: string[] | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    PromotionTier?: number | undefined;
    Timezone?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    DeletionProtection?: boolean | undefined;
    MaxAllocatedStorage?: number | undefined;
    EnableCustomerOwnedIp?: boolean | undefined;
    NetworkType?: string | undefined;
    BackupTarget?: string | undefined;
    CustomIamInstanceProfile?: string | undefined;
    DBSystemId?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    MultiTenant?: boolean | undefined;
    DedicatedLogVolume?: boolean | undefined;
    EngineLifecycleSupport?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    MasterUserAuthenticationType?: MasterUserAuthenticationType | undefined;
}
export interface Endpoint {
    Address?: string | undefined;
    Port?: number | undefined;
    HostedZoneId?: string | undefined;
}
export interface DBParameterGroupStatus {
    DBParameterGroupName?: string | undefined;
    ParameterApplyStatus?: string | undefined;
}
export type DBParameterGroupStatusList = DBParameterGroupStatus[];
export interface AvailabilityZone {
    Name?: string | undefined;
}
export interface Outpost {
    Arn?: string | undefined;
}
export interface Subnet {
    SubnetIdentifier?: string | undefined;
    SubnetAvailabilityZone?: AvailabilityZone | undefined;
    SubnetOutpost?: Outpost | undefined;
    SubnetStatus?: string | undefined;
}
export type SubnetList = Subnet[];
export interface DBSubnetGroup {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    SubnetGroupStatus?: string | undefined;
    Subnets?: Subnet[] | undefined;
    DBSubnetGroupArn?: string | undefined;
    SupportedNetworkTypes?: string[] | undefined;
}
export type AutomationMode = "full" | "all-paused" | (string & {});
export interface PendingModifiedValues {
    DBInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    DBInstanceIdentifier?: string | undefined;
    StorageType?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    AutomationMode?: AutomationMode | undefined;
    ResumeFullAutomationModeTime?: Date | undefined;
    MultiTenant?: boolean | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    DedicatedLogVolume?: boolean | undefined;
    Engine?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
}
export type ReadReplicaDBInstanceIdentifierList = string[];
export type ReadReplicaDBClusterIdentifierList = string[];
export interface OptionGroupMembership {
    OptionGroupName?: string | undefined;
    Status?: string | undefined;
}
export type OptionGroupMembershipList = OptionGroupMembership[];
export interface DBInstanceStatusInfo {
    StatusType?: string | undefined;
    Normal?: boolean | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
}
export type DBInstanceStatusInfoList = DBInstanceStatusInfo[];
export interface DBInstanceRole {
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
    Status?: string | undefined;
}
export type DBInstanceRoles = DBInstanceRole[];
export interface DBInstanceAutomatedBackupsReplication {
    DBInstanceAutomatedBackupsArn?: string | undefined;
}
export type DBInstanceAutomatedBackupsReplicationList = DBInstanceAutomatedBackupsReplication[];
export type ActivityStreamPolicyStatus = "locked" | "unlocked" | "locking-policy" | "unlocking-policy" | (string & {});
export interface AdditionalStorageVolumeOutput {
    VolumeName?: string | undefined;
    StorageVolumeStatus?: string | undefined;
    StorageOperationStatus?: string | undefined;
    StorageOperationPercentProgress?: number | undefined;
    AllocatedStorage?: number | undefined;
    IOPS?: number | undefined;
    MaxAllocatedStorage?: number | undefined;
    StorageThroughput?: number | undefined;
    StorageType?: string | undefined;
}
export type AdditionalStorageVolumesOutputList = AdditionalStorageVolumeOutput[];
export interface DBInstance {
    DBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    DBInstanceStatus?: string | undefined;
    MasterUsername?: string | undefined;
    DBName?: string | undefined;
    Endpoint?: Endpoint | undefined;
    AllocatedStorage?: number | undefined;
    InstanceCreateTime?: Date | undefined;
    PreferredBackupWindow?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    DBSecurityGroups?: DBSecurityGroupMembership[] | undefined;
    VpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    DBParameterGroups?: DBParameterGroupStatus[] | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroup?: DBSubnetGroup | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    UpgradeRolloutOrder?: UpgradeRolloutOrder | undefined;
    PendingModifiedValues?: PendingModifiedValues | undefined;
    LatestRestorableTime?: Date | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    ReadReplicaSourceDBInstanceIdentifier?: string | undefined;
    ReadReplicaDBInstanceIdentifiers?: string[] | undefined;
    ReadReplicaDBClusterIdentifiers?: string[] | undefined;
    ReplicaMode?: ReplicaMode | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupMemberships?: OptionGroupMembership[] | undefined;
    CharacterSetName?: string | undefined;
    NcharCharacterSetName?: string | undefined;
    SecondaryAvailabilityZone?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    StatusInfos?: DBInstanceStatusInfo[] | undefined;
    StorageType?: string | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    TdeCredentialArn?: string | undefined;
    DbInstancePort?: number | undefined;
    DBClusterIdentifier?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DbiResourceId?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    DomainMemberships?: DomainMembership[] | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    EnhancedMonitoringResourceArn?: string | undefined;
    MonitoringRoleArn?: string | undefined;
    PromotionTier?: number | undefined;
    DBInstanceArn?: string | undefined;
    Timezone?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    PerformanceInsightsEnabled?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnabledCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    DeletionProtection?: boolean | undefined;
    AssociatedRoles?: DBInstanceRole[] | undefined;
    ListenerEndpoint?: Endpoint | undefined;
    MaxAllocatedStorage?: number | undefined;
    TagList?: Tag[] | undefined;
    AutomationMode?: AutomationMode | undefined;
    ResumeFullAutomationModeTime?: Date | undefined;
    CustomerOwnedIpEnabled?: boolean | undefined;
    NetworkType?: string | undefined;
    ActivityStreamStatus?: ActivityStreamStatus | undefined;
    ActivityStreamKmsKeyId?: string | undefined;
    ActivityStreamKinesisStreamName?: string | undefined;
    ActivityStreamMode?: ActivityStreamMode | undefined;
    ActivityStreamEngineNativeAuditFieldsIncluded?: boolean | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    DBInstanceAutomatedBackupsReplications?: DBInstanceAutomatedBackupsReplication[] | undefined;
    BackupTarget?: string | undefined;
    AutomaticRestartTime?: Date | undefined;
    CustomIamInstanceProfile?: string | undefined;
    ActivityStreamPolicyStatus?: ActivityStreamPolicyStatus | undefined;
    CertificateDetails?: CertificateDetails | undefined;
    DBSystemId?: string | undefined;
    MasterUserSecret?: MasterUserSecret | undefined;
    ReadReplicaSourceDBClusterIdentifier?: string | undefined;
    PercentProgress?: string | undefined;
    MultiTenant?: boolean | undefined;
    DedicatedLogVolume?: boolean | undefined;
    IsStorageConfigUpgradeAvailable?: boolean | undefined;
    EngineLifecycleSupport?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolumeOutput[] | undefined;
    StorageVolumeStatus?: string | undefined;
    StorageOperationStatus?: string | undefined;
    StorageOperationPercentProgress?: number | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
}
export interface CreateDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface CreateDBInstanceReadReplicaMessage {
    DBInstanceIdentifier?: string | undefined;
    SourceDBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    AvailabilityZone?: string | undefined;
    Port?: number | undefined;
    MultiAZ?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    DBParameterGroupName?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Tags?: Tag[] | undefined;
    DBSubnetGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    StorageType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | redacted.Redacted<string> | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    UseDefaultProcessorFeatures?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    DomainFqdn?: string | undefined;
    DomainOu?: string | undefined;
    DomainAuthSecretArn?: string | undefined;
    DomainDnsIps?: string[] | undefined;
    ReplicaMode?: ReplicaMode | undefined;
    EnableCustomerOwnedIp?: boolean | undefined;
    NetworkType?: string | undefined;
    MaxAllocatedStorage?: number | undefined;
    BackupTarget?: string | undefined;
    CustomIamInstanceProfile?: string | undefined;
    AllocatedStorage?: number | undefined;
    SourceDBClusterIdentifier?: string | undefined;
    DedicatedLogVolume?: boolean | undefined;
    UpgradeStorageConfig?: boolean | undefined;
    CACertificateIdentifier?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
}
export interface CreateDBInstanceReadReplicaResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface CreateDBParameterGroupMessage {
    DBParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBParameterGroupResult {
    DBParameterGroup?: DBParameterGroup | undefined;
}
export type DBProxyName = string;
export type EngineFamily = "MYSQL" | "POSTGRESQL" | "SQLSERVER" | (string & {});
export type DefaultAuthScheme = "IAM_AUTH" | "NONE" | (string & {});
export type AuthUserName = string;
export type AuthScheme = "SECRETS" | (string & {});
export type Arn = string;
export type IAMAuthMode = "DISABLED" | "REQUIRED" | "ENABLED" | (string & {});
export type ClientPasswordAuthType = "MYSQL_NATIVE_PASSWORD" | "MYSQL_CACHING_SHA2_PASSWORD" | "POSTGRES_SCRAM_SHA_256" | "POSTGRES_MD5" | "SQL_SERVER_AUTHENTICATION" | (string & {});
export interface UserAuthConfig {
    Description?: string | undefined;
    UserName?: string | undefined;
    AuthScheme?: AuthScheme | undefined;
    SecretArn?: string | undefined;
    IAMAuth?: IAMAuthMode | undefined;
    ClientPasswordAuthType?: ClientPasswordAuthType | undefined;
}
export type UserAuthConfigList = UserAuthConfig[];
export type EndpointNetworkType = "IPV4" | "IPV6" | "DUAL" | (string & {});
export type TargetConnectionNetworkType = "IPV4" | "IPV6" | (string & {});
export interface CreateDBProxyRequest {
    DBProxyName?: string | undefined;
    EngineFamily?: EngineFamily | undefined;
    DefaultAuthScheme?: DefaultAuthScheme | undefined;
    Auth?: UserAuthConfig[] | undefined;
    RoleArn?: string | undefined;
    VpcSubnetIds?: string[] | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    RequireTLS?: boolean | undefined;
    IdleClientTimeout?: number | undefined;
    DebugLogging?: boolean | undefined;
    Tags?: Tag[] | undefined;
    EndpointNetworkType?: EndpointNetworkType | undefined;
    TargetConnectionNetworkType?: TargetConnectionNetworkType | undefined;
}
export type DBProxyStatus = "available" | "modifying" | "incompatible-network" | "insufficient-resource-limits" | "creating" | "deleting" | "suspended" | "suspending" | "reactivating" | (string & {});
export interface UserAuthConfigInfo {
    Description?: string | undefined;
    UserName?: string | undefined;
    AuthScheme?: AuthScheme | undefined;
    SecretArn?: string | undefined;
    IAMAuth?: IAMAuthMode | undefined;
    ClientPasswordAuthType?: ClientPasswordAuthType | undefined;
}
export type UserAuthConfigInfoList = UserAuthConfigInfo[];
export interface DBProxy {
    DBProxyName?: string | undefined;
    DBProxyArn?: string | undefined;
    Status?: DBProxyStatus | undefined;
    EngineFamily?: string | undefined;
    VpcId?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    VpcSubnetIds?: string[] | undefined;
    DefaultAuthScheme?: string | undefined;
    Auth?: UserAuthConfigInfo[] | undefined;
    RoleArn?: string | undefined;
    Endpoint?: string | undefined;
    RequireTLS?: boolean | undefined;
    IdleClientTimeout?: number | undefined;
    DebugLogging?: boolean | undefined;
    CreatedDate?: Date | undefined;
    UpdatedDate?: Date | undefined;
    EndpointNetworkType?: EndpointNetworkType | undefined;
    TargetConnectionNetworkType?: TargetConnectionNetworkType | undefined;
}
export interface CreateDBProxyResponse {
    DBProxy?: DBProxy | undefined;
}
export type DBProxyEndpointName = string;
export type DBProxyEndpointTargetRole = "READ_WRITE" | "READ_ONLY" | (string & {});
export interface CreateDBProxyEndpointRequest {
    DBProxyName?: string | undefined;
    DBProxyEndpointName?: string | undefined;
    VpcSubnetIds?: string[] | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    TargetRole?: DBProxyEndpointTargetRole | undefined;
    Tags?: Tag[] | undefined;
    EndpointNetworkType?: EndpointNetworkType | undefined;
}
export type DBProxyEndpointStatus = "available" | "modifying" | "incompatible-network" | "insufficient-resource-limits" | "creating" | "deleting" | (string & {});
export interface DBProxyEndpoint {
    DBProxyEndpointName?: string | undefined;
    DBProxyEndpointArn?: string | undefined;
    DBProxyName?: string | undefined;
    Status?: DBProxyEndpointStatus | undefined;
    VpcId?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    VpcSubnetIds?: string[] | undefined;
    Endpoint?: string | undefined;
    CreatedDate?: Date | undefined;
    TargetRole?: DBProxyEndpointTargetRole | undefined;
    IsDefault?: boolean | undefined;
    EndpointNetworkType?: EndpointNetworkType | undefined;
}
export interface CreateDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint | undefined;
}
export interface CreateDBSecurityGroupMessage {
    DBSecurityGroupName?: string | undefined;
    DBSecurityGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBSecurityGroupResult {
    DBSecurityGroup?: DBSecurityGroup | undefined;
}
export interface CreateDBShardGroupMessage {
    DBShardGroupIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    ComputeRedundancy?: number | undefined;
    MaxACU?: number | undefined;
    MinACU?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type DBShardGroupIdentifier = string;
export interface DBShardGroup {
    DBShardGroupResourceId?: string | undefined;
    DBShardGroupIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    MaxACU?: number | undefined;
    MinACU?: number | undefined;
    ComputeRedundancy?: number | undefined;
    Status?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Endpoint?: string | undefined;
    DBShardGroupArn?: string | undefined;
    TagList?: Tag[] | undefined;
}
export interface CreateDBSnapshotMessage {
    DBSnapshotIdentifier?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBSnapshotResult {
    DBSnapshot?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export type SubnetIdentifierList = string[];
export interface CreateDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup | undefined;
}
export interface CreateEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SnsTopicArn?: string | undefined;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    SourceIds?: string[] | undefined;
    Enabled?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface CreateGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    SourceDBClusterIdentifier?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    DeletionProtection?: boolean | undefined;
    DatabaseName?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type ReadersArnList = string[];
export type GlobalClusterMemberSynchronizationStatus = "connected" | "pending-resync" | (string & {});
export interface GlobalClusterMember {
    DBClusterArn?: string | undefined;
    Readers?: string[] | undefined;
    IsWriter?: boolean | undefined;
    GlobalWriteForwardingStatus?: WriteForwardingStatus | undefined;
    SynchronizationStatus?: GlobalClusterMemberSynchronizationStatus | undefined;
}
export type GlobalClusterMemberList = GlobalClusterMember[];
export type FailoverStatus = "pending" | "failing-over" | "cancelling" | (string & {});
export interface FailoverState {
    Status?: FailoverStatus | undefined;
    FromDbClusterArn?: string | undefined;
    ToDbClusterArn?: string | undefined;
    IsDataLossAllowed?: boolean | undefined;
}
export interface GlobalCluster {
    GlobalClusterIdentifier?: string | undefined;
    GlobalClusterResourceId?: string | undefined;
    GlobalClusterArn?: string | undefined;
    Status?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    DatabaseName?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    DeletionProtection?: boolean | undefined;
    GlobalClusterMembers?: GlobalClusterMember[] | undefined;
    Endpoint?: string | undefined;
    FailoverState?: FailoverState | undefined;
    TagList?: Tag[] | undefined;
}
export interface CreateGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export type SourceArn = string;
export type IntegrationName = string;
export type EncryptionContextMap = {
    [key: string]: string | undefined;
};
export type DataFilter = string;
export type IntegrationDescription = string;
export interface CreateIntegrationMessage {
    SourceArn?: string | undefined;
    TargetArn?: string | undefined;
    IntegrationName?: string | undefined;
    KMSKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: Tag[] | undefined;
    DataFilter?: string | undefined;
    Description?: string | undefined;
}
export type IntegrationArn = string;
export type IntegrationStatus = "creating" | "active" | "modifying" | "failed" | "deleting" | "syncing" | "needs_attention" | (string & {});
export interface IntegrationError {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type IntegrationErrorList = IntegrationError[];
export interface Integration {
    SourceArn?: string | undefined;
    TargetArn?: string | undefined;
    IntegrationName?: string | undefined;
    IntegrationArn?: string | undefined;
    KMSKeyId?: string | undefined;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Status?: IntegrationStatus | undefined;
    Tags?: Tag[] | undefined;
    DataFilter?: string | undefined;
    Description?: string | undefined;
    CreateTime?: Date | undefined;
    Errors?: (IntegrationError & {
        ErrorCode: string;
    })[] | undefined;
}
export interface CreateOptionGroupMessage {
    OptionGroupName?: string | undefined;
    EngineName?: string | undefined;
    MajorEngineVersion?: string | undefined;
    OptionGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateOptionGroupResult {
    OptionGroup?: OptionGroup | undefined;
}
export interface CreateTenantDatabaseMessage {
    DBInstanceIdentifier?: string | undefined;
    TenantDBName?: string | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    CharacterSetName?: string | undefined;
    NcharCharacterSetName?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TenantDatabasePendingModifiedValues {
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    TenantDBName?: string | undefined;
}
export interface TenantDatabase {
    TenantDatabaseCreateTime?: Date | undefined;
    DBInstanceIdentifier?: string | undefined;
    TenantDBName?: string | undefined;
    Status?: string | undefined;
    MasterUsername?: string | undefined;
    DbiResourceId?: string | undefined;
    TenantDatabaseResourceId?: string | undefined;
    TenantDatabaseARN?: string | undefined;
    CharacterSetName?: string | undefined;
    NcharCharacterSetName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    PendingModifiedValues?: TenantDatabasePendingModifiedValues | undefined;
    MasterUserSecret?: MasterUserSecret | undefined;
    TagList?: Tag[] | undefined;
}
export interface CreateTenantDatabaseResult {
    TenantDatabase?: TenantDatabase | undefined;
}
export interface DeleteBlueGreenDeploymentRequest {
    BlueGreenDeploymentIdentifier?: string | undefined;
    DeleteTarget?: boolean | undefined;
}
export interface DeleteBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment | undefined;
}
export interface DeleteCustomDBEngineVersionMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
}
export interface DeleteDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    SkipFinalSnapshot?: boolean | undefined;
    FinalDBSnapshotIdentifier?: string | undefined;
    DeleteAutomatedBackups?: boolean | undefined;
}
export interface DeleteDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface DeleteDBClusterAutomatedBackupMessage {
    DbClusterResourceId?: string | undefined;
}
export interface RestoreWindow {
    EarliestTime?: Date | undefined;
    LatestTime?: Date | undefined;
}
export interface DBClusterAutomatedBackup {
    Engine?: string | undefined;
    VpcId?: string | undefined;
    DBClusterAutomatedBackupsArn?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    RestoreWindow?: RestoreWindow | undefined;
    MasterUsername?: string | undefined;
    DbClusterResourceId?: string | undefined;
    Region?: string | undefined;
    LicenseModel?: string | undefined;
    Status?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    ClusterCreateTime?: Date | undefined;
    StorageEncrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    AllocatedStorage?: number | undefined;
    EngineVersion?: string | undefined;
    DBClusterArn?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    EngineMode?: string | undefined;
    AvailabilityZones?: string[] | undefined;
    Port?: number | undefined;
    KmsKeyId?: string | undefined;
    StorageType?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    TagList?: Tag[] | undefined;
}
export interface DeleteDBClusterAutomatedBackupResult {
    DBClusterAutomatedBackup?: DBClusterAutomatedBackup | undefined;
}
export interface DeleteDBClusterEndpointMessage {
    DBClusterEndpointIdentifier?: string | undefined;
}
export interface DeleteDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
}
export interface DeleteDBClusterParameterGroupResponse {
}
export interface DeleteDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
}
export interface DeleteDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export interface DeleteDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    SkipFinalSnapshot?: boolean | undefined;
    FinalDBSnapshotIdentifier?: string | undefined;
    DeleteAutomatedBackups?: boolean | undefined;
}
export interface DeleteDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface DeleteDBInstanceAutomatedBackupMessage {
    DbiResourceId?: string | undefined;
    DBInstanceAutomatedBackupsArn?: string | undefined;
}
export interface DBInstanceAutomatedBackup {
    DBInstanceArn?: string | undefined;
    DbiResourceId?: string | undefined;
    Region?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    RestoreWindow?: RestoreWindow | undefined;
    AllocatedStorage?: number | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    VpcId?: string | undefined;
    InstanceCreateTime?: Date | undefined;
    MasterUsername?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    TdeCredentialArn?: string | undefined;
    Encrypted?: boolean | undefined;
    StorageEncryptionType?: StorageEncryptionType | undefined;
    StorageType?: string | undefined;
    KmsKeyId?: string | undefined;
    Timezone?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    DBInstanceAutomatedBackupsArn?: string | undefined;
    DBInstanceAutomatedBackupsReplications?: DBInstanceAutomatedBackupsReplication[] | undefined;
    BackupTarget?: string | undefined;
    MultiTenant?: boolean | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    TagList?: Tag[] | undefined;
    DedicatedLogVolume?: boolean | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
}
export interface DeleteDBInstanceAutomatedBackupResult {
    DBInstanceAutomatedBackup?: (DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export interface DeleteDBParameterGroupMessage {
    DBParameterGroupName?: string | undefined;
}
export interface DeleteDBParameterGroupResponse {
}
export interface DeleteDBProxyRequest {
    DBProxyName?: string | undefined;
}
export interface DeleteDBProxyResponse {
    DBProxy?: DBProxy | undefined;
}
export interface DeleteDBProxyEndpointRequest {
    DBProxyEndpointName?: string | undefined;
}
export interface DeleteDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint | undefined;
}
export interface DeleteDBSecurityGroupMessage {
    DBSecurityGroupName?: string | undefined;
}
export interface DeleteDBSecurityGroupResponse {
}
export interface DeleteDBShardGroupMessage {
    DBShardGroupIdentifier?: string | undefined;
}
export interface DeleteDBSnapshotMessage {
    DBSnapshotIdentifier?: string | undefined;
}
export interface DeleteDBSnapshotResult {
    DBSnapshot?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export interface DeleteDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
}
export interface DeleteDBSubnetGroupResponse {
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
}
export interface DeleteEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface DeleteGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
}
export interface DeleteGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export type IntegrationIdentifier = string;
export interface DeleteIntegrationMessage {
    IntegrationIdentifier?: string | undefined;
}
export interface DeleteOptionGroupMessage {
    OptionGroupName?: string | undefined;
}
export interface DeleteOptionGroupResponse {
}
export interface DeleteTenantDatabaseMessage {
    DBInstanceIdentifier?: string | undefined;
    TenantDBName?: string | undefined;
    SkipFinalSnapshot?: boolean | undefined;
    FinalDBSnapshotIdentifier?: string | undefined;
}
export interface DeleteTenantDatabaseResult {
    TenantDatabase?: TenantDatabase | undefined;
}
export type DBProxyTargetGroupName = string;
export interface DeregisterDBProxyTargetsRequest {
    DBProxyName?: string | undefined;
    TargetGroupName?: string | undefined;
    DBInstanceIdentifiers?: string[] | undefined;
    DBClusterIdentifiers?: string[] | undefined;
}
export interface DeregisterDBProxyTargetsResponse {
}
export interface DescribeAccountAttributesMessage {
}
export interface AccountQuota {
    AccountQuotaName?: string | undefined;
    Used?: number | undefined;
    Max?: number | undefined;
}
export type AccountQuotaList = AccountQuota[];
export interface AccountAttributesMessage {
    AccountQuotas?: AccountQuota[] | undefined;
}
export type FilterValueList = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export type MaxRecords = number;
export interface DescribeBlueGreenDeploymentsRequest {
    BlueGreenDeploymentIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type BlueGreenDeploymentList = BlueGreenDeployment[];
export interface DescribeBlueGreenDeploymentsResponse {
    BlueGreenDeployments?: BlueGreenDeployment[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeCertificatesMessage {
    CertificateIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Certificate {
    CertificateIdentifier?: string | undefined;
    CertificateType?: string | undefined;
    Thumbprint?: string | undefined;
    ValidFrom?: Date | undefined;
    ValidTill?: Date | undefined;
    CertificateArn?: string | undefined;
    CustomerOverride?: boolean | undefined;
    CustomerOverrideValidTill?: Date | undefined;
}
export type CertificateList = Certificate[];
export interface CertificateMessage {
    DefaultCertificateForNewLaunches?: string | undefined;
    Certificates?: Certificate[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBCapacityReservationsRequest {
    DBCapacityReservationIdentifier?: string | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    Filters?: Filter[] | undefined;
}
export type DBCapacityReservationList = DBCapacityReservation[];
export interface DescribeDBCapacityReservationsResponse {
    DBCapacityReservations?: DBCapacityReservation[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBClusterAutomatedBackupsMessage {
    DbClusterResourceId?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterAutomatedBackupList = DBClusterAutomatedBackup[];
export interface DBClusterAutomatedBackupMessage {
    Marker?: string | undefined;
    DBClusterAutomatedBackups?: DBClusterAutomatedBackup[] | undefined;
}
export interface DescribeDBClusterBacktracksMessage {
    DBClusterIdentifier?: string | undefined;
    BacktrackIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterBacktrackList = DBClusterBacktrack[];
export interface DBClusterBacktrackMessage {
    Marker?: string | undefined;
    DBClusterBacktracks?: DBClusterBacktrack[] | undefined;
}
export interface DescribeDBClusterEndpointsMessage {
    DBClusterIdentifier?: string | undefined;
    DBClusterEndpointIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterEndpointList = DBClusterEndpoint[];
export interface DBClusterEndpointMessage {
    Marker?: string | undefined;
    DBClusterEndpoints?: DBClusterEndpoint[] | undefined;
}
export interface DescribeDBClusterParameterGroupsMessage {
    DBClusterParameterGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterParameterGroupList = DBClusterParameterGroup[];
export interface DBClusterParameterGroupsMessage {
    Marker?: string | undefined;
    DBClusterParameterGroups?: DBClusterParameterGroup[] | undefined;
}
export interface DescribeDBClusterParametersMessage {
    DBClusterParameterGroupName?: string | undefined;
    Source?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type PotentiallySensitiveParameterValue = string;
export type ApplyMethod = "immediate" | "pending-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string | undefined;
    ParameterValue?: string | undefined;
    Description?: string | undefined;
    Source?: string | undefined;
    ApplyType?: string | undefined;
    DataType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    MinimumEngineVersion?: string | undefined;
    ApplyMethod?: ApplyMethod | undefined;
    SupportedEngineModes?: string[] | undefined;
}
export type ParametersList = Parameter[];
export interface DBClusterParameterGroupDetails {
    Parameters?: Parameter[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBClustersMessage {
    DBClusterIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    IncludeShared?: boolean | undefined;
}
export type DBClusterList = DBCluster[];
export interface DBClusterMessage {
    Marker?: string | undefined;
    DBClusters?: DBCluster[] | undefined;
}
export interface DescribeDBClusterSnapshotAttributesMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
}
export type AttributeValueList = string[];
export interface DBClusterSnapshotAttribute {
    AttributeName?: string | undefined;
    AttributeValues?: string[] | undefined;
}
export type DBClusterSnapshotAttributeList = DBClusterSnapshotAttribute[];
export interface DBClusterSnapshotAttributesResult {
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterSnapshotAttributes?: DBClusterSnapshotAttribute[] | undefined;
}
export interface DescribeDBClusterSnapshotAttributesResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult | undefined;
}
export interface DescribeDBClusterSnapshotsMessage {
    DBClusterIdentifier?: string | undefined;
    DBClusterSnapshotIdentifier?: string | undefined;
    SnapshotType?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    IncludeShared?: boolean | undefined;
    IncludePublic?: boolean | undefined;
    DbClusterResourceId?: string | undefined;
}
export type DBClusterSnapshotList = DBClusterSnapshot[];
export interface DBClusterSnapshotMessage {
    Marker?: string | undefined;
    DBClusterSnapshots?: DBClusterSnapshot[] | undefined;
}
export interface DescribeDBEngineVersionsMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    DefaultOnly?: boolean | undefined;
    ListSupportedCharacterSets?: boolean | undefined;
    ListSupportedTimezones?: boolean | undefined;
    IncludeAll?: boolean | undefined;
}
export type DBEngineVersionList = DBEngineVersion[];
export interface DBEngineVersionMessage {
    Marker?: string | undefined;
    DBEngineVersions?: DBEngineVersion[] | undefined;
}
export interface DescribeDBInstanceAutomatedBackupsMessage {
    DbiResourceId?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    DBInstanceAutomatedBackupsArn?: string | undefined;
}
export type DBInstanceAutomatedBackupList = DBInstanceAutomatedBackup[];
export interface DBInstanceAutomatedBackupMessage {
    Marker?: string | undefined;
    DBInstanceAutomatedBackups?: (DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    })[] | undefined;
}
export interface DescribeDBInstancesMessage {
    DBInstanceIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBInstanceList = DBInstance[];
export interface DBInstanceMessage {
    Marker?: string | undefined;
    DBInstances?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    })[] | undefined;
}
export interface DescribeDBLogFilesMessage {
    DBInstanceIdentifier?: string | undefined;
    FilenameContains?: string | undefined;
    FileLastWritten?: number | undefined;
    FileSize?: number | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBLogFilesDetails {
    LogFileName?: string | undefined;
    LastWritten?: number | undefined;
    Size?: number | undefined;
}
export type DescribeDBLogFilesList = DescribeDBLogFilesDetails[];
export interface DescribeDBLogFilesResponse {
    DescribeDBLogFiles?: DescribeDBLogFilesDetails[] | undefined;
    Marker?: string | undefined;
}
export type Engine = string;
export type MajorEngineVersion = string;
export type Marker = string;
export interface DescribeDBMajorEngineVersionsRequest {
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type LifecycleSupportName = "open-source-rds-standard-support" | "open-source-rds-extended-support" | (string & {});
export interface SupportedEngineLifecycle {
    LifecycleSupportName?: LifecycleSupportName | undefined;
    LifecycleSupportStartDate?: Date | undefined;
    LifecycleSupportEndDate?: Date | undefined;
}
export type SupportedEngineLifecycleList = SupportedEngineLifecycle[];
export interface DBMajorEngineVersion {
    Engine?: string | undefined;
    MajorEngineVersion?: string | undefined;
    SupportedEngineLifecycles?: SupportedEngineLifecycle[] | undefined;
}
export type DBMajorEngineVersionsList = DBMajorEngineVersion[];
export interface DescribeDBMajorEngineVersionsResponse {
    DBMajorEngineVersions?: (DBMajorEngineVersion & {
        SupportedEngineLifecycles: (SupportedEngineLifecycle & {
            LifecycleSupportName: LifecycleSupportName;
            LifecycleSupportStartDate: Date;
            LifecycleSupportEndDate: Date;
        })[];
    })[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBParameterGroupsMessage {
    DBParameterGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBParameterGroupList = DBParameterGroup[];
export interface DBParameterGroupsMessage {
    Marker?: string | undefined;
    DBParameterGroups?: DBParameterGroup[] | undefined;
}
export interface DescribeDBParametersMessage {
    DBParameterGroupName?: string | undefined;
    Source?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface DBParameterGroupDetails {
    Parameters?: Parameter[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBProxiesRequest {
    DBProxyName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type DBProxyList = DBProxy[];
export interface DescribeDBProxiesResponse {
    DBProxies?: DBProxy[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBProxyEndpointsRequest {
    DBProxyName?: string | undefined;
    DBProxyEndpointName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type DBProxyEndpointList = DBProxyEndpoint[];
export interface DescribeDBProxyEndpointsResponse {
    DBProxyEndpoints?: DBProxyEndpoint[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBProxyTargetGroupsRequest {
    DBProxyName?: string | undefined;
    TargetGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type OperatorSensitiveString = string | redacted.Redacted<string>;
export interface ConnectionPoolConfigurationInfo {
    MaxConnectionsPercent?: number | undefined;
    MaxIdleConnectionsPercent?: number | undefined;
    ConnectionBorrowTimeout?: number | undefined;
    SessionPinningFilters?: string[] | undefined;
    InitQuery?: string | redacted.Redacted<string> | undefined;
}
export interface DBProxyTargetGroup {
    DBProxyName?: string | undefined;
    TargetGroupName?: string | undefined;
    TargetGroupArn?: string | undefined;
    IsDefault?: boolean | undefined;
    Status?: string | undefined;
    ConnectionPoolConfig?: ConnectionPoolConfigurationInfo | undefined;
    CreatedDate?: Date | undefined;
    UpdatedDate?: Date | undefined;
}
export type TargetGroupList = DBProxyTargetGroup[];
export interface DescribeDBProxyTargetGroupsResponse {
    TargetGroups?: DBProxyTargetGroup[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBProxyTargetsRequest {
    DBProxyName?: string | undefined;
    TargetGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type TargetType = "RDS_INSTANCE" | "RDS_SERVERLESS_ENDPOINT" | "TRACKED_CLUSTER" | (string & {});
export type TargetRole = "READ_WRITE" | "READ_ONLY" | "UNKNOWN" | (string & {});
export type TargetState = "REGISTERING" | "AVAILABLE" | "UNAVAILABLE" | "UNUSED" | (string & {});
export type TargetHealthReason = "UNREACHABLE" | "CONNECTION_FAILED" | "AUTH_FAILURE" | "PENDING_PROXY_CAPACITY" | "INVALID_REPLICATION_STATE" | "PROMOTED" | (string & {});
export interface TargetHealth {
    State?: TargetState | undefined;
    Reason?: TargetHealthReason | undefined;
    Description?: string | undefined;
}
export interface DBProxyTarget {
    TargetArn?: string | undefined;
    Endpoint?: string | undefined;
    TrackedClusterId?: string | undefined;
    RdsResourceId?: string | undefined;
    Port?: number | undefined;
    Type?: TargetType | undefined;
    Role?: TargetRole | undefined;
    TargetHealth?: TargetHealth | undefined;
}
export type TargetList = DBProxyTarget[];
export interface DescribeDBProxyTargetsResponse {
    Targets?: DBProxyTarget[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBRecommendationsMessage {
    LastUpdatedAfter?: Date | undefined;
    LastUpdatedBefore?: Date | undefined;
    Locale?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface RecommendedActionParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type RecommendedActionParameterList = RecommendedActionParameter[];
export interface ScalarReferenceDetails {
    Value?: number | undefined;
}
export interface ReferenceDetails {
    ScalarReferenceDetails?: ScalarReferenceDetails | undefined;
}
export interface MetricReference {
    Name?: string | undefined;
    ReferenceDetails?: ReferenceDetails | undefined;
}
export type MetricReferenceList = MetricReference[];
export interface PerformanceInsightsMetricDimensionGroup {
    Dimensions?: string[] | undefined;
    Group?: string | undefined;
    Limit?: number | undefined;
}
export interface PerformanceInsightsMetricQuery {
    GroupBy?: PerformanceInsightsMetricDimensionGroup | undefined;
    Metric?: string | undefined;
}
export interface MetricQuery {
    PerformanceInsightsMetricQuery?: PerformanceInsightsMetricQuery | undefined;
}
export interface Metric {
    Name?: string | undefined;
    References?: MetricReference[] | undefined;
    StatisticsDetails?: string | undefined;
    MetricQuery?: MetricQuery | undefined;
}
export type MetricList = Metric[];
export interface PerformanceIssueDetails {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Metrics?: Metric[] | undefined;
    Analysis?: string | undefined;
}
export interface IssueDetails {
    PerformanceIssueDetails?: PerformanceIssueDetails | undefined;
}
export interface ContextAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ContextAttributeList = ContextAttribute[];
export interface RecommendedAction {
    ActionId?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    Operation?: string | undefined;
    Parameters?: RecommendedActionParameter[] | undefined;
    ApplyModes?: string[] | undefined;
    Status?: string | undefined;
    IssueDetails?: IssueDetails | undefined;
    ContextAttributes?: ContextAttribute[] | undefined;
}
export type RecommendedActionList = RecommendedAction[];
export interface DocLink {
    Text?: string | undefined;
    Url?: string | undefined;
}
export type DocLinkList = DocLink[];
export interface DBRecommendation {
    RecommendationId?: string | undefined;
    TypeId?: string | undefined;
    Severity?: string | undefined;
    ResourceArn?: string | undefined;
    Status?: string | undefined;
    CreatedTime?: Date | undefined;
    UpdatedTime?: Date | undefined;
    Detection?: string | undefined;
    Recommendation?: string | undefined;
    Description?: string | undefined;
    Reason?: string | undefined;
    RecommendedActions?: RecommendedAction[] | undefined;
    Category?: string | undefined;
    Source?: string | undefined;
    TypeDetection?: string | undefined;
    TypeRecommendation?: string | undefined;
    Impact?: string | undefined;
    AdditionalInfo?: string | undefined;
    Links?: DocLink[] | undefined;
    IssueDetails?: IssueDetails | undefined;
}
export type DBRecommendationList = DBRecommendation[];
export interface DBRecommendationsMessage {
    DBRecommendations?: DBRecommendation[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBSecurityGroupsMessage {
    DBSecurityGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBSecurityGroups = DBSecurityGroup[];
export interface DBSecurityGroupMessage {
    Marker?: string | undefined;
    DBSecurityGroups?: DBSecurityGroup[] | undefined;
}
export interface DescribeDBShardGroupsMessage {
    DBShardGroupIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type DBShardGroupsList = DBShardGroup[];
export interface DescribeDBShardGroupsResponse {
    DBShardGroups?: DBShardGroup[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBSnapshotAttributesMessage {
    DBSnapshotIdentifier?: string | undefined;
}
export interface DBSnapshotAttribute {
    AttributeName?: string | undefined;
    AttributeValues?: string[] | undefined;
}
export type DBSnapshotAttributeList = DBSnapshotAttribute[];
export interface DBSnapshotAttributesResult {
    DBSnapshotIdentifier?: string | undefined;
    DBSnapshotAttributes?: DBSnapshotAttribute[] | undefined;
}
export interface DescribeDBSnapshotAttributesResult {
    DBSnapshotAttributesResult?: DBSnapshotAttributesResult | undefined;
}
export interface DescribeDBSnapshotsMessage {
    DBInstanceIdentifier?: string | undefined;
    DBSnapshotIdentifier?: string | undefined;
    SnapshotType?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    IncludeShared?: boolean | undefined;
    IncludePublic?: boolean | undefined;
    DbiResourceId?: string | undefined;
}
export type DBSnapshotList = DBSnapshot[];
export interface DBSnapshotMessage {
    Marker?: string | undefined;
    DBSnapshots?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    })[] | undefined;
}
export interface DescribeDBSnapshotTenantDatabasesMessage {
    DBInstanceIdentifier?: string | undefined;
    DBSnapshotIdentifier?: string | undefined;
    SnapshotType?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    DbiResourceId?: string | undefined;
}
export interface DBSnapshotTenantDatabase {
    DBSnapshotIdentifier?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    DbiResourceId?: string | undefined;
    EngineName?: string | undefined;
    SnapshotType?: string | undefined;
    TenantDatabaseCreateTime?: Date | undefined;
    TenantDBName?: string | undefined;
    MasterUsername?: string | undefined;
    TenantDatabaseResourceId?: string | undefined;
    CharacterSetName?: string | undefined;
    DBSnapshotTenantDatabaseARN?: string | undefined;
    NcharCharacterSetName?: string | undefined;
    TagList?: Tag[] | undefined;
}
export type DBSnapshotTenantDatabasesList = DBSnapshotTenantDatabase[];
export interface DBSnapshotTenantDatabasesMessage {
    Marker?: string | undefined;
    DBSnapshotTenantDatabases?: DBSnapshotTenantDatabase[] | undefined;
}
export interface DescribeDBSubnetGroupsMessage {
    DBSubnetGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBSubnetGroups = DBSubnetGroup[];
export interface DBSubnetGroupMessage {
    Marker?: string | undefined;
    DBSubnetGroups?: DBSubnetGroup[] | undefined;
}
export interface DescribeEngineDefaultClusterParametersMessage {
    DBParameterGroupFamily?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface EngineDefaults {
    DBParameterGroupFamily?: string | undefined;
    Marker?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface DescribeEngineDefaultClusterParametersResult {
    EngineDefaults?: EngineDefaults | undefined;
}
export interface DescribeEngineDefaultParametersMessage {
    DBParameterGroupFamily?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface DescribeEngineDefaultParametersResult {
    EngineDefaults?: EngineDefaults | undefined;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface EventCategoriesMap {
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
}
export type EventCategoriesMapList = EventCategoriesMap[];
export interface EventCategoriesMessage {
    EventCategoriesMapList?: EventCategoriesMap[] | undefined;
}
export type SourceType = "db-instance" | "db-parameter-group" | "db-security-group" | "db-snapshot" | "db-cluster" | "db-cluster-snapshot" | "custom-engine-version" | "db-proxy" | "blue-green-deployment" | "db-shard-group" | "zero-etl" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Duration?: number | undefined;
    EventCategories?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Event {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    Message?: string | undefined;
    EventCategories?: string[] | undefined;
    Date?: Date | undefined;
    SourceArn?: string | undefined;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string | undefined;
    Events?: Event[] | undefined;
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type EventSubscriptionsList = EventSubscription[];
export interface EventSubscriptionsMessage {
    Marker?: string | undefined;
    EventSubscriptionsList?: EventSubscription[] | undefined;
}
export interface DescribeExportTasksMessage {
    ExportTaskIdentifier?: string | undefined;
    SourceArn?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    SourceType?: ExportSourceType | undefined;
}
export type ExportTasksList = ExportTask[];
export interface ExportTasksMessage {
    Marker?: string | undefined;
    ExportTasks?: ExportTask[] | undefined;
}
export interface DescribeGlobalClustersMessage {
    GlobalClusterIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type GlobalClusterList = GlobalCluster[];
export interface GlobalClustersMessage {
    Marker?: string | undefined;
    GlobalClusters?: GlobalCluster[] | undefined;
}
export interface DescribeIntegrationsMessage {
    IntegrationIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type IntegrationList = Integration[];
export interface DescribeIntegrationsResponse {
    Marker?: string | undefined;
    Integrations?: (Integration & {
        Errors: (IntegrationError & {
            ErrorCode: string;
        })[];
    })[] | undefined;
}
export interface DescribeOptionGroupOptionsMessage {
    EngineName?: string | undefined;
    MajorEngineVersion?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type OptionsDependedOn = string[];
export type OptionsConflictsWith = string[];
export interface MinimumEngineVersionPerAllowedValue {
    AllowedValue?: string | undefined;
    MinimumEngineVersion?: string | undefined;
}
export type MinimumEngineVersionPerAllowedValueList = MinimumEngineVersionPerAllowedValue[];
export interface OptionGroupOptionSetting {
    SettingName?: string | undefined;
    SettingDescription?: string | undefined;
    DefaultValue?: string | undefined;
    ApplyType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    IsRequired?: boolean | undefined;
    MinimumEngineVersionPerAllowedValue?: MinimumEngineVersionPerAllowedValue[] | undefined;
}
export type OptionGroupOptionSettingsList = OptionGroupOptionSetting[];
export interface OptionVersion {
    Version?: string | undefined;
    IsDefault?: boolean | undefined;
}
export type OptionGroupOptionVersionsList = OptionVersion[];
export interface OptionGroupOption {
    Name?: string | undefined;
    Description?: string | undefined;
    EngineName?: string | undefined;
    MajorEngineVersion?: string | undefined;
    MinimumRequiredMinorEngineVersion?: string | undefined;
    PortRequired?: boolean | undefined;
    DefaultPort?: number | undefined;
    OptionsDependedOn?: string[] | undefined;
    OptionsConflictsWith?: string[] | undefined;
    Persistent?: boolean | undefined;
    Permanent?: boolean | undefined;
    RequiresAutoMinorEngineVersionUpgrade?: boolean | undefined;
    VpcOnly?: boolean | undefined;
    SupportsOptionVersionDowngrade?: boolean | undefined;
    OptionGroupOptionSettings?: OptionGroupOptionSetting[] | undefined;
    OptionGroupOptionVersions?: OptionVersion[] | undefined;
    CopyableCrossAccount?: boolean | undefined;
    CopyableCrossRegion?: boolean | undefined;
}
export type OptionGroupOptionsList = OptionGroupOption[];
export interface OptionGroupOptionsMessage {
    OptionGroupOptions?: OptionGroupOption[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeOptionGroupsMessage {
    OptionGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    EngineName?: string | undefined;
    MajorEngineVersion?: string | undefined;
}
export type OptionGroupsList = OptionGroup[];
export interface OptionGroups {
    OptionGroupsList?: OptionGroup[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeOrderableDBInstanceOptionsMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBInstanceClass?: string | undefined;
    LicenseModel?: string | undefined;
    AvailabilityZoneGroup?: string | undefined;
    Vpc?: boolean | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface AvailableProcessorFeature {
    Name?: string | undefined;
    DefaultValue?: string | undefined;
    AllowedValues?: string | undefined;
}
export type AvailableProcessorFeatureList = AvailableProcessorFeature[];
export type ActivityStreamModeList = string[];
export interface AvailableAdditionalStorageVolumesOption {
    SupportsStorageAutoscaling?: boolean | undefined;
    SupportsStorageThroughput?: boolean | undefined;
    SupportsIops?: boolean | undefined;
    StorageType?: string | undefined;
    MinStorageSize?: number | undefined;
    MaxStorageSize?: number | undefined;
    MinIops?: number | undefined;
    MaxIops?: number | undefined;
    MinIopsPerGib?: number | undefined;
    MaxIopsPerGib?: number | undefined;
    MinStorageThroughput?: number | undefined;
    MaxStorageThroughput?: number | undefined;
}
export type AvailableAdditionalStorageVolumesOptionList = AvailableAdditionalStorageVolumesOption[];
export interface OrderableDBInstanceOption {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBInstanceClass?: string | undefined;
    LicenseModel?: string | undefined;
    AvailabilityZoneGroup?: string | undefined;
    AvailabilityZones?: AvailabilityZone[] | undefined;
    MultiAZCapable?: boolean | undefined;
    ReadReplicaCapable?: boolean | undefined;
    Vpc?: boolean | undefined;
    SupportsStorageEncryption?: boolean | undefined;
    StorageType?: string | undefined;
    SupportsIops?: boolean | undefined;
    SupportsStorageThroughput?: boolean | undefined;
    SupportsEnhancedMonitoring?: boolean | undefined;
    SupportsIAMDatabaseAuthentication?: boolean | undefined;
    SupportsPerformanceInsights?: boolean | undefined;
    MinStorageSize?: number | undefined;
    MaxStorageSize?: number | undefined;
    MinIopsPerDbInstance?: number | undefined;
    MaxIopsPerDbInstance?: number | undefined;
    MinIopsPerGib?: number | undefined;
    MaxIopsPerGib?: number | undefined;
    MinStorageThroughputPerDbInstance?: number | undefined;
    MaxStorageThroughputPerDbInstance?: number | undefined;
    MinStorageThroughputPerIops?: number | undefined;
    MaxStorageThroughputPerIops?: number | undefined;
    AvailableProcessorFeatures?: AvailableProcessorFeature[] | undefined;
    SupportedEngineModes?: string[] | undefined;
    SupportsStorageAutoscaling?: boolean | undefined;
    SupportsKerberosAuthentication?: boolean | undefined;
    OutpostCapable?: boolean | undefined;
    SupportedActivityStreamModes?: string[] | undefined;
    SupportsGlobalDatabases?: boolean | undefined;
    SupportedNetworkTypes?: string[] | undefined;
    SupportsClusters?: boolean | undefined;
    SupportsDedicatedLogVolume?: boolean | undefined;
    SupportsAdditionalStorageVolumes?: boolean | undefined;
    SupportsHttpEndpoint?: boolean | undefined;
    AvailableAdditionalStorageVolumesOptions?: AvailableAdditionalStorageVolumesOption[] | undefined;
}
export type OrderableDBInstanceOptionsList = OrderableDBInstanceOption[];
export interface OrderableDBInstanceOptionsMessage {
    OrderableDBInstanceOptions?: OrderableDBInstanceOption[] | undefined;
    Marker?: string | undefined;
}
export interface DescribePendingMaintenanceActionsMessage {
    ResourceIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export interface PendingMaintenanceActionsMessage {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeReservedDBInstancesMessage {
    ReservedDBInstanceId?: string | undefined;
    ReservedDBInstancesOfferingId?: string | undefined;
    DBInstanceClass?: string | undefined;
    Duration?: string | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MultiAZ?: boolean | undefined;
    LeaseId?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface RecurringCharge {
    RecurringChargeAmount?: number | undefined;
    RecurringChargeFrequency?: string | undefined;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedDBInstance {
    ReservedDBInstanceId?: string | undefined;
    ReservedDBInstancesOfferingId?: string | undefined;
    DBInstanceClass?: string | undefined;
    StartTime?: Date | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    DBInstanceCount?: number | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MultiAZ?: boolean | undefined;
    State?: string | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
    ReservedDBInstanceArn?: string | undefined;
    LeaseId?: string | undefined;
}
export type ReservedDBInstanceList = ReservedDBInstance[];
export interface ReservedDBInstanceMessage {
    Marker?: string | undefined;
    ReservedDBInstances?: ReservedDBInstance[] | undefined;
}
export interface DescribeReservedDBInstancesOfferingsMessage {
    ReservedDBInstancesOfferingId?: string | undefined;
    DBInstanceClass?: string | undefined;
    Duration?: string | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MultiAZ?: boolean | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ReservedDBInstancesOffering {
    ReservedDBInstancesOfferingId?: string | undefined;
    DBInstanceClass?: string | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    ProductDescription?: string | undefined;
    OfferingType?: string | undefined;
    MultiAZ?: boolean | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedDBInstancesOfferingList = ReservedDBInstancesOffering[];
export interface ReservedDBInstancesOfferingMessage {
    Marker?: string | undefined;
    ReservedDBInstancesOfferings?: ReservedDBInstancesOffering[] | undefined;
}
export interface DescribeServerlessV2PlatformVersionsMessage {
    ServerlessV2PlatformVersion?: string | undefined;
    Engine?: string | undefined;
    Filters?: Filter[] | undefined;
    DefaultOnly?: boolean | undefined;
    IncludeAll?: boolean | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ServerlessV2PlatformVersionInfo {
    ServerlessV2PlatformVersion?: string | undefined;
    ServerlessV2PlatformVersionDescription?: string | undefined;
    Engine?: string | undefined;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport | undefined;
    Status?: string | undefined;
    IsDefault?: boolean | undefined;
}
export type ServerlessV2PlatformVersionList = ServerlessV2PlatformVersionInfo[];
export interface ServerlessV2PlatformVersionsMessage {
    Marker?: string | undefined;
    ServerlessV2PlatformVersions?: ServerlessV2PlatformVersionInfo[] | undefined;
}
export interface DescribeSourceRegionsMessage {
    RegionName?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface SourceRegion {
    RegionName?: string | undefined;
    Endpoint?: string | undefined;
    Status?: string | undefined;
    SupportsDBInstanceAutomatedBackupsReplication?: boolean | undefined;
}
export type SourceRegionList = SourceRegion[];
export interface SourceRegionMessage {
    Marker?: string | undefined;
    SourceRegions?: SourceRegion[] | undefined;
}
export interface DescribeTenantDatabasesMessage {
    DBInstanceIdentifier?: string | undefined;
    TenantDBName?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type TenantDatabasesList = TenantDatabase[];
export interface TenantDatabasesMessage {
    Marker?: string | undefined;
    TenantDatabases?: TenantDatabase[] | undefined;
}
export interface DescribeValidDBInstanceModificationsMessage {
    DBInstanceIdentifier?: string | undefined;
}
export interface Range {
    From?: number | undefined;
    To?: number | undefined;
    Step?: number | undefined;
}
export type RangeList = Range[];
export interface DoubleRange {
    From?: number | undefined;
    To?: number | undefined;
}
export type DoubleRangeList = DoubleRange[];
export interface ValidStorageOptions {
    StorageType?: string | undefined;
    StorageSize?: Range[] | undefined;
    ProvisionedIops?: Range[] | undefined;
    IopsToStorageRatio?: DoubleRange[] | undefined;
    ProvisionedStorageThroughput?: Range[] | undefined;
    StorageThroughputToIopsRatio?: DoubleRange[] | undefined;
    SupportsStorageAutoscaling?: boolean | undefined;
}
export type ValidStorageOptionsList = ValidStorageOptions[];
export interface ValidVolumeOptions {
    VolumeName?: string | undefined;
    Storage?: ValidStorageOptions[] | undefined;
}
export type ValidVolumeOptionsList = ValidVolumeOptions[];
export interface ValidAdditionalStorageOptions {
    SupportsAdditionalStorageVolumes?: boolean | undefined;
    Volumes?: ValidVolumeOptions[] | undefined;
}
export interface ValidDBInstanceModificationsMessage {
    Storage?: ValidStorageOptions[] | undefined;
    ValidProcessorFeatures?: AvailableProcessorFeature[] | undefined;
    SupportsDedicatedLogVolume?: boolean | undefined;
    AdditionalStorage?: ValidAdditionalStorageOptions | undefined;
}
export interface DescribeValidDBInstanceModificationsResult {
    ValidDBInstanceModificationsMessage?: ValidDBInstanceModificationsMessage | undefined;
}
export interface DisableHttpEndpointRequest {
    ResourceArn?: string | undefined;
}
export interface DisableHttpEndpointResponse {
    ResourceArn?: string | undefined;
    HttpEndpointEnabled?: boolean | undefined;
}
export interface DownloadDBLogFilePortionMessage {
    DBInstanceIdentifier?: string | undefined;
    LogFileName?: string | undefined;
    Marker?: string | undefined;
    NumberOfLines?: number | undefined;
}
export interface DownloadDBLogFilePortionDetails {
    LogFileData?: string | redacted.Redacted<string> | undefined;
    Marker?: string | undefined;
    AdditionalDataPending?: boolean | undefined;
}
export interface EnableHttpEndpointRequest {
    ResourceArn?: string | undefined;
}
export interface EnableHttpEndpointResponse {
    ResourceArn?: string | undefined;
    HttpEndpointEnabled?: boolean | undefined;
}
export interface FailoverDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    TargetDBInstanceIdentifier?: string | undefined;
}
export interface FailoverDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export type DBClusterIdentifier = string;
export interface FailoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    TargetDbClusterIdentifier?: string | undefined;
    AllowDataLoss?: boolean | undefined;
    Switchover?: boolean | undefined;
}
export interface FailoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface ListTagsForResourceMessage {
    ResourceName?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface TagListMessage {
    TagList?: Tag[] | undefined;
}
export type AuditPolicyState = "locked" | "unlocked" | (string & {});
export interface ModifyActivityStreamRequest {
    ResourceArn?: string | undefined;
    AuditPolicyState?: AuditPolicyState | undefined;
}
export interface ModifyActivityStreamResponse {
    KmsKeyId?: string | undefined;
    KinesisStreamName?: string | undefined;
    Status?: ActivityStreamStatus | undefined;
    Mode?: ActivityStreamMode | undefined;
    EngineNativeAuditFieldsIncluded?: boolean | undefined;
    PolicyStatus?: ActivityStreamPolicyStatus | undefined;
}
export interface ModifyCertificatesMessage {
    CertificateIdentifier?: string | undefined;
    RemoveCustomerOverride?: boolean | undefined;
}
export interface ModifyCertificatesResult {
    Certificate?: Certificate | undefined;
}
export interface ModifyCurrentDBClusterCapacityMessage {
    DBClusterIdentifier?: string | undefined;
    Capacity?: number | undefined;
    SecondsBeforeTimeout?: number | undefined;
    TimeoutAction?: string | undefined;
}
export interface DBClusterCapacityInfo {
    DBClusterIdentifier?: string | undefined;
    PendingCapacity?: number | undefined;
    CurrentCapacity?: number | undefined;
    SecondsBeforeTimeout?: number | undefined;
    TimeoutAction?: string | undefined;
}
export type CustomEngineVersionStatus = "available" | "inactive" | "inactive-except-restore" | (string & {});
export interface ModifyCustomDBEngineVersionMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Description?: string | undefined;
    Status?: CustomEngineVersionStatus | undefined;
}
export type EndDateType = "unlimited" | "limited" | (string & {});
export interface ModifyDBCapacityReservationRequest {
    DBCapacityReservationIdentifier?: string | undefined;
    CapacityPerAvailabilityZone?: number | undefined;
    EndDateType?: EndDateType | undefined;
    EndDate?: Date | undefined;
}
export interface ModifyDBCapacityReservationResponse {
    DBCapacityReservation?: DBCapacityReservation | undefined;
}
export interface CloudwatchLogsExportConfiguration {
    EnableLogTypes?: string[] | undefined;
    DisableLogTypes?: string[] | undefined;
}
export type AwsBackupRecoveryPointArn = string;
export interface ModifyDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    NewDBClusterIdentifier?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    BackupRetentionPeriod?: number | undefined;
    DBClusterParameterGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Port?: number | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    OptionGroupName?: string | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    BacktrackWindow?: number | undefined;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration | undefined;
    EngineVersion?: string | undefined;
    AllowMajorVersionUpgrade?: boolean | undefined;
    DBInstanceParameterGroupName?: string | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    ScalingConfiguration?: ScalingConfiguration | undefined;
    DeletionProtection?: boolean | undefined;
    EnableHttpEndpoint?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    EnableGlobalWriteForwarding?: boolean | undefined;
    DBClusterInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    StorageType?: string | undefined;
    Iops?: number | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    NetworkType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    RotateMasterUserPassword?: boolean | undefined;
    EnableLocalWriteForwarding?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    EngineMode?: string | undefined;
    AllowEngineModeChange?: boolean | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    EnableLimitlessDatabase?: boolean | undefined;
    CACertificateIdentifier?: string | undefined;
    MasterUserAuthenticationType?: MasterUserAuthenticationType | undefined;
    EngineLifecycleSupport?: string | undefined;
}
export interface ModifyDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface ModifyDBClusterEndpointMessage {
    DBClusterEndpointIdentifier?: string | undefined;
    EndpointType?: string | undefined;
    StaticMembers?: string[] | undefined;
    ExcludedMembers?: string[] | undefined;
}
export interface ModifyDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface DBClusterParameterGroupNameMessage {
    DBClusterParameterGroupName?: string | undefined;
}
export interface ModifyDBClusterSnapshotAttributeMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
    AttributeName?: string | undefined;
    ValuesToAdd?: string[] | undefined;
    ValuesToRemove?: string[] | undefined;
}
export interface ModifyDBClusterSnapshotAttributeResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult | undefined;
}
export interface ModifyAdditionalStorageVolume {
    VolumeName?: string | undefined;
    AllocatedStorage?: number | undefined;
    IOPS?: number | undefined;
    MaxAllocatedStorage?: number | undefined;
    StorageThroughput?: number | undefined;
    StorageType?: string | undefined;
    SetForDelete?: boolean | undefined;
}
export type ModifyAdditionalStorageVolumesList = ModifyAdditionalStorageVolume[];
export interface ModifyDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    AllocatedStorage?: number | undefined;
    DBInstanceClass?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    DBSecurityGroups?: string[] | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    ApplyImmediately?: boolean | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    DBParameterGroupName?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AllowMajorVersionUpgrade?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    NewDBInstanceIdentifier?: string | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    TdeCredentialPassword?: string | redacted.Redacted<string> | undefined;
    CACertificateIdentifier?: string | undefined;
    Domain?: string | undefined;
    DomainFqdn?: string | undefined;
    DomainOu?: string | undefined;
    DomainAuthSecretArn?: string | undefined;
    DomainDnsIps?: string[] | undefined;
    DisableDomain?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    DBPortNumber?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
    MonitoringRoleArn?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    PromotionTier?: number | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    UseDefaultProcessorFeatures?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    MaxAllocatedStorage?: number | undefined;
    CertificateRotationRestart?: boolean | undefined;
    ReplicaMode?: ReplicaMode | undefined;
    AutomationMode?: AutomationMode | undefined;
    ResumeFullAutomationModeMinutes?: number | undefined;
    EnableCustomerOwnedIp?: boolean | undefined;
    NetworkType?: string | undefined;
    AwsBackupRecoveryPointArn?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    RotateMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    MultiTenant?: boolean | undefined;
    DedicatedLogVolume?: boolean | undefined;
    Engine?: string | undefined;
    AdditionalStorageVolumes?: ModifyAdditionalStorageVolume[] | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    MasterUserAuthenticationType?: MasterUserAuthenticationType | undefined;
    EngineLifecycleSupport?: string | undefined;
}
export interface ModifyDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface ModifyDBParameterGroupMessage {
    DBParameterGroupName?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface DBParameterGroupNameMessage {
    DBParameterGroupName?: string | undefined;
}
export interface ModifyDBProxyRequest {
    DBProxyName?: string | undefined;
    NewDBProxyName?: string | undefined;
    DefaultAuthScheme?: DefaultAuthScheme | undefined;
    Auth?: UserAuthConfig[] | undefined;
    RequireTLS?: boolean | undefined;
    IdleClientTimeout?: number | undefined;
    DebugLogging?: boolean | undefined;
    RoleArn?: string | undefined;
    SecurityGroups?: string[] | undefined;
}
export interface ModifyDBProxyResponse {
    DBProxy?: DBProxy | undefined;
}
export interface ModifyDBProxyEndpointRequest {
    DBProxyEndpointName?: string | undefined;
    NewDBProxyEndpointName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
}
export interface ModifyDBProxyEndpointResponse {
    DBProxyEndpoint?: DBProxyEndpoint | undefined;
}
export interface ConnectionPoolConfiguration {
    MaxConnectionsPercent?: number | undefined;
    MaxIdleConnectionsPercent?: number | undefined;
    ConnectionBorrowTimeout?: number | undefined;
    SessionPinningFilters?: string[] | undefined;
    InitQuery?: string | redacted.Redacted<string> | undefined;
}
export interface ModifyDBProxyTargetGroupRequest {
    TargetGroupName?: string | undefined;
    DBProxyName?: string | undefined;
    ConnectionPoolConfig?: ConnectionPoolConfiguration | undefined;
    NewName?: string | undefined;
}
export interface ModifyDBProxyTargetGroupResponse {
    DBProxyTargetGroup?: DBProxyTargetGroup | undefined;
}
export interface RecommendedActionUpdate {
    ActionId?: string | undefined;
    Status?: string | undefined;
}
export type RecommendedActionUpdateList = RecommendedActionUpdate[];
export interface ModifyDBRecommendationMessage {
    RecommendationId?: string | undefined;
    Locale?: string | undefined;
    Status?: string | undefined;
    RecommendedActionUpdates?: RecommendedActionUpdate[] | undefined;
}
export interface DBRecommendationMessage {
    DBRecommendation?: DBRecommendation | undefined;
}
export interface ModifyDBShardGroupMessage {
    DBShardGroupIdentifier?: string | undefined;
    MaxACU?: number | undefined;
    MinACU?: number | undefined;
    ComputeRedundancy?: number | undefined;
}
export interface ModifyDBSnapshotMessage {
    DBSnapshotIdentifier?: string | undefined;
    EngineVersion?: string | undefined;
    OptionGroupName?: string | undefined;
}
export interface ModifyDBSnapshotResult {
    DBSnapshot?: (DBSnapshot & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export interface ModifyDBSnapshotAttributeMessage {
    DBSnapshotIdentifier?: string | undefined;
    AttributeName?: string | undefined;
    ValuesToAdd?: string[] | undefined;
    ValuesToRemove?: string[] | undefined;
}
export interface ModifyDBSnapshotAttributeResult {
    DBSnapshotAttributesResult?: DBSnapshotAttributesResult | undefined;
}
export interface ModifyDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
}
export interface ModifyDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup | undefined;
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SnsTopicArn?: string | undefined;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface ModifyEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface ModifyGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    NewGlobalClusterIdentifier?: string | undefined;
    DeletionProtection?: boolean | undefined;
    EngineVersion?: string | undefined;
    AllowMajorVersionUpgrade?: boolean | undefined;
}
export interface ModifyGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface ModifyIntegrationMessage {
    IntegrationIdentifier?: string | undefined;
    IntegrationName?: string | undefined;
    DataFilter?: string | undefined;
    Description?: string | undefined;
}
export type OptionSettingsList = OptionSetting[];
export interface OptionConfiguration {
    OptionName?: string | undefined;
    Port?: number | undefined;
    OptionVersion?: string | undefined;
    DBSecurityGroupMemberships?: string[] | undefined;
    VpcSecurityGroupMemberships?: string[] | undefined;
    OptionSettings?: OptionSetting[] | undefined;
}
export type OptionConfigurationList = OptionConfiguration[];
export type OptionNamesList = string[];
export interface ModifyOptionGroupMessage {
    OptionGroupName?: string | undefined;
    OptionsToInclude?: OptionConfiguration[] | undefined;
    OptionsToRemove?: string[] | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface ModifyOptionGroupResult {
    OptionGroup?: OptionGroup | undefined;
}
export interface ModifyTenantDatabaseMessage {
    DBInstanceIdentifier?: string | undefined;
    TenantDBName?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    NewTenantDBName?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    RotateMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
}
export interface ModifyTenantDatabaseResult {
    TenantDatabase?: TenantDatabase | undefined;
}
export interface PromoteReadReplicaMessage {
    DBInstanceIdentifier?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
}
export interface PromoteReadReplicaResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface PromoteReadReplicaDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface PromoteReadReplicaDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface PurchaseReservedDBInstancesOfferingMessage {
    ReservedDBInstancesOfferingId?: string | undefined;
    ReservedDBInstanceId?: string | undefined;
    DBInstanceCount?: number | undefined;
    Tags?: Tag[] | undefined;
}
export interface PurchaseReservedDBInstancesOfferingResult {
    ReservedDBInstance?: ReservedDBInstance | undefined;
}
export interface RebootDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface RebootDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface RebootDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    ForceFailover?: boolean | undefined;
}
export interface RebootDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface RebootDBShardGroupMessage {
    DBShardGroupIdentifier?: string | undefined;
}
export interface RegisterDBProxyTargetsRequest {
    DBProxyName?: string | undefined;
    TargetGroupName?: string | undefined;
    DBInstanceIdentifiers?: string[] | undefined;
    DBClusterIdentifiers?: string[] | undefined;
}
export interface RegisterDBProxyTargetsResponse {
    DBProxyTargets?: DBProxyTarget[] | undefined;
}
export interface RemoveFromGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    DbClusterIdentifier?: string | undefined;
}
export interface RemoveFromGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface RemoveRoleFromDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
}
export interface RemoveRoleFromDBClusterResponse {
}
export interface RemoveRoleFromDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
}
export interface RemoveRoleFromDBInstanceResponse {
}
export interface RemoveSourceIdentifierFromSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SourceIdentifier?: string | undefined;
}
export interface RemoveSourceIdentifierFromSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface RemoveTagsFromResourceResponse {
}
export interface ResetDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    ResetAllParameters?: boolean | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface ResetDBParameterGroupMessage {
    DBParameterGroupName?: string | undefined;
    ResetAllParameters?: boolean | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface RestoreDBClusterFromS3Message {
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    CharacterSetName?: string | undefined;
    DatabaseName?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterParameterGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    DBSubnetGroupName?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    OptionGroupName?: string | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    Tags?: Tag[] | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    SourceEngine?: string | undefined;
    SourceEngineVersion?: string | undefined;
    S3BucketName?: string | undefined;
    S3Prefix?: string | undefined;
    S3IngestionRoleArn?: string | undefined;
    BacktrackWindow?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    DeletionProtection?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    StorageType?: string | undefined;
    NetworkType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    AssociatedRoles?: DBClusterAssociatedRole[] | undefined;
}
export interface RestoreDBClusterFromS3Result {
    DBCluster?: DBCluster | undefined;
}
export interface RestoreDBClusterFromSnapshotMessage {
    AvailabilityZones?: string[] | undefined;
    DBClusterIdentifier?: string | undefined;
    SnapshotIdentifier?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    DBSubnetGroupName?: string | undefined;
    DatabaseName?: string | undefined;
    OptionGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    BacktrackWindow?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    EngineMode?: string | undefined;
    ScalingConfiguration?: ScalingConfiguration | undefined;
    DBClusterParameterGroupName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    DBClusterInstanceClass?: string | undefined;
    StorageType?: string | undefined;
    Iops?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
    NetworkType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    EnableVPCNetworking?: boolean | undefined;
    EnableInternetAccessGateway?: boolean | undefined;
    AssociatedRoles?: DBClusterAssociatedRole[] | undefined;
}
export interface RestoreDBClusterFromSnapshotResult {
    DBCluster?: DBCluster | undefined;
}
export interface RestoreDBClusterToPointInTimeMessage {
    DBClusterIdentifier?: string | undefined;
    RestoreType?: string | undefined;
    SourceDBClusterIdentifier?: string | undefined;
    RestoreToTime?: Date | undefined;
    UseLatestRestorableTime?: boolean | undefined;
    Port?: number | undefined;
    DBSubnetGroupName?: string | undefined;
    OptionGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    BacktrackWindow?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    DBClusterParameterGroupName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    DBClusterInstanceClass?: string | undefined;
    StorageType?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Iops?: number | undefined;
    NetworkType?: string | undefined;
    SourceDbClusterResourceId?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    ScalingConfiguration?: ScalingConfiguration | undefined;
    EngineMode?: string | undefined;
    RdsCustomClusterConfiguration?: RdsCustomClusterConfiguration | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    EnableVPCNetworking?: boolean | undefined;
    EnableInternetAccessGateway?: boolean | undefined;
    AssociatedRoles?: DBClusterAssociatedRole[] | undefined;
}
export interface RestoreDBClusterToPointInTimeResult {
    DBCluster?: DBCluster | undefined;
}
export interface RestoreDBInstanceFromDBSnapshotMessage {
    DBInstanceIdentifier?: string | undefined;
    DBSnapshotIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    MultiAZ?: boolean | undefined;
    PubliclyAccessible?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    LicenseModel?: string | undefined;
    DBName?: string | undefined;
    Engine?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    Tags?: Tag[] | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    TdeCredentialPassword?: string | redacted.Redacted<string> | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Domain?: string | undefined;
    DomainFqdn?: string | undefined;
    DomainOu?: string | undefined;
    DomainAuthSecretArn?: string | undefined;
    DomainDnsIps?: string[] | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    DomainIAMRoleName?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    UseDefaultProcessorFeatures?: boolean | undefined;
    DBParameterGroupName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    EnableCustomerOwnedIp?: boolean | undefined;
    NetworkType?: string | undefined;
    BackupTarget?: string | undefined;
    CustomIamInstanceProfile?: string | undefined;
    AllocatedStorage?: number | undefined;
    DBClusterSnapshotIdentifier?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    DedicatedLogVolume?: boolean | undefined;
    CACertificateIdentifier?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
}
export interface RestoreDBInstanceFromDBSnapshotResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface RestoreDBInstanceFromS3Message {
    DBName?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    AllocatedStorage?: number | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    DBSecurityGroups?: string[] | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    DBParameterGroupName?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    Port?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Tags?: Tag[] | undefined;
    StorageType?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    SourceEngine?: string | undefined;
    SourceEngineVersion?: string | undefined;
    S3BucketName?: string | undefined;
    S3Prefix?: string | undefined;
    S3IngestionRoleArn?: string | undefined;
    DatabaseInsightsMode?: DatabaseInsightsMode | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    UseDefaultProcessorFeatures?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    MaxAllocatedStorage?: number | undefined;
    NetworkType?: string | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    DedicatedLogVolume?: boolean | undefined;
    CACertificateIdentifier?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
}
export interface RestoreDBInstanceFromS3Result {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface RestoreDBInstanceToPointInTimeMessage {
    SourceDBInstanceIdentifier?: string | undefined;
    TargetDBInstanceIdentifier?: string | undefined;
    RestoreTime?: Date | undefined;
    UseLatestRestorableTime?: boolean | undefined;
    DBInstanceClass?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    MultiAZ?: boolean | undefined;
    PubliclyAccessible?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    LicenseModel?: string | undefined;
    DBName?: string | undefined;
    Engine?: string | undefined;
    Iops?: number | undefined;
    StorageThroughput?: number | undefined;
    OptionGroupName?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    Tags?: Tag[] | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    TdeCredentialPassword?: string | redacted.Redacted<string> | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Domain?: string | undefined;
    DomainIAMRoleName?: string | undefined;
    DomainFqdn?: string | undefined;
    DomainOu?: string | undefined;
    DomainAuthSecretArn?: string | undefined;
    DomainDnsIps?: string[] | undefined;
    EnableIAMDatabaseAuthentication?: boolean | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: ProcessorFeature[] | undefined;
    UseDefaultProcessorFeatures?: boolean | undefined;
    DBParameterGroupName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    SourceDbiResourceId?: string | undefined;
    MaxAllocatedStorage?: number | undefined;
    EnableCustomerOwnedIp?: boolean | undefined;
    NetworkType?: string | undefined;
    SourceDBInstanceAutomatedBackupsArn?: string | undefined;
    BackupTarget?: string | undefined;
    CustomIamInstanceProfile?: string | undefined;
    AllocatedStorage?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
    DedicatedLogVolume?: boolean | undefined;
    CACertificateIdentifier?: string | undefined;
    EngineLifecycleSupport?: string | undefined;
    AdditionalStorageVolumes?: AdditionalStorageVolume[] | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
}
export interface RestoreDBInstanceToPointInTimeResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface RevokeDBSecurityGroupIngressMessage {
    DBSecurityGroupName?: string | undefined;
    CIDRIP?: string | undefined;
    EC2SecurityGroupName?: string | undefined;
    EC2SecurityGroupId?: string | undefined;
    EC2SecurityGroupOwnerId?: string | undefined;
}
export interface RevokeDBSecurityGroupIngressResult {
    DBSecurityGroup?: DBSecurityGroup | undefined;
}
export interface StartActivityStreamRequest {
    ResourceArn?: string | undefined;
    Mode?: ActivityStreamMode | undefined;
    KmsKeyId?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    EngineNativeAuditFieldsIncluded?: boolean | undefined;
}
export interface StartActivityStreamResponse {
    KmsKeyId?: string | undefined;
    KinesisStreamName?: string | undefined;
    Status?: ActivityStreamStatus | undefined;
    Mode?: ActivityStreamMode | undefined;
    EngineNativeAuditFieldsIncluded?: boolean | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface StartDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface StartDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface StartDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    DBCapacityReservationIdentifier?: string | undefined;
}
export interface StartDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface StartDBInstanceAutomatedBackupsReplicationMessage {
    SourceDBInstanceArn?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartDBInstanceAutomatedBackupsReplicationResult {
    DBInstanceAutomatedBackup?: (DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export interface StartExportTaskMessage {
    ExportTaskIdentifier?: string | undefined;
    SourceArn?: string | undefined;
    S3BucketName?: string | undefined;
    IamRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    S3Prefix?: string | undefined;
    ExportOnly?: string[] | undefined;
}
export interface StopActivityStreamRequest {
    ResourceArn?: string | undefined;
    ApplyImmediately?: boolean | undefined;
}
export interface StopActivityStreamResponse {
    KmsKeyId?: string | undefined;
    KinesisStreamName?: string | undefined;
    Status?: ActivityStreamStatus | undefined;
}
export interface StopDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface StopDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface StopDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    DBSnapshotIdentifier?: string | undefined;
    DetachFromDBCapacityReservation?: boolean | undefined;
}
export interface StopDBInstanceResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export interface StopDBInstanceAutomatedBackupsReplicationMessage {
    SourceDBInstanceArn?: string | undefined;
}
export interface StopDBInstanceAutomatedBackupsReplicationResult {
    DBInstanceAutomatedBackup?: (DBInstanceAutomatedBackup & {
        AdditionalStorageVolumes: (AdditionalStorageVolume & {
            VolumeName: string;
        })[];
    }) | undefined;
}
export type SwitchoverTimeout = number;
export interface SwitchoverBlueGreenDeploymentRequest {
    BlueGreenDeploymentIdentifier?: string | undefined;
    SwitchoverTimeout?: number | undefined;
}
export interface SwitchoverBlueGreenDeploymentResponse {
    BlueGreenDeployment?: BlueGreenDeployment | undefined;
}
export interface SwitchoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    TargetDbClusterIdentifier?: string | undefined;
}
export interface SwitchoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface SwitchoverReadReplicaMessage {
    DBInstanceIdentifier?: string | undefined;
}
export interface SwitchoverReadReplicaResult {
    DBInstance?: (DBInstance & {
        PendingModifiedValues: PendingModifiedValues & {
            AdditionalStorageVolumes: (AdditionalStorageVolume & {
                VolumeName: string;
            })[];
        };
    }) | undefined;
}
export type ExceptionMessage = string;
export type AddRoleToDBClusterError = DBClusterNotFoundFault | DBClusterRoleAlreadyExistsFault | DBClusterRoleQuotaExceededFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Associates an Identity and Access Management (IAM) role with a DB cluster.
 */
export declare const addRoleToDBCluster: API.OperationMethod<AddRoleToDBClusterMessage & RegionInput, AddRoleToDBClusterResponse, AddRoleToDBClusterError, Credentials | HttpClient.HttpClient>;
export type AddRoleToDBInstanceError = DBInstanceNotFoundFault | DBInstanceRoleAlreadyExistsFault | DBInstanceRoleQuotaExceededFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Associates an Amazon Web Services Identity and Access Management (IAM) role with a DB instance.
 *
 * To add a role to a DB instance, the status of the DB instance must be `available`.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const addRoleToDBInstance: API.OperationMethod<AddRoleToDBInstanceMessage & RegionInput, AddRoleToDBInstanceResponse, AddRoleToDBInstanceError, Credentials | HttpClient.HttpClient>;
export type AddSourceIdentifierToSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Adds a source identifier to an existing RDS event notification subscription.
 */
export declare const addSourceIdentifierToSubscription: API.OperationMethod<AddSourceIdentifierToSubscriptionMessage & RegionInput, AddSourceIdentifierToSubscriptionResult, AddSourceIdentifierToSubscriptionError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = BlueGreenDeploymentNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an Amazon RDS resource. These tags can also be used with cost allocation reporting to track cost associated with Amazon RDS resources, or used in a Condition statement in an IAM policy for Amazon RDS.
 *
 * For an overview on tagging your relational database resources, see Tagging Amazon RDS Resources or Tagging Amazon Aurora and Amazon RDS Resources.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage & RegionInput, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example, to a DB instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage & RegionInput, ApplyPendingMaintenanceActionResult, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type AuthorizeDBSecurityGroupIngressError = AuthorizationAlreadyExistsFault | AuthorizationQuotaExceededFault | DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Enables ingress to a DBSecurityGroup using one of two forms of authorization. First, EC2 or VPC security groups can be added to the DBSecurityGroup if the application using the database is running on EC2 or VPC instances. Second, IP ranges are available if the application accessing your database is running on the internet. Required parameters for this API are one of CIDR range, EC2SecurityGroupId for VPC, or (EC2SecurityGroupOwnerId and either EC2SecurityGroupName or EC2SecurityGroupId for non-VPC).
 *
 * You can't authorize ingress from an EC2 security group in one Amazon Web Services Region to an Amazon RDS DB instance in another. You can't authorize ingress from a VPC security group in one VPC to an Amazon RDS DB instance in another.
 *
 * For an overview of CIDR ranges, go to the Wikipedia Tutorial.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const authorizeDBSecurityGroupIngress: API.OperationMethod<AuthorizeDBSecurityGroupIngressMessage & RegionInput, AuthorizeDBSecurityGroupIngressResult, AuthorizeDBSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type BacktrackDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Backtracks a DB cluster to a specific time, without creating a new DB cluster.
 *
 * For more information on backtracking, see Backtracking an Aurora DB Cluster in the *Amazon Aurora User Guide*.
 *
 * This action applies only to Aurora MySQL DB clusters.
 */
export declare const backtrackDBCluster: API.OperationMethod<BacktrackDBClusterMessage & RegionInput, DBClusterBacktrack, BacktrackDBClusterError, Credentials | HttpClient.HttpClient>;
export type CancelDBCapacityReservationError = DBCapacityReservationNotFoundFault | InvalidDBCapacityReservationStateFault | CommonErrors;
/**
 * Cancels a DB capacity reservation. Amazon RDS changes the state of the reservation to `cancelled` and stops reporting available capacity for it. Amazon RDS then releases the reserved capacity.
 *
 * A DB instance that uses the reservation keeps running. It continues on unreserved capacity, and Amazon RDS doesn't stop it or modify it. However, Amazon RDS no longer reserves capacity for the DB instance. If Amazon RDS later moves the DB instance to different hardware, for example during hardware maintenance, that move can fail when the Amazon Web Services Region has insufficient capacity for the DB instance class.
 *
 * You can't cancel a reservation in the `active` state during a capacity commitment. The response of `DescribeDBCapacityReservations` reports the end of the commitment in `CommitmentInfo`.
 *
 * Constraints:
 *
 * - The reservation must be in the `active`, `assessing`, or `delayed` state.
 *
 * - The reservation must not be past its end date.
 */
export declare const cancelDBCapacityReservation: API.OperationMethod<CancelDBCapacityReservationRequest & RegionInput, CancelDBCapacityReservationResponse, CancelDBCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CancelExportTaskError = ExportTaskNotFoundFault | InvalidExportTaskStateFault | CommonErrors;
/**
 * Cancels an export task in progress that is exporting a snapshot or cluster to Amazon S3. Any data that has already been written to the S3 bucket isn't removed.
 */
export declare const cancelExportTask: API.OperationMethod<CancelExportTaskMessage & RegionInput, ExportTask, CancelExportTaskError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB cluster parameter group.
 *
 * You can't copy a default DB cluster parameter group. Instead, create a new custom DB cluster parameter group, which copies the default parameters and values for the specified DB cluster parameter group family.
 */
export declare const copyDBClusterParameterGroup: API.OperationMethod<CopyDBClusterParameterGroupMessage & RegionInput, CopyDBClusterParameterGroupResult, CopyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterSnapshotError = DBClusterSnapshotAlreadyExistsFault | DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies a snapshot of a DB cluster.
 *
 * To copy a DB cluster snapshot from a shared manual DB cluster snapshot, `SourceDBClusterSnapshotIdentifier` must be the Amazon Resource Name (ARN) of the shared DB cluster snapshot.
 *
 * You can copy an encrypted DB cluster snapshot from another Amazon Web Services Region. In that case, the Amazon Web Services Region where you call the `CopyDBClusterSnapshot` operation is the destination Amazon Web Services Region for the encrypted DB cluster snapshot to be copied to. To copy an encrypted DB cluster snapshot from another Amazon Web Services Region, you must provide the following values:
 *
 * - `KmsKeyId` - The Amazon Web Services Key Management System (Amazon Web Services KMS) key identifier for the key to use to encrypt the copy of the DB cluster snapshot in the destination Amazon Web Services Region.
 *
 * - `TargetDBClusterSnapshotIdentifier` - The identifier for the new copy of the DB cluster snapshot in the destination Amazon Web Services Region.
 *
 * - `SourceDBClusterSnapshotIdentifier` - The DB cluster snapshot identifier for the encrypted DB cluster snapshot to be copied. This identifier must be in the ARN format for the source Amazon Web Services Region and is the same value as the `SourceDBClusterSnapshotIdentifier` in the presigned URL.
 *
 * To cancel the copy operation once it is in progress, delete the target DB cluster snapshot identified by `TargetDBClusterSnapshotIdentifier` while that DB cluster snapshot is in "copying" status.
 *
 * For more information on copying encrypted Amazon Aurora DB cluster snapshots from one Amazon Web Services Region to another, see Copying a Snapshot in the *Amazon Aurora User Guide*.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const copyDBClusterSnapshot: API.OperationMethod<CopyDBClusterSnapshotMessage & RegionInput, CopyDBClusterSnapshotResult, CopyDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopyDBParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB parameter group.
 *
 * You can't copy a default DB parameter group. Instead, create a new custom DB parameter group, which copies the default parameters and values for the specified DB parameter group family.
 */
export declare const copyDBParameterGroup: API.OperationMethod<CopyDBParameterGroupMessage & RegionInput, CopyDBParameterGroupResult, CopyDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBSnapshotError = CustomAvailabilityZoneNotFoundFault | DBSnapshotAlreadyExistsFault | DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies the specified DB snapshot. The source DB snapshot must be in the `available` state.
 *
 * You can copy a snapshot from one Amazon Web Services Region to another. In that case, the Amazon Web Services Region where you call the `CopyDBSnapshot` operation is the destination Amazon Web Services Region for the DB snapshot copy.
 *
 * This command doesn't apply to RDS Custom.
 *
 * For more information about copying snapshots, see Copying a DB Snapshot in the *Amazon RDS User Guide*.
 */
export declare const copyDBSnapshot: API.OperationMethod<CopyDBSnapshotMessage & RegionInput, CopyDBSnapshotResult, CopyDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopyOptionGroupError = OptionGroupAlreadyExistsFault | OptionGroupNotFoundFault | OptionGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified option group.
 */
export declare const copyOptionGroup: API.OperationMethod<CopyOptionGroupMessage & RegionInput, CopyOptionGroupResult, CopyOptionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateBlueGreenDeploymentError = BlueGreenDeploymentAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | InstanceQuotaExceededFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SourceClusterNotSupportedFault | SourceDatabaseNotSupportedFault | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a blue/green deployment.
 *
 * A blue/green deployment creates a staging environment that copies the production environment. In a blue/green deployment, the blue environment is the current production environment. The green environment is the staging environment, and it stays in sync with the current production environment.
 *
 * You can make changes to the databases in the green environment without affecting production workloads. For example, you can upgrade the major or minor DB engine version, change database parameters, or make schema changes in the staging environment. You can thoroughly test changes in the green environment. When ready, you can switch over the environments to promote the green environment to be the new production environment. The switchover typically takes under a minute.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const createBlueGreenDeployment: API.OperationMethod<CreateBlueGreenDeploymentRequest & RegionInput, CreateBlueGreenDeploymentResponse, CreateBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDBEngineVersionError = CreateCustomDBEngineVersionFault | CustomDBEngineVersionAlreadyExistsFault | CustomDBEngineVersionNotFoundFault | CustomDBEngineVersionQuotaExceededFault | Ec2ImagePropertiesNotSupportedFault | InvalidCustomDBEngineVersionStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Creates a custom DB engine version (CEV).
 */
export declare const createCustomDBEngineVersion: API.OperationMethod<CreateCustomDBEngineVersionMessage & RegionInput, DBEngineVersion, CreateCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDBCapacityReservationError = DBCapacityReservationAlreadyExistsFault | DBCapacityReservationUnsupportedFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | CommonErrors;
/**
 * Creates a DB capacity reservation. A DB capacity reservation reserves compute and memory capacity for DB instances of one DB instance class and one database engine. Amazon RDS reserves that capacity in each Availability Zone that you specify.
 *
 * Amazon RDS reserves the same amount of capacity in every Availability Zone in the request. You set that amount with `CapacityPerAvailabilityZone`, and you set the Availability Zones with `AvailabilityZones`. The total reserved capacity is `CapacityPerAvailabilityZone` multiplied by the number of Availability Zones.
 *
 * Specify `StartDate` and `CommitmentDuration` together to create a future-dated reservation. A future-dated reservation reserves capacity for a period that starts later. Amazon RDS holds that capacity for the length of the commitment.
 *
 * A future-dated reservation has the following additional constraints:
 *
 * - `DBInstanceClass` must be a `db.c`, `db.m`, `db.r`, `db.t`, or `db.x` DB instance class. The letter after `db.` gives the DB instance class family. For example, `db.x2g.xlarge` qualifies, and `db.z1d.xlarge` doesn't.
 *
 * - If `DBInstanceClass` is a `db.m` or `db.r` DB instance class, it must be from generation 7 or later. The digit after the family letter gives the generation. For example, `db.m7g.xlarge` qualifies, and `db.m5.xlarge` doesn't. A `db.c`, `db.t`, or `db.x` DB instance class has no generation requirement.
 *
 * - The reserved capacity must total at least 32 vCPUs in each Availability Zone. Multiply `CapacityPerAvailabilityZone` by the number of vCPUs of the DB instance class. The product must be 32 or more.
 *
 * - `CommitmentDuration` must be at least 14 days. For a `db.x` DB instance class, it must be at least 84 days.
 *
 * - `StartDate` must be from 5 to 120 days in the future.
 *
 * Therefore, a DB instance class with 2 vCPUs needs a `CapacityPerAvailabilityZone` of 16 or more, a class with 4 vCPUs needs 8 or more, a class with 8 vCPUs needs 4 or more, and a class with 16 vCPUs needs 2 or more. For the number of vCPUs of each DB instance class, see DB instance classes in the *Amazon RDS User Guide*.
 *
 * You can't modify a future-dated reservation before it starts. You can't cancel a future-dated reservation in the `scheduled` state. You can't cancel a reservation in the `active` state during its capacity commitment. Therefore, you can't cancel a future-dated reservation from the time that Amazon RDS schedules it until the commitment ends.
 */
export declare const createDBCapacityReservation: API.OperationMethod<CreateDBCapacityReservationRequest & RegionInput, CreateDBCapacityReservationResponse, CreateDBCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | GlobalClusterNotFoundFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Creates a new Amazon Aurora DB cluster or Multi-AZ DB cluster.
 *
 * If you create an Aurora DB cluster, the request creates an empty cluster. You must explicitly create the writer instance for your DB cluster using the CreateDBInstance operation. If you create a Multi-AZ DB cluster, the request creates a writer and two reader DB instances for you, each in a different Availability Zone.
 *
 * You can use the `ReplicationSourceIdentifier` parameter to create an Amazon Aurora DB cluster as a read replica of another DB cluster or Amazon RDS for MySQL or PostgreSQL DB instance. For more information about Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * You can also use the `ReplicationSourceIdentifier` parameter to create a Multi-AZ DB cluster read replica with an RDS for MySQL or PostgreSQL DB instance as the source. For more information about Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 *
 * You can use the `WithExpressConfiguration` parameter to create an Aurora DB Cluster with express configuration and create cluster in seconds. Express configuration provides a cluster with a writer instance and feature specific values set to all other input parameters of this API.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster. Each associated role lets the DB cluster access other Amazon Web Services on your behalf, such as Amazon S3 for data import and export, or Amazon Web Services Lambda for invoking functions.
 */
export declare const createDBCluster: API.OperationMethod<CreateDBClusterMessage & RegionInput, CreateDBClusterResult, CreateDBClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterEndpointError = DBClusterEndpointAlreadyExistsFault | DBClusterEndpointQuotaExceededFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Creates a new custom endpoint and associates it with an Amazon Aurora DB cluster.
 *
 * This action applies only to Aurora DB clusters.
 */
export declare const createDBClusterEndpoint: API.OperationMethod<CreateDBClusterEndpointMessage & RegionInput, DBClusterEndpoint, CreateDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB cluster parameter group.
 *
 * Parameters in a DB cluster parameter group apply to all of the instances in a DB cluster.
 *
 * A DB cluster parameter group is initially created with the default parameters for the database engine used by instances in the DB cluster. To provide custom values for any of the parameters, you must modify the group after creating it using `ModifyDBClusterParameterGroup`. Once you've created a DB cluster parameter group, you need to associate it with your DB cluster using `ModifyDBCluster`.
 *
 * When you associate a new DB cluster parameter group with a running Aurora DB cluster, reboot the DB instances in the DB cluster without failover for the new DB cluster parameter group and associated settings to take effect.
 *
 * When you associate a new DB cluster parameter group with a running Multi-AZ DB cluster, reboot the DB cluster without failover for the new DB cluster parameter group and associated settings to take effect.
 *
 * After you create a DB cluster parameter group, you should wait at least 5 minutes before creating your first DB cluster that uses that DB cluster parameter group as the default parameter group. This allows Amazon RDS to fully complete the create action before the DB cluster parameter group is used as the default for a new DB cluster. This is especially important for parameters that are critical when creating the default database for a DB cluster, such as the character set for the default database defined by the `character_set_database` parameter. You can use the *Parameter Groups* option of the Amazon RDS console or the `DescribeDBClusterParameters` operation to verify that your DB cluster parameter group has been created or modified.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const createDBClusterParameterGroup: API.OperationMethod<CreateDBClusterParameterGroupMessage & RegionInput, CreateDBClusterParameterGroupResult, CreateDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterSnapshotError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a DB cluster.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const createDBClusterSnapshot: API.OperationMethod<CreateDBClusterSnapshotMessage & RegionInput, CreateDBClusterSnapshotResult, CreateDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Creates a new DB instance.
 *
 * The new DB instance can be an RDS DB instance, or it can be a DB instance in an Aurora DB cluster. For an Aurora DB cluster, you can call this operation multiple times to add more than one DB instance to the cluster.
 *
 * For more information about creating an RDS DB instance, see Creating an Amazon RDS DB instance in the *Amazon RDS User Guide*.
 *
 * For more information about creating a DB instance in an Aurora DB cluster, see Creating an Amazon Aurora DB cluster in the *Amazon Aurora User Guide*.
 */
export declare const createDBInstance: API.OperationMethod<CreateDBInstanceMessage & RegionInput, CreateDBInstanceResult, CreateDBInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceReadReplicaError = CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotAllowedFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB instance that acts as a read replica for an existing source DB instance or Multi-AZ DB cluster. You can create a read replica for a DB instance running Db2, MariaDB, MySQL, Oracle, PostgreSQL, or SQL Server. You can create a read replica for a Multi-AZ DB cluster running MySQL or PostgreSQL. For more information, see Working with read replicas and Migrating from a Multi-AZ DB cluster to a DB instance using a read replica in the *Amazon RDS User Guide*.
 *
 * Amazon Aurora doesn't support this operation. To create a DB instance for an Aurora DB cluster, use the `CreateDBInstance` operation.
 *
 * RDS creates read replicas with backups disabled. All other attributes (including DB security groups and DB parameter groups) are inherited from the source DB instance or cluster, except as specified.
 *
 * Your source DB instance or cluster must have backup retention enabled.
 */
export declare const createDBInstanceReadReplica: API.OperationMethod<CreateDBInstanceReadReplicaMessage & RegionInput, CreateDBInstanceReadReplicaResult, CreateDBInstanceReadReplicaError, Credentials | HttpClient.HttpClient>;
export type CreateDBParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB parameter group.
 *
 * A DB parameter group is initially created with the default parameters for the database engine used by the DB instance. To provide custom values for any of the parameters, you must modify the group after creating it using `ModifyDBParameterGroup`. Once you've created a DB parameter group, you need to associate it with your DB instance using `ModifyDBInstance`. When you associate a new DB parameter group with a running DB instance, you need to reboot the DB instance without failover for the new DB parameter group and associated settings to take effect.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const createDBParameterGroup: API.OperationMethod<CreateDBParameterGroupMessage & RegionInput, CreateDBParameterGroupResult, CreateDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBProxyError = DBProxyAlreadyExistsFault | DBProxyQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new DB proxy.
 */
export declare const createDBProxy: API.OperationMethod<CreateDBProxyRequest & RegionInput, CreateDBProxyResponse, CreateDBProxyError, Credentials | HttpClient.HttpClient>;
export type CreateDBProxyEndpointError = DBProxyEndpointAlreadyExistsFault | DBProxyEndpointQuotaExceededFault | DBProxyNotFoundFault | InvalidDBProxyStateFault | InvalidSubnet | CommonErrors;
/**
 * Creates a `DBProxyEndpoint`. Only applies to proxies that are associated with Aurora DB clusters. You can use DB proxy endpoints to specify read/write or read-only access to the DB cluster. You can also use DB proxy endpoints to access a DB proxy through a different VPC than the proxy's default VPC.
 */
export declare const createDBProxyEndpoint: API.OperationMethod<CreateDBProxyEndpointRequest & RegionInput, CreateDBProxyEndpointResponse, CreateDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateDBSecurityGroupError = DBSecurityGroupAlreadyExistsFault | DBSecurityGroupNotSupportedFault | DBSecurityGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new DB security group. DB security groups control access to a DB instance.
 *
 * A DB security group controls access to EC2-Classic DB instances that are not in a VPC.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const createDBSecurityGroup: API.OperationMethod<CreateDBSecurityGroupMessage & RegionInput, CreateDBSecurityGroupResult, CreateDBSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBShardGroupError = DBClusterNotFoundFault | DBShardGroupAlreadyExistsFault | InvalidDBClusterStateFault | InvalidVPCNetworkStateFault | MaxDBShardGroupLimitReached | NetworkTypeNotSupported | UnsupportedDBEngineVersionFault | CommonErrors;
/**
 * Creates a new DB shard group for Aurora Limitless Database. You must enable Aurora Limitless Database to create a DB shard group.
 *
 * Valid for: Aurora DB clusters only
 */
export declare const createDBShardGroup: API.OperationMethod<CreateDBShardGroupMessage & RegionInput, DBShardGroup, CreateDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBSnapshotError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a DB instance. The source DB instance must be in the `available` or `storage-optimization` state.
 */
export declare const createDBSnapshot: API.OperationMethod<CreateDBSnapshotMessage & RegionInput, CreateDBSnapshotResult, CreateDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBSubnetGroupError = DBSubnetGroupAlreadyExistsFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupQuotaExceededFault | DBSubnetQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new DB subnet group. DB subnet groups must contain at least one subnet in at least two AZs in the Amazon Web Services Region.
 */
export declare const createDBSubnetGroup: API.OperationMethod<CreateDBSubnetGroupMessage & RegionInput, CreateDBSubnetGroupResult, CreateDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionAlreadyExistFault | SubscriptionCategoryNotFoundFault | CommonErrors;
/**
 * Creates an RDS event notification subscription. This operation requires a topic Amazon Resource Name (ARN) created by either the RDS console, the SNS console, or the SNS API. To obtain an ARN with SNS, you must create a topic in Amazon SNS and subscribe to the topic. The ARN is displayed in the SNS console.
 *
 * You can specify the type of source (`SourceType`) that you want to be notified of and provide a list of RDS sources (`SourceIds`) that triggers the events. You can also provide a list of event categories (`EventCategories`) for events that you want to be notified of. For example, you can specify `SourceType` = `db-instance`, `SourceIds` = `mydbinstance1`, `mydbinstance2` and `EventCategories` = `Availability`, `Backup`.
 *
 * If you specify both the `SourceType` and `SourceIds`, such as `SourceType` = `db-instance` and `SourceIds` = `myDBInstance1`, you are notified of all the `db-instance` events for the specified source. If you specify a `SourceType` but do not specify `SourceIds`, you receive notice of the events for that source type for all your RDS sources. If you don't specify either the SourceType or the `SourceIds`, you are notified of events generated from all RDS sources belonging to your customer account.
 *
 * For more information about subscribing to an event for RDS DB engines, see Subscribing to Amazon RDS event notification in the *Amazon RDS User Guide*.
 *
 * For more information about subscribing to an event for Aurora DB engines, see Subscribing to Amazon RDS event notification in the *Amazon Aurora User Guide*.
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage & RegionInput, CreateEventSubscriptionResult, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalClusterError = DBClusterNotFoundFault | GlobalClusterAlreadyExistsFault | GlobalClusterQuotaExceededFault | InvalidDBClusterStateFault | InvalidDBShardGroupStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Creates an Aurora global database spread across multiple Amazon Web Services Regions. The global database contains a single primary cluster with read-write capability, and a read-only secondary cluster that receives data from the primary cluster through high-speed replication performed by the Aurora storage subsystem.
 *
 * You can create a global database that is initially empty, and then create the primary and secondary DB clusters in the global database. Or you can specify an existing Aurora cluster during the create operation, and this cluster becomes the primary cluster of the global database.
 *
 * This operation applies only to Aurora DB clusters.
 */
export declare const createGlobalCluster: API.OperationMethod<CreateGlobalClusterMessage & RegionInput, CreateGlobalClusterResult, CreateGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = DBClusterNotFoundFault | DBInstanceNotFoundFault | IntegrationAlreadyExistsFault | IntegrationConflictOperationFault | IntegrationQuotaExceededFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Creates a zero-ETL integration with Amazon Redshift.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationMessage & RegionInput, Integration, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateOptionGroupError = OptionGroupAlreadyExistsFault | OptionGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new option group. You can create up to 20 option groups.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const createOptionGroup: API.OperationMethod<CreateOptionGroupMessage & RegionInput, CreateOptionGroupResult, CreateOptionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateTenantDatabaseError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | TenantDatabaseAlreadyExistsFault | TenantDatabaseQuotaExceededFault | CommonErrors;
/**
 * Creates a tenant database in a DB instance that uses the multi-tenant configuration. Only RDS for Oracle container database (CDB) instances are supported.
 */
export declare const createTenantDatabase: API.OperationMethod<CreateTenantDatabaseMessage & RegionInput, CreateTenantDatabaseResult, CreateTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueGreenDeploymentError = BlueGreenDeploymentNotFoundFault | InvalidBlueGreenDeploymentStateFault | CommonErrors;
/**
 * Deletes a blue/green deployment.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const deleteBlueGreenDeployment: API.OperationMethod<DeleteBlueGreenDeploymentRequest & RegionInput, DeleteBlueGreenDeploymentResponse, DeleteBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDBEngineVersionError = CustomDBEngineVersionNotFoundFault | InvalidCustomDBEngineVersionStateFault | CommonErrors;
/**
 * Deletes a custom engine version. To run this command, make sure you meet the following prerequisites:
 *
 * - The CEV must not be the default for RDS Custom. If it is, change the default before running this command.
 *
 * - The CEV must not be associated with an RDS Custom DB instance, RDS Custom instance snapshot, or automated backup of your RDS Custom instance.
 *
 * Typically, deletion takes a few minutes.
 *
 * The MediaImport service that imports files from Amazon S3 to create CEVs isn't integrated with Amazon Web Services CloudTrail. If you turn on data logging for Amazon RDS in CloudTrail, calls to the `DeleteCustomDbEngineVersion` event aren't logged. However, you might see calls from the API gateway that accesses your Amazon S3 bucket. These calls originate from the MediaImport service for the `DeleteCustomDbEngineVersion` event.
 *
 * For more information, see Deleting a CEV in the *Amazon RDS User Guide*.
 */
export declare const deleteCustomDBEngineVersion: API.OperationMethod<DeleteCustomDBEngineVersionMessage & RegionInput, DBEngineVersion, DeleteCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterError = DBClusterAutomatedBackupQuotaExceededFault | DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | DBClusterDeletionProtected | CommonErrors;
/**
 * The DeleteDBCluster action deletes a previously provisioned DB cluster. When you delete a DB cluster, all automated backups for that DB cluster are deleted and can't be recovered. Manual DB cluster snapshots of the specified DB cluster are not deleted.
 *
 * If you're deleting a Multi-AZ DB cluster with read replicas, all cluster members are terminated and read replicas are promoted to standalone instances.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBCluster: API.OperationMethod<DeleteDBClusterMessage & RegionInput, DeleteDBClusterResult, DeleteDBClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterAutomatedBackupError = DBClusterAutomatedBackupNotFoundFault | InvalidDBClusterAutomatedBackupStateFault | CommonErrors;
/**
 * Deletes automated backups using the `DbClusterResourceId` value of the source DB cluster or the Amazon Resource Name (ARN) of the automated backups.
 */
export declare const deleteDBClusterAutomatedBackup: API.OperationMethod<DeleteDBClusterAutomatedBackupMessage & RegionInput, DeleteDBClusterAutomatedBackupResult, DeleteDBClusterAutomatedBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterEndpointError = DBClusterEndpointNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Deletes a custom endpoint and removes it from an Amazon Aurora DB cluster.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const deleteDBClusterEndpoint: API.OperationMethod<DeleteDBClusterEndpointMessage & RegionInput, DBClusterEndpoint, DeleteDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified DB cluster parameter group. The DB cluster parameter group to be deleted can't be associated with any DB clusters.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBClusterParameterGroup: API.OperationMethod<DeleteDBClusterParameterGroupMessage & RegionInput, DeleteDBClusterParameterGroupResponse, DeleteDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterSnapshotError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | CommonErrors;
/**
 * Deletes a DB cluster snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The DB cluster snapshot must be in the `available` state to be deleted.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const deleteDBClusterSnapshot: API.OperationMethod<DeleteDBClusterSnapshotMessage & RegionInput, DeleteDBClusterSnapshotResult, DeleteDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceError = DBInstanceAutomatedBackupQuotaExceededFault | DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | DBInstanceDeletionProtected | CommonErrors;
/**
 * Deletes a previously provisioned DB instance. When you delete a DB instance, all automated backups for that instance are deleted and can't be recovered. However, manual DB snapshots of the DB instance aren't deleted.
 *
 * If you request a final DB snapshot, the status of the Amazon RDS DB instance is `deleting` until the DB snapshot is created. This operation can't be canceled or reverted after it begins. To monitor the status of this operation, use `DescribeDBInstance`.
 *
 * When a DB instance is in a failure state and has a status of `failed`, `incompatible-restore`, or `incompatible-network`, you can only delete it when you skip creation of the final snapshot with the `SkipFinalSnapshot` parameter.
 *
 * If the specified DB instance is part of an Amazon Aurora DB cluster, you can't delete the DB instance if both of the following conditions are true:
 *
 * - The DB cluster is a read replica of another Amazon Aurora DB cluster.
 *
 * - The DB instance is the only instance in the DB cluster.
 *
 * To delete a DB instance in this case, first use the `PromoteReadReplicaDBCluster` operation to promote the DB cluster so that it's no longer a read replica. After the promotion completes, use the `DeleteDBInstance` operation to delete the final instance in the DB cluster.
 *
 * For RDS Custom DB instances, deleting the DB instance permanently deletes the EC2 instance and the associated EBS volumes. Make sure that you don't terminate or delete these resources before you delete the DB instance. Otherwise, deleting the DB instance and creation of the final snapshot might fail.
 */
export declare const deleteDBInstance: API.OperationMethod<DeleteDBInstanceMessage & RegionInput, DeleteDBInstanceResult, DeleteDBInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceAutomatedBackupError = DBInstanceAutomatedBackupNotFoundFault | InvalidDBInstanceAutomatedBackupStateFault | CommonErrors;
/**
 * Deletes automated backups using the `DbiResourceId` value of the source DB instance or the Amazon Resource Name (ARN) of the automated backups.
 */
export declare const deleteDBInstanceAutomatedBackup: API.OperationMethod<DeleteDBInstanceAutomatedBackupMessage & RegionInput, DeleteDBInstanceAutomatedBackupResult, DeleteDBInstanceAutomatedBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified DB parameter group. The DB parameter group to be deleted can't be associated with any DB instances.
 */
export declare const deleteDBParameterGroup: API.OperationMethod<DeleteDBParameterGroupMessage & RegionInput, DeleteDBParameterGroupResponse, DeleteDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBProxyError = DBProxyNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Deletes an existing DB proxy.
 */
export declare const deleteDBProxy: API.OperationMethod<DeleteDBProxyRequest & RegionInput, DeleteDBProxyResponse, DeleteDBProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteDBProxyEndpointError = DBProxyEndpointNotFoundFault | InvalidDBProxyEndpointStateFault | CommonErrors;
/**
 * Deletes a `DBProxyEndpoint`. Doing so removes the ability to access the DB proxy using the endpoint that you defined. The endpoint that you delete might have provided capabilities such as read/write or read-only operations, or using a different VPC than the DB proxy's default VPC.
 */
export declare const deleteDBProxyEndpoint: API.OperationMethod<DeleteDBProxyEndpointRequest & RegionInput, DeleteDBProxyEndpointResponse, DeleteDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSecurityGroupError = DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Deletes a DB security group.
 *
 * The specified DB security group must not be associated with any DB instances.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const deleteDBSecurityGroup: API.OperationMethod<DeleteDBSecurityGroupMessage & RegionInput, DeleteDBSecurityGroupResponse, DeleteDBSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBShardGroupError = DBShardGroupNotFoundFault | InvalidDBClusterStateFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * Deletes an Aurora Limitless Database DB shard group.
 */
export declare const deleteDBShardGroup: API.OperationMethod<DeleteDBShardGroupMessage & RegionInput, DBShardGroup, DeleteDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSnapshotError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | CommonErrors;
/**
 * Deletes a DB snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The DB snapshot must be in the `available` state to be deleted.
 */
export declare const deleteDBSnapshot: API.OperationMethod<DeleteDBSnapshotMessage & RegionInput, DeleteDBSnapshotResult, DeleteDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSubnetGroupError = DBSubnetGroupNotFoundFault | InvalidDBSubnetGroupStateFault | InvalidDBSubnetStateFault | CommonErrors;
/**
 * Deletes a DB subnet group.
 *
 * The specified database subnet group must not be associated with any DB instances.
 */
export declare const deleteDBSubnetGroup: API.OperationMethod<DeleteDBSubnetGroupMessage & RegionInput, DeleteDBSubnetGroupResponse, DeleteDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = InvalidEventSubscriptionStateFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Deletes an RDS event notification subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage & RegionInput, DeleteEventSubscriptionResult, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Deletes a global database cluster. The primary and secondary clusters must already be detached or destroyed first.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const deleteGlobalCluster: API.OperationMethod<DeleteGlobalClusterMessage & RegionInput, DeleteGlobalClusterResult, DeleteGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = IntegrationConflictOperationFault | IntegrationNotFoundFault | InvalidIntegrationStateFault | CommonErrors;
/**
 * Deletes a zero-ETL integration with Amazon Redshift.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationMessage & RegionInput, Integration, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteOptionGroupError = InvalidOptionGroupStateFault | OptionGroupNotFoundFault | CommonErrors;
/**
 * Deletes an existing option group.
 */
export declare const deleteOptionGroup: API.OperationMethod<DeleteOptionGroupMessage & RegionInput, DeleteOptionGroupResponse, DeleteOptionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTenantDatabaseError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Deletes a tenant database from your DB instance. This command only applies to RDS for Oracle container database (CDB) instances.
 *
 * You can't delete a tenant database when it is the only tenant in the DB instance.
 */
export declare const deleteTenantDatabase: API.OperationMethod<DeleteTenantDatabaseMessage & RegionInput, DeleteTenantDatabaseResult, DeleteTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeregisterDBProxyTargetsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBProxyTargetNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Remove the association between one or more `DBProxyTarget` data structures and a `DBProxyTargetGroup`.
 */
export declare const deregisterDBProxyTargets: API.OperationMethod<DeregisterDBProxyTargetsRequest & RegionInput, DeregisterDBProxyTargetsResponse, DeregisterDBProxyTargetsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = CommonErrors;
/**
 * Lists all of the attributes for a customer account. The attributes include Amazon RDS quotas for the account, such as the number of DB instances allowed. The description for a quota includes the quota name, current usage toward that quota, and the quota's maximum value.
 *
 * This command doesn't take any parameters.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesMessage & RegionInput, AccountAttributesMessage, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeBlueGreenDeploymentsError = BlueGreenDeploymentNotFoundFault | CommonErrors;
/**
 * Describes one or more blue/green deployments.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const describeBlueGreenDeployments: API.PaginatedOperationMethod<DescribeBlueGreenDeploymentsRequest & RegionInput, DescribeBlueGreenDeploymentsResponse, DescribeBlueGreenDeploymentsError, Credentials | HttpClient.HttpClient, BlueGreenDeployment>;
export type DescribeCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Lists the set of certificate authority (CA) certificates provided by Amazon RDS for this Amazon Web Services account.
 *
 * For more information, see Using SSL/TLS to encrypt a connection to a DB instance in the *Amazon RDS User Guide* and Using SSL/TLS to encrypt a connection to a DB cluster in the *Amazon Aurora User Guide*.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage & RegionInput, CertificateMessage, DescribeCertificatesError, Credentials | HttpClient.HttpClient, Certificate>;
export type DescribeDBCapacityReservationsError = DBCapacityReservationNotFoundFault | CommonErrors;
/**
 * Describes one or more DB capacity reservations. A DB capacity reservation reserves capacity for Amazon RDS DB instances in one or more Availability Zones.
 *
 * If you don't specify a `DBCapacityReservationIdentifier`, this operation returns information about all DB capacity reservations for your Amazon Web Services account.
 *
 * This operation supports pagination.
 */
export declare const describeDBCapacityReservations: API.PaginatedOperationMethod<DescribeDBCapacityReservationsRequest & RegionInput, DescribeDBCapacityReservationsResponse, DescribeDBCapacityReservationsError, Credentials | HttpClient.HttpClient, DBCapacityReservation>;
export type DescribeDBClusterAutomatedBackupsError = DBClusterAutomatedBackupNotFoundFault | CommonErrors;
/**
 * Displays backups for both current and deleted DB clusters. For example, use this operation to find details about automated backups for previously deleted clusters. Current clusters are returned for both the `DescribeDBClusterAutomatedBackups` and `DescribeDBClusters` operations.
 *
 * All parameters are optional.
 */
export declare const describeDBClusterAutomatedBackups: API.PaginatedOperationMethod<DescribeDBClusterAutomatedBackupsMessage & RegionInput, DBClusterAutomatedBackupMessage, DescribeDBClusterAutomatedBackupsError, Credentials | HttpClient.HttpClient, DBClusterAutomatedBackup>;
export type DescribeDBClusterBacktracksError = DBClusterBacktrackNotFoundFault | DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about backtracks for a DB cluster.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This action only applies to Aurora MySQL DB clusters.
 */
export declare const describeDBClusterBacktracks: API.PaginatedOperationMethod<DescribeDBClusterBacktracksMessage & RegionInput, DBClusterBacktrackMessage, DescribeDBClusterBacktracksError, Credentials | HttpClient.HttpClient, DBClusterBacktrack>;
export type DescribeDBClusterEndpointsError = DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about endpoints for an Amazon Aurora DB cluster.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const describeDBClusterEndpoints: API.PaginatedOperationMethod<DescribeDBClusterEndpointsMessage & RegionInput, DBClusterEndpointMessage, DescribeDBClusterEndpointsError, Credentials | HttpClient.HttpClient, DBClusterEndpoint>;
export type DescribeDBClusterParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBClusterParameterGroup` descriptions. If a `DBClusterParameterGroupName` parameter is specified, the list will contain only the description of the specified DB cluster parameter group.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterParameterGroups: API.PaginatedOperationMethod<DescribeDBClusterParameterGroupsMessage & RegionInput, DBClusterParameterGroupsMessage, DescribeDBClusterParameterGroupsError, Credentials | HttpClient.HttpClient, DBClusterParameterGroup>;
export type DescribeDBClusterParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular DB cluster parameter group.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterParameters: API.PaginatedOperationMethod<DescribeDBClusterParametersMessage & RegionInput, DBClusterParameterGroupDetails, DescribeDBClusterParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBClustersError = DBClusterNotFoundFault | CommonErrors;
/**
 * Describes existing Amazon Aurora DB clusters and Multi-AZ DB clusters. This API supports pagination.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 *
 * This operation can also return information for Amazon Neptune DB instances and Amazon DocumentDB instances.
 */
export declare const describeDBClusters: API.PaginatedOperationMethod<DescribeDBClustersMessage & RegionInput, DBClusterMessage, DescribeDBClustersError, Credentials | HttpClient.HttpClient, DBCluster>;
export type DescribeDBClusterSnapshotAttributesError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of DB cluster snapshot attribute names and values for a manual DB cluster snapshot.
 *
 * When sharing snapshots with other Amazon Web Services accounts, `DescribeDBClusterSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual DB cluster snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual DB cluster snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 *
 * To add or remove access for an Amazon Web Services account to copy or restore a manual DB cluster snapshot, or to make the manual DB cluster snapshot public or private, use the `ModifyDBClusterSnapshotAttribute` API action.
 */
export declare const describeDBClusterSnapshotAttributes: API.OperationMethod<DescribeDBClusterSnapshotAttributesMessage & RegionInput, DescribeDBClusterSnapshotAttributesResult, DescribeDBClusterSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBClusterSnapshotsError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about DB cluster snapshots. This API action supports pagination.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const describeDBClusterSnapshots: API.PaginatedOperationMethod<DescribeDBClusterSnapshotsMessage & RegionInput, DBClusterSnapshotMessage, DescribeDBClusterSnapshotsError, Credentials | HttpClient.HttpClient, DBClusterSnapshot>;
export type DescribeDBEngineVersionsError = InvalidParameterCombination | CommonErrors;
/**
 * Describes the properties of specific versions of DB engines.
 */
export declare const describeDBEngineVersions: API.PaginatedOperationMethod<DescribeDBEngineVersionsMessage & RegionInput, DBEngineVersionMessage, DescribeDBEngineVersionsError, Credentials | HttpClient.HttpClient, DBEngineVersion>;
export type DescribeDBInstanceAutomatedBackupsError = DBInstanceAutomatedBackupNotFoundFault | CommonErrors;
/**
 * Displays backups for both current and deleted instances. For example, use this operation to find details about automated backups for previously deleted instances. Current instances with retention periods greater than zero (0) are returned for both the `DescribeDBInstanceAutomatedBackups` and `DescribeDBInstances` operations.
 *
 * All parameters are optional.
 */
export declare const describeDBInstanceAutomatedBackups: API.PaginatedOperationMethod<DescribeDBInstanceAutomatedBackupsMessage & RegionInput, DBInstanceAutomatedBackupMessage, DescribeDBInstanceAutomatedBackupsError, Credentials | HttpClient.HttpClient, DBInstanceAutomatedBackup>;
export type DescribeDBInstancesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Describes provisioned RDS instances. This API supports pagination.
 *
 * This operation can also return information for Amazon Neptune DB instances and Amazon DocumentDB instances.
 */
export declare const describeDBInstances: API.PaginatedOperationMethod<DescribeDBInstancesMessage & RegionInput, DBInstanceMessage, DescribeDBInstancesError, Credentials | HttpClient.HttpClient, DBInstance>;
export type DescribeDBLogFilesError = DBInstanceNotFoundFault | DBInstanceNotReadyFault | CommonErrors;
/**
 * Returns a list of DB log files for the DB instance.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const describeDBLogFiles: API.PaginatedOperationMethod<DescribeDBLogFilesMessage & RegionInput, DescribeDBLogFilesResponse, DescribeDBLogFilesError, Credentials | HttpClient.HttpClient, DescribeDBLogFilesDetails>;
export type DescribeDBMajorEngineVersionsError = CommonErrors;
/**
 * Describes the properties of specific major versions of DB engines.
 */
export declare const describeDBMajorEngineVersions: API.PaginatedOperationMethod<DescribeDBMajorEngineVersionsRequest & RegionInput, DescribeDBMajorEngineVersionsResponse, DescribeDBMajorEngineVersionsError, Credentials | HttpClient.HttpClient, DBMajorEngineVersion>;
export type DescribeDBParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBParameterGroup` descriptions. If a `DBParameterGroupName` is specified, the list will contain only the description of the specified DB parameter group.
 */
export declare const describeDBParameterGroups: API.PaginatedOperationMethod<DescribeDBParameterGroupsMessage & RegionInput, DBParameterGroupsMessage, DescribeDBParameterGroupsError, Credentials | HttpClient.HttpClient, DBParameterGroup>;
export type DescribeDBParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular DB parameter group.
 */
export declare const describeDBParameters: API.PaginatedOperationMethod<DescribeDBParametersMessage & RegionInput, DBParameterGroupDetails, DescribeDBParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBProxiesError = DBProxyNotFoundFault | CommonErrors;
/**
 * Returns information about DB proxies.
 */
export declare const describeDBProxies: API.PaginatedOperationMethod<DescribeDBProxiesRequest & RegionInput, DescribeDBProxiesResponse, DescribeDBProxiesError, Credentials | HttpClient.HttpClient, DBProxy>;
export type DescribeDBProxyEndpointsError = DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | CommonErrors;
/**
 * Returns information about DB proxy endpoints.
 */
export declare const describeDBProxyEndpoints: API.PaginatedOperationMethod<DescribeDBProxyEndpointsRequest & RegionInput, DescribeDBProxyEndpointsResponse, DescribeDBProxyEndpointsError, Credentials | HttpClient.HttpClient, DBProxyEndpoint>;
export type DescribeDBProxyTargetGroupsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Returns information about DB proxy target groups, represented by `DBProxyTargetGroup` data structures.
 */
export declare const describeDBProxyTargetGroups: API.PaginatedOperationMethod<DescribeDBProxyTargetGroupsRequest & RegionInput, DescribeDBProxyTargetGroupsResponse, DescribeDBProxyTargetGroupsError, Credentials | HttpClient.HttpClient, DBProxyTargetGroup>;
export type DescribeDBProxyTargetsError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBProxyTargetNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Returns information about `DBProxyTarget` objects. This API supports pagination.
 */
export declare const describeDBProxyTargets: API.PaginatedOperationMethod<DescribeDBProxyTargetsRequest & RegionInput, DescribeDBProxyTargetsResponse, DescribeDBProxyTargetsError, Credentials | HttpClient.HttpClient, DBProxyTarget>;
export type DescribeDBRecommendationsError = CommonErrors;
/**
 * Describes the recommendations to resolve the issues for your DB instances, DB clusters, and DB parameter groups.
 */
export declare const describeDBRecommendations: API.PaginatedOperationMethod<DescribeDBRecommendationsMessage & RegionInput, DBRecommendationsMessage, DescribeDBRecommendationsError, Credentials | HttpClient.HttpClient, DBRecommendation>;
export type DescribeDBSecurityGroupsError = DBSecurityGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBSecurityGroup` descriptions. If a `DBSecurityGroupName` is specified, the list will contain only the descriptions of the specified DB security group.
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const describeDBSecurityGroups: API.PaginatedOperationMethod<DescribeDBSecurityGroupsMessage & RegionInput, DBSecurityGroupMessage, DescribeDBSecurityGroupsError, Credentials | HttpClient.HttpClient, DBSecurityGroup>;
export type DescribeDBShardGroupsError = DBClusterNotFoundFault | DBShardGroupNotFoundFault | CommonErrors;
/**
 * Describes existing Aurora Limitless Database DB shard groups.
 */
export declare const describeDBShardGroups: API.OperationMethod<DescribeDBShardGroupsMessage & RegionInput, DescribeDBShardGroupsResponse, DescribeDBShardGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeDBSnapshotAttributesError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of DB snapshot attribute names and values for a manual DB snapshot.
 *
 * When sharing snapshots with other Amazon Web Services accounts, `DescribeDBSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual DB snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual DB snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 *
 * To add or remove access for an Amazon Web Services account to copy or restore a manual DB snapshot, or to make the manual DB snapshot public or private, use the `ModifyDBSnapshotAttribute` API action.
 */
export declare const describeDBSnapshotAttributes: API.OperationMethod<DescribeDBSnapshotAttributesMessage & RegionInput, DescribeDBSnapshotAttributesResult, DescribeDBSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBSnapshotsError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about DB snapshots. This API action supports pagination.
 */
export declare const describeDBSnapshots: API.PaginatedOperationMethod<DescribeDBSnapshotsMessage & RegionInput, DBSnapshotMessage, DescribeDBSnapshotsError, Credentials | HttpClient.HttpClient, DBSnapshot>;
export type DescribeDBSnapshotTenantDatabasesError = DBSnapshotNotFoundFault | CommonErrors;
/**
 * Describes the tenant databases that exist in a DB snapshot. This command only applies to RDS for Oracle DB instances in the multi-tenant configuration.
 *
 * You can use this command to inspect the tenant databases within a snapshot before restoring it. You can't directly interact with the tenant databases in a DB snapshot. If you restore a snapshot that was taken from DB instance using the multi-tenant configuration, you restore all its tenant databases.
 */
export declare const describeDBSnapshotTenantDatabases: API.PaginatedOperationMethod<DescribeDBSnapshotTenantDatabasesMessage & RegionInput, DBSnapshotTenantDatabasesMessage, DescribeDBSnapshotTenantDatabasesError, Credentials | HttpClient.HttpClient, DBSnapshotTenantDatabase>;
export type DescribeDBSubnetGroupsError = DBSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of DBSubnetGroup descriptions. If a DBSubnetGroupName is specified, the list will contain only the descriptions of the specified DBSubnetGroup.
 *
 * For an overview of CIDR ranges, go to the Wikipedia Tutorial.
 */
export declare const describeDBSubnetGroups: API.PaginatedOperationMethod<DescribeDBSubnetGroupsMessage & RegionInput, DBSubnetGroupMessage, DescribeDBSubnetGroupsError, Credentials | HttpClient.HttpClient, DBSubnetGroup>;
export type DescribeEngineDefaultClusterParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the cluster database engine.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 */
export declare const describeEngineDefaultClusterParameters: API.PaginatedOperationMethod<DescribeEngineDefaultClusterParametersMessage & RegionInput, DescribeEngineDefaultClusterParametersResult, DescribeEngineDefaultClusterParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEngineDefaultParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the specified database engine.
 */
export declare const describeEngineDefaultParameters: API.PaginatedOperationMethod<DescribeEngineDefaultParametersMessage & RegionInput, DescribeEngineDefaultParametersResult, DescribeEngineDefaultParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Displays a list of categories for all event source types, or, if specified, for a specified source type. You can also see this list in the "Amazon RDS event categories and event messages" section of the *Amazon RDS User Guide* or the *Amazon Aurora User Guide* .
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage & RegionInput, EventCategoriesMessage, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns events related to DB instances, DB clusters, DB parameter groups, DB security groups, DB snapshots, DB cluster snapshots, and RDS Proxies for the past 14 days. Events specific to a particular DB instance, DB cluster, DB parameter group, DB security group, DB snapshot, DB cluster snapshot group, or RDS Proxy can be obtained by providing the name as a parameter.
 *
 * For more information on working with events, see Monitoring Amazon RDS events in the *Amazon RDS User Guide* and Monitoring Amazon Aurora events in the *Amazon Aurora User Guide*.
 *
 * By default, RDS returns events that were generated in the past hour.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage & RegionInput, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventSubscriptionsError = SubscriptionNotFoundFault | CommonErrors;
/**
 * Lists all the subscription descriptions for a customer account. The description for a subscription includes `SubscriptionName`, `SNSTopicARN`, `CustomerID`, `SourceType`, `SourceID`, `CreationTime`, and `Status`.
 *
 * If you specify a `SubscriptionName`, lists the description for that subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage & RegionInput, EventSubscriptionsMessage, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, EventSubscription>;
export type DescribeExportTasksError = ExportTaskNotFoundFault | CommonErrors;
/**
 * Returns information about a snapshot or cluster export to Amazon S3. This API operation supports pagination.
 */
export declare const describeExportTasks: API.PaginatedOperationMethod<DescribeExportTasksMessage & RegionInput, ExportTasksMessage, DescribeExportTasksError, Credentials | HttpClient.HttpClient, ExportTask>;
export type DescribeGlobalClustersError = GlobalClusterNotFoundFault | CommonErrors;
/**
 * Returns information about Aurora global database clusters. This API supports pagination.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This action only applies to Aurora DB clusters.
 */
export declare const describeGlobalClusters: API.PaginatedOperationMethod<DescribeGlobalClustersMessage & RegionInput, GlobalClustersMessage, DescribeGlobalClustersError, Credentials | HttpClient.HttpClient, GlobalCluster>;
export type DescribeIntegrationsError = IntegrationNotFoundFault | CommonErrors;
/**
 * Describe one or more zero-ETL integrations with Amazon Redshift.
 */
export declare const describeIntegrations: API.PaginatedOperationMethod<DescribeIntegrationsMessage & RegionInput, DescribeIntegrationsResponse, DescribeIntegrationsError, Credentials | HttpClient.HttpClient, Integration>;
export type DescribeOptionGroupOptionsError = CommonErrors;
/**
 * Describes all available options for the specified engine.
 */
export declare const describeOptionGroupOptions: API.PaginatedOperationMethod<DescribeOptionGroupOptionsMessage & RegionInput, OptionGroupOptionsMessage, DescribeOptionGroupOptionsError, Credentials | HttpClient.HttpClient, OptionGroupOption>;
export type DescribeOptionGroupsError = OptionGroupNotFoundFault | CommonErrors;
/**
 * Describes the available option groups.
 */
export declare const describeOptionGroups: API.PaginatedOperationMethod<DescribeOptionGroupsMessage & RegionInput, OptionGroups, DescribeOptionGroupsError, Credentials | HttpClient.HttpClient, OptionGroup>;
export type DescribeOrderableDBInstanceOptionsError = CommonErrors;
/**
 * Describes the orderable DB instance options for a specified DB engine.
 */
export declare const describeOrderableDBInstanceOptions: API.PaginatedOperationMethod<DescribeOrderableDBInstanceOptionsMessage & RegionInput, OrderableDBInstanceOptionsMessage, DescribeOrderableDBInstanceOptionsError, Credentials | HttpClient.HttpClient, OrderableDBInstanceOption>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of resources (for example, DB instances) that have at least one pending maintenance action.
 *
 * This API follows an eventual consistency model. This means that the result of the `DescribePendingMaintenanceActions` command might not be immediately visible to all subsequent RDS commands. Keep this in mind when you use `DescribePendingMaintenanceActions` immediately after using a previous API command such as `ApplyPendingMaintenanceActions`.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage & RegionInput, PendingMaintenanceActionsMessage, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, ResourcePendingMaintenanceActions>;
export type DescribeReservedDBInstancesError = ReservedDBInstanceNotFoundFault | CommonErrors;
/**
 * Returns information about reserved DB instances for this account, or about a specified reserved DB instance.
 */
export declare const describeReservedDBInstances: API.PaginatedOperationMethod<DescribeReservedDBInstancesMessage & RegionInput, ReservedDBInstanceMessage, DescribeReservedDBInstancesError, Credentials | HttpClient.HttpClient, ReservedDBInstance>;
export type DescribeReservedDBInstancesOfferingsError = ReservedDBInstancesOfferingNotFoundFault | CommonErrors;
/**
 * Lists available reserved DB instance offerings.
 */
export declare const describeReservedDBInstancesOfferings: API.PaginatedOperationMethod<DescribeReservedDBInstancesOfferingsMessage & RegionInput, ReservedDBInstancesOfferingMessage, DescribeReservedDBInstancesOfferingsError, Credentials | HttpClient.HttpClient, ReservedDBInstancesOffering>;
export type DescribeServerlessV2PlatformVersionsError = CommonErrors;
/**
 * Describes the properties of specific platform versions for Aurora Serverless v2.
 */
export declare const describeServerlessV2PlatformVersions: API.PaginatedOperationMethod<DescribeServerlessV2PlatformVersionsMessage & RegionInput, ServerlessV2PlatformVersionsMessage, DescribeServerlessV2PlatformVersionsError, Credentials | HttpClient.HttpClient, ServerlessV2PlatformVersionInfo>;
export type DescribeSourceRegionsError = CommonErrors;
/**
 * Returns a list of the source Amazon Web Services Regions where the current Amazon Web Services Region can create a read replica, copy a DB snapshot from, or replicate automated backups from.
 *
 * Use this operation to determine whether cross-Region features are supported between other Regions and your current Region. This operation supports pagination.
 *
 * To return information about the Regions that are enabled for your account, or all Regions, use the EC2 operation `DescribeRegions`. For more information, see DescribeRegions in the *Amazon EC2 API Reference*.
 */
export declare const describeSourceRegions: API.PaginatedOperationMethod<DescribeSourceRegionsMessage & RegionInput, SourceRegionMessage, DescribeSourceRegionsError, Credentials | HttpClient.HttpClient, SourceRegion>;
export type DescribeTenantDatabasesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Describes the tenant databases in a DB instance that uses the multi-tenant configuration. Only RDS for Oracle CDB instances are supported.
 */
export declare const describeTenantDatabases: API.PaginatedOperationMethod<DescribeTenantDatabasesMessage & RegionInput, TenantDatabasesMessage, DescribeTenantDatabasesError, Credentials | HttpClient.HttpClient, TenantDatabase>;
export type DescribeValidDBInstanceModificationsError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You can call `DescribeValidDBInstanceModifications` to learn what modifications you can make to your DB instance. You can use this information when you call `ModifyDBInstance`.
 *
 * This command doesn't apply to RDS Custom.
 */
export declare const describeValidDBInstanceModifications: API.OperationMethod<DescribeValidDBInstanceModificationsMessage & RegionInput, DescribeValidDBInstanceModificationsResult, DescribeValidDBInstanceModificationsError, Credentials | HttpClient.HttpClient>;
export type DisableHttpEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Disables the HTTP endpoint for the specified DB cluster. Disabling this endpoint disables RDS Data API.
 *
 * For more information, see Using RDS Data API in the *Amazon Aurora User Guide*.
 *
 * This operation applies only to Aurora Serverless v2 and provisioned DB clusters. To disable the HTTP endpoint for Aurora Serverless v1 DB clusters, use the `EnableHttpEndpoint` parameter of the `ModifyDBCluster` operation.
 */
export declare const disableHttpEndpoint: API.OperationMethod<DisableHttpEndpointRequest & RegionInput, DisableHttpEndpointResponse, DisableHttpEndpointError, Credentials | HttpClient.HttpClient>;
export type DownloadDBLogFilePortionError = DBInstanceNotFoundFault | DBInstanceNotReadyFault | DBLogFileNotFoundFault | CommonErrors;
/**
 * Downloads all or a portion of the specified log file, up to 1 MB in size.
 *
 * This command doesn't apply to RDS Custom.
 *
 * This operation uses resources on database instances. Because of this, we recommend publishing database logs to CloudWatch and then using the GetLogEvents operation. For more information, see GetLogEvents in the *Amazon CloudWatch Logs API Reference*.
 */
export declare const downloadDBLogFilePortion: API.PaginatedOperationMethod<DownloadDBLogFilePortionMessage & RegionInput, DownloadDBLogFilePortionDetails, DownloadDBLogFilePortionError, Credentials | HttpClient.HttpClient, unknown>;
export type EnableHttpEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Enables the HTTP endpoint for the DB cluster. By default, the HTTP endpoint isn't enabled.
 *
 * When enabled, this endpoint provides a connectionless web service API (RDS Data API) for running SQL queries on the Aurora DB cluster. You can also query your database from inside the RDS console with the RDS query editor.
 *
 * For more information, see Using RDS Data API in the *Amazon Aurora User Guide*.
 *
 * This operation applies only to Aurora Serverless v2 and provisioned DB clusters. To enable the HTTP endpoint for Aurora Serverless v1 DB clusters, use the `EnableHttpEndpoint` parameter of the `ModifyDBCluster` operation.
 */
export declare const enableHttpEndpoint: API.OperationMethod<EnableHttpEndpointRequest & RegionInput, EnableHttpEndpointResponse, EnableHttpEndpointError, Credentials | HttpClient.HttpClient>;
export type FailoverDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Forces a failover for a DB cluster.
 *
 * For an Aurora DB cluster, failover for a DB cluster promotes one of the Aurora Replicas (read-only instances) in the DB cluster to be the primary DB instance (the cluster writer).
 *
 * For a Multi-AZ DB cluster, after RDS terminates the primary DB instance, the internal monitoring system detects that the primary DB instance is unhealthy and promotes a readable standby (read-only instances) in the DB cluster to be the primary DB instance (the cluster writer). Failover times are typically less than 35 seconds.
 *
 * An Amazon Aurora DB cluster automatically fails over to an Aurora Replica, if one exists, when the primary DB instance fails. A Multi-AZ DB cluster automatically fails over to a readable standby DB instance when the primary DB instance fails.
 *
 * To simulate a failure of a primary instance for testing, you can force a failover. Because each instance in a DB cluster has its own endpoint address, make sure to clean up and re-establish any existing connections that use those endpoint addresses when the failover is complete.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const failoverDBCluster: API.OperationMethod<FailoverDBClusterMessage & RegionInput, FailoverDBClusterResult, FailoverDBClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Promotes the specified secondary DB cluster to be the primary DB cluster in the global database cluster to fail over or switch over a global database. Switchover operations were previously called "managed planned failovers."
 *
 * Although this operation can be used either to fail over or to switch over a global database cluster, its intended use is for global database failover. To switch over a global database cluster, we recommend that you use the SwitchoverGlobalCluster operation instead.
 *
 * How you use this operation depends on whether you are failing over or switching over your global database cluster:
 *
 * - Failing over - Specify the `AllowDataLoss` parameter and don't specify the `Switchover` parameter.
 *
 * - Switching over - Specify the `Switchover` parameter or omit it, but don't specify the `AllowDataLoss` parameter.
 *
 * **About failing over and switching over**
 *
 * While failing over and switching over a global database cluster both change the primary DB cluster, you use these operations for different reasons:
 *
 * - *Failing over* - Use this operation to respond to an unplanned event, such as a Regional disaster in the primary Region. Failing over can result in a loss of write transaction data that wasn't replicated to the chosen secondary before the failover event occurred. However, the recovery process that promotes a DB instance on the chosen seconday DB cluster to be the primary writer DB instance guarantees that the data is in a transactionally consistent state.
 *
 * For more information about failing over an Amazon Aurora global database, see Performing managed failovers for Aurora global databases in the *Amazon Aurora User Guide*.
 *
 * - *Switching over* - Use this operation on a healthy global database cluster for planned events, such as Regional rotation or to fail back to the original primary DB cluster after a failover operation. With this operation, there is no data loss.
 *
 * For more information about switching over an Amazon Aurora global database, see Performing switchovers for Aurora global databases in the *Amazon Aurora User Guide*.
 */
export declare const failoverGlobalCluster: API.OperationMethod<FailoverGlobalClusterMessage & RegionInput, FailoverGlobalClusterResult, FailoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BlueGreenDeploymentNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Lists all tags on an Amazon RDS resource.
 *
 * For an overview on tagging an Amazon RDS resource, see Tagging Amazon RDS Resources in the *Amazon RDS User Guide* or Tagging Amazon Aurora and Amazon RDS Resources in the *Amazon Aurora User Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage & RegionInput, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyActivityStreamError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Changes the audit policy state of a database activity stream to either locked (default) or unlocked. A locked policy is read-only, whereas an unlocked policy is read/write. If your activity stream is started and locked, you can unlock it, customize your audit policy, and then lock your activity stream. Restarting the activity stream isn't required. For more information, see Modifying a database activity stream in the *Amazon RDS User Guide*.
 *
 * This operation is supported for RDS for Oracle and Microsoft SQL Server.
 */
export declare const modifyActivityStream: API.OperationMethod<ModifyActivityStreamRequest & RegionInput, ModifyActivityStreamResponse, ModifyActivityStreamError, Credentials | HttpClient.HttpClient>;
export type ModifyCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Override the system-default Secure Sockets Layer/Transport Layer Security (SSL/TLS) certificate for Amazon RDS for new DB instances, or remove the override.
 *
 * By using this operation, you can specify an RDS-approved SSL/TLS certificate for new DB instances that is different from the default certificate provided by RDS. You can also use this operation to remove the override, so that new DB instances use the default certificate provided by RDS.
 *
 * You might need to override the default certificate in the following situations:
 *
 * - You already migrated your applications to support the latest certificate authority (CA) certificate, but the new CA certificate is not yet the RDS default CA certificate for the specified Amazon Web Services Region.
 *
 * - RDS has already moved to a new default CA certificate for the specified Amazon Web Services Region, but you are still in the process of supporting the new CA certificate. In this case, you temporarily need additional time to finish your application changes.
 *
 * For more information about rotating your SSL/TLS certificate for RDS DB engines, see Rotating Your SSL/TLS Certificate in the *Amazon RDS User Guide*.
 *
 * For more information about rotating your SSL/TLS certificate for Aurora DB engines, see Rotating Your SSL/TLS Certificate in the *Amazon Aurora User Guide*.
 */
export declare const modifyCertificates: API.OperationMethod<ModifyCertificatesMessage & RegionInput, ModifyCertificatesResult, ModifyCertificatesError, Credentials | HttpClient.HttpClient>;
export type ModifyCurrentDBClusterCapacityError = DBClusterNotFoundFault | InvalidDBClusterCapacityFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Set the capacity of an Aurora Serverless v1 DB cluster to a specific value.
 *
 * Aurora Serverless v1 scales seamlessly based on the workload on the DB cluster. In some cases, the capacity might not scale fast enough to meet a sudden change in workload, such as a large number of new transactions. Call `ModifyCurrentDBClusterCapacity` to set the capacity explicitly.
 *
 * After this call sets the DB cluster capacity, Aurora Serverless v1 can automatically scale the DB cluster based on the cooldown period for scaling up and the cooldown period for scaling down.
 *
 * For more information about Aurora Serverless v1, see Using Amazon Aurora Serverless v1 in the *Amazon Aurora User Guide*.
 *
 * If you call `ModifyCurrentDBClusterCapacity` with the default `TimeoutAction`, connections that prevent Aurora Serverless v1 from finding a scaling point might be dropped. For more information about scaling points, see Autoscaling for Aurora Serverless v1 in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora Serverless v1 DB clusters.
 */
export declare const modifyCurrentDBClusterCapacity: API.OperationMethod<ModifyCurrentDBClusterCapacityMessage & RegionInput, DBClusterCapacityInfo, ModifyCurrentDBClusterCapacityError, Credentials | HttpClient.HttpClient>;
export type ModifyCustomDBEngineVersionError = CustomDBEngineVersionNotFoundFault | InvalidCustomDBEngineVersionStateFault | CommonErrors;
/**
 * Modifies the status of a custom engine version (CEV). You can find CEVs to modify by calling `DescribeDBEngineVersions`.
 *
 * The MediaImport service that imports files from Amazon S3 to create CEVs isn't integrated with Amazon Web Services CloudTrail. If you turn on data logging for Amazon RDS in CloudTrail, calls to the `ModifyCustomDbEngineVersion` event aren't logged. However, you might see calls from the API gateway that accesses your Amazon S3 bucket. These calls originate from the MediaImport service for the `ModifyCustomDbEngineVersion` event.
 *
 * For more information, see Modifying CEV status in the *Amazon RDS User Guide*.
 */
export declare const modifyCustomDBEngineVersion: API.OperationMethod<ModifyCustomDBEngineVersionMessage & RegionInput, DBEngineVersion, ModifyCustomDBEngineVersionError, Credentials | HttpClient.HttpClient>;
export type ModifyDBCapacityReservationError = DBCapacityReservationNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | CommonErrors;
/**
 * Modifies a DB capacity reservation. You can change the reserved capacity in each Availability Zone of the reservation, and you can change the end date of the reservation. You can't change the Availability Zones of an existing reservation.
 *
 * The reservation must be in the `active` state. A future-dated reservation that hasn't started isn't modifiable, and neither is a reservation that Amazon RDS is already modifying.
 *
 * You must specify `CapacityPerAvailabilityZone`, `EndDateType`, or `EndDate`. A request that specifies none of the three changes nothing, and Amazon RDS rejects it.
 */
export declare const modifyDBCapacityReservation: API.OperationMethod<ModifyDBCapacityReservationRequest & RegionInput, ModifyDBCapacityReservationResponse, ModifyDBCapacityReservationError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotAvailableFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Modifies the settings of an Amazon Aurora DB cluster or a Multi-AZ DB cluster. You can change one or more settings by specifying these parameters and the new values in the request.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide*.
 */
export declare const modifyDBCluster: API.OperationMethod<ModifyDBClusterMessage & RegionInput, ModifyDBClusterResult, ModifyDBClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterEndpointError = DBClusterEndpointNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Modifies the properties of an endpoint in an Amazon Aurora DB cluster.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const modifyDBClusterEndpoint: API.OperationMethod<ModifyDBClusterEndpointMessage & RegionInput, DBClusterEndpoint, ModifyDBClusterEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB cluster parameter group. To modify more than one parameter, submit a list of the following: `ParameterName`, `ParameterValue`, and `ApplyMethod`. A maximum of 20 parameters can be modified in a single request.
 *
 * There are two types of parameters - dynamic parameters and static parameters. Changes to dynamic parameters are applied to the DB cluster immediately without a reboot. Changes to static parameters are applied only after the DB cluster is rebooted, which can be done using `RebootDBCluster` operation. You can use the *Parameter Groups* option of the Amazon RDS console or the `DescribeDBClusterParameters` operation to verify that your DB cluster parameter group has been created or modified.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const modifyDBClusterParameterGroup: API.OperationMethod<ModifyDBClusterParameterGroupMessage & RegionInput, DBClusterParameterGroupNameMessage, ModifyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterSnapshotAttributeError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual DB cluster snapshot.
 *
 * To share a manual DB cluster snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName` and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual DB cluster snapshot. Use the value `all` to make the manual DB cluster snapshot public, which means that it can be copied or restored by all Amazon Web Services accounts.
 *
 * Don't add the `all` value for any manual DB cluster snapshots that contain private information that you don't want available to all Amazon Web Services accounts.
 *
 * If a manual DB cluster snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 *
 * To view which Amazon Web Services accounts have access to copy or restore a manual DB cluster snapshot, or whether a manual DB cluster snapshot is public or private, use the DescribeDBClusterSnapshotAttributes API operation. The accounts are returned as values for the `restore` attribute.
 */
export declare const modifyDBClusterSnapshotAttribute: API.OperationMethod<ModifyDBClusterSnapshotAttributeMessage & RegionInput, ModifyDBClusterSnapshotAttributeResult, ModifyDBClusterSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBInstanceError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBUpgradeDependencyFailureFault | DomainNotFoundFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | InvalidParameterCombination | InvalidParameterValue | CommonErrors;
/**
 * Modifies settings for a DB instance. You can change one or more database configuration parameters by specifying these parameters and the new values in the request. To learn what modifications you can make to your DB instance, call `DescribeValidDBInstanceModifications` before you call `ModifyDBInstance`.
 */
export declare const modifyDBInstance: API.OperationMethod<ModifyDBInstanceMessage & RegionInput, ModifyDBInstanceResult, ModifyDBInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB parameter group. To modify more than one parameter, submit a list of the following: `ParameterName`, `ParameterValue`, and `ApplyMethod`. A maximum of 20 parameters can be modified in a single request.
 *
 * After you modify a DB parameter group, you should wait at least 5 minutes before creating your first DB instance that uses that DB parameter group as the default parameter group. This allows Amazon RDS to fully complete the modify operation before the parameter group is used as the default for a new DB instance. This is especially important for parameters that are critical when creating the default database for a DB instance, such as the character set for the default database defined by the `character_set_database` parameter. You can use the *Parameter Groups* option of the Amazon RDS console or the *DescribeDBParameters* command to verify that your DB parameter group has been created or modified.
 */
export declare const modifyDBParameterGroup: API.OperationMethod<ModifyDBParameterGroupMessage & RegionInput, DBParameterGroupNameMessage, ModifyDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyError = DBProxyAlreadyExistsFault | DBProxyNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Changes the settings for an existing DB proxy.
 */
export declare const modifyDBProxy: API.OperationMethod<ModifyDBProxyRequest & RegionInput, ModifyDBProxyResponse, ModifyDBProxyError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyEndpointError = DBProxyEndpointAlreadyExistsFault | DBProxyEndpointNotFoundFault | InvalidDBProxyEndpointStateFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Changes the settings for an existing DB proxy endpoint.
 */
export declare const modifyDBProxyEndpoint: API.OperationMethod<ModifyDBProxyEndpointRequest & RegionInput, ModifyDBProxyEndpointResponse, ModifyDBProxyEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyDBProxyTargetGroupError = DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Modifies the properties of a `DBProxyTargetGroup`.
 */
export declare const modifyDBProxyTargetGroup: API.OperationMethod<ModifyDBProxyTargetGroupRequest & RegionInput, ModifyDBProxyTargetGroupResponse, ModifyDBProxyTargetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBRecommendationError = CommonErrors;
/**
 * Updates the recommendation status and recommended action status for the specified recommendation.
 */
export declare const modifyDBRecommendation: API.OperationMethod<ModifyDBRecommendationMessage & RegionInput, DBRecommendationMessage, ModifyDBRecommendationError, Credentials | HttpClient.HttpClient>;
export type ModifyDBShardGroupError = DBShardGroupAlreadyExistsFault | DBShardGroupNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Modifies the settings of an Aurora Limitless Database DB shard group. You can change one or more settings by specifying these parameters and the new values in the request.
 */
export declare const modifyDBShardGroup: API.OperationMethod<ModifyDBShardGroupMessage & RegionInput, DBShardGroup, ModifyDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSnapshotError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Updates a manual DB snapshot with a new engine version. The snapshot can be encrypted or unencrypted, but not shared or public.
 *
 * Amazon RDS supports upgrading DB snapshots for MariaDB, MySQL, PostgreSQL, and Oracle. This operation doesn't apply to RDS Custom or RDS for Db2.
 */
export declare const modifyDBSnapshot: API.OperationMethod<ModifyDBSnapshotMessage & RegionInput, ModifyDBSnapshotResult, ModifyDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSnapshotAttributeError = DBSnapshotNotFoundFault | InvalidDBSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual DB snapshot.
 *
 * To share a manual DB snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName` and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual DB snapshot. Uses the value `all` to make the manual DB snapshot public, which means it can be copied or restored by all Amazon Web Services accounts.
 *
 * Don't add the `all` value for any manual DB snapshots that contain private information that you don't want available to all Amazon Web Services accounts.
 *
 * If the manual DB snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 *
 * To view which Amazon Web Services accounts have access to copy or restore a manual DB snapshot, or whether a manual DB snapshot public or private, use the DescribeDBSnapshotAttributes API operation. The accounts are returned as values for the `restore` attribute.
 */
export declare const modifyDBSnapshotAttribute: API.OperationMethod<ModifyDBSnapshotAttributeMessage & RegionInput, ModifyDBSnapshotAttributeResult, ModifyDBSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSubnetGroupError = DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DBSubnetQuotaExceededFault | InvalidDBSubnetGroupStateFault | InvalidSubnet | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies an existing DB subnet group. DB subnet groups must contain at least one subnet in at least two AZs in the Amazon Web Services Region.
 */
export declare const modifyDBSubnetGroup: API.OperationMethod<ModifyDBSubnetGroupMessage & RegionInput, ModifyDBSubnetGroupResult, ModifyDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SubscriptionCategoryNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Modifies an existing RDS event notification subscription. You can't modify the source identifiers using this call. To change source identifiers for a subscription, use the `AddSourceIdentifierToSubscription` and `RemoveSourceIdentifierFromSubscription` calls.
 *
 * You can see a list of the event categories for a given source type (`SourceType`) in Events in the *Amazon RDS User Guide* or by using the `DescribeEventCategories` operation.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage & RegionInput, ModifyEventSubscriptionResult, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalClusterError = GlobalClusterAlreadyExistsFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Modifies a setting for an Amazon Aurora global database cluster. You can change one or more database configuration parameters by specifying these parameters and the new values in the request. For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora global database clusters.
 */
export declare const modifyGlobalCluster: API.OperationMethod<ModifyGlobalClusterMessage & RegionInput, ModifyGlobalClusterResult, ModifyGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyIntegrationError = IntegrationConflictOperationFault | IntegrationNotFoundFault | InvalidIntegrationStateFault | CommonErrors;
/**
 * Modifies a zero-ETL integration with Amazon Redshift.
 */
export declare const modifyIntegration: API.OperationMethod<ModifyIntegrationMessage & RegionInput, Integration, ModifyIntegrationError, Credentials | HttpClient.HttpClient>;
export type ModifyOptionGroupError = InvalidOptionGroupStateFault | OptionGroupNotFoundFault | CommonErrors;
/**
 * Modifies an existing option group.
 */
export declare const modifyOptionGroup: API.OperationMethod<ModifyOptionGroupMessage & RegionInput, ModifyOptionGroupResult, ModifyOptionGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyTenantDatabaseError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | TenantDatabaseAlreadyExistsFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Modifies an existing tenant database in a DB instance. You can change the tenant database name or the master user password. This operation is supported only for RDS for Oracle CDB instances using the multi-tenant configuration.
 */
export declare const modifyTenantDatabase: API.OperationMethod<ModifyTenantDatabaseMessage & RegionInput, ModifyTenantDatabaseResult, ModifyTenantDatabaseError, Credentials | HttpClient.HttpClient>;
export type PromoteReadReplicaError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Promotes a read replica DB instance to a standalone DB instance.
 *
 * - Backup duration is a function of the amount of changes to the database since the previous backup. If you plan to promote a read replica to a standalone instance, we recommend that you enable backups and complete at least one backup prior to promotion. In addition, a read replica cannot be promoted to a standalone instance when it is in the `backing-up` status. If you have enabled backups on your read replica, configure the automated backup window so that daily backups do not interfere with read replica promotion.
 *
 * - This command doesn't apply to Aurora MySQL, Aurora PostgreSQL, or RDS Custom.
 */
export declare const promoteReadReplica: API.OperationMethod<PromoteReadReplicaMessage & RegionInput, PromoteReadReplicaResult, PromoteReadReplicaError, Credentials | HttpClient.HttpClient>;
export type PromoteReadReplicaDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Promotes a read replica DB cluster to a standalone DB cluster.
 */
export declare const promoteReadReplicaDBCluster: API.OperationMethod<PromoteReadReplicaDBClusterMessage & RegionInput, PromoteReadReplicaDBClusterResult, PromoteReadReplicaDBClusterError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedDBInstancesOfferingError = ReservedDBInstanceAlreadyExistsFault | ReservedDBInstanceQuotaExceededFault | ReservedDBInstancesOfferingNotFoundFault | CommonErrors;
/**
 * Purchases a reserved DB instance offering.
 */
export declare const purchaseReservedDBInstancesOffering: API.OperationMethod<PurchaseReservedDBInstancesOfferingMessage & RegionInput, PurchaseReservedDBInstancesOfferingResult, PurchaseReservedDBInstancesOfferingError, Credentials | HttpClient.HttpClient>;
export type RebootDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You might need to reboot your DB cluster, usually for maintenance reasons. For example, if you make certain modifications, or if you change the DB cluster parameter group associated with the DB cluster, reboot the DB cluster for the changes to take effect.
 *
 * Rebooting a DB cluster restarts the database engine service. Rebooting a DB cluster results in a momentary outage, during which the DB cluster status is set to rebooting.
 *
 * Use this operation only for a non-Aurora Multi-AZ DB cluster.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const rebootDBCluster: API.OperationMethod<RebootDBClusterMessage & RegionInput, RebootDBClusterResult, RebootDBClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDBInstanceError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * You might need to reboot your DB instance, usually for maintenance reasons. For example, if you make certain modifications, or if you change the DB parameter group associated with the DB instance, you must reboot the instance for the changes to take effect.
 *
 * Rebooting a DB instance restarts the database engine service. Rebooting a DB instance results in a momentary outage, during which the DB instance status is set to rebooting.
 *
 * For more information about rebooting, see Rebooting a DB Instance in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom.
 *
 * If your DB instance is part of a Multi-AZ DB cluster, you can reboot the DB cluster with the `RebootDBCluster` operation.
 */
export declare const rebootDBInstance: API.OperationMethod<RebootDBInstanceMessage & RegionInput, RebootDBInstanceResult, RebootDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RebootDBShardGroupError = DBShardGroupNotFoundFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * You might need to reboot your DB shard group, usually for maintenance reasons. For example, if you make certain modifications, reboot the DB shard group for the changes to take effect.
 *
 * This operation applies only to Aurora Limitless Database DBb shard groups.
 */
export declare const rebootDBShardGroup: API.OperationMethod<RebootDBShardGroupMessage & RegionInput, DBShardGroup, RebootDBShardGroupError, Credentials | HttpClient.HttpClient>;
export type RegisterDBProxyTargetsError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyNotFoundFault | DBProxyTargetAlreadyRegisteredFault | DBProxyTargetGroupNotFoundFault | InsufficientAvailableIPsInSubnetFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBProxyStateFault | CommonErrors;
/**
 * Associate one or more `DBProxyTarget` data structures with a `DBProxyTargetGroup`.
 */
export declare const registerDBProxyTargets: API.OperationMethod<RegisterDBProxyTargetsRequest & RegionInput, RegisterDBProxyTargetsResponse, RegisterDBProxyTargetsError, Credentials | HttpClient.HttpClient>;
export type RemoveFromGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Detaches an Aurora secondary cluster from an Aurora global database cluster. The cluster becomes a standalone cluster with read-write capability instead of being read-only and receiving data from a primary cluster in a different Region.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const removeFromGlobalCluster: API.OperationMethod<RemoveFromGlobalClusterMessage & RegionInput, RemoveFromGlobalClusterResult, RemoveFromGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveRoleFromDBClusterError = DBClusterNotFoundFault | DBClusterRoleNotFoundFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Removes the asssociation of an Amazon Web Services Identity and Access Management (IAM) role from a DB cluster.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const removeRoleFromDBCluster: API.OperationMethod<RemoveRoleFromDBClusterMessage & RegionInput, RemoveRoleFromDBClusterResponse, RemoveRoleFromDBClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveRoleFromDBInstanceError = DBInstanceNotFoundFault | DBInstanceRoleNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Disassociates an Amazon Web Services Identity and Access Management (IAM) role from a DB instance.
 */
export declare const removeRoleFromDBInstance: API.OperationMethod<RemoveRoleFromDBInstanceMessage & RegionInput, RemoveRoleFromDBInstanceResponse, RemoveRoleFromDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveSourceIdentifierFromSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Removes a source identifier from an existing RDS event notification subscription.
 */
export declare const removeSourceIdentifierFromSubscription: API.OperationMethod<RemoveSourceIdentifierFromSubscriptionMessage & RegionInput, RemoveSourceIdentifierFromSubscriptionResult, RemoveSourceIdentifierFromSubscriptionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = BlueGreenDeploymentNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBProxyEndpointNotFoundFault | DBProxyNotFoundFault | DBProxyTargetGroupNotFoundFault | DBShardGroupNotFoundFault | DBSnapshotNotFoundFault | DBSnapshotTenantDatabaseNotFoundFault | IntegrationNotFoundFault | InvalidDBClusterEndpointStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | TenantDatabaseNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an Amazon RDS resource.
 *
 * For an overview on tagging an Amazon RDS resource, see Tagging Amazon RDS Resources in the *Amazon RDS User Guide* or Tagging Amazon Aurora and Amazon RDS Resources in the *Amazon Aurora User Guide*.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage & RegionInput, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB cluster parameter group to the default value. To reset specific parameters submit a list of the following: `ParameterName` and `ApplyMethod`. To reset the entire DB cluster parameter group, specify the `DBClusterParameterGroupName` and `ResetAllParameters` parameters.
 *
 * When resetting the entire group, dynamic parameters are updated immediately and static parameters are set to `pending-reboot` to take effect on the next DB instance restart or `RebootDBInstance` request. You must call `RebootDBInstance` for every DB instance in your DB cluster that you want the updated static parameter to apply to.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const resetDBClusterParameterGroup: API.OperationMethod<ResetDBClusterParameterGroupMessage & RegionInput, DBClusterParameterGroupNameMessage, ResetDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ResetDBParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a DB parameter group to the engine/system default value. To reset specific parameters, provide a list of the following: `ParameterName` and `ApplyMethod`. To reset the entire DB parameter group, specify the `DBParameterGroup` name and `ResetAllParameters` parameters. When resetting the entire group, dynamic parameters are updated immediately and static parameters are set to `pending-reboot` to take effect on the next DB instance restart or `RebootDBInstance` request.
 */
export declare const resetDBParameterGroup: API.OperationMethod<ResetDBParameterGroupMessage & RegionInput, DBParameterGroupNameMessage, ResetDBParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromS3Error = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBSubnetGroupStateFault | InvalidS3BucketFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Creates an Amazon Aurora DB cluster from MySQL data stored in an Amazon S3 bucket. Amazon RDS must be authorized to access the Amazon S3 bucket and the data must be created using the Percona XtraBackup utility as described in Migrating Data from MySQL by Using an Amazon S3 Bucket in the *Amazon Aurora User Guide*.
 *
 * This operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterFromS3` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters. The source DB engine must be MySQL.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with the Aurora DB cluster when you restore it from Amazon S3.
 */
export declare const restoreDBClusterFromS3: API.OperationMethod<RestoreDBClusterFromS3Message & RegionInput, RestoreDBClusterFromS3Result, RestoreDBClusterFromS3Error, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromSnapshotError = DBClusterAlreadyExistsFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBInstanceStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB cluster from a DB snapshot or DB cluster snapshot.
 *
 * The target DB cluster is created from the source snapshot with a default configuration. If you don't specify a security group, the new DB cluster is associated with the default security group.
 *
 * You can use the `EnableVPCNetworking` and `EnableInternetAccessGateway` parameters together to restore an Aurora PostgreSQL cluster without VPC networking and with internet-based connectivity. These two parameters must always be specified together. Set `EnableVPCNetworking` to `false` to disable the VPC network interface (ENI) for the cluster. `EnableInternetAccessGateway` enables internet-based connectivity through an internet access gateway. IAM database authentication is required and must be enabled using `EnableIAMDatabaseAuthentication`. Once the cluster is restored, you need to modify the DB cluster to update `MasterUserAuthenticationType` to `iam-db-auth`.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster when you restore it from a snapshot.
 *
 * This operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterFromSnapshot` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const restoreDBClusterFromSnapshot: API.OperationMethod<RestoreDBClusterFromSnapshotMessage & RegionInput, RestoreDBClusterFromSnapshotResult, RestoreDBClusterFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterToPointInTimeError = DBClusterAlreadyExistsFault | DBClusterAutomatedBackupNotFoundFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBClusterRoleQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientDBInstanceCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Restores a DB cluster to an arbitrary point in time. Users can restore to any point in time before `LatestRestorableTime` for up to `BackupRetentionPeriod` days. The target DB cluster is created from the source DB cluster with the same configuration as the original DB cluster, except that the new DB cluster is created with the default DB security group. Unless the `RestoreType` is set to `copy-on-write`, the restore may occur in a different Availability Zone (AZ) from the original DB cluster. The AZ where RDS restores the DB cluster depends on the AZs in the specified subnet group.
 *
 * You can use the `EnableVPCNetworking` and `EnableInternetAccessGateway` parameters together to restore an Aurora PostgreSQL cluster without VPC networking and with internet-based connectivity. These two parameters must always be specified together. Set `EnableVPCNetworking` to `false` to disable the VPC network interface (ENI) for the cluster. `EnableInternetAccessGateway` enables internet-based connectivity through an internet access gateway. IAM database authentication is required and must be enabled using `EnableIAMDatabaseAuthentication`. Once the cluster is restored, you need to modify the DB cluster to update `MasterUserAuthenticationType` to `iam-db-auth`.
 *
 * You can use the `AssociatedRoles` parameter to associate one or more Amazon Web Services Identity and Access Management (IAM) roles with an Aurora DB cluster when you restore it to a point in time.
 *
 * For Aurora, this operation only restores the DB cluster, not the DB instances for that DB cluster. You must invoke the `CreateDBInstance` operation to create DB instances for the restored DB cluster, specifying the identifier of the restored DB cluster in `DBClusterIdentifier`. You can create DB instances only after the `RestoreDBClusterToPointInTime` operation has completed and the DB cluster is available.
 *
 * For more information on Amazon Aurora DB clusters, see What is Amazon Aurora? in the *Amazon Aurora User Guide*.
 *
 * For more information on Multi-AZ DB clusters, see Multi-AZ DB cluster deployments in the *Amazon RDS User Guide.*
 */
export declare const restoreDBClusterToPointInTime: API.OperationMethod<RestoreDBClusterToPointInTimeMessage & RegionInput, RestoreDBClusterToPointInTimeResult, RestoreDBClusterToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceFromDBSnapshotError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterSnapshotNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Creates a new DB instance from a DB snapshot. The target database is created from the source database restore point with most of the source's original configuration, including the default security group and DB parameter group. By default, the new DB instance is created as a Single-AZ deployment, except when the instance is a SQL Server instance that has an option group associated with mirroring. In this case, the instance becomes a Multi-AZ deployment, not a Single-AZ deployment.
 *
 * If you want to replace your original DB instance with the new, restored DB instance, then rename your original DB instance before you call the `RestoreDBInstanceFromDBSnapshot` operation. RDS doesn't allow two DB instances with the same name. After you have renamed your original DB instance with a different identifier, then you can pass the original name of the DB instance as the `DBInstanceIdentifier` in the call to the `RestoreDBInstanceFromDBSnapshot` operation. The result is that you replace the original DB instance with the DB instance created from the snapshot.
 *
 * If you are restoring from a shared manual DB snapshot, the `DBSnapshotIdentifier` must be the ARN of the shared DB snapshot.
 *
 * To restore from a DB snapshot with an unsupported engine version, you must first upgrade the engine version of the snapshot. For more information about upgrading a RDS for MySQL DB snapshot engine version, see Upgrading a MySQL DB snapshot engine version. For more information about upgrading a RDS for PostgreSQL DB snapshot engine version, Upgrading a PostgreSQL DB snapshot engine version.
 *
 * This command doesn't apply to Aurora MySQL and Aurora PostgreSQL. For Aurora, use `RestoreDBClusterFromSnapshot`.
 */
export declare const restoreDBInstanceFromDBSnapshot: API.OperationMethod<RestoreDBInstanceFromDBSnapshotMessage & RegionInput, RestoreDBInstanceFromDBSnapshotResult, RestoreDBInstanceFromDBSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceFromS3Error = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidS3BucketFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Amazon Relational Database Service (Amazon RDS) supports importing MySQL databases by using backup files. You can create a backup of your on-premises database, store it on Amazon Simple Storage Service (Amazon S3), and then restore the backup file onto a new Amazon RDS DB instance running MySQL. For more information, see Restoring a backup into an Amazon RDS for MySQL DB instance in the *Amazon RDS User Guide.*
 *
 * This operation doesn't apply to RDS Custom.
 */
export declare const restoreDBInstanceFromS3: API.OperationMethod<RestoreDBInstanceFromS3Message & RegionInput, RestoreDBInstanceFromS3Result, RestoreDBInstanceFromS3Error, Credentials | HttpClient.HttpClient>;
export type RestoreDBInstanceToPointInTimeError = AuthorizationNotFoundFault | BackupPolicyNotFoundFault | CertificateNotFoundFault | DBCapacityReservationNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceAutomatedBackupNotFoundFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DomainNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBInstanceStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | OptionGroupNotFoundFault | PointInTimeRestoreNotEnabledFault | ProvisionedIopsNotAvailableInAZFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | TenantDatabaseQuotaExceededFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Restores a DB instance to an arbitrary point in time. You can restore to any point in time before the time identified by the `LatestRestorableTime` property. You can restore to a point up to the number of days specified by the `BackupRetentionPeriod` property.
 *
 * The target database is created with most of the original configuration, but in a system-selected Availability Zone, with the default security group, the default subnet group, and the default DB parameter group. By default, the new DB instance is created as a single-AZ deployment except when the instance is a SQL Server instance that has an option group that is associated with mirroring; in this case, the instance becomes a mirrored deployment and not a single-AZ deployment.
 *
 * This operation doesn't apply to Aurora MySQL and Aurora PostgreSQL. For Aurora, use `RestoreDBClusterToPointInTime`.
 */
export declare const restoreDBInstanceToPointInTime: API.OperationMethod<RestoreDBInstanceToPointInTimeMessage & RegionInput, RestoreDBInstanceToPointInTimeResult, RestoreDBInstanceToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type RevokeDBSecurityGroupIngressError = AuthorizationNotFoundFault | DBSecurityGroupNotFoundFault | InvalidDBSecurityGroupStateFault | CommonErrors;
/**
 * Revokes ingress from a DBSecurityGroup for previously authorized IP ranges or EC2 or VPC security groups. Required parameters for this API are one of CIDRIP, EC2SecurityGroupId for VPC, or (EC2SecurityGroupOwnerId and either EC2SecurityGroupName or EC2SecurityGroupId).
 *
 * EC2-Classic was retired on August 15, 2022. If you haven't migrated from EC2-Classic to a VPC, we recommend that you migrate as soon as possible. For more information, see Migrate from EC2-Classic to a VPC in the *Amazon EC2 User Guide*, the blog EC2-Classic Networking is Retiring - Here's How to Prepare, and Moving a DB instance not in a VPC into a VPC in the *Amazon RDS User Guide*.
 */
export declare const revokeDBSecurityGroupIngress: API.OperationMethod<RevokeDBSecurityGroupIngressMessage & RegionInput, RevokeDBSecurityGroupIngressResult, RevokeDBSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type StartActivityStreamError = DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts a database activity stream to monitor activity on the database. For more information, see Monitoring Amazon Aurora with Database Activity Streams in the *Amazon Aurora User Guide* or Monitoring Amazon RDS with Database Activity Streams in the *Amazon RDS User Guide*.
 */
export declare const startActivityStream: API.OperationMethod<StartActivityStreamRequest & RegionInput, StartActivityStreamResponse, StartActivityStreamError, Credentials | HttpClient.HttpClient>;
export type StartDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBShardGroupStateFault | KMSKeyNotAccessibleFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Starts an Amazon Aurora DB cluster that was stopped using the Amazon Web Services console, the stop-db-cluster CLI command, or the `StopDBCluster` operation.
 *
 * For more information, see Stopping and Starting an Aurora Cluster in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const startDBCluster: API.OperationMethod<StartDBClusterMessage & RegionInput, StartDBClusterResult, StartDBClusterError, Credentials | HttpClient.HttpClient>;
export type StartDBInstanceError = AuthorizationNotFoundFault | DBCapacityReservationNotFoundFault | DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InsufficientDBInstanceCapacityFault | InvalidDBCapacityReservationStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | VpcEncryptionControlViolationException | CommonErrors;
/**
 * Starts an Amazon RDS DB instance that was stopped using the Amazon Web Services console, the stop-db-instance CLI command, or the `StopDBInstance` operation.
 *
 * For more information, see Starting an Amazon RDS DB instance That Was Previously Stopped in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL. For Aurora DB clusters, use `StartDBCluster` instead.
 */
export declare const startDBInstance: API.OperationMethod<StartDBInstanceMessage & RegionInput, StartDBInstanceResult, StartDBInstanceError, Credentials | HttpClient.HttpClient>;
export type StartDBInstanceAutomatedBackupsReplicationError = DBInstanceAutomatedBackupQuotaExceededFault | DBInstanceNotFoundFault | InvalidDBInstanceAutomatedBackupStateFault | InvalidDBInstanceStateFault | KMSKeyNotAccessibleFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Enables replication of automated backups to a different Amazon Web Services Region.
 *
 * This command doesn't apply to RDS Custom.
 *
 * For more information, see Replicating Automated Backups to Another Amazon Web Services Region in the *Amazon RDS User Guide.*
 */
export declare const startDBInstanceAutomatedBackupsReplication: API.OperationMethod<StartDBInstanceAutomatedBackupsReplicationMessage & RegionInput, StartDBInstanceAutomatedBackupsReplicationResult, StartDBInstanceAutomatedBackupsReplicationError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = DBClusterNotFoundFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | ExportTaskAlreadyExistsFault | IamRoleMissingPermissionsFault | IamRoleNotFoundFault | InvalidExportOnlyFault | InvalidExportSourceStateFault | InvalidS3BucketFault | KMSKeyNotAccessibleFault | CommonErrors;
/**
 * Starts an export of DB snapshot or DB cluster data to Amazon S3. The provided IAM role must have access to the S3 bucket.
 *
 * You can't export snapshot data from RDS Custom DB instances. For more information, see Supported Regions and DB engines for exporting snapshots to S3 in Amazon RDS.
 *
 * For more information on exporting DB snapshot data, see Exporting DB snapshot data to Amazon S3 in the *Amazon RDS User Guide* or Exporting DB cluster snapshot data to Amazon S3 in the *Amazon Aurora User Guide*.
 *
 * For more information on exporting DB cluster data, see Exporting DB cluster data to Amazon S3 in the *Amazon Aurora User Guide*.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskMessage & RegionInput, ExportTask, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StopActivityStreamError = DBClusterNotFoundFault | DBInstanceNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops a database activity stream that was started using the Amazon Web Services console, the `start-activity-stream` CLI command, or the `StartActivityStream` operation.
 *
 * For more information, see Monitoring Amazon Aurora with Database Activity Streams in the *Amazon Aurora User Guide* or Monitoring Amazon RDS with Database Activity Streams in the *Amazon RDS User Guide*.
 */
export declare const stopActivityStream: API.OperationMethod<StopActivityStreamRequest & RegionInput, StopActivityStreamResponse, StopActivityStreamError, Credentials | HttpClient.HttpClient>;
export type StopDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBShardGroupStateFault | CommonErrors;
/**
 * Stops an Amazon Aurora DB cluster. When you stop a DB cluster, Aurora retains the DB cluster's metadata, including its endpoints and DB parameter groups. Aurora also retains the transaction logs so you can do a point-in-time restore if necessary.
 *
 * For more information, see Stopping and Starting an Aurora Cluster in the *Amazon Aurora User Guide*.
 *
 * This operation only applies to Aurora DB clusters.
 */
export declare const stopDBCluster: API.OperationMethod<StopDBClusterMessage & RegionInput, StopDBClusterResult, StopDBClusterError, Credentials | HttpClient.HttpClient>;
export type StopDBInstanceError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBCapacityReservationStateFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Stops an Amazon RDS DB instance temporarily. When you stop a DB instance, Amazon RDS retains the DB instance's metadata, including its endpoint, DB parameter group, and option group membership. Amazon RDS also retains the transaction logs so you can do a point-in-time restore if necessary. The instance restarts automatically after 7 days.
 *
 * For more information, see Stopping an Amazon RDS DB Instance Temporarily in the *Amazon RDS User Guide.*
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL. For Aurora clusters, use `StopDBCluster` instead.
 */
export declare const stopDBInstance: API.OperationMethod<StopDBInstanceMessage & RegionInput, StopDBInstanceResult, StopDBInstanceError, Credentials | HttpClient.HttpClient>;
export type StopDBInstanceAutomatedBackupsReplicationError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Stops automated backup replication for a DB instance.
 *
 * This command doesn't apply to RDS Custom, Aurora MySQL, and Aurora PostgreSQL.
 *
 * For more information, see Replicating Automated Backups to Another Amazon Web Services Region in the *Amazon RDS User Guide.*
 */
export declare const stopDBInstanceAutomatedBackupsReplication: API.OperationMethod<StopDBInstanceAutomatedBackupsReplicationMessage & RegionInput, StopDBInstanceAutomatedBackupsReplicationResult, StopDBInstanceAutomatedBackupsReplicationError, Credentials | HttpClient.HttpClient>;
export type SwitchoverBlueGreenDeploymentError = BlueGreenDeploymentNotFoundFault | InvalidBlueGreenDeploymentStateFault | CommonErrors;
/**
 * Switches over a blue/green deployment.
 *
 * Before you switch over, production traffic is routed to the databases in the blue environment. After you switch over, production traffic is routed to the databases in the green environment.
 *
 * For more information, see Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon RDS User Guide* and Using Amazon RDS Blue/Green Deployments for database updates in the *Amazon Aurora User Guide*.
 */
export declare const switchoverBlueGreenDeployment: API.OperationMethod<SwitchoverBlueGreenDeploymentRequest & RegionInput, SwitchoverBlueGreenDeploymentResponse, SwitchoverBlueGreenDeploymentError, Credentials | HttpClient.HttpClient>;
export type SwitchoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Switches over the specified secondary DB cluster to be the new primary DB cluster in the global database cluster. Switchover operations were previously called "managed planned failovers."
 *
 * Aurora promotes the specified secondary cluster to assume full read/write capabilities and demotes the current primary cluster to a secondary (read-only) cluster, maintaining the orginal replication topology. All secondary clusters are synchronized with the primary at the beginning of the process so the new primary continues operations for the Aurora global database without losing any data. Your database is unavailable for a short time while the primary and selected secondary clusters are assuming their new roles. For more information about switching over an Aurora global database, see Performing switchovers for Amazon Aurora global databases in the *Amazon Aurora User Guide*.
 *
 * This operation is intended for controlled environments, for operations such as "regional rotation" or to fall back to the original primary after a global database failover.
 */
export declare const switchoverGlobalCluster: API.OperationMethod<SwitchoverGlobalClusterMessage & RegionInput, SwitchoverGlobalClusterResult, SwitchoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type SwitchoverReadReplicaError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Switches over an Oracle standby database in an Oracle Data Guard environment, making it the new primary database. Issue this command in the Region that hosts the current standby database.
 */
export declare const switchoverReadReplica: API.OperationMethod<SwitchoverReadReplicaMessage & RegionInput, SwitchoverReadReplicaResult, SwitchoverReadReplicaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=rds.d.ts.map