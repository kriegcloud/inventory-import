import { McpServer, Tool, Toolkit } from "effect/ai";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import { HttpServerRequest } from "effect/http/HttpServerRequest";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import type * as Rpc from "effect/rpc/Rpc";
import type * as RpcGroup from "effect/rpc/RpcGroup";
import type * as RpcMiddleware from "effect/rpc/RpcMiddleware";
import * as Scope from "effect/Scope";
import type { Servable } from "./Api.ts";
import { DefinitionError, DuplicateTool, ToolNameTooLong } from "./DefinitionError.ts";
import { type Client, invoke, isToolCall, specOf, toolName } from "./Mention.ts";
import {
  type ClientOf,
  exposedOf,
  type OnceCallName,
  type Operation,
  operationsOf,
  outsideClient,
} from "./ReadRpcs.ts";

/** What {@link toToolkit} reads from an Api class: what it serves, its RPCs, and its in-process client. */
export interface Toolable {
  readonly apiName: string;
  readonly serves: ReadonlyArray<Servable>;
  readonly group: RpcGroup.RpcGroup<Rpc.Any>;
  readonly clientInProcess: Effect.Effect<unknown, never, any>;
}

/**
 * The services an Api's tools need: the hosted Domain and its middleware
 * Layers. Not the client half of any middleware: the agent's calls carry
 * their own headers.
 */
export type Services<A extends Toolable> = Exclude<
  Effect.Services<A["clientInProcess"]>,
  Scope.Scope | RpcMiddleware.ForClient<any>
>;

/**
 * A call {@link toToolkit} can give as a tool: a command's tag
 * (`DepositMoney`), or a read that returns once as `<Name>.<operation>`
 * (`AccountSummary.get`). `watch` and `events` are streams, not tools.
 */
export type Exposable<A extends Toolable> = OnceCallName<ClientOf<A>>;

export interface ToolkitOptions<A extends Toolable, R = never> {
  /**
   * The calls to give as tools, by name. No tool is given unless it is
   * listed, so a call the Api later adds, or a field a reply later gains,
   * never reaches an agent by accident: list each call on purpose.
   * @default []
   */
  readonly expose?: ReadonlyArray<Exposable<A>>;
  /**
   * The headers each call carries to the Api's middleware (a session cookie,
   * a bearer token), read in the context of the call. By default, the
   * headers of the current `HttpServerRequest`, if there is one: an MCP
   * server over HTTP passes on what its client sent. Without one, a call
   * carries no headers.
   */
  readonly headers?: Effect.Effect<Headers.Input, never, R>;
}

/** An Api's tools, and the Layer that answers them. */
export interface ApiToolkit<R> {
  /** One tool per call of the Api that returns once (see {@link toToolkit}). */
  readonly toolkit: Toolkit.Toolkit<Record<string, Tool.Any>>;
  /** The handlers of {@link toolkit}: each calls the Api in process. */
  readonly layer: Layer.Layer<Tool.HandlersFor<Record<string, Tool.Any>>, never, R>;
}

/** The longest tool name model providers accept. */
const MAX_NAME = 64;

/** The tool for one call, and how to call it with the in-process client. */
const toolOf = (api: string) => (op: Operation) => {
  const { name, spec, wrapped } = specOf(api, op);
  const write = op.operation === "send";
  const tool = Tool.make(name, {
    ...spec,
    // A rejection is a result the model can act on, not a failed generation.
    failureMode: "return",
  })
    .annotate(Tool.Readonly, !write)
    .annotate(Tool.Destructive, write)
    .annotate(Tool.Idempotent, !write);
  return { tool, op, wrapped };
};

const requestHeaders: Effect.Effect<Headers.Input | undefined> = Effect.map(
  Effect.serviceOption(HttpServerRequest),
  Option.match({ onNone: () => undefined, onSome: (request) => request.headers }),
);

/**
 * An Effect AI `Toolkit` with one tool per call `options.expose` lists: a
 * command (a write), a query, or a `get`, `peek`, `list` or `snapshot` (reads). No
 * tool is given unless it is listed. `watch` and `events` are streams, not
 * one tool result, so they stay on the Api's own clients. Convenient for
 * internal tools and agents working on your own data.
 *
 * A tool is named `<api>_<name>_<operation>` (`BankApi_DepositMoney_send`),
 * with every character other than a letter, digit, `_` or `-` replaced by
 * `_`. Its parameters, success and failure are the call's own schemas, as the
 * Api's RPC server decodes them. A query or a read is marked read-only and
 * a command destructive. A query's tool is `<api>_<Query>_ask`. A success that is not a JSON object
 * (a view's `state | null`) comes back as `{ value }`, since MCP requires an
 * object.
 *
 * Each handler calls the Api in process, through the same RPC server as
 * `clientInProcess`: the call's middleware runs against the headers from
 * `options.headers`, and a rejection or a middleware error comes back as the
 * tool's typed failure, for the model to act on. Any other error is a
 * defect, and never reaches the model. Two calls that make the same tool
 * name, or a name longer than 64 characters, fail the Layer with a
 * `DefinitionError`.
 *
 * **Example:** Tools for an in-app agent
 * ```typescript
 * import * as DomainAi from "@alchemy.run/domain/Ai";
 * import { LanguageModel } from "effect/ai";
 *
 * const { toolkit, layer } = DomainAi.toToolkit(CustomerApi, {
 *   expose: ["TransferMoney", "AccountLedger", "AccountSummary.get"],
 *   // The signed-in customer's session, for the Api's session middleware.
 *   headers: Effect.map(CurrentSession, (s) => ({ authorization: `Bearer ${s.token}` })),
 * });
 *
 * const answer = LanguageModel.generateText({
 *   prompt: "Move 20 dollars to savings",
 *   toolkit,
 * }).pipe(Effect.provide(layer));
 * ```
 */
export const toToolkit = <A extends Toolable, R = never>(
  api: A,
  options: ToolkitOptions<A, R> = {},
): ApiToolkit<Services<A> | R> => {
  // A tool name a model provider would refuse fails the Layer, like the model's own definition problems.
  const problems: Array<DefinitionError> = [];
  const names = new Set<string>();
  const tools = exposedOf(operationsOf(api.serves), options.expose)
    .filter(isToolCall)
    .map(toolOf(api.apiName))
    .filter(({ tool }) => {
      if (tool.name.length > MAX_NAME) {
        problems.push(
          new DefinitionError({
            reason: new ToolNameTooLong({ tool: tool.name, max: MAX_NAME }),
          }),
        );
      } else if (names.has(tool.name)) {
        problems.push(
          new DefinitionError({
            reason: new DuplicateTool({ api: api.apiName, tool: tool.name }),
          }),
        );
      } else {
        names.add(tool.name);
        return true;
      }
      return false;
    });
  const toolkit = Toolkit.make(...tools.map(({ tool }) => tool)) as unknown as Toolkit.Toolkit<
    Record<string, Tool.Any>
  >;
  const headers = (options.headers ?? requestHeaders) as Effect.Effect<
    Headers.Input | undefined,
    never,
    R
  >;
  const layer = toolkit.toLayer(
    Effect.gen(function* () {
      if (problems.length > 0) return yield* Effect.die(problems[0]);
      // Without the client half of any middleware (see `outsideClient`).
      const client = (yield* outsideClient(api)) as Client;
      return Object.fromEntries(
        tools.map(({ tool, op, wrapped }) => [
          tool.name,
          (payload: unknown) =>
            headers.pipe(
              Effect.flatMap((headers) => invoke(client, op, payload, headers)),
              Effect.map((value) => (wrapped ? { value } : value)),
            ),
        ]),
      );
    }) as Effect.Effect<Record<string, never>, never, Services<A> | R | Scope.Scope>,
  );
  return { toolkit, layer } as ApiToolkit<Services<A> | R>;
};

/**
 * Serve an Api's tools ({@link toToolkit}) from Effect's `McpServer`. Only
 * the calls `options.expose` lists are served; nothing is by default. Provide
 * an `McpServer` transport, such as `McpServer.layerHttp`. Over HTTP, each
 * call carries the headers of the MCP request to the Api's middleware, so
 * the Api authenticates an MCP client as it does any other.
 *
 * **Example:** An MCP server for an Api
 * ```typescript
 * import * as DomainAi from "@alchemy.run/domain/Ai";
 * import { McpProtocol, McpServer } from "effect/ai";
 * import * as HttpRouter from "effect/http/HttpRouter";
 *
 * const Mcp = DomainAi.toMcp(CustomerApi, {
 *   expose: ["DepositMoney", "AccountSummary.get"],
 * }).pipe(
 *   Layer.provide(
 *     McpServer.layerHttp({
 *       name: "bank",
 *       version: "1.0.0",
 *       path: "/mcp",
 *       protocols: [McpProtocol.v2025_11_25],
 *     }),
 *   ),
 *   Layer.provide(BankLive),
 * );
 *
 * const { handler } = HttpRouter.toWebHandler(Mcp);
 * ```
 */
export const toMcp = <A extends Toolable, R = never>(
  api: A,
  options: ToolkitOptions<A, R> = {},
): Layer.Layer<never, never, Services<A> | R> => {
  const { toolkit, layer } = toToolkit(api, options);
  return McpServer.toolkit(toolkit).pipe(Layer.provide(layer)) as Layer.Layer<
    never,
    never,
    Services<A> | R
  >;
};

export { toolName };
