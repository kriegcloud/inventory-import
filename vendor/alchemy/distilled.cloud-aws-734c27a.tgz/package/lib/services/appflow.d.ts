import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConnectorAuthenticationException_base: S.TaggedErrorClass<"ConnectorAuthenticationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ConnectorAuthenticationException extends /*@__PURE__*/ ConnectorAuthenticationException_base {
}
declare const ConnectorServerException_base: S.TaggedErrorClass<"ConnectorServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConnectorServerException extends /*@__PURE__*/ ConnectorServerException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FlowName = string;
export type ExecutionId = string;
export type ExecutionIds = string[];
export interface CancelFlowExecutionsRequest {
    flowName: string;
    executionIds?: string[] | undefined;
}
export interface CancelFlowExecutionsResponse {
    invalidExecutions?: string[] | undefined;
}
export type ConnectorProfileName = string;
export type KMSArn = string;
export type ConnectorType = "Salesforce" | "Singular" | "Slack" | "Redshift" | "S3" | "Marketo" | "Googleanalytics" | "Zendesk" | "Servicenow" | "Datadog" | "Trendmicro" | "Snowflake" | "Dynatrace" | "Infornexus" | "Amplitude" | "Veeva" | "EventBridge" | "LookoutMetrics" | "Upsolver" | "Honeycode" | "CustomerProfiles" | "SAPOData" | "CustomConnector" | "Pardot" | (string & {});
export type ConnectorLabel = string;
export type ConnectionMode = "Public" | "Private" | (string & {});
export interface AmplitudeConnectorProfileProperties {
}
export type InstanceUrl = string;
export interface DatadogConnectorProfileProperties {
    instanceUrl: string;
}
export interface DynatraceConnectorProfileProperties {
    instanceUrl: string;
}
export interface GoogleAnalyticsConnectorProfileProperties {
}
export interface HoneycodeConnectorProfileProperties {
}
export interface InforNexusConnectorProfileProperties {
    instanceUrl: string;
}
export interface MarketoConnectorProfileProperties {
    instanceUrl: string;
}
export type DatabaseUrl = string;
export type BucketName = string;
export type BucketPrefix = string;
export type RoleArn = string;
export type DataApiRoleArn = string;
export type ClusterIdentifier = string;
export type WorkgroupName = string;
export type DatabaseName = string;
export interface RedshiftConnectorProfileProperties {
    databaseUrl?: string | undefined;
    bucketName: string;
    bucketPrefix?: string | undefined;
    roleArn: string;
    dataApiRoleArn?: string | undefined;
    isRedshiftServerless?: boolean | undefined;
    clusterIdentifier?: string | undefined;
    workgroupName?: string | undefined;
    databaseName?: string | undefined;
}
export interface SalesforceConnectorProfileProperties {
    instanceUrl?: string | undefined;
    isSandboxEnvironment?: boolean | undefined;
    usePrivateLinkForMetadataAndAuthorization?: boolean | undefined;
}
export interface ServiceNowConnectorProfileProperties {
    instanceUrl: string;
}
export interface SingularConnectorProfileProperties {
}
export interface SlackConnectorProfileProperties {
    instanceUrl: string;
}
export type Warehouse = string;
export type Stage = string;
export type PrivateLinkServiceName = string;
export type AccountName = string;
export type Region = string;
export interface SnowflakeConnectorProfileProperties {
    warehouse: string;
    stage: string;
    bucketName: string;
    bucketPrefix?: string | undefined;
    privateLinkServiceName?: string | undefined;
    accountName?: string | undefined;
    region?: string | undefined;
}
export interface TrendmicroConnectorProfileProperties {
}
export interface VeevaConnectorProfileProperties {
    instanceUrl: string;
}
export interface ZendeskConnectorProfileProperties {
    instanceUrl: string;
}
export type ApplicationHostUrl = string;
export type ApplicationServicePath = string;
export type PortNumber = number;
export type ClientNumber = string;
export type LogonLanguage = string;
export type TokenUrl = string;
export type AuthCodeUrl = string;
export type OAuthScope = string;
export type OAuthScopeList = string[];
export interface OAuthProperties {
    tokenUrl: string;
    authCodeUrl: string;
    oAuthScopes: string[];
}
export interface SAPODataConnectorProfileProperties {
    applicationHostUrl: string;
    applicationServicePath: string;
    portNumber: number;
    clientNumber: string;
    logonLanguage?: string | undefined;
    privateLinkServiceName?: string | undefined;
    oAuthProperties?: OAuthProperties | undefined;
    disableSSO?: boolean | undefined;
}
export type ProfilePropertyKey = string;
export type ProfilePropertyValue = string;
export type ProfilePropertiesMap = {
    [key: string]: string | undefined;
};
export type OAuth2GrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "JWT_BEARER" | (string & {});
export type CustomPropertyKey = string;
export type CustomPropertyValue = string;
export type TokenUrlCustomProperties = {
    [key: string]: string | undefined;
};
export interface OAuth2Properties {
    tokenUrl: string;
    oAuth2GrantType: OAuth2GrantType;
    tokenUrlCustomProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CustomConnectorProfileProperties {
    profileProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    oAuth2Properties?: OAuth2Properties | undefined;
}
export type BusinessUnitId = string;
export interface PardotConnectorProfileProperties {
    instanceUrl?: string | undefined;
    isSandboxEnvironment?: boolean | undefined;
    businessUnitId?: string | undefined;
}
export interface ConnectorProfileProperties {
    Amplitude?: AmplitudeConnectorProfileProperties | undefined;
    Datadog?: DatadogConnectorProfileProperties | undefined;
    Dynatrace?: DynatraceConnectorProfileProperties | undefined;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileProperties | undefined;
    Honeycode?: HoneycodeConnectorProfileProperties | undefined;
    InforNexus?: InforNexusConnectorProfileProperties | undefined;
    Marketo?: MarketoConnectorProfileProperties | undefined;
    Redshift?: RedshiftConnectorProfileProperties | undefined;
    Salesforce?: SalesforceConnectorProfileProperties | undefined;
    ServiceNow?: ServiceNowConnectorProfileProperties | undefined;
    Singular?: SingularConnectorProfileProperties | undefined;
    Slack?: SlackConnectorProfileProperties | undefined;
    Snowflake?: SnowflakeConnectorProfileProperties | undefined;
    Trendmicro?: TrendmicroConnectorProfileProperties | undefined;
    Veeva?: VeevaConnectorProfileProperties | undefined;
    Zendesk?: ZendeskConnectorProfileProperties | undefined;
    SAPOData?: SAPODataConnectorProfileProperties | undefined;
    CustomConnector?: CustomConnectorProfileProperties | undefined;
    Pardot?: PardotConnectorProfileProperties | undefined;
}
export type ApiKey = string | redacted.Redacted<string>;
export type SecretKey = string | redacted.Redacted<string>;
export interface AmplitudeConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    secretKey: string | redacted.Redacted<string>;
}
export type ApplicationKey = string;
export interface DatadogConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
    applicationKey: string | redacted.Redacted<string>;
}
export type ApiToken = string;
export interface DynatraceConnectorProfileCredentials {
    apiToken: string | redacted.Redacted<string>;
}
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type RefreshToken = string;
export type AuthCode = string;
export type RedirectUri = string;
export type CodeVerifier = string | redacted.Redacted<string>;
export interface ConnectorOAuthRequest {
    authCode?: string | undefined;
    redirectUri?: string | undefined;
    codeVerifier?: string | redacted.Redacted<string> | undefined;
}
export interface GoogleAnalyticsConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export interface HoneycodeConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export type AccessKeyId = string | redacted.Redacted<string>;
export type Username = string;
export type Key = string;
export interface InforNexusConnectorProfileCredentials {
    accessKeyId: string | redacted.Redacted<string>;
    userId: string;
    secretAccessKey: string | redacted.Redacted<string>;
    datakey: string | redacted.Redacted<string>;
}
export interface MarketoConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export type Password = string | redacted.Redacted<string>;
export interface RedshiftConnectorProfileCredentials {
    username?: string | undefined;
    password?: string | redacted.Redacted<string> | undefined;
}
export type ClientCredentialsArn = string | redacted.Redacted<string>;
export type JwtToken = string | redacted.Redacted<string>;
export interface SalesforceConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
    clientCredentialsArn?: string | redacted.Redacted<string> | undefined;
    oAuth2GrantType?: OAuth2GrantType | undefined;
    jwtToken?: string | redacted.Redacted<string> | undefined;
}
export interface OAuth2Credentials {
    clientId?: string | undefined;
    clientSecret?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export interface ServiceNowConnectorProfileCredentials {
    username?: string | undefined;
    password?: string | redacted.Redacted<string> | undefined;
    oAuth2Credentials?: OAuth2Credentials | undefined;
}
export interface SingularConnectorProfileCredentials {
    apiKey: string | redacted.Redacted<string>;
}
export interface SlackConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export type PrivateKey = string | redacted.Redacted<string>;
export interface SnowflakeConnectorProfileCredentials {
    username: string;
    password?: string | redacted.Redacted<string> | undefined;
    privateKey?: string | redacted.Redacted<string> | undefined;
}
export type ApiSecretKey = string | redacted.Redacted<string>;
export interface TrendmicroConnectorProfileCredentials {
    apiSecretKey: string | redacted.Redacted<string>;
}
export interface VeevaConnectorProfileCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export interface ZendeskConnectorProfileCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export interface BasicAuthCredentials {
    username: string;
    password: string | redacted.Redacted<string>;
}
export interface OAuthCredentials {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
}
export interface SAPODataConnectorProfileCredentials {
    basicAuthCredentials?: BasicAuthCredentials | undefined;
    oAuthCredentials?: OAuthCredentials | undefined;
}
export type AuthenticationType = "OAUTH2" | "APIKEY" | "BASIC" | "CUSTOM" | (string & {});
export interface ApiKeyCredentials {
    apiKey: string | redacted.Redacted<string>;
    apiSecretKey?: string | redacted.Redacted<string> | undefined;
}
export type CustomAuthenticationType = string;
export type CredentialsMapKey = string | redacted.Redacted<string>;
export type CredentialsMapValue = string | redacted.Redacted<string>;
export type CredentialsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CustomAuthCredentials {
    customAuthenticationType: string;
    credentialsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export interface CustomConnectorProfileCredentials {
    authenticationType: AuthenticationType;
    basic?: BasicAuthCredentials | undefined;
    oauth2?: OAuth2Credentials | undefined;
    apiKey?: ApiKeyCredentials | undefined;
    custom?: CustomAuthCredentials | undefined;
}
export interface PardotConnectorProfileCredentials {
    accessToken?: string | redacted.Redacted<string> | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
    oAuthRequest?: ConnectorOAuthRequest | undefined;
    clientCredentialsArn?: string | redacted.Redacted<string> | undefined;
}
export interface ConnectorProfileCredentials {
    Amplitude?: AmplitudeConnectorProfileCredentials | undefined;
    Datadog?: DatadogConnectorProfileCredentials | undefined;
    Dynatrace?: DynatraceConnectorProfileCredentials | undefined;
    GoogleAnalytics?: GoogleAnalyticsConnectorProfileCredentials | undefined;
    Honeycode?: HoneycodeConnectorProfileCredentials | undefined;
    InforNexus?: InforNexusConnectorProfileCredentials | undefined;
    Marketo?: MarketoConnectorProfileCredentials | undefined;
    Redshift?: RedshiftConnectorProfileCredentials | undefined;
    Salesforce?: SalesforceConnectorProfileCredentials | undefined;
    ServiceNow?: ServiceNowConnectorProfileCredentials | undefined;
    Singular?: SingularConnectorProfileCredentials | undefined;
    Slack?: SlackConnectorProfileCredentials | undefined;
    Snowflake?: SnowflakeConnectorProfileCredentials | undefined;
    Trendmicro?: TrendmicroConnectorProfileCredentials | undefined;
    Veeva?: VeevaConnectorProfileCredentials | undefined;
    Zendesk?: ZendeskConnectorProfileCredentials | undefined;
    SAPOData?: SAPODataConnectorProfileCredentials | undefined;
    CustomConnector?: CustomConnectorProfileCredentials | undefined;
    Pardot?: PardotConnectorProfileCredentials | undefined;
}
export interface ConnectorProfileConfig {
    connectorProfileProperties: ConnectorProfileProperties;
    connectorProfileCredentials?: ConnectorProfileCredentials | undefined;
}
export type ClientToken = string;
export interface CreateConnectorProfileRequest {
    connectorProfileName: string;
    kmsArn?: string | undefined;
    connectorType: ConnectorType;
    connectorLabel?: string | undefined;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string | undefined;
}
export type ConnectorProfileArn = string;
export interface CreateConnectorProfileResponse {
    connectorProfileArn?: string | undefined;
}
export type FlowDescription = string;
export type TriggerType = "Scheduled" | "Event" | "OnDemand" | (string & {});
export type ScheduleExpression = string;
export type DataPullMode = "Incremental" | "Complete" | (string & {});
export type Timezone = string;
export type ScheduleOffset = number;
export type FlowErrorDeactivationThreshold = number;
export interface ScheduledTriggerProperties {
    scheduleExpression: string;
    dataPullMode?: DataPullMode | undefined;
    scheduleStartTime?: Date | undefined;
    scheduleEndTime?: Date | undefined;
    timezone?: string | undefined;
    scheduleOffset?: number | undefined;
    firstExecutionFrom?: Date | undefined;
    flowErrorDeactivationThreshold?: number | undefined;
}
export interface TriggerProperties {
    Scheduled?: ScheduledTriggerProperties | undefined;
}
export interface TriggerConfig {
    triggerType: TriggerType;
    triggerProperties?: TriggerProperties | undefined;
}
export type ApiVersion = string;
export interface AmplitudeSourceProperties {
    object: string;
}
export interface DatadogSourceProperties {
    object: string;
}
export interface DynatraceSourceProperties {
    object: string;
}
export interface GoogleAnalyticsSourceProperties {
    object: string;
}
export interface InforNexusSourceProperties {
    object: string;
}
export interface MarketoSourceProperties {
    object: string;
}
export type S3InputFileType = "CSV" | "JSON" | (string & {});
export interface S3InputFormatConfig {
    s3InputFileType?: S3InputFileType | undefined;
}
export interface S3SourceProperties {
    bucketName: string;
    bucketPrefix?: string | undefined;
    s3InputFormatConfig?: S3InputFormatConfig | undefined;
}
export type SalesforceDataTransferApi = "AUTOMATIC" | "BULKV2" | "REST_SYNC" | (string & {});
export interface SalesforceSourceProperties {
    object: string;
    enableDynamicFieldUpdate?: boolean | undefined;
    includeDeletedRecords?: boolean | undefined;
    dataTransferApi?: SalesforceDataTransferApi | undefined;
}
export interface ServiceNowSourceProperties {
    object: string;
}
export interface SingularSourceProperties {
    object: string;
}
export interface SlackSourceProperties {
    object: string;
}
export interface TrendmicroSourceProperties {
    object: string;
}
export type DocumentType = string;
export interface VeevaSourceProperties {
    object: string;
    documentType?: string | undefined;
    includeSourceFiles?: boolean | undefined;
    includeRenditions?: boolean | undefined;
    includeAllVersions?: boolean | undefined;
}
export interface ZendeskSourceProperties {
    object: string;
}
export type SAPODataMaxParallelism = number;
export interface SAPODataParallelismConfig {
    maxParallelism: number;
}
export type SAPODataMaxPageSize = number;
export interface SAPODataPaginationConfig {
    maxPageSize: number;
}
export interface SAPODataSourceProperties {
    objectPath?: string | undefined;
    parallelismConfig?: SAPODataParallelismConfig | undefined;
    paginationConfig?: SAPODataPaginationConfig | undefined;
}
export type EntityName = string;
export type CustomProperties = {
    [key: string]: string | undefined;
};
export type DataTransferApiTypeName = string;
export type DataTransferApiType = "SYNC" | "ASYNC" | "AUTOMATIC" | (string & {});
export interface DataTransferApi {
    Name?: string | undefined;
    Type?: DataTransferApiType | undefined;
}
export interface CustomConnectorSourceProperties {
    entityName: string;
    customProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    dataTransferApi?: DataTransferApi | undefined;
}
export interface PardotSourceProperties {
    object: string;
}
export interface SourceConnectorProperties {
    Amplitude?: AmplitudeSourceProperties | undefined;
    Datadog?: DatadogSourceProperties | undefined;
    Dynatrace?: DynatraceSourceProperties | undefined;
    GoogleAnalytics?: GoogleAnalyticsSourceProperties | undefined;
    InforNexus?: InforNexusSourceProperties | undefined;
    Marketo?: MarketoSourceProperties | undefined;
    S3?: S3SourceProperties | undefined;
    Salesforce?: SalesforceSourceProperties | undefined;
    ServiceNow?: ServiceNowSourceProperties | undefined;
    Singular?: SingularSourceProperties | undefined;
    Slack?: SlackSourceProperties | undefined;
    Trendmicro?: TrendmicroSourceProperties | undefined;
    Veeva?: VeevaSourceProperties | undefined;
    Zendesk?: ZendeskSourceProperties | undefined;
    SAPOData?: SAPODataSourceProperties | undefined;
    CustomConnector?: CustomConnectorSourceProperties | undefined;
    Pardot?: PardotSourceProperties | undefined;
}
export type DatetimeTypeFieldName = string;
export interface IncrementalPullConfig {
    datetimeTypeFieldName?: string | undefined;
}
export interface SourceFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string | undefined;
    connectorProfileName?: string | undefined;
    sourceConnectorProperties: SourceConnectorProperties;
    incrementalPullConfig?: IncrementalPullConfig | undefined;
}
export interface ErrorHandlingConfig {
    failOnFirstDestinationError?: boolean | undefined;
    bucketPrefix?: string | undefined;
    bucketName?: string | undefined;
}
export interface RedshiftDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string | undefined;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
}
export type FileType = "CSV" | "JSON" | "PARQUET" | (string & {});
export type PrefixType = "FILENAME" | "PATH" | "PATH_AND_FILENAME" | (string & {});
export type PrefixFormat = "YEAR" | "MONTH" | "DAY" | "HOUR" | "MINUTE" | (string & {});
export type PathPrefix = "EXECUTION_ID" | "SCHEMA_VERSION" | (string & {});
export type PathPrefixHierarchy = PathPrefix[];
export interface PrefixConfig {
    prefixType?: PrefixType | undefined;
    prefixFormat?: PrefixFormat | undefined;
    pathPrefixHierarchy?: PathPrefix[] | undefined;
}
export type AggregationType = "None" | "SingleFile" | (string & {});
export interface AggregationConfig {
    aggregationType?: AggregationType | undefined;
    targetFileSize?: number | undefined;
}
export type JavaBoolean = boolean;
export interface S3OutputFormatConfig {
    fileType?: FileType | undefined;
    prefixConfig?: PrefixConfig | undefined;
    aggregationConfig?: AggregationConfig | undefined;
    preserveSourceDataTyping?: boolean | undefined;
}
export interface S3DestinationProperties {
    bucketName: string;
    bucketPrefix?: string | undefined;
    s3OutputFormatConfig?: S3OutputFormatConfig | undefined;
}
export type Name = string;
export type IdFieldNameList = string[];
export type WriteOperationType = "INSERT" | "UPSERT" | "UPDATE" | "DELETE" | (string & {});
export interface SalesforceDestinationProperties {
    object: string;
    idFieldNames?: string[] | undefined;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
    writeOperationType?: WriteOperationType | undefined;
    dataTransferApi?: SalesforceDataTransferApi | undefined;
}
export interface SnowflakeDestinationProperties {
    object: string;
    intermediateBucketName: string;
    bucketPrefix?: string | undefined;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
}
export interface EventBridgeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
}
export interface LookoutMetricsDestinationProperties {
}
export type UpsolverBucketName = string;
export interface UpsolverS3OutputFormatConfig {
    fileType?: FileType | undefined;
    prefixConfig: PrefixConfig;
    aggregationConfig?: AggregationConfig | undefined;
}
export interface UpsolverDestinationProperties {
    bucketName: string;
    bucketPrefix?: string | undefined;
    s3OutputFormatConfig: UpsolverS3OutputFormatConfig;
}
export interface HoneycodeDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
}
export type DomainName = string;
export type ObjectTypeName = string;
export interface CustomerProfilesDestinationProperties {
    domainName: string;
    objectTypeName?: string | undefined;
}
export interface ZendeskDestinationProperties {
    object: string;
    idFieldNames?: string[] | undefined;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
    writeOperationType?: WriteOperationType | undefined;
}
export interface MarketoDestinationProperties {
    object: string;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
}
export interface CustomConnectorDestinationProperties {
    entityName: string;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
    writeOperationType?: WriteOperationType | undefined;
    idFieldNames?: string[] | undefined;
    customProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SuccessResponseHandlingConfig {
    bucketPrefix?: string | undefined;
    bucketName?: string | undefined;
}
export interface SAPODataDestinationProperties {
    objectPath: string;
    successResponseHandlingConfig?: SuccessResponseHandlingConfig | undefined;
    idFieldNames?: string[] | undefined;
    errorHandlingConfig?: ErrorHandlingConfig | undefined;
    writeOperationType?: WriteOperationType | undefined;
}
export interface DestinationConnectorProperties {
    Redshift?: RedshiftDestinationProperties | undefined;
    S3?: S3DestinationProperties | undefined;
    Salesforce?: SalesforceDestinationProperties | undefined;
    Snowflake?: SnowflakeDestinationProperties | undefined;
    EventBridge?: EventBridgeDestinationProperties | undefined;
    LookoutMetrics?: LookoutMetricsDestinationProperties | undefined;
    Upsolver?: UpsolverDestinationProperties | undefined;
    Honeycode?: HoneycodeDestinationProperties | undefined;
    CustomerProfiles?: CustomerProfilesDestinationProperties | undefined;
    Zendesk?: ZendeskDestinationProperties | undefined;
    Marketo?: MarketoDestinationProperties | undefined;
    CustomConnector?: CustomConnectorDestinationProperties | undefined;
    SAPOData?: SAPODataDestinationProperties | undefined;
}
export interface DestinationFlowConfig {
    connectorType: ConnectorType;
    apiVersion?: string | undefined;
    connectorProfileName?: string | undefined;
    destinationConnectorProperties: DestinationConnectorProperties;
}
export type DestinationFlowConfigList = DestinationFlowConfig[];
export type SourceFields = string[];
export type AmplitudeConnectorOperator = "BETWEEN" | (string & {});
export type DatadogConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type DynatraceConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type GoogleAnalyticsConnectorOperator = "PROJECTION" | "BETWEEN" | (string & {});
export type InforNexusConnectorOperator = "PROJECTION" | "BETWEEN" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type MarketoConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type S3ConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SalesforceConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ServiceNowConnectorOperator = "PROJECTION" | "CONTAINS" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SingularConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SlackConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type TrendmicroConnectorOperator = "PROJECTION" | "EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type VeevaConnectorOperator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type ZendeskConnectorOperator = "PROJECTION" | "GREATER_THAN" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SAPODataConnectorOperator = "PROJECTION" | "LESS_THAN" | "CONTAINS" | "GREATER_THAN" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type Operator = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type PardotConnectorOperator = "PROJECTION" | "EQUAL_TO" | "NO_OP" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | (string & {});
export interface ConnectorOperator {
    Amplitude?: AmplitudeConnectorOperator | undefined;
    Datadog?: DatadogConnectorOperator | undefined;
    Dynatrace?: DynatraceConnectorOperator | undefined;
    GoogleAnalytics?: GoogleAnalyticsConnectorOperator | undefined;
    InforNexus?: InforNexusConnectorOperator | undefined;
    Marketo?: MarketoConnectorOperator | undefined;
    S3?: S3ConnectorOperator | undefined;
    Salesforce?: SalesforceConnectorOperator | undefined;
    ServiceNow?: ServiceNowConnectorOperator | undefined;
    Singular?: SingularConnectorOperator | undefined;
    Slack?: SlackConnectorOperator | undefined;
    Trendmicro?: TrendmicroConnectorOperator | undefined;
    Veeva?: VeevaConnectorOperator | undefined;
    Zendesk?: ZendeskConnectorOperator | undefined;
    SAPOData?: SAPODataConnectorOperator | undefined;
    CustomConnector?: Operator | undefined;
    Pardot?: PardotConnectorOperator | undefined;
}
export type DestinationField = string;
export type TaskType = "Arithmetic" | "Filter" | "Map" | "Map_all" | "Mask" | "Merge" | "Passthrough" | "Truncate" | "Validate" | "Partition" | (string & {});
export type OperatorPropertiesKeys = "VALUE" | "VALUES" | "DATA_TYPE" | "UPPER_BOUND" | "LOWER_BOUND" | "SOURCE_DATA_TYPE" | "DESTINATION_DATA_TYPE" | "VALIDATION_ACTION" | "MASK_VALUE" | "MASK_LENGTH" | "TRUNCATE_LENGTH" | "MATH_OPERATION_FIELDS_ORDER" | "CONCAT_FORMAT" | "SUBFIELD_CATEGORY_MAP" | "EXCLUDE_SOURCE_FIELDS_LIST" | "INCLUDE_NEW_FIELDS" | "ORDERED_PARTITION_KEYS_LIST" | (string & {});
export type Property = string;
export type TaskPropertiesMap = {
    [key in OperatorPropertiesKeys]?: string | undefined;
};
export interface Task {
    sourceFields: string[];
    connectorOperator?: ConnectorOperator | undefined;
    destinationField?: string | undefined;
    taskType: TaskType;
    taskProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Tasks = Task[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type GlueDataCatalogIAMRole = string;
export type GlueDataCatalogDatabaseName = string;
export type GlueDataCatalogTablePrefix = string;
export interface GlueDataCatalogConfig {
    roleArn: string;
    databaseName: string;
    tablePrefix: string;
}
export interface MetadataCatalogConfig {
    glueDataCatalog?: GlueDataCatalogConfig | undefined;
}
export interface CreateFlowRequest {
    flowName: string;
    description?: string | undefined;
    kmsArn?: string | undefined;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    metadataCatalogConfig?: MetadataCatalogConfig | undefined;
    clientToken?: string | undefined;
}
export type FlowArn = string;
export type FlowStatus = "Active" | "Deprecated" | "Deleted" | "Draft" | "Errored" | "Suspended" | (string & {});
export interface CreateFlowResponse {
    flowArn?: string | undefined;
    flowStatus?: FlowStatus | undefined;
}
export interface DeleteConnectorProfileRequest {
    connectorProfileName: string;
    forceDelete?: boolean | undefined;
}
export interface DeleteConnectorProfileResponse {
}
export interface DeleteFlowRequest {
    flowName: string;
    forceDelete?: boolean | undefined;
}
export interface DeleteFlowResponse {
}
export interface DescribeConnectorRequest {
    connectorType: ConnectorType;
    connectorLabel?: string | undefined;
}
export type ConnectorTypeList = ConnectorType[];
export type ScheduleFrequencyType = "BYMINUTE" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "ONCE" | (string & {});
export type SchedulingFrequencyTypeList = ScheduleFrequencyType[];
export type TriggerTypeList = TriggerType[];
export interface AmplitudeMetadata {
}
export interface DatadogMetadata {
}
export interface DynatraceMetadata {
}
export interface GoogleAnalyticsMetadata {
    oAuthScopes?: string[] | undefined;
}
export interface InforNexusMetadata {
}
export interface MarketoMetadata {
}
export interface RedshiftMetadata {
}
export interface S3Metadata {
}
export type SalesforceDataTransferApiList = SalesforceDataTransferApi[];
export type OAuth2GrantTypeSupportedList = OAuth2GrantType[];
export interface SalesforceMetadata {
    oAuthScopes?: string[] | undefined;
    dataTransferApis?: SalesforceDataTransferApi[] | undefined;
    oauth2GrantTypesSupported?: OAuth2GrantType[] | undefined;
}
export interface ServiceNowMetadata {
}
export interface SingularMetadata {
}
export interface SlackMetadata {
    oAuthScopes?: string[] | undefined;
}
export type RegionList = string[];
export interface SnowflakeMetadata {
    supportedRegions?: string[] | undefined;
}
export interface TrendmicroMetadata {
}
export interface VeevaMetadata {
}
export interface ZendeskMetadata {
    oAuthScopes?: string[] | undefined;
}
export interface EventBridgeMetadata {
}
export interface UpsolverMetadata {
}
export interface CustomerProfilesMetadata {
}
export interface HoneycodeMetadata {
    oAuthScopes?: string[] | undefined;
}
export interface SAPODataMetadata {
}
export interface PardotMetadata {
}
export interface ConnectorMetadata {
    Amplitude?: AmplitudeMetadata | undefined;
    Datadog?: DatadogMetadata | undefined;
    Dynatrace?: DynatraceMetadata | undefined;
    GoogleAnalytics?: GoogleAnalyticsMetadata | undefined;
    InforNexus?: InforNexusMetadata | undefined;
    Marketo?: MarketoMetadata | undefined;
    Redshift?: RedshiftMetadata | undefined;
    S3?: S3Metadata | undefined;
    Salesforce?: SalesforceMetadata | undefined;
    ServiceNow?: ServiceNowMetadata | undefined;
    Singular?: SingularMetadata | undefined;
    Slack?: SlackMetadata | undefined;
    Snowflake?: SnowflakeMetadata | undefined;
    Trendmicro?: TrendmicroMetadata | undefined;
    Veeva?: VeevaMetadata | undefined;
    Zendesk?: ZendeskMetadata | undefined;
    EventBridge?: EventBridgeMetadata | undefined;
    Upsolver?: UpsolverMetadata | undefined;
    CustomerProfiles?: CustomerProfilesMetadata | undefined;
    Honeycode?: HoneycodeMetadata | undefined;
    SAPOData?: SAPODataMetadata | undefined;
    Pardot?: PardotMetadata | undefined;
}
export type ConnectorDescription = string;
export type ConnectorOwner = string;
export type ConnectorName = string;
export type ConnectorVersion = string;
export type ARN = string;
export type ConnectorMode = string;
export type ConnectorModeList = string[];
export type TokenUrlList = string[];
export type AuthCodeUrlList = string[];
export type Label = string;
export type Description = string;
export type ConnectorSuppliedValue = string;
export type ConnectorSuppliedValueList = string[];
export type OAuth2CustomPropType = "TOKEN_URL" | "AUTH_URL" | (string & {});
export interface OAuth2CustomParameter {
    key?: string | undefined;
    isRequired?: boolean | undefined;
    label?: string | undefined;
    description?: string | undefined;
    isSensitiveField?: boolean | undefined;
    connectorSuppliedValues?: string[] | undefined;
    type?: OAuth2CustomPropType | undefined;
}
export type OAuth2CustomPropertiesList = OAuth2CustomParameter[];
export interface OAuth2Defaults {
    oauthScopes?: string[] | undefined;
    tokenUrls?: string[] | undefined;
    authCodeUrls?: string[] | undefined;
    oauth2GrantTypesSupported?: OAuth2GrantType[] | undefined;
    oauth2CustomProperties?: OAuth2CustomParameter[] | undefined;
}
export interface AuthParameter {
    key?: string | undefined;
    isRequired?: boolean | undefined;
    label?: string | undefined;
    description?: string | undefined;
    isSensitiveField?: boolean | undefined;
    connectorSuppliedValues?: string[] | undefined;
}
export type AuthParameterList = AuthParameter[];
export interface CustomAuthConfig {
    customAuthenticationType?: string | undefined;
    authParameters?: AuthParameter[] | undefined;
}
export type CustomAuthConfigList = CustomAuthConfig[];
export interface AuthenticationConfig {
    isBasicAuthSupported?: boolean | undefined;
    isApiKeyAuthSupported?: boolean | undefined;
    isOAuth2Supported?: boolean | undefined;
    isCustomAuthSupported?: boolean | undefined;
    oAuth2Defaults?: OAuth2Defaults | undefined;
    customAuthConfigs?: CustomAuthConfig[] | undefined;
}
export type ConnectorRuntimeSettingDataType = string;
export type ConnectorRuntimeSettingScope = string;
export type ConnectorSuppliedValueOptionList = string[];
export interface ConnectorRuntimeSetting {
    key?: string | undefined;
    dataType?: string | undefined;
    isRequired?: boolean | undefined;
    label?: string | undefined;
    description?: string | undefined;
    scope?: string | undefined;
    connectorSuppliedValueOptions?: string[] | undefined;
}
export type ConnectorRuntimeSettingList = ConnectorRuntimeSetting[];
export type SupportedApiVersion = string;
export type SupportedApiVersionList = string[];
export type Operators = "PROJECTION" | "LESS_THAN" | "GREATER_THAN" | "CONTAINS" | "BETWEEN" | "LESS_THAN_OR_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "NOT_EQUAL_TO" | "ADDITION" | "MULTIPLICATION" | "DIVISION" | "SUBTRACTION" | "MASK_ALL" | "MASK_FIRST_N" | "MASK_LAST_N" | "VALIDATE_NON_NULL" | "VALIDATE_NON_ZERO" | "VALIDATE_NON_NEGATIVE" | "VALIDATE_NUMERIC" | "NO_OP" | (string & {});
export type SupportedOperatorList = Operators[];
export type SupportedWriteOperationList = WriteOperationType[];
export type ConnectorProvisioningType = "LAMBDA" | (string & {});
export interface LambdaConnectorProvisioningConfig {
    lambdaArn: string;
}
export interface ConnectorProvisioningConfig {
    lambda?: LambdaConnectorProvisioningConfig | undefined;
}
export type LogoURL = string;
export type RegisteredBy = string;
export type SupportedDataTransferType = "RECORD" | "FILE" | (string & {});
export type SupportedDataTransferTypeList = SupportedDataTransferType[];
export type SupportedDataTransferApis = DataTransferApi[];
export interface ConnectorConfiguration {
    canUseAsSource?: boolean | undefined;
    canUseAsDestination?: boolean | undefined;
    supportedDestinationConnectors?: ConnectorType[] | undefined;
    supportedSchedulingFrequencies?: ScheduleFrequencyType[] | undefined;
    isPrivateLinkEnabled?: boolean | undefined;
    isPrivateLinkEndpointUrlRequired?: boolean | undefined;
    supportedTriggerTypes?: TriggerType[] | undefined;
    connectorMetadata?: ConnectorMetadata | undefined;
    connectorType?: ConnectorType | undefined;
    connectorLabel?: string | undefined;
    connectorDescription?: string | undefined;
    connectorOwner?: string | undefined;
    connectorName?: string | undefined;
    connectorVersion?: string | undefined;
    connectorArn?: string | undefined;
    connectorModes?: string[] | undefined;
    authenticationConfig?: AuthenticationConfig | undefined;
    connectorRuntimeSettings?: ConnectorRuntimeSetting[] | undefined;
    supportedApiVersions?: string[] | undefined;
    supportedOperators?: Operators[] | undefined;
    supportedWriteOperations?: WriteOperationType[] | undefined;
    connectorProvisioningType?: ConnectorProvisioningType | undefined;
    connectorProvisioningConfig?: ConnectorProvisioningConfig | undefined;
    logoURL?: string | undefined;
    registeredAt?: Date | undefined;
    registeredBy?: string | undefined;
    supportedDataTransferTypes?: SupportedDataTransferType[] | undefined;
    supportedDataTransferApis?: DataTransferApi[] | undefined;
}
export interface DescribeConnectorResponse {
    connectorConfiguration?: ConnectorConfiguration | undefined;
}
export interface DescribeConnectorEntityRequest {
    connectorEntityName: string;
    connectorType?: ConnectorType | undefined;
    connectorProfileName?: string | undefined;
    apiVersion?: string | undefined;
}
export type Identifier = string;
export type FieldType = string;
export type FilterOperatorList = Operator[];
export type Value = string;
export type SupportedValueList = string[];
export interface Range {
    maximum?: number | undefined;
    minimum?: number | undefined;
}
export interface FieldTypeDetails {
    fieldType: string;
    filterOperators: Operator[];
    supportedValues?: string[] | undefined;
    valueRegexPattern?: string | undefined;
    supportedDateFormat?: string | undefined;
    fieldValueRange?: Range | undefined;
    fieldLengthRange?: Range | undefined;
}
export interface SupportedFieldTypeDetails {
    v1: FieldTypeDetails;
}
export interface SourceFieldProperties {
    isRetrievable?: boolean | undefined;
    isQueryable?: boolean | undefined;
    isTimestampFieldForIncrementalQueries?: boolean | undefined;
}
export interface DestinationFieldProperties {
    isCreatable?: boolean | undefined;
    isNullable?: boolean | undefined;
    isUpsertable?: boolean | undefined;
    isUpdatable?: boolean | undefined;
    isDefaultedOnCreate?: boolean | undefined;
    supportedWriteOperations?: WriteOperationType[] | undefined;
}
export interface ConnectorEntityField {
    identifier: string;
    parentIdentifier?: string | undefined;
    label?: string | undefined;
    isPrimaryKey?: boolean | undefined;
    defaultValue?: string | undefined;
    isDeprecated?: boolean | undefined;
    supportedFieldTypeDetails?: SupportedFieldTypeDetails | undefined;
    description?: string | undefined;
    sourceProperties?: SourceFieldProperties | undefined;
    destinationProperties?: DestinationFieldProperties | undefined;
    customProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConnectorEntityFieldList = ConnectorEntityField[];
export interface DescribeConnectorEntityResponse {
    connectorEntityFields: ConnectorEntityField[];
}
export type ConnectorProfileNameList = string[];
export type MaxResults = number;
export type NextToken = string;
export interface DescribeConnectorProfilesRequest {
    connectorProfileNames?: string[] | undefined;
    connectorType?: ConnectorType | undefined;
    connectorLabel?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type PrivateConnectionProvisioningStatus = "FAILED" | "PENDING" | "CREATED" | (string & {});
export type PrivateConnectionProvisioningFailureMessage = string;
export type PrivateConnectionProvisioningFailureCause = "CONNECTOR_AUTHENTICATION" | "CONNECTOR_SERVER" | "INTERNAL_SERVER" | "ACCESS_DENIED" | "VALIDATION" | (string & {});
export interface PrivateConnectionProvisioningState {
    status?: PrivateConnectionProvisioningStatus | undefined;
    failureMessage?: string | undefined;
    failureCause?: PrivateConnectionProvisioningFailureCause | undefined;
}
export interface ConnectorProfile {
    connectorProfileArn?: string | undefined;
    connectorProfileName?: string | undefined;
    connectorType?: ConnectorType | undefined;
    connectorLabel?: string | undefined;
    connectionMode?: ConnectionMode | undefined;
    credentialsArn?: string | undefined;
    connectorProfileProperties?: ConnectorProfileProperties | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    privateConnectionProvisioningState?: PrivateConnectionProvisioningState | undefined;
}
export type ConnectorProfileDetailList = ConnectorProfile[];
export interface DescribeConnectorProfilesResponse {
    connectorProfileDetails?: ConnectorProfile[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeConnectorsRequest {
    connectorTypes?: ConnectorType[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ConnectorConfigurationsMap = {
    [key in ConnectorType]?: ConnectorConfiguration | undefined;
};
export type ApplicationType = string;
export interface ConnectorDetail {
    connectorDescription?: string | undefined;
    connectorName?: string | undefined;
    connectorOwner?: string | undefined;
    connectorVersion?: string | undefined;
    applicationType?: string | undefined;
    connectorType?: ConnectorType | undefined;
    connectorLabel?: string | undefined;
    registeredAt?: Date | undefined;
    registeredBy?: string | undefined;
    connectorProvisioningType?: ConnectorProvisioningType | undefined;
    connectorModes?: string[] | undefined;
    supportedDataTransferTypes?: SupportedDataTransferType[] | undefined;
}
export type ConnectorList = ConnectorDetail[];
export interface DescribeConnectorsResponse {
    connectorConfigurations?: {
        [key: string]: ConnectorConfiguration | undefined;
    } | undefined;
    connectors?: ConnectorDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeFlowRequest {
    flowName: string;
}
export type FlowStatusMessage = string;
export type MostRecentExecutionMessage = string;
export type ExecutionStatus = "InProgress" | "Successful" | "Error" | "CancelStarted" | "Canceled" | (string & {});
export interface ExecutionDetails {
    mostRecentExecutionMessage?: string | undefined;
    mostRecentExecutionTime?: Date | undefined;
    mostRecentExecutionStatus?: ExecutionStatus | undefined;
}
export type CreatedBy = string;
export type UpdatedBy = string;
export type CatalogType = "GLUE" | (string & {});
export interface RegistrationOutput {
    message?: string | undefined;
    result?: string | undefined;
    status?: ExecutionStatus | undefined;
}
export interface MetadataCatalogDetail {
    catalogType?: CatalogType | undefined;
    tableName?: string | undefined;
    tableRegistrationOutput?: RegistrationOutput | undefined;
    partitionRegistrationOutput?: RegistrationOutput | undefined;
}
export type MetadataCatalogDetails = MetadataCatalogDetail[];
export interface DescribeFlowResponse {
    flowArn?: string | undefined;
    description?: string | undefined;
    flowName?: string | undefined;
    kmsArn?: string | undefined;
    flowStatus?: FlowStatus | undefined;
    flowStatusMessage?: string | undefined;
    sourceFlowConfig?: SourceFlowConfig | undefined;
    destinationFlowConfigList?: DestinationFlowConfig[] | undefined;
    lastRunExecutionDetails?: ExecutionDetails | undefined;
    triggerConfig?: TriggerConfig | undefined;
    tasks?: Task[] | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    createdBy?: string | undefined;
    lastUpdatedBy?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    metadataCatalogConfig?: MetadataCatalogConfig | undefined;
    lastRunMetadataCatalogDetails?: MetadataCatalogDetail[] | undefined;
    schemaVersion?: number | undefined;
}
export interface DescribeFlowExecutionRecordsRequest {
    flowName: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ExecutionMessage = string;
export interface ErrorInfo {
    putFailuresCount?: number | undefined;
    executionMessage?: string | undefined;
}
export interface ExecutionResult {
    errorInfo?: ErrorInfo | undefined;
    bytesProcessed?: number | undefined;
    bytesWritten?: number | undefined;
    recordsProcessed?: number | undefined;
    numParallelProcesses?: number | undefined;
    maxPageSize?: number | undefined;
}
export interface ExecutionRecord {
    executionId?: string | undefined;
    executionStatus?: ExecutionStatus | undefined;
    executionResult?: ExecutionResult | undefined;
    startedAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    dataPullStartTime?: Date | undefined;
    dataPullEndTime?: Date | undefined;
    metadataCatalogDetails?: MetadataCatalogDetail[] | undefined;
}
export type FlowExecutionList = ExecutionRecord[];
export interface DescribeFlowExecutionRecordsResponse {
    flowExecutions?: ExecutionRecord[] | undefined;
    nextToken?: string | undefined;
}
export type EntitiesPath = string;
export type ListEntitiesMaxResults = number;
export interface ListConnectorEntitiesRequest {
    connectorProfileName?: string | undefined;
    connectorType?: ConnectorType | undefined;
    entitiesPath?: string | undefined;
    apiVersion?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Group = string;
export interface ConnectorEntity {
    name: string;
    label?: string | undefined;
    hasNestedEntities?: boolean | undefined;
}
export type ConnectorEntityList = ConnectorEntity[];
export type ConnectorEntityMap = {
    [key: string]: ConnectorEntity[] | undefined;
};
export interface ListConnectorEntitiesResponse {
    connectorEntityMap: {
        [key: string]: ConnectorEntity[] | undefined;
    };
    nextToken?: string | undefined;
}
export interface ListConnectorsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListConnectorsResponse {
    connectors?: ConnectorDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFlowsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FlowDefinition {
    flowArn?: string | undefined;
    description?: string | undefined;
    flowName?: string | undefined;
    flowStatus?: FlowStatus | undefined;
    sourceConnectorType?: ConnectorType | undefined;
    sourceConnectorLabel?: string | undefined;
    destinationConnectorType?: ConnectorType | undefined;
    destinationConnectorLabel?: string | undefined;
    triggerType?: TriggerType | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    createdBy?: string | undefined;
    lastUpdatedBy?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    lastRunExecutionDetails?: ExecutionDetails | undefined;
}
export type FlowList = FlowDefinition[];
export interface ListFlowsResponse {
    flows?: FlowDefinition[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RegisterConnectorRequest {
    connectorLabel?: string | undefined;
    description?: string | undefined;
    connectorProvisioningType?: ConnectorProvisioningType | undefined;
    connectorProvisioningConfig?: ConnectorProvisioningConfig | undefined;
    clientToken?: string | undefined;
}
export interface RegisterConnectorResponse {
    connectorArn?: string | undefined;
}
export interface ResetConnectorMetadataCacheRequest {
    connectorProfileName?: string | undefined;
    connectorType?: ConnectorType | undefined;
    connectorEntityName?: string | undefined;
    entitiesPath?: string | undefined;
    apiVersion?: string | undefined;
}
export interface ResetConnectorMetadataCacheResponse {
}
export interface StartFlowRequest {
    flowName: string;
    clientToken?: string | undefined;
}
export interface StartFlowResponse {
    flowArn?: string | undefined;
    flowStatus?: FlowStatus | undefined;
    executionId?: string | undefined;
}
export interface StopFlowRequest {
    flowName: string;
}
export interface StopFlowResponse {
    flowArn?: string | undefined;
    flowStatus?: FlowStatus | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UnregisterConnectorRequest {
    connectorLabel: string;
    forceDelete?: boolean | undefined;
}
export interface UnregisterConnectorResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConnectorProfileRequest {
    connectorProfileName: string;
    connectionMode: ConnectionMode;
    connectorProfileConfig: ConnectorProfileConfig;
    clientToken?: string | undefined;
}
export interface UpdateConnectorProfileResponse {
    connectorProfileArn?: string | undefined;
}
export interface UpdateConnectorRegistrationRequest {
    connectorLabel: string;
    description?: string | undefined;
    connectorProvisioningConfig?: ConnectorProvisioningConfig | undefined;
    clientToken?: string | undefined;
}
export interface UpdateConnectorRegistrationResponse {
    connectorArn?: string | undefined;
}
export interface UpdateFlowRequest {
    flowName: string;
    description?: string | undefined;
    triggerConfig: TriggerConfig;
    sourceFlowConfig: SourceFlowConfig;
    destinationFlowConfigList: DestinationFlowConfig[];
    tasks: Task[];
    metadataCatalogConfig?: MetadataCatalogConfig | undefined;
    clientToken?: string | undefined;
}
export interface UpdateFlowResponse {
    flowStatus?: FlowStatus | undefined;
}
export type ErrorMessage = string;
export type CancelFlowExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels active runs for a flow.
 *
 * You can cancel all of the active runs for a flow, or you can cancel specific runs by
 * providing their IDs.
 *
 * You can cancel a flow run only when the run is in progress. You can't cancel a run that
 * has already completed or failed. You also can't cancel a run that's scheduled to occur but
 * hasn't started yet. To prevent a scheduled run, you can deactivate the flow with the
 * `StopFlow` action.
 *
 * You cannot resume a run after you cancel it.
 *
 * When you send your request, the status for each run becomes `CancelStarted`.
 * When the cancellation completes, the status becomes `Canceled`.
 *
 * When you cancel a run, you still incur charges for any data that the run already
 * processed before the cancellation. If the run had already written some data to the flow
 * destination, then that data remains in the destination. If you configured the flow to use a
 * batch API (such as the Salesforce Bulk API 2.0), then the run will finish reading or writing
 * its entire batch of data after the cancellation. For these operations, the data processing
 * charges for Amazon AppFlow apply. For the pricing information, see Amazon AppFlow pricing.
 */
export declare const cancelFlowExecutions: API.OperationMethod<CancelFlowExecutionsRequest & RegionInput, CancelFlowExecutionsResponse, CancelFlowExecutionsError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ServiceQuotaExceededException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Creates a new connector profile associated with your Amazon Web Services account. There is
 * a soft quota of 100 connector profiles per Amazon Web Services account. If you need more
 * connector profiles than this quota allows, you can submit a request to the Amazon AppFlow
 * team through the Amazon AppFlow support channel. In each connector profile that you
 * create, you can provide the credentials and properties for only one connector.
 */
export declare const createConnectorProfile: API.OperationMethod<CreateConnectorProfileRequest & RegionInput, CreateConnectorProfileResponse, CreateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Enables your application to create a new flow using Amazon AppFlow. You must create
 * a connector profile before calling this API. Please note that the Request Syntax below shows
 * syntax for multiple destinations, however, you can only transfer data to one item in this list
 * at a time. Amazon AppFlow does not currently support flows to multiple destinations at
 * once.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest & RegionInput, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorProfileError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables you to delete an existing connector profile.
 */
export declare const deleteConnectorProfile: API.OperationMethod<DeleteConnectorProfileRequest & RegionInput, DeleteConnectorProfileResponse, DeleteConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Enables your application to delete an existing flow. Before deleting the flow, Amazon AppFlow validates the request by checking the flow configuration and status. You can
 * delete flows one at a time.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest & RegionInput, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the given custom connector registered in your Amazon Web Services account. This
 * API can be used for custom connectors that are registered in your account and also for Amazon
 * authored connectors.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest & RegionInput, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorEntityError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides details regarding the entity used with the connector, with a description of the
 * data model for each field in that entity.
 */
export declare const describeConnectorEntity: API.OperationMethod<DescribeConnectorEntityRequest & RegionInput, DescribeConnectorEntityResponse, DescribeConnectorEntityError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorProfilesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of `connector-profile` details matching the provided
 * `connector-profile` names and `connector-types`. Both input lists are
 * optional, and you can use them to filter the result.
 *
 * If no names or `connector-types` are provided, returns all connector profiles
 * in a paginated form. If there is no match, this operation returns an empty list.
 */
export declare const describeConnectorProfiles: API.PaginatedOperationMethod<DescribeConnectorProfilesRequest & RegionInput, DescribeConnectorProfilesResponse, DescribeConnectorProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the connectors vended by Amazon AppFlow for specified connector types. If
 * you don't specify a connector type, this operation describes all connectors vended by Amazon AppFlow. If there are more connectors than can be returned in one page, the response
 * contains a `nextToken` object, which can be be passed in to the next call to the
 * `DescribeConnectors` API operation to retrieve the next page.
 */
export declare const describeConnectors: API.PaginatedOperationMethod<DescribeConnectorsRequest & RegionInput, DescribeConnectorsResponse, DescribeConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFlowError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Provides a description of the specified flow.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest & RegionInput, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowExecutionRecordsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Fetches the execution history of the flow.
 */
export declare const describeFlowExecutionRecords: API.PaginatedOperationMethod<DescribeFlowExecutionRecordsRequest & RegionInput, DescribeFlowExecutionRecordsResponse, DescribeFlowExecutionRecordsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectorEntitiesError = ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the list of available connector entities supported by Amazon AppFlow. For
 * example, you can query Salesforce for *Account* and
 * *Opportunity* entities, or query ServiceNow for the
 * *Incident* entity.
 */
export declare const listConnectorEntities: API.OperationMethod<ListConnectorEntitiesRequest & RegionInput, ListConnectorEntitiesResponse, ListConnectorEntitiesError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the list of all registered custom connectors in your Amazon Web Services account.
 * This API lists only custom connectors registered in this account, not the Amazon Web Services
 * authored connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlowsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all of the flows associated with your account.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest & RegionInput, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the tags that are associated with a specified flow.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectorError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers a new custom connector with your Amazon Web Services account. Before you can
 * register the connector, you must deploy the associated AWS lambda function in your
 * account.
 */
export declare const registerConnector: API.OperationMethod<RegisterConnectorRequest & RegionInput, RegisterConnectorResponse, RegisterConnectorError, Credentials | HttpClient.HttpClient>;
export type ResetConnectorMetadataCacheError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resets metadata about your connector entities that Amazon AppFlow stored in its
 * cache. Use this action when you want Amazon AppFlow to return the latest information
 * about the data that you have in a source application.
 *
 * Amazon AppFlow returns metadata about your entities when you use the
 * ListConnectorEntities or DescribeConnectorEntities actions. Following these actions, Amazon AppFlow caches the metadata to reduce the number of API requests that it must send to
 * the source application. Amazon AppFlow automatically resets the cache once every hour,
 * but you can use this action when you want to get the latest metadata right away.
 */
export declare const resetConnectorMetadataCache: API.OperationMethod<ResetConnectorMetadataCacheRequest & RegionInput, ResetConnectorMetadataCacheResponse, ResetConnectorMetadataCacheError, Credentials | HttpClient.HttpClient>;
export type StartFlowError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Activates an existing flow. For on-demand flows, this operation runs the flow
 * immediately. For schedule and event-triggered flows, this operation activates the flow.
 */
export declare const startFlow: API.OperationMethod<StartFlowRequest & RegionInput, StartFlowResponse, StartFlowError, Credentials | HttpClient.HttpClient>;
export type StopFlowError = ConflictException | InternalServerException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deactivates the existing flow. For on-demand flows, this operation returns an
 * `unsupportedOperationException` error message. For schedule and event-triggered
 * flows, this operation deactivates the flow.
 */
export declare const stopFlow: API.OperationMethod<StopFlowRequest & RegionInput, StopFlowResponse, StopFlowError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Applies a tag to the specified flow.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UnregisterConnectorError = ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Unregisters the custom connector registered in your account that matches the connector
 * label provided in the request.
 */
export declare const unregisterConnector: API.OperationMethod<UnregisterConnectorRequest & RegionInput, UnregisterConnectorResponse, UnregisterConnectorError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from the specified flow.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorProfileError = ConflictException | ConnectorAuthenticationException | InternalServerException | ResourceNotFoundException | ValidationException | ConnectorServerException | CommonErrors;
/**
 * Updates a given connector profile associated with your account.
 */
export declare const updateConnectorProfile: API.OperationMethod<UpdateConnectorProfileRequest & RegionInput, UpdateConnectorProfileResponse, UpdateConnectorProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorRegistrationError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom connector that you've previously registered. This operation updates the
 * connector with one of the following:
 *
 * - The latest version of the AWS Lambda function that's assigned to the connector
 *
 * - A new AWS Lambda function that you specify
 */
export declare const updateConnectorRegistration: API.OperationMethod<UpdateConnectorRegistrationRequest & RegionInput, UpdateConnectorRegistrationResponse, UpdateConnectorRegistrationError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | ConnectorAuthenticationException | ConnectorServerException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing flow.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest & RegionInput, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appflow.d.ts.map