import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DashboardInvalidInputError_base: S.TaggedErrorClass<"DashboardInvalidInputError", {
    readonly message: any;
    readonly dashboardValidationMessages: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DashboardInvalidInputError extends /*@__PURE__*/ DashboardInvalidInputError_base {
}
declare const DashboardNotFoundError_base: S.TaggedErrorClass<"DashboardNotFoundError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DashboardNotFoundError extends /*@__PURE__*/ DashboardNotFoundError_base {
}
declare const InternalServiceFault_base: S.TaggedErrorClass<"InternalServiceFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceFault extends /*@__PURE__*/ InternalServiceFault_base {
}
declare const InvalidFormatFault_base: S.TaggedErrorClass<"InvalidFormatFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFormatFault extends /*@__PURE__*/ InvalidFormatFault_base {
}
declare const InvalidNextToken_base: S.TaggedErrorClass<"InvalidNextToken", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextToken extends /*@__PURE__*/ InvalidNextToken_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const KmsAccessDeniedException_base: S.TaggedErrorClass<"KmsAccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class KmsAccessDeniedException extends /*@__PURE__*/ KmsAccessDeniedException_base {
}
declare const KmsKeyDisabledException_base: S.TaggedErrorClass<"KmsKeyDisabledException", {
    readonly message: any;
}>;
export declare class KmsKeyDisabledException extends /*@__PURE__*/ KmsKeyDisabledException_base {
}
declare const KmsKeyNotFoundException_base: S.TaggedErrorClass<"KmsKeyNotFoundException", {
    readonly message: any;
}>;
export declare class KmsKeyNotFoundException extends /*@__PURE__*/ KmsKeyNotFoundException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LimitExceededFault_base: S.TaggedErrorClass<"LimitExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededFault extends /*@__PURE__*/ LimitExceededFault_base {
}
declare const MissingRequiredParameterException_base: S.TaggedErrorClass<"MissingRequiredParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingRequiredParameterException extends /*@__PURE__*/ MissingRequiredParameterException_base {
}
declare const ResourceConflict_base: S.TaggedErrorClass<"ResourceConflict", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflict extends /*@__PURE__*/ ResourceConflict_base {
}
declare const ResourceNotFound_base: S.TaggedErrorClass<"ResourceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFound extends /*@__PURE__*/ ResourceNotFound_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const UnsupportedOperation_base: S.TaggedErrorClass<"UnsupportedOperation", {
    readonly message: any;
}>;
export declare class UnsupportedOperation extends /*@__PURE__*/ UnsupportedOperation_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DatasetIdentifier = string;
export type KmsKeyArn = string;
export interface AssociateDatasetKmsKeyInput {
    DatasetIdentifier?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export interface AssociateDatasetKmsKeyOutput {
}
export type ResourceArn = string;
export type MetricName = string;
export type MetricNameList = string[];
export interface ResourceMetricSelection {
    IncludeMetrics?: string[] | undefined;
}
export type ResourceMetricSelectionList = ResourceMetricSelection[];
export interface CreateResourceMetricsConfigurationInput {
    ResourceArn?: string | undefined;
    MetricSelections?: ResourceMetricSelection[] | undefined;
}
export interface ResourceMetricsConfiguration {
    ResourceArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    MetricSelections?: ResourceMetricSelection[] | undefined;
}
export interface CreateResourceMetricsConfigurationOutput {
    ResourceMetricsConfiguration: ResourceMetricsConfiguration & {
        ResourceArn: ResourceArn;
        CreatedAt: Date;
        UpdatedAt: Date;
        MetricSelections: (ResourceMetricSelection & {
            IncludeMetrics: MetricNameList;
        })[];
    };
}
export type Name = string;
export interface DeleteAlarmMuteRuleInput {
    AlarmMuteRuleName?: string | undefined;
}
export interface DeleteAlarmMuteRuleResponse {
}
export type AlarmName = string;
export type AlarmNames = string[];
export interface DeleteAlarmsInput {
    AlarmNames?: string[] | undefined;
}
export interface DeleteAlarmsResponse {
}
export type AnomalyDetectorId = string;
export type Namespace = string;
export type DimensionName = string;
export type DimensionValue = string;
export interface Dimension {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type Dimensions = Dimension[];
export type AnomalyDetectorMetricStat = string;
export type AccountId = string;
export interface SingleMetricAnomalyDetector {
    AccountId?: string | undefined;
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Stat?: string | undefined;
}
export type MetricId = string;
export interface Metric {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
}
export type Period = number;
export type Stat = string;
export type StandardUnit = "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export interface MetricStat {
    Metric?: Metric | undefined;
    Period?: number | undefined;
    Stat?: string | undefined;
    Unit?: StandardUnit | undefined;
}
export type MetricExpression = string;
export type MetricLabel = string;
export type ReturnData = boolean;
export interface MetricDataQuery {
    Id?: string | undefined;
    MetricStat?: MetricStat | undefined;
    Expression?: string | undefined;
    Label?: string | undefined;
    ReturnData?: boolean | undefined;
    Period?: number | undefined;
    AccountId?: string | undefined;
}
export type MetricDataQueries = MetricDataQuery[];
export interface MetricMathAnomalyDetector {
    MetricDataQueries?: MetricDataQuery[] | undefined;
}
export interface DeleteAnomalyDetectorInput {
    AnomalyDetectorId?: string | undefined;
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Stat?: string | undefined;
    SingleMetricAnomalyDetector?: SingleMetricAnomalyDetector | undefined;
    MetricMathAnomalyDetector?: MetricMathAnomalyDetector | undefined;
}
export interface DeleteAnomalyDetectorOutput {
}
export type DashboardName = string;
export type DashboardNames = string[];
export interface DeleteDashboardsInput {
    DashboardNames?: string[] | undefined;
}
export interface DeleteDashboardsOutput {
}
export type InsightRuleName = string;
export type InsightRuleNames = string[];
export interface DeleteInsightRulesInput {
    RuleNames?: string[] | undefined;
}
export type FailureResource = string;
export type ExceptionType = string;
export type FailureCode = string;
export type FailureDescription = string;
export interface PartialFailure {
    FailureResource?: string | undefined;
    ExceptionType?: string | undefined;
    FailureCode?: string | undefined;
    FailureDescription?: string | undefined;
}
export type BatchFailures = PartialFailure[];
export interface DeleteInsightRulesOutput {
    Failures?: PartialFailure[] | undefined;
}
export type DefinitionId = string;
export interface DeleteMetricDataQueryDefinitionInput {
    Id?: string | undefined;
}
export interface DeleteMetricDataQueryDefinitionOutput {
}
export type MetricStreamName = string;
export interface DeleteMetricStreamInput {
    Name?: string | undefined;
}
export interface DeleteMetricStreamOutput {
}
export interface DeleteResourceMetricsConfigurationInput {
    ResourceArn?: string | undefined;
}
export interface DeleteResourceMetricsConfigurationOutput {
}
export type NextToken = string;
export interface DescribeAlarmContributorsInput {
    AlarmName?: string | undefined;
    NextToken?: string | undefined;
}
export type ContributorId = string;
export type AttributeName = string;
export type AttributeValue = string;
export type ContributorAttributes = {
    [key: string]: string | undefined;
};
export type StateReason = string;
export interface AlarmContributor {
    ContributorId?: string | undefined;
    ContributorAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    StateReason?: string | undefined;
    StateTransitionedTimestamp?: Date | undefined;
}
export type AlarmContributors = AlarmContributor[];
export interface DescribeAlarmContributorsOutput {
    AlarmContributors: (AlarmContributor & {
        ContributorId: ContributorId;
        ContributorAttributes: ContributorAttributes;
        StateReason: StateReason;
    })[];
    NextToken?: string | undefined;
}
export type AlarmType = "CompositeAlarm" | "MetricAlarm" | "LogAlarm" | (string & {});
export type AlarmTypes = AlarmType[];
export type HistoryItemType = "ConfigurationUpdate" | "StateUpdate" | "Action" | "AlarmContributorStateUpdate" | "AlarmContributorAction" | (string & {});
export type MaxRecords = number;
export type ScanBy = "TimestampDescending" | "TimestampAscending" | (string & {});
export interface DescribeAlarmHistoryInput {
    AlarmName?: string | undefined;
    AlarmContributorId?: string | undefined;
    AlarmTypes?: AlarmType[] | undefined;
    HistoryItemType?: HistoryItemType | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
    ScanBy?: ScanBy | undefined;
}
export type HistorySummary = string;
export type HistoryData = string;
export interface AlarmHistoryItem {
    AlarmName?: string | undefined;
    AlarmContributorId?: string | undefined;
    AlarmType?: AlarmType | undefined;
    Timestamp?: Date | undefined;
    HistoryItemType?: HistoryItemType | undefined;
    HistorySummary?: string | undefined;
    HistoryData?: string | undefined;
    AlarmContributorAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AlarmHistoryItems = AlarmHistoryItem[];
export interface DescribeAlarmHistoryOutput {
    AlarmHistoryItems?: AlarmHistoryItem[] | undefined;
    NextToken?: string | undefined;
}
export type AlarmNamePrefix = string;
export type StateValue = "OK" | "ALARM" | "INSUFFICIENT_DATA" | (string & {});
export type ActionPrefix = string;
export interface DescribeAlarmsInput {
    AlarmNames?: string[] | undefined;
    AlarmNamePrefix?: string | undefined;
    AlarmTypes?: AlarmType[] | undefined;
    ChildrenOfAlarmName?: string | undefined;
    ParentsOfAlarmName?: string | undefined;
    StateValue?: StateValue | undefined;
    ActionPrefix?: string | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export type ActionsEnabled = boolean;
export type ResourceName = string;
export type ResourceList = string[];
export type AlarmArn = string;
export type AlarmDescription = string;
export type AlarmRule = string;
export type StateReasonData = string;
export type ActionsSuppressedBy = "WaitPeriod" | "ExtensionPeriod" | "Alarm" | (string & {});
export type ActionsSuppressedReason = string;
export type SuppressorPeriod = number;
export type AlarmTagsPropagationEnabled = boolean;
export type AlarmTagsPropagationTagKey = string;
export type AlarmTagsPropagationTagKeys = string[];
export interface AlarmTagsPropagation {
    Enabled?: boolean | undefined;
    IncludedTagKeys?: string[] | undefined;
    ExcludedTagKeys?: string[] | undefined;
}
export interface ActionConfiguration {
    AlarmTagsPropagation?: AlarmTagsPropagation | undefined;
}
export interface CompositeAlarm {
    ActionsEnabled?: boolean | undefined;
    AlarmActions?: string[] | undefined;
    AlarmArn?: string | undefined;
    AlarmConfigurationUpdatedTimestamp?: Date | undefined;
    AlarmDescription?: string | undefined;
    AlarmName?: string | undefined;
    AlarmRule?: string | undefined;
    InsufficientDataActions?: string[] | undefined;
    OKActions?: string[] | undefined;
    StateReason?: string | undefined;
    StateReasonData?: string | undefined;
    StateUpdatedTimestamp?: Date | undefined;
    StateValue?: StateValue | undefined;
    StateTransitionedTimestamp?: Date | undefined;
    ActionsSuppressedBy?: ActionsSuppressedBy | undefined;
    ActionsSuppressedReason?: string | undefined;
    ActionsSuppressor?: string | undefined;
    ActionsSuppressorWaitPeriod?: number | undefined;
    ActionsSuppressorExtensionPeriod?: number | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export type CompositeAlarms = CompositeAlarm[];
export type Statistic = "SampleCount" | "Average" | "Sum" | "Minimum" | "Maximum" | (string & {});
export type ExtendedStatistic = string;
export type EvaluationPeriods = number;
export type DatapointsToAlarm = number;
export type Threshold = number;
export type ComparisonOperator = "GreaterThanOrEqualToThreshold" | "GreaterThanThreshold" | "LessThanThreshold" | "LessThanOrEqualToThreshold" | "LessThanLowerOrGreaterThanUpperThreshold" | "LessThanLowerThreshold" | "GreaterThanUpperThreshold" | (string & {});
export type TreatMissingData = string;
export type EvaluateLowSampleCountPercentile = string;
export type EvaluationState = "PARTIAL_DATA" | "EVALUATION_FAILURE" | "EVALUATION_ERROR" | (string & {});
export type Timezone = string;
export interface WallClockWindow {
    Timezone?: string | undefined;
}
export interface SlidingWindow {
}
export type EvaluationWindow = {
    WallClockWindow: WallClockWindow;
    SlidingWindow?: undefined;
} | {
    WallClockWindow?: undefined;
    SlidingWindow: SlidingWindow;
};
export type WarmUpPeriodDurationInMinutes = number;
export type OnlyStartEvaluatingAfterWarmUpPeriodEnds = boolean;
export interface WarmUpConfiguration {
    WarmUpPeriodDurationInMinutes?: number | undefined;
    OnlyStartEvaluatingAfterWarmUpPeriodEnds?: boolean | undefined;
}
export type Query = string;
export type PendingPeriod = number;
export type RecoveryPeriod = number;
export interface AlarmPromQLCriteria {
    Query?: string | undefined;
    PendingPeriod?: number | undefined;
    RecoveryPeriod?: number | undefined;
}
export type EvaluationCriteria = {
    PromQLCriteria: AlarmPromQLCriteria;
};
export type EvaluationInterval = number;
export interface MetricAlarm {
    AlarmName?: string | undefined;
    AlarmArn?: string | undefined;
    AlarmDescription?: string | undefined;
    AlarmConfigurationUpdatedTimestamp?: Date | undefined;
    ActionsEnabled?: boolean | undefined;
    OKActions?: string[] | undefined;
    AlarmActions?: string[] | undefined;
    InsufficientDataActions?: string[] | undefined;
    StateValue?: StateValue | undefined;
    StateReason?: string | undefined;
    StateReasonData?: string | undefined;
    StateUpdatedTimestamp?: Date | undefined;
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Statistic?: Statistic | undefined;
    ExtendedStatistic?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Period?: number | undefined;
    Unit?: StandardUnit | undefined;
    EvaluationPeriods?: number | undefined;
    DatapointsToAlarm?: number | undefined;
    Threshold?: number | undefined;
    ComparisonOperator?: ComparisonOperator | undefined;
    TreatMissingData?: string | undefined;
    EvaluateLowSampleCountPercentile?: string | undefined;
    Metrics?: MetricDataQuery[] | undefined;
    ThresholdMetricId?: string | undefined;
    EvaluationState?: EvaluationState | undefined;
    StateTransitionedTimestamp?: Date | undefined;
    EvaluationWindow?: EvaluationWindow | undefined;
    WarmUpConfiguration?: WarmUpConfiguration | undefined;
    EvaluationCriteria?: EvaluationCriteria | undefined;
    EvaluationInterval?: number | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export type MetricAlarms = MetricAlarm[];
export type QueryString = string;
export type AmazonResourceName = string;
export type LogGroupIdentifiers = string[];
export type ScheduleExpression = string;
export type StartTimeOffset = number;
export type EndTimeOffset = number;
export interface ScheduleConfiguration {
    ScheduleExpression?: string | undefined;
    StartTimeOffset?: number | undefined;
    EndTimeOffset?: number | undefined;
}
export type AggregationExpression = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface ScheduledQueryConfiguration {
    QueryString?: string | undefined;
    LogGroupIdentifiers?: string[] | undefined;
    QueryARN?: string | undefined;
    ScheduledQueryRoleARN?: string | undefined;
    ScheduleConfiguration?: ScheduleConfiguration | undefined;
    AggregationExpression?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type QueryResultsToEvaluate = number;
export type QueryResultsToAlarm = number;
export type ActionLogLineCount = number;
export type ActionLogLineRoleArn = string;
export interface LogAlarm {
    AlarmName?: string | undefined;
    AlarmArn?: string | undefined;
    AlarmDescription?: string | undefined;
    AlarmConfigurationUpdatedTimestamp?: Date | undefined;
    ActionsEnabled?: boolean | undefined;
    OKActions?: string[] | undefined;
    AlarmActions?: string[] | undefined;
    InsufficientDataActions?: string[] | undefined;
    StateValue?: StateValue | undefined;
    StateReason?: string | undefined;
    StateReasonData?: string | undefined;
    StateUpdatedTimestamp?: Date | undefined;
    ScheduledQueryConfiguration?: ScheduledQueryConfiguration | undefined;
    QueryResultsToEvaluate?: number | undefined;
    QueryResultsToAlarm?: number | undefined;
    Threshold?: number | undefined;
    ComparisonOperator?: ComparisonOperator | undefined;
    TreatMissingData?: string | undefined;
    StateTransitionedTimestamp?: Date | undefined;
    EvaluationState?: EvaluationState | undefined;
    ActionLogLineCount?: number | undefined;
    ActionLogLineRoleArn?: string | undefined;
    WarmUpConfiguration?: WarmUpConfiguration | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export type LogAlarms = LogAlarm[];
export interface DescribeAlarmsOutput {
    CompositeAlarms?: (CompositeAlarm & {
        ActionConfiguration: ActionConfiguration & {
            AlarmTagsPropagation: AlarmTagsPropagation & {
                Enabled: AlarmTagsPropagationEnabled;
            };
        };
    })[] | undefined;
    MetricAlarms?: (MetricAlarm & {
        Dimensions: (Dimension & {
            Name: DimensionName;
            Value: DimensionValue;
        })[];
        Metrics: (MetricDataQuery & {
            Id: MetricId;
            MetricStat: MetricStat & {
                Metric: Metric & {
                    Dimensions: (Dimension & {
                        Name: DimensionName;
                        Value: DimensionValue;
                    })[];
                };
                Period: Period;
                Stat: Stat;
            };
        })[];
        WarmUpConfiguration: WarmUpConfiguration & {
            WarmUpPeriodDurationInMinutes: WarmUpPeriodDurationInMinutes;
        };
        ActionConfiguration: ActionConfiguration & {
            AlarmTagsPropagation: AlarmTagsPropagation & {
                Enabled: AlarmTagsPropagationEnabled;
            };
        };
    })[] | undefined;
    LogAlarms?: (LogAlarm & {
        ScheduledQueryConfiguration: ScheduledQueryConfiguration & {
            QueryString: QueryString;
            ScheduledQueryRoleARN: AmazonResourceName;
            ScheduleConfiguration: ScheduleConfiguration & {
                ScheduleExpression: ScheduleExpression;
                StartTimeOffset: StartTimeOffset;
            };
            AggregationExpression: AggregationExpression;
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
        WarmUpConfiguration: WarmUpConfiguration & {
            WarmUpPeriodDurationInMinutes: WarmUpPeriodDurationInMinutes;
        };
        ActionConfiguration: ActionConfiguration & {
            AlarmTagsPropagation: AlarmTagsPropagation & {
                Enabled: AlarmTagsPropagationEnabled;
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAlarmsForMetricInput {
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Statistic?: Statistic | undefined;
    ExtendedStatistic?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Period?: number | undefined;
    Unit?: StandardUnit | undefined;
}
export interface DescribeAlarmsForMetricOutput {
    MetricAlarms?: (MetricAlarm & {
        Dimensions: (Dimension & {
            Name: DimensionName;
            Value: DimensionValue;
        })[];
        Metrics: (MetricDataQuery & {
            Id: MetricId;
            MetricStat: MetricStat & {
                Metric: Metric & {
                    Dimensions: (Dimension & {
                        Name: DimensionName;
                        Value: DimensionValue;
                    })[];
                };
                Period: Period;
                Stat: Stat;
            };
        })[];
        WarmUpConfiguration: WarmUpConfiguration & {
            WarmUpPeriodDurationInMinutes: WarmUpPeriodDurationInMinutes;
        };
        ActionConfiguration: ActionConfiguration & {
            AlarmTagsPropagation: AlarmTagsPropagation & {
                Enabled: AlarmTagsPropagationEnabled;
            };
        };
    })[] | undefined;
}
export type AnomalyDetectorIds = string[];
export type MaxReturnedResultsCount = number;
export type AnomalyDetectorType = "SINGLE_METRIC" | "METRIC_MATH" | (string & {});
export type AnomalyDetectorTypes = AnomalyDetectorType[];
export interface DescribeAnomalyDetectorsInput {
    AnomalyDetectorIds?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    AnomalyDetectorTypes?: AnomalyDetectorType[] | undefined;
}
export interface Range {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type AnomalyDetectorExcludedTimeRanges = Range[];
export type AnomalyDetectorMetricTimezone = string;
export type AnomalyDetectorAdaptationSpeed = "FAST" | "NORMAL" | "SLOW" | (string & {});
export type AnomalyDetectorOutlierFilteringStrength = "MINIMAL" | "MODERATE" | "STRICT" | (string & {});
export interface AnomalyDetectorConfiguration {
    ExcludedTimeRanges?: Range[] | undefined;
    MetricTimezone?: string | undefined;
    AdaptationSpeed?: AnomalyDetectorAdaptationSpeed | undefined;
    OutlierFilteringStrength?: AnomalyDetectorOutlierFilteringStrength | undefined;
}
export type AnomalyDetectorStateValue = "PENDING_TRAINING" | "TRAINED_INSUFFICIENT_DATA" | "TRAINED" | (string & {});
export type PeriodicSpikes = boolean;
export interface MetricCharacteristics {
    PeriodicSpikes?: boolean | undefined;
}
export interface AnomalyDetector {
    AnomalyDetectorId?: string | undefined;
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Stat?: string | undefined;
    Configuration?: AnomalyDetectorConfiguration | undefined;
    StateValue?: AnomalyDetectorStateValue | undefined;
    MetricCharacteristics?: MetricCharacteristics | undefined;
    SingleMetricAnomalyDetector?: SingleMetricAnomalyDetector | undefined;
    MetricMathAnomalyDetector?: MetricMathAnomalyDetector | undefined;
}
export type AnomalyDetectors = AnomalyDetector[];
export interface DescribeAnomalyDetectorsOutput {
    AnomalyDetectors?: (AnomalyDetector & {
        Dimensions: (Dimension & {
            Name: DimensionName;
            Value: DimensionValue;
        })[];
        Configuration: AnomalyDetectorConfiguration & {
            ExcludedTimeRanges: (Range & {
                StartTime: Date;
                EndTime: Date;
            })[];
        };
        SingleMetricAnomalyDetector: SingleMetricAnomalyDetector & {
            Dimensions: (Dimension & {
                Name: DimensionName;
                Value: DimensionValue;
            })[];
        };
        MetricMathAnomalyDetector: MetricMathAnomalyDetector & {
            MetricDataQueries: (MetricDataQuery & {
                Id: MetricId;
                MetricStat: MetricStat & {
                    Metric: Metric & {
                        Dimensions: (Dimension & {
                            Name: DimensionName;
                            Value: DimensionValue;
                        })[];
                    };
                    Period: Period;
                    Stat: Stat;
                };
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type InsightRuleMaxResults = number;
export interface DescribeInsightRulesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type InsightRuleState = string;
export type InsightRuleSchema = string;
export type InsightRuleDefinition = string;
export type InsightRuleIsManaged = boolean;
export type InsightRuleOnTransformedLogs = boolean;
export interface InsightRule {
    Name?: string | undefined;
    State?: string | undefined;
    Schema?: string | undefined;
    Definition?: string | undefined;
    ManagedRule?: boolean | undefined;
    ApplyOnTransformedLogs?: boolean | undefined;
}
export type InsightRules = InsightRule[];
export interface DescribeInsightRulesOutput {
    NextToken?: string | undefined;
    InsightRules?: (InsightRule & {
        Name: InsightRuleName;
        State: InsightRuleState;
        Schema: InsightRuleSchema;
        Definition: InsightRuleDefinition;
    })[] | undefined;
}
export interface DisableAlarmActionsInput {
    AlarmNames?: string[] | undefined;
}
export interface DisableAlarmActionsResponse {
}
export interface DisableInsightRulesInput {
    RuleNames?: string[] | undefined;
}
export interface DisableInsightRulesOutput {
    Failures?: PartialFailure[] | undefined;
}
export interface DisassociateDatasetKmsKeyInput {
    DatasetIdentifier?: string | undefined;
}
export interface DisassociateDatasetKmsKeyOutput {
}
export interface EnableAlarmActionsInput {
    AlarmNames?: string[] | undefined;
}
export interface EnableAlarmActionsResponse {
}
export interface EnableInsightRulesInput {
    RuleNames?: string[] | undefined;
}
export interface EnableInsightRulesOutput {
    Failures?: PartialFailure[] | undefined;
}
export interface GetAlarmMuteRuleInput {
    AlarmMuteRuleName?: string | undefined;
}
export type Arn = string;
export type Expression = string;
export type Duration = string;
export interface Schedule {
    Expression?: string | undefined;
    Duration?: string | undefined;
    Timezone?: string | undefined;
}
export interface Rule {
    Schedule?: Schedule | undefined;
}
export type MuteTargetAlarmNameList = string[];
export interface MuteTargets {
    AlarmNames?: string[] | undefined;
}
export type AlarmMuteRuleStatus = "SCHEDULED" | "ACTIVE" | "EXPIRED" | (string & {});
export type MuteType = string;
export interface GetAlarmMuteRuleOutput {
    Name?: string | undefined;
    AlarmMuteRuleArn?: string | undefined;
    Description?: string | undefined;
    Rule?: (Rule & {
        Schedule: Schedule & {
            Expression: Expression;
            Duration: Duration;
        };
    }) | undefined;
    MuteTargets?: (MuteTargets & {
        AlarmNames: MuteTargetAlarmNameList;
    }) | undefined;
    StartDate?: Date | undefined;
    ExpireDate?: Date | undefined;
    Status?: AlarmMuteRuleStatus | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    MuteType?: string | undefined;
}
export interface GetDashboardInput {
    DashboardName?: string | undefined;
}
export type DashboardArn = string;
export type DashboardBody = string;
export interface GetDashboardOutput {
    DashboardArn?: string | undefined;
    DashboardBody?: string | undefined;
    DashboardName?: string | undefined;
}
export interface GetDatasetInput {
    DatasetIdentifier?: string | undefined;
}
export type DatasetId = string;
export type DatasetArn = string;
export interface GetDatasetOutput {
    DatasetId: string;
    Arn: string;
    KmsKeyArn?: string | undefined;
}
export type InsightRuleUnboundInteger = number;
export type InsightRuleMetricName = string;
export type InsightRuleMetricList = string[];
export type InsightRuleOrderBy = string;
export interface GetInsightRuleReportInput {
    RuleName?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Period?: number | undefined;
    MaxContributorCount?: number | undefined;
    Metrics?: string[] | undefined;
    OrderBy?: string | undefined;
}
export type InsightRuleContributorKeyLabel = string;
export type InsightRuleContributorKeyLabels = string[];
export type InsightRuleAggregationStatistic = string;
export type InsightRuleUnboundDouble = number;
export type InsightRuleUnboundLong = number;
export type InsightRuleContributorKey = string;
export type InsightRuleContributorKeys = string[];
export interface InsightRuleContributorDatapoint {
    Timestamp?: Date | undefined;
    ApproximateValue?: number | undefined;
}
export type InsightRuleContributorDatapoints = InsightRuleContributorDatapoint[];
export interface InsightRuleContributor {
    Keys?: string[] | undefined;
    ApproximateAggregateValue?: number | undefined;
    Datapoints?: InsightRuleContributorDatapoint[] | undefined;
}
export type InsightRuleContributors = InsightRuleContributor[];
export interface InsightRuleMetricDatapoint {
    Timestamp?: Date | undefined;
    UniqueContributors?: number | undefined;
    MaxContributorValue?: number | undefined;
    SampleCount?: number | undefined;
    Average?: number | undefined;
    Sum?: number | undefined;
    Minimum?: number | undefined;
    Maximum?: number | undefined;
}
export type InsightRuleMetricDatapoints = InsightRuleMetricDatapoint[];
export interface GetInsightRuleReportOutput {
    KeyLabels?: string[] | undefined;
    AggregationStatistic?: string | undefined;
    AggregateValue?: number | undefined;
    ApproximateUniqueCount?: number | undefined;
    Contributors?: (InsightRuleContributor & {
        Keys: InsightRuleContributorKeys;
        ApproximateAggregateValue: InsightRuleUnboundDouble;
        Datapoints: (InsightRuleContributorDatapoint & {
            Timestamp: Date;
            ApproximateValue: InsightRuleUnboundDouble;
        })[];
    })[] | undefined;
    MetricDatapoints?: (InsightRuleMetricDatapoint & {
        Timestamp: Date;
    })[] | undefined;
}
export type GetMetricDataMaxDatapoints = number;
export type GetMetricDataLabelTimezone = string;
export interface LabelOptions {
    Timezone?: string | undefined;
}
export interface GetMetricDataInput {
    MetricDataQueries?: MetricDataQuery[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
    ScanBy?: ScanBy | undefined;
    MaxDatapoints?: number | undefined;
    LabelOptions?: LabelOptions | undefined;
}
export type Timestamps = Date[];
export type DatapointValue = number;
export type DatapointValues = number[];
export type StatusCode = "Complete" | "InternalError" | "PartialData" | "Forbidden" | (string & {});
export type MessageDataCode = string;
export type MessageDataValue = string;
export interface MessageData {
    Code?: string | undefined;
    Value?: string | undefined;
}
export type MetricDataResultMessages = MessageData[];
export interface MetricDataResult {
    Id?: string | undefined;
    Label?: string | undefined;
    Timestamps?: Date[] | undefined;
    Values?: number[] | undefined;
    StatusCode?: StatusCode | undefined;
    Messages?: MessageData[] | undefined;
}
export type MetricDataResults = MetricDataResult[];
export interface GetMetricDataOutput {
    MetricDataResults?: MetricDataResult[] | undefined;
    NextToken?: string | undefined;
    Messages?: MessageData[] | undefined;
}
export interface GetMetricDataQueryDefinitionInput {
    Id?: string | undefined;
}
export type DefinitionPath = string;
export type MetricExpressionString = string | redacted.Redacted<string>;
export type QueryType = "PROMQL" | "SQL" | "METRIC_MATH" | (string & {});
export interface GetMetricDataQueryDefinitionOutput {
    Id: string;
    Arn: string;
    Path: string;
    Expression: string | redacted.Redacted<string>;
    Type: QueryType;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type Statistics = Statistic[];
export type ExtendedStatistics = string[];
export interface GetMetricStatisticsInput {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Period?: number | undefined;
    Statistics?: Statistic[] | undefined;
    ExtendedStatistics?: string[] | undefined;
    Unit?: StandardUnit | undefined;
}
export type DatapointValueMap = {
    [key: string]: number | undefined;
};
export interface Datapoint {
    Timestamp?: Date | undefined;
    SampleCount?: number | undefined;
    Average?: number | undefined;
    Sum?: number | undefined;
    Minimum?: number | undefined;
    Maximum?: number | undefined;
    Unit?: StandardUnit | undefined;
    ExtendedStatistics?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type Datapoints = Datapoint[];
export interface GetMetricStatisticsOutput {
    Label?: string | undefined;
    Datapoints?: Datapoint[] | undefined;
}
export interface GetMetricStreamInput {
    Name?: string | undefined;
}
export type MetricStreamFilterMetricNames = string[];
export interface MetricStreamFilter {
    Namespace?: string | undefined;
    MetricNames?: string[] | undefined;
}
export type MetricStreamFilters = MetricStreamFilter[];
export type MetricStreamState = string;
export type MetricStreamOutputFormat = "json" | "opentelemetry0.7" | "opentelemetry1.0" | (string & {});
export interface MetricStreamStatisticsMetric {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
}
export type MetricStreamStatisticsIncludeMetrics = MetricStreamStatisticsMetric[];
export type MetricStreamStatistic = string;
export type MetricStreamStatisticsAdditionalStatistics = string[];
export interface MetricStreamStatisticsConfiguration {
    IncludeMetrics?: MetricStreamStatisticsMetric[] | undefined;
    AdditionalStatistics?: string[] | undefined;
}
export type MetricStreamStatisticsConfigurations = MetricStreamStatisticsConfiguration[];
export type IncludeLinkedAccountsMetrics = boolean;
export interface GetMetricStreamOutput {
    Arn?: string | undefined;
    Name?: string | undefined;
    IncludeFilters?: MetricStreamFilter[] | undefined;
    ExcludeFilters?: MetricStreamFilter[] | undefined;
    FirehoseArn?: string | undefined;
    RoleArn?: string | undefined;
    State?: string | undefined;
    CreationDate?: Date | undefined;
    LastUpdateDate?: Date | undefined;
    OutputFormat?: MetricStreamOutputFormat | undefined;
    StatisticsConfigurations?: (MetricStreamStatisticsConfiguration & {
        IncludeMetrics: (MetricStreamStatisticsMetric & {
            Namespace: Namespace;
            MetricName: MetricName;
        })[];
        AdditionalStatistics: MetricStreamStatisticsAdditionalStatistics;
    })[] | undefined;
    IncludeLinkedAccountsMetrics?: boolean | undefined;
}
export type MetricWidget = string;
export type OutputFormat = string;
export interface GetMetricWidgetImageInput {
    MetricWidget?: string | undefined;
    OutputFormat?: string | undefined;
}
export type MetricWidgetImage = Uint8Array;
export interface GetMetricWidgetImageOutput {
    MetricWidgetImage?: Uint8Array | undefined;
}
export interface GetOTelEnrichmentInput {
}
export type OTelEnrichmentStatus = "Running" | "Stopped" | (string & {});
export type OTelEnrichmentMetricNameList = string[];
export interface OTelEnrichmentMetricSelector {
    Namespace?: string | undefined;
    MetricNames?: string[] | undefined;
}
export type OTelEnrichmentMetricSelectorList = OTelEnrichmentMetricSelector[];
export interface GetOTelEnrichmentOutput {
    Status: OTelEnrichmentStatus;
    IncludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    ExcludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetResourceMetricsConfigurationInput {
    ResourceArn?: string | undefined;
}
export interface GetResourceMetricsConfigurationOutput {
    ResourceMetricsConfiguration: ResourceMetricsConfiguration & {
        ResourceArn: ResourceArn;
        CreatedAt: Date;
        UpdatedAt: Date;
        MetricSelections: (ResourceMetricSelection & {
            IncludeMetrics: MetricNameList;
        })[];
    };
}
export type AlarmMuteRuleStatuses = AlarmMuteRuleStatus[];
export interface ListAlarmMuteRulesInput {
    AlarmName?: string | undefined;
    Statuses?: AlarmMuteRuleStatus[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface AlarmMuteRuleSummary {
    AlarmMuteRuleArn?: string | undefined;
    ExpireDate?: Date | undefined;
    Status?: AlarmMuteRuleStatus | undefined;
    MuteType?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
}
export type AlarmMuteRuleSummaries = AlarmMuteRuleSummary[];
export interface ListAlarmMuteRulesOutput {
    AlarmMuteRuleSummaries?: AlarmMuteRuleSummary[] | undefined;
    NextToken?: string | undefined;
}
export type DashboardNamePrefix = string;
export interface ListDashboardsInput {
    DashboardNamePrefix?: string | undefined;
    NextToken?: string | undefined;
}
export type LastModified = Date;
export type Size = number;
export interface DashboardEntry {
    DashboardName?: string | undefined;
    DashboardArn?: string | undefined;
    LastModified?: Date | undefined;
    Size?: number | undefined;
}
export type DashboardEntries = DashboardEntry[];
export interface ListDashboardsOutput {
    DashboardEntries?: DashboardEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListManagedInsightRulesInput {
    ResourceARN?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TemplateName = string;
export interface ManagedRuleState {
    RuleName?: string | undefined;
    State?: string | undefined;
}
export interface ManagedRuleDescription {
    TemplateName?: string | undefined;
    ResourceARN?: string | undefined;
    RuleState?: ManagedRuleState | undefined;
}
export type ManagedRuleDescriptions = ManagedRuleDescription[];
export interface ListManagedInsightRulesOutput {
    ManagedRules?: (ManagedRuleDescription & {
        RuleState: ManagedRuleState & {
            RuleName: InsightRuleName;
            State: InsightRuleState;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export type MetricDataQueryDefinitionNextToken = string;
export interface ListMetricDataQueryDefinitionsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MetricDataQueryDefinitionSummary {
    Id?: string | undefined;
    Path?: string | undefined;
    Type?: QueryType | undefined;
    UpdatedAt?: Date | undefined;
}
export type MetricDataQueryDefinitionSummaries = MetricDataQueryDefinitionSummary[];
export interface ListMetricDataQueryDefinitionsOutput {
    Items: (MetricDataQueryDefinitionSummary & {
        Id: DefinitionId;
        Path: DefinitionPath;
        Type: QueryType;
    })[];
    NextToken?: string | undefined;
}
export interface DimensionFilter {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type DimensionFilters = DimensionFilter[];
export type RecentlyActive = "PT3H" | (string & {});
export type IncludeLinkedAccounts = boolean;
export interface ListMetricsInput {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: DimensionFilter[] | undefined;
    NextToken?: string | undefined;
    RecentlyActive?: RecentlyActive | undefined;
    IncludeLinkedAccounts?: boolean | undefined;
    OwningAccount?: string | undefined;
}
export type Metrics = Metric[];
export type OwningAccounts = string[];
export interface ListMetricsOutput {
    Metrics?: (Metric & {
        Dimensions: (Dimension & {
            Name: DimensionName;
            Value: DimensionValue;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
    OwningAccounts?: string[] | undefined;
}
export type ListMetricStreamsMaxResults = number;
export interface ListMetricStreamsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MetricStreamEntry {
    Arn?: string | undefined;
    CreationDate?: Date | undefined;
    LastUpdateDate?: Date | undefined;
    Name?: string | undefined;
    FirehoseArn?: string | undefined;
    State?: string | undefined;
    OutputFormat?: MetricStreamOutputFormat | undefined;
}
export type MetricStreamEntries = MetricStreamEntry[];
export interface ListMetricStreamsOutput {
    NextToken?: string | undefined;
    Entries?: MetricStreamEntry[] | undefined;
}
export interface ListTagsForResourceInput {
    ResourceARN?: string | undefined;
}
export interface ListTagsForResourceOutput {
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
}
export interface PutAlarmMuteRuleInput {
    Name?: string | undefined;
    Description?: string | undefined;
    Rule?: Rule | undefined;
    MuteTargets?: MuteTargets | undefined;
    Tags?: Tag[] | undefined;
    StartDate?: Date | undefined;
    ExpireDate?: Date | undefined;
}
export interface PutAlarmMuteRuleResponse {
}
export interface PutAnomalyDetectorInput {
    Namespace?: string | undefined;
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Stat?: string | undefined;
    Configuration?: AnomalyDetectorConfiguration | undefined;
    MetricCharacteristics?: MetricCharacteristics | undefined;
    SingleMetricAnomalyDetector?: SingleMetricAnomalyDetector | undefined;
    MetricMathAnomalyDetector?: MetricMathAnomalyDetector | undefined;
}
export interface PutAnomalyDetectorOutput {
    AnomalyDetectorId?: string | undefined;
}
export interface PutCompositeAlarmInput {
    ActionsEnabled?: boolean | undefined;
    AlarmActions?: string[] | undefined;
    AlarmDescription?: string | undefined;
    AlarmName?: string | undefined;
    AlarmRule?: string | undefined;
    InsufficientDataActions?: string[] | undefined;
    OKActions?: string[] | undefined;
    Tags?: Tag[] | undefined;
    ActionsSuppressor?: string | undefined;
    ActionsSuppressorWaitPeriod?: number | undefined;
    ActionsSuppressorExtensionPeriod?: number | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export interface PutCompositeAlarmResponse {
}
export interface PutDashboardInput {
    DashboardName?: string | undefined;
    DashboardBody?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DataPath = string;
export type Message = string;
export interface DashboardValidationMessage {
    DataPath?: string | undefined;
    Message?: string | undefined;
}
export type DashboardValidationMessages = DashboardValidationMessage[];
export interface PutDashboardOutput {
    DashboardValidationMessages?: DashboardValidationMessage[] | undefined;
}
export interface PutInsightRuleInput {
    RuleName?: string | undefined;
    RuleState?: string | undefined;
    RuleDefinition?: string | undefined;
    Tags?: Tag[] | undefined;
    ApplyOnTransformedLogs?: boolean | undefined;
}
export interface PutInsightRuleOutput {
}
export interface PutLogAlarmInput {
    AlarmName?: string | undefined;
    AlarmDescription?: string | undefined;
    ScheduledQueryConfiguration?: ScheduledQueryConfiguration | undefined;
    ActionLogLineCount?: number | undefined;
    ActionLogLineRoleArn?: string | undefined;
    ActionsEnabled?: boolean | undefined;
    OKActions?: string[] | undefined;
    AlarmActions?: string[] | undefined;
    InsufficientDataActions?: string[] | undefined;
    QueryResultsToEvaluate?: number | undefined;
    QueryResultsToAlarm?: number | undefined;
    Threshold?: number | undefined;
    ComparisonOperator?: ComparisonOperator | undefined;
    TreatMissingData?: string | undefined;
    Tags?: Tag[] | undefined;
    WarmUpConfiguration?: WarmUpConfiguration | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export interface PutLogAlarmResponse {
}
export interface ManagedRule {
    TemplateName?: string | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ManagedRules = ManagedRule[];
export interface PutManagedInsightRulesInput {
    ManagedRules?: ManagedRule[] | undefined;
}
export interface PutManagedInsightRulesOutput {
    Failures?: PartialFailure[] | undefined;
}
export interface PutMetricAlarmInput {
    AlarmName?: string | undefined;
    AlarmDescription?: string | undefined;
    ActionsEnabled?: boolean | undefined;
    OKActions?: string[] | undefined;
    AlarmActions?: string[] | undefined;
    InsufficientDataActions?: string[] | undefined;
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Statistic?: Statistic | undefined;
    ExtendedStatistic?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Period?: number | undefined;
    Unit?: StandardUnit | undefined;
    EvaluationPeriods?: number | undefined;
    DatapointsToAlarm?: number | undefined;
    Threshold?: number | undefined;
    ComparisonOperator?: ComparisonOperator | undefined;
    TreatMissingData?: string | undefined;
    EvaluateLowSampleCountPercentile?: string | undefined;
    Metrics?: MetricDataQuery[] | undefined;
    Tags?: Tag[] | undefined;
    ThresholdMetricId?: string | undefined;
    EvaluationWindow?: EvaluationWindow | undefined;
    WarmUpConfiguration?: WarmUpConfiguration | undefined;
    EvaluationCriteria?: EvaluationCriteria | undefined;
    EvaluationInterval?: number | undefined;
    ActionConfiguration?: ActionConfiguration | undefined;
}
export interface PutMetricAlarmResponse {
}
export interface StatisticSet {
    SampleCount?: number | undefined;
    Sum?: number | undefined;
    Minimum?: number | undefined;
    Maximum?: number | undefined;
}
export type Values = number[];
export type Counts = number[];
export type StorageResolution = number;
export interface MetricDatum {
    MetricName?: string | undefined;
    Dimensions?: Dimension[] | undefined;
    Timestamp?: Date | undefined;
    Value?: number | undefined;
    StatisticValues?: StatisticSet | undefined;
    Values?: number[] | undefined;
    Counts?: number[] | undefined;
    Unit?: StandardUnit | undefined;
    StorageResolution?: number | undefined;
}
export type MetricData = MetricDatum[];
export type EntityKeyAttributesMapKeyString = string;
export type EntityKeyAttributesMapValueString = string;
export type EntityKeyAttributesMap = {
    [key: string]: string | undefined;
};
export type EntityAttributesMapKeyString = string;
export type EntityAttributesMapValueString = string;
export type EntityAttributesMap = {
    [key: string]: string | undefined;
};
export interface Entity {
    KeyAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EntityMetricData {
    Entity?: Entity | undefined;
    MetricData?: MetricDatum[] | undefined;
}
export type EntityMetricDataList = EntityMetricData[];
export type StrictEntityValidation = boolean;
export interface PutMetricDataInput {
    Namespace?: string | undefined;
    MetricData?: MetricDatum[] | undefined;
    EntityMetricData?: EntityMetricData[] | undefined;
    StrictEntityValidation?: boolean | undefined;
}
export interface PutMetricDataResponse {
}
export interface PutMetricDataQueryDefinitionInput {
    Id?: string | undefined;
    Path?: string | undefined;
    Expression?: string | redacted.Redacted<string> | undefined;
    Type?: QueryType | undefined;
    Tags?: Tag[] | undefined;
}
export interface PutMetricDataQueryDefinitionOutput {
    Id: string;
    Arn: string;
    Path: string;
    Expression: string | redacted.Redacted<string>;
    Type: QueryType;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface PutMetricStreamInput {
    Name?: string | undefined;
    IncludeFilters?: MetricStreamFilter[] | undefined;
    ExcludeFilters?: MetricStreamFilter[] | undefined;
    FirehoseArn?: string | undefined;
    RoleArn?: string | undefined;
    OutputFormat?: MetricStreamOutputFormat | undefined;
    Tags?: Tag[] | undefined;
    StatisticsConfigurations?: MetricStreamStatisticsConfiguration[] | undefined;
    IncludeLinkedAccountsMetrics?: boolean | undefined;
}
export interface PutMetricStreamOutput {
    Arn?: string | undefined;
}
export interface SetAlarmStateInput {
    AlarmName?: string | undefined;
    StateValue?: StateValue | undefined;
    StateReason?: string | undefined;
    StateReasonData?: string | undefined;
}
export interface SetAlarmStateResponse {
}
export type MetricStreamNames = string[];
export interface StartMetricStreamsInput {
    Names?: string[] | undefined;
}
export interface StartMetricStreamsOutput {
}
export interface StartOTelEnrichmentInput {
    IncludeFilters?: OTelEnrichmentMetricSelector[] | undefined;
    ExcludeFilters?: OTelEnrichmentMetricSelector[] | undefined;
}
export interface StartOTelEnrichmentOutput {
    IncludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    ExcludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface StopMetricStreamsInput {
    Names?: string[] | undefined;
}
export interface StopMetricStreamsOutput {
}
export interface StopOTelEnrichmentInput {
}
export interface StopOTelEnrichmentOutput {
}
export interface TagResourceInput {
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceARN?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceOutput {
}
export interface UpdateOTelEnrichmentInput {
    IncludeFilters?: OTelEnrichmentMetricSelector[] | undefined;
    ExcludeFilters?: OTelEnrichmentMetricSelector[] | undefined;
}
export interface UpdateOTelEnrichmentOutput {
    IncludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    ExcludeFilters?: (OTelEnrichmentMetricSelector & {
        Namespace: Namespace;
    })[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface UpdateResourceMetricsConfigurationInput {
    ResourceArn?: string | undefined;
    MetricSelections?: ResourceMetricSelection[] | undefined;
}
export interface UpdateResourceMetricsConfigurationOutput {
    ResourceMetricsConfiguration: ResourceMetricsConfiguration & {
        ResourceArn: ResourceArn;
        CreatedAt: Date;
        UpdatedAt: Date;
        MetricSelections: (ResourceMetricSelection & {
            IncludeMetrics: MetricNameList;
        })[];
    };
}
export type ErrorMessage = string;
export type ResourceType = string;
export type ResourceId = string;
export type FaultDescription = string;
export type AwsQueryErrorMessage = string;
export type ValidationExceptionMessage = string;
export type DashboardErrorMessage = string;
export type AssociateDatasetKmsKeyError = ConflictException | KmsAccessDeniedException | KmsKeyDisabledException | KmsKeyNotFoundException | ResourceNotFoundException | CommonErrors;
/**
 * Associates an Amazon Web Services Key Management Service (Amazon Web Services KMS)
 * customer managed key with the specified dataset. After this operation completes, all
 * data published to the dataset is encrypted at rest using the specified KMS key.
 * Callers must have `kms:Decrypt` permission on the key to read the
 * encrypted data.
 *
 * Only the `default` dataset is supported. The `default` dataset
 * is implicit for every account in every Region -- you do not need to create it before
 * calling this operation.
 *
 * You can call `AssociateDatasetKmsKey` on a dataset that is already
 * associated with a KMS key to replace the existing key with a different one. The
 * caller must have `kms:Decrypt` permission on both the current key and
 * the new key.
 *
 * If the currently associated key has been deleted, is scheduled for deletion,
 * is pending import, is unavailable, or has been disabled, Amazon CloudWatch
 * does not require `kms:Decrypt` permission on the current key and
 * the rotation proceeds. If the key was only disabled, consider re-enabling it
 * instead of rotating, because re-enabling allows Amazon CloudWatch to
 * resume decrypting your existing metric data encrypted with that key.
 *
 * The KMS key that you specify must meet all of the following requirements:
 *
 * - It must be a symmetric encryption KMS key (key spec
 * `SYMMETRIC_DEFAULT`, key usage `ENCRYPT_DECRYPT`).
 * Asymmetric keys, HMAC keys, and key material types other than
 * `SYMMETRIC_DEFAULT` are not supported.
 *
 * - It must be enabled and not pending deletion.
 *
 * - Its key policy must grant the CloudWatch service principal
 * (`cloudwatch.amazonaws.com`) these permissions:
 * `kms:DescribeKey`, `kms:GenerateDataKey`,
 * `kms:Encrypt`, `kms:Decrypt`, and
 * `kms:ReEncrypt*`. Amazon CloudWatch requires these permissions
 * to manage the data on your behalf.
 *
 * - The calling principal must have `kms:Decrypt` permission on the
 * key.
 *
 * - It must be specified as a fully qualified key ARN. Key IDs, aliases, and
 * alias ARNs are not accepted.
 *
 * - It must be in the same Amazon Web Services Region as the dataset.
 *
 * Before completing the association, Amazon CloudWatch validates the key by
 * performing a series of dry-run KMS operations. Service-principal checks run first to
 * verify that the key policy grants the required access to Amazon CloudWatch. These
 * checks include `kms:DescribeKey`, `kms:GenerateDataKey`,
 * `kms:Encrypt`, `kms:Decrypt`, and `kms:ReEncrypt*`.
 * After those succeed, a `kms:Decrypt` dry-run is run with the caller's
 * credentials to verify that the calling principal can use the new key. When you are
 * replacing an existing key, the caller's `kms:Decrypt` dry-run is also run
 * on the current key.
 *
 * If any of these checks on the new key fails, the operation fails and the existing
 * key association (if any) remains unchanged. Common failure causes include the new key
 * being disabled, the key policy not granting the required permissions to
 * Amazon CloudWatch, or the caller lacking `kms:Decrypt` permission on
 * the new key.
 *
 * For more information about using customer managed keys with Amazon CloudWatch,
 * see Encryption at rest
 * with customer managed keys in the Amazon CloudWatch User
 * Guide.
 */
export declare const associateDatasetKmsKey: API.OperationMethod<AssociateDatasetKmsKeyInput & RegionInput, AssociateDatasetKmsKeyOutput, AssociateDatasetKmsKeyError, Credentials | HttpClient.HttpClient>;
export type CreateResourceMetricsConfigurationError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a resource metrics configuration for an Amazon Web Services resource. After you
 * create a configuration, Amazon CloudWatch collects detailed metrics for that
 * resource.
 *
 * Each Amazon Web Services resource can have only one resource metrics configuration. If a
 * configuration already exists for the specified resource ARN, this operation returns a
 * `ConflictException`. To modify an existing configuration, use UpdateResourceMetricsConfiguration.
 *
 * If the Amazon Web Services resource that you specify in `ResourceArn` does
 * not exist, this operation returns a `ResourceNotFoundException`. Verify that
 * the resource ARN is correct and that the resource exists before you retry the
 * request.
 *
 * To create a resource metrics configuration, you must have the
 * `cloudwatch:CreateResourceMetricsConfiguration` permission. For information about scoping
 * this permission to specific resources, see Condition keys for resource metrics configuration access in the
 * *Amazon CloudWatch User Guide*.
 */
export declare const createResourceMetricsConfiguration: API.OperationMethod<CreateResourceMetricsConfigurationInput & RegionInput, CreateResourceMetricsConfigurationOutput, CreateResourceMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteAlarmMuteRuleError = CommonErrors;
/**
 * Deletes a specific alarm mute rule.
 *
 * When you delete a mute rule, any alarms that are currently being muted by that rule
 * are immediately unmuted. If those alarms are in an ALARM state, their configured actions
 * will trigger.
 *
 * This operation is idempotent. If you delete a mute rule that does not exist, the
 * operation succeeds without returning an error.
 *
 * **Permissions**
 *
 * To delete a mute rule, you need the `cloudwatch:DeleteAlarmMuteRule`
 * permission on the alarm mute rule resource.
 */
export declare const deleteAlarmMuteRule: API.OperationMethod<DeleteAlarmMuteRuleInput & RegionInput, DeleteAlarmMuteRuleResponse, DeleteAlarmMuteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteAlarmsError = ResourceConflict | ResourceNotFound | CommonErrors;
/**
 * Deletes the specified alarms. You can delete up to 100 alarms in one operation.
 * However, this total can include no more than one composite alarm. For example, you could
 * delete 99 metric alarms and one composite alarms with one operation, but you can't
 * delete two composite alarms with one operation. Log alarms cannot be batch deleted.
 *
 * If you specify any incorrect alarm names, the alarms you specify with correct
 * names are still deleted. Other syntax errors might result in no alarms being deleted. To
 * confirm that alarms were deleted successfully, you can use the DescribeAlarms operation after using `DeleteAlarms`.
 *
 * It is possible to create a loop or cycle of composite alarms, where composite
 * alarm A depends on composite alarm B, and composite alarm B also depends on
 * composite alarm A. In this scenario, you can't delete any composite alarm that is
 * part of the cycle because there is always still a composite alarm that depends on
 * that alarm that you want to delete.
 *
 * To get out of such a situation, you must break the cycle by changing the rule of
 * one of the composite alarms in the cycle to remove a dependency that creates the
 * cycle. The simplest change to make to break a cycle is to change the
 * `AlarmRule` of one of the alarms to `false`.
 *
 * Additionally, the evaluation of composite alarms stops if CloudWatch
 * detects a cycle in the evaluation path.
 */
export declare const deleteAlarms: API.OperationMethod<DeleteAlarmsInput & RegionInput, DeleteAlarmsResponse, DeleteAlarmsError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalyDetectorError = InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | MissingRequiredParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified anomaly detection model from your account. For more information
 * about how to delete an anomaly detection model, see Deleting an anomaly detection model in the CloudWatch User
 * Guide.
 */
export declare const deleteAnomalyDetector: API.OperationMethod<DeleteAnomalyDetectorInput & RegionInput, DeleteAnomalyDetectorOutput, DeleteAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardsError = ConflictException | InternalServiceFault | InvalidParameterValueException | CommonErrors;
/**
 * Deletes all dashboards that you specify. You can specify up to 100 dashboards to
 * delete. If there is an error during this call, the operation attempts to delete as many
 * dashboards as possible.
 */
export declare const deleteDashboards: API.OperationMethod<DeleteDashboardsInput & RegionInput, DeleteDashboardsOutput, DeleteDashboardsError, Credentials | HttpClient.HttpClient>;
export type DeleteInsightRulesError = InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Permanently deletes the specified Contributor Insights rules.
 *
 * If you create a rule, delete it, and then re-create it with the same name, historical
 * data from the first time the rule was created might not be available.
 */
export declare const deleteInsightRules: API.OperationMethod<DeleteInsightRulesInput & RegionInput, DeleteInsightRulesOutput, DeleteInsightRulesError, Credentials | HttpClient.HttpClient>;
export type DeleteMetricDataQueryDefinitionError = CommonErrors;
/**
 * Deletes a metric data query definition.
 *
 * This operation is idempotent. If the definition doesn't exist, the operation succeeds
 * without returning an error.
 *
 * **Permissions**
 *
 * To delete a definition, you need the
 * `cloudwatch:DeleteMetricDataQueryDefinition` permission on the metric
 * data query definition resource. You can use the `aws:ResourceTag/${TagKey}`
 * condition key to control access based on the tags of the definition.
 */
export declare const deleteMetricDataQueryDefinition: API.OperationMethod<DeleteMetricDataQueryDefinitionInput & RegionInput, DeleteMetricDataQueryDefinitionOutput, DeleteMetricDataQueryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteMetricStreamError = InternalServiceFault | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Permanently deletes the metric stream that you specify.
 */
export declare const deleteMetricStream: API.OperationMethod<DeleteMetricStreamInput & RegionInput, DeleteMetricStreamOutput, DeleteMetricStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceMetricsConfigurationError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes the resource metrics configuration for an Amazon Web Services resource. After
 * you delete the configuration, Amazon CloudWatch stops collecting detailed metrics
 * for the resource. Metric data that Amazon CloudWatch already collected for the
 * resource is not deleted.
 *
 * This operation returns a `ResourceNotFoundException` if no resource metrics
 * configuration exists for the specified resource ARN. Verify that the resource ARN is
 * correct.
 *
 * To delete a resource metrics configuration, you must have the
 * `cloudwatch:DeleteResourceMetricsConfiguration` permission. For information about scoping
 * this permission to specific resources, see Condition keys for resource metrics configuration access in the
 * *Amazon CloudWatch User Guide*.
 */
export declare const deleteResourceMetricsConfiguration: API.OperationMethod<DeleteResourceMetricsConfigurationInput & RegionInput, DeleteResourceMetricsConfigurationOutput, DeleteResourceMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmContributorsError = InvalidNextToken | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the information of the current alarm contributors that are in
 * `ALARM` state. This operation returns details about the individual time
 * series that contribute to the alarm's state.
 */
export declare const describeAlarmContributors: API.OperationMethod<DescribeAlarmContributorsInput & RegionInput, DescribeAlarmContributorsOutput, DescribeAlarmContributorsError, Credentials | HttpClient.HttpClient>;
export type DescribeAlarmHistoryError = InvalidNextToken | CommonErrors;
/**
 * Retrieves the history for the specified alarm. You can filter the results by date
 * range or item type. If an alarm name is not specified, the histories for either all
 * metric alarms or all composite alarms are returned.
 *
 * CloudWatch retains the history of an alarm even if you delete the alarm.
 *
 * To use this operation and return information about a composite alarm, you must be
 * signed on with the `cloudwatch:DescribeAlarmHistory` permission that is
 * scoped to `*`. You can't return information about composite alarms if your
 * `cloudwatch:DescribeAlarmHistory` permission has a narrower scope.
 */
export declare const describeAlarmHistory: API.PaginatedOperationMethod<DescribeAlarmHistoryInput & RegionInput, DescribeAlarmHistoryOutput, DescribeAlarmHistoryError, Credentials | HttpClient.HttpClient, AlarmHistoryItem>;
export type DescribeAlarmsError = InvalidNextToken | CommonErrors;
/**
 * Retrieves the specified alarms. You can filter the results by specifying a prefix
 * for the alarm name, the alarm state, or a prefix for any action.
 *
 * To use this operation and return information about composite alarms, you must be
 * signed on with the `cloudwatch:DescribeAlarms` permission that is scoped to
 * `*`. You can't return information about composite alarms if your
 * `cloudwatch:DescribeAlarms` permission has a narrower scope.
 */
export declare const describeAlarms: API.PaginatedOperationMethod<DescribeAlarmsInput & RegionInput, DescribeAlarmsOutput, DescribeAlarmsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAlarmsForMetricError = CommonErrors;
/**
 * Retrieves the alarms for the specified metric. To filter the results, specify a
 * statistic, period, or unit.
 *
 * This operation retrieves only standard alarms that are based on the specified
 * metric. It does not return alarms based on math expressions that use the specified
 * metric, or composite alarms that use the specified metric.
 */
export declare const describeAlarmsForMetric: API.OperationMethod<DescribeAlarmsForMetricInput & RegionInput, DescribeAlarmsForMetricOutput, DescribeAlarmsForMetricError, Credentials | HttpClient.HttpClient>;
export type DescribeAnomalyDetectorsError = InternalServiceFault | InvalidNextToken | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Lists the anomaly detection models that you have created in your account. For single
 * metric anomaly detectors, you can list all of the models in your account or filter the
 * results to only the models that are related to a certain namespace, metric name, or
 * metric dimension. For metric math anomaly detectors, you can list them by adding
 * `METRIC_MATH` to the `AnomalyDetectorTypes` array. This will
 * return all metric math anomaly detectors in your account.
 */
export declare const describeAnomalyDetectors: API.PaginatedOperationMethod<DescribeAnomalyDetectorsInput & RegionInput, DescribeAnomalyDetectorsOutput, DescribeAnomalyDetectorsError, Credentials | HttpClient.HttpClient, AnomalyDetector>;
export type DescribeInsightRulesError = InvalidNextToken | UnsupportedOperation | CommonErrors;
/**
 * Returns a list of all the Contributor Insights rules in your account.
 *
 * For more information about Contributor Insights, see Using Contributor
 * Insights to Analyze High-Cardinality Data.
 */
export declare const describeInsightRules: API.PaginatedOperationMethod<DescribeInsightRulesInput & RegionInput, DescribeInsightRulesOutput, DescribeInsightRulesError, Credentials | HttpClient.HttpClient, unknown>;
export type DisableAlarmActionsError = CommonErrors;
/**
 * Disables the actions for the specified alarms. When an alarm's actions are
 * disabled, the alarm actions do not execute when the alarm state changes.
 */
export declare const disableAlarmActions: API.OperationMethod<DisableAlarmActionsInput & RegionInput, DisableAlarmActionsResponse, DisableAlarmActionsError, Credentials | HttpClient.HttpClient>;
export type DisableInsightRulesError = InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Disables the specified Contributor Insights rules. When rules are disabled, they do
 * not analyze log groups and do not incur costs.
 */
export declare const disableInsightRules: API.OperationMethod<DisableInsightRulesInput & RegionInput, DisableInsightRulesOutput, DisableInsightRulesError, Credentials | HttpClient.HttpClient>;
export type DisassociateDatasetKmsKeyError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the customer managed Amazon Web Services Key Management Service
 * (Amazon Web Services KMS) key association from the specified dataset. After this
 * operation completes, data that you publish to the dataset is encrypted at rest using
 * an Amazon Web Services owned key managed by Amazon CloudWatch.
 *
 * Only the `default` dataset is supported. To call this operation, the
 * dataset must currently have a customer managed KMS key associated with it. If the
 * dataset has no associated KMS key, the operation fails with
 * `ResourceNotFoundException`.
 *
 * Amazon CloudWatch performs a dry-run `kms:Decrypt` call on the
 * currently associated key as part of this operation. The caller must have
 * `kms:Decrypt` permission on the currently associated key. If the key is
 * accessible but the caller lacks `kms:Decrypt` permission, the operation
 * fails with `AccessDeniedException`.
 *
 * If the currently associated key has been deleted, is scheduled for deletion,
 * is pending import, is unavailable, or has been disabled, Amazon CloudWatch
 * does not require `kms:Decrypt` permission on that key and the
 * disassociation proceeds. If the key was only disabled, consider re-enabling it
 * instead of disassociating, because re-enabling allows Amazon CloudWatch to
 * resume decrypting your existing metric data.
 *
 * Disassociating a KMS key from a dataset does not immediately remove the
 * `kms:Decrypt` requirement on data plane operations. For up to three
 * hours after disassociation, callers must continue to have
 * `kms:Decrypt` permission on the previously associated key. Some data
 * might still be encrypted with that key during this window. After this enforcement
 * window elapses, the `kms:Decrypt` requirement is lifted.
 *
 * For more information about using customer managed keys with Amazon CloudWatch,
 * see Encryption at rest
 * with customer managed keys in the Amazon CloudWatch User
 * Guide.
 */
export declare const disassociateDatasetKmsKey: API.OperationMethod<DisassociateDatasetKmsKeyInput & RegionInput, DisassociateDatasetKmsKeyOutput, DisassociateDatasetKmsKeyError, Credentials | HttpClient.HttpClient>;
export type EnableAlarmActionsError = CommonErrors;
/**
 * Enables the actions for the specified alarms.
 */
export declare const enableAlarmActions: API.OperationMethod<EnableAlarmActionsInput & RegionInput, EnableAlarmActionsResponse, EnableAlarmActionsError, Credentials | HttpClient.HttpClient>;
export type EnableInsightRulesError = InvalidParameterValueException | LimitExceededException | MissingRequiredParameterException | CommonErrors;
/**
 * Enables the specified Contributor Insights rules. When rules are enabled, they
 * immediately begin analyzing log data.
 */
export declare const enableInsightRules: API.OperationMethod<EnableInsightRulesInput & RegionInput, EnableInsightRulesOutput, EnableInsightRulesError, Credentials | HttpClient.HttpClient>;
export type GetAlarmMuteRuleError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details for a specific alarm mute rule.
 *
 * This operation returns complete information about the mute rule, including its
 * configuration, status, targeted alarms, and metadata.
 *
 * The returned status indicates the current state of the mute rule:
 *
 * - **SCHEDULED**: The mute rule is configured and
 * will become active in the future
 *
 * - **ACTIVE**: The mute rule is currently muting
 * alarm actions
 *
 * - **EXPIRED**: The mute rule has passed its
 * expiration date and will no longer become active
 *
 * **Permissions**
 *
 * To retrieve details for a mute rule, you need the
 * `cloudwatch:GetAlarmMuteRule` permission on the alarm mute rule
 * resource.
 */
export declare const getAlarmMuteRule: API.OperationMethod<GetAlarmMuteRuleInput & RegionInput, GetAlarmMuteRuleOutput, GetAlarmMuteRuleError, Credentials | HttpClient.HttpClient>;
export type GetDashboardError = DashboardNotFoundError | InternalServiceFault | InvalidParameterValueException | CommonErrors;
/**
 * Displays the details of the dashboard that you specify.
 *
 * To copy an existing dashboard, use `GetDashboard`, and then use the data
 * returned within `DashboardBody` as the template for the new dashboard when
 * you call `PutDashboard` to create the copy.
 *
 * You might have recently enabled an opt-in Region (Region that is disabled by default) for your account. In
 * that Region, `GetDashboard` can return an access denied error for up to 24
 * hours after you enable the Region. This delay occurs while dashboard data propagates.
 * The error does not
 * indicate a problem with your permissions. Because dashboards are global, you can call
 * `GetDashboard` in any other enabled Region, or retry after propagation
 * completes.
 */
export declare const getDashboard: API.OperationMethod<GetDashboardInput & RegionInput, GetDashboardOutput, GetDashboardError, Credentials | HttpClient.HttpClient>;
export type GetDatasetError = ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the specified dataset. This includes its identifier,
 * Amazon Resource Name (ARN), and any customer managed Amazon Web Services Key
 * Management Service (Amazon Web Services KMS) key that is currently associated with
 * it.
 *
 * Only the `default` dataset is supported. The `default` dataset
 * is implicit for every account in every Region -- you can call `GetDataset`
 * for it without first creating it. If no customer managed KMS key has been associated
 * with the dataset, the response omits the `KmsKeyArn` field, indicating that
 * data is encrypted at rest using an Amazon Web Services owned key managed by
 * Amazon CloudWatch.
 *
 * To associate a customer managed KMS key with a dataset, use AssociateDatasetKmsKey. To remove the association, use DisassociateDatasetKmsKey.
 */
export declare const getDataset: API.OperationMethod<GetDatasetInput & RegionInput, GetDatasetOutput, GetDatasetError, Credentials | HttpClient.HttpClient>;
export type GetInsightRuleReportError = InvalidParameterValueException | MissingRequiredParameterException | ResourceNotFoundException | CommonErrors;
/**
 * This operation returns the time series data collected by a Contributor Insights rule.
 * The data includes the identity and number of contributors to the log group.
 *
 * You can also optionally return one or more statistics about each data point in the
 * time series. These statistics can include the following:
 *
 * - `UniqueContributors` -- the number of unique contributors for each
 * data point.
 *
 * - `MaxContributorValue` -- the value of the top contributor for each
 * data point. The identity of the contributor might change for each data point in
 * the graph.
 *
 * If this rule aggregates by COUNT, the top contributor for each data point is
 * the contributor with the most occurrences in that period. If the rule aggregates
 * by SUM, the top contributor is the contributor with the highest sum in the log
 * field specified by the rule's `Value`, during that period.
 *
 * - `SampleCount` -- the number of data points matched by the
 * rule.
 *
 * - `Sum` -- the sum of the values from all contributors during the
 * time period represented by that data point.
 *
 * - `Minimum` -- the minimum value from a single observation during the
 * time period represented by that data point.
 *
 * - `Maximum` -- the maximum value from a single observation during the
 * time period represented by that data point.
 *
 * - `Average` -- the average value from all contributors during the
 * time period represented by that data point.
 */
export declare const getInsightRuleReport: API.OperationMethod<GetInsightRuleReportInput & RegionInput, GetInsightRuleReportOutput, GetInsightRuleReportError, Credentials | HttpClient.HttpClient>;
export type GetMetricDataError = InvalidNextToken | CommonErrors;
/**
 * You can use the `GetMetricData` API to retrieve CloudWatch metric
 * values. The operation can also include a CloudWatch Metrics Insights query, and
 * one or more metric math functions.
 *
 * A `GetMetricData` operation that does not include a query can retrieve
 * as many as 500 different metrics in a single request, with a total of as many as 100,800
 * data points. You can also optionally perform metric math expressions on the values of
 * the returned statistics, to create new time series that represent new insights into your
 * data. For example, using Lambda metrics, you could divide the Errors metric by the
 * Invocations metric to get an error rate time series. For more information about metric
 * math expressions, see Metric Math Syntax and Functions in the Amazon CloudWatch User
 * Guide.
 *
 * If you include a Metrics Insights query, each `GetMetricData` operation can
 * include only one query. But the same `GetMetricData` operation can also
 * retrieve other metrics. Metrics Insights queries can query the most recent two weeks of
 * metric data. For alarm condition evaluations, Metrics Insights queries can query only
 * the most recent three hours of metric data. For more information about Metrics Insights,
 * see Query your metrics with CloudWatch Metrics Insights.
 *
 * Calls to the `GetMetricData` API have a different pricing structure than
 * calls to `GetMetricStatistics`. For more information about pricing, see
 * Amazon CloudWatch
 * Pricing.
 *
 * Amazon CloudWatch retains metric data as follows:
 *
 * - Data points with a period of less than 60 seconds are available for 3
 * hours. These data points are high-resolution metrics and are available only for
 * custom metrics that have been defined with a `StorageResolution` of
 * 1.
 *
 * - Data points with a period of 60 seconds (1-minute) are available for 15
 * days.
 *
 * - Data points with a period of 300 seconds (5-minute) are available for 63
 * days.
 *
 * - Data points with a period of 3600 seconds (1 hour) are available for 455
 * days (15 months).
 *
 * Data points that are initially published with a shorter period are aggregated
 * together for long-term storage. For example, if you collect data using a period of 1
 * minute, the data remains available for 15 days with 1-minute resolution. After 15 days,
 * this data is still available, but is aggregated and retrievable only with a resolution
 * of 5 minutes. After 63 days, the data is further aggregated and is available with a
 * resolution of 1 hour.
 *
 * If you omit `Unit` in your request, all data that was collected with any
 * unit is returned, along with the corresponding units that were specified when the data
 * was reported to CloudWatch. If you specify a unit, the operation returns only data that
 * was collected with that unit specified. If you specify a unit that does not match the
 * data collected, the results of the operation are null. CloudWatch does not perform unit
 * conversions.
 *
 * Using Metrics Insights queries with metric
 * math
 *
 * You can't mix a Metric Insights query and metric math syntax in the same expression,
 * but you can reference results from a Metrics Insights query within other Metric math
 * expressions. A Metrics Insights query without a GROUP
 * BY clause returns a single time-series (TS), and can be used as input for
 * a metric math expression that expects a single time series. A Metrics Insights query
 * with a **GROUP BY** clause returns an array of time-series
 * (TS[]), and can be used as input for a metric math expression that expects an array of
 * time series.
 */
export declare const getMetricData: API.PaginatedOperationMethod<GetMetricDataInput & RegionInput, GetMetricDataOutput, GetMetricDataError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMetricDataQueryDefinitionError = ResourceNotFoundException | CommonErrors;
/**
 * Returns a metric data query definition, including its expression.
 *
 * **Permissions**
 *
 * To get a definition, you need the
 * `cloudwatch:GetMetricDataQueryDefinition` permission on the metric data
 * query definition resource. You can use the `aws:ResourceTag/${TagKey}`
 * condition key to control access based on the tags of the definition.
 */
export declare const getMetricDataQueryDefinition: API.OperationMethod<GetMetricDataQueryDefinitionInput & RegionInput, GetMetricDataQueryDefinitionOutput, GetMetricDataQueryDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetMetricStatisticsError = InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Gets statistics for the specified metric.
 *
 * The maximum number of data points returned from a single call is 1,440. If you
 * request more than 1,440 data points, CloudWatch returns an error. To reduce the number
 * of data points, you can narrow the specified time range and make multiple requests
 * across adjacent time ranges, or you can increase the specified period. Data points are
 * not returned in chronological order.
 *
 * CloudWatch aggregates data points based on the length of the period that you
 * specify. For example, if you request statistics with a one-hour period, CloudWatch
 * aggregates all data points with time stamps that fall within each one-hour period.
 * Therefore, the number of values aggregated by CloudWatch is larger than the number of
 * data points returned.
 *
 * CloudWatch needs raw data points to calculate percentile statistics. If you publish
 * data using a statistic set instead, you can only retrieve percentile statistics for this
 * data if one of the following conditions is true:
 *
 * - The SampleCount value of the statistic set is 1.
 *
 * - The Min and the Max values of the statistic set are equal.
 *
 * Percentile statistics are not available for metrics when any of the metric values
 * are negative numbers.
 *
 * Amazon CloudWatch retains metric data as follows:
 *
 * - Data points with a period of less than 60 seconds are available for 3
 * hours. These data points are high-resolution metrics and are available only for
 * custom metrics that have been defined with a `StorageResolution` of
 * 1.
 *
 * - Data points with a period of 60 seconds (1-minute) are available for 15
 * days.
 *
 * - Data points with a period of 300 seconds (5-minute) are available for 63
 * days.
 *
 * - Data points with a period of 3600 seconds (1 hour) are available for 455
 * days (15 months).
 *
 * Data points that are initially published with a shorter period are aggregated
 * together for long-term storage. For example, if you collect data using a period of 1
 * minute, the data remains available for 15 days with 1-minute resolution. After 15 days,
 * this data is still available, but is aggregated and retrievable only with a resolution
 * of 5 minutes. After 63 days, the data is further aggregated and is available with a
 * resolution of 1 hour.
 *
 * CloudWatch started retaining 5-minute and 1-hour metric data as of July 9,
 * 2016.
 *
 * For information about metrics and dimensions supported by Amazon Web Services
 * services, see the Amazon CloudWatch
 * Metrics and Dimensions Reference in the Amazon CloudWatch User
 * Guide.
 */
export declare const getMetricStatistics: API.OperationMethod<GetMetricStatisticsInput & RegionInput, GetMetricStatisticsOutput, GetMetricStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetMetricStreamError = InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | MissingRequiredParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the metric stream that you specify.
 */
export declare const getMetricStream: API.OperationMethod<GetMetricStreamInput & RegionInput, GetMetricStreamOutput, GetMetricStreamError, Credentials | HttpClient.HttpClient>;
export type GetMetricWidgetImageError = CommonErrors;
/**
 * You can use the `GetMetricWidgetImage` API to retrieve a snapshot graph
 * of one or more Amazon CloudWatch metrics as a bitmap image. You can then embed this
 * image into your services and products, such as wiki pages, reports, and documents. You
 * could also retrieve images regularly, such as every minute, and create your own custom
 * live dashboard.
 *
 * `GetMetricWidgetImage` is not available in the Amazon Web Services
 * GovCloud (US) Regions. In those Regions, calls to this operation fail. For the list
 * of Amazon CloudWatch features that are not available in Amazon Web Services
 * GovCloud (US), see Amazon CloudWatch in
 * Amazon Web Services GovCloud (US).
 *
 * The graph you retrieve can include all CloudWatch metric graph features, including
 * metric math and horizontal and vertical annotations.
 *
 * There is a limit of 20 transactions per second for this API. Each
 * `GetMetricWidgetImage` action has the following limits:
 *
 * - As many as 100 metrics in the graph.
 *
 * - Up to 100 KB uncompressed payload.
 */
export declare const getMetricWidgetImage: API.OperationMethod<GetMetricWidgetImageInput & RegionInput, GetMetricWidgetImageOutput, GetMetricWidgetImageError, Credentials | HttpClient.HttpClient>;
export type GetOTelEnrichmentError = CommonErrors;
/**
 * Returns the current status of vended metric enrichment for the account, including
 * whether CloudWatch vended metrics are enriched with resource ARN and resource tag labels
 * and queryable using PromQL. For the list of supported resources, see Supported Amazon Web Services infrastructure metrics.
 */
export declare const getOTelEnrichment: API.OperationMethod<GetOTelEnrichmentInput & RegionInput, GetOTelEnrichmentOutput, GetOTelEnrichmentError, Credentials | HttpClient.HttpClient>;
export type GetResourceMetricsConfigurationError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the current resource metrics configuration for an Amazon Web Services
 * resource. The response includes the resource ARN, any metric selections, and the times
 * at which the configuration was created and last updated.
 *
 * This operation returns a `ResourceNotFoundException` if no resource metrics
 * configuration exists for the specified resource ARN. To create a configuration, use CreateResourceMetricsConfiguration.
 *
 * To retrieve a resource metrics configuration, you must have the
 * `cloudwatch:GetResourceMetricsConfiguration` permission. For information
 * about scoping this permission to specific resources, see Condition keys for resource metrics configuration access in the
 * *Amazon CloudWatch User Guide*.
 */
export declare const getResourceMetricsConfiguration: API.OperationMethod<GetResourceMetricsConfigurationInput & RegionInput, GetResourceMetricsConfigurationOutput, GetResourceMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAlarmMuteRulesError = InvalidNextToken | ResourceNotFoundException | CommonErrors;
/**
 * Lists alarm mute rules in your Amazon Web Services account and region.
 *
 * You can filter the results by alarm name to find all mute rules targeting a specific
 * alarm, or by status to find rules that are scheduled, active, or expired.
 *
 * This operation supports pagination for accounts with many mute rules. Use the
 * `MaxRecords` and `NextToken` parameters to retrieve results in
 * multiple calls.
 *
 * **Permissions**
 *
 * To list mute rules, you need the `cloudwatch:ListAlarmMuteRules`
 * permission.
 */
export declare const listAlarmMuteRules: API.PaginatedOperationMethod<ListAlarmMuteRulesInput & RegionInput, ListAlarmMuteRulesOutput, ListAlarmMuteRulesError, Credentials | HttpClient.HttpClient, AlarmMuteRuleSummary>;
export type ListDashboardsError = InternalServiceFault | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of the dashboards for your account. If you include
 * `DashboardNamePrefix`, only those dashboards with names starting with the
 * prefix are listed. Otherwise, all dashboards in your account are listed.
 *
 * `ListDashboards` returns up to 1000 results on one page. If there are
 * more than 1000 dashboards, you can call `ListDashboards` again and include
 * the value you received for `NextToken` in the first call, to receive the next
 * 1000 results.
 *
 * You might have recently enabled an opt-in Region (Region that is disabled by default) for your account. In
 * that Region, `ListDashboards` can return an access denied error for up to 24
 * hours after you enable the Region. This delay occurs while dashboard data propagates.
 * The error does not
 * indicate a problem with your permissions. Because dashboards are global, you can call
 * `ListDashboards` in any other enabled Region, or retry after propagation
 * completes.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsInput & RegionInput, ListDashboardsOutput, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardEntry>;
export type ListManagedInsightRulesError = InvalidNextToken | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Returns a list that contains the number of managed Contributor Insights rules in your
 * account.
 */
export declare const listManagedInsightRules: API.PaginatedOperationMethod<ListManagedInsightRulesInput & RegionInput, ListManagedInsightRulesOutput, ListManagedInsightRulesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMetricDataQueryDefinitionsError = CommonErrors;
/**
 * Lists the metric data query definitions in your account and Region.
 *
 * The results are summaries that don't include the expression. To get the full
 * definition, call `GetMetricDataQueryDefinition` with its ID.
 *
 * This operation supports pagination. Use the `MaxResults` and
 * `NextToken` parameters to retrieve results in multiple calls.
 *
 * **Permissions**
 *
 * To list definitions, you need the
 * `cloudwatch:ListMetricDataQueryDefinitions` permission. This permission
 * applies to all definitions in the account and Region. The results aren't filtered by
 * tags.
 */
export declare const listMetricDataQueryDefinitions: API.PaginatedOperationMethod<ListMetricDataQueryDefinitionsInput & RegionInput, ListMetricDataQueryDefinitionsOutput, ListMetricDataQueryDefinitionsError, Credentials | HttpClient.HttpClient, MetricDataQueryDefinitionSummary>;
export type ListMetricsError = InternalServiceFault | InvalidParameterValueException | CommonErrors;
/**
 * List the specified metrics. You can use the returned metrics with GetMetricData or GetMetricStatistics to get statistical data.
 *
 * Up to 500 results are returned for any one call. To retrieve additional results,
 * use the returned token with subsequent calls.
 *
 * After you create a metric, allow up to 15 minutes for the metric to appear. To see
 * metric statistics sooner, use GetMetricData or GetMetricStatistics.
 *
 * If you are using CloudWatch cross-account observability, you can use this
 * operation in a monitoring account and view metrics from the linked source accounts. For
 * more information, see CloudWatch cross-account observability.
 *
 * `ListMetrics` doesn't return information about metrics if those metrics
 * haven't reported data in the past two weeks. To retrieve those metrics, use GetMetricData or GetMetricStatistics.
 */
export declare const listMetrics: API.PaginatedOperationMethod<ListMetricsInput & RegionInput, ListMetricsOutput, ListMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMetricStreamsError = InternalServiceFault | InvalidNextToken | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Returns a list of metric streams in this account.
 */
export declare const listMetricStreams: API.PaginatedOperationMethod<ListMetricStreamsInput & RegionInput, ListMetricStreamsOutput, ListMetricStreamsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceFault | InvalidParameterValueException | ResourceNotFoundException | CommonErrors;
/**
 * Displays the tags associated with a CloudWatch resource. Currently, alarms,
 * dashboards, metric streams and Contributor Insights rules support tagging.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAlarmMuteRuleError = LimitExceededFault | CommonErrors;
/**
 * Creates or updates an alarm mute rule.
 *
 * Alarm mute rules automatically mute alarm actions during predefined time windows. When
 * a mute rule is active, targeted alarms continue to evaluate metrics and transition
 * between states, but their configured actions (such as Amazon SNS notifications
 * or Auto Scaling actions) are muted.
 *
 * You can create mute rules with recurring schedules using `cron` expressions
 * or one-time mute windows using `at` expressions. Each mute rule can target up
 * to 100 specific alarms by name.
 *
 * If you specify a rule name that already exists, this operation updates the existing
 * rule with the new configuration.
 *
 * **Permissions**
 *
 * To create or update a mute rule, you must have the
 * `cloudwatch:PutAlarmMuteRule` permission on two types of resources: the
 * alarm mute rule resource itself, and each alarm that the rule targets.
 *
 * For example, If you want to allow a user to create mute rules that target only
 * specific alarms named "WebServerCPUAlarm" and "DatabaseConnectionAlarm", you would
 * create an IAM policy with one statement granting
 * `cloudwatch:PutAlarmMuteRule` on the alarm mute rule resource
 * (`arn:aws:cloudwatch:[REGION]:123456789012:alarm-mute-rule:*`), and
 * another statement granting `cloudwatch:PutAlarmMuteRule` on the targeted
 * alarm resources
 * (`arn:aws:cloudwatch:[REGION]:123456789012:alarm:WebServerCPUAlarm` and
 * `arn:aws:cloudwatch:[REGION]:123456789012:alarm:DatabaseConnectionAlarm`).
 *
 * You can also use IAM policy conditions to allow targeting alarms based on resource
 * tags. For example, you can restrict users to create/update mute rules to only target
 * alarms that have a specific tag key-value pair, such as `Team=TeamA`.
 */
export declare const putAlarmMuteRule: API.OperationMethod<PutAlarmMuteRuleInput & RegionInput, PutAlarmMuteRuleResponse, PutAlarmMuteRuleError, Credentials | HttpClient.HttpClient>;
export type PutAnomalyDetectorError = InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | LimitExceededException | MissingRequiredParameterException | CommonErrors;
/**
 * Creates an anomaly detection model for a CloudWatch metric. You can use the model to
 * display a band of expected normal values when the metric is graphed.
 *
 * If you have enabled unified cross-account observability, and this account is a
 * monitoring account, the metric can be in the same account or a source account. You can
 * specify the account ID in the object you specify in the
 * `SingleMetricAnomalyDetector` parameter.
 *
 * For more information, see CloudWatch Anomaly Detection.
 */
export declare const putAnomalyDetector: API.OperationMethod<PutAnomalyDetectorInput & RegionInput, PutAnomalyDetectorOutput, PutAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type PutCompositeAlarmError = LimitExceededFault | CommonErrors;
/**
 * Creates or updates a *composite alarm*. When you create a composite
 * alarm, you specify a rule expression for the alarm that takes into account the alarm
 * states of other alarms that you have created. The composite alarm goes into ALARM state
 * only if all conditions of the rule are met.
 *
 * The alarms specified in a composite alarm's rule expression can include metric alarms
 * and other composite alarms. The rule expression of a composite alarm can include as many
 * as 100 underlying alarms. Any single alarm can be included in the rule expressions of as
 * many as 150 composite alarms.
 *
 * Using composite alarms can reduce alarm noise. You can create multiple metric alarms,
 * and also create a composite alarm and set up alerts only for the composite alarm. For
 * example, you could create a composite alarm that goes into ALARM state only when more
 * than one of the underlying metric alarms are in ALARM state.
 *
 * Composite alarms can take the following actions:
 *
 * - Notify Amazon SNS topics.
 *
 * - Invoke Lambda functions.
 *
 * - Create OpsItems in Systems Manager Ops Center.
 *
 * - Create incidents in Systems Manager Incident Manager.
 *
 * It is possible to create a loop or cycle of composite alarms, where composite
 * alarm A depends on composite alarm B, and composite alarm B also depends on
 * composite alarm A. In this scenario, you can't delete any composite alarm that is
 * part of the cycle because there is always still a composite alarm that depends on
 * that alarm that you want to delete.
 *
 * To get out of such a situation, you must break the cycle by changing the rule of
 * one of the composite alarms in the cycle to remove a dependency that creates the
 * cycle. The simplest change to make to break a cycle is to change the
 * `AlarmRule` of one of the alarms to `false`.
 *
 * Additionally, the evaluation of composite alarms stops if CloudWatch detects a
 * cycle in the evaluation path.
 *
 * When this operation creates an alarm, the alarm state is immediately set to
 * `INSUFFICIENT_DATA`. The alarm is then evaluated and its state is set
 * appropriately. Any actions associated with the new state are then executed. For a
 * composite alarm, this initial time after creation is the only time that the alarm can be
 * in `INSUFFICIENT_DATA` state.
 *
 * When you update an existing alarm, its state is left unchanged, but the update
 * completely overwrites the previous configuration of the alarm.
 *
 * To use this operation, you must be signed on with the
 * `cloudwatch:PutCompositeAlarm` permission that is scoped to
 * `*`. You can't create a composite alarms if your
 * `cloudwatch:PutCompositeAlarm` permission has a narrower scope.
 *
 * If you are an IAM user, you must have
 * `iam:CreateServiceLinkedRole` to create a composite alarm that has
 * Systems Manager OpsItem actions.
 */
export declare const putCompositeAlarm: API.OperationMethod<PutCompositeAlarmInput & RegionInput, PutCompositeAlarmResponse, PutCompositeAlarmError, Credentials | HttpClient.HttpClient>;
export type PutDashboardError = ConflictException | DashboardInvalidInputError | InternalServiceFault | CommonErrors;
/**
 * Creates a dashboard if it does not already exist, or updates an existing dashboard.
 * If you update a dashboard, the entire contents are replaced with what you specify
 * here.
 *
 * All dashboards in your account are global, not region-specific.
 *
 * A simple way to create a dashboard using `PutDashboard` is to copy an
 * existing dashboard. To copy an existing dashboard using the console, you can load the
 * dashboard and then use the View/edit source command in the Actions menu to display the
 * JSON block for that dashboard. Another way to copy a dashboard is to use
 * `GetDashboard`, and then use the data returned within
 * `DashboardBody` as the template for the new dashboard when you call
 * `PutDashboard`.
 *
 * When you create a dashboard with `PutDashboard`, a good practice is to
 * add a text widget at the top of the dashboard with a message that the dashboard was
 * created by script and should not be changed in the console. This message could also
 * point console users to the location of the `DashboardBody` script or the
 * CloudFormation template used to create the dashboard.
 */
export declare const putDashboard: API.OperationMethod<PutDashboardInput & RegionInput, PutDashboardOutput, PutDashboardError, Credentials | HttpClient.HttpClient>;
export type PutInsightRuleError = InvalidParameterValueException | LimitExceededException | MissingRequiredParameterException | CommonErrors;
/**
 * Creates a Contributor Insights rule. Rules evaluate log events in a CloudWatch Logs
 * log group, enabling you to find contributor data for the log events in that log group.
 * For more information, see Using Contributor
 * Insights to Analyze High-Cardinality Data.
 *
 * If you create a rule, delete it, and then re-create it with the same name, historical
 * data from the first time the rule was created might not be available.
 */
export declare const putInsightRule: API.OperationMethod<PutInsightRuleInput & RegionInput, PutInsightRuleOutput, PutInsightRuleError, Credentials | HttpClient.HttpClient>;
export type PutLogAlarmError = LimitExceededFault | ResourceConflict | CommonErrors;
/**
 * Creates or updates a log alarm. A log alarm evaluates the results of a CloudWatch Logs scheduled query against the configured threshold and comparison operator to determine its state.
 *
 * When you create a log alarm, the operation creates a service-managed CloudWatch Logs scheduled query that runs the query string you provide on the schedule you configure. Each scheduled query execution returns one or more aggregated values determined by the `AggregationExpression`, and each aggregated value is compared against the alarm `Threshold` to determine the alarm state. The alarm uses M-out-of-N evaluation: if `QueryResultsToAlarm` out of the most recent `QueryResultsToEvaluate` query results breach the threshold, the alarm transitions to `ALARM`.
 *
 * Log alarms support the alarm states (`OK`, `ALARM`, `INSUFFICIENT_DATA`). Configure transition actions using `OKActions`, `AlarmActions`, and `InsufficientDataActions`.
 *
 * If you call this operation with the name of an existing log alarm, the operation replaces the previous configuration of that alarm.
 *
 * **Permissions**
 *
 * To create or update a log alarm, you must have the `cloudwatch:PutLogAlarm` permission. The IAM role specified in `ScheduledQueryRoleARN` must grant the CloudWatch Alarms service permission to execute scheduled queries on the specified log groups. If you set `ActionLogLineCount`, the role specified in `ActionLogLineRoleArn` must grant permission to retrieve log events for inclusion in alarm notifications.
 */
export declare const putLogAlarm: API.OperationMethod<PutLogAlarmInput & RegionInput, PutLogAlarmResponse, PutLogAlarmError, Credentials | HttpClient.HttpClient>;
export type PutManagedInsightRulesError = InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Creates a managed Contributor Insights rule for a specified Amazon Web Services
 * resource. When you enable a managed rule, you create a Contributor Insights rule that
 * collects data from Amazon Web Services services. You cannot edit these rules with
 * `PutInsightRule`. The rules can be enabled, disabled, and deleted using
 * `EnableInsightRules`, `DisableInsightRules`, and
 * `DeleteInsightRules`. If a previously created managed rule is currently
 * disabled, a subsequent call to this API will re-enable it. Use
 * `ListManagedInsightRules` to describe all available rules.
 */
export declare const putManagedInsightRules: API.OperationMethod<PutManagedInsightRulesInput & RegionInput, PutManagedInsightRulesOutput, PutManagedInsightRulesError, Credentials | HttpClient.HttpClient>;
export type PutMetricAlarmError = LimitExceededFault | CommonErrors;
/**
 * Creates or updates an alarm and associates it with the specified metric, metric
 * math expression, anomaly detection model, Metrics Insights query, or PromQL query. For
 * more information about using a Metrics Insights query for an alarm, see Create
 * alarms on Metrics Insights queries.
 *
 * Alarms based on anomaly detection models cannot have Auto Scaling actions.
 *
 * When this operation creates an alarm, the alarm state is immediately set to
 * `INSUFFICIENT_DATA`. For PromQL alarms, the alarm state is instead
 * immediately set to `OK`. The alarm is then evaluated and its state is set
 * appropriately. Any actions associated with the new state are then executed.
 *
 * When you update an existing alarm, its state is left unchanged, but the update
 * completely overwrites the previous configuration of the alarm.
 *
 * If you are an IAM user, you must have Amazon EC2 permissions for
 * some alarm operations:
 *
 * - The `iam:CreateServiceLinkedRole` permission for all alarms with
 * EC2 actions
 *
 * - The `iam:CreateServiceLinkedRole` permissions to create an alarm
 * with Systems Manager OpsItem or response plan actions.
 *
 * The first time you create an alarm in the Amazon Web Services Management Console, the CLI, or by using the PutMetricAlarm API, CloudWatch creates the necessary
 * service-linked role for you. The service-linked roles are called
 * `AWSServiceRoleForCloudWatchEvents` and
 * `AWSServiceRoleForCloudWatchAlarms_ActionSSM`. For more information, see
 * Amazon Web Services service-linked role.
 *
 * Each `PutMetricAlarm` action has a maximum uncompressed payload of 120
 * KB.
 *
 * **Cross-account alarms**
 *
 * You can set an alarm on metrics in the current account, or in another account. To
 * create a cross-account alarm that watches a metric in a different account, you must have
 * completed the following pre-requisites:
 *
 * - The account where the metrics are located (the sharing
 * account) must already have a sharing role named **CloudWatch-CrossAccountSharingRole**. If it does not
 * already have this role, you must create it using the instructions in **Set up a sharing account** in Cross-account cross-Region CloudWatch console. The policy
 * for that role must grant access to the ID of the account where you are creating
 * the alarm.
 *
 * - The account where you are creating the alarm (the monitoring
 * account) must already have a service-linked role named **AWSServiceRoleForCloudWatchCrossAccount** to allow
 * CloudWatch to assume the sharing role in the sharing account. If it
 * does not, you must create it following the directions in **Set up a monitoring account** in Cross-account cross-Region CloudWatch console.
 */
export declare const putMetricAlarm: API.OperationMethod<PutMetricAlarmInput & RegionInput, PutMetricAlarmResponse, PutMetricAlarmError, Credentials | HttpClient.HttpClient>;
export type PutMetricDataError = InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Publishes metric data to Amazon CloudWatch. CloudWatch associates the data with the
 * specified metric. If the specified metric does not exist, CloudWatch creates the metric.
 * When CloudWatch creates a metric, it can take up to fifteen minutes for the metric to
 * appear in calls to ListMetrics.
 *
 * You can publish metrics with associated entity data (so that related telemetry can be
 * found and viewed together), or publish metric data by itself. To send entity data with
 * your metrics, use the `EntityMetricData` parameter. To send metrics without
 * entity data, use the `MetricData` parameter. The
 * `EntityMetricData` structure includes `MetricData` structures
 * for the metric data.
 *
 * You can publish either individual values in the `Value` field, or arrays of
 * values and the number of times each value occurred during the period by using the
 * `Values` and `Counts` fields in the `MetricData`
 * structure. Using the `Values` and `Counts` method enables you to
 * publish up to 150 values per metric with one `PutMetricData` request, and
 * supports retrieving percentile statistics on this data.
 *
 * Each `PutMetricData` request is limited to 1 MB in size for HTTP POST
 * requests. You can send a payload compressed by gzip. Each request is also limited to no
 * more than 1000 different metrics (across both the `MetricData` and
 * `EntityMetricData` properties).
 *
 * Although the `Value` parameter accepts numbers of type `Double`,
 * CloudWatch rejects values that are either too small or too large. Values must be in the
 * range of -2^360 to 2^360. In addition, special values (for example, NaN, +Infinity,
 * -Infinity) are not supported.
 *
 * You can use up to 30 dimensions per metric to further clarify what data the metric
 * collects. Each dimension consists of a Name and Value pair. For more information about
 * specifying dimensions, see Publishing
 * Metrics in the *Amazon CloudWatch User Guide*.
 *
 * You specify the time stamp to be associated with each data point. You can specify time
 * stamps that are as much as two weeks before the current date, and as much as 2 hours
 * after the current day and time.
 *
 * Data points with time stamps from 24 hours ago or longer can take at least 48 hours to
 * become available for GetMetricData or GetMetricStatistics from the time they are submitted. Data points with time
 * stamps between 3 and 24 hours ago can take as much as 2 hours to become available for
 * GetMetricData or GetMetricStatistics.
 *
 * CloudWatch needs raw data points to calculate percentile statistics. If you publish
 * data using a statistic set instead, you can only retrieve percentile statistics for this
 * data if one of the following conditions is true:
 *
 * - The `SampleCount` value of the statistic set is 1 and
 * `Min`, `Max`, and `Sum` are all
 * equal.
 *
 * - The `Min` and `Max` are equal, and `Sum`
 * is equal to `Min` multiplied by `SampleCount`.
 */
export declare const putMetricData: API.OperationMethod<PutMetricDataInput & RegionInput, PutMetricDataResponse, PutMetricDataError, Credentials | HttpClient.HttpClient>;
export type PutMetricDataQueryDefinitionError = ConflictException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates a metric data query definition.
 *
 * A metric data query definition saves a metric query so that you can reuse it later.
 * It includes the query expression, the query language, and a path that names the
 * definition and can organize it into folders. When you save a definition,
 * CloudWatch doesn't validate or run its expression.
 *
 * To create a definition, omit `Id`. CloudWatch generates the ID and
 * returns it. To update a definition, specify its `Id`. An update replaces the
 * path, expression, and type, and keeps the creation time.
 *
 * The path must be unique in your account and Region. If another definition already
 * uses the path, the request fails with a `ConflictException`.
 *
 * You can have up to 1,000 metric data query definitions in each Region of your
 * account. A request that would create more fails with a
 * `LimitExceededException`.
 *
 * **Permissions**
 *
 * To create or update a definition, you need the
 * `cloudwatch:PutMetricDataQueryDefinition` permission on the metric data
 * query definition resource. The resource ARN has the format
 * `arn:aws:cloudwatch:Region:account-id:metric-query-definition/Id`.
 *
 * To add tags when you create a definition, you also need the
 * `cloudwatch:TagResource` permission. You can use the
 * `aws:RequestTag/${TagKey}` and `aws:TagKeys` condition keys
 * to control which tags can be added.
 */
export declare const putMetricDataQueryDefinition: API.OperationMethod<PutMetricDataQueryDefinitionInput & RegionInput, PutMetricDataQueryDefinitionOutput, PutMetricDataQueryDefinitionError, Credentials | HttpClient.HttpClient>;
export type PutMetricStreamError = ConcurrentModificationException | InternalServiceFault | InvalidParameterCombinationException | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Creates or updates a metric stream. Metric streams can automatically stream CloudWatch
 * metrics to Amazon Web Services destinations, including Amazon S3, and to many third-party
 * solutions.
 *
 * For more information, see Using
 * Metric Streams.
 *
 * To create a metric stream, you must be signed in to an account that has the
 * `iam:PassRole` permission and either the
 * `CloudWatchFullAccess` policy or the
 * `cloudwatch:PutMetricStream` permission.
 *
 * When you create or update a metric stream, you choose one of the following:
 *
 * - Stream metrics from all metric namespaces in the account.
 *
 * - Stream metrics from all metric namespaces in the account, except for the
 * namespaces that you list in `ExcludeFilters`.
 *
 * - Stream metrics from only the metric namespaces that you list in
 * `IncludeFilters`.
 *
 * By default, a metric stream always sends the `MAX`, `MIN`,
 * `SUM`, and `SAMPLECOUNT` statistics for each metric that is
 * streamed. You can use the `StatisticsConfigurations` parameter to have the
 * metric stream send additional statistics in the stream. Streaming additional statistics
 * incurs additional costs. For more information, see Amazon CloudWatch Pricing.
 *
 * When you use `PutMetricStream` to create a new metric stream, the stream is
 * created in the `running` state. If you use it to update an existing stream,
 * the state of the stream is not changed.
 *
 * If you are using CloudWatch cross-account observability and you create a metric
 * stream in a monitoring account, you can choose whether to include metrics from source
 * accounts in the stream. For more information, see CloudWatch cross-account observability.
 */
export declare const putMetricStream: API.OperationMethod<PutMetricStreamInput & RegionInput, PutMetricStreamOutput, PutMetricStreamError, Credentials | HttpClient.HttpClient>;
export type SetAlarmStateError = InvalidFormatFault | ResourceNotFound | CommonErrors;
/**
 * Temporarily sets the state of an alarm for testing purposes. When the updated state
 * differs from the previous value, the action configured for the appropriate state is
 * invoked. For example, if your alarm is configured to send an Amazon SNS message when an
 * alarm is triggered, temporarily changing the alarm state to `ALARM` sends an
 * SNS message.
 *
 * Metric alarms returns to their actual state quickly, often within seconds. Because
 * the metric alarm state change happens quickly, it is typically only visible in the
 * alarm's **History** tab in the Amazon CloudWatch console or
 * through DescribeAlarmHistory.
 *
 * If you use `SetAlarmState` on a composite alarm, the composite alarm is
 * not guaranteed to return to its actual state. It returns to its actual state only once
 * any of its children alarms change state. It is also reevaluated if you update its
 * configuration.
 *
 * If an alarm triggers EC2 Auto Scaling policies or application Auto Scaling
 * policies, you must include information in the `StateReasonData` parameter to
 * enable the policy to take the correct action.
 */
export declare const setAlarmState: API.OperationMethod<SetAlarmStateInput & RegionInput, SetAlarmStateResponse, SetAlarmStateError, Credentials | HttpClient.HttpClient>;
export type StartMetricStreamsError = InternalServiceFault | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Starts the streaming of metrics for one or more of your metric streams.
 */
export declare const startMetricStreams: API.OperationMethod<StartMetricStreamsInput & RegionInput, StartMetricStreamsOutput, StartMetricStreamsError, Credentials | HttpClient.HttpClient>;
export type StartOTelEnrichmentError = ValidationException | CommonErrors;
/**
 * Enables enrichment and PromQL access for CloudWatch vended metrics for supported Amazon Web Services resources in the account. Once enabled,
 * metrics that contain a resource identifier dimension (for example, EC2
 * `CPUUtilization` with an `InstanceId` dimension) are enriched
 * with resource ARN and resource tag labels and become queryable using PromQL.
 *
 * Before calling this operation, you must enable resource tags on telemetry for your
 * account. For more information, see Enable
 * resource tags on telemetry.
 *
 * Optionally, `IncludeFilters` and `ExcludeFilters` limit
 * enrichment to a subset of the account's metrics. These filters are stored only when this
 * operation starts enrichment. Calling `StartOTelEnrichment` for an account
 * where enrichment is already running has no effect and does not modify the filters that
 * are applied. To change them, use UpdateOTelEnrichment.
 */
export declare const startOTelEnrichment: API.OperationMethod<StartOTelEnrichmentInput & RegionInput, StartOTelEnrichmentOutput, StartOTelEnrichmentError, Credentials | HttpClient.HttpClient>;
export type StopMetricStreamsError = InternalServiceFault | InvalidParameterValueException | MissingRequiredParameterException | CommonErrors;
/**
 * Stops the streaming of metrics for one or more of your metric streams.
 */
export declare const stopMetricStreams: API.OperationMethod<StopMetricStreamsInput & RegionInput, StopMetricStreamsOutput, StopMetricStreamsError, Credentials | HttpClient.HttpClient>;
export type StopOTelEnrichmentError = CommonErrors;
/**
 * Disables enrichment and PromQL access for CloudWatch vended metrics for supported Amazon Web Services resources in the account. After disabling,
 * these metrics are no longer enriched with resource ARN and resource tag labels, and
 * cannot be queried using PromQL.
 */
export declare const stopOTelEnrichment: API.OperationMethod<StopOTelEnrichmentInput & RegionInput, StopOTelEnrichmentOutput, StopOTelEnrichmentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | ConflictException | InternalServiceFault | InvalidParameterValueException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified CloudWatch resource.
 * Currently, the only CloudWatch resources that can be tagged are alarms, dashboards,
 * metric streams and Contributor Insights rules.
 *
 * Tags can help you organize and categorize your resources. You can also use them to
 * scope user permissions by granting a user permission to access or change only resources
 * with certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted
 * strictly as strings of characters.
 *
 * You can use the `TagResource` action with an alarm that already has tags.
 * If you specify a new tag key for the alarm, this tag is appended to the list of tags
 * associated with the alarm. If you specify a tag key that is already associated with the
 * alarm, the new tag value that you specify replaces the previous value for that
 * tag.
 *
 * You can associate as many as 50 tags with a CloudWatch resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | ConflictException | InternalServiceFault | InvalidParameterValueException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified resource. Currently, alarms, dashboards,
 * metric streams and Contributor Insights rules support tagging.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateOTelEnrichmentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Replaces the filters that determine which CloudWatch vended metrics are enriched
 * with resource ARN and resource tag labels for the account. Enrichment must already be
 * running for the account. If it is not, this operation returns a
 * `ResourceNotFoundException`. To start enrichment, use StartOTelEnrichment.
 *
 * The filters in the request completely replace the stored filters; they are not
 * merged with them. `IncludeFilters` and `ExcludeFilters` are
 * replaced as a pair, so a request that specifies only `IncludeFilters` also
 * clears the stored `ExcludeFilters`, and a request that specifies neither
 * clears both.
 */
export declare const updateOTelEnrichment: API.OperationMethod<UpdateOTelEnrichmentInput & RegionInput, UpdateOTelEnrichmentOutput, UpdateOTelEnrichmentError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceMetricsConfigurationError = ResourceNotFoundException | CommonErrors;
/**
 * Updates the resource metrics configuration for an Amazon Web Services resource. The
 * `MetricSelections` value that you provide replaces any existing metric
 * selections for the resource; it is not merged with them.
 *
 * If you omit `MetricSelections`, Amazon CloudWatch removes any existing
 * metric selection filter and collects all available detailed metrics for the
 * resource.
 *
 * This operation returns a `ResourceNotFoundException` if no resource metrics
 * configuration exists for the specified resource ARN. To create a configuration, use
 * CreateResourceMetricsConfiguration.
 *
 * To update a resource metrics configuration, you must have the
 * `cloudwatch:UpdateResourceMetricsConfiguration` permission. For information about scoping
 * this permission to specific resources, see Condition keys for resource metrics configuration access in the
 * *Amazon CloudWatch User Guide*.
 */
export declare const updateResourceMetricsConfiguration: API.OperationMethod<UpdateResourceMetricsConfigurationInput & RegionInput, UpdateResourceMetricsConfigurationOutput, UpdateResourceMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudwatch.d.ts.map