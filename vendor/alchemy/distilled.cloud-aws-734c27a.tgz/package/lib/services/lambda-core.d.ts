import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const NetworkConnectorLimitExceededException_base: S.TaggedErrorClass<"NetworkConnectorLimitExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkConnectorLimitExceededException extends /*@__PURE__*/ NetworkConnectorLimitExceededException_base {
}
declare const OperatorRoleNotAssumable_base: S.TaggedErrorClass<"OperatorRoleNotAssumable", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class OperatorRoleNotAssumable extends /*@__PURE__*/ OperatorRoleNotAssumable_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly retryAfterSeconds: any;
    readonly Type: any;
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type NetworkConnectorName = string;
export type NetworkConnectorSubnetId = string;
export type NetworkConnectorSubnetIds = string[];
export type NetworkConnectorSecurityGroupId = string;
export type NetworkConnectorSecurityGroupIds = string[];
export type NetworkProtocol = "IPv4" | "DualStack" | (string & {});
export type ComputeResourceType = "MicroVm" | "WebFunction" | (string & {});
export type AssociatedComputeResourceTypesList = ComputeResourceType[];
export interface NetworkConnectorVpcEgressConfiguration {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    NetworkProtocol?: NetworkProtocol | undefined;
    AssociatedComputeResourceTypes?: ComputeResourceType[] | undefined;
}
export type NetworkConnectorConfiguration = {
    VpcEgressConfiguration: NetworkConnectorVpcEgressConfiguration;
};
export type NetworkConnectorRoleArn = string;
export type ClientTokenString = string;
export type NetworkConnectorTagKey = string;
export type NetworkConnectorTagValue = string;
export type NetworkConnectorTags = {
    [key: string]: string | undefined;
};
export interface CreateNetworkConnectorRequest {
    Name: string;
    Configuration: NetworkConnectorConfiguration;
    OperatorRole?: string | undefined;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkConnectorArn = string;
export type NetworkConnectorId = string;
export type NetworkConnectorVersion = number;
export type NetworkConnectorState = "PENDING" | "ACTIVE" | "INACTIVE" | "FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface CreateNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string | undefined;
    Version?: number | undefined;
    Configuration?: NetworkConnectorConfiguration | undefined;
    OperatorRole?: string | undefined;
    State?: NetworkConnectorState | undefined;
}
export type RuntimeName = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type RuntimeDescription = string;
export type RuntimeLicenseInfo = string;
export type RuntimeReleaseState = "PREVIEW" | "GA" | "DEPRECATED" | (string & {});
export type RuntimeLifecycleDate = string;
export interface RuntimeReleaseLifecycle {
    ReleaseState?: RuntimeReleaseState | undefined;
    DeprecationDate?: string | undefined;
    FunctionCreateBlockDate?: string | undefined;
    FunctionUpdateBlockDate?: string | undefined;
}
export interface CreateRuntimeRequest {
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
}
export type RuntimeArn = string;
export type RuntimeTimestamp = string;
export interface CreateRuntimeResponse {
    Arn: string;
    Name: string;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export type RuntimeIdentifier = string;
export type RuntimeVersionName = string;
export type RuntimeAliasName = string;
export type RuntimeAliasDescription = string;
export interface CreateRuntimeAliasRequest {
    RuntimeName: string;
    RuntimeVersion: string;
    Name: string;
    Description?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
}
export type RuntimeAliasState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "PENDING_DELETION" | (string & {});
export interface CreateRuntimeAliasResponse {
    Name: string;
    Arn: string;
    RuntimeVersion: string;
    RuntimeVersionArn: string;
    State: RuntimeAliasState;
    Description?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export interface CreateRuntimeVersionRequest {
    RuntimeName: string;
    ImageUri: string;
    Name: string;
    ReleaseNotes?: string | undefined;
    DryRun?: boolean | undefined;
}
export type RuntimeVersionState = "CREATING" | "ACTIVE" | "FAILED" | "DELETING" | "PENDING_DELETION" | (string & {});
export interface Platform {
    Architecture: string;
    Os: string;
    Digest: string;
}
export type PlatformList = Platform[];
export type IntegrationModel = "RuntimeAPI" | (string & {});
export type IntegrationModelList = IntegrationModel[];
export type RuntimeArchitecture = "x86_64" | "arm64" | (string & {});
export type RuntimeArchitectureList = RuntimeArchitecture[];
export type CompatibilityPolicy = "Supported" | "NotSupported" | (string & {});
export interface Compatibility {
    IntegrationModels?: IntegrationModel[] | undefined;
    Architectures?: RuntimeArchitecture[] | undefined;
    ManagedInstances?: CompatibilityPolicy | undefined;
}
export interface CreateRuntimeVersionResponse {
    Name: string;
    Arn: string;
    ResolvedUri: string;
    State: RuntimeVersionState;
    ReleaseNotes?: string | undefined;
    Platforms?: Platform[] | undefined;
    Compatibility?: Compatibility | undefined;
    Created: string;
    LastModified: string;
}
export type NetworkConnectorIdentifier = string;
export interface DeleteNetworkConnectorRequest {
    Identifier: string;
}
export interface DeleteNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string | undefined;
    Version?: number | undefined;
    Configuration?: NetworkConnectorConfiguration | undefined;
    OperatorRole?: string | undefined;
    State?: NetworkConnectorState | undefined;
}
export interface DeleteRuntimeRequest {
    RuntimeName: string;
    RecoveryWindowInDays?: number | undefined;
}
export interface DeleteRuntimeResponse {
}
export interface DeleteRuntimeAliasRequest {
    RuntimeName: string;
    Name: string;
    RecoveryWindowInDays?: number | undefined;
}
export interface DeleteRuntimeAliasResponse {
}
export interface DeleteRuntimeVersionRequest {
    RuntimeName: string;
    Name: string;
    RecoveryWindowInDays?: number | undefined;
}
export interface DeleteRuntimeVersionResponse {
}
export interface GetNetworkConnectorRequest {
    Identifier: string;
}
export type AwsGirApiString = string;
export type NetworkConnectorStateReasonCode = "DisallowedByVpcEncryptionControl" | "Ec2RequestLimitExceeded" | "InsufficientRolePermissions" | "InternalError" | "InvalidSecurityGroup" | "InvalidSubnet" | "SecurityGroupsPerInterfaceLimitExceeded" | "SubnetOutOfIPAddresses" | (string & {});
export type NetworkConnectorLastUpdateStatus = "Successful" | "Failed" | "InProgress" | (string & {});
export type NetworkConnectorLastUpdateStatusReason = string;
export type NetworkConnectorLastUpdateStatusReasonCode = "DisallowedByVpcEncryptionControl" | "Ec2RequestLimitExceeded" | "InsufficientRolePermissions" | "InternalError" | "InvalidSecurityGroup" | "InvalidSubnet" | "SecurityGroupsPerInterfaceLimitExceeded" | "SubnetOutOfIPAddresses" | (string & {});
export type CoreTimestamp = Date;
export interface GetNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string | undefined;
    Version?: number | undefined;
    LatestVersionArn?: string | undefined;
    LatestVersion?: number | undefined;
    Configuration?: NetworkConnectorConfiguration | undefined;
    OperatorRole?: string | undefined;
    State?: NetworkConnectorState | undefined;
    StateReason?: string | undefined;
    StateReasonCode?: NetworkConnectorStateReasonCode | undefined;
    LastUpdateStatus?: NetworkConnectorLastUpdateStatus | undefined;
    LastUpdateStatusReason?: string | undefined;
    LastUpdateStatusReasonCode?: NetworkConnectorLastUpdateStatusReasonCode | undefined;
    LastModified?: Date | undefined;
}
export interface GetRuntimeRequest {
    RuntimeName: string;
}
export type RuntimeState = "ACTIVE" | "PENDING_DELETION" | "DELETING" | "FAILED" | (string & {});
export interface GetRuntimeResponse {
    Arn: string;
    Name: string;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    State?: RuntimeState | undefined;
    PendingDeletionAt?: string | undefined;
    Created: string;
    LastModified: string;
    Id?: string | undefined;
}
export interface GetRuntimeAliasRequest {
    RuntimeName: string;
    Name: string;
}
export interface GetRuntimeAliasResponse {
    Name: string;
    Arn: string;
    RuntimeVersion: string;
    RuntimeVersionArn: string;
    State: RuntimeAliasState;
    PendingDeletionAt?: string | undefined;
    Description?: string | undefined;
    Compatibility?: Compatibility | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export interface GetRuntimeVersionRequest {
    RuntimeName: string;
    Name: string;
}
export interface GetRuntimeVersionResponse {
    Name: string;
    Arn: string;
    ResolvedUri: string;
    State: RuntimeVersionState;
    PendingDeletionAt?: string | undefined;
    ReleaseNotes?: string | undefined;
    Platforms?: Platform[] | undefined;
    Compatibility?: Compatibility | undefined;
    Created: string;
    LastModified: string;
}
export type MaxHundredListItems = number;
export interface ListNetworkConnectorsRequest {
    State?: NetworkConnectorState | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type NetworkConnectorType = "VPC_EGRESS" | (string & {});
export interface NetworkConnectorSummary {
    Arn: string;
    Name: string;
    Id: string;
    Type: NetworkConnectorType;
    State?: NetworkConnectorState | undefined;
    LastModified?: Date | undefined;
    LatestVersionArn?: string | undefined;
    LatestVersion?: number | undefined;
}
export type NetworkConnectorsList = NetworkConnectorSummary[];
export interface ListNetworkConnectorsResponse {
    NetworkConnectors: NetworkConnectorSummary[];
    NextMarker?: string | undefined;
}
export interface ListNetworkConnectorVersionsRequest {
    Identifier: string;
    State?: NetworkConnectorState | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface NetworkConnectorVersionSummary {
    Arn: string;
    VersionArn: string;
    Name: string;
    Id: string;
    Version: number;
    State: NetworkConnectorState;
    StateReason?: string | undefined;
    StateReasonCode?: NetworkConnectorStateReasonCode | undefined;
    LastModified?: Date | undefined;
}
export type NetworkConnectorVersionsList = NetworkConnectorVersionSummary[];
export interface ListNetworkConnectorVersionsResponse {
    NetworkConnectorVersions: NetworkConnectorVersionSummary[];
    NextMarker?: string | undefined;
}
export interface ListRuntimeAliasesRequest {
    RuntimeName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RuntimeAliasInfo {
    Name: string;
    Arn: string;
    RuntimeVersion: string;
    RuntimeVersionArn: string;
    State: RuntimeAliasState;
    PendingDeletionAt?: string | undefined;
    Description?: string | undefined;
    Compatibility?: Compatibility | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export type RuntimeAliasList = RuntimeAliasInfo[];
export interface ListRuntimeAliasesResponse {
    Items: RuntimeAliasInfo[];
    NextToken?: string | undefined;
}
export interface ListRuntimesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RuntimeInfo {
    Arn: string;
    Name: string;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    State?: RuntimeState | undefined;
    PendingDeletionAt?: string | undefined;
    Created: string;
    LastModified: string;
}
export type RuntimeList = RuntimeInfo[];
export interface ListRuntimesResponse {
    NextToken?: string | undefined;
    Items: RuntimeInfo[];
}
export interface ListRuntimeVersionsRequest {
    RuntimeName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RuntimeVersionInfo {
    Name: string;
    Arn: string;
    ResolvedUri: string;
    State: RuntimeVersionState;
    PendingDeletionAt?: string | undefined;
    ReleaseNotes?: string | undefined;
    Compatibility?: Compatibility | undefined;
    Created: string;
    LastModified: string;
}
export type RuntimeVersionList = RuntimeVersionInfo[];
export interface ListRuntimeVersionsResponse {
    Items: RuntimeVersionInfo[];
    NextToken?: string | undefined;
}
export interface RestoreRuntimeRequest {
    RuntimeName: string;
    RuntimeVersion?: string | undefined;
    RuntimeAlias?: string | undefined;
}
export interface RestoreRuntimeResponse {
    RuntimeName: string;
    RuntimeVersion?: string | undefined;
    RuntimeAlias?: string | undefined;
    Arn: string;
    State: RuntimeState;
    LastModified: string;
}
export interface UpdateNetworkConnectorRequest {
    Identifier: string;
    Configuration?: NetworkConnectorConfiguration | undefined;
    OperatorRole?: string | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateNetworkConnectorResponse {
    Arn: string;
    Name: string;
    Id: string;
    VersionArn?: string | undefined;
    Version?: number | undefined;
    OperatorRole?: string | undefined;
    Configuration?: NetworkConnectorConfiguration | undefined;
    State?: NetworkConnectorState | undefined;
    LastUpdateStatus?: NetworkConnectorLastUpdateStatus | undefined;
    LastUpdateStatusReason?: string | undefined;
    LastModified?: Date | undefined;
}
export interface UpdateRuntimeRequest {
    RuntimeName: string;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
}
export interface UpdateRuntimeResponse {
    Arn: string;
    Name: string;
    Description?: string | undefined;
    LicenseInfo?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export interface UpdateRuntimeAliasRequest {
    RuntimeName: string;
    Name: string;
    RuntimeVersion: string;
    Description?: string | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
}
export interface UpdateRuntimeAliasResponse {
    RuntimeName: string;
    Name: string;
    Arn: string;
    RuntimeVersion: string;
    RuntimeVersionArn: string;
    State: RuntimeAliasState;
    Description?: string | undefined;
    Compatibility?: Compatibility | undefined;
    ReleaseLifecycle?: RuntimeReleaseLifecycle | undefined;
    Created: string;
    LastModified: string;
}
export interface UpdateRuntimeVersionRequest {
    RuntimeName: string;
    Name: string;
    ReleaseNotes: string;
}
export interface UpdateRuntimeVersionResponse {
    Name: string;
    Arn: string;
    ResolvedUri: string;
    State: RuntimeVersionState;
    ReleaseNotes?: string | undefined;
    Platforms?: Platform[] | undefined;
    Compatibility?: Compatibility | undefined;
    Created: string;
    LastModified: string;
}
export type ThrottleReason = "ConcurrentInvocationLimitExceeded" | "FunctionInvocationRateLimitExceeded" | "ReservedFunctionConcurrentInvocationLimitExceeded" | "ReservedFunctionInvocationRateLimitExceeded" | "CallerRateLimitExceeded" | "ConcurrentSnapshotCreateLimitExceeded" | (string & {});
export type CreateNetworkConnectorError = InvalidParameterValueException | NetworkConnectorLimitExceededException | ResourceConflictException | ServiceException | TooManyRequestsException | OperatorRoleNotAssumable | CommonErrors;
/**
 * Creates a network connector that enables Lambda compute resources to route outbound traffic through your Amazon VPC. The network connector provisions elastic network interfaces (ENIs) in the subnets you specify, providing a managed network path to private resources such as databases, caches, and internal APIs.
 *
 * This operation is asynchronous. The network connector starts in `PENDING` state while ENIs are provisioned in your VPC (provisioning typically takes up to 10 minutes). Use `GetNetworkConnector` to poll the connector state until it reaches `ACTIVE`. Once active, you can attach the connector to supported Lambda compute resources -- such as MicroVMs and WebFunctions -- at run time. For how to attach a connector, see the documentation for the specific compute type.
 *
 * This operation is idempotent when you provide a `ClientToken` -- if you retry a request that completed successfully using the same client token, the operation returns the existing connector without creating a duplicate.
 */
export declare const createNetworkConnector: API.OperationMethod<CreateNetworkConnectorRequest & RegionInput, CreateNetworkConnectorResponse, CreateNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateRuntimeError = InvalidParameterValueException | ResourceConflictException | ServiceException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a customer-managed runtime, a resource providing a centrally managed execution environment for your Lambda functions. The runtime resource is the parent of the runtime version and runtime alias child resources.
 */
export declare const createRuntime: API.OperationMethod<CreateRuntimeRequest & RegionInput, CreateRuntimeResponse, CreateRuntimeError, Credentials | HttpClient.HttpClient>;
export type CreateRuntimeAliasError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new customer-managed runtime alias. The alias is a named pointer to a runtime version. Functions consume the customer-managed runtime through the runtime alias.
 */
export declare const createRuntimeAlias: API.OperationMethod<CreateRuntimeAliasRequest & RegionInput, CreateRuntimeAliasResponse, CreateRuntimeAliasError, Credentials | HttpClient.HttpClient>;
export type CreateRuntimeVersionError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new runtime version. A runtime version defines the function execution environment by referencing a container image. Runtime versions are immutable. To update the runtime, create a new runtime version and migrate functions by updating the runtime aliases to point to the new runtime version.
 */
export declare const createRuntimeVersion: API.OperationMethod<CreateRuntimeVersionRequest & RegionInput, CreateRuntimeVersionResponse, CreateRuntimeVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkConnectorError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Initiates deletion of a network connector. The connector transitions to `DELETING` state while elastic network interfaces are cleaned up asynchronously. After deletion completes, subsequent calls to `GetNetworkConnector` return `ResourceNotFoundException`.
 *
 * This operation is idempotent -- calling delete on a connector that is already deleting or has been deleted succeeds without error. You can delete connectors in `ACTIVE` or `FAILED` states. Before deleting a connector, ensure that no Lambda compute resources are using it, as they will lose VPC egress connectivity immediately.
 *
 * Deleting with an unqualified identifier removes the connector and all of its versions. To remove a single historical version, supply its version-qualified ARN; the connector and its remaining versions are unaffected. You can't delete the latest version on its own -- delete the connector to remove it.
 */
export declare const deleteNetworkConnector: API.OperationMethod<DeleteNetworkConnectorRequest & RegionInput, DeleteNetworkConnectorResponse, DeleteNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteRuntimeError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Schedules a customer-managed runtime to be deleted. Runtimes scheduled for deletion enter the PENDING_DELETION state and can be restored during the scheduled deletion window. Runtime versions and aliases must be deleted or scheduled for deletion before deleting the runtime. Function invokes fail for functions using runtime versions or aliases that are deleted or pending deletion.
 */
export declare const deleteRuntime: API.OperationMethod<DeleteRuntimeRequest & RegionInput, DeleteRuntimeResponse, DeleteRuntimeError, Credentials | HttpClient.HttpClient>;
export type DeleteRuntimeAliasError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Schedules a runtime alias to be deleted. Runtime aliases scheduled for deletion enter the PENDING_DELETION state and can be restored during the scheduled deletion window. Function invokes fail for functions using runtime aliases that are deleted or pending deletion.
 */
export declare const deleteRuntimeAlias: API.OperationMethod<DeleteRuntimeAliasRequest & RegionInput, DeleteRuntimeAliasResponse, DeleteRuntimeAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteRuntimeVersionError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Schedules a runtime version to be deleted. Runtime versions scheduled for deletion enter the PENDING_DELETION state and can be restored during the scheduled deletion window. Function invokes fail for functions using a runtime version that is deleted or pending deletion.
 */
export declare const deleteRuntimeVersion: API.OperationMethod<DeleteRuntimeVersionRequest & RegionInput, DeleteRuntimeVersionResponse, DeleteRuntimeVersionError, Credentials | HttpClient.HttpClient>;
export type GetNetworkConnectorError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the current configuration, state, and metadata of a network connector. The `Identifier` parameter accepts the connector ID, name, or full ARN. Use this operation to poll connector state after creation or update, or to inspect the current VPC configuration and any failure reasons.
 *
 * The response includes the full connector configuration, current state, and -- if the connector has been updated -- the `LastUpdateStatus` and `LastUpdateStatusReasonCode` fields that indicate whether the most recent update succeeded or failed.
 */
export declare const getNetworkConnector: API.OperationMethod<GetNetworkConnectorRequest & RegionInput, GetNetworkConnectorResponse, GetNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the configuration and metadata of a runtime.
 */
export declare const getRuntime: API.OperationMethod<GetRuntimeRequest & RegionInput, GetRuntimeResponse, GetRuntimeError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeAliasError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the configuration, state, and metadata of a runtime alias.
 */
export declare const getRuntimeAlias: API.OperationMethod<GetRuntimeAliasRequest & RegionInput, GetRuntimeAliasResponse, GetRuntimeAliasError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeVersionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the configuration, state, and metadata of a runtime version.
 */
export declare const getRuntimeVersion: API.OperationMethod<GetRuntimeVersionRequest & RegionInput, GetRuntimeVersionResponse, GetRuntimeVersionError, Credentials | HttpClient.HttpClient>;
export type ListNetworkConnectorsError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of network connectors in your account for the current Region. You can optionally filter results by connector state. Use the `Marker` parameter from a previous response to retrieve the next page of results.
 *
 * Each item in the response includes the connector ARN, name, ID, type, current state, and last modified timestamp. To retrieve full configuration details for a specific connector, use `GetNetworkConnector`.
 */
export declare const listNetworkConnectors: API.PaginatedOperationMethod<ListNetworkConnectorsRequest & RegionInput, ListNetworkConnectorsResponse, ListNetworkConnectorsError, Credentials | HttpClient.HttpClient, NetworkConnectorSummary>;
export type ListNetworkConnectorVersionsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of the versions of a network connector. Each configuration update creates a new immutable version; this operation lists those versions for the connector you specify. You can optionally filter results by version state. Use the `Marker` parameter from a previous response to retrieve the next page of results.
 *
 * Each item in the response includes the version-qualified ARN, version number, current state, and last modified timestamp for that version. To retrieve the current (latest) configuration of the connector, use `GetNetworkConnector`; to inspect a specific version, call `GetNetworkConnector` with a version-qualified identifier.
 */
export declare const listNetworkConnectorVersions: API.PaginatedOperationMethod<ListNetworkConnectorVersionsRequest & RegionInput, ListNetworkConnectorVersionsResponse, ListNetworkConnectorVersionsError, Credentials | HttpClient.HttpClient, NetworkConnectorVersionSummary>;
export type ListRuntimeAliasesError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of aliases for the specified runtime.
 */
export declare const listRuntimeAliases: API.PaginatedOperationMethod<ListRuntimeAliasesRequest & RegionInput, ListRuntimeAliasesResponse, ListRuntimeAliasesError, Credentials | HttpClient.HttpClient, RuntimeAliasInfo>;
export type ListRuntimesError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of runtimes in your account for the current Region.
 */
export declare const listRuntimes: API.PaginatedOperationMethod<ListRuntimesRequest & RegionInput, ListRuntimesResponse, ListRuntimesError, Credentials | HttpClient.HttpClient, RuntimeInfo>;
export type ListRuntimeVersionsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a paginated list of versions for the specified runtime.
 */
export declare const listRuntimeVersions: API.PaginatedOperationMethod<ListRuntimeVersionsRequest & RegionInput, ListRuntimeVersionsResponse, ListRuntimeVersionsError, Credentials | HttpClient.HttpClient, RuntimeVersionInfo>;
export type RestoreRuntimeError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Cancels a pending scheduled deletion, returning the resource to the ACTIVE state. Scope is
 * determined by the RuntimeName path parameter plus an optional, mutually exclusive RuntimeVersion
 * or RuntimeAlias query parameter: with neither, the runtime itself is restored; with RuntimeVersion,
 * the named runtime version; with RuntimeAlias, the named runtime alias. Restoring a resource that is
 * already ACTIVE is a no-op success. Restore only works while the target is PENDING_DELETION; once the
 * scheduled deletion has begun executing (DELETING) or has completed, the call fails.
 */
export declare const restoreRuntime: API.OperationMethod<RestoreRuntimeRequest & RegionInput, RestoreRuntimeResponse, RestoreRuntimeError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkConnectorError = InvalidParameterValueException | NetworkConnectorLimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | OperatorRoleNotAssumable | CommonErrors;
/**
 * Updates the VPC configuration or operator role of an existing network connector. You can modify the subnet IDs, security group IDs, network protocol, or operator role. The connector must be in `ACTIVE` state to accept updates.
 *
 * This operation is asynchronous. The connector remains in `ACTIVE` state during the update -- existing workloads that reference this connector are not disrupted. Use `GetNetworkConnector` to monitor the `LastUpdateStatus` field, which transitions through `InProgress` to `Successful` or `Failed`. If the update fails, the `LastUpdateStatusReasonCode` field provides a specific error code for troubleshooting. This operation is idempotent when you provide a `ClientToken`.
 *
 * Each successful configuration change creates a new immutable version. A connector can have a limited number of versions; once that limit is reached, further updates fail with `NetworkConnectorLimitExceededException` until you delete older versions.
 */
export declare const updateNetworkConnector: API.OperationMethod<UpdateNetworkConnectorRequest & RegionInput, UpdateNetworkConnectorResponse, UpdateNetworkConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateRuntimeError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates the properties of an existing customer-managed runtime, such as its description, license information, or lifecycle information.
 */
export declare const updateRuntime: API.OperationMethod<UpdateRuntimeRequest & RegionInput, UpdateRuntimeResponse, UpdateRuntimeError, Credentials | HttpClient.HttpClient>;
export type UpdateRuntimeAliasError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing runtime alias to point to a different runtime version or to change its description or lifecycle information.
 */
export declare const updateRuntimeAlias: API.OperationMethod<UpdateRuntimeAliasRequest & RegionInput, UpdateRuntimeAliasResponse, UpdateRuntimeAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateRuntimeVersionError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates the runtime version release notes. The runtime version must be in the ACTIVE state. The runtime version image is immutable. To change the runtime contents, create a new runtime version.
 */
export declare const updateRuntimeVersion: API.OperationMethod<UpdateRuntimeVersionRequest & RegionInput, UpdateRuntimeVersionResponse, UpdateRuntimeVersionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lambda-core.d.ts.map