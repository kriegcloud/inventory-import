import type { TerminalCapabilities, TerminalOptions } from "../../Interaction.ts";
/** Detect what the terminal behind the given streams supports. */
export declare const resolveCapabilities: (options?: TerminalOptions) => TerminalCapabilities;
//# sourceMappingURL=capabilities.d.ts.map