import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BaseException_base: S.TaggedErrorClass<"BaseException", {
    readonly Code: any;
    readonly message: any;
}>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const DisabledOperationException_base: S.TaggedErrorClass<"DisabledOperationException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidTypeException_base: S.TaggedErrorClass<"InvalidTypeException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainName = string;
export interface BuildSuggestersRequest {
    DomainName: string;
}
export type FieldName = string;
export type FieldNameList = string[];
export interface BuildSuggestersResponse {
    FieldNames?: string[] | undefined;
}
export interface CreateDomainRequest {
    DomainName: string;
}
export type DomainId = string;
export type ARN = string;
export type ServiceUrl = string;
export interface ServiceEndpoint {
    Endpoint?: string | undefined;
}
export type SearchInstanceType = string;
export type PartitionCount = number;
export type InstanceCount = number;
export type MaximumReplicationCount = number;
export type MaximumPartitionCount = number;
export interface Limits {
    MaximumReplicationCount: number;
    MaximumPartitionCount: number;
}
export interface DomainStatus {
    DomainId: string;
    DomainName: string;
    ARN?: string | undefined;
    Created?: boolean | undefined;
    Deleted?: boolean | undefined;
    DocService?: ServiceEndpoint | undefined;
    SearchService?: ServiceEndpoint | undefined;
    RequiresIndexDocuments: boolean;
    Processing?: boolean | undefined;
    SearchInstanceType?: string | undefined;
    SearchPartitionCount?: number | undefined;
    SearchInstanceCount?: number | undefined;
    Limits?: Limits | undefined;
}
export interface CreateDomainResponse {
    DomainStatus?: DomainStatus | undefined;
}
export type StandardName = string;
export type AnalysisSchemeLanguage = "ar" | "bg" | "ca" | "cs" | "da" | "de" | "el" | "en" | "es" | "eu" | "fa" | "fi" | "fr" | "ga" | "gl" | "he" | "hi" | "hu" | "hy" | "id" | "it" | "ja" | "ko" | "lv" | "mul" | "nl" | "no" | "pt" | "ro" | "ru" | "sv" | "th" | "tr" | "zh-Hans" | "zh-Hant" | (string & {});
export type AlgorithmicStemming = "none" | "minimal" | "light" | "full" | (string & {});
export interface AnalysisOptions {
    Synonyms?: string | undefined;
    Stopwords?: string | undefined;
    StemmingDictionary?: string | undefined;
    JapaneseTokenizationDictionary?: string | undefined;
    AlgorithmicStemming?: AlgorithmicStemming | undefined;
}
export interface AnalysisScheme {
    AnalysisSchemeName: string;
    AnalysisSchemeLanguage: AnalysisSchemeLanguage;
    AnalysisOptions?: AnalysisOptions | undefined;
}
export interface DefineAnalysisSchemeRequest {
    DomainName: string;
    AnalysisScheme: AnalysisScheme;
}
export type UpdateTimestamp = Date;
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | "FailedToValidate" | (string & {});
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number | undefined;
    State: OptionState;
    PendingDeletion?: boolean | undefined;
}
export interface AnalysisSchemeStatus {
    Options: AnalysisScheme;
    Status: OptionStatus;
}
export interface DefineAnalysisSchemeResponse {
    AnalysisScheme: AnalysisSchemeStatus;
}
export type ExpressionValue = string;
export interface Expression {
    ExpressionName: string;
    ExpressionValue: string;
}
export interface DefineExpressionRequest {
    DomainName: string;
    Expression: Expression;
}
export interface ExpressionStatus {
    Options: Expression;
    Status: OptionStatus;
}
export interface DefineExpressionResponse {
    Expression: ExpressionStatus;
}
export type DynamicFieldName = string;
export type IndexFieldType = "int" | "double" | "literal" | "text" | "date" | "latlon" | "int-array" | "double-array" | "literal-array" | "text-array" | "date-array" | (string & {});
export interface IntOptions {
    DefaultValue?: number | undefined;
    SourceField?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
}
export interface DoubleOptions {
    DefaultValue?: number | undefined;
    SourceField?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
}
export type FieldValue = string;
export interface LiteralOptions {
    DefaultValue?: string | undefined;
    SourceField?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
}
export type Word = string;
export interface TextOptions {
    DefaultValue?: string | undefined;
    SourceField?: string | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
    HighlightEnabled?: boolean | undefined;
    AnalysisScheme?: string | undefined;
}
export interface DateOptions {
    DefaultValue?: string | undefined;
    SourceField?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
}
export interface LatLonOptions {
    DefaultValue?: string | undefined;
    SourceField?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
    SortEnabled?: boolean | undefined;
}
export type FieldNameCommaList = string;
export interface IntArrayOptions {
    DefaultValue?: number | undefined;
    SourceFields?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
}
export interface DoubleArrayOptions {
    DefaultValue?: number | undefined;
    SourceFields?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
}
export interface LiteralArrayOptions {
    DefaultValue?: string | undefined;
    SourceFields?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
}
export interface TextArrayOptions {
    DefaultValue?: string | undefined;
    SourceFields?: string | undefined;
    ReturnEnabled?: boolean | undefined;
    HighlightEnabled?: boolean | undefined;
    AnalysisScheme?: string | undefined;
}
export interface DateArrayOptions {
    DefaultValue?: string | undefined;
    SourceFields?: string | undefined;
    FacetEnabled?: boolean | undefined;
    SearchEnabled?: boolean | undefined;
    ReturnEnabled?: boolean | undefined;
}
export interface IndexField {
    IndexFieldName: string;
    IndexFieldType: IndexFieldType;
    IntOptions?: IntOptions | undefined;
    DoubleOptions?: DoubleOptions | undefined;
    LiteralOptions?: LiteralOptions | undefined;
    TextOptions?: TextOptions | undefined;
    DateOptions?: DateOptions | undefined;
    LatLonOptions?: LatLonOptions | undefined;
    IntArrayOptions?: IntArrayOptions | undefined;
    DoubleArrayOptions?: DoubleArrayOptions | undefined;
    LiteralArrayOptions?: LiteralArrayOptions | undefined;
    TextArrayOptions?: TextArrayOptions | undefined;
    DateArrayOptions?: DateArrayOptions | undefined;
}
export interface DefineIndexFieldRequest {
    DomainName: string;
    IndexField: IndexField;
}
export interface IndexFieldStatus {
    Options: IndexField;
    Status: OptionStatus;
}
export interface DefineIndexFieldResponse {
    IndexField: IndexFieldStatus;
}
export type SuggesterFuzzyMatching = "none" | "low" | "high" | (string & {});
export interface DocumentSuggesterOptions {
    SourceField: string;
    FuzzyMatching?: SuggesterFuzzyMatching | undefined;
    SortExpression?: string | undefined;
}
export interface Suggester {
    SuggesterName: string;
    DocumentSuggesterOptions: DocumentSuggesterOptions;
}
export interface DefineSuggesterRequest {
    DomainName: string;
    Suggester: Suggester;
}
export interface SuggesterStatus {
    Options: Suggester;
    Status: OptionStatus;
}
export interface DefineSuggesterResponse {
    Suggester: SuggesterStatus;
}
export interface DeleteAnalysisSchemeRequest {
    DomainName: string;
    AnalysisSchemeName: string;
}
export interface DeleteAnalysisSchemeResponse {
    AnalysisScheme: AnalysisSchemeStatus;
}
export interface DeleteDomainRequest {
    DomainName: string;
}
export interface DeleteDomainResponse {
    DomainStatus?: DomainStatus | undefined;
}
export interface DeleteExpressionRequest {
    DomainName: string;
    ExpressionName: string;
}
export interface DeleteExpressionResponse {
    Expression: ExpressionStatus;
}
export interface DeleteIndexFieldRequest {
    DomainName: string;
    IndexFieldName: string;
}
export interface DeleteIndexFieldResponse {
    IndexField: IndexFieldStatus;
}
export interface DeleteSuggesterRequest {
    DomainName: string;
    SuggesterName: string;
}
export interface DeleteSuggesterResponse {
    Suggester: SuggesterStatus;
}
export type StandardNameList = string[];
export interface DescribeAnalysisSchemesRequest {
    DomainName: string;
    AnalysisSchemeNames?: string[] | undefined;
    Deployed?: boolean | undefined;
}
export type AnalysisSchemeStatusList = AnalysisSchemeStatus[];
export interface DescribeAnalysisSchemesResponse {
    AnalysisSchemes: AnalysisSchemeStatus[];
}
export interface DescribeAvailabilityOptionsRequest {
    DomainName: string;
    Deployed?: boolean | undefined;
}
export type MultiAZ = boolean;
export interface AvailabilityOptionsStatus {
    Options: boolean;
    Status: OptionStatus;
}
export interface DescribeAvailabilityOptionsResponse {
    AvailabilityOptions?: AvailabilityOptionsStatus | undefined;
}
export interface DescribeDomainEndpointOptionsRequest {
    DomainName: string;
    Deployed?: boolean | undefined;
}
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | (string & {});
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean | undefined;
    TLSSecurityPolicy?: TLSSecurityPolicy | undefined;
}
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export interface DescribeDomainEndpointOptionsResponse {
    DomainEndpointOptions?: DomainEndpointOptionsStatus | undefined;
}
export type DomainNameList = string[];
export interface DescribeDomainsRequest {
    DomainNames?: string[] | undefined;
}
export type DomainStatusList = DomainStatus[];
export interface DescribeDomainsResponse {
    DomainStatusList: DomainStatus[];
}
export interface DescribeExpressionsRequest {
    DomainName: string;
    ExpressionNames?: string[] | undefined;
    Deployed?: boolean | undefined;
}
export type ExpressionStatusList = ExpressionStatus[];
export interface DescribeExpressionsResponse {
    Expressions: ExpressionStatus[];
}
export type DynamicFieldNameList = string[];
export interface DescribeIndexFieldsRequest {
    DomainName: string;
    FieldNames?: string[] | undefined;
    Deployed?: boolean | undefined;
}
export type IndexFieldStatusList = IndexFieldStatus[];
export interface DescribeIndexFieldsResponse {
    IndexFields: IndexFieldStatus[];
}
export interface DescribeScalingParametersRequest {
    DomainName: string;
}
export type PartitionInstanceType = "search.m1.small" | "search.m1.large" | "search.m2.xlarge" | "search.m2.2xlarge" | "search.m3.medium" | "search.m3.large" | "search.m3.xlarge" | "search.m3.2xlarge" | "search.small" | "search.medium" | "search.large" | "search.xlarge" | "search.2xlarge" | "search.previousgeneration.small" | "search.previousgeneration.large" | "search.previousgeneration.xlarge" | "search.previousgeneration.2xlarge" | (string & {});
export interface ScalingParameters {
    DesiredInstanceType?: PartitionInstanceType | undefined;
    DesiredReplicationCount?: number | undefined;
    DesiredPartitionCount?: number | undefined;
}
export interface ScalingParametersStatus {
    Options: ScalingParameters;
    Status: OptionStatus;
}
export interface DescribeScalingParametersResponse {
    ScalingParameters: ScalingParametersStatus;
}
export interface DescribeServiceAccessPoliciesRequest {
    DomainName: string;
    Deployed?: boolean | undefined;
}
export type PolicyDocument = string;
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export interface DescribeServiceAccessPoliciesResponse {
    AccessPolicies: AccessPoliciesStatus;
}
export interface DescribeSuggestersRequest {
    DomainName: string;
    SuggesterNames?: string[] | undefined;
    Deployed?: boolean | undefined;
}
export type SuggesterStatusList = SuggesterStatus[];
export interface DescribeSuggestersResponse {
    Suggesters: SuggesterStatus[];
}
export interface IndexDocumentsRequest {
    DomainName: string;
}
export interface IndexDocumentsResponse {
    FieldNames?: string[] | undefined;
}
export interface ListDomainNamesRequest {
}
export type APIVersion = string;
export type DomainNameMap = {
    [key: string]: string | undefined;
};
export interface ListDomainNamesResponse {
    DomainNames?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateAvailabilityOptionsRequest {
    DomainName: string;
    MultiAZ: boolean;
}
export interface UpdateAvailabilityOptionsResponse {
    AvailabilityOptions?: AvailabilityOptionsStatus | undefined;
}
export interface UpdateDomainEndpointOptionsRequest {
    DomainName: string;
    DomainEndpointOptions: DomainEndpointOptions;
}
export interface UpdateDomainEndpointOptionsResponse {
    DomainEndpointOptions?: DomainEndpointOptionsStatus | undefined;
}
export interface UpdateScalingParametersRequest {
    DomainName: string;
    ScalingParameters: ScalingParameters;
}
export interface UpdateScalingParametersResponse {
    ScalingParameters: ScalingParametersStatus;
}
export interface UpdateServiceAccessPoliciesRequest {
    DomainName: string;
    AccessPolicies: string;
}
export interface UpdateServiceAccessPoliciesResponse {
    AccessPolicies: AccessPoliciesStatus;
}
export type ErrorCode = string;
export type ErrorMessage = string;
export type BuildSuggestersError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Indexes the search suggestions. For more information, see Configuring Suggesters in the *Amazon CloudSearch Developer Guide*.
 */
export declare const buildSuggesters: API.OperationMethod<BuildSuggestersRequest & RegionInput, BuildSuggestersResponse, BuildSuggestersError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = BaseException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new search domain. For more information,
 * see Creating a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type DefineAnalysisSchemeError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an analysis scheme that can be applied to a `text` or `text-array` field to define language-specific text processing options. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineAnalysisScheme: API.OperationMethod<DefineAnalysisSchemeRequest & RegionInput, DefineAnalysisSchemeResponse, DefineAnalysisSchemeError, Credentials | HttpClient.HttpClient>;
export type DefineExpressionError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an `Expression` for the search domain. Used to create new expressions and modify existing ones. If the expression exists, the new configuration replaces the old one. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineExpression: API.OperationMethod<DefineExpressionRequest & RegionInput, DefineExpressionResponse, DefineExpressionError, Credentials | HttpClient.HttpClient>;
export type DefineIndexFieldError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures an `IndexField` for the search domain. Used to create new fields and modify existing ones. You must specify the name of the domain you are configuring and an index field configuration. The index field configuration specifies a unique name, the index field type, and the options you want to configure for the field. The options you can specify depend on the `IndexFieldType`. If the field exists, the new configuration replaces the old one. For more information, see Configuring Index Fields in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineIndexField: API.OperationMethod<DefineIndexFieldRequest & RegionInput, DefineIndexFieldResponse, DefineIndexFieldError, Credentials | HttpClient.HttpClient>;
export type DefineSuggesterError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures a suggester for a domain. A suggester enables you to display possible matches before users finish typing their queries. When you configure a suggester, you must specify the name of the text field you want to search for possible matches and a unique name for the suggester. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const defineSuggester: API.OperationMethod<DefineSuggesterRequest & RegionInput, DefineSuggesterResponse, DefineSuggesterError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalysisSchemeError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an analysis scheme. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteAnalysisScheme: API.OperationMethod<DeleteAnalysisSchemeRequest & RegionInput, DeleteAnalysisSchemeResponse, DeleteAnalysisSchemeError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = BaseException | InternalException | CommonErrors;
/**
 * Permanently deletes a search domain and all of its data. Once a domain has been deleted, it cannot be recovered. For more information,
 * see Deleting a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteExpressionError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes an `Expression` from the search domain. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteExpression: API.OperationMethod<DeleteExpressionRequest & RegionInput, DeleteExpressionResponse, DeleteExpressionError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexFieldError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes an `IndexField` from the search domain. For more information, see Configuring Index Fields in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteIndexField: API.OperationMethod<DeleteIndexFieldRequest & RegionInput, DeleteIndexFieldResponse, DeleteIndexFieldError, Credentials | HttpClient.HttpClient>;
export type DeleteSuggesterError = BaseException | InternalException | InvalidTypeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a suggester. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const deleteSuggester: API.OperationMethod<DeleteSuggesterRequest & RegionInput, DeleteSuggesterResponse, DeleteSuggesterError, Credentials | HttpClient.HttpClient>;
export type DescribeAnalysisSchemesError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the analysis schemes configured for a domain. An analysis scheme defines language-specific text processing options for a `text` field. Can be limited to specific analysis schemes by name. By default, shows all analysis schemes and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Analysis Schemes in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeAnalysisSchemes: API.OperationMethod<DescribeAnalysisSchemesRequest & RegionInput, DescribeAnalysisSchemesResponse, DescribeAnalysisSchemesError, Credentials | HttpClient.HttpClient>;
export type DescribeAvailabilityOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the availability options configured for a domain. By default, shows the configuration with any pending changes. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Availability Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeAvailabilityOptions: API.OperationMethod<DescribeAvailabilityOptionsRequest & RegionInput, DescribeAvailabilityOptionsResponse, DescribeAvailabilityOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainEndpointOptionsError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the domain's endpoint options, specifically whether all requests to the domain must arrive over HTTPS. For more information, see Configuring Domain Endpoint Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeDomainEndpointOptions: API.OperationMethod<DescribeDomainEndpointOptionsRequest & RegionInput, DescribeDomainEndpointOptionsResponse, DescribeDomainEndpointOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainsError = BaseException | InternalException | CommonErrors;
/**
 * Gets information about the search domains owned by this account. Can be limited to specific domains. Shows
 * all domains by default. To get the number of searchable documents in a domain, use the console or submit a `matchall` request to your domain's search endpoint: `q=matchall&q.parser=structured&size=0`. For more information,
 * see Getting Information about a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeDomains: API.OperationMethod<DescribeDomainsRequest & RegionInput, DescribeDomainsResponse, DescribeDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeExpressionsError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the expressions configured for the search domain. Can be limited to specific expressions by name. By default, shows all expressions and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Configuring Expressions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeExpressions: API.OperationMethod<DescribeExpressionsRequest & RegionInput, DescribeExpressionsResponse, DescribeExpressionsError, Credentials | HttpClient.HttpClient>;
export type DescribeIndexFieldsError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the index fields configured for the search domain.
 * Can be limited to specific fields by name. By default, shows all fields and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information,
 * see Getting Domain Information in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeIndexFields: API.OperationMethod<DescribeIndexFieldsRequest & RegionInput, DescribeIndexFieldsResponse, DescribeIndexFieldsError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingParametersError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the scaling parameters configured for a domain. A domain's scaling parameters specify the desired search instance type and replication count. For more information, see Configuring Scaling Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeScalingParameters: API.OperationMethod<DescribeScalingParametersRequest & RegionInput, DescribeScalingParametersResponse, DescribeScalingParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceAccessPoliciesError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the access policies that control access to the domain's document and search endpoints. By default, shows the configuration with any pending changes. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information,
 * see Configuring Access for a Search Domain in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeServiceAccessPolicies: API.OperationMethod<DescribeServiceAccessPoliciesRequest & RegionInput, DescribeServiceAccessPoliciesResponse, DescribeServiceAccessPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeSuggestersError = BaseException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the suggesters configured for a domain. A suggester enables you to display possible matches before users finish typing their queries. Can be limited to specific suggesters by name. By default, shows all suggesters and includes any pending changes to the configuration. Set the `Deployed` option to `true` to show the active configuration and exclude pending changes. For more information, see Getting Search Suggestions in the *Amazon CloudSearch Developer Guide*.
 */
export declare const describeSuggesters: API.OperationMethod<DescribeSuggestersRequest & RegionInput, DescribeSuggestersResponse, DescribeSuggestersError, Credentials | HttpClient.HttpClient>;
export type IndexDocumentsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tells the search domain to start indexing its documents using the latest indexing options. This operation must be invoked to activate options whose OptionStatus is `RequiresIndexDocuments`.
 */
export declare const indexDocuments: API.OperationMethod<IndexDocumentsRequest & RegionInput, IndexDocumentsResponse, IndexDocumentsError, Credentials | HttpClient.HttpClient>;
export type ListDomainNamesError = BaseException | CommonErrors;
/**
 * Lists all search domains owned by an account.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest & RegionInput, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type UpdateAvailabilityOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures the availability options for a domain. Enabling the Multi-AZ option expands an Amazon CloudSearch domain to an additional Availability Zone in the same Region to increase fault tolerance in the event of a service disruption. Changes to the Multi-AZ option can take about half an hour to become active. For more information, see Configuring Availability Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateAvailabilityOptions: API.OperationMethod<UpdateAvailabilityOptionsRequest & RegionInput, UpdateAvailabilityOptionsResponse, UpdateAvailabilityOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainEndpointOptionsError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the domain's endpoint options, specifically whether all requests to the domain must arrive over HTTPS. For more information, see Configuring Domain Endpoint Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateDomainEndpointOptions: API.OperationMethod<UpdateDomainEndpointOptionsRequest & RegionInput, UpdateDomainEndpointOptionsResponse, UpdateDomainEndpointOptionsError, Credentials | HttpClient.HttpClient>;
export type UpdateScalingParametersError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures scaling parameters for a domain. A domain's scaling parameters specify the desired search instance type and replication count. Amazon CloudSearch will still automatically scale your domain based on the volume of data and traffic, but not below the desired instance type and replication count. If the Multi-AZ option is enabled, these values control the resources used per Availability Zone. For more information, see Configuring Scaling Options in the *Amazon CloudSearch Developer Guide*.
 */
export declare const updateScalingParameters: API.OperationMethod<UpdateScalingParametersRequest & RegionInput, UpdateScalingParametersResponse, UpdateScalingParametersError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceAccessPoliciesError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Configures the access rules that control access to the domain's document and search endpoints.
 * For more information, see
 * Configuring Access for an Amazon CloudSearch Domain.
 */
export declare const updateServiceAccessPolicies: API.OperationMethod<UpdateServiceAccessPoliciesRequest & RegionInput, UpdateServiceAccessPoliciesResponse, UpdateServiceAccessPoliciesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudsearch.d.ts.map