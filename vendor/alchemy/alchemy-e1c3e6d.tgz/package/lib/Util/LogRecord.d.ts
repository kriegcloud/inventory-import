import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Logger from "effect/Logger";
import * as LogLevel from "effect/LogLevel";
import * as Schema from "effect/Schema";
import { Event } from "../Events.ts";
import { type TraceParent } from "./TraceParent.ts";
/** Record levels, spelled like `--log-level`. */
export type Level = "trace" | "debug" | "info" | "warn" | "error" | "fatal";
/**
 * What a record is, and the first thing a sink filters on:
 * - `log`: a line alchemy logged;
 * - `event`: a typed event (see `emit`);
 * - `output`: a line a child process wrote (dev servers, workerd, the user's code);
 * - `run`: the first line of a run log, describing the run.
 */
export type Kind = "log" | "event" | "output" | "run";
/**
 * The envelope every record shares. Every key is always present (`null`
 * when it doesn't apply), so a reader filters on fields without guessing
 * which ones a record carries; `data` has the shape its `kind` names.
 */
interface Envelope<K extends Kind, Data> {
    /** Unix time in milliseconds. */
    readonly time: number;
    readonly level: Level;
    readonly kind: K;
    /** The alchemy process that produced it: `cli`, `exec` or `sidecar`. */
    readonly process: string;
    /** Which run log it belongs to: account-level work is `global`. */
    readonly scope: "project" | "global";
    /**
     * The trace and span it was logged in, for joining with telemetry; outside
     * any span, the process's trace (see `processTrace`).
     */
    readonly trace: TraceParent;
    /** Annotations on the record, beyond the envelope's own fields. */
    readonly attributes: Readonly<Record<string, unknown>>;
    readonly data: Data;
}
/**
 * One record as data. Every alchemy process logs these; only the process
 * that owns the terminal renders them (pretty or JSON), so structure
 * survives process boundaries instead of being baked into rendered text.
 */
export type LogRecord = Envelope<"log", {
    readonly message: string;
    readonly cause: string | null;
}> | Envelope<"event", Event> | Envelope<"output", {
    readonly stream: "stdout" | "stderr";
    /** The line as the child wrote it, ANSI styling included. */
    readonly text: string;
}> | Envelope<"run", {
    readonly version: string;
    readonly pid: number;
    readonly cwd: string;
    readonly argv: ReadonlyArray<string>;
}>;
/** The name this process stamps on its records: `cli`, `exec` or `sidecar`. */
export declare const LogProcess: Context.Reference<string>;
/** The Effect log level of each record {@link Level}. */
export declare const severities: Record<Level, LogLevel.Severity>;
/**
 * `JSON.stringify` that never throws: cycles become `"[Circular]"` and
 * bigints their decimal string. Logging must not fail the work it reports.
 */
export declare const safeStringify: (value: unknown) => string;
/** A record's {@link Kind}, read from its annotations alone. */
export declare const kindOf: (options: Logger.Options<unknown>) => Exclude<Kind, "run">;
/** The record a logger call describes. */
export declare const recordOf: (options: Logger.Options<unknown>) => LogRecord;
/**
 * Mark the logs of `effect` as account-level: the CLI files them in the
 * global run log (`~/.alchemy/logs`) instead of the project's. For work that
 * isn't about one project — the state store, auth and credentials, profiles.
 */
export declare const globalLogs: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/**
 * Set to `json` on alchemy child processes (sidecars) so they log
 * {@link LogRecord} lines instead of rendering, and on the CLI to print
 * records as JSON.
 */
export declare const LOG_FORMAT_ENV = "ALCHEMY_LOG_FORMAT";
/** The console's `--log-level`, for child processes that render the run's logs. */
export declare const LOG_LEVEL_ENV = "ALCHEMY_LOG_LEVEL";
/** Formats each record as one line of JSON (for `Logger.toFile`). */
export declare const formatJsonRecord: Logger.Logger<unknown, string>;
/** A logger that writes each record as one line of JSON. */
export declare const jsonLogger: (write: (line: string) => void) => Logger.Logger<unknown, void>;
/**
 * The only logger of an alchemy child process: every record as a JSON line
 * on stdout, down to Debug, for the parent to filter and render.
 */
export declare const childJsonLogLayer: Layer.Layer<never, never, never>;
/**
 * Set on a child process that renders its own terminal output (the
 * `alchemy dev` exec child) to the file descriptor its parent reads log
 * records from. The parent writes the run log; the child keeps none.
 */
export declare const LOG_FD_ENV = "ALCHEMY_LOG_FD";
/**
 * Forward every record, down to Debug, to the parent as JSON lines on the
 * descriptor in {@link LOG_FD_ENV}, alongside the installed loggers. Empty
 * when the variable is unset.
 */
export declare const parentLogLayer: () => Layer.Layer<never>;
/**
 * The wire form of a {@link LogRecord}: what a child process sends and the
 * run log stores. An event is decoded with the {@link Event} union; one whose
 * `type` this version doesn't know is kept as-is rather than rejected, so a
 * newer process's records still pass through.
 */
export declare const LogRecordSchema: Schema.Union<readonly [Schema.Struct<{
    readonly time: Schema.Number;
    readonly level: Schema.Literals<readonly ["trace", "debug", "info", "warn", "error", "fatal"]>;
    readonly process: Schema.String;
    readonly scope: Schema.Literals<readonly ["project", "global"]>;
    readonly trace: Schema.Struct<{
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
    }>;
    readonly attributes: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly kind: Schema.Literal<"log">;
    readonly data: Schema.Struct<{
        readonly message: Schema.String;
        readonly cause: Schema.NullOr<Schema.String>;
    }>;
}>, Schema.Struct<{
    readonly time: Schema.Number;
    readonly level: Schema.Literals<readonly ["trace", "debug", "info", "warn", "error", "fatal"]>;
    readonly process: Schema.String;
    readonly scope: Schema.Literals<readonly ["project", "global"]>;
    readonly trace: Schema.Struct<{
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
    }>;
    readonly attributes: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly kind: Schema.Literal<"event">;
    readonly data: Schema.Union<readonly [Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"plan.phase">;
        readonly phase: Schema.Literals<readonly ["importing-module", "resolving-services", "loading-state", "computing-plan", "plan-ready"]>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"plan.resource.started">;
        readonly fqn: Schema.String;
        readonly logicalId: Schema.String;
        readonly resourceType: Schema.String;
        readonly total: Schema.Number;
    }>, Schema.Struct<{
        readonly fqn: Schema.String;
        readonly logicalId: Schema.String;
        readonly resourceType: Schema.String;
        readonly action: Schema.Literals<readonly ["create", "update", "adopted", "replace", "delete", "orphaned", "noop"]>;
        readonly bindings: Schema.$Array<Schema.Struct<{
            readonly sid: Schema.String;
            readonly action: Schema.Literals<readonly ["create", "update", "delete", "noop"]>;
        }>>;
        readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
        readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
        readonly type: Schema.Literal<"plan.resource.completed">;
        readonly completed: Schema.Number;
        readonly total: Schema.Number;
    }>, Schema.Struct<{
        readonly fqn: Schema.String;
        readonly logicalId: Schema.String;
        readonly actionType: Schema.String;
        readonly action: Schema.Literals<readonly ["run", "delete", "noop"]>;
        readonly type: Schema.Literal<"plan.action.completed">;
        readonly completed: Schema.Number;
        readonly total: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"apply.resource.note">;
        readonly fqn: Schema.String;
        readonly id: Schema.String;
        readonly message: Schema.String;
        readonly kind: Schema.optionalKey<Schema.Literals<readonly ["status", "output"]>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"apply.resource.status">;
        readonly fqn: Schema.String;
        readonly id: Schema.String;
        readonly resourceType: Schema.String;
        readonly status: Schema.Literals<readonly ["attaching", "post-attach", "pending", "pre-creating", "creating", "creating replacement", "created", "updating", "updated", "adopting", "adopted", "deleting", "deleted", "orphaning", "orphaned", "replacing", "replaced", "running", "ran", "skipped", "fail"]>;
        readonly message: Schema.optionalKey<Schema.String>;
        readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
        readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"state.bootstrap.started">;
        readonly store: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"state.bootstrap.completed">;
        readonly store: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"provider.configure.started">;
        readonly provider: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"provider.configure.completed">;
        readonly provider: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"provider.refresh.started">;
        readonly provider: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"provider.refresh.completed">;
        readonly provider: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.scan.started">;
        readonly total: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.scan.provider.started">;
        readonly provider: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.scan.provider.completed">;
        readonly provider: Schema.String;
        readonly resources: Schema.Number;
        readonly error: Schema.optionalKey<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.pass.started">;
        readonly pass: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.resource.deleted">;
        readonly provider: Schema.String;
        readonly resource: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"nuke.resource.failed">;
        readonly provider: Schema.String;
        readonly resource: Schema.String;
        readonly message: Schema.String;
    }>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>;
}>, Schema.Struct<{
    readonly time: Schema.Number;
    readonly level: Schema.Literals<readonly ["trace", "debug", "info", "warn", "error", "fatal"]>;
    readonly process: Schema.String;
    readonly scope: Schema.Literals<readonly ["project", "global"]>;
    readonly trace: Schema.Struct<{
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
    }>;
    readonly attributes: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly kind: Schema.Literal<"output">;
    readonly data: Schema.Struct<{
        readonly stream: Schema.Literals<readonly ["stdout", "stderr"]>;
        readonly text: Schema.String;
    }>;
}>, Schema.Struct<{
    readonly time: Schema.Number;
    readonly level: Schema.Literals<readonly ["trace", "debug", "info", "warn", "error", "fatal"]>;
    readonly process: Schema.String;
    readonly scope: Schema.Literals<readonly ["project", "global"]>;
    readonly trace: Schema.Struct<{
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
    }>;
    readonly attributes: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly kind: Schema.Literal<"run">;
    readonly data: Schema.Struct<{
        readonly version: Schema.String;
        readonly pid: Schema.Number;
        readonly cwd: Schema.String;
        readonly argv: Schema.$Array<Schema.String>;
    }>;
}>]>;
/** Decode one JSON log line, or `undefined` when it isn't a log record. */
export declare const parseRecord: (line: string) => typeof LogRecordSchema.Type | undefined;
/**
 * Log a record from another process through this process's loggers,
 * keeping its envelope: the sinks here see the record the child produced.
 */
export declare const replayRecord: (record: typeof LogRecordSchema.Type) => Effect.Effect<void>;
/**
 * Log one line a child process wrote. A JSON {@link LogRecord} (an alchemy
 * child) is replayed as-is; anything else becomes an Info `output` record,
 * from `source.process` or, when that's unset, this process.
 */
export declare const logChildLine: (line: string, source: {
    readonly stream: "stdout" | "stderr";
    readonly resource?: string;
    readonly process?: string;
}) => Effect.Effect<void>;
export {};
//# sourceMappingURL=LogRecord.d.ts.map