import { UserFacingError } from "alchemy/UserFacingError";
/** The SDK operation that failed, without retaining credentials or returned values. */
export type OnePasswordOperation = "initialize" | "authenticate" | "read" | "resolve";
declare const OnePasswordRateLimitError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordRateLimitError";
} & Readonly<A>;
/**
 * 1Password rejected a request because a rate limit was exceeded.
 * Alchemy does not automatically retry: service-account quotas can take hours
 * to reset, and the SDK does not expose a structured retry-after duration.
 */
export declare class OnePasswordRateLimitError extends OnePasswordRateLimitError_base<{
    readonly environmentId?: string;
    readonly operation: OnePasswordOperation;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordSdkError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordSdkError";
} & Readonly<A>;
/**
 * The SDK failed for a reason it doesn't classify, or couldn't be loaded.
 * The raw error may contain secret values and is not retained.
 */
export declare class OnePasswordSdkError extends OnePasswordSdkError_base<{
    readonly environmentId?: string;
    readonly operation: OnePasswordOperation;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordAuthExpiredError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordAuthExpiredError";
} & Readonly<A>;
/** The service account token was rejected or has expired. */
export declare class OnePasswordAuthExpiredError extends OnePasswordAuthExpiredError_base<{}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordDesktopSessionExpiredError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordDesktopSessionExpiredError";
} & Readonly<A>;
/** The desktop app's authorization ended, e.g. because 1Password locked. */
export declare class OnePasswordDesktopSessionExpiredError extends OnePasswordDesktopSessionExpiredError_base<{}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordAccountNotFoundError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordAccountNotFoundError";
} & Readonly<A>;
/** The desktop app has no account matching the `account` selector. */
export declare class OnePasswordAccountNotFoundError extends OnePasswordAccountNotFoundError_base<{
    readonly account: string;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordTimeoutError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordTimeoutError";
} & Readonly<A>;
/** A 1Password call didn't finish in time. */
export declare class OnePasswordTimeoutError extends OnePasswordTimeoutError_base<{
    readonly operation: OnePasswordOperation;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
declare const OnePasswordReferenceError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OnePasswordReferenceError";
} & Readonly<A>;
/**
 * A reference could not be resolved, so nothing was loaded. Neither its URI nor
 * the SDK's free-text message is retained; `errorType` is the SDK's fixed error
 * kind (e.g. `parsing`, `fieldNotFound`, `itemNotFound`, `vaultNotFound`).
 */
export declare class OnePasswordReferenceError extends OnePasswordReferenceError_base<{
    readonly configKey: string;
    readonly errorType?: string;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
export {};
//# sourceMappingURL=Errors.d.ts.map