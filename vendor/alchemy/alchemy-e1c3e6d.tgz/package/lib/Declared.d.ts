import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import type { PropsInput } from "./Input.ts";
import * as Output from "./Output.ts";
type Leaf = string | number | boolean | bigint | symbol | null | undefined | Redacted.Redacted<any> | Uint8Array | Date | ((...args: any[]) => any);
/**
 * A prop value, or the declaration of a resource that has it: `template: Node`
 * instead of `template: yield* Node`, at any depth. `Providers` is the
 * provider package's own services, which the declaration needs.
 */
export type Declared<T, Providers> = T extends Leaf ? T : T extends Output.Output<any> ? T : T extends ReadonlyArray<infer U> ? Declared<U, Providers>[] | Effect.Effect<T, never, Providers> : {
    [K in keyof T]: Declared<T[K], Providers>;
} | Effect.Effect<T, never, Providers>;
/** Props where any value may be a resource declaration. */
export type DeclaredProps<P, Providers> = {
    [K in keyof PropsInput<P>]: Declared<PropsInput<P>[K], Providers>;
};
/**
 * A declaration still to be yielded: an Effect that isn't an Output, a
 * resource, or a Config (which the engine resolves as a prop value).
 */
export declare const isDeclaration: (value: unknown) => value is Effect.Effect<unknown>;
/**
 * Yield every declaration in `value`, at any depth. The declarations'
 * requirements are the stack's, which the engine satisfies when it yields
 * the resource that holds them.
 */
export declare const resolveDeclarations: (value: unknown) => Effect.Effect<unknown>;
/**
 * Let a resource's props hold declarations of other resources, which are
 * yielded when the resource is: `Modal.Image("Node", { app: Backend })`.
 * Props without declarations are passed through unchanged.
 *
 * Bind it once per provider package to that package's `Providers`:
 * `export const declarable = Declared.declarable<Providers>();`
 */
export declare const declarable: <Providers>() => <R extends {
    readonly Props: any;
}>() => <C extends object>(resource: C) => C & ((id: string, props: DeclaredProps<R["Props"], Providers>) => Effect.Effect<R, never, Providers>);
export {};
//# sourceMappingURL=Declared.d.ts.map