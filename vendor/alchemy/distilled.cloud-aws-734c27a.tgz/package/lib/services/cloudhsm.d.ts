import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const CloudHsmInternalException_base: S.TaggedErrorClass<"CloudHsmInternalException", {
    readonly message: any;
    readonly retryable: any;
}>;
export declare class CloudHsmInternalException extends /*@__PURE__*/ CloudHsmInternalException_base {
}
declare const CloudHsmServiceException_base: S.TaggedErrorClass<"CloudHsmServiceException", {
    readonly message: any;
    readonly retryable: any;
}>;
export declare class CloudHsmServiceException extends /*@__PURE__*/ CloudHsmServiceException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly retryable: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AddTagsToResourceRequest {
    ResourceArn: string;
    TagList: Tag[];
}
export interface AddTagsToResourceResponse {
    Status: string;
}
export type Label = string;
export interface CreateHapgRequest {
    Label: string;
}
export type HapgArn = string;
export interface CreateHapgResponse {
    HapgArn?: string | undefined;
}
export type SubnetId = string;
export type SshKey = string;
export type IpAddress = string;
export type IamRoleArn = string;
export type ExternalId = string;
export type SubscriptionType = "PRODUCTION" | (string & {});
export type ClientToken = string;
export interface CreateHsmRequest {
    SubnetId: string;
    SshKey: string;
    EniIp?: string | undefined;
    IamRoleArn: string;
    ExternalId?: string | undefined;
    SubscriptionType: SubscriptionType;
    ClientToken?: string | undefined;
    SyslogIp?: string | undefined;
}
export type HsmArn = string;
export interface CreateHsmResponse {
    HsmArn?: string | undefined;
}
export type ClientLabel = string;
export type Certificate = string;
export interface CreateLunaClientRequest {
    Label?: string | undefined;
    Certificate: string;
}
export type ClientArn = string;
export interface CreateLunaClientResponse {
    ClientArn?: string | undefined;
}
export interface DeleteHapgRequest {
    HapgArn: string;
}
export interface DeleteHapgResponse {
    Status: string;
}
export interface DeleteHsmRequest {
    HsmArn: string;
}
export interface DeleteHsmResponse {
    Status: string;
}
export interface DeleteLunaClientRequest {
    ClientArn: string;
}
export interface DeleteLunaClientResponse {
    Status: string;
}
export interface DescribeHapgRequest {
    HapgArn: string;
}
export type HsmList = string[];
export type PartitionSerial = string;
export type PartitionSerialList = string[];
export type CloudHsmObjectState = "READY" | "UPDATING" | "DEGRADED" | (string & {});
export interface DescribeHapgResponse {
    HapgArn?: string | undefined;
    HapgSerial?: string | undefined;
    HsmsLastActionFailed?: string[] | undefined;
    HsmsPendingDeletion?: string[] | undefined;
    HsmsPendingRegistration?: string[] | undefined;
    Label?: string | undefined;
    LastModifiedTimestamp?: string | undefined;
    PartitionSerialList?: string[] | undefined;
    State?: CloudHsmObjectState | undefined;
}
export type HsmSerialNumber = string;
export interface DescribeHsmRequest {
    HsmArn?: string | undefined;
    HsmSerialNumber?: string | undefined;
}
export type HsmStatus = "PENDING" | "RUNNING" | "UPDATING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | "DEGRADED" | (string & {});
export type AZ = string;
export type EniId = string;
export type VpcId = string;
export type PartitionArn = string;
export type PartitionList = string[];
export interface DescribeHsmResponse {
    HsmArn?: string | undefined;
    Status?: HsmStatus | undefined;
    StatusDetails?: string | undefined;
    AvailabilityZone?: string | undefined;
    EniId?: string | undefined;
    EniIp?: string | undefined;
    SubscriptionType?: SubscriptionType | undefined;
    SubscriptionStartDate?: string | undefined;
    SubscriptionEndDate?: string | undefined;
    VpcId?: string | undefined;
    SubnetId?: string | undefined;
    IamRoleArn?: string | undefined;
    SerialNumber?: string | undefined;
    VendorName?: string | undefined;
    HsmType?: string | undefined;
    SoftwareVersion?: string | undefined;
    SshPublicKey?: string | undefined;
    SshKeyLastUpdated?: string | undefined;
    ServerCertUri?: string | undefined;
    ServerCertLastUpdated?: string | undefined;
    Partitions?: string[] | undefined;
}
export type CertificateFingerprint = string;
export interface DescribeLunaClientRequest {
    ClientArn?: string | undefined;
    CertificateFingerprint?: string | undefined;
}
export interface DescribeLunaClientResponse {
    ClientArn?: string | undefined;
    Certificate?: string | undefined;
    CertificateFingerprint?: string | undefined;
    LastModifiedTimestamp?: string | undefined;
    Label?: string | undefined;
}
export type ClientVersion = "5.1" | "5.3" | (string & {});
export type HapgList = string[];
export interface GetConfigRequest {
    ClientArn: string;
    ClientVersion: ClientVersion;
    HapgList: string[];
}
export interface GetConfigResponse {
    ConfigType?: string | undefined;
    ConfigFile?: string | undefined;
    ConfigCred?: string | undefined;
}
export interface ListAvailableZonesRequest {
}
export type AZList = string[];
export interface ListAvailableZonesResponse {
    AZList?: string[] | undefined;
}
export type PaginationToken = string;
export interface ListHapgsRequest {
    NextToken?: string | undefined;
}
export interface ListHapgsResponse {
    HapgList: string[];
    NextToken?: string | undefined;
}
export interface ListHsmsRequest {
    NextToken?: string | undefined;
}
export interface ListHsmsResponse {
    HsmList?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLunaClientsRequest {
    NextToken?: string | undefined;
}
export type ClientList = string[];
export interface ListLunaClientsResponse {
    ClientList: string[];
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    TagList: Tag[];
}
export interface ModifyHapgRequest {
    HapgArn: string;
    Label?: string | undefined;
    PartitionSerialList?: string[] | undefined;
}
export interface ModifyHapgResponse {
    HapgArn?: string | undefined;
}
export interface ModifyHsmRequest {
    HsmArn: string;
    SubnetId?: string | undefined;
    EniIp?: string | undefined;
    IamRoleArn?: string | undefined;
    ExternalId?: string | undefined;
    SyslogIp?: string | undefined;
}
export interface ModifyHsmResponse {
    HsmArn?: string | undefined;
}
export interface ModifyLunaClientRequest {
    ClientArn: string;
    Certificate: string;
}
export interface ModifyLunaClientResponse {
    ClientArn?: string | undefined;
}
export type TagKeyList = string[];
export interface RemoveTagsFromResourceRequest {
    ResourceArn: string;
    TagKeyList: string[];
}
export interface RemoveTagsFromResourceResponse {
    Status: string;
}
export type AddTagsToResourceError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Adds or overwrites one or more tags for the specified AWS CloudHSM resource.
 *
 * Each tag consists of a key and a value. Tag keys must be unique to each
 * resource.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceRequest & RegionInput, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type CreateHapgError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Creates a high-availability partition group. A high-availability partition group is a
 * group of partitions that spans multiple physical HSMs.
 */
export declare const createHapg: API.OperationMethod<CreateHapgRequest & RegionInput, CreateHapgResponse, CreateHapgError, Credentials | HttpClient.HttpClient>;
export type CreateHsmError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Creates an uninitialized HSM instance.
 *
 * There is an upfront fee charged for each HSM instance that you create with the
 * `CreateHsm` operation. If you accidentally provision an HSM and want to request a
 * refund, delete the instance using the DeleteHsm operation, go to the AWS Support Center, create a new case, and select
 * **Account and Billing Support**.
 *
 * It can take up to 20 minutes to create and provision an HSM. You can monitor the
 * status of the HSM with the DescribeHsm operation. The HSM is ready to be
 * initialized when the status changes to `RUNNING`.
 */
export declare const createHsm: API.OperationMethod<CreateHsmRequest & RegionInput, CreateHsmResponse, CreateHsmError, Credentials | HttpClient.HttpClient>;
export type CreateLunaClientError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Creates an HSM client.
 */
export declare const createLunaClient: API.OperationMethod<CreateLunaClientRequest & RegionInput, CreateLunaClientResponse, CreateLunaClientError, Credentials | HttpClient.HttpClient>;
export type DeleteHapgError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Deletes a high-availability partition group.
 */
export declare const deleteHapg: API.OperationMethod<DeleteHapgRequest & RegionInput, DeleteHapgResponse, DeleteHapgError, Credentials | HttpClient.HttpClient>;
export type DeleteHsmError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Deletes an HSM. After completion, this operation cannot be undone and your key material
 * cannot be recovered.
 */
export declare const deleteHsm: API.OperationMethod<DeleteHsmRequest & RegionInput, DeleteHsmResponse, DeleteHsmError, Credentials | HttpClient.HttpClient>;
export type DeleteLunaClientError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Deletes a client.
 */
export declare const deleteLunaClient: API.OperationMethod<DeleteLunaClientRequest & RegionInput, DeleteLunaClientResponse, DeleteLunaClientError, Credentials | HttpClient.HttpClient>;
export type DescribeHapgError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Retrieves information about a high-availability partition group.
 */
export declare const describeHapg: API.OperationMethod<DescribeHapgRequest & RegionInput, DescribeHapgResponse, DescribeHapgError, Credentials | HttpClient.HttpClient>;
export type DescribeHsmError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Retrieves information about an HSM. You can identify the HSM by its ARN or its serial
 * number.
 */
export declare const describeHsm: API.OperationMethod<DescribeHsmRequest & RegionInput, DescribeHsmResponse, DescribeHsmError, Credentials | HttpClient.HttpClient>;
export type DescribeLunaClientError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Retrieves information about an HSM client.
 */
export declare const describeLunaClient: API.OperationMethod<DescribeLunaClientRequest & RegionInput, DescribeLunaClientResponse, DescribeLunaClientError, Credentials | HttpClient.HttpClient>;
export type GetConfigError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Gets the configuration files necessary to connect to all high availability partition
 * groups the client is associated with.
 */
export declare const getConfig: API.OperationMethod<GetConfigRequest & RegionInput, GetConfigResponse, GetConfigError, Credentials | HttpClient.HttpClient>;
export type ListAvailableZonesError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Lists the Availability Zones that have available AWS CloudHSM capacity.
 */
export declare const listAvailableZones: API.OperationMethod<ListAvailableZonesRequest & RegionInput, ListAvailableZonesResponse, ListAvailableZonesError, Credentials | HttpClient.HttpClient>;
export type ListHapgsError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Lists the high-availability partition groups for the account.
 *
 * This operation supports pagination with the use of the `NextToken` member.
 * If more results are available, the `NextToken` member of the response contains a
 * token that you pass in the next call to `ListHapgs` to retrieve the next set of
 * items.
 */
export declare const listHapgs: API.OperationMethod<ListHapgsRequest & RegionInput, ListHapgsResponse, ListHapgsError, Credentials | HttpClient.HttpClient>;
export type ListHsmsError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Retrieves the identifiers of all of the HSMs provisioned for the current
 * customer.
 *
 * This operation supports pagination with the use of the `NextToken` member.
 * If more results are available, the `NextToken` member of the response contains a
 * token that you pass in the next call to `ListHsms` to retrieve the next set of
 * items.
 */
export declare const listHsms: API.OperationMethod<ListHsmsRequest & RegionInput, ListHsmsResponse, ListHsmsError, Credentials | HttpClient.HttpClient>;
export type ListLunaClientsError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Lists all of the clients.
 *
 * This operation supports pagination with the use of the `NextToken` member.
 * If more results are available, the `NextToken` member of the response contains a
 * token that you pass in the next call to `ListLunaClients` to retrieve the next set
 * of items.
 */
export declare const listLunaClients: API.OperationMethod<ListLunaClientsRequest & RegionInput, ListLunaClientsResponse, ListLunaClientsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Returns a list of all tags for the specified AWS CloudHSM resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyHapgError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Modifies an existing high-availability partition group.
 */
export declare const modifyHapg: API.OperationMethod<ModifyHapgRequest & RegionInput, ModifyHapgResponse, ModifyHapgError, Credentials | HttpClient.HttpClient>;
export type ModifyHsmError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Modifies an HSM.
 *
 * This operation can result in the HSM being offline for up to 15 minutes while the AWS
 * CloudHSM service is reconfigured. If you are modifying a production HSM, you should ensure
 * that your AWS CloudHSM service is configured for high availability, and consider executing this
 * operation during a maintenance window.
 */
export declare const modifyHsm: API.OperationMethod<ModifyHsmRequest & RegionInput, ModifyHsmResponse, ModifyHsmError, Credentials | HttpClient.HttpClient>;
export type ModifyLunaClientError = CloudHsmServiceException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Modifies the certificate used by the client.
 *
 * This action can potentially start a workflow to install the new certificate on the
 * client's HSMs.
 */
export declare const modifyLunaClient: API.OperationMethod<ModifyLunaClientRequest & RegionInput, ModifyLunaClientResponse, ModifyLunaClientError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = CloudHsmInternalException | CloudHsmServiceException | InvalidRequestException | CommonErrors;
/**
 * This is documentation for **AWS CloudHSM Classic**. For
 * more information, see AWS CloudHSM
 * Classic FAQs, the AWS
 * CloudHSM Classic User Guide, and the AWS CloudHSM Classic API Reference.
 *
 * For information about the current version of AWS
 * CloudHSM, see AWS CloudHSM, the
 * AWS CloudHSM User Guide,
 * and the AWS CloudHSM API
 * Reference.
 *
 * Removes one or more tags from the specified AWS CloudHSM resource.
 *
 * To remove a tag, specify only the tag key to remove (not the value). To overwrite the
 * value for an existing tag, use AddTagsToResource.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceRequest & RegionInput, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudhsm.d.ts.map