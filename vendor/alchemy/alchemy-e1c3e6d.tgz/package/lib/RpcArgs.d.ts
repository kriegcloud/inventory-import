import * as Effect from "effect/Effect";
declare const RpcDecodeError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "RpcDecodeError";
} & Readonly<A>;
export declare class RpcDecodeError extends RpcDecodeError_base<{
    readonly cause: unknown;
}> {
    get message(): string;
}
/**
 * Encode a method's arguments for a JSON transport, keeping an `undefined`
 * argument `undefined` on the other side. Trailing `undefined` arguments are
 * left off, which a callee on any version reads as `undefined`; one followed
 * by a defined argument goes as a marker that {@link decodeRpcArgs} restores.
 * Properties set to `undefined` inside an argument are dropped by JSON, which
 * the callee reads as `undefined` too.
 */
export declare const encodeRpcArgs: (args: ReadonlyArray<unknown>) => string;
/**
 * Decode arguments encoded by {@link encodeRpcArgs} (or by a plain
 * `JSON.stringify(args)`). An empty body is no arguments; anything other than
 * a JSON array fails with {@link RpcDecodeError}.
 */
export declare const decodeRpcArgs: (text: string) => Effect.Effect<Array<unknown>, RpcDecodeError>;
export {};
//# sourceMappingURL=RpcArgs.d.ts.map