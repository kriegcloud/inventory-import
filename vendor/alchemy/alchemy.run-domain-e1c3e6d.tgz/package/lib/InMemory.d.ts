import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { WorkflowEngine } from "effect/workflow";
import { Platform, type StreamHandled, type StreamMeta, type StreamWrite } from "./Platform.ts";
/**
 * Options for {@link make}.
 */
export interface Options {
    /**
     * When `true`, deliveries queue until {@link Control.drain} is called and
     * policy runs are tracked so a caller can wait for quiescence. Used by the
     * story runner. Defaults to `false` (deliver in the background).
     */
    readonly manual?: boolean;
    /** Clock used to time-stamp commands. Defaults to `Date.now`. */
    readonly now?: () => number;
    /**
     * With `manual`: pick which ready writer (a policy delivery, a saga run or a
     * saga's next step) runs next, by its index in `ready`. Called only when
     * more than one is ready. Defaults to the first, in the order they were queued.
     */
    readonly choose?: (ready: ReadonlyArray<string>) => number;
    /**
     * With `manual`: called after each queued item has run (until every run it
     * started is finished or waiting), with the streams it committed to.
     */
    readonly ran?: (label: string, wrote: ReadonlyArray<string>) => void;
}
/**
 * Control surface of an in-memory platform.
 */
export interface Control {
    /**
     * Send due scheduled commands, then deliver every queued delivery (and
     * those it produces) until the queue is empty.
     */
    readonly drain: Effect.Effect<void>;
    /** `true` when nothing is queued and every running policy is suspended. */
    readonly idle: Effect.Effect<boolean>;
    /**
     * Mark the current run as waiting while `effect` runs: on a story's
     * external system, a lock, or its turn to run. With `manual`, `drain` runs
     * one queued item at a time, until every run is finished or waiting.
     */
    readonly suspended: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /** Defects raised by policy and projection runs. */
    readonly failures: ReadonlyArray<unknown>;
    /** Saga runs that ended with a defect, in the order they died. */
    readonly deaths: ReadonlyArray<{
        readonly saga: string;
        readonly executionId: string;
        readonly defect: unknown;
    }>;
    /**
     * Every event a command committed (seeded events excluded), in commit
     * order: its aggregate, instance id, and position in the instance's
     * events, from 0.
     */
    readonly commits: ReadonlyArray<{
        readonly aggregate: string;
        readonly id: string;
        readonly index: number;
    }>;
}
/**
 * Build an in-memory platform and its control surface.
 */
export declare const make: (options?: Options) => {
    readonly layer: Layer.Layer<Platform | WorkflowEngine.WorkflowEngine | SecureRandom.SecureRandom>;
    readonly control: Control;
};
/**
 * Host a domain model in the current process: aggregates, views and policies,
 * with nothing to deploy. Use it in tests and single-process apps; swap it
 * for `DomainCloudflare.layerDurableObjects()` and nothing else changes.
 *
 * ### Hosting in memory
 * **Example:** A model with its policies
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 *
 * export const BankInMemory = Bank.layer(BankPolicies).pipe(Layer.provide(Domain.InMemory));
 * ```
 *
 * @layer
 * @provides Domain.Platform
 * @provides WorkflowEngine
 */
export declare const InMemory: Layer.Layer<Platform | WorkflowEngine.WorkflowEngine | SecureRandom.SecureRandom>;
/** Is a stream write's origin after the last one applied? @internal */
export declare const isAfter: (origin: readonly [number, number], last: readonly [number, number]) => boolean;
/** The later of two sets of per-source checkpoints. @internal */
export declare const mergeCheckpoints: (a: Readonly<Record<string, number>>, b: Readonly<Record<string, number>>) => Record<string, number>;
/**
 * What a write does to a stream key: the meta to store, and whether its
 * events are appended. A write from an older generation is dropped (the
 * writer is rebuilt; the old one runs only on older code); a newer one starts
 * its log, and drops the roots an earlier generation handled, which it is
 * replaying; within a generation, a write not after the last is a repeat.
 *
 * @internal
 */
export declare const admitStreamWrite: (meta: StreamMeta, write: Pick<StreamWrite, "generation" | "origin" | "root" | "source" | "sourceSeq">) => {
    readonly meta: StreamMeta;
    readonly appends: boolean;
};
/** A stream key's meta once its writer handled `handled`, appends or not. @internal */
export declare const advanceStreamMeta: (meta: StreamMeta, handled: StreamHandled) => StreamMeta;
//# sourceMappingURL=InMemory.d.ts.map