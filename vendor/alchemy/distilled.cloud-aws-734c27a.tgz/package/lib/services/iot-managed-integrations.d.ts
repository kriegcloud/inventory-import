import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type ConnectorDestinationId = string;
export type AccountAssociationName = string;
export type AccountAssociationDescription = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type AuthMaterialName = string;
export interface GeneralAuthorizationName {
    AuthMaterialName?: string | undefined;
}
export interface CreateAccountAssociationRequest {
    ClientToken?: string | undefined;
    ConnectorDestinationId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    GeneralAuthorization?: GeneralAuthorizationName | undefined;
}
export type OAuthAuthorizationUrlOutput = string | redacted.Redacted<string>;
export type AccountAssociationId = string;
export type AssociationState = "ASSOCIATION_IN_PROGRESS" | "ASSOCIATION_FAILED" | "ASSOCIATION_SUCCEEDED" | "ASSOCIATION_DELETING" | "REFRESH_TOKEN_EXPIRED" | (string & {});
export type AccountAssociationArn = string;
export interface CreateAccountAssociationResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    AccountAssociationId: string;
    AssociationState: AssociationState;
    Arn?: string | undefined;
}
export type DisplayName = string;
export type LambdaArn = string;
export interface LambdaConfig {
    arn: string;
}
export interface EndpointConfig {
    lambda?: LambdaConfig | undefined;
}
export type CloudConnectorDescription = string;
export type EndpointType = "LAMBDA" | (string & {});
export interface CreateCloudConnectorRequest {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string | undefined;
    EndpointType?: EndpointType | undefined;
    ClientToken?: string | undefined;
}
export type CloudConnectorId = string;
export interface CreateCloudConnectorResponse {
    Id?: string | undefined;
}
export type ConnectorDestinationName = string;
export type ConnectorDestinationDescription = string;
export type AuthType = "OAUTH" | (string & {});
export type AuthUrl = string;
export type TokenUrl = string;
export type TokenEndpointAuthenticationScheme = "HTTP_BASIC" | "REQUEST_BODY_CREDENTIALS" | (string & {});
export interface ProactiveRefreshTokenRenewal {
    enabled?: boolean | undefined;
    DaysBeforeRenewal?: number | undefined;
}
export interface OAuthConfig {
    authUrl: string;
    tokenUrl: string;
    scope?: string | undefined;
    tokenEndpointAuthenticationScheme: TokenEndpointAuthenticationScheme;
    oAuthCompleteRedirectUrl?: string | undefined;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal | undefined;
}
export type SecretsManagerArn = string;
export type SecretsManagerVersionId = string;
export interface SecretsManager {
    arn: string;
    versionId: string;
}
export interface AuthMaterial {
    SecretsManager: SecretsManager;
    AuthMaterialName: string;
}
export type AuthMaterials = AuthMaterial[];
export interface AuthConfig {
    oAuth?: OAuthConfig | undefined;
    GeneralAuthorization?: AuthMaterial[] | undefined;
}
export interface CreateConnectorDestinationRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    CloudConnectorId: string;
    AuthType?: AuthType | undefined;
    AuthConfig: AuthConfig;
    SecretsManager?: SecretsManager | undefined;
    ClientToken?: string | undefined;
}
export interface CreateConnectorDestinationResponse {
    Id?: string | undefined;
}
export type CredentialLockerName = string | redacted.Redacted<string>;
export interface CreateCredentialLockerRequest {
    Name?: string | redacted.Redacted<string> | undefined;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CredentialLockerId = string;
export type CredentialLockerArn = string;
export type CredentialLockerCreatedAt = Date;
export interface CreateCredentialLockerResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
}
export type DeliveryDestinationArn = string;
export type DeliveryDestinationType = "KINESIS" | (string & {});
export type DestinationName = string;
export type DeliveryDestinationRoleArn = string;
export type DestinationDescription = string;
export interface CreateDestinationRequest {
    DeliveryDestinationArn: string;
    DeliveryDestinationType: DeliveryDestinationType;
    Name: string;
    RoleArn: string;
    ClientToken?: string | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDestinationResponse {
    Name?: string | undefined;
}
export type SmartHomeResourceType = string;
export type SmartHomeResourceId = string;
export type LogLevel = "DEBUG" | "ERROR" | "INFO" | "WARN" | (string & {});
export interface CreateEventLogConfigurationRequest {
    ResourceType: string;
    ResourceId?: string | undefined;
    EventLogLevel: LogLevel;
    ClientToken?: string | undefined;
}
export type LogConfigurationId = string;
export interface CreateEventLogConfigurationResponse {
    Id?: string | undefined;
}
export type Role = "CONTROLLER" | "DEVICE" | (string & {});
export type Owner = string | redacted.Redacted<string>;
export type AuthMaterialString = string | redacted.Redacted<string>;
export type AuthMaterialType = "CUSTOM_PROTOCOL_QR_BAR_CODE" | "WIFI_SETUP_QR_BAR_CODE" | "ZWAVE_QR_BAR_CODE" | "ZIGBEE_QR_BAR_CODE" | "DISCOVERED_DEVICE" | "PRE_ONBOARDED_CLOUD" | (string & {});
export type EnableAsProvisioner = boolean;
export type EnableAsProvisionee = boolean;
export type TimeoutInMinutes = number;
export interface WiFiSimpleSetupConfiguration {
    EnableAsProvisioner?: boolean | undefined;
    EnableAsProvisionee?: boolean | undefined;
    TimeoutInMinutes?: number | undefined;
}
export type SerialNumber = string | redacted.Redacted<string>;
export type Brand = string | redacted.Redacted<string>;
export type Model = string | redacted.Redacted<string>;
export type Name = string;
export type CapabilityReportVersion = string;
export type NodeId = string;
export type EndpointId = string;
export type DeviceType = string;
export type DeviceTypes = string[];
export type SchemaVersionedId = string;
export type CapabilityName = string;
export type CapabilityVersion = string;
export type PropertyName = string;
export type CapabilityReportProperties = string[];
export type ActionName = string;
export type CapabilityReportActions = string[];
export type EventName = string;
export type CapabilityReportEvents = string[];
export interface CapabilityReportCapability {
    id: string;
    name: string;
    version: string;
    properties: string[];
    actions: string[];
    events: string[];
}
export type CapabilityReportCapabilities = CapabilityReportCapability[];
export interface CapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    capabilities: CapabilityReportCapability[];
}
export type CapabilityReportEndpoints = CapabilityReportEndpoint[];
export interface CapabilityReport {
    version: string;
    nodeId?: string | undefined;
    endpoints: CapabilityReportEndpoint[];
}
export type SchemaVersionFormat = "AWS" | "ZCL" | "CONNECTOR" | (string & {});
export type ExtrinsicSchemaId = string;
export type MatterCapabilityReportClusterRevisionId = number;
export type ValidationSchema = unknown;
export interface CapabilitySchemaItem {
    Format: SchemaVersionFormat;
    CapabilityId: string;
    ExtrinsicId: string;
    ExtrinsicVersion: number;
    Schema: any;
}
export type CapabilitySchemas = CapabilitySchemaItem[];
export type Capabilities = string;
export type Classification = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type MetaData = {
    [key: string]: string | undefined;
};
export interface CreateManagedThingRequest {
    Role: Role;
    Owner?: string | redacted.Redacted<string> | undefined;
    CredentialLockerId?: string | undefined;
    AuthenticationMaterial: string | redacted.Redacted<string>;
    AuthenticationMaterialType: AuthMaterialType;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration | undefined;
    SerialNumber?: string | redacted.Redacted<string> | undefined;
    Brand?: string | redacted.Redacted<string> | undefined;
    Model?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    CapabilityReport?: CapabilityReport | undefined;
    CapabilitySchemas?: CapabilitySchemaItem[] | undefined;
    Capabilities?: string | undefined;
    ClientToken?: string | undefined;
    Classification?: string | redacted.Redacted<string> | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    MetaData?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ManagedThingId = string;
export type ManagedThingArn = string;
export type CreatedAt = Date;
export interface CreateManagedThingResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
}
export type EventType = "DEVICE_COMMAND" | "DEVICE_COMMAND_REQUEST" | "DEVICE_DISCOVERY_STATUS" | "DEVICE_EVENT" | "DEVICE_LIFE_CYCLE" | "DEVICE_STATE" | "DEVICE_OTA" | "DEVICE_WSS" | "CONNECTOR_ASSOCIATION" | "ACCOUNT_ASSOCIATION" | "CONNECTOR_ERROR_REPORT" | (string & {});
export interface CreateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateNotificationConfigurationResponse {
    EventType?: EventType | undefined;
}
export type OtaDescription = string;
export type S3Url = string;
export type OtaProtocol = "HTTP" | (string & {});
export type Target = string[];
export type OtaTaskConfigurationId = string;
export type OtaMechanism = "PUSH" | (string & {});
export type OtaType = "ONE_TIME" | "CONTINUOUS" | (string & {});
export type OtaTargetQueryString = string;
export type SchedulingConfigEndBehavior = "STOP_ROLLOUT" | "CANCEL" | "FORCE_CANCEL" | (string & {});
export type EndTime = string;
export type DurationInMinutes = number;
export type StartTime = string;
export interface ScheduleMaintenanceWindow {
    DurationInMinutes?: number | undefined;
    StartTime?: string | undefined;
}
export type ScheduleMaintenanceWindowList = ScheduleMaintenanceWindow[];
export type ScheduleStartTime = string;
export interface OtaTaskSchedulingConfig {
    EndBehavior?: SchedulingConfigEndBehavior | undefined;
    EndTime?: string | undefined;
    MaintenanceWindows?: ScheduleMaintenanceWindow[] | undefined;
    StartTime?: string | undefined;
}
export type RetryCriteriaFailureType = "FAILED" | "TIMED_OUT" | "ALL" | (string & {});
export type MinNumberOfRetries = number;
export interface RetryConfigCriteria {
    FailureType?: RetryCriteriaFailureType | undefined;
    MinNumberOfRetries?: number | undefined;
}
export type RetryConfigCriteriaList = RetryConfigCriteria[];
export interface OtaTaskExecutionRetryConfig {
    RetryConfigCriteria?: RetryConfigCriteria[] | undefined;
}
export interface CreateOtaTaskRequest {
    Description?: string | undefined;
    S3Url: string;
    Protocol?: OtaProtocol | undefined;
    Target?: string[] | undefined;
    TaskConfigurationId?: string | undefined;
    OtaMechanism?: OtaMechanism | undefined;
    OtaType: OtaType;
    OtaTargetQueryString?: string | undefined;
    ClientToken?: string | undefined;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig | undefined;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type OtaTaskId = string;
export type OtaTaskArn = string;
export interface CreateOtaTaskResponse {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    Description?: string | undefined;
}
export type OtaTaskConfigurationName = string | redacted.Redacted<string>;
export type AbortCriteriaAction = "CANCEL" | (string & {});
export type AbortCriteriaFailureType = "FAILED" | "REJECTED" | "TIMED_OUT" | "ALL" | (string & {});
export type MinNumberOfExecutedThings = number;
export type ThresholdPercentage = number;
export interface AbortConfigCriteria {
    Action?: AbortCriteriaAction | undefined;
    FailureType?: AbortCriteriaFailureType | undefined;
    MinNumberOfExecutedThings?: number | undefined;
    ThresholdPercentage?: number | undefined;
}
export type AbortConfigCriteriaList = AbortConfigCriteria[];
export interface OtaTaskAbortConfig {
    AbortConfigCriteriaList?: AbortConfigCriteria[] | undefined;
}
export type BaseRatePerMinute = number;
export type IncrementFactor = number;
export type NumberOfNotifiedThings = number;
export type NumberOfSucceededThings = number;
export interface RolloutRateIncreaseCriteria {
    numberOfNotifiedThings?: number | undefined;
    numberOfSucceededThings?: number | undefined;
}
export interface ExponentialRolloutRate {
    BaseRatePerMinute?: number | undefined;
    IncrementFactor?: number | undefined;
    RateIncreaseCriteria?: RolloutRateIncreaseCriteria | undefined;
}
export type MaximumPerMinute = number;
export interface OtaTaskExecutionRolloutConfig {
    ExponentialRolloutRate?: ExponentialRolloutRate | undefined;
    MaximumPerMinute?: number | undefined;
}
export type InProgressTimeoutInMinutes = number;
export interface OtaTaskTimeoutConfig {
    InProgressTimeoutInMinutes?: number | undefined;
}
export interface PushConfig {
    AbortConfig?: OtaTaskAbortConfig | undefined;
    RolloutConfig?: OtaTaskExecutionRolloutConfig | undefined;
    TimeoutConfig?: OtaTaskTimeoutConfig | undefined;
}
export interface CreateOtaTaskConfigurationRequest {
    Description?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    PushConfig?: PushConfig | undefined;
    ClientToken?: string | undefined;
}
export interface CreateOtaTaskConfigurationResponse {
    TaskConfigurationId?: string | undefined;
}
export type ProvisioningType = "FLEET_PROVISIONING" | "JITR" | (string & {});
export type CaCertificate = string | redacted.Redacted<string>;
export type ClaimCertificate = string | redacted.Redacted<string>;
export type ProvisioningProfileName = string;
export interface CreateProvisioningProfileRequest {
    ProvisioningType: ProvisioningType;
    CaCertificate?: string | redacted.Redacted<string> | undefined;
    ClaimCertificate?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProvisioningProfileArn = string;
export type ProvisioningProfileId = string;
export type ProvisioningProfileStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type ClaimCertificatePrivateKey = string | redacted.Redacted<string>;
export interface CreateProvisioningProfileResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    ProvisioningType?: ProvisioningType | undefined;
    Id?: string | undefined;
    Status?: ProvisioningProfileStatus | undefined;
    ClaimCertificate?: string | redacted.Redacted<string> | undefined;
    ClaimCertificatePrivateKey?: string | redacted.Redacted<string> | undefined;
}
export interface DeleteAccountAssociationRequest {
    AccountAssociationId: string;
}
export interface DeleteAccountAssociationResponse {
}
export interface DeleteCloudConnectorRequest {
    Identifier: string;
}
export interface DeleteCloudConnectorResponse {
}
export interface DeleteConnectorDestinationRequest {
    Identifier: string;
}
export interface DeleteConnectorDestinationResponse {
}
export interface DeleteCredentialLockerRequest {
    Identifier: string;
}
export interface DeleteCredentialLockerResponse {
}
export interface DeleteDestinationRequest {
    Name: string;
}
export interface DeleteDestinationResponse {
}
export interface DeleteEventLogConfigurationRequest {
    Id: string;
}
export interface DeleteEventLogConfigurationResponse {
}
export interface DeleteManagedThingRequest {
    Identifier: string;
    Force?: boolean | undefined;
}
export interface DeleteManagedThingResponse {
}
export interface DeleteNotificationConfigurationRequest {
    EventType: EventType;
}
export interface DeleteNotificationConfigurationResponse {
}
export interface DeleteOtaTaskRequest {
    Identifier: string;
}
export interface DeleteOtaTaskResponse {
}
export interface DeleteOtaTaskConfigurationRequest {
    Identifier: string;
}
export interface DeleteOtaTaskConfigurationResponse {
}
export interface DeleteProvisioningProfileRequest {
    Identifier: string;
}
export interface DeleteProvisioningProfileResponse {
}
export interface DeregisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
}
export interface DeregisterAccountAssociationResponse {
}
export interface GetAccountAssociationRequest {
    AccountAssociationId: string;
}
export type AccountAssociationErrorMessage = string;
export interface GetAccountAssociationResponse {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string | undefined;
    ConnectorDestinationId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Arn?: string | undefined;
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    GeneralAuthorization?: GeneralAuthorizationName | undefined;
}
export interface GetCloudConnectorRequest {
    Identifier: string;
}
export type CloudConnectorType = "LISTED" | "UNLISTED" | (string & {});
export interface GetCloudConnectorResponse {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string | undefined;
    EndpointType?: EndpointType | undefined;
    Id?: string | undefined;
    Type?: CloudConnectorType | undefined;
}
export interface GetConnectorDestinationRequest {
    Identifier: string;
}
export type OAuthCompleteRedirectUrl = string;
export interface GetConnectorDestinationResponse {
    Name?: string | undefined;
    Description?: string | undefined;
    CloudConnectorId?: string | undefined;
    Id?: string | undefined;
    AuthType?: AuthType | undefined;
    AuthConfig?: AuthConfig | undefined;
    SecretsManager?: SecretsManager | undefined;
    OAuthCompleteRedirectUrl?: string | undefined;
}
export interface GetCredentialLockerRequest {
    Identifier: string;
}
export interface GetCredentialLockerResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetCustomEndpointRequest {
}
export type EndpointAddress = string;
export interface GetCustomEndpointResponse {
    EndpointAddress: string;
}
export interface GetDefaultEncryptionConfigurationRequest {
}
export type ConfigurationErrorCode = string;
export type ConfigurationErrorMessage = string;
export interface ConfigurationError {
    code?: string | undefined;
    message?: string | undefined;
}
export type ConfigurationState = "ENABLED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | (string & {});
export interface ConfigurationStatus {
    error?: ConfigurationError | undefined;
    state: ConfigurationState;
}
export type EncryptionType = "MANAGED_INTEGRATIONS_DEFAULT_ENCRYPTION" | "CUSTOMER_KEY_ENCRYPTION" | (string & {});
export type KmsKeyArn = string;
export interface GetDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string | undefined;
}
export interface GetDestinationRequest {
    Name: string;
}
export type DestinationCreatedAt = Date;
export type DestinationUpdatedAt = Date;
export interface GetDestinationResponse {
    Description?: string | undefined;
    DeliveryDestinationArn?: string | undefined;
    DeliveryDestinationType?: DeliveryDestinationType | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DeviceDiscoveryId = string;
export interface GetDeviceDiscoveryRequest {
    Identifier: string;
}
export type DeviceDiscoveryArn = string;
export type DiscoveryType = "ZWAVE" | "ZIGBEE" | "CLOUD" | "CUSTOM" | "CONTROLLER_CAPABILITY_REDISCOVERY" | (string & {});
export type DeviceDiscoveryStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export type DiscoveryStartedAt = Date;
export type ConnectorAssociationId = string;
export type DiscoveryFinishedAt = Date;
export interface GetDeviceDiscoveryResponse {
    Id: string;
    Arn: string;
    DiscoveryType: DiscoveryType;
    Status: DeviceDiscoveryStatus;
    StartedAt: Date;
    ControllerId?: string | undefined;
    ConnectorAssociationId?: string | undefined;
    AccountAssociationId?: string | undefined;
    FinishedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEventLogConfigurationRequest {
    Id: string;
}
export interface GetEventLogConfigurationResponse {
    Id?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    EventLogLevel?: LogLevel | undefined;
}
export interface GetHubConfigurationRequest {
}
export type HubTokenTimerExpirySettingInSeconds = number;
export type HubConfigurationUpdatedAt = Date;
export interface GetHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetManagedThingRequest {
    Identifier: string;
}
export type AdvertisedProductId = string;
export type ProvisioningStatus = "UNASSOCIATED" | "PRE_ASSOCIATED" | "DISCOVERED" | "ACTIVATED" | "DELETION_FAILED" | "DELETE_IN_PROGRESS" | "ISOLATED" | "DELETED" | (string & {});
export type UniversalProductCode = string | redacted.Redacted<string>;
export type InternationalArticleNumber = string | redacted.Redacted<string>;
export type ConnectorPolicyId = string;
export type ConnectorDeviceId = string | redacted.Redacted<string>;
export type DeviceSpecificKey = string | redacted.Redacted<string>;
export type MacAddress = string | redacted.Redacted<string>;
export type ParentControllerId = string;
export type UpdatedAt = Date;
export type SetupAt = Date;
export type HubNetworkMode = "STANDARD" | "NETWORK_WIDE_EXCLUSION" | (string & {});
export interface GetManagedThingResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    Owner?: string | redacted.Redacted<string> | undefined;
    CredentialLockerId?: string | undefined;
    AdvertisedProductId?: string | undefined;
    Role?: Role | undefined;
    ProvisioningStatus?: ProvisioningStatus | undefined;
    Name?: string | undefined;
    Model?: string | redacted.Redacted<string> | undefined;
    Brand?: string | redacted.Redacted<string> | undefined;
    SerialNumber?: string | redacted.Redacted<string> | undefined;
    UniversalProductCode?: string | redacted.Redacted<string> | undefined;
    InternationalArticleNumber?: string | redacted.Redacted<string> | undefined;
    ConnectorPolicyId?: string | undefined;
    ConnectorDestinationId?: string | undefined;
    ConnectorDeviceId?: string | redacted.Redacted<string> | undefined;
    DeviceSpecificKey?: string | redacted.Redacted<string> | undefined;
    MacAddress?: string | redacted.Redacted<string> | undefined;
    ParentControllerId?: string | undefined;
    Classification?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ActivatedAt?: Date | undefined;
    HubNetworkMode?: HubNetworkMode | undefined;
    MetaData?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration | undefined;
}
export interface GetManagedThingCapabilitiesRequest {
    Identifier: string;
}
export interface GetManagedThingCapabilitiesResponse {
    ManagedThingId?: string | undefined;
    Capabilities?: string | undefined;
    CapabilityReport?: CapabilityReport | undefined;
}
export interface GetManagedThingCertificateRequest {
    Identifier: string;
}
export type CertificatePem = string;
export interface GetManagedThingCertificateResponse {
    ManagedThingId?: string | undefined;
    CertificatePem?: string | undefined;
}
export interface GetManagedThingConnectivityDataRequest {
    Identifier: string;
}
export type ConnectivityStatus = boolean;
export type ConnectivityTimestamp = Date;
export type DisconnectReasonValue = "AUTH_ERROR" | "CLIENT_INITIATED_DISCONNECT" | "CLIENT_ERROR" | "CONNECTION_LOST" | "DUPLICATE_CLIENTID" | "FORBIDDEN_ACCESS" | "MQTT_KEEP_ALIVE_TIMEOUT" | "SERVER_ERROR" | "SERVER_INITIATED_DISCONNECT" | "THROTTLED" | "WEBSOCKET_TTL_EXPIRATION" | "CUSTOMAUTH_TTL_EXPIRATION" | "UNKNOWN" | "NONE" | (string & {});
export interface GetManagedThingConnectivityDataResponse {
    ManagedThingId?: string | undefined;
    Connected?: boolean | undefined;
    Timestamp?: Date | undefined;
    DisconnectReason?: DisconnectReasonValue | undefined;
}
export interface GetManagedThingMetaDataRequest {
    Identifier: string;
}
export interface GetManagedThingMetaDataResponse {
    ManagedThingId?: string | undefined;
    MetaData?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetManagedThingStateRequest {
    ManagedThingId: string;
}
export type CapabilityProperties = unknown;
export interface StateCapability {
    id: string;
    name: string;
    version: string;
    properties?: any | undefined;
}
export type StateCapabilities = StateCapability[];
export interface StateEndpoint {
    endpointId: string;
    capabilities: StateCapability[];
}
export type StateEndpoints = StateEndpoint[];
export interface GetManagedThingStateResponse {
    Endpoints: StateEndpoint[];
}
export interface GetNotificationConfigurationRequest {
    EventType: EventType;
}
export type NotificationConfigurationCreatedAt = Date;
export type NotificationConfigurationUpdatedAt = Date;
export interface GetNotificationConfigurationResponse {
    EventType?: EventType | undefined;
    DestinationName?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetOtaTaskRequest {
    Identifier: string;
}
export type LastUpdatedAt = Date;
export interface TaskProcessingDetails {
    NumberOfCanceledThings?: number | undefined;
    NumberOfFailedThings?: number | undefined;
    NumberOfInProgressThings?: number | undefined;
    numberOfQueuedThings?: number | undefined;
    numberOfRejectedThings?: number | undefined;
    numberOfRemovedThings?: number | undefined;
    numberOfSucceededThings?: number | undefined;
    numberOfTimedOutThings?: number | undefined;
    processingTargets?: string[] | undefined;
}
export type OtaStatus = "IN_PROGRESS" | "CANCELED" | "COMPLETED" | "DELETION_IN_PROGRESS" | "SCHEDULED" | (string & {});
export interface GetOtaTaskResponse {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    Description?: string | undefined;
    S3Url?: string | undefined;
    Protocol?: OtaProtocol | undefined;
    OtaType?: OtaType | undefined;
    OtaTargetQueryString?: string | undefined;
    OtaMechanism?: OtaMechanism | undefined;
    Target?: string[] | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    TaskConfigurationId?: string | undefined;
    TaskProcessingDetails?: TaskProcessingDetails | undefined;
    OtaSchedulingConfig?: OtaTaskSchedulingConfig | undefined;
    OtaTaskExecutionRetryConfig?: OtaTaskExecutionRetryConfig | undefined;
    Status?: OtaStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetOtaTaskConfigurationRequest {
    Identifier: string;
}
export interface GetOtaTaskConfigurationResponse {
    TaskConfigurationId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    PushConfig?: PushConfig | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
}
export interface GetProvisioningProfileRequest {
    Identifier: string;
}
export interface GetProvisioningProfileResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    ProvisioningType?: ProvisioningType | undefined;
    Id?: string | undefined;
    Status?: ProvisioningProfileStatus | undefined;
    ClaimCertificate?: string | redacted.Redacted<string> | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export type LocalStoreLocation = string;
export type LocalStoreFileRotationMaxFiles = number;
export type LocalStoreFileRotationMaxBytes = number;
export type UploadLog = boolean;
export type UploadPeriodMinutes = number;
export type DeleteLocalStoreAfterUpload = boolean;
export interface RuntimeLogConfigurations {
    LogLevel?: LogLevel | undefined;
    LogFlushLevel?: LogLevel | undefined;
    LocalStoreLocation?: string | undefined;
    LocalStoreFileRotationMaxFiles?: number | undefined;
    LocalStoreFileRotationMaxBytes?: number | undefined;
    UploadLog?: boolean | undefined;
    UploadPeriodMinutes?: number | undefined;
    DeleteLocalStoreAfterUpload?: boolean | undefined;
}
export interface GetRuntimeLogConfigurationResponse {
    ManagedThingId?: string | undefined;
    RuntimeLogConfigurations?: RuntimeLogConfigurations | undefined;
}
export type SchemaVersionType = "capability" | "definition" | (string & {});
export interface GetSchemaVersionRequest {
    Type: SchemaVersionType;
    SchemaVersionedId: string;
    Format?: SchemaVersionFormat | undefined;
}
export type SchemaId = string;
export type SchemaVersionDescription = string;
export type SchemaVersionNamespaceName = string;
export type SchemaVersionVersion = string;
export type SchemaVersionVisibility = "PUBLIC" | "PRIVATE" | (string & {});
export type SchemaVersionSchema = unknown;
export interface GetSchemaVersionResponse {
    SchemaId?: string | undefined;
    Type?: SchemaVersionType | undefined;
    Description?: string | undefined;
    Namespace?: string | undefined;
    SemanticVersion?: string | undefined;
    Visibility?: SchemaVersionVisibility | undefined;
    Schema?: any | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAccountAssociationsRequest {
    ConnectorDestinationId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AccountAssociationItem {
    AccountAssociationId: string;
    AssociationState: AssociationState;
    ErrorMessage?: string | undefined;
    ConnectorDestinationId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Arn?: string | undefined;
}
export type AccountAssociationListDefinition = AccountAssociationItem[];
export interface ListAccountAssociationsResponse {
    Items?: AccountAssociationItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCloudConnectorsRequest {
    Type?: CloudConnectorType | undefined;
    LambdaArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ConnectorItem {
    Name: string;
    EndpointConfig: EndpointConfig;
    Description?: string | undefined;
    EndpointType?: EndpointType | undefined;
    Id?: string | undefined;
    Type?: CloudConnectorType | undefined;
}
export type ConnectorList = ConnectorItem[];
export interface ListCloudConnectorsResponse {
    Items?: ConnectorItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConnectorDestinationsRequest {
    CloudConnectorId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ConnectorDestinationSummary {
    Name?: string | undefined;
    Description?: string | undefined;
    CloudConnectorId?: string | undefined;
    Id?: string | undefined;
}
export type ConnectorDestinationListDefinition = ConnectorDestinationSummary[];
export interface ListConnectorDestinationsResponse {
    ConnectorDestinationList?: ConnectorDestinationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCredentialLockersRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface CredentialLockerSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
}
export type CredentialLockerListDefinition = CredentialLockerSummary[];
export interface ListCredentialLockersResponse {
    Items?: CredentialLockerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDestinationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DestinationSummary {
    Description?: string | undefined;
    DeliveryDestinationArn?: string | undefined;
    DeliveryDestinationType?: DeliveryDestinationType | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
}
export type DestinationListDefinition = DestinationSummary[];
export interface ListDestinationsResponse {
    DestinationList?: DestinationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeviceDiscoveriesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    TypeFilter?: DiscoveryType | undefined;
    StatusFilter?: DeviceDiscoveryStatus | undefined;
}
export interface DeviceDiscoverySummary {
    Id?: string | undefined;
    DiscoveryType?: DiscoveryType | undefined;
    Status?: DeviceDiscoveryStatus | undefined;
}
export type DeviceDiscoveryListDefinition = DeviceDiscoverySummary[];
export interface ListDeviceDiscoveriesResponse {
    Items?: DeviceDiscoverySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDiscoveredDevicesRequest {
    Identifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ConnectorDeviceName = string;
export type DeviceTypeList = string[];
export type DiscoveryModification = "DISCOVERED" | "UPDATED" | "NO_CHANGE" | (string & {});
export type DiscoveredAt = Date;
export interface DiscoveredDeviceSummary {
    ConnectorDeviceId?: string | redacted.Redacted<string> | undefined;
    ConnectorDeviceName?: string | undefined;
    DeviceTypes?: string[] | undefined;
    ManagedThingId?: string | undefined;
    Modification?: DiscoveryModification | undefined;
    DiscoveredAt?: Date | undefined;
    Brand?: string | redacted.Redacted<string> | undefined;
    Model?: string | redacted.Redacted<string> | undefined;
    AuthenticationMaterial?: string | redacted.Redacted<string> | undefined;
}
export type DiscoveredDeviceListDefinition = DiscoveredDeviceSummary[];
export interface ListDiscoveredDevicesResponse {
    Items?: DiscoveredDeviceSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventLogConfigurationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EventLogConfigurationSummary {
    Id?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    EventLogLevel?: LogLevel | undefined;
}
export type EventLogConfigurationListDefinition = EventLogConfigurationSummary[];
export interface ListEventLogConfigurationsResponse {
    EventLogConfigurationList?: EventLogConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListManagedThingAccountAssociationsRequest {
    ManagedThingId?: string | undefined;
    AccountAssociationId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ManagedThingAssociationStatus = "PRE_ASSOCIATED" | "ASSOCIATED" | (string & {});
export interface ManagedThingAssociation {
    ManagedThingId?: string | undefined;
    AccountAssociationId?: string | undefined;
    ManagedThingAssociationStatus?: ManagedThingAssociationStatus | undefined;
}
export type ManagedThingAssociationList = ManagedThingAssociation[];
export interface ListManagedThingAccountAssociationsResponse {
    Items?: ManagedThingAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListManagedThingsRequest {
    OwnerFilter?: string | redacted.Redacted<string> | undefined;
    CredentialLockerFilter?: string | undefined;
    RoleFilter?: Role | undefined;
    ParentControllerIdentifierFilter?: string | undefined;
    ConnectorPolicyIdFilter?: string | undefined;
    ConnectorDestinationIdFilter?: string | undefined;
    ConnectorDeviceIdFilter?: string | redacted.Redacted<string> | undefined;
    SerialNumberFilter?: string | redacted.Redacted<string> | undefined;
    ProvisioningStatusFilter?: ProvisioningStatus | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ManagedThingSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    AdvertisedProductId?: string | undefined;
    Brand?: string | redacted.Redacted<string> | undefined;
    Classification?: string | redacted.Redacted<string> | undefined;
    ConnectorDeviceId?: string | redacted.Redacted<string> | undefined;
    ConnectorPolicyId?: string | undefined;
    ConnectorDestinationId?: string | undefined;
    Model?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Owner?: string | redacted.Redacted<string> | undefined;
    CredentialLockerId?: string | undefined;
    ParentControllerId?: string | undefined;
    ProvisioningStatus?: ProvisioningStatus | undefined;
    Role?: Role | undefined;
    SerialNumber?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ActivatedAt?: Date | undefined;
}
export type ManagedThingListDefinition = ManagedThingSummary[];
export interface ListManagedThingsResponse {
    Items?: ManagedThingSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CapabilityId = string;
export interface ListManagedThingSchemasRequest {
    Identifier: string;
    EndpointIdFilter?: string | undefined;
    CapabilityIdFilter?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ManagedThingSchemaListItem {
    EndpointId?: string | undefined;
    CapabilityId?: string | undefined;
    Schema?: any | undefined;
}
export type ManagedThingSchemaListDefinition = ManagedThingSchemaListItem[];
export interface ListManagedThingSchemasResponse {
    Items?: ManagedThingSchemaListItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListNotificationConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface NotificationConfigurationSummary {
    EventType?: EventType | undefined;
    DestinationName?: string | undefined;
}
export type NotificationConfigurationListDefinition = NotificationConfigurationSummary[];
export interface ListNotificationConfigurationsResponse {
    NotificationConfigurationList?: NotificationConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOtaTaskConfigurationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface OtaTaskConfigurationSummary {
    TaskConfigurationId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
}
export type OtaTaskConfigurationListDefinition = OtaTaskConfigurationSummary[];
export interface ListOtaTaskConfigurationsResponse {
    Items?: OtaTaskConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type OtaNextToken = string;
export interface ListOtaTaskExecutionsRequest {
    Identifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ExecutionNumber = number;
export type QueuedAt = Date;
export type RetryAttempt = number;
export type StartedAt = Date;
export type OtaTaskExecutionStatus = "QUEUED" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "REJECTED" | "REMOVED" | "CANCELED" | (string & {});
export interface OtaTaskExecutionSummary {
    ExecutionNumber?: number | undefined;
    LastUpdatedAt?: Date | undefined;
    QueuedAt?: Date | undefined;
    RetryAttempt?: number | undefined;
    StartedAt?: Date | undefined;
    Status?: OtaTaskExecutionStatus | undefined;
}
export interface OtaTaskExecutionSummaries {
    TaskExecutionSummary?: OtaTaskExecutionSummary | undefined;
    ManagedThingId?: string | undefined;
}
export type OtaTaskExecutionSummariesListDefinition = OtaTaskExecutionSummaries[];
export interface ListOtaTaskExecutionsResponse {
    ExecutionSummaries?: OtaTaskExecutionSummaries[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOtaTasksRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface OtaTaskSummary {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    TaskConfigurationId?: string | undefined;
    Status?: OtaStatus | undefined;
}
export type OtaTaskListDefinition = OtaTaskSummary[];
export interface ListOtaTasksResponse {
    Tasks?: OtaTaskSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProvisioningProfilesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ProvisioningProfileSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Arn?: string | undefined;
    ProvisioningType?: ProvisioningType | undefined;
    Status?: ProvisioningProfileStatus | undefined;
}
export type ProvisioningProfileListDefinition = ProvisioningProfileSummary[];
export interface ListProvisioningProfilesResponse {
    Items?: ProvisioningProfileSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSchemaVersionsRequest {
    Type: SchemaVersionType;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SchemaId?: string | undefined;
    Namespace?: string | undefined;
    Visibility?: SchemaVersionVisibility | undefined;
    SemanticVersion?: string | undefined;
}
export interface SchemaVersionListItem {
    SchemaId?: string | undefined;
    Type?: SchemaVersionType | undefined;
    Description?: string | undefined;
    Namespace?: string | undefined;
    SemanticVersion?: string | undefined;
    Visibility?: SchemaVersionVisibility | undefined;
}
export type SchemaVersionList = SchemaVersionListItem[];
export interface ListSchemaVersionsResponse {
    Items?: SchemaVersionListItem[] | undefined;
    NextToken?: string | undefined;
}
export type IoTManagedIntegrationsResourceARN = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutDefaultEncryptionConfigurationRequest {
    encryptionType: EncryptionType;
    kmsKeyArn?: string | undefined;
}
export interface PutDefaultEncryptionConfigurationResponse {
    configurationStatus: ConfigurationStatus;
    encryptionType: EncryptionType;
    kmsKeyArn?: string | undefined;
}
export interface PutHubConfigurationRequest {
    HubTokenTimerExpirySettingInSeconds: number;
}
export interface PutHubConfigurationResponse {
    HubTokenTimerExpirySettingInSeconds?: number | undefined;
}
export interface PutRuntimeLogConfigurationRequest {
    ManagedThingId: string;
    RuntimeLogConfigurations: RuntimeLogConfigurations;
}
export interface PutRuntimeLogConfigurationResponse {
}
export interface RegisterAccountAssociationRequest {
    ManagedThingId: string;
    AccountAssociationId: string;
    DeviceDiscoveryId: string;
}
export interface RegisterAccountAssociationResponse {
    AccountAssociationId?: string | undefined;
    DeviceDiscoveryId?: string | undefined;
    ManagedThingId?: string | undefined;
}
export interface RegisterCustomEndpointRequest {
}
export interface RegisterCustomEndpointResponse {
    EndpointAddress: string;
}
export interface ResetRuntimeLogConfigurationRequest {
    ManagedThingId: string;
}
export interface ResetRuntimeLogConfigurationResponse {
}
export type ConnectorId = string;
export type ThirdPartyUserId = string | redacted.Redacted<string>;
export type ConnectorEventOperation = "DEVICE_COMMAND_RESPONSE" | "DEVICE_DISCOVERY" | "DEVICE_EVENT" | "DEVICE_COMMAND_REQUEST" | (string & {});
export type ConnectorEventOperationVersion = string;
export type ConnectorEventStatusCode = number;
export type ConnectorEventMessage = string | redacted.Redacted<string>;
export type TraceId = string;
export type ClusterId = string;
export type SpecVersion = string;
export type MatterAttributeId = string;
export type MatterCapabilityReportAttributeValue = unknown;
export interface MatterCapabilityReportAttribute {
    id?: string | undefined;
    name?: string | undefined;
    value?: any | undefined;
}
export type MatterCapabilityReportAttributes = MatterCapabilityReportAttribute[];
export type MatterCommandId = string;
export type MatterCapabilityReportCommands = string[];
export type MatterEventId = string;
export type MatterCapabilityReportEvents = string[];
export type MatterCapabilityReportFeatureMap = number;
export type MatterCapabilityReportGeneratedCommands = string[];
export type MatterCapabilityReportFabricIndex = number;
export interface MatterCapabilityReportCluster {
    id: string;
    revision: number;
    publicId?: string | undefined;
    name?: string | undefined;
    specVersion?: string | undefined;
    attributes?: MatterCapabilityReportAttribute[] | undefined;
    commands?: string[] | undefined;
    events?: string[] | undefined;
    featureMap?: number | undefined;
    generatedCommands?: string[] | undefined;
    fabricIndex?: number | undefined;
}
export type MatterCapabilityReportClusters = MatterCapabilityReportCluster[];
export type MatterCapabilityReportEndpointParts = string[];
export type EndpointSemanticTag = string;
export type MatterCapabilityReportEndpointSemanticTags = string[];
export type MatterCapabilityReportEndpointClientClusters = string[];
export interface MatterCapabilityReportEndpoint {
    id: string;
    deviceTypes: string[];
    clusters: MatterCapabilityReportCluster[];
    parts?: string[] | undefined;
    semanticTags?: string[] | undefined;
    clientClusters?: string[] | undefined;
}
export type MatterCapabilityReportEndpoints = MatterCapabilityReportEndpoint[];
export interface MatterCapabilityReport {
    version: string;
    nodeId?: string | undefined;
    endpoints: MatterCapabilityReportEndpoint[];
}
export type DeviceMetadata = unknown;
export interface Device {
    ConnectorDeviceId: string | redacted.Redacted<string>;
    ConnectorDeviceName?: string | undefined;
    CapabilityReport: MatterCapabilityReport;
    CapabilitySchemas?: CapabilitySchemaItem[] | undefined;
    DeviceMetadata?: any | undefined;
}
export type Devices = Device[];
export type MatterAttributes = unknown;
export type MatterFields = unknown;
export type MatterCommands = {
    [key: string]: any | undefined;
};
export type MatterEvents = {
    [key: string]: any | undefined;
};
export interface MatterCluster {
    id?: string | undefined;
    attributes?: any | undefined;
    commands?: {
        [key: string]: any | undefined;
    } | undefined;
    events?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type MatterClusters = MatterCluster[];
export interface MatterEndpoint {
    id?: string | undefined;
    clusters?: MatterCluster[] | undefined;
}
export interface SendConnectorEventRequest {
    ConnectorId: string;
    UserId?: string | redacted.Redacted<string> | undefined;
    Operation: ConnectorEventOperation;
    OperationVersion?: string | undefined;
    StatusCode?: number | undefined;
    Message?: string | redacted.Redacted<string> | undefined;
    DeviceDiscoveryId?: string | undefined;
    ConnectorDeviceId?: string | redacted.Redacted<string> | undefined;
    TraceId?: string | undefined;
    Devices?: Device[] | undefined;
    MatterEndpoint?: MatterEndpoint | undefined;
}
export interface SendConnectorEventResponse {
    ConnectorId: string;
}
export type CapabilityActionName = string;
export type ActionReference = string;
export type ActionTraceId = string;
export interface CapabilityAction {
    name: string;
    ref?: string | undefined;
    actionTraceId?: string | undefined;
    parameters?: any | undefined;
}
export type CapabilityActions = CapabilityAction[];
export interface CommandCapability {
    id: string;
    name: string;
    version: string;
    actions: CapabilityAction[];
}
export type CommandCapabilities = CommandCapability[];
export interface CommandEndpoint {
    endpointId: string;
    capabilities: CommandCapability[];
}
export type CommandEndpoints = CommandEndpoint[];
export interface SendManagedThingCommandRequest {
    ManagedThingId: string;
    Endpoints: CommandEndpoint[];
    ConnectorAssociationId?: string | undefined;
    AccountAssociationId?: string | undefined;
}
export interface SendManagedThingCommandResponse {
    TraceId?: string | undefined;
}
export interface StartAccountAssociationRefreshRequest {
    AccountAssociationId: string;
}
export interface StartAccountAssociationRefreshResponse {
    OAuthAuthorizationUrl: string | redacted.Redacted<string>;
}
export type CustomProtocolDetailKey = string;
export type CustomProtocolDetailValue = string;
export type CustomProtocolDetail = {
    [key: string]: string | undefined;
};
export type DiscoveryAuthMaterialString = string | redacted.Redacted<string>;
export type DiscoveryAuthMaterialType = "ZWAVE_INSTALL_CODE" | (string & {});
export type ConnectorDeviceIdList = (string | redacted.Redacted<string>)[];
export type ProtocolType = "ZWAVE" | "ZIGBEE" | "CUSTOM" | (string & {});
export interface StartDeviceDiscoveryRequest {
    DiscoveryType: DiscoveryType;
    CustomProtocolDetail?: {
        [key: string]: string | undefined;
    } | undefined;
    ControllerIdentifier?: string | undefined;
    ConnectorAssociationIdentifier?: string | undefined;
    AccountAssociationId?: string | undefined;
    AuthenticationMaterial?: string | redacted.Redacted<string> | undefined;
    AuthenticationMaterialType?: DiscoveryAuthMaterialType | undefined;
    ClientToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ConnectorDeviceIdList?: (string | redacted.Redacted<string>)[] | undefined;
    Protocol?: ProtocolType | undefined;
    EndDeviceIdentifier?: string | undefined;
}
export interface StartDeviceDiscoveryResponse {
    Id?: string | undefined;
    StartedAt?: Date | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccountAssociationRequest {
    AccountAssociationId: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateAccountAssociationResponse {
}
export interface UpdateCloudConnectorRequest {
    Identifier: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateCloudConnectorResponse {
}
export interface OAuthUpdate {
    oAuthCompleteRedirectUrl?: string | undefined;
    proactiveRefreshTokenRenewal?: ProactiveRefreshTokenRenewal | undefined;
}
export interface GeneralAuthorizationUpdate {
    AuthMaterialsToAdd?: AuthMaterial[] | undefined;
    AuthMaterialsToUpdate?: AuthMaterial[] | undefined;
}
export interface AuthConfigUpdate {
    oAuthUpdate?: OAuthUpdate | undefined;
    GeneralAuthorizationUpdate?: GeneralAuthorizationUpdate | undefined;
}
export interface UpdateConnectorDestinationRequest {
    Identifier: string;
    Description?: string | undefined;
    Name?: string | undefined;
    AuthType?: AuthType | undefined;
    AuthConfig?: AuthConfigUpdate | undefined;
    SecretsManager?: SecretsManager | undefined;
}
export interface UpdateConnectorDestinationResponse {
}
export interface UpdateDestinationRequest {
    Name: string;
    DeliveryDestinationArn?: string | undefined;
    DeliveryDestinationType?: DeliveryDestinationType | undefined;
    RoleArn?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateDestinationResponse {
}
export interface UpdateEventLogConfigurationRequest {
    Id: string;
    EventLogLevel: LogLevel;
}
export interface UpdateEventLogConfigurationResponse {
}
export interface UpdateManagedThingRequest {
    Identifier: string;
    Owner?: string | redacted.Redacted<string> | undefined;
    CredentialLockerId?: string | undefined;
    SerialNumber?: string | redacted.Redacted<string> | undefined;
    WiFiSimpleSetupConfiguration?: WiFiSimpleSetupConfiguration | undefined;
    Brand?: string | redacted.Redacted<string> | undefined;
    Model?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    CapabilityReport?: CapabilityReport | undefined;
    CapabilitySchemas?: CapabilitySchemaItem[] | undefined;
    Capabilities?: string | undefined;
    Classification?: string | redacted.Redacted<string> | undefined;
    HubNetworkMode?: HubNetworkMode | undefined;
    MetaData?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateManagedThingResponse {
}
export interface UpdateNotificationConfigurationRequest {
    EventType: EventType;
    DestinationName: string;
}
export interface UpdateNotificationConfigurationResponse {
}
export interface UpdateOtaTaskRequest {
    Identifier: string;
    Description?: string | undefined;
    TaskConfigurationId?: string | undefined;
}
export interface UpdateOtaTaskResponse {
}
export type ErrorMessage = string;
export type ErrorResourceId = string;
export type ErrorResourceType = string;
export type CreateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a new account association via the destination id.
 */
export declare const createAccountAssociation: API.OperationMethod<CreateAccountAssociationRequest & RegionInput, CreateAccountAssociationResponse, CreateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateCloudConnectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a C2C (cloud-to-cloud) connector.
 */
export declare const createCloudConnector: API.OperationMethod<CreateCloudConnectorRequest & RegionInput, CreateCloudConnectorResponse, CreateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a connector destination for connecting a cloud-to-cloud (C2C) connector to the customer's Amazon Web Services account.
 */
export declare const createConnectorDestination: API.OperationMethod<CreateConnectorDestinationRequest & RegionInput, CreateConnectorDestinationResponse, CreateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateCredentialLockerError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a credential locker.
 *
 * This operation will not trigger the creation of all the manufacturing resources.
 */
export declare const createCredentialLocker: API.OperationMethod<CreateCredentialLockerRequest & RegionInput, CreateCredentialLockerResponse, CreateCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type CreateDestinationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a notification destination such as Kinesis Data Streams that receive events and notifications from Managed integrations. Managed integrations uses the destination to determine where to deliver notifications.
 */
export declare const createDestination: API.OperationMethod<CreateDestinationRequest & RegionInput, CreateDestinationResponse, CreateDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateEventLogConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the event log configuration for the account, resource type, or specific resource.
 */
export declare const createEventLogConfiguration: API.OperationMethod<CreateEventLogConfigurationRequest & RegionInput, CreateEventLogConfigurationResponse, CreateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates a managed thing. A managed thing contains the device identifier, protocol supported, and capabilities of the device in a data model format defined by Managed integrations.
 */
export declare const createManagedThing: API.OperationMethod<CreateManagedThingRequest & RegionInput, CreateManagedThingResponse, CreateManagedThingError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a notification configuration. A configuration is a connection between an event type and a destination that you have already created.
 */
export declare const createNotificationConfiguration: API.OperationMethod<CreateNotificationConfigurationRequest & RegionInput, CreateNotificationConfigurationResponse, CreateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create an over-the-air (OTA) task to target a device.
 */
export declare const createOtaTask: API.OperationMethod<CreateOtaTaskRequest & RegionInput, CreateOtaTaskResponse, CreateOtaTaskError, Credentials | HttpClient.HttpClient>;
export type CreateOtaTaskConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a configuraiton for the over-the-air (OTA) task.
 */
export declare const createOtaTaskConfiguration: API.OperationMethod<CreateOtaTaskConfigurationRequest & RegionInput, CreateOtaTaskConfigurationResponse, CreateOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Create a provisioning profile for executing device provisioning flows. The provisioning profile is a document that defines the set of resources and policies applied to a device during the provisioning process.
 */
export declare const createProvisioningProfile: API.OperationMethod<CreateProvisioningProfileRequest & RegionInput, CreateProvisioningProfileResponse, CreateProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove a third-party account association for an end user.
 *
 * You must first call the `DeregisterAccountAssociation` to remove the connection between the managed thing and the third-party account before calling the `DeleteAccountAssociation` API.
 */
export declare const deleteAccountAssociation: API.OperationMethod<DeleteAccountAssociationRequest & RegionInput, DeleteAccountAssociationResponse, DeleteAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a cloud connector.
 */
export declare const deleteCloudConnector: API.OperationMethod<DeleteCloudConnectorRequest & RegionInput, DeleteCloudConnectorResponse, DeleteCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a connector destination linked to a cloud-to-cloud (C2C) connector.
 *
 * Deletion can't be done if the account association has used this connector destination.
 */
export declare const deleteConnectorDestination: API.OperationMethod<DeleteConnectorDestinationRequest & RegionInput, DeleteConnectorDestinationResponse, DeleteConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a credential locker.
 *
 * This operation can't be undone and any existing device won't be able to use IoT managed integrations.
 */
export declare const deleteCredentialLocker: API.OperationMethod<DeleteCredentialLockerRequest & RegionInput, DeleteCredentialLockerResponse, DeleteCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type DeleteDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification destination specified by name.
 */
export declare const deleteDestination: API.OperationMethod<DeleteDestinationRequest & RegionInput, DeleteDestinationResponse, DeleteDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an event log configuration.
 */
export declare const deleteEventLogConfiguration: API.OperationMethod<DeleteEventLogConfigurationRequest & RegionInput, DeleteEventLogConfigurationResponse, DeleteEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a managed thing. For direct-connected and hub-connected devices connecting with Managed integrations via a controller, all of the devices connected to it will have their status changed to `PENDING`. It is not possible to remove a cloud-to-cloud device.
 */
export declare const deleteManagedThing: API.OperationMethod<DeleteManagedThingRequest & RegionInput, DeleteManagedThingResponse, DeleteManagedThingError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a notification configuration.
 */
export declare const deleteNotificationConfiguration: API.OperationMethod<DeleteNotificationConfigurationRequest & RegionInput, DeleteNotificationConfigurationResponse, DeleteNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task.
 */
export declare const deleteOtaTask: API.OperationMethod<DeleteOtaTaskRequest & RegionInput, DeleteOtaTaskResponse, DeleteOtaTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the over-the-air (OTA) task configuration.
 */
export declare const deleteOtaTaskConfiguration: API.OperationMethod<DeleteOtaTaskConfigurationRequest & RegionInput, DeleteOtaTaskConfigurationResponse, DeleteOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisioningProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Delete a provisioning profile.
 */
export declare const deleteProvisioningProfile: API.OperationMethod<DeleteProvisioningProfileRequest & RegionInput, DeleteProvisioningProfileResponse, DeleteProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type DeregisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregister an account association from a managed thing.
 */
export declare const deregisterAccountAssociation: API.OperationMethod<DeregisterAccountAssociationRequest & RegionInput, DeregisterAccountAssociationResponse, DeregisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetAccountAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an account association for an Amazon Web Services account linked to a customer-managed destination.
 */
export declare const getAccountAssociation: API.OperationMethod<GetAccountAssociationRequest & RegionInput, GetAccountAssociationResponse, GetAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get configuration details for a cloud connector.
 */
export declare const getCloudConnector: API.OperationMethod<GetCloudConnectorRequest & RegionInput, GetCloudConnectorResponse, GetCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get connector destination details linked to a cloud-to-cloud (C2C) connector.
 */
export declare const getConnectorDestination: API.OperationMethod<GetConnectorDestinationRequest & RegionInput, GetConnectorDestinationResponse, GetConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type GetCredentialLockerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information on an existing credential locker
 */
export declare const getCredentialLocker: API.OperationMethod<GetCredentialLockerRequest & RegionInput, GetCredentialLockerResponse, GetCredentialLockerError, Credentials | HttpClient.HttpClient>;
export type GetCustomEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the IoT managed integrations custom endpoint.
 */
export declare const getCustomEndpoint: API.OperationMethod<GetCustomEndpointRequest & RegionInput, GetCustomEndpointResponse, GetCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type GetDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves information about the default encryption configuration for the Amazon Web Services account in the default or specified region. For more information, see Key management in the *AWS IoT SiteWise User Guide*.
 */
export declare const getDefaultEncryptionConfiguration: API.OperationMethod<GetDefaultEncryptionConfigurationRequest & RegionInput, GetDefaultEncryptionConfigurationResponse, GetDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a destination by name.
 */
export declare const getDestination: API.OperationMethod<GetDestinationRequest & RegionInput, GetDestinationResponse, GetDestinationError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDiscoveryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the current state of a device discovery.
 */
export declare const getDeviceDiscovery: API.OperationMethod<GetDeviceDiscoveryRequest & RegionInput, GetDeviceDiscoveryResponse, GetDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type GetEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an event log configuration.
 */
export declare const getEventLogConfiguration: API.OperationMethod<GetEventLogConfigurationRequest & RegionInput, GetEventLogConfigurationResponse, GetEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a hub configuration.
 */
export declare const getHubConfiguration: API.OperationMethod<GetHubConfigurationRequest & RegionInput, GetHubConfigurationResponse, GetHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a managed thing including its attributes and capabilities.
 */
export declare const getManagedThing: API.OperationMethod<GetManagedThingRequest & RegionInput, GetManagedThingResponse, GetManagedThingError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCapabilitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the capabilities for a managed thing using the device ID.
 */
export declare const getManagedThingCapabilities: API.OperationMethod<GetManagedThingCapabilitiesRequest & RegionInput, GetManagedThingCapabilitiesResponse, GetManagedThingCapabilitiesError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingCertificateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the certificate PEM for a managed IoT thing.
 */
export declare const getManagedThingCertificate: API.OperationMethod<GetManagedThingCertificateRequest & RegionInput, GetManagedThingCertificateResponse, GetManagedThingCertificateError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingConnectivityDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the connectivity status of a managed thing.
 */
export declare const getManagedThingConnectivityData: API.OperationMethod<GetManagedThingConnectivityDataRequest & RegionInput, GetManagedThingConnectivityDataResponse, GetManagedThingConnectivityDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingMetaDataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get the metadata information for a managed thing.
 *
 * The `managedThing` `metadata` parameter is used for associating attributes with a `managedThing` that can be used for grouping over-the-air (OTA) tasks. Name value pairs in `metadata` can be used in the `OtaTargetQueryString` parameter for the `CreateOtaTask` API operation.
 */
export declare const getManagedThingMetaData: API.OperationMethod<GetManagedThingMetaDataRequest & RegionInput, GetManagedThingMetaDataResponse, GetManagedThingMetaDataError, Credentials | HttpClient.HttpClient>;
export type GetManagedThingStateError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the managed thing state for the given device Id.
 */
export declare const getManagedThingState: API.OperationMethod<GetManagedThingStateRequest & RegionInput, GetManagedThingStateResponse, GetManagedThingStateError, Credentials | HttpClient.HttpClient>;
export type GetNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a notification configuration for a specified event type.
 */
export declare const getNotificationConfiguration: API.OperationMethod<GetNotificationConfigurationRequest & RegionInput, GetNotificationConfigurationResponse, GetNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details of the over-the-air (OTA) task by its task id.
 */
export declare const getOtaTask: API.OperationMethod<GetOtaTaskRequest & RegionInput, GetOtaTaskResponse, GetOtaTaskError, Credentials | HttpClient.HttpClient>;
export type GetOtaTaskConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a configuraiton for the over-the-air (OTA) task.
 */
export declare const getOtaTaskConfiguration: API.OperationMethod<GetOtaTaskConfigurationRequest & RegionInput, GetOtaTaskConfigurationResponse, GetOtaTaskConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetProvisioningProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Get details of a provisioning profile.
 */
export declare const getProvisioningProfile: API.OperationMethod<GetProvisioningProfileRequest & RegionInput, GetProvisioningProfileResponse, GetProvisioningProfileError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the runtime log configuration for a specific managed thing.
 */
export declare const getRuntimeLogConfiguration: API.OperationMethod<GetRuntimeLogConfigurationRequest & RegionInput, GetRuntimeLogConfigurationResponse, GetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a schema version with the provided information.
 */
export declare const getSchemaVersion: API.OperationMethod<GetSchemaVersionRequest & RegionInput, GetSchemaVersionResponse, GetSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type ListAccountAssociationsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations, with optional filtering by connector destination ID.
 */
export declare const listAccountAssociations: API.PaginatedOperationMethod<ListAccountAssociationsRequest & RegionInput, ListAccountAssociationsResponse, ListAccountAssociationsError, Credentials | HttpClient.HttpClient, AccountAssociationItem>;
export type ListCloudConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of connectors filtered by its Lambda Amazon Resource Name (ARN) and `type`.
 */
export declare const listCloudConnectors: API.PaginatedOperationMethod<ListCloudConnectorsRequest & RegionInput, ListCloudConnectorsResponse, ListCloudConnectorsError, Credentials | HttpClient.HttpClient, ConnectorItem>;
export type ListConnectorDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all connector destinations, with optional filtering by cloud connector ID.
 */
export declare const listConnectorDestinations: API.PaginatedOperationMethod<ListConnectorDestinationsRequest & RegionInput, ListConnectorDestinationsResponse, ListConnectorDestinationsError, Credentials | HttpClient.HttpClient, ConnectorDestinationSummary>;
export type ListCredentialLockersError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List information on an existing credential locker.
 */
export declare const listCredentialLockers: API.PaginatedOperationMethod<ListCredentialLockersRequest & RegionInput, ListCredentialLockersResponse, ListCredentialLockersError, Credentials | HttpClient.HttpClient, CredentialLockerSummary>;
export type ListDestinationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification destinations.
 */
export declare const listDestinations: API.PaginatedOperationMethod<ListDestinationsRequest & RegionInput, ListDestinationsResponse, ListDestinationsError, Credentials | HttpClient.HttpClient, DestinationSummary>;
export type ListDeviceDiscoveriesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all device discovery tasks, with optional filtering by type and status.
 */
export declare const listDeviceDiscoveries: API.PaginatedOperationMethod<ListDeviceDiscoveriesRequest & RegionInput, ListDeviceDiscoveriesResponse, ListDeviceDiscoveriesError, Credentials | HttpClient.HttpClient, DeviceDiscoverySummary>;
export type ListDiscoveredDevicesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all devices discovered during a specific device discovery task.
 */
export declare const listDiscoveredDevices: API.PaginatedOperationMethod<ListDiscoveredDevicesRequest & RegionInput, ListDiscoveredDevicesResponse, ListDiscoveredDevicesError, Credentials | HttpClient.HttpClient, DiscoveredDeviceSummary>;
export type ListEventLogConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all event log configurations for an account.
 */
export declare const listEventLogConfigurations: API.PaginatedOperationMethod<ListEventLogConfigurationsRequest & RegionInput, ListEventLogConfigurationsResponse, ListEventLogConfigurationsError, Credentials | HttpClient.HttpClient, EventLogConfigurationSummary>;
export type ListManagedThingAccountAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all account associations for a specific managed thing.
 */
export declare const listManagedThingAccountAssociations: API.PaginatedOperationMethod<ListManagedThingAccountAssociationsRequest & RegionInput, ListManagedThingAccountAssociationsResponse, ListManagedThingAccountAssociationsError, Credentials | HttpClient.HttpClient, ManagedThingAssociation>;
export type ListManagedThingsError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Listing all managed things with provision for filters.
 */
export declare const listManagedThings: API.PaginatedOperationMethod<ListManagedThingsRequest & RegionInput, ListManagedThingsResponse, ListManagedThingsError, Credentials | HttpClient.HttpClient, ManagedThingSummary>;
export type ListManagedThingSchemasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List schemas associated with a managed thing.
 */
export declare const listManagedThingSchemas: API.PaginatedOperationMethod<ListManagedThingSchemasRequest & RegionInput, ListManagedThingSchemasResponse, ListManagedThingSchemasError, Credentials | HttpClient.HttpClient, ManagedThingSchemaListItem>;
export type ListNotificationConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all notification configurations.
 */
export declare const listNotificationConfigurations: API.PaginatedOperationMethod<ListNotificationConfigurationsRequest & RegionInput, ListNotificationConfigurationsResponse, ListNotificationConfigurationsError, Credentials | HttpClient.HttpClient, NotificationConfigurationSummary>;
export type ListOtaTaskConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task configurations.
 */
export declare const listOtaTaskConfigurations: API.PaginatedOperationMethod<ListOtaTaskConfigurationsRequest & RegionInput, ListOtaTaskConfigurationsResponse, ListOtaTaskConfigurationsError, Credentials | HttpClient.HttpClient, OtaTaskConfigurationSummary>;
export type ListOtaTaskExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) task executions.
 */
export declare const listOtaTaskExecutions: API.PaginatedOperationMethod<ListOtaTaskExecutionsRequest & RegionInput, ListOtaTaskExecutionsResponse, ListOtaTaskExecutionsError, Credentials | HttpClient.HttpClient, OtaTaskExecutionSummaries>;
export type ListOtaTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all of the over-the-air (OTA) tasks.
 */
export declare const listOtaTasks: API.PaginatedOperationMethod<ListOtaTasksRequest & RegionInput, ListOtaTasksResponse, ListOtaTasksError, Credentials | HttpClient.HttpClient, OtaTaskSummary>;
export type ListProvisioningProfilesError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * List the provisioning profiles within the Amazon Web Services account.
 */
export declare const listProvisioningProfiles: API.PaginatedOperationMethod<ListProvisioningProfilesRequest & RegionInput, ListProvisioningProfilesResponse, ListProvisioningProfilesError, Credentials | HttpClient.HttpClient, ProvisioningProfileSummary>;
export type ListSchemaVersionsError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists schema versions with the provided information.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsRequest & RegionInput, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionListItem>;
export type ListTagsForResourceError = InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutDefaultEncryptionConfigurationError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Sets the default encryption configuration for the Amazon Web Services account. For more information, see Key management in the AWS IoT SiteWise User Guide.
 */
export declare const putDefaultEncryptionConfiguration: API.OperationMethod<PutDefaultEncryptionConfigurationRequest & RegionInput, PutDefaultEncryptionConfigurationResponse, PutDefaultEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutHubConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a hub configuration.
 */
export declare const putHubConfiguration: API.OperationMethod<PutHubConfigurationRequest & RegionInput, PutHubConfigurationResponse, PutHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the runtime log configuration for a specific managed thing.
 */
export declare const putRuntimeLogConfiguration: API.OperationMethod<PutRuntimeLogConfigurationRequest & RegionInput, PutRuntimeLogConfigurationResponse, PutRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type RegisterAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an account association with a managed thing, establishing a connection between a device and a third-party account.
 */
export declare const registerAccountAssociation: API.OperationMethod<RegisterAccountAssociationRequest & RegionInput, RegisterAccountAssociationResponse, RegisterAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type RegisterCustomEndpointError = AccessDeniedException | ConflictException | InternalServerException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Customers can request IoT managed integrations to manage the server trust for them or bring their own external server trusts for the custom domain. Returns an IoT managed integrations endpoint.
 */
export declare const registerCustomEndpoint: API.OperationMethod<RegisterCustomEndpointRequest & RegionInput, RegisterCustomEndpointResponse, RegisterCustomEndpointError, Credentials | HttpClient.HttpClient>;
export type ResetRuntimeLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reset a runtime log configuration for a specific managed thing.
 */
export declare const resetRuntimeLogConfiguration: API.OperationMethod<ResetRuntimeLogConfigurationRequest & RegionInput, ResetRuntimeLogConfigurationResponse, ResetRuntimeLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type SendConnectorEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Relays third-party device events for a connector such as a new device or a device state change event.
 */
export declare const sendConnectorEvent: API.OperationMethod<SendConnectorEventRequest & RegionInput, SendConnectorEventResponse, SendConnectorEventError, Credentials | HttpClient.HttpClient>;
export type SendManagedThingCommandError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Send the command to the device represented by the managed thing.
 */
export declare const sendManagedThingCommand: API.OperationMethod<SendManagedThingCommandRequest & RegionInput, SendManagedThingCommandResponse, SendManagedThingCommandError, Credentials | HttpClient.HttpClient>;
export type StartAccountAssociationRefreshError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a refresh of an existing account association to update its authorization and connection status.
 */
export declare const startAccountAssociationRefresh: API.OperationMethod<StartAccountAssociationRefreshRequest & RegionInput, StartAccountAssociationRefreshResponse, StartAccountAssociationRefreshError, Credentials | HttpClient.HttpClient>;
export type StartDeviceDiscoveryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * This API is used to start device discovery for hub-connected and third-party-connected devices. The authentication material (install code) is delivered as a message to the controller instructing it to start the discovery.
 */
export declare const startDeviceDiscovery: API.OperationMethod<StartDeviceDiscoveryRequest & RegionInput, StartDeviceDiscoveryResponse, StartDeviceDiscoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing account association.
 */
export declare const updateAccountAssociation: API.OperationMethod<UpdateAccountAssociationRequest & RegionInput, UpdateAccountAssociationResponse, UpdateAccountAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudConnectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update an existing cloud connector.
 */
export declare const updateCloudConnector: API.OperationMethod<UpdateCloudConnectorRequest & RegionInput, UpdateCloudConnectorResponse, UpdateCloudConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing connector destination.
 */
export declare const updateConnectorDestination: API.OperationMethod<UpdateConnectorDestinationRequest & RegionInput, UpdateConnectorDestinationResponse, UpdateConnectorDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a destination specified by name.
 */
export declare const updateDestination: API.OperationMethod<UpdateDestinationRequest & RegionInput, UpdateDestinationResponse, UpdateDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventLogConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an event log configuration by log configuration ID.
 */
export declare const updateEventLogConfiguration: API.OperationMethod<UpdateEventLogConfigurationRequest & RegionInput, UpdateEventLogConfigurationResponse, UpdateEventLogConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedThingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Update the attributes and capabilities associated with a managed thing.
 */
export declare const updateManagedThing: API.OperationMethod<UpdateManagedThingRequest & RegionInput, UpdateManagedThingResponse, UpdateManagedThingError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a notification configuration.
 */
export declare const updateNotificationConfiguration: API.OperationMethod<UpdateNotificationConfigurationRequest & RegionInput, UpdateNotificationConfigurationResponse, UpdateNotificationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateOtaTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an over-the-air (OTA) task.
 */
export declare const updateOtaTask: API.OperationMethod<UpdateOtaTaskRequest & RegionInput, UpdateOtaTaskResponse, UpdateOtaTaskError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-managed-integrations.d.ts.map