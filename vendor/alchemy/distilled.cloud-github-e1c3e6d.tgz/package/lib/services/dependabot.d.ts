import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AddSelectedRepoToOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgSecretResponse {
}
/** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
export type CreateOrUpdateOrgSecretRequestVisibility = "all" | "private" | "selected";
export type CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsItem = number | string;
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList = Array<CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsItem>;
export interface CreateOrUpdateOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/dependabot/secrets#get-an-organization-public-key) endpoint. */
    encrypted_value?: string | undefined;
    /** ID of the key you used to encrypt the secret. */
    key_id?: string | undefined;
    /** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
    visibility: CreateOrUpdateOrgSecretRequestVisibility | (string & {});
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids?: CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrUpdateOrgSecretResponse = unknown;
export interface CreateOrUpdateRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/dependabot/secrets#get-a-repository-public-key) endpoint. */
    encrypted_value?: string | undefined;
    /** ID of the key you used to encrypt the secret. */
    key_id?: string | undefined;
}
export type CreateOrUpdateRepoSecretResponse = unknown;
export interface DeleteOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteOrgSecretResponse {
}
export interface DeleteRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteRepoSecretResponse {
}
export interface GetAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies a Dependabot alert in its repository. You can find this at the end of the URL for a Dependabot alert within GitHub, or in `number` fields in the response from the `GET /repos/{owner}/{repo}/dependabot/alerts` operation. */
    alert_number: number;
}
/** The state of the Dependabot alert. */
export type DependabotAlertState = "auto_dismissed" | "dismissed" | "fixed" | "open";
/** Details for the vulnerable package. */
export interface DependabotAlertPackage {
    /** The package's language or package management ecosystem. */
    ecosystem: string;
    /** The unique package name within its ecosystem. */
    name: string;
}
/** The execution scope of the vulnerable dependency. */
export type DependabotAlertDependencyScope = "development" | "runtime";
/** The vulnerable dependency's relationship to your project. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
export type DependabotAlertDependencyRelationship = "unknown" | "direct" | "transitive" | "inconclusive";
/** Details for the vulnerable dependency. */
export interface DependabotAlertDependency {
    package?: DependabotAlertPackage | undefined;
    /** The full path to the dependency manifest file, relative to the root of the repository. */
    manifest_path?: string | undefined;
    /** The dependency version or version constraint last recorded for the dependency associated with this alert. For dependencies detected from a lockfile, this can be the resolved version. For manifest-only dependencies, it can be the declared version constraint. Returns `null` when unavailable. An empty string can indicate an unconstrained dependency. The stored value is limited to 64 bytes; longer requirements may have been truncated and may no longer form a complete, valid version constraint. When multiple vulnerable versions of a dependency correspond to the same alert, this field contains one recorded version or constraint and may not represent all vulnerable versions. */
    version_requirement?: string | null | undefined;
    /** The execution scope of the vulnerable dependency. */
    scope?: DependabotAlertDependencyScope | null | undefined;
    /** The vulnerable dependency's relationship to your project. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
    relationship?: DependabotAlertDependencyRelationship | null | undefined;
}
/** The severity of the vulnerability. */
export type DependabotAlertSecurityVulnerabilitySeverity = "low" | "medium" | "high" | "critical";
/** Details pertaining to the package version that patches this vulnerability. */
export interface DependabotAlertSecurityVulnerabilityFirstPatchedVersion {
    /** The package version that patches this vulnerability. */
    identifier: string;
}
/** Details pertaining to one vulnerable version range for the advisory. */
export interface DependabotAlertSecurityVulnerability {
    package: DependabotAlertPackage;
    /** The severity of the vulnerability. */
    severity: DependabotAlertSecurityVulnerabilitySeverity;
    /** Conditions that identify vulnerable versions of this vulnerability's package. */
    vulnerable_version_range: string;
    /** Details pertaining to the package version that patches this vulnerability. */
    first_patched_version: DependabotAlertSecurityVulnerabilityFirstPatchedVersion | null;
}
/** Vulnerable version range information for the advisory. */
export type DependabotAlertSecurityAdvisoryVulnerabilitiesList = Array<DependabotAlertSecurityVulnerability>;
/** The severity of the advisory. */
export type DependabotAlertSecurityAdvisorySeverity = "low" | "medium" | "high" | "critical";
/** The classification of the advisory. */
export type DependabotAlertSecurityAdvisoryClassification = "general" | "malware";
/** Details for the advisory pertaining to the Common Vulnerability Scoring System. */
export interface DependabotAlertSecurityAdvisoryCvss {
    /** The overall CVSS score of the advisory. */
    score: number;
    /** The full CVSS vector string for the advisory. */
    vector_string: string | null;
}
export interface CvssSeveritiesCvssV3 {
    /** The CVSS 3 vector string. */
    vector_string: string | null;
    /** The CVSS 3 score. */
    score: number | null;
}
export interface CvssSeveritiesCvssV4 {
    /** The CVSS 4 vector string. */
    vector_string: string | null;
    /** The CVSS 4 score. */
    score: number | null;
}
export interface CvssSeverities {
    cvss_v3?: CvssSeveritiesCvssV3 | null | undefined;
    cvss_v4?: CvssSeveritiesCvssV4 | null | undefined;
}
/** The EPSS scores as calculated by the [Exploit Prediction Scoring System](https://www.first.org/epss). */
export interface SecurityAdvisoryEpss {
    percentage?: number | undefined;
    percentile?: number | undefined;
}
/** A CWE weakness assigned to the advisory. */
export interface DependabotAlertSecurityAdvisoryCwesItem {
    /** The unique CWE ID. */
    cwe_id: string;
    /** The short, plain text name of the CWE. */
    name: string;
}
/** Details for the advisory pertaining to Common Weakness Enumeration. */
export type DependabotAlertSecurityAdvisoryCwesList = Array<DependabotAlertSecurityAdvisoryCwesItem>;
/** The type of advisory identifier. */
export type DependabotAlertSecurityAdvisoryIdentifiersItemType = "CVE" | "GHSA";
/** An advisory identifier. */
export interface DependabotAlertSecurityAdvisoryIdentifiersItem {
    /** The type of advisory identifier. */
    type: DependabotAlertSecurityAdvisoryIdentifiersItemType;
    /** The value of the advisory identifer. */
    value: string;
}
/** Values that identify this advisory among security information sources. */
export type DependabotAlertSecurityAdvisoryIdentifiersList = Array<DependabotAlertSecurityAdvisoryIdentifiersItem>;
/** A link to additional advisory information. */
export interface DependabotAlertSecurityAdvisoryReferencesItem {
    /** The URL of the reference. */
    url: string;
}
/** Links to additional advisory information. */
export type DependabotAlertSecurityAdvisoryReferencesList = Array<DependabotAlertSecurityAdvisoryReferencesItem>;
/** Details for the GitHub Security Advisory. */
export interface DependabotAlertSecurityAdvisory {
    /** The unique GitHub Security Advisory ID assigned to the advisory. */
    ghsa_id: string;
    /** The unique CVE ID assigned to the advisory. */
    cve_id: string | null;
    /** A short, plain text summary of the advisory. */
    summary: string;
    /** A long-form Markdown-supported description of the advisory. */
    description: string;
    /** Vulnerable version range information for the advisory. */
    vulnerabilities: DependabotAlertSecurityAdvisoryVulnerabilitiesList;
    /** The severity of the advisory. */
    severity: DependabotAlertSecurityAdvisorySeverity;
    /** The classification of the advisory. */
    classification?: DependabotAlertSecurityAdvisoryClassification | undefined;
    /** Details for the advisory pertaining to the Common Vulnerability Scoring System. */
    cvss: DependabotAlertSecurityAdvisoryCvss;
    cvss_severities?: CvssSeverities | null | undefined;
    epss?: SecurityAdvisoryEpss | null | undefined;
    /** Details for the advisory pertaining to Common Weakness Enumeration. */
    cwes: DependabotAlertSecurityAdvisoryCwesList;
    /** Values that identify this advisory among security information sources. */
    identifiers: DependabotAlertSecurityAdvisoryIdentifiersList;
    /** Links to additional advisory information. */
    references: DependabotAlertSecurityAdvisoryReferencesList;
    /** The time that the advisory was published in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    published_at: string;
    /** The time that the advisory was last modified in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    updated_at: string;
    /** The time that the advisory was withdrawn in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    withdrawn_at: string | null;
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The reason that the alert was dismissed. */
export type DependabotAlertDismissedReason = "fix_started" | "inaccurate" | "no_bandwidth" | "not_used" | "tolerable_risk";
/** The current status of the dismissal request. */
export type DependabotAlertDismissalRequestSimpleStatus = "pending" | "approved" | "rejected" | "cancelled";
/** The user who requested the dismissal. */
export interface DependabotAlertDismissalRequestSimpleRequester {
    /** The unique identifier of the user. */
    id?: number | undefined;
    /** The login name of the user. */
    login?: string | undefined;
}
/** Information about an active dismissal request for this Dependabot alert. */
export interface DependabotAlertDismissalRequestSimple {
    /** The unique identifier of the dismissal request. */
    id?: number | undefined;
    /** The current status of the dismissal request. */
    status?: DependabotAlertDismissalRequestSimpleStatus | undefined;
    /** The user who requested the dismissal. */
    requester?: DependabotAlertDismissalRequestSimpleRequester | undefined;
    /** The date and time when the dismissal request was created. */
    created_at?: string | undefined;
    /** The API URL to get more information about this dismissal request. */
    url?: string | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
/** The users assigned to this alert. */
export type DependabotAlertAssigneesList = Array<NullableSimpleUser>;
/** The reachability verdict for the alert. - `reachable`: a path from the repository's code reaches a vulnerable function. - `unreachable`: no path from the repository's code reaches a vulnerable function. - `potentially_reachable`: reachability could not be determined with confidence; review manually. - `unavailable`: no verdict has been computed for the alert yet. - `disabled`: reachability analysis is not enabled for the repository. */
export type DependabotAlertReachabilityVerdict = "reachable" | "unreachable" | "potentially_reachable" | "unavailable" | "disabled";
/** The reason for the reachability verdict. This field is omitted when reachability analysis is disabled or no result has been computed. */
export type DependabotAlertReachabilityReason = "unknown" | "unavailable_unsupported_ecosystem" | "unavailable_analysis_timed_out" | "potentially_reachable_invalid_manifest_path" | "potentially_reachable_missing_vulnerable_function_annotation" | "potentially_reachable_dependency_not_found" | "potentially_reachable_dependency_analysis_incomplete" | "potentially_reachable_repository_analysis_incomplete" | "potentially_reachable_call_found_outside_manifest_scope" | "potentially_reachable_unclassified_analysis_state" | "reachable_vulnerable_function_called" | "unreachable_vulnerable_function_not_called" | "potentially_reachable_unresolved_dynamic_call";
/** The reachability result for the vulnerability that triggered the alert, indicating whether a vulnerable function is reachable from the repository's own code. */
export interface DependabotAlertReachability {
    /** The reachability verdict for the alert. - `reachable`: a path from the repository's code reaches a vulnerable function. - `unreachable`: no path from the repository's code reaches a vulnerable function. - `potentially_reachable`: reachability could not be determined with confidence; review manually. - `unavailable`: no verdict has been computed for the alert yet. - `disabled`: reachability analysis is not enabled for the repository. */
    verdict: DependabotAlertReachabilityVerdict;
    /** The reason for the reachability verdict. This field is omitted when reachability analysis is disabled or no result has been computed. */
    reason?: DependabotAlertReachabilityReason | undefined;
}
/** A Dependabot alert. */
export interface DependabotAlert {
    number: number;
    /** The state of the Dependabot alert. */
    state: DependabotAlertState;
    /** Details for the vulnerable dependency. */
    dependency: DependabotAlertDependency;
    security_advisory: DependabotAlertSecurityAdvisory;
    security_vulnerability: DependabotAlertSecurityVulnerability;
    url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    dismissed_at: string | null;
    dismissed_by: NullableSimpleUser | null;
    /** The reason that the alert was dismissed. */
    dismissed_reason: DependabotAlertDismissedReason | null;
    /** An optional comment associated with the alert's dismissal. */
    dismissed_comment: string | null;
    fixed_at: string | null;
    auto_dismissed_at?: string | null | undefined;
    dismissal_request?: DependabotAlertDismissalRequestSimple | null | undefined;
    /** The users assigned to this alert. */
    assignees?: DependabotAlertAssigneesList | undefined;
    /** The reachability result for the vulnerability that triggered the alert, indicating whether a vulnerable function is reachable from the repository's own code. */
    reachability?: DependabotAlertReachability | undefined;
}
export interface GetOrgPublicKeyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The public key used for setting Dependabot Secrets. */
export interface DependabotPublicKey {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
}
export interface GetOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Visibility of a secret */
export type OrganizationDependabotSecretVisibility = "all" | "private" | "selected";
/** Secrets for GitHub Dependabot for an organization. */
export interface OrganizationDependabotSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
    /** Visibility of a secret */
    visibility: OrganizationDependabotSecretVisibility;
    selected_repositories_url?: string | undefined;
}
export interface GetRepoPublicKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Set secrets for Dependabot. */
export interface DependabotSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
}
export interface GetRepositoryRunnerSettingsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** `labeled` when Dependabot runs on labeled runners. Otherwise `standard`. */
export type DependabotRunnerSettingsRunnerType = "standard" | "labeled";
/** Runner labels Dependabot uses. Empty for `standard`. */
export type DependabotRunnerSettingsRunnerLabelsList = Array<string>;
/** The runner Dependabot uses for this repository, as shown in the repository settings. */
export interface DependabotRunnerSettings {
    /** `labeled` when Dependabot runs on labeled runners. Otherwise `standard`. */
    runner_type: DependabotRunnerSettingsRunnerType;
    /** Runner labels Dependabot uses. Empty for `standard`. */
    runner_labels: DependabotRunnerSettingsRunnerLabelsList;
    /** Runner group Dependabot uses, or `null` for no group. */
    runner_group: string | null;
}
export type ListAlertsForEnterpriseRequestHasCase1Item = "patch";
export type ListAlertsForEnterpriseRequestHasCase1List = Array<ListAlertsForEnterpriseRequestHasCase1Item | (string & {})>;
export type ListAlertsForEnterpriseRequestHas = string | ListAlertsForEnterpriseRequestHasCase1List;
export type ListAlertsForEnterpriseRequestScope = "development" | "runtime";
export type ListAlertsForEnterpriseRequestSort = "created" | "updated" | "epss_percentage";
export type ListAlertsForEnterpriseRequestDirection = "asc" | "desc";
export interface ListAlertsForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** A comma-separated list of vulnerability classifications. If specified, only alerts for vulnerabilities with these classifications will be returned. Can be: `malware`, `general` */
    classification?: string | undefined;
    /** A comma-separated list of states. If specified, only alerts with these states will be returned. Can be: `auto_dismissed`, `dismissed`, `fixed`, `open` */
    state?: string | undefined;
    /** A comma-separated list of severities. If specified, only alerts with these severities will be returned. Can be: `low`, `medium`, `high`, `critical` */
    severity?: string | undefined;
    /** A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned. Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust` */
    ecosystem?: string | undefined;
    /** A comma-separated list of package names. If specified, only alerts for these packages will be returned. */
    package?: string | undefined;
    /** CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as: - An exact number (`n`) - Comparators such as `>n`, `<n`, `>=n`, `<=n` - A range like `n..n`, where `n` is a number from 0.0 to 1.0 Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned. */
    epss_percentage?: string | undefined;
    /** Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned. Multiple `has` filters can be passed to filter for alerts that have all of the values. Currently, only `patch` is supported. */
    has?: ListAlertsForEnterpriseRequestHas | undefined;
    /** Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users. Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees. */
    assignee?: string | undefined;
    /** The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. */
    scope?: ListAlertsForEnterpriseRequestScope | (string & {}) | undefined;
    /** A comma-separated list of relationships of the vulnerable dependency to your project. If specified, only alerts with these relationships will be returned. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
    relationship?: string | undefined;
    /** The property by which to sort the results. `created` means when the alert was created. `updated` means when the alert's state last changed. `epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. */
    sort?: ListAlertsForEnterpriseRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForEnterpriseRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
/** The state of the Dependabot alert. */
export type DependabotAlertWithRepositoryState = "auto_dismissed" | "dismissed" | "fixed" | "open";
/** The execution scope of the vulnerable dependency. */
export type DependabotAlertWithRepositoryDependencyScope = "development" | "runtime";
/** The vulnerable dependency's relationship to your project. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
export type DependabotAlertWithRepositoryDependencyRelationship = "unknown" | "direct" | "transitive" | "inconclusive";
/** Details for the vulnerable dependency. */
export interface DependabotAlertWithRepositoryDependency {
    package?: DependabotAlertPackage | undefined;
    /** The full path to the dependency manifest file, relative to the root of the repository. */
    manifest_path?: string | undefined;
    /** The dependency version or version constraint last recorded for the dependency associated with this alert. For dependencies detected from a lockfile, this can be the resolved version. For manifest-only dependencies, it can be the declared version constraint. Returns `null` when unavailable. An empty string can indicate an unconstrained dependency. The stored value is limited to 64 bytes; longer requirements may have been truncated and may no longer form a complete, valid version constraint. When multiple vulnerable versions of a dependency correspond to the same alert, this field contains one recorded version or constraint and may not represent all vulnerable versions. */
    version_requirement?: string | null | undefined;
    /** The execution scope of the vulnerable dependency. */
    scope?: DependabotAlertWithRepositoryDependencyScope | null | undefined;
    /** The vulnerable dependency's relationship to your project. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
    relationship?: DependabotAlertWithRepositoryDependencyRelationship | null | undefined;
}
/** The reason that the alert was dismissed. */
export type DependabotAlertWithRepositoryDismissedReason = "fix_started" | "inaccurate" | "no_bandwidth" | "not_used" | "tolerable_risk";
/** The users assigned to this alert. */
export type DependabotAlertWithRepositoryAssigneesList = Array<NullableSimpleUser>;
/** The reachability verdict for the alert. - `reachable`: a path from the repository's code reaches a vulnerable function. - `unreachable`: no path from the repository's code reaches a vulnerable function. - `potentially_reachable`: reachability could not be determined with confidence; review manually. - `unavailable`: no verdict has been computed for the alert yet. - `disabled`: reachability analysis is not enabled for the repository. */
export type DependabotAlertWithRepositoryReachabilityVerdict = "reachable" | "unreachable" | "potentially_reachable" | "unavailable" | "disabled";
/** The reason for the reachability verdict. This field is omitted when reachability analysis is disabled or no result has been computed. */
export type DependabotAlertWithRepositoryReachabilityReason = "unknown" | "unavailable_unsupported_ecosystem" | "unavailable_analysis_timed_out" | "potentially_reachable_invalid_manifest_path" | "potentially_reachable_missing_vulnerable_function_annotation" | "potentially_reachable_dependency_not_found" | "potentially_reachable_dependency_analysis_incomplete" | "potentially_reachable_repository_analysis_incomplete" | "potentially_reachable_call_found_outside_manifest_scope" | "potentially_reachable_unclassified_analysis_state" | "reachable_vulnerable_function_called" | "unreachable_vulnerable_function_not_called" | "potentially_reachable_unresolved_dynamic_call";
/** The reachability result for the vulnerability that triggered the alert, indicating whether a vulnerable function is reachable from the repository's own code. */
export interface DependabotAlertWithRepositoryReachability {
    /** The reachability verdict for the alert. - `reachable`: a path from the repository's code reaches a vulnerable function. - `unreachable`: no path from the repository's code reaches a vulnerable function. - `potentially_reachable`: reachability could not be determined with confidence; review manually. - `unavailable`: no verdict has been computed for the alert yet. - `disabled`: reachability analysis is not enabled for the repository. */
    verdict: DependabotAlertWithRepositoryReachabilityVerdict;
    /** The reason for the reachability verdict. This field is omitted when reachability analysis is disabled or no result has been computed. */
    reason?: DependabotAlertWithRepositoryReachabilityReason | undefined;
}
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: NullableSimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
/** A Dependabot alert. */
export interface DependabotAlertWithRepository {
    number: number;
    /** The state of the Dependabot alert. */
    state: DependabotAlertWithRepositoryState;
    /** Details for the vulnerable dependency. */
    dependency: DependabotAlertWithRepositoryDependency;
    security_advisory: DependabotAlertSecurityAdvisory;
    security_vulnerability: DependabotAlertSecurityVulnerability;
    url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    dismissed_at: string | null;
    dismissed_by: NullableSimpleUser | null;
    /** The reason that the alert was dismissed. */
    dismissed_reason: DependabotAlertWithRepositoryDismissedReason | null;
    /** An optional comment associated with the alert's dismissal. */
    dismissed_comment: string | null;
    fixed_at: string | null;
    auto_dismissed_at?: string | null | undefined;
    dismissal_request?: DependabotAlertDismissalRequestSimple | null | undefined;
    /** The users assigned to this alert. */
    assignees?: DependabotAlertWithRepositoryAssigneesList | undefined;
    /** The reachability result for the vulnerability that triggered the alert, indicating whether a vulnerable function is reachable from the repository's own code. */
    reachability?: DependabotAlertWithRepositoryReachability | undefined;
    repository: SimpleRepository;
}
export type ListAlertsForEnterpriseResponseBodyList = Array<DependabotAlertWithRepository>;
export type ListAlertsForEnterpriseResponse = ListAlertsForEnterpriseResponseBodyList;
export type ListAlertsForOrgRequestHasCase1Item = "patch" | "deployment";
export type ListAlertsForOrgRequestHasCase1List = Array<ListAlertsForOrgRequestHasCase1Item | (string & {})>;
export type ListAlertsForOrgRequestHas = string | ListAlertsForOrgRequestHasCase1List;
export type ListAlertsForOrgRequestScope = "development" | "runtime";
export type ListAlertsForOrgRequestSort = "created" | "updated" | "epss_percentage";
export type ListAlertsForOrgRequestDirection = "asc" | "desc";
export interface ListAlertsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** A comma-separated list of vulnerability classifications. If specified, only alerts for vulnerabilities with these classifications will be returned. Can be: `malware`, `general` */
    classification?: string | undefined;
    /** A comma-separated list of states. If specified, only alerts with these states will be returned. Can be: `auto_dismissed`, `dismissed`, `fixed`, `open` */
    state?: string | undefined;
    /** A comma-separated list of severities. If specified, only alerts with these severities will be returned. Can be: `low`, `medium`, `high`, `critical` */
    severity?: string | undefined;
    /** A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned. Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust` */
    ecosystem?: string | undefined;
    /** A comma-separated list of package names. If specified, only alerts for these packages will be returned. */
    package?: string | undefined;
    /** CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as: - An exact number (`n`) - Comparators such as `>n`, `<n`, `>=n`, `<=n` - A range like `n..n`, where `n` is a number from 0.0 to 1.0 Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned. */
    epss_percentage?: string | undefined;
    /** A comma-separated list of artifact registry URLs. If specified, only alerts for repositories with storage records matching these URLs will be returned. */
    artifact_registry_url?: string | undefined;
    /** A comma-separated list of Artifact Registry name strings. If specified, only alerts for repositories with storage records matching these registries will be returned. Can be: `jfrog-artifactory` */
    artifact_registry?: string | undefined;
    /** Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned. Multiple `has` filters can be passed to filter for alerts that have all of the values. */
    has?: ListAlertsForOrgRequestHas | undefined;
    /** Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users. Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees. */
    assignee?: string | undefined;
    /** A comma-separated list of runtime risk strings. If specified, only alerts for repositories with deployment records matching these risks will be returned. Can be: `critical-resource`, `internet-exposed`, `sensitive-data`, `lateral-movement` */
    runtime_risk?: string | undefined;
    /** The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. */
    scope?: ListAlertsForOrgRequestScope | (string & {}) | undefined;
    /** A comma-separated list of relationships of the vulnerable dependency to your project. If specified, only alerts with these relationships will be returned. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
    relationship?: string | undefined;
    /** The property by which to sort the results. `created` means when the alert was created. `updated` means when the alert's state last changed. `epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. */
    sort?: ListAlertsForOrgRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForOrgRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListAlertsForOrgResponseBodyList = Array<DependabotAlertWithRepository>;
export type ListAlertsForOrgResponse = ListAlertsForOrgResponseBodyList;
export type ListAlertsForRepoRequestHasCase1Item = "patch";
export type ListAlertsForRepoRequestHasCase1List = Array<ListAlertsForRepoRequestHasCase1Item | (string & {})>;
export type ListAlertsForRepoRequestHas = string | ListAlertsForRepoRequestHasCase1List;
export type ListAlertsForRepoRequestScope = "development" | "runtime";
export type ListAlertsForRepoRequestSort = "created" | "updated" | "epss_percentage";
export type ListAlertsForRepoRequestDirection = "asc" | "desc";
export interface ListAlertsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A comma-separated list of vulnerability classifications. If specified, only alerts for vulnerabilities with these classifications will be returned. Can be: `malware`, `general` */
    classification?: string | undefined;
    /** A comma-separated list of states. If specified, only alerts with these states will be returned. Can be: `auto_dismissed`, `dismissed`, `fixed`, `open` */
    state?: string | undefined;
    /** A comma-separated list of severities. If specified, only alerts with these severities will be returned. Can be: `low`, `medium`, `high`, `critical` */
    severity?: string | undefined;
    /** A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned. Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust` */
    ecosystem?: string | undefined;
    /** A comma-separated list of package names. If specified, only alerts for these packages will be returned. */
    package?: string | undefined;
    /** A comma-separated list of full manifest paths. If specified, only alerts for these manifests will be returned. */
    manifest?: string | undefined;
    /** CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as: - An exact number (`n`) - Comparators such as `>n`, `<n`, `>=n`, `<=n` - A range like `n..n`, where `n` is a number from 0.0 to 1.0 Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned. */
    epss_percentage?: string | undefined;
    /** Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned. Multiple `has` filters can be passed to filter for alerts that have all of the values. Currently, only `patch` is supported. */
    has?: ListAlertsForRepoRequestHas | undefined;
    /** Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users. Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees. */
    assignee?: string | undefined;
    /** The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. */
    scope?: ListAlertsForRepoRequestScope | (string & {}) | undefined;
    /** A comma-separated list of relationships of the vulnerable dependency to your project. If specified, only alerts with these relationships will be returned. > [!NOTE] > We are rolling out support for dependency relationship across ecosystems. This value will be "unknown" for all dependencies in unsupported ecosystems. */
    relationship?: string | undefined;
    /** The property by which to sort the results. `created` means when the alert was created. `updated` means when the alert's state last changed. `epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. */
    sort?: ListAlertsForRepoRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForRepoRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListAlertsForRepoResponseBodyList = Array<DependabotAlert>;
export type ListAlertsForRepoResponse = ListAlertsForRepoResponseBodyList;
export interface ListOrgSecretsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgSecretsResponseSecretsList = Array<OrganizationDependabotSecret>;
export interface ListOrgSecretsResponse {
    total_count: number;
    secrets: ListOrgSecretsResponseSecretsList;
}
export interface ListRepoSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoSecretsResponseSecretsList = Array<DependabotSecret>;
export interface ListRepoSecretsResponse {
    total_count: number;
    secrets: ListRepoSecretsResponseSecretsList;
}
export interface ListSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: NullableSimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type ListSelectedReposForOrgSecretResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgSecretResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgSecretResponseRepositoriesList;
}
export interface RemoveSelectedRepoFromOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgSecretResponse {
}
export interface RepositoryAccessForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The page number of results to fetch. */
    page?: number | undefined;
    /** Number of results per page. */
    per_page?: number | undefined;
}
/** The default repository access level for Dependabot updates. */
export type DependabotRepositoryAccessDetailsDefaultLevel = "public" | "internal";
/** A GitHub repository. */
export type NullableSimpleRepository = SimpleRepository;
export type DependabotRepositoryAccessDetailsAccessibleRepositoriesList = Array<SimpleRepository | null>;
/** Information about repositories that Dependabot is able to access in an organization */
export interface DependabotRepositoryAccessDetails {
    /** The default repository access level for Dependabot updates. */
    default_level?: DependabotRepositoryAccessDetailsDefaultLevel | null | undefined;
    accessible_repositories: DependabotRepositoryAccessDetailsAccessibleRepositoriesList;
}
export interface RepositoryAccessForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The page number of results to fetch. */
    page?: number | undefined;
    /** Number of results per page. */
    per_page?: number | undefined;
}
/** The default repository access level for Dependabot updates. */
export type SetRepositoryAccessDefaultLevelRequestDefaultLevel = "public" | "internal";
export interface SetRepositoryAccessDefaultLevelRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The default repository access level for Dependabot updates. */
    default_level: SetRepositoryAccessDefaultLevelRequestDefaultLevel | (string & {});
}
export interface SetRepositoryAccessDefaultLevelResponse {
}
/** The default repository access level for Dependabot updates. */
export type SetRepositoryAccessDefaultLevelForEnterpriseRequestDefaultLevel = "public" | "internal";
export interface SetRepositoryAccessDefaultLevelForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** The default repository access level for Dependabot updates. */
    default_level: SetRepositoryAccessDefaultLevelForEnterpriseRequestDefaultLevel | (string & {});
}
export interface SetRepositoryAccessDefaultLevelForEnterpriseResponse {
}
/** `labeled` for labeled runners, `standard` for standard GitHub-hosted runners. */
export type SetRepositoryRunnerSettingsRequestRunnerType = "standard" | "labeled";
/** Required for `labeled`. Exactly one non-blank runner label. Not allowed for `standard`. */
export type SetRepositoryRunnerSettingsRequestRunnerLabelsList = Array<string>;
export interface SetRepositoryRunnerSettingsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** `labeled` for labeled runners, `standard` for standard GitHub-hosted runners. */
    runner_type: SetRepositoryRunnerSettingsRequestRunnerType | (string & {});
    /** Required for `labeled`. Exactly one non-blank runner label. Not allowed for `standard`. */
    runner_labels?: SetRepositoryRunnerSettingsRequestRunnerLabelsList | undefined;
    /** Optional for `labeled`. Omitted, `null` or blank means no group. Not allowed for `standard`. */
    runner_group?: string | null | undefined;
}
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids: SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgSecretResponse {
}
/** The state of the Dependabot alert. A `dismissed_reason` must be provided when setting the state to `dismissed`. */
export type UpdateAlertRequestState = "dismissed" | "open";
/** **Required when `state` is `dismissed`.** A reason for dismissing the alert. */
export type UpdateAlertRequestDismissedReason = "fix_started" | "inaccurate" | "no_bandwidth" | "not_used" | "tolerable_risk";
/** Usernames to assign to this Dependabot Alert. Pass one or more user logins to _replace_ the set of assignees on this alert. Send an empty array (`[]`) to clear all assignees from the alert. To assign an AI agent, include the bot login (for example, `copilot-swe-agent[bot]`). */
export type UpdateAlertRequestAssigneesList = Array<string>;
/** Parameters for AI agent assignment. Only used when an agent bot login is included in `assignees`. Ignored when no agent is being assigned. */
export interface UpdateAlertRequestAgentAssignment {
    /** Custom instructions for the agent. */
    custom_instructions?: string | undefined;
    /** A custom agent identifier. */
    custom_agent?: string | undefined;
    /** The model to use for the agent. */
    model?: string | undefined;
}
export interface UpdateAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies a Dependabot alert in its repository. You can find this at the end of the URL for a Dependabot alert within GitHub, or in `number` fields in the response from the `GET /repos/{owner}/{repo}/dependabot/alerts` operation. */
    alert_number: number;
    /** The state of the Dependabot alert. A `dismissed_reason` must be provided when setting the state to `dismissed`. */
    state?: UpdateAlertRequestState | (string & {}) | undefined;
    /** **Required when `state` is `dismissed`.** A reason for dismissing the alert. */
    dismissed_reason?: UpdateAlertRequestDismissedReason | (string & {}) | undefined;
    /** An optional comment associated with dismissing the alert. */
    dismissed_comment?: string | undefined;
    /** Usernames to assign to this Dependabot Alert. Pass one or more user logins to _replace_ the set of assignees on this alert. Send an empty array (`[]`) to clear all assignees from the alert. To assign an AI agent, include the bot login (for example, `copilot-swe-agent[bot]`). */
    assignees?: UpdateAlertRequestAssigneesList | undefined;
    /** Parameters for AI agent assignment. Only used when an agent bot login is included in `assignees`. Ignored when no agent is being assigned. */
    agent_assignment?: UpdateAlertRequestAgentAssignment | undefined;
}
/** List of repository IDs to add. */
export type UpdateRepositoryAccessForEnterpriseRequestRepositoryIdsToAddList = Array<number>;
/** List of repository IDs to remove. */
export type UpdateRepositoryAccessForEnterpriseRequestRepositoryIdsToRemoveList = Array<number>;
export interface UpdateRepositoryAccessForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** List of repository IDs to add. */
    repository_ids_to_add?: UpdateRepositoryAccessForEnterpriseRequestRepositoryIdsToAddList | undefined;
    /** List of repository IDs to remove. */
    repository_ids_to_remove?: UpdateRepositoryAccessForEnterpriseRequestRepositoryIdsToRemoveList | undefined;
}
export interface UpdateRepositoryAccessForEnterpriseResponse {
}
/** List of repository IDs to add. */
export type UpdateRepositoryAccessForOrgRequestRepositoryIdsToAddList = Array<number>;
/** List of repository IDs to remove. */
export type UpdateRepositoryAccessForOrgRequestRepositoryIdsToRemoveList = Array<number>;
export interface UpdateRepositoryAccessForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** List of repository IDs to add. */
    repository_ids_to_add?: UpdateRepositoryAccessForOrgRequestRepositoryIdsToAddList | undefined;
    /** List of repository IDs to remove. */
    repository_ids_to_remove?: UpdateRepositoryAccessForOrgRequestRepositoryIdsToRemoveList | undefined;
}
export interface UpdateRepositoryAccessForOrgResponse {
}
export type AddSelectedRepoToOrgSecretError = GithubOpError;
/** Add selected repository to an organization secret Adds a repository to an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/dependabot/secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const addSelectedRepoToOrgSecret: API.OperationMethod<AddSelectedRepoToOrgSecretRequest, AddSelectedRepoToOrgSecretResponse, AddSelectedRepoToOrgSecretError, GithubOpContext>;
export type CreateOrUpdateOrgSecretError = GithubOpError;
/** Create or update an organization secret Creates or updates an organization secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createOrUpdateOrgSecret: API.OperationMethod<CreateOrUpdateOrgSecretRequest, CreateOrUpdateOrgSecretResponse, CreateOrUpdateOrgSecretError, GithubOpContext>;
export type CreateOrUpdateRepoSecretError = GithubOpError;
/** Create or update a repository secret Creates or updates a repository secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateRepoSecret: API.OperationMethod<CreateOrUpdateRepoSecretRequest, CreateOrUpdateRepoSecretResponse, CreateOrUpdateRepoSecretError, GithubOpContext>;
export type DeleteOrgSecretError = GithubOpError;
/** Delete an organization secret Deletes a secret in an organization using the secret name. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteOrgSecret: API.OperationMethod<DeleteOrgSecretRequest, DeleteOrgSecretResponse, DeleteOrgSecretError, GithubOpContext>;
export type DeleteRepoSecretError = GithubOpError;
/** Delete a repository secret Deletes a secret in a repository using the secret name. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteRepoSecret: API.OperationMethod<DeleteRepoSecretRequest, DeleteRepoSecretResponse, DeleteRepoSecretError, GithubOpContext>;
export type GetAlertError = GithubOpError;
/** Get a Dependabot alert OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const getAlert: API.OperationMethod<GetAlertRequest, DependabotAlert, GetAlertError, GithubOpContext>;
export type GetOrgPublicKeyError = GithubOpError;
/** Get an organization public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgPublicKey: API.OperationMethod<GetOrgPublicKeyRequest, DependabotPublicKey, GetOrgPublicKeyError, GithubOpContext>;
export type GetOrgSecretError = GithubOpError;
/** Get an organization secret Gets a single organization secret without revealing its encrypted value. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getOrgSecret: API.OperationMethod<GetOrgSecretRequest, OrganizationDependabotSecret, GetOrgSecretError, GithubOpContext>;
export type GetRepoPublicKeyError = GithubOpError;
/** Get a repository public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint if the repository is private. */
export declare const getRepoPublicKey: API.OperationMethod<GetRepoPublicKeyRequest, DependabotPublicKey, GetRepoPublicKeyError, GithubOpContext>;
export type GetRepoSecretError = GithubOpError;
/** Get a repository secret Gets a single repository secret without revealing its encrypted value. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoSecret: API.OperationMethod<GetRepoSecretRequest, DependabotSecret, GetRepoSecretError, GithubOpContext>;
export type GetRepositoryRunnerSettingsError = GithubOpError;
/** Get repository Dependabot runner settings Gets the runner Dependabot uses for this repository: standard GitHub-hosted runners, or labeled runners with their labels and optional runner group. The response matches the repository's code security settings page. Labeled runners take effect only for private and internal repositories with GitHub Actions enabled. Otherwise, the response shows `standard`. Repository administrators and users who can manage security products for the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) require the `repo` scope for both public and private repositories. GitHub App tokens and fine-grained personal access tokens require repository Administration read permission. Workflow `GITHUB_TOKEN` access is not supported. */
export declare const getRepositoryRunnerSettings: API.OperationMethod<GetRepositoryRunnerSettingsRequest, DependabotRunnerSettings, GetRepositoryRunnerSettingsError, GithubOpContext>;
export type ListAlertsForEnterpriseError = GithubOpError;
/** List Dependabot alerts for an enterprise Lists Dependabot alerts for repositories that are owned by the specified enterprise. The authenticated user must be a member of the enterprise to use this endpoint. Alerts are only returned for organizations in the enterprise for which you are an organization owner or a security manager. For more information about security managers, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. */
export declare const listAlertsForEnterprise: API.OperationMethod<ListAlertsForEnterpriseRequest, ListAlertsForEnterpriseResponse, ListAlertsForEnterpriseError, GithubOpContext>;
export type ListAlertsForOrgError = GithubOpError;
/** List Dependabot alerts for an organization Lists Dependabot alerts for an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const listAlertsForOrg: API.OperationMethod<ListAlertsForOrgRequest, ListAlertsForOrgResponse, ListAlertsForOrgError, GithubOpContext>;
export type ListAlertsForRepoError = GithubOpError;
/** List Dependabot alerts for a repository OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const listAlertsForRepo: API.OperationMethod<ListAlertsForRepoRequest, ListAlertsForRepoResponse, ListAlertsForRepoError, GithubOpContext>;
export type ListOrgSecretsError = GithubOpError;
/** List organization secrets Lists all secrets available in an organization without revealing their encrypted values. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listOrgSecrets: API.PaginatedOperationMethod<ListOrgSecretsRequest, ListOrgSecretsResponse, ListOrgSecretsError, GithubOpContext, OrganizationDependabotSecret>;
export type ListRepoSecretsError = GithubOpError;
/** List repository secrets Lists all secrets available in a repository without revealing their encrypted values. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoSecrets: API.PaginatedOperationMethod<ListRepoSecretsRequest, ListRepoSecretsResponse, ListRepoSecretsError, GithubOpContext, DependabotSecret>;
export type ListSelectedReposForOrgSecretError = GithubOpError;
/** List selected repositories for an organization secret Lists all repositories that have been selected when the `visibility` for repository access to a secret is set to `selected`. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listSelectedReposForOrgSecret: API.PaginatedOperationMethod<ListSelectedReposForOrgSecretRequest, ListSelectedReposForOrgSecretResponse, ListSelectedReposForOrgSecretError, GithubOpContext, MinimalRepository>;
export type RemoveSelectedRepoFromOrgSecretError = GithubOpError;
/** Remove selected repository from an organization secret Removes a repository from an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/dependabot/secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const removeSelectedRepoFromOrgSecret: API.OperationMethod<RemoveSelectedRepoFromOrgSecretRequest, RemoveSelectedRepoFromOrgSecretResponse, RemoveSelectedRepoFromOrgSecretError, GithubOpContext>;
export type RepositoryAccessForEnterpriseError = GithubOpError;
/** Lists the repositories Dependabot can access in an enterprise Lists repositories that enterprise admins have allowed Dependabot to access when updating dependencies across organizations in the enterprise. The authenticated user must be an enterprise owner to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const repositoryAccessForEnterprise: API.PaginatedOperationMethod<RepositoryAccessForEnterpriseRequest, DependabotRepositoryAccessDetails, RepositoryAccessForEnterpriseError, GithubOpContext, SimpleRepository>;
export type RepositoryAccessForOrgError = GithubOpError;
/** Lists the repositories Dependabot can access in an organization Lists repositories that organization admins have allowed Dependabot to access when updating dependencies. > [!NOTE] > This operation supports both server-to-server and user-to-server access. Unauthorized users will not see the existence of this endpoint. */
export declare const repositoryAccessForOrg: API.PaginatedOperationMethod<RepositoryAccessForOrgRequest, DependabotRepositoryAccessDetails, RepositoryAccessForOrgError, GithubOpContext, SimpleRepository>;
export type SetRepositoryAccessDefaultLevelError = GithubOpError;
/** Set the default repository access level for Dependabot Sets the default level of repository access Dependabot will have while performing an update. Available values are: - 'public' - Dependabot will only have access to public repositories, unless access is explicitly granted to non-public repositories. - 'internal' - Dependabot will only have access to public and internal repositories, unless access is explicitly granted to private repositories. Unauthorized users will not see the existence of this endpoint. This operation supports both server-to-server and user-to-server access. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const setRepositoryAccessDefaultLevel: API.OperationMethod<SetRepositoryAccessDefaultLevelRequest, SetRepositoryAccessDefaultLevelResponse, SetRepositoryAccessDefaultLevelError, GithubOpContext>;
export type SetRepositoryAccessDefaultLevelForEnterpriseError = GithubOpError;
/** Set the default repository access level for Dependabot in an enterprise Sets the default level of repository access Dependabot will have while performing an update across organizations in the enterprise. Available values are: - 'public' - Dependabot will only have access to public repositories, unless access is explicitly granted to non-public repositories. - 'internal' - Dependabot will only have access to public and internal repositories, unless access is explicitly granted to private repositories. The authenticated user must be an enterprise owner to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const setRepositoryAccessDefaultLevelForEnterprise: API.OperationMethod<SetRepositoryAccessDefaultLevelForEnterpriseRequest, SetRepositoryAccessDefaultLevelForEnterpriseResponse, SetRepositoryAccessDefaultLevelForEnterpriseError, GithubOpContext>;
export type SetRepositoryRunnerSettingsError = GithubOpError;
/** Set repository Dependabot runner settings Sets the runner Dependabot uses for this repository. This is the same setting as on the repository's code security settings page. `labeled` turns on labeled runners with exactly one runner label and an optional runner group. `standard` turns them off and clears the label and group. Labeled runners are only available for private and internal repositories with GitHub Actions enabled. The response returns the settings after the change. Repository administrators and users who can manage security products for the repository can use this endpoint, subject to enterprise policy. OAuth app tokens and personal access tokens (classic) require the `repo` scope. GitHub App tokens and fine-grained personal access tokens require repository Administration write permission. Workflow `GITHUB_TOKEN` access is not supported. */
export declare const setRepositoryRunnerSettings: API.OperationMethod<SetRepositoryRunnerSettingsRequest, DependabotRunnerSettings, SetRepositoryRunnerSettingsError, GithubOpContext>;
export type SetSelectedReposForOrgSecretError = GithubOpError;
/** Set selected repositories for an organization secret Replaces all repositories for an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/dependabot/secrets#create-or-update-an-organization-secret). OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setSelectedReposForOrgSecret: API.OperationMethod<SetSelectedReposForOrgSecretRequest, SetSelectedReposForOrgSecretResponse, SetSelectedReposForOrgSecretError, GithubOpContext>;
export type UpdateAlertError = GithubOpError;
/** Update a Dependabot alert The authenticated user must have access to security alerts for the repository to use this endpoint. For more information, see "[Granting access to security alerts](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-security-and-analysis-settings-for-your-repository#granting-access-to-security-alerts)." OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const updateAlert: API.OperationMethod<UpdateAlertRequest, DependabotAlert, UpdateAlertError, GithubOpContext>;
export type UpdateRepositoryAccessForEnterpriseError = GithubOpError;
/** Updates Dependabot's repository access list for an enterprise Updates repositories according to the list of repositories that enterprise admins have given Dependabot access to when they've updated dependencies across organizations in the enterprise. The authenticated user must be an enterprise owner to use this endpoint. **Example request body:** ```json { "repository_ids_to_add": [123, 456], "repository_ids_to_remove": [789] } ``` > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const updateRepositoryAccessForEnterprise: API.OperationMethod<UpdateRepositoryAccessForEnterpriseRequest, UpdateRepositoryAccessForEnterpriseResponse, UpdateRepositoryAccessForEnterpriseError, GithubOpContext>;
export type UpdateRepositoryAccessForOrgError = GithubOpError;
/** Updates Dependabot's repository access list for an organization Updates repositories according to the list of repositories that organization admins have given Dependabot access to when they've updated dependencies. > [!NOTE] > This operation supports both server-to-server and user-to-server access. Unauthorized users will not see the existence of this endpoint. OAuth app tokens and personal access tokens (classic) need the `write:org` scope to use this endpoint. **Example request body:** ```json { "repository_ids_to_add": [123, 456], "repository_ids_to_remove": [789] } ``` */
export declare const updateRepositoryAccessForOrg: API.OperationMethod<UpdateRepositoryAccessForOrgRequest, UpdateRepositoryAccessForOrgResponse, UpdateRepositoryAccessForOrgError, GithubOpContext>;
//# sourceMappingURL=dependabot.d.ts.map