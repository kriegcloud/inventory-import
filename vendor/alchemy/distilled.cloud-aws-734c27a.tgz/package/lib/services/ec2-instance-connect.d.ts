import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AuthException_base: S.TaggedErrorClass<"AuthException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthException extends /*@__PURE__*/ AuthException_base {
}
declare const EC2InstanceNotFoundException_base: S.TaggedErrorClass<"EC2InstanceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceNotFoundException extends /*@__PURE__*/ EC2InstanceNotFoundException_base {
}
declare const EC2InstanceStateInvalidException_base: S.TaggedErrorClass<"EC2InstanceStateInvalidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceStateInvalidException extends /*@__PURE__*/ EC2InstanceStateInvalidException_base {
}
declare const EC2InstanceTypeInvalidException_base: S.TaggedErrorClass<"EC2InstanceTypeInvalidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EC2InstanceTypeInvalidException extends /*@__PURE__*/ EC2InstanceTypeInvalidException_base {
}
declare const EC2InstanceUnavailableException_base: S.TaggedErrorClass<"EC2InstanceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class EC2InstanceUnavailableException extends /*@__PURE__*/ EC2InstanceUnavailableException_base {
}
declare const InvalidArgsException_base: S.TaggedErrorClass<"InvalidArgsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgsException extends /*@__PURE__*/ InvalidArgsException_base {
}
declare const SerialConsoleAccessDisabledException_base: S.TaggedErrorClass<"SerialConsoleAccessDisabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SerialConsoleAccessDisabledException extends /*@__PURE__*/ SerialConsoleAccessDisabledException_base {
}
declare const SerialConsoleSessionLimitExceededException_base: S.TaggedErrorClass<"SerialConsoleSessionLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SerialConsoleSessionLimitExceededException extends /*@__PURE__*/ SerialConsoleSessionLimitExceededException_base {
}
declare const SerialConsoleSessionUnavailableException_base: S.TaggedErrorClass<"SerialConsoleSessionUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class SerialConsoleSessionUnavailableException extends /*@__PURE__*/ SerialConsoleSessionUnavailableException_base {
}
declare const SerialConsoleSessionUnsupportedException_base: S.TaggedErrorClass<"SerialConsoleSessionUnsupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SerialConsoleSessionUnsupportedException extends /*@__PURE__*/ SerialConsoleSessionUnsupportedException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type InstanceId = string;
export type SerialPort = number;
export type SSHPublicKey = string;
export interface SendSerialConsoleSSHPublicKeyRequest {
    InstanceId: string;
    SerialPort?: number | undefined;
    SSHPublicKey: string;
}
export type RequestId = string;
export type Success = boolean;
export interface SendSerialConsoleSSHPublicKeyResponse {
    RequestId?: string | undefined;
    Success?: boolean | undefined;
}
export type InstanceOSUser = string;
export type AvailabilityZone = string;
export interface SendSSHPublicKeyRequest {
    InstanceId: string;
    InstanceOSUser: string;
    SSHPublicKey: string;
    AvailabilityZone?: string | undefined;
}
export interface SendSSHPublicKeyResponse {
    RequestId?: string | undefined;
    Success?: boolean | undefined;
}
export type SendSerialConsoleSSHPublicKeyError = AuthException | EC2InstanceNotFoundException | EC2InstanceStateInvalidException | EC2InstanceTypeInvalidException | EC2InstanceUnavailableException | InvalidArgsException | SerialConsoleAccessDisabledException | SerialConsoleSessionLimitExceededException | SerialConsoleSessionUnavailableException | SerialConsoleSessionUnsupportedException | ServiceException | ThrottlingException | CommonErrors;
/**
 * Pushes an SSH public key to the specified EC2 instance. The key remains for 60
 * seconds, which gives you 60 seconds to establish a serial console connection to the
 * instance using SSH. For more information, see EC2 Serial Console in
 * the *Amazon EC2 User Guide*.
 */
export declare const sendSerialConsoleSSHPublicKey: API.OperationMethod<SendSerialConsoleSSHPublicKeyRequest & RegionInput, SendSerialConsoleSSHPublicKeyResponse, SendSerialConsoleSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export type SendSSHPublicKeyError = AuthException | EC2InstanceNotFoundException | EC2InstanceStateInvalidException | EC2InstanceUnavailableException | InvalidArgsException | ServiceException | ThrottlingException | CommonErrors;
/**
 * Pushes an SSH public key to the specified EC2 instance for use by the specified user.
 * The key remains for 60 seconds. For more information, see Connect to
 * your Linux instance using EC2 Instance Connect in the Amazon EC2
 * User Guide.
 */
export declare const sendSSHPublicKey: API.OperationMethod<SendSSHPublicKeyRequest & RegionInput, SendSSHPublicKeyResponse, SendSSHPublicKeyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ec2-instance-connect.d.ts.map