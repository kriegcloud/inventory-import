import * as Command from "effect/cli/Command";
import * as Option from "effect/Option";
import * as Alchemist from "../../Alchemist/index.ts";
import * as Interaction from "../../Interaction.ts";
import { Cli } from "../../Report.ts";
export declare const deployCommand: Command.Command<"deploy", {
    readonly dryRun: boolean;
    readonly force: boolean;
    readonly include: readonly string[] | undefined;
    readonly exclude: readonly string[] | undefined;
    readonly config: string | undefined;
    readonly configPath: string | undefined;
    readonly envFile: Option.Option<string>;
    readonly stage: string | undefined;
    readonly yes: boolean;
    readonly profile: string | undefined;
    readonly adopt: boolean;
    readonly detailed: boolean;
    readonly detectDrift: boolean;
}, {}, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Demand.ts").CredentialsRequired | import("../../Apply.ts").DestroyError | import("../../Output.ts").InvalidReferenceError | import("../../Output.ts").MissingSourceError | import("../../Auth/AuthProvider.ts").NeedsReauth | Interaction.NonInteractiveTerminal | import("effect/PlatformError").PlatformError | Alchemist.StackEntrypointError | import("../../State/State.ts").StateStoreError | import("./errors.ts").UserInputError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | Cli | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Interaction.Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
export declare const destroyCommand: Command.Command<"destroy", {
    readonly include: readonly string[] | undefined;
    readonly exclude: readonly string[] | undefined;
    readonly dryRun: boolean;
    readonly config: string | undefined;
    readonly configPath: string | undefined;
    readonly envFile: Option.Option<string>;
    readonly stage: string | undefined;
    readonly yes: boolean;
    readonly profile: string | undefined;
}, {}, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Demand.ts").CredentialsRequired | import("../../Apply.ts").DestroyError | import("../../Output.ts").InvalidReferenceError | import("../../Output.ts").MissingSourceError | import("../../Auth/AuthProvider.ts").NeedsReauth | Interaction.NonInteractiveTerminal | import("effect/PlatformError").PlatformError | Alchemist.StackEntrypointError | import("../../State/State.ts").StateStoreError | import("./errors.ts").UserInputError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | Cli | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Interaction.Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
export declare const planCommand: Command.Command<"plan", {
    readonly include: readonly string[] | undefined;
    readonly exclude: readonly string[] | undefined;
    readonly config: string | undefined;
    readonly configPath: string | undefined;
    readonly envFile: Option.Option<string>;
    readonly stage: string | undefined;
    readonly profile: string | undefined;
    readonly adopt: boolean;
    readonly detailed: boolean;
}, {}, import("../../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../../Auth/Demand.ts").CredentialsRequired | import("../../Apply.ts").DestroyError | import("../../Output.ts").InvalidReferenceError | import("../../Output.ts").MissingSourceError | import("../../Auth/AuthProvider.ts").NeedsReauth | Interaction.NonInteractiveTerminal | import("effect/PlatformError").PlatformError | Alchemist.StackEntrypointError | import("../../State/State.ts").StateStoreError | import("./errors.ts").UserInputError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | Cli | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Interaction.Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
//# sourceMappingURL=deploy.d.ts.map