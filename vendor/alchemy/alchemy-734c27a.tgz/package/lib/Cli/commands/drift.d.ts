import * as Command from "effect/cli/Command";
import * as Option from "effect/Option";
import * as Alchemist from "../../Alchemist/index.ts";
import * as Interaction from "../../Interaction.ts";
import { Cli } from "../../Report.ts";
/**
 * Exit code when drift was found and left unrepaired, so a scheduled job can
 * tell it apart from a clean stage (0) and a failed check (1), as
 * `terraform plan -detailed-exitcode` does.
 */
export declare const EXIT_DRIFT_DETECTED = 2;
export declare const driftCommand: Command.Command<"drift", {
    readonly repair: boolean;
    readonly yes: boolean;
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly stage: string | undefined;
    readonly profile: string | undefined;
}, {}, import("effect/Config").ConfigError | Interaction.NonInteractiveTerminal | import("effect/PlatformError").PlatformError | Alchemist.StackEntrypointError | import("../../State/State.ts").StateStoreError | import("./errors.ts").UserInputError, import("../../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | Cli | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Interaction.Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
//# sourceMappingURL=drift.d.ts.map