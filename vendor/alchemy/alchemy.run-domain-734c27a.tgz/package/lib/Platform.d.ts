import type { HttpEffect } from "alchemy/Http";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import { Scope } from "effect/Scope";
import type * as Stream from "effect/Stream";
import * as Aggregate from "./Aggregate.ts";
import type { Plan } from "./Backfill.ts";
import type { ReplayInput, ReplayResult } from "./CatchUp.ts";
import type * as Decision from "./Decision.ts";
import type * as Policy from "./Policy.ts";
import type * as Projection from "./Projection.ts";
import type * as DomainStream from "./Stream.ts";
import { TraceJson } from "./Telemetry.ts";
import type * as View from "./View.ts";
/**
 * Capture the services `R` for later use, minus the `Scope`: a captured
 * construction-time scope must never replace the scope of a later request or
 * event (finalizers would attach to the wrong lifetime, and on workerd the
 * work would be pinned to another request's I/O context). Platforms that host
 * a model call this when they are built.
 */
export declare const captureContext: <R = never>() => Effect.Effect<Context.Context<Exclude<R, Scope>>, never, R>;
/**
 * Everything a platform persists or sends is plain JSON. The kernel owns the
 * schemas; platforms only move and store these values.
 */
export type Json = unknown;
/**
 * An event envelope in JSON form. `at` is epoch milliseconds.
 */
export declare const EnvelopeJson: Schema.Struct<{
    readonly id: Schema.String;
    readonly stream: Schema.String;
    readonly seq: Schema.Number;
    readonly commandId: Schema.String;
    readonly at: Schema.Number;
    /** Absent on events stored before correlation ids: the command id stands in. */
    readonly correlationId: Schema.optionalKey<Schema.String>;
    /** The span that committed the event, so its reactions continue or link to it. */
    readonly trace: Schema.optionalKey<Schema.Struct<{
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
        readonly sampled: Schema.Boolean;
    }>>;
}>;
export type EnvelopeJson = typeof EnvelopeJson.Type;
/**
 * A committed event as stored by an aggregate.
 */
export interface StoredEvent {
    readonly event: Json;
    readonly envelope: EnvelopeJson;
}
/**
 * A unit of work routed from one host to another: an event (from an aggregate
 * or a view) to a view or policy. Deliveries are at least once; targets drop
 * duplicates by `(source, seq)`. Platforms must deliver in order per
 * `(source, target)`.
 */
export interface Delivery {
    readonly target: {
        readonly kind: "view" | "policy" | "projection";
        readonly name: string;
        /** The consumer's generation (see `Kernel.generationOf`), when it has been rebuilt. */
        readonly generation?: number;
        /** Rebuilt in the storage it had (see `Kernel.inPlace`): its id says `@` for `#`. */
        readonly inPlace?: boolean;
    };
    /** The target partition: a key's id, or the source stream for an unkeyed policy. */
    readonly key: string;
    /** Named routes (from `keyOf`) the event takes into this key; absent for the default route. */
    readonly routes?: ReadonlyArray<string>;
    /** The source stream, e.g. `Account/a-1` or `Statement/a-1`. */
    readonly source: string;
    /** The event's sequence number in its source stream. */
    readonly seq: number;
    /** The aggregate or view that produced the event. */
    readonly origin: string;
    readonly tag: string;
    readonly event: Json;
    readonly envelope: EnvelopeJson;
    /** For an event from a view: the view's encoded state after it. */
    readonly state?: Json;
    /**
     * History: seeded (story `given`) or replayed to a consumer added after the
     * event (see `CatchUp`). Views and projections apply it, policies ignore it.
     */
    readonly history?: boolean;
    /**
     * For an event from a view: the aggregate event it derives from. Absent,
     * the delivery's own `source` and `seq` are its root.
     */
    readonly root?: Root;
}
/**
 * The aggregate event a delivery derives from, through any views: its stream
 * and seq. A rebuilt view numbers its entries afresh, but its roots stay.
 */
export interface Root {
    readonly source: string;
    readonly seq: number;
}
/**
 * A client's live read (`watch` or `events`) of one key, in JSON form. A
 * platform that pushes keeps it with the connection (on a WebSocket's
 * attachment, so a hibernated object can resume pushing) and asks the kit's
 * `push` what to send after each commit.
 */
export declare const Subscription: Schema.Struct<{
    /** The client's request id, echoed as is (the client matches it by identity). */
    readonly requestId: Schema.Union<readonly [Schema.String, Schema.Number]>;
    readonly mode: Schema.Literals<readonly ["watch", "events"]>;
    /** The client's filter: it narrows what a permitted read sends. */
    readonly where: Schema.optionalKey<Schema.Unknown>;
    /** The context the read's middleware provided (see `Domain.RequestContext`), for `validate`. */
    readonly context: Schema.$Record<Schema.String, Schema.Unknown>;
    /** Progress: the last state version (`watch`) or event `seq` (`events`) sent. */
    readonly cursor: Schema.Number;
    /** Set when the read was refused before reaching the key: the encoded `Exit` to send. */
    readonly refused: Schema.optionalKey<Schema.Unknown>;
    /** `events` only: set once the `CaughtUp` frame after the read's history was sent. */
    readonly caughtUpSent: Schema.optionalKey<Schema.Boolean>;
    /**
     * Epoch milliseconds until which the read's middleware vouched for the
     * caller (see `Domain.setExpiry`). Once it passes, the platform closes the
     * connection with {@link REAUTHORIZE_CLOSE_CODE} instead of sending more.
     */
    readonly validUntil: Schema.optionalKey<Schema.Number>;
}>;
export type Subscription = typeof Subscription.Type;
/**
 * The close code of a live read's connection whose middleware must run again.
 * The client reconnects at once and resumes from its cursor, so the read's
 * middleware judges the caller afresh.
 */
export declare const REAUTHORIZE_CLOSE_CODE = 4000;
/** Whether a subscription must be judged again before anything more is sent. */
export declare const mustReauthorize: (subscription: Subscription, now: number) => boolean;
/**
 * What to send a subscriber, from a kit's `push`.
 */
export interface Push {
    /** Effect RPC messages (a `Chunk`, then an `Exit` if the read ended), in JSON form. */
    readonly messages: ReadonlyArray<Json>;
    /** The subscription with its progress after these messages. */
    readonly subscription: Subscription;
    /** `validate` rejected the read: send the messages, then close the connection. */
    readonly done: boolean;
}
/**
 * Input to {@link AggregateKit.handle}.
 */
export interface HandleInput {
    readonly id: string;
    /** The stored state, or `null` for an instance that has never committed. */
    readonly state: Json;
    readonly version: number;
    readonly command: Json;
    readonly commandId: string;
    /** The context the command was sent with (see `Domain.RequestContext`). */
    readonly context: Readonly<Record<string, Json>>;
    /** Epoch milliseconds. */
    readonly now: number;
    /** The flow the command belongs to; the command id when it starts one. */
    readonly correlationId?: string;
    /** The span that sent the command. */
    readonly trace?: TraceJson;
    /** Link to `trace` instead of continuing it. */
    readonly link?: boolean;
}
/**
 * Result of {@link AggregateKit.handle}.
 */
export type HandleResult = {
    readonly _tag: "Rejected";
    readonly rejection: Json;
} | {
    readonly _tag: "Accepted";
    readonly state: Json;
    readonly version: number;
    readonly events: ReadonlyArray<StoredEvent>;
    readonly reply: Json;
    readonly deliveries: ReadonlyArray<Delivery>;
};
/**
 * The receipt of an accepted command, in JSON form.
 */
export interface ReceiptJson {
    readonly stream: string;
    readonly version: number;
    readonly events: ReadonlyArray<Json>;
    readonly reply: Json;
}
/**
 * Result of {@link AggregateStore.send}.
 */
export type SendResult = {
    readonly _tag: "Rejected";
    readonly rejection: Json;
} | {
    readonly _tag: "Accepted";
    readonly receipt: ReceiptJson;
};
/**
 * Result of {@link AggregateStore.import}: the receipt, or the version the
 * instance was at when it was not the one expected.
 */
export type ImportResult = {
    readonly _tag: "Imported";
    readonly receipt: ReceiptJson;
} | {
    readonly _tag: "UnexpectedVersion";
    readonly version: number;
} | {
    readonly _tag: "OutOfOrder";
    /** The position of the first event out of order. */
    readonly index: number;
    /** Its commit time, in epoch milliseconds. */
    readonly at: number;
    /** The commit time it may not precede (or the clock it may not pass), in epoch milliseconds. */
    readonly after: number;
};
/**
 * What {@link AggregateStore.import} receives with the events.
 */
export interface ImportMeta {
    readonly commandId: string;
    readonly expectedVersion: number;
    /**
     * Each event's original commit time, in epoch milliseconds, by position;
     * `null` (or no list) for the platform's current time.
     */
    readonly at?: ReadonlyArray<number | null>;
}
/**
 * The kernel for one aggregate type, handed to a platform.
 */
export interface AggregateKit {
    readonly name: string;
    /**
     * Decide, evolve, reply and route, purely. Throws only on a bug (an evolve
     * guard, an undecodable value); a platform turns that into a defect.
     */
    readonly handle: (input: HandleInput) => Effect.Effect<HandleResult>;
    /**
     * Fold already-decided events into state and route them, without running
     * `decide`. Used to seed history (story `given`) and to import it.
     */
    readonly seed: (input: SeedInput) => Effect.Effect<SeedResult>;
    /**
     * Fold the events a decision recorded on an instance into its state and
     * route them, without running `decide`: they reach policies like any other.
     */
    readonly record: (input: RecordInput) => Effect.Effect<SeedResult>;
    /** Route a delivery produced by `handle` to its target's host. */
    readonly deliver: (delivery: Delivery) => Effect.Effect<void>;
    /** The views and projections that consume this aggregate, by `CatchUp.targetId`. */
    readonly targets: ReadonlyArray<string>;
    /** Whether each key of a consumer it feeds hears only from the instance with its own id. */
    readonly consumerSingleSource: (target: string) => boolean;
    /** Route stored events to the consumers lagging behind them (see `CatchUp`). */
    readonly replay: (input: ReplayInput<StoredEvent>) => Effect.Effect<ReplayResult>;
}
/**
 * Input to {@link AggregateKit.seed}.
 */
export interface SeedInput {
    readonly id: string;
    readonly state: Json;
    readonly version: number;
    readonly events: ReadonlyArray<Json>;
    readonly commandId: string;
    readonly now: number;
    /** Each event's commit time by position, overriding `now` where it isn't `null`. */
    readonly at?: ReadonlyArray<number | null>;
}
/**
 * Result of {@link AggregateKit.seed}.
 */
export interface SeedResult {
    readonly state: Json;
    readonly version: number;
    readonly events: ReadonlyArray<StoredEvent>;
    readonly deliveries: ReadonlyArray<Delivery>;
}
/** Input to {@link AggregateKit.record}. */
export interface RecordInput {
    readonly id: string;
    readonly state: Json;
    readonly version: number;
    /** The events a decision recorded on this instance, encoded. */
    readonly events: ReadonlyArray<Json>;
    readonly commandId: string;
    /** Epoch milliseconds the decision was made at. */
    readonly now: number;
    readonly correlationId: string;
    readonly trace?: TraceJson;
}
/** One aggregate instance a decision reads, by the name `reads` gives it. */
export interface DecisionRead {
    /** The names `reads` gives the instance: more than one when it is named twice. */
    readonly keys: ReadonlyArray<string>;
    readonly aggregate: string;
    readonly id: string;
    /** The instance's stream, e.g. `Account/a-1`. */
    readonly stream: string;
}
/** A read instance with the state and version it was read at. */
export interface DecisionState extends DecisionRead {
    /** The stored state, or `null` for an instance that has never committed. */
    readonly state: Json;
    readonly version: number;
}
/** What a decision writes to one instance it read: nothing, when `events` is empty. */
export interface DecisionWrite extends DecisionRead {
    /** The version the instance was read at: it must still have it. */
    readonly version: number;
    readonly events: ReadonlyArray<Json>;
}
/** The receipt of an accepted decision, in JSON form. */
export interface DecisionReceiptJson {
    readonly commits: ReadonlyArray<{
        readonly stream: string;
        readonly version: number;
    }>;
    readonly events: ReadonlyArray<Json>;
    readonly reply: Json;
}
/** Input to {@link DecisionKit.decide}. */
export interface DecideInput {
    readonly command: Json;
    readonly commandId: string;
    readonly context: Readonly<Record<string, Json>>;
    /** Epoch milliseconds. */
    readonly now: number;
    readonly correlationId?: string;
    readonly trace?: TraceJson;
    readonly link?: boolean;
    /** Every instance {@link DecisionKit.reads} named, as it was read. */
    readonly states: ReadonlyArray<DecisionState>;
}
/** Result of {@link DecisionKit.decide}. */
export type DecideResult = {
    readonly _tag: "Rejected";
    readonly rejection: Json;
} | {
    readonly _tag: "Accepted";
    /** One per instance read, in stream order: its events, or none. */
    readonly writes: ReadonlyArray<DecisionWrite>;
    readonly receipt: DecisionReceiptJson;
    readonly correlationId: string;
    /** The span that decided, so the events' reactions continue it. */
    readonly trace?: TraceJson;
};
/** Result of {@link DecisionStore.send}. */
export type DecisionResult = {
    readonly _tag: "Rejected";
    readonly rejection: Json;
} | {
    readonly _tag: "Accepted";
    readonly receipt: DecisionReceiptJson;
};
/**
 * The kernel for one decision, handed to a platform.
 */
export interface DecisionKit {
    readonly name: string;
    /** The instances a command involves, each once, ordered by stream. */
    readonly reads: (command: Json) => Effect.Effect<ReadonlyArray<DecisionRead>>;
    /** Decide purely against the states read: a rejection, or what to write to each instance. */
    readonly decide: (input: DecideInput) => Effect.Effect<DecideResult>;
}
/**
 * What a platform provides for a decision.
 */
export interface DecisionStore {
    /**
     * Handle a command across the instances it reads: decide against their
     * states, and commit every write or none. Nothing commits unless each
     * instance still has the version it was read at; a command id already
     * committed returns its first receipt.
     */
    readonly send: (command: Json, meta: Aggregate.SendMeta) => Effect.Effect<DecisionResult>;
}
/**
 * What a platform provides for an aggregate type.
 */
export interface AggregateStore {
    /**
     * Handle a command on one instance: single writer per id; dedupe by
     * `commandId`; persist events, state, receipt and deliveries atomically;
     * then deliver at least once, in order.
     */
    readonly send: (id: string, command: Json, meta: Aggregate.SendMeta) => Effect.Effect<SendResult>;
    /**
     * Send a command to one instance when it is due, durably (it survives
     * restarts) and at least once. `name` is the scheduled command's id on the
     * instance; `meta.commandId` is this arming's, the one the command commits
     * with. Scheduling under a `name` replaces its command, pending or already
     * run, unless that command has the same `meta.commandId`: then it is the
     * same arming again (a policy or step that ran again) and nothing changes,
     * not even when it is due. Rejections are impossible: only non-rejecting
     * commands are scheduled. Returns when it is due, in epoch milliseconds on
     * the platform's clock.
     */
    readonly schedule: (id: string, name: string, command: Json, meta: Aggregate.SendMeta, due: Aggregate.Due) => Effect.Effect<number>;
    /**
     * Cancel the pending scheduled command named `commandId` on one instance,
     * durably, and remember the cancel. Once this succeeds, the command never
     * runs, even one already due. Fails with `AlreadyExecuted` when the
     * command under that name already ran, `AlreadyCancelled` when it was
     * cancelled before (and not scheduled again since), and `NotScheduled`
     * when nothing was scheduled under it.
     */
    readonly unschedule: (id: string, commandId: string) => Effect.Effect<void, Aggregate.AlreadyExecuted | Aggregate.AlreadyCancelled | Aggregate.NotScheduled>;
    /** Read the stored state of an instance. */
    readonly state: (id: string) => Effect.Effect<{
        readonly state: Json;
        readonly version: number;
    }>;
    /** Read the committed events of an instance (tests and diagnostics; optional). */
    readonly events?: (id: string) => Effect.Effect<ReadonlyArray<StoredEvent>>;
    /** The stored state and version of an instance, then every new one. */
    readonly changes: (id: string) => Stream.Stream<{
        readonly state: Json;
        readonly version: number;
    }>;
    /** Committed events with `seq > after`, then live ones. */
    readonly tail: (id: string, after: number) => Stream.Stream<StoredEvent>;
    /**
     * Append events without deciding. They reach views as history, and never
     * trigger policies (tests; optional).
     */
    readonly seed?: (id: string, events: ReadonlyArray<Json>) => Effect.Effect<void>;
    /**
     * Append events without deciding, once per `meta.commandId`: single writer
     * per id; a seen `commandId` answers its stored receipt; otherwise, unless
     * the instance is at `meta.expectedVersion`, commit nothing and answer
     * `UnexpectedVersion`. Persist events, state, receipt and deliveries
     * atomically, as `send` does. The events reach views and projections as
     * history, and never trigger policies. Optional: a client fails with a
     * defect on a platform without it.
     */
    readonly import?: (id: string, events: ReadonlyArray<Json>, meta: ImportMeta) => Effect.Effect<ImportResult>;
}
/** How much history has reached a consumer: see `View.History`. */
export interface HistoryJson {
    readonly complete: boolean;
}
/**
 * The stored state of one view key.
 */
export interface ViewSnapshot {
    /** The encoded state, or `null` when the key does not exist. */
    readonly state: Json;
    /** Number of applied deliveries. */
    readonly version: number;
    /**
     * Last applied `seq` per source.
     *
     * A command that waits for its views (`consistency: "strong"`) and a read's
     * `atLeast` both answer once a `seq` is reported here, and promise that any
     * read after that includes it. So a platform that serves a key's reads from
     * more than one copy (read replicas) reports a `seq` only once every copy
     * that serves reads has applied it.
     */
    readonly checkpoints: Readonly<Record<string, number>>;
    /** Number of events the key has emitted. */
    readonly seq: number;
    /** The view's generation the key was built by: an earlier one is stale and starts over. */
    readonly generation?: number;
    /**
     * Per source, what the last command to reach the key from it became: see
     * {@link EmittedRange}. A reader finds a command's emissions with it instead
     * of scanning entries. Absent from snapshots written before it existed, and
     * for a source until the key next applies a delivery from it.
     */
    readonly emitted?: Readonly<Record<string, EmittedRange>>;
}
/**
 * The entries a view key emitted for one command's deliveries from one source.
 */
export interface EmittedRange {
    /** The command the deliveries came from. */
    readonly commandId: string;
    /** The last of its deliveries' `seq` (on the source) the key applied. */
    readonly sourceSeq: number;
    /** The key's `seq` before the first of them: its entries are those after it… */
    readonly after: number;
    /** …through this one (`after` itself when they emitted nothing). */
    readonly through: number;
}
/** The snapshot of a key that has never received a delivery. */
export declare const emptySnapshot: ViewSnapshot;
/**
 * One event a view key emitted, with the key's state after it.
 */
export interface ViewEntry {
    readonly seq: number;
    readonly event: Json;
    readonly envelope: EnvelopeJson;
    readonly state: Json;
    /** The aggregate event the entry derives from; absent on entries written before roots were. */
    readonly root?: Root;
}
/**
 * The kernel for one view, handed to a platform.
 */
export interface ViewKit {
    readonly name: string;
    /**
     * Apply deliveries to a key's snapshot: evolve its state and emit events.
     * Drops duplicates. Persist the snapshot and entries together, then send
     * the downstream deliveries.
     */
    readonly apply: (key: string, snapshot: ViewSnapshot, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<{
        readonly snapshot: ViewSnapshot;
        /** `false` when every delivery was a duplicate. */
        readonly changed: boolean;
        readonly entries: ReadonlyArray<ViewEntry>;
        readonly downstream: ReadonlyArray<Delivery>;
    }>;
    /** Route a downstream delivery to its target's host. */
    readonly deliver: (delivery: Delivery) => Effect.Effect<void>;
    /** The views and projections that consume this view, by `CatchUp.targetId`. */
    readonly targets: ReadonlyArray<string>;
    /** Whether each key of a consumer it feeds hears only from the instance with its own id. */
    readonly consumerSingleSource: (target: string) => boolean;
    /**
     * This view's generation. A stored key built by an earlier one is reset
     * (state, entries, input log and cursors) before it is read or applied to.
     */
    readonly generation: number;
    /** The generation of the view's storage: its generation, unless it is rebuilt in place. */
    readonly classGeneration: number;
    /** The view's id, by `CatchUp.targetId`, in this code. */
    readonly target: string;
    /**
     * Set for a view keyed by the one aggregate it reads (`source`): before a key
     * answers a read, it reads its history from the instance with its own id, so
     * every answer covers the whole history even when no backfill filled it.
     */
    readonly catchUp?: {
        readonly source: string;
    };
    /** Whether each key hears only from the source instance with its own id (see `Kernel.singleSource`). */
    readonly singleSource: boolean;
    /**
     * Route a source instance's stored rows (as its backfill `log` returns them)
     * to one consumer (by `CatchUp.targetId`), as history: each row's seq and its
     * deliveries. What a key keyed by its source runs on the rows it reads.
     */
    readonly history: (target: string, source: string, id: string, rows: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<{
        readonly seq: number;
        readonly deliveries: ReadonlyArray<Delivery>;
    }>>;
    /** Route emitted entries to the consumers lagging behind them (see `CatchUp`). */
    readonly replay: (input: ReplayInput<ViewEntry>) => Effect.Effect<ReplayResult>;
    /** Trace an `apply` of these deliveries to `key` (wrap the work that applies and persists them). */
    readonly observe: (key: string, deliveries: ReadonlyArray<Delivery>) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
    /**
     * What a subscriber of `key` receives, given its snapshot and the entries
     * emitted since (at least those after the subscription's cursor).
     */
    readonly push: (key: string, subscription: Subscription, snapshot: ViewSnapshot, entries: ReadonlyArray<ViewEntry>) => Effect.Effect<Push>;
}
/**
 * Which entries of a key a `list` reads, by `seq`. Without a range, every
 * entry, oldest first.
 */
export interface ListRange {
    /** Oldest first (`"asc"`, the default) or newest first. */
    readonly order?: "asc" | "desc";
    /** Only entries after this `seq` in `order`: greater for `"asc"`, smaller for `"desc"`. */
    readonly after?: number;
    /** At most this many entries. */
    readonly limit?: number;
}
/**
 * The first imported event whose commit time comes before the event ahead of
 * it (`latest` for the first: the instance's last commit time, `0` if it has
 * none) or after `now`, or `undefined` when they are in order. An event
 * without a time (`null`) commits at `now`. Views are rebuilt in commit-time
 * order, so a history out of order would replay out of order.
 */
export declare const outOfOrder: (at: ReadonlyArray<number | null> | undefined, count: number, latest: number, now: number) => Extract<ImportResult, {
    readonly _tag: "OutOfOrder";
}> | undefined;
/** The entries of `entries` (sorted by `seq`) in `range`, for platforms that hold them in memory. */
export declare const inRange: <A extends {
    readonly seq: number;
}>(entries: ReadonlyArray<A>, range: ListRange | undefined) => ReadonlyArray<A>;
/**
 * What a platform provides for a view.
 */
export interface ViewStore {
    /** Apply deliveries to one key (single writer per key), then forward downstream deliveries. */
    readonly receive: (key: string, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<void>;
    readonly read: (key: string) => Effect.Effect<ViewSnapshot>;
    /** The current snapshot, then every new one. */
    readonly changes: (key: string) => Stream.Stream<ViewSnapshot>;
    /** A key's entries in `range`: only these are read from storage. */
    readonly list: (key: string, range?: ListRange) => Effect.Effect<ReadonlyArray<ViewEntry>>;
    /** Entries with `seq > after`, then live entries. */
    readonly tail: (key: string, after: number) => Stream.Stream<ViewEntry>;
    /**
     * Accept a WebSocket upgrade (the current request) for a live read of
     * `key`, then push to it on every commit. Optional: without it, live reads
     * are streamed responses over `changes` and `tail`.
     */
    readonly connect?: (key: string, subscription: Subscription) => HttpEffect;
}
/**
 * The kernel for one policy, handed to a platform.
 */
export interface PolicyKit {
    readonly name: string;
    /** Run the policy's handler for one delivery. */
    readonly run: (delivery: Delivery) => Effect.Effect<void>;
}
/**
 * What a platform provides for a policy.
 */
export interface PolicyStore {
    /** Run deliveries at least once, in order per key. */
    readonly receive: (delivery: Delivery) => Effect.Effect<void>;
}
/**
 * One delivery a consumer's key accepted, in the key's immutable input log.
 */
export interface Accepted {
    /** The delivery's place in the key's input log, from 1. */
    readonly position: number;
    readonly delivery: Delivery;
    /** Epoch milliseconds it was accepted. */
    readonly at: number;
}
/**
 * How a projection's Layer tunes it (variants, not part of its meaning).
 */
export interface ProjectionOptions {
    /** Hand the handler up to `size` accepted deliveries at once, waiting up to `wait` ms to fill. */
    readonly batch?: {
        readonly size: number;
        readonly waitMillis: number;
    };
}
/**
 * The kernel for one projection, handed to a platform.
 */
export interface ProjectionKit {
    readonly name: string;
    readonly options: ProjectionOptions;
    /**
     * This projection's generation. A key's log from an earlier one is reset;
     * deliveries for an earlier one are dropped.
     */
    readonly generation: number;
    /** Whether each key hears only from the source instance with its own id (see `Kernel.singleSource`). */
    readonly singleSource: boolean;
    /**
     * Route a source instance's stored rows (as its backfill `log` returns them)
     * to one consumer (by `CatchUp.targetId`), as history: each row's seq and its
     * deliveries. What a key keyed by its source runs on the rows it reads.
     */
    readonly history: (target: string, source: string, id: string, rows: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<{
        readonly seq: number;
        readonly deliveries: ReadonlyArray<Delivery>;
    }>>;
    /**
     * Run the handler for a run of one key's input log, in order. Succeeds only
     * when every write the handler made succeeded; the platform then records
     * the run as processed.
     */
    readonly run: (key: string, batch: ReadonlyArray<Accepted>) => Effect.Effect<void>;
}
/**
 * What a platform provides for a projection.
 */
export interface ProjectionStore {
    /**
     * Accept a delivery into its key's input log (dropping one already
     * accepted, by source and `seq`), then process the log in order, in batches.
     */
    readonly receive: (delivery: Delivery) => Effect.Effect<void>;
    /** The last processed `seq` per source stream, for one key. */
    readonly checkpoints: (key: string) => Effect.Effect<Readonly<Record<string, number>>>;
}
/**
 * One entry appended to a stream key.
 */
export interface StreamEntry {
    readonly seq: number;
    readonly event: Json;
    readonly envelope: EnvelopeJson;
}
/**
 * The stored progress of one stream key.
 */
export interface StreamMeta {
    /** Number of entries. */
    readonly seq: number;
    /** The last source `seq` the writer has handled, per source stream. */
    readonly checkpoints: Readonly<Record<string, number>>;
    /** The last write applied: the writer's input-log position and its append index there. */
    readonly origin: readonly [number, number];
    /** The writer generation `origin` belongs to (see `Kernel.generationOf`); 0 when absent. */
    readonly generation?: number;
    /** The last root seq the writer has handled, per aggregate stream, over every generation. */
    readonly roots?: Readonly<Record<string, number>>;
    /**
     * `roots` as of when this generation started writing: a rebuilt writer's
     * replay of these appends nothing again.
     */
    readonly inherited?: Readonly<Record<string, number>>;
}
/** The meta of a stream key nothing has written. */
export declare const emptyStreamMeta: StreamMeta;
/**
 * One append to a stream key, made by its writer while handling an input.
 */
export interface StreamWrite {
    /** The writer's generation: its input log starts over at each one. */
    readonly generation: number;
    /** Where the write comes from: the writer's input-log position and the append's index there. */
    readonly origin: readonly [number, number];
    /** The aggregate event the input being handled derives from. */
    readonly root: Root;
    /** The source event being handled. */
    readonly source: string;
    readonly sourceSeq: number;
    readonly at: number;
    readonly commandId: string;
    readonly events: ReadonlyArray<Json>;
}
/**
 * What a writer's run handled, appends or not.
 */
export interface StreamHandled {
    readonly generation: number;
    /** The last source `seq` handled, per source stream. */
    readonly checkpoints: Readonly<Record<string, number>>;
    /** The last root seq handled, per aggregate stream. */
    readonly roots: Readonly<Record<string, number>>;
}
/**
 * The kernel for one stream, handed to a platform.
 */
export interface StreamKit {
    readonly name: string;
    /**
     * What a subscriber of `key` receives, given its meta and the entries
     * appended since (at least those after the subscription's cursor).
     */
    readonly push: (key: string, subscription: Subscription, meta: StreamMeta, entries: ReadonlyArray<StreamEntry>, latest: StreamEntry | undefined) => Effect.Effect<Push>;
}
/**
 * What a platform provides for a stream.
 */
export interface StreamStore {
    /**
     * Append a write to one key (single writer per key), as the platform's
     * stream rules decide: a repeat, a write from an older generation, or a rebuilt
     * writer's replay of a root an earlier generation handled is dropped.
     */
    readonly append: (key: string, write: StreamWrite) => Effect.Effect<void>;
    /** Record that the writer handled source events without appending. */
    readonly advance: (key: string, handled: StreamHandled) => Effect.Effect<void>;
    readonly read: (key: string) => Effect.Effect<StreamMeta>;
    /** The current meta, then every new one. */
    readonly changes: (key: string) => Stream.Stream<StreamMeta>;
    /** A key's entries in `range`: only these are read from storage. */
    readonly list: (key: string, range?: ListRange) => Effect.Effect<ReadonlyArray<StreamEntry>>;
    /** Entries with `seq > after`, then live entries. */
    readonly tail: (key: string, after: number) => Stream.Stream<StreamEntry>;
    /** Accept a WebSocket upgrade for a live read of `key` (optional, like views). */
    readonly connect?: (key: string, subscription: Subscription) => HttpEffect;
}
/**
 * Where one model is hosted. One factory per concept, each called once per
 * entity while the model's Layer is built. A factory may declare any
 * infrastructure (Durable Objects, buckets, queues) and returns the store the
 * kernel talks to.
 */
export interface ModelHost {
    readonly aggregate: (aggregate: Aggregate.Any, kit: AggregateKit) => Effect.Effect<AggregateStore>;
    /**
     * Called after every aggregate's factory. A platform without it can't host
     * a model that has decisions.
     */
    readonly decision?: (decision: Decision.Any, kit: DecisionKit) => Effect.Effect<DecisionStore>;
    readonly view: (view: View.Any, kit: ViewKit) => Effect.Effect<ViewStore>;
    readonly policy: (policy: Policy.Any, kit: PolicyKit) => Effect.Effect<PolicyStore>;
    readonly projection: (projection: Projection.Any, kit: ProjectionKit) => Effect.Effect<ProjectionStore>;
    readonly stream: (stream: DomainStream.Any, kit: StreamKit) => Effect.Effect<StreamStore>;
    /**
     * Called once every store is built. A platform that keeps events across
     * deploys starts catching up the views and projections in `targets` (every
     * consumer in the model, by `CatchUp.targetId`) that are new to it.
     */
    readonly start?: (targets: ReadonlyArray<string>, 
    /** What a backfill needs to know of each consumer: the sources it reads, and its keys' shape. */
    planOf: (target: string) => Plan | undefined, 
    /**
     * The consumers among `targets` the deploy backfills. The others fill each
     * key themselves, from its own instance (see `ViewKit.catchUp`).
     */
    backfill: ReadonlyArray<string>) => Effect.Effect<void>;
    /**
     * How much of the history recorded before a consumer (by
     * `CatchUp.targetId`) has reached it. A platform without it keeps nothing
     * across deploys, so there is no history to wait for.
     */
    readonly history?: (target: string) => Effect.Effect<HistoryJson>;
}
/** What a platform is told about a model it hosts. */
export interface HostedModel {
    readonly modelName: string;
    /** The same for every Layer of one model, and different for another model with the same name. */
    readonly id: object;
    /** The names of the model's sagas, which run on the workflow engine. */
    readonly sagas: ReadonlyArray<string>;
    /** Whether this model takes over data it shared with other models before Domain version 0: `legacyData` on its `layer`. */
    readonly legacyData: boolean;
}
declare const Platform_base: Context.ServiceClass<Platform, "alchemy/Domain/Platform", {
    readonly model: (model: HostedModel) => Effect.Effect<ModelHost, never, Scope>;
}>;
/**
 * How a Domain is hosted. `model` is called once per model while its Layer is
 * built, and gives that model storage of its own: two models that use the
 * same aggregate, view or stream definition never share its data. Hosting
 * two models with the same name on one platform fails.
 *
 * Swap the platform Layer to move a Domain between infrastructures: in-memory
 * for tests and single processes, Durable Objects on Cloudflare, and so on.
 */
export declare class Platform extends Platform_base {
}
/**
 * Track the models a platform hosts: `claim` fails while a different model
 * with the same name is hosted, since both would address the same storage.
 * The same model may be built again while an earlier build is open.
 *
 * @internal
 */
export declare const hostedModels: ({ release, }: {
    /**
     * Free a model's name when its build closes, so it can be built again as
     * a redeploy. A platform whose builds outlive their scope, like a Worker's
     * init, keeps every name for as long as it runs.
     */
    readonly release: boolean;
}) => (modelName: string, id: object) => Effect.Effect<void, never, Scope>;
/**
 * How a platform counts a run that waits for another run's work: a read
 * `atLeast` a write that polls until its view or projection has it. The
 * manual in-memory platform (a story) runs one queued item at a time, until
 * every run it started is finished or waiting; it provides this so a poll is
 * waiting and the run it waits for can start. Other platforms run their work
 * concurrently and leave it as is.
 *
 * @internal
 */
export declare const RunWait: Context.Reference<<A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>>;
/** {@link RunWait} on a platform that does not manage its runs' waits. @internal */
export declare const runDirectly: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
export {};
//# sourceMappingURL=Platform.d.ts.map