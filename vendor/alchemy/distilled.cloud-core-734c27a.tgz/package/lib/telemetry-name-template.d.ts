/**
 * The `com.distilled.telemetry#operation` trait's `nameTemplate`, as a
 * function: generated code imports this only where a trait has one
 * (messaging operations). See `packages/dev/src/codegen/telemetry-traits.md`.
 */
import type { SpanRename } from "./telemetry.ts";
/**
 * Span name from `{attribute}` placeholders filled from the call's input
 * attributes (`send {messaging.destination.name}`); undefined (the trait's
 * `name`) when one is missing.
 */
export declare const nameTemplate: (template: string) => SpanRename;
//# sourceMappingURL=telemetry-name-template.d.ts.map