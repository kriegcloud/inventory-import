import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AccountHasOngoingImportException_base: S.TaggedErrorClass<"AccountHasOngoingImportException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountHasOngoingImportException extends /*@__PURE__*/ AccountHasOngoingImportException_base {
}
declare const AccountNotFoundException_base: S.TaggedErrorClass<"AccountNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotFoundException extends /*@__PURE__*/ AccountNotFoundException_base {
}
declare const AccountNotRegisteredException_base: S.TaggedErrorClass<"AccountNotRegisteredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotRegisteredException extends /*@__PURE__*/ AccountNotRegisteredException_base {
}
declare const AccountRegisteredException_base: S.TaggedErrorClass<"AccountRegisteredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountRegisteredException extends /*@__PURE__*/ AccountRegisteredException_base {
}
declare const CannotDelegateManagementAccountException_base: S.TaggedErrorClass<"CannotDelegateManagementAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotDelegateManagementAccountException extends /*@__PURE__*/ CannotDelegateManagementAccountException_base {
}
declare const ChannelAlreadyExistsException_base: S.TaggedErrorClass<"ChannelAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ChannelAlreadyExistsException extends /*@__PURE__*/ ChannelAlreadyExistsException_base {
}
declare const ChannelARNInvalidException_base: S.TaggedErrorClass<"ChannelARNInvalidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelARNInvalidException extends /*@__PURE__*/ ChannelARNInvalidException_base {
}
declare const ChannelExistsForEDSException_base: S.TaggedErrorClass<"ChannelExistsForEDSException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelExistsForEDSException extends /*@__PURE__*/ ChannelExistsForEDSException_base {
}
declare const ChannelMaxLimitExceededException_base: S.TaggedErrorClass<"ChannelMaxLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelMaxLimitExceededException extends /*@__PURE__*/ ChannelMaxLimitExceededException_base {
}
declare const ChannelNotFoundException_base: S.TaggedErrorClass<"ChannelNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelNotFoundException extends /*@__PURE__*/ ChannelNotFoundException_base {
}
declare const CloudTrailAccessNotEnabledException_base: S.TaggedErrorClass<"CloudTrailAccessNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailAccessNotEnabledException extends /*@__PURE__*/ CloudTrailAccessNotEnabledException_base {
}
declare const CloudTrailARNInvalidException_base: S.TaggedErrorClass<"CloudTrailARNInvalidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailARNInvalidException extends /*@__PURE__*/ CloudTrailARNInvalidException_base {
}
declare const CloudTrailInvalidClientTokenIdException_base: S.TaggedErrorClass<"CloudTrailInvalidClientTokenIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailInvalidClientTokenIdException extends /*@__PURE__*/ CloudTrailInvalidClientTokenIdException_base {
}
declare const CloudTrailLakeOnboardingClosed_base: S.TaggedErrorClass<"CloudTrailLakeOnboardingClosed", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailLakeOnboardingClosed extends /*@__PURE__*/ CloudTrailLakeOnboardingClosed_base {
}
declare const CloudWatchLogsDeliveryUnavailableException_base: S.TaggedErrorClass<"CloudWatchLogsDeliveryUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudWatchLogsDeliveryUnavailableException extends /*@__PURE__*/ CloudWatchLogsDeliveryUnavailableException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DelegatedAdminAccountLimitExceededException_base: S.TaggedErrorClass<"DelegatedAdminAccountLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DelegatedAdminAccountLimitExceededException extends /*@__PURE__*/ DelegatedAdminAccountLimitExceededException_base {
}
declare const EventDataStoreAlreadyExistsException_base: S.TaggedErrorClass<"EventDataStoreAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EventDataStoreAlreadyExistsException extends /*@__PURE__*/ EventDataStoreAlreadyExistsException_base {
}
declare const EventDataStoreARNInvalidException_base: S.TaggedErrorClass<"EventDataStoreARNInvalidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreARNInvalidException extends /*@__PURE__*/ EventDataStoreARNInvalidException_base {
}
declare const EventDataStoreFederationEnabledException_base: S.TaggedErrorClass<"EventDataStoreFederationEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreFederationEnabledException extends /*@__PURE__*/ EventDataStoreFederationEnabledException_base {
}
declare const EventDataStoreHasOngoingImportException_base: S.TaggedErrorClass<"EventDataStoreHasOngoingImportException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreHasOngoingImportException extends /*@__PURE__*/ EventDataStoreHasOngoingImportException_base {
}
declare const EventDataStoreMaxLimitExceededException_base: S.TaggedErrorClass<"EventDataStoreMaxLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreMaxLimitExceededException extends /*@__PURE__*/ EventDataStoreMaxLimitExceededException_base {
}
declare const EventDataStoreNotFoundException_base: S.TaggedErrorClass<"EventDataStoreNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreNotFoundException extends /*@__PURE__*/ EventDataStoreNotFoundException_base {
}
declare const EventDataStoreTerminationProtectedException_base: S.TaggedErrorClass<"EventDataStoreTerminationProtectedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreTerminationProtectedException extends /*@__PURE__*/ EventDataStoreTerminationProtectedException_base {
}
declare const GenerateResponseException_base: S.TaggedErrorClass<"GenerateResponseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GenerateResponseException extends /*@__PURE__*/ GenerateResponseException_base {
}
declare const ImportNotFoundException_base: S.TaggedErrorClass<"ImportNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ImportNotFoundException extends /*@__PURE__*/ ImportNotFoundException_base {
}
declare const InactiveEventDataStoreException_base: S.TaggedErrorClass<"InactiveEventDataStoreException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InactiveEventDataStoreException extends /*@__PURE__*/ InactiveEventDataStoreException_base {
}
declare const InactiveQueryException_base: S.TaggedErrorClass<"InactiveQueryException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InactiveQueryException extends /*@__PURE__*/ InactiveQueryException_base {
}
declare const InsightNotEnabledException_base: S.TaggedErrorClass<"InsightNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsightNotEnabledException extends /*@__PURE__*/ InsightNotEnabledException_base {
}
declare const InsufficientDependencyServiceAccessPermissionException_base: S.TaggedErrorClass<"InsufficientDependencyServiceAccessPermissionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDependencyServiceAccessPermissionException extends /*@__PURE__*/ InsufficientDependencyServiceAccessPermissionException_base {
}
declare const InsufficientEncryptionPolicyException_base: S.TaggedErrorClass<"InsufficientEncryptionPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientEncryptionPolicyException extends /*@__PURE__*/ InsufficientEncryptionPolicyException_base {
}
declare const InsufficientIAMAccessPermissionException_base: S.TaggedErrorClass<"InsufficientIAMAccessPermissionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientIAMAccessPermissionException extends /*@__PURE__*/ InsufficientIAMAccessPermissionException_base {
}
declare const InsufficientS3BucketPolicyException_base: S.TaggedErrorClass<"InsufficientS3BucketPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientS3BucketPolicyException extends /*@__PURE__*/ InsufficientS3BucketPolicyException_base {
}
declare const InsufficientSnsTopicPolicyException_base: S.TaggedErrorClass<"InsufficientSnsTopicPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientSnsTopicPolicyException extends /*@__PURE__*/ InsufficientSnsTopicPolicyException_base {
}
declare const InvalidCloudWatchLogsLogGroupArnException_base: S.TaggedErrorClass<"InvalidCloudWatchLogsLogGroupArnException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCloudWatchLogsLogGroupArnException extends /*@__PURE__*/ InvalidCloudWatchLogsLogGroupArnException_base {
}
declare const InvalidCloudWatchLogsRoleArnException_base: S.TaggedErrorClass<"InvalidCloudWatchLogsRoleArnException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCloudWatchLogsRoleArnException extends /*@__PURE__*/ InvalidCloudWatchLogsRoleArnException_base {
}
declare const InvalidDateRangeException_base: S.TaggedErrorClass<"InvalidDateRangeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDateRangeException extends /*@__PURE__*/ InvalidDateRangeException_base {
}
declare const InvalidEventCategoryException_base: S.TaggedErrorClass<"InvalidEventCategoryException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventCategoryException extends /*@__PURE__*/ InvalidEventCategoryException_base {
}
declare const InvalidEventDataStoreCategoryException_base: S.TaggedErrorClass<"InvalidEventDataStoreCategoryException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventDataStoreCategoryException extends /*@__PURE__*/ InvalidEventDataStoreCategoryException_base {
}
declare const InvalidEventDataStoreStatusException_base: S.TaggedErrorClass<"InvalidEventDataStoreStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventDataStoreStatusException extends /*@__PURE__*/ InvalidEventDataStoreStatusException_base {
}
declare const InvalidEventSelectorsException_base: S.TaggedErrorClass<"InvalidEventSelectorsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSelectorsException extends /*@__PURE__*/ InvalidEventSelectorsException_base {
}
declare const InvalidHomeRegionException_base: S.TaggedErrorClass<"InvalidHomeRegionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHomeRegionException extends /*@__PURE__*/ InvalidHomeRegionException_base {
}
declare const InvalidImportSourceException_base: S.TaggedErrorClass<"InvalidImportSourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidImportSourceException extends /*@__PURE__*/ InvalidImportSourceException_base {
}
declare const InvalidInsightSelectorsException_base: S.TaggedErrorClass<"InvalidInsightSelectorsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInsightSelectorsException extends /*@__PURE__*/ InvalidInsightSelectorsException_base {
}
declare const InvalidKmsKeyIdException_base: S.TaggedErrorClass<"InvalidKmsKeyIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKmsKeyIdException extends /*@__PURE__*/ InvalidKmsKeyIdException_base {
}
declare const InvalidLookupAttributesException_base: S.TaggedErrorClass<"InvalidLookupAttributesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLookupAttributesException extends /*@__PURE__*/ InvalidLookupAttributesException_base {
}
declare const InvalidMaxResultsException_base: S.TaggedErrorClass<"InvalidMaxResultsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMaxResultsException extends /*@__PURE__*/ InvalidMaxResultsException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidQueryStatementException_base: S.TaggedErrorClass<"InvalidQueryStatementException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStatementException extends /*@__PURE__*/ InvalidQueryStatementException_base {
}
declare const InvalidQueryStatusException_base: S.TaggedErrorClass<"InvalidQueryStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStatusException extends /*@__PURE__*/ InvalidQueryStatusException_base {
}
declare const InvalidS3BucketNameException_base: S.TaggedErrorClass<"InvalidS3BucketNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketNameException extends /*@__PURE__*/ InvalidS3BucketNameException_base {
}
declare const InvalidS3PrefixException_base: S.TaggedErrorClass<"InvalidS3PrefixException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3PrefixException extends /*@__PURE__*/ InvalidS3PrefixException_base {
}
declare const InvalidSnsTopicNameException_base: S.TaggedErrorClass<"InvalidSnsTopicNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnsTopicNameException extends /*@__PURE__*/ InvalidSnsTopicNameException_base {
}
declare const InvalidSourceException_base: S.TaggedErrorClass<"InvalidSourceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSourceException extends /*@__PURE__*/ InvalidSourceException_base {
}
declare const InvalidTagParameterException_base: S.TaggedErrorClass<"InvalidTagParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTagParameterException extends /*@__PURE__*/ InvalidTagParameterException_base {
}
declare const InvalidTimeRangeException_base: S.TaggedErrorClass<"InvalidTimeRangeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const InvalidTokenException_base: S.TaggedErrorClass<"InvalidTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const InvalidTrailNameException_base: S.TaggedErrorClass<"InvalidTrailNameException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTrailNameException extends /*@__PURE__*/ InvalidTrailNameException_base {
}
declare const KmsException_base: S.TaggedErrorClass<"KmsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsException extends /*@__PURE__*/ KmsException_base {
}
declare const KmsKeyDisabledException_base: S.TaggedErrorClass<"KmsKeyDisabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyDisabledException extends /*@__PURE__*/ KmsKeyDisabledException_base {
}
declare const KmsKeyNotFoundException_base: S.TaggedErrorClass<"KmsKeyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyNotFoundException extends /*@__PURE__*/ KmsKeyNotFoundException_base {
}
declare const MaxConcurrentQueriesException_base: S.TaggedErrorClass<"MaxConcurrentQueriesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class MaxConcurrentQueriesException extends /*@__PURE__*/ MaxConcurrentQueriesException_base {
}
declare const MaximumNumberOfTrailsExceededException_base: S.TaggedErrorClass<"MaximumNumberOfTrailsExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class MaximumNumberOfTrailsExceededException extends /*@__PURE__*/ MaximumNumberOfTrailsExceededException_base {
}
declare const NoManagementAccountSLRExistsException_base: S.TaggedErrorClass<"NoManagementAccountSLRExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NoManagementAccountSLRExistsException extends /*@__PURE__*/ NoManagementAccountSLRExistsException_base {
}
declare const NotOrganizationManagementAccountException_base: S.TaggedErrorClass<"NotOrganizationManagementAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotOrganizationManagementAccountException extends /*@__PURE__*/ NotOrganizationManagementAccountException_base {
}
declare const NotOrganizationMasterAccountException_base: S.TaggedErrorClass<"NotOrganizationMasterAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotOrganizationMasterAccountException extends /*@__PURE__*/ NotOrganizationMasterAccountException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const OrganizationNotInAllFeaturesModeException_base: S.TaggedErrorClass<"OrganizationNotInAllFeaturesModeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotInAllFeaturesModeException extends /*@__PURE__*/ OrganizationNotInAllFeaturesModeException_base {
}
declare const OrganizationsNotInUseException_base: S.TaggedErrorClass<"OrganizationsNotInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationsNotInUseException extends /*@__PURE__*/ OrganizationsNotInUseException_base {
}
declare const QueryIdNotFoundException_base: S.TaggedErrorClass<"QueryIdNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryIdNotFoundException extends /*@__PURE__*/ QueryIdNotFoundException_base {
}
declare const ResourceARNNotValidException_base: S.TaggedErrorClass<"ResourceARNNotValidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceARNNotValidException extends /*@__PURE__*/ ResourceARNNotValidException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourcePolicyNotFoundException_base: S.TaggedErrorClass<"ResourcePolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourcePolicyNotFoundException extends /*@__PURE__*/ ResourcePolicyNotFoundException_base {
}
declare const ResourcePolicyNotValidException_base: S.TaggedErrorClass<"ResourcePolicyNotValidException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourcePolicyNotValidException extends /*@__PURE__*/ ResourcePolicyNotValidException_base {
}
declare const ResourceTypeNotSupportedException_base: S.TaggedErrorClass<"ResourceTypeNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceTypeNotSupportedException extends /*@__PURE__*/ ResourceTypeNotSupportedException_base {
}
declare const S3BucketDoesNotExistException_base: S.TaggedErrorClass<"S3BucketDoesNotExistException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3BucketDoesNotExistException extends /*@__PURE__*/ S3BucketDoesNotExistException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagsLimitExceededException_base: S.TaggedErrorClass<"TagsLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagsLimitExceededException extends /*@__PURE__*/ TagsLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TrailAlreadyExistsException_base: S.TaggedErrorClass<"TrailAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TrailAlreadyExistsException extends /*@__PURE__*/ TrailAlreadyExistsException_base {
}
declare const TrailNotFoundException_base: S.TaggedErrorClass<"TrailNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrailNotFoundException extends /*@__PURE__*/ TrailNotFoundException_base {
}
declare const TrailNotProvidedException_base: S.TaggedErrorClass<"TrailNotProvidedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrailNotProvidedException extends /*@__PURE__*/ TrailNotProvidedException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type TagsList = Tag[];
export interface AddTagsRequest {
    ResourceId: string;
    TagsList: Tag[];
}
export interface AddTagsResponse {
}
export type EventDataStoreArn = string;
export type UUID = string;
export type AccountId = string;
export interface CancelQueryRequest {
    EventDataStore?: string | undefined;
    QueryId: string;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export type QueryStatus = "QUEUED" | "RUNNING" | "FINISHED" | "FAILED" | "CANCELLED" | "TIMED_OUT" | (string & {});
export interface CancelQueryResponse {
    QueryId: string;
    QueryStatus: QueryStatus;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export type ChannelName = string;
export type Source = string;
export type DestinationType = "EVENT_DATA_STORE" | "AWS_SERVICE" | (string & {});
export type Location = string;
export interface Destination {
    Type: DestinationType;
    Location: string;
}
export type Destinations = Destination[];
export interface CreateChannelRequest {
    Name: string;
    Source: string;
    Destinations: Destination[];
    Tags?: Tag[] | undefined;
}
export type ChannelArn = string;
export interface CreateChannelResponse {
    ChannelArn?: string | undefined;
    Name?: string | undefined;
    Source?: string | undefined;
    Destinations?: Destination[] | undefined;
    Tags?: Tag[] | undefined;
}
export type DashboardName = string;
export type RefreshScheduleFrequencyUnit = "HOURS" | "DAYS" | (string & {});
export type RefreshScheduleFrequencyValue = number;
export interface RefreshScheduleFrequency {
    Unit?: RefreshScheduleFrequencyUnit | undefined;
    Value?: number | undefined;
}
export type RefreshScheduleStatus = "ENABLED" | "DISABLED" | (string & {});
export type TimeOfDay = string;
export interface RefreshSchedule {
    Frequency?: RefreshScheduleFrequency | undefined;
    Status?: RefreshScheduleStatus | undefined;
    TimeOfDay?: string | undefined;
}
export type TerminationProtectionEnabled = boolean;
export type QueryStatement = string;
export type QueryParameter = string;
export type QueryParameters = string[];
export type ViewPropertiesKey = string;
export type ViewPropertiesValue = string;
export type ViewPropertiesMap = {
    [key: string]: string | undefined;
};
export interface RequestWidget {
    QueryStatement: string;
    QueryParameters?: string[] | undefined;
    ViewProperties: {
        [key: string]: string | undefined;
    };
}
export type RequestWidgetList = RequestWidget[];
export interface CreateDashboardRequest {
    Name: string;
    RefreshSchedule?: RefreshSchedule | undefined;
    TagsList?: Tag[] | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    Widgets?: RequestWidget[] | undefined;
}
export type DashboardArn = string;
export type DashboardType = "MANAGED" | "CUSTOM" | (string & {});
export type QueryAlias = string;
export interface Widget {
    QueryAlias?: string | undefined;
    QueryStatement?: string | undefined;
    QueryParameters?: string[] | undefined;
    ViewProperties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WidgetList = Widget[];
export interface CreateDashboardResponse {
    DashboardArn?: string | undefined;
    Name?: string | undefined;
    Type?: DashboardType | undefined;
    Widgets?: Widget[] | undefined;
    TagsList?: Tag[] | undefined;
    RefreshSchedule?: RefreshSchedule | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
}
export type EventDataStoreName = string;
export type SelectorName = string;
export type SelectorField = string;
export type OperatorValue = string;
export type Operator = string[];
export interface AdvancedFieldSelector {
    Field: string;
    Equals?: string[] | undefined;
    StartsWith?: string[] | undefined;
    EndsWith?: string[] | undefined;
    NotEquals?: string[] | undefined;
    NotStartsWith?: string[] | undefined;
    NotEndsWith?: string[] | undefined;
}
export type AdvancedFieldSelectors = AdvancedFieldSelector[];
export interface AdvancedEventSelector {
    Name?: string | undefined;
    FieldSelectors: AdvancedFieldSelector[];
}
export type AdvancedEventSelectors = AdvancedEventSelector[];
export type RetentionPeriod = number;
export type EventDataStoreKmsKeyId = string;
export type BillingMode = "EXTENDABLE_RETENTION_PRICING" | "FIXED_RETENTION_PRICING" | (string & {});
export interface CreateEventDataStoreRequest {
    Name: string;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    TagsList?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    StartIngestion?: boolean | undefined;
    BillingMode?: BillingMode | undefined;
}
export type EventDataStoreStatus = "CREATED" | "ENABLED" | "PENDING_DELETION" | "STARTING_INGESTION" | "STOPPING_INGESTION" | "STOPPED_INGESTION" | (string & {});
export interface CreateEventDataStoreResponse {
    EventDataStoreArn?: string | undefined;
    Name?: string | undefined;
    Status?: EventDataStoreStatus | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    TagsList?: Tag[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    KmsKeyId?: string | undefined;
    BillingMode?: BillingMode | undefined;
}
export interface CreateTrailRequest {
    Name: string;
    S3BucketName: string;
    S3KeyPrefix?: string | undefined;
    SnsTopicName?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    EnableLogFileValidation?: boolean | undefined;
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    IsOrganizationTrail?: boolean | undefined;
    TagsList?: Tag[] | undefined;
    RecursiveLogging?: boolean | undefined;
}
export interface CreateTrailResponse {
    Name?: string | undefined;
    S3BucketName?: string | undefined;
    S3KeyPrefix?: string | undefined;
    SnsTopicName?: string | undefined;
    SnsTopicARN?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    TrailARN?: string | undefined;
    LogFileValidationEnabled?: boolean | undefined;
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    IsOrganizationTrail?: boolean | undefined;
    RecursiveLogging?: boolean | undefined;
}
export interface DeleteChannelRequest {
    Channel: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteDashboardRequest {
    DashboardId: string;
}
export interface DeleteDashboardResponse {
}
export interface DeleteEventDataStoreRequest {
    EventDataStore: string;
}
export interface DeleteEventDataStoreResponse {
}
export type ResourceArn = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteTrailRequest {
    Name: string;
}
export interface DeleteTrailResponse {
}
export interface DeregisterOrganizationDelegatedAdminRequest {
    DelegatedAdminAccountId: string;
}
export interface DeregisterOrganizationDelegatedAdminResponse {
}
export type RefreshId = string;
export interface DescribeQueryRequest {
    EventDataStore?: string | undefined;
    QueryId?: string | undefined;
    QueryAlias?: string | undefined;
    RefreshId?: string | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export interface QueryStatisticsForDescribeQuery {
    EventsMatched?: number | undefined;
    EventsScanned?: number | undefined;
    BytesScanned?: number | undefined;
    ExecutionTimeInMillis?: number | undefined;
    CreationTime?: Date | undefined;
}
export type ErrorMessage = string;
export type DeliveryS3Uri = string;
export type DeliveryStatus = "SUCCESS" | "FAILED" | "FAILED_SIGNING_FILE" | "PENDING" | "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "ACCESS_DENIED_SIGNING_FILE" | "CANCELLED" | "UNKNOWN" | (string & {});
export type Prompt = string;
export interface DescribeQueryResponse {
    QueryId?: string | undefined;
    QueryString?: string | undefined;
    QueryStatus?: QueryStatus | undefined;
    QueryStatistics?: QueryStatisticsForDescribeQuery | undefined;
    ErrorMessage?: string | undefined;
    DeliveryS3Uri?: string | undefined;
    DeliveryStatus?: DeliveryStatus | undefined;
    Prompt?: string | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export type TrailNameList = string[];
export interface DescribeTrailsRequest {
    trailNameList?: string[] | undefined;
    includeShadowTrails?: boolean | undefined;
}
export interface Trail {
    Name?: string | undefined;
    S3BucketName?: string | undefined;
    S3KeyPrefix?: string | undefined;
    SnsTopicName?: string | undefined;
    SnsTopicARN?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    HomeRegion?: string | undefined;
    TrailARN?: string | undefined;
    LogFileValidationEnabled?: boolean | undefined;
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    HasCustomEventSelectors?: boolean | undefined;
    HasInsightSelectors?: boolean | undefined;
    IsOrganizationTrail?: boolean | undefined;
    RecursiveLogging?: boolean | undefined;
}
export type TrailList = Trail[];
export interface DescribeTrailsResponse {
    trailList?: Trail[] | undefined;
}
export interface DisableFederationRequest {
    EventDataStore: string;
}
export type FederationStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export interface DisableFederationResponse {
    EventDataStoreArn?: string | undefined;
    FederationStatus?: FederationStatus | undefined;
}
export type FederationRoleArn = string;
export interface EnableFederationRequest {
    EventDataStore: string;
    FederationRoleArn: string;
}
export interface EnableFederationResponse {
    EventDataStoreArn?: string | undefined;
    FederationStatus?: FederationStatus | undefined;
    FederationRoleArn?: string | undefined;
}
export type EventDataStoreList = string[];
export interface GenerateQueryRequest {
    EventDataStores: string[];
    Prompt: string;
}
export interface GenerateQueryResponse {
    QueryStatement?: string | undefined;
    QueryAlias?: string | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export interface GetChannelRequest {
    Channel: string;
}
export interface SourceConfig {
    ApplyToAllRegions?: boolean | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
}
export interface IngestionStatus {
    LatestIngestionSuccessTime?: Date | undefined;
    LatestIngestionSuccessEventID?: string | undefined;
    LatestIngestionErrorCode?: string | undefined;
    LatestIngestionAttemptTime?: Date | undefined;
    LatestIngestionAttemptEventID?: string | undefined;
}
export interface GetChannelResponse {
    ChannelArn?: string | undefined;
    Name?: string | undefined;
    Source?: string | undefined;
    SourceConfig?: SourceConfig | undefined;
    Destinations?: Destination[] | undefined;
    IngestionStatus?: IngestionStatus | undefined;
}
export interface GetDashboardRequest {
    DashboardId: string;
}
export type DashboardStatus = "CREATING" | "CREATED" | "UPDATING" | "UPDATED" | "DELETING" | (string & {});
export interface GetDashboardResponse {
    DashboardArn?: string | undefined;
    Type?: DashboardType | undefined;
    Status?: DashboardStatus | undefined;
    Widgets?: Widget[] | undefined;
    RefreshSchedule?: RefreshSchedule | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    LastRefreshId?: string | undefined;
    LastRefreshFailureReason?: string | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
}
export interface GetEventConfigurationRequest {
    TrailName?: string | undefined;
    EventDataStore?: string | undefined;
}
export type MaxEventSize = "Standard" | "Large" | (string & {});
export type Type = "TagContext" | "RequestContext" | (string & {});
export type OperatorTargetListMember = string;
export type OperatorTargetList = string[];
export interface ContextKeySelector {
    Type: Type;
    Equals: string[];
}
export type ContextKeySelectors = ContextKeySelector[];
export type Template = "API_ACTIVITY" | "RESOURCE_ACCESS" | "USER_ACTIONS" | (string & {});
export type Templates = Template[];
export type EventCategoryAggregation = "Data" | (string & {});
export interface AggregationConfiguration {
    Templates: Template[];
    EventCategory: EventCategoryAggregation;
}
export type AggregationConfigurations = AggregationConfiguration[];
export interface GetEventConfigurationResponse {
    TrailARN?: string | undefined;
    EventDataStoreArn?: string | undefined;
    MaxEventSize?: MaxEventSize | undefined;
    ContextKeySelectors?: ContextKeySelector[] | undefined;
    AggregationConfigurations?: AggregationConfiguration[] | undefined;
}
export interface GetEventDataStoreRequest {
    EventDataStore: string;
}
export type PartitionKeyName = string;
export type PartitionKeyType = string;
export interface PartitionKey {
    Name: string;
    Type: string;
}
export type PartitionKeyList = PartitionKey[];
export interface GetEventDataStoreResponse {
    EventDataStoreArn?: string | undefined;
    Name?: string | undefined;
    Status?: EventDataStoreStatus | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    KmsKeyId?: string | undefined;
    BillingMode?: BillingMode | undefined;
    FederationStatus?: FederationStatus | undefined;
    FederationRoleArn?: string | undefined;
    PartitionKeys?: PartitionKey[] | undefined;
}
export interface GetEventSelectorsRequest {
    TrailName: string;
}
export type ReadWriteType = "ReadOnly" | "WriteOnly" | "All" | (string & {});
export type DataResourceValues = string[];
export interface DataResource {
    Type?: string | undefined;
    Values?: string[] | undefined;
}
export type DataResources = DataResource[];
export type ExcludeManagementEventSources = string[];
export interface EventSelector {
    ReadWriteType?: ReadWriteType | undefined;
    IncludeManagementEvents?: boolean | undefined;
    DataResources?: DataResource[] | undefined;
    ExcludeManagementEventSources?: string[] | undefined;
}
export type EventSelectors = EventSelector[];
export interface GetEventSelectorsResponse {
    TrailARN?: string | undefined;
    EventSelectors?: EventSelector[] | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
}
export interface GetImportRequest {
    ImportId: string;
}
export type ImportDestinations = string[];
export interface S3ImportSource {
    S3LocationUri: string;
    S3BucketRegion: string;
    S3BucketAccessRoleArn: string;
}
export interface ImportSource {
    S3: S3ImportSource;
}
export type ImportStatus = "INITIALIZING" | "IN_PROGRESS" | "FAILED" | "STOPPED" | "COMPLETED" | (string & {});
export interface ImportStatistics {
    PrefixesFound?: number | undefined;
    PrefixesCompleted?: number | undefined;
    FilesCompleted?: number | undefined;
    EventsCompleted?: number | undefined;
    FailedEntries?: number | undefined;
}
export interface GetImportResponse {
    ImportId?: string | undefined;
    Destinations?: string[] | undefined;
    ImportSource?: ImportSource | undefined;
    StartEventTime?: Date | undefined;
    EndEventTime?: Date | undefined;
    ImportStatus?: ImportStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    ImportStatistics?: ImportStatistics | undefined;
}
export interface GetInsightSelectorsRequest {
    TrailName?: string | undefined;
    EventDataStore?: string | undefined;
}
export type InsightType = "ApiCallRateInsight" | "ApiErrorRateInsight" | (string & {});
export type SourceEventCategory = "Management" | "Data" | (string & {});
export type SourceEventCategories = SourceEventCategory[];
export interface InsightSelector {
    InsightType?: InsightType | undefined;
    EventCategories?: SourceEventCategory[] | undefined;
}
export type InsightSelectors = InsightSelector[];
export interface GetInsightSelectorsResponse {
    TrailARN?: string | undefined;
    InsightSelectors?: InsightSelector[] | undefined;
    EventDataStoreArn?: string | undefined;
    InsightsDestination?: string | undefined;
}
export type PaginationToken = string;
export type MaxQueryResults = number;
export interface GetQueryResultsRequest {
    EventDataStore?: string | undefined;
    QueryId: string;
    NextToken?: string | undefined;
    MaxQueryResults?: number | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export interface QueryStatistics {
    ResultsCount?: number | undefined;
    TotalResultsCount?: number | undefined;
    BytesScanned?: number | undefined;
}
export type QueryResultKey = string;
export type QueryResultValue = string;
export type QueryResultColumn = {
    [key: string]: string | undefined;
};
export type QueryResultRow = {
    [key: string]: string | undefined;
}[];
export type QueryResultRows = {
    [key: string]: string | undefined;
}[][];
export interface GetQueryResultsResponse {
    QueryStatus?: QueryStatus | undefined;
    QueryStatistics?: QueryStatistics | undefined;
    QueryResultRows?: {
        [key: string]: string | undefined;
    }[][] | undefined;
    NextToken?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    ResourceArn?: string | undefined;
    ResourcePolicy?: string | undefined;
    DelegatedAdminResourcePolicy?: string | undefined;
}
export interface GetTrailRequest {
    Name: string;
}
export interface GetTrailResponse {
    Trail?: Trail | undefined;
}
export interface GetTrailStatusRequest {
    Name: string;
}
export interface GetTrailStatusResponse {
    IsLogging?: boolean | undefined;
    LatestDeliveryError?: string | undefined;
    LatestNotificationError?: string | undefined;
    LatestDeliveryTime?: Date | undefined;
    LatestNotificationTime?: Date | undefined;
    StartLoggingTime?: Date | undefined;
    StopLoggingTime?: Date | undefined;
    LatestCloudWatchLogsDeliveryError?: string | undefined;
    LatestCloudWatchLogsDeliveryTime?: Date | undefined;
    LatestDigestDeliveryTime?: Date | undefined;
    LatestDigestDeliveryError?: string | undefined;
    LatestDeliveryAttemptTime?: string | undefined;
    LatestNotificationAttemptTime?: string | undefined;
    LatestNotificationAttemptSucceeded?: string | undefined;
    LatestDeliveryAttemptSucceeded?: string | undefined;
    TimeLoggingStarted?: string | undefined;
    TimeLoggingStopped?: string | undefined;
}
export type ListChannelsMaxResultsCount = number;
export interface ListChannelsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Channel {
    ChannelArn?: string | undefined;
    Name?: string | undefined;
}
export type Channels = Channel[];
export interface ListChannelsResponse {
    Channels?: Channel[] | undefined;
    NextToken?: string | undefined;
}
export type ListDashboardsMaxResultsCount = number;
export interface ListDashboardsRequest {
    NamePrefix?: string | undefined;
    Type?: DashboardType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DashboardDetail {
    DashboardArn?: string | undefined;
    Type?: DashboardType | undefined;
}
export type Dashboards = DashboardDetail[];
export interface ListDashboardsResponse {
    Dashboards?: DashboardDetail[] | undefined;
    NextToken?: string | undefined;
}
export type ListEventDataStoresMaxResultsCount = number;
export interface ListEventDataStoresRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EventDataStore {
    EventDataStoreArn?: string | undefined;
    Name?: string | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    Status?: EventDataStoreStatus | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export type EventDataStores = EventDataStore[];
export interface ListEventDataStoresResponse {
    EventDataStores?: EventDataStore[] | undefined;
    NextToken?: string | undefined;
}
export type ListImportFailuresMaxResultsCount = number;
export interface ListImportFailuresRequest {
    ImportId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ImportFailureStatus = "FAILED" | "RETRY" | "SUCCEEDED" | (string & {});
export interface ImportFailureListItem {
    Location?: string | undefined;
    Status?: ImportFailureStatus | undefined;
    ErrorType?: string | undefined;
    ErrorMessage?: string | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type ImportFailureList = ImportFailureListItem[];
export interface ListImportFailuresResponse {
    Failures?: ImportFailureListItem[] | undefined;
    NextToken?: string | undefined;
}
export type ListImportsMaxResultsCount = number;
export interface ListImportsRequest {
    MaxResults?: number | undefined;
    Destination?: string | undefined;
    ImportStatus?: ImportStatus | undefined;
    NextToken?: string | undefined;
}
export interface ImportsListItem {
    ImportId?: string | undefined;
    ImportStatus?: ImportStatus | undefined;
    Destinations?: string[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export type ImportsList = ImportsListItem[];
export interface ListImportsResponse {
    Imports?: ImportsListItem[] | undefined;
    NextToken?: string | undefined;
}
export type ListInsightsDataType = "InsightsEvents" | (string & {});
export type ListInsightsDataDimensionKey = "EventId" | "EventName" | "EventSource" | (string & {});
export type ListInsightsDataDimensionValue = string;
export type ListInsightsDataDimensions = {
    [key in ListInsightsDataDimensionKey]?: string | undefined;
};
export type ListInsightsDataMaxResultsCount = number;
export interface ListInsightsDataRequest {
    InsightSource: string;
    DataType: ListInsightsDataType;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Resource {
    ResourceType?: string | undefined;
    ResourceName?: string | undefined;
}
export type ResourceList = Resource[];
export interface Event {
    EventId?: string | undefined;
    EventName?: string | undefined;
    ReadOnly?: string | undefined;
    AccessKeyId?: string | undefined;
    EventTime?: Date | undefined;
    EventSource?: string | undefined;
    Username?: string | undefined;
    Resources?: Resource[] | undefined;
    CloudTrailEvent?: string | undefined;
}
export type EventsList = Event[];
export interface ListInsightsDataResponse {
    Events?: Event[] | undefined;
    NextToken?: string | undefined;
}
export type EventSource = string;
export type EventName = string;
export type ErrorCode = string;
export type InsightsMetricPeriod = number;
export type InsightsMetricDataType = "FillWithZeros" | "NonZeroData" | (string & {});
export type InsightsMetricMaxResults = number;
export type InsightsMetricNextToken = string;
export interface ListInsightsMetricDataRequest {
    TrailName?: string | undefined;
    EventSource: string;
    EventName: string;
    InsightType: InsightType;
    ErrorCode?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Period?: number | undefined;
    DataType?: InsightsMetricDataType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type Timestamps = Date[];
export type InsightsMetricValues = number[];
export interface ListInsightsMetricDataResponse {
    TrailARN?: string | undefined;
    EventSource?: string | undefined;
    EventName?: string | undefined;
    InsightType?: InsightType | undefined;
    ErrorCode?: string | undefined;
    Timestamps?: Date[] | undefined;
    Values?: number[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPublicKeysRequest {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
}
export type ByteBuffer = Uint8Array;
export interface PublicKey {
    Value?: Uint8Array | undefined;
    ValidityStartTime?: Date | undefined;
    ValidityEndTime?: Date | undefined;
    Fingerprint?: string | undefined;
}
export type PublicKeyList = PublicKey[];
export interface ListPublicKeysResponse {
    PublicKeyList?: PublicKey[] | undefined;
    NextToken?: string | undefined;
}
export type ListQueriesMaxResultsCount = number;
export interface ListQueriesRequest {
    EventDataStore: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    QueryStatus?: QueryStatus | undefined;
}
export interface Query {
    QueryId?: string | undefined;
    QueryStatus?: QueryStatus | undefined;
    CreationTime?: Date | undefined;
}
export type Queries = Query[];
export interface ListQueriesResponse {
    Queries?: Query[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceIdList = string[];
export interface ListTagsRequest {
    ResourceIdList: string[];
    NextToken?: string | undefined;
}
export interface ResourceTag {
    ResourceId?: string | undefined;
    TagsList?: Tag[] | undefined;
}
export type ResourceTagList = ResourceTag[];
export interface ListTagsResponse {
    ResourceTagList?: ResourceTag[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTrailsRequest {
    NextToken?: string | undefined;
}
export interface TrailInfo {
    TrailARN?: string | undefined;
    Name?: string | undefined;
    HomeRegion?: string | undefined;
}
export type Trails = TrailInfo[];
export interface ListTrailsResponse {
    Trails?: TrailInfo[] | undefined;
    NextToken?: string | undefined;
}
export type LookupAttributeKey = "EventId" | "EventName" | "ReadOnly" | "Username" | "ResourceType" | "ResourceName" | "EventSource" | "AccessKeyId" | (string & {});
export type LookupAttributeValue = string;
export interface LookupAttribute {
    AttributeKey: LookupAttributeKey;
    AttributeValue: string;
}
export type LookupAttributesList = LookupAttribute[];
export type EventCategory = "insight" | (string & {});
export type MaxResults = number;
export type NextToken = string;
export interface LookupEventsRequest {
    LookupAttributes?: LookupAttribute[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    EventCategory?: EventCategory | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface LookupEventsResponse {
    Events?: Event[] | undefined;
    NextToken?: string | undefined;
}
export interface PutEventConfigurationRequest {
    TrailName?: string | undefined;
    EventDataStore?: string | undefined;
    MaxEventSize?: MaxEventSize | undefined;
    ContextKeySelectors?: ContextKeySelector[] | undefined;
    AggregationConfigurations?: AggregationConfiguration[] | undefined;
}
export interface PutEventConfigurationResponse {
    TrailARN?: string | undefined;
    EventDataStoreArn?: string | undefined;
    MaxEventSize?: MaxEventSize | undefined;
    ContextKeySelectors?: ContextKeySelector[] | undefined;
    AggregationConfigurations?: AggregationConfiguration[] | undefined;
}
export interface PutEventSelectorsRequest {
    TrailName: string;
    EventSelectors?: EventSelector[] | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
}
export interface PutEventSelectorsResponse {
    TrailARN?: string | undefined;
    EventSelectors?: EventSelector[] | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
}
export interface PutInsightSelectorsRequest {
    TrailName?: string | undefined;
    InsightSelectors: InsightSelector[];
    EventDataStore?: string | undefined;
    InsightsDestination?: string | undefined;
}
export interface PutInsightSelectorsResponse {
    TrailARN?: string | undefined;
    InsightSelectors?: InsightSelector[] | undefined;
    EventDataStoreArn?: string | undefined;
    InsightsDestination?: string | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    ResourcePolicy: string;
}
export interface PutResourcePolicyResponse {
    ResourceArn?: string | undefined;
    ResourcePolicy?: string | undefined;
    DelegatedAdminResourcePolicy?: string | undefined;
}
export interface RegisterOrganizationDelegatedAdminRequest {
    MemberAccountId: string;
}
export interface RegisterOrganizationDelegatedAdminResponse {
}
export interface RemoveTagsRequest {
    ResourceId: string;
    TagsList: Tag[];
}
export interface RemoveTagsResponse {
}
export interface RestoreEventDataStoreRequest {
    EventDataStore: string;
}
export interface RestoreEventDataStoreResponse {
    EventDataStoreArn?: string | undefined;
    Name?: string | undefined;
    Status?: EventDataStoreStatus | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    KmsKeyId?: string | undefined;
    BillingMode?: BillingMode | undefined;
}
export type SearchSampleQueriesSearchPhrase = string;
export type SearchSampleQueriesMaxResults = number;
export interface SearchSampleQueriesRequest {
    SearchPhrase: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SampleQueryName = string;
export type SampleQueryDescription = string;
export type SampleQuerySQL = string;
export type SampleQueryRelevance = number;
export interface SearchSampleQueriesSearchResult {
    Name?: string | undefined;
    Description?: string | undefined;
    SQL?: string | undefined;
    Relevance?: number | undefined;
}
export type SearchSampleQueriesSearchResults = SearchSampleQueriesSearchResult[];
export interface SearchSampleQueriesResponse {
    SearchResults?: SearchSampleQueriesSearchResult[] | undefined;
    NextToken?: string | undefined;
}
export type QueryParameterKey = string;
export type QueryParameterValue = string;
export type QueryParameterValues = {
    [key: string]: string | undefined;
};
export interface StartDashboardRefreshRequest {
    DashboardId: string;
    QueryParameterValues?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartDashboardRefreshResponse {
    RefreshId?: string | undefined;
}
export interface StartEventDataStoreIngestionRequest {
    EventDataStore: string;
}
export interface StartEventDataStoreIngestionResponse {
}
export interface StartImportRequest {
    Destinations?: string[] | undefined;
    ImportSource?: ImportSource | undefined;
    StartEventTime?: Date | undefined;
    EndEventTime?: Date | undefined;
    ImportId?: string | undefined;
}
export interface StartImportResponse {
    ImportId?: string | undefined;
    Destinations?: string[] | undefined;
    ImportSource?: ImportSource | undefined;
    StartEventTime?: Date | undefined;
    EndEventTime?: Date | undefined;
    ImportStatus?: ImportStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface StartLoggingRequest {
    Name: string;
}
export interface StartLoggingResponse {
}
export interface StartQueryRequest {
    QueryStatement?: string | undefined;
    DeliveryS3Uri?: string | undefined;
    QueryAlias?: string | undefined;
    QueryParameters?: string[] | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export interface StartQueryResponse {
    QueryId?: string | undefined;
    EventDataStoreOwnerAccountId?: string | undefined;
}
export interface StopEventDataStoreIngestionRequest {
    EventDataStore: string;
}
export interface StopEventDataStoreIngestionResponse {
}
export interface StopImportRequest {
    ImportId: string;
}
export interface StopImportResponse {
    ImportId?: string | undefined;
    ImportSource?: ImportSource | undefined;
    Destinations?: string[] | undefined;
    ImportStatus?: ImportStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    StartEventTime?: Date | undefined;
    EndEventTime?: Date | undefined;
    ImportStatistics?: ImportStatistics | undefined;
}
export interface StopLoggingRequest {
    Name: string;
}
export interface StopLoggingResponse {
}
export interface UpdateChannelRequest {
    Channel: string;
    Destinations?: Destination[] | undefined;
    Name?: string | undefined;
}
export interface UpdateChannelResponse {
    ChannelArn?: string | undefined;
    Name?: string | undefined;
    Source?: string | undefined;
    Destinations?: Destination[] | undefined;
}
export interface UpdateDashboardRequest {
    DashboardId: string;
    Widgets?: RequestWidget[] | undefined;
    RefreshSchedule?: RefreshSchedule | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
}
export interface UpdateDashboardResponse {
    DashboardArn?: string | undefined;
    Name?: string | undefined;
    Type?: DashboardType | undefined;
    Widgets?: Widget[] | undefined;
    RefreshSchedule?: RefreshSchedule | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface UpdateEventDataStoreRequest {
    EventDataStore: string;
    Name?: string | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
    BillingMode?: BillingMode | undefined;
}
export interface UpdateEventDataStoreResponse {
    EventDataStoreArn?: string | undefined;
    Name?: string | undefined;
    Status?: EventDataStoreStatus | undefined;
    AdvancedEventSelectors?: AdvancedEventSelector[] | undefined;
    MultiRegionEnabled?: boolean | undefined;
    OrganizationEnabled?: boolean | undefined;
    RetentionPeriod?: number | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    KmsKeyId?: string | undefined;
    BillingMode?: BillingMode | undefined;
    FederationStatus?: FederationStatus | undefined;
    FederationRoleArn?: string | undefined;
}
export interface UpdateTrailRequest {
    Name: string;
    S3BucketName?: string | undefined;
    S3KeyPrefix?: string | undefined;
    SnsTopicName?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    EnableLogFileValidation?: boolean | undefined;
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    IsOrganizationTrail?: boolean | undefined;
    RecursiveLogging?: boolean | undefined;
}
export interface UpdateTrailResponse {
    Name?: string | undefined;
    S3BucketName?: string | undefined;
    S3KeyPrefix?: string | undefined;
    SnsTopicName?: string | undefined;
    SnsTopicARN?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    TrailARN?: string | undefined;
    LogFileValidationEnabled?: boolean | undefined;
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    KmsKeyId?: string | undefined;
    IsOrganizationTrail?: boolean | undefined;
    RecursiveLogging?: boolean | undefined;
}
export type AddTagsError = ChannelARNInvalidException | ChannelNotFoundException | CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTagParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | TagsLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Adds one or more tags to a trail, event data store, dashboard, or channel, up to a limit of 50. Overwrites an
 * existing tag's value when a new value is specified for an existing tag key. Tag key names
 * must be unique; you cannot have two keys with the same name but different
 * values. If you specify a key without a value, the tag will be created with the specified
 * key and a value of null. You can tag a trail or event data store that applies to all
 * Amazon Web Services Regions only from the Region in which the trail or event data store
 * was created (also known as its home Region).
 */
export declare const addTags: API.OperationMethod<AddTagsRequest & RegionInput, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InactiveQueryException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Cancels a query if the query is not in a terminated state, such as
 * `CANCELLED`, `FAILED`, `TIMED_OUT`, or
 * `FINISHED`. You must specify an ARN value for `EventDataStore`.
 * The ID of the query that you want to cancel is also required. When you run
 * `CancelQuery`, the query status might show as `CANCELLED` even if
 * the operation is not yet finished.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryRequest & RegionInput, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = ChannelAlreadyExistsException | ChannelMaxLimitExceededException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidEventDataStoreCategoryException | InvalidParameterException | InvalidSourceException | InvalidTagParameterException | OperationNotPermittedException | TagsLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Creates a channel for CloudTrail to ingest events from a partner or external source.
 * After you create a channel, a CloudTrail Lake event data store can log events
 * from the partner or source that you specify.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateDashboardError = ConflictException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidQueryStatementException | InvalidTagParameterException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Creates a custom dashboard or the Highlights dashboard.
 *
 * - **Custom dashboards** - Custom dashboards allow you to query
 * events in any event data store type. You can add up to 10 widgets to a custom dashboard. You can manually refresh a custom dashboard, or you can set a refresh schedule.
 *
 * - **Highlights dashboard** - You can create
 * the Highlights dashboard to see a summary of key user activities and API usage across all your event data stores.
 * CloudTrail Lake manages the Highlights dashboard and refreshes the dashboard every 6 hours. To create the Highlights dashboard, you must set and enable a refresh schedule.
 *
 * CloudTrail runs queries to populate the dashboard's widgets during a manual or scheduled refresh. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 *
 * To set a refresh schedule, CloudTrail must be granted permissions to run the `StartDashboardRefresh` operation to refresh the dashboard on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to the dashboard. For more information,
 * see
 * Resource-based policy example for a dashboard in the *CloudTrail User Guide*.
 *
 * For more information about dashboards, see CloudTrail Lake dashboards in the *CloudTrail User Guide*.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest & RegionInput, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateEventDataStoreError = CloudTrailAccessNotEnabledException | ConflictException | EventDataStoreAlreadyExistsException | EventDataStoreMaxLimitExceededException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InvalidEventSelectorsException | InvalidKmsKeyIdException | InvalidParameterException | InvalidTagParameterException | KmsException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | ThrottlingException | UnsupportedOperationException | CloudTrailLakeOnboardingClosed | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Creates a new event data store.
 */
export declare const createEventDataStore: API.OperationMethod<CreateEventDataStoreRequest & RegionInput, CreateEventDataStoreResponse, CreateEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type CreateTrailError = CloudTrailAccessNotEnabledException | CloudTrailInvalidClientTokenIdException | CloudWatchLogsDeliveryUnavailableException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InsufficientSnsTopicPolicyException | InvalidCloudWatchLogsLogGroupArnException | InvalidCloudWatchLogsRoleArnException | InvalidKmsKeyIdException | InvalidParameterCombinationException | InvalidParameterException | InvalidS3BucketNameException | InvalidS3PrefixException | InvalidSnsTopicNameException | InvalidTagParameterException | InvalidTrailNameException | KmsException | KmsKeyDisabledException | KmsKeyNotFoundException | MaximumNumberOfTrailsExceededException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | S3BucketDoesNotExistException | TagsLimitExceededException | ThrottlingException | TrailAlreadyExistsException | TrailNotProvidedException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a trail that specifies the settings for delivery of log data to an Amazon S3 bucket.
 */
export declare const createTrail: API.OperationMethod<CreateTrailRequest & RegionInput, CreateTrailResponse, CreateTrailError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = ChannelARNInvalidException | ChannelNotFoundException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Deletes a channel.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = ConflictException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Deletes the specified dashboard. You cannot delete a dashboard that has termination protection enabled.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest & RegionInput, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteEventDataStoreError = ChannelExistsForEDSException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreFederationEnabledException | EventDataStoreHasOngoingImportException | EventDataStoreNotFoundException | EventDataStoreTerminationProtectedException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Disables the event data store specified by `EventDataStore`, which accepts an
 * event data store ARN. After you run `DeleteEventDataStore`, the event data store
 * enters a `PENDING_DELETION` state, and is automatically deleted after a wait
 * period of seven days. `TerminationProtectionEnabled` must be set to
 * `False` on the event data store and the `FederationStatus` must be `DISABLED`.
 * You cannot delete an event data store if `TerminationProtectionEnabled`
 * is `True` or the `FederationStatus` is `ENABLED`.
 *
 * After you run `DeleteEventDataStore` on an event data store, you cannot run
 * `ListQueries`, `DescribeQuery`, or `GetQueryResults` on
 * queries that are using an event data store in a `PENDING_DELETION` state. An
 * event data store in the `PENDING_DELETION` state does not incur costs.
 */
export declare const deleteEventDataStore: API.OperationMethod<DeleteEventDataStoreRequest & RegionInput, DeleteEventDataStoreResponse, DeleteEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = ConflictException | OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the resource-based policy attached to the CloudTrail event data store, dashboard, or channel.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTrailError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a trail. This operation must be called from the Region in which the trail was
 * created. `DeleteTrail` cannot be called on the shadow trails (replicated trails
 * in other Regions) of a trail that is enabled in all Regions.
 *
 * While deleting a CloudTrail trail is an irreversible action, CloudTrail does not
 * delete log files in the Amazon S3 bucket for that trail, the Amazon S3 bucket itself, or the
 * CloudWatchlog group to which the trail delivers events. Deleting a multi-Region trail
 * will stop logging of events in all Amazon Web Services Regions enabled in your Amazon Web Services account. Deleting a
 * single-Region trail will stop logging of events in that Region only. It will not stop
 * logging of events in other Regions even if the trails in those other Regions have
 * identical names to the deleted trail.
 *
 * For information about account closure and deletion of CloudTrail trails, see https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-account-closure.html.
 */
export declare const deleteTrail: API.OperationMethod<DeleteTrailRequest & RegionInput, DeleteTrailResponse, DeleteTrailError, Credentials | HttpClient.HttpClient>;
export type DeregisterOrganizationDelegatedAdminError = AccountNotFoundException | AccountNotRegisteredException | CloudTrailAccessNotEnabledException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NotOrganizationManagementAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Removes CloudTrail delegated administrator permissions from a member account in
 * an organization.
 */
export declare const deregisterOrganizationDelegatedAdmin: API.OperationMethod<DeregisterOrganizationDelegatedAdminRequest & RegionInput, DeregisterOrganizationDelegatedAdminResponse, DeregisterOrganizationDelegatedAdminError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns metadata about a query, including query run time in milliseconds, number of
 * events scanned and matched, and query status. If the query results were delivered to an S3 bucket,
 * the response also provides the S3 URI and the delivery status.
 *
 * You must specify either `QueryId` or `QueryAlias`. Specifying the `QueryAlias` parameter
 * returns information about the last query run for the alias. You can provide
 * `RefreshId` along with `QueryAlias` to view the query results
 * of a dashboard query for the specified `RefreshId`.
 */
export declare const describeQuery: API.OperationMethod<DescribeQueryRequest & RegionInput, DescribeQueryResponse, DescribeQueryError, Credentials | HttpClient.HttpClient>;
export type DescribeTrailsError = CloudTrailARNInvalidException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves settings for one or more trails associated with the current Region for your
 * account.
 */
export declare const describeTrails: API.OperationMethod<DescribeTrailsRequest & RegionInput, DescribeTrailsResponse, DescribeTrailsError, Credentials | HttpClient.HttpClient>;
export type DisableFederationError = AccessDeniedException | CloudTrailAccessNotEnabledException | ConcurrentModificationException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Disables Lake query federation on the specified event data store. When you disable federation, CloudTrail disables
 * the integration with Glue, Lake Formation, and Amazon Athena.
 * After disabling Lake query federation, you can no longer query your event data in Amazon Athena.
 *
 * No CloudTrail Lake data is deleted when you disable federation and you can continue to run queries in CloudTrail Lake.
 */
export declare const disableFederation: API.OperationMethod<DisableFederationRequest & RegionInput, DisableFederationResponse, DisableFederationError, Credentials | HttpClient.HttpClient>;
export type EnableFederationError = AccessDeniedException | CloudTrailAccessNotEnabledException | ConcurrentModificationException | EventDataStoreARNInvalidException | EventDataStoreFederationEnabledException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Enables Lake query federation on the specified event data store. Federating an event data store lets you view the metadata associated with the event data store in the Glue
 * Data Catalog and run
 * SQL queries against your event data using Amazon Athena. The table metadata stored in the Glue Data Catalog
 * lets the Athena query engine know how to find, read, and process the data that you want to query.
 *
 * When you enable Lake query federation, CloudTrail
 * creates a managed database named `aws:cloudtrail` (if the database doesn't already exist) and a managed federated table in
 * the Glue Data Catalog. The event data store ID is used for the table name. CloudTrail registers the role ARN and event data store in
 * Lake Formation, the service responsible for allowing fine-grained access control
 * of the federated resources in the Glue Data Catalog.
 *
 * For more information about Lake query federation, see Federate an event data store.
 */
export declare const enableFederation: API.OperationMethod<EnableFederationRequest & RegionInput, EnableFederationResponse, EnableFederationError, Credentials | HttpClient.HttpClient>;
export type GenerateQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | GenerateResponseException | InactiveEventDataStoreException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Generates a query from a natural language prompt. This operation uses generative artificial intelligence
 * (generative AI) to produce a ready-to-use SQL query from the prompt.
 *
 * The prompt can be a question or a statement about the event data
 * in your event data store. For example, you can enter prompts like "What are my
 * top errors in the past month?" and "Give me a list of users that used SNS."
 *
 * The prompt must be in English. For information about limitations, permissions, and supported Regions, see
 * Create CloudTrail Lake queries from natural language prompts
 * in the *CloudTrail * user guide.
 *
 * Do not include any personally identifying, confidential, or sensitive information
 * in your prompts.
 *
 * This feature uses generative AI large language models (LLMs); we recommend double-checking the
 * LLM response.
 */
export declare const generateQuery: API.OperationMethod<GenerateQueryRequest & RegionInput, GenerateQueryResponse, GenerateQueryError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = ChannelARNInvalidException | ChannelNotFoundException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information about a specific channel.
 */
export declare const getChannel: API.OperationMethod<GetChannelRequest & RegionInput, GetChannelResponse, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetDashboardError = ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns the specified dashboard.
 */
export declare const getDashboard: API.OperationMethod<GetDashboardRequest & RegionInput, GetDashboardResponse, GetDashboardError, Credentials | HttpClient.HttpClient>;
export type GetEventConfigurationError = CloudTrailARNInvalidException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the current event configuration settings for the specified event data store or trail. The response includes maximum event size configuration, the context key selectors configured for the event data store, and any aggregation settings configured for the trail.
 */
export declare const getEventConfiguration: API.OperationMethod<GetEventConfigurationRequest & RegionInput, GetEventConfigurationResponse, GetEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetEventDataStoreError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information about an event data store specified as either an ARN or the ID
 * portion of the ARN.
 */
export declare const getEventDataStore: API.OperationMethod<GetEventDataStoreRequest & RegionInput, GetEventDataStoreResponse, GetEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type GetEventSelectorsError = CloudTrailARNInvalidException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Describes the settings for the event selectors that you configured for your trail. The
 * information returned for your event selectors includes the following:
 *
 * - If your event selector includes read-only events, write-only events, or all
 * events. This applies to management events, data events, and network activity events.
 *
 * - If your event selector includes management events.
 *
 * - If your event selector includes network activity events, the event sources
 * for which you are logging network activity events.
 *
 * - If your event selector includes data events, the resources on which you are
 * logging data events.
 *
 * For more information about logging management, data, and network activity events, see the following topics
 * in the *CloudTrail User Guide*:
 *
 * - Logging management events
 *
 * - Logging data events
 *
 * - Logging network activity events
 */
export declare const getEventSelectors: API.OperationMethod<GetEventSelectorsRequest & RegionInput, GetEventSelectorsResponse, GetEventSelectorsError, Credentials | HttpClient.HttpClient>;
export type GetImportError = ImportNotFoundException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information about a specific import.
 */
export declare const getImport: API.OperationMethod<GetImportRequest & RegionInput, GetImportResponse, GetImportError, Credentials | HttpClient.HttpClient>;
export type GetInsightSelectorsError = CloudTrailARNInvalidException | InsightNotEnabledException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Describes the settings for the Insights event selectors that you configured for your
 * trail or event data store. `GetInsightSelectors` shows if CloudTrail Insights logging is enabled
 * and which Insights types are configured with corresponding event categories. If you run
 * `GetInsightSelectors` on a trail or event data store that does not have Insights events enabled,
 * the operation throws the exception `InsightNotEnabledException`
 *
 * Specify either the `EventDataStore` parameter to get Insights event selectors for an event data store,
 * or the `TrailName` parameter to the get Insights event selectors for a trail. You cannot specify these parameters together.
 *
 * For more information, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 */
export declare const getInsightSelectors: API.OperationMethod<GetInsightSelectorsRequest & RegionInput, GetInsightSelectorsResponse, GetInsightSelectorsError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidMaxResultsException | InvalidNextTokenException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Gets event data results of a query. You must specify the `QueryID` value
 * returned by the `StartQuery` operation.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsRequest & RegionInput, GetQueryResultsResponse, GetQueryResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourcePolicyError = OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the JSON text of the resource-based policy document attached to the CloudTrail event data store, dashboard, or channel.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTrailError = CloudTrailARNInvalidException | InvalidTrailNameException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns settings information for a specified trail.
 */
export declare const getTrail: API.OperationMethod<GetTrailRequest & RegionInput, GetTrailResponse, GetTrailError, Credentials | HttpClient.HttpClient>;
export type GetTrailStatusError = CloudTrailARNInvalidException | InvalidTrailNameException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a JSON-formatted list of information about the specified trail. Fields include
 * information on delivery errors, Amazon SNS and Amazon S3 errors, and start
 * and stop logging times for each trail. This operation returns trail status from a single
 * Region. To return trail status from all Regions, you must call the operation on each
 * Region.
 */
export declare const getTrailStatus: API.OperationMethod<GetTrailStatusRequest & RegionInput, GetTrailStatusResponse, GetTrailStatusError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = InvalidNextTokenException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Lists the channels in the current account, and their source names.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDashboardsError = UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information about all dashboards in the account, in the current Region.
 */
export declare const listDashboards: API.OperationMethod<ListDashboardsRequest & RegionInput, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient>;
export type ListEventDataStoresError = InvalidMaxResultsException | InvalidNextTokenException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information about all event data stores in the account, in the current
 * Region.
 */
export declare const listEventDataStores: API.PaginatedOperationMethod<ListEventDataStoresRequest & RegionInput, ListEventDataStoresResponse, ListEventDataStoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListImportFailuresError = InvalidNextTokenException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns a list of failures for the specified import.
 */
export declare const listImportFailures: API.PaginatedOperationMethod<ListImportFailuresRequest & RegionInput, ListImportFailuresResponse, ListImportFailuresError, Credentials | HttpClient.HttpClient, ImportFailureListItem>;
export type ListImportsError = EventDataStoreARNInvalidException | InvalidNextTokenException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns information on all imports, or a select set of imports by
 * `ImportStatus` or `Destination`.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsRequest & RegionInput, ListImportsResponse, ListImportsError, Credentials | HttpClient.HttpClient, ImportsListItem>;
export type ListInsightsDataError = InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns Insights events generated on a trail that logs data events. You can list Insights events that occurred in a Region within the last 90 days.
 *
 * ListInsightsData supports the following Dimensions for Insights events:
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * All dimensions are optional. The default number of results returned is 50, with a
 * maximum of 50 possible. The response includes a token that you can use to get the next page
 * of results.
 *
 * The rate of ListInsightsData requests is limited to two per second, per account, per Region. If
 * this limit is exceeded, a throttling error occurs.
 *
 * For data event Insights on organization trails, only the management account and delegated
 * administrator accounts can call `ListInsightsData`. For these callers, the API returns
 * Insights events only for the caller's own account. Member accounts cannot call this API on
 * organization trails.
 */
export declare const listInsightsData: API.PaginatedOperationMethod<ListInsightsDataRequest & RegionInput, ListInsightsDataResponse, ListInsightsDataError, Credentials | HttpClient.HttpClient, Event>;
export type ListInsightsMetricDataError = InvalidParameterException | InvalidTrailNameException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns Insights metrics data for trails that have enabled Insights. The request must include the `EventSource`,
 * `EventName`, and `InsightType` parameters.
 *
 * If the `InsightType` is set to `ApiErrorRateInsight`, the request must also include the `ErrorCode` parameter.
 *
 * The following are the available time periods for `ListInsightsMetricData`. Each cutoff is inclusive.
 *
 * - Data points with a period of 60 seconds (1-minute) are available for 15 days.
 *
 * - Data points with a period of 300 seconds (5-minute) are available for 63 days.
 *
 * - Data points with a period of 3600 seconds (1 hour) are available for 90 days.
 *
 * To use `ListInsightsMetricData` operation, you must have the following permissions:
 *
 * - If `ListInsightsMetricData` is invoked with `TrailName` parameter, access to the `ListInsightsMetricData` API operation is linked to the `cloudtrail:LookupEvents` action and `cloudtrail:ListInsightsData`. To use this operation,
 * you must have permissions to perform the `cloudtrail:LookupEvents` and `cloudtrail:ListInsightsData` action on the specific trail.
 *
 * - If `ListInsightsMetricData` is invoked without `TrailName` parameter, access to the `ListInsightsMetricData` API operation is linked to the `cloudtrail:LookupEvents` action only. To use this operation,
 * you must have permissions to perform the `cloudtrail:LookupEvents` action.
 *
 * For data event Insights on organization trails, only the management account and delegated
 * administrator accounts can call `ListInsightsMetricData`. For these callers, the API returns
 * Insights metrics only for the caller's own account. Member accounts cannot call this API on
 * organization trails.
 */
export declare const listInsightsMetricData: API.PaginatedOperationMethod<ListInsightsMetricDataRequest & RegionInput, ListInsightsMetricDataResponse, ListInsightsMetricDataError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPublicKeysError = InvalidTimeRangeException | InvalidTokenException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns all public keys whose private keys were used to sign the digest files within the
 * specified time range. The public key is needed to validate digest files that were signed
 * with its corresponding private key.
 *
 * CloudTrail uses different private and public key pairs per Region. Each digest
 * file is signed with a private key unique to its Region. When you validate a digest file
 * from a specific Region, you must look in the same Region for its corresponding public
 * key.
 */
export declare const listPublicKeys: API.PaginatedOperationMethod<ListPublicKeysRequest & RegionInput, ListPublicKeysResponse, ListPublicKeysError, Credentials | HttpClient.HttpClient, PublicKey>;
export type ListQueriesError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidDateRangeException | InvalidMaxResultsException | InvalidNextTokenException | InvalidParameterException | InvalidQueryStatusException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Returns a list of queries and query statuses for the past seven days. You must specify
 * an ARN value for `EventDataStore`. Optionally, to shorten the list of results,
 * you can specify a time range, formatted as timestamps, by adding `StartTime` and
 * `EndTime` parameters, and a `QueryStatus` value. Valid values for
 * `QueryStatus` include `QUEUED`, `RUNNING`,
 * `FINISHED`, `FAILED`, `TIMED_OUT`, or
 * `CANCELLED`.
 */
export declare const listQueries: API.PaginatedOperationMethod<ListQueriesRequest & RegionInput, ListQueriesResponse, ListQueriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = ChannelARNInvalidException | CloudTrailARNInvalidException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTokenException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Lists the tags for the specified trails, event data stores, dashboards, or channels in the current Region.
 */
export declare const listTags: API.PaginatedOperationMethod<ListTagsRequest & RegionInput, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient, ResourceTag>;
export type ListTrailsError = OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Lists trails that are in the current account.
 */
export declare const listTrails: API.PaginatedOperationMethod<ListTrailsRequest & RegionInput, ListTrailsResponse, ListTrailsError, Credentials | HttpClient.HttpClient, TrailInfo>;
export type LookupEventsError = InvalidEventCategoryException | InvalidLookupAttributesException | InvalidMaxResultsException | InvalidNextTokenException | InvalidTimeRangeException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Looks up management events or CloudTrail Insights events that are captured by CloudTrail.
 * You can look up events that occurred in a Region within the last 90 days.
 *
 * `LookupEvents` returns recent Insights events for trails that enable Insights. To view Insights events for an event data store, you can run queries on your
 * Insights event data store, and you can also view the Lake dashboard for Insights.
 *
 * Lookup supports the following attributes for management events:
 *
 * - Amazon Web Services access key
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * - Read only
 *
 * - Resource name
 *
 * - Resource type
 *
 * - User name
 *
 * Lookup supports the following attributes for Insights events:
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * All attributes are optional. The default number of results returned is 50, with a
 * maximum of 50 possible. The response includes a token that you can use to get the next page
 * of results.
 *
 * The rate of lookup requests is limited to two per second, per account, per Region. If
 * this limit is exceeded, a throttling error occurs.
 */
export declare const lookupEvents: API.PaginatedOperationMethod<LookupEventsRequest & RegionInput, LookupEventsResponse, LookupEventsError, Credentials | HttpClient.HttpClient, Event>;
export type PutEventConfigurationError = CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InsufficientIAMAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidHomeRegionException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the event configuration settings for the specified event data store or trail. This operation supports updating the maximum event size, adding or modifying context key selectors for event data store, and configuring aggregation settings for the trail.
 */
export declare const putEventConfiguration: API.OperationMethod<PutEventConfigurationRequest & RegionInput, PutEventConfigurationResponse, PutEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutEventSelectorsError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidEventSelectorsException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Configures event selectors (also referred to as *basic event selectors*) or advanced event selectors for your trail. You can use
 * either `AdvancedEventSelectors` or `EventSelectors`, but not both. If
 * you apply `AdvancedEventSelectors` to a trail, any existing
 * `EventSelectors` are overwritten.
 *
 * You can use `AdvancedEventSelectors` to
 * log management events, data events for all resource types, and network activity events.
 *
 * You can use `EventSelectors` to log management events and data events for the following resource types:
 *
 * - `AWS::DynamoDB::Table`
 *
 * - `AWS::Lambda::Function`
 *
 * - `AWS::S3::Object`
 *
 * You can't use `EventSelectors` to log network activity events.
 *
 * If you want your trail to log Insights events, be sure the event selector or advanced event selector enables
 * logging of the Insights event types you want configured for your trail. For more information about logging Insights events, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 * By default, trails created without specific event selectors are configured to
 * log all read and write management events, and no data events or network activity events.
 *
 * When an event occurs in your account, CloudTrail evaluates the event selectors or
 * advanced event selectors in all trails. For each trail, if the event matches any event
 * selector, the trail processes and logs the event. If the event doesn't match any event
 * selector, the trail doesn't log the event.
 *
 * Example
 *
 * - You create an event selector for a trail and specify that you want to log write-only
 * events.
 *
 * - The EC2 `GetConsoleOutput` and `RunInstances` API operations
 * occur in your account.
 *
 * - CloudTrail evaluates whether the events match your event selectors.
 *
 * - The `RunInstances` is a write-only event and it matches your event
 * selector. The trail logs the event.
 *
 * - The `GetConsoleOutput` is a read-only event that doesn't match your
 * event selector. The trail doesn't log the event.
 *
 * The `PutEventSelectors` operation must be called from the Region in which the
 * trail was created; otherwise, an `InvalidHomeRegionException` exception is
 * thrown.
 *
 * You can configure up to five event selectors for each trail.
 *
 * You can add advanced event selectors, and conditions for your advanced event selectors,
 * up to a maximum of 500 values for all conditions and selectors on a trail. For more information, see
 * Logging management events, Logging
 * data events, Logging
 * network activity events, and Quotas in CloudTrail in the CloudTrail User
 * Guide.
 */
export declare const putEventSelectors: API.OperationMethod<PutEventSelectorsRequest & RegionInput, PutEventSelectorsResponse, PutEventSelectorsError, Credentials | HttpClient.HttpClient>;
export type PutInsightSelectorsError = CloudTrailARNInvalidException | ConflictException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InvalidHomeRegionException | InvalidInsightSelectorsException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | KmsException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | S3BucketDoesNotExistException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Lets you enable Insights event logging on specific event categories by specifying the Insights selectors that you
 * want to enable on an existing trail or event data store. You also use `PutInsightSelectors` to turn
 * off Insights event logging, by passing an empty list of Insights types. The valid Insights
 * event types are `ApiErrorRateInsight` and
 * `ApiCallRateInsight`, and valid EventCategories are `Management` and `Data`.
 *
 * Insights on data events are not supported on event data stores. For event data stores, you can only enable Insights on management events.
 *
 * To enable Insights on an event data store, you must specify the ARNs (or ID suffix of the ARNs) for the source event data store (`EventDataStore`) and the destination event data store (`InsightsDestination`). The source event data store logs management events and enables Insights.
 * The destination event data store logs Insights events based upon the management event activity of the source event data store. The source and destination event data stores must belong to the same Amazon Web Services account.
 *
 * To log Insights events for a trail, you must specify the name (`TrailName`) of the CloudTrail trail for which you want to change or add Insights
 * selectors.
 *
 * - For Management events Insights: To log CloudTrail Insights on the API call rate, the trail or event data store must log `write` management events.
 * To log CloudTrail Insights on the API error rate, the trail or event data store must log `read` or `write` management events.
 *
 * - For Data events Insights: To log CloudTrail Insights on the API call rate or API error rate, the trail must log `read` or `write` data events. Data events Insights are not supported on event data store.
 *
 * To log CloudTrail Insights events on API call volume, the trail or event data store
 * must log `write` management events. To log CloudTrail
 * Insights events on API error rate, the trail or event data store must log `read` or
 * `write` management events. You can call `GetEventSelectors` on a trail
 * to check whether the trail logs management events. You can call `GetEventDataStore` on an
 * event data store to check whether the event data store logs management events.
 *
 * For more information, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 */
export declare const putInsightSelectors: API.OperationMethod<PutInsightSelectorsRequest & RegionInput, PutInsightSelectorsResponse, PutInsightSelectorsError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = ConflictException | OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotValidException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Attaches a resource-based permission policy to a CloudTrail event data store, dashboard, or channel. For more information about resource-based policies, see
 * CloudTrail resource-based policy examples
 * in the *CloudTrail User Guide*.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterOrganizationDelegatedAdminError = AccountNotFoundException | AccountRegisteredException | CannotDelegateManagementAccountException | CloudTrailAccessNotEnabledException | ConflictException | DelegatedAdminAccountLimitExceededException | InsufficientDependencyServiceAccessPermissionException | InsufficientIAMAccessPermissionException | InvalidParameterException | NotOrganizationManagementAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Registers an organization's member account as the CloudTrail delegated administrator.
 */
export declare const registerOrganizationDelegatedAdmin: API.OperationMethod<RegisterOrganizationDelegatedAdminRequest & RegionInput, RegisterOrganizationDelegatedAdminResponse, RegisterOrganizationDelegatedAdminError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = ChannelARNInvalidException | ChannelNotFoundException | CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTagParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Removes the specified tags from a trail, event data store, dashboard, or channel.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest & RegionInput, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RestoreEventDataStoreError = CloudTrailAccessNotEnabledException | EventDataStoreARNInvalidException | EventDataStoreMaxLimitExceededException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Restores a deleted event data store specified by `EventDataStore`, which
 * accepts an event data store ARN. You can only restore a deleted event data store within the
 * seven-day wait period after deletion. Restoring an event data store can take several
 * minutes, depending on the size of the event data store.
 */
export declare const restoreEventDataStore: API.OperationMethod<RestoreEventDataStoreRequest & RegionInput, RestoreEventDataStoreResponse, RestoreEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type SearchSampleQueriesError = InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Searches sample queries and returns a list of sample queries that are sorted by relevance.
 * To search for sample queries, provide a natural language `SearchPhrase` in English.
 */
export declare const searchSampleQueries: API.OperationMethod<SearchSampleQueriesRequest & RegionInput, SearchSampleQueriesResponse, SearchSampleQueriesError, Credentials | HttpClient.HttpClient>;
export type StartDashboardRefreshError = EventDataStoreNotFoundException | InactiveEventDataStoreException | ResourceNotFoundException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Starts a refresh of the specified dashboard.
 *
 * Each time a dashboard is refreshed, CloudTrail runs queries to populate the dashboard's widgets. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 */
export declare const startDashboardRefresh: API.OperationMethod<StartDashboardRefreshRequest & RegionInput, StartDashboardRefreshResponse, StartDashboardRefreshError, Credentials | HttpClient.HttpClient>;
export type StartEventDataStoreIngestionError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Starts the ingestion of live events on an event data store specified as either an ARN or the ID portion of the ARN. To start ingestion, the event data store `Status` must be `STOPPED_INGESTION`
 * and the `eventCategory` must be `Management`, `Data`, `NetworkActivity`, or `ConfigurationItem`.
 */
export declare const startEventDataStoreIngestion: API.OperationMethod<StartEventDataStoreIngestionRequest & RegionInput, StartEventDataStoreIngestionResponse, StartEventDataStoreIngestionError, Credentials | HttpClient.HttpClient>;
export type StartImportError = AccountHasOngoingImportException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | ImportNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidImportSourceException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Starts an import of logged trail events from a source S3 bucket to a destination event
 * data store. By default, CloudTrail only imports events contained in the S3 bucket's
 * `CloudTrail` prefix and the prefixes inside the `CloudTrail` prefix, and does not check prefixes for other Amazon Web Services
 * services. If you want to import CloudTrail events contained in another prefix, you
 * must include the prefix in the `S3LocationUri`. For more considerations about
 * importing trail events, see Considerations for copying trail events in the *CloudTrail User Guide*.
 *
 * When you start a new import, the `Destinations` and
 * `ImportSource` parameters are required. Before starting a new import, disable
 * any access control lists (ACLs) attached to the source S3 bucket. For more information
 * about disabling ACLs, see Controlling ownership of
 * objects and disabling ACLs for your bucket.
 *
 * When you retry an import, the `ImportID` parameter is required.
 *
 * If the destination event data store is for an organization, you must use the
 * management account to import trail events. You cannot use the delegated administrator
 * account for the organization.
 */
export declare const startImport: API.OperationMethod<StartImportRequest & RegionInput, StartImportResponse, StartImportError, Credentials | HttpClient.HttpClient>;
export type StartLoggingError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Starts the recording of Amazon Web Services API calls and log file delivery for a trail.
 * For a trail that is enabled in all Regions, this operation must be called from the Region
 * in which the trail was created. This operation cannot be called on the shadow trails
 * (replicated trails in other Regions) of a trail that is enabled in all Regions.
 */
export declare const startLogging: API.OperationMethod<StartLoggingRequest & RegionInput, StartLoggingResponse, StartLoggingError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InvalidParameterException | InvalidQueryStatementException | InvalidS3BucketNameException | InvalidS3PrefixException | MaxConcurrentQueriesException | NoManagementAccountSLRExistsException | OperationNotPermittedException | S3BucketDoesNotExistException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Starts a CloudTrail Lake query. Use the `QueryStatement`
 * parameter to provide your SQL query, enclosed in single quotation marks. Use the optional
 * `DeliveryS3Uri` parameter to deliver the query results to an S3
 * bucket.
 *
 * `StartQuery` requires you specify either the `QueryStatement` parameter, or a `QueryAlias` and any `QueryParameters`. In the current release,
 * the `QueryAlias` and `QueryParameters` parameters are used only for the queries that populate the CloudTrail Lake dashboards.
 */
export declare const startQuery: API.OperationMethod<StartQueryRequest & RegionInput, StartQueryResponse, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StopEventDataStoreIngestionError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Stops the ingestion of live events on an event data store specified as either an ARN or the ID portion of the ARN. To stop ingestion, the event data store `Status` must be `ENABLED`
 * and the `eventCategory` must be `Management`, `Data`, `NetworkActivity`, or `ConfigurationItem`.
 */
export declare const stopEventDataStoreIngestion: API.OperationMethod<StopEventDataStoreIngestionRequest & RegionInput, StopEventDataStoreIngestionResponse, StopEventDataStoreIngestionError, Credentials | HttpClient.HttpClient>;
export type StopImportError = ImportNotFoundException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Stops a specified import.
 */
export declare const stopImport: API.OperationMethod<StopImportRequest & RegionInput, StopImportResponse, StopImportError, Credentials | HttpClient.HttpClient>;
export type StopLoggingError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Suspends the recording of Amazon Web Services API calls and log file delivery for the
 * specified trail. Under most circumstances, there is no need to use this action. You can
 * update a trail without stopping it first. This action is the only way to stop recording.
 * For a trail enabled in all Regions, this operation must be called from the Region in which
 * the trail was created, or an `InvalidHomeRegionException` will occur. This
 * operation cannot be called on the shadow trails (replicated trails in other Regions) of a
 * trail enabled in all Regions.
 */
export declare const stopLogging: API.OperationMethod<StopLoggingRequest & RegionInput, StopLoggingResponse, StopLoggingError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = ChannelAlreadyExistsException | ChannelARNInvalidException | ChannelNotFoundException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidEventDataStoreCategoryException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Updates a channel specified by a required channel ARN or UUID.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = ConflictException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidQueryStatementException | ResourceNotFoundException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Updates the specified dashboard.
 *
 * To set a refresh schedule, CloudTrail must be granted permissions to run the `StartDashboardRefresh` operation to refresh the dashboard on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to the dashboard. For more information,
 * see
 * Resource-based policy example for a dashboard in the *CloudTrail User Guide*.
 *
 * CloudTrail runs queries to populate the dashboard's widgets during a manual or scheduled refresh. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest & RegionInput, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateEventDataStoreError = CloudTrailAccessNotEnabledException | ConflictException | EventDataStoreAlreadyExistsException | EventDataStoreARNInvalidException | EventDataStoreHasOngoingImportException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InvalidEventSelectorsException | InvalidInsightSelectorsException | InvalidKmsKeyIdException | InvalidParameterException | KmsException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * CloudTrail Lake will no longer be open to new customers starting May 31, 2026. If you would like to use CloudTrail Lake, sign up prior to that date. Existing customers can continue to use the service as normal. For more information, see CloudTrail Lake availability change.
 *
 * Updates an event data store. The required `EventDataStore` value is an ARN or
 * the ID portion of the ARN. Other parameters are optional, but at least one optional
 * parameter must be specified, or CloudTrail throws an error.
 * `RetentionPeriod` is in days, and valid values are integers between 7 and
 * 3653 if the `BillingMode` is set to `EXTENDABLE_RETENTION_PRICING`, or between 7 and 2557 if `BillingMode` is set to `FIXED_RETENTION_PRICING`. By default, `TerminationProtection` is enabled.
 *
 * For event data stores for CloudTrail events, `AdvancedEventSelectors`
 * includes or excludes management, data, or network activity events in your event data store. For more
 * information about `AdvancedEventSelectors`, see AdvancedEventSelectors.
 *
 * For event data stores for CloudTrail Insights events, Config configuration items, Audit Manager evidence, or non-Amazon Web Services events,
 * `AdvancedEventSelectors` includes events of that type in your event data store.
 */
export declare const updateEventDataStore: API.OperationMethod<UpdateEventDataStoreRequest & RegionInput, UpdateEventDataStoreResponse, UpdateEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateTrailError = CloudTrailAccessNotEnabledException | CloudTrailARNInvalidException | CloudTrailInvalidClientTokenIdException | CloudWatchLogsDeliveryUnavailableException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InsufficientSnsTopicPolicyException | InvalidCloudWatchLogsLogGroupArnException | InvalidCloudWatchLogsRoleArnException | InvalidEventSelectorsException | InvalidHomeRegionException | InvalidKmsKeyIdException | InvalidParameterCombinationException | InvalidParameterException | InvalidS3BucketNameException | InvalidS3PrefixException | InvalidSnsTopicNameException | InvalidTrailNameException | KmsException | KmsKeyDisabledException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | S3BucketDoesNotExistException | ThrottlingException | TrailNotFoundException | TrailNotProvidedException | UnsupportedOperationException | CommonErrors;
/**
 * Updates trail settings that control what events you are logging, and how to handle log
 * files. Changes to a trail do not require stopping the CloudTrail service. Use this
 * action to designate an existing bucket for log delivery. If the existing bucket has
 * previously been a target for CloudTrail log files, an IAM policy
 * exists for the bucket. `UpdateTrail` must be called from the Region in which the
 * trail was created; otherwise, an `InvalidHomeRegionException` is thrown.
 */
export declare const updateTrail: API.OperationMethod<UpdateTrailRequest & RegionInput, UpdateTrailResponse, UpdateTrailError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudtrail.d.ts.map