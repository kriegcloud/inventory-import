import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type WordCharactersWithDelimiters = string;
export interface CreateConfigurationSetRequest {
    ConfigurationSetName?: string | undefined;
}
export interface CreateConfigurationSetResponse {
}
export interface CloudWatchLogsDestination {
    IamRoleArn?: string | undefined;
    LogGroupArn?: string | undefined;
}
export interface KinesisFirehoseDestination {
    DeliveryStreamArn?: string | undefined;
    IamRoleArn?: string | undefined;
}
export type EventType = "INITIATED_CALL" | "RINGING" | "ANSWERED" | "COMPLETED_CALL" | "BUSY" | "FAILED" | "NO_ANSWER" | (string & {});
export type EventTypes = EventType[];
export interface SnsDestination {
    TopicArn?: string | undefined;
}
export interface EventDestinationDefinition {
    CloudWatchLogsDestination?: CloudWatchLogsDestination | undefined;
    Enabled?: boolean | undefined;
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    MatchingEventTypes?: EventType[] | undefined;
    SnsDestination?: SnsDestination | undefined;
}
export type NonEmptyString = string;
export interface CreateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination?: EventDestinationDefinition | undefined;
    EventDestinationName?: string | undefined;
}
export interface CreateConfigurationSetEventDestinationResponse {
}
export interface DeleteConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetResponse {
}
export interface DeleteConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
}
export interface DeleteConfigurationSetEventDestinationResponse {
}
export interface GetConfigurationSetEventDestinationsRequest {
    ConfigurationSetName: string;
}
export interface EventDestination {
    CloudWatchLogsDestination?: CloudWatchLogsDestination | undefined;
    Enabled?: boolean | undefined;
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    MatchingEventTypes?: EventType[] | undefined;
    Name?: string | undefined;
    SnsDestination?: SnsDestination | undefined;
}
export type EventDestinations = EventDestination[];
export interface GetConfigurationSetEventDestinationsResponse {
    EventDestinations?: EventDestination[] | undefined;
}
export interface ListConfigurationSetsRequest {
    NextToken?: string | undefined;
    PageSize?: string | undefined;
}
export type ConfigurationSets = string[];
export type NextTokenString = string;
export interface ListConfigurationSetsResponse {
    ConfigurationSets?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface CallInstructionsMessageType {
    Text?: string | undefined;
}
export interface PlainTextMessageType {
    LanguageCode?: string | undefined;
    Text?: string | undefined;
    VoiceId?: string | undefined;
}
export interface SSMLMessageType {
    LanguageCode?: string | undefined;
    Text?: string | undefined;
    VoiceId?: string | undefined;
}
export interface VoiceMessageContent {
    CallInstructionsMessage?: CallInstructionsMessageType | undefined;
    PlainTextMessage?: PlainTextMessageType | undefined;
    SSMLMessage?: SSMLMessageType | undefined;
}
export interface SendVoiceMessageRequest {
    CallerId?: string | undefined;
    ConfigurationSetName?: string | undefined;
    Content?: VoiceMessageContent | undefined;
    DestinationPhoneNumber?: string | undefined;
    OriginationPhoneNumber?: string | undefined;
}
export interface SendVoiceMessageResponse {
    MessageId?: string | undefined;
}
export interface UpdateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestination?: EventDestinationDefinition | undefined;
    EventDestinationName: string;
}
export interface UpdateConfigurationSetEventDestinationResponse {
}
export type CreateConfigurationSetError = AlreadyExistsException | BadRequestException | InternalServiceErrorException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new configuration set. After you create the configuration set, you can add one or more event destinations to it.
 */
export declare const createConfigurationSet: API.OperationMethod<CreateConfigurationSetRequest & RegionInput, CreateConfigurationSetResponse, CreateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetEventDestinationError = AlreadyExistsException | BadRequestException | InternalServiceErrorException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create a new event destination in a configuration set.
 */
export declare const createConfigurationSetEventDestination: API.OperationMethod<CreateConfigurationSetEventDestinationRequest & RegionInput, CreateConfigurationSetEventDestinationResponse, CreateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing configuration set.
 */
export declare const deleteConfigurationSet: API.OperationMethod<DeleteConfigurationSetRequest & RegionInput, DeleteConfigurationSetResponse, DeleteConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetEventDestinationError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an event destination in a configuration set.
 */
export declare const deleteConfigurationSetEventDestination: API.OperationMethod<DeleteConfigurationSetEventDestinationRequest & RegionInput, DeleteConfigurationSetEventDestinationResponse, DeleteConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetEventDestinationsError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Obtain information about an event destination, including the types of events it reports, the Amazon Resource Name (ARN) of the destination, and the name of the event destination.
 */
export declare const getConfigurationSetEventDestinations: API.OperationMethod<GetConfigurationSetEventDestinationsRequest & RegionInput, GetConfigurationSetEventDestinationsResponse, GetConfigurationSetEventDestinationsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationSetsError = BadRequestException | InternalServiceErrorException | TooManyRequestsException | CommonErrors;
/**
 * List all of the configuration sets associated with your Amazon Pinpoint account in the current region.
 */
export declare const listConfigurationSets: API.OperationMethod<ListConfigurationSetsRequest & RegionInput, ListConfigurationSetsResponse, ListConfigurationSetsError, Credentials | HttpClient.HttpClient>;
export type SendVoiceMessageError = BadRequestException | InternalServiceErrorException | TooManyRequestsException | CommonErrors;
/**
 * Create a new voice message and send it to a recipient's phone number.
 */
export declare const sendVoiceMessage: API.OperationMethod<SendVoiceMessageRequest & RegionInput, SendVoiceMessageResponse, SendVoiceMessageError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetEventDestinationError = BadRequestException | InternalServiceErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update an event destination in a configuration set. An event destination is a location that you publish information about your voice calls to. For example, you can log an event to an Amazon CloudWatch destination when a call fails.
 */
export declare const updateConfigurationSetEventDestination: API.OperationMethod<UpdateConfigurationSetEventDestinationRequest & RegionInput, UpdateConfigurationSetEventDestinationResponse, UpdateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pinpoint-sms-voice.d.ts.map