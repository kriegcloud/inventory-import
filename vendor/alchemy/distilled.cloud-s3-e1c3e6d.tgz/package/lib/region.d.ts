/**
 * The region an operation is dispatched to. The first of these wins:
 *
 * 1. The call's own `region` ({@link RegionInput}):
 *    `S3.getObject({ Bucket, Key, region: "eu-west-1" })`.
 * 2. The {@link Region} layer, for every call in a scope:
 *    `Effect.provide(Region.of("eu-west-1"))`.
 * 3. The region of the credentials ({@link ResolvedCredentials.region}),
 *    which is never absent.
 *
 * `Region` is an optional service: generated operations do not list it in
 * their requirements.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type { ProviderError } from "./credentials.ts";
declare const RegionService: Context.ServiceClass<Region, "AWS::Region", Effect.Effect<RegionName, ProviderError>>;
export declare class Region extends RegionService {
}
/** Send the calls in a scope to one region, e.g. `Region.of("us-west-2")`. */
export declare const of: (region: RegionName) => Layer.Layer<Region, never, never>;
/**
 * The optional `region` every operation input accepts. It sends one call to
 * that region, over the `Region` layer and the credentials' region. It is
 * not sent on the wire.
 */
export interface RegionInput {
    readonly region?: RegionName;
}
export type RegionName = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "af-south-1" | "ap-east-1" | "ap-south-2" | "ap-southeast-3" | "ap-southeast-5" | "ap-southeast-4" | "ap-south-1" | "ap-southeast-6" | "ap-northeast-3" | "ap-northeast-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-east-2" | "ap-southeast-7" | "ap-northeast-1" | "ca-central-1" | "ca-west-1" | "eu-central-1" | "eu-west-1" | "eu-west-2" | "eu-south-1" | "eu-west-3" | "eu-south-2" | "eu-north-1" | "eu-central-2" | "il-central-1" | "mx-central-1" | "me-south-1" | "me-central-1" | "sa-east-1" | (string & {});
export {};
//# sourceMappingURL=region.d.ts.map