import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type SelectionExpression = string;
export type CorsHeaderList = string[];
export type StringWithLengthBetween1And64 = string;
export type CorsMethodList = string[];
export type CorsOriginList = string[];
export type IntegerWithLengthBetweenMinus1And86400 = number;
export interface Cors {
    AllowCredentials?: boolean | undefined;
    AllowHeaders?: string[] | undefined;
    AllowMethods?: string[] | undefined;
    AllowOrigins?: string[] | undefined;
    ExposeHeaders?: string[] | undefined;
    MaxAge?: number | undefined;
}
export type Arn = string;
export type StringWithLengthBetween0And1024 = string;
export type IpAddressType = "ipv4" | "dualstack" | (string & {});
export type StringWithLengthBetween1And128 = string;
export type ProtocolType = "WEBSOCKET" | "HTTP" | (string & {});
export type SelectionKey = string;
export type StringWithLengthBetween1And1600 = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type UriWithLengthBetween1And2048 = string;
export interface CreateApiRequest {
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteKey?: string | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Target?: string | undefined;
    Version?: string | undefined;
}
export type Id = string;
export type __timestampIso8601 = Date;
export type __listOf__string = string[];
export interface CreateApiResponse {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export interface CreateApiMappingRequest {
    ApiId?: string | undefined;
    ApiMappingKey?: string | undefined;
    DomainName: string;
    Stage?: string | undefined;
}
export interface CreateApiMappingResponse {
    ApiId?: string | undefined;
    ApiMappingId?: string | undefined;
    ApiMappingKey?: string | undefined;
    Stage?: string | undefined;
}
export type IntegerWithLengthBetween0And3600 = number;
export type AuthorizerType = "REQUEST" | "JWT" | (string & {});
export type IdentitySourceList = string[];
export interface JWTConfiguration {
    Audience?: string[] | undefined;
    Issuer?: string | undefined;
}
export interface CreateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export interface CreateAuthorizerResponse {
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerId?: string | undefined;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export interface CreateDeploymentRequest {
    ApiId: string;
    Description?: string | undefined;
    StageName?: string | undefined;
}
export type DeploymentStatus = "PENDING" | "FAILED" | "DEPLOYED" | (string & {});
export interface CreateDeploymentResponse {
    AutoDeployed?: boolean | undefined;
    CreatedDate?: Date | undefined;
    DeploymentId?: string | undefined;
    DeploymentStatus?: DeploymentStatus | undefined;
    DeploymentStatusMessage?: string | undefined;
    Description?: string | undefined;
}
export type StringWithLengthBetween1And512 = string;
export type DomainNameStatus = "AVAILABLE" | "UPDATING" | "PENDING_CERTIFICATE_REIMPORT" | "PENDING_OWNERSHIP_VERIFICATION" | (string & {});
export type EndpointType = "REGIONAL" | "EDGE" | (string & {});
export type SecurityPolicy = "TLS_1_0" | "TLS_1_2" | (string & {});
export interface DomainNameConfiguration {
    ApiGatewayDomainName?: string | undefined;
    CertificateArn?: string | undefined;
    CertificateName?: string | undefined;
    CertificateUploadDate?: Date | undefined;
    DomainNameStatus?: DomainNameStatus | undefined;
    DomainNameStatusMessage?: string | undefined;
    EndpointType?: EndpointType | undefined;
    HostedZoneId?: string | undefined;
    IpAddressType?: IpAddressType | undefined;
    SecurityPolicy?: SecurityPolicy | undefined;
    OwnershipVerificationCertificateArn?: string | undefined;
}
export type DomainNameConfigurations = DomainNameConfiguration[];
export interface MutualTlsAuthenticationInput {
    TruststoreUri?: string | undefined;
    TruststoreVersion?: string | undefined;
}
export type RoutingMode = "API_MAPPING_ONLY" | "ROUTING_RULE_ONLY" | "ROUTING_RULE_THEN_API_MAPPING" | (string & {});
export interface CreateDomainNameRequest {
    DomainName?: string | undefined;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthenticationInput | undefined;
    RoutingMode?: RoutingMode | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface MutualTlsAuthentication {
    TruststoreUri?: string | undefined;
    TruststoreVersion?: string | undefined;
    TruststoreWarnings?: string[] | undefined;
}
export interface CreateDomainNameResponse {
    ApiMappingSelectionExpression?: string | undefined;
    DomainName?: string | undefined;
    DomainNameArn?: string | undefined;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthentication | undefined;
    RoutingMode?: RoutingMode | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StringWithLengthBetween1And1024 = string;
export type ConnectionType = "INTERNET" | "VPC_LINK" | (string & {});
export type ContentHandlingStrategy = "CONVERT_TO_BINARY" | "CONVERT_TO_TEXT" | (string & {});
export type IntegrationType = "AWS" | "HTTP" | "MOCK" | "HTTP_PROXY" | "AWS_PROXY" | (string & {});
export type PassthroughBehavior = "WHEN_NO_MATCH" | "NEVER" | "WHEN_NO_TEMPLATES" | (string & {});
export type IntegrationParameters = {
    [key: string]: string | undefined;
};
export type StringWithLengthBetween0And32K = string;
export type TemplateMap = {
    [key: string]: string | undefined;
};
export type ResponseParameters = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type IntegerWithLengthBetween50And30000 = number;
export interface TlsConfigInput {
    ServerNameToVerify?: string | undefined;
}
export interface CreateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationMethod?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfigInput | undefined;
}
export interface TlsConfig {
    ServerNameToVerify?: string | undefined;
}
export interface CreateIntegrationResult {
    ApiGatewayManaged?: boolean | undefined;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationId?: string | undefined;
    IntegrationMethod?: string | undefined;
    IntegrationResponseSelectionExpression?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfig | undefined;
}
export interface CreateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationId: string;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export interface CreateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationResponseId?: string | undefined;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export type StringWithLengthBetween1And256 = string;
export interface CreateModelRequest {
    ApiId: string;
    ContentType?: string | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export interface CreateModelResponse {
    ContentType?: string | undefined;
    Description?: string | undefined;
    ModelId?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export type __stringMin1Max256 = string;
export type __stringMin20Max2048 = string;
export interface CognitoConfig {
    AppClientId?: string | undefined;
    UserPoolArn?: string | undefined;
    UserPoolDomain?: string | undefined;
}
export interface None {
}
export interface Authorization {
    CognitoConfig?: CognitoConfig | undefined;
    None?: None | undefined;
}
export type __stringMin10Max2048 = string;
export type __stringMin3Max256 = string;
export interface ACMManaged {
    CertificateArn?: string | undefined;
    DomainName?: string | undefined;
}
export interface EndpointConfigurationRequest {
    AcmManaged?: ACMManaged | undefined;
    None?: None | undefined;
}
export type __listOf__stringMin20Max2048 = string[];
export type __stringMin0Max1092 = string;
export type __stringMin0Max1024 = string;
export type __stringMin3Max255 = string;
export type __stringMin1Max16 = string;
export interface CustomColors {
    AccentColor?: string | undefined;
    BackgroundColor?: string | undefined;
    ErrorValidationColor?: string | undefined;
    HeaderColor?: string | undefined;
    NavigationColor?: string | undefined;
    TextColor?: string | undefined;
}
export interface PortalTheme {
    CustomColors?: CustomColors | undefined;
    LogoLastUploaded?: Date | undefined;
}
export interface PortalContent {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    Theme?: PortalTheme | undefined;
}
export type __stringMin0Max255 = string;
export interface CreatePortalRequest {
    Authorization?: Authorization | undefined;
    EndpointConfiguration?: EndpointConfigurationRequest | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LogoUri?: string | undefined;
    PortalContent?: PortalContent | undefined;
    RumAppMonitorName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin1Max64 = string;
export interface EndpointConfigurationResponse {
    CertificateArn?: string | undefined;
    DomainName?: string | undefined;
    PortalDefaultDomainName?: string | undefined;
    PortalDomainHostedZoneId?: string | undefined;
}
export type __stringMin10Max30PatternAZ09 = string;
export type PublishStatus = "PUBLISHED" | "PUBLISH_IN_PROGRESS" | "PUBLISH_FAILED" | "DISABLE_IN_PROGRESS" | "DISABLE_FAILED" | "DISABLED" | (string & {});
export type __stringMin1Max2048 = string;
export interface StatusException {
    Exception?: string | undefined;
    Message?: string | undefined;
}
export interface CreatePortalResponse {
    Authorization?: (Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    }) | undefined;
    EndpointConfiguration?: (EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    }) | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LastModified?: Date | undefined;
    LastPublished?: Date | undefined;
    LastPublishedDescription?: string | undefined;
    PortalArn?: string | undefined;
    PortalContent?: (PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    }) | undefined;
    PortalId?: string | undefined;
    PublishStatus?: PublishStatus | undefined;
    RumAppMonitorName?: string | undefined;
    StatusException?: StatusException | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin1Max255 = string;
export interface CreatePortalProductRequest {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Section {
    ProductRestEndpointPageArns?: string[] | undefined;
    SectionName?: string | undefined;
}
export type __listOfSection = Section[];
export interface DisplayOrder {
    Contents?: Section[] | undefined;
    OverviewPageArn?: string | undefined;
    ProductPageArns?: string[] | undefined;
}
export interface CreatePortalProductResponse {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    DisplayOrder?: (DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    }) | undefined;
    LastModified?: Date | undefined;
    PortalProductArn?: string | undefined;
    PortalProductId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin1Max32768 = string;
export interface DisplayContent {
    Body?: string | undefined;
    Title?: string | undefined;
}
export interface CreateProductPageRequest {
    DisplayContent?: DisplayContent | undefined;
    PortalProductId: string;
}
export interface CreateProductPageResponse {
    DisplayContent?: (DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductPageArn?: string | undefined;
    ProductPageId?: string | undefined;
}
export type __stringMin1Max1024 = string;
export interface DisplayContentOverrides {
    Body?: string | undefined;
    Endpoint?: string | undefined;
    OperationName?: string | undefined;
}
export interface EndpointDisplayContent {
    None?: None | undefined;
    Overrides?: DisplayContentOverrides | undefined;
}
export type __stringMin1Max20 = string;
export type __stringMin1Max4096 = string;
export type __stringMin1Max50 = string;
export type __stringMin1Max128 = string;
export interface IdentifierParts {
    Method?: string | undefined;
    Path?: string | undefined;
    RestApiId?: string | undefined;
    Stage?: string | undefined;
}
export interface RestEndpointIdentifier {
    IdentifierParts?: IdentifierParts | undefined;
}
export type TryItState = "ENABLED" | "DISABLED" | (string & {});
export interface CreateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent | undefined;
    PortalProductId: string;
    RestEndpointIdentifier?: RestEndpointIdentifier | undefined;
    TryItState?: TryItState | undefined;
}
export interface EndpointDisplayContentResponse {
    Body?: string | undefined;
    Endpoint?: string | undefined;
    OperationName?: string | undefined;
}
export type Status = "AVAILABLE" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface CreateProductRestEndpointPageResponse {
    DisplayContent?: (EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductRestEndpointPageArn?: string | undefined;
    ProductRestEndpointPageId?: string | undefined;
    RestEndpointIdentifier?: (RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    }) | undefined;
    Status?: Status | undefined;
    StatusException?: StatusException | undefined;
    TryItState?: TryItState | undefined;
}
export type AuthorizationScopes = string[];
export type AuthorizationType = "NONE" | "AWS_IAM" | "CUSTOM" | "JWT" | (string & {});
export type RouteModels = {
    [key: string]: string | undefined;
};
export interface ParameterConstraints {
    Required?: boolean | undefined;
}
export type RouteParameters = {
    [key: string]: ParameterConstraints | undefined;
};
export interface CreateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export interface CreateRouteResult {
    ApiGatewayManaged?: boolean | undefined;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId?: string | undefined;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export interface CreateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId: string;
    RouteResponseKey?: string | undefined;
}
export interface CreateRouteResponseResponse {
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteResponseId?: string | undefined;
    RouteResponseKey?: string | undefined;
}
export interface RoutingRuleActionInvokeApi {
    ApiId?: string | undefined;
    Stage?: string | undefined;
    StripBasePath?: boolean | undefined;
}
export interface RoutingRuleAction {
    InvokeApi?: RoutingRuleActionInvokeApi | undefined;
}
export type __listOfRoutingRuleAction = RoutingRuleAction[];
export type __listOfSelectionKey = string[];
export interface RoutingRuleMatchBasePaths {
    AnyOf?: string[] | undefined;
}
export interface RoutingRuleMatchHeaderValue {
    Header?: string | undefined;
    ValueGlob?: string | undefined;
}
export type __listOfRoutingRuleMatchHeaderValue = RoutingRuleMatchHeaderValue[];
export interface RoutingRuleMatchHeaders {
    AnyOf?: RoutingRuleMatchHeaderValue[] | undefined;
}
export interface RoutingRuleCondition {
    MatchBasePaths?: RoutingRuleMatchBasePaths | undefined;
    MatchHeaders?: RoutingRuleMatchHeaders | undefined;
}
export type __listOfRoutingRuleCondition = RoutingRuleCondition[];
export type RoutingRulePriority = number;
export interface CreateRoutingRuleRequest {
    Actions?: RoutingRuleAction[] | undefined;
    Conditions?: RoutingRuleCondition[] | undefined;
    DomainName: string;
    DomainNameId?: string | undefined;
    Priority?: number | undefined;
}
export interface CreateRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[] | undefined;
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[] | undefined;
    Priority?: number | undefined;
    RoutingRuleArn?: string | undefined;
    RoutingRuleId?: string | undefined;
}
export interface AccessLogSettings {
    DestinationArn?: string | undefined;
    Format?: string | undefined;
}
export type LoggingLevel = "ERROR" | "INFO" | "OFF" | (string & {});
export interface RouteSettings {
    DataTraceEnabled?: boolean | undefined;
    DetailedMetricsEnabled?: boolean | undefined;
    LoggingLevel?: LoggingLevel | undefined;
    ThrottlingBurstLimit?: number | undefined;
    ThrottlingRateLimit?: number | undefined;
}
export type RouteSettingsMap = {
    [key: string]: RouteSettings | undefined;
};
export type StringWithLengthBetween0And2048 = string;
export type StageVariablesMap = {
    [key: string]: string | undefined;
};
export interface CreateStageRequest {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiId: string;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateStageResponse {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiGatewayManaged?: boolean | undefined;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    CreatedDate?: Date | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    LastDeploymentStatusMessage?: string | undefined;
    LastUpdatedDate?: Date | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SecurityGroupIdList = string[];
export type SubnetIdList = string[];
export interface CreateVpcLinkRequest {
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VpcLinkStatus = "PENDING" | "AVAILABLE" | "DELETING" | "FAILED" | "INACTIVE" | (string & {});
export type VpcLinkVersion = "V2" | (string & {});
export interface CreateVpcLinkResponse {
    CreatedDate?: Date | undefined;
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcLinkId?: string | undefined;
    VpcLinkStatus?: VpcLinkStatus | undefined;
    VpcLinkStatusMessage?: string | undefined;
    VpcLinkVersion?: VpcLinkVersion | undefined;
}
export interface DeleteAccessLogSettingsRequest {
    ApiId: string;
    StageName: string;
}
export interface DeleteAccessLogSettingsResponse {
}
export interface DeleteApiRequest {
    ApiId: string;
}
export interface DeleteApiResponse {
}
export interface DeleteApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export interface DeleteApiMappingResponse {
}
export interface DeleteAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export interface DeleteAuthorizerResponse {
}
export interface DeleteCorsConfigurationRequest {
    ApiId: string;
}
export interface DeleteCorsConfigurationResponse {
}
export interface DeleteDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export interface DeleteDeploymentResponse {
}
export interface DeleteDomainNameRequest {
    DomainName: string;
}
export interface DeleteDomainNameResponse {
}
export interface DeleteIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export interface DeleteIntegrationResponse {
}
export interface DeleteIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export interface DeleteIntegrationResponseResponse {
}
export interface DeleteModelRequest {
    ApiId: string;
    ModelId: string;
}
export interface DeleteModelResponse {
}
export interface DeletePortalRequest {
    PortalId: string;
}
export interface DeletePortalResponse {
}
export interface DeletePortalProductRequest {
    PortalProductId: string;
}
export interface DeletePortalProductResponse {
}
export interface DeletePortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export interface DeletePortalProductSharingPolicyResponse {
}
export interface DeleteProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
}
export interface DeleteProductPageResponse {
}
export interface DeleteProductRestEndpointPageRequest {
    PortalProductId: string;
    ProductRestEndpointPageId: string;
}
export interface DeleteProductRestEndpointPageResponse {
}
export interface DeleteRouteRequest {
    ApiId: string;
    RouteId: string;
}
export interface DeleteRouteResponse {
}
export interface DeleteRouteRequestParameterRequest {
    ApiId: string;
    RequestParameterKey: string;
    RouteId: string;
}
export interface DeleteRouteRequestParameterResponse {
}
export interface DeleteRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export interface DeleteRouteResponseResponse {
}
export interface DeleteRouteSettingsRequest {
    ApiId: string;
    RouteKey: string;
    StageName: string;
}
export interface DeleteRouteSettingsResponse {
}
export interface DeleteRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string | undefined;
    RoutingRuleId: string;
}
export interface DeleteRoutingRuleResponse {
}
export interface DeleteStageRequest {
    ApiId: string;
    StageName: string;
}
export interface DeleteStageResponse {
}
export interface DeleteVpcLinkRequest {
    VpcLinkId: string;
}
export interface DeleteVpcLinkResponse {
}
export interface DisablePortalRequest {
    PortalId: string;
}
export interface DisablePortalResponse {
}
export interface ExportApiRequest {
    ApiId: string;
    ExportVersion?: string | undefined;
    IncludeExtensions?: boolean | undefined;
    OutputType?: string | undefined;
    Specification: string;
    StageName?: string | undefined;
}
export interface ExportApiResponse {
    body?: T.StreamingOutputBody | undefined;
}
export interface GetApiRequest {
    ApiId: string;
}
export interface GetApiResponse {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export interface GetApiMappingRequest {
    ApiMappingId: string;
    DomainName: string;
}
export interface GetApiMappingResponse {
    ApiId?: string | undefined;
    ApiMappingId?: string | undefined;
    ApiMappingKey?: string | undefined;
    Stage?: string | undefined;
}
export interface GetApiMappingsRequest {
    DomainName: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ApiMapping {
    ApiId?: string | undefined;
    ApiMappingId?: string | undefined;
    ApiMappingKey?: string | undefined;
    Stage?: string | undefined;
}
export type __listOfApiMapping = ApiMapping[];
export type NextToken = string;
export interface GetApiMappingsResponse {
    Items?: (ApiMapping & {
        ApiId: Id;
        Stage: StringWithLengthBetween1And128;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetApisRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Api {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export type __listOfApi = Api[];
export interface GetApisResponse {
    Items?: (Api & {
        Name: StringWithLengthBetween1And128;
        ProtocolType: ProtocolType;
        RouteSelectionExpression: SelectionExpression;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetAuthorizerRequest {
    ApiId: string;
    AuthorizerId: string;
}
export interface GetAuthorizerResponse {
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerId?: string | undefined;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export interface GetAuthorizersRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Authorizer {
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerId?: string | undefined;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export type __listOfAuthorizer = Authorizer[];
export interface GetAuthorizersResponse {
    Items?: (Authorizer & {
        Name: StringWithLengthBetween1And128;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
}
export interface GetDeploymentResponse {
    AutoDeployed?: boolean | undefined;
    CreatedDate?: Date | undefined;
    DeploymentId?: string | undefined;
    DeploymentStatus?: DeploymentStatus | undefined;
    DeploymentStatusMessage?: string | undefined;
    Description?: string | undefined;
}
export interface GetDeploymentsRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Deployment {
    AutoDeployed?: boolean | undefined;
    CreatedDate?: Date | undefined;
    DeploymentId?: string | undefined;
    DeploymentStatus?: DeploymentStatus | undefined;
    DeploymentStatusMessage?: string | undefined;
    Description?: string | undefined;
}
export type __listOfDeployment = Deployment[];
export interface GetDeploymentsResponse {
    Items?: Deployment[] | undefined;
    NextToken?: string | undefined;
}
export interface GetDomainNameRequest {
    DomainName: string;
}
export interface GetDomainNameResponse {
    ApiMappingSelectionExpression?: string | undefined;
    DomainName?: string | undefined;
    DomainNameArn?: string | undefined;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthentication | undefined;
    RoutingMode?: RoutingMode | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDomainNamesRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface DomainName {
    ApiMappingSelectionExpression?: string | undefined;
    DomainName?: string | undefined;
    DomainNameArn?: string | undefined;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthentication | undefined;
    RoutingMode?: RoutingMode | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfDomainName = DomainName[];
export interface GetDomainNamesResponse {
    Items?: (DomainName & {
        DomainName: StringWithLengthBetween1And512;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetIntegrationRequest {
    ApiId: string;
    IntegrationId: string;
}
export interface GetIntegrationResult {
    ApiGatewayManaged?: boolean | undefined;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationId?: string | undefined;
    IntegrationMethod?: string | undefined;
    IntegrationResponseSelectionExpression?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfig | undefined;
}
export interface GetIntegrationResponseRequest {
    ApiId: string;
    IntegrationId: string;
    IntegrationResponseId: string;
}
export interface GetIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationResponseId?: string | undefined;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export interface GetIntegrationResponsesRequest {
    ApiId: string;
    IntegrationId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface IntegrationResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationResponseId?: string | undefined;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export type __listOfIntegrationResponse = IntegrationResponse[];
export interface GetIntegrationResponsesResponse {
    Items?: (IntegrationResponse & {
        IntegrationResponseKey: SelectionKey;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetIntegrationsRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Integration {
    ApiGatewayManaged?: boolean | undefined;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationId?: string | undefined;
    IntegrationMethod?: string | undefined;
    IntegrationResponseSelectionExpression?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfig | undefined;
}
export type __listOfIntegration = Integration[];
export interface GetIntegrationsResponse {
    Items?: Integration[] | undefined;
    NextToken?: string | undefined;
}
export interface GetModelRequest {
    ApiId: string;
    ModelId: string;
}
export interface GetModelResponse {
    ContentType?: string | undefined;
    Description?: string | undefined;
    ModelId?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export interface GetModelsRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Model {
    ContentType?: string | undefined;
    Description?: string | undefined;
    ModelId?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export type __listOfModel = Model[];
export interface GetModelsResponse {
    Items?: (Model & {
        Name: StringWithLengthBetween1And128;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetModelTemplateRequest {
    ApiId: string;
    ModelId: string;
}
export interface GetModelTemplateResponse {
    Value?: string | undefined;
}
export interface GetPortalRequest {
    PortalId: string;
}
export type PreviewStatus = "PREVIEW_IN_PROGRESS" | "PREVIEW_FAILED" | "PREVIEW_READY" | (string & {});
export interface Preview {
    PreviewStatus?: PreviewStatus | undefined;
    PreviewUrl?: string | undefined;
    StatusException?: StatusException | undefined;
}
export interface GetPortalResponse {
    Authorization?: (Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    }) | undefined;
    EndpointConfiguration?: (EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    }) | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LastModified?: Date | undefined;
    LastPublished?: Date | undefined;
    LastPublishedDescription?: string | undefined;
    PortalArn?: string | undefined;
    PortalContent?: (PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    }) | undefined;
    PortalId?: string | undefined;
    Preview?: (Preview & {
        PreviewStatus: PreviewStatus;
    }) | undefined;
    PublishStatus?: PublishStatus | undefined;
    RumAppMonitorName?: string | undefined;
    StatusException?: StatusException | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPortalProductRequest {
    PortalProductId: string;
    ResourceOwnerAccountId?: string | undefined;
}
export interface GetPortalProductResponse {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    DisplayOrder?: (DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    }) | undefined;
    LastModified?: Date | undefined;
    PortalProductArn?: string | undefined;
    PortalProductId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPortalProductSharingPolicyRequest {
    PortalProductId: string;
}
export type __stringMin1Max307200 = string;
export interface GetPortalProductSharingPolicyResponse {
    PolicyDocument?: string | undefined;
    PortalProductId?: string | undefined;
}
export interface GetProductPageRequest {
    PortalProductId: string;
    ProductPageId: string;
    ResourceOwnerAccountId?: string | undefined;
}
export interface GetProductPageResponse {
    DisplayContent?: (DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductPageArn?: string | undefined;
    ProductPageId?: string | undefined;
}
export interface GetProductRestEndpointPageRequest {
    IncludeRawDisplayContent?: string | undefined;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    ResourceOwnerAccountId?: string | undefined;
}
export interface GetProductRestEndpointPageResponse {
    DisplayContent?: (EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductRestEndpointPageArn?: string | undefined;
    ProductRestEndpointPageId?: string | undefined;
    RawDisplayContent?: string | undefined;
    RestEndpointIdentifier?: (RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    }) | undefined;
    Status?: Status | undefined;
    StatusException?: StatusException | undefined;
    TryItState?: TryItState | undefined;
}
export interface GetRouteRequest {
    ApiId: string;
    RouteId: string;
}
export interface GetRouteResult {
    ApiGatewayManaged?: boolean | undefined;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId?: string | undefined;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export interface GetRouteResponseRequest {
    ApiId: string;
    RouteId: string;
    RouteResponseId: string;
}
export interface GetRouteResponseResponse {
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteResponseId?: string | undefined;
    RouteResponseKey?: string | undefined;
}
export interface GetRouteResponsesRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    RouteId: string;
}
export interface RouteResponse {
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteResponseId?: string | undefined;
    RouteResponseKey?: string | undefined;
}
export type __listOfRouteResponse = RouteResponse[];
export interface GetRouteResponsesResponse {
    Items?: (RouteResponse & {
        RouteResponseKey: SelectionKey;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetRoutesRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Route {
    ApiGatewayManaged?: boolean | undefined;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId?: string | undefined;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export type __listOfRoute = Route[];
export interface GetRoutesResponse {
    Items?: (Route & {
        RouteKey: SelectionKey;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetRoutingRuleRequest {
    DomainName: string;
    DomainNameId?: string | undefined;
    RoutingRuleId: string;
}
export interface GetRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[] | undefined;
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[] | undefined;
    Priority?: number | undefined;
    RoutingRuleArn?: string | undefined;
    RoutingRuleId?: string | undefined;
}
export interface GetStageRequest {
    ApiId: string;
    StageName: string;
}
export interface GetStageResponse {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiGatewayManaged?: boolean | undefined;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    CreatedDate?: Date | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    LastDeploymentStatusMessage?: string | undefined;
    LastUpdatedDate?: Date | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetStagesRequest {
    ApiId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Stage {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiGatewayManaged?: boolean | undefined;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    CreatedDate?: Date | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    LastDeploymentStatusMessage?: string | undefined;
    LastUpdatedDate?: Date | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfStage = Stage[];
export interface GetStagesResponse {
    Items?: (Stage & {
        StageName: StringWithLengthBetween1And128;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTagsRequest {
    ResourceArn: string;
}
export interface GetTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetVpcLinkRequest {
    VpcLinkId: string;
}
export interface GetVpcLinkResponse {
    CreatedDate?: Date | undefined;
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcLinkId?: string | undefined;
    VpcLinkStatus?: VpcLinkStatus | undefined;
    VpcLinkStatusMessage?: string | undefined;
    VpcLinkVersion?: VpcLinkVersion | undefined;
}
export interface GetVpcLinksRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface VpcLink {
    CreatedDate?: Date | undefined;
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcLinkId?: string | undefined;
    VpcLinkStatus?: VpcLinkStatus | undefined;
    VpcLinkStatusMessage?: string | undefined;
    VpcLinkVersion?: VpcLinkVersion | undefined;
}
export type __listOfVpcLink = VpcLink[];
export interface GetVpcLinksResponse {
    Items?: (VpcLink & {
        Name: StringWithLengthBetween1And128;
        SecurityGroupIds: SecurityGroupIdList;
        SubnetIds: SubnetIdList;
        VpcLinkId: Id;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ImportApiRequest {
    Basepath?: string | undefined;
    Body?: string | undefined;
    FailOnWarnings?: boolean | undefined;
}
export interface ImportApiResponse {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export interface ListPortalProductsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    ResourceOwner?: string | undefined;
}
export interface PortalProductSummary {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    LastModified?: Date | undefined;
    PortalProductArn?: string | undefined;
    PortalProductId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfPortalProductSummary = PortalProductSummary[];
export interface ListPortalProductsResponse {
    Items?: (PortalProductSummary & {
        Description: __stringMin0Max1024;
        DisplayName: __stringMin1Max255;
        LastModified: __timestampIso8601;
        PortalProductArn: __stringMin20Max2048;
        PortalProductId: __stringMin10Max30PatternAZ09;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPortalsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface PortalSummary {
    Authorization?: Authorization | undefined;
    EndpointConfiguration?: EndpointConfigurationResponse | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LastModified?: Date | undefined;
    LastPublished?: Date | undefined;
    LastPublishedDescription?: string | undefined;
    PortalArn?: string | undefined;
    PortalContent?: PortalContent | undefined;
    PortalId?: string | undefined;
    Preview?: Preview | undefined;
    PublishStatus?: PublishStatus | undefined;
    RumAppMonitorName?: string | undefined;
    StatusException?: StatusException | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfPortalSummary = PortalSummary[];
export interface ListPortalsResponse {
    Items?: (PortalSummary & {
        Authorization: Authorization & {
            CognitoConfig: CognitoConfig & {
                AppClientId: __stringMin1Max256;
                UserPoolArn: __stringMin20Max2048;
                UserPoolDomain: __stringMin20Max2048;
            };
        };
        EndpointConfiguration: EndpointConfigurationResponse & {
            PortalDefaultDomainName: __stringMin3Max256;
            PortalDomainHostedZoneId: __stringMin1Max64;
        };
        IncludedPortalProductArns: __listOf__stringMin20Max2048;
        LastModified: __timestampIso8601;
        PortalArn: __stringMin20Max2048;
        PortalContent: PortalContent & {
            DisplayName: __stringMin3Max255;
            Theme: PortalTheme & {
                CustomColors: CustomColors & {
                    AccentColor: __stringMin1Max16;
                    BackgroundColor: __stringMin1Max16;
                    ErrorValidationColor: __stringMin1Max16;
                    HeaderColor: __stringMin1Max16;
                    NavigationColor: __stringMin1Max16;
                    TextColor: __stringMin1Max16;
                };
            };
        };
        PortalId: __stringMin10Max30PatternAZ09;
        Preview: Preview & {
            PreviewStatus: PreviewStatus;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProductPagesRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    PortalProductId: string;
    ResourceOwnerAccountId?: string | undefined;
}
export interface ProductPageSummaryNoBody {
    LastModified?: Date | undefined;
    PageTitle?: string | undefined;
    ProductPageArn?: string | undefined;
    ProductPageId?: string | undefined;
}
export type __listOfProductPageSummaryNoBody = ProductPageSummaryNoBody[];
export interface ListProductPagesResponse {
    Items?: (ProductPageSummaryNoBody & {
        LastModified: __timestampIso8601;
        PageTitle: __stringMin1Max255;
        ProductPageArn: __stringMin20Max2048;
        ProductPageId: __stringMin10Max30PatternAZ09;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProductRestEndpointPagesRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    PortalProductId: string;
    ResourceOwnerAccountId?: string | undefined;
}
export interface ProductRestEndpointPageSummaryNoBody {
    Endpoint?: string | undefined;
    LastModified?: Date | undefined;
    OperationName?: string | undefined;
    ProductRestEndpointPageArn?: string | undefined;
    ProductRestEndpointPageId?: string | undefined;
    RestEndpointIdentifier?: RestEndpointIdentifier | undefined;
    Status?: Status | undefined;
    StatusException?: StatusException | undefined;
    TryItState?: TryItState | undefined;
}
export type __listOfProductRestEndpointPageSummaryNoBody = ProductRestEndpointPageSummaryNoBody[];
export interface ListProductRestEndpointPagesResponse {
    Items?: (ProductRestEndpointPageSummaryNoBody & {
        Endpoint: __stringMin1Max1024;
        LastModified: __timestampIso8601;
        ProductRestEndpointPageArn: __stringMin20Max2048;
        ProductRestEndpointPageId: __stringMin10Max30PatternAZ09;
        RestEndpointIdentifier: RestEndpointIdentifier & {
            IdentifierParts: IdentifierParts & {
                Method: __stringMin1Max20;
                Path: __stringMin1Max4096;
                RestApiId: __stringMin1Max50;
                Stage: __stringMin1Max128;
            };
        };
        Status: Status;
        TryItState: TryItState;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListRoutingRulesRequest {
    DomainName: string;
    DomainNameId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RoutingRule {
    Actions?: RoutingRuleAction[] | undefined;
    Conditions?: RoutingRuleCondition[] | undefined;
    Priority?: number | undefined;
    RoutingRuleArn?: string | undefined;
    RoutingRuleId?: string | undefined;
}
export type __listOfRoutingRule = RoutingRule[];
export interface ListRoutingRulesResponse {
    NextToken?: string | undefined;
    RoutingRules?: (RoutingRule & {
        Actions: (RoutingRuleAction & {
            InvokeApi: RoutingRuleActionInvokeApi & {
                ApiId: Id;
                Stage: StringWithLengthBetween1And128;
            };
        })[];
        Conditions: (RoutingRuleCondition & {
            MatchBasePaths: RoutingRuleMatchBasePaths & {
                AnyOf: __listOfSelectionKey;
            };
            MatchHeaders: RoutingRuleMatchHeaders & {
                AnyOf: (RoutingRuleMatchHeaderValue & {
                    Header: SelectionKey;
                    ValueGlob: SelectionExpression;
                })[];
            };
        })[];
    })[] | undefined;
}
export interface PreviewPortalRequest {
    PortalId: string;
}
export interface PreviewPortalResponse {
}
export interface PublishPortalRequest {
    Description?: string | undefined;
    PortalId: string;
}
export interface PublishPortalResponse {
}
export interface PutPortalProductSharingPolicyRequest {
    PolicyDocument?: string | undefined;
    PortalProductId: string;
}
export interface PutPortalProductSharingPolicyResponse {
}
export interface PutRoutingRuleRequest {
    Actions?: RoutingRuleAction[] | undefined;
    Conditions?: RoutingRuleCondition[] | undefined;
    DomainName: string;
    DomainNameId?: string | undefined;
    Priority?: number | undefined;
    RoutingRuleId: string;
}
export interface PutRoutingRuleResponse {
    Actions?: (RoutingRuleAction & {
        InvokeApi: RoutingRuleActionInvokeApi & {
            ApiId: Id;
            Stage: StringWithLengthBetween1And128;
        };
    })[] | undefined;
    Conditions?: (RoutingRuleCondition & {
        MatchBasePaths: RoutingRuleMatchBasePaths & {
            AnyOf: __listOfSelectionKey;
        };
        MatchHeaders: RoutingRuleMatchHeaders & {
            AnyOf: (RoutingRuleMatchHeaderValue & {
                Header: SelectionKey;
                ValueGlob: SelectionExpression;
            })[];
        };
    })[] | undefined;
    Priority?: number | undefined;
    RoutingRuleArn?: string | undefined;
    RoutingRuleId?: string | undefined;
}
export interface ReimportApiRequest {
    ApiId: string;
    Basepath?: string | undefined;
    Body?: string | undefined;
    FailOnWarnings?: boolean | undefined;
}
export interface ReimportApiResponse {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export interface ResetAuthorizersCacheRequest {
    ApiId: string;
    StageName: string;
}
export interface ResetAuthorizersCacheResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateApiRequest {
    ApiId: string;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    RouteKey?: string | undefined;
    RouteSelectionExpression?: string | undefined;
    Target?: string | undefined;
    Version?: string | undefined;
}
export interface UpdateApiResponse {
    ApiEndpoint?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CorsConfiguration?: Cors | undefined;
    CreatedDate?: Date | undefined;
    Description?: string | undefined;
    DisableSchemaValidation?: boolean | undefined;
    DisableExecuteApiEndpoint?: boolean | undefined;
    ImportInfo?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
    Name?: string | undefined;
    ProtocolType?: ProtocolType | undefined;
    RouteSelectionExpression?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Version?: string | undefined;
    Warnings?: string[] | undefined;
}
export interface UpdateApiMappingRequest {
    ApiId?: string | undefined;
    ApiMappingId: string;
    ApiMappingKey?: string | undefined;
    DomainName: string;
    Stage?: string | undefined;
}
export interface UpdateApiMappingResponse {
    ApiId?: string | undefined;
    ApiMappingId?: string | undefined;
    ApiMappingKey?: string | undefined;
    Stage?: string | undefined;
}
export interface UpdateAuthorizerRequest {
    ApiId: string;
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerId: string;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export interface UpdateAuthorizerResponse {
    AuthorizerCredentialsArn?: string | undefined;
    AuthorizerId?: string | undefined;
    AuthorizerPayloadFormatVersion?: string | undefined;
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerType?: AuthorizerType | undefined;
    AuthorizerUri?: string | undefined;
    EnableSimpleResponses?: boolean | undefined;
    IdentitySource?: string[] | undefined;
    IdentityValidationExpression?: string | undefined;
    JwtConfiguration?: JWTConfiguration | undefined;
    Name?: string | undefined;
}
export interface UpdateDeploymentRequest {
    ApiId: string;
    DeploymentId: string;
    Description?: string | undefined;
}
export interface UpdateDeploymentResponse {
    AutoDeployed?: boolean | undefined;
    CreatedDate?: Date | undefined;
    DeploymentId?: string | undefined;
    DeploymentStatus?: DeploymentStatus | undefined;
    DeploymentStatusMessage?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateDomainNameRequest {
    DomainName: string;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthenticationInput | undefined;
    RoutingMode?: RoutingMode | undefined;
}
export interface UpdateDomainNameResponse {
    ApiMappingSelectionExpression?: string | undefined;
    DomainName?: string | undefined;
    DomainNameArn?: string | undefined;
    DomainNameConfigurations?: DomainNameConfiguration[] | undefined;
    MutualTlsAuthentication?: MutualTlsAuthentication | undefined;
    RoutingMode?: RoutingMode | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateIntegrationRequest {
    ApiId: string;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationId: string;
    IntegrationMethod?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfigInput | undefined;
}
export interface UpdateIntegrationResult {
    ApiGatewayManaged?: boolean | undefined;
    ConnectionId?: string | undefined;
    ConnectionType?: ConnectionType | undefined;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    CredentialsArn?: string | undefined;
    Description?: string | undefined;
    IntegrationId?: string | undefined;
    IntegrationMethod?: string | undefined;
    IntegrationResponseSelectionExpression?: string | undefined;
    IntegrationSubtype?: string | undefined;
    IntegrationType?: IntegrationType | undefined;
    IntegrationUri?: string | undefined;
    PassthroughBehavior?: PassthroughBehavior | undefined;
    PayloadFormatVersion?: string | undefined;
    RequestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
    TimeoutInMillis?: number | undefined;
    TlsConfig?: TlsConfig | undefined;
}
export interface UpdateIntegrationResponseRequest {
    ApiId: string;
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationId: string;
    IntegrationResponseId: string;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export interface UpdateIntegrationResponseResponse {
    ContentHandlingStrategy?: ContentHandlingStrategy | undefined;
    IntegrationResponseId?: string | undefined;
    IntegrationResponseKey?: string | undefined;
    ResponseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    TemplateSelectionExpression?: string | undefined;
}
export interface UpdateModelRequest {
    ApiId: string;
    ContentType?: string | undefined;
    Description?: string | undefined;
    ModelId: string;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export interface UpdateModelResponse {
    ContentType?: string | undefined;
    Description?: string | undefined;
    ModelId?: string | undefined;
    Name?: string | undefined;
    Schema?: string | undefined;
}
export interface UpdatePortalRequest {
    Authorization?: Authorization | undefined;
    EndpointConfiguration?: EndpointConfigurationRequest | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LogoUri?: string | undefined;
    PortalContent?: PortalContent | undefined;
    PortalId: string;
    RumAppMonitorName?: string | undefined;
}
export interface UpdatePortalResponse {
    Authorization?: (Authorization & {
        CognitoConfig: CognitoConfig & {
            AppClientId: __stringMin1Max256;
            UserPoolArn: __stringMin20Max2048;
            UserPoolDomain: __stringMin20Max2048;
        };
    }) | undefined;
    EndpointConfiguration?: (EndpointConfigurationResponse & {
        PortalDefaultDomainName: __stringMin3Max256;
        PortalDomainHostedZoneId: __stringMin1Max64;
    }) | undefined;
    IncludedPortalProductArns?: string[] | undefined;
    LastModified?: Date | undefined;
    LastPublished?: Date | undefined;
    LastPublishedDescription?: string | undefined;
    PortalArn?: string | undefined;
    PortalContent?: (PortalContent & {
        DisplayName: __stringMin3Max255;
        Theme: PortalTheme & {
            CustomColors: CustomColors & {
                AccentColor: __stringMin1Max16;
                BackgroundColor: __stringMin1Max16;
                ErrorValidationColor: __stringMin1Max16;
                HeaderColor: __stringMin1Max16;
                NavigationColor: __stringMin1Max16;
                TextColor: __stringMin1Max16;
            };
        };
    }) | undefined;
    PortalId?: string | undefined;
    Preview?: (Preview & {
        PreviewStatus: PreviewStatus;
    }) | undefined;
    PublishStatus?: PublishStatus | undefined;
    RumAppMonitorName?: string | undefined;
    StatusException?: StatusException | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdatePortalProductRequest {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    DisplayOrder?: DisplayOrder | undefined;
    PortalProductId: string;
}
export interface UpdatePortalProductResponse {
    Description?: string | undefined;
    DisplayName?: string | undefined;
    DisplayOrder?: (DisplayOrder & {
        Contents: (Section & {
            ProductRestEndpointPageArns: __listOf__stringMin20Max2048;
            SectionName: string;
        })[];
    }) | undefined;
    LastModified?: Date | undefined;
    PortalProductArn?: string | undefined;
    PortalProductId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateProductPageRequest {
    DisplayContent?: DisplayContent | undefined;
    PortalProductId: string;
    ProductPageId: string;
}
export interface UpdateProductPageResponse {
    DisplayContent?: (DisplayContent & {
        Body: __stringMin1Max32768;
        Title: __stringMin1Max255;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductPageArn?: string | undefined;
    ProductPageId?: string | undefined;
}
export interface UpdateProductRestEndpointPageRequest {
    DisplayContent?: EndpointDisplayContent | undefined;
    PortalProductId: string;
    ProductRestEndpointPageId: string;
    TryItState?: TryItState | undefined;
}
export interface UpdateProductRestEndpointPageResponse {
    DisplayContent?: (EndpointDisplayContentResponse & {
        Endpoint: __stringMin1Max1024;
    }) | undefined;
    LastModified?: Date | undefined;
    ProductRestEndpointPageArn?: string | undefined;
    ProductRestEndpointPageId?: string | undefined;
    RestEndpointIdentifier?: (RestEndpointIdentifier & {
        IdentifierParts: IdentifierParts & {
            Method: __stringMin1Max20;
            Path: __stringMin1Max4096;
            RestApiId: __stringMin1Max50;
            Stage: __stringMin1Max128;
        };
    }) | undefined;
    Status?: Status | undefined;
    StatusException?: StatusException | undefined;
    TryItState?: TryItState | undefined;
}
export interface UpdateRouteRequest {
    ApiId: string;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId: string;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export interface UpdateRouteResult {
    ApiGatewayManaged?: boolean | undefined;
    ApiKeyRequired?: boolean | undefined;
    AuthorizationScopes?: string[] | undefined;
    AuthorizationType?: AuthorizationType | undefined;
    AuthorizerId?: string | undefined;
    ModelSelectionExpression?: string | undefined;
    OperationName?: string | undefined;
    RequestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    RequestParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId?: string | undefined;
    RouteKey?: string | undefined;
    RouteResponseSelectionExpression?: string | undefined;
    Target?: string | undefined;
}
export interface UpdateRouteResponseRequest {
    ApiId: string;
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteId: string;
    RouteResponseId: string;
    RouteResponseKey?: string | undefined;
}
export interface UpdateRouteResponseResponse {
    ModelSelectionExpression?: string | undefined;
    ResponseModels?: {
        [key: string]: string | undefined;
    } | undefined;
    ResponseParameters?: {
        [key: string]: ParameterConstraints | undefined;
    } | undefined;
    RouteResponseId?: string | undefined;
    RouteResponseKey?: string | undefined;
}
export interface UpdateStageRequest {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiId: string;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName: string;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateStageResponse {
    AccessLogSettings?: AccessLogSettings | undefined;
    ApiGatewayManaged?: boolean | undefined;
    AutoDeploy?: boolean | undefined;
    ClientCertificateId?: string | undefined;
    CreatedDate?: Date | undefined;
    DefaultRouteSettings?: RouteSettings | undefined;
    DeploymentId?: string | undefined;
    Description?: string | undefined;
    LastDeploymentStatusMessage?: string | undefined;
    LastUpdatedDate?: Date | undefined;
    RouteSettings?: {
        [key: string]: RouteSettings | undefined;
    } | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateVpcLinkRequest {
    Name?: string | undefined;
    VpcLinkId: string;
}
export interface UpdateVpcLinkResponse {
    CreatedDate?: Date | undefined;
    Name?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcLinkId?: string | undefined;
    VpcLinkStatus?: VpcLinkStatus | undefined;
    VpcLinkStatusMessage?: string | undefined;
    VpcLinkVersion?: VpcLinkVersion | undefined;
}
export type CreateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Api resource.
 */
export declare const createApi: API.OperationMethod<CreateApiRequest & RegionInput, CreateApiResponse, CreateApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an API mapping.
 */
export declare const createApiMapping: API.OperationMethod<CreateApiMappingRequest & RegionInput, CreateApiMappingResponse, CreateApiMappingError, Credentials | HttpClient.HttpClient>;
export type CreateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Authorizer for an API.
 */
export declare const createAuthorizer: API.OperationMethod<CreateAuthorizerRequest & RegionInput, CreateAuthorizerResponse, CreateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Deployment for an API.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest & RegionInput, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a domain name.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest & RegionInput, CreateDomainNameResponse, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Integration.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationRequest & RegionInput, CreateIntegrationResult, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates an IntegrationResponses.
 */
export declare const createIntegrationResponse: API.OperationMethod<CreateIntegrationResponseRequest & RegionInput, CreateIntegrationResponseResponse, CreateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Model for an API.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest & RegionInput, CreateModelResponse, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreatePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal.
 */
export declare const createPortal: API.OperationMethod<CreatePortalRequest & RegionInput, CreatePortalResponse, CreatePortalError, Credentials | HttpClient.HttpClient>;
export type CreatePortalProductError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new portal product.
 */
export declare const createPortalProduct: API.OperationMethod<CreatePortalProductRequest & RegionInput, CreatePortalProductResponse, CreatePortalProductError, Credentials | HttpClient.HttpClient>;
export type CreateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new product page for a portal product.
 */
export declare const createProductPage: API.OperationMethod<CreateProductPageRequest & RegionInput, CreateProductPageResponse, CreateProductPageError, Credentials | HttpClient.HttpClient>;
export type CreateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a product REST endpoint page for a portal product.
 */
export declare const createProductRestEndpointPage: API.OperationMethod<CreateProductRestEndpointPageRequest & RegionInput, CreateProductRestEndpointPageResponse, CreateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type CreateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Route for an API.
 */
export declare const createRoute: API.OperationMethod<CreateRouteRequest & RegionInput, CreateRouteResult, CreateRouteError, Credentials | HttpClient.HttpClient>;
export type CreateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RouteResponse for a Route.
 */
export declare const createRouteResponse: API.OperationMethod<CreateRouteResponseRequest & RegionInput, CreateRouteResponseResponse, CreateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type CreateRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a RoutingRule.
 */
export declare const createRoutingRule: API.OperationMethod<CreateRoutingRuleRequest & RegionInput, CreateRoutingRuleResponse, CreateRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type CreateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a Stage for an API.
 */
export declare const createStage: API.OperationMethod<CreateStageRequest & RegionInput, CreateStageResponse, CreateStageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcLinkError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Creates a VPC link.
 */
export declare const createVpcLink: API.OperationMethod<CreateVpcLinkRequest & RegionInput, CreateVpcLinkResponse, CreateVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessLogSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the AccessLogSettings for a Stage. To disable access logging for a Stage, delete its AccessLogSettings.
 */
export declare const deleteAccessLogSettings: API.OperationMethod<DeleteAccessLogSettingsRequest & RegionInput, DeleteAccessLogSettingsResponse, DeleteAccessLogSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Api resource.
 */
export declare const deleteApi: API.OperationMethod<DeleteApiRequest & RegionInput, DeleteApiResponse, DeleteApiError, Credentials | HttpClient.HttpClient>;
export type DeleteApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an API mapping.
 */
export declare const deleteApiMapping: API.OperationMethod<DeleteApiMappingRequest & RegionInput, DeleteApiMappingResponse, DeleteApiMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Authorizer.
 */
export declare const deleteAuthorizer: API.OperationMethod<DeleteAuthorizerRequest & RegionInput, DeleteAuthorizerResponse, DeleteAuthorizerError, Credentials | HttpClient.HttpClient>;
export type DeleteCorsConfigurationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a CORS configuration.
 */
export declare const deleteCorsConfiguration: API.OperationMethod<DeleteCorsConfigurationRequest & RegionInput, DeleteCorsConfigurationResponse, DeleteCorsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Deployment.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest & RegionInput, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a domain name.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest & RegionInput, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an Integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest & RegionInput, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an IntegrationResponses.
 */
export declare const deleteIntegrationResponse: API.OperationMethod<DeleteIntegrationResponseRequest & RegionInput, DeleteIntegrationResponseResponse, DeleteIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest & RegionInput, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeletePortalError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal.
 */
export declare const deletePortal: API.OperationMethod<DeletePortalRequest & RegionInput, DeletePortalResponse, DeletePortalError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a portal product.
 */
export declare const deletePortalProduct: API.OperationMethod<DeletePortalProductRequest & RegionInput, DeletePortalProductResponse, DeletePortalProductError, Credentials | HttpClient.HttpClient>;
export type DeletePortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the sharing policy for a portal product.
 */
export declare const deletePortalProductSharingPolicy: API.OperationMethod<DeletePortalProductSharingPolicyRequest & RegionInput, DeletePortalProductSharingPolicyResponse, DeletePortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product page of a portal product.
 */
export declare const deleteProductPage: API.OperationMethod<DeleteProductPageRequest & RegionInput, DeleteProductPageResponse, DeleteProductPageError, Credentials | HttpClient.HttpClient>;
export type DeleteProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a product REST endpoint page.
 */
export declare const deleteProductRestEndpointPage: API.OperationMethod<DeleteProductRestEndpointPageRequest & RegionInput, DeleteProductRestEndpointPageResponse, DeleteProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Route.
 */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest & RegionInput, DeleteRouteResponse, DeleteRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteRequestParameterError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a route request parameter. Supported only for WebSocket APIs.
 */
export declare const deleteRouteRequestParameter: API.OperationMethod<DeleteRouteRequestParameterRequest & RegionInput, DeleteRouteRequestParameterResponse, DeleteRouteRequestParameterError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a RouteResponse.
 */
export declare const deleteRouteResponse: API.OperationMethod<DeleteRouteResponseRequest & RegionInput, DeleteRouteResponseResponse, DeleteRouteResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteSettingsError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the RouteSettings for a stage.
 */
export declare const deleteRouteSettings: API.OperationMethod<DeleteRouteSettingsRequest & RegionInput, DeleteRouteSettingsResponse, DeleteRouteSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a routing rule.
 */
export declare const deleteRoutingRule: API.OperationMethod<DeleteRoutingRuleRequest & RegionInput, DeleteRoutingRuleResponse, DeleteRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Stage.
 */
export declare const deleteStage: API.OperationMethod<DeleteStageRequest & RegionInput, DeleteStageResponse, DeleteStageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a VPC link.
 */
export declare const deleteVpcLink: API.OperationMethod<DeleteVpcLinkRequest & RegionInput, DeleteVpcLinkResponse, DeleteVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DisablePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the publication of a portal portal.
 */
export declare const disablePortal: API.OperationMethod<DisablePortalRequest & RegionInput, DisablePortalResponse, DisablePortalError, Credentials | HttpClient.HttpClient>;
export type ExportApiError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 *
 */
export declare const exportApi: API.OperationMethod<ExportApiRequest & RegionInput, ExportApiResponse, ExportApiError, Credentials | HttpClient.HttpClient>;
export type GetApiError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Api resource.
 */
export declare const getApi: API.OperationMethod<GetApiRequest & RegionInput, GetApiResponse, GetApiError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an API mapping.
 */
export declare const getApiMapping: API.OperationMethod<GetApiMappingRequest & RegionInput, GetApiMappingResponse, GetApiMappingError, Credentials | HttpClient.HttpClient>;
export type GetApiMappingsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets API mappings.
 */
export declare const getApiMappings: API.OperationMethod<GetApiMappingsRequest & RegionInput, GetApiMappingsResponse, GetApiMappingsError, Credentials | HttpClient.HttpClient>;
export type GetApisError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Api resources.
 */
export declare const getApis: API.OperationMethod<GetApisRequest & RegionInput, GetApisResponse, GetApisError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizerError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Authorizer.
 */
export declare const getAuthorizer: API.OperationMethod<GetAuthorizerRequest & RegionInput, GetAuthorizerResponse, GetAuthorizerError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizersError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Authorizers for an API.
 */
export declare const getAuthorizers: API.OperationMethod<GetAuthorizersRequest & RegionInput, GetAuthorizersResponse, GetAuthorizersError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest & RegionInput, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Deployments for an API.
 */
export declare const getDeployments: API.OperationMethod<GetDeploymentsRequest & RegionInput, GetDeploymentsResponse, GetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a domain name.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest & RegionInput, GetDomainNameResponse, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetDomainNamesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the domain names for an AWS account.
 */
export declare const getDomainNames: API.OperationMethod<GetDomainNamesRequest & RegionInput, GetDomainNamesResponse, GetDomainNamesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an Integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest & RegionInput, GetIntegrationResult, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets an IntegrationResponses.
 */
export declare const getIntegrationResponse: API.OperationMethod<GetIntegrationResponseRequest & RegionInput, GetIntegrationResponseResponse, GetIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the IntegrationResponses for an Integration.
 */
export declare const getIntegrationResponses: API.OperationMethod<GetIntegrationResponsesRequest & RegionInput, GetIntegrationResponsesResponse, GetIntegrationResponsesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Integrations for an API.
 */
export declare const getIntegrations: API.OperationMethod<GetIntegrationsRequest & RegionInput, GetIntegrationsResponse, GetIntegrationsError, Credentials | HttpClient.HttpClient>;
export type GetModelError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Model.
 */
export declare const getModel: API.OperationMethod<GetModelRequest & RegionInput, GetModelResponse, GetModelError, Credentials | HttpClient.HttpClient>;
export type GetModelsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Models for an API.
 */
export declare const getModels: API.OperationMethod<GetModelsRequest & RegionInput, GetModelsResponse, GetModelsError, Credentials | HttpClient.HttpClient>;
export type GetModelTemplateError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model template.
 */
export declare const getModelTemplate: API.OperationMethod<GetModelTemplateRequest & RegionInput, GetModelTemplateResponse, GetModelTemplateError, Credentials | HttpClient.HttpClient>;
export type GetPortalError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal.
 */
export declare const getPortal: API.OperationMethod<GetPortalRequest & RegionInput, GetPortalResponse, GetPortalError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a portal product.
 */
export declare const getPortalProduct: API.OperationMethod<GetPortalProductRequest & RegionInput, GetPortalProductResponse, GetPortalProductError, Credentials | HttpClient.HttpClient>;
export type GetPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the sharing policy for a portal product.
 */
export declare const getPortalProductSharingPolicy: API.OperationMethod<GetPortalProductSharingPolicyRequest & RegionInput, GetPortalProductSharingPolicyResponse, GetPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product page of a portal product.
 */
export declare const getProductPage: API.OperationMethod<GetProductPageRequest & RegionInput, GetProductPageResponse, GetProductPageError, Credentials | HttpClient.HttpClient>;
export type GetProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a product REST endpoint page.
 */
export declare const getProductRestEndpointPage: API.OperationMethod<GetProductRestEndpointPageRequest & RegionInput, GetProductRestEndpointPageResponse, GetProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type GetRouteError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Route.
 */
export declare const getRoute: API.OperationMethod<GetRouteRequest & RegionInput, GetRouteResult, GetRouteError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponseError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a RouteResponse.
 */
export declare const getRouteResponse: API.OperationMethod<GetRouteResponseRequest & RegionInput, GetRouteResponseResponse, GetRouteResponseError, Credentials | HttpClient.HttpClient>;
export type GetRouteResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the RouteResponses for a Route.
 */
export declare const getRouteResponses: API.OperationMethod<GetRouteResponsesRequest & RegionInput, GetRouteResponsesResponse, GetRouteResponsesError, Credentials | HttpClient.HttpClient>;
export type GetRoutesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Routes for an API.
 */
export declare const getRoutes: API.OperationMethod<GetRoutesRequest & RegionInput, GetRoutesResponse, GetRoutesError, Credentials | HttpClient.HttpClient>;
export type GetRoutingRuleError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a routing rule.
 */
export declare const getRoutingRule: API.OperationMethod<GetRoutingRuleRequest & RegionInput, GetRoutingRuleResponse, GetRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type GetStageError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a Stage.
 */
export declare const getStage: API.OperationMethod<GetStageRequest & RegionInput, GetStageResponse, GetStageError, Credentials | HttpClient.HttpClient>;
export type GetStagesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the Stages for an API.
 */
export declare const getStages: API.OperationMethod<GetStagesRequest & RegionInput, GetStagesResponse, GetStagesError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of Tag resources.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest & RegionInput, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinkError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a VPC link.
 */
export declare const getVpcLink: API.OperationMethod<GetVpcLinkRequest & RegionInput, GetVpcLinkResponse, GetVpcLinkError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinksError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a collection of VPC links.
 */
export declare const getVpcLinks: API.OperationMethod<GetVpcLinksRequest & RegionInput, GetVpcLinksResponse, GetVpcLinksError, Credentials | HttpClient.HttpClient>;
export type ImportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an API.
 */
export declare const importApi: API.OperationMethod<ImportApiRequest & RegionInput, ImportApiResponse, ImportApiError, Credentials | HttpClient.HttpClient>;
export type ListPortalProductsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portal products.
 */
export declare const listPortalProducts: API.OperationMethod<ListPortalProductsRequest & RegionInput, ListPortalProductsResponse, ListPortalProductsError, Credentials | HttpClient.HttpClient>;
export type ListPortalsError = AccessDeniedException | BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Lists portals.
 */
export declare const listPortals: API.OperationMethod<ListPortalsRequest & RegionInput, ListPortalsResponse, ListPortalsError, Credentials | HttpClient.HttpClient>;
export type ListProductPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product pages for a portal product.
 */
export declare const listProductPages: API.OperationMethod<ListProductPagesRequest & RegionInput, ListProductPagesResponse, ListProductPagesError, Credentials | HttpClient.HttpClient>;
export type ListProductRestEndpointPagesError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the product REST endpoint pages of a portal product.
 */
export declare const listProductRestEndpointPages: API.OperationMethod<ListProductRestEndpointPagesRequest & RegionInput, ListProductRestEndpointPagesResponse, ListProductRestEndpointPagesError, Credentials | HttpClient.HttpClient>;
export type ListRoutingRulesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists routing rules.
 */
export declare const listRoutingRules: API.PaginatedOperationMethod<ListRoutingRulesRequest & RegionInput, ListRoutingRulesResponse, ListRoutingRulesError, Credentials | HttpClient.HttpClient, RoutingRule>;
export type PreviewPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a portal preview.
 */
export declare const previewPortal: API.OperationMethod<PreviewPortalRequest & RegionInput, PreviewPortalResponse, PreviewPortalError, Credentials | HttpClient.HttpClient>;
export type PublishPortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a portal.
 */
export declare const publishPortal: API.OperationMethod<PublishPortalRequest & RegionInput, PublishPortalResponse, PublishPortalError, Credentials | HttpClient.HttpClient>;
export type PutPortalProductSharingPolicyError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the sharing policy for a portal product.
 */
export declare const putPortalProductSharingPolicy: API.OperationMethod<PutPortalProductSharingPolicyRequest & RegionInput, PutPortalProductSharingPolicyResponse, PutPortalProductSharingPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRoutingRuleError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a routing rule.
 */
export declare const putRoutingRule: API.OperationMethod<PutRoutingRuleRequest & RegionInput, PutRoutingRuleResponse, PutRoutingRuleError, Credentials | HttpClient.HttpClient>;
export type ReimportApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Puts an Api resource.
 */
export declare const reimportApi: API.OperationMethod<ReimportApiRequest & RegionInput, ReimportApiResponse, ReimportApiError, Credentials | HttpClient.HttpClient>;
export type ResetAuthorizersCacheError = NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Resets all authorizer cache entries on a stage. Supported only for HTTP APIs.
 */
export declare const resetAuthorizersCache: API.OperationMethod<ResetAuthorizersCacheRequest & RegionInput, ResetAuthorizersCacheResponse, ResetAuthorizersCacheError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new Tag resource to represent a tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Tag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Api resource.
 */
export declare const updateApi: API.OperationMethod<UpdateApiRequest & RegionInput, UpdateApiResponse, UpdateApiError, Credentials | HttpClient.HttpClient>;
export type UpdateApiMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The API mapping.
 */
export declare const updateApiMapping: API.OperationMethod<UpdateApiMappingRequest & RegionInput, UpdateApiMappingResponse, UpdateApiMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Authorizer.
 */
export declare const updateAuthorizer: API.OperationMethod<UpdateAuthorizerRequest & RegionInput, UpdateAuthorizerResponse, UpdateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Deployment.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentRequest & RegionInput, UpdateDeploymentResponse, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a domain name.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest & RegionInput, UpdateDomainNameResponse, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an Integration.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationRequest & RegionInput, UpdateIntegrationResult, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an IntegrationResponses.
 */
export declare const updateIntegrationResponse: API.OperationMethod<UpdateIntegrationResponseRequest & RegionInput, UpdateIntegrationResponseResponse, UpdateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Model.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest & RegionInput, UpdateModelResponse, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalError = AccessDeniedException | BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a portal.
 */
export declare const updatePortal: API.OperationMethod<UpdatePortalRequest & RegionInput, UpdatePortalResponse, UpdatePortalError, Credentials | HttpClient.HttpClient>;
export type UpdatePortalProductError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the portal product.
 */
export declare const updatePortalProduct: API.OperationMethod<UpdatePortalProductRequest & RegionInput, UpdatePortalProductResponse, UpdatePortalProductError, Credentials | HttpClient.HttpClient>;
export type UpdateProductPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product page of a portal product.
 */
export declare const updateProductPage: API.OperationMethod<UpdateProductPageRequest & RegionInput, UpdateProductPageResponse, UpdateProductPageError, Credentials | HttpClient.HttpClient>;
export type UpdateProductRestEndpointPageError = AccessDeniedException | BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a product REST endpoint page.
 */
export declare const updateProductRestEndpointPage: API.OperationMethod<UpdateProductRestEndpointPageRequest & RegionInput, UpdateProductRestEndpointPageResponse, UpdateProductRestEndpointPageError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Route.
 */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest & RegionInput, UpdateRouteResult, UpdateRouteError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a RouteResponse.
 */
export declare const updateRouteResponse: API.OperationMethod<UpdateRouteResponseRequest & RegionInput, UpdateRouteResponseResponse, UpdateRouteResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateStageError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a Stage.
 */
export declare const updateStage: API.OperationMethod<UpdateStageRequest & RegionInput, UpdateStageResponse, UpdateStageError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcLinkError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a VPC link.
 */
export declare const updateVpcLink: API.OperationMethod<UpdateVpcLinkRequest & RegionInput, UpdateVpcLinkResponse, UpdateVpcLinkError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apigatewayv2.d.ts.map