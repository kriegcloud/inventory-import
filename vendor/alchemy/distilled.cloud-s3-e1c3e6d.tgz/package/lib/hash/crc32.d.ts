/**
 * CRC32 checksum implementation.
 * Prefers Node.js zlib.crc32 (Node 20.15+) for performance and falls back to
 * the plain-JavaScript {@link Crc32}. Browsers resolve `#crc32` to
 * `crc32.browser.ts` instead, which never imports `node:zlib`.
 */
import type { Checksum } from "./checksum.ts";
import { Crc32 } from "./crc32-portable.ts";
export { Crc32 };
export declare const getCrc32ChecksumAlgorithmFunction: () => new () => Checksum;
//# sourceMappingURL=crc32.d.ts.map