import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetAllTemplatesRequest {
}
export type GetAllTemplatesResponseBodyList = Array<string>;
export type GetAllTemplatesResponse = GetAllTemplatesResponseBodyList;
export interface GetTemplateRequest {
    name: string;
}
/** Gitignore Template */
export interface GitignoreTemplate {
    name: string;
    source: string;
}
export type GetAllTemplatesError = GithubOpError;
/** Get all gitignore templates List all templates available to pass as an option when [creating a repository](https://docs.github.com/rest/repos/repos#create-a-repository-for-the-authenticated-user). */
export declare const getAllTemplates: API.OperationMethod<GetAllTemplatesRequest, GetAllTemplatesResponse, GetAllTemplatesError, GithubOpContext>;
export type GetTemplateError = GithubOpError;
/** Get a gitignore template Get the content of a gitignore template. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw .gitignore contents. */
export declare const getTemplate: API.OperationMethod<GetTemplateRequest, GitignoreTemplate, GetTemplateError, GithubOpContext>;
//# sourceMappingURL=gitignore.d.ts.map