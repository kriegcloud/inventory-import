import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type TableARN = string;
export interface CompleteTableMigrationRequest {
    tableARN: string;
}
export interface CompleteTableMigrationResponse {
}
export type TableBucketARN = string;
export type NamespaceName = string;
export type NamespaceList = string[];
export interface CreateNamespaceRequest {
    tableBucketARN: string;
    namespace: string[];
}
export interface CreateNamespaceResponse {
    tableBucketARN: string;
    namespace: string[];
}
export type TableName = string;
export type OpenTableFormat = "ICEBERG" | (string & {});
export interface SchemaField {
    id?: number | undefined;
    name: string;
    type: string;
    required?: boolean | undefined;
}
export type SchemaFieldList = SchemaField[];
export interface IcebergSchema {
    fields: SchemaField[];
}
export type SchemaV2FieldType = "struct" | (string & {});
export interface SchemaV2Field {
    id: number;
    name: string;
    type: any;
    required: boolean;
    doc?: string | undefined;
}
export type SchemaV2FieldList = SchemaV2Field[];
export type IntegerList = number[];
export interface IcebergSchemaV2 {
    type: SchemaV2FieldType;
    fields: SchemaV2Field[];
    schemaId?: number | undefined;
    identifierFieldIds?: number[] | undefined;
}
export interface IcebergPartitionField {
    sourceId: number;
    transform: string;
    name: string;
    fieldId?: number | undefined;
}
export type IcebergPartitionFieldList = IcebergPartitionField[];
export interface IcebergPartitionSpec {
    fields: IcebergPartitionField[];
    specId?: number | undefined;
}
export type IcebergSortDirection = "asc" | "desc" | (string & {});
export type IcebergNullOrder = "nulls-first" | "nulls-last" | (string & {});
export interface IcebergSortField {
    sourceId: number;
    transform: string;
    direction: IcebergSortDirection;
    nullOrder: IcebergNullOrder;
}
export type IcebergSortFieldList = IcebergSortField[];
export interface IcebergSortOrder {
    orderId: number;
    fields: IcebergSortField[];
}
export type TableProperties = {
    [key: string]: string | undefined;
};
export interface IcebergMetadata {
    schema?: IcebergSchema | undefined;
    schemaV2?: IcebergSchemaV2 | undefined;
    partitionSpec?: IcebergPartitionSpec | undefined;
    writeOrder?: IcebergSortOrder | undefined;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TableMetadata = {
    iceberg: IcebergMetadata;
};
export type SSEAlgorithm = "AES256" | "aws:kms" | (string & {});
export interface EncryptionConfiguration {
    sseAlgorithm: SSEAlgorithm;
    kmsKeyArn?: string | undefined;
}
export type StorageClass = "STANDARD" | "INTELLIGENT_TIERING" | (string & {});
export interface StorageClassConfiguration {
    storageClass: StorageClass;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    format: OpenTableFormat;
    metadata?: TableMetadata | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    storageClassConfiguration?: StorageClassConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VersionToken = string;
export interface CreateTableResponse {
    tableARN: string;
    versionToken: string;
}
export type TableBucketName = string;
export interface CreateTableBucketRequest {
    name: string;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    storageClassConfiguration?: StorageClassConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateTableBucketResponse {
    arn: string;
}
export interface DeleteNamespaceRequest {
    tableBucketARN: string;
    namespace: string;
}
export interface DeleteNamespaceResponse {
}
export interface DeleteTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    versionToken?: string | undefined;
}
export interface DeleteTableResponse {
}
export interface DeleteTableBucketRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketResponse {
}
export interface DeleteTableBucketEncryptionRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketEncryptionResponse {
}
export interface DeleteTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketMetricsConfigurationResponse {
}
export interface DeleteTableBucketPolicyRequest {
    tableBucketARN: string;
}
export interface DeleteTableBucketPolicyResponse {
}
export interface DeleteTableBucketReplicationRequest {
    tableBucketARN: string;
    versionToken?: string | undefined;
}
export interface DeleteTableBucketReplicationResponse {
}
export interface DeleteTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface DeleteTablePolicyResponse {
}
export interface DeleteTableReplicationRequest {
    tableArn: string;
    versionToken: string;
}
export interface DeleteTableReplicationResponse {
}
export interface GetNamespaceRequest {
    tableBucketARN: string;
    namespace: string;
}
export type AccountId = string;
export type NamespaceId = string;
export type TableBucketId = string;
export interface GetNamespaceResponse {
    namespace: string[];
    createdAt: Date;
    createdBy: string;
    ownerAccountId: string;
    namespaceId?: string | undefined;
    tableBucketId?: string | undefined;
}
export interface GetTableRequest {
    tableBucketARN?: string | undefined;
    namespace?: string | undefined;
    name?: string | undefined;
    tableArn?: string | undefined;
}
export type TableType = "customer" | "aws" | (string & {});
export type MetadataLocation = string;
export type WarehouseLocation = string;
export interface ReplicationInformation {
    sourceTableARN: string;
}
export interface ManagedTableInformation {
    replicationInformation?: ReplicationInformation | undefined;
}
export interface GetTableResponse {
    name: string;
    type: TableType;
    tableARN: string;
    namespace: string[];
    namespaceId?: string | undefined;
    versionToken: string;
    metadataLocation?: string | undefined;
    warehouseLocation: string;
    createdAt: Date;
    createdBy: string;
    managedByService?: string | undefined;
    modifiedAt: Date;
    modifiedBy?: string | undefined;
    ownerAccountId: string;
    format: OpenTableFormat;
    tableBucketId?: string | undefined;
    managedTableInformation?: ManagedTableInformation | undefined;
}
export interface GetTableBucketRequest {
    tableBucketARN: string;
}
export type TableBucketType = "customer" | "aws" | (string & {});
export interface GetTableBucketResponse {
    arn: string;
    name: string;
    ownerAccountId: string;
    createdAt: Date;
    tableBucketId?: string | undefined;
    type?: TableBucketType | undefined;
}
export interface GetTableBucketEncryptionRequest {
    tableBucketARN: string;
}
export interface GetTableBucketEncryptionResponse {
    encryptionConfiguration: EncryptionConfiguration;
}
export interface GetTableBucketLoggingRequest {
    tableBucketARN: string;
}
export type LoggingTargetBucket = string;
export type LoggingTargetPrefix = string;
export type PartitionDateSource = "EventTime" | "DeliveryTime" | (string & {});
export interface PartitionedPrefix {
    partitionDateSource: PartitionDateSource;
}
export interface TargetObjectKeyFormat {
    partitionedPrefix: PartitionedPrefix;
}
export interface LoggingEnabled {
    targetBucket: string;
    targetPrefix: string;
    targetObjectKeyFormat: TargetObjectKeyFormat;
}
export interface TableBucketLoggingStatus {
    loggingEnabled?: LoggingEnabled | undefined;
}
export interface GetTableBucketLoggingResponse {
    tableBucketLoggingStatus: TableBucketLoggingStatus;
}
export interface GetTableBucketMaintenanceConfigurationRequest {
    tableBucketARN: string;
}
export type TableBucketMaintenanceType = "icebergUnreferencedFileRemoval" | (string & {});
export type MaintenanceStatus = "enabled" | "disabled" | (string & {});
export type PositiveInteger = number;
export interface IcebergUnreferencedFileRemovalSettings {
    unreferencedDays?: number | undefined;
    nonCurrentDays?: number | undefined;
}
export type TableBucketMaintenanceSettings = {
    icebergUnreferencedFileRemoval: IcebergUnreferencedFileRemovalSettings;
};
export interface TableBucketMaintenanceConfigurationValue {
    status?: MaintenanceStatus | undefined;
    settings?: TableBucketMaintenanceSettings | undefined;
}
export type TableBucketMaintenanceConfiguration = {
    [key in TableBucketMaintenanceType]?: TableBucketMaintenanceConfigurationValue | undefined;
};
export interface GetTableBucketMaintenanceConfigurationResponse {
    tableBucketARN: string;
    configuration: {
        [key: string]: TableBucketMaintenanceConfigurationValue | undefined;
    };
}
export interface GetTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface GetTableBucketMetricsConfigurationResponse {
    tableBucketARN: string;
    id?: string | undefined;
}
export interface GetTableBucketPolicyRequest {
    tableBucketARN: string;
}
export type ResourcePolicy = string;
export interface GetTableBucketPolicyResponse {
    resourcePolicy: string;
}
export interface GetTableBucketReplicationRequest {
    tableBucketARN: string;
}
export type IAMRole = string;
export interface ReplicationDestination {
    destinationTableBucketARN: string;
}
export type ReplicationDestinations = ReplicationDestination[];
export interface TableBucketReplicationRule {
    destinations: ReplicationDestination[];
}
export type TableBucketReplicationRules = TableBucketReplicationRule[];
export interface TableBucketReplicationConfiguration {
    role: string;
    rules: TableBucketReplicationRule[];
}
export interface GetTableBucketReplicationResponse {
    versionToken: string;
    configuration: TableBucketReplicationConfiguration;
}
export interface GetTableBucketStorageClassRequest {
    tableBucketARN: string;
}
export interface GetTableBucketStorageClassResponse {
    storageClassConfiguration: StorageClassConfiguration;
}
export interface GetTableEncryptionRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableEncryptionResponse {
    encryptionConfiguration: EncryptionConfiguration;
}
export interface GetTableMaintenanceConfigurationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export type TableMaintenanceType = "icebergCompaction" | "icebergSnapshotManagement" | (string & {});
export type IcebergCompactionStrategy = "auto" | "binpack" | "sort" | "z-order" | (string & {});
export interface IcebergCompactionSettings {
    targetFileSizeMB?: number | undefined;
    strategy?: IcebergCompactionStrategy | undefined;
}
export interface IcebergSnapshotManagementSettings {
    minSnapshotsToKeep?: number | undefined;
    maxSnapshotAgeHours?: number | undefined;
}
export type TableMaintenanceSettings = {
    icebergCompaction: IcebergCompactionSettings;
    icebergSnapshotManagement?: undefined;
} | {
    icebergCompaction?: undefined;
    icebergSnapshotManagement: IcebergSnapshotManagementSettings;
};
export interface TableMaintenanceConfigurationValue {
    status?: MaintenanceStatus | undefined;
    settings?: TableMaintenanceSettings | undefined;
}
export type TableMaintenanceConfiguration = {
    [key in TableMaintenanceType]?: TableMaintenanceConfigurationValue | undefined;
};
export interface GetTableMaintenanceConfigurationResponse {
    tableARN: string;
    configuration: {
        [key: string]: TableMaintenanceConfigurationValue | undefined;
    };
}
export interface GetTableMaintenanceJobStatusRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export type TableMaintenanceJobType = "icebergCompaction" | "icebergSnapshotManagement" | "icebergUnreferencedFileRemoval" | (string & {});
export type JobStatus = "Not_Yet_Run" | "Successful" | "Failed" | "Disabled" | (string & {});
export interface TableMaintenanceJobStatusValue {
    status: JobStatus;
    lastRunTimestamp?: Date | undefined;
    failureMessage?: string | undefined;
}
export type TableMaintenanceJobStatus = {
    [key in TableMaintenanceJobType]?: TableMaintenanceJobStatusValue | undefined;
};
export interface GetTableMaintenanceJobStatusResponse {
    tableARN: string;
    status: {
        [key: string]: TableMaintenanceJobStatusValue | undefined;
    };
}
export interface GetTableMetadataLocationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableMetadataLocationResponse {
    versionToken: string;
    metadataLocation?: string | undefined;
    warehouseLocation: string;
}
export type MigrationId = string;
export interface GetTableMigrationRequest {
    migrationId?: string | undefined;
    tableARN?: string | undefined;
}
export type MigrationType = "start" | "sync" | (string & {});
export type MigrationState = "new" | "planning" | "pendingReview" | "queued" | "migrating" | "succeeded" | "failed" | "cancelling" | "cancelled" | (string & {});
export type RoleArn = string;
export type MigrationFailureCode = "rolePermissions" | "sourcePermissions" | "destinationPermissions" | "resourceNotFound" | "sourceNotSupported" | "objectMigrationReport" | "objectCompatibilityReport" | "tableCompatibilityReport" | "internalError" | "reportBucketNotSupported" | (string & {});
export type MigrationFailureDetail = string;
export interface MigrationFailureReason {
    code: MigrationFailureCode;
    detail?: string | undefined;
}
export interface PlanningStats {
    objectsScanned?: number | undefined;
    objectsPlanned?: number | undefined;
    partitionCount?: number | undefined;
}
export interface MigrationStats {
    objectsMigrated?: number | undefined;
    objectsFailedMigration?: number | undefined;
    objectsPendingMigration?: number | undefined;
}
export type MigrationSourceType = "glueTable" | (string & {});
export interface GlueTableSource {
    catalogId: string;
    databaseName: string;
    tableName: string;
}
export type SourceConfiguration = {
    glueTable: GlueTableSource;
};
export type MigrationTargetFileSizeMB = number;
export interface MigrationCompactionSettings {
    targetFileSizeMB?: number | undefined;
    strategy?: IcebergCompactionStrategy | undefined;
}
export type MigrationMinSnapshotsToKeep = number;
export interface MigrationSnapshotManagementSettings {
    minSnapshotsToKeep?: number | undefined;
    maxSnapshotAgeHours?: number | undefined;
}
export interface MaintenanceSettings {
    icebergCompaction?: MigrationCompactionSettings | undefined;
    icebergSnapshotManagement?: MigrationSnapshotManagementSettings | undefined;
}
export type UnmatchedSourceFieldsPolicy = "fail" | "drop" | (string & {});
export type IncompatibleValuesPolicy = "fail" | "setNull" | (string & {});
export interface MigrationPolicies {
    unmatchedSourceFieldsPolicy?: UnmatchedSourceFieldsPolicy | undefined;
    incompatibleValuesPolicy?: IncompatibleValuesPolicy | undefined;
}
export interface DataMigrationOverview {
    maintenanceSettings: MaintenanceSettings;
    migrationPolicies: MigrationPolicies;
}
export type S3BucketARN = string;
export type MigrationReportPrefix = string;
export type ReportObjectKey = string;
export type ChecksumCRC64NVME = string;
export type FindingCategory = "access" | "metadata" | "data" | "internal" | (string & {});
export type FindingCategoryCounts = {
    [key in FindingCategory]?: number | undefined;
};
export interface ReportOverview {
    prefix?: string | undefined;
    key?: string | undefined;
    checksumCRC64NVME?: string | undefined;
    invalidFindings?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface MigrationOutputOverview {
    bucket: string;
    tableCompatibilityReport: ReportOverview;
    objectCompatibilityReport: ReportOverview;
    objectMigrationReport: ReportOverview;
}
export interface GetTableMigrationResponse {
    migrationId: string;
    tableBucketARN: string;
    namespace: string;
    tableARN?: string | undefined;
    name: string;
    type: MigrationType;
    state: MigrationState;
    roleARN: string;
    reviewMigrationPlan: boolean;
    hasValidPlan?: boolean | undefined;
    createdAt: Date;
    stateUpdatedAt: Date;
    failureReason?: MigrationFailureReason | undefined;
    planningStats?: PlanningStats | undefined;
    migrationStats?: MigrationStats | undefined;
    sourceType: MigrationSourceType;
    source: SourceConfiguration;
    dataMigration: DataMigrationOverview;
    migrationOutput: MigrationOutputOverview;
}
export interface GetTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTablePolicyResponse {
    resourcePolicy: string;
}
export interface GetTableRecordExpirationConfigurationRequest {
    tableArn: string;
}
export type TableRecordExpirationStatus = "enabled" | "disabled" | (string & {});
export interface TableRecordExpirationSettings {
    days?: number | undefined;
}
export interface TableRecordExpirationConfigurationValue {
    status?: TableRecordExpirationStatus | undefined;
    settings?: TableRecordExpirationSettings | undefined;
}
export interface GetTableRecordExpirationConfigurationResponse {
    configuration: TableRecordExpirationConfigurationValue;
}
export interface GetTableRecordExpirationJobStatusRequest {
    tableArn: string;
}
export type TableRecordExpirationJobStatus = "NotYetRun" | "Successful" | "Failed" | "Disabled" | (string & {});
export interface TableRecordExpirationJobMetrics {
    deletedDataFiles?: number | undefined;
    deletedRecords?: number | undefined;
    removedFilesSize?: number | undefined;
}
export interface GetTableRecordExpirationJobStatusResponse {
    status: TableRecordExpirationJobStatus;
    lastRunTimestamp?: Date | undefined;
    failureMessage?: string | undefined;
    metrics?: TableRecordExpirationJobMetrics | undefined;
}
export interface GetTableReplicationRequest {
    tableArn: string;
}
export interface TableReplicationRule {
    destinations: ReplicationDestination[];
}
export type TableReplicationRules = TableReplicationRule[];
export interface TableReplicationConfiguration {
    role: string;
    rules: TableReplicationRule[];
}
export interface GetTableReplicationResponse {
    versionToken: string;
    configuration: TableReplicationConfiguration;
}
export interface GetTableReplicationStatusRequest {
    tableArn: string;
}
export type ReplicationStatus = "pending" | "completed" | "failed" | (string & {});
export interface LastSuccessfulReplicatedUpdate {
    metadataLocation: string;
    timestamp: Date;
}
export interface ReplicationDestinationStatusModel {
    replicationStatus: ReplicationStatus;
    destinationTableBucketArn: string;
    destinationTableArn?: string | undefined;
    lastSuccessfulReplicatedUpdate?: LastSuccessfulReplicatedUpdate | undefined;
    failureMessage?: string | undefined;
}
export type ReplicationDestinationStatuses = ReplicationDestinationStatusModel[];
export interface GetTableReplicationStatusResponse {
    sourceTableArn: string;
    destinations: ReplicationDestinationStatusModel[];
}
export interface GetTableStorageClassRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
}
export interface GetTableStorageClassResponse {
    storageClassConfiguration: StorageClassConfiguration;
}
export type NextToken = string;
export type ListNamespacesLimit = number;
export interface ListNamespacesRequest {
    tableBucketARN: string;
    prefix?: string | undefined;
    continuationToken?: string | undefined;
    maxNamespaces?: number | undefined;
}
export interface NamespaceSummary {
    namespace: string[];
    createdAt: Date;
    createdBy: string;
    ownerAccountId: string;
    namespaceId?: string | undefined;
    tableBucketId?: string | undefined;
}
export type NamespaceSummaryList = NamespaceSummary[];
export interface ListNamespacesResponse {
    namespaces: NamespaceSummary[];
    continuationToken?: string | undefined;
}
export type ListTableBucketsLimit = number;
export interface ListTableBucketsRequest {
    prefix?: string | undefined;
    continuationToken?: string | undefined;
    maxBuckets?: number | undefined;
    type?: TableBucketType | undefined;
}
export interface TableBucketSummary {
    arn: string;
    name: string;
    ownerAccountId: string;
    createdAt: Date;
    tableBucketId?: string | undefined;
    type?: TableBucketType | undefined;
}
export type TableBucketSummaryList = TableBucketSummary[];
export interface ListTableBucketsResponse {
    tableBuckets: TableBucketSummary[];
    continuationToken?: string | undefined;
}
export type ListTableMigrationsLimit = number;
export interface ListTableMigrationsRequest {
    tableBucketARN?: string | undefined;
    namespace?: string | undefined;
    name?: string | undefined;
    tableARN?: string | undefined;
    state?: MigrationState | undefined;
    hasValidPlan?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MigrationSummary {
    migrationId: string;
    tableBucketARN: string;
    namespace: string;
    tableARN?: string | undefined;
    name: string;
    type: MigrationType;
    state: MigrationState;
    hasValidPlan?: boolean | undefined;
    createdAt: Date;
    stateUpdatedAt: Date;
}
export type MigrationSummaryList = MigrationSummary[];
export interface ListTableMigrationsResponse {
    migrations: MigrationSummary[];
    nextToken?: string | undefined;
}
export type ListTablesLimit = number;
export interface ListTablesRequest {
    tableBucketARN: string;
    namespace?: string | undefined;
    prefix?: string | undefined;
    continuationToken?: string | undefined;
    maxTables?: number | undefined;
}
export interface TableSummary {
    namespace: string[];
    name: string;
    type: TableType;
    tableARN: string;
    createdAt: Date;
    modifiedAt: Date;
    managedByService?: string | undefined;
    namespaceId?: string | undefined;
    tableBucketId?: string | undefined;
}
export type TableSummaryList = TableSummary[];
export interface ListTablesResponse {
    tables: TableSummary[];
    continuationToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutTableBucketEncryptionRequest {
    tableBucketARN: string;
    encryptionConfiguration: EncryptionConfiguration;
}
export interface PutTableBucketEncryptionResponse {
}
export interface PutTableBucketLoggingRequest {
    tableBucketARN: string;
    tableBucketLoggingStatus: TableBucketLoggingStatus;
}
export interface PutTableBucketLoggingResponse {
}
export interface PutTableBucketMaintenanceConfigurationRequest {
    tableBucketARN: string;
    type: TableBucketMaintenanceType;
    value: TableBucketMaintenanceConfigurationValue;
}
export interface PutTableBucketMaintenanceConfigurationResponse {
}
export interface PutTableBucketMetricsConfigurationRequest {
    tableBucketARN: string;
}
export interface PutTableBucketMetricsConfigurationResponse {
}
export interface PutTableBucketPolicyRequest {
    tableBucketARN: string;
    resourcePolicy: string;
}
export interface PutTableBucketPolicyResponse {
}
export interface PutTableBucketReplicationRequest {
    tableBucketARN: string;
    versionToken?: string | undefined;
    configuration: TableBucketReplicationConfiguration;
}
export interface PutTableBucketReplicationResponse {
    versionToken: string;
    status: string;
}
export interface PutTableBucketStorageClassRequest {
    tableBucketARN: string;
    storageClassConfiguration: StorageClassConfiguration;
}
export interface PutTableBucketStorageClassResponse {
}
export interface PutTableMaintenanceConfigurationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    type: TableMaintenanceType;
    value: TableMaintenanceConfigurationValue;
}
export interface PutTableMaintenanceConfigurationResponse {
}
export interface PutTablePolicyRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    resourcePolicy: string;
}
export interface PutTablePolicyResponse {
}
export interface PutTableRecordExpirationConfigurationRequest {
    tableArn: string;
    value: TableRecordExpirationConfigurationValue;
}
export interface PutTableRecordExpirationConfigurationResponse {
}
export interface PutTableReplicationRequest {
    tableArn: string;
    versionToken?: string | undefined;
    configuration: TableReplicationConfiguration;
}
export interface PutTableReplicationResponse {
    versionToken: string;
    status: string;
}
export interface RenameTableRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    newNamespaceName?: string | undefined;
    newName?: string | undefined;
    versionToken?: string | undefined;
}
export interface RenameTableResponse {
}
export type DataFileFormat = "parquet" | (string & {});
export type CompressionCodec = "zstd" | "snappy" | "gzip" | "uncompressed" | (string & {});
export interface MigrationTableProperties {
    writeFormat?: DataFileFormat | undefined;
    icebergFormatVersion?: number | undefined;
    compressionCodec?: CompressionCodec | undefined;
    dictionaryEncoding?: boolean | undefined;
}
export interface DestinationTable {
    tableBucketARN: string;
    namespace: string;
    name: string;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    storageClassConfiguration?: StorageClassConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    properties?: MigrationTableProperties | undefined;
    schema?: IcebergSchemaV2 | undefined;
    icebergSortOrder?: IcebergSortOrder | undefined;
}
export interface DataMigrationSettings {
    maintenanceSettings?: MaintenanceSettings | undefined;
    migrationPolicies?: MigrationPolicies | undefined;
}
export interface MigrationReportPrefixes {
    tableCompatibilityReport?: string | undefined;
    objectCompatibilityReport?: string | undefined;
    objectMigrationReport?: string | undefined;
}
export interface MigrationOutputConfiguration {
    bucket: string;
    prefixes?: MigrationReportPrefixes | undefined;
}
export interface StartTableMigrationRequest {
    roleARN: string;
    destinationTable: DestinationTable;
    sourceType: MigrationSourceType;
    source: SourceConfiguration;
    dataMigration?: DataMigrationSettings | undefined;
    reviewMigrationPlan?: boolean | undefined;
    migrationOutput: MigrationOutputConfiguration;
}
export interface StartTableMigrationResponse {
    migrationId: string;
    state: MigrationState;
}
export interface SyncTableMigrationRequest {
    roleARN: string;
    tableARN: string;
    reviewMigrationPlan?: boolean | undefined;
    migrationOutput: MigrationOutputConfiguration;
}
export interface SyncTableMigrationResponse {
    migrationId: string;
    state: MigrationState;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateTableMetadataLocationRequest {
    tableBucketARN: string;
    namespace: string;
    name: string;
    versionToken: string;
    metadataLocation: string;
}
export interface UpdateTableMetadataLocationResponse {
    name: string;
    tableARN: string;
    namespace: string[];
    versionToken: string;
    metadataLocation: string;
}
export type MigrationRequestedState = "queued" | "cancelled" | (string & {});
export interface UpdateTableMigrationRequest {
    tableARN?: string | undefined;
    migrationId?: string | undefined;
    requestedState: MigrationRequestedState;
    updateDescription?: string | undefined;
}
export interface UpdateTableMigrationResponse {
    migrationId: string;
    state: MigrationState;
    tableARN?: string | undefined;
}
export type ErrorMessage = string;
export type CompleteTableMigrationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Completes the migration of a table. The table's most recent migration must be in the `succeeded`, `failed` or `cancelled` state. After you complete the migration, you can't sync the table again, and you can write to and maintain the table as you do any other table: compaction starts, and unreferenced file removal follows the table bucket's configuration. You can't undo this operation. Calling it again for the same table returns a `ConflictException`.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:CompleteTableMigration` permission to use this operation.
 */
export declare const completeTableMigration: API.OperationMethod<CompleteTableMigrationRequest & RegionInput, CompleteTableMigrationResponse, CompleteTableMigrationError, Credentials | HttpClient.HttpClient>;
export type CreateNamespaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a namespace. A namespace is a logical grouping of tables within your table bucket, which you can use to organize tables. For more information, see Create a namespace in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:CreateNamespace` permission to use this operation.
 */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest & RegionInput, CreateNamespaceResponse, CreateNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table associated with the given namespace in a table bucket. For more information, see Creating an Amazon S3 table in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:CreateTable` permission to use this operation.
 *
 * - If you use this operation with the optional `metadata` request parameter you must have the `s3tables:PutTableData` permission.
 *
 * - If you use this operation with the optional `encryptionConfiguration` request parameter you must have the `s3tables:PutTableEncryption` permission.
 *
 * - If you use this operation with the `storageClassConfiguration` request parameter, you must have the `s3tables:PutTableStorageClass` permission.
 *
 * - To create a table with tags, you must have the `s3tables:TagResource` permission in addition to `s3tables:CreateTable` permission.
 *
 * Additionally, If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see Permissions requirements for S3 Tables SSE-KMS encryption.
 */
export declare const createTable: API.OperationMethod<CreateTableRequest & RegionInput, CreateTableResponse, CreateTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableBucketError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a table bucket. For more information, see Creating a table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:CreateTableBucket` permission to use this operation.
 *
 * - If you use this operation with the optional `encryptionConfiguration` parameter you must have the `s3tables:PutTableBucketEncryption` permission.
 *
 * - If you use this operation with the `storageClassConfiguration` request parameter, you must have the `s3tables:PutTableBucketStorageClass` permission.
 *
 * - To create a table bucket with tags, you must have the `s3tables:TagResource` permission in addition to `s3tables:CreateTableBucket` permission.
 */
export declare const createTableBucket: API.OperationMethod<CreateTableBucketRequest & RegionInput, CreateTableBucketResponse, CreateTableBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a namespace. For more information, see Delete a namespace in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteNamespace` permission to use this operation.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest & RegionInput, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table. For more information, see Deleting an Amazon S3 table in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTable` permission to use this operation.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableRequest & RegionInput, DeleteTableResponse, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table bucket. For more information, see Deleting a table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucket` permission to use this operation.
 */
export declare const deleteTableBucket: API.OperationMethod<DeleteTableBucketRequest & RegionInput, DeleteTableBucketResponse, DeleteTableBucketError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketEncryptionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketEncryption` permission to use this operation.
 */
export declare const deleteTableBucketEncryption: API.OperationMethod<DeleteTableBucketEncryptionRequest & RegionInput, DeleteTableBucketEncryptionResponse, DeleteTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const deleteTableBucketMetricsConfiguration: API.OperationMethod<DeleteTableBucketMetricsConfigurationRequest & RegionInput, DeleteTableBucketMetricsConfigurationResponse, DeleteTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table bucket policy. For more information, see Deleting a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketPolicy` permission to use this operation.
 */
export declare const deleteTableBucketPolicy: API.OperationMethod<DeleteTableBucketPolicyRequest & RegionInput, DeleteTableBucketPolicyResponse, DeleteTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the replication configuration for a table bucket. After deletion, new table updates will no longer be replicated to destination buckets, though existing replicated tables will remain in destination buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableBucketReplication` permission to use this operation.
 */
export declare const deleteTableBucketReplication: API.OperationMethod<DeleteTableBucketReplicationRequest & RegionInput, DeleteTableBucketReplicationResponse, DeleteTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a table policy. For more information, see Deleting a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTablePolicy` permission to use this operation.
 */
export declare const deleteTablePolicy: API.OperationMethod<DeleteTablePolicyRequest & RegionInput, DeleteTablePolicyResponse, DeleteTablePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the replication configuration for a specific table. After deletion, new updates to this table will no longer be replicated to destination tables, though existing replicated copies will remain in destination buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:DeleteTableReplication` permission to use this operation.
 */
export declare const deleteTableReplication: API.OperationMethod<DeleteTableReplicationRequest & RegionInput, DeleteTableReplicationResponse, DeleteTableReplicationError, Credentials | HttpClient.HttpClient>;
export type GetNamespaceError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a namespace. For more information, see Table namespaces in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetNamespace` permission to use this operation.
 */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest & RegionInput, GetNamespaceResponse, GetNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetTableError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTable` permission to use this operation.
 */
export declare const getTable: API.OperationMethod<GetTableRequest & RegionInput, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details on a table bucket. For more information, see Viewing details about an Amazon S3 table bucket in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucket` permission to use this operation.
 */
export declare const getTableBucket: API.OperationMethod<GetTableBucketRequest & RegionInput, GetTableBucketResponse, GetTableBucketError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketEncryptionError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketEncryption` permission to use this operation.
 */
export declare const getTableBucketEncryption: API.OperationMethod<GetTableBucketEncryptionRequest & RegionInput, GetTableBucketEncryptionResponse, GetTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketLoggingError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the server access logging configuration for a table bucket. For more information, see Server access logging for table buckets in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketLogging` permission to use this operation.
 */
export declare const getTableBucketLogging: API.OperationMethod<GetTableBucketLoggingRequest & RegionInput, GetTableBucketLoggingResponse, GetTableBucketLoggingError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a maintenance configuration for a given table bucket. For more information, see Amazon S3 table bucket maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketMaintenanceConfiguration` permission to use this operation.
 */
export declare const getTableBucketMaintenanceConfiguration: API.OperationMethod<GetTableBucketMaintenanceConfigurationRequest & RegionInput, GetTableBucketMaintenanceConfigurationResponse, GetTableBucketMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const getTableBucketMetricsConfiguration: API.OperationMethod<GetTableBucketMetricsConfigurationRequest & RegionInput, GetTableBucketMetricsConfigurationResponse, GetTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table bucket policy. For more information, see Viewing a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketPolicy` permission to use this operation.
 */
export declare const getTableBucketPolicy: API.OperationMethod<GetTableBucketPolicyRequest & RegionInput, GetTableBucketPolicyResponse, GetTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication configuration for a table bucket.This operation returns the IAM role, `versionToken`, and replication rules that define how tables in this bucket are replicated to other buckets.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketReplication` permission to use this operation.
 */
export declare const getTableBucketReplication: API.OperationMethod<GetTableBucketReplicationRequest & RegionInput, GetTableBucketReplicationResponse, GetTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type GetTableBucketStorageClassError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the storage class configuration for a specific table. This allows you to view the storage class settings that apply to an individual table, which may differ from the table bucket's default configuration.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableBucketStorageClass` permission to use this operation.
 */
export declare const getTableBucketStorageClass: API.OperationMethod<GetTableBucketStorageClassRequest & RegionInput, GetTableBucketStorageClassResponse, GetTableBucketStorageClassError, Credentials | HttpClient.HttpClient>;
export type GetTableEncryptionError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the encryption configuration for a table.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableEncryption` permission to use this operation.
 */
export declare const getTableEncryption: API.OperationMethod<GetTableEncryptionRequest & RegionInput, GetTableEncryptionResponse, GetTableEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetTableMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about the maintenance configuration of a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:GetTableMaintenanceConfiguration` permission to use this operation.
 *
 * - You must have the `s3tables:GetTableData` permission to use set the compaction strategy to `sort` or `zorder`.
 */
export declare const getTableMaintenanceConfiguration: API.OperationMethod<GetTableMaintenanceConfigurationRequest & RegionInput, GetTableMaintenanceConfigurationResponse, GetTableMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableMaintenanceJobStatusError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the status of a maintenance job for a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableMaintenanceJobStatus` permission to use this operation.
 */
export declare const getTableMaintenanceJobStatus: API.OperationMethod<GetTableMaintenanceJobStatusRequest & RegionInput, GetTableMaintenanceJobStatusResponse, GetTableMaintenanceJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableMetadataLocationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the location of the table metadata.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableMetadataLocation` permission to use this operation.
 */
export declare const getTableMetadataLocation: API.OperationMethod<GetTableMetadataLocationRequest & RegionInput, GetTableMetadataLocationResponse, GetTableMetadataLocationError, Credentials | HttpClient.HttpClient>;
export type GetTableMigrationError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details of a migration, including its state, the reason it failed, its statistics and the location of its reports. Identify the migration by its `migrationId`, or specify the `tableARN` of a destination table to get that table's most recent migration.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:GetTableMigration` permission to use this operation.
 */
export declare const getTableMigration: API.OperationMethod<GetTableMigrationRequest & RegionInput, GetTableMigrationResponse, GetTableMigrationError, Credentials | HttpClient.HttpClient>;
export type GetTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details about a table policy. For more information, see Viewing a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTablePolicy` permission to use this operation.
 */
export declare const getTablePolicy: API.OperationMethod<GetTablePolicyRequest & RegionInput, GetTablePolicyResponse, GetTablePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTableRecordExpirationConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the expiration configuration settings for records in a table, and the status of the configuration. If the status of the configuration is `enabled`, records expire and are automatically removed from the table after the specified number of days.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableRecordExpirationConfiguration` permission to use this operation.
 */
export declare const getTableRecordExpirationConfiguration: API.OperationMethod<GetTableRecordExpirationConfigurationRequest & RegionInput, GetTableRecordExpirationConfigurationResponse, GetTableRecordExpirationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetTableRecordExpirationJobStatusError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the status, metrics, and details of the latest record expiration job for a table. This includes when the job ran, and whether it succeeded or failed. If the job ran successfully, this also includes statistics about the records that were removed.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableRecordExpirationJobStatus` permission to use this operation.
 */
export declare const getTableRecordExpirationJobStatus: API.OperationMethod<GetTableRecordExpirationJobStatusRequest & RegionInput, GetTableRecordExpirationJobStatusResponse, GetTableRecordExpirationJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication configuration for a specific table.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableReplication` permission to use this operation.
 */
export declare const getTableReplication: API.OperationMethod<GetTableReplicationRequest & RegionInput, GetTableReplicationResponse, GetTableReplicationError, Credentials | HttpClient.HttpClient>;
export type GetTableReplicationStatusError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the replication status for a table, including the status of replication to each destination. This operation provides visibility into replication health and progress.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableReplicationStatus` permission to use this operation.
 */
export declare const getTableReplicationStatus: API.OperationMethod<GetTableReplicationStatusRequest & RegionInput, GetTableReplicationStatusResponse, GetTableReplicationStatusError, Credentials | HttpClient.HttpClient>;
export type GetTableStorageClassError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the storage class configuration for a specific table. This allows you to view the storage class settings that apply to an individual table, which may differ from the table bucket's default configuration.
 *
 * ### Permissions
 *
 * You must have the `s3tables:GetTableStorageClass` permission to use this operation.
 */
export declare const getTableStorageClass: API.OperationMethod<GetTableStorageClassRequest & RegionInput, GetTableStorageClassResponse, GetTableStorageClassError, Credentials | HttpClient.HttpClient>;
export type ListNamespacesError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the namespaces within a table bucket. For more information, see Table namespaces in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListNamespaces` permission to use this operation.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest & RegionInput, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, NamespaceSummary>;
export type ListTableBucketsError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists table buckets for your account. For more information, see S3 Table buckets in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListTableBuckets` permission to use this operation.
 */
export declare const listTableBuckets: API.PaginatedOperationMethod<ListTableBucketsRequest & RegionInput, ListTableBucketsResponse, ListTableBucketsError, Credentials | HttpClient.HttpClient, TableBucketSummary>;
export type ListTableMigrationsError = AccessDeniedException | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the migrations whose destination is in a table bucket, a namespace or a table. Specify a `tableBucketARN` to list the migrations into a table bucket, and add a `namespace`, or a `namespace` and a `name`, to narrow the list. Or specify a `tableARN` to list the migrations into a table.
 *
 * Migrations are listed newest first. Results are paginated: use `maxResults` to set the page size, and pass the `nextToken` from a response to retrieve the next page of results. A page can contain fewer migrations than `maxResults`, or none, and still return a `nextToken`. Continue until a response has no `nextToken`.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:ListTableMigrations` permission to use this operation.
 */
export declare const listTableMigrations: API.PaginatedOperationMethod<ListTableMigrationsRequest & RegionInput, ListTableMigrationsResponse, ListTableMigrationsError, Credentials | HttpClient.HttpClient, MigrationSummary>;
export type ListTablesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List tables in the given table bucket. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:ListTables` permission to use this operation.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest & RegionInput, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, TableSummary>;
export type ListTagsForResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the tags applied to a specified Amazon S3 Tables resource. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to resources.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:ListTagsForResource` permission to use this operation.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketEncryptionError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the encryption configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketEncryption` permission to use this operation.
 *
 * If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see Permissions requirements for S3 Tables SSE-KMS encryption in the *Amazon Simple Storage Service User Guide*.
 */
export declare const putTableBucketEncryption: API.OperationMethod<PutTableBucketEncryptionRequest & RegionInput, PutTableBucketEncryptionResponse, PutTableBucketEncryptionError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketLoggingError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets, updates, or removes the server access logging configuration for a table bucket. When logging is enabled, Amazon S3 delivers a record of the requests made to the table bucket and its tables to the target general purpose bucket that you specify. To disable logging, call this operation with an empty `tableBucketLoggingStatus`. For more information, see Server access logging for table buckets in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketLogging` permission to use this operation.
 */
export declare const putTableBucketLogging: API.OperationMethod<PutTableBucketLoggingRequest & RegionInput, PutTableBucketLoggingResponse, PutTableBucketLoggingError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new maintenance configuration or replaces an existing maintenance configuration for a table bucket. For more information, see Amazon S3 table bucket maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketMaintenanceConfiguration` permission to use this operation.
 */
export declare const putTableBucketMaintenanceConfiguration: API.OperationMethod<PutTableBucketMaintenanceConfigurationRequest & RegionInput, PutTableBucketMaintenanceConfigurationResponse, PutTableBucketMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketMetricsConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the metrics configuration for a table bucket.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketMetricsConfiguration` permission to use this operation.
 */
export declare const putTableBucketMetricsConfiguration: API.OperationMethod<PutTableBucketMetricsConfigurationRequest & RegionInput, PutTableBucketMetricsConfigurationResponse, PutTableBucketMetricsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table bucket policy or replaces an existing table bucket policy for a table bucket. For more information, see Adding a table bucket policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketPolicy` permission to use this operation.
 */
export declare const putTableBucketPolicy: API.OperationMethod<PutTableBucketPolicyRequest & RegionInput, PutTableBucketPolicyResponse, PutTableBucketPolicyError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the replication configuration for a table bucket. This operation defines how tables in the source bucket are replicated to destination buckets. Replication helps ensure data availability and disaster recovery across regions or accounts.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:PutTableBucketReplication` permission to use this operation. The IAM role specified in the configuration must have permissions to read from the source bucket and write permissions to all destination buckets.
 *
 * - You must also have the following permissions:
 *
 * - `s3tables:GetTable` permission on the source table.
 *
 * - `s3tables:ListTables` permission on the bucket containing the table.
 *
 * - `s3tables:CreateTable` permission for the destination.
 *
 * - `s3tables:CreateNamespace` permission for the destination.
 *
 * - `s3tables:GetTableMaintenanceConfig` permission for the source bucket.
 *
 * - `s3tables:PutTableMaintenanceConfig` permission for the destination bucket.
 *
 * - You must have `iam:PassRole` permission with condition allowing roles to be passed to `replication.s3tables.amazonaws.com`.
 */
export declare const putTableBucketReplication: API.OperationMethod<PutTableBucketReplicationRequest & RegionInput, PutTableBucketReplicationResponse, PutTableBucketReplicationError, Credentials | HttpClient.HttpClient>;
export type PutTableBucketStorageClassError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets or updates the storage class configuration for a table bucket. This configuration serves as the default storage class for all new tables created in the bucket, allowing you to optimize storage costs at the bucket level.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableBucketStorageClass` permission to use this operation.
 */
export declare const putTableBucketStorageClass: API.OperationMethod<PutTableBucketStorageClassRequest & RegionInput, PutTableBucketStorageClassResponse, PutTableBucketStorageClassError, Credentials | HttpClient.HttpClient>;
export type PutTableMaintenanceConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new maintenance configuration or replaces an existing maintenance configuration for a table. For more information, see S3 Tables maintenance in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableMaintenanceConfiguration` permission to use this operation.
 */
export declare const putTableMaintenanceConfiguration: API.OperationMethod<PutTableMaintenanceConfigurationRequest & RegionInput, PutTableMaintenanceConfigurationResponse, PutTableMaintenanceConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTablePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new table policy or replaces an existing table policy for a table. For more information, see Adding a table policy in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTablePolicy` permission to use this operation.
 */
export declare const putTablePolicy: API.OperationMethod<PutTablePolicyRequest & RegionInput, PutTablePolicyResponse, PutTablePolicyError, Credentials | HttpClient.HttpClient>;
export type PutTableRecordExpirationConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | MethodNotAllowedException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the expiration configuration settings for records in a table, including the status of the configuration. If you enable record expiration for a table, records expire and are automatically removed from the table after the number of days that you specify.
 *
 * ### Permissions
 *
 * You must have the `s3tables:PutTableRecordExpirationConfiguration` permission to use this operation.
 */
export declare const putTableRecordExpirationConfiguration: API.OperationMethod<PutTableRecordExpirationConfigurationRequest & RegionInput, PutTableRecordExpirationConfigurationResponse, PutTableRecordExpirationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTableReplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates or updates the replication configuration for a specific table. This operation allows you to define table-level replication independently of bucket-level replication, providing granular control over which tables are replicated and where.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:PutTableReplication` permission to use this operation. The IAM role specified in the configuration must have permissions to read from the source table and write to all destination tables.
 *
 * - You must also have the following permissions:
 *
 * - `s3tables:GetTable` permission on the source table being replicated.
 *
 * - `s3tables:CreateTable` permission for the destination.
 *
 * - `s3tables:CreateNamespace` permission for the destination.
 *
 * - `s3tables:GetTableMaintenanceConfig` permission for the source table.
 *
 * - `s3tables:PutTableMaintenanceConfig` permission for the destination table.
 *
 * - You must have `iam:PassRole` permission with condition allowing roles to be passed to `replication.s3tables.amazonaws.com`.
 */
export declare const putTableReplication: API.OperationMethod<PutTableReplicationRequest & RegionInput, PutTableReplicationResponse, PutTableReplicationError, Credentials | HttpClient.HttpClient>;
export type RenameTableError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Renames a table or a namespace. For more information, see S3 Tables in the *Amazon Simple Storage Service User Guide*.
 *
 * ### Permissions
 *
 * You must have the `s3tables:RenameTable` permission to use this operation.
 */
export declare const renameTable: API.OperationMethod<RenameTableRequest & RegionInput, RenameTableResponse, RenameTableError, Credentials | HttpClient.HttpClient>;
export type StartTableMigrationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts migrating an Amazon Web Services Glue Data Catalog table into a new table in a table bucket. The migration runs asynchronously: this operation returns the migration ID and its initial state, and you track progress with `GetTableMigration`.
 *
 * The namespace must already exist, and a table with the specified name must not. The migration creates the table during planning and commits data to it as it runs. Until you call `CompleteTableMigration`, you can read the table but you can't write to it. If the migration fails or is cancelled, the table and the data already committed to it remain.
 *
 * The migration first checks the source and the destination, and writes the table compatibility and object compatibility reports to the bucket that you specify in `migrationOutput`. If you set `reviewMigrationPlan` to `true`, the migration waits in the `pendingReview` state so that you can review the reports, and continues only when you call `UpdateTableMigration` with `requestedState` set to `queued`. If you don't continue or cancel the migration within 30 days, the migration fails. Otherwise it continues to migrate the data, and writes the object migration report when the migration ends. If planning fails, the migration writes no object migration report.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:StartTableMigration` permission to use this operation.
 *
 * - You must have the `iam:PassRole` permission on the role that you specify in `roleARN`, with a condition that allows passing it to `migration.s3tables.amazonaws.com`. The associated resource is the table bucket.
 *
 * - If `destinationTable` specifies SSE-KMS encryption, you must have the `kms:DescribeKey` and `kms:GenerateDataKey` permissions on the KMS key. You must also grant the S3 Tables maintenance principal access to the key. For more information, see Permissions requirements for S3 Tables SSE-KMS encryption.
 */
export declare const startTableMigration: API.OperationMethod<StartTableMigrationRequest & RegionInput, StartTableMigrationResponse, StartTableMigrationError, Credentials | HttpClient.HttpClient>;
export type SyncTableMigrationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Migrates the changes in the source table since the previous start or sync, such as added and deleted source objects, into the destination table. The sync runs asynchronously: this operation returns the migration ID of the sync and its initial state, and you track progress with `GetTableMigration`.
 *
 * A sync uses the source, destination and data migration settings of the table's migration, and plans the work and writes its reports in the same way as `StartTableMigration`. You can sync after a start or sync that succeeded, failed or was cancelled, if an earlier start or sync of the table has a valid plan (`hasValidPlan`). You can't sync a table while a start or sync is in progress for it, and you can sync a table until you call `CompleteTableMigration` for it. If a source object that an earlier migration migrated has since been overwritten, the sync fails.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:SyncTableMigration` permission to use this operation.
 *
 * - You must have the `iam:PassRole` permission on the role that you specify in `roleARN`, with a condition that allows passing it to `migration.s3tables.amazonaws.com`. The associated resource is the table.
 */
export declare const syncTableMigration: API.OperationMethod<SyncTableMigrationRequest & RegionInput, SyncTableMigrationResponse, SyncTableMigrationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Applies one or more user-defined tags to an Amazon S3 Tables resource or updates existing tags. Each tag is a label consisting of a key and value pair. Tags can help you organize, track costs for, and control access to your resources. You can add up to 50 tags for each S3 resource.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:TagResource` permission to use this operation.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified user-defined tags from an Amazon S3 Tables resource. You can pass one or more tag keys.
 *
 * For a list of S3 resources that support tagging, see Managing tags for Amazon S3 resources.
 *
 * ### Permissions
 *
 * For tables and table buckets, you must have the `s3tables:UntagResource` permission to use this operation.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTableMetadataLocationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the metadata location for a table. The metadata location of a table must be an S3 URI that begins with the table's warehouse location. The metadata location for an Apache Iceberg table must end with `.metadata.json`, or if the metadata file is Gzip-compressed, `.metadata.json.gz`.
 *
 * ### Permissions
 *
 * You must have the `s3tables:UpdateTableMetadataLocation` permission to use this operation.
 */
export declare const updateTableMetadataLocation: API.OperationMethod<UpdateTableMetadataLocationRequest & RegionInput, UpdateTableMetadataLocationResponse, UpdateTableMetadataLocationError, Credentials | HttpClient.HttpClient>;
export type UpdateTableMigrationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Requests a state change for a migration. Identify the migration by its `migrationId` or by the `tableARN` of its destination table.
 *
 * Set `requestedState` to `queued` to continue a migration in the `pendingReview` state; the migration moves to `queued` or `migrating`. Set it to `cancelled` to cancel a migration in the `new`, `planning`, `pendingReview`, `queued` or `migrating` state; the migration moves to `cancelling`, finishes the work in progress, and then ends in the `cancelled` state, or in the `failed` state if any objects failed to migrate. Data that the migration already committed stays in the destination table.
 *
 * ### Permissions
 *
 * - You must have the `s3tables:UpdateTableMigration` permission to use this operation.
 */
export declare const updateTableMigration: API.OperationMethod<UpdateTableMigrationRequest & RegionInput, UpdateTableMigrationResponse, UpdateTableMigrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=s3tables.d.ts.map