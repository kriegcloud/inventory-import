import * as HttpClient from "effect/http/HttpClient";
import type * as Layer from "effect/Layer";
/** An `HttpClient` that sends each request over its own `cloudflare:sockets` socket. */
export declare const client: HttpClient.HttpClient;
/** Send gRPC calls over `cloudflare:sockets` in this scope. */
export declare const layer: Layer.Layer<never>;
//# sourceMappingURL=grpc-transport-cloudflare-sockets.d.ts.map