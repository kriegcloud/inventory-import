import type { Kit, Model } from "../Kit.ts";
import type { V } from "../Value.ts";
/**
 * `Deferred`, `Queue`, `Semaphore` and `Latch`: what one part of a program
 * waits on for another. A handler is one fiber that runs to its end without
 * waiting, so each is what the handler itself last did to it. A call that
 * would wait (a `Deferred` nothing has completed, a `Queue` with nothing in
 * it) never ends in a handler: it is reported, and never read as something
 * else.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
    member: (value: V, key: string) => V | undefined;
};
//# sourceMappingURL=Waits.d.ts.map