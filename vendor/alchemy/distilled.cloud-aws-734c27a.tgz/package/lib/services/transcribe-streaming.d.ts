import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
export type SessionId = string;
export interface GetMedicalScribeStreamRequest {
    SessionId: string;
}
export type MedicalScribeLanguageCode = "en-US" | (string & {});
export type MedicalScribeMediaSampleRateHertz = number;
export type MedicalScribeMediaEncoding = "pcm" | "ogg-opus" | "flac" | (string & {});
export type VocabularyName = string;
export type VocabularyFilterName = string;
export type MedicalScribeVocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export type IamRoleArn = string;
export type MedicalScribeChannelId = number;
export type MedicalScribeParticipantRole = "PATIENT" | "CLINICIAN" | (string & {});
export interface MedicalScribeChannelDefinition {
    ChannelId: number;
    ParticipantRole: MedicalScribeParticipantRole;
}
export type MedicalScribeChannelDefinitions = MedicalScribeChannelDefinition[];
export type NonEmptyString = string;
export type KMSEncryptionContextMap = {
    [key: string]: string | undefined;
};
export type KMSKeyId = string;
export interface MedicalScribeEncryptionSettings {
    KmsEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    KmsKeyId: string;
}
export type MedicalScribeStreamStatus = "IN_PROGRESS" | "PAUSED" | "FAILED" | "COMPLETED" | (string & {});
export type BucketName = string;
export type MedicalScribeNoteTemplate = "HISTORY_AND_PHYSICAL" | "GIRPP" | "DAP" | "SIRP" | "BIRP" | "BEHAVIORAL_SOAP" | "PHYSICAL_SOAP" | (string & {});
export interface ClinicalNoteGenerationSettings {
    OutputBucketName: string;
    NoteTemplate?: MedicalScribeNoteTemplate | undefined;
}
export interface MedicalScribePostStreamAnalyticsSettings {
    ClinicalNoteGenerationSettings: ClinicalNoteGenerationSettings;
}
export type Uri = string;
export type ClinicalNoteGenerationStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export interface ClinicalNoteGenerationResult {
    ClinicalNoteOutputLocation?: string | undefined;
    TranscriptOutputLocation?: string | undefined;
    Status?: ClinicalNoteGenerationStatus | undefined;
    FailureReason?: string | undefined;
}
export interface MedicalScribePostStreamAnalyticsResult {
    ClinicalNoteGenerationResult?: ClinicalNoteGenerationResult | undefined;
}
export interface MedicalScribeStreamDetails {
    SessionId?: string | undefined;
    StreamCreatedAt?: Date | undefined;
    StreamEndedAt?: Date | undefined;
    LanguageCode?: MedicalScribeLanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaEncoding?: MedicalScribeMediaEncoding | undefined;
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: MedicalScribeVocabularyFilterMethod | undefined;
    ResourceAccessRoleArn?: string | undefined;
    ChannelDefinitions?: MedicalScribeChannelDefinition[] | undefined;
    EncryptionSettings?: MedicalScribeEncryptionSettings | undefined;
    StreamStatus?: MedicalScribeStreamStatus | undefined;
    PostStreamAnalyticsSettings?: MedicalScribePostStreamAnalyticsSettings | undefined;
    PostStreamAnalyticsResult?: MedicalScribePostStreamAnalyticsResult | undefined;
    MedicalScribeContextProvided?: boolean | undefined;
}
export interface GetMedicalScribeStreamResponse {
    MedicalScribeStreamDetails?: MedicalScribeStreamDetails | undefined;
}
export type CallAnalyticsLanguageCode = "en-US" | "en-GB" | "es-US" | "fr-CA" | "fr-FR" | "en-AU" | "it-IT" | "de-DE" | "pt-BR" | (string & {});
export type MediaSampleRateHertz = number;
export type MediaEncoding = "pcm" | "ogg-opus" | "flac" | "g711-alaw" | "g711-ulaw" | "g729" | (string & {});
export type AudioChunk = Uint8Array;
export interface AudioEvent {
    AudioChunk?: Uint8Array | undefined;
}
export type ChannelId = number;
export type ParticipantRole = "AGENT" | "CUSTOMER" | (string & {});
export interface ChannelDefinition {
    ChannelId: number;
    ParticipantRole: ParticipantRole;
}
export type ChannelDefinitions = ChannelDefinition[];
export type ContentRedactionOutput = "redacted" | "redacted_and_unredacted" | (string & {});
export interface PostCallAnalyticsSettings {
    OutputLocation: string;
    DataAccessRoleArn: string;
    ContentRedactionOutput?: ContentRedactionOutput | undefined;
    OutputEncryptionKMSKeyId?: string | undefined;
}
export interface ConfigurationEvent {
    ChannelDefinitions?: ChannelDefinition[] | undefined;
    PostCallAnalyticsSettings?: PostCallAnalyticsSettings | undefined;
}
export type AudioStream = {
    AudioEvent: AudioEvent;
    ConfigurationEvent?: undefined;
} | {
    AudioEvent?: undefined;
    ConfigurationEvent: ConfigurationEvent;
};
export type VocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export type ModelName = string;
export type LanguageOptions = string;
export type VocabularyNames = string;
export type VocabularyFilterNames = string;
export type PartialResultsStability = "high" | "medium" | "low" | (string & {});
export type ContentIdentificationType = "PII" | (string & {});
export type ContentRedactionType = "PII" | (string & {});
export type PiiEntityTypes = string;
export interface StartCallAnalyticsStreamTranscriptionRequest {
    LanguageCode?: CallAnalyticsLanguageCode | undefined;
    MediaSampleRateHertz: number;
    MediaEncoding: MediaEncoding;
    VocabularyName?: string | undefined;
    SessionId?: string | undefined;
    AudioStream: stream.Stream<AudioStream, Error, never>;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    LanguageModelName?: string | undefined;
    IdentifyLanguage?: boolean | undefined;
    LanguageOptions?: string | undefined;
    PreferredLanguage?: CallAnalyticsLanguageCode | undefined;
    VocabularyNames?: string | undefined;
    VocabularyFilterNames?: string | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentIdentificationType | undefined;
    ContentRedactionType?: ContentRedactionType | undefined;
    PiiEntityTypes?: string | undefined;
}
export type RequestId = string;
export type ItemType = "pronunciation" | "punctuation" | (string & {});
export type Confidence = number;
export type Stable = boolean;
export interface CallAnalyticsItem {
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
    Type?: ItemType | undefined;
    Content?: string | undefined;
    Confidence?: number | undefined;
    VocabularyFilterMatch?: boolean | undefined;
    Stable?: boolean | undefined;
}
export type CallAnalyticsItemList = CallAnalyticsItem[];
export interface CallAnalyticsEntity {
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
    Category?: string | undefined;
    Type?: string | undefined;
    Content?: string | undefined;
    Confidence?: number | undefined;
}
export type CallAnalyticsEntityList = CallAnalyticsEntity[];
export type Sentiment = "POSITIVE" | "NEGATIVE" | "MIXED" | "NEUTRAL" | (string & {});
export interface CharacterOffsets {
    Begin?: number | undefined;
    End?: number | undefined;
}
export interface IssueDetected {
    CharacterOffsets?: CharacterOffsets | undefined;
}
export type IssuesDetected = IssueDetected[];
export interface CallAnalyticsLanguageWithScore {
    LanguageCode?: CallAnalyticsLanguageCode | undefined;
    Score?: number | undefined;
}
export type CallAnalyticsLanguageIdentification = CallAnalyticsLanguageWithScore[];
export interface UtteranceEvent {
    UtteranceId?: string | undefined;
    IsPartial?: boolean | undefined;
    ParticipantRole?: ParticipantRole | undefined;
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
    Transcript?: string | undefined;
    Items?: CallAnalyticsItem[] | undefined;
    Entities?: CallAnalyticsEntity[] | undefined;
    Sentiment?: Sentiment | undefined;
    IssuesDetected?: IssueDetected[] | undefined;
    LanguageCode?: CallAnalyticsLanguageCode | undefined;
    LanguageIdentification?: CallAnalyticsLanguageWithScore[] | undefined;
}
export type StringList = string[];
export interface TimestampRange {
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
}
export type TimestampRanges = TimestampRange[];
export interface PointsOfInterest {
    TimestampRanges?: TimestampRange[] | undefined;
}
export type MatchedCategoryDetails = {
    [key: string]: PointsOfInterest | undefined;
};
export interface CategoryEvent {
    MatchedCategories?: string[] | undefined;
    MatchedDetails?: {
        [key: string]: PointsOfInterest | undefined;
    } | undefined;
}
export type CallAnalyticsTranscriptResultStream = {
    UtteranceEvent: UtteranceEvent;
    CategoryEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent: CategoryEvent;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent?: undefined;
    BadRequestException: BadRequestException;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException: LimitExceededException;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException: InternalFailureException;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException: ConflictException;
    ServiceUnavailableException?: undefined;
} | {
    UtteranceEvent?: undefined;
    CategoryEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException: ServiceUnavailableException;
};
export interface StartCallAnalyticsStreamTranscriptionResponse {
    RequestId?: string | undefined;
    LanguageCode?: CallAnalyticsLanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaEncoding?: MediaEncoding | undefined;
    VocabularyName?: string | undefined;
    SessionId?: string | undefined;
    CallAnalyticsTranscriptResultStream?: stream.Stream<CallAnalyticsTranscriptResultStream, Error, never> | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    LanguageModelName?: string | undefined;
    IdentifyLanguage?: boolean | undefined;
    LanguageOptions?: string | undefined;
    PreferredLanguage?: CallAnalyticsLanguageCode | undefined;
    VocabularyNames?: string | undefined;
    VocabularyFilterNames?: string | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentIdentificationType | undefined;
    ContentRedactionType?: ContentRedactionType | undefined;
    PiiEntityTypes?: string | undefined;
}
export interface MedicalScribeAudioEvent {
    AudioChunk: Uint8Array;
}
export type MedicalScribeSessionControlEventType = "END_OF_SESSION" | (string & {});
export interface MedicalScribeSessionControlEvent {
    Type: MedicalScribeSessionControlEventType;
}
export type Pronouns = "HE_HIM" | "SHE_HER" | "THEY_THEM" | (string & {});
export interface MedicalScribePatientContext {
    Pronouns?: Pronouns | undefined;
}
export interface MedicalScribeContext {
    PatientContext?: MedicalScribePatientContext | undefined;
}
export interface MedicalScribeConfigurationEvent {
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: MedicalScribeVocabularyFilterMethod | undefined;
    ResourceAccessRoleArn: string;
    ChannelDefinitions?: MedicalScribeChannelDefinition[] | undefined;
    EncryptionSettings?: MedicalScribeEncryptionSettings | undefined;
    PostStreamAnalyticsSettings: MedicalScribePostStreamAnalyticsSettings;
    MedicalScribeContext?: MedicalScribeContext | undefined;
}
export type MedicalScribeInputStream = {
    AudioEvent: MedicalScribeAudioEvent;
    SessionControlEvent?: undefined;
    ConfigurationEvent?: undefined;
} | {
    AudioEvent?: undefined;
    SessionControlEvent: MedicalScribeSessionControlEvent;
    ConfigurationEvent?: undefined;
} | {
    AudioEvent?: undefined;
    SessionControlEvent?: undefined;
    ConfigurationEvent: MedicalScribeConfigurationEvent;
};
export interface StartMedicalScribeStreamRequest {
    SessionId?: string | undefined;
    LanguageCode: MedicalScribeLanguageCode;
    MediaSampleRateHertz: number;
    MediaEncoding: MedicalScribeMediaEncoding;
    InputStream: stream.Stream<MedicalScribeInputStream, Error, never>;
}
export type MedicalScribeTranscriptItemType = "pronunciation" | "punctuation" | (string & {});
export interface MedicalScribeTranscriptItem {
    BeginAudioTime?: number | undefined;
    EndAudioTime?: number | undefined;
    Type?: MedicalScribeTranscriptItemType | undefined;
    Confidence?: number | undefined;
    Content?: string | undefined;
    VocabularyFilterMatch?: boolean | undefined;
}
export type MedicalScribeTranscriptItemList = MedicalScribeTranscriptItem[];
export interface MedicalScribeTranscriptSegment {
    SegmentId?: string | undefined;
    BeginAudioTime?: number | undefined;
    EndAudioTime?: number | undefined;
    Content?: string | undefined;
    Items?: MedicalScribeTranscriptItem[] | undefined;
    IsPartial?: boolean | undefined;
    ChannelId?: string | undefined;
}
export interface MedicalScribeTranscriptEvent {
    TranscriptSegment?: MedicalScribeTranscriptSegment | undefined;
}
export type MedicalScribeResultStream = {
    TranscriptEvent: MedicalScribeTranscriptEvent;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException: BadRequestException;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException: LimitExceededException;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException: InternalFailureException;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException: ConflictException;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException: ServiceUnavailableException;
};
export interface StartMedicalScribeStreamResponse {
    SessionId?: string | undefined;
    RequestId?: string | undefined;
    LanguageCode?: MedicalScribeLanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaEncoding?: MedicalScribeMediaEncoding | undefined;
    ResultStream?: stream.Stream<MedicalScribeResultStream, Error, never> | undefined;
}
export type LanguageCode = "en-US" | "en-GB" | "es-US" | "fr-CA" | "fr-FR" | "en-AU" | "it-IT" | "de-DE" | "pt-BR" | "ja-JP" | "ko-KR" | "zh-CN" | "th-TH" | "es-ES" | "ar-SA" | "pt-PT" | "ca-ES" | "ar-AE" | "hi-IN" | "zh-HK" | "nl-NL" | "no-NO" | "sv-SE" | "pl-PL" | "fi-FI" | "zh-TW" | "en-IN" | "en-IE" | "en-NZ" | "en-AB" | "en-ZA" | "en-WL" | "de-CH" | "af-ZA" | "eu-ES" | "hr-HR" | "cs-CZ" | "da-DK" | "fa-IR" | "gl-ES" | "el-GR" | "he-IL" | "id-ID" | "lv-LV" | "ms-MY" | "ro-RO" | "ru-RU" | "sr-RS" | "sk-SK" | "so-SO" | "tl-PH" | "uk-UA" | "vi-VN" | "zu-ZA" | "am-ET" | "be-BY" | "bg-BG" | "bn-IN" | "bs-BA" | "ckb-IQ" | "ckb-IR" | "cy-WL" | "es-MX" | "et-ET" | "fa-AF" | "gu-IN" | "ht-HT" | "hu-HU" | "hy-AM" | "is-IS" | "jv-ID" | "ka-GE" | "kab-DZ" | "kk-KZ" | "km-KH" | "kn-IN" | "lg-IN" | "lt-LT" | "mk-MK" | "ml-IN" | "mr-IN" | "my-MM" | "ne-NP" | "or-IN" | "pa-IN" | "ps-AF" | "si-LK" | "sl-SI" | "sq-AL" | "su-ID" | "sw-BI" | "sw-KE" | "sw-RW" | "sw-TZ" | "sw-UG" | "ta-IN" | "te-IN" | "tr-TR" | "uz-UZ" | (string & {});
export type Specialty = "PRIMARYCARE" | "CARDIOLOGY" | "NEUROLOGY" | "ONCOLOGY" | "RADIOLOGY" | "UROLOGY" | (string & {});
export type Type = "CONVERSATION" | "DICTATION" | (string & {});
export type NumberOfChannels = number;
export type MedicalContentIdentificationType = "PHI" | (string & {});
export interface StartMedicalStreamTranscriptionRequest {
    LanguageCode: LanguageCode;
    MediaSampleRateHertz: number;
    MediaEncoding: MediaEncoding;
    VocabularyName?: string | undefined;
    Specialty: Specialty;
    Type: Type;
    ShowSpeakerLabel?: boolean | undefined;
    SessionId?: string | undefined;
    AudioStream: stream.Stream<AudioStream, Error, never>;
    EnableChannelIdentification?: boolean | undefined;
    NumberOfChannels?: number | undefined;
    ContentIdentificationType?: MedicalContentIdentificationType | undefined;
}
export interface MedicalItem {
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    Type?: ItemType | undefined;
    Content?: string | undefined;
    Confidence?: number | undefined;
    Speaker?: string | undefined;
}
export type MedicalItemList = MedicalItem[];
export interface MedicalEntity {
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    Category?: string | undefined;
    Content?: string | undefined;
    Confidence?: number | undefined;
}
export type MedicalEntityList = MedicalEntity[];
export interface MedicalAlternative {
    Transcript?: string | undefined;
    Items?: MedicalItem[] | undefined;
    Entities?: MedicalEntity[] | undefined;
}
export type MedicalAlternativeList = MedicalAlternative[];
export interface MedicalResult {
    ResultId?: string | undefined;
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    IsPartial?: boolean | undefined;
    Alternatives?: MedicalAlternative[] | undefined;
    ChannelId?: string | undefined;
}
export type MedicalResultList = MedicalResult[];
export interface MedicalTranscript {
    Results?: MedicalResult[] | undefined;
}
export interface MedicalTranscriptEvent {
    Transcript?: MedicalTranscript | undefined;
}
export type MedicalTranscriptResultStream = {
    TranscriptEvent: MedicalTranscriptEvent;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException: BadRequestException;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException: LimitExceededException;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException: InternalFailureException;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException: ConflictException;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException: ServiceUnavailableException;
};
export interface StartMedicalStreamTranscriptionResponse {
    RequestId?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaEncoding?: MediaEncoding | undefined;
    VocabularyName?: string | undefined;
    Specialty?: Specialty | undefined;
    Type?: Type | undefined;
    ShowSpeakerLabel?: boolean | undefined;
    SessionId?: string | undefined;
    TranscriptResultStream?: stream.Stream<MedicalTranscriptResultStream, Error, never> | undefined;
    EnableChannelIdentification?: boolean | undefined;
    NumberOfChannels?: number | undefined;
    ContentIdentificationType?: MedicalContentIdentificationType | undefined;
}
export type SessionResumeWindow = number;
export type TranscriptFormat = "spoken" | "written" | (string & {});
export interface StartStreamTranscriptionRequest {
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz: number;
    MediaEncoding: MediaEncoding;
    VocabularyName?: string | undefined;
    SessionId?: string | undefined;
    AudioStream: stream.Stream<AudioStream, Error, never>;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    ShowSpeakerLabel?: boolean | undefined;
    EnableChannelIdentification?: boolean | undefined;
    NumberOfChannels?: number | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentIdentificationType | undefined;
    ContentRedactionType?: ContentRedactionType | undefined;
    PiiEntityTypes?: string | undefined;
    LanguageModelName?: string | undefined;
    IdentifyLanguage?: boolean | undefined;
    LanguageOptions?: string | undefined;
    PreferredLanguage?: LanguageCode | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    VocabularyNames?: string | undefined;
    VocabularyFilterNames?: string | undefined;
    SessionResumeWindow?: number | undefined;
    TranscriptFormat?: TranscriptFormat | undefined;
}
export interface Item {
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    Type?: ItemType | undefined;
    Content?: string | undefined;
    VocabularyFilterMatch?: boolean | undefined;
    Speaker?: string | undefined;
    Confidence?: number | undefined;
    Stable?: boolean | undefined;
}
export type ItemList = Item[];
export interface Entity {
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    Category?: string | undefined;
    Type?: string | undefined;
    Content?: string | undefined;
    Confidence?: number | undefined;
}
export type EntityList = Entity[];
export interface Alternative {
    Transcript?: string | undefined;
    Items?: Item[] | undefined;
    Entities?: Entity[] | undefined;
}
export type AlternativeList = Alternative[];
export interface LanguageWithScore {
    LanguageCode?: LanguageCode | undefined;
    Score?: number | undefined;
}
export type LanguageIdentification = LanguageWithScore[];
export interface Result {
    ResultId?: string | undefined;
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    IsPartial?: boolean | undefined;
    Alternatives?: Alternative[] | undefined;
    ChannelId?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LanguageIdentification?: LanguageWithScore[] | undefined;
}
export type ResultList = Result[];
export interface Transcript {
    Results?: Result[] | undefined;
}
export interface TranscriptEvent {
    Transcript?: Transcript | undefined;
}
export type TranscriptResultStream = {
    TranscriptEvent: TranscriptEvent;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException: BadRequestException;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException: LimitExceededException;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException: InternalFailureException;
    ConflictException?: undefined;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException: ConflictException;
    ServiceUnavailableException?: undefined;
} | {
    TranscriptEvent?: undefined;
    BadRequestException?: undefined;
    LimitExceededException?: undefined;
    InternalFailureException?: undefined;
    ConflictException?: undefined;
    ServiceUnavailableException: ServiceUnavailableException;
};
export interface StartStreamTranscriptionResponse {
    RequestId?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaEncoding?: MediaEncoding | undefined;
    VocabularyName?: string | undefined;
    SessionId?: string | undefined;
    TranscriptResultStream?: stream.Stream<TranscriptResultStream, Error, never> | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    ShowSpeakerLabel?: boolean | undefined;
    EnableChannelIdentification?: boolean | undefined;
    NumberOfChannels?: number | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentIdentificationType | undefined;
    ContentRedactionType?: ContentRedactionType | undefined;
    PiiEntityTypes?: string | undefined;
    LanguageModelName?: string | undefined;
    IdentifyLanguage?: boolean | undefined;
    LanguageOptions?: string | undefined;
    PreferredLanguage?: LanguageCode | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    VocabularyNames?: string | undefined;
    VocabularyFilterNames?: string | undefined;
    SessionResumeWindow?: number | undefined;
    TranscriptFormat?: TranscriptFormat | undefined;
}
export type GetMedicalScribeStreamError = BadRequestException | InternalFailureException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Provides details about the specified Amazon Web Services HealthScribe streaming session.
 * To view the status of the streaming session, check the `StreamStatus` field in the response. To get the
 * details of post-stream analytics, including its status, check the `PostStreamAnalyticsResult` field in the response.
 */
export declare const getMedicalScribeStream: API.OperationMethod<GetMedicalScribeStreamRequest & RegionInput, GetMedicalScribeStreamResponse, GetMedicalScribeStreamError, Credentials | HttpClient.HttpClient>;
export type StartCallAnalyticsStreamTranscriptionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a bidirectional HTTP/2 or WebSocket stream where audio is streamed to
 * Amazon Transcribe and the transcription results are streamed to your application. Use this operation
 * for Call Analytics transcriptions.
 *
 * The following parameters are required:
 *
 * - `language-code` or `identify-language`
 *
 * - `media-encoding`
 *
 * - `sample-rate`
 *
 * For more information on streaming with Amazon Transcribe, see Transcribing streaming audio.
 */
export declare const startCallAnalyticsStreamTranscription: API.OperationMethod<StartCallAnalyticsStreamTranscriptionRequest & RegionInput, StartCallAnalyticsStreamTranscriptionResponse, StartCallAnalyticsStreamTranscriptionError, Credentials | HttpClient.HttpClient>;
export type StartMedicalScribeStreamError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a bidirectional HTTP/2 stream, where audio is streamed to
 * Amazon Web Services HealthScribe
 * and the transcription results are streamed to your application.
 *
 * When you start a stream, you first specify the stream configuration in a `MedicalScribeConfigurationEvent`.
 * This event includes channel definitions, encryption settings, medical scribe context, and post-stream analytics settings, such as the output configuration for aggregated transcript and clinical note generation. These are additional
 * streaming session configurations beyond those provided in your initial start request headers. Whether you are starting a new session or resuming an existing session,
 * your first event must be a `MedicalScribeConfigurationEvent`.
 *
 * After you send a `MedicalScribeConfigurationEvent`, you start `AudioEvents` and Amazon Web Services HealthScribe
 * responds with real-time transcription results. When you are finished, to start processing the results with the post-stream analytics, send a `MedicalScribeSessionControlEvent` with a `Type` of
 * `END_OF_SESSION` and Amazon Web Services HealthScribe starts the analytics.
 *
 * You can pause or resume streaming.
 * To pause streaming, complete the input stream without sending the
 * `MedicalScribeSessionControlEvent`.
 * To resume streaming, call the `StartMedicalScribeStream` and specify the same SessionId you used to start the stream.
 *
 * The following parameters are required:
 *
 * - `language-code`
 *
 * - `media-encoding`
 *
 * - `media-sample-rate-hertz`
 *
 * For more information on streaming with
 * Amazon Web Services HealthScribe,
 * see Amazon Web Services HealthScribe.
 */
export declare const startMedicalScribeStream: API.OperationMethod<StartMedicalScribeStreamRequest & RegionInput, StartMedicalScribeStreamResponse, StartMedicalScribeStreamError, Credentials | HttpClient.HttpClient>;
export type StartMedicalStreamTranscriptionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a bidirectional HTTP/2 or WebSocket stream where audio is streamed to
 * Amazon Transcribe Medical and the transcription results are streamed to your
 * application.
 *
 * The following parameters are required:
 *
 * - `language-code`
 *
 * - `media-encoding`
 *
 * - `sample-rate`
 *
 * For more information on streaming with Amazon Transcribe Medical, see
 * Transcribing
 * streaming audio.
 */
export declare const startMedicalStreamTranscription: API.OperationMethod<StartMedicalStreamTranscriptionRequest & RegionInput, StartMedicalStreamTranscriptionResponse, StartMedicalStreamTranscriptionError, Credentials | HttpClient.HttpClient>;
export type StartStreamTranscriptionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a bidirectional HTTP/2 or WebSocket stream where audio is streamed to
 * Amazon Transcribe and the transcription results are streamed to your application.
 *
 * The following parameters are required:
 *
 * - `language-code` or `identify-language` or `identify-multiple-language`
 *
 * - `media-encoding`
 *
 * - `sample-rate`
 *
 * For more information on streaming with Amazon Transcribe, see Transcribing streaming audio.
 */
export declare const startStreamTranscription: API.OperationMethod<StartStreamTranscriptionRequest & RegionInput, StartStreamTranscriptionResponse, StartStreamTranscriptionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=transcribe-streaming.d.ts.map