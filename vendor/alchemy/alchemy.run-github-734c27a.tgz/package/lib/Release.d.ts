import * as Repos from "@distilled.cloud/github/repos";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface ReleaseProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Git tag name for this release. The tag is the release's identity —
     * changing it replaces the release.
     */
    tagName: string;
    /**
     * Release title/name. If omitted, GitHub uses the tag name.
     */
    name?: string;
    /**
     * Release notes/description (supports GitHub Markdown).
     *
     * The body is automatically dedented, so you can use indented template
     * literals without worrying about leading whitespace. Accepts
     * `Output<string>` at the call site via `Output.interpolate` to embed
     * resource attributes that are not yet resolved.
     */
    body?: string;
    /**
     * Whether this is a draft release (not visible to users).
     * @default false
     */
    draft?: boolean;
    /**
     * Whether this is a prerelease (beta, alpha, etc.).
     * @default false
     */
    prerelease?: boolean;
    /**
     * Commitish (branch, commit SHA, or tag) to target. If the tag doesn't
     * exist, the release will create it from this commitish. If omitted,
     * GitHub defaults to the repository's default branch.
     */
    targetCommitish?: string;
    /**
     * Whether to automatically generate release notes from commits.
     * @default false
     */
    generateReleaseNotes?: boolean;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface Release extends Resource<"GitHub.Release", ReleaseProps, {
    /**
     * Numeric release ID.
     */
    releaseId: number;
    /**
     * GraphQL node ID of the release.
     */
    nodeId: string;
    /**
     * The git tag name.
     */
    tagName: string;
    /**
     * The release name/title.
     */
    name: string;
    /**
     * Release notes/description.
     */
    body: string;
    /**
     * Whether this is a draft release.
     */
    draft: boolean;
    /**
     * Whether this is a prerelease.
     */
    prerelease: boolean;
    /**
     * URL to view the release in a browser.
     */
    htmlUrl: string;
    /**
     * URL for uploading release assets.
     */
    uploadUrl: string;
    /**
     * ISO-8601 timestamp of when the release was created.
     */
    createdAt: string;
    /**
     * ISO-8601 timestamp of when the release was published.
     */
    publishedAt: string | null;
}, never, GitHub.Providers, ReleaseLookup> {
}
/**
 * Props for {@link Release.lookup}: find a release this stack
 * doesn't manage by its repository and tag.
 */
export interface ReleaseLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Git tag the release is for. */
    tag: string;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub release.
 *
 * `Release` manages repository releases (tagged versions with notes,
 * binaries, etc.). Releases are created on first deploy and updated in place
 * on subsequent deploys when properties change. Publishing a draft converts it
 * to a public release.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope for private repositories or `public_repo` for public ones.
 * ### Creating Releases
 * **Example:** Basic Release
 * ```typescript
 * const v1 = yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.0",
 *   name: "Version 1.0.0",
 *   body: "First stable release",
 * });
 * ```
 *
 * **Example:** Prerelease
 * ```typescript
 * yield* GitHub.Release("beta", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v2.0.0-beta.1",
 *   name: "v2.0.0 Beta 1",
 *   body: "Beta release for testing",
 *   prerelease: true,
 * });
 * ```
 *
 * ### Draft Releases
 * **Example:** Create Draft and Publish Later
 * ```typescript
 * // First deploy: create as draft
 * const release = yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.0",
 *   name: "Version 1.0.0",
 *   body: "Release notes here",
 *   draft: true,
 * });
 *
 * // Later deploy: publish by setting draft: false
 * const release = yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.0",
 *   name: "Version 1.0.0",
 *   body: "Release notes here",
 *   draft: false,
 * });
 * ```
 *
 * ### Auto-Generated Release Notes
 * **Example:** Generate Notes from Commits
 * ```typescript
 * yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.1.0",
 *   name: "Version 1.1.0",
 *   generateReleaseNotes: true,
 * });
 * ```
 *
 * ### Targeting Specific Commits
 * **Example:** Release from Branch or Commit
 * ```typescript
 * yield* GitHub.Release("hotfix", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.1",
 *   name: "Hotfix 1.0.1",
 *   body: "Critical bug fix",
 *   targetCommitish: "hotfix-branch",
 * });
 * ```
 *
 * ### Updating Releases
 * Deploy with the same logical ID and tag to update the existing release.
 *
 * **Example:** Update Release Notes
 * ```typescript
 * yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.0",
 *   name: "Version 1.0.0",
 *   body: `
 *     # What's New
 *
 *     - Feature A
 *     - Feature B
 *     - Bug fixes
 *   `,
 * });
 * ```
 *
 * ### Replacing on Tag Change
 * Changing the tag creates a new release and deletes the old one.
 *
 * **Example:** New Tag = New Release
 * ```typescript
 * // First deploy creates v1.0.0
 * const release = yield* GitHub.Release("latest", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.0.0",
 * });
 *
 * // Later deploy with different tag replaces it
 * const release = yield* GitHub.Release("latest", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   tagName: "v1.1.0",
 * });
 * ```
 *
 * ### Wiring with Other Resources
 * **Example:** Create Repository with Release
 * ```typescript
 * import * as Output from "alchemy/Output";
 *
 * const repo = yield* GitHub.Repository("sdk", {
 *   owner: "my-org",
 *   name: "sdk",
 *   autoInit: true,
 * });
 *
 * yield* GitHub.Release("v1", {
 *   owner: "my-org",
 *   repository: Output.map(repo.fullName, (fullName) => fullName.split("/")[1]!),
 *   tagName: "v1.0.0",
 *   name: "Initial Release",
 *   body: "First public version of the SDK",
 * });
 * ```
 *
 * ### Looking up an existing release
 * `Release.lookup` references a release Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 * Draft releases have no tag yet, so a lookup finds only published ones.
 *
 * **Example:** Reference an existing release
 * ```typescript
 * const latest = GitHub.Release.lookup({ owner: "alchemy-run", repository: "alchemy", tag: "v2.0.0" });
 * ```
 *
 * @resource
 * @product Release
 */
export declare const Release: import("alchemy/Resource").ResourceClass<Release>;
export declare const ReleaseProvider: () => import("effect/Layer").Layer<Provider.Provider<Release>, never, Repos.GithubOpContext>;
//# sourceMappingURL=Release.d.ts.map