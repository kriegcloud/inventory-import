import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { StateStoreError } from "./State.ts";
/**
 * Client-side envelope encryption of the secrets (`Redacted` values) in
 * persisted state, for any state store.
 *
 * The {@link StateEncryption} service mints and unwraps data keys, e.g. with
 * AWS KMS. Provide it to a store's layer and the store encrypts every secret
 * under a data key before it leaves the process:
 *
 * ```typescript
 * state: Cloudflare.state().pipe(Layer.provide(AWS.stateEncryption())),
 * ```
 *
 * A store minting a data key asks the service once per stage for its
 * lifetime, so a deploy makes one key request per stage however many
 * secrets it writes. Secrets are AES-256-GCM encrypted under it; every other
 * value stays readable, so plans and diffs keep working. A record with no
 * secret is written as it always was.
 *
 * Stores that keep records as text write a sealed record as a header line
 * naming the service and holding the wrapped data key, then the record's
 * JSON with every secret replaced by its ciphertext:
 *
 * ```
 * alchemy:sealed:1:aws-kms:<wrapped data key>
 * {"status":"created","attr":{"password":{"__sealed__":"<iv | ciphertext | tag>"}}}
 * ```
 *
 * The header makes the record invalid JSON on purpose: a version of alchemy
 * from before encryption fails to parse it instead of reading the envelope as
 * the secret. Stores that keep records as JSON values put the same header in
 * a top-level `__alchemy_sealed__` field, and fence older versions out by
 * their store version.
 */
/** Starts every sealed text record. */
export declare const SEALED_PREFIX = "alchemy:sealed:1:";
/** Marks one sealed secret: `{ [SEALED_MARKER]: base64(iv | ciphertext | tag) }`. */
export declare const SEALED_MARKER = "__sealed__";
/** Carries a sealed JSON record's header: `{ by, key }`, plus `value` for a non-object. */
export declare const SEALED_RECORD_MARKER = "__alchemy_sealed__";
/** The stage a record belongs to. Data keys are bound to it. */
export interface SealingScope {
    readonly stack: string;
    readonly stage: string;
}
/** A data key: its plaintext, and the copy the service wrapped. */
export interface DataKey {
    readonly plaintext: Uint8Array;
    /** The wrapped key, base64. */
    readonly wrapped: string;
}
/** What a {@link StateEncryption} implementation provides. */
export interface StateEncryptionService {
    /**
     * Names the implementation in every record it seals, e.g. `aws-kms`:
     * lowercase letters, digits and hyphens. A store refuses a record another
     * implementation sealed rather than handing it the wrong key.
     */
    readonly id: string;
    /** A fresh 256-bit data key for `scope`'s writes. */
    readonly generate: (scope: SealingScope) => Effect.Effect<DataKey, StateStoreError>;
    /** The plaintext of a data key {@link StateEncryptionService.generate} wrapped for `scope`. */
    readonly unwrap: (wrapped: string, scope: SealingScope) => Effect.Effect<Uint8Array, StateStoreError>;
    /**
     * Turn encryption off: write every secret in plaintext again, and open the
     * ones this implementation sealed as each stage deploys. Deploy every stage
     * this way, then remove the layer.
     */
    readonly decryptOnly?: boolean;
}
declare const StateEncryption_base: Context.ServiceClass<StateEncryption, "alchemy/State/StateEncryption", StateEncryptionService>;
/**
 * Encrypts the secrets in state. Provide an implementation to a state store's
 * layer, e.g. `AWS.stateEncryption()`; a store with none writes secrets as
 * it always has (the AWS stores default to their own KMS key).
 */
export declare class StateEncryption extends StateEncryption_base {
}
/** How a store turns state values into what it stores, and back. */
export interface StateCodec {
    /** Text for `value`, sealed when it holds a secret. */
    readonly encode: (scope: SealingScope, value: unknown, space?: number) => Effect.Effect<string, StateStoreError>;
    /** The value of stored text. `what` names it in a failure, e.g. `state object 'a.json'`. */
    readonly decode: <T>(scope: SealingScope, text: string, what: string) => Effect.Effect<T, StateStoreError>;
    /** A JSON value for `value`, for stores that keep JSON: secrets sealed in place. */
    readonly encodeJson: (scope: SealingScope, value: unknown) => Effect.Effect<unknown, StateStoreError>;
    /** The value of a stored JSON value. */
    readonly decodeJson: <T>(scope: SealingScope, json: unknown, what: string) => Effect.Effect<T, StateStoreError>;
    /** Plain JSON for stored text, every sealed secret opened. */
    readonly open: (scope: SealingScope, text: string) => Effect.Effect<string, StateStoreError>;
    /**
     * Whether stored text should be written again: it holds a secret in
     * plaintext and this codec encrypts, or it is sealed and this codec is
     * turning encryption off. A store that holds the stage's lock rewrites
     * such a record when it loads it; one that doesn't marks it, and the
     * stage's deploy commits it.
     */
    readonly stale: (text: string) => boolean;
    /** {@link StateCodec.stale} for a stored JSON value. */
    readonly staleJson: (json: unknown) => boolean;
}
/** Whether stored text is a sealed record. */
export declare const isSealed: (text: string) => boolean;
/**
 * The codec of a store without {@link StateEncryption}: secrets are written in
 * plaintext, as `{ "__redacted__": <value> }`. A sealed record fails to decode.
 */
export declare const plainCodec: StateCodec;
/**
 * A codec that seals secrets under data keys from `encryption`. It mints one
 * data key per stage for its lifetime, and unwraps each stored data key at
 * most once. Records written in plaintext still decode, so a store can start
 * encrypting with state already in it.
 */
export declare const makeSealingCodec: (encryption: StateEncryptionService) => StateCodec;
/**
 * The codec for the {@link StateEncryption} in context: sealing when one is
 * provided, {@link plainCodec} otherwise. Stores resolve it when they are
 * built.
 */
export declare const stateCodec: Effect.Effect<StateCodec>;
export {};
//# sourceMappingURL=StateEncryption.d.ts.map