import * as Effect from "effect/Effect";
import type * as Aggregate from "../../Aggregate.ts";
import * as Smt from "./Smt.ts";
import * as Source from "./Source.ts";
/** How a rule stands against the one it was locked as. */
export type Comparison = 
/** Every state the rules allow now is one the locked rule allows. */
{
    readonly _tag: "Kept";
}
/** A state the rules allow now, that the locked rule refuses. */
 | {
    readonly _tag: "Weaker";
    readonly state: unknown;
} | {
    readonly _tag: "Unknown";
    readonly reason: string;
};
/**
 * A rule's text with what a formatter changes taken out: two texts that are
 * the same after it are the same rule.
 */
export declare const normal: (source: string) => string;
/** What a model's or an aggregate's files say of its rules, and how the changed ones compare. */
export interface Inspected {
    /** Each rule the files write, by the name a report gives it, as the code that writes it. */
    readonly sources: ReadonlyMap<string, {
        readonly kind: string;
        readonly source: string;
    }>;
    /** Each rule asked about, by name, against the text it was locked as. */
    readonly compared: ReadonlyMap<string, Comparison>;
}
/**
 * Read the rules of a model, or of one aggregate, from the files that declare
 * them, and compare each invariant in `changed` with the text it was locked as.
 */
export declare const inspect: (options: {
    /** The file that declares the model or the aggregate. */
    readonly file: string;
    readonly target: unknown;
    readonly aggregates: ReadonlyArray<Aggregate.Any>;
    /** A model's decisions: each has transitions of its own. */
    readonly decisions?: ReadonlyArray<{
        readonly decisionName: string;
        readonly command: unknown;
    }>;
    /** A model's name, for the rules of its own. */
    readonly model?: string;
    /** Whether `sources` and `compared` are named `Rule` or `Aggregate.Rule`. */
    readonly qualified: boolean;
    /** For a rule that may have changed: the text it was locked as. */
    readonly locked: ReadonlyMap<string, string>;
    /** The functions not read, as for the verification itself. */
    readonly reading?: Source.Reading | undefined;
}) => Effect.Effect<Inspected, Source.LoadError | Smt.SolverError, import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("effect/Scope").Scope>;
//# sourceMappingURL=Lock.d.ts.map