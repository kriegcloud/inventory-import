import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyException_base: S.TaggedErrorClass<"DependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DependencyException extends /*@__PURE__*/ DependencyException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLinkedRoleLockClientException_base: S.TaggedErrorClass<"ServiceLinkedRoleLockClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleLockClientException extends /*@__PURE__*/ ServiceLinkedRoleLockClientException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationComponentId = string;
export interface GetApplicationComponentDetailsRequest {
    applicationComponentId: string;
}
export type ResourceId = string;
export type ResourceName = string;
export type TransformationToolName = string;
export type TranformationToolDescription = string;
export type TranformationToolInstallationLink = string;
export interface TransformationTool {
    name?: string | undefined;
    description?: string | undefined;
    tranformationToolInstallationLink?: string | undefined;
}
export type TargetDestination = string;
export type Strategy = string;
export interface RecommendationSet {
    transformationTool?: TransformationTool | undefined;
    targetDestination?: string | undefined;
    strategy?: string | undefined;
}
export type SrcCodeOrDbAnalysisStatus = string;
export type StatusMessage = string;
export type Severity = string;
export interface AntipatternSeveritySummary {
    severity?: string | undefined;
    count?: number | undefined;
}
export type ListAntipatternSeveritySummary = AntipatternSeveritySummary[];
export interface DatabaseConfigDetail {
    secretName?: string | undefined;
}
export interface SourceCodeRepository {
    repository?: string | undefined;
    branch?: string | undefined;
    versionControlType?: string | undefined;
    projectName?: string | undefined;
}
export type SourceCodeRepositories = SourceCodeRepository[];
export type AppType = string;
export type ResourceSubType = string;
export type InclusionStatus = string;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Object {
    s3Bucket?: string | undefined;
    s3key?: string | undefined;
}
export type AntipatternReportStatus = string;
export type ServerId = string;
export type RuntimeAnalysisStatus = string;
export type AppUnitErrorCategory = string;
export interface AppUnitError {
    appUnitErrorCategory?: string | undefined;
}
export type AnalysisType = string;
export type AnalysisStatusUnion = {
    runtimeAnalysisStatus: string;
    srcCodeOrDbAnalysisStatus?: undefined;
} | {
    runtimeAnalysisStatus?: undefined;
    srcCodeOrDbAnalysisStatus: string;
};
export type BinaryAnalyzerName = string;
export type RunTimeAnalyzerName = string;
export type SourceCodeAnalyzerName = string;
export type AnalyzerNameUnion = {
    binaryAnalyzerName: string;
    runTimeAnalyzerName?: undefined;
    sourceCodeAnalyzerName?: undefined;
} | {
    binaryAnalyzerName?: undefined;
    runTimeAnalyzerName: string;
    sourceCodeAnalyzerName?: undefined;
} | {
    binaryAnalyzerName?: undefined;
    runTimeAnalyzerName?: undefined;
    sourceCodeAnalyzerName: string;
};
export interface AntipatternReportResult {
    analyzerName?: AnalyzerNameUnion | undefined;
    antiPatternReportS3Object?: S3Object | undefined;
    antipatternReportStatus?: string | undefined;
    antipatternReportStatusMessage?: string | undefined;
}
export type AntipatternReportResultList = AntipatternReportResult[];
export interface Result {
    analysisType?: string | undefined;
    analysisStatus?: AnalysisStatusUnion | undefined;
    statusMessage?: string | undefined;
    antipatternReportResultList?: AntipatternReportResult[] | undefined;
}
export type ResultList = Result[];
export interface ApplicationComponentDetail {
    id?: string | undefined;
    name?: string | undefined;
    recommendationSet?: RecommendationSet | undefined;
    analysisStatus?: string | undefined;
    statusMessage?: string | undefined;
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[] | undefined;
    databaseConfigDetail?: DatabaseConfigDetail | undefined;
    sourceCodeRepositories?: SourceCodeRepository[] | undefined;
    appType?: string | undefined;
    resourceSubType?: string | undefined;
    inclusionStatus?: string | undefined;
    antipatternReportS3Object?: S3Object | undefined;
    antipatternReportStatus?: string | undefined;
    antipatternReportStatusMessage?: string | undefined;
    osVersion?: string | undefined;
    osDriver?: string | undefined;
    lastAnalyzedTimestamp?: Date | undefined;
    associatedServerId?: string | undefined;
    moreServerAssociationExists?: boolean | undefined;
    runtimeStatus?: string | undefined;
    runtimeStatusMessage?: string | undefined;
    appUnitError?: AppUnitError | undefined;
    resultList?: Result[] | undefined;
}
export interface AssociatedApplication {
    name?: string | undefined;
    id?: string | undefined;
}
export type AssociatedApplications = AssociatedApplication[];
export type AssociatedServerIDs = string[];
export interface GetApplicationComponentDetailsResponse {
    applicationComponentDetail?: ApplicationComponentDetail | undefined;
    associatedApplications?: AssociatedApplication[] | undefined;
    moreApplicationResource?: boolean | undefined;
    associatedServerIds?: string[] | undefined;
}
export interface GetApplicationComponentStrategiesRequest {
    applicationComponentId: string;
}
export type StrategyRecommendation = string;
export interface ApplicationComponentStrategy {
    recommendation?: RecommendationSet | undefined;
    status?: string | undefined;
    isPreferred?: boolean | undefined;
}
export type ApplicationComponentStrategies = ApplicationComponentStrategy[];
export interface GetApplicationComponentStrategiesResponse {
    applicationComponentStrategies?: ApplicationComponentStrategy[] | undefined;
}
export type AsyncTaskId = string;
export interface GetAssessmentRequest {
    id: string;
}
export type AssessmentStatus = string;
export type AssessmentStatusMessage = string;
export interface DataCollectionDetails {
    status?: string | undefined;
    servers?: number | undefined;
    failed?: number | undefined;
    success?: number | undefined;
    inProgress?: number | undefined;
    startTime?: Date | undefined;
    completionTime?: Date | undefined;
    statusMessage?: string | undefined;
}
export type Condition = string;
export type AssessmentTargetValues = string[];
export interface AssessmentTarget {
    condition: string;
    name: string;
    values: string[];
}
export type AssessmentTargets = AssessmentTarget[];
export interface GetAssessmentResponse {
    id?: string | undefined;
    dataCollectionDetails?: DataCollectionDetails | undefined;
    assessmentTargets?: AssessmentTarget[] | undefined;
}
export interface GetImportFileTaskRequest {
    id: string;
}
export type ImportFileTaskStatus = string;
export type ImportS3Bucket = string;
export type ImportS3Key = string;
export interface GetImportFileTaskResponse {
    id?: string | undefined;
    status?: string | undefined;
    startTime?: Date | undefined;
    inputS3Bucket?: string | undefined;
    inputS3Key?: string | undefined;
    statusReportS3Bucket?: string | undefined;
    statusReportS3Key?: string | undefined;
    completionTime?: Date | undefined;
    numberOfRecordsSuccess?: number | undefined;
    numberOfRecordsFailed?: number | undefined;
    importName?: string | undefined;
}
export interface GetLatestAssessmentIdRequest {
}
export interface GetLatestAssessmentIdResponse {
    id?: string | undefined;
}
export interface GetPortfolioPreferencesRequest {
}
export type BusinessGoalsInteger = number;
export interface BusinessGoals {
    speedOfMigration?: number | undefined;
    reduceOperationalOverheadWithManagedServices?: number | undefined;
    modernizeInfrastructureWithCloudNativeTechnologies?: number | undefined;
    licenseCostReduction?: number | undefined;
}
export interface PrioritizeBusinessGoals {
    businessGoals?: BusinessGoals | undefined;
}
export type AwsManagedTargetDestination = string;
export type AwsManagedTargetDestinations = string[];
export interface AwsManagedResources {
    targetDestination: string[];
}
export type SelfManageTargetDestination = string;
export type SelfManageTargetDestinations = string[];
export interface SelfManageResources {
    targetDestination: string[];
}
export type NoPreferenceTargetDestination = string;
export type NoPreferenceTargetDestinations = string[];
export interface NoManagementPreference {
    targetDestination: string[];
}
export type ManagementPreference = {
    awsManagedResources: AwsManagedResources;
    selfManageResources?: undefined;
    noPreference?: undefined;
} | {
    awsManagedResources?: undefined;
    selfManageResources: SelfManageResources;
    noPreference?: undefined;
} | {
    awsManagedResources?: undefined;
    selfManageResources?: undefined;
    noPreference: NoManagementPreference;
};
export interface ApplicationPreferences {
    managementPreference?: ManagementPreference | undefined;
}
export type DatabaseManagementPreference = string;
export type HeterogeneousTargetDatabaseEngine = string;
export type HeterogeneousTargetDatabaseEngines = string[];
export interface Heterogeneous {
    targetDatabaseEngine: string[];
}
export type HomogeneousTargetDatabaseEngine = string;
export type HomogeneousTargetDatabaseEngines = string[];
export interface Homogeneous {
    targetDatabaseEngine?: string[] | undefined;
}
export type TargetDatabaseEngine = string;
export type TargetDatabaseEngines = string[];
export interface NoDatabaseMigrationPreference {
    targetDatabaseEngine: string[];
}
export type DatabaseMigrationPreference = {
    heterogeneous: Heterogeneous;
    homogeneous?: undefined;
    noPreference?: undefined;
} | {
    heterogeneous?: undefined;
    homogeneous: Homogeneous;
    noPreference?: undefined;
} | {
    heterogeneous?: undefined;
    homogeneous?: undefined;
    noPreference: NoDatabaseMigrationPreference;
};
export interface DatabasePreferences {
    databaseManagementPreference?: string | undefined;
    databaseMigrationPreference?: DatabaseMigrationPreference | undefined;
}
export type ApplicationMode = string;
export interface GetPortfolioPreferencesResponse {
    prioritizeBusinessGoals?: PrioritizeBusinessGoals | undefined;
    applicationPreferences?: ApplicationPreferences | undefined;
    databasePreferences?: DatabasePreferences | undefined;
    applicationMode?: string | undefined;
}
export interface GetPortfolioSummaryRequest {
}
export interface StrategySummary {
    strategy?: string | undefined;
    count?: number | undefined;
}
export type ListStrategySummary = StrategySummary[];
export interface ApplicationComponentSummary {
    appType?: string | undefined;
    count?: number | undefined;
}
export type ListApplicationComponentSummary = ApplicationComponentSummary[];
export type ServerOsType = string;
export interface ServerSummary {
    ServerOsType?: string | undefined;
    count?: number | undefined;
}
export type ListServerSummary = ServerSummary[];
export interface ApplicationComponentStatusSummary {
    srcCodeOrDbAnalysisStatus?: string | undefined;
    count?: number | undefined;
}
export type ListApplicationComponentStatusSummary = ApplicationComponentStatusSummary[];
export type RunTimeAssessmentStatus = string;
export interface ServerStatusSummary {
    runTimeAssessmentStatus?: string | undefined;
    count?: number | undefined;
}
export type ListServerStatusSummary = ServerStatusSummary[];
export interface AssessmentSummary {
    listServerStrategySummary?: StrategySummary[] | undefined;
    listApplicationComponentStrategySummary?: StrategySummary[] | undefined;
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[] | undefined;
    listApplicationComponentSummary?: ApplicationComponentSummary[] | undefined;
    listServerSummary?: ServerSummary[] | undefined;
    antipatternReportS3Object?: S3Object | undefined;
    antipatternReportStatus?: string | undefined;
    antipatternReportStatusMessage?: string | undefined;
    lastAnalyzedTimestamp?: Date | undefined;
    listApplicationComponentStatusSummary?: ApplicationComponentStatusSummary[] | undefined;
    listServerStatusSummary?: ServerStatusSummary[] | undefined;
}
export interface GetPortfolioSummaryResponse {
    assessmentSummary?: AssessmentSummary | undefined;
}
export type RecommendationTaskId = string;
export interface GetRecommendationReportDetailsRequest {
    id: string;
}
export type RecommendationReportStatus = string;
export type RecommendationReportStatusMessage = string;
export type RecommendationReportTimeStamp = Date;
export type S3Keys = string[];
export interface RecommendationReportDetails {
    status?: string | undefined;
    statusMessage?: string | undefined;
    startTime?: Date | undefined;
    completionTime?: Date | undefined;
    s3Bucket?: string | undefined;
    s3Keys?: string[] | undefined;
}
export interface GetRecommendationReportDetailsResponse {
    id?: string | undefined;
    recommendationReportDetails?: RecommendationReportDetails | undefined;
}
export type NextToken = string;
export type MaxResult = number;
export interface GetServerDetailsRequest {
    serverId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type OSType = string;
export type OSVersion = string;
export interface OSInfo {
    type?: string | undefined;
    version?: string | undefined;
}
export type InterfaceName = string;
export type IPAddress = string;
export type MacAddress = string;
export type NetMask = string;
export interface NetworkInfo {
    interfaceName: string;
    ipAddress: string;
    macAddress: string;
    netMask: string;
}
export type NetworkInfoList = NetworkInfo[];
export interface SystemInfo {
    osInfo?: OSInfo | undefined;
    fileSystemType?: string | undefined;
    networkInfoList?: NetworkInfo[] | undefined;
    cpuArchitecture?: string | undefined;
}
export type ServerErrorCategory = string;
export interface ServerError {
    serverErrorCategory?: string | undefined;
}
export interface ServerDetail {
    id?: string | undefined;
    name?: string | undefined;
    recommendationSet?: RecommendationSet | undefined;
    dataCollectionStatus?: string | undefined;
    statusMessage?: string | undefined;
    listAntipatternSeveritySummary?: AntipatternSeveritySummary[] | undefined;
    systemInfo?: SystemInfo | undefined;
    applicationComponentStrategySummary?: StrategySummary[] | undefined;
    antipatternReportS3Object?: S3Object | undefined;
    antipatternReportStatus?: string | undefined;
    antipatternReportStatusMessage?: string | undefined;
    serverType?: string | undefined;
    lastAnalyzedTimestamp?: Date | undefined;
    serverError?: ServerError | undefined;
}
export interface GetServerDetailsResponse {
    nextToken?: string | undefined;
    serverDetail?: ServerDetail | undefined;
    associatedApplications?: AssociatedApplication[] | undefined;
}
export interface GetServerStrategiesRequest {
    serverId: string;
}
export interface ServerStrategy {
    recommendation?: RecommendationSet | undefined;
    status?: string | undefined;
    numberOfApplicationComponents?: number | undefined;
    isPreferred?: boolean | undefined;
}
export type ServerStrategies = ServerStrategy[];
export interface GetServerStrategiesResponse {
    serverStrategies?: ServerStrategy[] | undefined;
}
export type SortOrder = string;
export interface ListAnalyzableServersRequest {
    sort?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AnalyzableServerSummary {
    hostname?: string | undefined;
    ipAddress?: string | undefined;
    source?: string | undefined;
    vmId?: string | undefined;
}
export type AnalyzableServerSummaryList = AnalyzableServerSummary[];
export interface ListAnalyzableServersResponse {
    analyzableServers?: AnalyzableServerSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ApplicationComponentCriteria = string;
export type GroupName = string;
export interface Group {
    name?: string | undefined;
    value?: string | undefined;
}
export type GroupIds = Group[];
export interface ListApplicationComponentsRequest {
    applicationComponentCriteria?: string | undefined;
    filterValue?: string | undefined;
    sort?: string | undefined;
    groupIdFilter?: Group[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ApplicationComponentDetails = ApplicationComponentDetail[];
export interface ListApplicationComponentsResponse {
    applicationComponentInfos?: ApplicationComponentDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCollectorsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type CollectorHealth = string;
export interface VcenterBasedRemoteInfo {
    vcenterConfigurationTimeStamp?: string | undefined;
    osType?: string | undefined;
}
export type VcenterBasedRemoteInfoList = VcenterBasedRemoteInfo[];
export type AuthType = string;
export interface IPAddressBasedRemoteInfo {
    ipAddressConfigurationTimeStamp?: string | undefined;
    authType?: string | undefined;
    osType?: string | undefined;
}
export type IPAddressBasedRemoteInfoList = IPAddressBasedRemoteInfo[];
export type VersionControlType = string;
export interface VersionControlInfo {
    versionControlType?: string | undefined;
    versionControlConfigurationTimeStamp?: string | undefined;
}
export type VersionControlInfoList = VersionControlInfo[];
export type PipelineType = string;
export interface PipelineInfo {
    pipelineType?: string | undefined;
    pipelineConfigurationTimeStamp?: string | undefined;
}
export type PipelineInfoList = PipelineInfo[];
export interface RemoteSourceCodeAnalysisServerInfo {
    remoteSourceCodeAnalysisServerConfigurationTimestamp?: string | undefined;
}
export interface ConfigurationSummary {
    vcenterBasedRemoteInfoList?: VcenterBasedRemoteInfo[] | undefined;
    ipAddressBasedRemoteInfoList?: IPAddressBasedRemoteInfo[] | undefined;
    versionControlInfoList?: VersionControlInfo[] | undefined;
    pipelineInfoList?: PipelineInfo[] | undefined;
    remoteSourceCodeAnalysisServerInfo?: RemoteSourceCodeAnalysisServerInfo | undefined;
}
export interface Collector {
    collectorId?: string | undefined;
    ipAddress?: string | undefined;
    hostName?: string | undefined;
    collectorHealth?: string | undefined;
    collectorVersion?: string | undefined;
    registeredTimeStamp?: string | undefined;
    lastActivityTimeStamp?: string | undefined;
    configurationSummary?: ConfigurationSummary | undefined;
}
export type Collectors = Collector[];
export interface ListCollectorsResponse {
    Collectors?: Collector[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImportFileTaskRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ImportFileTaskInformation {
    id?: string | undefined;
    status?: string | undefined;
    startTime?: Date | undefined;
    inputS3Bucket?: string | undefined;
    inputS3Key?: string | undefined;
    statusReportS3Bucket?: string | undefined;
    statusReportS3Key?: string | undefined;
    completionTime?: Date | undefined;
    numberOfRecordsSuccess?: number | undefined;
    numberOfRecordsFailed?: number | undefined;
    importName?: string | undefined;
}
export type ListImportFileTaskInformation = ImportFileTaskInformation[];
export interface ListImportFileTaskResponse {
    taskInfos?: ImportFileTaskInformation[] | undefined;
    nextToken?: string | undefined;
}
export type ServerCriteria = string;
export interface ListServersRequest {
    serverCriteria?: string | undefined;
    filterValue?: string | undefined;
    sort?: string | undefined;
    groupIdFilter?: Group[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ServerDetails = ServerDetail[];
export interface ListServersResponse {
    serverInfos?: ServerDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface PutPortfolioPreferencesRequest {
    prioritizeBusinessGoals?: PrioritizeBusinessGoals | undefined;
    applicationPreferences?: ApplicationPreferences | undefined;
    databasePreferences?: DatabasePreferences | undefined;
    applicationMode?: string | undefined;
}
export interface PutPortfolioPreferencesResponse {
}
export type AssessmentDataSourceType = string;
export interface StartAssessmentRequest {
    s3bucketForAnalysisData?: string | undefined;
    s3bucketForReportData?: string | undefined;
    assessmentTargets?: AssessmentTarget[] | undefined;
    assessmentDataSourceType?: string | undefined;
}
export interface StartAssessmentResponse {
    assessmentId?: string | undefined;
}
export type DataSourceType = string;
export interface StartImportFileTaskRequest {
    name: string;
    S3Bucket: string;
    s3key: string;
    dataSourceType?: string | undefined;
    groupId?: Group[] | undefined;
    s3bucketForReportData?: string | undefined;
}
export interface StartImportFileTaskResponse {
    id?: string | undefined;
}
export type OutputFormat = string;
export interface StartRecommendationReportGenerationRequest {
    outputFormat?: string | undefined;
    groupIdFilter?: Group[] | undefined;
}
export interface StartRecommendationReportGenerationResponse {
    id?: string | undefined;
}
export interface StopAssessmentRequest {
    assessmentId: string;
}
export interface StopAssessmentResponse {
}
export interface StrategyOption {
    strategy?: string | undefined;
    toolName?: string | undefined;
    targetDestination?: string | undefined;
    isPreferred?: boolean | undefined;
}
export type VersionControl = string;
export type SourceVersion = string;
export type Location = string;
export type ProjectName = string;
export interface SourceCode {
    versionControl?: string | undefined;
    sourceVersion?: string | undefined;
    location?: string | undefined;
    projectName?: string | undefined;
}
export type SourceCodeList = SourceCode[];
export type SecretsManagerKey = string | redacted.Redacted<string>;
export interface UpdateApplicationComponentConfigRequest {
    applicationComponentId: string;
    inclusionStatus?: string | undefined;
    strategyOption?: StrategyOption | undefined;
    sourceCodeList?: SourceCode[] | undefined;
    secretsManagerKey?: string | redacted.Redacted<string> | undefined;
    configureOnly?: boolean | undefined;
    appType?: string | undefined;
}
export interface UpdateApplicationComponentConfigResponse {
}
export interface UpdateServerConfigRequest {
    serverId: string;
    strategyOption?: StrategyOption | undefined;
}
export interface UpdateServerConfigResponse {
}
export type ErrorMessage = string;
export type GetApplicationComponentDetailsError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about an application component.
 */
export declare const getApplicationComponentDetails: API.OperationMethod<GetApplicationComponentDetailsRequest & RegionInput, GetApplicationComponentDetailsResponse, GetApplicationComponentDetailsError, Credentials | HttpClient.HttpClient>;
export type GetApplicationComponentStrategiesError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a list of all the recommended strategies and tools for an application component
 * running on a server.
 */
export declare const getApplicationComponentStrategies: API.OperationMethod<GetApplicationComponentStrategiesRequest & RegionInput, GetApplicationComponentStrategiesResponse, GetApplicationComponentStrategiesError, Credentials | HttpClient.HttpClient>;
export type GetAssessmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status of an on-going assessment.
 */
export declare const getAssessment: API.OperationMethod<GetAssessmentRequest & RegionInput, GetAssessmentResponse, GetAssessmentError, Credentials | HttpClient.HttpClient>;
export type GetImportFileTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details about a specific import task.
 */
export declare const getImportFileTask: API.OperationMethod<GetImportFileTaskRequest & RegionInput, GetImportFileTaskResponse, GetImportFileTaskError, Credentials | HttpClient.HttpClient>;
export type GetLatestAssessmentIdError = AccessDeniedException | DependencyException | InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieve the latest ID of a specific assessment task.
 */
export declare const getLatestAssessmentId: API.OperationMethod<GetLatestAssessmentIdRequest & RegionInput, GetLatestAssessmentIdResponse, GetLatestAssessmentIdError, Credentials | HttpClient.HttpClient>;
export type GetPortfolioPreferencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves your migration and modernization preferences.
 */
export declare const getPortfolioPreferences: API.OperationMethod<GetPortfolioPreferencesRequest & RegionInput, GetPortfolioPreferencesResponse, GetPortfolioPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetPortfolioSummaryError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves overall summary including the number of servers to rehost and the overall
 * number of anti-patterns.
 */
export declare const getPortfolioSummary: API.OperationMethod<GetPortfolioSummaryRequest & RegionInput, GetPortfolioSummaryResponse, GetPortfolioSummaryError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationReportDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about the specified recommendation report.
 */
export declare const getRecommendationReportDetails: API.OperationMethod<GetRecommendationReportDetailsRequest & RegionInput, GetRecommendationReportDetailsResponse, GetRecommendationReportDetailsError, Credentials | HttpClient.HttpClient>;
export type GetServerDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specified server.
 */
export declare const getServerDetails: API.PaginatedOperationMethod<GetServerDetailsRequest & RegionInput, GetServerDetailsResponse, GetServerDetailsError, Credentials | HttpClient.HttpClient, AssociatedApplication>;
export type GetServerStrategiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves recommended strategies and tools for the specified server.
 */
export declare const getServerStrategies: API.OperationMethod<GetServerStrategiesRequest & RegionInput, GetServerStrategiesResponse, GetServerStrategiesError, Credentials | HttpClient.HttpClient>;
export type ListAnalyzableServersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the servers fetched from customer vCenter using Strategy Recommendation Collector.
 */
export declare const listAnalyzableServers: API.PaginatedOperationMethod<ListAnalyzableServersRequest & RegionInput, ListAnalyzableServersResponse, ListAnalyzableServersError, Credentials | HttpClient.HttpClient, AnalyzableServerSummary>;
export type ListApplicationComponentsError = AccessDeniedException | InternalServerException | ServiceLinkedRoleLockClientException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the application components (processes).
 */
export declare const listApplicationComponents: API.PaginatedOperationMethod<ListApplicationComponentsRequest & RegionInput, ListApplicationComponentsResponse, ListApplicationComponentsError, Credentials | HttpClient.HttpClient, ApplicationComponentDetail>;
export type ListCollectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the installed collectors.
 */
export declare const listCollectors: API.PaginatedOperationMethod<ListCollectorsRequest & RegionInput, ListCollectorsResponse, ListCollectorsError, Credentials | HttpClient.HttpClient, Collector>;
export type ListImportFileTaskError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all the imports performed.
 */
export declare const listImportFileTask: API.PaginatedOperationMethod<ListImportFileTaskRequest & RegionInput, ListImportFileTaskResponse, ListImportFileTaskError, Credentials | HttpClient.HttpClient, ImportFileTaskInformation>;
export type ListServersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the servers.
 */
export declare const listServers: API.PaginatedOperationMethod<ListServersRequest & RegionInput, ListServersResponse, ListServersError, Credentials | HttpClient.HttpClient, ServerDetail>;
export type PutPortfolioPreferencesError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Saves the specified migration and modernization preferences.
 */
export declare const putPortfolioPreferences: API.OperationMethod<PutPortfolioPreferencesRequest & RegionInput, PutPortfolioPreferencesResponse, PutPortfolioPreferencesError, Credentials | HttpClient.HttpClient>;
export type StartAssessmentError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts the assessment of an on-premises environment.
 */
export declare const startAssessment: API.OperationMethod<StartAssessmentRequest & RegionInput, StartAssessmentResponse, StartAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartImportFileTaskError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a file import.
 */
export declare const startImportFileTask: API.OperationMethod<StartImportFileTaskRequest & RegionInput, StartImportFileTaskResponse, StartImportFileTaskError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationReportGenerationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts generating a recommendation report.
 */
export declare const startRecommendationReportGeneration: API.OperationMethod<StartRecommendationReportGenerationRequest & RegionInput, StartRecommendationReportGenerationResponse, StartRecommendationReportGenerationError, Credentials | HttpClient.HttpClient>;
export type StopAssessmentError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the assessment of an on-premises environment.
 */
export declare const stopAssessment: API.OperationMethod<StopAssessmentRequest & RegionInput, StopAssessmentResponse, StopAssessmentError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationComponentConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an application component.
 */
export declare const updateApplicationComponentConfig: API.OperationMethod<UpdateApplicationComponentConfigRequest & RegionInput, UpdateApplicationComponentConfigResponse, UpdateApplicationComponentConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateServerConfigError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of the specified server.
 */
export declare const updateServerConfig: API.OperationMethod<UpdateServerConfigRequest & RegionInput, UpdateServerConfigResponse, UpdateServerConfigError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migrationhubstrategy.d.ts.map