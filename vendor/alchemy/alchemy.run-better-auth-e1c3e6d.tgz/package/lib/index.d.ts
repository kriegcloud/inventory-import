export type { BetterAuthApi } from "./ApiProxy.ts";
export { BetterAuth, type AuthOptions, type BetterAuthInstance, type BetterAuthProps, type Session, } from "./BetterAuth.ts";
export { Database, type DatabaseInput, type DatabaseService, type DirectDatabase, type Provider, } from "./Database.ts";
export { BetterAuthApiError, BetterAuthMigrationError, BetterAuthStorageError, isAPIErrorLike, mergeAPIErrorHeaders, } from "./Errors.ts";
export { Memory } from "./Memory.ts";
export { SecondaryStorage, type SecondaryStorageService } from "./SecondaryStorage.ts";
//# sourceMappingURL=index.d.ts.map