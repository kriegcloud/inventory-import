/**
 * The private wire format a workflow step uses to carry a typed Effect
 * failure through the engine's native step retry/storage machinery, which
 * keeps only an `Error`'s message. Shared by every Workflows engine that
 * follows the Cloudflare Workflows API (Cloudflare today).
 *
 * @internal
 */
import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import * as Scope from "effect/Scope";
/** The workflow run a step failure belongs to. */
export interface WorkflowIdentity {
    readonly workflow: string;
    readonly instanceId: string;
}
/** Build the engine's non-retryable error for a terminal failure message. */
export type TerminalFailure = (message: string) => Promise<Error>;
/** The marked message of a terminal (non-retryable) step failure. */
export declare const terminalFailureMessage: (message: string) => string;
/**
 * Encode a step's failure cause into the engine's native error (and decode
 * it back on the run side), terminating with `terminalFailure` for defects,
 * interruptions and unserializable failures.
 */
export declare const makeWorkflowFailureCodec: (terminalFailure: TerminalFailure) => {
    callbackFailure: <E>(cause: Cause.Cause<E>, step: string, identity: WorkflowIdentity | undefined) => Promise<Error>;
    decodeApplicationFailure: <E>(error: unknown, step: string, identity: WorkflowIdentity | undefined) => Promise<Cause.Cause<E> | undefined>;
};
/**
 * Run one durable workflow task through the engine's native step API,
 * owning its native callbacks: a typed failure crosses the native step as
 * an encoded error and is decoded back into the task's failure channel;
 * interruption does not wait out native retry timers.
 */
export declare const runWorkflowTask: <A, E, C>(options: {
    readonly name: string;
    readonly identity?: WorkflowIdentity;
    readonly terminalFailure: TerminalFailure;
    /** The engine's own terminal errors, rethrown as-is. */
    readonly isNativeTerminal?: (error: unknown) => error is Error;
    readonly effect: (context: C) => Effect.Effect<A, E, Scope.Scope>;
    readonly native: (callback: (context: C) => Promise<A>, run: <B, F>(effect: Effect.Effect<B, F, Scope.Scope>) => Promise<B>) => Promise<A>;
}) => Effect.Effect<A, E>;
/** Close run resources with the original exit; cleanup cannot replace the result. */
export declare const withWorkflowScope: <A, E, R>(effect: Effect.Effect<A, E, R | Scope.Scope>, isEjected?: (scope: Scope.Scope) => boolean) => Effect.Effect<A, E, Exclude<R, Scope.Scope>>;
//# sourceMappingURL=WorkflowFailure.d.ts.map