import * as Effect from "effect/Effect";
import * as Rpc from "effect/rpc/Rpc";
import type * as RpcGroup from "effect/rpc/RpcGroup";
import * as Schema from "effect/Schema";
import type * as Stream from "effect/Stream";
import * as Aggregate from "./Aggregate.ts";
import type { Servable } from "./Api.ts";
import type * as Event from "./Event.ts";
import * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import * as View from "./View.ts";
/** Something an Api can expose for reading. */
export type Readable = View.Any | DomainStream.Any;
/** The name of a view, a stream, or an aggregate a view reads from. */
export declare const nameOf: (entry: Readable | Aggregate.Any) => string;
export declare const union: (members: ReadonlyArray<Schema.Top>) => Schema.Never | Schema.Union<readonly Schema.Top[]>;
/** The events a view emits: its declared events, or the events it applies. */
export declare const outputEvents: (view: View.Any) => ReadonlyArray<Event.Any>;
export interface ReadRpcs {
    /** `get` for views; `peek` for streams. */
    readonly get: Rpc.Any;
    readonly watch: Rpc.Any;
    readonly events: Rpc.Any;
    readonly list?: Rpc.Any;
    /** Views only: the state and the cursor it is valid at. */
    readonly snapshot?: Rpc.Any;
}
/** The read contract an entry's RPCs are built from. */
export declare const contractOf: (entry: Readable) => Read.AnyContract;
/** The RPCs of a view or stream exposed in an Api. */
export declare const readRpcs: (entry: Readable) => ReadRpcs;
/** One call an Api serves, as the HTTP, CLI and AI surfaces publish it. */
export interface Operation {
    /** The command, query, view or stream it belongs to. */
    readonly served: Servable;
    /** A command's tag, a query's name, or a view's, stream's or aggregate's name. */
    readonly name: string;
    /**
     * `send` for a command, `ask` for a query; the read's client method
     * otherwise (`get`, `peek`, `watch`, ...).
     */
    readonly operation: string;
    readonly rpc: Rpc.AnyWithProps;
    /** Whether the call answers with a stream of values (`watch`, `events`). */
    readonly stream: boolean;
    /**
     * The entry's `description` annotation, or for a command without one, its
     * Schema `description` annotation.
     */
    readonly description: string | undefined;
}
/** Every call an Api serves, in the order it serves them. */
export declare const operationsOf: (serves: ReadonlyArray<Servable>) => ReadonlyArray<Operation>;
/**
 * The name of one call of an Api's client: a command's tag (`DepositMoney`),
 * a query's name (`AccountLedger`), or a read as `<Name>.<operation>` (`AccountSummary.get`).
 */
export type CallName<Client> = {
    readonly [K in keyof Client & string]: Client[K] extends (...args: never) => unknown ? K : `${K}.${keyof Client[K] & string}`;
}[keyof Client & string];
/** The {@link CallName}s of the calls that return once: every call but `watch` and `events`. */
export type OnceCallName<Client> = {
    readonly [K in keyof Client & string]: Client[K] extends (...args: never) => unknown ? K : {
        readonly [O in keyof Client[K] & string]: Client[K][O] extends (...args: never) => Stream.Stream<unknown, unknown, unknown> ? never : `${K}.${O}`;
    }[keyof Client[K] & string];
}[keyof Client & string];
/** The client an Api's `clientInProcess` builds. */
export type ClientOf<A> = A extends {
    readonly clientInProcess: Effect.Effect<infer Client, any, any>;
} ? Client : never;
/** Whether the client calls it as a method of its own: a command's `send` or a query's `ask`. */
export declare const isMethod: (op: Operation) => boolean;
/** The {@link CallName} of an operation. */
export declare const callName: (op: Operation) => string;
/**
 * The operations a caller listed: nothing is exposed unless it is named.
 * An Api's calls stay private to its own clients until a surface opts in.
 */
export declare const exposedOf: (operations: ReadonlyArray<Operation>, expose: ReadonlyArray<string> | undefined) => ReadonlyArray<Operation>;
/**
 * An Api's in-process client for a caller from outside the app, such as an
 * HTTP request or an MCP client. It runs no middleware's client half (what
 * `RpcMiddleware.layerClient` provides): a credential the server holds for
 * its own calls must never replace the caller's headers.
 */
export declare const outsideClient: <A, R>(api: {
    readonly group: RpcGroup.RpcGroup<Rpc.Any>;
    readonly clientInProcess: Effect.Effect<A, never, R>;
}) => Effect.Effect<A, never, R>;
//# sourceMappingURL=ReadRpcs.d.ts.map