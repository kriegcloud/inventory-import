import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}>;
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ProductCode = string;
export type GetEntitlementFilterName = "CUSTOMER_IDENTIFIER" | "DIMENSION" | "CUSTOMER_AWS_ACCOUNT_ID" | "LICENSE_ARN" | (string & {});
export type FilterValue = string;
export type FilterValueList = string[];
export type GetEntitlementFilters = {
    [key in GetEntitlementFilterName]?: string[] | undefined;
};
export type NonEmptyString = string;
export type PageSizeInteger = number;
export interface GetEntitlementsRequest {
    ProductCode: string;
    Filter?: {
        [key: string]: string[] | undefined;
    } | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EntitlementValue {
    IntegerValue?: number | undefined;
    DoubleValue?: number | undefined;
    BooleanValue?: boolean | undefined;
    StringValue?: string | undefined;
}
export interface Entitlement {
    ProductCode?: string | undefined;
    Dimension?: string | undefined;
    CustomerIdentifier?: string | undefined;
    CustomerAWSAccountId?: string | undefined;
    Value?: EntitlementValue | undefined;
    ExpirationDate?: Date | undefined;
    LicenseArn?: string | undefined;
}
export type EntitlementList = Entitlement[];
export interface GetEntitlementsResult {
    Entitlements?: Entitlement[] | undefined;
    NextToken?: string | undefined;
}
export type ErrorMessage = string;
export type GetEntitlementsError = InternalServiceErrorException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * GetEntitlements retrieves entitlement values for a given product. The results can be
 * filtered based on customer identifier, AWS account ID, license ARN, or product dimensions.
 */
export declare const getEntitlements: API.PaginatedOperationMethod<GetEntitlementsRequest & RegionInput, GetEntitlementsResult, GetEntitlementsError, Credentials | HttpClient.HttpClient, unknown>;
export {};
//# sourceMappingURL=marketplace-entitlement-service.d.ts.map