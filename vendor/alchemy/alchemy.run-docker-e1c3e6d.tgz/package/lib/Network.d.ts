import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { Docker } from "./Docker.ts";
import type { Providers } from "./Providers.ts";
/** Address allocation settings for one Docker network subnet. */
export interface NetworkIpamConfig {
    /** IPv4 or IPv6 CIDR network prefix, without host bits. */
    subnet: string;
    /** Gateway address in the subnet's address family. Docker chooses one when omitted. */
    gateway?: string;
    /** CIDR sub-range from which Docker allocates container addresses. */
    ipRange?: string;
    /** Map of reservation names to IP addresses in the subnet's address family. */
    auxAddresses?: Record<string, string>;
}
/** Docker network IP Address Management (IPAM) configuration. */
export interface NetworkIpam {
    /** IPAM driver. @default "default" */
    driver?: string;
    /** IPAM driver-specific key/value options. */
    options?: Record<string, string>;
    /**
     * Subnet configurations. Docker allocates a subnet automatically when omitted;
     * drivers differ in how many explicit subnet entries they accept.
     */
    config?: NetworkIpamConfig[];
}
export interface NetworkProps {
    /**
     * Docker network name.
     *
     * @default Generated from stack, stage, logical id, and instance id.
     */
    name?: string;
    /** Network driver. @default "bridge" */
    driver?: "bridge" | "host" | "none" | "overlay" | "macvlan" | (string & {});
    /**
     * Restrict external connectivity through this network. Containers connected
     * to other networks can still have an external route.
     * @default false
     */
    internal?: boolean;
    /** Allow standalone containers to attach to an overlay network. @default false */
    attachable?: boolean;
    /** Enable IPv4 address allocation. Explicit `false` requires IPv6. @default true */
    enableIPv4?: boolean;
    /** Enable IPv6 on the network. @default false */
    enableIPv6?: boolean;
    /** Network-driver-specific key/value options, as passed to Docker `--opt`. */
    driverOpts?: Record<string, string>;
    /** Explicit IPAM configuration. Docker allocates missing subnet/gateway values. */
    ipam?: NetworkIpam;
    /** User labels. The `alchemy::*` prefix is reserved for resource ownership. */
    labels?: Record<string, string>;
    /**
     * The engine the network is created on: a Docker context name, a
     * `Docker.Context` resource, or a `Docker.Swarm` — overlay networks
     * require a swarm manager, and passing the swarm orders the network after
     * the swarm is initialized.
     */
    context?: Docker.EngineRef;
}
export interface Network extends Resource<"Docker.Network", NetworkProps, {
    /** Docker network ID. */
    id: string;
    /** Docker network name. */
    name: string;
    /** Network driver. */
    driver: string;
    /** Whether the network is isolated from external connectivity. */
    internal: boolean;
    /** Whether manual container attachment is allowed. */
    attachable: boolean;
    /** Whether IPv4 address allocation is enabled. */
    enableIPv4: boolean;
    /** Whether IPv6 is enabled. */
    enableIPv6: boolean;
    /** Driver options reported by Docker. */
    driverOpts: Record<string, string>;
    /** IPAM configuration reported by Docker (including automatically allocated values). */
    ipam: {
        driver: string;
        options: Record<string, string>;
        config: NetworkIpamConfig[];
    };
    /** Labels reported by Docker. */
    labels: Record<string, string>;
    /** Creation timestamp in milliseconds since epoch. */
    createdAt: number;
}, never, Providers, NetworkLookup> {
}
/**
 * Props for {@link Network.lookup}: find a network this stack
 * doesn't manage by its name.
 */
export interface NetworkLookup {
    /** Network name. */
    name: string;
    /**
     * Docker context the engine is reached through.
     * @default the current context
     */
    context?: string;
}
/**
 * A Docker network managed through the active Docker context.
 *
 * Existing same-name networks are treated as foreign unless the engine is
 * explicitly allowed to adopt them with `--adopt` or `adopt(true)`.
 *
 * ### Creating Networks
 * **Example:** Basic bridge network
 * ```typescript
 * const network = yield* Docker.Network("app-network", {
 *   name: "app-network",
 * });
 * ```
 *
 * ### Isolation and address allocation
 * **Example:** Internal bridge network with an explicit subnet and driver option
 * ```typescript
 * const network = yield* Docker.Network("private-network", {
 *   internal: true,
 *   attachable: true,
 *   enableIPv4: true,
 *   driverOpts: { "com.docker.network.driver.mtu": "1420" },
 *   ipam: {
 *     config: [{
 *       subnet: "10.50.0.0/24",
 *       gateway: "10.50.0.1",
 *       ipRange: "10.50.0.128/25",
 *       auxAddresses: { reserved: "10.50.0.5" },
 *     }],
 *   },
 * });
 * ```
 *
 * An internal network restricts external connectivity through that network;
 * additional container network attachments can still provide external routes.
 * If IPAM is omitted, Docker allocates a subnet and gateway. Alchemy does not
 * treat those automatically assigned values as configuration drift.
 * IPAM subnet and range values must be valid CIDR network prefixes (for
 * example, `10.50.0.0/24`, not `10.50.0.1/24`). Declared IPv4/IPv6 subnets
 * require the corresponding address family to be enabled. Alchemy validates
 * address containment and overlapping subnets before a destructive replacement,
 * and compares IPv6 addresses by their network value rather than text.
 * Invalid options fail with `InvalidNetworkOptions`, whose `path` identifies
 * the rejected field (for example, `ipam.config[0].gateway`).
 * Labels beginning with `alchemy::` are reserved for resource ownership and
 * cannot be overridden by user-supplied labels.
 *
 * ### IPv6-only networks
 * **Example:** Disable IPv4 address allocation
 * ```typescript
 * const network = yield* Docker.Network("ipv6-only", {
 *   enableIPv4: false,
 *   enableIPv6: true,
 * });
 * ```
 *
 * ### Dual-stack networks
 * **Example:** Allocate addresses from both families on a bridge network
 * ```typescript
 * const network = yield* Docker.Network("dual-stack", {
 *   enableIPv6: true,
 *   ipam: {
 *     config: [
 *       { subnet: "10.51.0.0/24", gateway: "10.51.0.1" },
 *       { subnet: "fd51:3456:789a::/64", gateway: "fd51:3456:789a::1" },
 *     ],
 *   },
 * });
 * ```
 *
 * ### Driver-specific IPAM options
 * **Example:** Pass IPAM driver-specific settings
 * ```typescript
 * const network = yield* Docker.Network("ipam-network", {
 *   ipam: {
 *     driver: "default",
 *     options: { "my-option": "my-value" },
 *   },
 * });
 * ```
 *
 * Network driver and IPAM driver options are passed to Docker without
 * interpreting driver-specific semantics.
 *
 * ### Adoption
 * **Example:** Adopt a pre-existing network
 * ```typescript
 * const network = yield* Docker.Network("app-network", {
 *   name: "shared-app-network",
 * }).pipe(adopt(true));
 * ```
 *
 * ### Looking up an existing network
 * `Network.lookup` references a network Alchemy doesn't manage (created with
 * the Docker CLI, Compose or another stack). It is read during plan/deploy,
 * never created, updated or removed.
 *
 * **Example:** Attach a container to an existing network
 * ```typescript
 * const shared = Docker.Network.lookup({ name: "compose_default" });
 * const api = yield* Docker.Container("Api", {
 *   image: "nginx:alpine",
 *   networks: [{ name: shared.name }],
 * });
 * ```
 *
 * ### Replacement
 * Network creation settings are immutable. Changing them replaces the network.
 * Docker refuses to delete a network while it has attached endpoints; Alchemy
 * does not forcibly disconnect unrelated containers to complete replacement.
 * A managed network deleted outside Alchemy is recreated on the next deploy.
 * If another network takes over its name, Alchemy refuses to claim it: the
 * recorded Docker ID must still match, even if the network's settings do.
 * Replacement is not transactional: a custom network or IPAM driver may reject
 * a configuration after Docker has already removed the old network. Alchemy
 * validates known IPAM constraints ahead of time, but the network driver
 * determines which settings take effect. Some drivers may accept options
 * without applying them; inspect the resulting network for advanced settings.
 *
 * @resource
 * @product Network
 */
export declare const Network: import("alchemy/Resource").ResourceClass<Network>;
export declare const NetworkProvider: () => import("effect/Layer").Layer<Provider.Provider<Network>, never, Docker | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
declare const InvalidNetworkOptions_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidNetworkOptions";
} & Readonly<A>;
/** Invalid user-supplied network settings, detected before Docker is called. */
export declare class InvalidNetworkOptions extends InvalidNetworkOptions_base<{
    /** Property path in the declared Docker.Network configuration. */
    readonly path: string;
    /** Human-readable reason for rejecting the network configuration. */
    readonly message: string;
}> {
}
export declare const toNetworkAttributes: (info: Docker.Network) => Network["Attributes"];
export {};
//# sourceMappingURL=Network.d.ts.map