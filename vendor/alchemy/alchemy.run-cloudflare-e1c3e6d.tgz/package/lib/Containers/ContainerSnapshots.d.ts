import * as Containers from "@distilled.cloud/cloudflare/containers";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
declare const ContainerSnapshotCleanupError_base: Schema.Class<ContainerSnapshotCleanupError, Schema.TaggedStruct<"ContainerSnapshotCleanupError", {
    readonly message: Schema.String;
    readonly cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class ContainerSnapshotCleanupError extends ContainerSnapshotCleanupError_base {
}
/** One tag of a container snapshot image in the account registry. */
export interface SnapshotImageTag {
    /** `<account>/cloudchamber-snapshots/<id>` */
    repository: string;
    tag: string;
}
/**
 * List the registry tags of every container snapshot taken by the given
 * Durable Objects.
 *
 * `ctx.container.snapshotContainer()` stores a snapshot in the account
 * registry under `<account>/cloudchamber-snapshots/<id>` as one manifest with
 * several tags (`rootfs-set-…`, `rootfs-snapshot-…`, `sha256:…`). The
 * manifest's `deployment_id` annotation is the id of the Durable Object that
 * took it.
 */
export declare const listSnapshotImages: (accountId: string, durableObjectIds: Iterable<string>) => Effect.Effect<SnapshotImageTag[], ContainerSnapshotCleanupError | Containers.CreateContainerRegistryCredentialsError, Containers.CloudflareOpContext>;
/** The ids of the Durable Objects a container application has assigned. */
export declare const listApplicationDurableObjects: (accountId: string, applicationId: string) => Effect.Effect<string[], Containers.ListContainerApplicationInstancesError, Containers.CloudflareOpContext>;
/**
 * Delete the registry images of every container snapshot an application's
 * Durable Objects took. Cloudflare keeps them after the application is
 * deleted.
 *
 * Deleting a tag removes only that tag, so every tag goes, digest tags last,
 * before layers are collected. A tag that is already gone is skipped, so an
 * interrupted delete finishes on the next run.
 */
export declare const deleteSnapshotImages: (accountId: string, applicationId: string) => Effect.Effect<void, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | Containers.ContainerApplicationNotFound | ContainerSnapshotCleanupError | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | Containers.InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, Containers.CloudflareOpContext>;
export {};
//# sourceMappingURL=ContainerSnapshots.d.ts.map