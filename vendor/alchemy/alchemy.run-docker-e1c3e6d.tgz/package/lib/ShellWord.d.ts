/**
 * Docker's word processing (BuildKit `frontend/dockerfile/shell/lex.go`),
 * without an environment: quotes and escapes are resolved and every variable
 * reference is kept as written (`$NAME`, `${NAME:-default}`), as BuildKit
 * does with `SkipUnsetEnv`. Expanding variables is left to the builder.
 */
import * as Result from "effect/Result";
declare const ShellWordError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ShellWordError";
} & Readonly<A>;
/** A word Docker cannot process: an unterminated quote or a bad `${…}`. */
export declare class ShellWordError extends ShellWordError_base<{
    readonly message: string;
}> {
}
export interface ShellWordOptions {
    readonly escape: string;
    /** Keep quote characters in the result. */
    readonly rawQuotes?: boolean;
    /** Keep escape characters in the result. */
    readonly rawEscapes?: boolean;
}
/** The word with quotes and escapes resolved. */
export declare const processWord: (word: string, options: ShellWordOptions) => Result.Result<string, ShellWordError>;
/** The input split into words, as a shell would. */
export declare const processWords: (input: string, options: ShellWordOptions) => Result.Result<string[], ShellWordError>;
export {};
//# sourceMappingURL=ShellWord.d.ts.map