import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import type * as DateTime from "effect/DateTime";
import type * as Aggregate from "../../Aggregate.ts";
import * as Decision from "../../Decision.ts";
/** One instance a decision read, and what the decision left of it. */
export interface Wrote {
    readonly aggregate: Aggregate.Any;
    readonly id: string;
    readonly stream: string;
    readonly before: unknown;
    readonly version: number;
    /** What the decision recorded on it: empty when it only read it. */
    readonly events: ReadonlyArray<{
        readonly _tag: string;
    }>;
    readonly after: unknown;
}
/** What the real `decide` of a decision does with a command, and the real `evolve` of each instance after it. */
export type Ran = {
    readonly _tag: "Accepted";
    /** Every event, in the order `decide` recorded them. */
    readonly events: ReadonlyArray<{
        readonly _tag: string;
    }>;
    /** Every instance read, each once. */
    readonly wrote: ReadonlyArray<Wrote>;
    /** For each name in `reads`: its instance's stream, or each of its instances'. */
    readonly streams: Readonly<Record<string, string | ReadonlyArray<string>>>;
} | {
    readonly _tag: "Rejected";
    readonly rejection: {
        readonly _tag: string;
    };
} | {
    readonly _tag: "Unpredictable";
    readonly cause: Cause.Cause<unknown>;
};
/** The state and version of each stream a decision may read: one left out is a new instance. */
export type States = ReadonlyMap<string, {
    readonly state: unknown;
    readonly version: number;
}>;
/**
 * Run a decision's own `decide`, and each instance's `evolve` on what it
 * records, without a platform: what the kernel does for the same states,
 * command and time.
 */
export declare const run: (decision: Decision.Any, command: {
    readonly _tag: string;
}, states: States, options: {
    readonly now: DateTime.Utc;
    readonly commandId: string;
    readonly context: Context.Context<never>;
}) => Ran;
/** A value for each name in `reads`, of its instance or of each of its instances. */
export declare const byName: <A>(streams: Readonly<Record<string, string | ReadonlyArray<string>>>, of: (stream: string) => A) => Readonly<Record<string, A | ReadonlyArray<A>>>;
//# sourceMappingURL=Decide.d.ts.map