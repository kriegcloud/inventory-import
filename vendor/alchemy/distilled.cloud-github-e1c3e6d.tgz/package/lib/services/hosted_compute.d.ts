import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The hosted compute service to use for the network configuration. */
export type CreateNetworkConfigurationForOrgRequestComputeService = "none" | "actions";
/** A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
export type CreateNetworkConfigurationForOrgRequestNetworkSettingsIdsList = Array<string>;
/** A list of identifiers of the failover network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
export type CreateNetworkConfigurationForOrgRequestFailoverNetworkSettingsIdsList = Array<string>;
export interface CreateNetworkConfigurationForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Name of the network configuration. Must be between 1 and 100 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'. */
    name: string;
    /** The hosted compute service to use for the network configuration. */
    compute_service?: CreateNetworkConfigurationForOrgRequestComputeService | (string & {}) | undefined;
    /** A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
    network_settings_ids: CreateNetworkConfigurationForOrgRequestNetworkSettingsIdsList;
    /** A list of identifiers of the failover network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
    failover_network_settings_ids?: CreateNetworkConfigurationForOrgRequestFailoverNetworkSettingsIdsList | undefined;
    /** Indicates whether the failover network resource is enabled. */
    failover_network_enabled?: boolean | undefined;
}
/** The hosted compute service the network configuration supports. */
export type NetworkConfigurationComputeService = "none" | "actions" | "codespaces";
/** The unique identifier of each network settings in the configuration. */
export type NetworkConfigurationNetworkSettingsIdsList = Array<string>;
/** The unique identifier of each failover network settings in the configuration. */
export type NetworkConfigurationFailoverNetworkSettingsIdsList = Array<string>;
/** A hosted compute network configuration. */
export interface NetworkConfiguration {
    /** The unique identifier of the network configuration. */
    id: string;
    /** The name of the network configuration. */
    name: string;
    /** The hosted compute service the network configuration supports. */
    compute_service?: NetworkConfigurationComputeService | undefined;
    /** The unique identifier of each network settings in the configuration. */
    network_settings_ids?: NetworkConfigurationNetworkSettingsIdsList | undefined;
    /** The unique identifier of each failover network settings in the configuration. */
    failover_network_settings_ids?: NetworkConfigurationFailoverNetworkSettingsIdsList | undefined;
    /** Indicates whether the failover network resource is enabled. */
    failover_network_enabled?: boolean | undefined;
    /** The time at which the network configuration was created, in ISO 8601 format. */
    created_on: string | null;
}
export interface DeleteNetworkConfigurationFromOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the hosted compute network configuration. */
    network_configuration_id: string;
}
export interface DeleteNetworkConfigurationFromOrgResponse {
}
export interface GetNetworkConfigurationForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the hosted compute network configuration. */
    network_configuration_id: string;
}
export interface GetNetworkSettingsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the hosted compute network settings. */
    network_settings_id: string;
}
/** A hosted compute network settings resource. */
export interface NetworkSettings {
    /** The unique identifier of the network settings resource. */
    id: string;
    /** The identifier of the network configuration that is using this settings resource. */
    network_configuration_id?: string | undefined;
    /** The name of the network settings resource. */
    name: string;
    /** The subnet this network settings resource is configured for. */
    subnet_id: string;
    /** The location of the subnet this network settings resource is configured for. */
    region: string;
}
export interface ListNetworkConfigurationsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListNetworkConfigurationsForOrgResponseNetworkConfigurationsList = Array<NetworkConfiguration>;
export interface ListNetworkConfigurationsForOrgResponse {
    total_count: number;
    network_configurations: ListNetworkConfigurationsForOrgResponseNetworkConfigurationsList;
}
/** The hosted compute service to use for the network configuration. */
export type UpdateNetworkConfigurationForOrgRequestComputeService = "none" | "actions";
/** A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
export type UpdateNetworkConfigurationForOrgRequestNetworkSettingsIdsList = Array<string>;
/** A list of identifiers of the failover network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
export type UpdateNetworkConfigurationForOrgRequestFailoverNetworkSettingsIdsList = Array<string>;
export interface UpdateNetworkConfigurationForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the hosted compute network configuration. */
    network_configuration_id: string;
    /** Name of the network configuration. Must be between 1 and 100 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'. */
    name?: string | undefined;
    /** The hosted compute service to use for the network configuration. */
    compute_service?: UpdateNetworkConfigurationForOrgRequestComputeService | (string & {}) | undefined;
    /** A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
    network_settings_ids?: UpdateNetworkConfigurationForOrgRequestNetworkSettingsIdsList | undefined;
    /** A list of identifiers of the failover network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list. */
    failover_network_settings_ids?: UpdateNetworkConfigurationForOrgRequestFailoverNetworkSettingsIdsList | undefined;
    /** Indicates whether the failover network resource is enabled. */
    failover_network_enabled?: boolean | undefined;
}
export type CreateNetworkConfigurationForOrgError = GithubOpError;
/** Create a hosted compute network configuration for an organization Creates a hosted compute network configuration for an organization. OAuth app tokens and personal access tokens (classic) need the `write:network_configurations` scope to use this endpoint. */
export declare const createNetworkConfigurationForOrg: API.OperationMethod<CreateNetworkConfigurationForOrgRequest, NetworkConfiguration, CreateNetworkConfigurationForOrgError, GithubOpContext>;
export type DeleteNetworkConfigurationFromOrgError = GithubOpError;
/** Delete a hosted compute network configuration from an organization Deletes a hosted compute network configuration from an organization. OAuth app tokens and personal access tokens (classic) need the `write:network_configurations` scope to use this endpoint. */
export declare const deleteNetworkConfigurationFromOrg: API.OperationMethod<DeleteNetworkConfigurationFromOrgRequest, DeleteNetworkConfigurationFromOrgResponse, DeleteNetworkConfigurationFromOrgError, GithubOpContext>;
export type GetNetworkConfigurationForOrgError = GithubOpError;
/** Get a hosted compute network configuration for an organization Gets a hosted compute network configuration configured in an organization. OAuth app tokens and personal access tokens (classic) need the `read:network_configurations` scope to use this endpoint. */
export declare const getNetworkConfigurationForOrg: API.OperationMethod<GetNetworkConfigurationForOrgRequest, NetworkConfiguration, GetNetworkConfigurationForOrgError, GithubOpContext>;
export type GetNetworkSettingsForOrgError = GithubOpError;
/** Get a hosted compute network settings resource for an organization Gets a hosted compute network settings resource configured for an organization. OAuth app tokens and personal access tokens (classic) need the `read:network_configurations` scope to use this endpoint. */
export declare const getNetworkSettingsForOrg: API.OperationMethod<GetNetworkSettingsForOrgRequest, NetworkSettings, GetNetworkSettingsForOrgError, GithubOpContext>;
export type ListNetworkConfigurationsForOrgError = GithubOpError;
/** List hosted compute network configurations for an organization Lists all hosted compute network configurations configured in an organization. OAuth app tokens and personal access tokens (classic) need the `read:network_configurations` scope to use this endpoint. */
export declare const listNetworkConfigurationsForOrg: API.PaginatedOperationMethod<ListNetworkConfigurationsForOrgRequest, ListNetworkConfigurationsForOrgResponse, ListNetworkConfigurationsForOrgError, GithubOpContext, NetworkConfiguration>;
export type UpdateNetworkConfigurationForOrgError = GithubOpError;
/** Update a hosted compute network configuration for an organization Updates a hosted compute network configuration for an organization. OAuth app tokens and personal access tokens (classic) need the `write:network_configurations` scope to use this endpoint. */
export declare const updateNetworkConfigurationForOrg: API.OperationMethod<UpdateNetworkConfigurationForOrgRequest, NetworkConfiguration, UpdateNetworkConfigurationForOrgError, GithubOpContext>;
//# sourceMappingURL=hosted_compute.d.ts.map