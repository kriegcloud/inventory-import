import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const CallRateLimitExceededException_base: S.TaggedErrorClass<"CallRateLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class CallRateLimitExceededException extends /*@__PURE__*/ CallRateLimitExceededException_base {
}
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const DryRunOperationException_base: S.TaggedErrorClass<"DryRunOperationException", {
    readonly message: any;
}>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidVersionNumberException_base: S.TaggedErrorClass<"InvalidVersionNumberException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVersionNumberException extends /*@__PURE__*/ InvalidVersionNumberException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceDependencyException_base: S.TaggedErrorClass<"ResourceDependencyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceDependencyException extends /*@__PURE__*/ ResourceDependencyException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type ImageBuildVersionArn = string;
export type ClientToken = string;
export interface CancelImageCreationRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export type NonEmptyString = string;
export interface CancelImageCreationResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export type LifecycleExecutionId = string;
export interface CancelLifecycleExecutionRequest {
    lifecycleExecutionId: string;
    clientToken: string;
}
export interface CancelLifecycleExecutionResponse {
    lifecycleExecutionId?: string | undefined;
}
export type ResourceName = string;
export type VersionNumber = string;
export type Platform = "Windows" | "Linux" | "macOS" | (string & {});
export type OsVersion = string;
export type OsVersionList = string[];
export type InlineComponentData = string;
export type Uri = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string | undefined;
    changeDescription?: string | undefined;
    platform: Platform;
    supportedOsVersions?: string[] | undefined;
    data?: string | undefined;
    uri?: string | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export type ComponentBuildVersionArn = string;
export type ImageBuilderArn = string;
export interface LatestVersionReferences {
    latestVersionArn?: string | undefined;
    latestMajorVersionArn?: string | undefined;
    latestMinorVersionArn?: string | undefined;
    latestPatchVersionArn?: string | undefined;
}
export interface CreateComponentResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    componentBuildVersionArn?: string | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export type ContainerType = "DOCKER" | (string & {});
export type WildcardVersionNumber = string;
export type ComponentVersionArnOrBuildVersionArn = string;
export type ComponentParameterName = string;
export type ComponentParameterValue = string;
export type ComponentParameterValueList = string[];
export interface ComponentParameter {
    name: string;
    value: string[];
}
export type ComponentParameterList = ComponentParameter[];
export interface ComponentConfiguration {
    componentArn: string;
    parameters?: ComponentParameter[] | undefined;
}
export type ComponentConfigurationList = ComponentConfiguration[];
export type EbsIopsInteger = number;
export type EbsVolumeSizeInteger = number;
export type EbsVolumeType = "standard" | "io1" | "io2" | "gp2" | "gp3" | "sc1" | "st1" | (string & {});
export type EbsVolumeThroughput = number;
export interface EbsInstanceBlockDeviceSpecification {
    encrypted?: boolean | undefined;
    deleteOnTermination?: boolean | undefined;
    iops?: number | undefined;
    kmsKeyId?: string | undefined;
    snapshotId?: string | undefined;
    volumeSize?: number | undefined;
    volumeType?: EbsVolumeType | undefined;
    throughput?: number | undefined;
}
export type EmptyString = string;
export interface InstanceBlockDeviceMapping {
    deviceName?: string | undefined;
    ebs?: EbsInstanceBlockDeviceSpecification | undefined;
    virtualName?: string | undefined;
    noDevice?: string | undefined;
}
export type InstanceBlockDeviceMappings = InstanceBlockDeviceMapping[];
export interface InstanceConfiguration {
    image?: string | undefined;
    blockDeviceMappings?: InstanceBlockDeviceMapping[] | undefined;
}
export type InlineDockerFileTemplate = string;
export type ContainerRepositoryService = "ECR" | (string & {});
export interface TargetContainerRepository {
    service: ContainerRepositoryService;
    repositoryName: string;
}
export interface CreateContainerRecipeRequest {
    containerType: ContainerType;
    name: string;
    description?: string | undefined;
    semanticVersion: string;
    components?: ComponentConfiguration[] | undefined;
    instanceConfiguration?: InstanceConfiguration | undefined;
    dockerfileTemplateData?: string | undefined;
    dockerfileTemplateUri?: string | undefined;
    platformOverride?: Platform | undefined;
    imageOsVersionOverride?: string | undefined;
    parentImage: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workingDirectory?: string | undefined;
    targetRepository: TargetContainerRepository;
    kmsKeyId?: string | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export type ContainerRecipeArn = string;
export interface CreateContainerRecipeResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    containerRecipeArn?: string | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export type AmiNameString = string;
export type AccountId = string;
export type AccountList = string[];
export type StringList = string[];
export type OrganizationArn = string;
export type OrganizationArnList = string[];
export type OrganizationalUnitArn = string;
export type OrganizationalUnitArnList = string[];
export interface LaunchPermissionConfiguration {
    userIds?: string[] | undefined;
    userGroups?: string[] | undefined;
    organizationArns?: string[] | undefined;
    organizationalUnitArns?: string[] | undefined;
}
export interface AmiDistributionConfiguration {
    name?: string | undefined;
    description?: string | undefined;
    targetAccountIds?: string[] | undefined;
    amiTags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyId?: string | undefined;
    launchPermission?: LaunchPermissionConfiguration | undefined;
}
export interface ContainerDistributionConfiguration {
    description?: string | undefined;
    containerTags?: string[] | undefined;
    targetRepository: TargetContainerRepository;
}
export type LicenseConfigurationArn = string;
export type LicenseConfigurationArnList = string[];
export type LaunchTemplateId = string;
export interface LaunchTemplateConfiguration {
    launchTemplateId: string;
    accountId?: string | undefined;
    setDefaultVersion?: boolean | undefined;
}
export type LaunchTemplateConfigurationList = LaunchTemplateConfiguration[];
export type DiskImageFormat = "VMDK" | "RAW" | "VHD" | (string & {});
export interface S3ExportConfiguration {
    roleName: string;
    diskImageFormat: DiskImageFormat;
    s3Bucket: string;
    s3Prefix?: string | undefined;
}
export type TargetResourceCount = number;
export interface FastLaunchSnapshotConfiguration {
    targetResourceCount?: number | undefined;
}
export type MaxParallelLaunches = number;
export interface FastLaunchLaunchTemplateSpecification {
    launchTemplateId?: string | undefined;
    launchTemplateName?: string | undefined;
    launchTemplateVersion?: string | undefined;
}
export interface FastLaunchConfiguration {
    enabled: boolean;
    snapshotConfiguration?: FastLaunchSnapshotConfiguration | undefined;
    maxParallelLaunches?: number | undefined;
    launchTemplate?: FastLaunchLaunchTemplateSpecification | undefined;
    accountId?: string | undefined;
}
export type FastLaunchConfigurationList = FastLaunchConfiguration[];
export type SsmParameterName = string;
export type SsmParameterDataType = "text" | "aws:ec2:image" | (string & {});
export interface SsmParameterConfiguration {
    amiAccountId?: string | undefined;
    parameterName: string;
    dataType?: SsmParameterDataType | undefined;
}
export type SsmParameterConfigurationList = SsmParameterConfiguration[];
export interface Distribution {
    region: string;
    amiDistributionConfiguration?: AmiDistributionConfiguration | undefined;
    containerDistributionConfiguration?: ContainerDistributionConfiguration | undefined;
    licenseConfigurationArns?: string[] | undefined;
    launchTemplateConfigurations?: LaunchTemplateConfiguration[] | undefined;
    s3ExportConfiguration?: S3ExportConfiguration | undefined;
    fastLaunchConfigurations?: FastLaunchConfiguration[] | undefined;
    ssmParameterConfigurations?: SsmParameterConfiguration[] | undefined;
}
export type DistributionList = Distribution[];
export interface CreateDistributionConfigurationRequest {
    name: string;
    description?: string | undefined;
    distributions: Distribution[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export type DistributionConfigurationArn = string;
export interface CreateDistributionConfigurationResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    distributionConfigurationArn?: string | undefined;
}
export type ImageRecipeArn = string;
export type InfrastructureConfigurationArn = string;
export type ImageTestsTimeoutMinutes = number;
export interface ImageTestsConfiguration {
    imageTestsEnabled?: boolean | undefined;
    timeoutMinutes?: number | undefined;
}
export interface EcrConfiguration {
    repositoryName?: string | undefined;
    containerTags?: string[] | undefined;
}
export type ImageScanningType = "TEST_INSTANCE_CVE" | "ON_DEMAND_AMI_CVE" | (string & {});
export type ImageScanningTypeList = ImageScanningType[];
export type MaximumSeverityLabel = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface ScanResultCondition {
    maximumSeverityLabel: MaximumSeverityLabel;
    fixAvailable?: boolean | undefined;
}
export interface ImageScanningConfiguration {
    imageScanningEnabled?: boolean | undefined;
    ecrConfiguration?: EcrConfiguration | undefined;
    imageScanningTypes?: ImageScanningType[] | undefined;
    scanResultCondition?: ScanResultCondition | undefined;
}
export type WorkflowVersionArnOrBuildVersionArn = string;
export type WorkflowParameterName = string;
export type WorkflowParameterValue = string;
export type WorkflowParameterValueList = string[];
export interface WorkflowParameter {
    name: string;
    value: string[];
}
export type WorkflowParameterList = WorkflowParameter[];
export type ParallelGroup = string;
export type OnWorkflowFailure = "CONTINUE" | "ABORT" | (string & {});
export interface WorkflowConfiguration {
    workflowArn: string;
    parameters?: WorkflowParameter[] | undefined;
    parallelGroup?: string | undefined;
    onFailure?: OnWorkflowFailure | undefined;
}
export type WorkflowConfigurationList = WorkflowConfiguration[];
export type RoleNameOrArn = string;
export type LogGroupName = string;
export interface ImageLoggingConfiguration {
    logGroupName?: string | undefined;
}
export interface CreateImageRequest {
    imageRecipeArn?: string | undefined;
    containerRecipeArn?: string | undefined;
    distributionConfigurationArn?: string | undefined;
    infrastructureConfigurationArn: string;
    imageTestsConfiguration?: ImageTestsConfiguration | undefined;
    enhancedImageMetadataEnabled?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    workflows?: WorkflowConfiguration[] | undefined;
    executionRole?: string | undefined;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
}
export interface CreateImageResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export type Timezone = string;
export type PipelineExecutionStartCondition = "EXPRESSION_MATCH_ONLY" | "EXPRESSION_MATCH_AND_DEPENDENCY_UPDATES_AVAILABLE" | (string & {});
export type AutoDisableFailureCount = number;
export interface AutoDisablePolicy {
    failureCount: number;
}
export interface Schedule {
    scheduleExpression?: string | undefined;
    timezone?: string | undefined;
    pipelineExecutionStartCondition?: PipelineExecutionStartCondition | undefined;
    autoDisablePolicy?: AutoDisablePolicy | undefined;
}
export type PipelineStatus = "DISABLED" | "ENABLED" | (string & {});
export interface PipelineLoggingConfiguration {
    imageLogGroupName?: string | undefined;
    pipelineLogGroupName?: string | undefined;
}
export interface CreateImagePipelineRequest {
    name: string;
    description?: string | undefined;
    imageRecipeArn?: string | undefined;
    containerRecipeArn?: string | undefined;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string | undefined;
    imageTestsConfiguration?: ImageTestsConfiguration | undefined;
    enhancedImageMetadataEnabled?: boolean | undefined;
    schedule?: Schedule | undefined;
    status?: PipelineStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    imageTags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    workflows?: WorkflowConfiguration[] | undefined;
    executionRole?: string | undefined;
    loggingConfiguration?: PipelineLoggingConfiguration | undefined;
    dryRun?: boolean | undefined;
}
export type ImagePipelineArn = string;
export interface CreateImagePipelineResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imagePipelineArn?: string | undefined;
}
export interface SystemsManagerAgent {
    uninstallAfterBuild?: boolean | undefined;
}
export type UserDataOverride = string;
export interface AdditionalInstanceConfiguration {
    systemsManagerAgent?: SystemsManagerAgent | undefined;
    userDataOverride?: string | undefined;
}
export type AmiWatermarkName = string;
export type AmiWatermarksList = string[];
export interface CreateImageRecipeRequest {
    name: string;
    description?: string | undefined;
    semanticVersion: string;
    components?: ComponentConfiguration[] | undefined;
    parentImage: string;
    blockDeviceMappings?: InstanceBlockDeviceMapping[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workingDirectory?: string | undefined;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration | undefined;
    amiTags?: {
        [key: string]: string | undefined;
    } | undefined;
    amiWatermarks?: string[] | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export interface CreateImageRecipeResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imageRecipeArn?: string | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export type InstanceType = string;
export type InstanceTypeList = string[];
export type InstanceProfileNameType = string;
export type SecurityGroupIds = string[];
export interface S3Logs {
    s3BucketName?: string | undefined;
    s3KeyPrefix?: string | undefined;
}
export interface Logging {
    s3Logs?: S3Logs | undefined;
}
export type SnsTopicArn = string;
export type ResourceTagMap = {
    [key: string]: string | undefined;
};
export type HttpTokens = string;
export type HttpPutResponseHopLimit = number;
export interface InstanceMetadataOptions {
    httpTokens?: string | undefined;
    httpPutResponseHopLimit?: number | undefined;
}
export type TenancyType = "default" | "dedicated" | "host" | (string & {});
export interface Placement {
    availabilityZone?: string | undefined;
    tenancy?: TenancyType | undefined;
    hostId?: string | undefined;
    hostResourceGroupArn?: string | undefined;
}
export type CapacityWaitTimeoutSeconds = number;
export interface AutoScalingGroupConfiguration {
    name: string;
    capacityWaitTimeoutSeconds?: number | undefined;
}
export interface ParentInstanceConfiguration {
    autoScalingGroup: AutoScalingGroupConfiguration;
}
export interface CreateInfrastructureConfigurationRequest {
    name: string;
    description?: string | undefined;
    instanceTypes?: string[] | undefined;
    instanceProfileName: string;
    securityGroupIds?: string[] | undefined;
    subnetId?: string | undefined;
    logging?: Logging | undefined;
    keyPair?: string | undefined;
    terminateInstanceOnFailure?: boolean | undefined;
    terminateInstanceOnCompletion?: boolean | undefined;
    snsTopicArn?: string | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    instanceMetadataOptions?: InstanceMetadataOptions | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    placement?: Placement | undefined;
    parentInstance?: ParentInstanceConfiguration | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export interface CreateInfrastructureConfigurationResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    infrastructureConfigurationArn?: string | undefined;
}
export type LifecyclePolicyStatus = "DISABLED" | "ENABLED" | (string & {});
export type LifecyclePolicyResourceType = "AMI_IMAGE" | "CONTAINER_IMAGE" | (string & {});
export type LifecyclePolicyDetailActionType = "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export interface LifecyclePolicyDetailActionIncludeResources {
    amis?: boolean | undefined;
    snapshots?: boolean | undefined;
    containers?: boolean | undefined;
}
export interface LifecyclePolicyDetailAction {
    type: LifecyclePolicyDetailActionType;
    includeResources?: LifecyclePolicyDetailActionIncludeResources | undefined;
}
export type LifecyclePolicyDetailFilterType = "AGE" | "COUNT" | (string & {});
export type LifecyclePolicyDetailFilterValue = number;
export type LifecyclePolicyTimeUnit = "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export type LifecyclePolicyDetailFilterRetainAtLeast = number;
export interface LifecyclePolicyDetailFilter {
    type: LifecyclePolicyDetailFilterType;
    value: number;
    unit?: LifecyclePolicyTimeUnit | undefined;
    retainAtLeast?: number | undefined;
}
export type LifecyclePolicyDetailExclusionRulesAmisLastLaunchedValue = number;
export interface LifecyclePolicyDetailExclusionRulesAmisLastLaunched {
    value: number;
    unit: LifecyclePolicyTimeUnit;
}
export interface LifecyclePolicyDetailExclusionRulesAmis {
    isPublic?: boolean | undefined;
    regions?: string[] | undefined;
    sharedAccounts?: string[] | undefined;
    lastLaunched?: LifecyclePolicyDetailExclusionRulesAmisLastLaunched | undefined;
    tagMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface LifecyclePolicyDetailExclusionRules {
    tagMap?: {
        [key: string]: string | undefined;
    } | undefined;
    amis?: LifecyclePolicyDetailExclusionRulesAmis | undefined;
}
export interface LifecyclePolicyDetail {
    action: LifecyclePolicyDetailAction;
    filter: LifecyclePolicyDetailFilter;
    exclusionRules?: LifecyclePolicyDetailExclusionRules | undefined;
}
export type LifecyclePolicyDetails = LifecyclePolicyDetail[];
export interface LifecyclePolicyResourceSelectionRecipe {
    name: string;
    semanticVersion: string;
}
export type LifecyclePolicyResourceSelectionRecipes = LifecyclePolicyResourceSelectionRecipe[];
export interface LifecyclePolicyResourceSelection {
    recipes?: LifecyclePolicyResourceSelectionRecipe[] | undefined;
    tagMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateLifecyclePolicyRequest {
    name: string;
    description?: string | undefined;
    status?: LifecyclePolicyStatus | undefined;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    dryRun?: boolean | undefined;
}
export type LifecyclePolicyArn = string;
export interface CreateLifecyclePolicyResponse {
    clientToken?: string | undefined;
    lifecyclePolicyArn?: string | undefined;
}
export type InlineWorkflowData = string;
export type WorkflowType = "BUILD" | "TEST" | "DISTRIBUTION" | (string & {});
export interface CreateWorkflowRequest {
    name: string;
    semanticVersion: string;
    description?: string | undefined;
    changeDescription?: string | undefined;
    data?: string | undefined;
    uri?: string | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    type: WorkflowType;
    dryRun?: boolean | undefined;
}
export type WorkflowBuildVersionArn = string;
export interface CreateWorkflowResponse {
    clientToken?: string | undefined;
    workflowBuildVersionArn?: string | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface DeleteComponentRequest {
    componentBuildVersionArn: string;
}
export interface DeleteComponentResponse {
    requestId?: string | undefined;
    componentBuildVersionArn?: string | undefined;
}
export interface DeleteContainerRecipeRequest {
    containerRecipeArn: string;
}
export interface DeleteContainerRecipeResponse {
    requestId?: string | undefined;
    containerRecipeArn?: string | undefined;
}
export interface DeleteDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export interface DeleteDistributionConfigurationResponse {
    requestId?: string | undefined;
    distributionConfigurationArn?: string | undefined;
}
export interface DeleteImageRequest {
    imageBuildVersionArn: string;
}
export interface DeleteImageResponse {
    requestId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export interface DeleteImagePipelineRequest {
    imagePipelineArn: string;
}
export interface DeleteImagePipelineResponse {
    requestId?: string | undefined;
    imagePipelineArn?: string | undefined;
}
export interface DeleteImageRecipeRequest {
    imageRecipeArn: string;
}
export interface DeleteImageRecipeResponse {
    requestId?: string | undefined;
    imageRecipeArn?: string | undefined;
}
export interface DeleteInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export interface DeleteInfrastructureConfigurationResponse {
    requestId?: string | undefined;
    infrastructureConfigurationArn?: string | undefined;
}
export interface DeleteLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export interface DeleteLifecyclePolicyResponse {
    lifecyclePolicyArn?: string | undefined;
}
export interface DeleteWorkflowRequest {
    workflowBuildVersionArn: string;
}
export interface DeleteWorkflowResponse {
    workflowBuildVersionArn?: string | undefined;
}
export interface DistributeImageRequest {
    sourceImage: string;
    distributionConfigurationArn: string;
    executionRole: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
}
export interface DistributeImageResponse {
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export interface GetComponentRequest {
    componentBuildVersionArn: string;
}
export type ComponentType = "BUILD" | "TEST" | (string & {});
export type ComponentStatus = "DEPRECATED" | "DISABLED" | "ACTIVE" | (string & {});
export interface ComponentState {
    status?: ComponentStatus | undefined;
    reason?: string | undefined;
}
export type ComponentParameterType = string;
export type ComponentParameterDescription = string;
export interface ComponentParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[] | undefined;
    description?: string | undefined;
}
export type ComponentParameterDetailList = ComponentParameterDetail[];
export type ComponentData = string;
export type ProductCodeId = string;
export type ProductCodeType = "marketplace" | (string & {});
export interface ProductCodeListItem {
    productCodeId: string;
    productCodeType: ProductCodeType;
}
export type ProductCodeList = ProductCodeListItem[];
export interface Component {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    description?: string | undefined;
    changeDescription?: string | undefined;
    type?: ComponentType | undefined;
    platform?: Platform | undefined;
    supportedOsVersions?: string[] | undefined;
    state?: ComponentState | undefined;
    parameters?: ComponentParameterDetail[] | undefined;
    owner?: string | undefined;
    data?: string | undefined;
    kmsKeyId?: string | undefined;
    encrypted?: boolean | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    publisher?: string | undefined;
    obfuscate?: boolean | undefined;
    productCodes?: ProductCodeListItem[] | undefined;
}
export interface GetComponentResponse {
    requestId?: string | undefined;
    component?: Component | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface GetComponentPolicyRequest {
    componentArn: string;
}
export type ResourcePolicyDocument = string;
export interface GetComponentPolicyResponse {
    requestId?: string | undefined;
    policy?: string | undefined;
}
export interface GetContainerRecipeRequest {
    containerRecipeArn: string;
}
export type DockerFileTemplate = string;
export interface ContainerRecipe {
    arn?: string | undefined;
    containerType?: ContainerType | undefined;
    name?: string | undefined;
    description?: string | undefined;
    platform?: Platform | undefined;
    owner?: string | undefined;
    version?: string | undefined;
    components?: ComponentConfiguration[] | undefined;
    instanceConfiguration?: InstanceConfiguration | undefined;
    dockerfileTemplateData?: string | undefined;
    kmsKeyId?: string | undefined;
    encrypted?: boolean | undefined;
    parentImage?: string | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workingDirectory?: string | undefined;
    targetRepository?: TargetContainerRepository | undefined;
}
export interface GetContainerRecipeResponse {
    requestId?: string | undefined;
    containerRecipe?: ContainerRecipe | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface GetContainerRecipePolicyRequest {
    containerRecipeArn: string;
}
export interface GetContainerRecipePolicyResponse {
    requestId?: string | undefined;
    policy?: string | undefined;
}
export interface GetDistributionConfigurationRequest {
    distributionConfigurationArn: string;
}
export type DistributionTimeoutMinutes = number;
export interface DistributionConfiguration {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    distributions?: Distribution[] | undefined;
    timeoutMinutes?: number | undefined;
    dateCreated?: string | undefined;
    dateUpdated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDistributionConfigurationResponse {
    requestId?: string | undefined;
    distributionConfiguration?: DistributionConfiguration | undefined;
}
export type ImageVersionArnOrBuildVersionArn = string;
export interface GetImageRequest {
    imageBuildVersionArn: string;
}
export type ImageType = "AMI" | "DOCKER" | (string & {});
export type VersionNumberWithBuild = string;
export type ImageStatus = "PENDING" | "CREATING" | "BUILDING" | "TESTING" | "DISTRIBUTING" | "INTEGRATING" | "AVAILABLE" | "CANCELLED" | "FAILED" | "DEPRECATED" | "DELETED" | "DISABLED" | (string & {});
export type WorkflowExecutionId = string;
export type WorkflowStepExecutionId = string;
export type WorkflowStepName = string;
export type NonEmptyMaxLengthString = string;
export interface ComponentFailureContext {
    componentArn?: string | undefined;
    phaseName?: string | undefined;
    stepName?: string | undefined;
    action?: string | undefined;
    errorMessage?: string | undefined;
}
export type RegionFailureStatus = "FAILED" | "CANCELLED" | "TIMED_OUT" | (string & {});
export type ImageConfigurationStep = "ASSOCIATE_LICENSES" | "UPDATE_LAUNCH_TEMPLATES" | "PUT_SSM_PARAMETERS" | "UPDATE_FAST_LAUNCH_CONFIGURATIONS" | "EXPORT_AMI" | (string & {});
export interface RegionFailure {
    region?: string | undefined;
    status?: RegionFailureStatus | undefined;
    imageConfigurationStep?: ImageConfigurationStep | undefined;
    errorMessage?: string | undefined;
    targetAccountId?: string | undefined;
}
export type RegionFailureList = RegionFailure[];
export interface DistributionFailureContext {
    errorMessage?: string | undefined;
    regionFailures?: RegionFailure[] | undefined;
}
export interface ImageFailureContext {
    imageStatus?: ImageStatus | undefined;
    workflowExecutionId?: string | undefined;
    workflowArn?: string | undefined;
    stepExecutionId?: string | undefined;
    failedStep?: string | undefined;
    componentFailure?: ComponentFailureContext | undefined;
    distributionFailure?: DistributionFailureContext | undefined;
}
export interface ImageState {
    status?: ImageStatus | undefined;
    reason?: string | undefined;
    failureContext?: ImageFailureContext | undefined;
}
export interface ImageRecipe {
    arn?: string | undefined;
    type?: ImageType | undefined;
    name?: string | undefined;
    description?: string | undefined;
    platform?: Platform | undefined;
    owner?: string | undefined;
    version?: string | undefined;
    components?: ComponentConfiguration[] | undefined;
    parentImage?: string | undefined;
    blockDeviceMappings?: InstanceBlockDeviceMapping[] | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workingDirectory?: string | undefined;
    additionalInstanceConfiguration?: AdditionalInstanceConfiguration | undefined;
    amiTags?: {
        [key: string]: string | undefined;
    } | undefined;
    amiWatermarks?: string[] | undefined;
}
export type Arn = string;
export interface InfrastructureConfiguration {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    instanceTypes?: string[] | undefined;
    instanceProfileName?: string | undefined;
    securityGroupIds?: string[] | undefined;
    subnetId?: string | undefined;
    logging?: Logging | undefined;
    keyPair?: string | undefined;
    terminateInstanceOnFailure?: boolean | undefined;
    snsTopicArn?: string | undefined;
    dateCreated?: string | undefined;
    dateUpdated?: string | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    instanceMetadataOptions?: InstanceMetadataOptions | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    placement?: Placement | undefined;
    terminateInstanceOnCompletion?: boolean | undefined;
    parentInstance?: ParentInstanceConfiguration | undefined;
}
export interface Ami {
    region?: string | undefined;
    image?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    state?: ImageState | undefined;
    accountId?: string | undefined;
}
export type AmiList = Ami[];
export interface Container {
    region?: string | undefined;
    imageUris?: string[] | undefined;
}
export type ContainerList = Container[];
export interface OutputResources {
    amis?: Ami[] | undefined;
    containers?: Container[] | undefined;
}
export type BuildType = "USER_INITIATED" | "SCHEDULED" | "IMPORT" | "IMPORT_ISO" | (string & {});
export type ImageSource = "AMAZON_MANAGED" | "AWS_MARKETPLACE" | "IMPORTED" | "CUSTOM" | (string & {});
export type ImageScanStatus = "PENDING" | "SCANNING" | "COLLECTING" | "COMPLETED" | "ABANDONED" | "FAILED" | "TIMED_OUT" | (string & {});
export interface ImageScanState {
    status?: ImageScanStatus | undefined;
    reason?: string | undefined;
}
export type DateTimeTimestamp = Date;
export interface Image {
    arn?: string | undefined;
    type?: ImageType | undefined;
    name?: string | undefined;
    version?: string | undefined;
    platform?: Platform | undefined;
    enhancedImageMetadataEnabled?: boolean | undefined;
    osVersion?: string | undefined;
    state?: ImageState | undefined;
    imageRecipe?: ImageRecipe | undefined;
    containerRecipe?: ContainerRecipe | undefined;
    sourcePipelineName?: string | undefined;
    sourcePipelineArn?: string | undefined;
    infrastructureConfiguration?: InfrastructureConfiguration | undefined;
    distributionConfiguration?: DistributionConfiguration | undefined;
    imageTestsConfiguration?: ImageTestsConfiguration | undefined;
    dateCreated?: string | undefined;
    outputResources?: OutputResources | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    buildType?: BuildType | undefined;
    imageSource?: ImageSource | undefined;
    scanState?: ImageScanState | undefined;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    deprecationTime?: Date | undefined;
    lifecycleExecutionId?: string | undefined;
    executionRole?: string | undefined;
    workflows?: WorkflowConfiguration[] | undefined;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
}
export interface GetImageResponse {
    requestId?: string | undefined;
    image?: Image | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface GetImagePipelineRequest {
    imagePipelineArn: string;
}
export type ConsecutiveFailures = number;
export interface ImagePipeline {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    platform?: Platform | undefined;
    enhancedImageMetadataEnabled?: boolean | undefined;
    imageRecipeArn?: string | undefined;
    containerRecipeArn?: string | undefined;
    infrastructureConfigurationArn?: string | undefined;
    distributionConfigurationArn?: string | undefined;
    imageTestsConfiguration?: ImageTestsConfiguration | undefined;
    schedule?: Schedule | undefined;
    status?: PipelineStatus | undefined;
    dateCreated?: string | undefined;
    dateUpdated?: string | undefined;
    dateLastRun?: string | undefined;
    lastRunStatus?: ImageStatus | undefined;
    dateNextRun?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    imageTags?: {
        [key: string]: string | undefined;
    } | undefined;
    executionRole?: string | undefined;
    workflows?: WorkflowConfiguration[] | undefined;
    loggingConfiguration?: PipelineLoggingConfiguration | undefined;
    consecutiveFailures?: number | undefined;
}
export interface GetImagePipelineResponse {
    requestId?: string | undefined;
    imagePipeline?: ImagePipeline | undefined;
}
export interface GetImagePolicyRequest {
    imageArn: string;
}
export interface GetImagePolicyResponse {
    requestId?: string | undefined;
    policy?: string | undefined;
}
export interface GetImageRecipeRequest {
    imageRecipeArn: string;
}
export interface GetImageRecipeResponse {
    requestId?: string | undefined;
    imageRecipe?: ImageRecipe | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface GetImageRecipePolicyRequest {
    imageRecipeArn: string;
}
export interface GetImageRecipePolicyResponse {
    requestId?: string | undefined;
    policy?: string | undefined;
}
export interface GetInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
}
export interface GetInfrastructureConfigurationResponse {
    requestId?: string | undefined;
    infrastructureConfiguration?: InfrastructureConfiguration | undefined;
}
export interface GetLifecycleExecutionRequest {
    lifecycleExecutionId: string;
}
export interface LifecycleExecutionResourcesImpactedSummary {
    hasImpactedResources?: boolean | undefined;
}
export type LifecycleExecutionStatus = "IN_PROGRESS" | "CANCELLED" | "CANCELLING" | "FAILED" | "SUCCESS" | "PENDING" | (string & {});
export interface LifecycleExecutionState {
    status?: LifecycleExecutionStatus | undefined;
    reason?: string | undefined;
}
export interface LifecycleExecution {
    lifecycleExecutionId?: string | undefined;
    lifecyclePolicyArn?: string | undefined;
    resourcesImpactedSummary?: LifecycleExecutionResourcesImpactedSummary | undefined;
    state?: LifecycleExecutionState | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface GetLifecycleExecutionResponse {
    lifecycleExecution?: LifecycleExecution | undefined;
}
export interface GetLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
}
export interface LifecyclePolicy {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: LifecyclePolicyStatus | undefined;
    executionRole?: string | undefined;
    resourceType?: LifecyclePolicyResourceType | undefined;
    policyDetails?: LifecyclePolicyDetail[] | undefined;
    resourceSelection?: LifecyclePolicyResourceSelection | undefined;
    dateCreated?: Date | undefined;
    dateUpdated?: Date | undefined;
    dateLastRun?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetLifecyclePolicyResponse {
    lifecyclePolicy?: LifecyclePolicy | undefined;
}
export type MarketplaceResourceType = "COMPONENT_DATA" | "COMPONENT_ARTIFACT" | (string & {});
export type MarketplaceResourceLocation = string;
export interface GetMarketplaceResourceRequest {
    resourceType: MarketplaceResourceType;
    resourceArn: string;
    resourceLocation?: string | undefined;
}
export interface GetMarketplaceResourceResponse {
    resourceArn?: string | undefined;
    url?: string | undefined;
    data?: string | undefined;
}
export interface GetWorkflowRequest {
    workflowBuildVersionArn: string;
}
export type WorkflowStatus = "DEPRECATED" | (string & {});
export interface WorkflowState {
    status?: WorkflowStatus | undefined;
    reason?: string | undefined;
}
export type WorkflowData = string;
export type WorkflowParameterType = string;
export type WorkflowParameterDescription = string;
export interface WorkflowParameterDetail {
    name: string;
    type: string;
    defaultValue?: string[] | undefined;
    description?: string | undefined;
}
export type WorkflowParameterDetailList = WorkflowParameterDetail[];
export interface Workflow {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    description?: string | undefined;
    changeDescription?: string | undefined;
    type?: WorkflowType | undefined;
    state?: WorkflowState | undefined;
    owner?: string | undefined;
    data?: string | undefined;
    kmsKeyId?: string | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    parameters?: WorkflowParameterDetail[] | undefined;
}
export interface GetWorkflowResponse {
    workflow?: Workflow | undefined;
    latestVersionReferences?: LatestVersionReferences | undefined;
}
export interface GetWorkflowExecutionRequest {
    workflowExecutionId: string;
}
export type WorkflowExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETED" | "CANCELLED" | (string & {});
export type WorkflowExecutionMessage = string;
export type WorkflowStepCount = number;
export interface GetWorkflowExecutionResponse {
    requestId?: string | undefined;
    workflowBuildVersionArn?: string | undefined;
    workflowExecutionId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    type?: WorkflowType | undefined;
    status?: WorkflowExecutionStatus | undefined;
    message?: string | undefined;
    totalStepCount?: number | undefined;
    totalStepsSucceeded?: number | undefined;
    totalStepsFailed?: number | undefined;
    totalStepsSkipped?: number | undefined;
    startTime?: string | undefined;
    endTime?: string | undefined;
    parallelGroup?: string | undefined;
}
export interface GetWorkflowStepExecutionRequest {
    stepExecutionId: string;
}
export type WorkflowStepDescription = string;
export type WorkflowStepAction = string;
export type WorkflowStepExecutionStatus = "PENDING" | "SKIPPED" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export type WorkflowStepExecutionRollbackStatus = "RUNNING" | "COMPLETED" | "SKIPPED" | "FAILED" | (string & {});
export type WorkflowStepMessage = string;
export type WorkflowStepInputs = string;
export type WorkflowStepOutputs = string;
export type WorkflowStepTimeoutSecondsInteger = number;
export type WorkflowStepAttemptCount = number;
export interface GetWorkflowStepExecutionResponse {
    requestId?: string | undefined;
    stepExecutionId?: string | undefined;
    workflowBuildVersionArn?: string | undefined;
    workflowExecutionId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    action?: string | undefined;
    status?: WorkflowStepExecutionStatus | undefined;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus | undefined;
    message?: string | undefined;
    inputs?: string | undefined;
    outputs?: string | undefined;
    startTime?: string | undefined;
    endTime?: string | undefined;
    onFailure?: string | undefined;
    timeoutSeconds?: number | undefined;
    attemptNumber?: number | undefined;
    maxAttempts?: number | undefined;
}
export type ComponentFormat = "SHELL" | (string & {});
export interface ImportComponentRequest {
    name: string;
    semanticVersion: string;
    description?: string | undefined;
    changeDescription?: string | undefined;
    type: ComponentType;
    format: ComponentFormat;
    platform: Platform;
    data?: string | undefined;
    uri?: string | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
}
export interface ImportComponentResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    componentBuildVersionArn?: string | undefined;
}
export type UefiData = string;
export interface RegisterImageOptions {
    secureBootEnabled?: boolean | undefined;
    uefiData?: string | undefined;
}
export type WindowsConfigurationImageIndex = number;
export interface WindowsConfiguration {
    imageIndex: number;
}
export interface ImportDiskImageRequest {
    name: string;
    semanticVersion: string;
    description?: string | undefined;
    platform: string;
    osVersion: string;
    executionRole?: string | undefined;
    infrastructureConfigurationArn: string;
    uri: string;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    registerImageOptions?: RegisterImageOptions | undefined;
    windowsConfiguration?: WindowsConfiguration | undefined;
    clientToken: string;
}
export interface ImportDiskImageResponse {
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export interface ImportVmImageRequest {
    name: string;
    semanticVersion: string;
    description?: string | undefined;
    platform: Platform;
    osVersion?: string | undefined;
    vmImportTaskId: string;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
}
export interface ImportVmImageResponse {
    requestId?: string | undefined;
    imageArn?: string | undefined;
    clientToken?: string | undefined;
}
export type ComponentVersionArn = string;
export type RestrictedInteger = number;
export type PaginationToken = string;
export interface ListComponentBuildVersionsRequest {
    componentVersionArn?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ComponentSummary {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    platform?: Platform | undefined;
    supportedOsVersions?: string[] | undefined;
    state?: ComponentState | undefined;
    type?: ComponentType | undefined;
    owner?: string | undefined;
    description?: string | undefined;
    changeDescription?: string | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    publisher?: string | undefined;
    obfuscate?: boolean | undefined;
}
export type ComponentSummaryList = ComponentSummary[];
export interface ListComponentBuildVersionsResponse {
    requestId?: string | undefined;
    componentSummaryList?: ComponentSummary[] | undefined;
    nextToken?: string | undefined;
}
export type Ownership = "Self" | "Shared" | "Amazon" | "ThirdParty" | "AWSMarketplace" | (string & {});
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    name?: string | undefined;
    values?: string[] | undefined;
}
export type FilterList = Filter[];
export interface ListComponentsRequest {
    owner?: Ownership | undefined;
    filters?: Filter[] | undefined;
    byName?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ComponentVersion {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    description?: string | undefined;
    platform?: Platform | undefined;
    supportedOsVersions?: string[] | undefined;
    type?: ComponentType | undefined;
    owner?: string | undefined;
    dateCreated?: string | undefined;
    status?: ComponentStatus | undefined;
    productCodes?: ProductCodeListItem[] | undefined;
}
export type ComponentVersionList = ComponentVersion[];
export interface ListComponentsResponse {
    requestId?: string | undefined;
    componentVersionList?: ComponentVersion[] | undefined;
    nextToken?: string | undefined;
}
export interface ListContainerRecipesRequest {
    owner?: Ownership | undefined;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ContainerRecipeSummary {
    arn?: string | undefined;
    containerType?: ContainerType | undefined;
    name?: string | undefined;
    platform?: Platform | undefined;
    owner?: string | undefined;
    parentImage?: string | undefined;
    dateCreated?: string | undefined;
    instanceImage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ContainerRecipeSummaryList = ContainerRecipeSummary[];
export interface ListContainerRecipesResponse {
    requestId?: string | undefined;
    containerRecipeSummaryList?: ContainerRecipeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDistributionConfigurationsRequest {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type RegionList = string[];
export interface DistributionConfigurationSummary {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    dateCreated?: string | undefined;
    dateUpdated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    regions?: string[] | undefined;
}
export type DistributionConfigurationSummaryList = DistributionConfigurationSummary[];
export interface ListDistributionConfigurationsResponse {
    requestId?: string | undefined;
    distributionConfigurationSummaryList?: DistributionConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ImageVersionArn = string;
export interface ListImageBuildVersionsRequest {
    imageVersionArn?: string | undefined;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ImageSummary {
    arn?: string | undefined;
    name?: string | undefined;
    type?: ImageType | undefined;
    version?: string | undefined;
    platform?: Platform | undefined;
    osVersion?: string | undefined;
    state?: ImageState | undefined;
    owner?: string | undefined;
    dateCreated?: string | undefined;
    outputResources?: OutputResources | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    buildType?: BuildType | undefined;
    imageSource?: ImageSource | undefined;
    deprecationTime?: Date | undefined;
    lifecycleExecutionId?: string | undefined;
    loggingConfiguration?: ImageLoggingConfiguration | undefined;
}
export type ImageSummaryList = ImageSummary[];
export interface ListImageBuildVersionsResponse {
    requestId?: string | undefined;
    imageSummaryList?: ImageSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImagePackagesRequest {
    imageBuildVersionArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ImagePackage {
    packageName?: string | undefined;
    packageVersion?: string | undefined;
}
export type ImagePackageList = ImagePackage[];
export interface ListImagePackagesResponse {
    requestId?: string | undefined;
    imagePackageList?: ImagePackage[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImagePipelineImagesRequest {
    imagePipelineArn: string;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListImagePipelineImagesResponse {
    requestId?: string | undefined;
    imageSummaryList?: ImageSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImagePipelinesRequest {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ImagePipelineList = ImagePipeline[];
export interface ListImagePipelinesResponse {
    requestId?: string | undefined;
    imagePipelineList?: ImagePipeline[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImageRecipesRequest {
    owner?: Ownership | undefined;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ImageRecipeSummary {
    arn?: string | undefined;
    name?: string | undefined;
    platform?: Platform | undefined;
    owner?: string | undefined;
    parentImage?: string | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ImageRecipeSummaryList = ImageRecipeSummary[];
export interface ListImageRecipesResponse {
    requestId?: string | undefined;
    imageRecipeSummaryList?: ImageRecipeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImagesRequest {
    owner?: Ownership | undefined;
    filters?: Filter[] | undefined;
    byName?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    includeDeprecated?: boolean | undefined;
}
export interface ImageVersion {
    arn?: string | undefined;
    name?: string | undefined;
    type?: ImageType | undefined;
    version?: string | undefined;
    platform?: Platform | undefined;
    osVersion?: string | undefined;
    owner?: string | undefined;
    dateCreated?: string | undefined;
    buildType?: BuildType | undefined;
    imageSource?: ImageSource | undefined;
}
export type ImageVersionList = ImageVersion[];
export interface ListImagesResponse {
    requestId?: string | undefined;
    imageVersionList?: ImageVersion[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImageScanFindingAggregationsRequest {
    filter?: Filter | undefined;
    nextToken?: string | undefined;
}
export type SeverityCountNumber = number;
export interface SeverityCounts {
    all?: number | undefined;
    critical?: number | undefined;
    high?: number | undefined;
    medium?: number | undefined;
}
export interface AccountAggregation {
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface ImageAggregation {
    imageBuildVersionArn?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface ImagePipelineAggregation {
    imagePipelineArn?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface VulnerabilityIdAggregation {
    vulnerabilityId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface ImageScanFindingAggregation {
    accountAggregation?: AccountAggregation | undefined;
    imageAggregation?: ImageAggregation | undefined;
    imagePipelineAggregation?: ImagePipelineAggregation | undefined;
    vulnerabilityIdAggregation?: VulnerabilityIdAggregation | undefined;
}
export type ImageScanFindingAggregationsList = ImageScanFindingAggregation[];
export interface ListImageScanFindingAggregationsResponse {
    requestId?: string | undefined;
    aggregationType?: string | undefined;
    responses?: ImageScanFindingAggregation[] | undefined;
    nextToken?: string | undefined;
}
export type ImageScanFindingsFilterValues = string[];
export interface ImageScanFindingsFilter {
    name?: string | undefined;
    values?: string[] | undefined;
}
export type ImageScanFindingsFilterList = ImageScanFindingsFilter[];
export interface ListImageScanFindingsRequest {
    filters?: ImageScanFindingsFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RemediationRecommendation {
    text?: string | undefined;
    url?: string | undefined;
}
export interface Remediation {
    recommendation?: RemediationRecommendation | undefined;
}
export type NonNegativeDouble = number;
export interface CvssScoreAdjustment {
    metric?: string | undefined;
    reason?: string | undefined;
}
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export interface CvssScoreDetails {
    scoreSource?: string | undefined;
    cvssSource?: string | undefined;
    version?: string | undefined;
    score?: number | undefined;
    scoringVector?: string | undefined;
    adjustments?: CvssScoreAdjustment[] | undefined;
}
export interface InspectorScoreDetails {
    adjustedCvss?: CvssScoreDetails | undefined;
}
export type VulnerabilityId = string;
export type SourceLayerHash = string;
export type PackageEpoch = number;
export type PackageArchitecture = string;
export interface VulnerablePackage {
    name?: string | undefined;
    version?: string | undefined;
    sourceLayerHash?: string | undefined;
    epoch?: number | undefined;
    release?: string | undefined;
    arch?: string | undefined;
    packageManager?: string | undefined;
    filePath?: string | undefined;
    fixedInVersion?: string | undefined;
    remediation?: string | undefined;
}
export type VulnerablePackageList = VulnerablePackage[];
export interface CvssScore {
    baseScore?: number | undefined;
    scoringVector?: string | undefined;
    version?: string | undefined;
    source?: string | undefined;
}
export type CvssScoreList = CvssScore[];
export type VulnerabilityIdList = string[];
export type NonEmptyStringList = string[];
export interface PackageVulnerabilityDetails {
    vulnerabilityId: string;
    vulnerablePackages?: VulnerablePackage[] | undefined;
    source?: string | undefined;
    cvss?: CvssScore[] | undefined;
    relatedVulnerabilities?: string[] | undefined;
    sourceUrl?: string | undefined;
    vendorSeverity?: string | undefined;
    vendorCreatedAt?: Date | undefined;
    vendorUpdatedAt?: Date | undefined;
    referenceUrls?: string[] | undefined;
}
export interface ImageScanFinding {
    awsAccountId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    imagePipelineArn?: string | undefined;
    type?: string | undefined;
    description?: string | undefined;
    title?: string | undefined;
    remediation?: Remediation | undefined;
    severity?: string | undefined;
    firstObservedAt?: Date | undefined;
    updatedAt?: Date | undefined;
    inspectorScore?: number | undefined;
    inspectorScoreDetails?: InspectorScoreDetails | undefined;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails | undefined;
    fixAvailable?: string | undefined;
}
export type ImageScanFindingsList = ImageScanFinding[];
export interface ListImageScanFindingsResponse {
    requestId?: string | undefined;
    findings?: ImageScanFinding[] | undefined;
    nextToken?: string | undefined;
}
export interface ListInfrastructureConfigurationsRequest {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface InfrastructureConfigurationSummary {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    dateCreated?: string | undefined;
    dateUpdated?: string | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    instanceTypes?: string[] | undefined;
    instanceProfileName?: string | undefined;
    placement?: Placement | undefined;
}
export type InfrastructureConfigurationSummaryList = InfrastructureConfigurationSummary[];
export interface ListInfrastructureConfigurationsResponse {
    requestId?: string | undefined;
    infrastructureConfigurationSummaryList?: InfrastructureConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListLifecycleExecutionResourcesRequest {
    lifecycleExecutionId: string;
    parentResourceId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type LifecycleExecutionResourceStatus = "FAILED" | "IN_PROGRESS" | "SKIPPED" | "SUCCESS" | (string & {});
export interface LifecycleExecutionResourceState {
    status?: LifecycleExecutionResourceStatus | undefined;
    reason?: string | undefined;
}
export type LifecycleExecutionResourceActionName = "AVAILABLE" | "DELETE" | "DEPRECATE" | "DISABLE" | (string & {});
export interface LifecycleExecutionResourceAction {
    name?: LifecycleExecutionResourceActionName | undefined;
    reason?: string | undefined;
}
export interface LifecycleExecutionSnapshotResource {
    snapshotId?: string | undefined;
    state?: LifecycleExecutionResourceState | undefined;
}
export type LifecycleExecutionSnapshotResourceList = LifecycleExecutionSnapshotResource[];
export interface LifecycleExecutionResource {
    accountId?: string | undefined;
    resourceId?: string | undefined;
    state?: LifecycleExecutionResourceState | undefined;
    action?: LifecycleExecutionResourceAction | undefined;
    region?: string | undefined;
    snapshots?: LifecycleExecutionSnapshotResource[] | undefined;
    imageUris?: string[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type LifecycleExecutionResourceList = LifecycleExecutionResource[];
export interface ListLifecycleExecutionResourcesResponse {
    lifecycleExecutionId?: string | undefined;
    lifecycleExecutionState?: LifecycleExecutionState | undefined;
    resources?: LifecycleExecutionResource[] | undefined;
    nextToken?: string | undefined;
}
export interface ListLifecycleExecutionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    resourceArn: string;
}
export type LifecycleExecutionsList = LifecycleExecution[];
export interface ListLifecycleExecutionsResponse {
    lifecycleExecutions?: LifecycleExecution[] | undefined;
    nextToken?: string | undefined;
}
export interface ListLifecyclePoliciesRequest {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface LifecyclePolicySummary {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: LifecyclePolicyStatus | undefined;
    executionRole?: string | undefined;
    resourceType?: LifecyclePolicyResourceType | undefined;
    dateCreated?: Date | undefined;
    dateUpdated?: Date | undefined;
    dateLastRun?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type LifecyclePolicySummaryList = LifecyclePolicySummary[];
export interface ListLifecyclePoliciesResponse {
    lifecyclePolicySummaryList?: LifecyclePolicySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListWaitingWorkflowStepsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkflowStepExecution {
    stepExecutionId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    workflowExecutionId?: string | undefined;
    workflowBuildVersionArn?: string | undefined;
    name?: string | undefined;
    action?: string | undefined;
    startTime?: string | undefined;
}
export type WorkflowStepExecutionList = WorkflowStepExecution[];
export interface ListWaitingWorkflowStepsResponse {
    steps?: WorkflowStepExecution[] | undefined;
    nextToken?: string | undefined;
}
export type WorkflowWildcardVersionArn = string;
export interface ListWorkflowBuildVersionsRequest {
    workflowVersionArn?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkflowSummary {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    description?: string | undefined;
    changeDescription?: string | undefined;
    type?: WorkflowType | undefined;
    owner?: string | undefined;
    state?: WorkflowState | undefined;
    dateCreated?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkflowSummaryList = WorkflowSummary[];
export interface ListWorkflowBuildVersionsResponse {
    workflowSummaryList?: WorkflowSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkflowExecutionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    imageBuildVersionArn: string;
}
export interface WorkflowExecutionMetadata {
    workflowBuildVersionArn?: string | undefined;
    workflowExecutionId?: string | undefined;
    type?: WorkflowType | undefined;
    status?: WorkflowExecutionStatus | undefined;
    message?: string | undefined;
    totalStepCount?: number | undefined;
    totalStepsSucceeded?: number | undefined;
    totalStepsFailed?: number | undefined;
    totalStepsSkipped?: number | undefined;
    startTime?: string | undefined;
    endTime?: string | undefined;
    parallelGroup?: string | undefined;
    retried?: boolean | undefined;
}
export type WorkflowExecutionsList = WorkflowExecutionMetadata[];
export type ImageBuildMessage = string;
export interface ListWorkflowExecutionsResponse {
    requestId?: string | undefined;
    workflowExecutions?: WorkflowExecutionMetadata[] | undefined;
    imageBuildVersionArn?: string | undefined;
    message?: string | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkflowsRequest {
    owner?: Ownership | undefined;
    filters?: Filter[] | undefined;
    byName?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkflowVersion {
    arn?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    description?: string | undefined;
    type?: WorkflowType | undefined;
    owner?: string | undefined;
    dateCreated?: string | undefined;
}
export type WorkflowVersionList = WorkflowVersion[];
export interface ListWorkflowsResponse {
    workflowVersionList?: WorkflowVersion[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkflowStepExecutionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    workflowExecutionId: string;
}
export interface WorkflowStepMetadata {
    stepExecutionId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    action?: string | undefined;
    status?: WorkflowStepExecutionStatus | undefined;
    rollbackStatus?: WorkflowStepExecutionRollbackStatus | undefined;
    message?: string | undefined;
    inputs?: string | undefined;
    outputs?: string | undefined;
    startTime?: string | undefined;
    endTime?: string | undefined;
    attemptNumber?: number | undefined;
    maxAttempts?: number | undefined;
}
export type WorkflowStepExecutionsList = WorkflowStepMetadata[];
export interface ListWorkflowStepExecutionsResponse {
    requestId?: string | undefined;
    steps?: WorkflowStepMetadata[] | undefined;
    workflowBuildVersionArn?: string | undefined;
    workflowExecutionId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    message?: string | undefined;
    nextToken?: string | undefined;
}
export interface PutComponentPolicyRequest {
    componentArn: string;
    policy: string;
}
export interface PutComponentPolicyResponse {
    requestId?: string | undefined;
    componentArn?: string | undefined;
}
export interface PutContainerRecipePolicyRequest {
    containerRecipeArn: string;
    policy: string;
}
export interface PutContainerRecipePolicyResponse {
    requestId?: string | undefined;
    containerRecipeArn?: string | undefined;
}
export interface PutImagePolicyRequest {
    imageArn: string;
    policy: string;
}
export interface PutImagePolicyResponse {
    requestId?: string | undefined;
    imageArn?: string | undefined;
}
export interface PutImageRecipePolicyRequest {
    imageRecipeArn: string;
    policy: string;
}
export interface PutImageRecipePolicyResponse {
    requestId?: string | undefined;
    imageRecipeArn?: string | undefined;
}
export interface RetryImageRequest {
    imageBuildVersionArn: string;
    clientToken: string;
}
export interface RetryImageResponse {
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export type WorkflowStepActionType = "RESUME" | "STOP" | (string & {});
export interface SendWorkflowStepActionRequest {
    stepExecutionId: string;
    imageBuildVersionArn: string;
    action: WorkflowStepActionType;
    reason?: string | undefined;
    clientToken: string;
}
export interface SendWorkflowStepActionResponse {
    stepExecutionId?: string | undefined;
    imageBuildVersionArn?: string | undefined;
    clientToken?: string | undefined;
}
export interface StartImagePipelineExecutionRequest {
    imagePipelineArn: string;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartImagePipelineExecutionResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imageBuildVersionArn?: string | undefined;
}
export type ResourceStatus = "AVAILABLE" | "DELETED" | "DEPRECATED" | "DISABLED" | (string & {});
export interface ResourceState {
    status?: ResourceStatus | undefined;
}
export interface ResourceStateUpdateIncludeResources {
    amis?: boolean | undefined;
    snapshots?: boolean | undefined;
    containers?: boolean | undefined;
}
export interface ResourceStateUpdateExclusionRules {
    amis?: LifecyclePolicyDetailExclusionRulesAmis | undefined;
}
export interface StartResourceStateUpdateRequest {
    resourceArn: string;
    state: ResourceState;
    executionRole?: string | undefined;
    includeResources?: ResourceStateUpdateIncludeResources | undefined;
    exclusionRules?: ResourceStateUpdateExclusionRules | undefined;
    updateAt?: Date | undefined;
    clientToken: string;
}
export interface StartResourceStateUpdateResponse {
    lifecycleExecutionId?: string | undefined;
    resourceArn?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDistributionConfigurationRequest {
    distributionConfigurationArn: string;
    description?: string | undefined;
    distributions: Distribution[];
    clientToken: string;
}
export interface UpdateDistributionConfigurationResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    distributionConfigurationArn?: string | undefined;
}
export interface UpdateImagePipelineRequest {
    imagePipelineArn: string;
    description?: string | undefined;
    imageRecipeArn?: string | undefined;
    containerRecipeArn?: string | undefined;
    infrastructureConfigurationArn: string;
    distributionConfigurationArn?: string | undefined;
    imageTestsConfiguration?: ImageTestsConfiguration | undefined;
    enhancedImageMetadataEnabled?: boolean | undefined;
    schedule?: Schedule | undefined;
    status?: PipelineStatus | undefined;
    clientToken: string;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    workflows?: WorkflowConfiguration[] | undefined;
    loggingConfiguration?: PipelineLoggingConfiguration | undefined;
    executionRole?: string | undefined;
    imageTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateImagePipelineResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    imagePipelineArn?: string | undefined;
}
export interface UpdateInfrastructureConfigurationRequest {
    infrastructureConfigurationArn: string;
    description?: string | undefined;
    instanceTypes?: string[] | undefined;
    instanceProfileName: string;
    securityGroupIds?: string[] | undefined;
    subnetId?: string | undefined;
    logging?: Logging | undefined;
    keyPair?: string | undefined;
    terminateInstanceOnFailure?: boolean | undefined;
    terminateInstanceOnCompletion?: boolean | undefined;
    snsTopicArn?: string | undefined;
    resourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    instanceMetadataOptions?: InstanceMetadataOptions | undefined;
    placement?: Placement | undefined;
    parentInstance?: ParentInstanceConfiguration | undefined;
    clientToken: string;
}
export interface UpdateInfrastructureConfigurationResponse {
    requestId?: string | undefined;
    clientToken?: string | undefined;
    infrastructureConfigurationArn?: string | undefined;
}
export interface UpdateLifecyclePolicyRequest {
    lifecyclePolicyArn: string;
    description?: string | undefined;
    status?: LifecyclePolicyStatus | undefined;
    executionRole: string;
    resourceType: LifecyclePolicyResourceType;
    policyDetails: LifecyclePolicyDetail[];
    resourceSelection: LifecyclePolicyResourceSelection;
    clientToken: string;
}
export interface UpdateLifecyclePolicyResponse {
    lifecyclePolicyArn?: string | undefined;
}
export type ErrorMessage = string;
export type CancelImageCreationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels the creation of an image. This operation can only be used on
 * images in a non-terminal state. Cancellation is asynchronous: the request
 * returns immediately, then Image Builder stops the running build and moves the image
 * to the `CANCELLED` state. Output resources that the build already
 * created, such as AMIs and snapshots, aren't removed.
 */
export declare const cancelImageCreation: API.OperationMethod<CancelImageCreationRequest & RegionInput, CancelImageCreationResponse, CancelImageCreationError, Credentials | HttpClient.HttpClient>;
export type CancelLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Cancels a lifecycle execution - a single run of lifecycle actions that a
 * lifecycle policy or a StartResourceStateUpdate request
 * started. You can only cancel an execution that hasn't reached a
 * terminal state. Cancellation is asynchronous and doesn't undo
 * completed lifecycle actions.
 */
export declare const cancelLifecycleExecution: API.OperationMethod<CancelLifecycleExecutionRequest & RegionInput, CancelLifecycleExecutionResponse, CancelLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateComponentError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new component that can be used to build, validate, test, and assess your
 * image. The component is based on a YAML document that you specify using exactly one of
 * the following methods:
 *
 * - Inline, using the `data` property in the request body.
 *
 * - A URL that points to a YAML document file stored in Amazon S3, using the
 * `uri` property in the request body.
 *
 * Image Builder determines the component type from the document. If the document
 * contains a single phase named `test`, the component type is
 * `TEST`. Otherwise, the component type is `BUILD`.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest & RegionInput, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateContainerRecipeError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new container recipe. Container recipes define how images are configured,
 * tested, and assessed.
 */
export declare const createContainerRecipe: API.OperationMethod<CreateContainerRecipeRequest & RegionInput, CreateContainerRecipeResponse, CreateContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionConfigurationError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new distribution configuration. Distribution configurations define
 * and configure the outputs for your images, including the target Regions,
 * accounts, and settings for each Region.
 */
export declare const createDistributionConfiguration: API.OperationMethod<CreateDistributionConfigurationRequest & RegionInput, CreateDistributionConfigurationResponse, CreateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image along with all configured output resources defined in the
 * distribution configuration. You must specify exactly one recipe for your image, using
 * either a `containerRecipeArn` or an `imageRecipeArn`.
 *
 * The response returns as soon as Image Builder creates the new image resource.
 * The image build process runs asynchronously. To check its progress, call
 * GetImage and check the image status.
 */
export declare const createImage: API.OperationMethod<CreateImageRequest & RegionInput, CreateImageResponse, CreateImageError, Credentials | HttpClient.HttpClient>;
export type CreateImagePipelineError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image pipeline. Use image pipelines to automate the creation and
 * distribution of images. You must specify exactly one recipe for the pipeline,
 * using either a `containerRecipeArn` or an
 * `imageRecipeArn`.
 */
export declare const createImagePipeline: API.OperationMethod<CreateImagePipelineRequest & RegionInput, CreateImagePipelineResponse, CreateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type CreateImageRecipeError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | InvalidVersionNumberException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new image recipe. Image recipes define how images are configured, tested,
 * and assessed.
 */
export declare const createImageRecipe: API.OperationMethod<CreateImageRecipeRequest & RegionInput, CreateImageRecipeResponse, CreateImageRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | InvalidParameterValueException | CommonErrors;
/**
 * Creates a new infrastructure configuration. An infrastructure configuration defines
 * the environment in which your image will be built and tested.
 */
export declare const createInfrastructureConfiguration: API.OperationMethod<CreateInfrastructureConfigurationRequest & RegionInput, CreateInfrastructureConfigurationResponse, CreateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateLifecyclePolicyError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceAlreadyExistsException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a lifecycle policy resource.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest & RegionInput, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = CallRateLimitExceededException | ClientException | DryRunOperationException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a new workflow or a new version of an existing workflow. If a workflow
 * with the same name and semantic version already exists, and your request changes
 * its configuration, Image Builder creates a new build version.
 * If the configuration is identical to the latest build version, the request
 * fails because that workflow configuration already exists.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest & RegionInput, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a component build version. The request fails with
 * `ResourceDependencyException` if an image recipe or container
 * recipe references this component version. It also fails if the component
 * build version is shared with other accounts.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest & RegionInput, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a container recipe. The request fails with
 * `ResourceDependencyException` if the recipe is shared with other
 * accounts, or if an image pipeline references it.
 */
export declare const deleteContainerRecipe: API.OperationMethod<DeleteContainerRecipeRequest & RegionInput, DeleteContainerRecipeResponse, DeleteContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a distribution configuration. You can't delete a configuration
 * that an image pipeline still references. The request fails with
 * `ResourceDependencyException`. Update or delete the referencing
 * pipelines first.
 */
export declare const deleteDistributionConfiguration: API.OperationMethod<DeleteDistributionConfigurationRequest & RegionInput, DeleteDistributionConfigurationResponse, DeleteDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Image Builder image resource. This does not delete any EC2 AMIs or ECR container
 * images that are created during the image build process. You must clean those up
 * separately, using the appropriate Amazon EC2 or Amazon ECR console actions, or API or CLI
 * commands.
 *
 * The request fails with `ResourceDependencyException` if the image
 * is shared with other accounts, or if other resources depend on it. It also
 * fails while the image build is still running. Cancel an in-progress build
 * with CancelImageCreation before you delete the image.
 *
 * - To deregister an EC2 Linux AMI, see Deregister your
 * Linux AMI in the
 * *Amazon EC2 User Guide*
 * .
 *
 * - To deregister an EC2 Windows AMI, see Deregister your
 * Windows AMI in the
 * *Amazon EC2 Windows Guide*
 * .
 *
 * - To delete a container image from Amazon ECR, see Deleting
 * an image in the *Amazon ECR User Guide*.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest & RegionInput, DeleteImageResponse, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image pipeline. Images that the pipeline created aren't
 * deleted - remove those separately with DeleteImage. You
 * can delete a pipeline while a build that it started is still running. The
 * build continues independently.
 */
export declare const deleteImagePipeline: API.OperationMethod<DeleteImagePipelineRequest & RegionInput, DeleteImagePipelineResponse, DeleteImagePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an image recipe.
 */
export declare const deleteImageRecipe: API.OperationMethod<DeleteImageRecipeRequest & RegionInput, DeleteImageRecipeResponse, DeleteImageRecipeError, Credentials | HttpClient.HttpClient>;
export type DeleteInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an infrastructure configuration. You can't delete a configuration
 * that an image pipeline still references. The request fails with
 * `ResourceDependencyException`. Update or delete the referencing
 * pipelines first.
 */
export declare const deleteInfrastructureConfiguration: API.OperationMethod<DeleteInfrastructureConfigurationRequest & RegionInput, DeleteInfrastructureConfigurationResponse, DeleteInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified lifecycle policy resource. Deleting the policy removes
 * its schedule, so no further lifecycle runs occur for that policy. If a
 * lifecycle execution is in progress for the policy, Image Builder cancels it. Deletion
 * doesn't revert actions that the policy already applied to your
 * resources.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest & RegionInput, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ResourceDependencyException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a specific workflow resource. You can't delete a workflow build
 * version while an image pipeline references it. The request fails with
 * `ResourceDependencyException`.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest & RegionInput, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DistributeImageError = AccessDeniedException | CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Distributes an existing AMI to target Regions and accounts without running
 * the full image build process. This operation only runs the distribution
 * phase on an image that has already been built.
 */
export declare const distributeImage: API.OperationMethod<DistributeImageRequest & RegionInput, DistributeImageResponse, DistributeImageError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a component object.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest & RegionInput, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetComponentPolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a component policy.
 */
export declare const getComponentPolicy: API.OperationMethod<GetComponentPolicyRequest & RegionInput, GetComponentPolicyResponse, GetComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a container recipe.
 */
export declare const getContainerRecipe: API.OperationMethod<GetContainerRecipeRequest & RegionInput, GetContainerRecipeResponse, GetContainerRecipeError, Credentials | HttpClient.HttpClient>;
export type GetContainerRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the policy for a container recipe.
 */
export declare const getContainerRecipePolicy: API.OperationMethod<GetContainerRecipePolicyRequest & RegionInput, GetContainerRecipePolicyResponse, GetContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a distribution configuration.
 */
export declare const getDistributionConfiguration: API.OperationMethod<GetDistributionConfigurationRequest & RegionInput, GetDistributionConfigurationResponse, GetDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetImageError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image.
 */
export declare const getImage: API.OperationMethod<GetImageRequest & RegionInput, GetImageResponse, GetImageError, Credentials | HttpClient.HttpClient>;
export type GetImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image pipeline.
 */
export declare const getImagePipeline: API.OperationMethod<GetImagePipelineRequest & RegionInput, GetImagePipelineResponse, GetImagePipelineError, Credentials | HttpClient.HttpClient>;
export type GetImagePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves an image policy.
 */
export declare const getImagePolicy: API.OperationMethod<GetImagePolicyRequest & RegionInput, GetImagePolicyResponse, GetImagePolicyError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipeError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an image recipe.
 */
export declare const getImageRecipe: API.OperationMethod<GetImageRecipeRequest & RegionInput, GetImageRecipeResponse, GetImageRecipeError, Credentials | HttpClient.HttpClient>;
export type GetImageRecipePolicyError = CallRateLimitExceededException | ForbiddenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves an image recipe policy.
 */
export declare const getImageRecipePolicy: API.OperationMethod<GetImageRecipePolicyRequest & RegionInput, GetImageRecipePolicyResponse, GetImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type GetInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an infrastructure configuration.
 */
export declare const getInfrastructureConfiguration: API.OperationMethod<GetInfrastructureConfigurationRequest & RegionInput, GetInfrastructureConfigurationResponse, GetInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetLifecycleExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a lifecycle execution - a single run of
 * lifecycle actions that a lifecycle policy or a
 * StartResourceStateUpdate request started.
 */
export declare const getLifecycleExecution: API.OperationMethod<GetLifecycleExecutionRequest & RegionInput, GetLifecycleExecutionResponse, GetLifecycleExecutionError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves details for the specified image lifecycle policy.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest & RegionInput, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetMarketplaceResourceError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Verifies the subscription and performs resource dependency checks on the
 * requested Amazon Web Services Marketplace resource. The caller must be entitled to the resource. For
 * Amazon Web Services Marketplace components, the response contains fields to download the components
 * and their artifacts.
 */
export declare const getMarketplaceResource: API.OperationMethod<GetMarketplaceResourceRequest & RegionInput, GetMarketplaceResourceResponse, GetMarketplaceResourceError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a workflow resource object.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest & RegionInput, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a specific runtime instance
 * of the workflow.
 */
export declare const getWorkflowExecution: API.OperationMethod<GetWorkflowExecutionRequest & RegionInput, GetWorkflowExecutionResponse, GetWorkflowExecutionError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves runtime information for a specific runtime instance of
 * the workflow step.
 */
export declare const getWorkflowStepExecution: API.OperationMethod<GetWorkflowStepExecutionRequest & RegionInput, GetWorkflowStepExecutionResponse, GetWorkflowStepExecutionError, Credentials | HttpClient.HttpClient>;
export type ImportComponentError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | InvalidVersionNumberException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Imports a component and transforms its data into a component document. For
 * the `SHELL` format, Image Builder wraps your script in a component
 * document with a single step that runs the script.
 */
export declare const importComponent: API.OperationMethod<ImportComponentRequest & RegionInput, ImportComponentResponse, ImportComponentError, Credentials | HttpClient.HttpClient>;
export type ImportDiskImageError = AccessDeniedException | ClientException | ServiceException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Imports a Windows operating system image from a verified Microsoft ISO disk
 * file. The following disk images are supported:
 *
 * - Windows 11 Enterprise
 *
 * The response returns as soon as Image Builder creates the new image resource in the
 * `PENDING` state. The conversion from ISO file to AMI then runs
 * asynchronously on an EC2 instance that Image Builder launches with the specified
 * infrastructure configuration.
 */
export declare const importDiskImage: API.OperationMethod<ImportDiskImageRequest & RegionInput, ImportDiskImageResponse, ImportDiskImageError, Credentials | HttpClient.HttpClient>;
export type ImportVmImageError = ClientException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an Image Builder image resource from an Amazon EC2 VM import task. The response
 * returns as soon as Image Builder creates the image resource in the
 * `PENDING` state. Image Builder then monitors the import task
 * asynchronously. When the task completes, Image Builder records the AMI that it
 * produced as the new image's output resource and marks the image
 * `AVAILABLE`. You can then use the imported image as the base
 * image for your recipes.
 *
 * To create the VM import task, use the Amazon EC2 API ImportImage
 * operation, or the import-image
 * CLI command.
 */
export declare const importVmImage: API.OperationMethod<ImportVmImageRequest & RegionInput, ImportVmImageResponse, ImportVmImageError, Credentials | HttpClient.HttpClient>;
export type ListComponentBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of component build versions for the specified component
 * version ARN. You can only list build versions for components that your
 * account owns. Deprecated build versions aren't included in the
 * results.
 */
export declare const listComponentBuildVersions: API.PaginatedOperationMethod<ListComponentBuildVersionsRequest & RegionInput, ListComponentBuildVersionsResponse, ListComponentBuildVersionsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListComponentsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of components that you have access to. By default, the
 * response doesn't include components in the
 * `DEPRECATED` state. To list deprecated components, use the
 * `status` filter with the value `DEPRECATED`.
 *
 * The semantic version has four nodes: ../.
 * You can assign values for the first three, and can filter on all of them.
 *
 * **Filtering:** You can use wildcards (x) to specify the most recent versions or nodes when
 * selecting the base image or components for your recipe. When you use a wildcard in any node, all nodes
 * to the right of the first wildcard must also be wildcards.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest & RegionInput, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentVersion>;
export type ListContainerRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of container recipes.
 */
export declare const listContainerRecipes: API.PaginatedOperationMethod<ListContainerRecipesRequest & RegionInput, ListContainerRecipesResponse, ListContainerRecipesError, Credentials | HttpClient.HttpClient, ContainerRecipeSummary>;
export type ListDistributionConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of distribution configurations.
 */
export declare const listDistributionConfigurations: API.PaginatedOperationMethod<ListDistributionConfigurationsRequest & RegionInput, ListDistributionConfigurationsResponse, ListDistributionConfigurationsError, Credentials | HttpClient.HttpClient, DistributionConfigurationSummary>;
export type ListImageBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image build versions.
 */
export declare const listImageBuildVersions: API.PaginatedOperationMethod<ListImageBuildVersionsRequest & RegionInput, ListImageBuildVersionsResponse, ListImageBuildVersionsError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePackagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the packages that are associated with an image build version, as determined by
 * Amazon Web Services Systems Manager Inventory at build time.
 */
export declare const listImagePackages: API.PaginatedOperationMethod<ListImagePackagesRequest & RegionInput, ListImagePackagesResponse, ListImagePackagesError, Credentials | HttpClient.HttpClient, ImagePackage>;
export type ListImagePipelineImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of images created by the specified pipeline.
 */
export declare const listImagePipelineImages: API.PaginatedOperationMethod<ListImagePipelineImagesRequest & RegionInput, ListImagePipelineImagesResponse, ListImagePipelineImagesError, Credentials | HttpClient.HttpClient, ImageSummary>;
export type ListImagePipelinesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image pipelines.
 */
export declare const listImagePipelines: API.PaginatedOperationMethod<ListImagePipelinesRequest & RegionInput, ListImagePipelinesResponse, ListImagePipelinesError, Credentials | HttpClient.HttpClient, ImagePipeline>;
export type ListImageRecipesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image recipes.
 */
export declare const listImageRecipes: API.PaginatedOperationMethod<ListImageRecipesRequest & RegionInput, ListImageRecipesResponse, ListImageRecipesError, Credentials | HttpClient.HttpClient, ImageRecipeSummary>;
export type ListImagesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the list of images that you have access to.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest & RegionInput, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, ImageVersion>;
export type ListImageScanFindingAggregationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan aggregations for your account. You can filter by the type
 * of key that Image Builder uses to group results. For example, if you want to get a list of
 * findings by severity level for one of your pipelines, you might specify your pipeline
 * with the `imagePipelineArn` filter. If you don't specify a filter, Image Builder
 * returns an aggregation for your account.
 *
 * To streamline results, you can use the following filters in your request:
 *
 * - `imageBuildVersionArn`
 *
 * - `imagePipelineArn`
 *
 * - `vulnerabilityId`
 */
export declare const listImageScanFindingAggregations: API.PaginatedOperationMethod<ListImageScanFindingAggregationsRequest & RegionInput, ListImageScanFindingAggregationsResponse, ListImageScanFindingAggregationsError, Credentials | HttpClient.HttpClient, ImageScanFindingAggregation>;
export type ListImageScanFindingsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of image scan findings for your account. Amazon Inspector generates the
 * findings when it scans images that have scanning enabled.
 */
export declare const listImageScanFindings: API.PaginatedOperationMethod<ListImageScanFindingsRequest & RegionInput, ListImageScanFindingsResponse, ListImageScanFindingsError, Credentials | HttpClient.HttpClient, ImageScanFinding>;
export type ListInfrastructureConfigurationsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of infrastructure configurations.
 */
export declare const listInfrastructureConfigurations: API.PaginatedOperationMethod<ListInfrastructureConfigurationsRequest & RegionInput, ListInfrastructureConfigurationsResponse, ListInfrastructureConfigurationsError, Credentials | HttpClient.HttpClient, InfrastructureConfigurationSummary>;
export type ListLifecycleExecutionResourcesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists resources that the runtime instance of the image lifecycle identified for lifecycle actions.
 */
export declare const listLifecycleExecutionResources: API.PaginatedOperationMethod<ListLifecycleExecutionResourcesRequest & RegionInput, ListLifecycleExecutionResourcesResponse, ListLifecycleExecutionResourcesError, Credentials | HttpClient.HttpClient, LifecycleExecutionResource>;
export type ListLifecycleExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the lifecycle runtime history for the specified resource.
 */
export declare const listLifecycleExecutions: API.PaginatedOperationMethod<ListLifecycleExecutionsRequest & RegionInput, ListLifecycleExecutionsResponse, ListLifecycleExecutionsError, Credentials | HttpClient.HttpClient, LifecycleExecution>;
export type ListLifecyclePoliciesError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a list of lifecycle policies in your Amazon Web Services account.
 */
export declare const listLifecyclePolicies: API.PaginatedOperationMethod<ListLifecyclePoliciesRequest & RegionInput, ListLifecyclePoliciesResponse, ListLifecyclePoliciesError, Credentials | HttpClient.HttpClient, LifecyclePolicySummary>;
export type ListTagsForResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Returns the list of tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWaitingWorkflowStepsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the workflow steps in your Amazon Web Services account that have paused at a
 * `WaitForAction` step, and are waiting for you to respond. To send
 * a response, call SendWorkflowStepAction.
 */
export declare const listWaitingWorkflowSteps: API.PaginatedOperationMethod<ListWaitingWorkflowStepsRequest & RegionInput, ListWaitingWorkflowStepsResponse, ListWaitingWorkflowStepsError, Credentials | HttpClient.HttpClient, WorkflowStepExecution>;
export type ListWorkflowBuildVersionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of build versions for a specific workflow resource.
 */
export declare const listWorkflowBuildVersions: API.PaginatedOperationMethod<ListWorkflowBuildVersionsRequest & RegionInput, ListWorkflowBuildVersionsResponse, ListWorkflowBuildVersionsError, Credentials | HttpClient.HttpClient, WorkflowSummary>;
export type ListWorkflowExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of workflow runtime instance metadata objects for a specific image build
 * version.
 */
export declare const listWorkflowExecutions: API.PaginatedOperationMethod<ListWorkflowExecutionsRequest & RegionInput, ListWorkflowExecutionsResponse, ListWorkflowExecutionsError, Credentials | HttpClient.HttpClient, WorkflowExecutionMetadata>;
export type ListWorkflowsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Lists workflow versions based on filtering parameters. To list the build
 * versions of a specific workflow version, call
 * ListWorkflowBuildVersions.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowVersion>;
export type ListWorkflowStepExecutionsError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidPaginationTokenException | InvalidRequestException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Returns runtime data for each step in a runtime instance of the workflow
 * that you specify in the request.
 */
export declare const listWorkflowStepExecutions: API.PaginatedOperationMethod<ListWorkflowStepExecutionsRequest & RegionInput, ListWorkflowStepExecutionsResponse, ListWorkflowStepExecutionsError, Credentials | HttpClient.HttpClient, WorkflowStepMetadata>;
export type PutComponentPolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a component. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutComponentPolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putComponentPolicy: API.OperationMethod<PutComponentPolicyRequest & RegionInput, PutComponentPolicyResponse, PutComponentPolicyError, Credentials | HttpClient.HttpClient>;
export type PutContainerRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to a container recipe. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutContainerRecipePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putContainerRecipePolicy: API.OperationMethod<PutContainerRecipePolicyRequest & RegionInput, PutContainerRecipePolicyResponse, PutContainerRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImagePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutImagePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putImagePolicy: API.OperationMethod<PutImagePolicyRequest & RegionInput, PutImagePolicyResponse, PutImagePolicyError, Credentials | HttpClient.HttpClient>;
export type PutImageRecipePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Applies a policy to an image recipe. The preferred way to share resources is with
 * the RAM API CreateResourceShare. If you use the PutImageRecipePolicy operation instead, you
 * must also call the RAM API PromoteResourceShareCreatedFromPolicy. Otherwise, the resource
 * isn't visible to the principals that it's shared with.
 */
export declare const putImageRecipePolicy: API.OperationMethod<PutImageRecipePolicyRequest & RegionInput, PutImageRecipePolicyResponse, PutImageRecipePolicyError, Credentials | HttpClient.HttpClient>;
export type RetryImageError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Retries a failed or canceled image build without rebuilding the phases
 * that already completed. The image re-runs asynchronously in place: the same
 * build version returns to the test or distribution phase where it failed and
 * continues from there. No new image build version is created. Retry is only
 * supported for AMI-based images.
 */
export declare const retryImage: API.OperationMethod<RetryImageRequest & RegionInput, RetryImageResponse, RetryImageError, Credentials | HttpClient.HttpClient>;
export type SendWorkflowStepActionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterValueException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Sends an action to a workflow step that has paused at a
 * `WaitForAction` step, so that image creation can continue.
 * To find the steps that are waiting for an action, call
 * ListWaitingWorkflowSteps.
 */
export declare const sendWorkflowStepAction: API.OperationMethod<SendWorkflowStepActionRequest & RegionInput, SendWorkflowStepActionResponse, SendWorkflowStepActionError, Credentials | HttpClient.HttpClient>;
export type StartImagePipelineExecutionError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Manually triggers a pipeline to create an image. You can start a build
 * this way whether the pipeline is enabled or disabled. The response returns
 * as soon as Image Builder creates the new image resource and queues the build. Use
 * the returned `imageBuildVersionArn` with
 * GetImage to track build progress.
 */
export declare const startImagePipelineExecution: API.OperationMethod<StartImagePipelineExecutionRequest & RegionInput, StartImagePipelineExecutionResponse, StartImagePipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StartResourceStateUpdateError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Begins an ad-hoc state change for the specified image build version.
 * This is a one-time operation - if you schedule the update, it runs only
 * once. If the
 * request includes underlying resources, or schedules the update far enough in
 * the future, Image Builder runs the update as an asynchronous lifecycle execution and
 * returns its identifier. Otherwise, for target states other than
 * `DELETED`, the state change applies immediately. If a request
 * that starts a lifecycle execution arrives while the image already has one in
 * progress, Image Builder rejects it.
 */
export declare const startResourceStateUpdate: API.OperationMethod<StartResourceStateUpdateRequest & RegionInput, StartResourceStateUpdateResponse, StartResourceStateUpdateError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a distribution configuration. Distribution configurations define and
 * configure the outputs for your images, including the target Regions,
 * accounts, and settings for each Region.
 *
 * This operation doesn't support selective updates. The request
 * replaces the entire distribution configuration, so include every setting
 * that you want to keep. Any optional property that you omit is removed
 * or reset to its default.
 */
export declare const updateDistributionConfiguration: API.OperationMethod<UpdateDistributionConfigurationRequest & RegionInput, UpdateDistributionConfigurationResponse, UpdateDistributionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateImagePipelineError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an image pipeline. Use image pipelines to automate the creation and
 * distribution of images. You must specify exactly one recipe for your image, using either
 * a `containerRecipeArn` or an `imageRecipeArn`. The
 * recipe must be the same type, image or container, as the pipeline's current
 * recipe.
 *
 * This operation doesn't support selective updates. The request
 * replaces the entire pipeline configuration, so include every setting
 * that you want to keep. Any optional property that you omit is removed
 * or reset to its default.
 */
export declare const updateImagePipeline: API.OperationMethod<UpdateImagePipelineRequest & RegionInput, UpdateImagePipelineResponse, UpdateImagePipelineError, Credentials | HttpClient.HttpClient>;
export type UpdateInfrastructureConfigurationError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | ResourceNotFoundException | InvalidParameterValueException | CommonErrors;
/**
 * Updates an infrastructure configuration. An infrastructure configuration defines
 * the environment in which Image Builder builds and tests your image.
 *
 * This operation doesn't support selective updates. The request
 * replaces the entire infrastructure configuration, so include every
 * setting that you want to keep. Any optional property that you omit is
 * removed or reset to its default.
 */
export declare const updateInfrastructureConfiguration: API.OperationMethod<UpdateInfrastructureConfigurationRequest & RegionInput, UpdateInfrastructureConfigurationResponse, UpdateInfrastructureConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = CallRateLimitExceededException | ClientException | ForbiddenException | IdempotentParameterMismatchException | InvalidParameterCombinationException | InvalidRequestException | ResourceInUseException | ServiceException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the specified lifecycle policy. The `resourceType` must
 * match the existing policy's value.
 *
 * This operation doesn't support selective updates. The request
 * replaces the entire lifecycle policy configuration, so include every
 * setting that you want to keep. Any optional property that you omit is
 * removed or reset to its default.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest & RegionInput, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=imagebuilder.d.ts.map