import type { AliasName } from "@alchemy.run/aws/KMS/Alias";
import { Decrypt } from "@alchemy.run/aws/KMS/Decrypt";
import { GenerateDataKey } from "@alchemy.run/aws/KMS/GenerateDataKey";
import type { Key } from "@alchemy.run/aws/KMS/Key";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type IntermediateKeyOptions, KeyWrap } from "../KeyWrap.ts";
/** Options for {@link KmsKeyWrap}. */
export interface KmsKeyWrapOptions {
    /**
     * Call KMS once per intermediate key instead of once per seal and open.
     * Each process has KMS make an intermediate key, keeps it in memory for
     * `keep`, and wraps subject keys under it locally.
     *
     * It trades cost for exposure: an intermediate key is in the process's
     * memory, KMS logs one call per intermediate key rather than one per
     * subject, and a process cut off from KMS reads on for up to `keep`.
     * Shredding is unchanged: each subject keeps a key of its own.
     *
     * @default undefined (every seal and open is one KMS call)
     */
    readonly intermediateKey?: IntermediateKeyOptions;
}
/**
 * Wrap each subject's key under an AWS KMS key. KMS makes the subject's key
 * (`GenerateDataKey`) and unwraps it (`Decrypt`), with the subject as the
 * encryption context, so a stored key unwraps only for the subject it was
 * made for. The root key never leaves KMS.
 *
 * Every seal and open is one `Decrypt` call.
 *
 * ### Wrapping keys under KMS
 * **Example:** A KMS key over keys in DynamoDB
 * ```typescript
 * import * as AWS from "@alchemy.run/aws";
 * import * as Domain from "@alchemy.run/domain";
 * import * as DomainAWS from "@alchemy.run/domain/AWS";
 * import * as Layer from "effect/Layer";
 *
 * export const Keys = AWS.DynamoDB.Table("VaultKeys", {
 *   partitionKey: "subject",
 *   attributes: { subject: "S" },
 * });
 * export const RootKey = AWS.KMS.Key("VaultRootKey");
 *
 * export const Sealing = Domain.VaultLive.pipe(
 *   Layer.provide(DomainAWS.DynamoKeyStore(Keys)),
 *   Layer.provide(DomainAWS.KmsKeyWrap(RootKey)),
 *   Layer.provide(
 *     Layer.mergeAll(
 *       AWS.DynamoDB.GetItemHttp,
 *       AWS.DynamoDB.PutItemHttp,
 *       AWS.DynamoDB.DeleteItemHttp,
 *       AWS.KMS.GenerateDataKeyHttp,
 *       AWS.KMS.DecryptHttp,
 *     ),
 *   ),
 * );
 * ```
 *
 * ### Calling KMS less often
 * `intermediateKey` has each process keep one intermediate key in memory
 * and wrap subject keys under it locally, so KMS is called once per
 * intermediate key instead of once per seal and open. The intermediate key
 * is in the process's memory, KMS no longer logs each subject's access,
 * and a process cut off from KMS reads on for up to `keep`. Shredding is
 * unchanged.
 *
 * **Example:** One KMS call per process every five minutes
 * ```typescript
 * DomainAWS.KmsKeyWrap(RootKey, { intermediateKey: { keep: "5 minutes" } });
 * ```
 *
 * @layer
 * @provides Domain.KeyWrap
 */
export declare const KmsKeyWrap: <E = never, R = never>(key: Key | AliasName | Effect.Effect<Key, E, R>, options?: KmsKeyWrapOptions) => Layer.Layer<KeyWrap, E, R | GenerateDataKey | Decrypt>;
//# sourceMappingURL=KmsKeyWrap.d.ts.map