import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
export type CategoryName = string;
export type TimestampMilliseconds = number;
export interface AbsoluteTimeRange {
    StartTime?: number | undefined;
    EndTime?: number | undefined;
    First?: number | undefined;
    Last?: number | undefined;
}
export type Percentage = number;
export interface RelativeTimeRange {
    StartPercentage?: number | undefined;
    EndPercentage?: number | undefined;
    First?: number | undefined;
    Last?: number | undefined;
}
export interface NonTalkTimeFilter {
    Threshold?: number | undefined;
    AbsoluteTimeRange?: AbsoluteTimeRange | undefined;
    RelativeTimeRange?: RelativeTimeRange | undefined;
    Negate?: boolean | undefined;
}
export type ParticipantRole = "AGENT" | "CUSTOMER" | (string & {});
export interface InterruptionFilter {
    Threshold?: number | undefined;
    ParticipantRole?: ParticipantRole | undefined;
    AbsoluteTimeRange?: AbsoluteTimeRange | undefined;
    RelativeTimeRange?: RelativeTimeRange | undefined;
    Negate?: boolean | undefined;
}
export type TranscriptFilterType = "EXACT" | (string & {});
export type NonEmptyString = string;
export type StringTargetList = string[];
export interface TranscriptFilter {
    TranscriptFilterType: TranscriptFilterType;
    AbsoluteTimeRange?: AbsoluteTimeRange | undefined;
    RelativeTimeRange?: RelativeTimeRange | undefined;
    ParticipantRole?: ParticipantRole | undefined;
    Negate?: boolean | undefined;
    Targets: string[];
}
export type SentimentValue = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | "MIXED" | (string & {});
export type SentimentValueList = SentimentValue[];
export interface SentimentFilter {
    Sentiments: SentimentValue[];
    AbsoluteTimeRange?: AbsoluteTimeRange | undefined;
    RelativeTimeRange?: RelativeTimeRange | undefined;
    ParticipantRole?: ParticipantRole | undefined;
    Negate?: boolean | undefined;
}
export type Rule = {
    NonTalkTimeFilter: NonTalkTimeFilter;
    InterruptionFilter?: undefined;
    TranscriptFilter?: undefined;
    SentimentFilter?: undefined;
} | {
    NonTalkTimeFilter?: undefined;
    InterruptionFilter: InterruptionFilter;
    TranscriptFilter?: undefined;
    SentimentFilter?: undefined;
} | {
    NonTalkTimeFilter?: undefined;
    InterruptionFilter?: undefined;
    TranscriptFilter: TranscriptFilter;
    SentimentFilter?: undefined;
} | {
    NonTalkTimeFilter?: undefined;
    InterruptionFilter?: undefined;
    TranscriptFilter?: undefined;
    SentimentFilter: SentimentFilter;
};
export type RuleList = Rule[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type InputType = "REAL_TIME" | "POST_CALL" | (string & {});
export interface CreateCallAnalyticsCategoryRequest {
    CategoryName: string;
    Rules: Rule[];
    Tags?: Tag[] | undefined;
    InputType?: InputType | undefined;
}
export interface CategoryProperties {
    CategoryName?: string | undefined;
    Rules?: Rule[] | undefined;
    CreateTime?: Date | undefined;
    LastUpdateTime?: Date | undefined;
    Tags?: Tag[] | undefined;
    InputType?: InputType | undefined;
}
export interface CreateCallAnalyticsCategoryResponse {
    CategoryProperties?: CategoryProperties | undefined;
}
export type CLMLanguageCode = "en-US" | "hi-IN" | "es-US" | "en-GB" | "en-AU" | "de-DE" | "ja-JP" | (string & {});
export type BaseModelName = "NarrowBand" | "WideBand" | (string & {});
export type ModelName = string;
export type Uri = string;
export type DataAccessRoleArn = string;
export interface InputDataConfig {
    S3Uri: string;
    TuningDataS3Uri?: string | undefined;
    DataAccessRoleArn: string;
}
export type PrintableNonEmptyString = string;
export type KMSEncryptionContextMap = {
    [key: string]: string | undefined;
};
export type KMSKeyId = string;
export interface EncryptionConfiguration {
    KMSEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    KMSKey: string;
}
export interface CreateLanguageModelRequest {
    LanguageCode: CLMLanguageCode;
    BaseModelName: BaseModelName;
    ModelName: string;
    InputDataConfig: InputDataConfig;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    Tags?: Tag[] | undefined;
}
export type ModelStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export interface CreateLanguageModelResponse {
    LanguageCode?: CLMLanguageCode | undefined;
    BaseModelName?: BaseModelName | undefined;
    ModelName?: string | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    ModelStatus?: ModelStatus | undefined;
}
export type VocabularyName = string;
export type LanguageCode = "af-ZA" | "ar-AE" | "ar-SA" | "am-ET" | "cy-GB" | "da-DK" | "de-CH" | "de-DE" | "en-AB" | "en-AU" | "en-GB" | "en-IE" | "en-IN" | "en-US" | "en-WL" | "es-ES" | "es-MX" | "es-US" | "fa-AF" | "fa-IR" | "fr-CA" | "fr-FR" | "ga-IE" | "gd-GB" | "he-IL" | "hi-IN" | "ht-HT" | "id-ID" | "it-IT" | "ja-JP" | "jv-ID" | "km-KH" | "ko-KR" | "my-MM" | "ms-MY" | "nl-NL" | "pt-BR" | "pt-PT" | "ru-RU" | "ta-IN" | "te-IN" | "tr-TR" | "zh-CN" | "zh-TW" | "th-TH" | "en-ZA" | "en-NZ" | "vi-VN" | "sv-SE" | "ab-GE" | "ast-ES" | "az-AZ" | "ba-RU" | "be-BY" | "bg-BG" | "bn-IN" | "bs-BA" | "ca-ES" | "ckb-IQ" | "ckb-IR" | "cs-CZ" | "cy-WL" | "el-GR" | "et-EE" | "et-ET" | "eu-ES" | "fi-FI" | "gl-ES" | "gu-IN" | "ha-NG" | "hr-HR" | "hu-HU" | "hy-AM" | "is-IS" | "ka-GE" | "kab-DZ" | "kk-KZ" | "kn-IN" | "ky-KG" | "lg-IN" | "lt-LT" | "lv-LV" | "mhr-RU" | "mi-NZ" | "mk-MK" | "ml-IN" | "mn-MN" | "mr-IN" | "mt-MT" | "no-NO" | "ne-NP" | "or-IN" | "pa-IN" | "pl-PL" | "ps-AF" | "ro-RO" | "rw-RW" | "si-LK" | "sk-SK" | "sl-SI" | "so-SO" | "sq-AL" | "sr-RS" | "su-ID" | "sw-BI" | "sw-KE" | "sw-RW" | "sw-TZ" | "sw-UG" | "tl-PH" | "tt-RU" | "ug-CN" | "uk-UA" | "uz-UZ" | "wo-SN" | "zh-HK" | "zu-ZA" | (string & {});
export interface CreateMedicalVocabularyRequest {
    VocabularyName: string;
    LanguageCode: LanguageCode;
    VocabularyFileUri: string;
    Tags?: Tag[] | undefined;
}
export type VocabularyState = "PENDING" | "READY" | "FAILED" | (string & {});
export type FailureReason = string;
export interface CreateMedicalVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    VocabularyState?: VocabularyState | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
}
export type Phrase = string;
export type Phrases = string[];
export interface CreateVocabularyRequest {
    VocabularyName: string;
    LanguageCode: LanguageCode;
    Phrases?: string[] | undefined;
    VocabularyFileUri?: string | undefined;
    Tags?: Tag[] | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface CreateVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    VocabularyState?: VocabularyState | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
}
export type VocabularyFilterName = string;
export type Word = string;
export type Words = string[];
export interface CreateVocabularyFilterRequest {
    VocabularyFilterName: string;
    LanguageCode: LanguageCode;
    Words?: string[] | undefined;
    VocabularyFilterFileUri?: string | undefined;
    Tags?: Tag[] | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface CreateVocabularyFilterResponse {
    VocabularyFilterName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DeleteCallAnalyticsCategoryRequest {
    CategoryName: string;
}
export interface DeleteCallAnalyticsCategoryResponse {
}
export type CallAnalyticsJobName = string;
export interface DeleteCallAnalyticsJobRequest {
    CallAnalyticsJobName: string;
}
export interface DeleteCallAnalyticsJobResponse {
}
export interface DeleteLanguageModelRequest {
    ModelName: string;
}
export interface DeleteLanguageModelResponse {
}
export type TranscriptionJobName = string;
export interface DeleteMedicalScribeJobRequest {
    MedicalScribeJobName: string;
}
export interface DeleteMedicalScribeJobResponse {
}
export interface DeleteMedicalTranscriptionJobRequest {
    MedicalTranscriptionJobName: string;
}
export interface DeleteMedicalTranscriptionJobResponse {
}
export interface DeleteMedicalVocabularyRequest {
    VocabularyName: string;
}
export interface DeleteMedicalVocabularyResponse {
}
export interface DeleteTranscriptionJobRequest {
    TranscriptionJobName: string;
}
export interface DeleteTranscriptionJobResponse {
}
export interface DeleteVocabularyRequest {
    VocabularyName: string;
}
export interface DeleteVocabularyResponse {
}
export interface DeleteVocabularyFilterRequest {
    VocabularyFilterName: string;
}
export interface DeleteVocabularyFilterResponse {
}
export interface DescribeLanguageModelRequest {
    ModelName: string;
}
export interface LanguageModel {
    ModelName?: string | undefined;
    CreateTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LanguageCode?: CLMLanguageCode | undefined;
    BaseModelName?: BaseModelName | undefined;
    ModelStatus?: ModelStatus | undefined;
    UpgradeAvailability?: boolean | undefined;
    FailureReason?: string | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface DescribeLanguageModelResponse {
    LanguageModel?: LanguageModel | undefined;
}
export interface GetCallAnalyticsCategoryRequest {
    CategoryName: string;
}
export interface GetCallAnalyticsCategoryResponse {
    CategoryProperties?: CategoryProperties | undefined;
}
export interface GetCallAnalyticsJobRequest {
    CallAnalyticsJobName: string;
}
export type CallAnalyticsJobStatus = "QUEUED" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type CallAnalyticsFeature = "GENERATIVE_SUMMARIZATION" | (string & {});
export type CallAnalyticsSkippedReasonCode = "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | (string & {});
export interface CallAnalyticsSkippedFeature {
    Feature?: CallAnalyticsFeature | undefined;
    ReasonCode?: CallAnalyticsSkippedReasonCode | undefined;
    Message?: string | undefined;
}
export type CallAnalyticsSkippedFeatureList = CallAnalyticsSkippedFeature[];
export interface CallAnalyticsJobDetails {
    Skipped?: CallAnalyticsSkippedFeature[] | undefined;
}
export type MediaSampleRateHertz = number;
export type MediaFormat = "mp3" | "mp4" | "wav" | "flac" | "ogg" | "amr" | "webm" | "m4a" | (string & {});
export interface Media {
    MediaFileUri?: string | undefined;
    RedactedMediaFileUri?: string | undefined;
}
export interface Transcript {
    TranscriptFileUri?: string | undefined;
    RedactedTranscriptFileUri?: string | undefined;
}
export type IdentifiedLanguageScore = number;
export type VocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export type RedactionType = "PII" | (string & {});
export type RedactionOutput = "redacted" | "redacted_and_unredacted" | (string & {});
export type PiiEntityType = "BANK_ACCOUNT_NUMBER" | "BANK_ROUTING" | "CREDIT_DEBIT_NUMBER" | "CREDIT_DEBIT_CVV" | "CREDIT_DEBIT_EXPIRY" | "PIN" | "EMAIL" | "ADDRESS" | "NAME" | "PHONE" | "SSN" | "DATE_TIME" | "PASSPORT_NUMBER" | "DRIVER_ID" | "URL" | "AGE" | "USERNAME" | "PASSWORD" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "IP_ADDRESS" | "MAC_ADDRESS" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "ALL" | (string & {});
export type PiiEntityTypes = PiiEntityType[];
export interface ContentRedaction {
    RedactionType: RedactionType;
    RedactionOutput: RedactionOutput;
    PiiEntityTypes?: PiiEntityType[] | undefined;
}
export type LanguageOptions = LanguageCode[];
export interface LanguageIdSettings {
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    LanguageModelName?: string | undefined;
}
export type LanguageIdSettingsMap = {
    [key in LanguageCode]?: LanguageIdSettings | undefined;
};
export interface Summarization {
    GenerateAbstractiveSummary: boolean;
}
export interface CallAnalyticsJobSettings {
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    LanguageModelName?: string | undefined;
    ContentRedaction?: ContentRedaction | undefined;
    LanguageOptions?: LanguageCode[] | undefined;
    LanguageIdSettings?: {
        [key: string]: LanguageIdSettings | undefined;
    } | undefined;
    Summarization?: Summarization | undefined;
}
export type ChannelId = number;
export interface ChannelDefinition {
    ChannelId?: number | undefined;
    ParticipantRole?: ParticipantRole | undefined;
}
export type ChannelDefinitions = ChannelDefinition[];
export interface CallAnalyticsJob {
    CallAnalyticsJobName?: string | undefined;
    CallAnalyticsJobStatus?: CallAnalyticsJobStatus | undefined;
    CallAnalyticsJobDetails?: CallAnalyticsJobDetails | undefined;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaFormat?: MediaFormat | undefined;
    Media?: Media | undefined;
    Transcript?: Transcript | undefined;
    StartTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    FailureReason?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    IdentifiedLanguageScore?: number | undefined;
    Settings?: CallAnalyticsJobSettings | undefined;
    ChannelDefinitions?: ChannelDefinition[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetCallAnalyticsJobResponse {
    CallAnalyticsJob?: CallAnalyticsJob | undefined;
}
export interface GetMedicalScribeJobRequest {
    MedicalScribeJobName: string;
}
export type MedicalScribeJobStatus = "QUEUED" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type MedicalScribeLanguageCode = "en-US" | (string & {});
export interface MedicalScribeOutput {
    TranscriptFileUri: string;
    ClinicalDocumentUri: string;
}
export type MaxSpeakers = number;
export type MedicalScribeNoteTemplate = "HISTORY_AND_PHYSICAL" | "GIRPP" | "BIRP" | "SIRP" | "DAP" | "BEHAVIORAL_SOAP" | "PHYSICAL_SOAP" | (string & {});
export interface ClinicalNoteGenerationSettings {
    NoteTemplate?: MedicalScribeNoteTemplate | undefined;
}
export interface MedicalScribeSettings {
    ShowSpeakerLabels?: boolean | undefined;
    MaxSpeakerLabels?: number | undefined;
    ChannelIdentification?: boolean | undefined;
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    ClinicalNoteGenerationSettings?: ClinicalNoteGenerationSettings | undefined;
}
export type MedicalScribeChannelId = number;
export type MedicalScribeParticipantRole = "PATIENT" | "CLINICIAN" | (string & {});
export interface MedicalScribeChannelDefinition {
    ChannelId: number;
    ParticipantRole: MedicalScribeParticipantRole;
}
export type MedicalScribeChannelDefinitions = MedicalScribeChannelDefinition[];
export interface MedicalScribeJob {
    MedicalScribeJobName?: string | undefined;
    MedicalScribeJobStatus?: MedicalScribeJobStatus | undefined;
    LanguageCode?: MedicalScribeLanguageCode | undefined;
    Media?: Media | undefined;
    MedicalScribeOutput?: MedicalScribeOutput | undefined;
    StartTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    FailureReason?: string | undefined;
    Settings?: MedicalScribeSettings | undefined;
    DataAccessRoleArn?: string | undefined;
    ChannelDefinitions?: MedicalScribeChannelDefinition[] | undefined;
    MedicalScribeContextProvided?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetMedicalScribeJobResponse {
    MedicalScribeJob?: MedicalScribeJob | undefined;
}
export interface GetMedicalTranscriptionJobRequest {
    MedicalTranscriptionJobName: string;
}
export type TranscriptionJobStatus = "QUEUED" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type MedicalMediaSampleRateHertz = number;
export interface MedicalTranscript {
    TranscriptFileUri?: string | undefined;
}
export type MaxAlternatives = number;
export interface MedicalTranscriptionSetting {
    ShowSpeakerLabels?: boolean | undefined;
    MaxSpeakerLabels?: number | undefined;
    ChannelIdentification?: boolean | undefined;
    ShowAlternatives?: boolean | undefined;
    MaxAlternatives?: number | undefined;
    VocabularyName?: string | undefined;
}
export type MedicalContentIdentificationType = "PHI" | (string & {});
export type Specialty = "PRIMARYCARE" | (string & {});
export type Type = "CONVERSATION" | "DICTATION" | (string & {});
export interface MedicalTranscriptionJob {
    MedicalTranscriptionJobName?: string | undefined;
    TranscriptionJobStatus?: TranscriptionJobStatus | undefined;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaFormat?: MediaFormat | undefined;
    Media?: Media | undefined;
    Transcript?: MedicalTranscript | undefined;
    StartTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    FailureReason?: string | undefined;
    Settings?: MedicalTranscriptionSetting | undefined;
    ContentIdentificationType?: MedicalContentIdentificationType | undefined;
    Specialty?: Specialty | undefined;
    Type?: Type | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetMedicalTranscriptionJobResponse {
    MedicalTranscriptionJob?: MedicalTranscriptionJob | undefined;
}
export interface GetMedicalVocabularyRequest {
    VocabularyName: string;
}
export interface GetMedicalVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    VocabularyState?: VocabularyState | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    DownloadUri?: string | undefined;
}
export interface GetTranscriptionJobRequest {
    TranscriptionJobName: string;
}
export interface Settings {
    VocabularyName?: string | undefined;
    ShowSpeakerLabels?: boolean | undefined;
    MaxSpeakerLabels?: number | undefined;
    ChannelIdentification?: boolean | undefined;
    ShowAlternatives?: boolean | undefined;
    MaxAlternatives?: number | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
}
export interface ModelSettings {
    LanguageModelName?: string | undefined;
}
export interface JobExecutionSettings {
    AllowDeferredExecution?: boolean | undefined;
    DataAccessRoleArn?: string | undefined;
}
export type DurationInSeconds = number;
export interface LanguageCodeItem {
    LanguageCode?: LanguageCode | undefined;
    DurationInSeconds?: number | undefined;
}
export type LanguageCodeList = LanguageCodeItem[];
export type SubtitleFormat = "vtt" | "srt" | (string & {});
export type SubtitleFormats = SubtitleFormat[];
export type SubtitleFileUris = string[];
export type SubtitleOutputStartIndex = number;
export interface SubtitlesOutput {
    Formats?: SubtitleFormat[] | undefined;
    SubtitleFileUris?: string[] | undefined;
    OutputStartIndex?: number | undefined;
}
export type ToxicityCategory = "ALL" | (string & {});
export type ToxicityCategories = ToxicityCategory[];
export interface ToxicityDetectionSettings {
    ToxicityCategories: ToxicityCategory[];
}
export type ToxicityDetection = ToxicityDetectionSettings[];
export interface TranscriptionJob {
    TranscriptionJobName?: string | undefined;
    TranscriptionJobStatus?: TranscriptionJobStatus | undefined;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaFormat?: MediaFormat | undefined;
    Media?: Media | undefined;
    Transcript?: Transcript | undefined;
    StartTime?: Date | undefined;
    CreationTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    FailureReason?: string | undefined;
    Settings?: Settings | undefined;
    ModelSettings?: ModelSettings | undefined;
    JobExecutionSettings?: JobExecutionSettings | undefined;
    ContentRedaction?: ContentRedaction | undefined;
    IdentifyLanguage?: boolean | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    LanguageOptions?: LanguageCode[] | undefined;
    IdentifiedLanguageScore?: number | undefined;
    LanguageCodes?: LanguageCodeItem[] | undefined;
    Tags?: Tag[] | undefined;
    Subtitles?: SubtitlesOutput | undefined;
    LanguageIdSettings?: {
        [key: string]: LanguageIdSettings | undefined;
    } | undefined;
    ToxicityDetection?: ToxicityDetectionSettings[] | undefined;
}
export interface GetTranscriptionJobResponse {
    TranscriptionJob?: TranscriptionJob | undefined;
}
export interface GetVocabularyRequest {
    VocabularyName: string;
}
export interface GetVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    VocabularyState?: VocabularyState | undefined;
    LastModifiedTime?: Date | undefined;
    FailureReason?: string | undefined;
    DownloadUri?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface GetVocabularyFilterRequest {
    VocabularyFilterName: string;
}
export interface GetVocabularyFilterResponse {
    VocabularyFilterName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
    DownloadUri?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListCallAnalyticsCategoriesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type CategoryPropertiesList = CategoryProperties[];
export interface ListCallAnalyticsCategoriesResponse {
    NextToken?: string | undefined;
    Categories?: CategoryProperties[] | undefined;
}
export interface ListCallAnalyticsJobsRequest {
    Status?: CallAnalyticsJobStatus | undefined;
    JobNameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface CallAnalyticsJobSummary {
    CallAnalyticsJobName?: string | undefined;
    CreationTime?: Date | undefined;
    StartTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LanguageCode?: LanguageCode | undefined;
    CallAnalyticsJobStatus?: CallAnalyticsJobStatus | undefined;
    CallAnalyticsJobDetails?: CallAnalyticsJobDetails | undefined;
    FailureReason?: string | undefined;
}
export type CallAnalyticsJobSummaries = CallAnalyticsJobSummary[];
export interface ListCallAnalyticsJobsResponse {
    Status?: CallAnalyticsJobStatus | undefined;
    NextToken?: string | undefined;
    CallAnalyticsJobSummaries?: CallAnalyticsJobSummary[] | undefined;
}
export interface ListLanguageModelsRequest {
    StatusEquals?: ModelStatus | undefined;
    NameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Models = LanguageModel[];
export interface ListLanguageModelsResponse {
    NextToken?: string | undefined;
    Models?: LanguageModel[] | undefined;
}
export interface ListMedicalScribeJobsRequest {
    Status?: MedicalScribeJobStatus | undefined;
    JobNameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MedicalScribeJobSummary {
    MedicalScribeJobName?: string | undefined;
    CreationTime?: Date | undefined;
    StartTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LanguageCode?: MedicalScribeLanguageCode | undefined;
    MedicalScribeJobStatus?: MedicalScribeJobStatus | undefined;
    FailureReason?: string | undefined;
}
export type MedicalScribeJobSummaries = MedicalScribeJobSummary[];
export interface ListMedicalScribeJobsResponse {
    Status?: MedicalScribeJobStatus | undefined;
    NextToken?: string | undefined;
    MedicalScribeJobSummaries?: MedicalScribeJobSummary[] | undefined;
}
export interface ListMedicalTranscriptionJobsRequest {
    Status?: TranscriptionJobStatus | undefined;
    JobNameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type OutputLocationType = "CUSTOMER_BUCKET" | "SERVICE_BUCKET" | (string & {});
export interface MedicalTranscriptionJobSummary {
    MedicalTranscriptionJobName?: string | undefined;
    CreationTime?: Date | undefined;
    StartTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LanguageCode?: LanguageCode | undefined;
    TranscriptionJobStatus?: TranscriptionJobStatus | undefined;
    FailureReason?: string | undefined;
    OutputLocationType?: OutputLocationType | undefined;
    Specialty?: Specialty | undefined;
    ContentIdentificationType?: MedicalContentIdentificationType | undefined;
    Type?: Type | undefined;
}
export type MedicalTranscriptionJobSummaries = MedicalTranscriptionJobSummary[];
export interface ListMedicalTranscriptionJobsResponse {
    Status?: TranscriptionJobStatus | undefined;
    NextToken?: string | undefined;
    MedicalTranscriptionJobSummaries?: MedicalTranscriptionJobSummary[] | undefined;
}
export interface ListMedicalVocabulariesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StateEquals?: VocabularyState | undefined;
    NameContains?: string | undefined;
}
export interface VocabularyInfo {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
    VocabularyState?: VocabularyState | undefined;
}
export type Vocabularies = VocabularyInfo[];
export interface ListMedicalVocabulariesResponse {
    Status?: VocabularyState | undefined;
    NextToken?: string | undefined;
    Vocabularies?: VocabularyInfo[] | undefined;
}
export type TranscribeArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ListTranscriptionJobsRequest {
    Status?: TranscriptionJobStatus | undefined;
    JobNameContains?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TranscriptionJobSummary {
    TranscriptionJobName?: string | undefined;
    CreationTime?: Date | undefined;
    StartTime?: Date | undefined;
    CompletionTime?: Date | undefined;
    LanguageCode?: LanguageCode | undefined;
    TranscriptionJobStatus?: TranscriptionJobStatus | undefined;
    FailureReason?: string | undefined;
    OutputLocationType?: OutputLocationType | undefined;
    ContentRedaction?: ContentRedaction | undefined;
    ModelSettings?: ModelSettings | undefined;
    IdentifyLanguage?: boolean | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    IdentifiedLanguageScore?: number | undefined;
    LanguageCodes?: LanguageCodeItem[] | undefined;
    ToxicityDetection?: ToxicityDetectionSettings[] | undefined;
}
export type TranscriptionJobSummaries = TranscriptionJobSummary[];
export interface ListTranscriptionJobsResponse {
    Status?: TranscriptionJobStatus | undefined;
    NextToken?: string | undefined;
    TranscriptionJobSummaries?: TranscriptionJobSummary[] | undefined;
}
export interface ListVocabulariesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StateEquals?: VocabularyState | undefined;
    NameContains?: string | undefined;
}
export interface ListVocabulariesResponse {
    Status?: VocabularyState | undefined;
    NextToken?: string | undefined;
    Vocabularies?: VocabularyInfo[] | undefined;
}
export interface ListVocabularyFiltersRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    NameContains?: string | undefined;
}
export interface VocabularyFilterInfo {
    VocabularyFilterName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
}
export type VocabularyFilters = VocabularyFilterInfo[];
export interface ListVocabularyFiltersResponse {
    NextToken?: string | undefined;
    VocabularyFilters?: VocabularyFilterInfo[] | undefined;
}
export interface StartCallAnalyticsJobRequest {
    CallAnalyticsJobName: string;
    Media: Media;
    OutputLocation?: string | undefined;
    OutputEncryptionKMSKeyId?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    Settings?: CallAnalyticsJobSettings | undefined;
    Tags?: Tag[] | undefined;
    ChannelDefinitions?: ChannelDefinition[] | undefined;
}
export interface StartCallAnalyticsJobResponse {
    CallAnalyticsJob?: CallAnalyticsJob | undefined;
}
export type OutputBucketName = string;
export type Pronouns = "HE_HIM" | "SHE_HER" | "THEY_THEM" | (string & {});
export interface MedicalScribePatientContext {
    Pronouns?: Pronouns | undefined;
}
export interface MedicalScribeContext {
    PatientContext?: MedicalScribePatientContext | undefined;
}
export interface StartMedicalScribeJobRequest {
    MedicalScribeJobName: string;
    Media: Media;
    OutputBucketName: string;
    OutputEncryptionKMSKeyId?: string | undefined;
    KMSEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    DataAccessRoleArn: string;
    Settings: MedicalScribeSettings;
    ChannelDefinitions?: MedicalScribeChannelDefinition[] | undefined;
    Tags?: Tag[] | undefined;
    MedicalScribeContext?: MedicalScribeContext | undefined;
}
export interface StartMedicalScribeJobResponse {
    MedicalScribeJob?: MedicalScribeJob | undefined;
}
export type OutputKey = string;
export interface StartMedicalTranscriptionJobRequest {
    MedicalTranscriptionJobName: string;
    LanguageCode: LanguageCode;
    MediaSampleRateHertz?: number | undefined;
    MediaFormat?: MediaFormat | undefined;
    Media: Media;
    OutputBucketName: string;
    OutputKey?: string | undefined;
    OutputEncryptionKMSKeyId?: string | undefined;
    KMSEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Settings?: MedicalTranscriptionSetting | undefined;
    ContentIdentificationType?: MedicalContentIdentificationType | undefined;
    Specialty: Specialty;
    Type: Type;
    Tags?: Tag[] | undefined;
}
export interface StartMedicalTranscriptionJobResponse {
    MedicalTranscriptionJob?: MedicalTranscriptionJob | undefined;
}
export interface Subtitles {
    Formats?: SubtitleFormat[] | undefined;
    OutputStartIndex?: number | undefined;
}
export interface StartTranscriptionJobRequest {
    TranscriptionJobName: string;
    LanguageCode?: LanguageCode | undefined;
    MediaSampleRateHertz?: number | undefined;
    MediaFormat?: MediaFormat | undefined;
    Media: Media;
    OutputBucketName?: string | undefined;
    OutputKey?: string | undefined;
    OutputEncryptionKMSKeyId?: string | undefined;
    KMSEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    Settings?: Settings | undefined;
    ModelSettings?: ModelSettings | undefined;
    JobExecutionSettings?: JobExecutionSettings | undefined;
    ContentRedaction?: ContentRedaction | undefined;
    IdentifyLanguage?: boolean | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    LanguageOptions?: LanguageCode[] | undefined;
    Subtitles?: Subtitles | undefined;
    Tags?: Tag[] | undefined;
    LanguageIdSettings?: {
        [key: string]: LanguageIdSettings | undefined;
    } | undefined;
    ToxicityDetection?: ToxicityDetectionSettings[] | undefined;
}
export interface StartTranscriptionJobResponse {
    TranscriptionJob?: TranscriptionJob | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCallAnalyticsCategoryRequest {
    CategoryName: string;
    Rules: Rule[];
    InputType?: InputType | undefined;
}
export interface UpdateCallAnalyticsCategoryResponse {
    CategoryProperties?: CategoryProperties | undefined;
}
export interface UpdateLanguageModelRequest {
    ModelName: string;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateLanguageModelResponse {
    ModelName?: string | undefined;
    ModelStatus?: ModelStatus | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface UpdateMedicalVocabularyRequest {
    VocabularyName: string;
    LanguageCode: LanguageCode;
    VocabularyFileUri: string;
}
export interface UpdateMedicalVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
    VocabularyState?: VocabularyState | undefined;
}
export interface UpdateVocabularyRequest {
    VocabularyName: string;
    LanguageCode: LanguageCode;
    Phrases?: string[] | undefined;
    VocabularyFileUri?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateVocabularyResponse {
    VocabularyName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
    VocabularyState?: VocabularyState | undefined;
}
export interface UpdateVocabularyFilterRequest {
    VocabularyFilterName: string;
    Words?: string[] | undefined;
    VocabularyFilterFileUri?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateVocabularyFilterResponse {
    VocabularyFilterName?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LastModifiedTime?: Date | undefined;
}
export type CreateCallAnalyticsCategoryError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Creates a new Call Analytics category.
 *
 * All categories are automatically applied to your Call Analytics transcriptions. Note that in
 * order to apply categories to your transcriptions, you must create them before submitting your
 * transcription request, as categories cannot be applied retroactively.
 *
 * When creating a new category, you can use the `InputType` parameter to
 * label the category as a `POST_CALL` or a `REAL_TIME` category.
 * `POST_CALL` categories can only be applied to post-call transcriptions and
 * `REAL_TIME` categories can only be applied to real-time transcriptions. If you
 * do not include `InputType`, your category is created as a
 * `POST_CALL` category by default.
 *
 * Call Analytics categories are composed of rules. For each category, you must create
 * between 1 and 20 rules. Rules can include these parameters: , , , and .
 *
 * To update an existing category, see .
 *
 * To learn more about Call Analytics categories, see Creating categories for post-call
 * transcriptions and Creating categories for
 * real-time transcriptions.
 */
export declare const createCallAnalyticsCategory: API.OperationMethod<CreateCallAnalyticsCategoryRequest & RegionInput, CreateCallAnalyticsCategoryResponse, CreateCallAnalyticsCategoryError, Credentials | HttpClient.HttpClient>;
export type CreateLanguageModelError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Creates a new custom language model.
 *
 * When creating a new custom language model, you must specify:
 *
 * - If you want a Wideband (audio sample rates over 16,000 Hz) or Narrowband
 * (audio sample rates under 16,000 Hz) base model
 *
 * - The location of your training and tuning files (this must be an Amazon S3 URI)
 *
 * - The language of your model
 *
 * - A unique name for your model
 */
export declare const createLanguageModel: API.OperationMethod<CreateLanguageModelRequest & RegionInput, CreateLanguageModelResponse, CreateLanguageModelError, Credentials | HttpClient.HttpClient>;
export type CreateMedicalVocabularyError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Creates a new custom medical vocabulary.
 *
 * Before creating a new custom medical vocabulary, you must first upload a text file
 * that contains your vocabulary table into an Amazon S3 bucket.
 * Note that this differs from , where you can
 * include a list of terms within your request using the `Phrases` flag;
 * `CreateMedicalVocabulary` does not support the `Phrases`
 * flag and only accepts vocabularies in table format.
 *
 * Each language has a character set that contains all allowed characters for that
 * specific language. If you use unsupported characters, your custom vocabulary request
 * fails. Refer to Character Sets for Custom Vocabularies to get the character set for your
 * language.
 *
 * For more information, see Custom
 * vocabularies.
 */
export declare const createMedicalVocabulary: API.OperationMethod<CreateMedicalVocabularyRequest & RegionInput, CreateMedicalVocabularyResponse, CreateMedicalVocabularyError, Credentials | HttpClient.HttpClient>;
export type CreateVocabularyError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Creates a new custom vocabulary.
 *
 * When creating a new custom vocabulary, you can either upload a text file that contains
 * your new entries, phrases, and terms into an Amazon S3 bucket and include the
 * URI in your request. Or you can include a list of terms directly in your request using
 * the `Phrases` flag.
 *
 * Each language has a character set that contains all allowed characters for that
 * specific language. If you use unsupported characters, your custom vocabulary request
 * fails. Refer to Character Sets for Custom Vocabularies to get the character set for your
 * language.
 *
 * For more information, see Custom
 * vocabularies.
 */
export declare const createVocabulary: API.OperationMethod<CreateVocabularyRequest & RegionInput, CreateVocabularyResponse, CreateVocabularyError, Credentials | HttpClient.HttpClient>;
export type CreateVocabularyFilterError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Creates a new custom vocabulary filter.
 *
 * You can use custom vocabulary filters to mask, delete, or flag specific words from
 * your transcript. Custom vocabulary filters are commonly used to mask profanity in
 * transcripts.
 *
 * Each language has a character set that contains all allowed characters for that
 * specific language. If you use unsupported characters, your custom vocabulary filter
 * request fails. Refer to Character Sets for Custom
 * Vocabularies to get the character set for your language.
 *
 * For more information, see Vocabulary
 * filtering.
 */
export declare const createVocabularyFilter: API.OperationMethod<CreateVocabularyFilterRequest & RegionInput, CreateVocabularyFilterResponse, CreateVocabularyFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteCallAnalyticsCategoryError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes a Call Analytics category. To use this operation, specify the name of the
 * category you want to delete using `CategoryName`. Category names are case
 * sensitive.
 */
export declare const deleteCallAnalyticsCategory: API.OperationMethod<DeleteCallAnalyticsCategoryRequest & RegionInput, DeleteCallAnalyticsCategoryResponse, DeleteCallAnalyticsCategoryError, Credentials | HttpClient.HttpClient>;
export type DeleteCallAnalyticsJobError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Deletes a Call Analytics job. To use this operation, specify the name of the job you
 * want to delete using `CallAnalyticsJobName`. Job names are case
 * sensitive.
 */
export declare const deleteCallAnalyticsJob: API.OperationMethod<DeleteCallAnalyticsJobRequest & RegionInput, DeleteCallAnalyticsJobResponse, DeleteCallAnalyticsJobError, Credentials | HttpClient.HttpClient>;
export type DeleteLanguageModelError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Deletes a custom language model. To use this operation, specify the name of the
 * language model you want to delete using `ModelName`. custom language model
 * names are case sensitive.
 */
export declare const deleteLanguageModel: API.OperationMethod<DeleteLanguageModelRequest & RegionInput, DeleteLanguageModelResponse, DeleteLanguageModelError, Credentials | HttpClient.HttpClient>;
export type DeleteMedicalScribeJobError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Deletes a Medical Scribe job. To use this operation, specify the name of the
 * job you want to delete using `MedicalScribeJobName`. Job names are
 * case sensitive.
 */
export declare const deleteMedicalScribeJob: API.OperationMethod<DeleteMedicalScribeJobRequest & RegionInput, DeleteMedicalScribeJobResponse, DeleteMedicalScribeJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMedicalTranscriptionJobError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Deletes a medical transcription job. To use this operation, specify the name of the
 * job you want to delete using `MedicalTranscriptionJobName`. Job names are
 * case sensitive.
 */
export declare const deleteMedicalTranscriptionJob: API.OperationMethod<DeleteMedicalTranscriptionJobRequest & RegionInput, DeleteMedicalTranscriptionJobResponse, DeleteMedicalTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMedicalVocabularyError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes a custom medical vocabulary. To use this operation, specify the name of the
 * custom vocabulary you want to delete using `VocabularyName`. Custom
 * vocabulary names are case sensitive.
 */
export declare const deleteMedicalVocabulary: API.OperationMethod<DeleteMedicalVocabularyRequest & RegionInput, DeleteMedicalVocabularyResponse, DeleteMedicalVocabularyError, Credentials | HttpClient.HttpClient>;
export type DeleteTranscriptionJobError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Deletes a transcription job. To use this operation, specify the name of the job you
 * want to delete using `TranscriptionJobName`. Job names are case
 * sensitive.
 */
export declare const deleteTranscriptionJob: API.OperationMethod<DeleteTranscriptionJobRequest & RegionInput, DeleteTranscriptionJobResponse, DeleteTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type DeleteVocabularyError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes a custom vocabulary. To use this operation, specify the name of the custom
 * vocabulary you want to delete using `VocabularyName`. Custom vocabulary names
 * are case sensitive.
 */
export declare const deleteVocabulary: API.OperationMethod<DeleteVocabularyRequest & RegionInput, DeleteVocabularyResponse, DeleteVocabularyError, Credentials | HttpClient.HttpClient>;
export type DeleteVocabularyFilterError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes a custom vocabulary filter. To use this operation, specify the name of the
 * custom vocabulary filter you want to delete using `VocabularyFilterName`.
 * Custom vocabulary filter names are case sensitive.
 */
export declare const deleteVocabularyFilter: API.OperationMethod<DeleteVocabularyFilterRequest & RegionInput, DeleteVocabularyFilterResponse, DeleteVocabularyFilterError, Credentials | HttpClient.HttpClient>;
export type DescribeLanguageModelError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified custom language model.
 *
 * This operation also shows if the base language model that you used to create your
 * custom language model has been updated. If Amazon Transcribe has updated the base
 * model, you can create a new custom language model using the updated base model.
 *
 * If you tried to create a new custom language model and the request wasn't successful,
 * you can use `DescribeLanguageModel` to help identify the reason for this
 * failure.
 */
export declare const describeLanguageModel: API.OperationMethod<DescribeLanguageModelRequest & RegionInput, DescribeLanguageModelResponse, DescribeLanguageModelError, Credentials | HttpClient.HttpClient>;
export type GetCallAnalyticsCategoryError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified Call Analytics category.
 *
 * To get a list of your Call Analytics categories, use the operation.
 */
export declare const getCallAnalyticsCategory: API.OperationMethod<GetCallAnalyticsCategoryRequest & RegionInput, GetCallAnalyticsCategoryResponse, GetCallAnalyticsCategoryError, Credentials | HttpClient.HttpClient>;
export type GetCallAnalyticsJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified Call Analytics job.
 *
 * To view the job's status, refer to `CallAnalyticsJobStatus`. If the status
 * is `COMPLETED`, the job is finished. You can find your completed transcript
 * at the URI specified in `TranscriptFileUri`. If the status is
 * `FAILED`, `FailureReason` provides details on why your
 * transcription job failed.
 *
 * If you enabled personally identifiable information (PII) redaction, the redacted
 * transcript appears at the location specified in
 * `RedactedTranscriptFileUri`.
 *
 * If you chose to redact the audio in your media file, you can find your redacted media
 * file at the location specified in `RedactedMediaFileUri`.
 *
 * To get a list of your Call Analytics jobs, use the operation.
 */
export declare const getCallAnalyticsJob: API.OperationMethod<GetCallAnalyticsJobRequest & RegionInput, GetCallAnalyticsJobResponse, GetCallAnalyticsJobError, Credentials | HttpClient.HttpClient>;
export type GetMedicalScribeJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified Medical Scribe job.
 *
 * To view the status of the specified medical transcription job, check the
 * `MedicalScribeJobStatus` field. If the status is `COMPLETED`,
 * the job is finished. You can find the results at the location specified in
 * `MedicalScribeOutput`.
 * If the status is `FAILED`, `FailureReason` provides details on why your Medical Scribe job
 * failed.
 *
 * To get a list of your Medical Scribe jobs, use the operation.
 */
export declare const getMedicalScribeJob: API.OperationMethod<GetMedicalScribeJobRequest & RegionInput, GetMedicalScribeJobResponse, GetMedicalScribeJobError, Credentials | HttpClient.HttpClient>;
export type GetMedicalTranscriptionJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified medical transcription job.
 *
 * To view the status of the specified medical transcription job, check the
 * `TranscriptionJobStatus` field. If the status is `COMPLETED`,
 * the job is finished. You can find the results at the location specified in
 * `TranscriptFileUri`. If the status is `FAILED`,
 * `FailureReason` provides details on why your transcription job
 * failed.
 *
 * To get a list of your medical transcription jobs, use the operation.
 */
export declare const getMedicalTranscriptionJob: API.OperationMethod<GetMedicalTranscriptionJobRequest & RegionInput, GetMedicalTranscriptionJobResponse, GetMedicalTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type GetMedicalVocabularyError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified custom medical vocabulary.
 *
 * To view the status of the specified custom medical vocabulary, check the
 * `VocabularyState` field. If the status is `READY`, your custom
 * vocabulary is available to use. If the status is `FAILED`,
 * `FailureReason` provides details on why your vocabulary failed.
 *
 * To get a list of your custom medical vocabularies, use the operation.
 */
export declare const getMedicalVocabulary: API.OperationMethod<GetMedicalVocabularyRequest & RegionInput, GetMedicalVocabularyResponse, GetMedicalVocabularyError, Credentials | HttpClient.HttpClient>;
export type GetTranscriptionJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified transcription job.
 *
 * To view the status of the specified transcription job, check the
 * `TranscriptionJobStatus` field. If the status is `COMPLETED`,
 * the job is finished. You can find the results at the location specified in
 * `TranscriptFileUri`. If the status is `FAILED`,
 * `FailureReason` provides details on why your transcription job
 * failed.
 *
 * If you enabled content redaction, the redacted transcript can be found at the location
 * specified in `RedactedTranscriptFileUri`.
 *
 * To get a list of your transcription jobs, use the operation.
 */
export declare const getTranscriptionJob: API.OperationMethod<GetTranscriptionJobRequest & RegionInput, GetTranscriptionJobResponse, GetTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type GetVocabularyError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified custom vocabulary.
 *
 * To view the status of the specified custom vocabulary, check the
 * `VocabularyState` field. If the status is `READY`, your custom
 * vocabulary is available to use. If the status is `FAILED`,
 * `FailureReason` provides details on why your custom vocabulary
 * failed.
 *
 * To get a list of your custom vocabularies, use the operation.
 */
export declare const getVocabulary: API.OperationMethod<GetVocabularyRequest & RegionInput, GetVocabularyResponse, GetVocabularyError, Credentials | HttpClient.HttpClient>;
export type GetVocabularyFilterError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides information about the specified custom vocabulary filter.
 *
 * To get a list of your custom vocabulary filters, use the operation.
 */
export declare const getVocabularyFilter: API.OperationMethod<GetVocabularyFilterRequest & RegionInput, GetVocabularyFilterResponse, GetVocabularyFilterError, Credentials | HttpClient.HttpClient>;
export type ListCallAnalyticsCategoriesError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of Call Analytics categories, including all rules that make up each
 * category.
 *
 * To get detailed information about a specific Call Analytics category, use the operation.
 */
export declare const listCallAnalyticsCategories: API.PaginatedOperationMethod<ListCallAnalyticsCategoriesRequest & RegionInput, ListCallAnalyticsCategoriesResponse, ListCallAnalyticsCategoriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCallAnalyticsJobsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of Call Analytics jobs that match the specified criteria. If no
 * criteria are specified, all Call Analytics jobs are returned.
 *
 * To get detailed information about a specific Call Analytics job, use the operation.
 */
export declare const listCallAnalyticsJobs: API.PaginatedOperationMethod<ListCallAnalyticsJobsRequest & RegionInput, ListCallAnalyticsJobsResponse, ListCallAnalyticsJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLanguageModelsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of custom language models that match the specified criteria. If no
 * criteria are specified, all custom language models are returned.
 *
 * To get detailed information about a specific custom language model, use the operation.
 */
export declare const listLanguageModels: API.PaginatedOperationMethod<ListLanguageModelsRequest & RegionInput, ListLanguageModelsResponse, ListLanguageModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMedicalScribeJobsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of Medical Scribe jobs that match the specified criteria. If no
 * criteria are specified, all Medical Scribe jobs are returned.
 *
 * To get detailed information about a specific Medical Scribe job, use the operation.
 */
export declare const listMedicalScribeJobs: API.PaginatedOperationMethod<ListMedicalScribeJobsRequest & RegionInput, ListMedicalScribeJobsResponse, ListMedicalScribeJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMedicalTranscriptionJobsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of medical transcription jobs that match the specified criteria. If no
 * criteria are specified, all medical transcription jobs are returned.
 *
 * To get detailed information about a specific medical transcription job, use the operation.
 */
export declare const listMedicalTranscriptionJobs: API.PaginatedOperationMethod<ListMedicalTranscriptionJobsRequest & RegionInput, ListMedicalTranscriptionJobsResponse, ListMedicalTranscriptionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMedicalVocabulariesError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of custom medical vocabularies that match the specified criteria. If
 * no criteria are specified, all custom medical vocabularies are returned.
 *
 * To get detailed information about a specific custom medical vocabulary, use the operation.
 */
export declare const listMedicalVocabularies: API.PaginatedOperationMethod<ListMedicalVocabulariesRequest & RegionInput, ListMedicalVocabulariesResponse, ListMedicalVocabulariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Lists all tags associated with the specified transcription job, vocabulary, model, or
 * resource.
 *
 * To learn more about using tags with Amazon Transcribe, refer to Tagging
 * resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTranscriptionJobsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of transcription jobs that match the specified criteria. If no
 * criteria are specified, all transcription jobs are returned.
 *
 * To get detailed information about a specific transcription job, use the operation.
 */
export declare const listTranscriptionJobs: API.PaginatedOperationMethod<ListTranscriptionJobsRequest & RegionInput, ListTranscriptionJobsResponse, ListTranscriptionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVocabulariesError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of custom vocabularies that match the specified criteria. If no
 * criteria are specified, all custom vocabularies are returned.
 *
 * To get detailed information about a specific custom vocabulary, use the operation.
 */
export declare const listVocabularies: API.PaginatedOperationMethod<ListVocabulariesRequest & RegionInput, ListVocabulariesResponse, ListVocabulariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVocabularyFiltersError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Provides a list of custom vocabulary filters that match the specified criteria. If no
 * criteria are specified, all custom vocabularies are returned.
 *
 * To get detailed information about a specific custom vocabulary filter, use the operation.
 */
export declare const listVocabularyFilters: API.PaginatedOperationMethod<ListVocabularyFiltersRequest & RegionInput, ListVocabularyFiltersResponse, ListVocabularyFiltersError, Credentials | HttpClient.HttpClient, unknown>;
export type StartCallAnalyticsJobError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Transcribes the audio from a customer service call and applies any additional Request
 * Parameters you choose to include in your request.
 *
 * In addition to many standard transcription features, Call Analytics provides you with
 * call characteristics, call summarization, speaker sentiment, and optional redaction of
 * your text transcript and your audio file. You can also apply custom categories to flag
 * specified conditions. To learn more about these features and insights, refer to Analyzing call
 * center audio with Call Analytics.
 *
 * If you want to apply categories to your Call Analytics job, you must create them
 * before submitting your job request. Categories cannot be retroactively applied to a job.
 * To create a new category, use the
 * operation. To learn more about Call Analytics categories, see Creating categories for post-call
 * transcriptions and Creating categories for
 * real-time transcriptions.
 *
 * To make a `StartCallAnalyticsJob` request, you must first upload your media
 * file into an Amazon S3 bucket; you can then specify the Amazon S3
 * location of the file using the `Media` parameter.
 *
 * Job queuing is available for Call Analytics jobs. If you pass a `DataAccessRoleArn`
 * in your request and you exceed your Concurrent Job Limit, your job will automatically be
 * added to a queue to be processed once your concurrent job count is below the limit.
 *
 * You must include the following parameters in your `StartCallAnalyticsJob`
 * request:
 *
 * - `region`: The Amazon Web Services Region where you are making your
 * request. For a list of Amazon Web Services Regions supported with Amazon Transcribe, refer to Amazon Transcribe endpoints and
 * quotas.
 *
 * - `CallAnalyticsJobName`: A custom name that you create for your
 * transcription job that's unique within your Amazon Web Services account.
 *
 * - `Media` (`MediaFileUri` or
 * `RedactedMediaFileUri`): The Amazon S3 location of your
 * media file.
 *
 * With Call Analytics, you can redact the audio contained in your media file by
 * including `RedactedMediaFileUri`, instead of `MediaFileUri`,
 * to specify the location of your input audio. If you choose to redact your audio, you
 * can find your redacted media at the location specified in the
 * `RedactedMediaFileUri` field of your response.
 */
export declare const startCallAnalyticsJob: API.OperationMethod<StartCallAnalyticsJobRequest & RegionInput, StartCallAnalyticsJobResponse, StartCallAnalyticsJobError, Credentials | HttpClient.HttpClient>;
export type StartMedicalScribeJobError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Transcribes patient-clinician conversations and generates clinical notes.
 *
 * Amazon Web Services HealthScribe automatically provides rich conversation transcripts, identifies speaker roles,
 * classifies dialogues, extracts medical terms, and generates preliminary clinical notes.
 * To learn more about these features, refer to Amazon Web Services HealthScribe.
 *
 * To make a `StartMedicalScribeJob` request, you must first upload
 * your media file into an Amazon S3 bucket; you can then specify the Amazon S3 location
 * of the file using the `Media` parameter.
 *
 * You must include the following parameters in your
 * `StartMedicalTranscriptionJob` request:
 *
 * - `DataAccessRoleArn`: The ARN of an IAM role with the these minimum permissions: read permission on input file Amazon S3 bucket specified in `Media`,
 * write permission on the Amazon S3 bucket specified in `OutputBucketName`, and full permissions on the KMS key specified in `OutputEncryptionKMSKeyId` (if set).
 * The role should also allow `transcribe.amazonaws.com` to assume it.
 *
 * - `Media` (`MediaFileUri`): The Amazon S3 location
 * of your media file.
 *
 * - `MedicalScribeJobName`: A custom name you create for your
 * MedicalScribe job that is unique within your Amazon Web Services account.
 *
 * - `OutputBucketName`: The Amazon S3 bucket where you want
 * your output files stored.
 *
 * - `Settings`: A `MedicalScribeSettings` object
 * that must set exactly one of `ShowSpeakerLabels` or `ChannelIdentification` to true.
 * If `ShowSpeakerLabels` is true, `MaxSpeakerLabels` must also be set.
 *
 * - `ChannelDefinitions`: A `MedicalScribeChannelDefinitions` array should be set if and only if the `ChannelIdentification`
 * value of `Settings` is set to true.
 */
export declare const startMedicalScribeJob: API.OperationMethod<StartMedicalScribeJobRequest & RegionInput, StartMedicalScribeJobResponse, StartMedicalScribeJobError, Credentials | HttpClient.HttpClient>;
export type StartMedicalTranscriptionJobError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Transcribes the audio from a medical dictation or conversation and applies any
 * additional Request Parameters you choose to include in your request.
 *
 * In addition to many standard transcription features, Amazon Transcribe Medical
 * provides you with a robust medical vocabulary and, optionally, content identification,
 * which adds flags to personal health information (PHI). To learn more about these
 * features, refer to How Amazon Transcribe Medical
 * works.
 *
 * To make a `StartMedicalTranscriptionJob` request, you must first upload
 * your media file into an Amazon S3 bucket; you can then specify the Amazon S3 location
 * of the file using the `Media` parameter.
 *
 * You must include the following parameters in your
 * `StartMedicalTranscriptionJob` request:
 *
 * - `region`: The Amazon Web Services Region where you are making your
 * request. For a list of Amazon Web Services Regions supported with Amazon Transcribe, refer to Amazon Transcribe endpoints and
 * quotas.
 *
 * - `MedicalTranscriptionJobName`: A custom name you create for your
 * transcription job that is unique within your Amazon Web Services account.
 *
 * - `Media` (`MediaFileUri`): The Amazon S3 location
 * of your media file.
 *
 * - `LanguageCode`: This must be `en-US`.
 *
 * - `OutputBucketName`: The Amazon S3 bucket where you want
 * your transcript stored. If you want your output stored in a sub-folder of this
 * bucket, you must also include `OutputKey`.
 *
 * - `Specialty`: This must be `PRIMARYCARE`.
 *
 * - `Type`: Choose whether your audio is a conversation or a
 * dictation.
 */
export declare const startMedicalTranscriptionJob: API.OperationMethod<StartMedicalTranscriptionJobRequest & RegionInput, StartMedicalTranscriptionJobResponse, StartMedicalTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type StartTranscriptionJobError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Transcribes the audio from a media file and applies any additional Request Parameters
 * you choose to include in your request.
 *
 * To make a `StartTranscriptionJob` request, you must first upload your media
 * file into an Amazon S3 bucket; you can then specify the Amazon S3
 * location of the file using the `Media` parameter.
 *
 * You must include the following parameters in your `StartTranscriptionJob`
 * request:
 *
 * - `region`: The Amazon Web Services Region where you are making your
 * request. For a list of Amazon Web Services Regions supported with Amazon Transcribe, refer to Amazon Transcribe endpoints and
 * quotas.
 *
 * - `TranscriptionJobName`: A custom name you create for your
 * transcription job that is unique within your Amazon Web Services account.
 *
 * - `Media` (`MediaFileUri`): The Amazon S3 location
 * of your media file.
 *
 * - One of `LanguageCode`, `IdentifyLanguage`, or
 * `IdentifyMultipleLanguages`: If you know the language of your
 * media file, specify it using the `LanguageCode` parameter; you can
 * find all valid language codes in the Supported
 * languages table. If you do not know the languages spoken in your
 * media, use either `IdentifyLanguage` or
 * `IdentifyMultipleLanguages` and let Amazon Transcribe identify
 * the languages for you.
 */
export declare const startTranscriptionJob: API.OperationMethod<StartTranscriptionJobRequest & RegionInput, StartTranscriptionJobResponse, StartTranscriptionJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Adds one or more custom tags, each in the form of a key:value pair, to the specified
 * resource.
 *
 * To learn more about using tags with Amazon Transcribe, refer to Tagging
 * resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified Amazon Transcribe resource.
 *
 * If you include `UntagResource` in your request, you must also include
 * `ResourceArn` and `TagKeys`.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCallAnalyticsCategoryError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Updates the specified Call Analytics category with new rules. Note that the
 * `UpdateCallAnalyticsCategory` operation overwrites all existing rules
 * contained in the specified category. You cannot append additional rules onto an existing
 * category.
 *
 * To create a new category, see .
 */
export declare const updateCallAnalyticsCategory: API.OperationMethod<UpdateCallAnalyticsCategoryRequest & RegionInput, UpdateCallAnalyticsCategoryResponse, UpdateCallAnalyticsCategoryError, Credentials | HttpClient.HttpClient>;
export type UpdateLanguageModelError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Updates the encryption configuration for an existing custom language model. You can
 * use this operation to change the KMS key used to encrypt your model artifacts. The model
 * artifacts are re-encrypted in place. No model training is required.
 *
 * Your custom language model must not be in the `IN_PROGRESS` state when you
 * call this operation. You cannot submit another update while a previous update is in
 * progress. Use to check the current state of
 * your model.
 *
 * Your custom language model remains available for transcription jobs while the update
 * is being processed.
 */
export declare const updateLanguageModel: API.OperationMethod<UpdateLanguageModelRequest & RegionInput, UpdateLanguageModelResponse, UpdateLanguageModelError, Credentials | HttpClient.HttpClient>;
export type UpdateMedicalVocabularyError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Updates an existing custom medical vocabulary with new values. This operation
 * overwrites all existing information with your new values; you cannot append new terms
 * onto an existing custom vocabulary.
 */
export declare const updateMedicalVocabulary: API.OperationMethod<UpdateMedicalVocabularyRequest & RegionInput, UpdateMedicalVocabularyResponse, UpdateMedicalVocabularyError, Credentials | HttpClient.HttpClient>;
export type UpdateVocabularyError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Updates an existing custom vocabulary with new values. This operation overwrites all
 * existing information with your new values; you cannot append new terms onto an existing
 * custom vocabulary.
 *
 * Your custom vocabulary must be in a terminal state (`READY` or
 * `FAILED`) before you can update it. You must include either
 * `Phrases` or `VocabularyFileUri` in your request.
 */
export declare const updateVocabulary: API.OperationMethod<UpdateVocabularyRequest & RegionInput, UpdateVocabularyResponse, UpdateVocabularyError, Credentials | HttpClient.HttpClient>;
export type UpdateVocabularyFilterError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Updates an existing custom vocabulary filter with a new list of words. The new list
 * you provide overwrites all previous entries; you cannot append new terms onto an
 * existing custom vocabulary filter.
 *
 * You must include either `Words` or `VocabularyFilterFileUri`
 * in your request.
 */
export declare const updateVocabularyFilter: API.OperationMethod<UpdateVocabularyFilterRequest & RegionInput, UpdateVocabularyFilterResponse, UpdateVocabularyFilterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=transcribe.d.ts.map