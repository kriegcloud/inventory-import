import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidTokenException_base: S.TaggedErrorClass<"InvalidTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const SecurityIncidentResponseNotActiveException_base: S.TaggedErrorClass<"SecurityIncidentResponseNotActiveException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SecurityIncidentResponseNotActiveException extends /*@__PURE__*/ SecurityIncidentResponseNotActiveException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MembershipId = string;
export type AWSAccountId = string;
export type AWSAccountIds = string[];
export interface BatchGetMemberAccountDetailsRequest {
    membershipId: string;
    accountIds: string[];
}
export type MembershipAccountRelationshipStatus = "Associated" | "Disassociated" | "Unassociated" | (string & {});
export type MembershipAccountRelationshipType = "Organization" | "Unrelated" | (string & {});
export interface GetMembershipAccountDetailItem {
    accountId?: string | undefined;
    relationshipStatus?: MembershipAccountRelationshipStatus | undefined;
    relationshipType?: MembershipAccountRelationshipType | undefined;
}
export type GetMembershipAccountDetailItems = GetMembershipAccountDetailItem[];
export interface GetMembershipAccountDetailError {
    accountId: string;
    error: string;
    message: string;
}
export type GetMembershipAccountDetailErrors = GetMembershipAccountDetailError[];
export interface BatchGetMemberAccountDetailsResponse {
    items?: GetMembershipAccountDetailItem[] | undefined;
    errors?: GetMembershipAccountDetailError[] | undefined;
}
export interface CancelMembershipRequest {
    membershipId: string;
}
export interface CancelMembershipResponse {
    membershipId: string;
}
export type CaseId = string;
export interface CloseCaseRequest {
    caseId: string;
}
export type CaseStatus = "Submitted" | "Acknowledged" | "Detection and Analysis" | "Containment, Eradication and Recovery" | "Post-incident Activities" | "Ready to Close" | "Closed" | (string & {});
export interface CloseCaseResponse {
    caseStatus?: CaseStatus | undefined;
    closedDate?: Date | undefined;
}
export type ResolverType = "AWS" | "Self" | (string & {});
export type CaseTitle = string | redacted.Redacted<string>;
export type CaseDescription = string | redacted.Redacted<string>;
export type EngagementType = "Security Incident" | "Investigation" | (string & {});
export type ImpactedAccounts = string[];
export type EmailAddress = string | redacted.Redacted<string>;
export type PersonName = string | redacted.Redacted<string>;
export type JobTitle = string | redacted.Redacted<string>;
export interface Watcher {
    email: string | redacted.Redacted<string>;
    name?: string | redacted.Redacted<string> | undefined;
    jobTitle?: string | redacted.Redacted<string> | undefined;
}
export type Watchers = Watcher[];
export type IPAddress = string | redacted.Redacted<string>;
export type UserAgent = string;
export interface ThreatActorIp {
    ipAddress: string | redacted.Redacted<string>;
    userAgent?: string | undefined;
}
export type ThreatActorIpList = ThreatActorIp[];
export type AwsService = string;
export type ImpactedServicesList = string[];
export type AwsRegion = "af-south-1" | "ap-east-1" | "ap-east-2" | "ap-northeast-1" | "ap-northeast-2" | "ap-northeast-3" | "ap-south-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-4" | "ap-southeast-5" | "ap-southeast-6" | "ap-southeast-7" | "ca-central-1" | "ca-west-1" | "cn-north-1" | "cn-northwest-1" | "eu-central-1" | "eu-central-2" | "eu-north-1" | "eu-south-1" | "eu-south-2" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "il-central-1" | "me-central-1" | "me-south-1" | "mx-central-1" | "sa-east-1" | "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | (string & {});
export interface ImpactedAwsRegion {
    region: AwsRegion;
}
export type ImpactedAwsRegionList = ImpactedAwsRegion[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCaseRequest {
    clientToken?: string | undefined;
    resolverType: ResolverType;
    title: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    engagementType: EngagementType;
    reportedIncidentStartDate: Date;
    impactedAccounts: string[];
    watchers: Watcher[];
    threatActorIpAddresses?: ThreatActorIp[] | undefined;
    impactedServices?: string[] | undefined;
    impactedAwsRegions?: ImpactedAwsRegion[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCaseResponse {
    caseId: string;
}
export type CommentBody = string | redacted.Redacted<string>;
export interface CreateCaseCommentRequest {
    caseId: string;
    clientToken?: string | undefined;
    body: string | redacted.Redacted<string>;
}
export type CommentId = string;
export interface CreateCaseCommentResponse {
    commentId: string;
}
export type MembershipName = string | redacted.Redacted<string>;
export type IncidentResponderName = string | redacted.Redacted<string>;
export type CommunicationType = "Case Created" | "Case Updated" | "Case Acknowledged" | "Case Closed" | "Case Updated To Service Managed" | "Case Status Updated" | "Case Pending Customer Action Reminder" | "Case Attachment Url Uploaded" | "Case Comment Added" | "Case Comment Updated" | "Membership Created" | "Membership Updated" | "Membership Cancelled" | "Register Delegated Administrator" | "Deregister Delegated Administrator" | "Disable AWS Service Access" | (string & {});
export type CommunicationPreferences = CommunicationType[];
export interface IncidentResponder {
    name: string | redacted.Redacted<string>;
    jobTitle: string | redacted.Redacted<string>;
    email: string | redacted.Redacted<string>;
    communicationPreferences?: CommunicationType[] | undefined;
}
export type IncidentResponseTeam = IncidentResponder[];
export type OptInFeatureName = "Triage" | (string & {});
export interface OptInFeature {
    featureName: OptInFeatureName;
    isEnabled: boolean;
}
export type OptInFeatures = OptInFeature[];
export interface CreateMembershipRequest {
    clientToken?: string | undefined;
    membershipName: string | redacted.Redacted<string>;
    incidentResponseTeam: IncidentResponder[];
    optInFeatures?: OptInFeature[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    coverEntireOrganization?: boolean | undefined;
}
export interface CreateMembershipResponse {
    membershipId: string;
}
export interface GetCaseRequest {
    caseId: string;
}
export type CaseArn = string;
export type PendingAction = "Customer" | "None" | (string & {});
export type ClosureCode = "Investigation Completed" | "Not Resolved" | "False Positive" | "Duplicate" | (string & {});
export type AttachmentId = string;
export type FileName = string | redacted.Redacted<string>;
export type CaseAttachmentStatus = "Verified" | "Failed" | "Pending" | (string & {});
export type PrincipalId = string;
export interface CaseAttachmentAttributes {
    attachmentId: string;
    fileName: string | redacted.Redacted<string>;
    attachmentStatus: CaseAttachmentStatus;
    creator: string;
    createdDate: Date;
}
export type CaseAttachmentsList = CaseAttachmentAttributes[];
export interface CaseMetadataEntry {
    key: string;
    value: string;
}
export type CaseMetadata = CaseMetadataEntry[];
export interface GetCaseResponse {
    title?: string | redacted.Redacted<string> | undefined;
    caseArn?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    caseStatus?: CaseStatus | undefined;
    engagementType?: EngagementType | undefined;
    reportedIncidentStartDate?: Date | undefined;
    actualIncidentStartDate?: Date | undefined;
    impactedAwsRegions?: ImpactedAwsRegion[] | undefined;
    threatActorIpAddresses?: ThreatActorIp[] | undefined;
    pendingAction?: PendingAction | undefined;
    impactedAccounts?: string[] | undefined;
    watchers?: Watcher[] | undefined;
    createdDate?: Date | undefined;
    lastUpdatedDate?: Date | undefined;
    closureCode?: ClosureCode | undefined;
    resolverType?: ResolverType | undefined;
    impactedServices?: string[] | undefined;
    caseAttachments?: CaseAttachmentAttributes[] | undefined;
    closedDate?: Date | undefined;
    caseMetadata?: CaseMetadataEntry[] | undefined;
}
export interface GetCaseAttachmentDownloadUrlRequest {
    caseId: string;
    attachmentId: string;
}
export type Url = string | redacted.Redacted<string>;
export interface GetCaseAttachmentDownloadUrlResponse {
    attachmentPresignedUrl: string | redacted.Redacted<string>;
}
export type ContentLength = number;
export interface GetCaseAttachmentUploadUrlRequest {
    caseId: string;
    fileName: string | redacted.Redacted<string>;
    contentLength: number;
    clientToken?: string | undefined;
}
export interface GetCaseAttachmentUploadUrlResponse {
    attachmentPresignedUrl: string | redacted.Redacted<string>;
}
export interface GetFindingMetricsRequest {
    membershipId: string;
    startDate: Date;
    endDate: Date;
}
export interface GetFindingMetricsResponse {
    findingsIngestedSecurityHub: number;
    findingsIngestedGuardDuty: number;
    findingsTriaged: number;
    findingsTriagedFalsePositive: number;
    findingsInvestigated: number;
    findingsInvestigatedFalsePositive: number;
    findingsEscalated: number;
    findingsEscalatedFalsePositive: number;
    findingsTruePositive: number;
    findingsInvestigatedInProgress: number;
    findingsEscalatedInProgress: number;
}
export interface GetMembershipRequest {
    membershipId: string;
}
export type MembershipArn = string;
export type MembershipStatus = "Active" | "Cancelled" | "Terminated" | (string & {});
export type CustomerType = "Standalone" | "Organization" | (string & {});
export type OrganizationalUnitId = string;
export type OrganizationalUnits = string[];
export interface MembershipAccountsConfigurations {
    coverEntireOrganization?: boolean | undefined;
    organizationalUnits?: string[] | undefined;
}
export interface GetMembershipResponse {
    membershipId: string;
    accountId?: string | undefined;
    region?: AwsRegion | undefined;
    membershipName?: string | redacted.Redacted<string> | undefined;
    membershipArn?: string | undefined;
    membershipStatus?: MembershipStatus | undefined;
    membershipActivationTimestamp?: Date | undefined;
    membershipDeactivationTimestamp?: Date | undefined;
    customerType?: CustomerType | undefined;
    numberOfAccountsCovered?: number | undefined;
    incidentResponseTeam?: IncidentResponder[] | undefined;
    optInFeatures?: OptInFeature[] | undefined;
    membershipAccountsConfigurations?: MembershipAccountsConfigurations | undefined;
}
export interface ListCaseEditsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    caseId: string;
}
export type CaseEditAction = string;
export type CaseEditMessage = string;
export interface CaseEditItem {
    eventTimestamp?: Date | undefined;
    principal?: string | undefined;
    action?: string | undefined;
    message?: string | undefined;
}
export type CaseEditItems = CaseEditItem[];
export interface ListCaseEditsResponse {
    nextToken?: string | undefined;
    items?: CaseEditItem[] | undefined;
    total?: number | undefined;
}
export interface ListCasesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListCasesItem {
    caseId: string;
    lastUpdatedDate?: Date | undefined;
    title?: string | redacted.Redacted<string> | undefined;
    caseArn?: string | undefined;
    engagementType?: EngagementType | undefined;
    caseStatus?: CaseStatus | undefined;
    createdDate?: Date | undefined;
    closedDate?: Date | undefined;
    resolverType?: ResolverType | undefined;
    pendingAction?: PendingAction | undefined;
}
export type ListCasesItems = ListCasesItem[];
export interface ListCasesResponse {
    nextToken?: string | undefined;
    items?: ListCasesItem[] | undefined;
    total?: number | undefined;
}
export interface ListCommentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    caseId: string;
}
export interface ListCommentsItem {
    commentId: string;
    createdDate?: Date | undefined;
    lastUpdatedDate?: Date | undefined;
    creator?: string | undefined;
    lastUpdatedBy?: string | undefined;
    body?: string | redacted.Redacted<string> | undefined;
}
export type ListCommentsItems = ListCommentsItem[];
export interface ListCommentsResponse {
    nextToken?: string | undefined;
    items?: ListCommentsItem[] | undefined;
    total?: number | undefined;
}
export interface ListInvestigationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    caseId: string;
}
export type InvestigationId = string;
export type ActionType = "Evidence" | "Investigation" | "Summarization" | (string & {});
export type InvestigationTitle = string;
export type InvestigationContent = string;
export type ExecutionStatus = "Pending" | "InProgress" | "Waiting" | "Completed" | "Failed" | "Cancelled" | (string & {});
export type UsefulnessRating = "USEFUL" | "NOT_USEFUL" | (string & {});
export type FeedbackComment = string;
export interface InvestigationFeedback {
    usefulness?: UsefulnessRating | undefined;
    comment?: string | undefined;
    submittedAt?: Date | undefined;
}
export interface InvestigationAction {
    investigationId: string;
    actionType: ActionType;
    title: string;
    content: string;
    status: ExecutionStatus;
    lastUpdated: Date;
    feedback?: InvestigationFeedback | undefined;
}
export type InvestigationActionList = InvestigationAction[];
export interface ListInvestigationsResponse {
    nextToken?: string | undefined;
    investigationActions: InvestigationAction[];
}
export interface ListMembershipsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListMembershipItem {
    membershipId: string;
    accountId?: string | undefined;
    region?: AwsRegion | undefined;
    membershipArn?: string | undefined;
    membershipStatus?: MembershipStatus | undefined;
}
export type ListMembershipItems = ListMembershipItem[];
export interface ListMembershipsResponse {
    nextToken?: string | undefined;
    items?: ListMembershipItem[] | undefined;
}
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export type ResultId = string;
export interface SendFeedbackRequest {
    caseId: string;
    resultId: string;
    usefulness: UsefulnessRating;
    comment?: string | undefined;
}
export interface SendFeedbackResponse {
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateCaseRequest {
    caseId: string;
    title?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    reportedIncidentStartDate?: Date | undefined;
    actualIncidentStartDate?: Date | undefined;
    engagementType?: EngagementType | undefined;
    watchersToAdd?: Watcher[] | undefined;
    watchersToDelete?: Watcher[] | undefined;
    threatActorIpAddressesToAdd?: ThreatActorIp[] | undefined;
    threatActorIpAddressesToDelete?: ThreatActorIp[] | undefined;
    impactedServicesToAdd?: string[] | undefined;
    impactedServicesToDelete?: string[] | undefined;
    impactedAwsRegionsToAdd?: ImpactedAwsRegion[] | undefined;
    impactedAwsRegionsToDelete?: ImpactedAwsRegion[] | undefined;
    impactedAccountsToAdd?: string[] | undefined;
    impactedAccountsToDelete?: string[] | undefined;
    caseMetadata?: CaseMetadataEntry[] | undefined;
}
export interface UpdateCaseResponse {
}
export interface UpdateCaseCommentRequest {
    caseId: string;
    commentId: string;
    body: string | redacted.Redacted<string>;
}
export interface UpdateCaseCommentResponse {
    commentId: string;
    body?: string | redacted.Redacted<string> | undefined;
}
export type SelfManagedCaseStatus = "Submitted" | "Detection and Analysis" | "Containment, Eradication and Recovery" | "Post-incident Activities" | (string & {});
export interface UpdateCaseStatusRequest {
    caseId: string;
    caseStatus: SelfManagedCaseStatus;
}
export interface UpdateCaseStatusResponse {
    caseStatus?: SelfManagedCaseStatus | undefined;
}
export interface MembershipAccountsConfigurationsUpdate {
    coverEntireOrganization?: boolean | undefined;
    organizationalUnitsToAdd?: string[] | undefined;
    organizationalUnitsToRemove?: string[] | undefined;
}
export interface UpdateMembershipRequest {
    membershipId: string;
    membershipName?: string | redacted.Redacted<string> | undefined;
    incidentResponseTeam?: IncidentResponder[] | undefined;
    optInFeatures?: OptInFeature[] | undefined;
    membershipAccountsConfigurationsUpdate?: MembershipAccountsConfigurationsUpdate | undefined;
    undoMembershipCancellation?: boolean | undefined;
}
export interface UpdateMembershipResponse {
}
export interface UpdateResolverTypeRequest {
    caseId: string;
    resolverType: ResolverType;
}
export interface UpdateResolverTypeResponse {
    caseId: string;
    caseStatus?: CaseStatus | undefined;
    resolverType?: ResolverType | undefined;
}
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetMemberAccountDetailsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides information on whether the supplied account IDs are associated with a membership.
 *
 * AWS account ID's may appear less than 12 characters and need to be zero-prepended. An example would be `123123123` which is nine digits, and with zero-prepend would be `000123123123`. Not zero-prepending to 12 digits could result in errors.
 */
export declare const batchGetMemberAccountDetails: API.OperationMethod<BatchGetMemberAccountDetailsRequest & RegionInput, BatchGetMemberAccountDetailsResponse, BatchGetMemberAccountDetailsError, Credentials | HttpClient.HttpClient>;
export type CancelMembershipError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an existing membership.
 */
export declare const cancelMembership: API.OperationMethod<CancelMembershipRequest & RegionInput, CancelMembershipResponse, CancelMembershipError, Credentials | HttpClient.HttpClient>;
export type CloseCaseError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Closes an existing case.
 */
export declare const closeCase: API.OperationMethod<CloseCaseRequest & RegionInput, CloseCaseResponse, CloseCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new case.
 */
export declare const createCase: API.OperationMethod<CreateCaseRequest & RegionInput, CreateCaseResponse, CreateCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseCommentError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a comment to an existing case.
 */
export declare const createCaseComment: API.OperationMethod<CreateCaseCommentRequest & RegionInput, CreateCaseCommentResponse, CreateCaseCommentError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new membership.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipRequest & RegionInput, CreateMembershipResponse, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type GetCaseError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the attributes of a case.
 */
export declare const getCase: API.OperationMethod<GetCaseRequest & RegionInput, GetCaseResponse, GetCaseError, Credentials | HttpClient.HttpClient>;
export type GetCaseAttachmentDownloadUrlError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a Pre-Signed URL for uploading attachments into a case.
 */
export declare const getCaseAttachmentDownloadUrl: API.OperationMethod<GetCaseAttachmentDownloadUrlRequest & RegionInput, GetCaseAttachmentDownloadUrlResponse, GetCaseAttachmentDownloadUrlError, Credentials | HttpClient.HttpClient>;
export type GetCaseAttachmentUploadUrlError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads an attachment to a case.
 */
export declare const getCaseAttachmentUploadUrl: API.OperationMethod<GetCaseAttachmentUploadUrlRequest & RegionInput, GetCaseAttachmentUploadUrlResponse, GetCaseAttachmentUploadUrlError, Credentials | HttpClient.HttpClient>;
export type GetFindingMetricsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns finding-lifecycle metrics for a membership over a date range.
 */
export declare const getFindingMetrics: API.OperationMethod<GetFindingMetricsRequest & RegionInput, GetFindingMetricsResponse, GetFindingMetricsError, Credentials | HttpClient.HttpClient>;
export type GetMembershipError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the attributes of a membership.
 */
export declare const getMembership: API.OperationMethod<GetMembershipRequest & RegionInput, GetMembershipResponse, GetMembershipError, Credentials | HttpClient.HttpClient>;
export type ListCaseEditsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Views the case history for edits made to a designated case.
 */
export declare const listCaseEdits: API.PaginatedOperationMethod<ListCaseEditsRequest & RegionInput, ListCaseEditsResponse, ListCaseEditsError, Credentials | HttpClient.HttpClient, CaseEditItem>;
export type ListCasesError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all cases the requester has access to.
 */
export declare const listCases: API.PaginatedOperationMethod<ListCasesRequest & RegionInput, ListCasesResponse, ListCasesError, Credentials | HttpClient.HttpClient, ListCasesItem>;
export type ListCommentsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns comments for a designated case.
 */
export declare const listComments: API.PaginatedOperationMethod<ListCommentsRequest & RegionInput, ListCommentsResponse, ListCommentsError, Credentials | HttpClient.HttpClient, ListCommentsItem>;
export type ListInvestigationsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Investigation performed by an agent for a security incident...
 */
export declare const listInvestigations: API.PaginatedOperationMethod<ListInvestigationsRequest & RegionInput, ListInvestigationsResponse, ListInvestigationsError, Credentials | HttpClient.HttpClient, InvestigationAction>;
export type ListMembershipsError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the memberships that the calling principal can access.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest & RegionInput, ListMembershipsResponse, ListMembershipsError, Credentials | HttpClient.HttpClient, ListMembershipItem>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | ConflictException | InternalServerException | InvalidTokenException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Returns currently configured tags on a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SendFeedbackError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Send feedback based on response investigation action
 */
export declare const sendFeedback: API.OperationMethod<SendFeedbackRequest & RegionInput, SendFeedbackResponse, SendFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | ConflictException | InternalServerException | InvalidTokenException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds a tag(s) to a designated resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | ConflictException | InternalServerException | InvalidTokenException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Removes a tag(s) from a designate resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing case.
 */
export declare const updateCase: API.OperationMethod<UpdateCaseRequest & RegionInput, UpdateCaseResponse, UpdateCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseCommentError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing case comment.
 */
export declare const updateCaseComment: API.OperationMethod<UpdateCaseCommentRequest & RegionInput, UpdateCaseCommentResponse, UpdateCaseCommentError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseStatusError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the state transitions for a designated cases.
 *
 * **Self-managed**: the following states are available for self-managed cases.
 *
 * - Submitted -> Detection and Analysis
 *
 * - Detection and Analysis -> Containment, Eradication, and Recovery
 *
 * - Detection and Analysis -> Post-incident Activities
 *
 * - Containment, Eradication, and Recovery -> Detection and Analysis
 *
 * - Containment, Eradication, and Recovery -> Post-incident Activities
 *
 * - Post-incident Activities -> Containment, Eradication, and Recovery
 *
 * - Post-incident Activities -> Detection and Analysis
 *
 * - Any -> Closed
 *
 * **AWS supported**: You must use the `CloseCase` API to close.
 */
export declare const updateCaseStatus: API.OperationMethod<UpdateCaseStatusRequest & RegionInput, UpdateCaseStatusResponse, UpdateCaseStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateMembershipError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates membership configuration.
 */
export declare const updateMembership: API.OperationMethod<UpdateMembershipRequest & RegionInput, UpdateMembershipResponse, UpdateMembershipError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverTypeError = AccessDeniedException | ConflictException | InternalServerException | InvalidTokenException | ResourceNotFoundException | SecurityIncidentResponseNotActiveException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the resolver type for a case.
 *
 * This is a one-way action and cannot be reversed.
 */
export declare const updateResolverType: API.OperationMethod<UpdateResolverTypeRequest & RegionInput, UpdateResolverTypeResponse, UpdateResolverTypeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=security-ir.d.ts.map