import * as API from "@distilled.cloud/core/api";
import type { ConfigError, InvalidInput } from "@distilled.cloud/core/errors";
import { TooManyRequests } from "@distilled.cloud/core/errors";
import { type RestErrorInfo } from "@distilled.cloud/core/protocol-rest";
import type { SdkError } from "@distilled.cloud/core/sdk-error";
import * as Duration from "effect/Duration";
import type * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import * as Layer from "effect/Layer";
import { Credentials } from "./credentials.ts";
import { type DefaultErrors } from "./errors.ts";
/**
 * The REST API version the generated services were built from -- sent on
 * every request so GitHub never silently serves a newer, differently-shaped
 * payload. Bump it together with a regeneration.
 */
export declare const API_VERSION = "2022-11-28";
/**
 * Error channel shared by every generated GitHub operation. Generated service
 * files annotate operations with `API.OperationMethod<I, O, GithubOpError,
 * GithubOpContext>` explicitly so the compiler never infers these back out of
 * the schema generics.
 */
export type GithubOpError = DefaultErrors | ConfigError | HttpClientError.HttpClientError | InvalidInput | SdkError;
/** Context (requirements) shared by every generated GitHub operation. */
export type GithubOpContext = Credentials | HttpClient.HttpClient;
/**
 * A rate-limited response, read the way GitHub documents it
 * (https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#exceeding-the-rate-limit):
 * a 403 or 429 with `retry-after`, with `x-ratelimit-remaining: 0`, or whose
 * message names a rate limit (a secondary limit can come back with no
 * headers). The wait is `retry-after`, else the time until
 * `x-ratelimit-reset`, else a minute. Any other 403 is a permission refusal.
 */
export declare const rateLimited: (info: RestErrorInfo) => TooManyRequests | undefined;
/**
 * Space POST, PATCH, PUT and DELETE requests at least `interval` apart
 * (default one second) for every GitHub call below this layer. GitHub asks
 * clients that make many such requests to wait a second between them, and
 * answers bursts with secondary rate limits
 * (https://docs.github.com/rest/using-the-rest-api/best-practices-for-using-the-rest-api#pause-between-mutative-requests).
 * Reads are not paced. Each layer build keeps its own schedule.
 *
 * @example
 * ```ts
 * program.pipe(Effect.provide(GitHub.paceWrites()));
 * ```
 */
export declare const paceWrites: (options?: {
    readonly interval?: Duration.Input;
}) => Layer.Layer<never>;
export declare const GithubProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map