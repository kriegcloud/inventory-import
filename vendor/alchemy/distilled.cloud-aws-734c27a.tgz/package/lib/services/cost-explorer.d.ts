import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AnalysisNotFoundException_base: S.TaggedErrorClass<"AnalysisNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AnalysisNotFoundException extends /*@__PURE__*/ AnalysisNotFoundException_base {
}
declare const AnomalyMonitorAlreadyExists_base: S.TaggedErrorClass<"AnomalyMonitorAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AnomalyMonitorAlreadyExists extends /*@__PURE__*/ AnomalyMonitorAlreadyExists_base {
}
declare const AnomalySubscriptionAlreadyExists_base: S.TaggedErrorClass<"AnomalySubscriptionAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AnomalySubscriptionAlreadyExists extends /*@__PURE__*/ AnomalySubscriptionAlreadyExists_base {
}
declare const BackfillLimitExceededException_base: S.TaggedErrorClass<"BackfillLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BackfillLimitExceededException extends /*@__PURE__*/ BackfillLimitExceededException_base {
}
declare const BillExpirationException_base: S.TaggedErrorClass<"BillExpirationException", {
    readonly message: any;
}>;
export declare class BillExpirationException extends /*@__PURE__*/ BillExpirationException_base {
}
declare const BillingViewHealthStatusException_base: S.TaggedErrorClass<"BillingViewHealthStatusException", {
    readonly message: any;
}>;
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const DataUnavailableException_base: S.TaggedErrorClass<"DataUnavailableException", {
    readonly message: any;
}>;
export declare class DataUnavailableException extends /*@__PURE__*/ DataUnavailableException_base {
}
declare const GenerationExistsException_base: S.TaggedErrorClass<"GenerationExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GenerationExistsException extends /*@__PURE__*/ GenerationExistsException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const RequestChangedException_base: S.TaggedErrorClass<"RequestChangedException", {
    readonly message: any;
}>;
export declare class RequestChangedException extends /*@__PURE__*/ RequestChangedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RightsizingRecommendationNotEnabled_base: S.TaggedErrorClass<"RightsizingRecommendationNotEnabled", {
    readonly message: any;
}>;
export declare class RightsizingRecommendationNotEnabled extends /*@__PURE__*/ RightsizingRecommendationNotEnabled_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnknownMonitorException_base: S.TaggedErrorClass<"UnknownMonitorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownMonitorException extends /*@__PURE__*/ UnknownMonitorException_base {
}
declare const UnknownSubscriptionException_base: S.TaggedErrorClass<"UnknownSubscriptionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownSubscriptionException extends /*@__PURE__*/ UnknownSubscriptionException_base {
}
declare const UnresolvableUsageUnitException_base: S.TaggedErrorClass<"UnresolvableUsageUnitException", {
    readonly message: any;
}>;
export declare class UnresolvableUsageUnitException extends /*@__PURE__*/ UnresolvableUsageUnitException_base {
}
export type YearMonthDay = string;
export type MonitorType = "DIMENSIONAL" | "CUSTOM" | (string & {});
export type MonitorDimension = "SERVICE" | "LINKED_ACCOUNT" | "TAG" | "COST_CATEGORY" | (string & {});
export type Expressions = Expression[];
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "PAYER_ACCOUNT" | "LINKED_ACCOUNT_NAME" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "SERVICE_CODE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "OPERATING_SYSTEM" | "TENANCY" | "SCOPE" | "PLATFORM" | "SUBSCRIPTION_ID" | "LEGAL_ENTITY_NAME" | "DEPLOYMENT_OPTION" | "DATABASE_ENGINE" | "CACHE_ENGINE" | "INSTANCE_TYPE_FAMILY" | "BILLING_ENTITY" | "RESERVATION_ID" | "RESOURCE_ID" | "RIGHTSIZING_TYPE" | "SAVINGS_PLANS_TYPE" | "SAVINGS_PLAN_ARN" | "PAYMENT_OPTION" | "AGREEMENT_END_DATE_TIME_AFTER" | "AGREEMENT_END_DATE_TIME_BEFORE" | "INVOICING_ENTITY" | "ANOMALY_TOTAL_IMPACT_ABSOLUTE" | "ANOMALY_TOTAL_IMPACT_PERCENTAGE" | "PRODUCT_ATTRIBUTE" | (string & {});
export type Value = string;
export type Values = string[];
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | "GREATER_THAN_OR_EQUAL" | (string & {});
export type MatchOptions = MatchOption[];
export interface DimensionValues {
    Key?: Dimension | undefined;
    Values?: string[] | undefined;
    MatchOptions?: MatchOption[] | undefined;
}
export type TagKey = string;
export interface TagValues {
    Key?: string | undefined;
    Values?: string[] | undefined;
    MatchOptions?: MatchOption[] | undefined;
}
export type CostCategoryName = string;
export interface CostCategoryValues {
    Key?: string | undefined;
    Values?: string[] | undefined;
    MatchOptions?: MatchOption[] | undefined;
}
export type ProductAttributeName = string;
export type ProductAttributeValueList = string[];
export interface ProductAttributeValues {
    Key: string;
    Values?: string[] | undefined;
    MatchOptions?: MatchOption[] | undefined;
}
export interface Expression {
    Or?: Expression[] | undefined;
    And?: Expression[] | undefined;
    Not?: Expression | undefined;
    Dimensions?: DimensionValues | undefined;
    Tags?: TagValues | undefined;
    CostCategories?: CostCategoryValues | undefined;
    ProductAttributes?: ProductAttributeValues | undefined;
}
export type NonNegativeInteger = number;
export interface AnomalyMonitor {
    MonitorArn?: string | undefined;
    MonitorName: string;
    CreationDate?: string | undefined;
    LastUpdatedDate?: string | undefined;
    LastEvaluatedDate?: string | undefined;
    MonitorType: MonitorType;
    MonitorDimension?: MonitorDimension | undefined;
    MonitorSpecification?: Expression | undefined;
    DimensionalValueCount?: number | undefined;
}
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export type ResourceTagList = ResourceTag[];
export interface CreateAnomalyMonitorRequest {
    AnomalyMonitor: AnomalyMonitor;
    ResourceTags?: ResourceTag[] | undefined;
}
export interface CreateAnomalyMonitorResponse {
    MonitorArn: string;
}
export type Arn = string;
export type MonitorArnList = string[];
export type SubscriberAddress = string;
export type SubscriberType = "EMAIL" | "SNS" | (string & {});
export type SubscriberStatus = "CONFIRMED" | "DECLINED" | (string & {});
export interface Subscriber {
    Address?: string | undefined;
    Type?: SubscriberType | undefined;
    Status?: SubscriberStatus | undefined;
}
export type Subscribers = Subscriber[];
export type NullableNonNegativeDouble = number;
export type AnomalySubscriptionFrequency = "DAILY" | "IMMEDIATE" | "WEEKLY" | (string & {});
export interface AnomalySubscription {
    SubscriptionArn?: string | undefined;
    AccountId?: string | undefined;
    MonitorArnList: string[];
    Subscribers: Subscriber[];
    Threshold?: number | undefined;
    Frequency: AnomalySubscriptionFrequency;
    SubscriptionName: string;
    ThresholdExpression?: Expression | undefined;
}
export interface CreateAnomalySubscriptionRequest {
    AnomalySubscription: AnomalySubscription;
    ResourceTags?: ResourceTag[] | undefined;
}
export interface CreateAnomalySubscriptionResponse {
    SubscriptionArn: string;
}
export type ZonedDateTime = string;
export type CostCategoryRuleVersion = "CostCategoryExpression.v1" | (string & {});
export type CostCategoryValue = string;
export type CostCategoryInheritedValueDimensionName = "LINKED_ACCOUNT_NAME" | "TAG" | (string & {});
export interface CostCategoryInheritedValueDimension {
    DimensionName?: CostCategoryInheritedValueDimensionName | undefined;
    DimensionKey?: string | undefined;
}
export type CostCategoryRuleType = "REGULAR" | "INHERITED_VALUE" | (string & {});
export interface CostCategoryRule {
    Value?: string | undefined;
    Rule?: Expression | undefined;
    InheritedValue?: CostCategoryInheritedValueDimension | undefined;
    Type?: CostCategoryRuleType | undefined;
}
export type CostCategoryRulesList = CostCategoryRule[];
export type CostCategorySplitChargeRuleTargetsList = string[];
export type CostCategorySplitChargeMethod = "FIXED" | "PROPORTIONAL" | "EVEN" | (string & {});
export type CostCategorySplitChargeRuleParameterType = "ALLOCATION_PERCENTAGES" | (string & {});
export type CostCategorySplitChargeRuleParameterValuesList = string[];
export interface CostCategorySplitChargeRuleParameter {
    Type: CostCategorySplitChargeRuleParameterType;
    Values: string[];
}
export type CostCategorySplitChargeRuleParametersList = CostCategorySplitChargeRuleParameter[];
export interface CostCategorySplitChargeRule {
    Source: string;
    Targets: string[];
    Method: CostCategorySplitChargeMethod;
    Parameters?: CostCategorySplitChargeRuleParameter[] | undefined;
}
export type CostCategorySplitChargeRulesList = CostCategorySplitChargeRule[];
export interface CreateCostCategoryDefinitionRequest {
    Name: string;
    EffectiveStart?: string | undefined;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    DefaultValue?: string | undefined;
    SplitChargeRules?: CostCategorySplitChargeRule[] | undefined;
    ResourceTags?: ResourceTag[] | undefined;
}
export interface CreateCostCategoryDefinitionResponse {
    CostCategoryArn?: string | undefined;
    EffectiveStart?: string | undefined;
}
export interface DeleteAnomalyMonitorRequest {
    MonitorArn: string;
}
export interface DeleteAnomalyMonitorResponse {
}
export interface DeleteAnomalySubscriptionRequest {
    SubscriptionArn: string;
}
export interface DeleteAnomalySubscriptionResponse {
}
export interface DeleteCostCategoryDefinitionRequest {
    CostCategoryArn: string;
}
export interface DeleteCostCategoryDefinitionResponse {
    CostCategoryArn?: string | undefined;
    EffectiveEnd?: string | undefined;
}
export interface DescribeCostCategoryDefinitionRequest {
    CostCategoryArn: string;
    EffectiveOn?: string | undefined;
}
export type CostCategoryStatusComponent = "COST_EXPLORER" | (string & {});
export type CostCategoryStatus = "PROCESSING" | "APPLIED" | (string & {});
export interface CostCategoryProcessingStatus {
    Component?: CostCategoryStatusComponent | undefined;
    Status?: CostCategoryStatus | undefined;
}
export type CostCategoryProcessingStatusList = CostCategoryProcessingStatus[];
export interface CostCategory {
    CostCategoryArn: string;
    EffectiveStart: string;
    EffectiveEnd?: string | undefined;
    Name: string;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    SplitChargeRules?: CostCategorySplitChargeRule[] | undefined;
    ProcessingStatus?: CostCategoryProcessingStatus[] | undefined;
    DefaultValue?: string | undefined;
}
export interface DescribeCostCategoryDefinitionResponse {
    CostCategory?: CostCategory | undefined;
}
export interface AnomalyDateInterval {
    StartDate: string;
    EndDate?: string | undefined;
}
export type AnomalyFeedbackType = "YES" | "NO" | "PLANNED_ACTIVITY" | (string & {});
export type NumericOperator = "EQUAL" | "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "GREATER_THAN" | "LESS_THAN" | "BETWEEN" | (string & {});
export interface TotalImpactFilter {
    NumericOperator: NumericOperator;
    StartValue: number;
    EndValue?: number | undefined;
}
export type NextPageToken = string;
export type PageSize = number;
export interface GetAnomaliesRequest {
    MonitorArn?: string | undefined;
    DateInterval: AnomalyDateInterval;
    Feedback?: AnomalyFeedbackType | undefined;
    TotalImpact?: TotalImpactFilter | undefined;
    NextPageToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RootCauseImpact {
    Contribution: number;
}
export interface RootCause {
    Service?: string | undefined;
    Region?: string | undefined;
    LinkedAccount?: string | undefined;
    LinkedAccountName?: string | undefined;
    UsageType?: string | undefined;
    Impact?: RootCauseImpact | undefined;
}
export type RootCauses = RootCause[];
export interface AnomalyScore {
    MaxScore: number;
    CurrentScore: number;
}
export interface Impact {
    MaxImpact: number;
    TotalImpact?: number | undefined;
    TotalActualSpend?: number | undefined;
    TotalExpectedSpend?: number | undefined;
    TotalImpactPercentage?: number | undefined;
}
export interface Anomaly {
    AnomalyId: string;
    AnomalyStartDate?: string | undefined;
    AnomalyEndDate?: string | undefined;
    DimensionValue?: string | undefined;
    RootCauses?: RootCause[] | undefined;
    AnomalyScore: AnomalyScore;
    Impact: Impact;
    MonitorArn: string;
    Feedback?: AnomalyFeedbackType | undefined;
}
export type Anomalies = Anomaly[];
export interface GetAnomaliesResponse {
    Anomalies: Anomaly[];
    NextPageToken?: string | undefined;
}
export interface GetAnomalyMonitorsRequest {
    MonitorArnList?: string[] | undefined;
    NextPageToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AnomalyMonitors = AnomalyMonitor[];
export interface GetAnomalyMonitorsResponse {
    AnomalyMonitors: AnomalyMonitor[];
    NextPageToken?: string | undefined;
}
export interface GetAnomalySubscriptionsRequest {
    SubscriptionArnList?: string[] | undefined;
    MonitorArn?: string | undefined;
    NextPageToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AnomalySubscriptions = AnomalySubscription[];
export interface GetAnomalySubscriptionsResponse {
    AnomalySubscriptions: AnomalySubscription[];
    NextPageToken?: string | undefined;
}
export type Granularity = "DAILY" | "MONTHLY" | "HOURLY" | (string & {});
export type UsageServices = string[];
export type ApproximationDimension = "SERVICE" | "RESOURCE" | (string & {});
export interface GetApproximateUsageRecordsRequest {
    Granularity: Granularity;
    Services?: string[] | undefined;
    ApproximationDimension: ApproximationDimension;
}
export type NonNegativeLong = number;
export type ApproximateUsageRecordsPerService = {
    [key: string]: number | undefined;
};
export interface DateInterval {
    Start: string;
    End: string;
}
export interface GetApproximateUsageRecordsResponse {
    Services?: {
        [key: string]: number | undefined;
    } | undefined;
    TotalRecords?: number | undefined;
    LookbackPeriod?: DateInterval | undefined;
}
export type AnalysisId = string;
export interface GetCommitmentPurchaseAnalysisRequest {
    AnalysisId: string;
}
export type AnalysisStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export type ErrorCode = "NO_USAGE_FOUND" | "INTERNAL_FAILURE" | "INVALID_SAVINGS_PLANS_TO_ADD" | "INVALID_SAVINGS_PLANS_TO_EXCLUDE" | "INVALID_ACCOUNT_ID" | (string & {});
export interface RecommendationDetailHourlyMetrics {
    StartTime?: string | undefined;
    EstimatedOnDemandCost?: string | undefined;
    CurrentCoverage?: string | undefined;
    EstimatedCoverage?: string | undefined;
    EstimatedNewCommitmentUtilization?: string | undefined;
}
export type MetricsOverLookbackPeriod = RecommendationDetailHourlyMetrics[];
export interface SavingsPlansPurchaseAnalysisDetails {
    CurrencyCode?: string | undefined;
    LookbackPeriodInHours?: string | undefined;
    CurrentAverageCoverage?: string | undefined;
    CurrentAverageHourlyOnDemandSpend?: string | undefined;
    CurrentMaximumHourlyOnDemandSpend?: string | undefined;
    CurrentMinimumHourlyOnDemandSpend?: string | undefined;
    CurrentOnDemandSpend?: string | undefined;
    ExistingHourlyCommitment?: string | undefined;
    HourlyCommitmentToPurchase?: string | undefined;
    EstimatedAverageCoverage?: string | undefined;
    EstimatedAverageUtilization?: string | undefined;
    EstimatedMonthlySavingsAmount?: string | undefined;
    EstimatedOnDemandCost?: string | undefined;
    EstimatedOnDemandCostWithCurrentCommitment?: string | undefined;
    EstimatedROI?: string | undefined;
    EstimatedSavingsAmount?: string | undefined;
    EstimatedSavingsPercentage?: string | undefined;
    EstimatedCommitmentCost?: string | undefined;
    LatestUsageTimestamp?: string | undefined;
    UpfrontCost?: string | undefined;
    AdditionalMetadata?: string | undefined;
    MetricsOverLookbackPeriod?: RecommendationDetailHourlyMetrics[] | undefined;
}
export interface AnalysisDetails {
    SavingsPlansPurchaseAnalysisDetails?: SavingsPlansPurchaseAnalysisDetails | undefined;
}
export type AccountScope = "PAYER" | "LINKED" | (string & {});
export type AccountId = string;
export type AnalysisType = "MAX_SAVINGS" | "CUSTOM_COMMITMENT" | "TARGET_AVERAGE_COVERAGE" | (string & {});
export type PaymentOption = "NO_UPFRONT" | "PARTIAL_UPFRONT" | "ALL_UPFRONT" | "LIGHT_UTILIZATION" | "MEDIUM_UTILIZATION" | "HEAVY_UTILIZATION" | (string & {});
export type SupportedSavingsPlansType = "COMPUTE_SP" | "EC2_INSTANCE_SP" | "SAGEMAKER_SP" | "DATABASE_SP" | (string & {});
export type TermInYears = "ONE_YEAR" | "THREE_YEARS" | (string & {});
export type SavingsPlansCommitment = number;
export interface SavingsPlans {
    PaymentOption?: PaymentOption | undefined;
    SavingsPlansType?: SupportedSavingsPlansType | undefined;
    Region?: string | undefined;
    InstanceFamily?: string | undefined;
    TermInYears?: TermInYears | undefined;
    SavingsPlansCommitment?: number | undefined;
    OfferingId?: string | undefined;
}
export type SavingsPlansToAdd = SavingsPlans[];
export type SavingsPlansId = string;
export type SavingsPlansToExclude = string[];
export type SavingsPlansTargetCoverage = number;
export interface SavingsPlansPurchaseAnalysisConfiguration {
    AccountScope?: AccountScope | undefined;
    AccountId?: string | undefined;
    AnalysisType: AnalysisType;
    SavingsPlansToAdd: SavingsPlans[];
    SavingsPlansToExclude?: string[] | undefined;
    LookBackTimePeriod: DateInterval;
    SavingsPlansTargetCoverage?: number | undefined;
}
export interface CommitmentPurchaseAnalysisConfiguration {
    SavingsPlansPurchaseAnalysisConfiguration?: SavingsPlansPurchaseAnalysisConfiguration | undefined;
}
export interface GetCommitmentPurchaseAnalysisResponse {
    EstimatedCompletionTime: string;
    AnalysisCompletionTime?: string | undefined;
    AnalysisStartedTime: string;
    AnalysisId: string;
    AnalysisStatus: AnalysisStatus;
    ErrorCode?: ErrorCode | undefined;
    AnalysisDetails?: AnalysisDetails | undefined;
    CommitmentPurchaseAnalysisConfiguration: CommitmentPurchaseAnalysisConfiguration;
}
export type MetricName = string;
export type MetricNames = string[];
export type GroupDefinitionType = "DIMENSION" | "TAG" | "COST_CATEGORY" | "PRODUCT_ATTRIBUTE" | (string & {});
export type GroupDefinitionKey = string;
export interface GroupDefinition {
    Type?: GroupDefinitionType | undefined;
    Key?: string | undefined;
}
export type GroupDefinitions = GroupDefinition[];
export type BillingViewArn = string;
export interface GetCostAndUsageRequest {
    TimePeriod: DateInterval;
    Granularity: Granularity;
    Filter?: Expression | undefined;
    Metrics: string[];
    GroupBy?: GroupDefinition[] | undefined;
    BillingViewArn?: string | undefined;
    NextPageToken?: string | undefined;
}
export type MetricAmount = string;
export type MetricUnit = string;
export interface MetricValue {
    Amount?: string | undefined;
    Unit?: string | undefined;
}
export type Metrics = {
    [key: string]: MetricValue | undefined;
};
export type Key = string;
export type Keys = string[];
export interface Group {
    Keys?: string[] | undefined;
    Metrics?: {
        [key: string]: MetricValue | undefined;
    } | undefined;
}
export type Groups = Group[];
export type Estimated = boolean;
export interface ResultByTime {
    TimePeriod?: DateInterval | undefined;
    Total?: {
        [key: string]: MetricValue | undefined;
    } | undefined;
    Groups?: Group[] | undefined;
    Estimated?: boolean | undefined;
}
export type ResultsByTime = ResultByTime[];
export type AttributeType = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export interface DimensionValuesWithAttributes {
    Value?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DimensionValuesWithAttributesList = DimensionValuesWithAttributes[];
export interface GetCostAndUsageResponse {
    NextPageToken?: string | undefined;
    GroupDefinitions?: GroupDefinition[] | undefined;
    ResultsByTime?: ResultByTime[] | undefined;
    DimensionValueAttributes?: DimensionValuesWithAttributes[] | undefined;
}
export type CostAndUsageComparisonsMaxResults = number;
export interface GetCostAndUsageComparisonsRequest {
    BillingViewArn?: string | undefined;
    BaselineTimePeriod: DateInterval;
    ComparisonTimePeriod: DateInterval;
    MetricForComparison: string;
    Filter?: Expression | undefined;
    GroupBy?: GroupDefinition[] | undefined;
    MaxResults?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface ComparisonMetricValue {
    BaselineTimePeriodAmount?: string | undefined;
    ComparisonTimePeriodAmount?: string | undefined;
    Difference?: string | undefined;
    Unit?: string | undefined;
}
export type ComparisonMetrics = {
    [key: string]: ComparisonMetricValue | undefined;
};
export interface CostAndUsageComparison {
    CostAndUsageSelector?: Expression | undefined;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    } | undefined;
}
export type CostAndUsageComparisons = CostAndUsageComparison[];
export interface GetCostAndUsageComparisonsResponse {
    CostAndUsageComparisons?: CostAndUsageComparison[] | undefined;
    TotalCostAndUsage?: {
        [key: string]: ComparisonMetricValue | undefined;
    } | undefined;
    NextPageToken?: string | undefined;
}
export interface GetCostAndUsageWithResourcesRequest {
    TimePeriod: DateInterval;
    Granularity: Granularity;
    Filter: Expression;
    Metrics?: string[] | undefined;
    GroupBy?: GroupDefinition[] | undefined;
    BillingViewArn?: string | undefined;
    NextPageToken?: string | undefined;
}
export interface GetCostAndUsageWithResourcesResponse {
    NextPageToken?: string | undefined;
    GroupDefinitions?: GroupDefinition[] | undefined;
    ResultsByTime?: ResultByTime[] | undefined;
    DimensionValueAttributes?: DimensionValuesWithAttributes[] | undefined;
}
export type SearchString = string;
export type SortDefinitionKey = string;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface SortDefinition {
    Key: string;
    SortOrder?: SortOrder | undefined;
}
export type SortDefinitions = SortDefinition[];
export type MaxResults = number;
export interface GetCostCategoriesRequest {
    SearchString?: string | undefined;
    TimePeriod: DateInterval;
    CostCategoryName?: string | undefined;
    Filter?: Expression | undefined;
    SortBy?: SortDefinition[] | undefined;
    BillingViewArn?: string | undefined;
    MaxResults?: number | undefined;
    NextPageToken?: string | undefined;
}
export type CostCategoryNamesList = string[];
export type CostCategoryValuesList = string[];
export interface GetCostCategoriesResponse {
    NextPageToken?: string | undefined;
    CostCategoryNames?: string[] | undefined;
    CostCategoryValues?: string[] | undefined;
    ReturnSize: number;
    TotalSize: number;
}
export type CostComparisonDriversMaxResults = number;
export interface GetCostComparisonDriversRequest {
    BillingViewArn?: string | undefined;
    BaselineTimePeriod: DateInterval;
    ComparisonTimePeriod: DateInterval;
    MetricForComparison: string;
    Filter?: Expression | undefined;
    GroupBy?: GroupDefinition[] | undefined;
    MaxResults?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface CostDriver {
    Type?: string | undefined;
    Name?: string | undefined;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    } | undefined;
}
export type CostDrivers = CostDriver[];
export interface CostComparisonDriver {
    CostSelector?: Expression | undefined;
    Metrics?: {
        [key: string]: ComparisonMetricValue | undefined;
    } | undefined;
    CostDrivers?: CostDriver[] | undefined;
}
export type CostComparisonDrivers = CostComparisonDriver[];
export interface GetCostComparisonDriversResponse {
    CostComparisonDrivers?: CostComparisonDriver[] | undefined;
    NextPageToken?: string | undefined;
}
export type Metric = "BLENDED_COST" | "UNBLENDED_COST" | "AMORTIZED_COST" | "NET_UNBLENDED_COST" | "NET_AMORTIZED_COST" | "USAGE_QUANTITY" | "NORMALIZED_USAGE_AMOUNT" | (string & {});
export type PredictionIntervalLevel = number;
export interface GetCostForecastRequest {
    TimePeriod: DateInterval;
    Metric: Metric;
    Granularity: Granularity;
    Filter?: Expression | undefined;
    BillingViewArn?: string | undefined;
    PredictionIntervalLevel?: number | undefined;
}
export interface ForecastResult {
    TimePeriod?: DateInterval | undefined;
    MeanValue?: string | undefined;
    PredictionIntervalLowerBound?: string | undefined;
    PredictionIntervalUpperBound?: string | undefined;
}
export type ForecastResultsByTime = ForecastResult[];
export interface GetCostForecastResponse {
    Total?: MetricValue | undefined;
    ForecastResultsByTime?: ForecastResult[] | undefined;
}
export type DimensionKey = string;
export type Context = "COST_AND_USAGE" | "RESERVATIONS" | "SAVINGS_PLANS" | (string & {});
export interface GetDimensionValuesRequest {
    SearchString?: string | undefined;
    TimePeriod: DateInterval;
    Dimension: Dimension;
    DimensionKey?: string | undefined;
    Context?: Context | undefined;
    Filter?: Expression | undefined;
    SortBy?: SortDefinition[] | undefined;
    BillingViewArn?: string | undefined;
    MaxResults?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface GetDimensionValuesResponse {
    DimensionValues: DimensionValuesWithAttributes[];
    ReturnSize: number;
    TotalSize: number;
    NextPageToken?: string | undefined;
}
export interface GetReservationCoverageRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[] | undefined;
    Granularity?: Granularity | undefined;
    Filter?: Expression | undefined;
    Metrics?: string[] | undefined;
    NextPageToken?: string | undefined;
    SortBy?: SortDefinition | undefined;
    MaxResults?: number | undefined;
}
export type OnDemandHours = string;
export type ReservedHours = string;
export type TotalRunningHours = string;
export type CoverageHoursPercentage = string;
export interface CoverageHours {
    OnDemandHours?: string | undefined;
    ReservedHours?: string | undefined;
    TotalRunningHours?: string | undefined;
    CoverageHoursPercentage?: string | undefined;
}
export type OnDemandNormalizedUnits = string;
export type ReservedNormalizedUnits = string;
export type TotalRunningNormalizedUnits = string;
export type CoverageNormalizedUnitsPercentage = string;
export interface CoverageNormalizedUnits {
    OnDemandNormalizedUnits?: string | undefined;
    ReservedNormalizedUnits?: string | undefined;
    TotalRunningNormalizedUnits?: string | undefined;
    CoverageNormalizedUnitsPercentage?: string | undefined;
}
export type OnDemandCost = string;
export interface CoverageCost {
    OnDemandCost?: string | undefined;
}
export interface Coverage {
    CoverageHours?: CoverageHours | undefined;
    CoverageNormalizedUnits?: CoverageNormalizedUnits | undefined;
    CoverageCost?: CoverageCost | undefined;
}
export interface ReservationCoverageGroup {
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Coverage?: Coverage | undefined;
}
export type ReservationCoverageGroups = ReservationCoverageGroup[];
export interface CoverageByTime {
    TimePeriod?: DateInterval | undefined;
    Groups?: ReservationCoverageGroup[] | undefined;
    Total?: Coverage | undefined;
}
export type CoveragesByTime = CoverageByTime[];
export interface GetReservationCoverageResponse {
    CoveragesByTime: CoverageByTime[];
    Total?: Coverage | undefined;
    NextPageToken?: string | undefined;
}
export type LookbackPeriodInDays = "SEVEN_DAYS" | "THIRTY_DAYS" | "SIXTY_DAYS" | (string & {});
export type OfferingClass = "STANDARD" | "CONVERTIBLE" | (string & {});
export interface EC2Specification {
    OfferingClass?: OfferingClass | undefined;
}
export interface ServiceSpecification {
    EC2Specification?: EC2Specification | undefined;
}
export type RecommendationsPageSize = number;
export interface GetReservationPurchaseRecommendationRequest {
    AccountId?: string | undefined;
    Service: string;
    Filter?: Expression | undefined;
    AccountScope?: AccountScope | undefined;
    LookbackPeriodInDays?: LookbackPeriodInDays | undefined;
    TermInYears?: TermInYears | undefined;
    PaymentOption?: PaymentOption | undefined;
    ServiceSpecification?: ServiceSpecification | undefined;
    PageSize?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface ReservationPurchaseRecommendationMetadata {
    RecommendationId?: string | undefined;
    GenerationTimestamp?: string | undefined;
    AdditionalMetadata?: string | undefined;
}
export interface EC2InstanceDetails {
    Family?: string | undefined;
    InstanceType?: string | undefined;
    Region?: string | undefined;
    AvailabilityZone?: string | undefined;
    Platform?: string | undefined;
    Tenancy?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
}
export interface RDSInstanceDetails {
    Family?: string | undefined;
    InstanceType?: string | undefined;
    Region?: string | undefined;
    DatabaseEngine?: string | undefined;
    DatabaseEdition?: string | undefined;
    DeploymentOption?: string | undefined;
    LicenseModel?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
    DeploymentModel?: string | undefined;
}
export interface RedshiftInstanceDetails {
    Family?: string | undefined;
    NodeType?: string | undefined;
    Region?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
}
export interface ElastiCacheInstanceDetails {
    Family?: string | undefined;
    NodeType?: string | undefined;
    Region?: string | undefined;
    ProductDescription?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
}
export interface ESInstanceDetails {
    InstanceClass?: string | undefined;
    InstanceSize?: string | undefined;
    Region?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
}
export interface MemoryDBInstanceDetails {
    Family?: string | undefined;
    NodeType?: string | undefined;
    Region?: string | undefined;
    CurrentGeneration?: boolean | undefined;
    SizeFlexEligible?: boolean | undefined;
}
export interface InstanceDetails {
    EC2InstanceDetails?: EC2InstanceDetails | undefined;
    RDSInstanceDetails?: RDSInstanceDetails | undefined;
    RedshiftInstanceDetails?: RedshiftInstanceDetails | undefined;
    ElastiCacheInstanceDetails?: ElastiCacheInstanceDetails | undefined;
    ESInstanceDetails?: ESInstanceDetails | undefined;
    MemoryDBInstanceDetails?: MemoryDBInstanceDetails | undefined;
}
export interface DynamoDBCapacityDetails {
    CapacityUnits?: string | undefined;
    Region?: string | undefined;
}
export interface ReservedCapacityDetails {
    DynamoDBCapacityDetails?: DynamoDBCapacityDetails | undefined;
}
export interface ReservationPurchaseRecommendationDetail {
    AccountId?: string | undefined;
    InstanceDetails?: InstanceDetails | undefined;
    RecommendedNumberOfInstancesToPurchase?: string | undefined;
    RecommendedNormalizedUnitsToPurchase?: string | undefined;
    MinimumNumberOfInstancesUsedPerHour?: string | undefined;
    MinimumNormalizedUnitsUsedPerHour?: string | undefined;
    MaximumNumberOfInstancesUsedPerHour?: string | undefined;
    MaximumNormalizedUnitsUsedPerHour?: string | undefined;
    AverageNumberOfInstancesUsedPerHour?: string | undefined;
    AverageNormalizedUnitsUsedPerHour?: string | undefined;
    AverageUtilization?: string | undefined;
    EstimatedBreakEvenInMonths?: string | undefined;
    CurrencyCode?: string | undefined;
    EstimatedMonthlySavingsAmount?: string | undefined;
    EstimatedMonthlySavingsPercentage?: string | undefined;
    EstimatedMonthlyOnDemandCost?: string | undefined;
    EstimatedReservationCostForLookbackPeriod?: string | undefined;
    UpfrontCost?: string | undefined;
    RecurringStandardMonthlyCost?: string | undefined;
    ReservedCapacityDetails?: ReservedCapacityDetails | undefined;
    RecommendedNumberOfCapacityUnitsToPurchase?: string | undefined;
    MinimumNumberOfCapacityUnitsUsedPerHour?: string | undefined;
    MaximumNumberOfCapacityUnitsUsedPerHour?: string | undefined;
    AverageNumberOfCapacityUnitsUsedPerHour?: string | undefined;
}
export type ReservationPurchaseRecommendationDetails = ReservationPurchaseRecommendationDetail[];
export interface ReservationPurchaseRecommendationSummary {
    TotalEstimatedMonthlySavingsAmount?: string | undefined;
    TotalEstimatedMonthlySavingsPercentage?: string | undefined;
    CurrencyCode?: string | undefined;
}
export interface ReservationPurchaseRecommendation {
    AccountScope?: AccountScope | undefined;
    LookbackPeriodInDays?: LookbackPeriodInDays | undefined;
    TermInYears?: TermInYears | undefined;
    PaymentOption?: PaymentOption | undefined;
    ServiceSpecification?: ServiceSpecification | undefined;
    RecommendationDetails?: ReservationPurchaseRecommendationDetail[] | undefined;
    RecommendationSummary?: ReservationPurchaseRecommendationSummary | undefined;
}
export type ReservationPurchaseRecommendations = ReservationPurchaseRecommendation[];
export interface GetReservationPurchaseRecommendationResponse {
    Metadata?: ReservationPurchaseRecommendationMetadata | undefined;
    Recommendations?: ReservationPurchaseRecommendation[] | undefined;
    NextPageToken?: string | undefined;
}
export interface GetReservationUtilizationRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[] | undefined;
    Granularity?: Granularity | undefined;
    Filter?: Expression | undefined;
    SortBy?: SortDefinition | undefined;
    NextPageToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ReservationGroupKey = string;
export type ReservationGroupValue = string;
export type UtilizationPercentage = string;
export type UtilizationPercentageInUnits = string;
export type PurchasedHours = string;
export type PurchasedUnits = string;
export type TotalActualHours = string;
export type TotalActualUnits = string;
export type UnusedHours = string;
export type UnusedUnits = string;
export type OnDemandCostOfRIHoursUsed = string;
export type NetRISavings = string;
export type TotalPotentialRISavings = string;
export type AmortizedUpfrontFee = string;
export type AmortizedRecurringFee = string;
export type TotalAmortizedFee = string;
export type RICostForUnusedHours = string;
export type RealizedSavings = string;
export type UnrealizedSavings = string;
export interface ReservationAggregates {
    UtilizationPercentage?: string | undefined;
    UtilizationPercentageInUnits?: string | undefined;
    PurchasedHours?: string | undefined;
    PurchasedUnits?: string | undefined;
    TotalActualHours?: string | undefined;
    TotalActualUnits?: string | undefined;
    UnusedHours?: string | undefined;
    UnusedUnits?: string | undefined;
    OnDemandCostOfRIHoursUsed?: string | undefined;
    NetRISavings?: string | undefined;
    TotalPotentialRISavings?: string | undefined;
    AmortizedUpfrontFee?: string | undefined;
    AmortizedRecurringFee?: string | undefined;
    TotalAmortizedFee?: string | undefined;
    RICostForUnusedHours?: string | undefined;
    RealizedSavings?: string | undefined;
    UnrealizedSavings?: string | undefined;
}
export interface ReservationUtilizationGroup {
    Key?: string | undefined;
    Value?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Utilization?: ReservationAggregates | undefined;
}
export type ReservationUtilizationGroups = ReservationUtilizationGroup[];
export interface UtilizationByTime {
    TimePeriod?: DateInterval | undefined;
    Groups?: ReservationUtilizationGroup[] | undefined;
    Total?: ReservationAggregates | undefined;
}
export type UtilizationsByTime = UtilizationByTime[];
export interface GetReservationUtilizationResponse {
    UtilizationsByTime: UtilizationByTime[];
    Total?: ReservationAggregates | undefined;
    NextPageToken?: string | undefined;
}
export type RecommendationTarget = "SAME_INSTANCE_FAMILY" | "CROSS_INSTANCE_FAMILY" | (string & {});
export interface RightsizingRecommendationConfiguration {
    RecommendationTarget: RecommendationTarget;
    BenefitsConsidered: boolean;
}
export interface GetRightsizingRecommendationRequest {
    Filter?: Expression | undefined;
    Configuration?: RightsizingRecommendationConfiguration | undefined;
    Service: string;
    PageSize?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface RightsizingRecommendationMetadata {
    RecommendationId?: string | undefined;
    GenerationTimestamp?: string | undefined;
    LookbackPeriodInDays?: LookbackPeriodInDays | undefined;
    AdditionalMetadata?: string | undefined;
}
export interface RightsizingRecommendationSummary {
    TotalRecommendationCount?: string | undefined;
    EstimatedTotalMonthlySavingsAmount?: string | undefined;
    SavingsCurrencyCode?: string | undefined;
    SavingsPercentage?: string | undefined;
}
export type TagValuesList = TagValues[];
export interface EC2ResourceDetails {
    HourlyOnDemandRate?: string | undefined;
    InstanceType?: string | undefined;
    Platform?: string | undefined;
    Region?: string | undefined;
    Sku?: string | undefined;
    Memory?: string | undefined;
    NetworkPerformance?: string | undefined;
    Storage?: string | undefined;
    Vcpu?: string | undefined;
}
export interface ResourceDetails {
    EC2ResourceDetails?: EC2ResourceDetails | undefined;
}
export interface EBSResourceUtilization {
    EbsReadOpsPerSecond?: string | undefined;
    EbsWriteOpsPerSecond?: string | undefined;
    EbsReadBytesPerSecond?: string | undefined;
    EbsWriteBytesPerSecond?: string | undefined;
}
export interface DiskResourceUtilization {
    DiskReadOpsPerSecond?: string | undefined;
    DiskWriteOpsPerSecond?: string | undefined;
    DiskReadBytesPerSecond?: string | undefined;
    DiskWriteBytesPerSecond?: string | undefined;
}
export interface NetworkResourceUtilization {
    NetworkInBytesPerSecond?: string | undefined;
    NetworkOutBytesPerSecond?: string | undefined;
    NetworkPacketsInPerSecond?: string | undefined;
    NetworkPacketsOutPerSecond?: string | undefined;
}
export interface EC2ResourceUtilization {
    MaxCpuUtilizationPercentage?: string | undefined;
    MaxMemoryUtilizationPercentage?: string | undefined;
    MaxStorageUtilizationPercentage?: string | undefined;
    EBSResourceUtilization?: EBSResourceUtilization | undefined;
    DiskResourceUtilization?: DiskResourceUtilization | undefined;
    NetworkResourceUtilization?: NetworkResourceUtilization | undefined;
}
export interface ResourceUtilization {
    EC2ResourceUtilization?: EC2ResourceUtilization | undefined;
}
export interface CurrentInstance {
    ResourceId?: string | undefined;
    InstanceName?: string | undefined;
    Tags?: TagValues[] | undefined;
    ResourceDetails?: ResourceDetails | undefined;
    ResourceUtilization?: ResourceUtilization | undefined;
    ReservationCoveredHoursInLookbackPeriod?: string | undefined;
    SavingsPlansCoveredHoursInLookbackPeriod?: string | undefined;
    OnDemandHoursInLookbackPeriod?: string | undefined;
    TotalRunningHoursInLookbackPeriod?: string | undefined;
    MonthlyCost?: string | undefined;
    CurrencyCode?: string | undefined;
}
export type RightsizingType = "TERMINATE" | "MODIFY" | (string & {});
export type PlatformDifference = "HYPERVISOR" | "NETWORK_INTERFACE" | "STORAGE_INTERFACE" | "INSTANCE_STORE_AVAILABILITY" | "VIRTUALIZATION_TYPE" | (string & {});
export type PlatformDifferences = PlatformDifference[];
export interface TargetInstance {
    EstimatedMonthlyCost?: string | undefined;
    EstimatedMonthlySavings?: string | undefined;
    CurrencyCode?: string | undefined;
    DefaultTargetInstance?: boolean | undefined;
    ResourceDetails?: ResourceDetails | undefined;
    ExpectedResourceUtilization?: ResourceUtilization | undefined;
    PlatformDifferences?: PlatformDifference[] | undefined;
}
export type TargetInstancesList = TargetInstance[];
export interface ModifyRecommendationDetail {
    TargetInstances?: TargetInstance[] | undefined;
}
export interface TerminateRecommendationDetail {
    EstimatedMonthlySavings?: string | undefined;
    CurrencyCode?: string | undefined;
}
export type FindingReasonCode = "CPU_OVER_PROVISIONED" | "CPU_UNDER_PROVISIONED" | "MEMORY_OVER_PROVISIONED" | "MEMORY_UNDER_PROVISIONED" | "EBS_THROUGHPUT_OVER_PROVISIONED" | "EBS_THROUGHPUT_UNDER_PROVISIONED" | "EBS_IOPS_OVER_PROVISIONED" | "EBS_IOPS_UNDER_PROVISIONED" | "NETWORK_BANDWIDTH_OVER_PROVISIONED" | "NETWORK_BANDWIDTH_UNDER_PROVISIONED" | "NETWORK_PPS_OVER_PROVISIONED" | "NETWORK_PPS_UNDER_PROVISIONED" | "DISK_IOPS_OVER_PROVISIONED" | "DISK_IOPS_UNDER_PROVISIONED" | "DISK_THROUGHPUT_OVER_PROVISIONED" | "DISK_THROUGHPUT_UNDER_PROVISIONED" | (string & {});
export type FindingReasonCodes = FindingReasonCode[];
export interface RightsizingRecommendation {
    AccountId?: string | undefined;
    CurrentInstance?: CurrentInstance | undefined;
    RightsizingType?: RightsizingType | undefined;
    ModifyRecommendationDetail?: ModifyRecommendationDetail | undefined;
    TerminateRecommendationDetail?: TerminateRecommendationDetail | undefined;
    FindingReasonCodes?: FindingReasonCode[] | undefined;
}
export type RightsizingRecommendationList = RightsizingRecommendation[];
export interface GetRightsizingRecommendationResponse {
    Metadata?: RightsizingRecommendationMetadata | undefined;
    Summary?: RightsizingRecommendationSummary | undefined;
    RightsizingRecommendations?: RightsizingRecommendation[] | undefined;
    NextPageToken?: string | undefined;
    Configuration?: RightsizingRecommendationConfiguration | undefined;
}
export type RecommendationDetailId = string;
export interface GetSavingsPlanPurchaseRecommendationDetailsRequest {
    RecommendationDetailId: string;
}
export interface RecommendationDetailData {
    AccountScope?: AccountScope | undefined;
    LookbackPeriodInDays?: LookbackPeriodInDays | undefined;
    SavingsPlansType?: SupportedSavingsPlansType | undefined;
    TermInYears?: TermInYears | undefined;
    PaymentOption?: PaymentOption | undefined;
    AccountId?: string | undefined;
    CurrencyCode?: string | undefined;
    InstanceFamily?: string | undefined;
    Region?: string | undefined;
    OfferingId?: string | undefined;
    GenerationTimestamp?: string | undefined;
    LatestUsageTimestamp?: string | undefined;
    CurrentAverageHourlyOnDemandSpend?: string | undefined;
    CurrentMaximumHourlyOnDemandSpend?: string | undefined;
    CurrentMinimumHourlyOnDemandSpend?: string | undefined;
    EstimatedAverageUtilization?: string | undefined;
    EstimatedMonthlySavingsAmount?: string | undefined;
    EstimatedOnDemandCost?: string | undefined;
    EstimatedOnDemandCostWithCurrentCommitment?: string | undefined;
    EstimatedROI?: string | undefined;
    EstimatedSPCost?: string | undefined;
    EstimatedSavingsAmount?: string | undefined;
    EstimatedSavingsPercentage?: string | undefined;
    ExistingHourlyCommitment?: string | undefined;
    HourlyCommitmentToPurchase?: string | undefined;
    UpfrontCost?: string | undefined;
    CurrentAverageCoverage?: string | undefined;
    EstimatedAverageCoverage?: string | undefined;
    MetricsOverLookbackPeriod?: RecommendationDetailHourlyMetrics[] | undefined;
}
export interface GetSavingsPlanPurchaseRecommendationDetailsResponse {
    RecommendationDetailId?: string | undefined;
    RecommendationDetailData?: RecommendationDetailData | undefined;
}
export interface GetSavingsPlansCoverageRequest {
    TimePeriod: DateInterval;
    GroupBy?: GroupDefinition[] | undefined;
    Granularity?: Granularity | undefined;
    Filter?: Expression | undefined;
    Metrics?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortBy?: SortDefinition | undefined;
}
export interface SavingsPlansCoverageData {
    SpendCoveredBySavingsPlans?: string | undefined;
    OnDemandCost?: string | undefined;
    TotalCost?: string | undefined;
    CoveragePercentage?: string | undefined;
}
export interface SavingsPlansCoverage {
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Coverage?: SavingsPlansCoverageData | undefined;
    TimePeriod?: DateInterval | undefined;
}
export type SavingsPlansCoverages = SavingsPlansCoverage[];
export interface GetSavingsPlansCoverageResponse {
    SavingsPlansCoverages: SavingsPlansCoverage[];
    NextToken?: string | undefined;
}
export interface GetSavingsPlansPurchaseRecommendationRequest {
    SavingsPlansType: SupportedSavingsPlansType;
    TermInYears: TermInYears;
    PaymentOption: PaymentOption;
    AccountScope?: AccountScope | undefined;
    NextPageToken?: string | undefined;
    PageSize?: number | undefined;
    LookbackPeriodInDays: LookbackPeriodInDays;
    Filter?: Expression | undefined;
}
export interface SavingsPlansPurchaseRecommendationMetadata {
    RecommendationId?: string | undefined;
    GenerationTimestamp?: string | undefined;
    AdditionalMetadata?: string | undefined;
}
export interface SavingsPlansDetails {
    Region?: string | undefined;
    InstanceFamily?: string | undefined;
    OfferingId?: string | undefined;
}
export interface SavingsPlansPurchaseRecommendationDetail {
    SavingsPlansDetails?: SavingsPlansDetails | undefined;
    AccountId?: string | undefined;
    UpfrontCost?: string | undefined;
    EstimatedROI?: string | undefined;
    CurrencyCode?: string | undefined;
    EstimatedSPCost?: string | undefined;
    EstimatedOnDemandCost?: string | undefined;
    EstimatedOnDemandCostWithCurrentCommitment?: string | undefined;
    EstimatedSavingsAmount?: string | undefined;
    EstimatedSavingsPercentage?: string | undefined;
    HourlyCommitmentToPurchase?: string | undefined;
    EstimatedAverageUtilization?: string | undefined;
    EstimatedMonthlySavingsAmount?: string | undefined;
    CurrentMinimumHourlyOnDemandSpend?: string | undefined;
    CurrentMaximumHourlyOnDemandSpend?: string | undefined;
    CurrentAverageHourlyOnDemandSpend?: string | undefined;
    RecommendationDetailId?: string | undefined;
}
export type SavingsPlansPurchaseRecommendationDetailList = SavingsPlansPurchaseRecommendationDetail[];
export interface SavingsPlansPurchaseRecommendationSummary {
    EstimatedROI?: string | undefined;
    CurrencyCode?: string | undefined;
    EstimatedTotalCost?: string | undefined;
    CurrentOnDemandSpend?: string | undefined;
    EstimatedSavingsAmount?: string | undefined;
    TotalRecommendationCount?: string | undefined;
    DailyCommitmentToPurchase?: string | undefined;
    HourlyCommitmentToPurchase?: string | undefined;
    EstimatedSavingsPercentage?: string | undefined;
    EstimatedMonthlySavingsAmount?: string | undefined;
    EstimatedOnDemandCostWithCurrentCommitment?: string | undefined;
}
export interface SavingsPlansPurchaseRecommendation {
    AccountScope?: AccountScope | undefined;
    SavingsPlansType?: SupportedSavingsPlansType | undefined;
    TermInYears?: TermInYears | undefined;
    PaymentOption?: PaymentOption | undefined;
    LookbackPeriodInDays?: LookbackPeriodInDays | undefined;
    SavingsPlansPurchaseRecommendationDetails?: SavingsPlansPurchaseRecommendationDetail[] | undefined;
    SavingsPlansPurchaseRecommendationSummary?: SavingsPlansPurchaseRecommendationSummary | undefined;
}
export interface GetSavingsPlansPurchaseRecommendationResponse {
    Metadata?: SavingsPlansPurchaseRecommendationMetadata | undefined;
    SavingsPlansPurchaseRecommendation?: SavingsPlansPurchaseRecommendation | undefined;
    NextPageToken?: string | undefined;
}
export interface GetSavingsPlansUtilizationRequest {
    TimePeriod: DateInterval;
    Granularity?: Granularity | undefined;
    Filter?: Expression | undefined;
    SortBy?: SortDefinition | undefined;
}
export interface SavingsPlansUtilization {
    TotalCommitment?: string | undefined;
    UsedCommitment?: string | undefined;
    UnusedCommitment?: string | undefined;
    UtilizationPercentage?: string | undefined;
}
export interface SavingsPlansSavings {
    NetSavings?: string | undefined;
    OnDemandCostEquivalent?: string | undefined;
}
export interface SavingsPlansAmortizedCommitment {
    AmortizedRecurringCommitment?: string | undefined;
    AmortizedUpfrontCommitment?: string | undefined;
    TotalAmortizedCommitment?: string | undefined;
}
export interface SavingsPlansUtilizationByTime {
    TimePeriod: DateInterval;
    Utilization: SavingsPlansUtilization;
    Savings?: SavingsPlansSavings | undefined;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment | undefined;
}
export type SavingsPlansUtilizationsByTime = SavingsPlansUtilizationByTime[];
export interface SavingsPlansUtilizationAggregates {
    Utilization: SavingsPlansUtilization;
    Savings?: SavingsPlansSavings | undefined;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment | undefined;
}
export interface GetSavingsPlansUtilizationResponse {
    SavingsPlansUtilizationsByTime?: SavingsPlansUtilizationByTime[] | undefined;
    Total: SavingsPlansUtilizationAggregates;
}
export type SavingsPlansDataType = "ATTRIBUTES" | "UTILIZATION" | "AMORTIZED_COMMITMENT" | "SAVINGS" | (string & {});
export type SavingsPlansDataTypes = SavingsPlansDataType[];
export interface GetSavingsPlansUtilizationDetailsRequest {
    TimePeriod: DateInterval;
    Filter?: Expression | undefined;
    DataType?: SavingsPlansDataType[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SortBy?: SortDefinition | undefined;
}
export type SavingsPlanArn = string;
export interface SavingsPlansUtilizationDetail {
    SavingsPlanArn?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    Utilization?: SavingsPlansUtilization | undefined;
    Savings?: SavingsPlansSavings | undefined;
    AmortizedCommitment?: SavingsPlansAmortizedCommitment | undefined;
}
export type SavingsPlansUtilizationDetails = SavingsPlansUtilizationDetail[];
export interface GetSavingsPlansUtilizationDetailsResponse {
    SavingsPlansUtilizationDetails: SavingsPlansUtilizationDetail[];
    Total?: SavingsPlansUtilizationAggregates | undefined;
    TimePeriod: DateInterval;
    NextToken?: string | undefined;
}
export interface GetTagsRequest {
    SearchString?: string | undefined;
    TimePeriod: DateInterval;
    TagKey?: string | undefined;
    Filter?: Expression | undefined;
    SortBy?: SortDefinition[] | undefined;
    BillingViewArn?: string | undefined;
    MaxResults?: number | undefined;
    NextPageToken?: string | undefined;
}
export type Entity = string;
export type TagList = string[];
export interface GetTagsResponse {
    NextPageToken?: string | undefined;
    Tags: string[];
    ReturnSize: number;
    TotalSize: number;
}
export interface GetUsageForecastRequest {
    TimePeriod: DateInterval;
    Metric: Metric;
    Granularity: Granularity;
    Filter?: Expression | undefined;
    BillingViewArn?: string | undefined;
    PredictionIntervalLevel?: number | undefined;
}
export interface GetUsageForecastResponse {
    Total?: MetricValue | undefined;
    ForecastResultsByTime?: ForecastResult[] | undefined;
}
export type AnalysesPageSize = number;
export type AnalysisIds = string[];
export interface ListCommitmentPurchaseAnalysesRequest {
    AnalysisStatus?: AnalysisStatus | undefined;
    NextPageToken?: string | undefined;
    PageSize?: number | undefined;
    AnalysisIds?: string[] | undefined;
}
export interface AnalysisSummary {
    EstimatedCompletionTime?: string | undefined;
    AnalysisCompletionTime?: string | undefined;
    AnalysisStartedTime?: string | undefined;
    AnalysisStatus?: AnalysisStatus | undefined;
    ErrorCode?: ErrorCode | undefined;
    AnalysisId?: string | undefined;
    CommitmentPurchaseAnalysisConfiguration?: CommitmentPurchaseAnalysisConfiguration | undefined;
}
export type AnalysisSummaryList = AnalysisSummary[];
export interface ListCommitmentPurchaseAnalysesResponse {
    AnalysisSummaryList?: AnalysisSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export type CostAllocationTagsMaxResults = number;
export interface ListCostAllocationTagBackfillHistoryRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type CostAllocationTagBackfillStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export interface CostAllocationTagBackfillRequest {
    BackfillFrom?: string | undefined;
    RequestedAt?: string | undefined;
    CompletedAt?: string | undefined;
    BackfillStatus?: CostAllocationTagBackfillStatus | undefined;
    LastUpdatedAt?: string | undefined;
}
export type CostAllocationTagBackfillRequestList = CostAllocationTagBackfillRequest[];
export interface ListCostAllocationTagBackfillHistoryResponse {
    BackfillRequests?: CostAllocationTagBackfillRequest[] | undefined;
    NextToken?: string | undefined;
}
export type CostAllocationTagStatus = "Active" | "Inactive" | (string & {});
export type CostAllocationTagKeyList = string[];
export type CostAllocationTagType = "AWSGenerated" | "UserDefined" | (string & {});
export interface ListCostAllocationTagsRequest {
    Status?: CostAllocationTagStatus | undefined;
    TagKeys?: string[] | undefined;
    Type?: CostAllocationTagType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface CostAllocationTag {
    TagKey: string;
    Type: CostAllocationTagType;
    Status: CostAllocationTagStatus;
    LastUpdatedDate?: string | undefined;
    LastUsedDate?: string | undefined;
}
export type CostAllocationTagList = CostAllocationTag[];
export interface ListCostAllocationTagsResponse {
    CostAllocationTags?: CostAllocationTag[] | undefined;
    NextToken?: string | undefined;
}
export type CostCategoryMaxResults = number;
export type ResourceType = string;
export type ResourceTypesFilterInput = string[];
export interface ListCostCategoryDefinitionsRequest {
    EffectiveOn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    SupportedResourceTypes?: string[] | undefined;
}
export type ResourceTypes = string[];
export interface CostCategoryReference {
    CostCategoryArn?: string | undefined;
    Name?: string | undefined;
    EffectiveStart?: string | undefined;
    EffectiveEnd?: string | undefined;
    NumberOfRules?: number | undefined;
    ProcessingStatus?: CostCategoryProcessingStatus[] | undefined;
    Values?: string[] | undefined;
    DefaultValue?: string | undefined;
    SupportedResourceTypes?: string[] | undefined;
}
export type CostCategoryReferencesList = CostCategoryReference[];
export interface ListCostCategoryDefinitionsResponse {
    CostCategoryReferences?: CostCategoryReference[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCostCategoryResourceAssociationsRequest {
    CostCategoryArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type GenericArn = string;
export interface CostCategoryResourceAssociation {
    ResourceArn?: string | undefined;
    CostCategoryName?: string | undefined;
    CostCategoryArn?: string | undefined;
}
export type CostCategoryResourceAssociations = CostCategoryResourceAssociation[];
export interface ListCostCategoryResourceAssociationsResponse {
    CostCategoryResourceAssociations?: CostCategoryResourceAssociation[] | undefined;
    NextToken?: string | undefined;
}
export type GenerationStatus = "SUCCEEDED" | "PROCESSING" | "FAILED" | (string & {});
export type RecommendationId = string;
export type RecommendationIdList = string[];
export interface ListSavingsPlansPurchaseRecommendationGenerationRequest {
    GenerationStatus?: GenerationStatus | undefined;
    RecommendationIds?: string[] | undefined;
    PageSize?: number | undefined;
    NextPageToken?: string | undefined;
}
export interface GenerationSummary {
    RecommendationId?: string | undefined;
    GenerationStatus?: GenerationStatus | undefined;
    GenerationStartedTime?: string | undefined;
    GenerationCompletionTime?: string | undefined;
    EstimatedCompletionTime?: string | undefined;
}
export type GenerationSummaryList = GenerationSummary[];
export interface ListSavingsPlansPurchaseRecommendationGenerationResponse {
    GenerationSummaryList?: GenerationSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[] | undefined;
}
export interface ProvideAnomalyFeedbackRequest {
    AnomalyId: string;
    Feedback: AnomalyFeedbackType;
}
export interface ProvideAnomalyFeedbackResponse {
    AnomalyId: string;
}
export interface StartCommitmentPurchaseAnalysisRequest {
    CommitmentPurchaseAnalysisConfiguration: CommitmentPurchaseAnalysisConfiguration;
}
export interface StartCommitmentPurchaseAnalysisResponse {
    AnalysisId: string;
    AnalysisStartedTime: string;
    EstimatedCompletionTime: string;
}
export interface StartCostAllocationTagBackfillRequest {
    BackfillFrom: string;
}
export interface StartCostAllocationTagBackfillResponse {
    BackfillRequest?: CostAllocationTagBackfillRequest | undefined;
}
export interface StartSavingsPlansPurchaseRecommendationGenerationRequest {
}
export interface StartSavingsPlansPurchaseRecommendationGenerationResponse {
    RecommendationId?: string | undefined;
    GenerationStartedTime?: string | undefined;
    EstimatedCompletionTime?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    ResourceTags: ResourceTag[];
}
export interface TagResourceResponse {
}
export type ResourceTagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    ResourceTagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAnomalyMonitorRequest {
    MonitorArn: string;
    MonitorName?: string | undefined;
}
export interface UpdateAnomalyMonitorResponse {
    MonitorArn: string;
}
export interface UpdateAnomalySubscriptionRequest {
    SubscriptionArn: string;
    Threshold?: number | undefined;
    Frequency?: AnomalySubscriptionFrequency | undefined;
    MonitorArnList?: string[] | undefined;
    Subscribers?: Subscriber[] | undefined;
    SubscriptionName?: string | undefined;
    ThresholdExpression?: Expression | undefined;
}
export interface UpdateAnomalySubscriptionResponse {
    SubscriptionArn: string;
}
export interface CostAllocationTagStatusEntry {
    TagKey: string;
    Status: CostAllocationTagStatus;
}
export type CostAllocationTagStatusList = CostAllocationTagStatusEntry[];
export interface UpdateCostAllocationTagsStatusRequest {
    CostAllocationTagsStatus: CostAllocationTagStatusEntry[];
}
export type ErrorMessage = string;
export interface UpdateCostAllocationTagsStatusError_ {
    TagKey?: string | undefined;
    Code?: string | undefined;
    Message?: string | undefined;
}
export type UpdateCostAllocationTagsStatusErrors = UpdateCostAllocationTagsStatusError_[];
export interface UpdateCostAllocationTagsStatusResponse {
    Errors?: UpdateCostAllocationTagsStatusError_[] | undefined;
}
export interface UpdateCostCategoryDefinitionRequest {
    CostCategoryArn: string;
    EffectiveStart?: string | undefined;
    RuleVersion: CostCategoryRuleVersion;
    Rules: CostCategoryRule[];
    DefaultValue?: string | undefined;
    SplitChargeRules?: CostCategorySplitChargeRule[] | undefined;
}
export interface UpdateCostCategoryDefinitionResponse {
    CostCategoryArn?: string | undefined;
    EffectiveStart?: string | undefined;
}
export type CreateAnomalyMonitorError = LimitExceededException | AnomalyMonitorAlreadyExists | CommonErrors;
/**
 * Creates a new cost anomaly detection monitor with the requested type and monitor
 * specification.
 */
export declare const createAnomalyMonitor: API.OperationMethod<CreateAnomalyMonitorRequest & RegionInput, CreateAnomalyMonitorResponse, CreateAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type CreateAnomalySubscriptionError = LimitExceededException | UnknownMonitorException | AnomalySubscriptionAlreadyExists | CommonErrors;
/**
 * Adds an alert subscription to a cost anomaly detection monitor. You can use each
 * subscription to define subscribers with email or SNS notifications. Email subscribers can set
 * an absolute or percentage threshold and a time frequency for receiving notifications.
 */
export declare const createAnomalySubscription: API.OperationMethod<CreateAnomalySubscriptionRequest & RegionInput, CreateAnomalySubscriptionResponse, CreateAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateCostCategoryDefinitionError = LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new cost category with the requested name and rules.
 */
export declare const createCostCategoryDefinition: API.OperationMethod<CreateCostCategoryDefinitionRequest & RegionInput, CreateCostCategoryDefinitionResponse, CreateCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalyMonitorError = LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Deletes a cost anomaly monitor.
 */
export declare const deleteAnomalyMonitor: API.OperationMethod<DeleteAnomalyMonitorRequest & RegionInput, DeleteAnomalyMonitorResponse, DeleteAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalySubscriptionError = LimitExceededException | UnknownSubscriptionException | CommonErrors;
/**
 * Deletes a cost anomaly subscription.
 */
export declare const deleteAnomalySubscription: API.OperationMethod<DeleteAnomalySubscriptionRequest & RegionInput, DeleteAnomalySubscriptionResponse, DeleteAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a cost category. Expenses from this month going forward will no longer be
 * categorized with this cost category.
 */
export declare const deleteCostCategoryDefinition: API.OperationMethod<DeleteCostCategoryDefinitionRequest & RegionInput, DeleteCostCategoryDefinitionResponse, DeleteCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the name, Amazon Resource Name (ARN), rules, definition, and effective dates of a
 * cost category that's defined in the account.
 *
 * You have the option to use `EffectiveOn` to return a cost category that's
 * active on a specific date. If there's no `EffectiveOn` specified, you see a Cost
 * Category that's effective on the current date. If cost category is still effective,
 * `EffectiveEnd` is omitted in the response.
 */
export declare const describeCostCategoryDefinition: API.OperationMethod<DescribeCostCategoryDefinitionRequest & RegionInput, DescribeCostCategoryDefinitionResponse, DescribeCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetAnomaliesError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves all of the cost anomalies detected on your account during the time period that's
 * specified by the `DateInterval` object. Anomalies are available for up to 90
 * days.
 */
export declare const getAnomalies: API.PaginatedOperationMethod<GetAnomaliesRequest & RegionInput, GetAnomaliesResponse, GetAnomaliesError, Credentials | HttpClient.HttpClient, Anomaly>;
export type GetAnomalyMonitorsError = InvalidNextTokenException | LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Retrieves the cost anomaly monitor definitions for your account. You can filter using a
 * list of cost anomaly monitor Amazon Resource Names (ARNs).
 */
export declare const getAnomalyMonitors: API.PaginatedOperationMethod<GetAnomalyMonitorsRequest & RegionInput, GetAnomalyMonitorsResponse, GetAnomalyMonitorsError, Credentials | HttpClient.HttpClient, AnomalyMonitor>;
export type GetAnomalySubscriptionsError = InvalidNextTokenException | LimitExceededException | UnknownSubscriptionException | CommonErrors;
/**
 * Retrieves the cost anomaly subscription objects for your account. You can filter using a
 * list of cost anomaly monitor Amazon Resource Names (ARNs).
 */
export declare const getAnomalySubscriptions: API.PaginatedOperationMethod<GetAnomalySubscriptionsRequest & RegionInput, GetAnomalySubscriptionsResponse, GetAnomalySubscriptionsError, Credentials | HttpClient.HttpClient, AnomalySubscription>;
export type GetApproximateUsageRecordsError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves estimated usage records for hourly granularity or resource-level data at daily
 * granularity.
 */
export declare const getApproximateUsageRecords: API.OperationMethod<GetApproximateUsageRecordsRequest & RegionInput, GetApproximateUsageRecordsResponse, GetApproximateUsageRecordsError, Credentials | HttpClient.HttpClient>;
export type GetCommitmentPurchaseAnalysisError = AnalysisNotFoundException | DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves a commitment purchase analysis result based on the
 * `AnalysisId`.
 */
export declare const getCommitmentPurchaseAnalysis: API.OperationMethod<GetCommitmentPurchaseAnalysisRequest & RegionInput, GetCommitmentPurchaseAnalysisResponse, GetCommitmentPurchaseAnalysisError, Credentials | HttpClient.HttpClient>;
export type GetCostAndUsageError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage metrics for your account. You can specify which cost and
 * usage-related metric that you want the request to return. For example, you can specify
 * `BlendedCosts` or `UsageQuantity`. You can also filter and group your
 * data by various dimensions, such as `SERVICE` or `AZ`, in a specific
 * time range. For a complete list of valid dimensions, see the GetDimensionValues operation. Management account in an organization in Organizations have access to all member accounts.
 *
 * For information about filter limitations, see Quotas and restrictions
 * in the *Billing and Cost Management User Guide*.
 */
export declare const getCostAndUsage: API.OperationMethod<GetCostAndUsageRequest & RegionInput, GetCostAndUsageResponse, GetCostAndUsageError, Credentials | HttpClient.HttpClient>;
export type GetCostAndUsageComparisonsError = BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage comparisons for your account between two periods within the last
 * 13 months. If you have enabled multi-year data at monthly granularity, you can go back up to
 * 38 months.
 */
export declare const getCostAndUsageComparisons: API.PaginatedOperationMethod<GetCostAndUsageComparisonsRequest & RegionInput, GetCostAndUsageComparisonsResponse, GetCostAndUsageComparisonsError, Credentials | HttpClient.HttpClient, CostAndUsageComparison>;
export type GetCostAndUsageWithResourcesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves cost and usage metrics with resources for your account. You can specify which
 * cost and usage-related metric, such as `BlendedCosts` or
 * `UsageQuantity`, that you want the request to return. You can also filter and group
 * your data by various dimensions, such as `SERVICE` or `AZ`, in a
 * specific time range. For a complete list of valid dimensions, see the GetDimensionValues operation. Management account in an organization in Organizations have access to all member accounts.
 *
 * Hourly granularity is only available for EC2-Instances (Elastic Compute Cloud)
 * resource-level data. All other resource-level data is available at daily
 * granularity.
 *
 * This is an opt-in only feature. You can enable this feature from the Cost Explorer
 * Settings page. For information about how to access the Settings page, see Controlling
 * Access for Cost Explorer in the Billing and Cost Management User
 * Guide.
 */
export declare const getCostAndUsageWithResources: API.OperationMethod<GetCostAndUsageWithResourcesRequest & RegionInput, GetCostAndUsageWithResourcesResponse, GetCostAndUsageWithResourcesError, Credentials | HttpClient.HttpClient>;
export type GetCostCategoriesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves an array of cost category names and values incurred cost.
 *
 * If some cost category names and values are not associated with any cost, they will not
 * be returned by this API.
 */
export declare const getCostCategories: API.OperationMethod<GetCostCategoriesRequest & RegionInput, GetCostCategoriesResponse, GetCostCategoriesError, Credentials | HttpClient.HttpClient>;
export type GetCostComparisonDriversError = BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves key factors driving cost changes between two time periods within the last 13
 * months, such as usage changes, discount changes, and commitment-based savings. If you have
 * enabled multi-year data at monthly granularity, you can go back up to 38 months.
 */
export declare const getCostComparisonDrivers: API.PaginatedOperationMethod<GetCostComparisonDriversRequest & RegionInput, GetCostComparisonDriversResponse, GetCostComparisonDriversError, Credentials | HttpClient.HttpClient, CostComparisonDriver>;
export type GetCostForecastError = BillingViewHealthStatusException | DataUnavailableException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a forecast for how much Amazon Web Services predicts that you will spend over
 * the forecast time period that you select, based on your past costs.
 */
export declare const getCostForecast: API.OperationMethod<GetCostForecastRequest & RegionInput, GetCostForecastResponse, GetCostForecastError, Credentials | HttpClient.HttpClient>;
export type GetDimensionValuesError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all available filter values for a specified filter over a period of time. You
 * can search the dimension values for an arbitrary string.
 */
export declare const getDimensionValues: API.OperationMethod<GetDimensionValuesRequest & RegionInput, GetDimensionValuesResponse, GetDimensionValuesError, Credentials | HttpClient.HttpClient>;
export type GetReservationCoverageError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the reservation coverage for your account, which you can use to see how much
 * of your Amazon Elastic Compute Cloud, Amazon ElastiCache, Amazon Relational Database Service,
 * or Amazon Redshift usage is covered by a reservation. An organization's management account can
 * see the coverage of the associated member accounts. This supports dimensions, cost categories,
 * and nested expressions. For any time period, you can filter data about reservation usage by
 * the following dimensions:
 *
 * - AZ
 *
 * - CACHE_ENGINE
 *
 * - DATABASE_ENGINE
 *
 * - DEPLOYMENT_OPTION
 *
 * - INSTANCE_TYPE
 *
 * - LINKED_ACCOUNT
 *
 * - OPERATING_SYSTEM
 *
 * - PLATFORM
 *
 * - REGION
 *
 * - SERVICE
 *
 * - TAG
 *
 * - TENANCY
 *
 * To determine valid values for a dimension, use the `GetDimensionValues`
 * operation.
 */
export declare const getReservationCoverage: API.OperationMethod<GetReservationCoverageRequest & RegionInput, GetReservationCoverageResponse, GetReservationCoverageError, Credentials | HttpClient.HttpClient>;
export type GetReservationPurchaseRecommendationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Gets recommendations for reservation purchases. These recommendations might help you to
 * reduce your costs. Reservations provide a discounted hourly rate (up to 75%) compared to
 * On-Demand pricing.
 *
 * Amazon Web Services generates your recommendations by identifying your On-Demand usage
 * during a specific time period and collecting your usage into categories that are eligible for
 * a reservation. After Amazon Web Services has these categories, it simulates every combination
 * of reservations in each category of usage to identify the best number of each type of Reserved
 * Instance (RI) to purchase to maximize your estimated savings.
 *
 * For example, Amazon Web Services automatically aggregates your Amazon EC2 Linux, shared
 * tenancy, and c4 family usage in the US West (Oregon) Region and recommends that you buy
 * size-flexible regional reservations to apply to the c4 family usage. Amazon Web Services
 * recommends the smallest size instance in an instance family. This makes it easier to purchase
 * a size-flexible Reserved Instance (RI). Amazon Web Services also shows the equal number of
 * normalized units. This way, you can purchase any instance size that you want. For this
 * example, your RI recommendation is for `c4.large` because that is the smallest size
 * instance in the c4 instance family.
 */
export declare const getReservationPurchaseRecommendation: API.PaginatedOperationMethod<GetReservationPurchaseRecommendationRequest & RegionInput, GetReservationPurchaseRecommendationResponse, GetReservationPurchaseRecommendationError, Credentials | HttpClient.HttpClient, ReservationPurchaseRecommendation>;
export type GetReservationUtilizationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the reservation utilization for your account. Management account in an
 * organization have access to member accounts. You can filter data by dimensions in a time
 * period. You can use `GetDimensionValues` to determine the possible dimension
 * values. Currently, you can group only by `SUBSCRIPTION_ID`.
 */
export declare const getReservationUtilization: API.OperationMethod<GetReservationUtilizationRequest & RegionInput, GetReservationUtilizationResponse, GetReservationUtilizationError, Credentials | HttpClient.HttpClient>;
export type GetRightsizingRecommendationError = InvalidNextTokenException | LimitExceededException | RightsizingRecommendationNotEnabled | CommonErrors;
/**
 * Creates recommendations that help you save cost by identifying idle and underutilized
 * Amazon EC2 instances.
 *
 * Recommendations are generated to either downsize or terminate instances, along with
 * providing savings detail and metrics. For more information about calculation and function, see
 * Optimizing Your Cost with Rightsizing Recommendations in the *Billing and Cost Management User Guide*.
 */
export declare const getRightsizingRecommendation: API.PaginatedOperationMethod<GetRightsizingRecommendationRequest & RegionInput, GetRightsizingRecommendationResponse, GetRightsizingRecommendationError, Credentials | HttpClient.HttpClient, RightsizingRecommendation>;
export type GetSavingsPlanPurchaseRecommendationDetailsError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves the details for a Savings Plan recommendation. These details include the hourly
 * data-points that construct the cost, coverage, and utilization charts.
 */
export declare const getSavingsPlanPurchaseRecommendationDetails: API.OperationMethod<GetSavingsPlanPurchaseRecommendationDetailsRequest & RegionInput, GetSavingsPlanPurchaseRecommendationDetailsResponse, GetSavingsPlanPurchaseRecommendationDetailsError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansCoverageError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans covered for your account. This enables you to see how much of
 * your cost is covered by a Savings Plan. An organization's management account can see the
 * coverage of the associated member accounts. This supports dimensions, cost categories, and
 * nested expressions. For any time period, you can filter data for Savings Plans usage with the
 * following dimensions:
 *
 * - `LINKED_ACCOUNT`
 *
 * - `REGION`
 *
 * - `SERVICE`
 *
 * - `INSTANCE_FAMILY`
 *
 * To determine valid values for a dimension, use the `GetDimensionValues`
 * operation.
 */
export declare const getSavingsPlansCoverage: API.PaginatedOperationMethod<GetSavingsPlansCoverageRequest & RegionInput, GetSavingsPlansCoverageResponse, GetSavingsPlansCoverageError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSavingsPlansPurchaseRecommendationError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans recommendations for your account. First use
 * `StartSavingsPlansPurchaseRecommendationGeneration` to generate a new set of
 * recommendations, and then use `GetSavingsPlansPurchaseRecommendation` to retrieve
 * them.
 */
export declare const getSavingsPlansPurchaseRecommendation: API.OperationMethod<GetSavingsPlansPurchaseRecommendationRequest & RegionInput, GetSavingsPlansPurchaseRecommendationResponse, GetSavingsPlansPurchaseRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansUtilizationError = DataUnavailableException | LimitExceededException | CommonErrors;
/**
 * Retrieves the Savings Plans utilization for your account across date ranges with daily or
 * monthly granularity. Management account in an organization have access to member accounts. You
 * can use `GetDimensionValues` in `SAVINGS_PLANS` to determine the
 * possible dimension values.
 *
 * You can't group by any dimension values for
 * `GetSavingsPlansUtilization`.
 */
export declare const getSavingsPlansUtilization: API.OperationMethod<GetSavingsPlansUtilizationRequest & RegionInput, GetSavingsPlansUtilizationResponse, GetSavingsPlansUtilizationError, Credentials | HttpClient.HttpClient>;
export type GetSavingsPlansUtilizationDetailsError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves attribute data along with aggregate utilization and savings data for a given
 * time period. This doesn't support granular or grouped data (daily/monthly) in response. You
 * can't retrieve data by dates in a single response similar to
 * `GetSavingsPlanUtilization`, but you have the option to make multiple calls to
 * `GetSavingsPlanUtilizationDetails` by providing individual dates. You can use
 * `GetDimensionValues` in `SAVINGS_PLANS` to determine the possible
 * dimension values.
 *
 * `GetSavingsPlanUtilizationDetails` internally groups data by
 * `SavingsPlansArn`.
 */
export declare const getSavingsPlansUtilizationDetails: API.PaginatedOperationMethod<GetSavingsPlansUtilizationDetailsRequest & RegionInput, GetSavingsPlansUtilizationDetailsResponse, GetSavingsPlansUtilizationDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTagsError = BillExpirationException | BillingViewHealthStatusException | DataUnavailableException | InvalidNextTokenException | LimitExceededException | RequestChangedException | ResourceNotFoundException | CommonErrors;
/**
 * Queries for available tag keys and tag values for a specified period. You can search
 * the tag values for an arbitrary string.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest & RegionInput, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetUsageForecastError = BillingViewHealthStatusException | DataUnavailableException | LimitExceededException | ResourceNotFoundException | UnresolvableUsageUnitException | CommonErrors;
/**
 * Retrieves a forecast for how much Amazon Web Services predicts that you will use
 * over the forecast time period that you select, based on your past usage.
 */
export declare const getUsageForecast: API.OperationMethod<GetUsageForecastRequest & RegionInput, GetUsageForecastResponse, GetUsageForecastError, Credentials | HttpClient.HttpClient>;
export type ListCommitmentPurchaseAnalysesError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Lists the commitment purchase analyses for your account.
 */
export declare const listCommitmentPurchaseAnalyses: API.PaginatedOperationMethod<ListCommitmentPurchaseAnalysesRequest & RegionInput, ListCommitmentPurchaseAnalysesResponse, ListCommitmentPurchaseAnalysesError, Credentials | HttpClient.HttpClient, AnalysisSummary>;
export type ListCostAllocationTagBackfillHistoryError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves a list of your historical cost allocation tag backfill requests.
 */
export declare const listCostAllocationTagBackfillHistory: API.PaginatedOperationMethod<ListCostAllocationTagBackfillHistoryRequest & RegionInput, ListCostAllocationTagBackfillHistoryResponse, ListCostAllocationTagBackfillHistoryError, Credentials | HttpClient.HttpClient, CostAllocationTagBackfillRequest>;
export type ListCostAllocationTagsError = InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Get a list of cost allocation tags. All inputs in the API are optional and serve as
 * filters. By default, all cost allocation tags are returned.
 */
export declare const listCostAllocationTags: API.PaginatedOperationMethod<ListCostAllocationTagsRequest & RegionInput, ListCostAllocationTagsResponse, ListCostAllocationTagsError, Credentials | HttpClient.HttpClient, CostAllocationTag>;
export type ListCostCategoryDefinitionsError = LimitExceededException | CommonErrors;
/**
 * Returns the name, Amazon Resource Name (ARN), `NumberOfRules` and effective
 * dates of all cost categories defined in the account. You have the option to use
 * `EffectiveOn` and `SupportedResourceTypes` to return a list of cost categories that were active on a specific
 * date. If there is no `EffectiveOn` specified, you'll see cost categories that are
 * effective on the current date. If cost category is still effective, `EffectiveEnd`
 * is omitted in the response. `ListCostCategoryDefinitions` supports pagination. The
 * request can have a `MaxResults` range up to 100.
 */
export declare const listCostCategoryDefinitions: API.PaginatedOperationMethod<ListCostCategoryDefinitionsRequest & RegionInput, ListCostCategoryDefinitionsResponse, ListCostCategoryDefinitionsError, Credentials | HttpClient.HttpClient, CostCategoryReference>;
export type ListCostCategoryResourceAssociationsError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns resource associations of all cost categories defined in the account. You have the option to use `CostCategoryArn` to get the association for a specific cost category. `ListCostCategoryResourceAssociations` supports pagination. The request can have a `MaxResults` range up to 100.
 */
export declare const listCostCategoryResourceAssociations: API.PaginatedOperationMethod<ListCostCategoryResourceAssociationsRequest & RegionInput, ListCostCategoryResourceAssociationsResponse, ListCostCategoryResourceAssociationsError, Credentials | HttpClient.HttpClient, CostCategoryResourceAssociation>;
export type ListSavingsPlansPurchaseRecommendationGenerationError = DataUnavailableException | InvalidNextTokenException | LimitExceededException | CommonErrors;
/**
 * Retrieves a list of your historical recommendation generations within the past 30
 * days.
 */
export declare const listSavingsPlansPurchaseRecommendationGeneration: API.PaginatedOperationMethod<ListSavingsPlansPurchaseRecommendationGenerationRequest & RegionInput, ListSavingsPlansPurchaseRecommendationGenerationResponse, ListSavingsPlansPurchaseRecommendationGenerationError, Credentials | HttpClient.HttpClient, GenerationSummary>;
export type ListTagsForResourceError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of resource tags associated with the resource specified by the Amazon
 * Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ProvideAnomalyFeedbackError = LimitExceededException | CommonErrors;
/**
 * Modifies the feedback property of a given cost anomaly.
 */
export declare const provideAnomalyFeedback: API.OperationMethod<ProvideAnomalyFeedbackRequest & RegionInput, ProvideAnomalyFeedbackResponse, ProvideAnomalyFeedbackError, Credentials | HttpClient.HttpClient>;
export type StartCommitmentPurchaseAnalysisError = DataUnavailableException | GenerationExistsException | LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Specifies the parameters of a planned commitment purchase and starts the generation of the
 * analysis. This enables you to estimate the cost, coverage, and utilization impact of your
 * planned commitment purchases.
 */
export declare const startCommitmentPurchaseAnalysis: API.OperationMethod<StartCommitmentPurchaseAnalysisRequest & RegionInput, StartCommitmentPurchaseAnalysisResponse, StartCommitmentPurchaseAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartCostAllocationTagBackfillError = BackfillLimitExceededException | LimitExceededException | CommonErrors;
/**
 * Request a cost allocation tag backfill. This will backfill the activation status (either `active` or `inactive`) for all tag keys from `para:BackfillFrom` up to the time this request is made.
 *
 * You can request a backfill once every 24 hours.
 */
export declare const startCostAllocationTagBackfill: API.OperationMethod<StartCostAllocationTagBackfillRequest & RegionInput, StartCostAllocationTagBackfillResponse, StartCostAllocationTagBackfillError, Credentials | HttpClient.HttpClient>;
export type StartSavingsPlansPurchaseRecommendationGenerationError = DataUnavailableException | GenerationExistsException | LimitExceededException | ServiceQuotaExceededException | CommonErrors;
/**
 * Requests a Savings Plans recommendation generation. This enables you to calculate a fresh
 * set of Savings Plans recommendations that takes your latest usage data and current Savings
 * Plans inventory into account. You can refresh Savings Plans recommendations up to three times
 * daily for a consolidated billing family.
 *
 * `StartSavingsPlansPurchaseRecommendationGeneration` has no request syntax
 * because no input parameters are needed to support this operation.
 */
export declare const startSavingsPlansPurchaseRecommendationGeneration: API.OperationMethod<StartSavingsPlansPurchaseRecommendationGenerationRequest & RegionInput, StartSavingsPlansPurchaseRecommendationGenerationResponse, StartSavingsPlansPurchaseRecommendationGenerationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = LimitExceededException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * An API operation for adding one or more tags (key-value pairs) to a resource.
 *
 * You can use the `TagResource` operation with a resource that already has tags.
 * If you specify a new tag key for the resource, this tag is appended to the list of tags
 * associated with the resource. If you specify a tag key that is already associated with the
 * resource, the new tag value you specify replaces the previous value for that tag.
 *
 * Although the maximum number of array members is 200, user-tag maximum is 50. The remaining
 * are reserved for Amazon Web Services use.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from a resource. Specify only tag keys in your request. Don't
 * specify the value.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnomalyMonitorError = LimitExceededException | UnknownMonitorException | CommonErrors;
/**
 * Updates an existing cost anomaly monitor. The changes made are applied going forward, and
 * doesn't change anomalies detected in the past.
 */
export declare const updateAnomalyMonitor: API.OperationMethod<UpdateAnomalyMonitorRequest & RegionInput, UpdateAnomalyMonitorResponse, UpdateAnomalyMonitorError, Credentials | HttpClient.HttpClient>;
export type UpdateAnomalySubscriptionError = LimitExceededException | UnknownMonitorException | UnknownSubscriptionException | CommonErrors;
/**
 * Updates an existing cost anomaly subscription. Specify the fields that you want to update.
 * Omitted fields are unchanged.
 *
 * The JSON below describes the generic construct for each type. See Request Parameters for possible values as they apply to
 * `AnomalySubscription`.
 */
export declare const updateAnomalySubscription: API.OperationMethod<UpdateAnomalySubscriptionRequest & RegionInput, UpdateAnomalySubscriptionResponse, UpdateAnomalySubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateCostAllocationTagsStatusError = LimitExceededException | CommonErrors;
/**
 * Updates status for cost allocation tags in bulk, with maximum batch size of 20. If the tag
 * status that's updated is the same as the existing tag status, the request doesn't fail.
 * Instead, it doesn't have any effect on the tag status (for example, activating the active
 * tag).
 */
export declare const updateCostAllocationTagsStatus: API.OperationMethod<UpdateCostAllocationTagsStatusRequest & RegionInput, UpdateCostAllocationTagsStatusResponse, UpdateCostAllocationTagsStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateCostCategoryDefinitionError = LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates an existing cost category. Changes made to the cost category rules will be used to
 * categorize the current month's expenses and future expenses. This won't change categorization
 * for the previous months.
 */
export declare const updateCostCategoryDefinition: API.OperationMethod<UpdateCostCategoryDefinitionRequest & RegionInput, UpdateCostCategoryDefinitionResponse, UpdateCostCategoryDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cost-explorer.d.ts.map