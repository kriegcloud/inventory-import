import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type QueryNetwork = string;
export type ChainAddress = string;
export type QueryTokenId = string;
export interface TokenIdentifier {
    network: string;
    contractAddress?: string | undefined;
    tokenId?: string | undefined;
}
export interface OwnerIdentifier {
    address: string;
}
export interface BlockchainInstant {
    time?: Date | undefined;
}
export interface BatchGetTokenBalanceInputItem {
    tokenIdentifier: TokenIdentifier;
    ownerIdentifier: OwnerIdentifier;
    atBlockchainInstant?: BlockchainInstant | undefined;
}
export type GetTokenBalanceInputList = BatchGetTokenBalanceInputItem[];
export interface BatchGetTokenBalanceInput {
    getTokenBalanceInputs?: BatchGetTokenBalanceInputItem[] | undefined;
}
export interface BatchGetTokenBalanceOutputItem {
    ownerIdentifier?: OwnerIdentifier | undefined;
    tokenIdentifier?: TokenIdentifier | undefined;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant | undefined;
}
export type BatchGetTokenBalanceOutputList = BatchGetTokenBalanceOutputItem[];
export type ErrorType = string;
export interface BatchGetTokenBalanceErrorItem {
    tokenIdentifier?: TokenIdentifier | undefined;
    ownerIdentifier?: OwnerIdentifier | undefined;
    atBlockchainInstant?: BlockchainInstant | undefined;
    errorCode: string;
    errorMessage: string;
    errorType: string;
}
export type BatchGetTokenBalanceErrors = BatchGetTokenBalanceErrorItem[];
export interface BatchGetTokenBalanceOutput {
    tokenBalances: BatchGetTokenBalanceOutputItem[];
    errors: BatchGetTokenBalanceErrorItem[];
}
export interface ContractIdentifier {
    network: string;
    contractAddress: string;
}
export interface GetAssetContractInput {
    contractIdentifier: ContractIdentifier;
}
export type QueryTokenStandard = string;
export interface ContractMetadata {
    name?: string | undefined;
    symbol?: string | undefined;
    decimals?: number | undefined;
}
export interface GetAssetContractOutput {
    contractIdentifier: ContractIdentifier;
    tokenStandard: string;
    deployerAddress: string;
    metadata?: ContractMetadata | undefined;
}
export interface GetTokenBalanceInput {
    tokenIdentifier: TokenIdentifier;
    ownerIdentifier: OwnerIdentifier;
    atBlockchainInstant?: BlockchainInstant | undefined;
}
export interface GetTokenBalanceOutput {
    ownerIdentifier?: OwnerIdentifier | undefined;
    tokenIdentifier?: TokenIdentifier | undefined;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant | undefined;
}
export type QueryTransactionHash = string;
export type QueryTransactionId = string;
export interface GetTransactionInput {
    transactionHash?: string | undefined;
    transactionId?: string | undefined;
    network: string;
}
export type BlockHash = string;
export type ConfirmationStatus = string;
export type ExecutionStatus = string;
export interface Transaction {
    network: string;
    blockHash?: string | undefined;
    transactionHash: string;
    blockNumber?: string | undefined;
    transactionTimestamp: Date;
    transactionIndex: number;
    numberOfTransactions: number;
    to: string;
    from?: string | undefined;
    contractAddress?: string | undefined;
    gasUsed?: string | undefined;
    cumulativeGasUsed?: string | undefined;
    effectiveGasPrice?: string | undefined;
    signatureV?: number | undefined;
    signatureR?: string | undefined;
    signatureS?: string | undefined;
    transactionFee?: string | undefined;
    transactionId?: string | undefined;
    confirmationStatus?: string | undefined;
    executionStatus?: string | undefined;
}
export interface GetTransactionOutput {
    transaction: Transaction;
}
export interface ContractFilter {
    network: string;
    tokenStandard: string;
    deployerAddress: string;
}
export type NextToken = string;
export interface ListAssetContractsInput {
    contractFilter: ContractFilter;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssetContract {
    contractIdentifier: ContractIdentifier;
    tokenStandard: string;
    deployerAddress: string;
}
export type AssetContractList = AssetContract[];
export interface ListAssetContractsOutput {
    contracts: AssetContract[];
    nextToken?: string | undefined;
}
export type ChainAddresses = string[];
export interface AddressIdentifierFilter {
    transactionEventToAddress: string[];
}
export interface TimeFilter {
    from?: BlockchainInstant | undefined;
    to?: BlockchainInstant | undefined;
}
export interface VoutFilter {
    voutSpent: boolean;
}
export type ConfirmationStatusIncludeList = string[];
export interface ConfirmationStatusFilter {
    include: string[];
}
export type ListFilteredTransactionEventsSortBy = string;
export type SortOrder = string;
export interface ListFilteredTransactionEventsSort {
    sortBy?: string | undefined;
    sortOrder?: string | undefined;
}
export interface ListFilteredTransactionEventsInput {
    network: string;
    addressIdentifierFilter: AddressIdentifierFilter;
    timeFilter?: TimeFilter | undefined;
    voutFilter?: VoutFilter | undefined;
    confirmationStatusFilter?: ConfirmationStatusFilter | undefined;
    sort?: ListFilteredTransactionEventsSort | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type QueryTransactionEventType = string;
export interface TransactionEvent {
    network: string;
    transactionHash: string;
    eventType: string;
    from?: string | undefined;
    to?: string | undefined;
    value?: string | undefined;
    contractAddress?: string | undefined;
    tokenId?: string | undefined;
    transactionId?: string | undefined;
    voutIndex?: number | undefined;
    voutSpent?: boolean | undefined;
    spentVoutTransactionId?: string | undefined;
    spentVoutTransactionHash?: string | undefined;
    spentVoutIndex?: number | undefined;
    blockchainInstant?: BlockchainInstant | undefined;
    confirmationStatus?: string | undefined;
}
export type TransactionEventList = TransactionEvent[];
export interface ListFilteredTransactionEventsOutput {
    events: TransactionEvent[];
    nextToken?: string | undefined;
}
export interface OwnerFilter {
    address: string;
}
export interface TokenFilter {
    network: string;
    contractAddress?: string | undefined;
    tokenId?: string | undefined;
}
export interface ListTokenBalancesInput {
    ownerFilter?: OwnerFilter | undefined;
    tokenFilter: TokenFilter;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface TokenBalance {
    ownerIdentifier?: OwnerIdentifier | undefined;
    tokenIdentifier?: TokenIdentifier | undefined;
    balance: string;
    atBlockchainInstant: BlockchainInstant;
    lastUpdatedTime?: BlockchainInstant | undefined;
}
export type TokenBalanceList = TokenBalance[];
export interface ListTokenBalancesOutput {
    tokenBalances: TokenBalance[];
    nextToken?: string | undefined;
}
export interface ListTransactionEventsInput {
    transactionHash?: string | undefined;
    transactionId?: string | undefined;
    network: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTransactionEventsOutput {
    events: TransactionEvent[];
    nextToken?: string | undefined;
}
export type ListTransactionsSortBy = string;
export interface ListTransactionsSort {
    sortBy?: string | undefined;
    sortOrder?: string | undefined;
}
export interface ListTransactionsInput {
    address: string;
    network: string;
    fromBlockchainInstant?: BlockchainInstant | undefined;
    toBlockchainInstant?: BlockchainInstant | undefined;
    sort?: ListTransactionsSort | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    confirmationStatusFilter?: ConfirmationStatusFilter | undefined;
}
export interface TransactionOutputItem {
    transactionHash: string;
    transactionId?: string | undefined;
    network: string;
    transactionTimestamp: Date;
    confirmationStatus?: string | undefined;
}
export type TransactionOutputList = TransactionOutputItem[];
export interface ListTransactionsOutput {
    transactions: TransactionOutputItem[];
    nextToken?: string | undefined;
}
export type ExceptionMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchGetTokenBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the token balance for a batch of tokens by using the `BatchGetTokenBalance`
 * action for every token in the request.
 *
 * Only the native tokens BTC and ETH, and the ERC-20,
 * ERC-721, and ERC 1155 token standards are supported.
 */
export declare const batchGetTokenBalance: API.OperationMethod<BatchGetTokenBalanceInput & RegionInput, BatchGetTokenBalanceOutput, BatchGetTokenBalanceError, Credentials | HttpClient.HttpClient>;
export type GetAssetContractError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the information about a specific contract deployed on the blockchain.
 *
 * - The Bitcoin blockchain networks do not support this
 * operation.
 *
 * - Metadata is currently only available for some `ERC-20` contracts.
 * Metadata will be available for additional contracts in the future.
 */
export declare const getAssetContract: API.OperationMethod<GetAssetContractInput & RegionInput, GetAssetContractOutput, GetAssetContractError, Credentials | HttpClient.HttpClient>;
export type GetTokenBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the balance of a specific token, including native tokens, for a given address (wallet or contract) on the blockchain.
 *
 * Only the native tokens BTC and ETH, and the ERC-20,
 * ERC-721, and ERC 1155 token standards are supported.
 */
export declare const getTokenBalance: API.OperationMethod<GetTokenBalanceInput & RegionInput, GetTokenBalanceOutput, GetTokenBalanceError, Credentials | HttpClient.HttpClient>;
export type GetTransactionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a transaction.
 *
 * This action will return transaction details for all transactions
 * that are *confirmed* on the blockchain, even if they have not reached
 * finality.
 */
export declare const getTransaction: API.OperationMethod<GetTransactionInput & RegionInput, GetTransactionOutput, GetTransactionError, Credentials | HttpClient.HttpClient>;
export type ListAssetContractsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the contracts for a given contract type deployed by an address
 * (either a contract address or a wallet address).
 *
 * The Bitcoin blockchain networks do not support this
 * operation.
 */
export declare const listAssetContracts: API.PaginatedOperationMethod<ListAssetContractsInput & RegionInput, ListAssetContractsOutput, ListAssetContractsError, Credentials | HttpClient.HttpClient, AssetContract>;
export type ListFilteredTransactionEventsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for an address on the blockchain.
 *
 * This operation is only supported on the Bitcoin networks.
 */
export declare const listFilteredTransactionEvents: API.PaginatedOperationMethod<ListFilteredTransactionEventsInput & RegionInput, ListFilteredTransactionEventsOutput, ListFilteredTransactionEventsError, Credentials | HttpClient.HttpClient, TransactionEvent>;
export type ListTokenBalancesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action returns the following for a given blockchain network:
 *
 * - Lists all token balances owned by an address (either a contract
 * address or a wallet address).
 *
 * - Lists all token balances for all tokens created by a contract.
 *
 * - Lists all token balances for a given token.
 *
 * You must always specify the network property of
 * the `tokenFilter` when using this operation.
 */
export declare const listTokenBalances: API.PaginatedOperationMethod<ListTokenBalancesInput & RegionInput, ListTokenBalancesOutput, ListTokenBalancesError, Credentials | HttpClient.HttpClient, TokenBalance>;
export type ListTransactionEventsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for a transaction
 *
 * This action will return transaction details for all transactions
 * that are *confirmed* on the blockchain, even if they have not reached
 * finality.
 */
export declare const listTransactionEvents: API.PaginatedOperationMethod<ListTransactionEventsInput & RegionInput, ListTransactionEventsOutput, ListTransactionEventsError, Credentials | HttpClient.HttpClient, TransactionEvent>;
export type ListTransactionsError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the transaction events for a transaction.
 */
export declare const listTransactions: API.PaginatedOperationMethod<ListTransactionsInput & RegionInput, ListTransactionsOutput, ListTransactionsError, Credentials | HttpClient.HttpClient, TransactionOutputItem>;
export {};
//# sourceMappingURL=managedblockchain-query.d.ts.map