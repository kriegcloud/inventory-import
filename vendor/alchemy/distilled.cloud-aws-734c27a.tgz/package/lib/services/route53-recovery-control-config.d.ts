import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type __stringMin1Max64PatternS = string;
export type __stringMin0Max256PatternS = string;
export type __mapOf__stringMin0Max256PatternS = {
    [key: string]: string | undefined;
};
export type NetworkType = "IPV4" | "DUALSTACK" | (string & {});
export interface CreateClusterRequest {
    ClientToken?: string | undefined;
    ClusterName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkType?: NetworkType | undefined;
}
export type __stringMin1Max256PatternAZaZ09 = string;
export type __stringMin1Max128PatternAZaZ09 = string;
export type __stringMin1Max32PatternS = string;
export interface ClusterEndpoint {
    Endpoint?: string | undefined;
    Region?: string | undefined;
}
export type __listOfClusterEndpoint = ClusterEndpoint[];
export type Status = "PENDING" | "DEPLOYED" | "PENDING_DELETION" | (string & {});
export type __stringMin12Max12PatternD12 = string;
export interface Cluster {
    ClusterArn?: string | undefined;
    ClusterEndpoints?: ClusterEndpoint[] | undefined;
    Name?: string | undefined;
    Status?: Status | undefined;
    Owner?: string | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateClusterResponse {
    Cluster?: Cluster | undefined;
}
export interface CreateControlPanelRequest {
    ClientToken?: string | undefined;
    ClusterArn?: string | undefined;
    ControlPanelName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ControlPanel {
    ClusterArn?: string | undefined;
    ControlPanelArn?: string | undefined;
    DefaultControlPanel?: boolean | undefined;
    Name?: string | undefined;
    RoutingControlCount?: number | undefined;
    Status?: Status | undefined;
    Owner?: string | undefined;
}
export interface CreateControlPanelResponse {
    ControlPanel?: ControlPanel | undefined;
}
export interface CreateRoutingControlRequest {
    ClientToken?: string | undefined;
    ClusterArn?: string | undefined;
    ControlPanelArn?: string | undefined;
    RoutingControlName?: string | undefined;
}
export interface RoutingControl {
    ControlPanelArn?: string | undefined;
    Name?: string | undefined;
    RoutingControlArn?: string | undefined;
    Status?: Status | undefined;
    Owner?: string | undefined;
}
export interface CreateRoutingControlResponse {
    RoutingControl?: RoutingControl | undefined;
}
export type __listOf__stringMin1Max256PatternAZaZ09 = string[];
export type RuleType = "ATLEAST" | "AND" | "OR" | (string & {});
export interface RuleConfig {
    Inverted?: boolean | undefined;
    Threshold?: number | undefined;
    Type?: RuleType | undefined;
}
export interface NewAssertionRule {
    AssertedControls?: string[] | undefined;
    ControlPanelArn?: string | undefined;
    Name?: string | undefined;
    RuleConfig?: RuleConfig | undefined;
    WaitPeriodMs?: number | undefined;
}
export interface NewGatingRule {
    ControlPanelArn?: string | undefined;
    GatingControls?: string[] | undefined;
    Name?: string | undefined;
    RuleConfig?: RuleConfig | undefined;
    TargetControls?: string[] | undefined;
    WaitPeriodMs?: number | undefined;
}
export interface CreateSafetyRuleRequest {
    AssertionRule?: NewAssertionRule | undefined;
    ClientToken?: string | undefined;
    GatingRule?: NewGatingRule | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AssertionRule {
    AssertedControls?: string[] | undefined;
    ControlPanelArn?: string | undefined;
    Name?: string | undefined;
    RuleConfig?: RuleConfig | undefined;
    SafetyRuleArn?: string | undefined;
    Status?: Status | undefined;
    WaitPeriodMs?: number | undefined;
    Owner?: string | undefined;
}
export interface GatingRule {
    ControlPanelArn?: string | undefined;
    GatingControls?: string[] | undefined;
    Name?: string | undefined;
    RuleConfig?: RuleConfig | undefined;
    SafetyRuleArn?: string | undefined;
    Status?: Status | undefined;
    TargetControls?: string[] | undefined;
    WaitPeriodMs?: number | undefined;
    Owner?: string | undefined;
}
export interface CreateSafetyRuleResponse {
    AssertionRule?: (AssertionRule & {
        AssertedControls: __listOf__stringMin1Max256PatternAZaZ09;
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        WaitPeriodMs: number;
    }) | undefined;
    GatingRule?: (GatingRule & {
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        GatingControls: __listOf__stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        TargetControls: __listOf__stringMin1Max256PatternAZaZ09;
        WaitPeriodMs: number;
    }) | undefined;
}
export interface DeleteClusterRequest {
    ClusterArn: string;
}
export interface DeleteClusterResponse {
}
export interface DeleteControlPanelRequest {
    ControlPanelArn: string;
}
export interface DeleteControlPanelResponse {
}
export interface DeleteRoutingControlRequest {
    RoutingControlArn: string;
}
export interface DeleteRoutingControlResponse {
}
export interface DeleteSafetyRuleRequest {
    SafetyRuleArn: string;
}
export interface DeleteSafetyRuleResponse {
}
export interface DescribeClusterRequest {
    ClusterArn: string;
}
export interface DescribeClusterResponse {
    Cluster?: Cluster | undefined;
}
export interface DescribeControlPanelRequest {
    ControlPanelArn: string;
}
export interface DescribeControlPanelResponse {
    ControlPanel?: ControlPanel | undefined;
}
export interface DescribeRoutingControlRequest {
    RoutingControlArn: string;
}
export interface DescribeRoutingControlResponse {
    RoutingControl?: RoutingControl | undefined;
}
export interface DescribeSafetyRuleRequest {
    SafetyRuleArn: string;
}
export interface DescribeSafetyRuleResponse {
    AssertionRule?: (AssertionRule & {
        AssertedControls: __listOf__stringMin1Max256PatternAZaZ09;
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        WaitPeriodMs: number;
    }) | undefined;
    GatingRule?: (GatingRule & {
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        GatingControls: __listOf__stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        TargetControls: __listOf__stringMin1Max256PatternAZaZ09;
        WaitPeriodMs: number;
    }) | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type __policy = string;
export interface GetResourcePolicyResponse {
    Policy?: string | undefined;
}
export type MaxResults = number;
export interface ListAssociatedRoute53HealthChecksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    RoutingControlArn: string;
}
export type __stringMax36PatternS = string;
export type __listOf__stringMax36PatternS = string[];
export type __stringMin1Max8096PatternS = string;
export interface ListAssociatedRoute53HealthChecksResponse {
    HealthCheckIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClustersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfCluster = Cluster[];
export interface ListClustersResponse {
    Clusters?: Cluster[] | undefined;
    NextToken?: string | undefined;
}
export interface ListControlPanelsRequest {
    ClusterArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfControlPanel = ControlPanel[];
export interface ListControlPanelsResponse {
    ControlPanels?: ControlPanel[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRoutingControlsRequest {
    ControlPanelArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfRoutingControl = RoutingControl[];
export interface ListRoutingControlsResponse {
    NextToken?: string | undefined;
    RoutingControls?: RoutingControl[] | undefined;
}
export interface ListSafetyRulesRequest {
    ControlPanelArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Rule {
    ASSERTION?: AssertionRule | undefined;
    GATING?: GatingRule | undefined;
}
export type __listOfRule = Rule[];
export interface ListSafetyRulesResponse {
    NextToken?: string | undefined;
    SafetyRules?: (Rule & {
        ASSERTION: AssertionRule & {
            AssertedControls: __listOf__stringMin1Max256PatternAZaZ09;
            ControlPanelArn: __stringMin1Max256PatternAZaZ09;
            Name: __stringMin1Max64PatternS;
            RuleConfig: RuleConfig & {
                Inverted: boolean;
                Threshold: number;
                Type: RuleType;
            };
            SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
            Status: Status;
            WaitPeriodMs: number;
        };
        GATING: GatingRule & {
            ControlPanelArn: __stringMin1Max256PatternAZaZ09;
            GatingControls: __listOf__stringMin1Max256PatternAZaZ09;
            Name: __stringMin1Max64PatternS;
            RuleConfig: RuleConfig & {
                Inverted: boolean;
                Threshold: number;
                Type: RuleType;
            };
            SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
            Status: Status;
            TargetControls: __listOf__stringMin1Max256PatternAZaZ09;
            WaitPeriodMs: number;
        };
    })[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type __listOf__string = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateClusterRequest {
    ClusterArn?: string | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface UpdateClusterResponse {
    Cluster?: Cluster | undefined;
}
export interface UpdateControlPanelRequest {
    ControlPanelArn?: string | undefined;
    ControlPanelName?: string | undefined;
}
export interface UpdateControlPanelResponse {
    ControlPanel?: ControlPanel | undefined;
}
export interface UpdateRoutingControlRequest {
    RoutingControlArn?: string | undefined;
    RoutingControlName?: string | undefined;
}
export interface UpdateRoutingControlResponse {
    RoutingControl?: RoutingControl | undefined;
}
export interface AssertionRuleUpdate {
    Name?: string | undefined;
    SafetyRuleArn?: string | undefined;
    WaitPeriodMs?: number | undefined;
}
export interface GatingRuleUpdate {
    Name?: string | undefined;
    SafetyRuleArn?: string | undefined;
    WaitPeriodMs?: number | undefined;
}
export interface UpdateSafetyRuleRequest {
    AssertionRuleUpdate?: AssertionRuleUpdate | undefined;
    GatingRuleUpdate?: GatingRuleUpdate | undefined;
}
export interface UpdateSafetyRuleResponse {
    AssertionRule?: (AssertionRule & {
        AssertedControls: __listOf__stringMin1Max256PatternAZaZ09;
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        WaitPeriodMs: number;
    }) | undefined;
    GatingRule?: (GatingRule & {
        ControlPanelArn: __stringMin1Max256PatternAZaZ09;
        GatingControls: __listOf__stringMin1Max256PatternAZaZ09;
        Name: __stringMin1Max64PatternS;
        RuleConfig: RuleConfig & {
            Inverted: boolean;
            Threshold: number;
            Type: RuleType;
        };
        SafetyRuleArn: __stringMin1Max256PatternAZaZ09;
        Status: Status;
        TargetControls: __listOf__stringMin1Max256PatternAZaZ09;
        WaitPeriodMs: number;
    }) | undefined;
}
export type CreateClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new cluster. A cluster is a set of redundant Regional endpoints against which you can run API calls to update or get the state of one or more routing controls. Each cluster has a name, status, Amazon Resource Name (ARN), and an array of the five cluster endpoints (one for each supported Amazon Web Services Region) that you can use with API calls to the cluster data plane.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateControlPanelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new control panel. A control panel represents a group of routing controls that can be changed together in a single transaction. You can use a control panel to centrally view the operational status of applications across your organization, and trigger multi-app failovers in a single transaction, for example, to fail over an Availability Zone or Amazon Web Services Region.
 */
export declare const createControlPanel: API.OperationMethod<CreateControlPanelRequest & RegionInput, CreateControlPanelResponse, CreateControlPanelError, Credentials | HttpClient.HttpClient>;
export type CreateRoutingControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new routing control.
 *
 * A routing control has one of two states: ON and OFF. You can map the routing control state to the state of an Amazon Route 53 health check, which can be used to control traffic routing.
 *
 * To get or update the routing control state, see the Recovery Cluster (data plane) API actions for Amazon Route 53 Application Recovery Controller.
 */
export declare const createRoutingControl: API.OperationMethod<CreateRoutingControlRequest & RegionInput, CreateRoutingControlResponse, CreateRoutingControlError, Credentials | HttpClient.HttpClient>;
export type CreateSafetyRuleError = InternalServerException | ValidationException | CommonErrors;
/**
 * Creates a safety rule in a control panel. Safety rules let you add safeguards around changing routing control states, and for enabling and disabling routing controls, to help prevent unexpected outcomes.
 *
 * There are two types of safety rules: assertion rules and gating rules.
 *
 * Assertion rule: An assertion rule enforces that, when you change a routing control state, that a certain criteria is met. For example, the criteria might be that at least one routing control state is On after the transaction so that traffic continues to flow to at least one cell for the application. This ensures that you avoid a fail-open scenario.
 *
 * Gating rule: A gating rule lets you configure a gating routing control as an overall "on/off" switch for a group of routing controls. Or, you can configure more complex gating scenarios, for example by configuring multiple gating routing controls.
 *
 * For more information, see Safety rules in the Amazon Route 53 Application Recovery Controller Developer Guide.
 */
export declare const createSafetyRule: API.OperationMethod<CreateSafetyRuleRequest & RegionInput, CreateSafetyRuleResponse, CreateSafetyRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a cluster.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest & RegionInput, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteControlPanelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a control panel.
 */
export declare const deleteControlPanel: API.OperationMethod<DeleteControlPanelRequest & RegionInput, DeleteControlPanelResponse, DeleteControlPanelError, Credentials | HttpClient.HttpClient>;
export type DeleteRoutingControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a routing control.
 */
export declare const deleteRoutingControl: API.OperationMethod<DeleteRoutingControlRequest & RegionInput, DeleteRoutingControlResponse, DeleteRoutingControlError, Credentials | HttpClient.HttpClient>;
export type DeleteSafetyRuleError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a safety rule.
 * />
 */
export declare const deleteSafetyRule: API.OperationMethod<DeleteSafetyRuleRequest & RegionInput, DeleteSafetyRuleResponse, DeleteSafetyRuleError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Display the details about a cluster. The response includes the cluster name, endpoints, status, and Amazon Resource Name (ARN).
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest & RegionInput, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeControlPanelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays details about a control panel.
 */
export declare const describeControlPanel: API.OperationMethod<DescribeControlPanelRequest & RegionInput, DescribeControlPanelResponse, DescribeControlPanelError, Credentials | HttpClient.HttpClient>;
export type DescribeRoutingControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Displays details about a routing control. A routing control has one of two states: ON and OFF. You can map the routing control state to the state of an Amazon Route 53 health check, which can be used to control routing.
 *
 * To get or update the routing control state, see the Recovery Cluster (data plane) API actions for Amazon Route 53 Application Recovery Controller.
 */
export declare const describeRoutingControl: API.OperationMethod<DescribeRoutingControlRequest & RegionInput, DescribeRoutingControlResponse, DescribeRoutingControlError, Credentials | HttpClient.HttpClient>;
export type DescribeSafetyRuleError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a safety rule.
 */
export declare const describeSafetyRule: API.OperationMethod<DescribeSafetyRuleRequest & RegionInput, DescribeSafetyRuleResponse, DescribeSafetyRuleError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Get information about the resource policy for a cluster.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedRoute53HealthChecksError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns an array of all Amazon Route 53 health checks associated with a specific routing control.
 */
export declare const listAssociatedRoute53HealthChecks: API.PaginatedOperationMethod<ListAssociatedRoute53HealthChecksRequest & RegionInput, ListAssociatedRoute53HealthChecksResponse, ListAssociatedRoute53HealthChecksError, Credentials | HttpClient.HttpClient, __stringMax36PatternS>;
export type ListClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array of all the clusters in an account.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, Cluster>;
export type ListControlPanelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array of control panels in an account or in a cluster.
 */
export declare const listControlPanels: API.PaginatedOperationMethod<ListControlPanelsRequest & RegionInput, ListControlPanelsResponse, ListControlPanelsError, Credentials | HttpClient.HttpClient, ControlPanel>;
export type ListRoutingControlsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array of routing controls for a control panel. A routing control is an Amazon Route 53 Application Recovery Controller construct that has one of two states: ON and OFF. You can map the routing control state to the state of an Amazon Route 53 health check, which can be used to control routing.
 */
export declare const listRoutingControls: API.PaginatedOperationMethod<ListRoutingControlsRequest & RegionInput, ListRoutingControlsResponse, ListRoutingControlsError, Credentials | HttpClient.HttpClient, RoutingControl>;
export type ListSafetyRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the safety rules (the assertion rules and gating rules) that you've defined for the routing controls in a control panel.
 */
export declare const listSafetyRules: API.PaginatedOperationMethod<ListSafetyRulesRequest & RegionInput, ListSafetyRulesResponse, ListSafetyRulesError, Credentials | HttpClient.HttpClient, Rule>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing cluster. You can only update the network type of a cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest & RegionInput, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateControlPanelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a control panel. The only update you can make to a control panel is to change the name of the control panel.
 */
export declare const updateControlPanel: API.OperationMethod<UpdateControlPanelRequest & RegionInput, UpdateControlPanelResponse, UpdateControlPanelError, Credentials | HttpClient.HttpClient>;
export type UpdateRoutingControlError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a routing control. You can only update the name of the routing control. To get or update the routing control state, see the Recovery Cluster (data plane) API actions for Amazon Route 53 Application Recovery Controller.
 */
export declare const updateRoutingControl: API.OperationMethod<UpdateRoutingControlRequest & RegionInput, UpdateRoutingControlResponse, UpdateRoutingControlError, Credentials | HttpClient.HttpClient>;
export type UpdateSafetyRuleError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update a safety rule (an assertion rule or gating rule). You can only update the name and the waiting period for a safety rule. To make other updates, delete the safety rule and create a new one.
 */
export declare const updateSafetyRule: API.OperationMethod<UpdateSafetyRuleRequest & RegionInput, UpdateSafetyRuleResponse, UpdateSafetyRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53-recovery-control-config.d.ts.map