import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryName = string;
export type Description = string | redacted.Redacted<string>;
export type KmsKeyArn = string;
export interface EncryptionConfiguration {
    kmsKeyArn: string;
}
export type DiscoveryUrl = string;
export type AllowedAudience = string;
export type AllowedAudienceList = string[];
export type AllowedClient = string;
export type AllowedClientsList = string[];
export type AllowedScopeType = string;
export type AllowedScopesType = string[];
export type InboundTokenClaimNameType = string;
export type InboundTokenClaimValueType = "STRING" | "STRING_ARRAY" | (string & {});
export type MatchValueString = string;
export type MatchValueStringList = string[];
export type ClaimMatchValueType = {
    matchValueString: string;
    matchValueStringList?: undefined;
} | {
    matchValueString?: undefined;
    matchValueStringList: string[];
};
export type ClaimMatchOperatorType = "EQUALS" | "CONTAINS" | "CONTAINS_ANY" | (string & {});
export interface AuthorizingClaimMatchValueType {
    claimMatchValue: ClaimMatchValueType;
    claimMatchOperator: ClaimMatchOperatorType;
}
export interface CustomClaimValidationType {
    inboundTokenClaimName: string;
    inboundTokenClaimValueType: InboundTokenClaimValueType;
    authorizingClaimMatchValue: AuthorizingClaimMatchValueType;
}
export type CustomClaimValidationsType = CustomClaimValidationType[];
export type ResourceConfigurationIdentifier = string;
export type SelfManagedLatticeResource = {
    resourceConfigurationIdentifier: string;
};
export type VpcIdentifier = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type EndpointIpAddressType = "IPV4" | "IPV6" | (string & {});
export type SecurityGroupIdentifier = string;
export type SecurityGroupIds = string[];
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type RoutingDomain = string;
export interface ManagedVpcResource {
    vpcIdentifier: string;
    subnetIds: string[];
    endpointIpAddressType: EndpointIpAddressType;
    securityGroupIds?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    routingDomain?: string | undefined;
}
export type PrivateEndpoint = {
    selfManagedLatticeResource: SelfManagedLatticeResource;
    managedVpcResource?: undefined;
} | {
    selfManagedLatticeResource?: undefined;
    managedVpcResource: ManagedVpcResource;
};
export type PrivateEndpointOverrideDomain = string;
export interface PrivateEndpointOverride {
    domain: string;
    privateEndpoint: PrivateEndpoint;
}
export type PrivateEndpointOverrides = PrivateEndpointOverride[];
export interface CustomJWTAuthorizerConfiguration {
    discoveryUrl: string;
    allowedAudience?: string[] | undefined;
    allowedClients?: string[] | undefined;
    allowedScopes?: string[] | undefined;
    customClaims?: CustomClaimValidationType[] | undefined;
    privateEndpoint?: PrivateEndpoint | undefined;
    privateEndpointOverrides?: PrivateEndpointOverride[] | undefined;
}
export type AuthorizerConfiguration = {
    customJWTAuthorizer: CustomJWTAuthorizerConfiguration;
};
export type RegistryAuthorizerType = "CUSTOM_JWT" | "AWS_IAM" | (string & {});
export interface DiscoveryConfiguration {
    authorizerConfiguration?: AuthorizerConfiguration | undefined;
    authorizerType?: RegistryAuthorizerType | undefined;
}
export type ClientToken = string;
export type AutoApprovalRule = "APPROVE_ALL" | (string & {});
export type AutoApprovalRuleList = AutoApprovalRule[];
export interface ApprovalConfiguration {
    autoApprovalRules?: AutoApprovalRule[] | undefined;
}
export type CustomMetadataSchemaDefinition = string | redacted.Redacted<string>;
export type RecordType = "MCP" | "AGENT" | "CUSTOM" | "SKILL" | "GATEWAY" | (string & {});
export interface RecordTypeSchemaOverride {
    recordType: RecordType;
    schema: string | redacted.Redacted<string>;
}
export type RecordTypeSchemaOverrideList = RecordTypeSchemaOverride[];
export interface CustomMetadataSchemaConfiguration {
    defaultSchema?: string | redacted.Redacted<string> | undefined;
    recordTypeSchemaOverrides?: RecordTypeSchemaOverride[] | undefined;
}
export type AutoDetectionScope = "ORGANIZATION" | (string & {});
export interface AutoDetectionConfiguration {
    scope: AutoDetectionScope;
    enabled: boolean;
}
export interface CreateRegistryRequest {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    discoveryConfiguration?: DiscoveryConfiguration | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    approvalConfiguration?: ApprovalConfiguration | undefined;
    customMetadataSchemaConfiguration?: CustomMetadataSchemaConfiguration | undefined;
    autoDetectionConfiguration?: AutoDetectionConfiguration | undefined;
}
export type RegistryArn = string;
export interface CreateRegistryResponse {
    registryArn: string;
}
export type RegistryIdentifier = string;
export type RegistryRecordName = string;
export type RegistryRecordDisplayName = string;
export type DescriptorData = string | redacted.Redacted<string>;
export type DataSchemaVersion = string;
export interface McpToolsDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
    dataSchemaVersion?: string | undefined;
}
export interface McpServerAdditionalData {
    tools?: McpToolsDescriptor | undefined;
}
export type DescriptorSourceUrl = string;
export type RegistryRecordCredentialProviderType = "OAUTH" | "IAM" | (string & {});
export type CredentialProviderArn = string;
export type RegistryRecordOAuthGrantType = "CLIENT_CREDENTIALS" | (string & {});
export type ScopeList = string[];
export type CustomParameterMap = {
    [key: string]: string | undefined;
};
export interface RegistryRecordOAuthCredentialProvider {
    providerArn: string;
    grantType?: RegistryRecordOAuthGrantType | undefined;
    scopes?: string[] | undefined;
    customParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IamRoleArn = string;
export type IamSigningServiceName = string;
export type IamSigningRegion = string;
export interface RegistryRecordIamCredentialProvider {
    roleArn?: string | undefined;
    service?: string | undefined;
    region?: string | undefined;
}
export type RegistryRecordCredentialProviderUnion = {
    oauthCredentialProvider: RegistryRecordOAuthCredentialProvider;
    iamCredentialProvider?: undefined;
} | {
    oauthCredentialProvider?: undefined;
    iamCredentialProvider: RegistryRecordIamCredentialProvider;
};
export interface RegistryRecordCredentialProviderConfiguration {
    credentialProviderType: RegistryRecordCredentialProviderType;
    credentialProvider: RegistryRecordCredentialProviderUnion;
}
export type RegistryRecordCredentialProviderConfigurationList = RegistryRecordCredentialProviderConfiguration[];
export interface DescriptorSourceFromUrl {
    url: string;
    credentialProviderConfigurations?: RegistryRecordCredentialProviderConfiguration[] | undefined;
}
export interface DescriptorSource {
    fromUrl?: DescriptorSourceFromUrl | undefined;
}
export interface McpServerDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
    dataSchemaVersion?: string | undefined;
    additionalData?: McpServerAdditionalData | undefined;
    source?: DescriptorSource | undefined;
}
export interface A2aAgentCardDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
    dataSchemaVersion?: string | undefined;
    source?: DescriptorSource | undefined;
}
export interface AgentSkillsMdDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
    dataSchemaVersion?: string | undefined;
    source?: DescriptorSource | undefined;
}
export interface AgentSkillsAdditionalData {
    skillMd?: AgentSkillsMdDescriptor | undefined;
}
export interface AgentSkillsDefinitionDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
    dataSchemaVersion?: string | undefined;
    additionalData?: AgentSkillsAdditionalData | undefined;
}
export interface CustomDescriptor {
    data?: string | redacted.Redacted<string> | undefined;
}
export interface HttpDescriptor {
    source?: DescriptorSource | undefined;
}
export interface AgUiDescriptor {
    source?: DescriptorSource | undefined;
}
export interface Descriptors {
    mcpServer?: McpServerDescriptor | undefined;
    a2aAgentCard?: A2aAgentCardDescriptor | undefined;
    agentSkillsDefinition?: AgentSkillsDefinitionDescriptor | undefined;
    custom?: CustomDescriptor | undefined;
    http?: HttpDescriptor | undefined;
    agui?: AgUiDescriptor | undefined;
}
export type RegistryRecordVersion = string;
export type ProvenanceRelation = "DETECTED_FROM" | (string & {});
export type SourceId = string;
export type SourceType = "AWS::BedrockAgentCore::Runtime" | "AWS::BedrockAgentCore::Gateway" | (string & {});
export type AgentCoreRuntimeServerProtocol = "HTTP" | "A2A" | "MCP" | "AGUI" | (string & {});
export interface AgentCoreRuntimeProtocolConfiguration {
    serverProtocol?: AgentCoreRuntimeServerProtocol | undefined;
}
export interface WorkloadIdentityDetails {
    workloadIdentityArn: string;
}
export interface AgentCoreRuntimeSourceDetails {
    protocolConfiguration?: AgentCoreRuntimeProtocolConfiguration | undefined;
    authorizerConfiguration?: AuthorizerConfiguration | undefined;
    workloadIdentityDetails?: WorkloadIdentityDetails | undefined;
}
export type AgentCoreGatewayProtocolType = "MCP" | (string & {});
export interface AgentCoreGatewaySourceDetails {
    protocolType?: AgentCoreGatewayProtocolType | undefined;
    authorizerType?: string | undefined;
    authorizerConfiguration?: AuthorizerConfiguration | undefined;
    workloadIdentityDetails?: WorkloadIdentityDetails | undefined;
}
export type SourceDetails = {
    agentcoreRuntime: AgentCoreRuntimeSourceDetails;
    agentcoreGateway?: undefined;
} | {
    agentcoreRuntime?: undefined;
    agentcoreGateway: AgentCoreGatewaySourceDetails;
};
export interface Provenance {
    relation: ProvenanceRelation;
    sourceId: string;
    sourceType?: SourceType | undefined;
    sourceDetails?: SourceDetails | undefined;
}
export type ProvenanceList = Provenance[];
export type CustomMetadataDocument = unknown;
export interface CreateRegistryRecordRequest {
    registryId: string;
    name: string;
    displayName?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    recordType: RecordType;
    descriptors: Descriptors;
    recordVersion?: string | undefined;
    clientToken?: string | undefined;
    provenance?: Provenance[] | undefined;
    customMetadata?: any | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RegistryRecordArn = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export interface CreateRegistryRecordResponse {
    recordArn: string;
    status: RegistryRecordStatus;
}
export interface DeleteRegistryRequest {
    registryId: string;
}
export type RegistryStatus = "CREATING" | "READY" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface DeleteRegistryResponse {
    status: RegistryStatus;
}
export type RecordIdentifier = string;
export interface DeleteRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export interface DeleteRegistryRecordResponse {
}
export interface GetRegistryRequest {
    registryId: string;
}
export type RegistryId = string;
export type AutoDetectionStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface AutoDetection {
    configuration: AutoDetectionConfiguration;
    status: AutoDetectionStatus;
    statusReason?: string | undefined;
}
export interface GetRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    approvalConfiguration?: ApprovalConfiguration | undefined;
    customMetadataSchemaConfiguration?: CustomMetadataSchemaConfiguration | undefined;
    status: RegistryStatus;
    statusReason?: string | undefined;
    autoDetection?: AutoDetection | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export type RegistryRecordId = string;
export type CreatorAccountId = string;
export type CustomMetadataSchemaComplianceStatus = "COMPLIANT" | "NON_COMPLIANT" | (string & {});
export interface GetRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    recordType: RecordType;
    descriptors?: Descriptors | undefined;
    recordVersion?: string | undefined;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string | undefined;
    provenance?: Provenance[] | undefined;
    createdByAutoDetection?: boolean | undefined;
    createdBy?: string | undefined;
    customMetadata?: any | undefined;
    customMetadataSchemaComplianceStatus?: CustomMetadataSchemaComplianceStatus | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export type RegistryFilterName = "status" | "discoveryConfiguration.authorizerType" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export interface RegistryFilter {
    name: RegistryFilterName;
    values: string[];
}
export type RegistryFilterList = RegistryFilter[];
export interface ListRegistriesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: RegistryFilter[] | undefined;
}
export interface RegistrySummary {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration | undefined;
    status: RegistryStatus;
    statusReason?: string | undefined;
    autoDetection?: AutoDetection | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type RegistrySummaryList = RegistrySummary[];
export interface ListRegistriesResponse {
    registries: RegistrySummary[];
    nextToken?: string | undefined;
}
export type RegistryRecordFilterName = "name" | "status" | "recordType" | (string & {});
export interface RegistryRecordFilter {
    name: RegistryRecordFilterName;
    values: string[];
}
export type RegistryRecordFilterList = RegistryRecordFilter[];
export interface ListRegistryRecordsRequest {
    registryId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: RegistryRecordFilter[] | undefined;
}
export interface ProvenanceSummary {
    relation: ProvenanceRelation;
    sourceId: string;
    sourceType?: SourceType | undefined;
}
export type ProvenanceSummaryList = ProvenanceSummary[];
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    recordType: RecordType;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    createdByAutoDetection?: boolean | undefined;
    createdBy?: string | undefined;
    provenanceSummaryList?: ProvenanceSummary[] | undefined;
    customMetadataSchemaComplianceStatus?: CustomMetadataSchemaComplianceStatus | undefined;
}
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export interface ListRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResourceTagsMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SubmitRegistryRecordForApprovalRequest {
    registryId: string;
    recordId: string;
}
export interface SubmitRegistryRecordForApprovalResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    updatedAt: Date;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdatedDescription {
    optionalValue?: string | redacted.Redacted<string> | undefined;
}
export interface UpdatedAuthorizerConfiguration {
    optionalValue?: AuthorizerConfiguration | undefined;
}
export interface UpdatedDiscoveryConfiguration {
    authorizerConfiguration?: UpdatedAuthorizerConfiguration | undefined;
}
export interface UpdatedApprovalConfiguration {
    optionalValue?: ApprovalConfiguration | undefined;
}
export interface UpdatedCustomMetadataSchemaConfiguration {
    optionalValue?: CustomMetadataSchemaConfiguration | undefined;
}
export interface UpdatedAutoDetectionConfiguration {
    optionalValue?: AutoDetectionConfiguration | undefined;
}
export interface UpdateRegistryRequest {
    registryId: string;
    name?: string | undefined;
    description?: UpdatedDescription | undefined;
    discoveryConfiguration?: UpdatedDiscoveryConfiguration | undefined;
    approvalConfiguration?: UpdatedApprovalConfiguration | undefined;
    customMetadataSchemaConfiguration?: UpdatedCustomMetadataSchemaConfiguration | undefined;
    autoDetectionConfiguration?: UpdatedAutoDetectionConfiguration | undefined;
}
export interface UpdateRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    approvalConfiguration?: ApprovalConfiguration | undefined;
    customMetadataSchemaConfiguration?: CustomMetadataSchemaConfiguration | undefined;
    status: RegistryStatus;
    statusReason?: string | undefined;
    autoDetection?: AutoDetection | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdatedDisplayName {
    optionalValue?: string | undefined;
}
export interface UpdatedDescriptorData {
    optionalValue?: string | redacted.Redacted<string> | undefined;
}
export interface UpdatedDataSchemaVersion {
    optionalValue?: string | undefined;
}
export interface UpdatedDescriptorSource {
    optionalValue?: DescriptorSource | undefined;
}
export interface UpdatedMcpToolsDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
    dataSchemaVersion?: UpdatedDataSchemaVersion | undefined;
}
export interface UpdatedMcpToolsDescriptor {
    optionalValue?: UpdatedMcpToolsDescriptorFields | undefined;
}
export interface UpdatedMcpServerAdditionalDataFields {
    tools?: UpdatedMcpToolsDescriptor | undefined;
}
export interface UpdatedMcpServerAdditionalData {
    optionalValue?: UpdatedMcpServerAdditionalDataFields | undefined;
}
export interface UpdatedMcpServerDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
    dataSchemaVersion?: UpdatedDataSchemaVersion | undefined;
    source?: UpdatedDescriptorSource | undefined;
    additionalData?: UpdatedMcpServerAdditionalData | undefined;
}
export interface UpdatedMcpServerDescriptor {
    optionalValue?: UpdatedMcpServerDescriptorFields | undefined;
}
export interface UpdatedA2aAgentCardDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
    dataSchemaVersion?: UpdatedDataSchemaVersion | undefined;
    source?: UpdatedDescriptorSource | undefined;
}
export interface UpdatedA2aAgentCardDescriptor {
    optionalValue?: UpdatedA2aAgentCardDescriptorFields | undefined;
}
export interface UpdatedAgentSkillsMdDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
    dataSchemaVersion?: UpdatedDataSchemaVersion | undefined;
    source?: UpdatedDescriptorSource | undefined;
}
export interface UpdatedAgentSkillsMdDescriptor {
    optionalValue?: UpdatedAgentSkillsMdDescriptorFields | undefined;
}
export interface UpdatedAgentSkillsAdditionalDataFields {
    skillMd?: UpdatedAgentSkillsMdDescriptor | undefined;
}
export interface UpdatedAgentSkillsAdditionalData {
    optionalValue?: UpdatedAgentSkillsAdditionalDataFields | undefined;
}
export interface UpdatedAgentSkillsDefinitionDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
    dataSchemaVersion?: UpdatedDataSchemaVersion | undefined;
    additionalData?: UpdatedAgentSkillsAdditionalData | undefined;
}
export interface UpdatedAgentSkillsDefinitionDescriptor {
    optionalValue?: UpdatedAgentSkillsDefinitionDescriptorFields | undefined;
}
export interface UpdatedCustomDescriptorFields {
    data?: UpdatedDescriptorData | undefined;
}
export interface UpdatedCustomDescriptor {
    optionalValue?: UpdatedCustomDescriptorFields | undefined;
}
export interface UpdatedHttpDescriptorFields {
    source?: UpdatedDescriptorSource | undefined;
}
export interface UpdatedHttpDescriptor {
    optionalValue?: UpdatedHttpDescriptorFields | undefined;
}
export interface UpdatedAgUiDescriptorFields {
    source?: UpdatedDescriptorSource | undefined;
}
export interface UpdatedAgUiDescriptor {
    optionalValue?: UpdatedAgUiDescriptorFields | undefined;
}
export interface UpdatedDescriptorsFields {
    mcpServer?: UpdatedMcpServerDescriptor | undefined;
    a2aAgentCard?: UpdatedA2aAgentCardDescriptor | undefined;
    agentSkillsDefinition?: UpdatedAgentSkillsDefinitionDescriptor | undefined;
    custom?: UpdatedCustomDescriptor | undefined;
    http?: UpdatedHttpDescriptor | undefined;
    agui?: UpdatedAgUiDescriptor | undefined;
}
export interface UpdatedDescriptors {
    optionalValue?: UpdatedDescriptorsFields | undefined;
}
export interface UpdatedCustomMetadataMap {
    optionalValue?: any | undefined;
}
export interface UpdateRegistryRecordRequest {
    registryId: string;
    recordId: string;
    name?: string | undefined;
    displayName?: UpdatedDisplayName | undefined;
    description?: UpdatedDescription | undefined;
    recordType?: RecordType | undefined;
    descriptors?: UpdatedDescriptors | undefined;
    recordVersion?: string | undefined;
    customMetadata?: UpdatedCustomMetadataMap | undefined;
    triggerSynchronization?: boolean | undefined;
    provenance?: Provenance[] | undefined;
}
export interface UpdateRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    recordType: RecordType;
    descriptors?: Descriptors | undefined;
    recordVersion?: string | undefined;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string | undefined;
    provenance?: Provenance[] | undefined;
    createdByAutoDetection?: boolean | undefined;
    createdBy?: string | undefined;
    customMetadata?: any | undefined;
    customMetadataSchemaComplianceStatus?: CustomMetadataSchemaComplianceStatus | undefined;
}
export interface UpdateRegistryRecordStatusRequest {
    registryId: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
}
export interface UpdateRegistryRecordStatusResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
    updatedAt: Date;
}
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new registry, a catalog that organizes registry records and defines their discovery authorization and record approval behavior. Creation is asynchronous: the registry begins in the CREATING status and becomes usable once it reaches READY.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryRequest & RegionInput, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a registry record within a registry. A registry record describes a discoverable resource, such as an MCP server, an agent, an agent skill, or a custom resource. Creation is asynchronous: the record is returned with the CREATING status while it is processed.
 */
export declare const createRegistryRecord: API.OperationMethod<CreateRegistryRecordRequest & RegionInput, CreateRegistryRecordResponse, CreateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry. Deletion is asynchronous: the registry transitions to the DELETING status and is removed along with its registry records.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryRequest & RegionInput, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry record
 */
export declare const deleteRegistryRecord: API.OperationMethod<DeleteRegistryRecordRequest & RegionInput, DeleteRegistryRecordResponse, DeleteRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type GetRegistryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a registry by identifier (ARN or ID)
 */
export declare const getRegistry: API.OperationMethod<GetRegistryRequest & RegionInput, GetRegistryResponse, GetRegistryError, Credentials | HttpClient.HttpClient>;
export type GetRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a registry record
 */
export declare const getRegistryRecord: API.OperationMethod<GetRegistryRecordRequest & RegionInput, GetRegistryRecordResponse, GetRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type ListRegistriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the registries in the caller's account and Region, with optional filtering by status and discovery authorizer type
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesRequest & RegionInput, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistrySummary>;
export type ListRegistryRecordsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the registry records within a registry, with optional filtering by name, status, and record type
 */
export declare const listRegistryRecords: API.PaginatedOperationMethod<ListRegistryRecordsRequest & RegionInput, ListRegistryRecordsResponse, ListRegistryRecordsError, Credentials | HttpClient.HttpClient, RegistryRecordSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with the specified Amazon Web Services Agent Registry resource. Returns the current tag key-value pairs on the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SubmitRegistryRecordForApprovalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a DRAFT registry record for approval, moving it into the registry's approval workflow. Depending on the registry's approval configuration, the record is either auto-approved or set to PENDING_APPROVAL for a curator to approve or reject.
 */
export declare const submitRegistryRecordForApproval: API.OperationMethod<SubmitRegistryRecordForApprovalRequest & RegionInput, SubmitRegistryRecordForApprovalResponse, SubmitRegistryRecordForApprovalError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified Amazon Web Services Agent Registry resource. Tags are key-value pairs that you can use to categorize and manage Amazon Web Services resources. If a tag with the same key already exists on the resource, the service replaces its value with the value you specify.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified Amazon Web Services Agent Registry resource. The operation removes only the tags whose keys you supply; other tags on the resource remain unchanged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing registry. This operation uses PATCH semantics: specify only the fields you want to change, and omit the rest to leave them unchanged. Updates are applied asynchronously and the registry transitions to the UPDATING status while they are processed.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryRequest & RegionInput, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a registry record. The update is asynchronous: the record is returned with the UPDATING status while it is processed. Fields that use update wrappers follow PATCH semantics: omit the field to leave it unchanged.
 */
export declare const updateRegistryRecord: API.OperationMethod<UpdateRegistryRecordRequest & RegionInput, UpdateRegistryRecordResponse, UpdateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a registry record as part of the registry's curation workflow, for example to approve or reject a record that is pending approval, or to deprecate an approved record so that it is no longer discoverable
 */
export declare const updateRegistryRecordStatus: API.OperationMethod<UpdateRegistryRecordStatusRequest & RegionInput, UpdateRegistryRecordStatusResponse, UpdateRegistryRecordStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=agent-registry-control.d.ts.map