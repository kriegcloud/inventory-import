import type * as Containers from "@distilled.cloud/cloudflare/containers";
import type { ScopedPlanStatusSession } from "alchemy/Report";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import { ContainerImagePreparationError } from "./ContainerConfiguration.ts";
/** Wait for Cloudflare preparation, with an interruptible deadline including API calls. */
export declare const waitForContainerImage: <E, R>(options: {
    image: string;
    name: string;
    timeout?: Duration.Input;
    prepare: Effect.Effect<Containers.PrepareContainerImageResponse, E, R>;
    session: Pick<ScopedPlanStatusSession, "note">;
}) => Effect.Effect<void, E | import("./ContainerConfiguration.ts").ContainerConfigurationError | ContainerImagePreparationError, R>;
/**
 * Real-path a user-supplied build `context` and `dockerfile`. A relative
 * `dockerfile` resolves against `context`, like Docker Compose.
 * Defaults to `<context>/Dockerfile`.
 */
export declare const resolveContainerBuildPaths: (props: {
    context: string | undefined;
    dockerfile: string | undefined;
}) => Effect.Effect<{
    context: string;
    dockerfile: string;
}, import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=ContainerImagePreparation.d.ts.map