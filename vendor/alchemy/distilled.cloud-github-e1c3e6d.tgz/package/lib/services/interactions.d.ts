import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetPullRequestBypassListForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type GetPullRequestBypassListForRepoResponseBodyList = Array<SimpleUser>;
export type GetPullRequestBypassListForRepoResponse = GetPullRequestBypassListForRepoResponseBodyList;
export interface GetPullRequestCreationCapForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface GetPullRequestCreationCapForOrgResponse {
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests: number;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export interface GetPullRequestCreationCapForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetPullRequestCreationCapForRepoResponse {
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests: number;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export interface GetRestrictionsForAuthenticatedUserRequest {
}
/** The type of GitHub user that can comment, open issues, or create pull requests while the interaction limit is in effect. */
export type InteractionGroup = "existing_users" | "contributors_only" | "collaborators_only";
/** Interaction limit settings. */
export interface InteractionLimitResponse {
    limit: InteractionGroup;
    origin: string;
    expires_at: string;
}
export type GetRestrictionsForAuthenticatedUserResponseBody = InteractionLimitResponse | unknown;
export type GetRestrictionsForAuthenticatedUserResponse = GetRestrictionsForAuthenticatedUserResponseBody;
export interface GetRestrictionsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type GetRestrictionsForOrgResponseBody = InteractionLimitResponse | unknown;
export type GetRestrictionsForOrgResponse = GetRestrictionsForOrgResponseBody;
export interface GetRestrictionsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type GetRestrictionsForRepoResponseBody = InteractionLimitResponse | unknown;
export type GetRestrictionsForRepoResponse = GetRestrictionsForRepoResponseBody;
/** A list of user logins to add or remove from the bypass list. */
export type RemovePullRequestBypassListForRepoRequestUsersList = Array<string>;
export interface RemovePullRequestBypassListForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A list of user logins to add or remove from the bypass list. */
    users: RemovePullRequestBypassListForRepoRequestUsersList;
}
export interface RemovePullRequestBypassListForRepoResponse {
}
export interface RemoveRestrictionsForAuthenticatedUserRequest {
}
export interface RemoveRestrictionsForAuthenticatedUserResponse {
}
export interface RemoveRestrictionsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface RemoveRestrictionsForOrgResponse {
}
export interface RemoveRestrictionsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface RemoveRestrictionsForRepoResponse {
}
/** A list of user logins to add or remove from the bypass list. */
export type SetPullRequestBypassListForRepoRequestUsersList = Array<string>;
export interface SetPullRequestBypassListForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A list of user logins to add or remove from the bypass list. */
    users: SetPullRequestBypassListForRepoRequestUsersList;
}
export interface SetPullRequestBypassListForRepoResponse {
}
/** The duration of the interaction restriction. Default: `one_day`. */
export type InteractionExpiry = "one_day" | "three_days" | "one_week" | "one_month" | "six_months";
export interface SetRestrictionsForAuthenticatedUserRequest {
    limit: InteractionGroup | (string & {});
    expiry?: InteractionExpiry | (string & {}) | undefined;
}
export interface SetRestrictionsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    limit: InteractionGroup | (string & {});
    expiry?: InteractionExpiry | (string & {}) | undefined;
}
export interface SetRestrictionsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    limit: InteractionGroup | (string & {});
    expiry?: InteractionExpiry | (string & {}) | undefined;
}
export interface UpdatePullRequestCreationCapForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests?: number | undefined;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export interface UpdatePullRequestCreationCapForOrgResponse {
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests: number;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export interface UpdatePullRequestCreationCapForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests?: number | undefined;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export interface UpdatePullRequestCreationCapForRepoResponse {
    /** Whether the pull request creation cap is enabled */
    enabled: boolean;
    /** The maximum number of open pull requests a user can have at one time */
    max_open_pull_requests: number;
    /** Whether draft pull requests count toward the pull request creation cap */
    include_drafts?: boolean | undefined;
}
export type GetPullRequestBypassListForRepoError = GithubOpError;
/** Get pull request creation cap bypass list for a repository Lists the users that are on the pull request creation cap bypass list for a repository. Users on this list can create pull requests regardless of any configured pull request creation cap. Only users with maintainer permissions can view the bypass list. */
export declare const getPullRequestBypassListForRepo: API.OperationMethod<GetPullRequestBypassListForRepoRequest, GetPullRequestBypassListForRepoResponse, GetPullRequestBypassListForRepoError, GithubOpContext>;
export type GetPullRequestCreationCapForOrgError = GithubOpError;
/** Get pull request creation cap for an org Gets the pull request creation cap configuration for an organization. The cap limits the total number of open pull requests a user can have across all public repositories in the organization at one time. Only users with admin access to the organization can view the cap configuration. */
export declare const getPullRequestCreationCapForOrg: API.OperationMethod<GetPullRequestCreationCapForOrgRequest, GetPullRequestCreationCapForOrgResponse, GetPullRequestCreationCapForOrgError, GithubOpContext>;
export type GetPullRequestCreationCapForRepoError = GithubOpError;
/** Get pull request creation cap for a repository Gets the pull request creation cap configuration for a repository. The cap limits the number of open pull requests a user can have at one time. Only users with admin access to the repository can view the cap configuration. */
export declare const getPullRequestCreationCapForRepo: API.OperationMethod<GetPullRequestCreationCapForRepoRequest, GetPullRequestCreationCapForRepoResponse, GetPullRequestCreationCapForRepoError, GithubOpContext>;
export type GetRestrictionsForAuthenticatedUserError = GithubOpError;
/** Get interaction restrictions for your public repositories Shows which type of GitHub user can interact with your public repositories and when the restriction expires. */
export declare const getRestrictionsForAuthenticatedUser: API.OperationMethod<GetRestrictionsForAuthenticatedUserRequest, GetRestrictionsForAuthenticatedUserResponse, GetRestrictionsForAuthenticatedUserError, GithubOpContext>;
export type GetRestrictionsForOrgError = GithubOpError;
/** Get interaction restrictions for an organization Shows which type of GitHub user can interact with this organization and when the restriction expires. If there is no restrictions, you will see an empty response. */
export declare const getRestrictionsForOrg: API.OperationMethod<GetRestrictionsForOrgRequest, GetRestrictionsForOrgResponse, GetRestrictionsForOrgError, GithubOpContext>;
export type GetRestrictionsForRepoError = GithubOpError;
/** Get interaction restrictions for a repository Shows which type of GitHub user can interact with this repository and when the restriction expires. If there are no restrictions, you will see an empty response. */
export declare const getRestrictionsForRepo: API.OperationMethod<GetRestrictionsForRepoRequest, GetRestrictionsForRepoResponse, GetRestrictionsForRepoError, GithubOpContext>;
export type RemovePullRequestBypassListForRepoError = GithubOpError;
/** Remove users from the pull request creation cap bypass list for a repository Removes users from the pull request creation cap bypass list for a repository. Removed users will be subject to any configured pull request creation cap. Only users with maintainer permissions can modify the bypass list. You can remove a maximum of 100 users per request. */
export declare const removePullRequestBypassListForRepo: API.OperationMethod<RemovePullRequestBypassListForRepoRequest, RemovePullRequestBypassListForRepoResponse, RemovePullRequestBypassListForRepoError, GithubOpContext>;
export type RemoveRestrictionsForAuthenticatedUserError = GithubOpError;
/** Remove interaction restrictions from your public repositories Removes any interaction restrictions from your public repositories. */
export declare const removeRestrictionsForAuthenticatedUser: API.OperationMethod<RemoveRestrictionsForAuthenticatedUserRequest, RemoveRestrictionsForAuthenticatedUserResponse, RemoveRestrictionsForAuthenticatedUserError, GithubOpContext>;
export type RemoveRestrictionsForOrgError = GithubOpError;
/** Remove interaction restrictions for an organization Removes all interaction restrictions from public repositories in the given organization. You must be an organization owner to remove restrictions. */
export declare const removeRestrictionsForOrg: API.OperationMethod<RemoveRestrictionsForOrgRequest, RemoveRestrictionsForOrgResponse, RemoveRestrictionsForOrgError, GithubOpContext>;
export type RemoveRestrictionsForRepoError = GithubOpError;
/** Remove interaction restrictions for a repository Removes all interaction restrictions from the given repository. You must have owner or admin access to remove restrictions. If the interaction limit is set for the user or organization that owns this repository, you will receive a `409 Conflict` response and will not be able to use this endpoint to change the interaction limit for a single repository. */
export declare const removeRestrictionsForRepo: API.OperationMethod<RemoveRestrictionsForRepoRequest, RemoveRestrictionsForRepoResponse, RemoveRestrictionsForRepoError, GithubOpContext>;
export type SetPullRequestBypassListForRepoError = GithubOpError;
/** Add users to the pull request creation cap bypass list for a repository Adds users to the pull request creation cap bypass list for a repository. Users on this list can create pull requests regardless of any configured pull request creation cap. Only users with maintainer permissions can modify the bypass list. You can add a maximum of 100 users per request. The bypass list can only hold a maximum of 100 users. */
export declare const setPullRequestBypassListForRepo: API.OperationMethod<SetPullRequestBypassListForRepoRequest, SetPullRequestBypassListForRepoResponse, SetPullRequestBypassListForRepoError, GithubOpContext>;
export type SetRestrictionsForAuthenticatedUserError = GithubOpError;
/** Set interaction restrictions for your public repositories Temporarily restricts which type of GitHub user can interact with your public repositories. Setting the interaction limit at the user level will overwrite any interaction limits that are set for individual repositories owned by the user. */
export declare const setRestrictionsForAuthenticatedUser: API.OperationMethod<SetRestrictionsForAuthenticatedUserRequest, InteractionLimitResponse, SetRestrictionsForAuthenticatedUserError, GithubOpContext>;
export type SetRestrictionsForOrgError = GithubOpError;
/** Set interaction restrictions for an organization Temporarily restricts interactions to a certain type of GitHub user in any public repository in the given organization. You must be an organization owner to set these restrictions. Setting the interaction limit at the organization level will overwrite any interaction limits that are set for individual repositories owned by the organization. */
export declare const setRestrictionsForOrg: API.OperationMethod<SetRestrictionsForOrgRequest, InteractionLimitResponse, SetRestrictionsForOrgError, GithubOpContext>;
export type SetRestrictionsForRepoError = GithubOpError;
/** Set interaction restrictions for a repository Temporarily restricts interactions to a certain type of GitHub user within the given repository. You must have owner or admin access to set these restrictions. If an interaction limit is set for the user or organization that owns this repository, you will receive a `409 Conflict` response and will not be able to use this endpoint to change the interaction limit for a single repository. */
export declare const setRestrictionsForRepo: API.OperationMethod<SetRestrictionsForRepoRequest, InteractionLimitResponse, SetRestrictionsForRepoError, GithubOpContext>;
export type UpdatePullRequestCreationCapForOrgError = GithubOpError;
/** Update pull request creation cap for an org Updates the pull request creation cap for an organization. The cap limits the total number of open pull requests a user can have across all public repositories in the organization at one time. Only users with admin access to the organization can configure the cap. */
export declare const updatePullRequestCreationCapForOrg: API.OperationMethod<UpdatePullRequestCreationCapForOrgRequest, UpdatePullRequestCreationCapForOrgResponse, UpdatePullRequestCreationCapForOrgError, GithubOpContext>;
export type UpdatePullRequestCreationCapForRepoError = GithubOpError;
/** Update pull request creation cap for a repository Updates the pull request creation cap for a repository. The cap limits the number of open pull requests a user can have at one time. Only users with admin access to the repository can configure the cap. */
export declare const updatePullRequestCreationCapForRepo: API.OperationMethod<UpdatePullRequestCreationCapForRepoRequest, UpdatePullRequestCreationCapForRepoResponse, UpdatePullRequestCreationCapForRepoError, GithubOpContext>;
//# sourceMappingURL=interactions.d.ts.map