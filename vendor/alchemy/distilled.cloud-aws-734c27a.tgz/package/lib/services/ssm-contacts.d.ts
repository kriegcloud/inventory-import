import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly DependentEntities: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DataEncryptionException_base: S.TaggedErrorClass<"DataEncryptionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DataEncryptionException extends /*@__PURE__*/ DataEncryptionException_base {
}
declare const IncidentManagerNotOnboarded_base: S.TaggedErrorClass<"IncidentManagerNotOnboarded", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncidentManagerNotOnboarded extends /*@__PURE__*/ IncidentManagerNotOnboarded_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRotationArn_base: S.TaggedErrorClass<"InvalidRotationArn", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRotationArn extends /*@__PURE__*/ InvalidRotationArn_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SsmContactsArn = string;
export type AcceptType = "DELIVERED" | "READ" | (string & {});
export type ReceiptInfo = string;
export type AcceptCode = string;
export type AcceptCodeValidation = "IGNORE" | "ENFORCE" | (string & {});
export interface AcceptPageRequest {
    PageId: string;
    ContactChannelId?: string | undefined;
    AcceptType: AcceptType;
    Note?: string | undefined;
    AcceptCode: string;
    AcceptCodeValidation?: AcceptCodeValidation | undefined;
}
export interface AcceptPageResult {
}
export type ActivationCode = string;
export interface ActivateContactChannelRequest {
    ContactChannelId: string;
    ActivationCode: string;
}
export interface ActivateContactChannelResult {
}
export type ContactAlias = string;
export type ContactName = string;
export type ContactType = "PERSONAL" | "ESCALATION" | "ONCALL_SCHEDULE" | (string & {});
export type StageDurationInMins = number;
export type RetryIntervalInMinutes = number;
export interface ChannelTargetInfo {
    ContactChannelId: string;
    RetryIntervalInMinutes?: number | undefined;
}
export type IsEssential = boolean;
export interface ContactTargetInfo {
    ContactId?: string | undefined;
    IsEssential: boolean;
}
export interface Target {
    ChannelTargetInfo?: ChannelTargetInfo | undefined;
    ContactTargetInfo?: ContactTargetInfo | undefined;
}
export type TargetsList = Target[];
export interface Stage {
    DurationInMinutes: number;
    Targets: Target[];
}
export type StagesList = Stage[];
export type SsmContactsArnList = string[];
export interface Plan {
    Stages?: Stage[] | undefined;
    RotationIds?: string[] | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagsList = Tag[];
export type IdempotencyToken = string;
export interface CreateContactRequest {
    Alias: string;
    DisplayName?: string | undefined;
    Type: ContactType;
    Plan: Plan;
    Tags?: Tag[] | undefined;
    IdempotencyToken?: string | undefined;
}
export interface CreateContactResult {
    ContactArn: string;
}
export type ChannelName = string;
export type ChannelType = "SMS" | "VOICE" | "EMAIL" | (string & {});
export type SimpleAddress = string;
export interface ContactChannelAddress {
    SimpleAddress?: string | undefined;
}
export type DeferActivation = boolean;
export interface CreateContactChannelRequest {
    ContactId: string;
    Name: string;
    Type: ChannelType;
    DeliveryAddress: ContactChannelAddress;
    DeferActivation?: boolean | undefined;
    IdempotencyToken?: string | undefined;
}
export interface CreateContactChannelResult {
    ContactChannelArn: string;
}
export type RotationName = string;
export type RotationContactsArnList = string[];
export type TimeZoneId = string;
export type DayOfMonth = number;
export type HourOfDay = number;
export type MinuteOfHour = number;
export interface HandOffTime {
    HourOfDay: number;
    MinuteOfHour: number;
}
export interface MonthlySetting {
    DayOfMonth: number;
    HandOffTime: HandOffTime;
}
export type MonthlySettings = MonthlySetting[];
export type DayOfWeek = "MON" | "TUE" | "WED" | "THU" | "FRI" | "SAT" | "SUN" | (string & {});
export interface WeeklySetting {
    DayOfWeek: DayOfWeek;
    HandOffTime: HandOffTime;
}
export type WeeklySettings = WeeklySetting[];
export type DailySettings = HandOffTime[];
export type NumberOfOnCalls = number;
export interface CoverageTime {
    Start?: HandOffTime | undefined;
    End?: HandOffTime | undefined;
}
export type CoverageTimes = CoverageTime[];
export type ShiftCoveragesMap = {
    [key in DayOfWeek]?: CoverageTime[] | undefined;
};
export type RecurrenceMultiplier = number;
export interface RecurrenceSettings {
    MonthlySettings?: MonthlySetting[] | undefined;
    WeeklySettings?: WeeklySetting[] | undefined;
    DailySettings?: HandOffTime[] | undefined;
    NumberOfOnCalls: number;
    ShiftCoverages?: {
        [key: string]: CoverageTime[] | undefined;
    } | undefined;
    RecurrenceMultiplier: number;
}
export interface CreateRotationRequest {
    Name: string;
    ContactIds: string[];
    StartTime?: Date | undefined;
    TimeZoneId: string;
    Recurrence: RecurrenceSettings;
    Tags?: Tag[] | undefined;
    IdempotencyToken?: string | undefined;
}
export interface CreateRotationResult {
    RotationArn: string;
}
export type RotationOverrideContactsArnList = string[];
export interface CreateRotationOverrideRequest {
    RotationId: string;
    NewContactIds: string[];
    StartTime: Date;
    EndTime: Date;
    IdempotencyToken?: string | undefined;
}
export type Uuid = string;
export interface CreateRotationOverrideResult {
    RotationOverrideId: string;
}
export interface DeactivateContactChannelRequest {
    ContactChannelId: string;
}
export interface DeactivateContactChannelResult {
}
export interface DeleteContactRequest {
    ContactId: string;
}
export interface DeleteContactResult {
}
export interface DeleteContactChannelRequest {
    ContactChannelId: string;
}
export interface DeleteContactChannelResult {
}
export interface DeleteRotationRequest {
    RotationId: string;
}
export interface DeleteRotationResult {
}
export interface DeleteRotationOverrideRequest {
    RotationId: string;
    RotationOverrideId: string;
}
export interface DeleteRotationOverrideResult {
}
export interface DescribeEngagementRequest {
    EngagementId: string;
}
export type Sender = string;
export type Subject = string;
export type Content = string;
export type PublicSubject = string;
export type PublicContent = string;
export type IncidentId = string;
export interface DescribeEngagementResult {
    ContactArn: string;
    EngagementArn: string;
    Sender: string;
    Subject: string;
    Content: string;
    PublicSubject?: string | undefined;
    PublicContent?: string | undefined;
    IncidentId?: string | undefined;
    StartTime?: Date | undefined;
    StopTime?: Date | undefined;
}
export interface DescribePageRequest {
    PageId: string;
}
export interface DescribePageResult {
    PageArn: string;
    EngagementArn: string;
    ContactArn: string;
    Sender: string;
    Subject: string;
    Content: string;
    PublicSubject?: string | undefined;
    PublicContent?: string | undefined;
    IncidentId?: string | undefined;
    SentTime?: Date | undefined;
    ReadTime?: Date | undefined;
    DeliveryTime?: Date | undefined;
}
export interface GetContactRequest {
    ContactId: string;
}
export interface GetContactResult {
    ContactArn: string;
    Alias: string;
    DisplayName?: string | undefined;
    Type: ContactType;
    Plan: Plan;
}
export interface GetContactChannelRequest {
    ContactChannelId: string;
}
export type ActivationStatus = "ACTIVATED" | "NOT_ACTIVATED" | (string & {});
export interface GetContactChannelResult {
    ContactArn: string;
    ContactChannelArn: string;
    Name: string;
    Type: ChannelType;
    DeliveryAddress: ContactChannelAddress;
    ActivationStatus?: ActivationStatus | undefined;
}
export interface GetContactPolicyRequest {
    ContactArn: string;
}
export type Policy = string;
export interface GetContactPolicyResult {
    ContactArn?: string | undefined;
    Policy?: string | undefined;
}
export interface GetRotationRequest {
    RotationId: string;
}
export interface GetRotationResult {
    RotationArn: string;
    Name: string;
    ContactIds: string[];
    StartTime: Date;
    TimeZoneId: string;
    Recurrence: RecurrenceSettings;
}
export interface GetRotationOverrideRequest {
    RotationId: string;
    RotationOverrideId: string;
}
export interface GetRotationOverrideResult {
    RotationOverrideId?: string | undefined;
    RotationArn?: string | undefined;
    NewContactIds?: string[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    CreateTime?: Date | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListContactChannelsRequest {
    ContactId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ContactChannel {
    ContactChannelArn: string;
    ContactArn: string;
    Name: string;
    Type?: ChannelType | undefined;
    DeliveryAddress: ContactChannelAddress;
    ActivationStatus: ActivationStatus;
}
export type ContactChannelList = ContactChannel[];
export interface ListContactChannelsResult {
    NextToken?: string | undefined;
    ContactChannels: ContactChannel[];
}
export interface ListContactsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AliasPrefix?: string | undefined;
    Type?: ContactType | undefined;
}
export interface Contact {
    ContactArn: string;
    Alias: string;
    DisplayName?: string | undefined;
    Type: ContactType;
}
export type ContactsList = Contact[];
export interface ListContactsResult {
    NextToken?: string | undefined;
    Contacts?: Contact[] | undefined;
}
export interface TimeRange {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface ListEngagementsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    IncidentId?: string | undefined;
    TimeRangeValue?: TimeRange | undefined;
}
export interface Engagement {
    EngagementArn: string;
    ContactArn: string;
    Sender: string;
    IncidentId?: string | undefined;
    StartTime?: Date | undefined;
    StopTime?: Date | undefined;
}
export type EngagementsList = Engagement[];
export interface ListEngagementsResult {
    NextToken?: string | undefined;
    Engagements: Engagement[];
}
export interface ListPageReceiptsRequest {
    PageId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ReceiptType = "DELIVERED" | "ERROR" | "READ" | "SENT" | "STOP" | (string & {});
export interface Receipt {
    ContactChannelArn?: string | undefined;
    ReceiptType: ReceiptType;
    ReceiptInfo?: string | undefined;
    ReceiptTime: Date;
}
export type ReceiptsList = Receipt[];
export interface ListPageReceiptsResult {
    NextToken?: string | undefined;
    Receipts?: Receipt[] | undefined;
}
export interface ListPageResolutionsRequest {
    NextToken?: string | undefined;
    PageId: string;
}
export type StageIndex = number;
export interface ResolutionContact {
    ContactArn: string;
    Type: ContactType;
    StageIndex?: number | undefined;
}
export type ResolutionList = ResolutionContact[];
export interface ListPageResolutionsResult {
    NextToken?: string | undefined;
    PageResolutions: ResolutionContact[];
}
export interface ListPagesByContactRequest {
    ContactId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface Page {
    PageArn: string;
    EngagementArn: string;
    ContactArn: string;
    Sender: string;
    IncidentId?: string | undefined;
    SentTime?: Date | undefined;
    DeliveryTime?: Date | undefined;
    ReadTime?: Date | undefined;
}
export type PagesList = Page[];
export interface ListPagesByContactResult {
    NextToken?: string | undefined;
    Pages: Page[];
}
export interface ListPagesByEngagementRequest {
    EngagementId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListPagesByEngagementResult {
    NextToken?: string | undefined;
    Pages: Page[];
}
export type Member = string;
export type RotationPreviewMemberList = string[];
export type RotationOverridePreviewMemberList = string[];
export interface PreviewOverride {
    NewMembers?: string[] | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type OverrideList = PreviewOverride[];
export interface ListPreviewRotationShiftsRequest {
    RotationStartTime?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime: Date;
    Members: string[];
    TimeZoneId: string;
    Recurrence: RecurrenceSettings;
    Overrides?: PreviewOverride[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ShiftType = "REGULAR" | "OVERRIDDEN" | (string & {});
export interface ShiftDetails {
    OverriddenContactIds: string[];
}
export interface RotationShift {
    ContactIds?: string[] | undefined;
    StartTime: Date;
    EndTime: Date;
    Type?: ShiftType | undefined;
    ShiftDetails?: ShiftDetails | undefined;
}
export type RotationShifts = RotationShift[];
export interface ListPreviewRotationShiftsResult {
    RotationShifts?: RotationShift[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRotationOverridesRequest {
    RotationId: string;
    StartTime: Date;
    EndTime: Date;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RotationOverride {
    RotationOverrideId: string;
    NewContactIds: string[];
    StartTime: Date;
    EndTime: Date;
    CreateTime: Date;
}
export type RotationOverrides = RotationOverride[];
export interface ListRotationOverridesResult {
    RotationOverrides?: RotationOverride[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRotationsRequest {
    RotationNamePrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface Rotation {
    RotationArn: string;
    Name: string;
    ContactIds?: string[] | undefined;
    StartTime?: Date | undefined;
    TimeZoneId?: string | undefined;
    Recurrence?: RecurrenceSettings | undefined;
}
export type Rotations = Rotation[];
export interface ListRotationsResult {
    NextToken?: string | undefined;
    Rotations: Rotation[];
}
export interface ListRotationShiftsRequest {
    RotationId: string;
    StartTime?: Date | undefined;
    EndTime: Date;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListRotationShiftsResult {
    RotationShifts?: RotationShift[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResult {
    Tags?: Tag[] | undefined;
}
export interface PutContactPolicyRequest {
    ContactArn: string;
    Policy: string;
}
export interface PutContactPolicyResult {
}
export interface SendActivationCodeRequest {
    ContactChannelId: string;
}
export interface SendActivationCodeResult {
}
export interface StartEngagementRequest {
    ContactId: string;
    Sender: string;
    Subject: string;
    Content: string;
    PublicSubject?: string | undefined;
    PublicContent?: string | undefined;
    IncidentId?: string | undefined;
    IdempotencyToken?: string | undefined;
}
export interface StartEngagementResult {
    EngagementArn: string;
}
export type StopReason = string;
export interface StopEngagementRequest {
    EngagementId: string;
    Reason?: string | undefined;
}
export interface StopEngagementResult {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResult {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResult {
}
export interface UpdateContactRequest {
    ContactId: string;
    DisplayName?: string | undefined;
    Plan?: Plan | undefined;
}
export interface UpdateContactResult {
}
export interface UpdateContactChannelRequest {
    ContactChannelId: string;
    Name?: string | undefined;
    DeliveryAddress?: ContactChannelAddress | undefined;
}
export interface UpdateContactChannelResult {
}
export interface UpdateRotationRequest {
    RotationId: string;
    ContactIds?: string[] | undefined;
    StartTime?: Date | undefined;
    TimeZoneId?: string | undefined;
    Recurrence: RecurrenceSettings;
}
export interface UpdateRotationResult {
}
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export interface DependentEntity {
    RelationType: string;
    DependentResourceIds: string[];
}
export type DependentEntityList = DependentEntity[];
export type AcceptPageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Used to acknowledge an engagement to a contact channel during an incident.
 */
export declare const acceptPage: API.OperationMethod<AcceptPageRequest & RegionInput, AcceptPageResult, AcceptPageError, Credentials | HttpClient.HttpClient>;
export type ActivateContactChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Activates a contact's contact channel. Incident Manager can't engage a contact until the
 * contact channel has been activated.
 */
export declare const activateContactChannel: API.OperationMethod<ActivateContactChannelRequest & RegionInput, ActivateContactChannelResult, ActivateContactChannelError, Credentials | HttpClient.HttpClient>;
export type CreateContactError = AccessDeniedException | ConflictException | DataEncryptionException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Contacts are either the contacts that Incident Manager engages during an incident or the
 * escalation plans that Incident Manager uses to engage contacts in phases during an
 * incident.
 */
export declare const createContact: API.OperationMethod<CreateContactRequest & RegionInput, CreateContactResult, CreateContactError, Credentials | HttpClient.HttpClient>;
export type CreateContactChannelError = AccessDeniedException | ConflictException | DataEncryptionException | InternalServerException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * A contact channel is the method that Incident Manager uses to engage your contact.
 */
export declare const createContactChannel: API.OperationMethod<CreateContactChannelRequest & RegionInput, CreateContactChannelResult, CreateContactChannelError, Credentials | HttpClient.HttpClient>;
export type CreateRotationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ConflictException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Creates a rotation in an on-call schedule.
 */
export declare const createRotation: API.OperationMethod<CreateRotationRequest & RegionInput, CreateRotationResult, CreateRotationError, Credentials | HttpClient.HttpClient>;
export type CreateRotationOverrideError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Creates an override for a rotation in an on-call schedule.
 */
export declare const createRotationOverride: API.OperationMethod<CreateRotationOverrideRequest & RegionInput, CreateRotationOverrideResult, CreateRotationOverrideError, Credentials | HttpClient.HttpClient>;
export type DeactivateContactChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * To no longer receive Incident Manager engagements to a contact channel, you can deactivate
 * the channel.
 */
export declare const deactivateContactChannel: API.OperationMethod<DeactivateContactChannelRequest & RegionInput, DeactivateContactChannelResult, DeactivateContactChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteContactError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * To remove a contact from Incident Manager, you can delete the contact. However, deleting a
 * contact does not remove it from escalation plans and related response plans. Deleting an
 * escalation plan also does not remove it from all related response plans. To modify an
 * escalation plan, we recommend using the UpdateContact action to specify a
 * different existing contact.
 */
export declare const deleteContact: API.OperationMethod<DeleteContactRequest & RegionInput, DeleteContactResult, DeleteContactError, Credentials | HttpClient.HttpClient>;
export type DeleteContactChannelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * To stop receiving engagements on a contact channel, you can delete the channel from a
 * contact. Deleting the contact channel does not remove it from the contact's engagement
 * plan, but the stage that includes the channel will be ignored. If you delete the only
 * contact channel for a contact, you'll no longer be able to engage that contact during an
 * incident.
 */
export declare const deleteContactChannel: API.OperationMethod<DeleteContactChannelRequest & RegionInput, DeleteContactChannelResult, DeleteContactChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteRotationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Deletes a rotation from the system. If a rotation belongs to more than one on-call
 * schedule, this operation deletes it from all of them.
 */
export declare const deleteRotation: API.OperationMethod<DeleteRotationRequest & RegionInput, DeleteRotationResult, DeleteRotationError, Credentials | HttpClient.HttpClient>;
export type DeleteRotationOverrideError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Deletes an existing override for an on-call rotation.
 */
export declare const deleteRotationOverride: API.OperationMethod<DeleteRotationOverrideRequest & RegionInput, DeleteRotationOverrideResult, DeleteRotationOverrideError, Credentials | HttpClient.HttpClient>;
export type DescribeEngagementError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Incident Manager uses engagements to engage contacts and escalation plans during an incident.
 * Use this command to describe the engagement that occurred during an incident.
 */
export declare const describeEngagement: API.OperationMethod<DescribeEngagementRequest & RegionInput, DescribeEngagementResult, DescribeEngagementError, Credentials | HttpClient.HttpClient>;
export type DescribePageError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists details of the engagement to a contact channel.
 */
export declare const describePage: API.OperationMethod<DescribePageRequest & RegionInput, DescribePageResult, DescribePageError, Credentials | HttpClient.HttpClient>;
export type GetContactError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Retrieves information about the specified contact or escalation plan.
 */
export declare const getContact: API.OperationMethod<GetContactRequest & RegionInput, GetContactResult, GetContactError, Credentials | HttpClient.HttpClient>;
export type GetContactChannelError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * List details about a specific contact channel.
 */
export declare const getContactChannel: API.OperationMethod<GetContactChannelRequest & RegionInput, GetContactChannelResult, GetContactChannelError, Credentials | HttpClient.HttpClient>;
export type GetContactPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Retrieves the resource policies attached to the specified contact or escalation
 * plan.
 */
export declare const getContactPolicy: API.OperationMethod<GetContactPolicyRequest & RegionInput, GetContactPolicyResult, GetContactPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRotationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Retrieves information about an on-call rotation.
 */
export declare const getRotation: API.OperationMethod<GetRotationRequest & RegionInput, GetRotationResult, GetRotationError, Credentials | HttpClient.HttpClient>;
export type GetRotationOverrideError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Retrieves information about an override to an on-call rotation.
 */
export declare const getRotationOverride: API.OperationMethod<GetRotationOverrideRequest & RegionInput, GetRotationOverrideResult, GetRotationOverrideError, Credentials | HttpClient.HttpClient>;
export type ListContactChannelsError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists all contact channels for the specified contact.
 */
export declare const listContactChannels: API.PaginatedOperationMethod<ListContactChannelsRequest & RegionInput, ListContactChannelsResult, ListContactChannelsError, Credentials | HttpClient.HttpClient, ContactChannel>;
export type ListContactsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists all contacts and escalation plans in Incident Manager.
 */
export declare const listContacts: API.PaginatedOperationMethod<ListContactsRequest & RegionInput, ListContactsResult, ListContactsError, Credentials | HttpClient.HttpClient, Contact>;
export type ListEngagementsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists all engagements that have happened in an incident.
 */
export declare const listEngagements: API.PaginatedOperationMethod<ListEngagementsRequest & RegionInput, ListEngagementsResult, ListEngagementsError, Credentials | HttpClient.HttpClient, Engagement>;
export type ListPageReceiptsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists all of the engagements to contact channels that have been acknowledged.
 */
export declare const listPageReceipts: API.PaginatedOperationMethod<ListPageReceiptsRequest & RegionInput, ListPageReceiptsResult, ListPageReceiptsError, Credentials | HttpClient.HttpClient, Receipt>;
export type ListPageResolutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Returns the resolution path of an engagement. For example, the escalation plan engaged
 * in an incident might target an on-call schedule that includes several contacts in a
 * rotation, but just one contact on-call when the incident starts. The resolution path
 * indicates the hierarchy of escalation plan > on-call schedule >
 * contact.
 */
export declare const listPageResolutions: API.PaginatedOperationMethod<ListPageResolutionsRequest & RegionInput, ListPageResolutionsResult, ListPageResolutionsError, Credentials | HttpClient.HttpClient, ResolutionContact>;
export type ListPagesByContactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists the engagements to a contact's contact channels.
 */
export declare const listPagesByContact: API.PaginatedOperationMethod<ListPagesByContactRequest & RegionInput, ListPagesByContactResult, ListPagesByContactError, Credentials | HttpClient.HttpClient, Page>;
export type ListPagesByEngagementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists the engagements to contact channels that occurred by engaging a contact.
 */
export declare const listPagesByEngagement: API.PaginatedOperationMethod<ListPagesByEngagementRequest & RegionInput, ListPagesByEngagementResult, ListPagesByEngagementError, Credentials | HttpClient.HttpClient, Page>;
export type ListPreviewRotationShiftsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Returns a list of shifts based on rotation configuration parameters.
 *
 * The Incident Manager primarily uses this operation to populate the **Preview** calendar. It is not typically run by end users.
 */
export declare const listPreviewRotationShifts: API.PaginatedOperationMethod<ListPreviewRotationShiftsRequest & RegionInput, ListPreviewRotationShiftsResult, ListPreviewRotationShiftsError, Credentials | HttpClient.HttpClient, RotationShift>;
export type ListRotationOverridesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Retrieves a list of overrides currently specified for an on-call rotation.
 */
export declare const listRotationOverrides: API.PaginatedOperationMethod<ListRotationOverridesRequest & RegionInput, ListRotationOverridesResult, ListRotationOverridesError, Credentials | HttpClient.HttpClient, RotationOverride>;
export type ListRotationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Retrieves a list of on-call rotations.
 */
export declare const listRotations: API.PaginatedOperationMethod<ListRotationsRequest & RegionInput, ListRotationsResult, ListRotationsError, Credentials | HttpClient.HttpClient, Rotation>;
export type ListRotationShiftsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Returns a list of shifts generated by an existing rotation in the system.
 */
export declare const listRotationShifts: API.PaginatedOperationMethod<ListRotationShiftsRequest & RegionInput, ListRotationShiftsResult, ListRotationShiftsError, Credentials | HttpClient.HttpClient, RotationShift>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Lists the tags of a contact, escalation plan, rotation, or on-call schedule.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutContactPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Adds a resource policy to the specified contact or escalation plan. The resource policy
 * is used to share the contact or escalation plan using Resource Access Manager (RAM). For more information about cross-account sharing, see Setting up
 * cross-account functionality.
 */
export declare const putContactPolicy: API.OperationMethod<PutContactPolicyRequest & RegionInput, PutContactPolicyResult, PutContactPolicyError, Credentials | HttpClient.HttpClient>;
export type SendActivationCodeError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Sends an activation code to a contact channel. The contact can use this code to activate
 * the contact channel in the console or with the `ActivateChannel` operation.
 * Incident Manager can't engage a contact channel until it has been activated.
 */
export declare const sendActivationCode: API.OperationMethod<SendActivationCodeRequest & RegionInput, SendActivationCodeResult, SendActivationCodeError, Credentials | HttpClient.HttpClient>;
export type StartEngagementError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Starts an engagement to a contact or escalation plan. The engagement engages each
 * contact specified in the incident.
 */
export declare const startEngagement: API.OperationMethod<StartEngagementRequest & RegionInput, StartEngagementResult, StartEngagementError, Credentials | HttpClient.HttpClient>;
export type StopEngagementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Stops an engagement before it finishes the final stage of the escalation plan or
 * engagement plan. Further contacts aren't engaged.
 */
export declare const stopEngagement: API.OperationMethod<StopEngagementRequest & RegionInput, StopEngagementResult, StopEngagementError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Tags a contact or escalation plan. You can tag only contacts and escalation plans in the
 * first region of your replication set.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateContactError = AccessDeniedException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Updates the contact or escalation plan specified.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest & RegionInput, UpdateContactResult, UpdateContactError, Credentials | HttpClient.HttpClient>;
export type UpdateContactChannelError = AccessDeniedException | ConflictException | DataEncryptionException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | CommonErrors;
/**
 * Updates a contact's contact channel.
 */
export declare const updateContactChannel: API.OperationMethod<UpdateContactChannelRequest & RegionInput, UpdateContactChannelResult, UpdateContactChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateRotationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | IncidentManagerNotOnboarded | InvalidRotationArn | CommonErrors;
/**
 * Updates the information specified for an on-call rotation.
 */
export declare const updateRotation: API.OperationMethod<UpdateRotationRequest & RegionInput, UpdateRotationResult, UpdateRotationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ssm-contacts.d.ts.map