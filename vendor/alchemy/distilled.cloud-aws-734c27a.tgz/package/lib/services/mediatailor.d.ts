import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ChannelNotFound_base: S.TaggedErrorClass<"ChannelNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ChannelNotFound extends /*@__PURE__*/ ChannelNotFound_base {
}
declare const PlaybackConfigurationNotFound_base: S.TaggedErrorClass<"PlaybackConfigurationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class PlaybackConfigurationNotFound extends /*@__PURE__*/ PlaybackConfigurationNotFound_base {
}
declare const PrefetchScheduleNotFound_base: S.TaggedErrorClass<"PrefetchScheduleNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class PrefetchScheduleNotFound extends /*@__PURE__*/ PrefetchScheduleNotFound_base {
}
declare const ProgramNotFound_base: S.TaggedErrorClass<"ProgramNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ProgramNotFound extends /*@__PURE__*/ ProgramNotFound_base {
}
export type LogType = "AS_RUN" | (string & {});
export type LogTypes = LogType[];
export interface ConfigureLogsForChannelRequest {
    ChannelName: string;
    LogTypes: LogType[];
}
export interface ConfigureLogsForChannelResponse {
    ChannelName?: string | undefined;
    LogTypes?: LogType[] | undefined;
}
export type LoggingStrategy = "VENDED_LOGS" | "LEGACY_CLOUDWATCH" | (string & {});
export type __listOfLoggingStrategies = LoggingStrategy[];
export type AdsInteractionPublishOptInEventType = "RAW_ADS_RESPONSE" | "RAW_ADS_REQUEST" | "RAW_BID_REQUEST" | "RAW_BID_RESPONSE" | "PRE_ADS_REQUEST_HOOK_SUMMARY" | "PRE_ADS_REQUEST_FUNCTION_COMPLETED" | "POST_ADS_RESPONSE_HOOK_SUMMARY" | "POST_ADS_RESPONSE_FUNCTION_COMPLETED" | "PRE_MANIFEST_INSERTION_HOOK_SUMMARY" | "PRE_MANIFEST_INSERTION_FUNCTION_COMPLETED" | (string & {});
export type __adsInteractionPublishOptInEventTypesList = AdsInteractionPublishOptInEventType[];
export type AdsInteractionExcludeEventType = "AD_MARKER_FOUND" | "NON_AD_MARKER_FOUND" | "MAKING_ADS_REQUEST" | "MODIFIED_TARGET_URL" | "VAST_REDIRECT" | "EMPTY_VAST_RESPONSE" | "EMPTY_VMAP_RESPONSE" | "VAST_RESPONSE" | "REDIRECTED_VAST_RESPONSE" | "FILLED_AVAIL" | "FILLED_OVERLAY_AVAIL" | "BEACON_FIRED" | "WARNING_NO_ADVERTISEMENTS" | "WARNING_VPAID_AD_DROPPED" | "WARNING_URL_VARIABLE_SUBSTITUTION_FAILED" | "ERROR_UNKNOWN" | "ERROR_UNKNOWN_HOST" | "ERROR_DISALLOWED_HOST" | "ERROR_ADS_IO" | "ERROR_ADS_TIMEOUT" | "ERROR_ADS_RESPONSE_PARSE" | "ERROR_ADS_RESPONSE_UNKNOWN_ROOT_ELEMENT" | "ERROR_ADS_INVALID_RESPONSE" | "ERROR_VAST_REDIRECT_EMPTY_RESPONSE" | "ERROR_VAST_REDIRECT_MULTIPLE_VAST" | "ERROR_VAST_REDIRECT_FAILED" | "ERROR_VAST_MISSING_MEDIAFILES" | "ERROR_VAST_MISSING_CREATIVES" | "ERROR_VAST_MISSING_OVERLAYS" | "ERROR_VAST_MISSING_IMPRESSION" | "ERROR_VAST_INVALID_VAST_AD_TAG_URI" | "ERROR_VAST_MULTIPLE_TRACKING_EVENTS" | "ERROR_VAST_MULTIPLE_LINEAR" | "ERROR_VAST_INVALID_MEDIA_FILE" | "ERROR_FIRING_BEACON_FAILED" | "ERROR_PERSONALIZATION_DISABLED" | "VOD_TIME_BASED_AVAIL_PLAN_VAST_RESPONSE_FOR_OFFSET" | "VOD_TIME_BASED_AVAIL_PLAN_SUCCESS" | "VOD_TIME_BASED_AVAIL_PLAN_WARNING_NO_ADVERTISEMENTS" | "INTERSTITIAL_VOD_SUCCESS" | "INTERSTITIAL_VOD_FAILURE" | "PRE_ADS_REQUEST_HOOK_ERROR" | "PRE_ADS_REQUEST_FUNCTION_ERROR" | "BEACON_RECEIVED" | "POST_ADS_RESPONSE_HOOK_ERROR" | "POST_ADS_RESPONSE_FUNCTION_ERROR" | "PRE_MANIFEST_INSERTION_HOOK_ERROR" | "PRE_MANIFEST_INSERTION_FUNCTION_ERROR" | (string & {});
export type __adsInteractionExcludeEventTypesList = AdsInteractionExcludeEventType[];
export interface AdsInteractionLog {
    PublishOptInEventTypes?: AdsInteractionPublishOptInEventType[] | undefined;
    ExcludeEventTypes?: AdsInteractionExcludeEventType[] | undefined;
}
export type ManifestServicePublishOptInEventType = "PRE_SESSION_INIT_HOOK_SUMMARY" | "PRE_SESSION_INIT_FUNCTION_COMPLETED" | "POST_ORIGIN_RESPONSE_HOOK_SUMMARY" | "POST_ORIGIN_RESPONSE_FUNCTION_COMPLETED" | (string & {});
export type __manifestServicePublishOptInEventTypesList = ManifestServicePublishOptInEventType[];
export type ManifestServiceExcludeEventType = "GENERATED_MANIFEST" | "ORIGIN_MANIFEST" | "SESSION_INITIALIZED" | "TRACKING_RESPONSE" | "CONFIG_SYNTAX_ERROR" | "CONFIG_SECURITY_ERROR" | "UNKNOWN_HOST" | "TIMEOUT_ERROR" | "CONNECTION_ERROR" | "IO_ERROR" | "UNKNOWN_ERROR" | "HOST_DISALLOWED" | "PARSING_ERROR" | "MANIFEST_ERROR" | "NO_MASTER_OR_MEDIA_PLAYLIST" | "NO_MASTER_PLAYLIST" | "NO_MEDIA_PLAYLIST" | "INCOMPATIBLE_HLS_VERSION" | "SCTE35_PARSING_ERROR" | "INVALID_SINGLE_PERIOD_DASH_MANIFEST" | "UNSUPPORTED_SINGLE_PERIOD_DASH_MANIFEST" | "LAST_PERIOD_MISSING_AUDIO" | "LAST_PERIOD_MISSING_AUDIO_WARNING" | "ERROR_ORIGIN_PREFIX_INTERPOLATION" | "ERROR_ADS_INTERPOLATION" | "ERROR_LIVE_PRE_ROLL_ADS_INTERPOLATION" | "ERROR_CDN_AD_SEGMENT_INTERPOLATION" | "ERROR_CDN_CONTENT_SEGMENT_INTERPOLATION" | "ERROR_SLATE_AD_URL_INTERPOLATION" | "ERROR_PROFILE_NAME_INTERPOLATION" | "ERROR_BUMPER_START_INTERPOLATION" | "ERROR_BUMPER_END_INTERPOLATION" | "PRE_SESSION_INIT_HOOK_ERROR" | "PRE_SESSION_INIT_FUNCTION_ERROR" | "POST_ORIGIN_RESPONSE_HOOK_ERROR" | "POST_ORIGIN_RESPONSE_FUNCTION_ERROR" | (string & {});
export type __manifestServiceExcludeEventTypesList = ManifestServiceExcludeEventType[];
export interface ManifestServiceInteractionLog {
    PublishOptInEventTypes?: ManifestServicePublishOptInEventType[] | undefined;
    ExcludeEventTypes?: ManifestServiceExcludeEventType[] | undefined;
}
export interface ConfigureLogsForPlaybackConfigurationRequest {
    PercentEnabled: number;
    PlaybackConfigurationName: string;
    EnabledLoggingStrategies?: LoggingStrategy[] | undefined;
    AdsInteractionLog?: AdsInteractionLog | undefined;
    ManifestServiceInteractionLog?: ManifestServiceInteractionLog | undefined;
}
export interface ConfigureLogsForPlaybackConfigurationResponse {
    PercentEnabled: number;
    PlaybackConfigurationName?: string | undefined;
    EnabledLoggingStrategies?: LoggingStrategy[] | undefined;
    AdsInteractionLog?: AdsInteractionLog | undefined;
    ManifestServiceInteractionLog?: ManifestServiceInteractionLog | undefined;
}
export interface SlateSource {
    SourceLocationName?: string | undefined;
    VodSourceName?: string | undefined;
}
export interface DashPlaylistSettings {
    ManifestWindowSeconds?: number | undefined;
    MinBufferTimeSeconds?: number | undefined;
    MinUpdatePeriodSeconds?: number | undefined;
    SuggestedPresentationDelaySeconds?: number | undefined;
}
export type AdMarkupType = "DATERANGE" | "SCTE35_ENHANCED" | (string & {});
export type AdMarkupTypes = AdMarkupType[];
export interface HlsPlaylistSettings {
    ManifestWindowSeconds?: number | undefined;
    AdMarkupType?: AdMarkupType[] | undefined;
}
export interface RequestOutputItem {
    DashPlaylistSettings?: DashPlaylistSettings | undefined;
    HlsPlaylistSettings?: HlsPlaylistSettings | undefined;
    ManifestName: string;
    SourceGroup: string;
}
export type RequestOutputs = RequestOutputItem[];
export type PlaybackMode = "LOOP" | "LINEAR" | (string & {});
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export type Tier = "BASIC" | "STANDARD" | (string & {});
export interface TimeShiftConfiguration {
    MaxTimeDelaySeconds: number;
}
export type Audiences = string[];
export interface CreateChannelRequest {
    ChannelName: string;
    FillerSlate?: SlateSource | undefined;
    Outputs: RequestOutputItem[];
    PlaybackMode: PlaybackMode;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Tier?: Tier | undefined;
    TimeShiftConfiguration?: TimeShiftConfiguration | undefined;
    Audiences?: string[] | undefined;
}
export type ChannelState = "RUNNING" | "STOPPED" | (string & {});
export type __timestampUnix = Date;
export interface ResponseOutputItem {
    DashPlaylistSettings?: DashPlaylistSettings | undefined;
    HlsPlaylistSettings?: HlsPlaylistSettings | undefined;
    ManifestName: string;
    PlaybackUrl: string;
    DualStackPlaybackUrl?: string | undefined;
    SourceGroup: string;
}
export type ResponseOutputs = ResponseOutputItem[];
export interface CreateChannelResponse {
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    ChannelState?: ChannelState | undefined;
    CreationTime?: Date | undefined;
    FillerSlate?: SlateSource | undefined;
    LastModifiedTime?: Date | undefined;
    Outputs?: ResponseOutputItem[] | undefined;
    PlaybackMode?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Tier?: string | undefined;
    TimeShiftConfiguration?: TimeShiftConfiguration | undefined;
    Audiences?: string[] | undefined;
}
export type Type = "DASH" | "HLS" | (string & {});
export interface HttpPackageConfiguration {
    Path: string;
    SourceGroup: string;
    Type: Type;
}
export type HttpPackageConfigurations = HttpPackageConfiguration[];
export interface CreateLiveSourceRequest {
    HttpPackageConfigurations: HttpPackageConfiguration[];
    LiveSourceName: string;
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateLiveSourceResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    LiveSourceName?: string | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Operator = "EQUALS" | (string & {});
export interface AvailMatchingCriteria {
    DynamicVariable: string;
    Operator: Operator;
}
export type __listOfAvailMatchingCriteria = AvailMatchingCriteria[];
export interface PrefetchConsumption {
    AvailMatchingCriteria?: AvailMatchingCriteria[] | undefined;
    EndTime: Date;
    StartTime?: Date | undefined;
}
export type TrafficShapingType = "RETRIEVAL_WINDOW" | "TPS" | (string & {});
export interface TrafficShapingRetrievalWindow {
    RetrievalWindowDurationSeconds?: number | undefined;
}
export interface TrafficShapingTpsConfiguration {
    PeakTps?: number | undefined;
    PeakConcurrentUsers?: number | undefined;
}
export interface PrefetchRetrieval {
    DynamicVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    EndTime: Date;
    StartTime?: Date | undefined;
    TrafficShapingType?: TrafficShapingType | undefined;
    TrafficShapingRetrievalWindow?: TrafficShapingRetrievalWindow | undefined;
    TrafficShapingTpsConfiguration?: TrafficShapingTpsConfiguration | undefined;
}
export interface RecurringConsumption {
    RetrievedAdExpirationSeconds?: number | undefined;
    AvailMatchingCriteria?: AvailMatchingCriteria[] | undefined;
}
export interface RecurringRetrieval {
    DynamicVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    DelayAfterAvailEndSeconds?: number | undefined;
    TrafficShapingType?: TrafficShapingType | undefined;
    TrafficShapingRetrievalWindow?: TrafficShapingRetrievalWindow | undefined;
    TrafficShapingTpsConfiguration?: TrafficShapingTpsConfiguration | undefined;
}
export interface RecurringPrefetchConfiguration {
    StartTime?: Date | undefined;
    EndTime: Date;
    RecurringConsumption: RecurringConsumption;
    RecurringRetrieval: RecurringRetrieval;
}
export type PrefetchScheduleType = "SINGLE" | "RECURRING" | (string & {});
export interface CreatePrefetchScheduleRequest {
    Consumption?: PrefetchConsumption | undefined;
    Name: string;
    PlaybackConfigurationName: string;
    Retrieval?: PrefetchRetrieval | undefined;
    RecurringPrefetchConfiguration?: RecurringPrefetchConfiguration | undefined;
    ScheduleType?: PrefetchScheduleType | undefined;
    StreamId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePrefetchScheduleResponse {
    Arn?: string | undefined;
    Consumption?: PrefetchConsumption | undefined;
    Name?: string | undefined;
    PlaybackConfigurationName?: string | undefined;
    Retrieval?: PrefetchRetrieval | undefined;
    RecurringPrefetchConfiguration?: RecurringPrefetchConfiguration | undefined;
    ScheduleType?: PrefetchScheduleType | undefined;
    StreamId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MessageType = "SPLICE_INSERT" | "TIME_SIGNAL" | (string & {});
export interface SpliceInsertMessage {
    AvailNum?: number | undefined;
    AvailsExpected?: number | undefined;
    SpliceEventId?: number | undefined;
    UniqueProgramId?: number | undefined;
}
export interface SegmentationDescriptor {
    SegmentationEventId?: number | undefined;
    SegmentationUpidType?: number | undefined;
    SegmentationUpid?: string | undefined;
    SegmentationTypeId?: number | undefined;
    SegmentNum?: number | undefined;
    SegmentsExpected?: number | undefined;
    SubSegmentNum?: number | undefined;
    SubSegmentsExpected?: number | undefined;
}
export type SegmentationDescriptorList = SegmentationDescriptor[];
export interface TimeSignalMessage {
    SegmentationDescriptors?: SegmentationDescriptor[] | undefined;
}
export interface KeyValuePair {
    Key: string;
    Value: string;
}
export type AdBreakMetadataList = KeyValuePair[];
export interface AdBreak {
    MessageType?: MessageType | undefined;
    OffsetMillis: number;
    Slate?: SlateSource | undefined;
    SpliceInsertMessage?: SpliceInsertMessage | undefined;
    TimeSignalMessage?: TimeSignalMessage | undefined;
    AdBreakMetadata?: KeyValuePair[] | undefined;
}
export type __listOfAdBreak = AdBreak[];
export type RelativePosition = "BEFORE_PROGRAM" | "AFTER_PROGRAM" | (string & {});
export interface Transition {
    DurationMillis?: number | undefined;
    RelativePosition: RelativePosition;
    RelativeProgram?: string | undefined;
    ScheduledStartTimeMillis?: number | undefined;
    Type: string;
}
export interface ClipRange {
    EndOffsetMillis?: number | undefined;
    StartOffsetMillis?: number | undefined;
}
export interface ScheduleConfiguration {
    Transition: Transition;
    ClipRange?: ClipRange | undefined;
}
export interface AlternateMedia {
    SourceLocationName?: string | undefined;
    LiveSourceName?: string | undefined;
    VodSourceName?: string | undefined;
    ClipRange?: ClipRange | undefined;
    ScheduledStartTimeMillis?: number | undefined;
    AdBreaks?: AdBreak[] | undefined;
    DurationMillis?: number | undefined;
}
export type __listOfAlternateMedia = AlternateMedia[];
export interface AudienceMedia {
    Audience?: string | undefined;
    AlternateMedia?: AlternateMedia[] | undefined;
}
export type __listOfAudienceMedia = AudienceMedia[];
export interface CreateProgramRequest {
    AdBreaks?: AdBreak[] | undefined;
    ChannelName: string;
    LiveSourceName?: string | undefined;
    ProgramName: string;
    ScheduleConfiguration: ScheduleConfiguration;
    SourceLocationName: string;
    VodSourceName?: string | undefined;
    AudienceMedia?: AudienceMedia[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateProgramResponse {
    AdBreaks?: AdBreak[] | undefined;
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    CreationTime?: Date | undefined;
    LiveSourceName?: string | undefined;
    ProgramName?: string | undefined;
    ScheduledStartTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    VodSourceName?: string | undefined;
    ClipRange?: ClipRange | undefined;
    DurationMillis?: number | undefined;
    AudienceMedia?: AudienceMedia[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AccessType = "S3_SIGV4" | "SECRETS_MANAGER_ACCESS_TOKEN" | "AUTODETECT_SIGV4" | (string & {});
export interface SecretsManagerAccessTokenConfiguration {
    HeaderName?: string | undefined;
    SecretArn?: string | undefined;
    SecretStringKey?: string | undefined;
}
export interface AccessConfiguration {
    AccessType?: AccessType | undefined;
    SecretsManagerAccessTokenConfiguration?: SecretsManagerAccessTokenConfiguration | undefined;
}
export interface DefaultSegmentDeliveryConfiguration {
    BaseUrl?: string | undefined;
}
export interface HttpConfiguration {
    BaseUrl: string;
}
export interface SegmentDeliveryConfiguration {
    BaseUrl?: string | undefined;
    Name?: string | undefined;
}
export type __listOfSegmentDeliveryConfiguration = SegmentDeliveryConfiguration[];
export interface CreateSourceLocationRequest {
    AccessConfiguration?: AccessConfiguration | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration: HttpConfiguration;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSourceLocationResponse {
    AccessConfiguration?: AccessConfiguration | undefined;
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration?: HttpConfiguration | undefined;
    LastModifiedTime?: Date | undefined;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateVodSourceRequest {
    HttpPackageConfigurations: HttpPackageConfiguration[];
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VodSourceName: string;
}
export interface CreateVodSourceResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VodSourceName?: string | undefined;
}
export interface DeleteChannelRequest {
    ChannelName: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteChannelPolicyRequest {
    ChannelName: string;
}
export interface DeleteChannelPolicyResponse {
}
export interface DeleteFunctionRequest {
    FunctionId: string;
}
export interface DeleteFunctionResponse {
}
export interface DeleteLiveSourceRequest {
    LiveSourceName: string;
    SourceLocationName: string;
}
export interface DeleteLiveSourceResponse {
}
export interface DeletePlaybackConfigurationRequest {
    Name: string;
}
export interface DeletePlaybackConfigurationResponse {
}
export interface DeletePrefetchScheduleRequest {
    Name: string;
    PlaybackConfigurationName: string;
}
export interface DeletePrefetchScheduleResponse {
}
export interface DeleteProgramRequest {
    ChannelName: string;
    ProgramName: string;
}
export interface DeleteProgramResponse {
}
export interface DeleteSourceLocationRequest {
    SourceLocationName: string;
}
export interface DeleteSourceLocationResponse {
}
export interface DeleteVodSourceRequest {
    SourceLocationName: string;
    VodSourceName: string;
}
export interface DeleteVodSourceResponse {
}
export interface DescribeChannelRequest {
    ChannelName: string;
}
export interface LogConfigurationForChannel {
    LogTypes?: LogType[] | undefined;
}
export interface DescribeChannelResponse {
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    ChannelState?: ChannelState | undefined;
    CreationTime?: Date | undefined;
    FillerSlate?: SlateSource | undefined;
    LastModifiedTime?: Date | undefined;
    Outputs?: ResponseOutputItem[] | undefined;
    PlaybackMode?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Tier?: string | undefined;
    LogConfiguration: LogConfigurationForChannel;
    TimeShiftConfiguration?: TimeShiftConfiguration | undefined;
    Audiences?: string[] | undefined;
}
export interface DescribeLiveSourceRequest {
    LiveSourceName: string;
    SourceLocationName: string;
}
export interface DescribeLiveSourceResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    LiveSourceName?: string | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeProgramRequest {
    ChannelName: string;
    ProgramName: string;
}
export interface DescribeProgramResponse {
    AdBreaks?: AdBreak[] | undefined;
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    CreationTime?: Date | undefined;
    LiveSourceName?: string | undefined;
    ProgramName?: string | undefined;
    ScheduledStartTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    VodSourceName?: string | undefined;
    ClipRange?: ClipRange | undefined;
    DurationMillis?: number | undefined;
    AudienceMedia?: AudienceMedia[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeSourceLocationRequest {
    SourceLocationName: string;
}
export interface DescribeSourceLocationResponse {
    AccessConfiguration?: AccessConfiguration | undefined;
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration?: HttpConfiguration | undefined;
    LastModifiedTime?: Date | undefined;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeVodSourceRequest {
    SourceLocationName: string;
    VodSourceName: string;
}
export interface AdBreakOpportunity {
    OffsetMillis: number;
}
export type AdBreakOpportunities = AdBreakOpportunity[];
export interface DescribeVodSourceResponse {
    AdBreakOpportunities?: AdBreakOpportunity[] | undefined;
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VodSourceName?: string | undefined;
}
export interface GetChannelPolicyRequest {
    ChannelName: string;
}
export interface GetChannelPolicyResponse {
    Policy?: string | undefined;
}
export type MaxResults = number;
export interface GetChannelScheduleRequest {
    ChannelName: string;
    DurationMinutes?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Audience?: string | undefined;
}
export interface ScheduleAdBreak {
    ApproximateDurationSeconds?: number | undefined;
    ApproximateStartTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    VodSourceName?: string | undefined;
}
export type __listOfScheduleAdBreak = ScheduleAdBreak[];
export type ScheduleEntryType = "PROGRAM" | "FILLER_SLATE" | "ALTERNATE_MEDIA" | (string & {});
export interface ScheduleEntry {
    ApproximateDurationSeconds?: number | undefined;
    ApproximateStartTime?: Date | undefined;
    Arn: string;
    ChannelName: string;
    LiveSourceName?: string | undefined;
    ProgramName: string;
    ScheduleAdBreaks?: ScheduleAdBreak[] | undefined;
    ScheduleEntryType?: ScheduleEntryType | undefined;
    SourceLocationName: string;
    VodSourceName?: string | undefined;
    Audiences?: string[] | undefined;
}
export type __listOfScheduleEntry = ScheduleEntry[];
export interface GetChannelScheduleResponse {
    Items?: ScheduleEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface GetFunctionRequest {
    FunctionId: string;
}
export type FunctionType = "HTTP_REQUEST" | "AWS_SERVICE_REQUEST" | "CUSTOM_OUTPUT" | "CONCURRENT_EXECUTOR" | "SEQUENTIAL_EXECUTOR" | "VAST_REQUEST" | "HLS_TAG_PROCESSOR" | (string & {});
export type RuntimeType = "JSONATA" | (string & {});
export type MethodType = "GET" | "POST" | (string & {});
export type __integerMin1 = number;
export interface HttpRequestCacheConfiguration {
    TtlMinimumSeconds: number;
    TtlMaximumSeconds: number;
    Key?: string | undefined;
}
export interface HttpRequestConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
    MethodType: MethodType;
    RequestTimeoutMilliseconds: number;
    Url: string;
    Body?: string | undefined;
    Headers?: {
        [key: string]: string | undefined;
    } | undefined;
    Cache?: HttpRequestCacheConfiguration | undefined;
}
export type AwsTargetService = string;
export interface AwsServiceRequestConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
    MethodType: MethodType;
    RequestTimeoutMilliseconds: number;
    Url: string;
    Body?: string | undefined;
    Headers?: {
        [key: string]: string | undefined;
    } | undefined;
    Cache?: HttpRequestCacheConfiguration | undefined;
    TargetService: string;
    TargetRegion: string;
}
export interface CustomOutputConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface FunctionRef {
    RunCondition?: string | undefined;
    FunctionId?: string | undefined;
    Alias?: string | undefined;
}
export type __listOfFunctionsRef = FunctionRef[];
export interface ConcurrentExecutorConfiguration {
    Runtime: RuntimeType;
    Output: {
        [key: string]: string | undefined;
    };
    FunctionList: FunctionRef[];
    TimeoutMilliseconds: number;
    MaxConcurrency: number;
}
export interface SequentialExecutorConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
    FunctionList: FunctionRef[];
    TimeoutMilliseconds: number;
}
export interface VastRequestConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
    MethodType: MethodType;
    RequestTimeoutMilliseconds: number;
    Url: string;
    Body?: string | undefined;
    Headers?: {
        [key: string]: string | undefined;
    } | undefined;
    Cache?: HttpRequestCacheConfiguration | undefined;
}
export type HlsTagName = "EXT-X-DATERANGE" | (string & {});
export type TagFilterList = HlsTagName[];
export interface HlsTagProcessorConfiguration {
    Runtime: RuntimeType;
    Output?: {
        [key: string]: string | undefined;
    } | undefined;
    TagFilter: HlsTagName[];
    RunCondition?: string | undefined;
}
export interface GetFunctionResponse {
    FunctionId: string;
    FunctionType: FunctionType;
    Description?: string | undefined;
    HttpRequestConfiguration?: HttpRequestConfiguration | undefined;
    AwsServiceRequestConfiguration?: AwsServiceRequestConfiguration | undefined;
    CustomOutputConfiguration?: CustomOutputConfiguration | undefined;
    ConcurrentExecutorConfiguration?: ConcurrentExecutorConfiguration | undefined;
    SequentialExecutorConfiguration?: SequentialExecutorConfiguration | undefined;
    VastRequestConfiguration?: VastRequestConfiguration | undefined;
    HlsTagProcessorConfiguration?: HlsTagProcessorConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export interface GetPlaybackConfigurationRequest {
    Name: string;
}
export type Mode = "OFF" | "BEHIND_LIVE_EDGE" | "AFTER_LIVE_EDGE" | (string & {});
export type FillPolicy = "FULL_AVAIL_ONLY" | "PARTIAL_AVAIL" | (string & {});
export interface AvailSuppression {
    Mode?: Mode | undefined;
    Value?: string | undefined;
    FillPolicy?: FillPolicy | undefined;
}
export interface Bumper {
    EndUrl?: string | undefined;
    StartUrl?: string | undefined;
}
export interface CdnConfiguration {
    AdSegmentUrlPrefix?: string | undefined;
    ContentSegmentUrlPrefix?: string | undefined;
}
export type ConfigurationAliasesResponse = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export type OriginManifestType = "SINGLE_PERIOD" | "MULTI_PERIOD" | (string & {});
export interface DashConfiguration {
    ManifestEndpointPrefix?: string | undefined;
    DualStackManifestEndpointPrefix?: string | undefined;
    MpdLocation?: string | undefined;
    OriginManifestType?: OriginManifestType | undefined;
}
export interface HlsConfiguration {
    ManifestEndpointPrefix?: string | undefined;
    DualStackManifestEndpointPrefix?: string | undefined;
}
export type InsertionMode = "STITCHED_ONLY" | "PLAYER_SELECT" | (string & {});
export type PreRollAdSequencingMode = "FOLLOW_AD_SEQUENCE" | "IGNORE_AD_SEQUENCE" | (string & {});
export interface PreRollVastResponse {
    AdSequencingMode?: PreRollAdSequencingMode | undefined;
}
export interface PreRollAdDecisionServerConfiguration {
    VastResponse?: PreRollVastResponse | undefined;
}
export interface LivePreRollConfiguration {
    AdDecisionServerUrl?: string | undefined;
    MaxDurationSeconds?: number | undefined;
    AdDecisionServerConfiguration?: PreRollAdDecisionServerConfiguration | undefined;
}
export interface LogConfiguration {
    PercentEnabled: number;
    EnabledLoggingStrategies?: LoggingStrategy[] | undefined;
    AdsInteractionLog?: AdsInteractionLog | undefined;
    ManifestServiceInteractionLog?: ManifestServiceInteractionLog | undefined;
}
export interface AdMarkerPassthrough {
    Enabled?: boolean | undefined;
}
export interface ManifestProcessingRules {
    AdMarkerPassthrough?: AdMarkerPassthrough | undefined;
}
export type StreamingMediaFileConditioning = "TRANSCODE" | "NONE" | (string & {});
export interface AdConditioningConfiguration {
    StreamingMediaFileConditioning: StreamingMediaFileConditioning;
}
export type Method = "GET" | "POST" | (string & {});
export type StringMap = {
    [key: string]: string | undefined;
};
export type CompressionMethod = "NONE" | "GZIP" | (string & {});
export interface HttpRequest {
    Method?: Method | undefined;
    Body?: string | undefined;
    Headers?: {
        [key: string]: string | undefined;
    } | undefined;
    CompressRequest?: CompressionMethod | undefined;
}
export type AdSequencingMode = "FOLLOW_AD_SEQUENCE" | "IGNORE_AD_SEQUENCE" | "FOLLOW_AD_SEQUENCE_ONLY_LIVE" | "FOLLOW_AD_SEQUENCE_ONLY_VOD" | (string & {});
export interface VastResponse {
    AdSequencingMode?: AdSequencingMode | undefined;
}
export interface AdDecisionServerConfiguration {
    HttpRequest?: HttpRequest | undefined;
    VastResponse?: VastResponse | undefined;
}
export type MinimumUnfilledDurationSeconds = number;
export type ApsPublisherId = string;
export type ApsRegion = "AMERICAS" | "EUROPE" | "ASIA_PACIFIC" | (string & {});
export type OpenRtbTemplateString = string;
export interface YieldOptimizationConfiguration {
    MinimumUnfilledDuration: number;
    PublisherId: string;
    Region: ApsRegion;
    OpenRtbTemplate: string;
}
export type EventName = "PRE_SESSION_INITIALIZATION" | "PRE_ADS_REQUEST" | "POST_ADS_RESPONSE" | "PRE_MANIFEST_INSERTION" | "POST_ORIGIN_RESPONSE" | (string & {});
export type FunctionMapping = {
    [key in EventName]?: string | undefined;
};
export interface AdsPersonalizationTimeouts {
    AdsRequestTimeoutMilliseconds?: number | undefined;
    LiveMaximumAdsPersonalizationTimeMilliseconds?: number | undefined;
    VodMaximumAdsPersonalizationTimeMilliseconds?: number | undefined;
    PrefetchAdsRequestTimeoutMilliseconds?: number | undefined;
    PrefetchMaximumAdsPersonalizationTimeMilliseconds?: number | undefined;
}
export interface AdsPersonalizationConcurrency {
    MaxConcurrentAdsRequests?: number | undefined;
    EnableVodVastParallelization?: boolean | undefined;
}
export type ClientSideBeaconingMode = "DISABLED" | "INSIGHTS" | (string & {});
export type BeaconEventType = "MUTE" | "UNMUTE" | "PAUSE" | "SKIP" | (string & {});
export type BeaconEventTypeList = BeaconEventType[];
export interface ClientSideBeaconingConfiguration {
    ReportingMode: ClientSideBeaconingMode;
    AdditionalEventTypes?: BeaconEventType[] | undefined;
}
export interface BeaconingConfiguration {
    ClientSide?: ClientSideBeaconingConfiguration | undefined;
}
export interface GetPlaybackConfigurationResponse {
    AdDecisionServerUrl?: string | undefined;
    AvailSuppression?: AvailSuppression | undefined;
    Bumper?: Bumper | undefined;
    CdnConfiguration?: CdnConfiguration | undefined;
    ConfigurationAliases?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    DashConfiguration?: DashConfiguration | undefined;
    HlsConfiguration?: HlsConfiguration | undefined;
    InsertionMode?: InsertionMode | undefined;
    LivePreRollConfiguration?: LivePreRollConfiguration | undefined;
    LogConfiguration?: (LogConfiguration & {
        EnabledLoggingStrategies: __listOfLoggingStrategies;
    }) | undefined;
    ManifestProcessingRules?: ManifestProcessingRules | undefined;
    Name?: string | undefined;
    PersonalizationThresholdSeconds?: number | undefined;
    PlaybackConfigurationArn?: string | undefined;
    PlaybackEndpointPrefix?: string | undefined;
    DualStackPlaybackEndpointPrefix?: string | undefined;
    SessionInitializationEndpointPrefix?: string | undefined;
    DualStackSessionInitializationEndpointPrefix?: string | undefined;
    SlateAdUrl?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TranscodeProfileName?: string | undefined;
    VideoContentSourceUrl?: string | undefined;
    AdConditioningConfiguration?: AdConditioningConfiguration | undefined;
    AdDecisionServerConfiguration?: AdDecisionServerConfiguration | undefined;
    YieldOptimizationConfiguration?: YieldOptimizationConfiguration | undefined;
    FunctionMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    AdsPersonalizationTimeouts?: AdsPersonalizationTimeouts | undefined;
    AdsPersonalizationConcurrency?: AdsPersonalizationConcurrency | undefined;
    BeaconingConfiguration?: BeaconingConfiguration | undefined;
}
export interface GetPrefetchScheduleRequest {
    Name: string;
    PlaybackConfigurationName: string;
}
export interface GetPrefetchScheduleResponse {
    Arn?: string | undefined;
    Consumption?: PrefetchConsumption | undefined;
    Name?: string | undefined;
    PlaybackConfigurationName?: string | undefined;
    Retrieval?: PrefetchRetrieval | undefined;
    ScheduleType?: PrefetchScheduleType | undefined;
    RecurringPrefetchConfiguration?: RecurringPrefetchConfiguration | undefined;
    StreamId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListAlertsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ResourceArn: string;
}
export type __listOf__string = string[];
export type AlertCategory = "SCHEDULING_ERROR" | "PLAYBACK_WARNING" | "INFO" | (string & {});
export interface Alert {
    AlertCode: string;
    AlertMessage: string;
    LastModifiedTime: Date;
    RelatedResourceArns: string[];
    ResourceArn: string;
    Category?: AlertCategory | undefined;
}
export type __listOfAlert = Alert[];
export interface ListAlertsResponse {
    Items?: Alert[] | undefined;
    NextToken?: string | undefined;
}
export interface ListChannelsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Channel {
    Arn: string;
    ChannelName: string;
    ChannelState: string;
    CreationTime?: Date | undefined;
    FillerSlate?: SlateSource | undefined;
    LastModifiedTime?: Date | undefined;
    Outputs: ResponseOutputItem[];
    PlaybackMode: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Tier: string;
    LogConfiguration: LogConfigurationForChannel;
    Audiences?: string[] | undefined;
}
export type __listOfChannel = Channel[];
export interface ListChannelsResponse {
    Items?: Channel[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFunctionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Function {
    FunctionId: string;
    FunctionType: FunctionType;
    Description?: string | undefined;
    HttpRequestConfiguration?: HttpRequestConfiguration | undefined;
    AwsServiceRequestConfiguration?: AwsServiceRequestConfiguration | undefined;
    CustomOutputConfiguration?: CustomOutputConfiguration | undefined;
    ConcurrentExecutorConfiguration?: ConcurrentExecutorConfiguration | undefined;
    SequentialExecutorConfiguration?: SequentialExecutorConfiguration | undefined;
    VastRequestConfiguration?: VastRequestConfiguration | undefined;
    HlsTagProcessorConfiguration?: HlsTagProcessorConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export type __listOfFunctionsResponse = Function[];
export interface ListFunctionsResponse {
    Items?: Function[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLiveSourcesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SourceLocationName: string;
}
export interface LiveSource {
    Arn: string;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations: HttpPackageConfiguration[];
    LastModifiedTime?: Date | undefined;
    LiveSourceName: string;
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfLiveSource = LiveSource[];
export interface ListLiveSourcesResponse {
    Items?: LiveSource[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPlaybackConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PlaybackConfiguration {
    AdDecisionServerUrl?: string | undefined;
    AvailSuppression?: AvailSuppression | undefined;
    Bumper?: Bumper | undefined;
    CdnConfiguration?: CdnConfiguration | undefined;
    ConfigurationAliases?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    DashConfiguration?: DashConfiguration | undefined;
    HlsConfiguration?: HlsConfiguration | undefined;
    InsertionMode?: InsertionMode | undefined;
    LivePreRollConfiguration?: LivePreRollConfiguration | undefined;
    LogConfiguration?: LogConfiguration | undefined;
    ManifestProcessingRules?: ManifestProcessingRules | undefined;
    Name?: string | undefined;
    PersonalizationThresholdSeconds?: number | undefined;
    PlaybackConfigurationArn?: string | undefined;
    PlaybackEndpointPrefix?: string | undefined;
    DualStackPlaybackEndpointPrefix?: string | undefined;
    SessionInitializationEndpointPrefix?: string | undefined;
    DualStackSessionInitializationEndpointPrefix?: string | undefined;
    SlateAdUrl?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TranscodeProfileName?: string | undefined;
    VideoContentSourceUrl?: string | undefined;
    AdConditioningConfiguration?: AdConditioningConfiguration | undefined;
    AdDecisionServerConfiguration?: AdDecisionServerConfiguration | undefined;
    YieldOptimizationConfiguration?: YieldOptimizationConfiguration | undefined;
    FunctionMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    AdsPersonalizationTimeouts?: AdsPersonalizationTimeouts | undefined;
    AdsPersonalizationConcurrency?: AdsPersonalizationConcurrency | undefined;
    BeaconingConfiguration?: BeaconingConfiguration | undefined;
}
export type __listOfPlaybackConfiguration = PlaybackConfiguration[];
export interface ListPlaybackConfigurationsResponse {
    Items?: (PlaybackConfiguration & {
        LogConfiguration: LogConfiguration & {
            EnabledLoggingStrategies: __listOfLoggingStrategies;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type __integerMin1Max100 = number;
export type ListPrefetchScheduleType = "SINGLE" | "RECURRING" | "ALL" | (string & {});
export interface ListPrefetchSchedulesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    PlaybackConfigurationName: string;
    ScheduleType?: ListPrefetchScheduleType | undefined;
    StreamId?: string | undefined;
}
export interface PrefetchSchedule {
    Arn: string;
    Consumption?: PrefetchConsumption | undefined;
    Name: string;
    PlaybackConfigurationName: string;
    Retrieval?: PrefetchRetrieval | undefined;
    ScheduleType?: PrefetchScheduleType | undefined;
    RecurringPrefetchConfiguration?: RecurringPrefetchConfiguration | undefined;
    StreamId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfPrefetchSchedule = PrefetchSchedule[];
export interface ListPrefetchSchedulesResponse {
    Items?: PrefetchSchedule[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSourceLocationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SourceLocation {
    AccessConfiguration?: AccessConfiguration | undefined;
    Arn: string;
    CreationTime?: Date | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration: HttpConfiguration;
    LastModifiedTime?: Date | undefined;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfSourceLocation = SourceLocation[];
export interface ListSourceLocationsResponse {
    Items?: SourceLocation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListVodSourcesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SourceLocationName: string;
}
export interface VodSource {
    Arn: string;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations: HttpPackageConfiguration[];
    LastModifiedTime?: Date | undefined;
    SourceLocationName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VodSourceName: string;
}
export type __listOfVodSource = VodSource[];
export interface ListVodSourcesResponse {
    Items?: VodSource[] | undefined;
    NextToken?: string | undefined;
}
export interface PutChannelPolicyRequest {
    ChannelName: string;
    Policy: string;
}
export interface PutChannelPolicyResponse {
}
export interface PutFunctionRequest {
    FunctionId: string;
    FunctionType: FunctionType;
    Description?: string | undefined;
    HttpRequestConfiguration?: HttpRequestConfiguration | undefined;
    AwsServiceRequestConfiguration?: AwsServiceRequestConfiguration | undefined;
    CustomOutputConfiguration?: CustomOutputConfiguration | undefined;
    ConcurrentExecutorConfiguration?: ConcurrentExecutorConfiguration | undefined;
    SequentialExecutorConfiguration?: SequentialExecutorConfiguration | undefined;
    VastRequestConfiguration?: VastRequestConfiguration | undefined;
    HlsTagProcessorConfiguration?: HlsTagProcessorConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutFunctionResponse {
    FunctionId: string;
    FunctionType: FunctionType;
    Description?: string | undefined;
    HttpRequestConfiguration?: HttpRequestConfiguration | undefined;
    AwsServiceRequestConfiguration?: AwsServiceRequestConfiguration | undefined;
    CustomOutputConfiguration?: CustomOutputConfiguration | undefined;
    ConcurrentExecutorConfiguration?: ConcurrentExecutorConfiguration | undefined;
    SequentialExecutorConfiguration?: SequentialExecutorConfiguration | undefined;
    VastRequestConfiguration?: VastRequestConfiguration | undefined;
    HlsTagProcessorConfiguration?: HlsTagProcessorConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export type ConfigurationAliasesRequest = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export interface DashConfigurationForPut {
    MpdLocation?: string | undefined;
    OriginManifestType?: OriginManifestType | undefined;
}
export interface PutPlaybackConfigurationRequest {
    AdDecisionServerUrl?: string | undefined;
    AvailSuppression?: AvailSuppression | undefined;
    Bumper?: Bumper | undefined;
    CdnConfiguration?: CdnConfiguration | undefined;
    ConfigurationAliases?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    DashConfiguration?: DashConfigurationForPut | undefined;
    InsertionMode?: InsertionMode | undefined;
    LivePreRollConfiguration?: LivePreRollConfiguration | undefined;
    ManifestProcessingRules?: ManifestProcessingRules | undefined;
    Name: string;
    PersonalizationThresholdSeconds?: number | undefined;
    SlateAdUrl?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TranscodeProfileName?: string | undefined;
    VideoContentSourceUrl?: string | undefined;
    AdConditioningConfiguration?: AdConditioningConfiguration | undefined;
    AdDecisionServerConfiguration?: AdDecisionServerConfiguration | undefined;
    YieldOptimizationConfiguration?: YieldOptimizationConfiguration | undefined;
    FunctionMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    AdsPersonalizationTimeouts?: AdsPersonalizationTimeouts | undefined;
    AdsPersonalizationConcurrency?: AdsPersonalizationConcurrency | undefined;
    BeaconingConfiguration?: BeaconingConfiguration | undefined;
}
export interface PutPlaybackConfigurationResponse {
    AdDecisionServerUrl?: string | undefined;
    AvailSuppression?: AvailSuppression | undefined;
    Bumper?: Bumper | undefined;
    CdnConfiguration?: CdnConfiguration | undefined;
    ConfigurationAliases?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    DashConfiguration?: DashConfiguration | undefined;
    HlsConfiguration?: HlsConfiguration | undefined;
    InsertionMode?: InsertionMode | undefined;
    LivePreRollConfiguration?: LivePreRollConfiguration | undefined;
    LogConfiguration?: (LogConfiguration & {
        EnabledLoggingStrategies: __listOfLoggingStrategies;
    }) | undefined;
    ManifestProcessingRules?: ManifestProcessingRules | undefined;
    Name?: string | undefined;
    PersonalizationThresholdSeconds?: number | undefined;
    PlaybackConfigurationArn?: string | undefined;
    PlaybackEndpointPrefix?: string | undefined;
    DualStackPlaybackEndpointPrefix?: string | undefined;
    SessionInitializationEndpointPrefix?: string | undefined;
    DualStackSessionInitializationEndpointPrefix?: string | undefined;
    SlateAdUrl?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TranscodeProfileName?: string | undefined;
    VideoContentSourceUrl?: string | undefined;
    AdConditioningConfiguration?: AdConditioningConfiguration | undefined;
    AdDecisionServerConfiguration?: AdDecisionServerConfiguration | undefined;
    YieldOptimizationConfiguration?: YieldOptimizationConfiguration | undefined;
    FunctionMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    AdsPersonalizationTimeouts?: AdsPersonalizationTimeouts | undefined;
    AdsPersonalizationConcurrency?: AdsPersonalizationConcurrency | undefined;
    BeaconingConfiguration?: BeaconingConfiguration | undefined;
}
export interface StartChannelRequest {
    ChannelName: string;
}
export interface StartChannelResponse {
}
export interface StopChannelRequest {
    ChannelName: string;
}
export interface StopChannelResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateChannelRequest {
    ChannelName: string;
    FillerSlate?: SlateSource | undefined;
    Outputs: RequestOutputItem[];
    TimeShiftConfiguration?: TimeShiftConfiguration | undefined;
    Audiences?: string[] | undefined;
}
export interface UpdateChannelResponse {
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    ChannelState?: ChannelState | undefined;
    CreationTime?: Date | undefined;
    FillerSlate?: SlateSource | undefined;
    LastModifiedTime?: Date | undefined;
    Outputs?: ResponseOutputItem[] | undefined;
    PlaybackMode?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Tier?: string | undefined;
    TimeShiftConfiguration?: TimeShiftConfiguration | undefined;
    Audiences?: string[] | undefined;
}
export interface UpdateLiveSourceRequest {
    HttpPackageConfigurations: HttpPackageConfiguration[];
    LiveSourceName: string;
    SourceLocationName: string;
}
export interface UpdateLiveSourceResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    LiveSourceName?: string | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateProgramTransition {
    ScheduledStartTimeMillis?: number | undefined;
    DurationMillis?: number | undefined;
}
export interface UpdateProgramScheduleConfiguration {
    Transition?: UpdateProgramTransition | undefined;
    ClipRange?: ClipRange | undefined;
}
export interface UpdateProgramRequest {
    AdBreaks?: AdBreak[] | undefined;
    ChannelName: string;
    ProgramName: string;
    ScheduleConfiguration: UpdateProgramScheduleConfiguration;
    AudienceMedia?: AudienceMedia[] | undefined;
}
export interface UpdateProgramResponse {
    AdBreaks?: AdBreak[] | undefined;
    Arn?: string | undefined;
    ChannelName?: string | undefined;
    CreationTime?: Date | undefined;
    ProgramName?: string | undefined;
    SourceLocationName?: string | undefined;
    VodSourceName?: string | undefined;
    LiveSourceName?: string | undefined;
    ClipRange?: ClipRange | undefined;
    DurationMillis?: number | undefined;
    ScheduledStartTime?: Date | undefined;
    AudienceMedia?: AudienceMedia[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSourceLocationRequest {
    AccessConfiguration?: AccessConfiguration | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration: HttpConfiguration;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName: string;
}
export interface UpdateSourceLocationResponse {
    AccessConfiguration?: AccessConfiguration | undefined;
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    DefaultSegmentDeliveryConfiguration?: DefaultSegmentDeliveryConfiguration | undefined;
    HttpConfiguration?: HttpConfiguration | undefined;
    LastModifiedTime?: Date | undefined;
    SegmentDeliveryConfigurations?: SegmentDeliveryConfiguration[] | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateVodSourceRequest {
    HttpPackageConfigurations: HttpPackageConfiguration[];
    SourceLocationName: string;
    VodSourceName: string;
}
export interface UpdateVodSourceResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    HttpPackageConfigurations?: HttpPackageConfiguration[] | undefined;
    LastModifiedTime?: Date | undefined;
    SourceLocationName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VodSourceName?: string | undefined;
}
export type ConfigureLogsForChannelError = CommonErrors;
/**
 * Configures Amazon CloudWatch log settings for a channel.
 */
export declare const configureLogsForChannel: API.OperationMethod<ConfigureLogsForChannelRequest & RegionInput, ConfigureLogsForChannelResponse, ConfigureLogsForChannelError, Credentials | HttpClient.HttpClient>;
export type ConfigureLogsForPlaybackConfigurationError = CommonErrors;
/**
 * Defines where AWS Elemental MediaTailor sends logs for the playback configuration.
 */
export declare const configureLogsForPlaybackConfiguration: API.OperationMethod<ConfigureLogsForPlaybackConfigurationRequest & RegionInput, ConfigureLogsForPlaybackConfigurationResponse, ConfigureLogsForPlaybackConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = CommonErrors;
/**
 * Creates a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateLiveSourceError = CommonErrors;
/**
 * The live source configuration.
 */
export declare const createLiveSource: API.OperationMethod<CreateLiveSourceRequest & RegionInput, CreateLiveSourceResponse, CreateLiveSourceError, Credentials | HttpClient.HttpClient>;
export type CreatePrefetchScheduleError = BadRequestException | PlaybackConfigurationNotFound | CommonErrors;
/**
 * Creates a prefetch schedule for a playback configuration. A prefetch schedule allows you to tell MediaTailor to fetch and prepare certain ads before an ad break happens. For more information about ad prefetching, see Using ad prefetching in the *MediaTailor User Guide*.
 */
export declare const createPrefetchSchedule: API.OperationMethod<CreatePrefetchScheduleRequest & RegionInput, CreatePrefetchScheduleResponse, CreatePrefetchScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateProgramError = BadRequestException | ChannelNotFound | CommonErrors;
/**
 * Creates a program within a channel. For information about programs, see Working with programs in the *MediaTailor User Guide*.
 */
export declare const createProgram: API.OperationMethod<CreateProgramRequest & RegionInput, CreateProgramResponse, CreateProgramError, Credentials | HttpClient.HttpClient>;
export type CreateSourceLocationError = CommonErrors;
/**
 * Creates a source location. A source location is a container for sources. For more information about source locations, see Working with source locations in the *MediaTailor User Guide*.
 */
export declare const createSourceLocation: API.OperationMethod<CreateSourceLocationRequest & RegionInput, CreateSourceLocationResponse, CreateSourceLocationError, Credentials | HttpClient.HttpClient>;
export type CreateVodSourceError = CommonErrors;
/**
 * The VOD source configuration parameters.
 */
export declare const createVodSource: API.OperationMethod<CreateVodSourceRequest & RegionInput, CreateVodSourceResponse, CreateVodSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = CommonErrors;
/**
 * Deletes a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelPolicyError = CommonErrors;
/**
 * The channel policy to delete.
 */
export declare const deleteChannelPolicy: API.OperationMethod<DeleteChannelPolicyRequest & RegionInput, DeleteChannelPolicyResponse, DeleteChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = CommonErrors;
/**
 * Deletes a function. MediaTailor prevents deletion of a function that is still referenced by a playback configuration or by another function. Remove all references before deleting. For more information about functions, see Working with functions in the *MediaTailor User Guide*.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest & RegionInput, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteLiveSourceError = CommonErrors;
/**
 * The live source to delete.
 */
export declare const deleteLiveSource: API.OperationMethod<DeleteLiveSourceRequest & RegionInput, DeleteLiveSourceResponse, DeleteLiveSourceError, Credentials | HttpClient.HttpClient>;
export type DeletePlaybackConfigurationError = CommonErrors;
/**
 * Deletes a playback configuration. For information about MediaTailor configurations, see Working with configurations in AWS Elemental MediaTailor.
 */
export declare const deletePlaybackConfiguration: API.OperationMethod<DeletePlaybackConfigurationRequest & RegionInput, DeletePlaybackConfigurationResponse, DeletePlaybackConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePrefetchScheduleError = BadRequestException | PrefetchScheduleNotFound | CommonErrors;
/**
 * Deletes a prefetch schedule for a specific playback configuration. If you call `DeletePrefetchSchedule` on an expired prefetch schedule, MediaTailor returns an HTTP 404 status code. For more information about ad prefetching, see Using ad prefetching in the *MediaTailor User Guide*.
 */
export declare const deletePrefetchSchedule: API.OperationMethod<DeletePrefetchScheduleRequest & RegionInput, DeletePrefetchScheduleResponse, DeletePrefetchScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteProgramError = BadRequestException | ProgramNotFound | CommonErrors;
/**
 * Deletes a program within a channel. For information about programs, see Working with programs in the *MediaTailor User Guide*.
 */
export declare const deleteProgram: API.OperationMethod<DeleteProgramRequest & RegionInput, DeleteProgramResponse, DeleteProgramError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceLocationError = CommonErrors;
/**
 * Deletes a source location. A source location is a container for sources. For more information about source locations, see Working with source locations in the *MediaTailor User Guide*.
 */
export declare const deleteSourceLocation: API.OperationMethod<DeleteSourceLocationRequest & RegionInput, DeleteSourceLocationResponse, DeleteSourceLocationError, Credentials | HttpClient.HttpClient>;
export type DeleteVodSourceError = CommonErrors;
/**
 * The video on demand (VOD) source to delete.
 */
export declare const deleteVodSource: API.OperationMethod<DeleteVodSourceRequest & RegionInput, DeleteVodSourceResponse, DeleteVodSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = CommonErrors;
/**
 * Describes a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest & RegionInput, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeLiveSourceError = CommonErrors;
/**
 * The live source to describe.
 */
export declare const describeLiveSource: API.OperationMethod<DescribeLiveSourceRequest & RegionInput, DescribeLiveSourceResponse, DescribeLiveSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeProgramError = BadRequestException | ProgramNotFound | CommonErrors;
/**
 * Describes a program within a channel. For information about programs, see Working with programs in the *MediaTailor User Guide*.
 */
export declare const describeProgram: API.OperationMethod<DescribeProgramRequest & RegionInput, DescribeProgramResponse, DescribeProgramError, Credentials | HttpClient.HttpClient>;
export type DescribeSourceLocationError = CommonErrors;
/**
 * Describes a source location. A source location is a container for sources. For more information about source locations, see Working with source locations in the *MediaTailor User Guide*.
 */
export declare const describeSourceLocation: API.OperationMethod<DescribeSourceLocationRequest & RegionInput, DescribeSourceLocationResponse, DescribeSourceLocationError, Credentials | HttpClient.HttpClient>;
export type DescribeVodSourceError = CommonErrors;
/**
 * Provides details about a specific video on demand (VOD) source in a specific source location.
 */
export declare const describeVodSource: API.OperationMethod<DescribeVodSourceRequest & RegionInput, DescribeVodSourceResponse, DescribeVodSourceError, Credentials | HttpClient.HttpClient>;
export type GetChannelPolicyError = CommonErrors;
/**
 * Returns the channel's IAM policy. IAM policies are used to control access to your channel.
 */
export declare const getChannelPolicy: API.OperationMethod<GetChannelPolicyRequest & RegionInput, GetChannelPolicyResponse, GetChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type GetChannelScheduleError = BadRequestException | ChannelNotFound | CommonErrors;
/**
 * Retrieves information about your channel's schedule.
 */
export declare const getChannelSchedule: API.PaginatedOperationMethod<GetChannelScheduleRequest & RegionInput, GetChannelScheduleResponse, GetChannelScheduleError, Credentials | HttpClient.HttpClient, ScheduleEntry>;
export type GetFunctionError = CommonErrors;
/**
 * Retrieves the configuration and metadata for a function. For more information about functions, see Working with functions in the *MediaTailor User Guide*.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest & RegionInput, GetFunctionResponse, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetPlaybackConfigurationError = PlaybackConfigurationNotFound | CommonErrors;
/**
 * Retrieves a playback configuration. For information about MediaTailor configurations, see Working with configurations in AWS Elemental MediaTailor.
 */
export declare const getPlaybackConfiguration: API.OperationMethod<GetPlaybackConfigurationRequest & RegionInput, GetPlaybackConfigurationResponse, GetPlaybackConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPrefetchScheduleError = BadRequestException | PrefetchScheduleNotFound | CommonErrors;
/**
 * Retrieves a prefetch schedule for a playback configuration. A prefetch schedule allows you to tell MediaTailor to fetch and prepare certain ads before an ad break happens. For more information about ad prefetching, see Using ad prefetching in the *MediaTailor User Guide*.
 */
export declare const getPrefetchSchedule: API.OperationMethod<GetPrefetchScheduleRequest & RegionInput, GetPrefetchScheduleResponse, GetPrefetchScheduleError, Credentials | HttpClient.HttpClient>;
export type ListAlertsError = BadRequestException | CommonErrors;
/**
 * Lists the alerts that are associated with a MediaTailor channel assembly resource.
 */
export declare const listAlerts: API.PaginatedOperationMethod<ListAlertsRequest & RegionInput, ListAlertsResponse, ListAlertsError, Credentials | HttpClient.HttpClient, Alert>;
export type ListChannelsError = CommonErrors;
/**
 * Retrieves information about the channels that are associated with the current AWS account.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, Channel>;
export type ListFunctionsError = CommonErrors;
/**
 * Retrieves all functions associated with your AWS account in the current Region. For more information about functions, see Working with functions in the *MediaTailor User Guide*.
 */
export declare const listFunctions: API.PaginatedOperationMethod<ListFunctionsRequest & RegionInput, ListFunctionsResponse, ListFunctionsError, Credentials | HttpClient.HttpClient, Function>;
export type ListLiveSourcesError = CommonErrors;
/**
 * Lists the live sources contained in a source location. A source represents a piece of content.
 */
export declare const listLiveSources: API.PaginatedOperationMethod<ListLiveSourcesRequest & RegionInput, ListLiveSourcesResponse, ListLiveSourcesError, Credentials | HttpClient.HttpClient, LiveSource>;
export type ListPlaybackConfigurationsError = CommonErrors;
/**
 * Retrieves existing playback configurations. For information about MediaTailor configurations, see Working with Configurations in AWS Elemental MediaTailor.
 */
export declare const listPlaybackConfigurations: API.PaginatedOperationMethod<ListPlaybackConfigurationsRequest & RegionInput, ListPlaybackConfigurationsResponse, ListPlaybackConfigurationsError, Credentials | HttpClient.HttpClient, PlaybackConfiguration>;
export type ListPrefetchSchedulesError = BadRequestException | PlaybackConfigurationNotFound | CommonErrors;
/**
 * Lists the prefetch schedules for a playback configuration.
 */
export declare const listPrefetchSchedules: API.PaginatedOperationMethod<ListPrefetchSchedulesRequest & RegionInput, ListPrefetchSchedulesResponse, ListPrefetchSchedulesError, Credentials | HttpClient.HttpClient, PrefetchSchedule>;
export type ListSourceLocationsError = CommonErrors;
/**
 * Lists the source locations for a channel. A source location defines the host server URL, and contains a list of sources.
 */
export declare const listSourceLocations: API.PaginatedOperationMethod<ListSourceLocationsRequest & RegionInput, ListSourceLocationsResponse, ListSourceLocationsError, Credentials | HttpClient.HttpClient, SourceLocation>;
export type ListTagsForResourceError = BadRequestException | CommonErrors;
/**
 * A list of tags that are associated with this resource. Tags are key-value pairs that you can associate with Amazon resources to help with organization, access control, and cost tracking. For more information, see Tagging AWS Elemental MediaTailor Resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVodSourcesError = CommonErrors;
/**
 * Lists the VOD sources contained in a source location. A source represents a piece of content.
 */
export declare const listVodSources: API.PaginatedOperationMethod<ListVodSourcesRequest & RegionInput, ListVodSourcesResponse, ListVodSourcesError, Credentials | HttpClient.HttpClient, VodSource>;
export type PutChannelPolicyError = CommonErrors;
/**
 * Creates an IAM policy for the channel. IAM policies are used to control access to your channel.
 */
export declare const putChannelPolicy: API.OperationMethod<PutChannelPolicyRequest & RegionInput, PutChannelPolicyResponse, PutChannelPolicyError, Credentials | HttpClient.HttpClient>;
export type PutFunctionError = CommonErrors;
/**
 * Creates or updates a function. A function defines reusable logic that MediaTailor executes at lifecycle hooks during ad insertion. For more information about functions, see Working with functions in the *MediaTailor User Guide*.
 */
export declare const putFunction: API.OperationMethod<PutFunctionRequest & RegionInput, PutFunctionResponse, PutFunctionError, Credentials | HttpClient.HttpClient>;
export type PutPlaybackConfigurationError = CommonErrors;
/**
 * Creates a playback configuration. For information about MediaTailor configurations, see Working with configurations in AWS Elemental MediaTailor.
 */
export declare const putPlaybackConfiguration: API.OperationMethod<PutPlaybackConfigurationRequest & RegionInput, PutPlaybackConfigurationResponse, PutPlaybackConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartChannelError = BadRequestException | ChannelNotFound | CommonErrors;
/**
 * Starts a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const startChannel: API.OperationMethod<StartChannelRequest & RegionInput, StartChannelResponse, StartChannelError, Credentials | HttpClient.HttpClient>;
export type StopChannelError = BadRequestException | ChannelNotFound | CommonErrors;
/**
 * Stops a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const stopChannel: API.OperationMethod<StopChannelRequest & RegionInput, StopChannelResponse, StopChannelError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | CommonErrors;
/**
 * The resource to tag. Tags are key-value pairs that you can associate with Amazon resources to help with organization, access control, and cost tracking. For more information, see Tagging AWS Elemental MediaTailor Resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | CommonErrors;
/**
 * The resource to untag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = CommonErrors;
/**
 * Updates a channel. For information about MediaTailor channels, see Working with channels in the *MediaTailor User Guide*.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateLiveSourceError = CommonErrors;
/**
 * Updates a live source's configuration.
 */
export declare const updateLiveSource: API.OperationMethod<UpdateLiveSourceRequest & RegionInput, UpdateLiveSourceResponse, UpdateLiveSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateProgramError = BadRequestException | ProgramNotFound | CommonErrors;
/**
 * Updates a program within a channel.
 */
export declare const updateProgram: API.OperationMethod<UpdateProgramRequest & RegionInput, UpdateProgramResponse, UpdateProgramError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceLocationError = CommonErrors;
/**
 * Updates a source location. A source location is a container for sources. For more information about source locations, see Working with source locations in the *MediaTailor User Guide*.
 */
export declare const updateSourceLocation: API.OperationMethod<UpdateSourceLocationRequest & RegionInput, UpdateSourceLocationResponse, UpdateSourceLocationError, Credentials | HttpClient.HttpClient>;
export type UpdateVodSourceError = CommonErrors;
/**
 * Updates a VOD source's configuration.
 */
export declare const updateVodSource: API.OperationMethod<UpdateVodSourceRequest & RegionInput, UpdateVodSourceResponse, UpdateVodSourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediatailor.d.ts.map