import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccountLimitExceededException_base: S.TaggedErrorClass<"AccountLimitExceededException", {
    readonly message: any;
}>;
export declare class AccountLimitExceededException extends /*@__PURE__*/ AccountLimitExceededException_base {
}
declare const AccountSuspendedException_base: S.TaggedErrorClass<"AccountSuspendedException", {
    readonly message: any;
}>;
export declare class AccountSuspendedException extends /*@__PURE__*/ AccountSuspendedException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const OAuthProviderException_base: S.TaggedErrorClass<"OAuthProviderException", {
    readonly message: any;
}>;
export declare class OAuthProviderException extends /*@__PURE__*/ OAuthProviderException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type NonEmptyString = string;
export type BuildIds = string[];
export interface BatchDeleteBuildsInput {
    ids: string[];
}
export interface BuildNotDeleted {
    id?: string | undefined;
    statusCode?: string | undefined;
}
export type BuildsNotDeleted = BuildNotDeleted[];
export interface BatchDeleteBuildsOutput {
    buildsDeleted?: string[] | undefined;
    buildsNotDeleted?: BuildNotDeleted[] | undefined;
}
export type BuildBatchIds = string[];
export interface BatchGetBuildBatchesInput {
    ids: string[];
}
export type StatusType = "SUCCEEDED" | "FAILED" | "FAULT" | "TIMED_OUT" | "IN_PROGRESS" | "STOPPED" | (string & {});
export type BuildBatchPhaseType = "SUBMITTED" | "DOWNLOAD_BATCHSPEC" | "IN_PROGRESS" | "COMBINE_ARTIFACTS" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export interface PhaseContext {
    statusCode?: string | undefined;
    message?: string | undefined;
}
export type PhaseContexts = PhaseContext[];
export interface BuildBatchPhase {
    phaseType?: BuildBatchPhaseType | undefined;
    phaseStatus?: StatusType | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    durationInSeconds?: number | undefined;
    contexts?: PhaseContext[] | undefined;
}
export type BuildBatchPhases = BuildBatchPhase[];
export type SourceType = "CODECOMMIT" | "CODEPIPELINE" | "GITHUB" | "GITLAB" | "GITLAB_SELF_MANAGED" | "S3" | "BITBUCKET" | "GITHUB_ENTERPRISE" | "NO_SOURCE" | (string & {});
export type GitCloneDepth = number;
export interface GitSubmodulesConfig {
    fetchSubmodules: boolean;
}
export type SourceAuthType = "OAUTH" | "CODECONNECTIONS" | "SECRETS_MANAGER" | (string & {});
export interface SourceAuth {
    type: SourceAuthType;
    resource?: string | undefined;
}
export interface BuildStatusConfig {
    context?: string | undefined;
    targetUrl?: string | undefined;
}
export interface ProjectSource {
    type: SourceType;
    location?: string | undefined;
    gitCloneDepth?: number | undefined;
    gitSubmodulesConfig?: GitSubmodulesConfig | undefined;
    buildspec?: string | undefined;
    auth?: SourceAuth | undefined;
    reportBuildStatus?: boolean | undefined;
    buildStatusConfig?: BuildStatusConfig | undefined;
    insecureSsl?: boolean | undefined;
    sourceIdentifier?: string | undefined;
}
export type ProjectSources = ProjectSource[];
export interface ProjectSourceVersion {
    sourceIdentifier: string;
    sourceVersion: string;
}
export type ProjectSecondarySourceVersions = ProjectSourceVersion[];
export type BucketOwnerAccess = "NONE" | "READ_ONLY" | "FULL" | (string & {});
export interface BuildArtifacts {
    location?: string | undefined;
    sha256sum?: string | undefined;
    md5sum?: string | undefined;
    overrideArtifactName?: boolean | undefined;
    encryptionDisabled?: boolean | undefined;
    artifactIdentifier?: string | undefined;
    bucketOwnerAccess?: BucketOwnerAccess | undefined;
}
export type BuildArtifactsList = BuildArtifacts[];
export type CacheType = "NO_CACHE" | "S3" | "LOCAL" | (string & {});
export type CacheMode = "LOCAL_DOCKER_LAYER_CACHE" | "LOCAL_SOURCE_CACHE" | "LOCAL_CUSTOM_CACHE" | (string & {});
export type ProjectCacheModes = CacheMode[];
export interface ProjectCache {
    type: CacheType;
    location?: string | undefined;
    modes?: CacheMode[] | undefined;
    cacheNamespace?: string | undefined;
}
export type EnvironmentType = "WINDOWS_CONTAINER" | "LINUX_CONTAINER" | "LINUX_GPU_CONTAINER" | "ARM_CONTAINER" | "WINDOWS_SERVER_2019_CONTAINER" | "WINDOWS_SERVER_2022_CONTAINER" | "LINUX_LAMBDA_CONTAINER" | "ARM_LAMBDA_CONTAINER" | "LINUX_EC2" | "ARM_EC2" | "WINDOWS_EC2" | "MAC_ARM" | (string & {});
export type ComputeType = "BUILD_GENERAL1_SMALL" | "BUILD_GENERAL1_MEDIUM" | "BUILD_GENERAL1_LARGE" | "BUILD_GENERAL1_XLARGE" | "BUILD_GENERAL1_2XLARGE" | "BUILD_LAMBDA_1GB" | "BUILD_LAMBDA_2GB" | "BUILD_LAMBDA_4GB" | "BUILD_LAMBDA_8GB" | "BUILD_LAMBDA_10GB" | "ATTRIBUTE_BASED_COMPUTE" | "CUSTOM_INSTANCE_TYPE" | (string & {});
export type MachineType = "GENERAL" | "NVME" | (string & {});
export interface ComputeConfiguration {
    vCpu?: number | undefined;
    memory?: number | undefined;
    disk?: number | undefined;
    machineType?: MachineType | undefined;
    instanceType?: string | undefined;
}
export interface ProjectFleet {
    fleetArn?: string | undefined;
}
export type EnvironmentVariableType = "PLAINTEXT" | "PARAMETER_STORE" | "SECRETS_MANAGER" | (string & {});
export interface EnvironmentVariable {
    name: string;
    value: string;
    type?: EnvironmentVariableType | undefined;
}
export type EnvironmentVariables = EnvironmentVariable[];
export type CredentialProviderType = "SECRETS_MANAGER" | (string & {});
export interface RegistryCredential {
    credential: string;
    credentialProvider: CredentialProviderType;
}
export type ImagePullCredentialsType = "CODEBUILD" | "SERVICE_ROLE" | (string & {});
export type SecurityGroupIds = string[];
export interface DockerServerStatus {
    status?: string | undefined;
    message?: string | undefined;
}
export interface DockerServer {
    computeType: ComputeType;
    securityGroupIds?: string[] | undefined;
    status?: DockerServerStatus | undefined;
}
export type HostKernel = "LINUX_KERNEL_4" | "LINUX_KERNEL_6" | "LINUX_KERNEL_LATEST" | (string & {});
export interface ProjectEnvironment {
    type: EnvironmentType;
    image: string;
    computeType: ComputeType;
    computeConfiguration?: ComputeConfiguration | undefined;
    fleet?: ProjectFleet | undefined;
    environmentVariables?: EnvironmentVariable[] | undefined;
    privilegedMode?: boolean | undefined;
    certificate?: string | undefined;
    registryCredential?: RegistryCredential | undefined;
    imagePullCredentialsType?: ImagePullCredentialsType | undefined;
    dockerServer?: DockerServer | undefined;
    hostKernel?: HostKernel | undefined;
}
export type LogsConfigStatusType = "ENABLED" | "DISABLED" | (string & {});
export interface CloudWatchLogsConfig {
    status: LogsConfigStatusType;
    groupName?: string | undefined;
    streamName?: string | undefined;
}
export interface S3LogsConfig {
    status: LogsConfigStatusType;
    location?: string | undefined;
    encryptionDisabled?: boolean | undefined;
    bucketOwnerAccess?: BucketOwnerAccess | undefined;
}
export interface LogsConfig {
    cloudWatchLogs?: CloudWatchLogsConfig | undefined;
    s3Logs?: S3LogsConfig | undefined;
}
export type Subnets = string[];
export interface VpcConfig {
    vpcId?: string | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
}
export type FileSystemType = "EFS" | (string & {});
export interface ProjectFileSystemLocation {
    type?: FileSystemType | undefined;
    location?: string | undefined;
    mountPoint?: string | undefined;
    identifier?: string | undefined;
    mountOptions?: string | undefined;
}
export type ProjectFileSystemLocations = ProjectFileSystemLocation[];
export type ComputeTypesAllowed = string[];
export type FleetsAllowed = string[];
export interface BatchRestrictions {
    maximumBuildsAllowed?: number | undefined;
    computeTypesAllowed?: string[] | undefined;
    fleetsAllowed?: string[] | undefined;
}
export type BatchReportModeType = "REPORT_INDIVIDUAL_BUILDS" | "REPORT_AGGREGATED_BATCH" | (string & {});
export interface ProjectBuildBatchConfig {
    serviceRole?: string | undefined;
    combineArtifacts?: boolean | undefined;
    restrictions?: BatchRestrictions | undefined;
    timeoutInMins?: number | undefined;
    batchReportMode?: BatchReportModeType | undefined;
}
export type Identifiers = string[];
export type ArtifactsType = "CODEPIPELINE" | "S3" | "NO_ARTIFACTS" | (string & {});
export interface ResolvedArtifact {
    type?: ArtifactsType | undefined;
    location?: string | undefined;
    identifier?: string | undefined;
}
export type ResolvedSecondaryArtifacts = ResolvedArtifact[];
export interface BuildSummary {
    arn?: string | undefined;
    requestedOn?: Date | undefined;
    buildStatus?: StatusType | undefined;
    primaryArtifact?: ResolvedArtifact | undefined;
    secondaryArtifacts?: ResolvedArtifact[] | undefined;
}
export type BuildSummaries = BuildSummary[];
export interface BuildGroup {
    identifier?: string | undefined;
    dependsOn?: string[] | undefined;
    ignoreFailure?: boolean | undefined;
    currentBuildSummary?: BuildSummary | undefined;
    priorBuildSummaryList?: BuildSummary[] | undefined;
}
export type BuildGroups = BuildGroup[];
export type BuildReportArns = string[];
export interface BuildBatch {
    id?: string | undefined;
    arn?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    currentPhase?: string | undefined;
    buildBatchStatus?: StatusType | undefined;
    sourceVersion?: string | undefined;
    resolvedSourceVersion?: string | undefined;
    projectName?: string | undefined;
    phases?: BuildBatchPhase[] | undefined;
    source?: ProjectSource | undefined;
    secondarySources?: ProjectSource[] | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    artifacts?: BuildArtifacts | undefined;
    secondaryArtifacts?: BuildArtifacts[] | undefined;
    cache?: ProjectCache | undefined;
    environment?: ProjectEnvironment | undefined;
    serviceRole?: string | undefined;
    logConfig?: LogsConfig | undefined;
    buildTimeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    complete?: boolean | undefined;
    initiator?: string | undefined;
    vpcConfig?: VpcConfig | undefined;
    encryptionKey?: string | undefined;
    buildBatchNumber?: number | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    buildBatchConfig?: ProjectBuildBatchConfig | undefined;
    buildGroups?: BuildGroup[] | undefined;
    debugSessionEnabled?: boolean | undefined;
    reportArns?: string[] | undefined;
}
export type BuildBatches = BuildBatch[];
export interface BatchGetBuildBatchesOutput {
    buildBatches?: BuildBatch[] | undefined;
    buildBatchesNotFound?: string[] | undefined;
}
export interface BatchGetBuildsInput {
    ids: string[];
}
export type BuildPhaseType = "SUBMITTED" | "QUEUED" | "PROVISIONING" | "DOWNLOAD_SOURCE" | "INSTALL" | "PRE_BUILD" | "BUILD" | "POST_BUILD" | "UPLOAD_ARTIFACTS" | "FINALIZING" | "COMPLETED" | (string & {});
export interface BuildPhase {
    phaseType?: BuildPhaseType | undefined;
    phaseStatus?: StatusType | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    durationInSeconds?: number | undefined;
    contexts?: PhaseContext[] | undefined;
}
export type BuildPhases = BuildPhase[];
export interface LogsLocation {
    groupName?: string | undefined;
    streamName?: string | undefined;
    deepLink?: string | undefined;
    s3DeepLink?: string | undefined;
    cloudWatchLogsArn?: string | undefined;
    s3LogsArn?: string | undefined;
    cloudWatchLogs?: CloudWatchLogsConfig | undefined;
    s3Logs?: S3LogsConfig | undefined;
}
export interface NetworkInterface {
    subnetId?: string | undefined;
    networkInterfaceId?: string | undefined;
}
export interface ExportedEnvironmentVariable {
    name?: string | undefined;
    value?: string | undefined;
}
export type ExportedEnvironmentVariables = ExportedEnvironmentVariable[];
export interface DebugSession {
    sessionEnabled?: boolean | undefined;
    sessionTarget?: string | undefined;
}
export interface AutoRetryConfig {
    autoRetryLimit?: number | undefined;
    autoRetryNumber?: number | undefined;
    nextAutoRetry?: string | undefined;
    previousAutoRetry?: string | undefined;
}
export interface Build {
    id?: string | undefined;
    arn?: string | undefined;
    buildNumber?: number | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    currentPhase?: string | undefined;
    buildStatus?: StatusType | undefined;
    sourceVersion?: string | undefined;
    resolvedSourceVersion?: string | undefined;
    projectName?: string | undefined;
    phases?: BuildPhase[] | undefined;
    source?: ProjectSource | undefined;
    secondarySources?: ProjectSource[] | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    artifacts?: BuildArtifacts | undefined;
    secondaryArtifacts?: BuildArtifacts[] | undefined;
    cache?: ProjectCache | undefined;
    environment?: ProjectEnvironment | undefined;
    serviceRole?: string | undefined;
    logs?: LogsLocation | undefined;
    timeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    buildComplete?: boolean | undefined;
    initiator?: string | undefined;
    vpcConfig?: VpcConfig | undefined;
    networkInterface?: NetworkInterface | undefined;
    encryptionKey?: string | undefined;
    exportedEnvironmentVariables?: ExportedEnvironmentVariable[] | undefined;
    reportArns?: string[] | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    debugSession?: DebugSession | undefined;
    buildBatchArn?: string | undefined;
    autoRetryConfig?: AutoRetryConfig | undefined;
}
export type Builds = Build[];
export interface BatchGetBuildsOutput {
    builds?: Build[] | undefined;
    buildsNotFound?: string[] | undefined;
}
export type CommandExecutionIds = string[];
export interface BatchGetCommandExecutionsInput {
    sandboxId: string;
    commandExecutionIds: string[];
}
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type CommandType = "SHELL" | (string & {});
export interface CommandExecution {
    id?: string | undefined;
    sandboxId?: string | undefined;
    submitTime?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    status?: string | undefined;
    command?: string | redacted.Redacted<string> | undefined;
    type?: CommandType | undefined;
    exitCode?: string | undefined;
    standardOutputContent?: string | redacted.Redacted<string> | undefined;
    standardErrContent?: string | redacted.Redacted<string> | undefined;
    logs?: LogsLocation | undefined;
    sandboxArn?: string | undefined;
}
export type CommandExecutions = CommandExecution[];
export interface BatchGetCommandExecutionsOutput {
    commandExecutions?: CommandExecution[] | undefined;
    commandExecutionsNotFound?: string[] | undefined;
}
export type FleetNames = string[];
export interface BatchGetFleetsInput {
    names: string[];
}
export type FleetName = string;
export type FleetStatusCode = "CREATING" | "UPDATING" | "ROTATING" | "PENDING_DELETION" | "DELETING" | "CREATE_FAILED" | "UPDATE_ROLLBACK_FAILED" | "ACTIVE" | (string & {});
export type FleetContextCode = "CREATE_FAILED" | "UPDATE_FAILED" | "ACTION_REQUIRED" | "PENDING_DELETION" | "INSUFFICIENT_CAPACITY" | (string & {});
export interface FleetStatus {
    statusCode?: FleetStatusCode | undefined;
    context?: FleetContextCode | undefined;
    message?: string | undefined;
}
export type FleetCapacity = number;
export type FleetScalingType = "TARGET_TRACKING_SCALING" | (string & {});
export type FleetScalingMetricType = "FLEET_UTILIZATION_RATE" | (string & {});
export interface TargetTrackingScalingConfiguration {
    metricType?: FleetScalingMetricType | undefined;
    targetValue?: number | undefined;
}
export type TargetTrackingScalingConfigurations = TargetTrackingScalingConfiguration[];
export interface ScalingConfigurationOutput {
    scalingType?: FleetScalingType | undefined;
    targetTrackingScalingConfigs?: TargetTrackingScalingConfiguration[] | undefined;
    maxCapacity?: number | undefined;
    desiredCapacity?: number | undefined;
}
export type FleetOverflowBehavior = "QUEUE" | "ON_DEMAND" | (string & {});
export type FleetProxyRuleBehavior = "ALLOW_ALL" | "DENY_ALL" | (string & {});
export type FleetProxyRuleType = "DOMAIN" | "IP" | (string & {});
export type FleetProxyRuleEffectType = "ALLOW" | "DENY" | (string & {});
export type FleetProxyRuleEntities = string[];
export interface FleetProxyRule {
    type: FleetProxyRuleType;
    effect: FleetProxyRuleEffectType;
    entities: string[];
}
export type FleetProxyRules = FleetProxyRule[];
export interface ProxyConfiguration {
    defaultBehavior?: FleetProxyRuleBehavior | undefined;
    orderedProxyRules?: FleetProxyRule[] | undefined;
}
export type KeyInput = string;
export type ValueInput = string;
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type TagList = Tag[];
export interface Fleet {
    arn?: string | undefined;
    name?: string | undefined;
    id?: string | undefined;
    created?: Date | undefined;
    lastModified?: Date | undefined;
    status?: FleetStatus | undefined;
    baseCapacity?: number | undefined;
    environmentType?: EnvironmentType | undefined;
    computeType?: ComputeType | undefined;
    computeConfiguration?: ComputeConfiguration | undefined;
    scalingConfiguration?: ScalingConfigurationOutput | undefined;
    overflowBehavior?: FleetOverflowBehavior | undefined;
    vpcConfig?: VpcConfig | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    imageId?: string | undefined;
    fleetServiceRole?: string | undefined;
    tags?: Tag[] | undefined;
}
export type Fleets = Fleet[];
export interface BatchGetFleetsOutput {
    fleets?: Fleet[] | undefined;
    fleetsNotFound?: string[] | undefined;
}
export type ProjectNames = string[];
export interface BatchGetProjectsInput {
    names: string[];
}
export type ProjectName = string;
export type ProjectDescription = string;
export type ArtifactNamespace = "NONE" | "BUILD_ID" | (string & {});
export type ArtifactPackaging = "NONE" | "ZIP" | (string & {});
export interface ProjectArtifacts {
    type: ArtifactsType;
    location?: string | undefined;
    path?: string | undefined;
    namespaceType?: ArtifactNamespace | undefined;
    name?: string | undefined;
    packaging?: ArtifactPackaging | undefined;
    overrideArtifactName?: boolean | undefined;
    encryptionDisabled?: boolean | undefined;
    artifactIdentifier?: string | undefined;
    bucketOwnerAccess?: BucketOwnerAccess | undefined;
}
export type ProjectArtifactsList = ProjectArtifacts[];
export type BuildTimeOut = number;
export type TimeOut = number;
export type WebhookFilterType = "EVENT" | "BASE_REF" | "HEAD_REF" | "ACTOR_ACCOUNT_ID" | "FILE_PATH" | "COMMIT_MESSAGE" | "WORKFLOW_NAME" | "TAG_NAME" | "RELEASE_NAME" | "REPOSITORY_NAME" | "ORGANIZATION_NAME" | (string & {});
export interface WebhookFilter {
    type: WebhookFilterType;
    pattern: string;
    excludeMatchedPattern?: boolean | undefined;
}
export type FilterGroup = WebhookFilter[];
export type FilterGroups = WebhookFilter[][];
export type WebhookBuildType = "BUILD" | "BUILD_BATCH" | "RUNNER_BUILDKITE_BUILD" | (string & {});
export type WebhookScopeType = "GITHUB_ORGANIZATION" | "GITHUB_GLOBAL" | "GITLAB_GROUP" | (string & {});
export interface ScopeConfiguration {
    name: string;
    domain?: string | undefined;
    scope: WebhookScopeType;
}
export type WebhookStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | (string & {});
export type PullRequestBuildCommentApproval = "DISABLED" | "ALL_PULL_REQUESTS" | "FORK_PULL_REQUESTS" | (string & {});
export type PullRequestBuildApproverRole = "GITHUB_READ" | "GITHUB_TRIAGE" | "GITHUB_WRITE" | "GITHUB_MAINTAIN" | "GITHUB_ADMIN" | "GITLAB_GUEST" | "GITLAB_PLANNER" | "GITLAB_REPORTER" | "GITLAB_DEVELOPER" | "GITLAB_MAINTAINER" | "GITLAB_OWNER" | "BITBUCKET_READ" | "BITBUCKET_WRITE" | "BITBUCKET_ADMIN" | (string & {});
export type PullRequestBuildApproverRoles = PullRequestBuildApproverRole[];
export interface PullRequestBuildPolicy {
    requiresCommentApproval: PullRequestBuildCommentApproval;
    approverRoles?: PullRequestBuildApproverRole[] | undefined;
}
export interface Webhook {
    url?: string | undefined;
    payloadUrl?: string | undefined;
    secret?: string | undefined;
    branchFilter?: string | undefined;
    filterGroups?: WebhookFilter[][] | undefined;
    buildType?: WebhookBuildType | undefined;
    manualCreation?: boolean | undefined;
    lastModifiedSecret?: Date | undefined;
    scopeConfiguration?: ScopeConfiguration | undefined;
    status?: WebhookStatus | undefined;
    statusMessage?: string | undefined;
    pullRequestBuildPolicy?: PullRequestBuildPolicy | undefined;
}
export interface ProjectBadge {
    badgeEnabled?: boolean | undefined;
    badgeRequestUrl?: string | undefined;
}
export type ProjectVisibilityType = "PUBLIC_READ" | "PRIVATE" | (string & {});
export interface Project {
    name?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    source?: ProjectSource | undefined;
    secondarySources?: ProjectSource[] | undefined;
    sourceVersion?: string | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    artifacts?: ProjectArtifacts | undefined;
    secondaryArtifacts?: ProjectArtifacts[] | undefined;
    cache?: ProjectCache | undefined;
    environment?: ProjectEnvironment | undefined;
    serviceRole?: string | undefined;
    timeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    encryptionKey?: string | undefined;
    tags?: Tag[] | undefined;
    created?: Date | undefined;
    lastModified?: Date | undefined;
    webhook?: Webhook | undefined;
    vpcConfig?: VpcConfig | undefined;
    badge?: ProjectBadge | undefined;
    logsConfig?: LogsConfig | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    buildBatchConfig?: ProjectBuildBatchConfig | undefined;
    concurrentBuildLimit?: number | undefined;
    projectVisibility?: ProjectVisibilityType | undefined;
    publicProjectAlias?: string | undefined;
    resourceAccessRole?: string | undefined;
    autoRetryLimit?: number | undefined;
}
export type Projects = Project[];
export interface BatchGetProjectsOutput {
    projects?: Project[] | undefined;
    projectsNotFound?: string[] | undefined;
}
export type ReportGroupArns = string[];
export interface BatchGetReportGroupsInput {
    reportGroupArns: string[];
}
export type ReportGroupName = string;
export type ReportType = "TEST" | "CODE_COVERAGE" | (string & {});
export type ReportExportConfigType = "S3" | "NO_EXPORT" | (string & {});
export type ReportPackagingType = "ZIP" | "NONE" | (string & {});
export interface S3ReportExportConfig {
    bucket?: string | undefined;
    bucketOwner?: string | undefined;
    path?: string | undefined;
    packaging?: ReportPackagingType | undefined;
    encryptionKey?: string | undefined;
    encryptionDisabled?: boolean | undefined;
}
export interface ReportExportConfig {
    exportConfigType?: ReportExportConfigType | undefined;
    s3Destination?: S3ReportExportConfig | undefined;
}
export type ReportGroupStatusType = "ACTIVE" | "DELETING" | (string & {});
export interface ReportGroup {
    arn?: string | undefined;
    name?: string | undefined;
    type?: ReportType | undefined;
    exportConfig?: ReportExportConfig | undefined;
    created?: Date | undefined;
    lastModified?: Date | undefined;
    tags?: Tag[] | undefined;
    status?: ReportGroupStatusType | undefined;
}
export type ReportGroups = ReportGroup[];
export interface BatchGetReportGroupsOutput {
    reportGroups?: ReportGroup[] | undefined;
    reportGroupsNotFound?: string[] | undefined;
}
export type ReportArns = string[];
export interface BatchGetReportsInput {
    reportArns: string[];
}
export type ReportStatusType = "GENERATING" | "SUCCEEDED" | "FAILED" | "INCOMPLETE" | "DELETING" | (string & {});
export type ReportStatusCounts = {
    [key: string]: number | undefined;
};
export interface TestReportSummary {
    total: number;
    statusCounts: {
        [key: string]: number | undefined;
    };
    durationInNanoSeconds: number;
}
export type Percentage = number;
export type NonNegativeInt = number;
export interface CodeCoverageReportSummary {
    lineCoveragePercentage?: number | undefined;
    linesCovered?: number | undefined;
    linesMissed?: number | undefined;
    branchCoveragePercentage?: number | undefined;
    branchesCovered?: number | undefined;
    branchesMissed?: number | undefined;
}
export interface Report {
    arn?: string | undefined;
    type?: ReportType | undefined;
    name?: string | undefined;
    reportGroupArn?: string | undefined;
    executionId?: string | undefined;
    status?: ReportStatusType | undefined;
    created?: Date | undefined;
    expired?: Date | undefined;
    exportConfig?: ReportExportConfig | undefined;
    truncated?: boolean | undefined;
    testSummary?: TestReportSummary | undefined;
    codeCoverageSummary?: CodeCoverageReportSummary | undefined;
}
export type Reports = Report[];
export interface BatchGetReportsOutput {
    reports?: Report[] | undefined;
    reportsNotFound?: string[] | undefined;
}
export type SandboxIds = string[];
export interface BatchGetSandboxesInput {
    ids: string[];
}
export interface SandboxSessionPhase {
    phaseType?: string | undefined;
    phaseStatus?: StatusType | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    durationInSeconds?: number | undefined;
    contexts?: PhaseContext[] | undefined;
}
export type SandboxSessionPhases = SandboxSessionPhase[];
export interface SandboxSession {
    id?: string | undefined;
    status?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    currentPhase?: string | undefined;
    phases?: SandboxSessionPhase[] | undefined;
    resolvedSourceVersion?: string | undefined;
    logs?: LogsLocation | undefined;
    networkInterface?: NetworkInterface | undefined;
}
export interface Sandbox {
    id?: string | undefined;
    arn?: string | undefined;
    projectName?: string | undefined;
    requestTime?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    status?: string | undefined;
    source?: ProjectSource | undefined;
    sourceVersion?: string | undefined;
    secondarySources?: ProjectSource[] | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    environment?: ProjectEnvironment | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    timeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    vpcConfig?: VpcConfig | undefined;
    logConfig?: LogsConfig | undefined;
    encryptionKey?: string | undefined;
    serviceRole?: string | undefined;
    currentSession?: SandboxSession | undefined;
}
export type Sandboxes = Sandbox[];
export interface BatchGetSandboxesOutput {
    sandboxes?: Sandbox[] | undefined;
    sandboxesNotFound?: string[] | undefined;
}
export interface ScalingConfigurationInput {
    scalingType?: FleetScalingType | undefined;
    targetTrackingScalingConfigs?: TargetTrackingScalingConfiguration[] | undefined;
    maxCapacity?: number | undefined;
}
export interface CreateFleetInput {
    name: string;
    baseCapacity: number;
    environmentType: EnvironmentType;
    computeType: ComputeType;
    computeConfiguration?: ComputeConfiguration | undefined;
    scalingConfiguration?: ScalingConfigurationInput | undefined;
    overflowBehavior?: FleetOverflowBehavior | undefined;
    vpcConfig?: VpcConfig | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    imageId?: string | undefined;
    fleetServiceRole?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateFleetOutput {
    fleet?: Fleet | undefined;
}
export interface CreateProjectInput {
    name: string;
    description?: string | undefined;
    source: ProjectSource;
    secondarySources?: ProjectSource[] | undefined;
    sourceVersion?: string | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    artifacts: ProjectArtifacts;
    secondaryArtifacts?: ProjectArtifacts[] | undefined;
    cache?: ProjectCache | undefined;
    environment: ProjectEnvironment;
    serviceRole: string;
    timeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    encryptionKey?: string | undefined;
    tags?: Tag[] | undefined;
    vpcConfig?: VpcConfig | undefined;
    badgeEnabled?: boolean | undefined;
    logsConfig?: LogsConfig | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    buildBatchConfig?: ProjectBuildBatchConfig | undefined;
    concurrentBuildLimit?: number | undefined;
    autoRetryLimit?: number | undefined;
}
export interface CreateProjectOutput {
    project?: Project | undefined;
}
export interface CreateReportGroupInput {
    name: string;
    type: ReportType;
    exportConfig: ReportExportConfig;
    tags?: Tag[] | undefined;
}
export interface CreateReportGroupOutput {
    reportGroup?: ReportGroup | undefined;
}
export interface CreateWebhookInput {
    projectName: string;
    branchFilter?: string | undefined;
    filterGroups?: WebhookFilter[][] | undefined;
    buildType?: WebhookBuildType | undefined;
    manualCreation?: boolean | undefined;
    scopeConfiguration?: ScopeConfiguration | undefined;
    pullRequestBuildPolicy?: PullRequestBuildPolicy | undefined;
}
export interface CreateWebhookOutput {
    webhook?: Webhook | undefined;
}
export interface DeleteBuildBatchInput {
    id: string;
}
export interface DeleteBuildBatchOutput {
    statusCode?: string | undefined;
    buildsDeleted?: string[] | undefined;
    buildsNotDeleted?: BuildNotDeleted[] | undefined;
}
export interface DeleteFleetInput {
    arn: string;
}
export interface DeleteFleetOutput {
}
export interface DeleteProjectInput {
    name: string;
}
export interface DeleteProjectOutput {
}
export interface DeleteReportInput {
    arn: string;
}
export interface DeleteReportOutput {
}
export interface DeleteReportGroupInput {
    arn: string;
    deleteReports?: boolean | undefined;
}
export interface DeleteReportGroupOutput {
}
export interface DeleteResourcePolicyInput {
    resourceArn: string;
}
export interface DeleteResourcePolicyOutput {
}
export interface DeleteSourceCredentialsInput {
    arn: string;
}
export interface DeleteSourceCredentialsOutput {
    arn?: string | undefined;
}
export interface DeleteWebhookInput {
    projectName: string;
}
export interface DeleteWebhookOutput {
}
export type PageSize = number;
export type SortOrderType = "ASCENDING" | "DESCENDING" | (string & {});
export type ReportCodeCoverageSortByType = "LINE_COVERAGE_PERCENTAGE" | "FILE_PATH" | (string & {});
export interface DescribeCodeCoveragesInput {
    reportArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    sortBy?: ReportCodeCoverageSortByType | undefined;
    minLineCoveragePercentage?: number | undefined;
    maxLineCoveragePercentage?: number | undefined;
}
export interface CodeCoverage {
    id?: string | undefined;
    reportARN?: string | undefined;
    filePath?: string | undefined;
    lineCoveragePercentage?: number | undefined;
    linesCovered?: number | undefined;
    linesMissed?: number | undefined;
    branchCoveragePercentage?: number | undefined;
    branchesCovered?: number | undefined;
    branchesMissed?: number | undefined;
    expired?: Date | undefined;
}
export type CodeCoverages = CodeCoverage[];
export interface DescribeCodeCoveragesOutput {
    nextToken?: string | undefined;
    codeCoverages?: CodeCoverage[] | undefined;
}
export interface TestCaseFilter {
    status?: string | undefined;
    keyword?: string | undefined;
}
export interface DescribeTestCasesInput {
    reportArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: TestCaseFilter | undefined;
}
export interface TestCase {
    reportArn?: string | undefined;
    testRawDataPath?: string | undefined;
    prefix?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    durationInNanoSeconds?: number | undefined;
    message?: string | undefined;
    expired?: Date | undefined;
    testSuiteName?: string | undefined;
}
export type TestCases = TestCase[];
export interface DescribeTestCasesOutput {
    nextToken?: string | undefined;
    testCases?: TestCase[] | undefined;
}
export type ReportGroupTrendFieldType = "PASS_RATE" | "DURATION" | "TOTAL" | "LINE_COVERAGE" | "LINES_COVERED" | "LINES_MISSED" | "BRANCH_COVERAGE" | "BRANCHES_COVERED" | "BRANCHES_MISSED" | (string & {});
export interface GetReportGroupTrendInput {
    reportGroupArn: string;
    numOfReports?: number | undefined;
    trendField: ReportGroupTrendFieldType;
}
export interface ReportGroupTrendStats {
    average?: string | undefined;
    max?: string | undefined;
    min?: string | undefined;
}
export interface ReportWithRawData {
    reportArn?: string | undefined;
    data?: string | undefined;
}
export type ReportGroupTrendRawDataList = ReportWithRawData[];
export interface GetReportGroupTrendOutput {
    stats?: ReportGroupTrendStats | undefined;
    rawData?: ReportWithRawData[] | undefined;
}
export interface GetResourcePolicyInput {
    resourceArn: string;
}
export interface GetResourcePolicyOutput {
    policy?: string | undefined;
}
export type ServerType = "GITHUB" | "BITBUCKET" | "GITHUB_ENTERPRISE" | "GITLAB" | "GITLAB_SELF_MANAGED" | (string & {});
export type AuthType = "OAUTH" | "BASIC_AUTH" | "PERSONAL_ACCESS_TOKEN" | "CODECONNECTIONS" | "SECRETS_MANAGER" | (string & {});
export interface ImportSourceCredentialsInput {
    username?: string | undefined;
    token: string | redacted.Redacted<string>;
    serverType: ServerType;
    authType: AuthType;
    shouldOverwrite?: boolean | undefined;
}
export interface ImportSourceCredentialsOutput {
    arn?: string | undefined;
}
export interface InvalidateProjectCacheInput {
    projectName: string;
}
export interface InvalidateProjectCacheOutput {
}
export interface BuildBatchFilter {
    status?: StatusType | undefined;
}
export interface ListBuildBatchesInput {
    filter?: BuildBatchFilter | undefined;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildBatchesOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildBatchesForProjectInput {
    projectName?: string | undefined;
    filter?: BuildBatchFilter | undefined;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildBatchesForProjectOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildsInput {
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildsOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildsForProjectInput {
    projectName: string;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListBuildsForProjectOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface ListCommandExecutionsForSandboxInput {
    sandboxId: string;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListCommandExecutionsForSandboxOutput {
    commandExecutions?: CommandExecution[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCuratedEnvironmentImagesInput {
}
export type PlatformType = "DEBIAN" | "AMAZON_LINUX" | "UBUNTU" | "WINDOWS_SERVER" | (string & {});
export type LanguageType = "JAVA" | "PYTHON" | "NODE_JS" | "RUBY" | "GOLANG" | "DOCKER" | "ANDROID" | "DOTNET" | "BASE" | "PHP" | (string & {});
export type ImageVersions = string[];
export interface EnvironmentImage {
    name?: string | undefined;
    description?: string | undefined;
    versions?: string[] | undefined;
}
export type EnvironmentImages = EnvironmentImage[];
export interface EnvironmentLanguage {
    language?: LanguageType | undefined;
    images?: EnvironmentImage[] | undefined;
}
export type EnvironmentLanguages = EnvironmentLanguage[];
export interface EnvironmentPlatform {
    platform?: PlatformType | undefined;
    languages?: EnvironmentLanguage[] | undefined;
}
export type EnvironmentPlatforms = EnvironmentPlatform[];
export interface ListCuratedEnvironmentImagesOutput {
    platforms?: EnvironmentPlatform[] | undefined;
}
export type FleetSortByType = "NAME" | "CREATED_TIME" | "LAST_MODIFIED_TIME" | (string & {});
export interface ListFleetsInput {
    nextToken?: string | redacted.Redacted<string> | undefined;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    sortBy?: FleetSortByType | undefined;
}
export type FleetArns = string[];
export interface ListFleetsOutput {
    nextToken?: string | undefined;
    fleets?: string[] | undefined;
}
export type ProjectSortByType = "NAME" | "CREATED_TIME" | "LAST_MODIFIED_TIME" | (string & {});
export interface ListProjectsInput {
    sortBy?: ProjectSortByType | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListProjectsOutput {
    nextToken?: string | undefined;
    projects?: string[] | undefined;
}
export type ReportGroupSortByType = "NAME" | "CREATED_TIME" | "LAST_MODIFIED_TIME" | (string & {});
export interface ListReportGroupsInput {
    sortOrder?: SortOrderType | undefined;
    sortBy?: ReportGroupSortByType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListReportGroupsOutput {
    nextToken?: string | undefined;
    reportGroups?: string[] | undefined;
}
export interface ReportFilter {
    status?: ReportStatusType | undefined;
}
export interface ListReportsInput {
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: ReportFilter | undefined;
}
export interface ListReportsOutput {
    nextToken?: string | undefined;
    reports?: string[] | undefined;
}
export interface ListReportsForReportGroupInput {
    reportGroupArn: string;
    nextToken?: string | undefined;
    sortOrder?: SortOrderType | undefined;
    maxResults?: number | undefined;
    filter?: ReportFilter | undefined;
}
export interface ListReportsForReportGroupOutput {
    nextToken?: string | undefined;
    reports?: string[] | undefined;
}
export interface ListSandboxesInput {
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | undefined;
}
export interface ListSandboxesOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSandboxesForProjectInput {
    projectName: string;
    maxResults?: number | undefined;
    sortOrder?: SortOrderType | undefined;
    nextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListSandboxesForProjectOutput {
    ids?: string[] | undefined;
    nextToken?: string | undefined;
}
export type SharedResourceSortByType = "ARN" | "MODIFIED_TIME" | (string & {});
export interface ListSharedProjectsInput {
    sortBy?: SharedResourceSortByType | undefined;
    sortOrder?: SortOrderType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ProjectArns = string[];
export interface ListSharedProjectsOutput {
    nextToken?: string | undefined;
    projects?: string[] | undefined;
}
export interface ListSharedReportGroupsInput {
    sortOrder?: SortOrderType | undefined;
    sortBy?: SharedResourceSortByType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListSharedReportGroupsOutput {
    nextToken?: string | undefined;
    reportGroups?: string[] | undefined;
}
export interface ListSourceCredentialsInput {
}
export interface SourceCredentialsInfo {
    arn?: string | undefined;
    serverType?: ServerType | undefined;
    authType?: AuthType | undefined;
    resource?: string | undefined;
}
export type SourceCredentialsInfos = SourceCredentialsInfo[];
export interface ListSourceCredentialsOutput {
    sourceCredentialsInfos?: SourceCredentialsInfo[] | undefined;
}
export interface PutResourcePolicyInput {
    policy: string;
    resourceArn: string;
}
export interface PutResourcePolicyOutput {
    resourceArn?: string | undefined;
}
export interface RetryBuildInput {
    id?: string | undefined;
    idempotencyToken?: string | undefined;
}
export interface RetryBuildOutput {
    build?: Build | undefined;
}
export type RetryBuildBatchType = "RETRY_ALL_BUILDS" | "RETRY_FAILED_BUILDS" | (string & {});
export interface RetryBuildBatchInput {
    id?: string | undefined;
    idempotencyToken?: string | undefined;
    retryType?: RetryBuildBatchType | undefined;
}
export interface RetryBuildBatchOutput {
    buildBatch?: BuildBatch | undefined;
}
export interface StartBuildInput {
    projectName: string;
    secondarySourcesOverride?: ProjectSource[] | undefined;
    secondarySourcesVersionOverride?: ProjectSourceVersion[] | undefined;
    sourceVersion?: string | undefined;
    artifactsOverride?: ProjectArtifacts | undefined;
    secondaryArtifactsOverride?: ProjectArtifacts[] | undefined;
    environmentVariablesOverride?: EnvironmentVariable[] | undefined;
    sourceTypeOverride?: SourceType | undefined;
    sourceLocationOverride?: string | undefined;
    sourceAuthOverride?: SourceAuth | undefined;
    gitCloneDepthOverride?: number | undefined;
    gitSubmodulesConfigOverride?: GitSubmodulesConfig | undefined;
    buildspecOverride?: string | undefined;
    insecureSslOverride?: boolean | undefined;
    reportBuildStatusOverride?: boolean | undefined;
    buildStatusConfigOverride?: BuildStatusConfig | undefined;
    environmentTypeOverride?: EnvironmentType | undefined;
    imageOverride?: string | undefined;
    computeTypeOverride?: ComputeType | undefined;
    certificateOverride?: string | undefined;
    cacheOverride?: ProjectCache | undefined;
    serviceRoleOverride?: string | undefined;
    privilegedModeOverride?: boolean | undefined;
    timeoutInMinutesOverride?: number | undefined;
    queuedTimeoutInMinutesOverride?: number | undefined;
    encryptionKeyOverride?: string | undefined;
    idempotencyToken?: string | undefined;
    logsConfigOverride?: LogsConfig | undefined;
    registryCredentialOverride?: RegistryCredential | undefined;
    imagePullCredentialsTypeOverride?: ImagePullCredentialsType | undefined;
    debugSessionEnabled?: boolean | undefined;
    fleetOverride?: ProjectFleet | undefined;
    autoRetryLimitOverride?: number | undefined;
    hostKernelOverride?: HostKernel | undefined;
}
export interface StartBuildOutput {
    build?: Build | undefined;
}
export interface StartBuildBatchInput {
    projectName: string;
    secondarySourcesOverride?: ProjectSource[] | undefined;
    secondarySourcesVersionOverride?: ProjectSourceVersion[] | undefined;
    sourceVersion?: string | undefined;
    artifactsOverride?: ProjectArtifacts | undefined;
    secondaryArtifactsOverride?: ProjectArtifacts[] | undefined;
    environmentVariablesOverride?: EnvironmentVariable[] | undefined;
    sourceTypeOverride?: SourceType | undefined;
    sourceLocationOverride?: string | undefined;
    sourceAuthOverride?: SourceAuth | undefined;
    gitCloneDepthOverride?: number | undefined;
    gitSubmodulesConfigOverride?: GitSubmodulesConfig | undefined;
    buildspecOverride?: string | undefined;
    insecureSslOverride?: boolean | undefined;
    reportBuildBatchStatusOverride?: boolean | undefined;
    environmentTypeOverride?: EnvironmentType | undefined;
    imageOverride?: string | undefined;
    computeTypeOverride?: ComputeType | undefined;
    certificateOverride?: string | undefined;
    cacheOverride?: ProjectCache | undefined;
    serviceRoleOverride?: string | undefined;
    privilegedModeOverride?: boolean | undefined;
    buildTimeoutInMinutesOverride?: number | undefined;
    queuedTimeoutInMinutesOverride?: number | undefined;
    encryptionKeyOverride?: string | undefined;
    idempotencyToken?: string | undefined;
    logsConfigOverride?: LogsConfig | undefined;
    registryCredentialOverride?: RegistryCredential | undefined;
    imagePullCredentialsTypeOverride?: ImagePullCredentialsType | undefined;
    buildBatchConfigOverride?: ProjectBuildBatchConfig | undefined;
    debugSessionEnabled?: boolean | undefined;
}
export interface StartBuildBatchOutput {
    buildBatch?: BuildBatch | undefined;
}
export interface StartCommandExecutionInput {
    sandboxId: string;
    command: string | redacted.Redacted<string>;
    type?: CommandType | undefined;
}
export interface StartCommandExecutionOutput {
    commandExecution?: CommandExecution | undefined;
}
export interface StartSandboxInput {
    projectName?: string | undefined;
    idempotencyToken?: string | redacted.Redacted<string> | undefined;
}
export interface StartSandboxOutput {
    sandbox?: Sandbox | undefined;
}
export interface StartSandboxConnectionInput {
    sandboxId: string;
}
export interface SSMSession {
    sessionId?: string | undefined;
    tokenValue?: string | undefined;
    streamUrl?: string | undefined;
}
export interface StartSandboxConnectionOutput {
    ssmSession?: SSMSession | undefined;
}
export interface StopBuildInput {
    id: string;
}
export interface StopBuildOutput {
    build?: Build | undefined;
}
export interface StopBuildBatchInput {
    id: string;
}
export interface StopBuildBatchOutput {
    buildBatch?: BuildBatch | undefined;
}
export interface StopSandboxInput {
    id: string;
}
export interface StopSandboxOutput {
    sandbox?: Sandbox | undefined;
}
export interface UpdateFleetInput {
    arn: string;
    baseCapacity?: number | undefined;
    environmentType?: EnvironmentType | undefined;
    computeType?: ComputeType | undefined;
    computeConfiguration?: ComputeConfiguration | undefined;
    scalingConfiguration?: ScalingConfigurationInput | undefined;
    overflowBehavior?: FleetOverflowBehavior | undefined;
    vpcConfig?: VpcConfig | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    imageId?: string | undefined;
    fleetServiceRole?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface UpdateFleetOutput {
    fleet?: Fleet | undefined;
}
export interface UpdateProjectInput {
    name: string;
    description?: string | undefined;
    source?: ProjectSource | undefined;
    secondarySources?: ProjectSource[] | undefined;
    sourceVersion?: string | undefined;
    secondarySourceVersions?: ProjectSourceVersion[] | undefined;
    artifacts?: ProjectArtifacts | undefined;
    secondaryArtifacts?: ProjectArtifacts[] | undefined;
    cache?: ProjectCache | undefined;
    environment?: ProjectEnvironment | undefined;
    serviceRole?: string | undefined;
    timeoutInMinutes?: number | undefined;
    queuedTimeoutInMinutes?: number | undefined;
    encryptionKey?: string | undefined;
    tags?: Tag[] | undefined;
    vpcConfig?: VpcConfig | undefined;
    badgeEnabled?: boolean | undefined;
    logsConfig?: LogsConfig | undefined;
    fileSystemLocations?: ProjectFileSystemLocation[] | undefined;
    buildBatchConfig?: ProjectBuildBatchConfig | undefined;
    concurrentBuildLimit?: number | undefined;
    autoRetryLimit?: number | undefined;
}
export interface UpdateProjectOutput {
    project?: Project | undefined;
}
export interface UpdateProjectVisibilityInput {
    projectArn: string;
    projectVisibility: ProjectVisibilityType;
    resourceAccessRole?: string | undefined;
}
export interface UpdateProjectVisibilityOutput {
    projectArn?: string | undefined;
    publicProjectAlias?: string | undefined;
    projectVisibility?: ProjectVisibilityType | undefined;
}
export interface UpdateReportGroupInput {
    arn: string;
    exportConfig?: ReportExportConfig | undefined;
    tags?: Tag[] | undefined;
}
export interface UpdateReportGroupOutput {
    reportGroup?: ReportGroup | undefined;
}
export interface UpdateWebhookInput {
    projectName: string;
    branchFilter?: string | undefined;
    rotateSecret?: boolean | undefined;
    filterGroups?: WebhookFilter[][] | undefined;
    buildType?: WebhookBuildType | undefined;
    pullRequestBuildPolicy?: PullRequestBuildPolicy | undefined;
}
export interface UpdateWebhookOutput {
    webhook?: Webhook | undefined;
}
export type BatchDeleteBuildsError = InvalidInputException | CommonErrors;
/**
 * Deletes one or more builds.
 */
export declare const batchDeleteBuilds: API.OperationMethod<BatchDeleteBuildsInput & RegionInput, BatchDeleteBuildsOutput, BatchDeleteBuildsError, Credentials | HttpClient.HttpClient>;
export type BatchGetBuildBatchesError = InvalidInputException | CommonErrors;
/**
 * Retrieves information about one or more batch builds.
 */
export declare const batchGetBuildBatches: API.OperationMethod<BatchGetBuildBatchesInput & RegionInput, BatchGetBuildBatchesOutput, BatchGetBuildBatchesError, Credentials | HttpClient.HttpClient>;
export type BatchGetBuildsError = InvalidInputException | CommonErrors;
/**
 * Gets information about one or more builds.
 */
export declare const batchGetBuilds: API.OperationMethod<BatchGetBuildsInput & RegionInput, BatchGetBuildsOutput, BatchGetBuildsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCommandExecutionsError = InvalidInputException | CommonErrors;
/**
 * Gets information about the command executions.
 */
export declare const batchGetCommandExecutions: API.OperationMethod<BatchGetCommandExecutionsInput & RegionInput, BatchGetCommandExecutionsOutput, BatchGetCommandExecutionsError, Credentials | HttpClient.HttpClient>;
export type BatchGetFleetsError = InvalidInputException | CommonErrors;
/**
 * Gets information about one or more compute fleets.
 */
export declare const batchGetFleets: API.OperationMethod<BatchGetFleetsInput & RegionInput, BatchGetFleetsOutput, BatchGetFleetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetProjectsError = InvalidInputException | CommonErrors;
/**
 * Gets information about one or more build projects.
 */
export declare const batchGetProjects: API.OperationMethod<BatchGetProjectsInput & RegionInput, BatchGetProjectsOutput, BatchGetProjectsError, Credentials | HttpClient.HttpClient>;
export type BatchGetReportGroupsError = InvalidInputException | CommonErrors;
/**
 * Returns an array of report groups.
 */
export declare const batchGetReportGroups: API.OperationMethod<BatchGetReportGroupsInput & RegionInput, BatchGetReportGroupsOutput, BatchGetReportGroupsError, Credentials | HttpClient.HttpClient>;
export type BatchGetReportsError = InvalidInputException | CommonErrors;
/**
 * Returns an array of reports.
 */
export declare const batchGetReports: API.OperationMethod<BatchGetReportsInput & RegionInput, BatchGetReportsOutput, BatchGetReportsError, Credentials | HttpClient.HttpClient>;
export type BatchGetSandboxesError = InvalidInputException | CommonErrors;
/**
 * Gets information about the sandbox status.
 */
export declare const batchGetSandboxes: API.OperationMethod<BatchGetSandboxesInput & RegionInput, BatchGetSandboxesOutput, BatchGetSandboxesError, Credentials | HttpClient.HttpClient>;
export type CreateFleetError = AccountLimitExceededException | InvalidInputException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a compute fleet.
 */
export declare const createFleet: API.OperationMethod<CreateFleetInput & RegionInput, CreateFleetOutput, CreateFleetError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = AccountLimitExceededException | InvalidInputException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a build project.
 */
export declare const createProject: API.OperationMethod<CreateProjectInput & RegionInput, CreateProjectOutput, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateReportGroupError = AccountLimitExceededException | InvalidInputException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a report group. A report group contains a collection of reports.
 */
export declare const createReportGroup: API.OperationMethod<CreateReportGroupInput & RegionInput, CreateReportGroupOutput, CreateReportGroupError, Credentials | HttpClient.HttpClient>;
export type CreateWebhookError = InvalidInputException | OAuthProviderException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * For an existing CodeBuild build project that has its source code stored in a GitHub or
 * Bitbucket repository, enables CodeBuild to start rebuilding the source code every time a
 * code change is pushed to the repository.
 *
 * If you enable webhooks for an CodeBuild project, and the project is used as a build
 * step in CodePipeline, then two identical builds are created for each commit. One build is
 * triggered through webhooks, and one through CodePipeline. Because billing is on a per-build
 * basis, you are billed for both builds. Therefore, if you are using CodePipeline, we
 * recommend that you disable webhooks in CodeBuild. In the CodeBuild console, clear the
 * Webhook box. For more information, see step 5 in Change a Build Project's Settings.
 */
export declare const createWebhook: API.OperationMethod<CreateWebhookInput & RegionInput, CreateWebhookOutput, CreateWebhookError, Credentials | HttpClient.HttpClient>;
export type DeleteBuildBatchError = InvalidInputException | CommonErrors;
/**
 * Deletes a batch build.
 */
export declare const deleteBuildBatch: API.OperationMethod<DeleteBuildBatchInput & RegionInput, DeleteBuildBatchOutput, DeleteBuildBatchError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetError = InvalidInputException | CommonErrors;
/**
 * Deletes a compute fleet. When you delete a compute fleet, its builds are not deleted.
 */
export declare const deleteFleet: API.OperationMethod<DeleteFleetInput & RegionInput, DeleteFleetOutput, DeleteFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = InvalidInputException | CommonErrors;
/**
 * Deletes a build project. When you delete a project, its builds are not deleted.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectInput & RegionInput, DeleteProjectOutput, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteReportError = InvalidInputException | CommonErrors;
/**
 * Deletes a report.
 */
export declare const deleteReport: API.OperationMethod<DeleteReportInput & RegionInput, DeleteReportOutput, DeleteReportError, Credentials | HttpClient.HttpClient>;
export type DeleteReportGroupError = InvalidInputException | CommonErrors;
/**
 * Deletes a report group. Before you delete a report group, you must delete its reports.
 */
export declare const deleteReportGroup: API.OperationMethod<DeleteReportGroupInput & RegionInput, DeleteReportGroupOutput, DeleteReportGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InvalidInputException | CommonErrors;
/**
 * Deletes a resource policy that is identified by its resource ARN.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyInput & RegionInput, DeleteResourcePolicyOutput, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceCredentialsError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a set of GitHub, GitHub Enterprise, or Bitbucket source credentials.
 */
export declare const deleteSourceCredentials: API.OperationMethod<DeleteSourceCredentialsInput & RegionInput, DeleteSourceCredentialsOutput, DeleteSourceCredentialsError, Credentials | HttpClient.HttpClient>;
export type DeleteWebhookError = InvalidInputException | OAuthProviderException | ResourceNotFoundException | CommonErrors;
/**
 * For an existing CodeBuild build project that has its source code stored in a GitHub or
 * Bitbucket repository, stops CodeBuild from rebuilding the source code every time a code
 * change is pushed to the repository.
 */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookInput & RegionInput, DeleteWebhookOutput, DeleteWebhookError, Credentials | HttpClient.HttpClient>;
export type DescribeCodeCoveragesError = InvalidInputException | CommonErrors;
/**
 * Retrieves one or more code coverage reports.
 */
export declare const describeCodeCoverages: API.PaginatedOperationMethod<DescribeCodeCoveragesInput & RegionInput, DescribeCodeCoveragesOutput, DescribeCodeCoveragesError, Credentials | HttpClient.HttpClient, CodeCoverage>;
export type DescribeTestCasesError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of details about test cases for a report.
 */
export declare const describeTestCases: API.PaginatedOperationMethod<DescribeTestCasesInput & RegionInput, DescribeTestCasesOutput, DescribeTestCasesError, Credentials | HttpClient.HttpClient, TestCase>;
export type GetReportGroupTrendError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Analyzes and accumulates test report values for the specified test reports.
 */
export declare const getReportGroupTrend: API.OperationMethod<GetReportGroupTrendInput & RegionInput, GetReportGroupTrendOutput, GetReportGroupTrendError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a resource policy that is identified by its resource ARN.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput & RegionInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ImportSourceCredentialsError = AccountLimitExceededException | InvalidInputException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Imports the source repository credentials for an CodeBuild project that has its
 * source code stored in a GitHub, GitHub Enterprise, GitLab, GitLab Self Managed, or Bitbucket repository.
 */
export declare const importSourceCredentials: API.OperationMethod<ImportSourceCredentialsInput & RegionInput, ImportSourceCredentialsOutput, ImportSourceCredentialsError, Credentials | HttpClient.HttpClient>;
export type InvalidateProjectCacheError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Resets the cache for a project.
 */
export declare const invalidateProjectCache: API.OperationMethod<InvalidateProjectCacheInput & RegionInput, InvalidateProjectCacheOutput, InvalidateProjectCacheError, Credentials | HttpClient.HttpClient>;
export type ListBuildBatchesError = InvalidInputException | CommonErrors;
/**
 * Retrieves the identifiers of your build batches in the current region.
 */
export declare const listBuildBatches: API.PaginatedOperationMethod<ListBuildBatchesInput & RegionInput, ListBuildBatchesOutput, ListBuildBatchesError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListBuildBatchesForProjectError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the identifiers of the build batches for a specific project.
 */
export declare const listBuildBatchesForProject: API.PaginatedOperationMethod<ListBuildBatchesForProjectInput & RegionInput, ListBuildBatchesForProjectOutput, ListBuildBatchesForProjectError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListBuildsError = InvalidInputException | CommonErrors;
/**
 * Gets a list of build IDs, with each build ID representing a single build.
 */
export declare const listBuilds: API.PaginatedOperationMethod<ListBuildsInput & RegionInput, ListBuildsOutput, ListBuildsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListBuildsForProjectError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of build identifiers for the specified build project, with each build
 * identifier representing a single build.
 */
export declare const listBuildsForProject: API.PaginatedOperationMethod<ListBuildsForProjectInput & RegionInput, ListBuildsForProjectOutput, ListBuildsForProjectError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListCommandExecutionsForSandboxError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of command executions for a sandbox.
 */
export declare const listCommandExecutionsForSandbox: API.PaginatedOperationMethod<ListCommandExecutionsForSandboxInput & RegionInput, ListCommandExecutionsForSandboxOutput, ListCommandExecutionsForSandboxError, Credentials | HttpClient.HttpClient, CommandExecution>;
export type ListCuratedEnvironmentImagesError = CommonErrors;
/**
 * Gets information about Docker images that are managed by CodeBuild.
 */
export declare const listCuratedEnvironmentImages: API.OperationMethod<ListCuratedEnvironmentImagesInput & RegionInput, ListCuratedEnvironmentImagesOutput, ListCuratedEnvironmentImagesError, Credentials | HttpClient.HttpClient>;
export type ListFleetsError = InvalidInputException | CommonErrors;
/**
 * Gets a list of compute fleet names with each compute fleet name representing a single compute fleet.
 */
export declare const listFleets: API.PaginatedOperationMethod<ListFleetsInput & RegionInput, ListFleetsOutput, ListFleetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProjectsError = InvalidInputException | CommonErrors;
/**
 * Gets a list of build project names, with each build project name representing a single
 * build project.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsInput & RegionInput, ListProjectsOutput, ListProjectsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListReportGroupsError = InvalidInputException | CommonErrors;
/**
 * Gets a list ARNs for the report groups in the current Amazon Web Services account.
 */
export declare const listReportGroups: API.PaginatedOperationMethod<ListReportGroupsInput & RegionInput, ListReportGroupsOutput, ListReportGroupsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListReportsError = InvalidInputException | CommonErrors;
/**
 * Returns a list of ARNs for the reports in the current Amazon Web Services account.
 */
export declare const listReports: API.PaginatedOperationMethod<ListReportsInput & RegionInput, ListReportsOutput, ListReportsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListReportsForReportGroupError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of ARNs for the reports that belong to a `ReportGroup`.
 */
export declare const listReportsForReportGroup: API.PaginatedOperationMethod<ListReportsForReportGroupInput & RegionInput, ListReportsForReportGroupOutput, ListReportsForReportGroupError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListSandboxesError = InvalidInputException | CommonErrors;
/**
 * Gets a list of sandboxes.
 */
export declare const listSandboxes: API.PaginatedOperationMethod<ListSandboxesInput & RegionInput, ListSandboxesOutput, ListSandboxesError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListSandboxesForProjectError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of sandboxes for a given project.
 */
export declare const listSandboxesForProject: API.PaginatedOperationMethod<ListSandboxesForProjectInput & RegionInput, ListSandboxesForProjectOutput, ListSandboxesForProjectError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListSharedProjectsError = InvalidInputException | CommonErrors;
/**
 * Gets a list of projects that are shared with other Amazon Web Services accounts or users.
 */
export declare const listSharedProjects: API.PaginatedOperationMethod<ListSharedProjectsInput & RegionInput, ListSharedProjectsOutput, ListSharedProjectsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListSharedReportGroupsError = InvalidInputException | CommonErrors;
/**
 * Gets a list of report groups that are shared with other Amazon Web Services accounts or users.
 */
export declare const listSharedReportGroups: API.PaginatedOperationMethod<ListSharedReportGroupsInput & RegionInput, ListSharedReportGroupsOutput, ListSharedReportGroupsError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListSourceCredentialsError = InvalidInputException | CommonErrors;
/**
 * Returns a list of `SourceCredentialsInfo` objects.
 */
export declare const listSourceCredentials: API.OperationMethod<ListSourceCredentialsInput & RegionInput, ListSourceCredentialsOutput, ListSourceCredentialsError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Stores a resource policy for the ARN of a `Project` or
 * `ReportGroup` object.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyInput & RegionInput, PutResourcePolicyOutput, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RetryBuildError = AccountLimitExceededException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Restarts a build.
 */
export declare const retryBuild: API.OperationMethod<RetryBuildInput & RegionInput, RetryBuildOutput, RetryBuildError, Credentials | HttpClient.HttpClient>;
export type RetryBuildBatchError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Restarts a failed batch build. Only batch builds that have failed can be retried.
 */
export declare const retryBuildBatch: API.OperationMethod<RetryBuildBatchInput & RegionInput, RetryBuildBatchOutput, RetryBuildBatchError, Credentials | HttpClient.HttpClient>;
export type StartBuildError = AccountLimitExceededException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Starts running a build with the settings defined in the project. These setting include: how to run a build,
 * where to get the source code, which build environment to use, which build commands to run, and where to store the build output.
 *
 * You can also start a build run by overriding some of the build settings in the project. The overrides only apply for that
 * specific start build request. The settings in the project are unaltered.
 */
export declare const startBuild: API.OperationMethod<StartBuildInput & RegionInput, StartBuildOutput, StartBuildError, Credentials | HttpClient.HttpClient>;
export type StartBuildBatchError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a batch build for a project.
 */
export declare const startBuildBatch: API.OperationMethod<StartBuildBatchInput & RegionInput, StartBuildBatchOutput, StartBuildBatchError, Credentials | HttpClient.HttpClient>;
export type StartCommandExecutionError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a command execution.
 */
export declare const startCommandExecution: API.OperationMethod<StartCommandExecutionInput & RegionInput, StartCommandExecutionOutput, StartCommandExecutionError, Credentials | HttpClient.HttpClient>;
export type StartSandboxError = AccountSuspendedException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a sandbox.
 */
export declare const startSandbox: API.OperationMethod<StartSandboxInput & RegionInput, StartSandboxOutput, StartSandboxError, Credentials | HttpClient.HttpClient>;
export type StartSandboxConnectionError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a sandbox connection.
 */
export declare const startSandboxConnection: API.OperationMethod<StartSandboxConnectionInput & RegionInput, StartSandboxConnectionOutput, StartSandboxConnectionError, Credentials | HttpClient.HttpClient>;
export type StopBuildError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Attempts to stop running a build.
 */
export declare const stopBuild: API.OperationMethod<StopBuildInput & RegionInput, StopBuildOutput, StopBuildError, Credentials | HttpClient.HttpClient>;
export type StopBuildBatchError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a running batch build.
 */
export declare const stopBuildBatch: API.OperationMethod<StopBuildBatchInput & RegionInput, StopBuildBatchOutput, StopBuildBatchError, Credentials | HttpClient.HttpClient>;
export type StopSandboxError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a sandbox.
 */
export declare const stopSandbox: API.OperationMethod<StopSandboxInput & RegionInput, StopSandboxOutput, StopSandboxError, Credentials | HttpClient.HttpClient>;
export type UpdateFleetError = AccountLimitExceededException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a compute fleet.
 */
export declare const updateFleet: API.OperationMethod<UpdateFleetInput & RegionInput, UpdateFleetOutput, UpdateFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Changes the settings of a build project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectInput & RegionInput, UpdateProjectOutput, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectVisibilityError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Changes the public visibility for a project. The project's build results, logs, and
 * artifacts are available to the general public. For more information, see Public build
 * projects in the *CodeBuild User Guide*.
 *
 * The following should be kept in mind when making your projects public:
 *
 * - All of a project's build results, logs, and artifacts, including builds that were run
 * when the project was private, are available to the general public.
 *
 * - All build logs and artifacts are available to the public. Environment variables, source
 * code, and other sensitive information may have been output to the build logs and artifacts.
 * You must be careful about what information is output to the build logs. Some best practice
 * are:
 *
 * - Do not store sensitive values in environment variables. We recommend that you use an Amazon EC2 Systems Manager Parameter Store
 * or Secrets Manager to store sensitive values.
 *
 * - Follow Best
 * practices for using webhooks in the CodeBuild User
 * Guide to limit which entities can trigger a build, and do
 * not store the buildspec in the project itself, to ensure that your webhooks are as
 * secure as possible.
 *
 * - A malicious user can use public builds to distribute malicious artifacts. We recommend
 * that you review all pull requests to verify that the pull request is a legitimate change. We
 * also recommend that you validate any artifacts with their checksums to make sure that the
 * correct artifacts are being downloaded.
 */
export declare const updateProjectVisibility: API.OperationMethod<UpdateProjectVisibilityInput & RegionInput, UpdateProjectVisibilityOutput, UpdateProjectVisibilityError, Credentials | HttpClient.HttpClient>;
export type UpdateReportGroupError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a report group.
 */
export declare const updateReportGroup: API.OperationMethod<UpdateReportGroupInput & RegionInput, UpdateReportGroupOutput, UpdateReportGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateWebhookError = InvalidInputException | OAuthProviderException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the webhook associated with an CodeBuild build project.
 *
 * If you use Bitbucket for your repository, `rotateSecret` is ignored.
 */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookInput & RegionInput, UpdateWebhookOutput, UpdateWebhookError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codebuild.d.ts.map