import * as durableObjects from "@distilled.cloud/cloudflare/durable-objects";
import * as secretsStore from "@distilled.cloud/cloudflare/secrets-store";
import * as workers from "@distilled.cloud/cloudflare/workers";
import * as zones from "@distilled.cloud/cloudflare/zones";
import { StateStoreError } from "alchemy/State/State";
import * as Effect from "effect/Effect";
import type { WorkerObservability } from "../Workers/Worker.ts";
/**
 * Deploy a Cloudflare State Store Worker with direct API calls.
 *
 * Every step is idempotent and only ever adds what is missing: the account's
 * Secrets Store and the two state-store secrets are created when absent and
 * never updated or deleted, so redeploying cannot rotate the auth token or
 * lose the encryption key. The Worker itself is re-uploaded on every call
 * with the same `Store` Durable Object class, keeping its stored state.
 *
 * With a `domain`, the Worker is also attached to that hostname as a custom
 * domain and served there.
 *
 * Returns the Worker's URL, and the auth token when this call created it
 * (an existing token can only be read back through a Worker binding).
 */
export declare const deployStateStoreWorker: (args_0: {
    accountId: string;
    scriptName: string;
    domain: string | undefined;
    observability?: WorkerObservability;
}) => Effect.Effect<{
    url: string;
    authToken: string | undefined;
}, import("@distilled.cloud/iceberg").BadGateway | import("alchemy/Bundle/Bundle").BundleError | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | workers.D1DatabaseNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").D1DatabaseNotFound | workers.DispatchNamespaceNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").DispatchNamespaceNotFound | workers.DuplicateMigrationTarget | workers.DurableObjectClassNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").DurableObjectClassNotFound | workers.DurableObjectMustBeSqlite | import("@distilled.cloud/iceberg").Forbidden | workers.Forbidden | import("@distilled.cloud/cloudflare/workers-for-platforms").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | workers.HostnameAlreadyInUse | import("effect/http/HttpClientError").HttpClientError | workers.HyperdriveConfigNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").HyperdriveConfigNotFound | import("@distilled.cloud/iceberg").InternalServerError | secretsStore.InvalidAccountId | durableObjects.InvalidIdentifier | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | workers.InvalidRoute | workers.InvalidWorkerScript | zones.InvalidZoneIdentifier | workers.KVNamespaceNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").KVNamespaceNotFound | workers.MtlsCertificateNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").MtlsCertificateNotFound | secretsStore.NotFound | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | workers.QueueNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").QueueNotFound | workers.R2BucketNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").R2BucketNotFound | workers.ScriptModuleNotFound | workers.ScriptStartupError | import("@distilled.cloud/core/sdk-error").SdkError | secretsStore.SecretNameEmpty | secretsStore.SecretScopeInvalid | workers.SecretsStoreBindingNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").SecretsStoreBindingNotFound | workers.ServiceBindingNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").ServiceBindingNotFound | import("@distilled.cloud/iceberg").ServiceUnavailable | StateStoreError | secretsStore.StoreNotFound | workers.SubdomainNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError | workers.UnknownWorkerEntrypoint | import("@distilled.cloud/cloudflare/workers-for-platforms").UnknownWorkerEntrypoint | workers.VectorizeIndexNotFound | import("@distilled.cloud/cloudflare/workers-for-platforms").VectorizeIndexNotFound | workers.WorkerNotFound, import("effect/FileSystem").FileSystem | import("effect/Path").Path | durableObjects.CloudflareOpContext>;
/**
 * A store's Worker name: lowercase letters, digits, `-` and `_`, starting with
 * a letter or digit, at most 54 characters. The store enables workers.dev
 * previews, and Cloudflare rejects a longer script name with previews enabled
 * (the preview hostname prefixes it); the cap also keeps its secret names well
 * under the Secrets Store's 255.
 */
export declare const validateStateStoreWorkerName: (scriptName: string) => Effect.Effect<string, never, never> | Effect.Effect<never, StateStoreError, never>;
/**
 * Another Worker whose store's secrets have the same names as this store's.
 * Secret names replace every character other than a letter, digit or `_` with
 * `_`, so the stores `team-a` and `team_a` would share one token and key.
 */
export declare const findSecretSharingWorker: (args_0: {
    accountId: string;
    scriptName: string;
}) => Effect.Effect<string | undefined, workers.ListScriptsError, durableObjects.CloudflareOpContext>;
/**
 * The store's version as Cloudflare's API reports it, `undefined` when it has
 * no Worker, or `"unrecorded"` for a Worker an older Alchemy deployed without
 * recording it. The edge can keep serving a deleted or replaced Worker for a
 * while, so decisions use this rather than what `/version` answers.
 */
export declare const observeDeployedVersion: (args_0: {
    accountId: string;
    scriptName: string;
}) => Effect.Effect<number | "unrecorded" | undefined, durableObjects.CloudflareOpError, durableObjects.CloudflareOpContext>;
/** The origin a store serves on: its custom domain, or its workers.dev URL. */
export declare const stateStoreUrl: (args_0: {
    accountId: string;
    scriptName: string;
    domain: string | undefined;
}) => Effect.Effect<string, workers.GetSubdomainError, durableObjects.CloudflareOpContext>;
/**
 * The zone of the custom domain `domain` when it is attached to this Worker,
 * or `undefined`. Fails when another Worker owns the hostname.
 */
export declare const observeStateStoreDomain: (args_0: {
    accountId: string;
    scriptName: string;
    domain: string;
}) => Effect.Effect<string | undefined, StateStoreError | workers.ListDomainsError, durableObjects.CloudflareOpContext>;
/** Whether the store's auth token and encryption key both exist. */
export declare const stateStoreSecretsExist: (args_0: {
    accountId: string;
    scriptName: string;
}) => Effect.Effect<boolean, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | secretsStore.InvalidAccountId | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | secretsStore.StoreNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, durableObjects.CloudflareOpContext>;
/**
 * Whether a store that may hold state has lost its encryption key: its Worker
 * exists, so it served state encrypted with a key, but the key is gone. A
 * listing can lag a create, so the key must be missing from several reads.
 */
export declare const encryptionKeyLost: (args_0: {
    accountId: string;
    scriptName: string;
}) => Effect.Effect<boolean, import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("@distilled.cloud/iceberg").ConfigError | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | secretsStore.InvalidAccountId | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | secretsStore.StoreNotFound | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, durableObjects.CloudflareOpContext>;
//# sourceMappingURL=Deploy.d.ts.map