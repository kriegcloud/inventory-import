import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ActionExecutionNotFoundException_base: S.TaggedErrorClass<"ActionExecutionNotFoundException", {
    readonly message: any;
}>;
export declare class ActionExecutionNotFoundException extends /*@__PURE__*/ ActionExecutionNotFoundException_base {
}
declare const ActionNotFoundException_base: S.TaggedErrorClass<"ActionNotFoundException", {
    readonly message: any;
}>;
export declare class ActionNotFoundException extends /*@__PURE__*/ ActionNotFoundException_base {
}
declare const ActionTypeNotFoundException_base: S.TaggedErrorClass<"ActionTypeNotFoundException", {
    readonly message: any;
}>;
export declare class ActionTypeNotFoundException extends /*@__PURE__*/ ActionTypeNotFoundException_base {
}
declare const ApprovalAlreadyCompletedException_base: S.TaggedErrorClass<"ApprovalAlreadyCompletedException", {
    readonly message: any;
}>;
export declare class ApprovalAlreadyCompletedException extends /*@__PURE__*/ ApprovalAlreadyCompletedException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConcurrentPipelineExecutionsLimitExceededException_base: S.TaggedErrorClass<"ConcurrentPipelineExecutionsLimitExceededException", {
    readonly message: any;
}>;
export declare class ConcurrentPipelineExecutionsLimitExceededException extends /*@__PURE__*/ ConcurrentPipelineExecutionsLimitExceededException_base {
}
declare const ConditionNotOverridableException_base: S.TaggedErrorClass<"ConditionNotOverridableException", {
    readonly message: any;
}>;
export declare class ConditionNotOverridableException extends /*@__PURE__*/ ConditionNotOverridableException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DuplicatedStopRequestException_base: S.TaggedErrorClass<"DuplicatedStopRequestException", {
    readonly message: any;
}>;
export declare class DuplicatedStopRequestException extends /*@__PURE__*/ DuplicatedStopRequestException_base {
}
declare const InvalidActionDeclarationException_base: S.TaggedErrorClass<"InvalidActionDeclarationException", {
    readonly message: any;
}>;
export declare class InvalidActionDeclarationException extends /*@__PURE__*/ InvalidActionDeclarationException_base {
}
declare const InvalidApprovalTokenException_base: S.TaggedErrorClass<"InvalidApprovalTokenException", {
    readonly message: any;
}>;
export declare class InvalidApprovalTokenException extends /*@__PURE__*/ InvalidApprovalTokenException_base {
}
declare const InvalidArnException_base: S.TaggedErrorClass<"InvalidArnException", {
    readonly message: any;
}>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidBlockerDeclarationException_base: S.TaggedErrorClass<"InvalidBlockerDeclarationException", {
    readonly message: any;
}>;
export declare class InvalidBlockerDeclarationException extends /*@__PURE__*/ InvalidBlockerDeclarationException_base {
}
declare const InvalidClientTokenException_base: S.TaggedErrorClass<"InvalidClientTokenException", {
    readonly message: any;
}>;
export declare class InvalidClientTokenException extends /*@__PURE__*/ InvalidClientTokenException_base {
}
declare const InvalidJobException_base: S.TaggedErrorClass<"InvalidJobException", {
    readonly message: any;
}>;
export declare class InvalidJobException extends /*@__PURE__*/ InvalidJobException_base {
}
declare const InvalidJobStateException_base: S.TaggedErrorClass<"InvalidJobStateException", {
    readonly message: any;
}>;
export declare class InvalidJobStateException extends /*@__PURE__*/ InvalidJobStateException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidNonceException_base: S.TaggedErrorClass<"InvalidNonceException", {
    readonly message: any;
}>;
export declare class InvalidNonceException extends /*@__PURE__*/ InvalidNonceException_base {
}
declare const InvalidStageDeclarationException_base: S.TaggedErrorClass<"InvalidStageDeclarationException", {
    readonly message: any;
}>;
export declare class InvalidStageDeclarationException extends /*@__PURE__*/ InvalidStageDeclarationException_base {
}
declare const InvalidStructureException_base: S.TaggedErrorClass<"InvalidStructureException", {
    readonly message: any;
}>;
export declare class InvalidStructureException extends /*@__PURE__*/ InvalidStructureException_base {
}
declare const InvalidTagsException_base: S.TaggedErrorClass<"InvalidTagsException", {
    readonly message: any;
}>;
export declare class InvalidTagsException extends /*@__PURE__*/ InvalidTagsException_base {
}
declare const InvalidWebhookAuthenticationParametersException_base: S.TaggedErrorClass<"InvalidWebhookAuthenticationParametersException", {
    readonly message: any;
}>;
export declare class InvalidWebhookAuthenticationParametersException extends /*@__PURE__*/ InvalidWebhookAuthenticationParametersException_base {
}
declare const InvalidWebhookFilterPatternException_base: S.TaggedErrorClass<"InvalidWebhookFilterPatternException", {
    readonly message: any;
}>;
export declare class InvalidWebhookFilterPatternException extends /*@__PURE__*/ InvalidWebhookFilterPatternException_base {
}
declare const JobNotFoundException_base: S.TaggedErrorClass<"JobNotFoundException", {
    readonly message: any;
}>;
export declare class JobNotFoundException extends /*@__PURE__*/ JobNotFoundException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotLatestPipelineExecutionException_base: S.TaggedErrorClass<"NotLatestPipelineExecutionException", {
    readonly message: any;
}>;
export declare class NotLatestPipelineExecutionException extends /*@__PURE__*/ NotLatestPipelineExecutionException_base {
}
declare const OutputVariablesSizeExceededException_base: S.TaggedErrorClass<"OutputVariablesSizeExceededException", {
    readonly message: any;
}>;
export declare class OutputVariablesSizeExceededException extends /*@__PURE__*/ OutputVariablesSizeExceededException_base {
}
declare const PipelineExecutionNotFoundException_base: S.TaggedErrorClass<"PipelineExecutionNotFoundException", {
    readonly message: any;
}>;
export declare class PipelineExecutionNotFoundException extends /*@__PURE__*/ PipelineExecutionNotFoundException_base {
}
declare const PipelineExecutionNotStoppableException_base: S.TaggedErrorClass<"PipelineExecutionNotStoppableException", {
    readonly message: any;
}>;
export declare class PipelineExecutionNotStoppableException extends /*@__PURE__*/ PipelineExecutionNotStoppableException_base {
}
declare const PipelineExecutionOutdatedException_base: S.TaggedErrorClass<"PipelineExecutionOutdatedException", {
    readonly message: any;
}>;
export declare class PipelineExecutionOutdatedException extends /*@__PURE__*/ PipelineExecutionOutdatedException_base {
}
declare const PipelineNameInUseException_base: S.TaggedErrorClass<"PipelineNameInUseException", {
    readonly message: any;
}>;
export declare class PipelineNameInUseException extends /*@__PURE__*/ PipelineNameInUseException_base {
}
declare const PipelineNotFoundException_base: S.TaggedErrorClass<"PipelineNotFoundException", {
    readonly message: any;
}>;
export declare class PipelineNotFoundException extends /*@__PURE__*/ PipelineNotFoundException_base {
}
declare const PipelineVersionNotFoundException_base: S.TaggedErrorClass<"PipelineVersionNotFoundException", {
    readonly message: any;
}>;
export declare class PipelineVersionNotFoundException extends /*@__PURE__*/ PipelineVersionNotFoundException_base {
}
declare const RequestFailedException_base: S.TaggedErrorClass<"RequestFailedException", {
    readonly message: any;
}>;
export declare class RequestFailedException extends /*@__PURE__*/ RequestFailedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const StageNotFoundException_base: S.TaggedErrorClass<"StageNotFoundException", {
    readonly message: any;
}>;
export declare class StageNotFoundException extends /*@__PURE__*/ StageNotFoundException_base {
}
declare const StageNotRetryableException_base: S.TaggedErrorClass<"StageNotRetryableException", {
    readonly message: any;
}>;
export declare class StageNotRetryableException extends /*@__PURE__*/ StageNotRetryableException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToRollbackStageException_base: S.TaggedErrorClass<"UnableToRollbackStageException", {
    readonly message: any;
}>;
export declare class UnableToRollbackStageException extends /*@__PURE__*/ UnableToRollbackStageException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const WebhookNotFoundException_base: S.TaggedErrorClass<"WebhookNotFoundException", {
    readonly message: any;
}>;
export declare class WebhookNotFoundException extends /*@__PURE__*/ WebhookNotFoundException_base {
}
export type JobId = string;
export type Nonce = string;
export interface AcknowledgeJobInput {
    jobId: string;
    nonce: string;
}
export type JobStatus = "Created" | "Queued" | "Dispatched" | "InProgress" | "TimedOut" | "Succeeded" | "Failed" | (string & {});
export interface AcknowledgeJobOutput {
    status?: JobStatus | undefined;
}
export type ThirdPartyJobId = string;
export type ClientToken = string;
export interface AcknowledgeThirdPartyJobInput {
    jobId: string;
    nonce: string;
    clientToken: string;
}
export interface AcknowledgeThirdPartyJobOutput {
    status?: JobStatus | undefined;
}
export type ActionCategory = "Source" | "Build" | "Deploy" | "Test" | "Invoke" | "Approval" | "Compute" | (string & {});
export type ActionProvider = string;
export type Version = string;
export type Url = string;
export type UrlTemplate = string;
export interface ActionTypeSettings {
    thirdPartyConfigurationUrl?: string | undefined;
    entityUrlTemplate?: string | undefined;
    executionUrlTemplate?: string | undefined;
    revisionUrlTemplate?: string | undefined;
}
export type ActionConfigurationKey = string;
export type Description = string;
export type ActionConfigurationPropertyType = "String" | "Number" | "Boolean" | (string & {});
export interface ActionConfigurationProperty {
    name: string;
    required: boolean;
    key: boolean;
    secret: boolean;
    queryable?: boolean | undefined;
    description?: string | undefined;
    type?: ActionConfigurationPropertyType | undefined;
}
export type ActionConfigurationPropertyList = ActionConfigurationProperty[];
export type MinimumArtifactCount = number;
export type MaximumArtifactCount = number;
export interface ArtifactDetails {
    minimumCount: number;
    maximumCount: number;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateCustomActionTypeInput {
    category: ActionCategory;
    provider: string;
    version: string;
    settings?: ActionTypeSettings | undefined;
    configurationProperties?: ActionConfigurationProperty[] | undefined;
    inputArtifactDetails: ArtifactDetails;
    outputArtifactDetails: ArtifactDetails;
    tags?: Tag[] | undefined;
}
export type ActionOwner = "AWS" | "ThirdParty" | "Custom" | (string & {});
export interface ActionTypeId {
    category: ActionCategory;
    owner: ActionOwner;
    provider: string;
    version: string;
}
export interface ActionType {
    id: ActionTypeId;
    settings?: ActionTypeSettings | undefined;
    actionConfigurationProperties?: ActionConfigurationProperty[] | undefined;
    inputArtifactDetails: ArtifactDetails;
    outputArtifactDetails: ArtifactDetails;
}
export interface CreateCustomActionTypeOutput {
    actionType: ActionType;
    tags?: Tag[] | undefined;
}
export type PipelineName = string;
export type RoleArn = string;
export type ArtifactStoreType = "S3" | (string & {});
export type ArtifactStoreLocation = string;
export type EncryptionKeyId = string;
export type EncryptionKeyType = "KMS" | (string & {});
export interface EncryptionKey {
    id: string;
    type: EncryptionKeyType;
}
export interface ArtifactStore {
    type: ArtifactStoreType;
    location: string;
    encryptionKey?: EncryptionKey | undefined;
}
export type AWSRegionName = string;
export type ArtifactStoreMap = {
    [key: string]: ArtifactStore | undefined;
};
export type StageName = string;
export type BlockerName = string;
export type BlockerType = "Schedule" | (string & {});
export interface BlockerDeclaration {
    name: string;
    type: BlockerType;
}
export type StageBlockerDeclarationList = BlockerDeclaration[];
export type ActionName = string;
export type ActionRunOrder = number;
export type ActionConfigurationValue = string;
export type ActionConfigurationMap = {
    [key: string]: string | undefined;
};
export type Command = string;
export type CommandList = string[];
export type ArtifactName = string;
export type FilePath = string;
export type FilePathList = string[];
export interface OutputArtifact {
    name: string;
    files?: string[] | undefined;
}
export type OutputArtifactList = OutputArtifact[];
export interface InputArtifact {
    name: string;
}
export type InputArtifactList = InputArtifact[];
export type OutputVariable = string;
export type OutputVariableList = string[];
export type ActionNamespace = string;
export type ActionTimeout = number;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariableType = "PLAINTEXT" | "SECRETS_MANAGER" | (string & {});
export interface EnvironmentVariable {
    name: string;
    value: string;
    type?: EnvironmentVariableType | undefined;
}
export type EnvironmentVariableList = EnvironmentVariable[];
export interface ActionDeclaration {
    name: string;
    actionTypeId: ActionTypeId;
    runOrder?: number | undefined;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    commands?: string[] | undefined;
    outputArtifacts?: OutputArtifact[] | undefined;
    inputArtifacts?: InputArtifact[] | undefined;
    outputVariables?: string[] | undefined;
    roleArn?: string | undefined;
    region?: string | undefined;
    namespace?: string | undefined;
    timeoutInMinutes?: number | undefined;
    environmentVariables?: EnvironmentVariable[] | undefined;
}
export type StageActionDeclarationList = ActionDeclaration[];
export type Result = "ROLLBACK" | "FAIL" | "RETRY" | "SKIP" | (string & {});
export type StageRetryMode = "FAILED_ACTIONS" | "ALL_ACTIONS" | (string & {});
export interface RetryConfiguration {
    retryMode?: StageRetryMode | undefined;
}
export type RuleName = string;
export type RuleCategory = "Rule" | (string & {});
export type RuleOwner = "AWS" | (string & {});
export type RuleProvider = string;
export interface RuleTypeId {
    category: RuleCategory;
    owner?: RuleOwner | undefined;
    provider: string;
    version?: string | undefined;
}
export type RuleConfigurationKey = string;
export type RuleConfigurationValue = string;
export type RuleConfigurationMap = {
    [key: string]: string | undefined;
};
export type RuleTimeout = number;
export interface RuleDeclaration {
    name: string;
    ruleTypeId: RuleTypeId;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    commands?: string[] | undefined;
    inputArtifacts?: InputArtifact[] | undefined;
    roleArn?: string | undefined;
    region?: string | undefined;
    timeoutInMinutes?: number | undefined;
}
export type RuleDeclarationList = RuleDeclaration[];
export interface Condition {
    result?: Result | undefined;
    rules?: RuleDeclaration[] | undefined;
}
export type ConditionList = Condition[];
export interface FailureConditions {
    result?: Result | undefined;
    retryConfiguration?: RetryConfiguration | undefined;
    conditions?: Condition[] | undefined;
}
export interface SuccessConditions {
    conditions: Condition[];
}
export interface BeforeEntryConditions {
    conditions: Condition[];
}
export interface StageDeclaration {
    name: string;
    blockers?: BlockerDeclaration[] | undefined;
    actions: ActionDeclaration[];
    onFailure?: FailureConditions | undefined;
    onSuccess?: SuccessConditions | undefined;
    beforeEntry?: BeforeEntryConditions | undefined;
}
export type PipelineStageDeclarationList = StageDeclaration[];
export type PipelineVersion = number;
export type ExecutionMode = "QUEUED" | "SUPERSEDED" | "PARALLEL" | (string & {});
export type PipelineType = "V1" | "V2" | (string & {});
export type PipelineVariableName = string;
export type PipelineVariableValue = string;
export type PipelineVariableDescription = string;
export interface PipelineVariableDeclaration {
    name: string;
    defaultValue?: string | undefined;
    description?: string | undefined;
}
export type PipelineVariableDeclarationList = PipelineVariableDeclaration[];
export type PipelineTriggerProviderType = "CodeStarSourceConnection" | (string & {});
export type GitTagNamePattern = string;
export type GitTagPatternList = string[];
export interface GitTagFilterCriteria {
    includes?: string[] | undefined;
    excludes?: string[] | undefined;
}
export type GitBranchNamePattern = string;
export type GitBranchPatternList = string[];
export interface GitBranchFilterCriteria {
    includes?: string[] | undefined;
    excludes?: string[] | undefined;
}
export type GitFilePathPattern = string;
export type GitFilePathPatternList = string[];
export interface GitFilePathFilterCriteria {
    includes?: string[] | undefined;
    excludes?: string[] | undefined;
}
export interface GitPushFilter {
    tags?: GitTagFilterCriteria | undefined;
    branches?: GitBranchFilterCriteria | undefined;
    filePaths?: GitFilePathFilterCriteria | undefined;
}
export type GitPushFilterList = GitPushFilter[];
export type GitPullRequestEventType = "OPEN" | "UPDATED" | "CLOSED" | (string & {});
export type GitPullRequestEventTypeList = GitPullRequestEventType[];
export interface GitPullRequestFilter {
    events?: GitPullRequestEventType[] | undefined;
    branches?: GitBranchFilterCriteria | undefined;
    filePaths?: GitFilePathFilterCriteria | undefined;
}
export type GitPullRequestFilterList = GitPullRequestFilter[];
export interface GitConfiguration {
    sourceActionName: string;
    push?: GitPushFilter[] | undefined;
    pullRequest?: GitPullRequestFilter[] | undefined;
}
export interface PipelineTriggerDeclaration {
    providerType: PipelineTriggerProviderType;
    gitConfiguration: GitConfiguration;
}
export type PipelineTriggerDeclarationList = PipelineTriggerDeclaration[];
export interface PipelineDeclaration {
    name: string;
    roleArn: string;
    artifactStore?: ArtifactStore | undefined;
    artifactStores?: {
        [key: string]: ArtifactStore | undefined;
    } | undefined;
    stages: StageDeclaration[];
    version?: number | undefined;
    executionMode?: ExecutionMode | undefined;
    pipelineType?: PipelineType | undefined;
    variables?: PipelineVariableDeclaration[] | undefined;
    triggers?: PipelineTriggerDeclaration[] | undefined;
}
export interface CreatePipelineInput {
    pipeline: PipelineDeclaration;
    tags?: Tag[] | undefined;
}
export interface CreatePipelineOutput {
    pipeline?: PipelineDeclaration | undefined;
    tags?: Tag[] | undefined;
}
export interface DeleteCustomActionTypeInput {
    category: ActionCategory;
    provider: string;
    version: string;
}
export interface DeleteCustomActionTypeResponse {
}
export interface DeletePipelineInput {
    name: string;
}
export interface DeletePipelineResponse {
}
export type WebhookName = string;
export interface DeleteWebhookInput {
    name: string;
}
export interface DeleteWebhookOutput {
}
export interface DeregisterWebhookWithThirdPartyInput {
    webhookName?: string | undefined;
}
export interface DeregisterWebhookWithThirdPartyOutput {
}
export type StageTransitionType = "Inbound" | "Outbound" | (string & {});
export type DisabledReason = string;
export interface DisableStageTransitionInput {
    pipelineName: string;
    stageName: string;
    transitionType: StageTransitionType;
    reason: string;
}
export interface DisableStageTransitionResponse {
}
export interface EnableStageTransitionInput {
    pipelineName: string;
    stageName: string;
    transitionType: StageTransitionType;
}
export interface EnableStageTransitionResponse {
}
export type ActionTypeOwner = string;
export interface GetActionTypeInput {
    category: ActionCategory;
    owner: string;
    provider: string;
    version: string;
}
export type ActionTypeDescription = string;
export type LambdaFunctionArn = string;
export interface LambdaExecutorConfiguration {
    lambdaFunctionArn: string;
}
export type AccountId = string;
export type PollingAccountList = string[];
export type ServicePrincipal = string;
export type PollingServicePrincipalList = string[];
export interface JobWorkerExecutorConfiguration {
    pollingAccounts?: string[] | undefined;
    pollingServicePrincipals?: string[] | undefined;
}
export interface ExecutorConfiguration {
    lambdaExecutorConfiguration?: LambdaExecutorConfiguration | undefined;
    jobWorkerExecutorConfiguration?: JobWorkerExecutorConfiguration | undefined;
}
export type ExecutorType = "JobWorker" | "Lambda" | (string & {});
export type PolicyStatementsTemplate = string;
export type JobTimeout = number;
export interface ActionTypeExecutor {
    configuration: ExecutorConfiguration;
    type: ExecutorType;
    policyStatementsTemplate?: string | undefined;
    jobTimeout?: number | undefined;
}
export interface ActionTypeIdentifier {
    category: ActionCategory;
    owner: string;
    provider: string;
    version: string;
}
export type MinimumActionTypeArtifactCount = number;
export type MaximumActionTypeArtifactCount = number;
export interface ActionTypeArtifactDetails {
    minimumCount: number;
    maximumCount: number;
}
export type AllowedAccount = string;
export type AllowedAccounts = string[];
export interface ActionTypePermissions {
    allowedAccounts: string[];
}
export type PropertyDescription = string;
export interface ActionTypeProperty {
    name: string;
    optional: boolean;
    key: boolean;
    noEcho: boolean;
    queryable?: boolean | undefined;
    description?: string | undefined;
}
export type ActionTypeProperties = ActionTypeProperty[];
export interface ActionTypeUrls {
    configurationUrl?: string | undefined;
    entityUrlTemplate?: string | undefined;
    executionUrlTemplate?: string | undefined;
    revisionUrlTemplate?: string | undefined;
}
export interface ActionTypeDeclaration {
    description?: string | undefined;
    executor: ActionTypeExecutor;
    id: ActionTypeIdentifier;
    inputArtifactDetails: ActionTypeArtifactDetails;
    outputArtifactDetails: ActionTypeArtifactDetails;
    permissions?: ActionTypePermissions | undefined;
    properties?: ActionTypeProperty[] | undefined;
    urls?: ActionTypeUrls | undefined;
}
export interface GetActionTypeOutput {
    actionType?: ActionTypeDeclaration | undefined;
}
export interface GetJobDetailsInput {
    jobId: string;
}
export interface ActionConfiguration {
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StageContext {
    name?: string | undefined;
}
export type ActionExecutionId = string;
export interface ActionContext {
    name?: string | undefined;
    actionExecutionId?: string | undefined;
}
export type PipelineArn = string;
export type PipelineExecutionId = string;
export interface PipelineContext {
    pipelineName?: string | undefined;
    stage?: StageContext | undefined;
    action?: ActionContext | undefined;
    pipelineArn?: string | undefined;
    pipelineExecutionId?: string | undefined;
}
export type Revision = string;
export type ArtifactLocationType = "S3" | (string & {});
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3ArtifactLocation {
    bucketName: string;
    objectKey: string;
}
export interface ArtifactLocation {
    type?: ArtifactLocationType | undefined;
    s3Location?: S3ArtifactLocation | undefined;
}
export interface Artifact {
    name?: string | undefined;
    revision?: string | undefined;
    location?: ArtifactLocation | undefined;
}
export type ArtifactList = Artifact[];
export type AccessKeyId = string | redacted.Redacted<string>;
export type SecretAccessKey = string | redacted.Redacted<string>;
export type SessionToken = string | redacted.Redacted<string>;
export interface AWSSessionCredentials {
    accessKeyId: string | redacted.Redacted<string>;
    secretAccessKey: string | redacted.Redacted<string>;
    sessionToken: string | redacted.Redacted<string>;
}
export type ContinuationToken = string;
export interface JobData {
    actionTypeId?: ActionTypeId | undefined;
    actionConfiguration?: ActionConfiguration | undefined;
    pipelineContext?: PipelineContext | undefined;
    inputArtifacts?: Artifact[] | undefined;
    outputArtifacts?: Artifact[] | undefined;
    artifactCredentials?: AWSSessionCredentials | undefined;
    continuationToken?: string | undefined;
    encryptionKey?: EncryptionKey | undefined;
}
export interface JobDetails {
    id?: string | undefined;
    data?: JobData | undefined;
    accountId?: string | undefined;
}
export interface GetJobDetailsOutput {
    jobDetails?: JobDetails | undefined;
}
export interface GetPipelineInput {
    name: string;
    version?: number | undefined;
}
export interface PipelineMetadata {
    pipelineArn?: string | undefined;
    created?: Date | undefined;
    updated?: Date | undefined;
    pollingDisabledAt?: Date | undefined;
}
export interface GetPipelineOutput {
    pipeline?: PipelineDeclaration | undefined;
    metadata?: PipelineMetadata | undefined;
}
export interface GetPipelineExecutionInput {
    pipelineName: string;
    pipelineExecutionId: string;
}
export type PipelineExecutionStatus = "Cancelled" | "InProgress" | "Stopped" | "Stopping" | "Succeeded" | "Superseded" | "Failed" | (string & {});
export type PipelineExecutionStatusSummary = string;
export type RevisionChangeIdentifier = string;
export type RevisionSummary = string;
export interface ArtifactRevision {
    name?: string | undefined;
    revisionId?: string | undefined;
    revisionChangeIdentifier?: string | undefined;
    revisionSummary?: string | undefined;
    created?: Date | undefined;
    revisionUrl?: string | undefined;
}
export type ArtifactRevisionList = ArtifactRevision[];
export interface ResolvedPipelineVariable {
    name?: string | undefined;
    resolvedValue?: string | undefined;
}
export type ResolvedPipelineVariableList = ResolvedPipelineVariable[];
export type TriggerType = "CreatePipeline" | "StartPipelineExecution" | "PollForSourceChanges" | "Webhook" | "CloudWatchEvent" | "PutActionRevision" | "WebhookV2" | "ManualRollback" | "AutomatedRollback" | (string & {});
export type TriggerDetail = string;
export interface ExecutionTrigger {
    triggerType?: TriggerType | undefined;
    triggerDetail?: string | undefined;
}
export type ExecutionType = "STANDARD" | "ROLLBACK" | (string & {});
export interface PipelineRollbackMetadata {
    rollbackTargetPipelineExecutionId?: string | undefined;
}
export interface PipelineExecution {
    pipelineName?: string | undefined;
    pipelineVersion?: number | undefined;
    pipelineExecutionId?: string | undefined;
    status?: PipelineExecutionStatus | undefined;
    statusSummary?: string | undefined;
    artifactRevisions?: ArtifactRevision[] | undefined;
    variables?: ResolvedPipelineVariable[] | undefined;
    trigger?: ExecutionTrigger | undefined;
    executionMode?: ExecutionMode | undefined;
    executionType?: ExecutionType | undefined;
    rollbackMetadata?: PipelineRollbackMetadata | undefined;
}
export interface GetPipelineExecutionOutput {
    pipelineExecution?: PipelineExecution | undefined;
}
export interface GetPipelineStateInput {
    name: string;
}
export type StageExecutionStatus = "Cancelled" | "InProgress" | "Failed" | "Stopped" | "Stopping" | "Succeeded" | "Skipped" | (string & {});
export interface StageExecution {
    pipelineExecutionId: string;
    status: StageExecutionStatus;
    type?: ExecutionType | undefined;
}
export type StageExecutionList = StageExecution[];
export type Enabled = boolean;
export type LastChangedBy = string;
export type LastChangedAt = Date;
export interface TransitionState {
    enabled?: boolean | undefined;
    lastChangedBy?: string | undefined;
    lastChangedAt?: Date | undefined;
    disabledReason?: string | undefined;
}
export interface ActionRevision {
    revisionId: string;
    revisionChangeId?: string | undefined;
    created?: Date | undefined;
}
export type ActionExecutionStatus = "InProgress" | "Abandoned" | "Succeeded" | "Failed" | (string & {});
export type ExecutionSummary = string;
export type ActionExecutionToken = string;
export type LastUpdatedBy = string;
export type ExecutionId = string;
export type Percentage = number;
export type Code = string;
export type Message = string;
export interface ErrorDetails {
    code?: string | undefined;
    message?: string | undefined;
}
export type LogStreamARN = string;
export interface ActionExecution {
    actionExecutionId?: string | undefined;
    status?: ActionExecutionStatus | undefined;
    summary?: string | undefined;
    lastStatusChange?: Date | undefined;
    token?: string | undefined;
    lastUpdatedBy?: string | undefined;
    externalExecutionId?: string | undefined;
    externalExecutionUrl?: string | undefined;
    percentComplete?: number | undefined;
    errorDetails?: ErrorDetails | undefined;
    logStreamARN?: string | undefined;
}
export interface ActionState {
    actionName?: string | undefined;
    currentRevision?: ActionRevision | undefined;
    latestExecution?: ActionExecution | undefined;
    entityUrl?: string | undefined;
    revisionUrl?: string | undefined;
}
export type ActionStateList = ActionState[];
export type ConditionExecutionStatus = "InProgress" | "Failed" | "Errored" | "Succeeded" | "Cancelled" | "Abandoned" | "Overridden" | (string & {});
export interface StageConditionsExecution {
    status?: ConditionExecutionStatus | undefined;
    summary?: string | undefined;
}
export interface ConditionExecution {
    status?: ConditionExecutionStatus | undefined;
    summary?: string | undefined;
    lastStatusChange?: Date | undefined;
}
export interface RuleRevision {
    revisionId: string;
    revisionChangeId?: string | undefined;
    created?: Date | undefined;
}
export type RuleExecutionId = string;
export type RuleExecutionStatus = "InProgress" | "Abandoned" | "Succeeded" | "Failed" | (string & {});
export type RuleExecutionToken = string;
export interface RuleExecution {
    ruleExecutionId?: string | undefined;
    status?: RuleExecutionStatus | undefined;
    summary?: string | undefined;
    lastStatusChange?: Date | undefined;
    token?: string | undefined;
    lastUpdatedBy?: string | undefined;
    externalExecutionId?: string | undefined;
    externalExecutionUrl?: string | undefined;
    errorDetails?: ErrorDetails | undefined;
}
export interface RuleState {
    ruleName?: string | undefined;
    currentRevision?: RuleRevision | undefined;
    latestExecution?: RuleExecution | undefined;
    entityUrl?: string | undefined;
    revisionUrl?: string | undefined;
}
export type RuleStateList = RuleState[];
export interface ConditionState {
    latestExecution?: ConditionExecution | undefined;
    ruleStates?: RuleState[] | undefined;
}
export type ConditionStateList = ConditionState[];
export interface StageConditionState {
    latestExecution?: StageConditionsExecution | undefined;
    conditionStates?: ConditionState[] | undefined;
}
export type RetryAttempt = number;
export type RetryTrigger = "AutomatedStageRetry" | "ManualStageRetry" | (string & {});
export interface RetryStageMetadata {
    autoStageRetryAttempt?: number | undefined;
    manualStageRetryAttempt?: number | undefined;
    latestRetryTrigger?: RetryTrigger | undefined;
}
export interface StageState {
    stageName?: string | undefined;
    inboundExecution?: StageExecution | undefined;
    inboundExecutions?: StageExecution[] | undefined;
    inboundTransitionState?: TransitionState | undefined;
    actionStates?: ActionState[] | undefined;
    latestExecution?: StageExecution | undefined;
    beforeEntryConditionState?: StageConditionState | undefined;
    onSuccessConditionState?: StageConditionState | undefined;
    onFailureConditionState?: StageConditionState | undefined;
    retryStageMetadata?: RetryStageMetadata | undefined;
}
export type StageStateList = StageState[];
export interface GetPipelineStateOutput {
    pipelineName?: string | undefined;
    pipelineVersion?: number | undefined;
    stageStates?: StageState[] | undefined;
    created?: Date | undefined;
    updated?: Date | undefined;
}
export interface GetThirdPartyJobDetailsInput {
    jobId: string;
    clientToken: string;
}
export interface ThirdPartyJobData {
    actionTypeId?: ActionTypeId | undefined;
    actionConfiguration?: ActionConfiguration | undefined;
    pipelineContext?: PipelineContext | undefined;
    inputArtifacts?: Artifact[] | undefined;
    outputArtifacts?: Artifact[] | undefined;
    artifactCredentials?: AWSSessionCredentials | undefined;
    continuationToken?: string | undefined;
    encryptionKey?: EncryptionKey | undefined;
}
export interface ThirdPartyJobDetails {
    id?: string | undefined;
    data?: ThirdPartyJobData | undefined;
    nonce?: string | undefined;
}
export interface GetThirdPartyJobDetailsOutput {
    jobDetails?: ThirdPartyJobDetails | undefined;
}
export type StartTimeRange = "Latest" | "All" | (string & {});
export interface LatestInPipelineExecutionFilter {
    pipelineExecutionId: string;
    startTimeRange: StartTimeRange;
}
export interface ActionExecutionFilter {
    pipelineExecutionId?: string | undefined;
    latestInPipelineExecution?: LatestInPipelineExecutionFilter | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListActionExecutionsInput {
    pipelineName: string;
    filter?: ActionExecutionFilter | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ResolvedActionConfigurationMap = {
    [key: string]: string | undefined;
};
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    bucket?: string | undefined;
    key?: string | undefined;
}
export interface ArtifactDetail {
    name?: string | undefined;
    s3location?: S3Location | undefined;
}
export type ArtifactDetailList = ArtifactDetail[];
export interface ActionExecutionInput {
    actionTypeId?: ActionTypeId | undefined;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    resolvedConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    roleArn?: string | undefined;
    region?: string | undefined;
    inputArtifacts?: ArtifactDetail[] | undefined;
    namespace?: string | undefined;
}
export type ExternalExecutionId = string;
export type ExternalExecutionSummary = string;
export interface ActionExecutionResult {
    externalExecutionId?: string | undefined;
    externalExecutionSummary?: string | undefined;
    externalExecutionUrl?: string | undefined;
    errorDetails?: ErrorDetails | undefined;
    logStreamARN?: string | undefined;
}
export type OutputVariablesKey = string;
export type OutputVariablesValue = string;
export type OutputVariablesMap = {
    [key: string]: string | undefined;
};
export interface ActionExecutionOutput {
    outputArtifacts?: ArtifactDetail[] | undefined;
    executionResult?: ActionExecutionResult | undefined;
    outputVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ActionExecutionDetail {
    pipelineExecutionId?: string | undefined;
    actionExecutionId?: string | undefined;
    pipelineVersion?: number | undefined;
    stageName?: string | undefined;
    actionName?: string | undefined;
    startTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    updatedBy?: string | undefined;
    status?: ActionExecutionStatus | undefined;
    input?: ActionExecutionInput | undefined;
    output?: ActionExecutionOutput | undefined;
}
export type ActionExecutionDetailList = ActionExecutionDetail[];
export interface ListActionExecutionsOutput {
    actionExecutionDetails?: ActionExecutionDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface ListActionTypesInput {
    actionOwnerFilter?: ActionOwner | undefined;
    nextToken?: string | undefined;
    regionFilter?: string | undefined;
}
export type ActionTypeList = ActionType[];
export interface ListActionTypesOutput {
    actionTypes: ActionType[];
    nextToken?: string | undefined;
}
export type TargetFilterName = "TARGET_STATUS" | (string & {});
export type TargetFilterValue = string;
export type TargetFilterValueList = string[];
export interface TargetFilter {
    name?: TargetFilterName | undefined;
    values?: string[] | undefined;
}
export type TargetFilterList = TargetFilter[];
export interface ListDeployActionExecutionTargetsInput {
    pipelineName?: string | undefined;
    actionExecutionId: string;
    filters?: TargetFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DeployTargetEventContext {
    ssmCommandId?: string | undefined;
    message?: string | undefined;
}
export interface DeployTargetEvent {
    name?: string | undefined;
    status?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    context?: DeployTargetEventContext | undefined;
}
export type DeployTargetEventList = DeployTargetEvent[];
export interface DeployActionExecutionTarget {
    targetId?: string | undefined;
    targetType?: string | undefined;
    status?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    events?: DeployTargetEvent[] | undefined;
}
export type DeployActionExecutionTargetList = DeployActionExecutionTarget[];
export interface ListDeployActionExecutionTargetsOutput {
    targets?: DeployActionExecutionTarget[] | undefined;
    nextToken?: string | undefined;
}
export interface SucceededInStageFilter {
    stageName?: string | undefined;
}
export interface PipelineExecutionFilter {
    succeededInStage?: SucceededInStageFilter | undefined;
}
export interface ListPipelineExecutionsInput {
    pipelineName: string;
    maxResults?: number | undefined;
    filter?: PipelineExecutionFilter | undefined;
    nextToken?: string | undefined;
}
export interface SourceRevision {
    actionName: string;
    revisionId?: string | undefined;
    revisionSummary?: string | undefined;
    revisionUrl?: string | undefined;
}
export type SourceRevisionList = SourceRevision[];
export type StopPipelineExecutionReason = string;
export interface StopExecutionTrigger {
    reason?: string | undefined;
}
export interface PipelineExecutionSummary {
    pipelineExecutionId?: string | undefined;
    status?: PipelineExecutionStatus | undefined;
    statusSummary?: string | undefined;
    startTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    sourceRevisions?: SourceRevision[] | undefined;
    trigger?: ExecutionTrigger | undefined;
    stopTrigger?: StopExecutionTrigger | undefined;
    executionMode?: ExecutionMode | undefined;
    executionType?: ExecutionType | undefined;
    rollbackMetadata?: PipelineRollbackMetadata | undefined;
}
export type PipelineExecutionSummaryList = PipelineExecutionSummary[];
export interface ListPipelineExecutionsOutput {
    pipelineExecutionSummaries?: PipelineExecutionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type MaxPipelines = number;
export interface ListPipelinesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PipelineSummary {
    name?: string | undefined;
    version?: number | undefined;
    pipelineType?: PipelineType | undefined;
    executionMode?: ExecutionMode | undefined;
    created?: Date | undefined;
    updated?: Date | undefined;
}
export type PipelineList = PipelineSummary[];
export interface ListPipelinesOutput {
    pipelines?: PipelineSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface RuleExecutionFilter {
    pipelineExecutionId?: string | undefined;
    latestInPipelineExecution?: LatestInPipelineExecutionFilter | undefined;
}
export interface ListRuleExecutionsInput {
    pipelineName: string;
    filter?: RuleExecutionFilter | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ResolvedRuleConfigurationMap = {
    [key: string]: string | undefined;
};
export interface RuleExecutionInput {
    ruleTypeId?: RuleTypeId | undefined;
    configuration?: {
        [key: string]: string | undefined;
    } | undefined;
    resolvedConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    roleArn?: string | undefined;
    region?: string | undefined;
    inputArtifacts?: ArtifactDetail[] | undefined;
}
export interface RuleExecutionResult {
    externalExecutionId?: string | undefined;
    externalExecutionSummary?: string | undefined;
    externalExecutionUrl?: string | undefined;
    errorDetails?: ErrorDetails | undefined;
}
export interface RuleExecutionOutput {
    executionResult?: RuleExecutionResult | undefined;
}
export interface RuleExecutionDetail {
    pipelineExecutionId?: string | undefined;
    ruleExecutionId?: string | undefined;
    pipelineVersion?: number | undefined;
    stageName?: string | undefined;
    ruleName?: string | undefined;
    startTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    updatedBy?: string | undefined;
    status?: RuleExecutionStatus | undefined;
    input?: RuleExecutionInput | undefined;
    output?: RuleExecutionOutput | undefined;
}
export type RuleExecutionDetailList = RuleExecutionDetail[];
export interface ListRuleExecutionsOutput {
    ruleExecutionDetails?: RuleExecutionDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRuleTypesInput {
    ruleOwnerFilter?: RuleOwner | undefined;
    regionFilter?: string | undefined;
}
export interface RuleTypeSettings {
    thirdPartyConfigurationUrl?: string | undefined;
    entityUrlTemplate?: string | undefined;
    executionUrlTemplate?: string | undefined;
    revisionUrlTemplate?: string | undefined;
}
export type RuleConfigurationPropertyType = "String" | "Number" | "Boolean" | (string & {});
export interface RuleConfigurationProperty {
    name: string;
    required: boolean;
    key: boolean;
    secret: boolean;
    queryable?: boolean | undefined;
    description?: string | undefined;
    type?: RuleConfigurationPropertyType | undefined;
}
export type RuleConfigurationPropertyList = RuleConfigurationProperty[];
export interface RuleType {
    id: RuleTypeId;
    settings?: RuleTypeSettings | undefined;
    ruleConfigurationProperties?: RuleConfigurationProperty[] | undefined;
    inputArtifactDetails: ArtifactDetails;
}
export type RuleTypeList = RuleType[];
export interface ListRuleTypesOutput {
    ruleTypes: RuleType[];
}
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTagsForResourceOutput {
    tags?: Tag[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWebhooksInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type JsonPath = string;
export type MatchEquals = string;
export interface WebhookFilterRule {
    jsonPath: string;
    matchEquals?: string | undefined;
}
export type WebhookFilters = WebhookFilterRule[];
export type WebhookAuthenticationType = "GITHUB_HMAC" | "IP" | "UNAUTHENTICATED" | (string & {});
export type WebhookAuthConfigurationAllowedIPRange = string;
export type WebhookAuthConfigurationSecretToken = string;
export interface WebhookAuthConfiguration {
    AllowedIPRange?: string | undefined;
    SecretToken?: string | redacted.Redacted<string> | undefined;
}
export interface WebhookDefinition {
    name: string;
    targetPipeline: string;
    targetAction: string;
    filters: WebhookFilterRule[];
    authentication: WebhookAuthenticationType;
    authenticationConfiguration: WebhookAuthConfiguration;
}
export type WebhookUrl = string;
export type WebhookErrorMessage = string;
export type WebhookErrorCode = string;
export type WebhookLastTriggered = Date;
export type WebhookArn = string;
export interface ListWebhookItem {
    definition: WebhookDefinition;
    url: string;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
    lastTriggered?: Date | undefined;
    arn?: string | undefined;
    tags?: Tag[] | undefined;
}
export type WebhookList = ListWebhookItem[];
export interface ListWebhooksOutput {
    webhooks?: ListWebhookItem[] | undefined;
    NextToken?: string | undefined;
}
export type ConditionType = "BEFORE_ENTRY" | "ON_SUCCESS" | (string & {});
export interface OverrideStageConditionInput {
    pipelineName: string;
    stageName: string;
    pipelineExecutionId: string;
    conditionType: ConditionType;
}
export interface OverrideStageConditionResponse {
}
export type MaxBatchSize = number;
export type ActionConfigurationQueryableValue = string;
export type QueryParamMap = {
    [key: string]: string | undefined;
};
export interface PollForJobsInput {
    actionTypeId: ActionTypeId;
    maxBatchSize?: number | undefined;
    queryParam?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Job {
    id?: string | undefined;
    data?: JobData | undefined;
    nonce?: string | undefined;
    accountId?: string | undefined;
}
export type JobList = Job[];
export interface PollForJobsOutput {
    jobs?: Job[] | undefined;
}
export interface PollForThirdPartyJobsInput {
    actionTypeId: ActionTypeId;
    maxBatchSize?: number | undefined;
}
export type ClientId = string;
export interface ThirdPartyJob {
    clientId?: string | undefined;
    jobId?: string | undefined;
}
export type ThirdPartyJobList = ThirdPartyJob[];
export interface PollForThirdPartyJobsOutput {
    jobs?: ThirdPartyJob[] | undefined;
}
export interface PutActionRevisionInput {
    pipelineName: string;
    stageName: string;
    actionName: string;
    actionRevision: ActionRevision;
}
export interface PutActionRevisionOutput {
    newRevision?: boolean | undefined;
    pipelineExecutionId?: string | undefined;
}
export type ApprovalSummary = string;
export type ApprovalStatus = "Approved" | "Rejected" | (string & {});
export interface ApprovalResult {
    summary: string;
    status: ApprovalStatus;
}
export type ApprovalToken = string;
export interface PutApprovalResultInput {
    pipelineName: string;
    stageName: string;
    actionName: string;
    result: ApprovalResult;
    token: string;
}
export interface PutApprovalResultOutput {
    approvedAt?: Date | undefined;
}
export type FailureType = "JobFailed" | "ConfigurationError" | "PermissionError" | "RevisionOutOfSync" | "RevisionUnavailable" | "SystemUnavailable" | (string & {});
export interface FailureDetails {
    type: FailureType;
    message: string;
    externalExecutionId?: string | undefined;
}
export interface PutJobFailureResultInput {
    jobId: string;
    failureDetails: FailureDetails;
}
export interface PutJobFailureResultResponse {
}
export interface CurrentRevision {
    revision: string;
    changeIdentifier: string;
    created?: Date | undefined;
    revisionSummary?: string | undefined;
}
export interface ExecutionDetails {
    summary?: string | undefined;
    externalExecutionId?: string | undefined;
    percentComplete?: number | undefined;
}
export interface PutJobSuccessResultInput {
    jobId: string;
    currentRevision?: CurrentRevision | undefined;
    continuationToken?: string | undefined;
    executionDetails?: ExecutionDetails | undefined;
    outputVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutJobSuccessResultResponse {
}
export interface PutThirdPartyJobFailureResultInput {
    jobId: string;
    clientToken: string;
    failureDetails: FailureDetails;
}
export interface PutThirdPartyJobFailureResultResponse {
}
export interface PutThirdPartyJobSuccessResultInput {
    jobId: string;
    clientToken: string;
    currentRevision?: CurrentRevision | undefined;
    continuationToken?: string | undefined;
    executionDetails?: ExecutionDetails | undefined;
}
export interface PutThirdPartyJobSuccessResultResponse {
}
export interface PutWebhookInput {
    webhook: WebhookDefinition;
    tags?: Tag[] | undefined;
}
export interface PutWebhookOutput {
    webhook?: ListWebhookItem | undefined;
}
export interface RegisterWebhookWithThirdPartyInput {
    webhookName?: string | undefined;
}
export interface RegisterWebhookWithThirdPartyOutput {
}
export interface RetryStageExecutionInput {
    pipelineName: string;
    stageName: string;
    pipelineExecutionId: string;
    retryMode: StageRetryMode;
}
export interface RetryStageExecutionOutput {
    pipelineExecutionId?: string | undefined;
}
export interface RollbackStageInput {
    pipelineName: string;
    stageName: string;
    targetPipelineExecutionId: string;
}
export interface RollbackStageOutput {
    pipelineExecutionId: string;
}
export interface PipelineVariable {
    name: string;
    value: string;
}
export type PipelineVariableList = PipelineVariable[];
export type ClientRequestToken = string;
export type SourceRevisionType = "COMMIT_ID" | "IMAGE_DIGEST" | "S3_OBJECT_VERSION_ID" | "S3_OBJECT_KEY" | (string & {});
export interface SourceRevisionOverride {
    actionName: string;
    revisionType: SourceRevisionType;
    revisionValue: string;
}
export type SourceRevisionOverrideList = SourceRevisionOverride[];
export interface StartPipelineExecutionInput {
    name: string;
    variables?: PipelineVariable[] | undefined;
    clientRequestToken?: string | undefined;
    sourceRevisions?: SourceRevisionOverride[] | undefined;
}
export interface StartPipelineExecutionOutput {
    pipelineExecutionId?: string | undefined;
}
export interface StopPipelineExecutionInput {
    pipelineName: string;
    pipelineExecutionId: string;
    abandon?: boolean | undefined;
    reason?: string | undefined;
}
export interface StopPipelineExecutionOutput {
    pipelineExecutionId?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateActionTypeInput {
    actionType: ActionTypeDeclaration;
}
export interface UpdateActionTypeResponse {
}
export interface UpdatePipelineInput {
    pipeline: PipelineDeclaration;
}
export interface UpdatePipelineOutput {
    pipeline?: PipelineDeclaration | undefined;
}
export type AcknowledgeJobError = InvalidNonceException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specified job and whether that job has been received by
 * the job worker. Used for custom actions only.
 */
export declare const acknowledgeJob: API.OperationMethod<AcknowledgeJobInput & RegionInput, AcknowledgeJobOutput, AcknowledgeJobError, Credentials | HttpClient.HttpClient>;
export type AcknowledgeThirdPartyJobError = InvalidClientTokenException | InvalidNonceException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Confirms a job worker has received the specified job. Used for partner actions
 * only.
 */
export declare const acknowledgeThirdPartyJob: API.OperationMethod<AcknowledgeThirdPartyJobInput & RegionInput, AcknowledgeThirdPartyJobOutput, AcknowledgeThirdPartyJobError, Credentials | HttpClient.HttpClient>;
export type CreateCustomActionTypeError = ConcurrentModificationException | InvalidTagsException | LimitExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new custom action that can be used in all pipelines associated with the
 * Amazon Web Services account. Only used for custom actions.
 */
export declare const createCustomActionType: API.OperationMethod<CreateCustomActionTypeInput & RegionInput, CreateCustomActionTypeOutput, CreateCustomActionTypeError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineError = ConcurrentModificationException | InvalidActionDeclarationException | InvalidBlockerDeclarationException | InvalidStageDeclarationException | InvalidStructureException | InvalidTagsException | LimitExceededException | PipelineNameInUseException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a pipeline.
 *
 * In the pipeline structure, you must include either `artifactStore`
 * or `artifactStores` in your pipeline, but you cannot use both. If you
 * create a cross-region action in your pipeline, you must use
 * `artifactStores`.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineInput & RegionInput, CreatePipelineOutput, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomActionTypeError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Marks a custom action as deleted. `PollForJobs` for the custom action
 * fails after the action is marked for deletion. Used for custom actions only.
 *
 * To re-create a custom action after it has been deleted you must use a string in
 * the version field that has never been used before. This string can be an incremented
 * version number, for example. To restore a deleted custom action, use a JSON file
 * that is identical to the deleted action, including the original string in the
 * version field.
 */
export declare const deleteCustomActionType: API.OperationMethod<DeleteCustomActionTypeInput & RegionInput, DeleteCustomActionTypeResponse, DeleteCustomActionTypeError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Deletes the specified pipeline.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineInput & RegionInput, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteWebhookError = ConcurrentModificationException | ValidationException | CommonErrors;
/**
 * Deletes a previously created webhook by name. Deleting the webhook stops CodePipeline from starting a pipeline every time an external event occurs. The API
 * returns successfully when trying to delete a webhook that is already deleted. If a
 * deleted webhook is re-created by calling PutWebhook with the same name, it will have a
 * different URL.
 */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookInput & RegionInput, DeleteWebhookOutput, DeleteWebhookError, Credentials | HttpClient.HttpClient>;
export type DeregisterWebhookWithThirdPartyError = ValidationException | WebhookNotFoundException | CommonErrors;
/**
 * Removes the connection between the webhook that was created by CodePipeline
 * and the external tool with events to be detected. Currently supported only for webhooks
 * that target an action type of GitHub.
 */
export declare const deregisterWebhookWithThirdParty: API.OperationMethod<DeregisterWebhookWithThirdPartyInput & RegionInput, DeregisterWebhookWithThirdPartyOutput, DeregisterWebhookWithThirdPartyError, Credentials | HttpClient.HttpClient>;
export type DisableStageTransitionError = PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Prevents artifacts in a pipeline from transitioning to the next stage in the
 * pipeline.
 */
export declare const disableStageTransition: API.OperationMethod<DisableStageTransitionInput & RegionInput, DisableStageTransitionResponse, DisableStageTransitionError, Credentials | HttpClient.HttpClient>;
export type EnableStageTransitionError = PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Enables artifacts in a pipeline to transition to a stage in a pipeline.
 */
export declare const enableStageTransition: API.OperationMethod<EnableStageTransitionInput & RegionInput, EnableStageTransitionResponse, EnableStageTransitionError, Credentials | HttpClient.HttpClient>;
export type GetActionTypeError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an action type created for an external provider, where the
 * action is to be used by customers of the external provider. The action can be created
 * with any supported integration model.
 */
export declare const getActionType: API.OperationMethod<GetActionTypeInput & RegionInput, GetActionTypeOutput, GetActionTypeError, Credentials | HttpClient.HttpClient>;
export type GetJobDetailsError = JobNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a job. Used for custom actions only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const getJobDetails: API.OperationMethod<GetJobDetailsInput & RegionInput, GetJobDetailsOutput, GetJobDetailsError, Credentials | HttpClient.HttpClient>;
export type GetPipelineError = PipelineNotFoundException | PipelineVersionNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the metadata, structure, stages, and actions of a pipeline. Can be used to
 * return the entire structure of a pipeline in JSON format, which can then be modified and
 * used to update the pipeline structure with UpdatePipeline.
 */
export declare const getPipeline: API.OperationMethod<GetPipelineInput & RegionInput, GetPipelineOutput, GetPipelineError, Credentials | HttpClient.HttpClient>;
export type GetPipelineExecutionError = PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an execution of a pipeline, including details about
 * artifacts, the pipeline execution ID, and the name, version, and status of the
 * pipeline.
 */
export declare const getPipelineExecution: API.OperationMethod<GetPipelineExecutionInput & RegionInput, GetPipelineExecutionOutput, GetPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type GetPipelineStateError = PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the state of a pipeline, including the stages and
 * actions.
 *
 * Values returned in the `revisionId` and `revisionUrl`
 * fields indicate the source revision information, such as the commit ID, for the
 * current state.
 */
export declare const getPipelineState: API.OperationMethod<GetPipelineStateInput & RegionInput, GetPipelineStateOutput, GetPipelineStateError, Credentials | HttpClient.HttpClient>;
export type GetThirdPartyJobDetailsError = InvalidClientTokenException | InvalidJobException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Requests the details of a job for a third party action. Used for partner actions
 * only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const getThirdPartyJobDetails: API.OperationMethod<GetThirdPartyJobDetailsInput & RegionInput, GetThirdPartyJobDetailsOutput, GetThirdPartyJobDetailsError, Credentials | HttpClient.HttpClient>;
export type ListActionExecutionsError = InvalidNextTokenException | PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the action executions that have occurred in a pipeline.
 */
export declare const listActionExecutions: API.PaginatedOperationMethod<ListActionExecutionsInput & RegionInput, ListActionExecutionsOutput, ListActionExecutionsError, Credentials | HttpClient.HttpClient, ActionExecutionDetail>;
export type ListActionTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a summary of all CodePipeline action types associated with your
 * account.
 */
export declare const listActionTypes: API.PaginatedOperationMethod<ListActionTypesInput & RegionInput, ListActionTypesOutput, ListActionTypesError, Credentials | HttpClient.HttpClient, ActionType>;
export type ListDeployActionExecutionTargetsError = ActionExecutionNotFoundException | InvalidNextTokenException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the targets for the deploy action.
 */
export declare const listDeployActionExecutionTargets: API.PaginatedOperationMethod<ListDeployActionExecutionTargetsInput & RegionInput, ListDeployActionExecutionTargetsOutput, ListDeployActionExecutionTargetsError, Credentials | HttpClient.HttpClient, DeployActionExecutionTarget>;
export type ListPipelineExecutionsError = InvalidNextTokenException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a summary of the most recent executions for a pipeline.
 *
 * When applying the filter for pipeline executions that have succeeded in the stage,
 * the operation returns all executions in the current pipeline version beginning on
 * February 1, 2024.
 */
export declare const listPipelineExecutions: API.PaginatedOperationMethod<ListPipelineExecutionsInput & RegionInput, ListPipelineExecutionsOutput, ListPipelineExecutionsError, Credentials | HttpClient.HttpClient, PipelineExecutionSummary>;
export type ListPipelinesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a summary of all of the pipelines associated with your account.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesInput & RegionInput, ListPipelinesOutput, ListPipelinesError, Credentials | HttpClient.HttpClient, PipelineSummary>;
export type ListRuleExecutionsError = InvalidNextTokenException | PipelineExecutionNotFoundException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the rule executions that have occurred in a pipeline configured for conditions
 * with rules.
 */
export declare const listRuleExecutions: API.PaginatedOperationMethod<ListRuleExecutionsInput & RegionInput, ListRuleExecutionsOutput, ListRuleExecutionsError, Credentials | HttpClient.HttpClient, RuleExecutionDetail>;
export type ListRuleTypesError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Lists the rules for the condition. For more information about conditions, see Stage
 * conditions and How do
 * stage conditions work?.For more information about rules, see the
 * CodePipeline rule reference.
 */
export declare const listRuleTypes: API.OperationMethod<ListRuleTypesInput & RegionInput, ListRuleTypesOutput, ListRuleTypesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidArnException | InvalidNextTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets the set of key-value pairs (metadata) that are used to manage the
 * resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListWebhooksError = InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Gets a listing of all the webhooks in this Amazon Web Services Region for this
 * account. The output lists all webhooks and includes the webhook URL and ARN and the
 * configuration for each webhook.
 *
 * If a secret token was provided, it will be redacted in the response.
 */
export declare const listWebhooks: API.PaginatedOperationMethod<ListWebhooksInput & RegionInput, ListWebhooksOutput, ListWebhooksError, Credentials | HttpClient.HttpClient, ListWebhookItem>;
export type OverrideStageConditionError = ConcurrentPipelineExecutionsLimitExceededException | ConditionNotOverridableException | ConflictException | NotLatestPipelineExecutionException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Used to override a stage condition. For more information about conditions, see Stage
 * conditions and How do
 * stage conditions work?.
 */
export declare const overrideStageCondition: API.OperationMethod<OverrideStageConditionInput & RegionInput, OverrideStageConditionResponse, OverrideStageConditionError, Credentials | HttpClient.HttpClient>;
export type PollForJobsError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about any jobs for CodePipeline to act on.
 * `PollForJobs` is valid only for action types with "Custom" in the owner
 * field. If the action type contains `AWS` or `ThirdParty` in the
 * owner field, the `PollForJobs` action returns an error.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts. This API also returns any
 * secret values defined for the action.
 */
export declare const pollForJobs: API.OperationMethod<PollForJobsInput & RegionInput, PollForJobsOutput, PollForJobsError, Credentials | HttpClient.HttpClient>;
export type PollForThirdPartyJobsError = ActionTypeNotFoundException | ValidationException | CommonErrors;
/**
 * Determines whether there are any third party jobs for a job worker to act on. Used
 * for partner actions only.
 *
 * When this API is called, CodePipeline returns temporary credentials for
 * the S3 bucket used to store artifacts for the pipeline, if the action requires
 * access to that S3 bucket for input or output artifacts.
 */
export declare const pollForThirdPartyJobs: API.OperationMethod<PollForThirdPartyJobsInput & RegionInput, PollForThirdPartyJobsOutput, PollForThirdPartyJobsError, Credentials | HttpClient.HttpClient>;
export type PutActionRevisionError = ActionNotFoundException | ConcurrentPipelineExecutionsLimitExceededException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Provides information to CodePipeline about new revisions to a
 * source.
 */
export declare const putActionRevision: API.OperationMethod<PutActionRevisionInput & RegionInput, PutActionRevisionOutput, PutActionRevisionError, Credentials | HttpClient.HttpClient>;
export type PutApprovalResultError = ActionNotFoundException | ApprovalAlreadyCompletedException | InvalidApprovalTokenException | PipelineNotFoundException | StageNotFoundException | ValidationException | CommonErrors;
/**
 * Provides the response to a manual approval request to CodePipeline. Valid
 * responses include Approved and Rejected.
 */
export declare const putApprovalResult: API.OperationMethod<PutApprovalResultInput & RegionInput, PutApprovalResultOutput, PutApprovalResultError, Credentials | HttpClient.HttpClient>;
export type PutJobFailureResultError = InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the failure of a job as returned to the pipeline by a job worker. Used
 * for custom actions only.
 */
export declare const putJobFailureResult: API.OperationMethod<PutJobFailureResultInput & RegionInput, PutJobFailureResultResponse, PutJobFailureResultError, Credentials | HttpClient.HttpClient>;
export type PutJobSuccessResultError = InvalidJobStateException | JobNotFoundException | OutputVariablesSizeExceededException | ValidationException | CommonErrors;
/**
 * Represents the success of a job as returned to the pipeline by a job worker. Used
 * for custom actions only.
 */
export declare const putJobSuccessResult: API.OperationMethod<PutJobSuccessResultInput & RegionInput, PutJobSuccessResultResponse, PutJobSuccessResultError, Credentials | HttpClient.HttpClient>;
export type PutThirdPartyJobFailureResultError = InvalidClientTokenException | InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the failure of a third party job as returned to the pipeline by a job
 * worker. Used for partner actions only.
 */
export declare const putThirdPartyJobFailureResult: API.OperationMethod<PutThirdPartyJobFailureResultInput & RegionInput, PutThirdPartyJobFailureResultResponse, PutThirdPartyJobFailureResultError, Credentials | HttpClient.HttpClient>;
export type PutThirdPartyJobSuccessResultError = InvalidClientTokenException | InvalidJobStateException | JobNotFoundException | ValidationException | CommonErrors;
/**
 * Represents the success of a third party job as returned to the pipeline by a job
 * worker. Used for partner actions only.
 */
export declare const putThirdPartyJobSuccessResult: API.OperationMethod<PutThirdPartyJobSuccessResultInput & RegionInput, PutThirdPartyJobSuccessResultResponse, PutThirdPartyJobSuccessResultError, Credentials | HttpClient.HttpClient>;
export type PutWebhookError = ConcurrentModificationException | InvalidTagsException | InvalidWebhookAuthenticationParametersException | InvalidWebhookFilterPatternException | LimitExceededException | PipelineNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Defines a webhook and returns a unique webhook URL generated by CodePipeline.
 * This URL can be supplied to third party source hosting providers to call every time
 * there's a code change. When CodePipeline receives a POST request on this URL, the
 * pipeline defined in the webhook is started as long as the POST request satisfied the
 * authentication and filtering requirements supplied when defining the webhook.
 * RegisterWebhookWithThirdParty and DeregisterWebhookWithThirdParty APIs can be used to
 * automatically configure supported third parties to call the generated webhook
 * URL.
 *
 * When creating CodePipeline webhooks, do not use your own credentials or
 * reuse the same secret token across multiple webhooks. For optimal security, generate
 * a unique secret token for each webhook you create. The secret token is an arbitrary
 * string that you provide, which GitHub uses to compute and sign the webhook payloads
 * sent to CodePipeline, for protecting the integrity and authenticity of the
 * webhook payloads. Using your own credentials or reusing the same token across
 * multiple webhooks can lead to security vulnerabilities.
 *
 * If a secret token was provided, it will be redacted in the response.
 */
export declare const putWebhook: API.OperationMethod<PutWebhookInput & RegionInput, PutWebhookOutput, PutWebhookError, Credentials | HttpClient.HttpClient>;
export type RegisterWebhookWithThirdPartyError = ValidationException | WebhookNotFoundException | CommonErrors;
/**
 * Configures a connection between the webhook that was created and the external tool
 * with events to be detected.
 */
export declare const registerWebhookWithThirdParty: API.OperationMethod<RegisterWebhookWithThirdPartyInput & RegionInput, RegisterWebhookWithThirdPartyOutput, RegisterWebhookWithThirdPartyError, Credentials | HttpClient.HttpClient>;
export type RetryStageExecutionError = ConcurrentPipelineExecutionsLimitExceededException | ConflictException | NotLatestPipelineExecutionException | PipelineNotFoundException | StageNotFoundException | StageNotRetryableException | ValidationException | CommonErrors;
/**
 * You can retry a stage that has failed without having to run a pipeline again from
 * the beginning. You do this by either retrying the failed actions in a stage or by
 * retrying all actions in the stage starting from the first action in the stage. When you
 * retry the failed actions in a stage, all actions that are still in progress continue
 * working, and failed actions are triggered again. When you retry a failed stage from the
 * first action in the stage, the stage cannot have any actions in progress. Before a stage
 * can be retried, it must either have all actions failed or some actions failed and some
 * succeeded.
 */
export declare const retryStageExecution: API.OperationMethod<RetryStageExecutionInput & RegionInput, RetryStageExecutionOutput, RetryStageExecutionError, Credentials | HttpClient.HttpClient>;
export type RollbackStageError = ConflictException | PipelineExecutionNotFoundException | PipelineExecutionOutdatedException | PipelineNotFoundException | StageNotFoundException | UnableToRollbackStageException | ValidationException | CommonErrors;
/**
 * Rolls back a stage execution.
 */
export declare const rollbackStage: API.OperationMethod<RollbackStageInput & RegionInput, RollbackStageOutput, RollbackStageError, Credentials | HttpClient.HttpClient>;
export type StartPipelineExecutionError = ConcurrentPipelineExecutionsLimitExceededException | ConflictException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Starts the specified pipeline. Specifically, it begins processing the latest commit
 * to the source location specified as part of the pipeline.
 */
export declare const startPipelineExecution: API.OperationMethod<StartPipelineExecutionInput & RegionInput, StartPipelineExecutionOutput, StartPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type StopPipelineExecutionError = ConflictException | DuplicatedStopRequestException | PipelineExecutionNotStoppableException | PipelineNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the specified pipeline execution. You choose to either stop the pipeline
 * execution by completing in-progress actions without starting subsequent actions, or by
 * abandoning in-progress actions. While completing or abandoning in-progress actions, the
 * pipeline execution is in a `Stopping` state. After all in-progress actions
 * are completed or abandoned, the pipeline execution is in a `Stopped`
 * state.
 */
export declare const stopPipelineExecution: API.OperationMethod<StopPipelineExecutionInput & RegionInput, StopPipelineExecutionOutput, StopPipelineExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InvalidArnException | InvalidTagsException | ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata that can be used
 * to manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InvalidArnException | InvalidTagsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateActionTypeError = ActionTypeNotFoundException | RequestFailedException | ValidationException | CommonErrors;
/**
 * Updates an action type that was created with any supported integration model, where
 * the action type is to be used by customers of the action type provider. Use a JSON file
 * with the action definition and `UpdateActionType` to provide the full
 * structure.
 */
export declare const updateActionType: API.OperationMethod<UpdateActionTypeInput & RegionInput, UpdateActionTypeResponse, UpdateActionTypeError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = InvalidActionDeclarationException | InvalidBlockerDeclarationException | InvalidStageDeclarationException | InvalidStructureException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Updates a specified pipeline with edits or changes to its structure. Use a JSON
 * file with the pipeline structure and `UpdatePipeline` to provide the full
 * structure of the pipeline. Updating the pipeline increases the version number of the
 * pipeline by 1.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineInput & RegionInput, UpdatePipelineOutput, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codepipeline.d.ts.map