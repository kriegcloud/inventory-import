import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import type { Annotations } from "./Annotations.ts";
import type { Fields } from "./Event.ts";
type OpImpl = (args: unknown) => Effect.Effect<unknown, unknown, unknown>;
/**
 * Trace every call to an external system: one client span per call, named
 * after the system and operation, plus a call count by outcome.
 *
 * @internal
 */
export declare const observeOps: (system: string, impl: Readonly<Record<string, OpImpl>>) => Record<string, OpImpl>;
/**
 * Sees every call to an implemented external system. A story provides one, so
 * it can assert what each real call was sent and what it returned.
 *
 * @internal
 */
export interface CallRecorder {
    readonly record: (system: string, op: string, args: unknown, call: Effect.Effect<unknown, unknown, unknown>) => Effect.Effect<unknown, unknown, unknown>;
}
/** @internal */
export declare const CallRecorder: Context.Reference<CallRecorder | undefined>;
declare const ExternalSystemSchemaError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "ExternalSystemSchemaError";
} & Readonly<A>;
/**
 * A call to an external system broke its declared schema: the model sent
 * arguments the operation's `args` reject, or the adapter answered with a
 * value or error the operation's `success` or `error` reject. It is a defect,
 * not a business error, because the declaration and the implementation
 * disagree.
 */
export declare class ExternalSystemSchemaError extends ExternalSystemSchemaError_base<{
    readonly system: string;
    readonly op: string;
    /** The side of the call the schema rejected. */
    readonly part: "args" | "success" | "error";
    readonly message: string;
}> {
}
/** A built check: the value its schema accepts, or an {@link ExternalSystemSchemaError} defect. */
type Check = (value: unknown) => Exit.Exit<unknown>;
/** One operation's built checks. `args` and `success` are absent when it declares none. */
interface OpChecks {
    readonly args: Check | undefined;
    readonly success: Check | undefined;
    readonly error: Check;
}
/**
 * Build the checks for every operation of a system, once: its arguments, its
 * success value and its typed error.
 *
 * @internal
 */
export declare const compileChecks: (system: string, ops: Readonly<Record<string, OpSpec>>) => Effect.Effect<Readonly<Record<string, OpChecks>>>;
/**
 * Check every call against its operation's built checks: the arguments before
 * the implementation runs, and its success value or typed error after. A value
 * a schema rejects becomes an {@link ExternalSystemSchemaError} defect. Defects
 * pass through.
 *
 * @internal
 */
export declare const validateOps: (checks: Readonly<Record<string, OpChecks>>, impl: Readonly<Record<string, OpImpl>>) => Record<string, OpImpl>;
/**
 * Options for {@link ExternalSystemClass.toLayer}.
 */
export interface ToLayerOptions {
    /**
     * Check every call against the operation's schemas. Defaults to `true`.
     * Turn it off only when the check costs too much, for example on a large
     * payload an adapter already validates.
     */
    readonly validate?: boolean;
}
/**
 * One operation of an external system: its arguments, success value and business errors.
 * `error` is one schema, or a list of them when the vendor can refuse in several ways.
 */
export interface OpSpec {
    readonly args?: Fields;
    readonly success?: Fields | Schema.Top;
    readonly error?: Schema.Top | ReadonlyArray<Schema.Top>;
}
type ArgsOf<S extends OpSpec> = S["args"] extends Fields ? Schema.Struct<S["args"]>["Type"] : void;
type SuccessOf<S extends OpSpec> = S["success"] extends Schema.Top ? S["success"]["Type"] : S["success"] extends Fields ? Schema.Struct<S["success"]>["Type"] : void;
type ErrorOf<S extends OpSpec> = S["error"] extends ReadonlyArray<Schema.Top> ? S["error"][number]["Type"] : S["error"] extends Schema.Top ? S["error"]["Type"] : never;
/**
 * The service shape of an external system: one Effect-returning function per operation.
 */
export type Shape<Ops extends Record<string, OpSpec>> = {
    readonly [K in keyof Ops]: (args: ArgsOf<Ops[K]>) => Effect.Effect<SuccessOf<Ops[K]>, ErrorOf<Ops[K]>>;
};
/**
 * A reference to one external system operation, used by stories (`call`, `succeed`, `fail`).
 */
export interface Op<Args = unknown, Success = unknown, Error = unknown> {
    readonly kind: "ExternalSystemOp";
    readonly system: string;
    readonly op: string;
    readonly "~args"?: Args;
    readonly "~success"?: Success;
    readonly "~error"?: Error;
}
/**
 * Structural constraint satisfied by every external system class.
 */
export interface Any extends Context.Key<unknown, unknown> {
    readonly kind: "ExternalSystem";
    readonly annotations: Annotations;
    readonly systemName: string;
    readonly ops: Record<string, OpSpec>;
}
/** The requirement identifier of an external system class. */
export type Identifier<P extends Any> = P extends Context.Key<infer I, unknown> ? I : never;
/**
 * Type-level identity of an external system in an Effect's requirements.
 */
export interface ExternalSystemKey<Name extends string> {
    readonly "~alchemy/Domain/ExternalSystem": Name;
}
declare const RESERVED: readonly ["name", "length", "prototype", "kind", "systemName", "ops", "toLayer", "key", "annotations"];
type Reserved = (typeof RESERVED)[number];
/**
 * An outside system your model calls, such as a payment provider or a fraud
 * scorer, declared as the operations the model uses. It's an Effect service:
 * policies `yield*` it, an adapter implements it with `toLayer`, and stories
 * answer its calls themselves, so the model depends on what it asks for and
 * never on a vendor.
 *
 * ### Declaring an external system and an adapter
 * **Example:** A fraud scorer
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Effect from "effect/Effect";
 * import * as Schema from "effect/Schema";
 *
 * export class FraudCheck extends Domain.ExternalSystem("FraudCheck", {
 *   score: { args: { accountId: Schema.String, amount: Schema.Int }, success: { risk: Schema.Number } },
 * }) {}
 *
 * export const SiftFraudCheck = FraudCheck.toLayer(
 *   Effect.succeed({
 *     score: ({ amount }) => Effect.succeed({ risk: amount >= 80_000 ? 0.95 : 0.05 }),
 *   }),
 * );
 * ```
 *
 * ### Annotating external systems
 * The last argument is its annotations: data for what is built on the
 * model, read back as `X.annotations`. Add your own keys by augmenting
 * `Domain.Annotations`.
 *
 * Nothing a client calls shows it; it is for the people and the tools that
 * read the model, as `X.annotations`. `annotations` is the class's own
 * static, so no operation may take that name.
 *
 * **Example:** A description
 * ```typescript
 * export class Payments extends Domain.ExternalSystem(
 *   "Payments",
 *   { refund: { args: { settlementId: Schema.String, amount: Cents }, success: { refundId: Schema.String } } },
 *   { description: "The payment provider that refunds settlements." },
 * ) {}
 * ```
 *
 * @primitive
 */
export declare const make: <const Name extends string, const Ops extends Record<string, OpSpec>>(name: Name, ops: Ops & { readonly [K in Extract<keyof Ops, Reserved>]: never; }, annotations?: Annotations) => ExternalSystemClass<Name, Ops>;
/**
 * The class type returned by {@link make}.
 */
export type ExternalSystemClass<Name extends string, Ops extends Record<string, OpSpec>> = Context.ServiceClass<ExternalSystemKey<Name>, string, Shape<Ops>> & {
    readonly kind: "ExternalSystem";
    readonly annotations: Annotations;
    readonly systemName: Name;
    readonly ops: Ops;
    /**
     * Implement the external system with an Effect that builds its service.
     * Every call is checked against the operation's schemas unless
     * `validate: false`.
     */
    toLayer<E, R>(build: Effect.Effect<Shape<Ops>, E, R>, options?: ToLayerOptions): Layer.Layer<ExternalSystemKey<Name>, E, R>;
} & {
    readonly [K in keyof Ops]: Op<ArgsOf<Ops[K]>, SuccessOf<Ops[K]>, ErrorOf<Ops[K]>>;
};
/** @internal */
export declare const successSchema: (spec: OpSpec) => Schema.Top;
/**
 * The schema of an operation's declared `error`: the schema itself, a
 * `Schema.Union` of a list, or `Schema.Never` when it declares none.
 *
 * @internal
 */
export declare const errorSchema: (spec: OpSpec) => Schema.Top;
export {};
//# sourceMappingURL=ExternalSystem.d.ts.map