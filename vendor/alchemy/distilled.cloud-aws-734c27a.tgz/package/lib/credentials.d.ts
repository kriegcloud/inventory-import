/**
 * `@distilled.cloud/aws/Credentials` for Node, Bun and workers: everything
 * the browser entry exports, with the Node variants of `fromHttp`,
 * `fromInstanceMetadata` and `fromTemporaryCredentials` in place of the
 * browser ones, plus the providers that read `~/.aws` or run a process.
 * Each layer is defined in its provider's own file.
 */
export * from "./credentials.browser.ts";
import { type SdkError } from "@distilled.cloud/core/sdk-error";
import * as Layer from "effect/Layer";
import type * as __from_http_node from "./credential-providers/from-http.node.ts";
import type * as __from_ini from "./credential-providers/from-ini.ts";
import type * as __from_instance_metadata_node from "./credential-providers/from-instance-metadata.node.ts";
import type * as __from_login_credentials from "./credential-providers/from-login-credentials.ts";
import type * as __from_node_provider_chain from "./credential-providers/from-node-provider-chain.ts";
import type * as __from_process from "./credential-providers/from-process.ts";
import type * as __from_sso from "./credential-providers/from-sso.ts";
import type * as __from_temporary_credentials_node from "./credential-providers/from-temporary-credentials.node.ts";
import type * as __from_token_file from "./credential-providers/from-token-file.ts";
/** A provider loaded on first use: building its layer also fails if its module can't load. */
type WithLoadError<F> = F extends (...args: infer A) => Layer.Layer<infer S, infer E, infer R> ? (...args: A) => Layer.Layer<S, E | SdkError, R> : never;
export declare const fromHttp: WithLoadError<typeof __from_http_node.fromHttp>;
export declare const fromIni: WithLoadError<typeof __from_ini.fromIni>;
export declare const fromInstanceMetadata: WithLoadError<typeof __from_instance_metadata_node.fromInstanceMetadata>;
export declare const fromLoginCredentials: WithLoadError<typeof __from_login_credentials.fromLoginCredentials>;
export declare const fromChain: WithLoadError<typeof __from_node_provider_chain.fromChain>;
export declare const fromNodeProviderChain: WithLoadError<typeof __from_node_provider_chain.fromNodeProviderChain>;
export declare const fromProcess: WithLoadError<typeof __from_process.fromProcess>;
export declare const fromSSO: WithLoadError<typeof __from_sso.fromSSO>;
export declare const fromTemporaryCredentials: WithLoadError<typeof __from_temporary_credentials_node.fromTemporaryCredentials>;
export declare const fromTokenFile: WithLoadError<typeof __from_token_file.fromTokenFile>;
//# sourceMappingURL=credentials.d.ts.map