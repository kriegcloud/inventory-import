import type { BetterAuthOptions } from "better-auth";
import * as Effect from "effect/Effect";
import type { DatabaseService } from "./Database.ts";
import { BetterAuthMigrationError } from "./Errors.ts";
export interface MigrateOutput {
    tablesCreated: number;
    tablesAltered: number;
    indexesCreated: number;
}
export interface RegisterMigrationOptions {
    readonly id: string;
    /** The user's Better Auth options (without `database`). */
    readonly options: BetterAuthOptions;
    readonly db: DatabaseService;
    /** The user's `migrate` prop — `undefined` means default-on. */
    readonly migrate: boolean | undefined;
}
/**
 * Register the schema-migration Action for a `BetterAuth` instance.
 *
 * Actions run only during `alchemy deploy` (apply), re-run only when their
 * resolved input changes — here: the schema fingerprint, the database
 * identity, or the dialect — and their body gets the ambient stack
 * services, so `migrate.connect` can resolve resource Outputs and reach
 * the cloud.
 */
export declare const registerMigration: ({ id, options, db, migrate, }: RegisterMigrationOptions) => Effect.Effect<void>;
/**
 * Connect via the platform layer's `migrate.connect` and apply Better
 * Auth's schema migrations. Additive and idempotent — re-running against
 * an up-to-date database is a no-op.
 */
export declare const applyMigrations: (support: NonNullable<DatabaseService["migrate"]>, options: BetterAuthOptions) => Effect.Effect<{
    tablesCreated: number;
    tablesAltered: number;
    indexesCreated: number;
}, BetterAuthMigrationError, import("alchemy").RuntimeContext>;
/**
 * Stable fingerprint of the Better Auth schema derived from the user's
 * options (plugins, additionalFields, model renames, table indexes).
 * Changing the schema changes the fingerprint, which changes the
 * migration Action's input and re-runs it on the next deploy.
 */
export declare const schemaFingerprint: (options: BetterAuthOptions) => Effect.Effect<string>;
//# sourceMappingURL=Migrate.d.ts.map