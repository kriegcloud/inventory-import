import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DismissInsightForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    dismiss?: boolean | undefined;
}
export interface DismissInsightForAccountResponse {
}
export interface DismissInsightForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    dismiss?: boolean | undefined;
}
export interface DismissInsightForZoneResponse {
}
export type InsightsClassGetRequestIssueClassList = Array<string>;
export type InsightsClassGetRequestIssueClassNeqList = Array<string>;
export type InsightsClassGetRequestIssueTypeList = Array<string>;
export type InsightsClassGetRequestIssueTypeNeqList = Array<string>;
export type InsightsClassGetRequestProductList = Array<string>;
export type InsightsClassGetRequestProductNeqList = Array<string>;
export type InsightsClassGetRequestSeverityList = Array<string>;
export type InsightsClassGetRequestSeverityNeqList = Array<string>;
export type InsightsClassGetRequestSource = "cloudflare" | "riskrecon";
export type InsightsClassGetRequestSourceList = Array<InsightsClassGetRequestSource | (string & {})>;
export type InsightsClassGetRequestSubjectList = Array<string>;
export type InsightsClassGetRequestSubjectNeqList = Array<string>;
export interface GetInsightClassForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsClassGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsClassGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsClassGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsClassGetRequestIssueTypeNeqList | undefined;
    product?: InsightsClassGetRequestProductList | undefined;
    productNeq?: InsightsClassGetRequestProductNeqList | undefined;
    severity?: InsightsClassGetRequestSeverityList | undefined;
    severityNeq?: InsightsClassGetRequestSeverityNeqList | undefined;
    source?: InsightsClassGetRequestSourceList | undefined;
    subject?: InsightsClassGetRequestSubjectList | undefined;
    subjectNeq?: InsightsClassGetRequestSubjectNeqList | undefined;
}
export interface InsightsClassGetResultItem {
    count?: number | null | undefined;
    value?: string | null | undefined;
}
export type InsightsClassGetResultList = Array<InsightsClassGetResultItem>;
export type GetInsightClassResponse = InsightsClassGetResultList;
export interface GetInsightClassForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsClassGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsClassGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsClassGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsClassGetRequestIssueTypeNeqList | undefined;
    product?: InsightsClassGetRequestProductList | undefined;
    productNeq?: InsightsClassGetRequestProductNeqList | undefined;
    severity?: InsightsClassGetRequestSeverityList | undefined;
    severityNeq?: InsightsClassGetRequestSeverityNeqList | undefined;
    source?: InsightsClassGetRequestSourceList | undefined;
    subject?: InsightsClassGetRequestSubjectList | undefined;
    subjectNeq?: InsightsClassGetRequestSubjectNeqList | undefined;
}
export interface GetInsightContextRequest {
    /** Identifier. */
    accountId: string;
    issueId: string;
}
export type InsightsContextGetResultMap = {
    [key: string]: unknown | undefined;
};
export type GetInsightContextResponse = InsightsContextGetResultMap;
export type InsightsSeverityGetRequestIssueClassList = Array<string>;
export type InsightsSeverityGetRequestIssueClassNeqList = Array<string>;
export type InsightsSeverityGetRequestIssueTypeList = Array<string>;
export type InsightsSeverityGetRequestIssueTypeNeqList = Array<string>;
export type InsightsSeverityGetRequestProductList = Array<string>;
export type InsightsSeverityGetRequestProductNeqList = Array<string>;
export type InsightsSeverityGetRequestSeverityList = Array<string>;
export type InsightsSeverityGetRequestSeverityNeqList = Array<string>;
export type InsightsSeverityGetRequestSource = "cloudflare" | "riskrecon";
export type InsightsSeverityGetRequestSourceList = Array<InsightsSeverityGetRequestSource | (string & {})>;
export type InsightsSeverityGetRequestSubjectList = Array<string>;
export type InsightsSeverityGetRequestSubjectNeqList = Array<string>;
export interface GetInsightSeverityForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsSeverityGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsSeverityGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsSeverityGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsSeverityGetRequestIssueTypeNeqList | undefined;
    product?: InsightsSeverityGetRequestProductList | undefined;
    productNeq?: InsightsSeverityGetRequestProductNeqList | undefined;
    severity?: InsightsSeverityGetRequestSeverityList | undefined;
    severityNeq?: InsightsSeverityGetRequestSeverityNeqList | undefined;
    source?: InsightsSeverityGetRequestSourceList | undefined;
    subject?: InsightsSeverityGetRequestSubjectList | undefined;
    subjectNeq?: InsightsSeverityGetRequestSubjectNeqList | undefined;
}
export type InsightsSeverityGetResultItem = InsightsClassGetResultItem;
export type InsightsSeverityGetResultList = Array<InsightsClassGetResultItem>;
export type GetInsightSeverityResponse = InsightsSeverityGetResultList;
export interface GetInsightSeverityForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsSeverityGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsSeverityGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsSeverityGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsSeverityGetRequestIssueTypeNeqList | undefined;
    product?: InsightsSeverityGetRequestProductList | undefined;
    productNeq?: InsightsSeverityGetRequestProductNeqList | undefined;
    severity?: InsightsSeverityGetRequestSeverityList | undefined;
    severityNeq?: InsightsSeverityGetRequestSeverityNeqList | undefined;
    source?: InsightsSeverityGetRequestSourceList | undefined;
    subject?: InsightsSeverityGetRequestSubjectList | undefined;
    subjectNeq?: InsightsSeverityGetRequestSubjectNeqList | undefined;
}
export type InsightsTypeGetRequestIssueClassList = Array<string>;
export type InsightsTypeGetRequestIssueClassNeqList = Array<string>;
export type InsightsTypeGetRequestIssueTypeList = Array<string>;
export type InsightsTypeGetRequestIssueTypeNeqList = Array<string>;
export type InsightsTypeGetRequestProductList = Array<string>;
export type InsightsTypeGetRequestProductNeqList = Array<string>;
export type InsightsTypeGetRequestSeverityList = Array<string>;
export type InsightsTypeGetRequestSeverityNeqList = Array<string>;
export type InsightsTypeGetRequestSource = "cloudflare" | "riskrecon";
export type InsightsTypeGetRequestSourceList = Array<InsightsTypeGetRequestSource | (string & {})>;
export type InsightsTypeGetRequestSubjectList = Array<string>;
export type InsightsTypeGetRequestSubjectNeqList = Array<string>;
export interface GetInsightTypeForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsTypeGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsTypeGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsTypeGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsTypeGetRequestIssueTypeNeqList | undefined;
    product?: InsightsTypeGetRequestProductList | undefined;
    productNeq?: InsightsTypeGetRequestProductNeqList | undefined;
    severity?: InsightsTypeGetRequestSeverityList | undefined;
    severityNeq?: InsightsTypeGetRequestSeverityNeqList | undefined;
    source?: InsightsTypeGetRequestSourceList | undefined;
    subject?: InsightsTypeGetRequestSubjectList | undefined;
    subjectNeq?: InsightsTypeGetRequestSubjectNeqList | undefined;
}
export type InsightsTypeGetResultItem = InsightsClassGetResultItem;
export type InsightsTypeGetResultList = Array<InsightsClassGetResultItem>;
export type GetInsightTypeResponse = InsightsTypeGetResultList;
export interface GetInsightTypeForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsTypeGetRequestIssueClassList | undefined;
    issueClassNeq?: InsightsTypeGetRequestIssueClassNeqList | undefined;
    issueType?: InsightsTypeGetRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsTypeGetRequestIssueTypeNeqList | undefined;
    product?: InsightsTypeGetRequestProductList | undefined;
    productNeq?: InsightsTypeGetRequestProductNeqList | undefined;
    severity?: InsightsTypeGetRequestSeverityList | undefined;
    severityNeq?: InsightsTypeGetRequestSeverityNeqList | undefined;
    source?: InsightsTypeGetRequestSourceList | undefined;
    subject?: InsightsTypeGetRequestSubjectList | undefined;
    subjectNeq?: InsightsTypeGetRequestSubjectNeqList | undefined;
}
export type InsightsAuditLogsListByInsightRequestFieldChanged = "status" | "user_classification";
export type InsightsAuditLogsListByInsightRequestOrder = "asc" | "desc";
export interface ListByInsightInsightAuditLogForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string | undefined;
    /** Filter by the actor that made the change. */
    changedBy?: string | undefined;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string | undefined;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightRequestFieldChanged | (string & {}) | undefined;
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListByInsightRequestOrder | (string & {}) | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string | undefined;
}
export type InsightsAuditLogsListByInsightResultItemFieldChanged = "status" | "user_classification";
export interface InsightsAuditLogsListByInsightResultItem {
    /** UUIDv7 identifier for the audit log entry, time-ordered. */
    id?: string | null | undefined;
    /** The timestamp when the change occurred. */
    changedAt?: string | null | undefined;
    /** The actor that made the change. 'system' for automated changes, or a user identifier. */
    changedBy?: string | null | undefined;
    /** The value of the field after the change. Null if the field was cleared. */
    currentValue?: string | null | undefined;
    /** The field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightResultItemFieldChanged | null | undefined;
    /** The ID of the insight this audit log entry relates to. */
    issueId?: string | null | undefined;
    /** The value of the field before the change. Null if the field was not previously set. */
    previousValue?: string | null | undefined;
    /** Optional rationale provided for the change. */
    rationale?: string | null | undefined;
    /** The zone ID associated with the insight. Only present for zone-level insights. */
    zoneId?: number | null | undefined;
}
export type InsightsAuditLogsListByInsightResultList = Array<InsightsAuditLogsListByInsightResultItem>;
export interface ListByInsightInsightAuditLogResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InsightsAuditLogsListByInsightResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListByInsightInsightAuditLogForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string | undefined;
    /** Filter by the actor that made the change. */
    changedBy?: string | undefined;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string | undefined;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListByInsightRequestFieldChanged | (string & {}) | undefined;
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListByInsightRequestOrder | (string & {}) | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string | undefined;
}
export type InsightsAuditLogsListRequestFieldChanged = "status" | "user_classification";
export type InsightsAuditLogsListRequestOrder = "asc" | "desc";
export interface ListInsightAuditLogsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string | undefined;
    /** Filter by the actor that made the change. */
    changedBy?: string | undefined;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string | undefined;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListRequestFieldChanged | (string & {}) | undefined;
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListRequestOrder | (string & {}) | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string | undefined;
}
export type InsightsAuditLogsListResultItemFieldChanged = "status" | "user_classification";
export interface InsightsAuditLogsListResultItem {
    /** UUIDv7 identifier for the audit log entry, time-ordered. */
    id?: string | null | undefined;
    /** The timestamp when the change occurred. */
    changedAt?: string | null | undefined;
    /** The actor that made the change. 'system' for automated changes, or a user identifier. */
    changedBy?: string | null | undefined;
    /** The value of the field after the change. Null if the field was cleared. */
    currentValue?: string | null | undefined;
    /** The field that was changed. */
    fieldChanged?: InsightsAuditLogsListResultItemFieldChanged | null | undefined;
    /** The ID of the insight this audit log entry relates to. */
    issueId?: string | null | undefined;
    /** The value of the field before the change. Null if the field was not previously set. */
    previousValue?: string | null | undefined;
    /** Optional rationale provided for the change. */
    rationale?: string | null | undefined;
    /** The zone ID associated with the insight. Only present for zone-level insights. */
    zoneId?: number | null | undefined;
}
export type InsightsAuditLogsListResultList = Array<InsightsAuditLogsListResultItem>;
export interface ListInsightAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InsightsAuditLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListInsightAuditLogsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Filter entries changed before this timestamp (RFC 3339). */
    before?: string | undefined;
    /** Filter by the actor that made the change. */
    changedBy?: string | undefined;
    /** Opaque cursor for pagination. Use the cursor value from result_info of the previous response. */
    cursor?: string | undefined;
    /** Filter by the field that was changed. */
    fieldChanged?: InsightsAuditLogsListRequestFieldChanged | (string & {}) | undefined;
    /** Sort order for results. Use 'asc' for oldest first or 'desc' for newest first. */
    order?: InsightsAuditLogsListRequestOrder | (string & {}) | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Filter entries changed at or after this timestamp (RFC 3339). */
    since?: string | undefined;
}
export type InsightsListRequestIssueClassList = Array<string>;
export type InsightsListRequestIssueClassNeqList = Array<string>;
export type InsightsListRequestIssueTypeList = Array<string>;
export type InsightsListRequestIssueTypeNeqList = Array<string>;
export type InsightsListRequestProductList = Array<string>;
export type InsightsListRequestProductNeqList = Array<string>;
export type InsightsListRequestSeverityList = Array<string>;
export type InsightsListRequestSeverityNeqList = Array<string>;
export type InsightsListRequestSource = "cloudflare" | "riskrecon";
export type InsightsListRequestSourceList = Array<InsightsListRequestSource | (string & {})>;
export type InsightsListRequestSubjectList = Array<string>;
export type InsightsListRequestSubjectNeqList = Array<string>;
export interface ListInsightsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsListRequestIssueClassList | undefined;
    issueClassNeq?: InsightsListRequestIssueClassNeqList | undefined;
    issueType?: InsightsListRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsListRequestIssueTypeNeqList | undefined;
    /** Specifies the current page within paginated list of results. */
    page?: number | undefined;
    /** Sets the number of results per page of results. */
    perPage?: number | undefined;
    product?: InsightsListRequestProductList | undefined;
    productNeq?: InsightsListRequestProductNeqList | undefined;
    severity?: InsightsListRequestSeverityList | undefined;
    severityNeq?: InsightsListRequestSeverityNeqList | undefined;
    source?: InsightsListRequestSourceList | undefined;
    subject?: InsightsListRequestSubjectList | undefined;
    subjectNeq?: InsightsListRequestSubjectNeqList | undefined;
}
export type InsightsListResponseIssuesItemIssueType = "compliance_violation" | "email_security" | "exposed_infrastructure" | "insecure_configuration" | "weak_authentication" | "configuration_suggestion";
export interface InsightsListResponseIssuesItemPayload {
    /** Describes the method used to detect insight. */
    detectionMethod?: string | null | undefined;
    zoneTag?: string | null | undefined;
}
export type InsightsListResponseIssuesItemSeverity = "Low" | "Moderate" | "Critical";
export type InsightsListResponseIssuesItemSource = "cloudflare" | "riskrecon";
export type InsightsListResponseIssuesItemStatus = "active" | "resolved";
export type InsightsListResponseIssuesItemUserClassification = "false_positive" | "accept_risk" | "other";
export interface InsightsListResponseIssuesItem {
    id?: string | null | undefined;
    dismissed?: boolean | null | undefined;
    /** Indicates whether the insight has a large payload that requires fetching via the context endpoint. */
    hasExtendedContext?: boolean | null | undefined;
    issueClass?: string | null | undefined;
    issueType?: InsightsListResponseIssuesItemIssueType | null | undefined;
    payload?: InsightsListResponseIssuesItemPayload | null | undefined;
    resolveLink?: string | null | undefined;
    resolveText?: string | null | undefined;
    severity?: InsightsListResponseIssuesItemSeverity | null | undefined;
    since?: string | null | undefined;
    /** Who generated the insight. `cloudflare` for Cloudflare-generated insights, otherwise the partner. */
    source?: InsightsListResponseIssuesItemSource | null | undefined;
    /** The current status of the insight. */
    status?: InsightsListResponseIssuesItemStatus | null | undefined;
    subject?: string | null | undefined;
    timestamp?: string | null | undefined;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    userClassification?: InsightsListResponseIssuesItemUserClassification | null | undefined;
}
export type InsightsListResponseIssuesList = Array<InsightsListResponseIssuesItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListInsightsResponse {
    /** Indicates the total number of results. */
    count?: number | null | undefined;
    issues?: InsightsListResponseIssuesList | null | undefined;
    /** Specifies the current page within paginated list of results. */
    page?: number | null | undefined;
    /** Sets the number of results per page of results. */
    perPage?: number | null | undefined;
}
export interface ListInsightsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    dismissed?: boolean | undefined;
    issueClass?: InsightsListRequestIssueClassList | undefined;
    issueClassNeq?: InsightsListRequestIssueClassNeqList | undefined;
    issueType?: InsightsListRequestIssueTypeList | undefined;
    issueTypeNeq?: InsightsListRequestIssueTypeNeqList | undefined;
    /** Specifies the current page within paginated list of results. */
    page?: number | undefined;
    /** Sets the number of results per page of results. */
    perPage?: number | undefined;
    product?: InsightsListRequestProductList | undefined;
    productNeq?: InsightsListRequestProductNeqList | undefined;
    severity?: InsightsListRequestSeverityList | undefined;
    severityNeq?: InsightsListRequestSeverityNeqList | undefined;
    source?: InsightsListRequestSourceList | undefined;
    subject?: InsightsListRequestSubjectList | undefined;
    subjectNeq?: InsightsListRequestSubjectNeqList | undefined;
}
export type InsightsClassificationUpdateRequestClassification = "false_positive" | "accept_risk" | "other";
export interface PatchInsightClassificationForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    issueId: string;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    classification?: InsightsClassificationUpdateRequestClassification | (string & {}) | undefined;
    /** Rationale for the classification change. Required when classification is 'accept_risk' or 'other'. */
    rationale?: string | undefined;
}
export interface PatchInsightClassificationForAccountResponse {
}
export interface PatchInsightClassificationForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    issueId: string;
    /** User-defined classification for the insight. Can be 'false_positive', 'accept_risk', 'other', or null. */
    classification?: InsightsClassificationUpdateRequestClassification | (string & {}) | undefined;
    /** Rationale for the classification change. Required when classification is 'accept_risk' or 'other'. */
    rationale?: string | undefined;
}
export interface PatchInsightClassificationForZoneResponse {
}
export type DismissInsightForAccountError = CloudflareOpError;
/** Archives a Security Center insight for an account or zone, removing it from the active insights list while preserving historical data. */
export declare const dismissInsightForAccount: API.OperationMethod<DismissInsightForAccountRequest, DismissInsightForAccountResponse, DismissInsightForAccountError, CloudflareOpContext>;
export type DismissInsightForZoneError = CloudflareOpError;
/** Archives a Security Center insight for an account or zone, removing it from the active insights list while preserving historical data. */
export declare const dismissInsightForZone: API.OperationMethod<DismissInsightForZoneRequest, DismissInsightForZoneResponse, DismissInsightForZoneError, CloudflareOpContext>;
export type GetInsightClassForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by classification class. */
export declare const getInsightClassForAccount: API.OperationMethod<GetInsightClassForAccountRequest, GetInsightClassResponse, GetInsightClassForAccountError, CloudflareOpContext>;
export type GetInsightClassForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by classification class. */
export declare const getInsightClassForZone: API.OperationMethod<GetInsightClassForZoneRequest, GetInsightClassResponse, GetInsightClassForZoneError, CloudflareOpContext>;
export type GetInsightContextError = CloudflareOpError;
/** Returns the full context payload for an insight. This endpoint is used for insights with large payloads that are not included inline in the list response. */
export declare const getInsightContext: API.OperationMethod<GetInsightContextRequest, GetInsightContextResponse, GetInsightContextError, CloudflareOpContext>;
export type GetInsightSeverityForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by severity level (critical, high, medium, low). */
export declare const getInsightSeverityForAccount: API.OperationMethod<GetInsightSeverityForAccountRequest, GetInsightSeverityResponse, GetInsightSeverityForAccountError, CloudflareOpContext>;
export type GetInsightSeverityForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by severity level (critical, high, medium, low). */
export declare const getInsightSeverityForZone: API.OperationMethod<GetInsightSeverityForZoneRequest, GetInsightSeverityResponse, GetInsightSeverityForZoneError, CloudflareOpContext>;
export type GetInsightTypeForAccountError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by insight type. */
export declare const getInsightTypeForAccount: API.OperationMethod<GetInsightTypeForAccountRequest, GetInsightTypeResponse, GetInsightTypeForAccountError, CloudflareOpContext>;
export type GetInsightTypeForZoneError = CloudflareOpError;
/** Retrieves Security Center insight counts aggregated by insight type. */
export declare const getInsightTypeForZone: API.OperationMethod<GetInsightTypeForZoneRequest, GetInsightTypeResponse, GetInsightTypeForZoneError, CloudflareOpContext>;
export type ListByInsightInsightAuditLogForAccountError = CloudflareOpError;
/** Lists audit log entries for a specific Security Center insight, showing changes to its status and classification over time. */
export declare const listByInsightInsightAuditLogForAccount: API.PaginatedOperationMethod<ListByInsightInsightAuditLogForAccountRequest, ListByInsightInsightAuditLogResponse, ListByInsightInsightAuditLogForAccountError, CloudflareOpContext, InsightsAuditLogsListByInsightResultItem>;
export type ListByInsightInsightAuditLogForZoneError = CloudflareOpError;
/** Lists audit log entries for a specific Security Center insight, showing changes to its status and classification over time. */
export declare const listByInsightInsightAuditLogForZone: API.PaginatedOperationMethod<ListByInsightInsightAuditLogForZoneRequest, ListByInsightInsightAuditLogResponse, ListByInsightInsightAuditLogForZoneError, CloudflareOpContext, InsightsAuditLogsListByInsightResultItem>;
export type ListInsightAuditLogsForAccountError = CloudflareOpError;
/** Lists audit log entries for all Security Center insights in the account or zone, showing changes to insight status and classification. */
export declare const listInsightAuditLogsForAccount: API.PaginatedOperationMethod<ListInsightAuditLogsForAccountRequest, ListInsightAuditLogsResponse, ListInsightAuditLogsForAccountError, CloudflareOpContext, InsightsAuditLogsListResultItem>;
export type ListInsightAuditLogsForZoneError = CloudflareOpError;
/** Lists audit log entries for all Security Center insights in the account or zone, showing changes to insight status and classification. */
export declare const listInsightAuditLogsForZone: API.PaginatedOperationMethod<ListInsightAuditLogsForZoneRequest, ListInsightAuditLogsResponse, ListInsightAuditLogsForZoneError, CloudflareOpContext, InsightsAuditLogsListResultItem>;
export type ListInsightsForAccountError = CloudflareOpError;
/** Lists all Security Center insights for the account or zone, showing security findings and recommendations. */
export declare const listInsightsForAccount: API.OperationMethod<ListInsightsForAccountRequest, ListInsightsResponse, ListInsightsForAccountError, CloudflareOpContext>;
export type ListInsightsForZoneError = CloudflareOpError;
/** Lists all Security Center insights for the account or zone, showing security findings and recommendations. */
export declare const listInsightsForZone: API.OperationMethod<ListInsightsForZoneRequest, ListInsightsResponse, ListInsightsForZoneError, CloudflareOpContext>;
export type PatchInsightClassificationForAccountError = CloudflareOpError;
/** Updates the user classification for a Security Center insight. Valid values are 'false_positive' or 'accept_risk'. To reset, set classification to null. Cannot change directly between classification values - must reset to null first. */
export declare const patchInsightClassificationForAccount: API.OperationMethod<PatchInsightClassificationForAccountRequest, PatchInsightClassificationForAccountResponse, PatchInsightClassificationForAccountError, CloudflareOpContext>;
export type PatchInsightClassificationForZoneError = CloudflareOpError;
/** Updates the user classification for a Security Center insight. Valid values are 'false_positive' or 'accept_risk'. To reset, set classification to null. Cannot change directly between classification values - must reset to null first. */
export declare const patchInsightClassificationForZone: API.OperationMethod<PatchInsightClassificationForZoneRequest, PatchInsightClassificationForZoneResponse, PatchInsightClassificationForZoneError, CloudflareOpContext>;
//# sourceMappingURL=security_center.d.ts.map