/**
 * GitHub credentials -- hand-written.
 *
 * The `Credentials` service resolves `{ token, apiBaseUrl, userAgent }` per
 * request; the protocol layer formats the `Authorization: Bearer <token>`
 * header from it.
 *
 * The token may be a personal access token (classic or fine-grained), a
 * GitHub App installation token, or the `GITHUB_TOKEN` an Actions run is
 * handed -- the REST API accepts all of them as bearer tokens. To
 * authenticate as a GitHub App, use `@distilled.cloud/github/App`, which
 * mints, caches and refreshes the App's JWT and installation tokens.
 */
import * as EffectConfig from "@distilled.cloud/core/config";
import { ConfigError } from "@distilled.cloud/core/errors";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type { GithubAppAuthError } from "./errors.ts";

/** github.com's REST API root. */
export const DEFAULT_API_BASE_URL = "https://api.github.com";

/**
 * GitHub requires every request to carry a User-Agent and rejects those
 * that don't (403). Callers on GitHub Enterprise Server point
 * `apiBaseUrl` at `https://HOSTNAME/api/v3`.
 */
export const DEFAULT_USER_AGENT = "distilled.cloud-github";

export interface Config {
  readonly token: Redacted.Redacted<string>;
  readonly apiBaseUrl: string;
  readonly userAgent: string;
  /**
   * When `token` was minted, in epoch milliseconds. GitHub can refuse a
   * token it minted a moment ago while the token replicates, so the
   * protocol sends a request that fails with 401 again for up to five
   * seconds after this time. Leave it out for long-lived tokens.
   */
  readonly issuedAt?: number;
}

export class Credentials
  extends /*@__PURE__*/ Context.Service<
    Credentials,
    Effect.Effect<Config, ConfigError | GithubAppAuthError>
  >()("GithubCredentials") {}

const envConfig = /*@__PURE__*/ EffectConfig.all({
  // `GITHUB_TOKEN` is what Actions injects; `GH_TOKEN` is the gh CLI's
  // spelling. Either works, GITHUB_TOKEN first.
  token: /*@__PURE__*/ EffectConfig.String("GITHUB_TOKEN").pipe(
    /*@__PURE__*/ EffectConfig.orElse(() => EffectConfig.String("GH_TOKEN")),
  ),
  // Actions sets GITHUB_API_URL; GHES runners set it to their own host.
  apiBaseUrl: /*@__PURE__*/ EffectConfig.String("GITHUB_API_URL").pipe(
    /*@__PURE__*/ EffectConfig.withDefault(DEFAULT_API_BASE_URL),
  ),
  userAgent: /*@__PURE__*/ EffectConfig.String("GITHUB_USER_AGENT").pipe(
    /*@__PURE__*/ EffectConfig.withDefault(DEFAULT_USER_AGENT),
  ),
});

export const CredentialsFromEnv = /*@__PURE__*/ Layer.succeed(
  Credentials,
  /*@__PURE__*/ envConfig.pipe(
    /*@__PURE__*/ Effect.mapError(
      () =>
        new ConfigError({
          message: "GITHUB_TOKEN (or GH_TOKEN) environment variable is required",
        }),
    ),
    /*@__PURE__*/ Effect.map(({ token, apiBaseUrl, userAgent }) => ({
      token: Redacted.make(token),
      apiBaseUrl,
      userAgent,
    })),
  ),
);

/** Convenience layer from a redacted token + optional base URL / User-Agent. */
export const credentials = (config: {
  readonly token: Redacted.Redacted<string>;
  readonly apiBaseUrl?: string;
  readonly userAgent?: string;
}): Layer.Layer<Credentials> =>
  Layer.succeed(
    Credentials,
    Effect.succeed({
      token: config.token,
      apiBaseUrl: config.apiBaseUrl ?? DEFAULT_API_BASE_URL,
      userAgent: config.userAgent ?? DEFAULT_USER_AGENT,
    }),
  );
