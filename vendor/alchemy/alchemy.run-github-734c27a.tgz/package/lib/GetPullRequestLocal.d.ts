import * as Layer from "effect/Layer";
import type { Credentials } from "./Credentials.ts";
import { GetPullRequest } from "./GetPullRequest.ts";
/**
 * Implementation of {@link GetPullRequest} with the provider's current credentials.
 * Provide it on an `Action` or another deploy-time Effect.
 *
 * @layer
 * @product Pull Request
 * @provides GitHub.GetPullRequest
 */
export declare const GetPullRequestLocal: Layer.Layer<GetPullRequest, never, Credentials>;
//# sourceMappingURL=GetPullRequestLocal.d.ts.map