import type { Term } from "./Smt.ts";
import type { Eval, Run, Site, V } from "./Value.ts";
/** What the library models need from the interpreter. */
export interface Host {
    readonly current: {
        run: Run;
    };
    readonly call: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
    /** What `yield*` on the value gives. */
    readonly settle: (value: V, site: Site) => Eval<V>;
    /** Whether a value is truthy on this path. */
    readonly decide: (value: V, site: Site) => Eval<boolean>;
    /** Whether two values are `===`, as a value: known, or a condition of the inputs. */
    readonly equal: (a: V, b: V, site: Site) => Eval<V>;
    /** A list with its items, when the value is one. */
    readonly force: (value: V) => V;
    /** An array's method that takes a function, such as `map`. */
    readonly array: (name: string, items: ReadonlyArray<V>, fn: V, initial: V | undefined, site: Site) => Eval<V>;
    /** The request contexts provided around the code being run, by tag. */
    readonly provided: Map<unknown, V>;
    /** Models a caller adds, by `module:path`. They come before the prover's own. */
    readonly extra: ReadonlyMap<string, Model>;
}
/** What a library function does to symbolic values. */
export type Model = (args: ReadonlyArray<V>, site: Site) => Eval<V>;
/**
 * The library functions the prover knows, each written once as what it does
 * to a symbolic value. A call to any other library function is not
 * translated, and the report names the call.
 */
export declare const make: (host: Host) => {
    opticMember: (optic: V & {
        readonly _tag: "Optic";
    }, key: string) => V | undefined;
    valueOf: (lib: V & {
        readonly _tag: "Lib";
    }) => V | undefined;
    call: (lib: V & {
        readonly _tag: "Lib";
    }, args: ReadonlyArray<V>, site: Site) => Eval<V>;
};
/** A number as a solver term, or `undefined` when the value is not a number. */
export declare const numeric: (v: V) => Term | undefined;
/** Two numbers in one sort: an integer next to a real becomes a real. */
export declare const promote: (a: Term, b: Term) => readonly [Term, Term];
//# sourceMappingURL=Library.d.ts.map