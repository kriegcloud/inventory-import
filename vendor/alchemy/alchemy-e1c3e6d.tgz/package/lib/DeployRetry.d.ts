import * as Ref from "effect/Ref";
import * as Schedule from "effect/Schedule";
/**
 * A distilled retry factory (`@distilled.cloud/core/retry` `Factory`). Typed
 * here so this module does not depend on distilled.
 */
export type Factory = (lastError: Ref.Ref<unknown>) => {
    readonly while?: (error: unknown) => boolean;
    readonly schedule?: Schedule.Schedule<unknown>;
};
/** Most retries after the first attempt. */
export declare const MAX_RETRIES = 8;
/**
 * Whether a deploy should retry `error`: anything marked retryable, plus the
 * categories that describe a transient failure, plus transport failures.
 */
export declare const isTransient: (error: unknown) => boolean;
/** The deploy policy, for `Layer.succeed(<SDK>.Retry, policy)`. */
export declare const policy: Factory;
//# sourceMappingURL=DeployRetry.d.ts.map