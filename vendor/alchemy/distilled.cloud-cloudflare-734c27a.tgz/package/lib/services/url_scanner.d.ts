import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type ScansBulkCreateRequestBodyItemCustomHeadersMap = {
    [key: string]: string | undefined;
};
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export type ScansBulkCreateRequestBodyItemScreenshotsResolutionsList = Array<ScansBulkCreateRequestBodyItemScreenshotsResolutionsItem | (string & {})>;
export type ScansBulkCreateRequestBodyItemVisibility = "Public" | "Unlisted";
export interface ScansBulkCreateRequestBodyItem {
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean | undefined;
    customagent?: string | undefined;
    /** Set custom headers. */
    customHeaders?: ScansBulkCreateRequestBodyItemCustomHeadersMap | undefined;
    referer?: string | undefined;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansBulkCreateRequestBodyItemScreenshotsResolutionsList | undefined;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansBulkCreateRequestBodyItemVisibility | (string & {}) | undefined;
}
export type ScansBulkCreateRequestBodyList = Array<ScansBulkCreateRequestBodyItem>;
export interface BulkCreateScansRequest {
    /** Account ID. */
    accountId: string;
    /** List of urls to scan (up to a 100). */
    body?: ScansBulkCreateRequestBodyList | undefined;
}
export type BulkCreateScansResponse = string;
export type ScansCreateRequestCountry = "AE" | "AL" | "AM" | "AO" | "AR" | "AT" | "AU" | "AZ" | "BB" | "BD" | "BE" | "BF" | "BG" | "BH" | "BN" | "BO" | "BR" | "BT" | "BW" | "BY" | "CA" | "CD" | "CH" | "CI" | "CL" | "CM" | "CO" | "CR" | "CW" | "CY" | "CZ" | "DE" | "DJ" | "DK" | "DO" | "DZ" | "EC" | "EE" | "EG" | "ES" | "ET" | "FI" | "FJ" | "FR" | "GB" | "GD" | "GE" | "GH" | "GR" | "GT" | "GU" | "GY" | "HK" | "HN" | "HR" | "HT" | "HU" | "ID" | "IE" | "IL" | "IN" | "IQ" | "IS" | "IT" | "JM" | "JO" | "JP" | "KE" | "KG" | "KH" | "KR" | "KW" | "KZ" | "LA" | "LB" | "LK" | "LR" | "LT" | "LU" | "LV" | "MA" | "MD" | "MG" | "MK" | "MM" | "MN" | "MO" | "MT" | "MU" | "MV" | "MW" | "MX" | "MY" | "MZ" | "NA" | "NC" | "NG" | "NL" | "NO" | "NP" | "NZ" | "OM" | "PA" | "PE" | "PF" | "PH" | "PK" | "PL" | "PR" | "PS" | "PT" | "PY" | "QA" | "RE" | "RO" | "RS" | "RU" | "RW" | "SA" | "SE" | "SG" | "SI" | "SK" | "SN" | "SR" | "TH" | "TJ" | "TN" | "TR" | "TT" | "TW" | "TZ" | "UA" | "UG" | "US" | "UZ" | "VN" | "ZA" | "ZM" | "ZW";
export type ScansCreateRequestCustomHeadersMap = {
    [key: string]: string | undefined;
};
export type ScansCreateRequestScreenshotsResolutionsItem = "desktop" | "mobile" | "tablet";
export type ScansCreateRequestScreenshotsResolutionsList = Array<ScansCreateRequestScreenshotsResolutionsItem | (string & {})>;
export type ScansCreateRequestVisibility = "Public" | "Unlisted";
export interface CreateScanRequest {
    /** Account ID. */
    accountId: string;
    url: string;
    /** Enable agent readiness checks. */
    agentReadiness?: boolean | undefined;
    /** Country to geo egress from */
    country?: ScansCreateRequestCountry | (string & {}) | undefined;
    customagent?: string | undefined;
    /** Set custom headers. */
    customHeaders?: ScansCreateRequestCustomHeadersMap | undefined;
    referer?: string | undefined;
    /** Take multiple screenshots targeting different device types. */
    screenshotsResolutions?: ScansCreateRequestScreenshotsResolutionsList | undefined;
    /** The option `Public` means it will be included in listings like recent scans and search results. `Unlisted` means it will not be included in the aforementioned listings, users will need to have the scan's ID to access it. A a scan will be automatically marked as unlisted if it fails, if it contains potential PII or other sensitive material. */
    visibility?: ScansCreateRequestVisibility | (string & {}) | undefined;
}
export type CreateScanResponse = string;
export interface DomScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface DomScanResponse {
}
export interface GetResponsRequest {
    /** Account ID. */
    accountId: string;
    /** Response hash. */
    responseId: string;
}
export interface GetResponsResponse {
}
export interface GetScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface ScansGetResponseDataConsoleItemMessage {
    level: string;
    source: string;
    text: string;
    url: string;
}
export interface ScansGetResponseDataConsoleItem {
    message: ScansGetResponseDataConsoleItemMessage;
}
export type ScansGetResponseDataConsoleList = Array<ScansGetResponseDataConsoleItem>;
export interface ScansGetResponseDataCookiesItem {
    domain: string;
    expires: number;
    httpOnly: boolean;
    name: string;
    path: string;
    priority: string;
    sameParty: boolean;
    secure: boolean;
    session: boolean;
    size: number;
    sourcePort: number;
    sourceScheme: string;
    value: string;
}
export type ScansGetResponseDataCookiesList = Array<ScansGetResponseDataCookiesItem>;
export interface ScansGetResponseDataGlobalsItem {
    prop: string;
    type: string;
}
export type ScansGetResponseDataGlobalsList = Array<ScansGetResponseDataGlobalsItem>;
export interface ScansGetResponseDataLinksItem {
    href: string;
    text: string;
}
export type ScansGetResponseDataLinksList = Array<ScansGetResponseDataLinksItem>;
export interface ScansGetResponseDataPerformanceItem {
    duration: number;
    entryType: string;
    name: string;
    startTime: number;
}
export type ScansGetResponseDataPerformanceList = Array<ScansGetResponseDataPerformanceItem>;
export interface ScansGetResponseDataRequestsItemRequestInitiator {
    host: string;
    type: string;
    url: string;
}
export interface ScansGetResponseDataRequestsItemRequestRequest {
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
    headers?: unknown | null | undefined;
}
export interface ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem {
    name: string;
    value: string;
}
export type ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansGetResponseDataRequestsItemRequestRedirectResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityHeaders: ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null | undefined;
}
export interface ScansGetResponseDataRequestsItemRequest {
    documentURL: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestInitiator;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestRequest;
    requestId: string;
    type: string;
    wallTime: number;
    frameId?: string | null | undefined;
    loaderId?: string | null | undefined;
    primaryRequest?: boolean | null | undefined;
    redirectResponse?: ScansGetResponseDataRequestsItemRequestRedirectResponse | null | undefined;
}
export interface ScansGetResponseDataRequestsItemResponseAsn {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
    org: string;
}
export type ScansGetResponseDataRequestsItemResponseGeoipLlList = Array<number>;
export interface ScansGetResponseDataRequestsItemResponseGeoip {
    city: string;
    country: string;
    countryName: string;
    geonameId: string;
    ll: ScansGetResponseDataRequestsItemResponseGeoipLlList;
    region: string;
}
export type ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList = Array<string>;
export interface ScansGetResponseDataRequestsItemResponseResponseSecurityDetails {
    certificateId: number;
    certificateTransparencyCompliance: string;
    cipher: string;
    encryptedClientHello: boolean;
    issuer: string;
    keyExchange: string;
    keyExchangeGroup: string;
    protocol: string;
    sanList: ScansGetResponseDataRequestsItemResponseResponseSecurityDetailsSanListList;
    serverSignatureAlgorithm: number;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansGetResponseDataRequestsItemResponseResponse {
    charset: string;
    mimeType: string;
    protocol: string;
    remoteIPAddress: string;
    remotePort: number;
    securityDetails: ScansGetResponseDataRequestsItemResponseResponseSecurityDetails;
    securityHeaders: ScansGetResponseDataRequestsItemResponseResponseSecurityHeadersList;
    securityState: string;
    status: number;
    statusText: string;
    url: string;
    headers?: unknown | null | undefined;
}
export interface ScansGetResponseDataRequestsItemResponse {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    dataLength: number;
    encodedDataLength: number;
    geoip: ScansGetResponseDataRequestsItemResponseGeoip;
    hasExtraInfo: boolean;
    requestId: string;
    response: ScansGetResponseDataRequestsItemResponseResponse;
    size: number;
    type: string;
    contentAvailable?: boolean | null | undefined;
    hash?: string | null | undefined;
}
export interface ScansGetResponseDataRequestsItemRequestsItemInitiator {
    type: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItemRequestHeaders {
    name: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItemRequest {
    headers: ScansGetResponseDataRequestsItemRequestsItemRequestHeaders;
    initialPriority: string;
    isSameSite: boolean;
    method: string;
    mixedContentType: string;
    referrerPolicy: string;
    url: string;
}
export interface ScansGetResponseDataRequestsItemRequestsItem {
    documentURL: string;
    frameId: string;
    hasUserGesture: boolean;
    initiator: ScansGetResponseDataRequestsItemRequestsItemInitiator;
    loaderId: string;
    redirectHasExtraInfo: boolean;
    request: ScansGetResponseDataRequestsItemRequestsItemRequest;
    requestId: string;
    type: string;
    wallTime: number;
}
export type ScansGetResponseDataRequestsItemRequestsList = Array<ScansGetResponseDataRequestsItemRequestsItem>;
export interface ScansGetResponseDataRequestsItem {
    request: ScansGetResponseDataRequestsItemRequest;
    response: ScansGetResponseDataRequestsItemResponse;
    requests?: ScansGetResponseDataRequestsItemRequestsList | null | undefined;
}
export type ScansGetResponseDataRequestsList = Array<ScansGetResponseDataRequestsItem>;
export interface ScansGetResponseData {
    console: ScansGetResponseDataConsoleList;
    cookies: ScansGetResponseDataCookiesList;
    globals: ScansGetResponseDataGlobalsList;
    links: ScansGetResponseDataLinksList;
    performance: ScansGetResponseDataPerformanceList;
    requests: ScansGetResponseDataRequestsList;
}
export type ScansGetResponseListsAsnsList = Array<string>;
export interface ScansGetResponseListsCertificatesItem {
    issuer: string;
    subjectName: string;
    validFrom: number;
    validTo: number;
}
export type ScansGetResponseListsCertificatesList = Array<ScansGetResponseListsCertificatesItem>;
export type ScansGetResponseListsContinentsList = Array<string>;
export type ScansGetResponseListsCountriesList = Array<string>;
export type ScansGetResponseListsDomainsList = Array<string>;
export type ScansGetResponseListsHashesList = Array<string>;
export type ScansGetResponseListsIpsList = Array<string>;
export type ScansGetResponseListsLinkDomainsList = Array<string>;
export type ScansGetResponseListsServersList = Array<string>;
export type ScansGetResponseListsUrlsList = Array<string>;
export interface ScansGetResponseLists {
    asns: ScansGetResponseListsAsnsList;
    certificates: ScansGetResponseListsCertificatesList;
    continents: ScansGetResponseListsContinentsList;
    countries: ScansGetResponseListsCountriesList;
    domains: ScansGetResponseListsDomainsList;
    hashes: ScansGetResponseListsHashesList;
    ips: ScansGetResponseListsIpsList;
    linkDomains: ScansGetResponseListsLinkDomainsList;
    servers: ScansGetResponseListsServersList;
    urls: ScansGetResponseListsUrlsList;
}
export interface ScansGetResponseMetaProcessorsAsnDataItem {
    asn: string;
    country: string;
    description: string;
    ip: string;
    name: string;
}
export type ScansGetResponseMetaProcessorsAsnDataList = Array<ScansGetResponseMetaProcessorsAsnDataItem>;
export interface ScansGetResponseMetaProcessorsAsn {
    data: ScansGetResponseMetaProcessorsAsnDataList;
}
export interface ScansGetResponseMetaProcessorsDnsDataItem {
    address: string;
    dnssecValid: boolean;
    name: string;
    type: string;
}
export type ScansGetResponseMetaProcessorsDnsDataList = Array<ScansGetResponseMetaProcessorsDnsDataItem>;
export interface ScansGetResponseMetaProcessorsDns {
    data: ScansGetResponseMetaProcessorsDnsDataList;
}
export interface ScansGetResponseMetaProcessorsDomainCategoriesDataItem {
    inherited: unknown;
    isPrimary: boolean;
    name: string;
}
export type ScansGetResponseMetaProcessorsDomainCategoriesDataList = Array<ScansGetResponseMetaProcessorsDomainCategoriesDataItem>;
export interface ScansGetResponseMetaProcessorsDomainCategories {
    data: ScansGetResponseMetaProcessorsDomainCategoriesDataList;
}
export type ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList = Array<number>;
export interface ScansGetResponseMetaProcessorsGeoipDataItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseMetaProcessorsGeoipDataItemGeoipLlList;
    region: string;
}
export interface ScansGetResponseMetaProcessorsGeoipDataItem {
    geoip: ScansGetResponseMetaProcessorsGeoipDataItemGeoip;
    ip: string;
}
export type ScansGetResponseMetaProcessorsGeoipDataList = Array<ScansGetResponseMetaProcessorsGeoipDataItem>;
export interface ScansGetResponseMetaProcessorsGeoip {
    data: ScansGetResponseMetaProcessorsGeoipDataList;
}
export type ScansGetResponseMetaProcessorsPhishingDataList = Array<string>;
export interface ScansGetResponseMetaProcessorsPhishing {
    data: ScansGetResponseMetaProcessorsPhishingDataList;
}
export interface ScansGetResponseMetaProcessorsRadarRankDataItem {
    bucket: string;
    hostname: string;
    rank?: number | null | undefined;
}
export type ScansGetResponseMetaProcessorsRadarRankDataList = Array<ScansGetResponseMetaProcessorsRadarRankDataItem>;
export interface ScansGetResponseMetaProcessorsRadarRank {
    data: ScansGetResponseMetaProcessorsRadarRankDataList;
}
export interface ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem {
    name: string;
    priority: number;
}
export type ScansGetResponseMetaProcessorsWappaDataItemCategoriesList = Array<ScansGetResponseMetaProcessorsWappaDataItemCategoriesItem>;
export interface ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem {
    confidence: number;
    name: string;
    pattern: string;
    patternType: string;
}
export type ScansGetResponseMetaProcessorsWappaDataItemConfidenceList = Array<ScansGetResponseMetaProcessorsWappaDataItemConfidenceItem>;
export interface ScansGetResponseMetaProcessorsWappaDataItem {
    app: string;
    categories: ScansGetResponseMetaProcessorsWappaDataItemCategoriesList;
    confidence: ScansGetResponseMetaProcessorsWappaDataItemConfidenceList;
    confidenceTotal: number;
    icon: string;
    website: string;
}
export type ScansGetResponseMetaProcessorsWappaDataList = Array<ScansGetResponseMetaProcessorsWappaDataItem>;
export interface ScansGetResponseMetaProcessorsWappa {
    data: ScansGetResponseMetaProcessorsWappaDataList;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding {
    outcome: string;
    summary: string;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest {
    method: string;
    url: string;
    headers?: unknown | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse {
    status: number;
    statusText: string;
    bodyPreview?: string | null | undefined;
    bodySize?: number | null | undefined;
    headers?: unknown | null | undefined;
    redirectedTo?: string | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem {
    action: string;
    label: string;
    finding?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding | null | undefined;
    request?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest | null | undefined;
    response?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef {
    /** Stable, translatable message code. */
    code: string;
    params?: unknown | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRulesEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuthEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl {
    contentSignals: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignals;
    robotsTxtAiRules: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlRobotsTxtAiRules;
    webBotAuth: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlWebBotAuth;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcpEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2MessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2 {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2EvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMppEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcpEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402MessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402 {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402EvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce {
    acp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAcp;
    ap2: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceAp2;
    mpp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceMpp;
    ucp: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceUcp;
    x402: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerceX402;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiationEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility {
    markdownNegotiation: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibilityMarkdownNegotiation;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAid {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAidEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeadersEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxtEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemapEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability {
    dnsAid: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityDnsAid;
    linkHeaders: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityLinkHeaders;
    robotsTxt: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilityRobotsTxt;
    sitemap: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverabilitySitemap;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCardEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkillsEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalogEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArd {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArdEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMd {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMdEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCardEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscoveryEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResourceEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocol {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocolEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemFinding = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemFinding;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemRequest = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemRequest;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItemResponse = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItemResponse;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceItem = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList = Array<ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsEvidenceItem>;
export type ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpMessageRef = ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef;
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp {
    status: string;
    details?: unknown | null | undefined;
    durationMs?: number | null | undefined;
    evidence?: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcpEvidenceList | null | undefined;
    message?: string | null | undefined;
    messageRef?: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControlContentSignalsMessageRef | null | undefined;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery {
    a2aAgentCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryA2aAgentCard;
    agentSkills: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAgentSkills;
    apiCatalog: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryApiCatalog;
    ard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryArd;
    authMd: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryAuthMd;
    mcpServerCard: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryMcpServerCard;
    oauthDiscovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthDiscovery;
    oauthProtectedResource: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryOauthProtectedResource;
    personalAgentProtocol: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryPersonalAgentProtocol;
    webMcp: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoveryWebMcp;
}
export interface ScansGetResponseMetaProcessorsAgentReadinessChecks {
    botAccessControl: ScansGetResponseMetaProcessorsAgentReadinessChecksBotAccessControl;
    commerce: ScansGetResponseMetaProcessorsAgentReadinessChecksCommerce;
    contentAccessibility: ScansGetResponseMetaProcessorsAgentReadinessChecksContentAccessibility;
    discoverability: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscoverability;
    discovery: ScansGetResponseMetaProcessorsAgentReadinessChecksDiscovery;
}
export type ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList = Array<string>;
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList = Array<string>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem {
    check: string;
    description: string;
    prompt: string;
    skillUrl: string;
    specUrls: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItemSpecUrlsList;
}
export type ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList = Array<ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsItem>;
export interface ScansGetResponseMetaProcessorsAgentReadinessNextLevel {
    name: string;
    requirements: ScansGetResponseMetaProcessorsAgentReadinessNextLevelRequirementsList;
    target: number;
}
export interface ScansGetResponseMetaProcessorsAgentReadiness {
    checks: ScansGetResponseMetaProcessorsAgentReadinessChecks;
    level: number;
    levelName: string;
    commerceSignals?: ScansGetResponseMetaProcessorsAgentReadinessCommerceSignalsList | null | undefined;
    isCommerce?: boolean | null | undefined;
    nextLevel?: ScansGetResponseMetaProcessorsAgentReadinessNextLevel | null | undefined;
}
export type ScansGetResponseMetaProcessorsPhishingV2DataList = Array<string>;
export interface ScansGetResponseMetaProcessorsPhishingV2 {
    data: ScansGetResponseMetaProcessorsPhishingV2DataList;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueAllowList = Array<string>;
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueDisallowList = Array<string>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueContentSignal {
    aiInput?: string | null | undefined;
    aiTrain?: string | null | undefined;
    search?: string | null | undefined;
}
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValue {
    allow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueAllowList;
    disallow: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueDisallowList;
    contentSignal?: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValueContentSignal | null | undefined;
    crawlDelay?: number | null | undefined;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesMap = {
    [key: string]: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesValue | undefined;
};
export type ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList = Array<string>;
export interface ScansGetResponseMetaProcessorsRobotsTxtDataItem {
    rules: ScansGetResponseMetaProcessorsRobotsTxtDataItemRulesMap;
    sitemaps: ScansGetResponseMetaProcessorsRobotsTxtDataItemSitemapsList;
    hash?: string | null | undefined;
}
export type ScansGetResponseMetaProcessorsRobotsTxtDataList = Array<ScansGetResponseMetaProcessorsRobotsTxtDataItem>;
export interface ScansGetResponseMetaProcessorsRobotsTxt {
    data: ScansGetResponseMetaProcessorsRobotsTxtDataList;
}
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem {
    id: number;
    name: string;
    superCategoryId: number;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedContentList;
    from: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInheritedRisksList;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksItem = ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem;
export type ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentItem>;
export interface ScansGetResponseMetaProcessorsUrlCategoriesDataItem {
    content: ScansGetResponseMetaProcessorsUrlCategoriesDataItemContentList;
    inherited: ScansGetResponseMetaProcessorsUrlCategoriesDataItemInherited;
    name: string;
    risks: ScansGetResponseMetaProcessorsUrlCategoriesDataItemRisksList;
}
export type ScansGetResponseMetaProcessorsUrlCategoriesDataList = Array<ScansGetResponseMetaProcessorsUrlCategoriesDataItem>;
export interface ScansGetResponseMetaProcessorsUrlCategories {
    data: ScansGetResponseMetaProcessorsUrlCategoriesDataList;
}
export interface ScansGetResponseMetaProcessors {
    asn: ScansGetResponseMetaProcessorsAsn;
    dns: ScansGetResponseMetaProcessorsDns;
    domainCategories: ScansGetResponseMetaProcessorsDomainCategories;
    geoip: ScansGetResponseMetaProcessorsGeoip;
    phishing: ScansGetResponseMetaProcessorsPhishing;
    radarRank: ScansGetResponseMetaProcessorsRadarRank;
    wappa: ScansGetResponseMetaProcessorsWappa;
    agentReadiness?: ScansGetResponseMetaProcessorsAgentReadiness | null | undefined;
    phishingV2?: ScansGetResponseMetaProcessorsPhishingV2 | null | undefined;
    robotsTxt?: ScansGetResponseMetaProcessorsRobotsTxt | null | undefined;
    urlCategories?: ScansGetResponseMetaProcessorsUrlCategories | null | undefined;
}
export interface ScansGetResponseMeta {
    processors: ScansGetResponseMetaProcessors;
}
export interface ScansGetResponsePageScreenshot {
    dhash: string;
    mm3Hash: number;
    name: string;
    phash: string;
}
export interface ScansGetResponsePage {
    apexDomain: string;
    asn: string;
    asnname: string;
    city: string;
    country: string;
    domain: string;
    ip: string;
    mimeType: string;
    server: string;
    status: string;
    title: string;
    tlsAgeDays: number;
    tlsIssuer: string;
    tlsValidDays: number;
    tlsValidFrom: string;
    url: string;
    screenshot?: ScansGetResponsePageScreenshot | null | undefined;
}
export interface ScansGetResponseScanner {
    colo: string;
    country: string;
}
export type ScansGetResponseStatsDomainStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsDomainStatsItemInitiatorsList = Array<string>;
export type ScansGetResponseStatsDomainStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsDomainStatsItem {
    count: number;
    countries: ScansGetResponseStatsDomainStatsItemCountriesList;
    domain: string;
    encodedSize: number;
    index: number;
    initiators: ScansGetResponseStatsDomainStatsItemInitiatorsList;
    ips: ScansGetResponseStatsDomainStatsItemIpsList;
    redirects: number;
    size: number;
}
export type ScansGetResponseStatsDomainStatsList = Array<ScansGetResponseStatsDomainStatsItem>;
export type ScansGetResponseStatsIpStatsItemAsn = ScansGetResponseDataRequestsItemResponseAsn;
export type ScansGetResponseStatsIpStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsIpStatsItemDomainsList = Array<string>;
export type ScansGetResponseStatsIpStatsItemGeoipLlList = Array<number>;
export interface ScansGetResponseStatsIpStatsItemGeoip {
    city: string;
    country: string;
    countryName: string;
    ll: ScansGetResponseStatsIpStatsItemGeoipLlList;
    region: string;
}
export interface ScansGetResponseStatsIpStatsItem {
    asn: ScansGetResponseDataRequestsItemResponseAsn;
    countries: ScansGetResponseStatsIpStatsItemCountriesList;
    domains: ScansGetResponseStatsIpStatsItemDomainsList;
    encodedSize: number;
    geoip: ScansGetResponseStatsIpStatsItemGeoip;
    index: number;
    ip: string;
    ipv6: boolean;
    redirects: number;
    requests: number;
    size: number;
    count?: number | null | undefined;
}
export type ScansGetResponseStatsIpStatsList = Array<ScansGetResponseStatsIpStatsItem>;
export type ScansGetResponseStatsProtocolStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsProtocolStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsProtocolStatsItem {
    count: number;
    countries: ScansGetResponseStatsProtocolStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsProtocolStatsItemIpsList;
    protocol: string;
    size: number;
}
export type ScansGetResponseStatsProtocolStatsList = Array<ScansGetResponseStatsProtocolStatsItem>;
export type ScansGetResponseStatsResourceStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsResourceStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsResourceStatsItem {
    compression: number;
    count: number;
    countries: ScansGetResponseStatsResourceStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsResourceStatsItemIpsList;
    percentage: number;
    size: number;
    type: string;
}
export type ScansGetResponseStatsResourceStatsList = Array<ScansGetResponseStatsResourceStatsItem>;
export type ScansGetResponseStatsServerStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsServerStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsServerStatsItem {
    count: number;
    countries: ScansGetResponseStatsServerStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsServerStatsItemIpsList;
    server: string;
    size: number;
}
export type ScansGetResponseStatsServerStatsList = Array<ScansGetResponseStatsServerStatsItem>;
export type ScansGetResponseStatsTlsStatsItemCountriesList = Array<string>;
export type ScansGetResponseStatsTlsStatsItemIpsList = Array<string>;
export interface ScansGetResponseStatsTlsStatsItemProtocols {
    TLS_1_3___AES_128_GCM: number;
}
export interface ScansGetResponseStatsTlsStatsItem {
    count: number;
    countries: ScansGetResponseStatsTlsStatsItemCountriesList;
    encodedSize: number;
    ips: ScansGetResponseStatsTlsStatsItemIpsList;
    protocols: ScansGetResponseStatsTlsStatsItemProtocols;
    securityState: string;
    size: number;
}
export type ScansGetResponseStatsTlsStatsList = Array<ScansGetResponseStatsTlsStatsItem>;
export interface ScansGetResponseStats {
    domainStats: ScansGetResponseStatsDomainStatsList;
    ipStats: ScansGetResponseStatsIpStatsList;
    iPv6Percentage: number;
    malicious: number;
    protocolStats: ScansGetResponseStatsProtocolStatsList;
    resourceStats: ScansGetResponseStatsResourceStatsList;
    securePercentage: number;
    secureRequests: number;
    serverStats: ScansGetResponseStatsServerStatsList;
    tlsStats: ScansGetResponseStatsTlsStatsList;
    totalLinks: number;
    uniqASNs: number;
    uniqCountries: number;
}
export type ScansGetResponseTaskOptionsScreenshotsResolutionsList = Array<string>;
export interface ScansGetResponseTaskOptions {
    /** Custom headers set. */
    customHeaders?: unknown | null | undefined;
    screenshotsResolutions?: ScansGetResponseTaskOptionsScreenshotsResolutionsList | null | undefined;
}
export interface ScansGetResponseTask {
    apexDomain: string;
    domain: string;
    domURL: string;
    method: string;
    options: ScansGetResponseTaskOptions;
    reportURL: string;
    screenshotURL: string;
    source: string;
    success: boolean;
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export type ScansGetResponseVerdictsOverallCategoriesList = Array<string>;
export type ScansGetResponseVerdictsOverallTagsList = Array<string>;
export interface ScansGetResponseVerdictsOverall {
    categories: ScansGetResponseVerdictsOverallCategoriesList;
    hasVerdicts: boolean;
    malicious: boolean;
    tags: ScansGetResponseVerdictsOverallTagsList;
}
export interface ScansGetResponseVerdicts {
    overall: ScansGetResponseVerdictsOverall;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetScanResponse {
    data: ScansGetResponseData;
    lists: ScansGetResponseLists;
    meta: ScansGetResponseMeta;
    page: ScansGetResponsePage;
    scanner: ScansGetResponseScanner;
    stats: ScansGetResponseStats;
    task: ScansGetResponseTask;
    verdicts: ScansGetResponseVerdicts;
}
export interface HarScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
}
export interface ScansHarResponseLogCreator {
    comment: string;
    name: string;
    version: string;
}
export type ScansHarResponseLogEntriesItemRequestHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansHarResponseLogEntriesItemRequestHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansHarResponseLogEntriesItemRequest {
    bodySize: number;
    headers: ScansHarResponseLogEntriesItemRequestHeadersList;
    headersSize: number;
    httpVersion: string;
    method: string;
    url: string;
}
export interface ScansHarResponseLogEntriesItemResponseContent {
    mimeType: string;
    size: number;
    compression?: number | null | undefined;
}
export type ScansHarResponseLogEntriesItemResponseHeadersItem = ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem;
export type ScansHarResponseLogEntriesItemResponseHeadersList = Array<ScansGetResponseDataRequestsItemRequestRedirectResponseSecurityHeadersItem>;
export interface ScansHarResponseLogEntriesItemResponse {
    transferSize: number;
    bodySize: number;
    content: ScansHarResponseLogEntriesItemResponseContent;
    headers: ScansHarResponseLogEntriesItemResponseHeadersList;
    headersSize: number;
    httpVersion: string;
    redirectURL: string;
    status: number;
    statusText: string;
}
export interface ScansHarResponseLogEntriesItem {
    initialPriority: string;
    initiatorType: string;
    priority: string;
    requestId: string;
    requestTime: number;
    resourceType: string;
    cache: unknown;
    connection: string;
    pageref: string;
    request: ScansHarResponseLogEntriesItemRequest;
    response: ScansHarResponseLogEntriesItemResponse;
    serverIPAddress: string;
    startedDateTime: string;
    time: number;
}
export type ScansHarResponseLogEntriesList = Array<ScansHarResponseLogEntriesItem>;
export interface ScansHarResponseLogPagesItemPageTimings {
    onContentLoad: number;
    onLoad: number;
}
export interface ScansHarResponseLogPagesItem {
    id: string;
    pageTimings: ScansHarResponseLogPagesItemPageTimings;
    startedDateTime: string;
    title: string;
}
export type ScansHarResponseLogPagesList = Array<ScansHarResponseLogPagesItem>;
export interface ScansHarResponseLog {
    creator: ScansHarResponseLogCreator;
    entries: ScansHarResponseLogEntriesList;
    pages: ScansHarResponseLogPagesList;
    version: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface HarScanResponse {
    log: ScansHarResponseLog;
}
export interface ListScansRequest {
    /** Account ID. */
    accountId: string;
    /** Filter scans */
    q?: string | undefined;
    /** Limit the number of objects in the response. */
    size?: number | undefined;
}
export interface ScansListResponseResultsItemPage {
    asn: string;
    country: string;
    ip: string;
    url: string;
}
export interface ScansListResponseResultsItemStats {
    dataLength: number;
    requests: number;
    uniqCountries: number;
    uniqIPs: number;
}
export interface ScansListResponseResultsItemTask {
    time: string;
    url: string;
    uuid: string;
    visibility: string;
}
export interface ScansListResponseResultsItemVerdicts {
    malicious: boolean;
}
export interface ScansListResponseResultsItem {
    id: string;
    page: ScansListResponseResultsItemPage;
    result: string;
    stats: ScansListResponseResultsItemStats;
    task: ScansListResponseResultsItemTask;
    verdicts: ScansListResponseResultsItemVerdicts;
}
export type ScansListResponseResultsList = Array<ScansListResponseResultsItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListScansResponse {
    results: ScansListResponseResultsList;
}
export type ScansScreenshotRequestResolution = "desktop" | "mobile" | "tablet";
export interface ScreenshotScanRequest {
    /** Account ID. */
    accountId: string;
    /** Scan UUID. */
    scanId: string;
    /** Target device type. */
    resolution?: ScansScreenshotRequestResolution | (string & {}) | undefined;
}
export interface ScreenshotScanResponse {
}
export type BulkCreateScansError = CloudflareOpError;
/** Submit URLs to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/ and take into account scans submitted in bulk have lower priority and may take longer to finish. */
export declare const bulkCreateScans: API.OperationMethod<BulkCreateScansRequest, BulkCreateScansResponse, BulkCreateScansError, CloudflareOpContext>;
export type CreateScanError = CloudflareOpError;
/** Submit a URL to scan. Check limits at https://developers.cloudflare.com/security-center/investigate/scan-limits/. */
export declare const createScan: API.OperationMethod<CreateScanRequest, CreateScanResponse, CreateScanError, CloudflareOpContext>;
export type DomScanError = CloudflareOpError;
/** Returns a plain text response, with the scan's DOM content as rendered by Chrome. */
export declare const domScan: API.OperationMethod<DomScanRequest, DomScanResponse, DomScanError, CloudflareOpContext>;
export type GetResponsError = CloudflareOpError;
/** Returns the raw response of the network request. Find the `response_id` in the `data.requests.response.hash`. */
export declare const getRespons: API.OperationMethod<GetResponsRequest, GetResponsResponse, GetResponsError, CloudflareOpContext>;
export type GetScanError = CloudflareOpError;
/** Get URL scan by uuid */
export declare const getScan: API.OperationMethod<GetScanRequest, GetScanResponse, GetScanError, CloudflareOpContext>;
export type HarScanError = CloudflareOpError;
/** Get a URL scan's HAR file. See HAR spec at http://www.softwareishard.com/blog/har-12-spec/. */
export declare const harScan: API.OperationMethod<HarScanRequest, HarScanResponse, HarScanError, CloudflareOpContext>;
export type ListScansError = CloudflareOpError;
/** Use a subset of ElasticSearch Query syntax to filter scans. Some example queries: - 'path:"/bundles/jquery.js"': Searches for scans who requested resources with the given path. - 'page.asn:AS24940 AND hash:xxx': Websites hosted in AS24940 where a resource with the given hash was downloaded. - 'page.domain:microsoft* AND verdicts.malicious:true AND NOT page.domain:microsoft.com': malicious scans whose hostname starts with "microsoft". - 'apikey:me AND date:[2025-01 TO 2025-02]': my scans from 2025 January to 2025 February. */
export declare const listScans: API.OperationMethod<ListScansRequest, ListScansResponse, ListScansError, CloudflareOpContext>;
export type ScreenshotScanError = CloudflareOpError;
/** Get scan's screenshot by resolution (desktop/mobile/tablet). */
export declare const screenshotScan: API.OperationMethod<ScreenshotScanRequest, ScreenshotScanResponse, ScreenshotScanError, CloudflareOpContext>;
//# sourceMappingURL=url_scanner.d.ts.map