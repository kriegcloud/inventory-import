import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExecutionTimeoutException_base: S.TaggedErrorClass<"ExecutionTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ExecutionTimeoutException extends /*@__PURE__*/ ExecutionTimeoutException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Identifier = string;
export type AuthSecretsManagerArn = string;
export interface CancelBatchJobExecutionRequest {
    applicationId: string;
    executionId: string;
    authSecretsManagerArn?: string | undefined;
}
export interface CancelBatchJobExecutionResponse {
}
export type EntityName = string;
export type EntityDescription = string;
export type EngineType = string;
export type String2000 = string;
export type StringFree65000 = string;
export type Definition = {
    s3Location: string;
    content?: undefined;
} | {
    s3Location?: undefined;
    content: string;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export type Arn = string;
export interface CreateApplicationRequest {
    name: string;
    description?: string | undefined;
    engineType: string;
    definition: Definition;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
    roleArn?: string | undefined;
}
export type Version = number;
export interface CreateApplicationResponse {
    applicationArn: string;
    applicationId: string;
    applicationVersion: number;
}
export type String200 = string;
export type ExternalLocation = {
    s3Location: string;
};
export interface DataSetExportItem {
    datasetName: string;
    externalLocation: ExternalLocation;
}
export type DataSetExportList = DataSetExportItem[];
export type DataSetExportConfig = {
    s3Location: string;
    dataSets?: undefined;
} | {
    s3Location?: undefined;
    dataSets: DataSetExportItem[];
};
export type KMSKeyId = string;
export interface CreateDataSetExportTaskRequest {
    applicationId: string;
    exportConfig: DataSetExportConfig;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
}
export interface CreateDataSetExportTaskResponse {
    taskId: string;
}
export interface PrimaryKey {
    name?: string | undefined;
    offset: number;
    length: number;
}
export interface AlternateKey {
    name?: string | undefined;
    offset: number;
    length: number;
    allowDuplicates?: boolean | undefined;
}
export type AlternateKeyList = AlternateKey[];
export interface VsamAttributes {
    format: string;
    encoding?: string | undefined;
    compressed?: boolean | undefined;
    primaryKey?: PrimaryKey | undefined;
    alternateKeys?: AlternateKey[] | undefined;
}
export interface GdgAttributes {
    limit?: number | undefined;
    rollDisposition?: string | undefined;
}
export type String20 = string;
export type String20List = string[];
export interface PoAttributes {
    format: string;
    encoding?: string | undefined;
    memberFileExtensions: string[];
}
export interface PsAttributes {
    format: string;
    encoding?: string | undefined;
}
export type DatasetOrgAttributes = {
    vsam: VsamAttributes;
    gdg?: undefined;
    po?: undefined;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg: GdgAttributes;
    po?: undefined;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg?: undefined;
    po: PoAttributes;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg?: undefined;
    po?: undefined;
    ps: PsAttributes;
};
export interface RecordLength {
    min: number;
    max: number;
}
export interface DataSet {
    storageType?: string | undefined;
    datasetName: string;
    datasetOrg: DatasetOrgAttributes;
    relativePath?: string | undefined;
    recordLength: RecordLength;
}
export interface DataSetImportItem {
    dataSet: DataSet;
    externalLocation: ExternalLocation;
}
export type DataSetImportList = DataSetImportItem[];
export type DataSetImportConfig = {
    s3Location: string;
    dataSets?: undefined;
} | {
    s3Location?: undefined;
    dataSets: DataSetImportItem[];
};
export interface CreateDataSetImportTaskRequest {
    applicationId: string;
    importConfig: DataSetImportConfig;
    clientToken?: string | undefined;
}
export interface CreateDataSetImportTaskResponse {
    taskId: string;
}
export interface CreateDeploymentRequest {
    environmentId: string;
    applicationId: string;
    applicationVersion: number;
    clientToken?: string | undefined;
}
export interface CreateDeploymentResponse {
    deploymentId: string;
}
export type EngineVersion = string;
export type String50 = string;
export type String50List = string[];
export interface EfsStorageConfiguration {
    fileSystemId: string;
    mountPoint: string;
}
export interface FsxStorageConfiguration {
    fileSystemId: string;
    mountPoint: string;
}
export type StorageConfiguration = {
    efs: EfsStorageConfiguration;
    fsx?: undefined;
} | {
    efs?: undefined;
    fsx: FsxStorageConfiguration;
};
export type StorageConfigurationList = StorageConfiguration[];
export type CapacityValue = number;
export interface HighAvailabilityConfig {
    desiredCapacity: number;
}
export type NetworkType = string;
export interface CreateEnvironmentRequest {
    name: string;
    instanceType: string;
    description?: string | undefined;
    engineType: string;
    engineVersion?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    storageConfigurations?: StorageConfiguration[] | undefined;
    publiclyAccessible?: boolean | undefined;
    highAvailabilityConfig?: HighAvailabilityConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    preferredMaintenanceWindow?: string | undefined;
    networkType?: string | undefined;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
}
export interface CreateEnvironmentResponse {
    environmentId: string;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteApplicationFromEnvironmentRequest {
    applicationId: string;
    environmentId: string;
}
export interface DeleteApplicationFromEnvironmentResponse {
}
export interface DeleteEnvironmentRequest {
    environmentId: string;
}
export interface DeleteEnvironmentResponse {
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationLifecycle = string;
export type ApplicationVersionLifecycle = string;
export interface ApplicationVersionSummary {
    applicationVersion: number;
    status: string;
    statusReason?: string | undefined;
    creationTime: Date;
}
export type DeploymentLifecycle = string;
export interface DeployedVersionSummary {
    applicationVersion: number;
    status: string;
    statusReason?: string | undefined;
}
export type LogGroupIdentifier = string;
export interface LogGroupSummary {
    logType: string;
    logGroupName: string;
}
export type LogGroupSummaries = LogGroupSummary[];
export type ArnList = string[];
export type PortList = number[];
export type String100 = string;
export interface GetApplicationResponse {
    name: string;
    description?: string | undefined;
    applicationId: string;
    applicationArn: string;
    status: string;
    latestVersion: ApplicationVersionSummary;
    deployedVersion?: DeployedVersionSummary | undefined;
    engineType: string;
    logGroups?: LogGroupSummary[] | undefined;
    creationTime: Date;
    lastStartTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    environmentId?: string | undefined;
    targetGroupArns?: string[] | undefined;
    listenerArns?: string[] | undefined;
    listenerPorts?: number[] | undefined;
    loadBalancerDnsName?: string | undefined;
    statusReason?: string | undefined;
    kmsKeyId?: string | undefined;
    roleArn?: string | undefined;
}
export interface GetApplicationVersionRequest {
    applicationId: string;
    applicationVersion: number;
}
export interface GetApplicationVersionResponse {
    name: string;
    applicationVersion: number;
    description?: string | undefined;
    definitionContent: string;
    status: string;
    creationTime: Date;
    statusReason?: string | undefined;
}
export interface GetBatchJobExecutionRequest {
    applicationId: string;
    executionId: string;
}
export type BatchJobType = string;
export type BatchJobExecutionStatus = string;
export interface FileBatchJobIdentifier {
    fileName: string;
    folderPath?: string | undefined;
}
export interface ScriptBatchJobIdentifier {
    scriptName: string;
}
export type JobIdentifier = {
    fileName: string;
    scriptName?: undefined;
} | {
    fileName?: undefined;
    scriptName: string;
};
export interface S3BatchJobIdentifier {
    bucket: string;
    keyPrefix?: string | undefined;
    identifier: JobIdentifier;
}
export interface JobStepRestartMarker {
    fromStep: string;
    fromProcStep?: string | undefined;
    toStep?: string | undefined;
    toProcStep?: string | undefined;
    stepCheckpoint?: number | undefined;
    skip?: boolean | undefined;
}
export interface RestartBatchJobIdentifier {
    executionId: string;
    jobStepRestartMarker: JobStepRestartMarker;
}
export type BatchJobIdentifier = {
    fileBatchJobIdentifier: FileBatchJobIdentifier;
    scriptBatchJobIdentifier?: undefined;
    s3BatchJobIdentifier?: undefined;
    restartBatchJobIdentifier?: undefined;
} | {
    fileBatchJobIdentifier?: undefined;
    scriptBatchJobIdentifier: ScriptBatchJobIdentifier;
    s3BatchJobIdentifier?: undefined;
    restartBatchJobIdentifier?: undefined;
} | {
    fileBatchJobIdentifier?: undefined;
    scriptBatchJobIdentifier?: undefined;
    s3BatchJobIdentifier: S3BatchJobIdentifier;
    restartBatchJobIdentifier?: undefined;
} | {
    fileBatchJobIdentifier?: undefined;
    scriptBatchJobIdentifier?: undefined;
    s3BatchJobIdentifier?: undefined;
    restartBatchJobIdentifier: RestartBatchJobIdentifier;
};
export interface GetBatchJobExecutionResponse {
    executionId: string;
    applicationId: string;
    jobId?: string | undefined;
    jobName?: string | undefined;
    jobUser?: string | undefined;
    jobType?: string | undefined;
    status: string;
    startTime: Date;
    endTime?: Date | undefined;
    statusReason?: string | undefined;
    returnCode?: string | undefined;
    batchJobIdentifier?: BatchJobIdentifier | undefined;
    jobStepRestartMarker?: JobStepRestartMarker | undefined;
}
export interface GetDataSetDetailsRequest {
    applicationId: string;
    dataSetName: string;
}
export interface VsamDetailAttributes {
    encoding?: string | undefined;
    recordFormat?: string | undefined;
    compressed?: boolean | undefined;
    cacheAtStartup?: boolean | undefined;
    primaryKey?: PrimaryKey | undefined;
    alternateKeys?: AlternateKey[] | undefined;
}
export interface GdgDetailAttributes {
    limit?: number | undefined;
    rollDisposition?: string | undefined;
}
export interface PoDetailAttributes {
    format: string;
    encoding: string;
}
export interface PsDetailAttributes {
    format: string;
    encoding: string;
}
export type DatasetDetailOrgAttributes = {
    vsam: VsamDetailAttributes;
    gdg?: undefined;
    po?: undefined;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg: GdgDetailAttributes;
    po?: undefined;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg?: undefined;
    po: PoDetailAttributes;
    ps?: undefined;
} | {
    vsam?: undefined;
    gdg?: undefined;
    po?: undefined;
    ps: PsDetailAttributes;
};
export interface GetDataSetDetailsResponse {
    dataSetName: string;
    dataSetOrg?: DatasetDetailOrgAttributes | undefined;
    recordLength?: number | undefined;
    location?: string | undefined;
    blocksize?: number | undefined;
    creationTime?: Date | undefined;
    lastUpdatedTime?: Date | undefined;
    lastReferencedTime?: Date | undefined;
    fileSize?: number | undefined;
}
export interface GetDataSetExportTaskRequest {
    applicationId: string;
    taskId: string;
}
export type DataSetTaskLifecycle = string;
export interface DataSetExportSummary {
    total: number;
    succeeded: number;
    failed: number;
    pending: number;
    inProgress: number;
}
export interface GetDataSetExportTaskResponse {
    taskId: string;
    status: string;
    summary?: DataSetExportSummary | undefined;
    statusReason?: string | undefined;
    kmsKeyArn?: string | undefined;
}
export interface GetDataSetImportTaskRequest {
    applicationId: string;
    taskId: string;
}
export interface DataSetImportSummary {
    total: number;
    succeeded: number;
    failed: number;
    pending: number;
    inProgress: number;
}
export interface GetDataSetImportTaskResponse {
    taskId: string;
    status: string;
    summary?: DataSetImportSummary | undefined;
}
export interface GetDeploymentRequest {
    deploymentId: string;
    applicationId: string;
}
export interface GetDeploymentResponse {
    deploymentId: string;
    applicationId: string;
    environmentId: string;
    applicationVersion: number;
    status: string;
    creationTime: Date;
    statusReason?: string | undefined;
}
export interface GetEnvironmentRequest {
    environmentId: string;
}
export type EnvironmentLifecycle = string;
export interface MaintenanceSchedule {
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface PendingMaintenance {
    schedule?: MaintenanceSchedule | undefined;
    engineVersion?: string | undefined;
}
export interface GetEnvironmentResponse {
    name: string;
    description?: string | undefined;
    environmentArn: string;
    environmentId: string;
    instanceType: string;
    status: string;
    engineType: string;
    engineVersion: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds: string[];
    creationTime: Date;
    storageConfigurations?: StorageConfiguration[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    highAvailabilityConfig?: HighAvailabilityConfig | undefined;
    publiclyAccessible?: boolean | undefined;
    actualCapacity?: number | undefined;
    loadBalancerArn?: string | undefined;
    statusReason?: string | undefined;
    preferredMaintenanceWindow?: string | undefined;
    pendingMaintenance?: PendingMaintenance | undefined;
    kmsKeyId?: string | undefined;
    networkType?: string | undefined;
}
export interface GetSignedBluinsightsUrlRequest {
}
export interface GetSignedBluinsightsUrlResponse {
    signedBiUrl: string;
}
export type NextToken = string;
export type MaxResults = number;
export type EntityNameList = string[];
export interface ListApplicationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    names?: string[] | undefined;
    environmentId?: string | undefined;
}
export type ApplicationDeploymentLifecycle = string;
export interface ApplicationSummary {
    name: string;
    description?: string | undefined;
    applicationId: string;
    applicationArn: string;
    applicationVersion: number;
    status: string;
    engineType: string;
    creationTime: Date;
    environmentId?: string | undefined;
    lastStartTime?: Date | undefined;
    versionStatus?: string | undefined;
    deploymentStatus?: string | undefined;
    roleArn?: string | undefined;
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsResponse {
    applications: ApplicationSummary[];
    nextToken?: string | undefined;
}
export interface ListApplicationVersionsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
}
export type ApplicationVersionSummaryList = ApplicationVersionSummary[];
export interface ListApplicationVersionsResponse {
    applicationVersions: ApplicationVersionSummary[];
    nextToken?: string | undefined;
}
export interface ListBatchJobDefinitionsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
    prefix?: string | undefined;
}
export interface FileBatchJobDefinition {
    fileName: string;
    folderPath?: string | undefined;
}
export interface ScriptBatchJobDefinition {
    scriptName: string;
}
export type BatchJobDefinition = {
    fileBatchJobDefinition: FileBatchJobDefinition;
    scriptBatchJobDefinition?: undefined;
} | {
    fileBatchJobDefinition?: undefined;
    scriptBatchJobDefinition: ScriptBatchJobDefinition;
};
export type BatchJobDefinitions = BatchJobDefinition[];
export interface ListBatchJobDefinitionsResponse {
    batchJobDefinitions: BatchJobDefinition[];
    nextToken?: string | undefined;
}
export type IdentifierList = string[];
export interface ListBatchJobExecutionsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
    executionIds?: string[] | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    startedAfter?: Date | undefined;
    startedBefore?: Date | undefined;
}
export interface BatchJobExecutionSummary {
    executionId: string;
    applicationId: string;
    jobId?: string | undefined;
    jobName?: string | undefined;
    jobType?: string | undefined;
    status: string;
    startTime: Date;
    endTime?: Date | undefined;
    returnCode?: string | undefined;
    batchJobIdentifier?: BatchJobIdentifier | undefined;
}
export type BatchJobExecutionSummaryList = BatchJobExecutionSummary[];
export interface ListBatchJobExecutionsResponse {
    batchJobExecutions: BatchJobExecutionSummary[];
    nextToken?: string | undefined;
}
export interface ListBatchJobRestartPointsRequest {
    applicationId: string;
    executionId: string;
    authSecretsManagerArn?: string | undefined;
}
export interface JobStep {
    stepNumber?: number | undefined;
    stepName?: string | undefined;
    procStepNumber?: number | undefined;
    procStepName?: string | undefined;
    stepCondCode?: string | undefined;
    stepRestartable?: boolean | undefined;
    stepCheckpoint?: number | undefined;
    stepCheckpointStatus?: string | undefined;
    stepCheckpointTime?: Date | undefined;
}
export type BatchJobStepList = JobStep[];
export interface ListBatchJobRestartPointsResponse {
    batchJobSteps?: JobStep[] | undefined;
}
export interface ListDataSetExportHistoryRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
}
export interface DataSetExportTask {
    taskId: string;
    status: string;
    summary: DataSetExportSummary;
    statusReason?: string | undefined;
}
export type DataSetExportTaskList = DataSetExportTask[];
export interface ListDataSetExportHistoryResponse {
    dataSetExportTasks: DataSetExportTask[];
    nextToken?: string | undefined;
}
export interface ListDataSetImportHistoryRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
}
export interface DataSetImportTask {
    taskId: string;
    status: string;
    summary: DataSetImportSummary;
    statusReason?: string | undefined;
}
export type DataSetImportTaskList = DataSetImportTask[];
export interface ListDataSetImportHistoryResponse {
    dataSetImportTasks: DataSetImportTask[];
    nextToken?: string | undefined;
}
export interface ListDataSetsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    prefix?: string | undefined;
    nameFilter?: string | undefined;
}
export interface DataSetSummary {
    dataSetName: string;
    dataSetOrg?: string | undefined;
    format?: string | undefined;
    creationTime?: Date | undefined;
    lastUpdatedTime?: Date | undefined;
    lastReferencedTime?: Date | undefined;
}
export type DataSetsSummaryList = DataSetSummary[];
export interface ListDataSetsResponse {
    dataSets: DataSetSummary[];
    nextToken?: string | undefined;
}
export interface ListDeploymentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    applicationId: string;
}
export interface DeploymentSummary {
    deploymentId: string;
    applicationId: string;
    environmentId: string;
    applicationVersion: number;
    status: string;
    creationTime: Date;
    statusReason?: string | undefined;
}
export type DeploymentList = DeploymentSummary[];
export interface ListDeploymentsResponse {
    deployments: DeploymentSummary[];
    nextToken?: string | undefined;
}
export interface ListEngineVersionsRequest {
    engineType?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EngineVersionsSummary {
    engineType: string;
    engineVersion: string;
}
export type EngineVersionsSummaryList = EngineVersionsSummary[];
export interface ListEngineVersionsResponse {
    engineVersions: EngineVersionsSummary[];
    nextToken?: string | undefined;
}
export interface ListEnvironmentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    names?: string[] | undefined;
    engineType?: string | undefined;
}
export interface EnvironmentSummary {
    name: string;
    environmentArn: string;
    environmentId: string;
    instanceType: string;
    status: string;
    engineType: string;
    engineVersion: string;
    creationTime: Date;
    networkType?: string | undefined;
}
export type EnvironmentSummaryList = EnvironmentSummary[];
export interface ListEnvironmentsResponse {
    environments: EnvironmentSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface StartApplicationRequest {
    applicationId: string;
}
export interface StartApplicationResponse {
}
export type BatchParamKey = string;
export type BatchParamValue = string;
export type BatchJobParametersMap = {
    [key: string]: string | undefined;
};
export interface StartBatchJobRequest {
    applicationId: string;
    batchJobIdentifier: BatchJobIdentifier;
    jobParams?: {
        [key: string]: string | undefined;
    } | undefined;
    authSecretsManagerArn?: string | undefined;
}
export interface StartBatchJobResponse {
    executionId: string;
}
export interface StopApplicationRequest {
    applicationId: string;
    forceStop?: boolean | undefined;
}
export interface StopApplicationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    applicationId: string;
    description?: string | undefined;
    currentApplicationVersion: number;
    definition?: Definition | undefined;
}
export interface UpdateApplicationResponse {
    applicationVersion: number;
}
export interface UpdateEnvironmentRequest {
    environmentId: string;
    desiredCapacity?: number | undefined;
    instanceType?: string | undefined;
    engineVersion?: string | undefined;
    preferredMaintenanceWindow?: string | undefined;
    applyDuringMaintenanceWindow?: boolean | undefined;
    forceUpdate?: boolean | undefined;
}
export interface UpdateEnvironmentResponse {
    environmentId: string;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CancelBatchJobExecutionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the running of a specific batch job execution.
 */
export declare const cancelBatchJobExecution: API.OperationMethod<CancelBatchJobExecutionRequest & RegionInput, CancelBatchJobExecutionResponse, CancelBatchJobExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new application with given parameters. Requires an existing runtime
 * environment and application definition file.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetExportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data set export task for a specific application.
 */
export declare const createDataSetExportTask: API.OperationMethod<CreateDataSetExportTaskRequest & RegionInput, CreateDataSetExportTaskResponse, CreateDataSetExportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetImportTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data set import task for a specific application.
 */
export declare const createDataSetImportTask: API.OperationMethod<CreateDataSetImportTaskRequest & RegionInput, CreateDataSetImportTaskResponse, CreateDataSetImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and starts a deployment to deploy an application into a runtime
 * environment.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest & RegionInput, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a runtime environment for a given runtime engine.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest & RegionInput, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific application. You cannot delete a running application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationFromEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific application from the specific runtime environment where it was
 * previously deployed. You cannot delete a runtime environment using DeleteEnvironment if any
 * application has ever been deployed to it. This API removes the association of the
 * application with the runtime environment so you can delete the environment smoothly.
 */
export declare const deleteApplicationFromEnvironment: API.OperationMethod<DeleteApplicationFromEnvironmentRequest & RegionInput, DeleteApplicationFromEnvironmentResponse, DeleteApplicationFromEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specific runtime environment. The environment cannot contain deployed
 * applications. If it does, you must delete those applications before you delete the
 * environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the details of a specific application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specific version of a specific application.
 */
export declare const getApplicationVersion: API.OperationMethod<GetApplicationVersionRequest & RegionInput, GetApplicationVersionResponse, GetApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type GetBatchJobExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a specific batch job execution for a specific application.
 */
export declare const getBatchJobExecution: API.OperationMethod<GetBatchJobExecutionRequest & RegionInput, GetBatchJobExecutionResponse, GetBatchJobExecutionError, Credentials | HttpClient.HttpClient>;
export type GetDataSetDetailsError = AccessDeniedException | ConflictException | ExecutionTimeoutException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of a specific data set.
 */
export declare const getDataSetDetails: API.OperationMethod<GetDataSetDetailsRequest & RegionInput, GetDataSetDetailsResponse, GetDataSetDetailsError, Credentials | HttpClient.HttpClient>;
export type GetDataSetExportTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the status of a data set import task initiated with the CreateDataSetExportTask operation.
 */
export declare const getDataSetExportTask: API.OperationMethod<GetDataSetExportTaskRequest & RegionInput, GetDataSetExportTaskResponse, GetDataSetExportTaskError, Credentials | HttpClient.HttpClient>;
export type GetDataSetImportTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the status of a data set import task initiated with the CreateDataSetImportTask operation.
 */
export declare const getDataSetImportTask: API.OperationMethod<GetDataSetImportTaskRequest & RegionInput, GetDataSetImportTaskResponse, GetDataSetImportTaskError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details of a specific deployment with a given deployment identifier.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest & RegionInput, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a specific runtime environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest & RegionInput, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetSignedBluinsightsUrlError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Gets a single sign-on URL that can be used to connect to AWS Blu Insights.
 */
export declare const getSignedBluinsightsUrl: API.OperationMethod<GetSignedBluinsightsUrlRequest & RegionInput, GetSignedBluinsightsUrlResponse, GetSignedBluinsightsUrlError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the applications associated with a specific Amazon Web Services account. You can provide the
 * unique identifier of a specific runtime environment in a query parameter to see all
 * applications associated with that environment.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListApplicationVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the application versions for a specific application.
 */
export declare const listApplicationVersions: API.PaginatedOperationMethod<ListApplicationVersionsRequest & RegionInput, ListApplicationVersionsResponse, ListApplicationVersionsError, Credentials | HttpClient.HttpClient, ApplicationVersionSummary>;
export type ListBatchJobDefinitionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the available batch job definitions based on the batch job resources uploaded
 * during the application creation. You can use the batch job definitions in the list to start
 * a batch job.
 */
export declare const listBatchJobDefinitions: API.PaginatedOperationMethod<ListBatchJobDefinitionsRequest & RegionInput, ListBatchJobDefinitionsResponse, ListBatchJobDefinitionsError, Credentials | HttpClient.HttpClient, BatchJobDefinition>;
export type ListBatchJobExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists historical, current, and scheduled batch job executions for a specific
 * application.
 */
export declare const listBatchJobExecutions: API.PaginatedOperationMethod<ListBatchJobExecutionsRequest & RegionInput, ListBatchJobExecutionsResponse, ListBatchJobExecutionsError, Credentials | HttpClient.HttpClient, BatchJobExecutionSummary>;
export type ListBatchJobRestartPointsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the job steps for a JCL file to restart a batch job. This is only applicable for Micro Focus engine with versions 8.0.6 and above.
 */
export declare const listBatchJobRestartPoints: API.OperationMethod<ListBatchJobRestartPointsRequest & RegionInput, ListBatchJobRestartPointsResponse, ListBatchJobRestartPointsError, Credentials | HttpClient.HttpClient>;
export type ListDataSetExportHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data set exports for the specified application.
 */
export declare const listDataSetExportHistory: API.PaginatedOperationMethod<ListDataSetExportHistoryRequest & RegionInput, ListDataSetExportHistoryResponse, ListDataSetExportHistoryError, Credentials | HttpClient.HttpClient, DataSetExportTask>;
export type ListDataSetImportHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data set imports for the specified application.
 */
export declare const listDataSetImportHistory: API.PaginatedOperationMethod<ListDataSetImportHistoryRequest & RegionInput, ListDataSetImportHistoryResponse, ListDataSetImportHistoryError, Credentials | HttpClient.HttpClient, DataSetImportTask>;
export type ListDataSetsError = AccessDeniedException | ConflictException | ExecutionTimeoutException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data sets imported for a specific application. In Amazon Web Services Mainframe Modernization, data sets are
 * associated with applications deployed on runtime environments. This is known as importing
 * data sets. Currently, Amazon Web Services Mainframe Modernization can import data sets into catalogs using CreateDataSetImportTask.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest & RegionInput, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetSummary>;
export type ListDeploymentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all deployments of a specific application. A deployment is a
 * combination of a specific application and a specific version of that application. Each
 * deployment is mapped to a particular application version.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest & RegionInput, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListEngineVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available engine versions.
 */
export declare const listEngineVersions: API.PaginatedOperationMethod<ListEngineVersionsRequest & RegionInput, ListEngineVersionsResponse, ListEngineVersionsError, Credentials | HttpClient.HttpClient, EngineVersionsSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the runtime environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest & RegionInput, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an application that is currently stopped.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest & RegionInput, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartBatchJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a batch job and returns the unique identifier of this execution of the batch job.
 * The associated application must be running in order to start the batch job.
 */
export declare const startBatchJob: API.OperationMethod<StartBatchJobRequest & RegionInput, StartBatchJobResponse, StartBatchJobError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a running application.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest & RegionInput, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an application and creates a new version.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration details for a specific runtime environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest & RegionInput, UpdateEnvironmentResponse, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=m2.d.ts.map