import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Interaction from "../Interaction.ts";
import type { Plan } from "../Plan.ts";
import { Cli, type PlanDisplayOptions } from "../Report.ts";
import { renderPlanning } from "./commands/render.ts";
import { renderNukeDelete, renderNukeScan } from "./components/view/Nuke.tsx";
/**
 * The CLI's terminal UI for scripts that drive `alchemy/Alchemist`
 * themselves: the Sigil UI on an interactive terminal, plain log lines
 * otherwise, exactly like the CLI.
 *
 * ```ts
 * const plan = yield* Alchemist.plan({ stack, operation: "deploy", stage }).pipe(
 *   SigilRenderer.planning({ operation: "Deploy", stage }),
 * );
 * if (!(yield* SigilRenderer.approve(plan, { stage }))) return;
 * const output = yield* Alchemist.apply(plan).pipe(SigilRenderer.apply(plan, { stage }));
 * yield* SigilRenderer.outputs(output);
 * ```
 */
/** A deploy or destroy plan, or a drift scan, from `alchemy/Alchemist`. */
export interface RenderablePlan {
    readonly native: Plan;
}
/**
 * The CLI's terminal and renderer services, in place of `Alchemist.layer()`'s
 * non-interactive terminal. Provide it after `Alchemist.layer()`:
 * `Effect.provide([Alchemist.layer(), SigilRenderer.layer()])`.
 */
export declare const layer: () => Layer.Layer<Cli | Interaction.Interaction, never, never>;
/** Planning progress (import, services, state, per-resource diffing) around a `plan` call. */
export declare const planning: typeof renderPlanning;
/**
 * Show the plan and ask to apply it; `true` when approved. Fails with
 * `NonInteractiveTerminal` when there is no terminal to ask on.
 */
export declare const approve: (plan: RenderablePlan, options?: PlanDisplayOptions) => Effect.Effect<boolean, Interaction.NonInteractiveTerminal, Cli>;
/** Show the plan without asking, as `alchemy plan` does. */
export declare const display: (plan: RenderablePlan, options?: PlanDisplayOptions) => Effect.Effect<void, never, Cli>;
/** Per-resource apply rows around an `apply` call. */
export declare const apply: (plan: RenderablePlan, options?: PlanDisplayOptions) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Print a deployed stack's outputs. */
export declare const outputs: (output: unknown) => Effect.Effect<void, never, Interaction.Interaction>;
/** `alchemy unsafe nuke`'s scan progress, review prompt and deletion view. */
export declare const Nuke: {
    /** Live scan progress around `Alchemist.Nuke.scan`. */
    scan: typeof renderNukeScan;
    /** Show the inventory and ask to delete it; `true` when approved (or `yes`/`dryRun`). */
    review: (targets: readonly Pick<import("../Nuke.ts").Target, "displayName" | "key" | "providerId">[], options: {
        mode: import("../ProviderMode.ts").ProviderMode;
        yes: boolean;
        dryRun: boolean;
    }) => Effect.Effect<boolean, Interaction.InteractionError, Interaction.Interaction>;
    /** Per-resource deletion rows around `Alchemist.Nuke.execute`. */
    delete: typeof renderNukeDelete;
};
//# sourceMappingURL=SigilRenderer.d.ts.map