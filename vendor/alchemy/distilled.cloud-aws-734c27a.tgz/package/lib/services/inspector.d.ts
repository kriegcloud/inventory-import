import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AgentsAlreadyRunningAssessmentException_base: S.TaggedErrorClass<"AgentsAlreadyRunningAssessmentException", {
    readonly message: any;
    readonly agents: any;
    readonly agentsTruncated: any;
    readonly canRetry: any;
}>;
export declare class AgentsAlreadyRunningAssessmentException extends /*@__PURE__*/ AgentsAlreadyRunningAssessmentException_base {
}
declare const AssessmentRunInProgressException_base: S.TaggedErrorClass<"AssessmentRunInProgressException", {
    readonly message: any;
    readonly assessmentRunArns: any;
    readonly assessmentRunArnsTruncated: any;
    readonly canRetry: any;
}>;
export declare class AssessmentRunInProgressException extends /*@__PURE__*/ AssessmentRunInProgressException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
    readonly canRetry: any;
}>;
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidCrossAccountRoleException_base: S.TaggedErrorClass<"InvalidCrossAccountRoleException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>;
export declare class InvalidCrossAccountRoleException extends /*@__PURE__*/ InvalidCrossAccountRoleException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NoSuchEntityException_base: S.TaggedErrorClass<"NoSuchEntityException", {
    readonly message: any;
    readonly errorCode: any;
    readonly canRetry: any;
}>;
export declare class NoSuchEntityException extends /*@__PURE__*/ NoSuchEntityException_base {
}
declare const PreviewGenerationInProgressException_base: S.TaggedErrorClass<"PreviewGenerationInProgressException", {
    readonly message: any;
}>;
export declare class PreviewGenerationInProgressException extends /*@__PURE__*/ PreviewGenerationInProgressException_base {
}
declare const ServiceTemporarilyUnavailableException_base: S.TaggedErrorClass<"ServiceTemporarilyUnavailableException", {
    readonly message: any;
    readonly canRetry: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceTemporarilyUnavailableException extends /*@__PURE__*/ ServiceTemporarilyUnavailableException_base {
}
declare const UnsupportedFeatureException_base: S.TaggedErrorClass<"UnsupportedFeatureException", {
    readonly message: any;
    readonly canRetry: any;
}>;
export declare class UnsupportedFeatureException extends /*@__PURE__*/ UnsupportedFeatureException_base {
}
export type Arn = string;
export type AddRemoveAttributesFindingArnList = string[];
export type AttributeKey = string;
export type AttributeValue = string;
export interface Attribute {
    key: string;
    value?: string | undefined;
}
export type UserAttributeList = Attribute[];
export interface AddAttributesToFindingsRequest {
    findingArns: string[];
    attributes: Attribute[];
}
export type FailedItemErrorCode = "INVALID_ARN" | "DUPLICATE_ARN" | "ITEM_DOES_NOT_EXIST" | "ACCESS_DENIED" | "LIMIT_EXCEEDED" | "INTERNAL_ERROR" | (string & {});
export interface FailedItemDetails {
    failureCode: FailedItemErrorCode;
    retryable: boolean;
}
export type FailedItems = {
    [key: string]: FailedItemDetails | undefined;
};
export interface AddAttributesToFindingsResponse {
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export type AssessmentTargetName = string;
export interface CreateAssessmentTargetRequest {
    assessmentTargetName: string;
    resourceGroupArn?: string | undefined;
}
export interface CreateAssessmentTargetResponse {
    assessmentTargetArn: string;
}
export type AssessmentTemplateName = string;
export type AssessmentRunDuration = number;
export type AssessmentTemplateRulesPackageArnList = string[];
export interface CreateAssessmentTemplateRequest {
    assessmentTargetArn: string;
    assessmentTemplateName: string;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings?: Attribute[] | undefined;
}
export interface CreateAssessmentTemplateResponse {
    assessmentTemplateArn: string;
}
export interface CreateExclusionsPreviewRequest {
    assessmentTemplateArn: string;
}
export type UUID = string;
export interface CreateExclusionsPreviewResponse {
    previewToken: string;
}
export type TagKey = string;
export type TagValue = string;
export interface ResourceGroupTag {
    key: string;
    value?: string | undefined;
}
export type ResourceGroupTags = ResourceGroupTag[];
export interface CreateResourceGroupRequest {
    resourceGroupTags: ResourceGroupTag[];
}
export interface CreateResourceGroupResponse {
    resourceGroupArn: string;
}
export interface DeleteAssessmentRunRequest {
    assessmentRunArn: string;
}
export interface DeleteAssessmentRunResponse {
}
export interface DeleteAssessmentTargetRequest {
    assessmentTargetArn: string;
}
export interface DeleteAssessmentTargetResponse {
}
export interface DeleteAssessmentTemplateRequest {
    assessmentTemplateArn: string;
}
export interface DeleteAssessmentTemplateResponse {
}
export type BatchDescribeArnList = string[];
export interface DescribeAssessmentRunsRequest {
    assessmentRunArns: string[];
}
export type AssessmentRunName = string;
export type AssessmentRunState = "CREATED" | "START_DATA_COLLECTION_PENDING" | "START_DATA_COLLECTION_IN_PROGRESS" | "COLLECTING_DATA" | "STOP_DATA_COLLECTION_PENDING" | "DATA_COLLECTED" | "START_EVALUATING_RULES_PENDING" | "EVALUATING_RULES" | "FAILED" | "ERROR" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "CANCELED" | (string & {});
export type AssessmentRulesPackageArnList = string[];
export interface AssessmentRunStateChange {
    stateChangedAt: Date;
    state: AssessmentRunState;
}
export type AssessmentRunStateChangeList = AssessmentRunStateChange[];
export type InspectorEvent = "ASSESSMENT_RUN_STARTED" | "ASSESSMENT_RUN_COMPLETED" | "ASSESSMENT_RUN_STATE_CHANGED" | "FINDING_REPORTED" | "OTHER" | (string & {});
export type Message = string;
export type AssessmentRunNotificationSnsStatusCode = "SUCCESS" | "TOPIC_DOES_NOT_EXIST" | "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export interface AssessmentRunNotification {
    date: Date;
    event: InspectorEvent;
    message?: string | undefined;
    error: boolean;
    snsTopicArn?: string | undefined;
    snsPublishStatusCode?: AssessmentRunNotificationSnsStatusCode | undefined;
}
export type AssessmentRunNotificationList = AssessmentRunNotification[];
export type Severity = "Low" | "Medium" | "High" | "Informational" | "Undefined" | (string & {});
export type FindingCount = number;
export type AssessmentRunFindingCounts = {
    [key in Severity]?: number | undefined;
};
export interface AssessmentRun {
    arn: string;
    name: string;
    assessmentTemplateArn: string;
    state: AssessmentRunState;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings: Attribute[];
    createdAt: Date;
    startedAt?: Date | undefined;
    completedAt?: Date | undefined;
    stateChangedAt: Date;
    dataCollected: boolean;
    stateChanges: AssessmentRunStateChange[];
    notifications: AssessmentRunNotification[];
    findingCounts: {
        [key: string]: number | undefined;
    };
}
export type AssessmentRunList = AssessmentRun[];
export interface DescribeAssessmentRunsResponse {
    assessmentRuns: AssessmentRun[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeAssessmentTargetsRequest {
    assessmentTargetArns: string[];
}
export interface AssessmentTarget {
    arn: string;
    name: string;
    resourceGroupArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type AssessmentTargetList = AssessmentTarget[];
export interface DescribeAssessmentTargetsResponse {
    assessmentTargets: AssessmentTarget[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeAssessmentTemplatesRequest {
    assessmentTemplateArns: string[];
}
export type ArnCount = number;
export interface AssessmentTemplate {
    arn: string;
    name: string;
    assessmentTargetArn: string;
    durationInSeconds: number;
    rulesPackageArns: string[];
    userAttributesForFindings: Attribute[];
    lastAssessmentRunArn?: string | undefined;
    assessmentRunCount: number;
    createdAt: Date;
}
export type AssessmentTemplateList = AssessmentTemplate[];
export interface DescribeAssessmentTemplatesResponse {
    assessmentTemplates: AssessmentTemplate[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeCrossAccountAccessRoleRequest {
}
export interface DescribeCrossAccountAccessRoleResponse {
    roleArn: string;
    valid: boolean;
    registeredAt: Date;
}
export type BatchDescribeExclusionsArnList = string[];
export type Locale = "EN_US" | (string & {});
export interface DescribeExclusionsRequest {
    exclusionArns: string[];
    locale?: Locale | undefined;
}
export type Text = string;
export type ScopeType = "INSTANCE_ID" | "RULES_PACKAGE_ARN" | (string & {});
export type ScopeValue = string;
export interface Scope {
    key?: ScopeType | undefined;
    value?: string | undefined;
}
export type ScopeList = Scope[];
export type AttributeList = Attribute[];
export interface Exclusion {
    arn: string;
    title: string;
    description: string;
    recommendation: string;
    scopes: Scope[];
    attributes?: Attribute[] | undefined;
}
export type ExclusionMap = {
    [key: string]: Exclusion | undefined;
};
export interface DescribeExclusionsResponse {
    exclusions: {
        [key: string]: Exclusion | undefined;
    };
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeFindingsRequest {
    findingArns: string[];
    locale?: Locale | undefined;
}
export type NumericVersion = number;
export type ServiceName = string;
export interface InspectorServiceAttributes {
    schemaVersion: number;
    assessmentRunArn?: string | undefined;
    rulesPackageArn?: string | undefined;
}
export type AssetType = "ec2-instance" | (string & {});
export type AgentId = string;
export type AutoScalingGroup = string;
export type AmiId = string;
export type Hostname = string;
export type Ipv4Address = string;
export type Ipv4AddressList = string[];
export interface Tag {
    key: string;
    value?: string | undefined;
}
export type Tags = Tag[];
export interface PrivateIp {
    privateDnsName?: string | undefined;
    privateIpAddress?: string | undefined;
}
export type PrivateIpAddresses = PrivateIp[];
export type Ipv6Addresses = string[];
export interface SecurityGroup {
    groupName?: string | undefined;
    groupId?: string | undefined;
}
export type SecurityGroups = SecurityGroup[];
export interface NetworkInterface {
    networkInterfaceId?: string | undefined;
    subnetId?: string | undefined;
    vpcId?: string | undefined;
    privateDnsName?: string | undefined;
    privateIpAddress?: string | undefined;
    privateIpAddresses?: PrivateIp[] | undefined;
    publicDnsName?: string | undefined;
    publicIp?: string | undefined;
    ipv6Addresses?: string[] | undefined;
    securityGroups?: SecurityGroup[] | undefined;
}
export type NetworkInterfaces = NetworkInterface[];
export interface AssetAttributes {
    schemaVersion: number;
    agentId?: string | undefined;
    autoScalingGroup?: string | undefined;
    amiId?: string | undefined;
    hostname?: string | undefined;
    ipv4Addresses?: string[] | undefined;
    tags?: Tag[] | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
}
export type FindingId = string;
export type NumericSeverity = number;
export type IocConfidence = number;
export interface Finding {
    arn: string;
    schemaVersion?: number | undefined;
    service?: string | undefined;
    serviceAttributes?: InspectorServiceAttributes | undefined;
    assetType?: AssetType | undefined;
    assetAttributes?: AssetAttributes | undefined;
    id?: string | undefined;
    title?: string | undefined;
    description?: string | undefined;
    recommendation?: string | undefined;
    severity?: Severity | undefined;
    numericSeverity?: number | undefined;
    confidence?: number | undefined;
    indicatorOfCompromise?: boolean | undefined;
    attributes: Attribute[];
    userAttributes: Attribute[];
    createdAt: Date;
    updatedAt: Date;
}
export type FindingList = Finding[];
export interface DescribeFindingsResponse {
    findings: Finding[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeResourceGroupsRequest {
    resourceGroupArns: string[];
}
export interface ResourceGroup {
    arn: string;
    tags: ResourceGroupTag[];
    createdAt: Date;
}
export type ResourceGroupList = ResourceGroup[];
export interface DescribeResourceGroupsResponse {
    resourceGroups: ResourceGroup[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface DescribeRulesPackagesRequest {
    rulesPackageArns: string[];
    locale?: Locale | undefined;
}
export type RulesPackageName = string;
export type Version = string;
export type ProviderName = string;
export interface RulesPackage {
    arn: string;
    name: string;
    version: string;
    provider: string;
    description?: string | undefined;
}
export type RulesPackageList = RulesPackage[];
export interface DescribeRulesPackagesResponse {
    rulesPackages: RulesPackage[];
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export type ReportFileFormat = "HTML" | "PDF" | (string & {});
export type ReportType = "FINDING" | "FULL" | (string & {});
export interface GetAssessmentReportRequest {
    assessmentRunArn: string;
    reportFileFormat: ReportFileFormat;
    reportType: ReportType;
}
export type ReportStatus = "WORK_IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export type Url = string;
export interface GetAssessmentReportResponse {
    status: ReportStatus;
    url?: string | undefined;
}
export type PaginationToken = string;
export type ListMaxResults = number;
export interface GetExclusionsPreviewRequest {
    assessmentTemplateArn: string;
    previewToken: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    locale?: Locale | undefined;
}
export type PreviewStatus = "WORK_IN_PROGRESS" | "COMPLETED" | (string & {});
export interface ExclusionPreview {
    title: string;
    description: string;
    recommendation: string;
    scopes: Scope[];
    attributes?: Attribute[] | undefined;
}
export type ExclusionPreviewList = ExclusionPreview[];
export interface GetExclusionsPreviewResponse {
    previewStatus: PreviewStatus;
    exclusionPreviews?: ExclusionPreview[] | undefined;
    nextToken?: string | undefined;
}
export interface GetTelemetryMetadataRequest {
    assessmentRunArn: string;
}
export type MessageType = string;
export interface TelemetryMetadata {
    messageType: string;
    count: number;
    dataSize?: number | undefined;
}
export type TelemetryMetadataList = TelemetryMetadata[];
export interface GetTelemetryMetadataResponse {
    telemetryMetadata: TelemetryMetadata[];
}
export type AgentHealth = "HEALTHY" | "UNHEALTHY" | "UNKNOWN" | (string & {});
export type AgentHealthList = AgentHealth[];
export type AgentHealthCode = "IDLE" | "RUNNING" | "SHUTDOWN" | "UNHEALTHY" | "THROTTLED" | "UNKNOWN" | (string & {});
export type AgentHealthCodeList = AgentHealthCode[];
export interface AgentFilter {
    agentHealths: AgentHealth[];
    agentHealthCodes: AgentHealthCode[];
}
export interface ListAssessmentRunAgentsRequest {
    assessmentRunArn: string;
    filter?: AgentFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AssessmentRunAgent {
    agentId: string;
    assessmentRunArn: string;
    agentHealth: AgentHealth;
    agentHealthCode: AgentHealthCode;
    agentHealthDetails?: string | undefined;
    autoScalingGroup?: string | undefined;
    telemetryMetadata: TelemetryMetadata[];
}
export type AssessmentRunAgentList = AssessmentRunAgent[];
export interface ListAssessmentRunAgentsResponse {
    assessmentRunAgents: AssessmentRunAgent[];
    nextToken?: string | undefined;
}
export type ListParentArnList = string[];
export type NamePattern = string;
export type AssessmentRunStateList = AssessmentRunState[];
export interface DurationRange {
    minSeconds?: number | undefined;
    maxSeconds?: number | undefined;
}
export type FilterRulesPackageArnList = string[];
export interface TimestampRange {
    beginDate?: Date | undefined;
    endDate?: Date | undefined;
}
export interface AssessmentRunFilter {
    namePattern?: string | undefined;
    states?: AssessmentRunState[] | undefined;
    durationRange?: DurationRange | undefined;
    rulesPackageArns?: string[] | undefined;
    startTimeRange?: TimestampRange | undefined;
    completionTimeRange?: TimestampRange | undefined;
    stateChangeTimeRange?: TimestampRange | undefined;
}
export interface ListAssessmentRunsRequest {
    assessmentTemplateArns?: string[] | undefined;
    filter?: AssessmentRunFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ListReturnedArnList = string[];
export interface ListAssessmentRunsResponse {
    assessmentRunArns: string[];
    nextToken?: string | undefined;
}
export interface AssessmentTargetFilter {
    assessmentTargetNamePattern?: string | undefined;
}
export interface ListAssessmentTargetsRequest {
    filter?: AssessmentTargetFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListAssessmentTargetsResponse {
    assessmentTargetArns: string[];
    nextToken?: string | undefined;
}
export interface AssessmentTemplateFilter {
    namePattern?: string | undefined;
    durationRange?: DurationRange | undefined;
    rulesPackageArns?: string[] | undefined;
}
export interface ListAssessmentTemplatesRequest {
    assessmentTargetArns?: string[] | undefined;
    filter?: AssessmentTemplateFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListAssessmentTemplatesResponse {
    assessmentTemplateArns: string[];
    nextToken?: string | undefined;
}
export type ListEventSubscriptionsMaxResults = number;
export interface ListEventSubscriptionsRequest {
    resourceArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EventSubscription {
    event: InspectorEvent;
    subscribedAt: Date;
}
export type EventSubscriptionList = EventSubscription[];
export interface Subscription {
    resourceArn: string;
    topicArn: string;
    eventSubscriptions: EventSubscription[];
}
export type SubscriptionList = Subscription[];
export interface ListEventSubscriptionsResponse {
    subscriptions: Subscription[];
    nextToken?: string | undefined;
}
export interface ListExclusionsRequest {
    assessmentRunArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListExclusionsResponse {
    exclusionArns: string[];
    nextToken?: string | undefined;
}
export type AgentIdList = string[];
export type AutoScalingGroupList = string[];
export type RuleName = string;
export type RuleNameList = string[];
export type SeverityList = Severity[];
export interface FindingFilter {
    agentIds?: string[] | undefined;
    autoScalingGroups?: string[] | undefined;
    ruleNames?: string[] | undefined;
    severities?: Severity[] | undefined;
    rulesPackageArns?: string[] | undefined;
    attributes?: Attribute[] | undefined;
    userAttributes?: Attribute[] | undefined;
    creationTimeRange?: TimestampRange | undefined;
}
export interface ListFindingsRequest {
    assessmentRunArns?: string[] | undefined;
    filter?: FindingFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListFindingsResponse {
    findingArns: string[];
    nextToken?: string | undefined;
}
export interface ListRulesPackagesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListRulesPackagesResponse {
    rulesPackageArns: string[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type TagList = Tag[];
export interface ListTagsForResourceResponse {
    tags: Tag[];
}
export type PreviewAgentsMaxResults = number;
export interface PreviewAgentsRequest {
    previewAgentsArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type AgentVersion = string;
export type OperatingSystem = string;
export type KernelVersion = string;
export interface AgentPreview {
    hostname?: string | undefined;
    agentId: string;
    autoScalingGroup?: string | undefined;
    agentHealth?: AgentHealth | undefined;
    agentVersion?: string | undefined;
    operatingSystem?: string | undefined;
    kernelVersion?: string | undefined;
    ipv4Address?: string | undefined;
}
export type AgentPreviewList = AgentPreview[];
export interface PreviewAgentsResponse {
    agentPreviews: AgentPreview[];
    nextToken?: string | undefined;
}
export interface RegisterCrossAccountAccessRoleRequest {
    roleArn: string;
}
export interface RegisterCrossAccountAccessRoleResponse {
}
export type UserAttributeKeyList = string[];
export interface RemoveAttributesFromFindingsRequest {
    findingArns: string[];
    attributeKeys: string[];
}
export interface RemoveAttributesFromFindingsResponse {
    failedItems: {
        [key: string]: FailedItemDetails | undefined;
    };
}
export interface SetTagsForResourceRequest {
    resourceArn: string;
    tags?: Tag[] | undefined;
}
export interface SetTagsForResourceResponse {
}
export interface StartAssessmentRunRequest {
    assessmentTemplateArn: string;
    assessmentRunName?: string | undefined;
}
export interface StartAssessmentRunResponse {
    assessmentRunArn: string;
}
export type StopAction = "START_EVALUATION" | "SKIP_EVALUATION" | (string & {});
export interface StopAssessmentRunRequest {
    assessmentRunArn: string;
    stopAction?: StopAction | undefined;
}
export interface StopAssessmentRunResponse {
}
export interface SubscribeToEventRequest {
    resourceArn: string;
    event: InspectorEvent;
    topicArn: string;
}
export interface SubscribeToEventResponse {
}
export interface UnsubscribeFromEventRequest {
    resourceArn: string;
    event: InspectorEvent;
    topicArn: string;
}
export interface UnsubscribeFromEventResponse {
}
export interface UpdateAssessmentTargetRequest {
    assessmentTargetArn: string;
    assessmentTargetName: string;
    resourceGroupArn?: string | undefined;
}
export interface UpdateAssessmentTargetResponse {
}
export type ErrorMessage = string;
export type AccessDeniedErrorCode = "ACCESS_DENIED_TO_ASSESSMENT_TARGET" | "ACCESS_DENIED_TO_ASSESSMENT_TEMPLATE" | "ACCESS_DENIED_TO_ASSESSMENT_RUN" | "ACCESS_DENIED_TO_FINDING" | "ACCESS_DENIED_TO_RESOURCE_GROUP" | "ACCESS_DENIED_TO_RULES_PACKAGE" | "ACCESS_DENIED_TO_SNS_TOPIC" | "ACCESS_DENIED_TO_IAM_ROLE" | (string & {});
export type InvalidInputErrorCode = "INVALID_ASSESSMENT_TARGET_ARN" | "INVALID_ASSESSMENT_TEMPLATE_ARN" | "INVALID_ASSESSMENT_RUN_ARN" | "INVALID_FINDING_ARN" | "INVALID_RESOURCE_GROUP_ARN" | "INVALID_RULES_PACKAGE_ARN" | "INVALID_RESOURCE_ARN" | "INVALID_SNS_TOPIC_ARN" | "INVALID_IAM_ROLE_ARN" | "INVALID_ASSESSMENT_TARGET_NAME" | "INVALID_ASSESSMENT_TARGET_NAME_PATTERN" | "INVALID_ASSESSMENT_TEMPLATE_NAME" | "INVALID_ASSESSMENT_TEMPLATE_NAME_PATTERN" | "INVALID_ASSESSMENT_TEMPLATE_DURATION" | "INVALID_ASSESSMENT_TEMPLATE_DURATION_RANGE" | "INVALID_ASSESSMENT_RUN_DURATION_RANGE" | "INVALID_ASSESSMENT_RUN_START_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_COMPLETION_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_STATE_CHANGE_TIME_RANGE" | "INVALID_ASSESSMENT_RUN_STATE" | "INVALID_TAG" | "INVALID_TAG_KEY" | "INVALID_TAG_VALUE" | "INVALID_RESOURCE_GROUP_TAG_KEY" | "INVALID_RESOURCE_GROUP_TAG_VALUE" | "INVALID_ATTRIBUTE" | "INVALID_USER_ATTRIBUTE" | "INVALID_USER_ATTRIBUTE_KEY" | "INVALID_USER_ATTRIBUTE_VALUE" | "INVALID_PAGINATION_TOKEN" | "INVALID_MAX_RESULTS" | "INVALID_AGENT_ID" | "INVALID_AUTO_SCALING_GROUP" | "INVALID_RULE_NAME" | "INVALID_SEVERITY" | "INVALID_LOCALE" | "INVALID_EVENT" | "ASSESSMENT_TARGET_NAME_ALREADY_TAKEN" | "ASSESSMENT_TEMPLATE_NAME_ALREADY_TAKEN" | "INVALID_NUMBER_OF_ASSESSMENT_TARGET_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_TEMPLATE_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_RUN_ARNS" | "INVALID_NUMBER_OF_FINDING_ARNS" | "INVALID_NUMBER_OF_RESOURCE_GROUP_ARNS" | "INVALID_NUMBER_OF_RULES_PACKAGE_ARNS" | "INVALID_NUMBER_OF_ASSESSMENT_RUN_STATES" | "INVALID_NUMBER_OF_TAGS" | "INVALID_NUMBER_OF_RESOURCE_GROUP_TAGS" | "INVALID_NUMBER_OF_ATTRIBUTES" | "INVALID_NUMBER_OF_USER_ATTRIBUTES" | "INVALID_NUMBER_OF_AGENT_IDS" | "INVALID_NUMBER_OF_AUTO_SCALING_GROUPS" | "INVALID_NUMBER_OF_RULE_NAMES" | "INVALID_NUMBER_OF_SEVERITIES" | (string & {});
export type NoSuchEntityErrorCode = "ASSESSMENT_TARGET_DOES_NOT_EXIST" | "ASSESSMENT_TEMPLATE_DOES_NOT_EXIST" | "ASSESSMENT_RUN_DOES_NOT_EXIST" | "FINDING_DOES_NOT_EXIST" | "RESOURCE_GROUP_DOES_NOT_EXIST" | "RULES_PACKAGE_DOES_NOT_EXIST" | "SNS_TOPIC_DOES_NOT_EXIST" | "IAM_ROLE_DOES_NOT_EXIST" | (string & {});
export type InvalidCrossAccountRoleErrorCode = "ROLE_DOES_NOT_EXIST_OR_INVALID_TRUST_RELATIONSHIP" | "ROLE_DOES_NOT_HAVE_CORRECT_POLICY" | (string & {});
export type LimitExceededErrorCode = "ASSESSMENT_TARGET_LIMIT_EXCEEDED" | "ASSESSMENT_TEMPLATE_LIMIT_EXCEEDED" | "ASSESSMENT_RUN_LIMIT_EXCEEDED" | "RESOURCE_GROUP_LIMIT_EXCEEDED" | "EVENT_SUBSCRIPTION_LIMIT_EXCEEDED" | (string & {});
export type AssessmentRunInProgressArnList = string[];
export interface AgentAlreadyRunningAssessment {
    agentId: string;
    assessmentRunArn: string;
}
export type AgentAlreadyRunningAssessmentList = AgentAlreadyRunningAssessment[];
export type AddAttributesToFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Assigns attributes (key and value pairs) to the findings that are specified by the
 * ARNs of the findings.
 */
export declare const addAttributesToFindings: API.OperationMethod<AddAttributesToFindingsRequest & RegionInput, AddAttributesToFindingsResponse, AddAttributesToFindingsError, Credentials | HttpClient.HttpClient>;
export type CreateAssessmentTargetError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates a new assessment target using the ARN of the resource group that is generated
 * by CreateResourceGroup. If resourceGroupArn is not specified, all EC2
 * instances in the current AWS account and region are included in the assessment target. If
 * the service-linked role isn't already registered, this action also creates and
 * registers a service-linked role to grant Amazon Inspector access to AWS Services needed to
 * perform security assessments. You can create up to 50 assessment targets per AWS account.
 * You can run up to 500 concurrent agents per AWS account. For more information, see
 * Amazon Inspector Assessment Targets.
 */
export declare const createAssessmentTarget: API.OperationMethod<CreateAssessmentTargetRequest & RegionInput, CreateAssessmentTargetResponse, CreateAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export type CreateAssessmentTemplateError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates an assessment template for the assessment target that is specified by the ARN
 * of the assessment target. If the service-linked role isn't already registered, this action also creates and
 * registers a service-linked role to grant Amazon Inspector access to AWS Services needed to
 * perform security assessments.
 */
export declare const createAssessmentTemplate: API.OperationMethod<CreateAssessmentTemplateRequest & RegionInput, CreateAssessmentTemplateResponse, CreateAssessmentTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateExclusionsPreviewError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | PreviewGenerationInProgressException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Starts the generation of an exclusions preview for the specified assessment template.
 * The exclusions preview lists the potential exclusions (ExclusionPreview) that Inspector can
 * detect before it runs the assessment.
 */
export declare const createExclusionsPreview: API.OperationMethod<CreateExclusionsPreviewRequest & RegionInput, CreateExclusionsPreviewResponse, CreateExclusionsPreviewError, Credentials | HttpClient.HttpClient>;
export type CreateResourceGroupError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Creates a resource group using the specified set of tags (key and value pairs) that
 * are used to select the EC2 instances to be included in an Amazon Inspector assessment
 * target. The created resource group is then used to create an Amazon Inspector assessment
 * target. For more information, see CreateAssessmentTarget.
 */
export declare const createResourceGroup: API.OperationMethod<CreateResourceGroupRequest & RegionInput, CreateResourceGroupResponse, CreateResourceGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentRunError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment run that is specified by the ARN of the assessment
 * run.
 */
export declare const deleteAssessmentRun: API.OperationMethod<DeleteAssessmentRunRequest & RegionInput, DeleteAssessmentRunResponse, DeleteAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentTargetError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment target that is specified by the ARN of the assessment
 * target.
 */
export declare const deleteAssessmentTarget: API.OperationMethod<DeleteAssessmentTargetRequest & RegionInput, DeleteAssessmentTargetResponse, DeleteAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssessmentTemplateError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Deletes the assessment template that is specified by the ARN of the assessment
 * template.
 */
export declare const deleteAssessmentTemplate: API.OperationMethod<DeleteAssessmentTemplateRequest & RegionInput, DeleteAssessmentTemplateResponse, DeleteAssessmentTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentRunsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment runs that are specified by the ARNs of the assessment
 * runs.
 */
export declare const describeAssessmentRuns: API.OperationMethod<DescribeAssessmentRunsRequest & RegionInput, DescribeAssessmentRunsResponse, DescribeAssessmentRunsError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentTargetsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment targets that are specified by the ARNs of the assessment
 * targets.
 */
export declare const describeAssessmentTargets: API.OperationMethod<DescribeAssessmentTargetsRequest & RegionInput, DescribeAssessmentTargetsResponse, DescribeAssessmentTargetsError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentTemplatesError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the assessment templates that are specified by the ARNs of the assessment
 * templates.
 */
export declare const describeAssessmentTemplates: API.OperationMethod<DescribeAssessmentTemplatesRequest & RegionInput, DescribeAssessmentTemplatesResponse, DescribeAssessmentTemplatesError, Credentials | HttpClient.HttpClient>;
export type DescribeCrossAccountAccessRoleError = InternalException | CommonErrors;
/**
 * Describes the IAM role that enables Amazon Inspector to access your AWS
 * account.
 */
export declare const describeCrossAccountAccessRole: API.OperationMethod<DescribeCrossAccountAccessRoleRequest & RegionInput, DescribeCrossAccountAccessRoleResponse, DescribeCrossAccountAccessRoleError, Credentials | HttpClient.HttpClient>;
export type DescribeExclusionsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the exclusions that are specified by the exclusions' ARNs.
 */
export declare const describeExclusions: API.OperationMethod<DescribeExclusionsRequest & RegionInput, DescribeExclusionsResponse, DescribeExclusionsError, Credentials | HttpClient.HttpClient>;
export type DescribeFindingsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the findings that are specified by the ARNs of the findings.
 */
export declare const describeFindings: API.OperationMethod<DescribeFindingsRequest & RegionInput, DescribeFindingsResponse, DescribeFindingsError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceGroupsError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the resource groups that are specified by the ARNs of the resource
 * groups.
 */
export declare const describeResourceGroups: API.OperationMethod<DescribeResourceGroupsRequest & RegionInput, DescribeResourceGroupsResponse, DescribeResourceGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeRulesPackagesError = InternalException | InvalidInputException | CommonErrors;
/**
 * Describes the rules packages that are specified by the ARNs of the rules
 * packages.
 */
export declare const describeRulesPackages: API.OperationMethod<DescribeRulesPackagesRequest & RegionInput, DescribeRulesPackagesResponse, DescribeRulesPackagesError, Credentials | HttpClient.HttpClient>;
export type GetAssessmentReportError = AccessDeniedException | AssessmentRunInProgressException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | UnsupportedFeatureException | CommonErrors;
/**
 * Produces an assessment report that includes detailed and comprehensive results of a
 * specified assessment run.
 */
export declare const getAssessmentReport: API.OperationMethod<GetAssessmentReportRequest & RegionInput, GetAssessmentReportResponse, GetAssessmentReportError, Credentials | HttpClient.HttpClient>;
export type GetExclusionsPreviewError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Retrieves the exclusions preview (a list of ExclusionPreview objects) specified by
 * the preview token. You can obtain the preview token by running the CreateExclusionsPreview
 * API.
 */
export declare const getExclusionsPreview: API.PaginatedOperationMethod<GetExclusionsPreviewRequest & RegionInput, GetExclusionsPreviewResponse, GetExclusionsPreviewError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTelemetryMetadataError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Information about the data that is collected for the specified assessment
 * run.
 */
export declare const getTelemetryMetadata: API.OperationMethod<GetTelemetryMetadataRequest & RegionInput, GetTelemetryMetadataResponse, GetTelemetryMetadataError, Credentials | HttpClient.HttpClient>;
export type ListAssessmentRunAgentsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the agents of the assessment runs that are specified by the ARNs of the
 * assessment runs.
 */
export declare const listAssessmentRunAgents: API.PaginatedOperationMethod<ListAssessmentRunAgentsRequest & RegionInput, ListAssessmentRunAgentsResponse, ListAssessmentRunAgentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentRunsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the assessment runs that correspond to the assessment templates that are
 * specified by the ARNs of the assessment templates.
 */
export declare const listAssessmentRuns: API.PaginatedOperationMethod<ListAssessmentRunsRequest & RegionInput, ListAssessmentRunsResponse, ListAssessmentRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentTargetsError = AccessDeniedException | InternalException | InvalidInputException | CommonErrors;
/**
 * Lists the ARNs of the assessment targets within this AWS account. For more
 * information about assessment targets, see Amazon Inspector Assessment
 * Targets.
 */
export declare const listAssessmentTargets: API.PaginatedOperationMethod<ListAssessmentTargetsRequest & RegionInput, ListAssessmentTargetsResponse, ListAssessmentTargetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAssessmentTemplatesError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists the assessment templates that correspond to the assessment targets that are
 * specified by the ARNs of the assessment targets.
 */
export declare const listAssessmentTemplates: API.PaginatedOperationMethod<ListAssessmentTemplatesRequest & RegionInput, ListAssessmentTemplatesResponse, ListAssessmentTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventSubscriptionsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists all the event subscriptions for the assessment template that is specified by
 * the ARN of the assessment template. For more information, see SubscribeToEvent and UnsubscribeFromEvent.
 */
export declare const listEventSubscriptions: API.PaginatedOperationMethod<ListEventSubscriptionsRequest & RegionInput, ListEventSubscriptionsResponse, ListEventSubscriptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExclusionsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * List exclusions that are generated by the assessment run.
 */
export declare const listExclusions: API.PaginatedOperationMethod<ListExclusionsRequest & RegionInput, ListExclusionsResponse, ListExclusionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists findings that are generated by the assessment runs that are specified by the
 * ARNs of the assessment runs.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest & RegionInput, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRulesPackagesError = AccessDeniedException | InternalException | InvalidInputException | CommonErrors;
/**
 * Lists all available Amazon Inspector rules packages.
 */
export declare const listRulesPackages: API.PaginatedOperationMethod<ListRulesPackagesRequest & RegionInput, ListRulesPackagesResponse, ListRulesPackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Lists all tags associated with an assessment template.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PreviewAgentsError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | NoSuchEntityException | CommonErrors;
/**
 * Previews the agents installed on the EC2 instances that are part of the specified
 * assessment target.
 */
export declare const previewAgents: API.PaginatedOperationMethod<PreviewAgentsRequest & RegionInput, PreviewAgentsResponse, PreviewAgentsError, Credentials | HttpClient.HttpClient, unknown>;
export type RegisterCrossAccountAccessRoleError = AccessDeniedException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Registers the IAM role that grants Amazon Inspector access to AWS Services needed to
 * perform security assessments.
 */
export declare const registerCrossAccountAccessRole: API.OperationMethod<RegisterCrossAccountAccessRoleRequest & RegionInput, RegisterCrossAccountAccessRoleResponse, RegisterCrossAccountAccessRoleError, Credentials | HttpClient.HttpClient>;
export type RemoveAttributesFromFindingsError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Removes entire attributes (key and value pairs) from the findings that are specified
 * by the ARNs of the findings where an attribute with the specified key exists.
 */
export declare const removeAttributesFromFindings: API.OperationMethod<RemoveAttributesFromFindingsRequest & RegionInput, RemoveAttributesFromFindingsResponse, RemoveAttributesFromFindingsError, Credentials | HttpClient.HttpClient>;
export type SetTagsForResourceError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Sets tags (key and value pairs) to the assessment template that is specified by the
 * ARN of the assessment template.
 */
export declare const setTagsForResource: API.OperationMethod<SetTagsForResourceRequest & RegionInput, SetTagsForResourceResponse, SetTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartAssessmentRunError = AccessDeniedException | AgentsAlreadyRunningAssessmentException | InternalException | InvalidCrossAccountRoleException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Starts the assessment run specified by the ARN of the assessment template. For this
 * API to function properly, you must not exceed the limit of running up to 500 concurrent
 * agents per AWS account.
 */
export declare const startAssessmentRun: API.OperationMethod<StartAssessmentRunRequest & RegionInput, StartAssessmentRunResponse, StartAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type StopAssessmentRunError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Stops the assessment run that is specified by the ARN of the assessment
 * run.
 */
export declare const stopAssessmentRun: API.OperationMethod<StopAssessmentRunRequest & RegionInput, StopAssessmentRunResponse, StopAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type SubscribeToEventError = AccessDeniedException | InternalException | InvalidInputException | LimitExceededException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Enables the process of sending Amazon Simple Notification Service (SNS) notifications
 * about a specified event to a specified SNS topic.
 */
export declare const subscribeToEvent: API.OperationMethod<SubscribeToEventRequest & RegionInput, SubscribeToEventResponse, SubscribeToEventError, Credentials | HttpClient.HttpClient>;
export type UnsubscribeFromEventError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Disables the process of sending Amazon Simple Notification Service (SNS)
 * notifications about a specified event to a specified SNS topic.
 */
export declare const unsubscribeFromEvent: API.OperationMethod<UnsubscribeFromEventRequest & RegionInput, UnsubscribeFromEventResponse, UnsubscribeFromEventError, Credentials | HttpClient.HttpClient>;
export type UpdateAssessmentTargetError = AccessDeniedException | InternalException | InvalidInputException | NoSuchEntityException | ServiceTemporarilyUnavailableException | CommonErrors;
/**
 * Updates the assessment target that is specified by the ARN of the assessment
 * target.
 *
 * If resourceGroupArn is not specified, all EC2 instances in the current AWS account
 * and region are included in the assessment target.
 */
export declare const updateAssessmentTarget: API.OperationMethod<UpdateAssessmentTargetRequest & RegionInput, UpdateAssessmentTargetResponse, UpdateAssessmentTargetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=inspector.d.ts.map