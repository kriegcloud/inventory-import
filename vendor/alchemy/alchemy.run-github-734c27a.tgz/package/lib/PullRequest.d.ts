import * as GraphQL from "@distilled.cloud/github/GraphQL";
import * as Issues from "@distilled.cloud/github/issues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
declare const PullRequestUnexpectedResponse_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "PullRequestUnexpectedResponse";
} & Readonly<A>;
export declare class PullRequestUnexpectedResponse extends PullRequestUnexpectedResponse_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export interface PullRequestProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Pull request title.
     */
    title: string;
    /**
     * Pull request body (supports GitHub Markdown).
     *
     * The body is automatically dedented, so you can use indented template
     * literals without worrying about leading whitespace. Accepts
     * `Output<string>` at the call site via `Output.interpolate` to embed
     * resource attributes that are not yet resolved.
     */
    body?: string;
    /**
     * The name of the branch where your changes are implemented (the source).
     */
    head: string;
    /**
     * The name of the branch you want the changes pulled into (the target).
     */
    base: string;
    /**
     * State of the pull request. Use "open" to reopen a closed PR or "closed"
     * to close an open PR. Note: only the PR owner, repo owner, or user with
     * push access can close PRs.
     * @default "open"
     */
    state?: "open" | "closed";
    /**
     * Whether the pull request is a draft.
     * @default false
     */
    draft?: boolean;
    /**
     * Labels to attach to the pull request. The provided list fully replaces
     * any existing labels.
     */
    labels?: string[];
    /**
     * Assignees (user logins) to assign to the pull request. The provided list
     * fully replaces existing assignees.
     */
    assignees?: string[];
    /**
     * Reviewers (user logins) to request reviews from. The provided list fully
     * replaces existing review requests.
     */
    reviewers?: string[];
    /**
     * Team slugs (for organization repos) to request reviews from.
     */
    teamReviewers?: string[];
    /**
     * Milestone number to assign to the pull request. Use `null` to remove
     * milestone.
     */
    milestone?: number | null;
    /**
     * Whether maintainers of the base repository can modify the pull
     * request's head branch. This does not change the pull request author.
     */
    maintainerCanModify?: boolean;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface PullRequest extends Resource<"GitHub.PullRequest", PullRequestProps, {
    /**
     * The numeric ID of the pull request in GitHub.
     */
    prNumber: number;
    /**
     * GraphQL node ID of the pull request.
     */
    nodeId: string;
    /**
     * URL to view the pull request in a browser.
     */
    htmlUrl: string;
    /**
     * State of the pull request (open or closed).
     */
    state: "open" | "closed";
    /**
     * Whether the pull request is merged.
     */
    merged: boolean;
    /**
     * Whether the pull request is a draft.
     */
    draft: boolean;
    /**
     * ISO-8601 timestamp of when the pull request was created.
     */
    createdAt: string;
    /**
     * ISO-8601 timestamp of the last update.
     */
    updatedAt: string;
}, never, GitHub.Providers, PullRequestLookup> {
}
/**
 * Props for {@link PullRequest.lookup}: find a pull request this
 * stack doesn't manage by its repository and number.
 */
export interface PullRequestLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Pull request number. */
    number: number;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub pull request.
 *
 * `PullRequest` manages the lifecycle of a pull request in a repository. PRs
 * are created on the first deploy and updated in place on subsequent deploys
 * when properties change. By default, pull requests are retained on
 * destruction to preserve history — set `destroy()` to opt in to closure.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope for private repositories or `public_repo` for public ones.
 *
 * ### Creating Pull Requests
 * **Example:** Create a Basic Pull Request
 * ```typescript
 * const pr = yield* GitHub.PullRequest("feature-pr", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Add new feature",
 *   body: "## Changes\n\nThis PR adds...",
 *   head: "feature-branch",
 *   base: "main",
 * })
 * ```
 *
 * **Example:** Draft Pull Request with Reviewers
 * ```typescript
 * const pr = yield* GitHub.PullRequest("draft-pr", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "WIP: New feature",
 *   body: "Work in progress...",
 *   head: "feature-branch",
 *   base: "main",
 *   draft: true,
 *   reviewers: ["reviewer1", "reviewer2"],
 *   teamReviewers: ["platform-team"],
 * })
 * ```
 *
 * ### Updating Pull Requests
 * Deploy with the same logical ID and different properties to update the
 * existing PR in place rather than creating a new one.
 *
 * **Example:** Update PR State
 * ```typescript
 * const pr = yield* GitHub.PullRequest("completed-pr", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Add new feature",
 *   body: "Completed and ready to merge.",
 *   head: "feature-branch",
 *   base: "main",
 *   state: "closed",
 * })
 * ```
 *
 * ### Pull Request with Labels and Milestone
 * **Example:** Organized Pull Request
 * ```typescript
 * const pr = yield* GitHub.PullRequest("release-pr", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Release v1.0",
 *   body: "Release notes...",
 *   head: "release-1.0",
 *   base: "main",
 *   labels: ["release", "v1.0"],
 *   milestone: 1,
 * })
 * ```
 *
 * ### Infrastructure Deployment PRs
 * A common pattern is creating PRs for infrastructure changes that require
 * review before merging.
 *
 * **Example:** Infrastructure Change PR
 * ```typescript
 * yield* GitHub.PullRequest("infra-update", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Update infrastructure configuration",
 *   body: Output.interpolate`
 *     ## Infrastructure Changes
 *
 *     **Database:** ${database.endpoint}
 *     **Cache:** ${cache.endpoint}
 *
 *     Requires approval before deployment.
 *   `,
 *   head: "infra-updates",
 *   base: "main",
 *   labels: ["infrastructure"],
 *   reviewers: ["infrastructure-lead"],
 * })
 * ```
 *
 * ### Looking up an existing pull request
 * `PullRequest.lookup` references a pull request Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 *
 * **Example:** Reference an existing pull request
 * ```typescript
 * const pr = GitHub.PullRequest.lookup({ owner: "alchemy-run", repository: "alchemy", number: 3094 });
 * ```
 *
 * @resource
 * @product Pull Request
 */
export declare const PullRequest: import("alchemy/Resource").ResourceClass<PullRequest>;
export declare const PullRequestProvider: () => import("effect/Layer").Layer<Provider.Provider<PullRequest>, never, GraphQL.GqlTransport | Issues.GithubOpContext>;
export {};
//# sourceMappingURL=PullRequest.d.ts.map