import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Bundle from "alchemy/Bundle/Bundle";
import { type PackageInstall } from "alchemy/Bundle/InstalledPackages";
import { type ExtraFile } from "alchemy/Util/extraFiles";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import type * as Redacted from "effect/Redacted";
import type * as rolldown from "rolldown";
import { type BuildCacheOptions } from "./BuildCache.ts";
import { type ContainerRuntime, type ContainerRuntimeSettings } from "./ContainerRuntime.ts";
import { Docker, type RegistryCredentials } from "./Docker.ts";
import { type InlineDockerfile } from "./Dockerfile.ts";
/**
 * INTERNAL — registry-agnostic container image-source machinery shared by
 * the container platforms (`AWS.ECS.*`, `AWS.EKS.*` via ECR, and
 * `Kubernetes.*` workloads pushing to any registry).
 *
 * NOT exported from any barrel. Consumers import the module path directly.
 *
 * A platform's props separate the ENVIRONMENT (what the container is) from
 * the PROGRAM (`main` — "and run my bundled Effect program in it"):
 *
 * - environment (at most one): `image` (registry ref) | `context` +
 *   `dockerfile`-as-path (docker build) | inline `dockerfile` content
 *   (`Dockerfile.inline`) | the default bun base when `main` stands alone.
 * - `main` present → the bundle is injected into the environment (COPY +
 *   ENTRYPOINT) and pushed as a derived image. `main` absent → the
 *   environment runs verbatim: `image` is mirrored (docker pull → tag →
 *   push, content-addressed on the ref), a Dockerfile builds as-is.
 * - `main` absent and an {@link ImageAgent} requested → the environment
 *   still runs verbatim, and the agent is pushed beside it as an image of
 *   its own, for the platform to mount into the environment's container.
 *
 * Where images land is an {@link ImageRegistryTarget}: ECR supplies one that
 * auto-creates a private repository; a plain registry (a local `registry`
 * container, GHCR, Docker Hub, …) supplies one that pushes to
 * `<server>/<name>`.
 */
/**
 * Bundle an Effect program into a generated image. Alchemy bundles `main`
 * with rolldown and bakes it into a Dockerfile generated from the
 * environment (`image`, `dockerfile`, or the default bun base).
 */
export interface BundledImageSource {
    /**
     * Module entrypoint for the bundled program. This should typically be
     * `import.meta.url` from an inline Effect program.
     */
    main: string;
    /**
     * Runtime the program runs on: `node` or `bun`, optionally with the
     * version the base image is tagged with. `"node24"` runs on
     * `node:24-slim`, `"bun1.3.13"` on `oven/bun:1.3.13`. An `image` beside it
     * replaces the base, and must be able to run this runtime. See
     * {@link ContainerRuntime}.
     * @default "node" (`node:26-slim`)
     */
    runtime?: ContainerRuntime;
    /**
     * @internal Dockerfile lines contributed by mount bindings (see
     * `alchemy/Mount`), inserted after the environment preamble so a
     * program change doesn't reinstall them. Hosts fold these in from their
     * bindings; users don't set them.
     */
    install?: ReadonlyArray<string>;
    /**
     * Environment image: used as the generated Dockerfile's `FROM`. Any
     * registry ref works (private non-ECR registries require docker
     * credentials on the build machine); the image must be able to run the
     * selected container runtime. Exclusive with {@link dockerfile} / {@link context}.
     * @default the {@link runtime}'s base image (`node:26-slim`)
     */
    image?: string;
    /**
     * Environment Dockerfile: a string is a PATH (built in {@link context},
     * then the bundle is layered on top in a second stage); an
     * {@link InlineDockerfile} is inline content used as the environment
     * preamble (built with no context — its own `COPY`s are unsupported).
     * The resulting environment must be able to run the selected container runtime.
     * Exclusive with {@link image}.
     */
    dockerfile?: string | InlineDockerfile;
    /**
     * Build context for a path {@link dockerfile} environment. Exclusive
     * with {@link image} and inline dockerfiles.
     */
    context?: string;
    /**
     * Named export to load from `main`.
     * @default "default"
     */
    handler?: string;
    /**
     * Bundler configuration for the entrypoint. Unused code is tree-shaken.
     * `effect`, alchemy, and `@distilled.cloud` are marked pure so unused
     * parts prune more aggressively. List extra packages with
     * `pure.packages`, or disable with `pure: false`. `cache` configures the
     * image build's BuildKit layer cache.
     */
    build?: Bundle.BundleConfig & BuildCacheOptions;
    /**
     * Files and directories copied into the image next to the bundle, under
     * `/app` (for example a website's client assets). Part of the image's
     * content hash.
     */
    extraFiles?: ReadonlyArray<ExtraFile>;
    /**
     * Packages `npm install`ed into an unbundled Node program's image instead
     * of bundled (native modules such as Next.js's `sharp`), at the versions
     * the project resolves. Only for an external `main` with `extraFiles`.
     */
    packages?: PackageInstall;
}
/**
 * Build arguments, BuildKit secrets and the layer cache for an image built
 * from the user's own Dockerfile (`context` / `dockerfile`).
 */
export interface DockerfileBuild extends BuildCacheOptions {
    /**
     * Docker build arguments (`--build-arg`), read by `ARG` instructions.
     * They are part of the image's content hash, so changing one rebuilds the
     * image. Never pass secrets here: build args are visible in the image
     * history. Use {@link secrets} instead.
     */
    args?: Record<string, string>;
    /**
     * BuildKit secrets, keyed by id. Mount one in a `RUN` step with
     * `--mount=type=secret,id=<id>` and read it from `/run/secrets/<id>`, or
     * add `env=<NAME>` to expose it as an environment variable for that step.
     *
     * A secret never enters the image, its build history, or `docker`'s argv.
     * Secrets are left out of the image's content hash, so rotating one does
     * not rebuild the image.
     */
    secrets?: Record<string, Redacted.Redacted<string>>;
}
/** The `build` prop of a source built from the user's own Dockerfile. */
export interface DockerfileBuildOptions {
    /** Build arguments, BuildKit secrets and the layer cache for the Dockerfile build. */
    build?: DockerfileBuild;
}
/**
 * Build the image from the user's own Dockerfile and build context — no
 * Effect program is bundled.
 */
export interface DockerfileImageSource extends DockerfileBuildOptions {
    /**
     * Docker build context directory. Optional when {@link dockerfile} is
     * inline content (which builds with an empty context).
     */
    context?: string;
    /**
     * Path to the Dockerfile relative to the cwd (NOT the context), or
     * {@link InlineDockerfile} content. The Dockerfile must define its own
     * `CMD`/`ENTRYPOINT` (no program is injected).
     * @default `${context}/Dockerfile`
     */
    dockerfile?: string | InlineDockerfile;
}
/**
 * Run a pre-built registry image. Registry-backed platforms may mirror it
 * into their own registry (ECR: docker pull → tag → push).
 */
export interface RegistryImageSource {
    /**
     * A pre-built image reference, e.g.
     * `public.ecr.aws/docker/library/busybox:stable`.
     */
    image: string;
}
/**
 * The image-source union. Discriminated by presence: exactly one of
 * `main`, `context`, or `image`.
 */
export type ImageSourceProps = BundledImageSource | DockerfileImageSource | RegistryImageSource;
/** Loose bag shape used to sniff which source variant a props object is. */
export interface ImageSourceLike {
    main?: string;
    /** Runtime of a bundled `main` (see {@link BundledImageSource.runtime}). */
    runtime?: ContainerRuntime;
    handler?: string;
    /** Bundler config for `main`; Docker build args and secrets for `context`. */
    build?: Bundle.BundleConfig & DockerfileBuild;
    context?: string;
    dockerfile?: string | InlineDockerfile;
    image?: string;
    /** @internal Mount-binding install lines (see {@link BundledImageSource.install}). */
    install?: ReadonlyArray<string>;
    /** Files copied next to a bundled `main` (see {@link BundledImageSource.extraFiles}). */
    extraFiles?: ReadonlyArray<ExtraFile>;
    /** Packages installed into an unbundled Node program's image (see {@link BundledImageSource.packages}). */
    packages?: PackageInstall;
}
/**
 * An unbundled Node program: an external `main` (already a complete
 * server) shipped with its `extraFiles` tree as built, so relative imports
 * between its chunks keep working.
 */
export declare const isNodeProgram: (source: ImageSourceLike, isExternal: boolean | undefined) => boolean;
export type ImageSourceKind = "main" | "context" | "image";
/**
 * Which image source a props bag declares. `main` always wins (the other
 * fields then describe its ENVIRONMENT); without `main`, `image` is the
 * mirrored-verbatim source and any `context`/`dockerfile` (path or inline)
 * is an external docker build.
 */
export declare const imageSourceKind: (source: ImageSourceLike) => ImageSourceKind | undefined;
declare const DockerfileBuildConflict_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DockerfileBuildConflict";
} & Readonly<A>;
/**
 * `build.args` or `build.secrets` set on an image that is not built from the
 * user's own Dockerfile (a `main` program or a pre-built `image`), or
 * `build.cache` set on a pre-built `image`, which is never built.
 */
export declare class DockerfileBuildConflict extends DockerfileBuildConflict_base<{
    readonly id: string;
    readonly source: "main" | "image";
    readonly option?: "cache";
}> {
    get message(): string;
}
/**
 * Dies with {@link DockerfileBuildConflict} when `build.args` or
 * `build.secrets` are set alongside `main` or `image`, or `build.cache`
 * alongside `image`.
 */
export declare const validateDockerfileBuild: (id: string, source: {
    main?: string;
    image?: string;
    build?: DockerfileBuild;
}) => Effect.Effect<void>;
/**
 * Validate environment-source exclusivity. Dies (plan-time defect) on
 * `image`+`dockerfile`, `image`+`context`, inline-`dockerfile`+`context`, or
 * build args/secrets without a Dockerfile build.
 */
export declare const validateImageSource: (id: string, source: ImageSourceLike) => Effect.Effect<void>;
/**
 * Where a resolved image is pushed. Each field is an Effect so a target can
 * create resources lazily (ECR creates the repository on first use). Each
 * field may fail and require differently; their errors and requirements
 * union into `resolve`'s own.
 */
export interface RegistryTargetFields<UriE, UriR, TagE, TagR, CredE, CredR> {
    /** The repository URI images are tagged into (`<repositoryUri>:<hash>`). */
    readonly repositoryUri: Effect.Effect<string, UriE, UriR>;
    /**
     * Whether the content-addressed tag is already in the registry. `true`
     * skips the build and push entirely.
     */
    readonly hasTag: (tag: string) => Effect.Effect<boolean, TagE, TagR>;
    /**
     * Push credentials. `undefined` pushes with the build machine's own
     * Docker configuration (`docker login`, credential helpers).
     */
    readonly credentials: Effect.Effect<RegistryCredentials | undefined, CredE, CredR>;
}
/** A registry target whose fields share one error and requirement type. */
export type ImageRegistryTarget<R = never, E = never> = RegistryTargetFields<E, R, E, R, E, R>;
export interface ResolveContainerImageOptions {
    /** Logical resource id — keys the stable build-context directory. */
    id: string;
    /**
     * The props bag carrying the image source fields (`main` / `context` /
     * `image` plus their modifiers).
     */
    source: ImageSourceLike;
    /**
     * Target image platform.
     * @default "linux/amd64"
     */
    platform?: string;
    /**
     * Port the generated Dockerfile should `ENV PORT=` + `EXPOSE`
     * (`main` source only).
     */
    port?: number;
    /**
     * True when the resource was declared without an inline Effect impl —
     * `main` is then bundled as-is without the virtual-entry bootstrap.
     */
    isExternal?: boolean;
    /**
     * The virtual-entry bootstrap wrapped around `main` for Effect-native
     * programs: receives the resolved entry import path and returns the
     * generated entry module source.
     */
    bootstrap: (importPath: string) => string;
    runtime?: ContainerRuntimeSettings;
    /**
     * Publish an agent beside an image that has no `main`. See
     * {@link ImageAgent}. Ignored for a `main` source, whose program serves the
     * agent itself.
     */
    agent?: ImageAgent;
    /** Plan-status session used to emit build/push progress notes. */
    session: {
        note: (message: string) => Effect.Effect<void>;
    };
}
/**
 * A program the platform runs inside a container whose image has none of its
 * own (`image` or `context`), so it can drive the container: a sandbox agent
 * that runs commands and serves files inside it.
 *
 * The image itself is never changed. The agent is bundled and pushed as an
 * image of its own, to the same repository, under an `agent-` tag. Run as a
 * container, that image copies the agent and its Bun runtime into
 * {@link IMAGE_AGENT_DIR} and exits. A platform mounts a volume there, shares
 * it with the image's container, and starts that container with
 * {@link imageAgentEntryPoint}. The agent runs on Bun whatever
 * `runtime` the image's programs use: it never shares a
 * process with them, and its terminals need Bun.
 */
export interface ImageAgent {
    /**
     * Module that exports `bootstrap(): Promise<void>`, which runs the agent.
     * A path or a `file:` URL.
     */
    main: string;
}
/**
 * Where an {@link ImageAgent}'s image copies the agent and its runtime, and
 * where the image's container finds them.
 */
export declare const IMAGE_AGENT_DIR = "/opt/alchemy/sandbox";
/**
 * The entry point that starts an {@link ImageAgent} from
 * {@link IMAGE_AGENT_DIR}. Bun starts through the loader that came with it,
 * so the image's own libc (glibc, another musl, or none) is never consulted
 * and the image needs nothing installed. The container's command arrives as
 * the agent's arguments.
 */
export declare const imageAgentEntryPoint: ReadonlyArray<string>;
/**
 * Content hash for the sources whose identity is computable WITHOUT running
 * a bundler:
 *
 * - `context` — hash of the build-context directory + Dockerfile content +
 *   platform.
 * - `image` — hash of the image reference + platform (re-mirror only when
 *   the ref changes).
 * - `main` — `undefined`: the hash comes from the bundle output, so it is
 *   only known inside `resolve`.
 *
 * Providers use this in `diff` to surface content drift (files changed under
 * an unchanged `context` path) as an update.
 */
export declare const computeStaticSourceHash: (source: ImageSourceLike, platform?: string | undefined) => Effect.Effect<string | undefined, import("./BuildHash.ts").BuildHashInvalidProps | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/** Docker and registry builds use the same artifact layout. Keep the Bun layout for existing images. */
export declare const containerBundleLayout: (runtime: ContainerRuntimeSettings) => {
    entrypoint: string;
    copy: string[];
    chunkFileNames: string | undefined;
};
/**
 * The exact rolldown input/output options `bundleMainProgram` hands to
 * `Bundle.build` — shared with {@link watchMain} so a dev watcher's
 * `Bundle.watch` observes the identical module graph.
 */
export declare const mainBundleOptions: (source: Pick<BundledImageSource, "build">, entry: string, cwd: string, runtime: ContainerRuntimeSettings, plugins?: rolldown.RolldownPluginOption) => {
    inputOptions: rolldown.InputOptions;
    outputOptions: rolldown.OutputOptions;
};
/**
 * Bundle the Effect program behind a `main` source: every emitted file
 * (entry + shared chunks) and the bundle hash. Needs no Docker engine, so
 * builders that are not Docker (`BuildPlan`) share it.
 */
export declare const bundleMainProgram: (options: {
    source: BundledImageSource;
    isExternal?: boolean;
    bootstrap: (importPath: string) => string;
    runtime?: ContainerRuntimeSettings;
}) => Effect.Effect<{
    files: {
        path: string;
        content: Uint8Array<ArrayBufferLike>;
    }[];
    hash: string;
}, Bundle.BundleError | import("./ContainerRuntime.ts").InvalidContainerRuntime | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/**
 * Init-time constructor for the image-source resolver. Resolves the services
 * that are only available at provider-layer construction (Docker, the
 * `.alchemy` directory, the rolldown virtual-entry plugin) and returns
 * `resolve` (build/mirror + push to an {@link ImageRegistryTarget}), `hash`,
 * and `watchMain`.
 */
export declare const makeContainerImageSource: Effect.Effect<{
    resolve: <UriE, UriR, TagE, TagR, CredE, CredR>(options: ResolveContainerImageOptions, target: RegistryTargetFields<UriE, UriR, TagE, TagR, CredE, CredR>) => Effect.Effect<{
        imageUri: string;
        repositoryUri: string;
        codeHash: string;
        agent: undefined;
    } | {
        imageUri: string;
        repositoryUri: string;
        codeHash: string;
        agent: {
            imageUri: string;
        };
    }, CredE | TagE | UriE | import("./BuildHash.ts").BuildHashInvalidProps | Bundle.BundleError | import("./ContainerRuntime.ts").InvalidContainerRuntime | import("effect/Cause").TimeoutError | import("./RegistryError.ts").DockerImagePublicationError, CredR | TagR | UriR | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
    hash: (options: {
        source: ImageSourceLike;
        platform?: string;
        port?: number;
        isExternal?: boolean;
        bootstrap: (importPath: string) => string;
        runtime?: ContainerRuntimeSettings;
        agent?: ImageAgent;
    }) => Effect.Effect<string | undefined, import("./BuildHash.ts").BuildHashInvalidProps | Bundle.BundleError | import("./ContainerRuntime.ts").InvalidContainerRuntime | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
    watchMain: (options: {
        source: BundledImageSource;
        isExternal?: boolean;
        bootstrap: (importPath: string) => string;
        runtime?: ContainerRuntimeSettings;
    }) => Effect.Effect<{
        inputOptions: rolldown.InputOptions;
        outputOptions: rolldown.OutputOptions;
        extra: (Bundle.BundleConfig & BuildCacheOptions) | undefined;
    }, import("./ContainerRuntime.ts").InvalidContainerRuntime | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
}, never, AlchemyContext | ChildProcessSpawner.ChildProcessSpawner | Docker | Path.Path>;
/** The resolver service returned by {@link makeContainerImageSource}. */
export interface ContainerImageSource extends Effect.Success<typeof makeContainerImageSource> {
}
export {};
//# sourceMappingURL=ImageSource.d.ts.map