import type { Kit, Models } from "../Kit.ts";
import type { Eval, Site, V } from "../Value.ts";
/**
 * `Number`, `BigInt`, `Boolean`, `Predicate`, `Function`, `Order`,
 * `Equivalence` and `Equal`: the small functions rules are written with.
 * Each does what the operator it stands for does.
 */
export declare const make: (kit: Kit) => {
    models: Models;
    values: Record<string, V>;
    pick: (name: string, largest: boolean, a: V, b: V, site: Site) => Eval<V>;
};
//# sourceMappingURL=Numbers.d.ts.map