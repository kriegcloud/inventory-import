import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const FeaturedResultsConflictException_base: S.TaggedErrorClass<"FeaturedResultsConflictException", {
    readonly message: any;
    readonly ConflictingItems: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class FeaturedResultsConflictException extends /*@__PURE__*/ FeaturedResultsConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const KendraClosedToNewCustomers_base: S.TaggedErrorClass<"KendraClosedToNewCustomers", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class KendraClosedToNewCustomers extends /*@__PURE__*/ KendraClosedToNewCustomers_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceAlreadyExistException_base: S.TaggedErrorClass<"ResourceAlreadyExistException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceAlreadyExistException extends /*@__PURE__*/ ResourceAlreadyExistException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ExperienceId = string;
export type IndexId = string;
export type EntityId = string;
export type EntityType = "USER" | "GROUP" | (string & {});
export interface EntityConfiguration {
    EntityId: string;
    EntityType: EntityType;
}
export type AssociateEntityList = EntityConfiguration[];
export interface AssociateEntitiesToExperienceRequest {
    Id: string;
    IndexId: string;
    EntityList: EntityConfiguration[];
}
export type ErrorMessage = string;
export interface FailedEntity {
    EntityId?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type AssociateEntitiesToExperienceFailedEntityList = FailedEntity[];
export interface AssociateEntitiesToExperienceResponse {
    FailedEntityList?: FailedEntity[] | undefined;
}
export type Persona = "OWNER" | "VIEWER" | (string & {});
export interface EntityPersonaConfiguration {
    EntityId: string;
    Persona: Persona;
}
export type EntityPersonaConfigurationList = EntityPersonaConfiguration[];
export interface AssociatePersonasToEntitiesRequest {
    Id: string;
    IndexId: string;
    Personas: EntityPersonaConfiguration[];
}
export type FailedEntityList = FailedEntity[];
export interface AssociatePersonasToEntitiesResponse {
    FailedEntityList?: FailedEntity[] | undefined;
}
export type DocumentId = string;
export type DocumentIdList = string[];
export type DataSourceId = string;
export type DataSourceSyncJobId = string;
export interface DataSourceSyncJobMetricTarget {
    DataSourceId: string;
    DataSourceSyncJobId?: string | undefined;
}
export interface BatchDeleteDocumentRequest {
    IndexId: string;
    DocumentIdList: string[];
    DataSourceSyncJobMetricTarget?: DataSourceSyncJobMetricTarget | undefined;
}
export type ErrorCode = "InternalError" | "InvalidRequest" | (string & {});
export interface BatchDeleteDocumentResponseFailedDocument {
    Id?: string | undefined;
    DataSourceId?: string | undefined;
    ErrorCode?: ErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchDeleteDocumentResponseFailedDocuments = BatchDeleteDocumentResponseFailedDocument[];
export interface BatchDeleteDocumentResponse {
    FailedDocuments?: BatchDeleteDocumentResponseFailedDocument[] | undefined;
}
export type FeaturedResultsSetId = string;
export type FeaturedResultsSetIdList = string[];
export interface BatchDeleteFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetIds: string[];
}
export interface BatchDeleteFeaturedResultsSetError_ {
    Id: string;
    ErrorCode: ErrorCode;
    ErrorMessage: string;
}
export type BatchDeleteFeaturedResultsSetErrors = BatchDeleteFeaturedResultsSetError_[];
export interface BatchDeleteFeaturedResultsSetResponse {
    Errors: BatchDeleteFeaturedResultsSetError_[];
}
export type DocumentAttributeKey = string;
export type DocumentAttributeStringValue = string;
export type DocumentAttributeStringListValue = string[];
export interface DocumentAttributeValue {
    StringValue?: string | undefined;
    StringListValue?: string[] | undefined;
    LongValue?: number | undefined;
    DateValue?: Date | undefined;
}
export interface DocumentAttribute {
    Key: string;
    Value: DocumentAttributeValue;
}
export type DocumentAttributeList = DocumentAttribute[];
export interface DocumentInfo {
    DocumentId: string;
    Attributes?: DocumentAttribute[] | undefined;
}
export type DocumentInfoList = DocumentInfo[];
export interface BatchGetDocumentStatusRequest {
    IndexId: string;
    DocumentInfoList: DocumentInfo[];
}
export interface BatchGetDocumentStatusResponseError {
    DocumentId?: string | undefined;
    DataSourceId?: string | undefined;
    ErrorCode?: ErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchGetDocumentStatusResponseErrors = BatchGetDocumentStatusResponseError[];
export type DocumentStatus = "NOT_FOUND" | "PROCESSING" | "INDEXED" | "UPDATED" | "FAILED" | "UPDATE_FAILED" | (string & {});
export interface Status {
    DocumentId?: string | undefined;
    DocumentStatus?: DocumentStatus | undefined;
    FailureCode?: string | undefined;
    FailureReason?: string | undefined;
}
export type DocumentStatusList = Status[];
export interface BatchGetDocumentStatusResponse {
    Errors?: BatchGetDocumentStatusResponseError[] | undefined;
    DocumentStatusList?: Status[] | undefined;
}
export type RoleArn = string;
export type Title = string;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Path {
    Bucket: string;
    Key: string;
}
export type PrincipalName = string;
export type PrincipalType = "USER" | "GROUP" | (string & {});
export type ReadAccessType = "ALLOW" | "DENY" | (string & {});
export interface Principal {
    Name: string;
    Type: PrincipalType;
    Access: ReadAccessType;
    DataSourceId?: string | undefined;
}
export type PrincipalList = Principal[];
export interface HierarchicalPrincipal {
    PrincipalList: Principal[];
}
export type HierarchicalPrincipalList = HierarchicalPrincipal[];
export type ContentType = "PDF" | "HTML" | "MS_WORD" | "PLAIN_TEXT" | "PPT" | "RTF" | "XML" | "XSLT" | "MS_EXCEL" | "CSV" | "JSON" | "MD" | (string & {});
export type AccessControlConfigurationId = string;
export interface Document {
    Id: string;
    Title?: string | undefined;
    Blob?: Uint8Array | undefined;
    S3Path?: S3Path | undefined;
    Attributes?: DocumentAttribute[] | undefined;
    AccessControlList?: Principal[] | undefined;
    HierarchicalAccessControlList?: HierarchicalPrincipal[] | undefined;
    ContentType?: ContentType | undefined;
    AccessControlConfigurationId?: string | undefined;
}
export type DocumentList = Document[];
export type ConditionOperator = "GreaterThan" | "GreaterThanOrEquals" | "LessThan" | "LessThanOrEquals" | "Equals" | "NotEquals" | "Contains" | "NotContains" | "Exists" | "NotExists" | "BeginsWith" | (string & {});
export interface DocumentAttributeCondition {
    ConditionDocumentAttributeKey: string;
    Operator: ConditionOperator;
    ConditionOnValue?: DocumentAttributeValue | undefined;
}
export interface DocumentAttributeTarget {
    TargetDocumentAttributeKey?: string | undefined;
    TargetDocumentAttributeValueDeletion?: boolean | undefined;
    TargetDocumentAttributeValue?: DocumentAttributeValue | undefined;
}
export interface InlineCustomDocumentEnrichmentConfiguration {
    Condition?: DocumentAttributeCondition | undefined;
    Target?: DocumentAttributeTarget | undefined;
    DocumentContentDeletion?: boolean | undefined;
}
export type InlineCustomDocumentEnrichmentConfigurationList = InlineCustomDocumentEnrichmentConfiguration[];
export type LambdaArn = string;
export interface HookConfiguration {
    InvocationCondition?: DocumentAttributeCondition | undefined;
    LambdaArn: string;
    S3Bucket: string;
}
export interface CustomDocumentEnrichmentConfiguration {
    InlineConfigurations?: InlineCustomDocumentEnrichmentConfiguration[] | undefined;
    PreExtractionHookConfiguration?: HookConfiguration | undefined;
    PostExtractionHookConfiguration?: HookConfiguration | undefined;
    RoleArn?: string | undefined;
}
export interface BatchPutDocumentRequest {
    IndexId: string;
    RoleArn?: string | undefined;
    Documents: Document[];
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration | undefined;
}
export interface BatchPutDocumentResponseFailedDocument {
    Id?: string | undefined;
    DataSourceId?: string | undefined;
    ErrorCode?: ErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchPutDocumentResponseFailedDocuments = BatchPutDocumentResponseFailedDocument[];
export interface BatchPutDocumentResponse {
    FailedDocuments?: BatchPutDocumentResponseFailedDocument[] | undefined;
}
export interface ClearQuerySuggestionsRequest {
    IndexId: string;
}
export interface ClearQuerySuggestionsResponse {
}
export type AccessControlConfigurationName = string;
export type Description = string;
export type ClientTokenName = string;
export interface CreateAccessControlConfigurationRequest {
    IndexId: string;
    Name: string;
    Description?: string | undefined;
    AccessControlList?: Principal[] | undefined;
    HierarchicalAccessControlList?: HierarchicalPrincipal[] | undefined;
    ClientToken?: string | undefined;
}
export interface CreateAccessControlConfigurationResponse {
    Id: string;
}
export type DataSourceName = string;
export type DataSourceType = "S3" | "SHAREPOINT" | "DATABASE" | "SALESFORCE" | "ONEDRIVE" | "SERVICENOW" | "CUSTOM" | "CONFLUENCE" | "GOOGLEDRIVE" | "WEBCRAWLER" | "WORKDOCS" | "FSX" | "SLACK" | "BOX" | "QUIP" | "JIRA" | "GITHUB" | "ALFRESCO" | "TEMPLATE" | (string & {});
export type DataSourceInclusionsExclusionsStringsMember = string;
export type DataSourceInclusionsExclusionsStrings = string[];
export interface DocumentsMetadataConfiguration {
    S3Prefix?: string | undefined;
}
export interface AccessControlListConfiguration {
    KeyPath?: string | undefined;
}
export interface S3DataSourceConfiguration {
    BucketName: string;
    InclusionPrefixes?: string[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    DocumentsMetadataConfiguration?: DocumentsMetadataConfiguration | undefined;
    AccessControlListConfiguration?: AccessControlListConfiguration | undefined;
}
export type SharePointVersion = "SHAREPOINT_2013" | "SHAREPOINT_2016" | "SHAREPOINT_ONLINE" | "SHAREPOINT_2019" | (string & {});
export type Url = string;
export type SharePointUrlList = string[];
export type SecretArn = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export type VpcSecurityGroupId = string;
export type SecurityGroupIdList = string[];
export interface DataSourceVpcConfiguration {
    SubnetIds: string[];
    SecurityGroupIds: string[];
}
export type DataSourceFieldName = string;
export type DataSourceDateFieldFormat = string;
export type IndexFieldName = string;
export interface DataSourceToIndexFieldMapping {
    DataSourceFieldName: string;
    DateFieldFormat?: string | undefined;
    IndexFieldName: string;
}
export type DataSourceToIndexFieldMappingList = DataSourceToIndexFieldMapping[];
export type SharePointOnlineAuthenticationType = "HTTP_BASIC" | "OAUTH2" | (string & {});
export type Host = string;
export type Port = number;
export interface ProxyConfiguration {
    Host: string;
    Port: number;
    Credentials?: string | undefined;
}
export interface SharePointConfiguration {
    SharePointVersion: SharePointVersion;
    Urls: string[];
    SecretArn: string;
    CrawlAttachments?: boolean | undefined;
    UseChangeLog?: boolean | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    DocumentTitleFieldName?: string | undefined;
    DisableLocalGroups?: boolean | undefined;
    SslCertificateS3Path?: S3Path | undefined;
    AuthenticationType?: SharePointOnlineAuthenticationType | undefined;
    ProxyConfiguration?: ProxyConfiguration | undefined;
}
export type DatabaseEngineType = "RDS_AURORA_MYSQL" | "RDS_AURORA_POSTGRESQL" | "RDS_MYSQL" | "RDS_POSTGRESQL" | (string & {});
export type DatabaseHost = string;
export type DatabasePort = number;
export type DatabaseName = string;
export type TableName = string;
export interface ConnectionConfiguration {
    DatabaseHost: string;
    DatabasePort: number;
    DatabaseName: string;
    TableName: string;
    SecretArn: string;
}
export type ColumnName = string;
export type ChangeDetectingColumns = string[];
export interface ColumnConfiguration {
    DocumentIdColumnName: string;
    DocumentDataColumnName: string;
    DocumentTitleColumnName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    ChangeDetectingColumns: string[];
}
export interface AclConfiguration {
    AllowedGroupsColumnName: string;
}
export type QueryIdentifiersEnclosingOption = "DOUBLE_QUOTES" | "NONE" | (string & {});
export interface SqlConfiguration {
    QueryIdentifiersEnclosingOption?: QueryIdentifiersEnclosingOption | undefined;
}
export interface DatabaseConfiguration {
    DatabaseEngineType: DatabaseEngineType;
    ConnectionConfiguration: ConnectionConfiguration;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    ColumnConfiguration: ColumnConfiguration;
    AclConfiguration?: AclConfiguration | undefined;
    SqlConfiguration?: SqlConfiguration | undefined;
}
export type SalesforceStandardObjectName = "ACCOUNT" | "CAMPAIGN" | "CASE" | "CONTACT" | "CONTRACT" | "DOCUMENT" | "GROUP" | "IDEA" | "LEAD" | "OPPORTUNITY" | "PARTNER" | "PRICEBOOK" | "PRODUCT" | "PROFILE" | "SOLUTION" | "TASK" | "USER" | (string & {});
export interface SalesforceStandardObjectConfiguration {
    Name: SalesforceStandardObjectName;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type SalesforceStandardObjectConfigurationList = SalesforceStandardObjectConfiguration[];
export type SalesforceKnowledgeArticleState = "DRAFT" | "PUBLISHED" | "ARCHIVED" | (string & {});
export type SalesforceKnowledgeArticleStateList = SalesforceKnowledgeArticleState[];
export interface SalesforceStandardKnowledgeArticleTypeConfiguration {
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type SalesforceCustomKnowledgeArticleTypeName = string;
export interface SalesforceCustomKnowledgeArticleTypeConfiguration {
    Name: string;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type SalesforceCustomKnowledgeArticleTypeConfigurationList = SalesforceCustomKnowledgeArticleTypeConfiguration[];
export interface SalesforceKnowledgeArticleConfiguration {
    IncludedStates: SalesforceKnowledgeArticleState[];
    StandardKnowledgeArticleTypeConfiguration?: SalesforceStandardKnowledgeArticleTypeConfiguration | undefined;
    CustomKnowledgeArticleTypeConfigurations?: SalesforceCustomKnowledgeArticleTypeConfiguration[] | undefined;
}
export type SalesforceChatterFeedIncludeFilterType = "ACTIVE_USER" | "STANDARD_USER" | (string & {});
export type SalesforceChatterFeedIncludeFilterTypes = SalesforceChatterFeedIncludeFilterType[];
export interface SalesforceChatterFeedConfiguration {
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    IncludeFilterTypes?: SalesforceChatterFeedIncludeFilterType[] | undefined;
}
export interface SalesforceStandardObjectAttachmentConfiguration {
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export interface SalesforceConfiguration {
    ServerUrl: string;
    SecretArn: string;
    StandardObjectConfigurations?: SalesforceStandardObjectConfiguration[] | undefined;
    KnowledgeArticleConfiguration?: SalesforceKnowledgeArticleConfiguration | undefined;
    ChatterFeedConfiguration?: SalesforceChatterFeedConfiguration | undefined;
    CrawlAttachments?: boolean | undefined;
    StandardObjectAttachmentConfiguration?: SalesforceStandardObjectAttachmentConfiguration | undefined;
    IncludeAttachmentFilePatterns?: string[] | undefined;
    ExcludeAttachmentFilePatterns?: string[] | undefined;
}
export type TenantDomain = string;
export type OneDriveUser = string;
export type OneDriveUserList = string[];
export interface OneDriveUsers {
    OneDriveUserList?: string[] | undefined;
    OneDriveUserS3Path?: S3Path | undefined;
}
export interface OneDriveConfiguration {
    TenantDomain: string;
    SecretArn: string;
    OneDriveUsers: OneDriveUsers;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    DisableLocalGroups?: boolean | undefined;
}
export type ServiceNowHostUrl = string;
export type ServiceNowBuildVersionType = "LONDON" | "OTHERS" | (string & {});
export type ServiceNowKnowledgeArticleFilterQuery = string;
export interface ServiceNowKnowledgeArticleConfiguration {
    CrawlAttachments?: boolean | undefined;
    IncludeAttachmentFilePatterns?: string[] | undefined;
    ExcludeAttachmentFilePatterns?: string[] | undefined;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    FilterQuery?: string | undefined;
}
export interface ServiceNowServiceCatalogConfiguration {
    CrawlAttachments?: boolean | undefined;
    IncludeAttachmentFilePatterns?: string[] | undefined;
    ExcludeAttachmentFilePatterns?: string[] | undefined;
    DocumentDataFieldName: string;
    DocumentTitleFieldName?: string | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type ServiceNowAuthenticationType = "HTTP_BASIC" | "OAUTH2" | (string & {});
export interface ServiceNowConfiguration {
    HostUrl: string;
    SecretArn: string;
    ServiceNowBuildVersion: ServiceNowBuildVersionType;
    KnowledgeArticleConfiguration?: ServiceNowKnowledgeArticleConfiguration | undefined;
    ServiceCatalogConfiguration?: ServiceNowServiceCatalogConfiguration | undefined;
    AuthenticationType?: ServiceNowAuthenticationType | undefined;
}
export type ConfluenceVersion = "CLOUD" | "SERVER" | (string & {});
export type ConfluenceSpaceIdentifier = string;
export type ConfluenceSpaceList = string[];
export type ConfluenceSpaceFieldName = "DISPLAY_URL" | "ITEM_TYPE" | "SPACE_KEY" | "URL" | (string & {});
export interface ConfluenceSpaceToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceSpaceFieldName | undefined;
    DateFieldFormat?: string | undefined;
    IndexFieldName?: string | undefined;
}
export type ConfluenceSpaceFieldMappingsList = ConfluenceSpaceToIndexFieldMapping[];
export interface ConfluenceSpaceConfiguration {
    CrawlPersonalSpaces?: boolean | undefined;
    CrawlArchivedSpaces?: boolean | undefined;
    IncludeSpaces?: string[] | undefined;
    ExcludeSpaces?: string[] | undefined;
    SpaceFieldMappings?: ConfluenceSpaceToIndexFieldMapping[] | undefined;
}
export type ConfluencePageFieldName = "AUTHOR" | "CONTENT_STATUS" | "CREATED_DATE" | "DISPLAY_URL" | "ITEM_TYPE" | "LABELS" | "MODIFIED_DATE" | "PARENT_ID" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export interface ConfluencePageToIndexFieldMapping {
    DataSourceFieldName?: ConfluencePageFieldName | undefined;
    DateFieldFormat?: string | undefined;
    IndexFieldName?: string | undefined;
}
export type ConfluencePageFieldMappingsList = ConfluencePageToIndexFieldMapping[];
export interface ConfluencePageConfiguration {
    PageFieldMappings?: ConfluencePageToIndexFieldMapping[] | undefined;
}
export type ConfluenceBlogFieldName = "AUTHOR" | "DISPLAY_URL" | "ITEM_TYPE" | "LABELS" | "PUBLISH_DATE" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export interface ConfluenceBlogToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceBlogFieldName | undefined;
    DateFieldFormat?: string | undefined;
    IndexFieldName?: string | undefined;
}
export type ConfluenceBlogFieldMappingsList = ConfluenceBlogToIndexFieldMapping[];
export interface ConfluenceBlogConfiguration {
    BlogFieldMappings?: ConfluenceBlogToIndexFieldMapping[] | undefined;
}
export type ConfluenceAttachmentFieldName = "AUTHOR" | "CONTENT_TYPE" | "CREATED_DATE" | "DISPLAY_URL" | "FILE_SIZE" | "ITEM_TYPE" | "PARENT_ID" | "SPACE_KEY" | "SPACE_NAME" | "URL" | "VERSION" | (string & {});
export interface ConfluenceAttachmentToIndexFieldMapping {
    DataSourceFieldName?: ConfluenceAttachmentFieldName | undefined;
    DateFieldFormat?: string | undefined;
    IndexFieldName?: string | undefined;
}
export type ConfluenceAttachmentFieldMappingsList = ConfluenceAttachmentToIndexFieldMapping[];
export interface ConfluenceAttachmentConfiguration {
    CrawlAttachments?: boolean | undefined;
    AttachmentFieldMappings?: ConfluenceAttachmentToIndexFieldMapping[] | undefined;
}
export type ConfluenceAuthenticationType = "HTTP_BASIC" | "PAT" | (string & {});
export interface ConfluenceConfiguration {
    ServerUrl: string;
    SecretArn: string;
    Version: ConfluenceVersion;
    SpaceConfiguration?: ConfluenceSpaceConfiguration | undefined;
    PageConfiguration?: ConfluencePageConfiguration | undefined;
    BlogConfiguration?: ConfluenceBlogConfiguration | undefined;
    AttachmentConfiguration?: ConfluenceAttachmentConfiguration | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    ProxyConfiguration?: ProxyConfiguration | undefined;
    AuthenticationType?: ConfluenceAuthenticationType | undefined;
}
export type MimeType = string;
export type ExcludeMimeTypesList = string[];
export type UserAccount = string;
export type ExcludeUserAccountsList = string[];
export type SharedDriveId = string;
export type ExcludeSharedDrivesList = string[];
export interface GoogleDriveConfiguration {
    SecretArn: string;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    ExcludeMimeTypes?: string[] | undefined;
    ExcludeUserAccounts?: string[] | undefined;
    ExcludeSharedDrives?: string[] | undefined;
}
export type SeedUrl = string;
export type SeedUrlList = string[];
export type WebCrawlerMode = "HOST_ONLY" | "SUBDOMAINS" | "EVERYTHING" | (string & {});
export interface SeedUrlConfiguration {
    SeedUrls: string[];
    WebCrawlerMode?: WebCrawlerMode | undefined;
}
export type SiteMap = string;
export type SiteMapsList = string[];
export interface SiteMapsConfiguration {
    SiteMaps: string[];
}
export interface Urls {
    SeedUrlConfiguration?: SeedUrlConfiguration | undefined;
    SiteMapsConfiguration?: SiteMapsConfiguration | undefined;
}
export type CrawlDepth = number;
export type MaxLinksPerPage = number;
export type MaxContentSizePerPageInMegaBytes = number;
export type MaxUrlsPerMinuteCrawlRate = number;
export interface BasicAuthenticationConfiguration {
    Host: string;
    Port: number;
    Credentials: string;
}
export type BasicAuthenticationConfigurationList = BasicAuthenticationConfiguration[];
export interface AuthenticationConfiguration {
    BasicAuthentication?: BasicAuthenticationConfiguration[] | undefined;
}
export interface WebCrawlerConfiguration {
    Urls: Urls;
    CrawlDepth?: number | undefined;
    MaxLinksPerPage?: number | undefined;
    MaxContentSizePerPageInMegaBytes?: number | undefined;
    MaxUrlsPerMinuteCrawlRate?: number | undefined;
    UrlInclusionPatterns?: string[] | undefined;
    UrlExclusionPatterns?: string[] | undefined;
    ProxyConfiguration?: ProxyConfiguration | undefined;
    AuthenticationConfiguration?: AuthenticationConfiguration | undefined;
}
export type OrganizationId = string;
export interface WorkDocsConfiguration {
    OrganizationId: string;
    CrawlComments?: boolean | undefined;
    UseChangeLog?: boolean | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type FileSystemId = string;
export type FsxFileSystemType = "WINDOWS" | (string & {});
export interface FsxConfiguration {
    FileSystemId: string;
    FileSystemType: FsxFileSystemType;
    VpcConfiguration: DataSourceVpcConfiguration;
    SecretArn?: string | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type TeamId = string;
export type SlackEntity = "PUBLIC_CHANNEL" | "PRIVATE_CHANNEL" | "GROUP_MESSAGE" | "DIRECT_MESSAGE" | (string & {});
export type SlackEntityList = SlackEntity[];
export type SinceCrawlDate = string;
export type LookBackPeriod = number;
export type PrivateChannelFilter = string[];
export type PublicChannelFilter = string[];
export interface SlackConfiguration {
    TeamId: string;
    SecretArn: string;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    SlackEntityList: SlackEntity[];
    UseChangeLog?: boolean | undefined;
    CrawlBotMessage?: boolean | undefined;
    ExcludeArchived?: boolean | undefined;
    SinceCrawlDate: string;
    LookBackPeriod?: number | undefined;
    PrivateChannelFilter?: string[] | undefined;
    PublicChannelFilter?: string[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    FieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type EnterpriseId = string;
export interface BoxConfiguration {
    EnterpriseId: string;
    SecretArn: string;
    UseChangeLog?: boolean | undefined;
    CrawlComments?: boolean | undefined;
    CrawlTasks?: boolean | undefined;
    CrawlWebLinks?: boolean | undefined;
    FileFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    TaskFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    CommentFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    WebLinkFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
}
export type Domain = string;
export type FolderId = string;
export type FolderIdList = string[];
export interface QuipConfiguration {
    Domain: string;
    SecretArn: string;
    CrawlFileComments?: boolean | undefined;
    CrawlChatRooms?: boolean | undefined;
    CrawlAttachments?: boolean | undefined;
    FolderIds?: string[] | undefined;
    ThreadFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    MessageFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    AttachmentFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
}
export type JiraAccountUrl = string;
export type Project = string[];
export type IssueType = string[];
export type JiraStatus = string[];
export type IssueSubEntity = "COMMENTS" | "ATTACHMENTS" | "WORKLOGS" | (string & {});
export type IssueSubEntityFilter = IssueSubEntity[];
export interface JiraConfiguration {
    JiraAccountUrl: string;
    SecretArn: string;
    UseChangeLog?: boolean | undefined;
    Project?: string[] | undefined;
    IssueType?: string[] | undefined;
    Status?: string[] | undefined;
    IssueSubEntityFilter?: IssueSubEntity[] | undefined;
    AttachmentFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    CommentFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    IssueFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    ProjectFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    WorkLogFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
}
export type OrganizationName = string;
export interface SaaSConfiguration {
    OrganizationName: string;
    HostUrl: string;
}
export interface OnPremiseConfiguration {
    HostUrl: string;
    OrganizationName: string;
    SslCertificateS3Path: S3Path;
}
export type Type = "SAAS" | "ON_PREMISE" | (string & {});
export interface GitHubDocumentCrawlProperties {
    CrawlRepositoryDocuments?: boolean | undefined;
    CrawlIssue?: boolean | undefined;
    CrawlIssueComment?: boolean | undefined;
    CrawlIssueCommentAttachment?: boolean | undefined;
    CrawlPullRequest?: boolean | undefined;
    CrawlPullRequestComment?: boolean | undefined;
    CrawlPullRequestCommentAttachment?: boolean | undefined;
}
export type RepositoryName = string;
export type RepositoryNames = string[];
export type StringList = string[];
export interface GitHubConfiguration {
    SaaSConfiguration?: SaaSConfiguration | undefined;
    OnPremiseConfiguration?: OnPremiseConfiguration | undefined;
    Type?: Type | undefined;
    SecretArn: string;
    UseChangeLog?: boolean | undefined;
    GitHubDocumentCrawlProperties?: GitHubDocumentCrawlProperties | undefined;
    RepositoryFilter?: string[] | undefined;
    InclusionFolderNamePatterns?: string[] | undefined;
    InclusionFileTypePatterns?: string[] | undefined;
    InclusionFileNamePatterns?: string[] | undefined;
    ExclusionFolderNamePatterns?: string[] | undefined;
    ExclusionFileTypePatterns?: string[] | undefined;
    ExclusionFileNamePatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    GitHubRepositoryConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubCommitConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubIssueDocumentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubIssueCommentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubIssueAttachmentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubPullRequestCommentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubPullRequestDocumentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    GitHubPullRequestDocumentAttachmentConfigurationFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
}
export type SiteUrl = string;
export type SiteId = string;
export type AlfrescoEntity = "wiki" | "blog" | "documentLibrary" | (string & {});
export type EntityFilter = AlfrescoEntity[];
export interface AlfrescoConfiguration {
    SiteUrl: string;
    SiteId: string;
    SecretArn: string;
    SslCertificateS3Path: S3Path;
    CrawlSystemFolders?: boolean | undefined;
    CrawlComments?: boolean | undefined;
    EntityFilter?: AlfrescoEntity[] | undefined;
    DocumentLibraryFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    BlogFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    WikiFieldMappings?: DataSourceToIndexFieldMapping[] | undefined;
    InclusionPatterns?: string[] | undefined;
    ExclusionPatterns?: string[] | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
}
export type Template = unknown;
export interface TemplateConfiguration {
    Template?: any | undefined;
}
export interface DataSourceConfiguration {
    S3Configuration?: S3DataSourceConfiguration | undefined;
    SharePointConfiguration?: SharePointConfiguration | undefined;
    DatabaseConfiguration?: DatabaseConfiguration | undefined;
    SalesforceConfiguration?: SalesforceConfiguration | undefined;
    OneDriveConfiguration?: OneDriveConfiguration | undefined;
    ServiceNowConfiguration?: ServiceNowConfiguration | undefined;
    ConfluenceConfiguration?: ConfluenceConfiguration | undefined;
    GoogleDriveConfiguration?: GoogleDriveConfiguration | undefined;
    WebCrawlerConfiguration?: WebCrawlerConfiguration | undefined;
    WorkDocsConfiguration?: WorkDocsConfiguration | undefined;
    FsxConfiguration?: FsxConfiguration | undefined;
    SlackConfiguration?: SlackConfiguration | undefined;
    BoxConfiguration?: BoxConfiguration | undefined;
    QuipConfiguration?: QuipConfiguration | undefined;
    JiraConfiguration?: JiraConfiguration | undefined;
    GitHubConfiguration?: GitHubConfiguration | undefined;
    AlfrescoConfiguration?: AlfrescoConfiguration | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
}
export type ScanSchedule = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type LanguageCode = string;
export interface CreateDataSourceRequest {
    Name: string;
    IndexId: string;
    Type: DataSourceType;
    Configuration?: DataSourceConfiguration | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    Description?: string | undefined;
    Schedule?: string | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
    LanguageCode?: string | undefined;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration | undefined;
}
export interface CreateDataSourceResponse {
    Id: string;
}
export type ExperienceName = string;
export type DataSourceIdList = string[];
export type FaqId = string;
export type FaqIdsList = string[];
export interface ContentSourceConfiguration {
    DataSourceIds?: string[] | undefined;
    FaqIds?: string[] | undefined;
    DirectPutContent?: boolean | undefined;
}
export type IdentityAttributeName = string;
export interface UserIdentityConfiguration {
    IdentityAttributeName?: string | undefined;
}
export interface ExperienceConfiguration {
    ContentSourceConfiguration?: ContentSourceConfiguration | undefined;
    UserIdentityConfiguration?: UserIdentityConfiguration | undefined;
}
export interface CreateExperienceRequest {
    Name: string;
    IndexId: string;
    RoleArn?: string | undefined;
    Configuration?: ExperienceConfiguration | undefined;
    Description?: string | undefined;
    ClientToken?: string | undefined;
}
export interface CreateExperienceResponse {
    Id: string;
}
export type FaqName = string;
export type FaqFileFormat = "CSV" | "CSV_WITH_HEADER" | "JSON" | (string & {});
export interface CreateFaqRequest {
    IndexId: string;
    Name: string;
    Description?: string | undefined;
    S3Path: S3Path;
    RoleArn: string;
    Tags?: Tag[] | undefined;
    FileFormat?: FaqFileFormat | undefined;
    ClientToken?: string | undefined;
    LanguageCode?: string | undefined;
}
export interface CreateFaqResponse {
    Id?: string | undefined;
}
export type FeaturedResultsSetName = string;
export type FeaturedResultsSetDescription = string;
export type FeaturedResultsSetStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type QueryText = string;
export type QueryTextList = string[];
export interface FeaturedDocument {
    Id?: string | undefined;
}
export type FeaturedDocumentList = FeaturedDocument[];
export interface CreateFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetName: string;
    Description?: string | undefined;
    ClientToken?: string | undefined;
    Status?: FeaturedResultsSetStatus | undefined;
    QueryTexts?: string[] | undefined;
    FeaturedDocuments?: FeaturedDocument[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface FeaturedResultsSet {
    FeaturedResultsSetId?: string | undefined;
    FeaturedResultsSetName?: string | undefined;
    Description?: string | undefined;
    Status?: FeaturedResultsSetStatus | undefined;
    QueryTexts?: string[] | undefined;
    FeaturedDocuments?: FeaturedDocument[] | undefined;
    LastUpdatedTimestamp?: number | undefined;
    CreationTimestamp?: number | undefined;
}
export interface CreateFeaturedResultsSetResponse {
    FeaturedResultsSet?: FeaturedResultsSet | undefined;
}
export type IndexName = string;
export type IndexEdition = "DEVELOPER_EDITION" | "ENTERPRISE_EDITION" | "GEN_AI_ENTERPRISE_EDITION" | (string & {});
export type KmsKeyId = string | redacted.Redacted<string>;
export interface ServerSideEncryptionConfiguration {
    KmsKeyId?: string | redacted.Redacted<string> | undefined;
}
export type KeyLocation = "URL" | "SECRET_MANAGER" | (string & {});
export type UserNameAttributeField = string;
export type GroupAttributeField = string;
export type Issuer = string;
export type ClaimRegex = string;
export interface JwtTokenTypeConfiguration {
    KeyLocation: KeyLocation;
    URL?: string | undefined;
    SecretManagerArn?: string | undefined;
    UserNameAttributeField?: string | undefined;
    GroupAttributeField?: string | undefined;
    Issuer?: string | undefined;
    ClaimRegex?: string | undefined;
}
export interface JsonTokenTypeConfiguration {
    UserNameAttributeField: string;
    GroupAttributeField: string;
}
export interface UserTokenConfiguration {
    JwtTokenTypeConfiguration?: JwtTokenTypeConfiguration | undefined;
    JsonTokenTypeConfiguration?: JsonTokenTypeConfiguration | undefined;
}
export type UserTokenConfigurationList = UserTokenConfiguration[];
export type UserContextPolicy = "ATTRIBUTE_FILTER" | "USER_TOKEN" | (string & {});
export type UserGroupResolutionMode = "AWS_SSO" | "NONE" | (string & {});
export interface UserGroupResolutionConfiguration {
    UserGroupResolutionMode: UserGroupResolutionMode;
}
export interface CreateIndexRequest {
    Name: string;
    Edition?: IndexEdition | undefined;
    RoleArn: string;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    Description?: string | undefined;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
    UserTokenConfigurations?: UserTokenConfiguration[] | undefined;
    UserContextPolicy?: UserContextPolicy | undefined;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration | undefined;
}
export interface CreateIndexResponse {
    Id?: string | undefined;
}
export type QuerySuggestionsBlockListName = string;
export interface CreateQuerySuggestionsBlockListRequest {
    IndexId: string;
    Name: string;
    Description?: string | undefined;
    SourceS3Path: S3Path;
    ClientToken?: string | undefined;
    RoleArn: string;
    Tags?: Tag[] | undefined;
}
export type QuerySuggestionsBlockListId = string;
export interface CreateQuerySuggestionsBlockListResponse {
    Id?: string | undefined;
}
export type ThesaurusName = string;
export interface CreateThesaurusRequest {
    IndexId: string;
    Name: string;
    Description?: string | undefined;
    RoleArn: string;
    Tags?: Tag[] | undefined;
    SourceS3Path: S3Path;
    ClientToken?: string | undefined;
}
export type ThesaurusId = string;
export interface CreateThesaurusResponse {
    Id?: string | undefined;
}
export interface DeleteAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
}
export interface DeleteAccessControlConfigurationResponse {
}
export interface DeleteDataSourceRequest {
    Id: string;
    IndexId: string;
}
export interface DeleteDataSourceResponse {
}
export interface DeleteExperienceRequest {
    Id: string;
    IndexId: string;
}
export interface DeleteExperienceResponse {
}
export interface DeleteFaqRequest {
    Id: string;
    IndexId: string;
}
export interface DeleteFaqResponse {
}
export interface DeleteIndexRequest {
    Id: string;
}
export interface DeleteIndexResponse {
}
export type GroupId = string;
export type PrincipalOrderingId = number;
export interface DeletePrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string | undefined;
    GroupId: string;
    OrderingId?: number | undefined;
}
export interface DeletePrincipalMappingResponse {
}
export interface DeleteQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
}
export interface DeleteQuerySuggestionsBlockListResponse {
}
export interface DeleteThesaurusRequest {
    Id: string;
    IndexId: string;
}
export interface DeleteThesaurusResponse {
}
export interface DescribeAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
}
export interface DescribeAccessControlConfigurationResponse {
    Name: string;
    Description?: string | undefined;
    ErrorMessage?: string | undefined;
    AccessControlList?: Principal[] | undefined;
    HierarchicalAccessControlList?: HierarchicalPrincipal[] | undefined;
}
export interface DescribeDataSourceRequest {
    Id: string;
    IndexId: string;
}
export type DataSourceStatus = "CREATING" | "DELETING" | "FAILED" | "UPDATING" | "ACTIVE" | (string & {});
export interface DescribeDataSourceResponse {
    Id?: string | undefined;
    IndexId?: string | undefined;
    Name?: string | undefined;
    Type?: DataSourceType | undefined;
    Configuration?: DataSourceConfiguration | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Description?: string | undefined;
    Status?: DataSourceStatus | undefined;
    Schedule?: string | undefined;
    RoleArn?: string | undefined;
    ErrorMessage?: string | undefined;
    LanguageCode?: string | undefined;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration | undefined;
}
export interface DescribeExperienceRequest {
    Id: string;
    IndexId: string;
}
export type EndpointType = "HOME" | (string & {});
export type Endpoint = string;
export interface ExperienceEndpoint {
    EndpointType?: EndpointType | undefined;
    Endpoint?: string | undefined;
}
export type ExperienceEndpoints = ExperienceEndpoint[];
export type ExperienceStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export interface DescribeExperienceResponse {
    Id?: string | undefined;
    IndexId?: string | undefined;
    Name?: string | undefined;
    Endpoints?: ExperienceEndpoint[] | undefined;
    Configuration?: ExperienceConfiguration | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Description?: string | undefined;
    Status?: ExperienceStatus | undefined;
    RoleArn?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface DescribeFaqRequest {
    Id: string;
    IndexId: string;
}
export type FaqStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export interface DescribeFaqResponse {
    Id?: string | undefined;
    IndexId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    S3Path?: S3Path | undefined;
    Status?: FaqStatus | undefined;
    RoleArn?: string | undefined;
    ErrorMessage?: string | undefined;
    FileFormat?: FaqFileFormat | undefined;
    LanguageCode?: string | undefined;
}
export interface DescribeFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetId: string;
}
export interface FeaturedDocumentWithMetadata {
    Id?: string | undefined;
    Title?: string | undefined;
    URI?: string | undefined;
}
export type FeaturedDocumentWithMetadataList = FeaturedDocumentWithMetadata[];
export interface FeaturedDocumentMissing {
    Id?: string | undefined;
}
export type FeaturedDocumentMissingList = FeaturedDocumentMissing[];
export interface DescribeFeaturedResultsSetResponse {
    FeaturedResultsSetId?: string | undefined;
    FeaturedResultsSetName?: string | undefined;
    Description?: string | undefined;
    Status?: FeaturedResultsSetStatus | undefined;
    QueryTexts?: string[] | undefined;
    FeaturedDocumentsWithMetadata?: FeaturedDocumentWithMetadata[] | undefined;
    FeaturedDocumentsMissing?: FeaturedDocumentMissing[] | undefined;
    LastUpdatedTimestamp?: number | undefined;
    CreationTimestamp?: number | undefined;
}
export interface DescribeIndexRequest {
    Id: string;
}
export type IndexStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | "SYSTEM_UPDATING" | (string & {});
export type DocumentMetadataConfigurationName = string;
export type DocumentAttributeValueType = "STRING_VALUE" | "STRING_LIST_VALUE" | "LONG_VALUE" | "DATE_VALUE" | (string & {});
export type DocumentMetadataBoolean = boolean;
export type Importance = number;
export type Duration = string;
export type Order = "ASCENDING" | "DESCENDING" | (string & {});
export type ValueImportanceMapKey = string;
export type ValueImportanceMap = {
    [key: string]: number | undefined;
};
export interface Relevance {
    Freshness?: boolean | undefined;
    Importance?: number | undefined;
    Duration?: string | undefined;
    RankOrder?: Order | undefined;
    ValueImportanceMap?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface Search {
    Facetable?: boolean | undefined;
    Searchable?: boolean | undefined;
    Displayable?: boolean | undefined;
    Sortable?: boolean | undefined;
}
export interface DocumentMetadataConfiguration {
    Name: string;
    Type: DocumentAttributeValueType;
    Relevance?: Relevance | undefined;
    Search?: Search | undefined;
}
export type DocumentMetadataConfigurationList = DocumentMetadataConfiguration[];
export type IndexedQuestionAnswersCount = number;
export interface FaqStatistics {
    IndexedQuestionAnswersCount: number;
}
export type IndexedTextDocumentsCount = number;
export type IndexedTextBytes = number;
export interface TextDocumentStatistics {
    IndexedTextDocumentsCount: number;
    IndexedTextBytes: number;
}
export interface IndexStatistics {
    FaqStatistics: FaqStatistics;
    TextDocumentStatistics: TextDocumentStatistics;
}
export type StorageCapacityUnit = number;
export type QueryCapacityUnit = number;
export interface CapacityUnitsConfiguration {
    StorageCapacityUnits: number;
    QueryCapacityUnits: number;
}
export interface DescribeIndexResponse {
    Name?: string | undefined;
    Id?: string | undefined;
    Edition?: IndexEdition | undefined;
    RoleArn?: string | undefined;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    Status?: IndexStatus | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    DocumentMetadataConfigurations?: DocumentMetadataConfiguration[] | undefined;
    IndexStatistics?: IndexStatistics | undefined;
    ErrorMessage?: string | undefined;
    CapacityUnits?: CapacityUnitsConfiguration | undefined;
    UserTokenConfigurations?: UserTokenConfiguration[] | undefined;
    UserContextPolicy?: UserContextPolicy | undefined;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration | undefined;
}
export interface DescribePrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string | undefined;
    GroupId: string;
}
export type PrincipalMappingStatus = "FAILED" | "SUCCEEDED" | "PROCESSING" | "DELETING" | "DELETED" | (string & {});
export type FailureReason = string;
export interface GroupOrderingIdSummary {
    Status?: PrincipalMappingStatus | undefined;
    LastUpdatedAt?: Date | undefined;
    ReceivedAt?: Date | undefined;
    OrderingId?: number | undefined;
    FailureReason?: string | undefined;
}
export type GroupOrderingIdSummaries = GroupOrderingIdSummary[];
export interface DescribePrincipalMappingResponse {
    IndexId?: string | undefined;
    DataSourceId?: string | undefined;
    GroupId?: string | undefined;
    GroupOrderingIdSummaries?: GroupOrderingIdSummary[] | undefined;
}
export interface DescribeQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
}
export type QuerySuggestionsBlockListStatus = "ACTIVE" | "CREATING" | "DELETING" | "UPDATING" | "ACTIVE_BUT_UPDATE_FAILED" | "FAILED" | (string & {});
export interface DescribeQuerySuggestionsBlockListResponse {
    IndexId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: QuerySuggestionsBlockListStatus | undefined;
    ErrorMessage?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    SourceS3Path?: S3Path | undefined;
    ItemCount?: number | undefined;
    FileSizeBytes?: number | undefined;
    RoleArn?: string | undefined;
}
export interface DescribeQuerySuggestionsConfigRequest {
    IndexId: string;
}
export type Mode = "ENABLED" | "LEARN_ONLY" | (string & {});
export type QuerySuggestionsStatus = "ACTIVE" | "UPDATING" | (string & {});
export type ObjectBoolean = boolean;
export type MinimumNumberOfQueryingUsers = number;
export type MinimumQueryCount = number;
export interface SuggestableConfig {
    AttributeName?: string | undefined;
    Suggestable?: boolean | undefined;
}
export type SuggestableConfigList = SuggestableConfig[];
export type AttributeSuggestionsMode = "ACTIVE" | "INACTIVE" | (string & {});
export interface AttributeSuggestionsDescribeConfig {
    SuggestableConfigList?: SuggestableConfig[] | undefined;
    AttributeSuggestionsMode?: AttributeSuggestionsMode | undefined;
}
export interface DescribeQuerySuggestionsConfigResponse {
    Mode?: Mode | undefined;
    Status?: QuerySuggestionsStatus | undefined;
    QueryLogLookBackWindowInDays?: number | undefined;
    IncludeQueriesWithoutUserInformation?: boolean | undefined;
    MinimumNumberOfQueryingUsers?: number | undefined;
    MinimumQueryCount?: number | undefined;
    LastSuggestionsBuildTime?: Date | undefined;
    LastClearTime?: Date | undefined;
    TotalSuggestionsCount?: number | undefined;
    AttributeSuggestionsConfig?: AttributeSuggestionsDescribeConfig | undefined;
}
export interface DescribeThesaurusRequest {
    Id: string;
    IndexId: string;
}
export type ThesaurusStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | "ACTIVE_BUT_UPDATE_FAILED" | "FAILED" | (string & {});
export interface DescribeThesaurusResponse {
    Id?: string | undefined;
    IndexId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: ThesaurusStatus | undefined;
    ErrorMessage?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    RoleArn?: string | undefined;
    SourceS3Path?: S3Path | undefined;
    FileSizeBytes?: number | undefined;
    TermCount?: number | undefined;
    SynonymRuleCount?: number | undefined;
}
export type DisassociateEntityList = EntityConfiguration[];
export interface DisassociateEntitiesFromExperienceRequest {
    Id: string;
    IndexId: string;
    EntityList: EntityConfiguration[];
}
export interface DisassociateEntitiesFromExperienceResponse {
    FailedEntityList?: FailedEntity[] | undefined;
}
export type EntityIdsList = string[];
export interface DisassociatePersonasFromEntitiesRequest {
    Id: string;
    IndexId: string;
    EntityIds: string[];
}
export interface DisassociatePersonasFromEntitiesResponse {
    FailedEntityList?: FailedEntity[] | undefined;
}
export type SuggestionQueryText = string;
export type SuggestionType = "QUERY" | "DOCUMENT_ATTRIBUTES" | (string & {});
export type SuggestionTypes = SuggestionType[];
export type DocumentAttributeKeyList = string[];
export type AttributeFilterList = AttributeFilter[];
export interface AttributeFilter {
    AndAllFilters?: AttributeFilter[] | undefined;
    OrAllFilters?: AttributeFilter[] | undefined;
    NotFilter?: AttributeFilter | undefined;
    EqualsTo?: DocumentAttribute | undefined;
    ContainsAll?: DocumentAttribute | undefined;
    ContainsAny?: DocumentAttribute | undefined;
    GreaterThan?: DocumentAttribute | undefined;
    GreaterThanOrEquals?: DocumentAttribute | undefined;
    LessThan?: DocumentAttribute | undefined;
    LessThanOrEquals?: DocumentAttribute | undefined;
}
export type Token = string;
export type Groups = string[];
export interface DataSourceGroup {
    GroupId: string;
    DataSourceId: string;
}
export type DataSourceGroups = DataSourceGroup[];
export interface UserContext {
    Token?: string | redacted.Redacted<string> | undefined;
    UserId?: string | undefined;
    Groups?: string[] | undefined;
    DataSourceGroups?: DataSourceGroup[] | undefined;
}
export interface AttributeSuggestionsGetConfig {
    SuggestionAttributes?: string[] | undefined;
    AdditionalResponseAttributes?: string[] | undefined;
    AttributeFilter?: AttributeFilter | undefined;
    UserContext?: UserContext | undefined;
}
export interface GetQuerySuggestionsRequest {
    IndexId: string;
    QueryText: string;
    MaxSuggestionsCount?: number | undefined;
    SuggestionTypes?: SuggestionType[] | undefined;
    AttributeSuggestionsConfig?: AttributeSuggestionsGetConfig | undefined;
}
export type QuerySuggestionsId = string;
export type ResultId = string;
export interface SuggestionHighlight {
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
}
export type SuggestionHighlightList = SuggestionHighlight[];
export interface SuggestionTextWithHighlights {
    Text?: string | undefined;
    Highlights?: SuggestionHighlight[] | undefined;
}
export interface SuggestionValue {
    Text?: SuggestionTextWithHighlights | undefined;
}
export interface SourceDocument {
    DocumentId?: string | undefined;
    SuggestionAttributes?: string[] | undefined;
    AdditionalAttributes?: DocumentAttribute[] | undefined;
}
export type SourceDocuments = SourceDocument[];
export interface Suggestion {
    Id?: string | undefined;
    Value?: SuggestionValue | undefined;
    SourceDocuments?: SourceDocument[] | undefined;
}
export type SuggestionList = Suggestion[];
export interface GetQuerySuggestionsResponse {
    QuerySuggestionsId?: string | undefined;
    Suggestions?: Suggestion[] | undefined;
}
export type Interval = "THIS_MONTH" | "THIS_WEEK" | "ONE_WEEK_AGO" | "TWO_WEEKS_AGO" | "ONE_MONTH_AGO" | "TWO_MONTHS_AGO" | (string & {});
export type MetricType = "QUERIES_BY_COUNT" | "QUERIES_BY_ZERO_CLICK_RATE" | "QUERIES_BY_ZERO_RESULT_RATE" | "DOCS_BY_CLICK_COUNT" | "AGG_QUERY_DOC_METRICS" | "TREND_QUERY_DOC_METRICS" | (string & {});
export type NextToken = string;
export interface GetSnapshotsRequest {
    IndexId: string;
    Interval: Interval;
    MetricType: MetricType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TimeRange {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type SnapshotsDataHeaderFields = string[];
export type SnapshotsDataRecord = string[];
export type SnapshotsDataRecords = string[][];
export interface GetSnapshotsResponse {
    SnapShotTimeFilter?: TimeRange | undefined;
    SnapshotsDataHeader?: string[] | undefined;
    SnapshotsData?: string[][] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListAccessControlConfigurationsRequest = number;
export interface ListAccessControlConfigurationsRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AccessControlConfigurationSummary {
    Id: string;
}
export type AccessControlConfigurationSummaryList = AccessControlConfigurationSummary[];
export interface ListAccessControlConfigurationsResponse {
    NextToken?: string | undefined;
    AccessControlConfigurations: AccessControlConfigurationSummary[];
}
export type MaxResultsIntegerForListDataSourcesRequest = number;
export interface ListDataSourcesRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataSourceSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Type?: DataSourceType | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Status?: DataSourceStatus | undefined;
    LanguageCode?: string | undefined;
}
export type DataSourceSummaryList = DataSourceSummary[];
export interface ListDataSourcesResponse {
    SummaryItems?: DataSourceSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListDataSourceSyncJobsRequest = number;
export type DataSourceSyncJobStatus = "FAILED" | "SUCCEEDED" | "SYNCING" | "INCOMPLETE" | "STOPPING" | "ABORTED" | "SYNCING_INDEXING" | (string & {});
export interface ListDataSourceSyncJobsRequest {
    Id: string;
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StartTimeFilter?: TimeRange | undefined;
    StatusFilter?: DataSourceSyncJobStatus | undefined;
}
export type MetricValue = string;
export interface DataSourceSyncJobMetrics {
    DocumentsAdded?: string | undefined;
    DocumentsModified?: string | undefined;
    DocumentsDeleted?: string | undefined;
    DocumentsFailed?: string | undefined;
    DocumentsScanned?: string | undefined;
}
export interface DataSourceSyncJob {
    ExecutionId?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Status?: DataSourceSyncJobStatus | undefined;
    ErrorMessage?: string | undefined;
    ErrorCode?: ErrorCode | undefined;
    DataSourceErrorCode?: string | undefined;
    Metrics?: DataSourceSyncJobMetrics | undefined;
}
export type DataSourceSyncJobHistoryList = DataSourceSyncJob[];
export interface ListDataSourceSyncJobsResponse {
    History?: DataSourceSyncJob[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListEntityPersonasRequest = number;
export interface ListEntityPersonasRequest {
    Id: string;
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface PersonasSummary {
    EntityId?: string | undefined;
    Persona?: Persona | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type PersonasSummaryList = PersonasSummary[];
export interface ListEntityPersonasResponse {
    SummaryItems?: PersonasSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExperienceEntitiesRequest {
    Id: string;
    IndexId: string;
    NextToken?: string | undefined;
}
export type NameType = string | redacted.Redacted<string>;
export interface EntityDisplayData {
    UserName?: string | redacted.Redacted<string> | undefined;
    GroupName?: string | redacted.Redacted<string> | undefined;
    IdentifiedUserName?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
}
export interface ExperienceEntitiesSummary {
    EntityId?: string | undefined;
    EntityType?: EntityType | undefined;
    DisplayData?: EntityDisplayData | undefined;
}
export type ExperienceEntitiesSummaryList = ExperienceEntitiesSummary[];
export interface ListExperienceEntitiesResponse {
    SummaryItems?: ExperienceEntitiesSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListExperiencesRequest = number;
export interface ListExperiencesRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ExperiencesSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    CreatedAt?: Date | undefined;
    Status?: ExperienceStatus | undefined;
    Endpoints?: ExperienceEndpoint[] | undefined;
}
export type ExperiencesSummaryList = ExperiencesSummary[];
export interface ListExperiencesResponse {
    SummaryItems?: ExperiencesSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListFaqsRequest = number;
export interface ListFaqsRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FaqSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: FaqStatus | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    FileFormat?: FaqFileFormat | undefined;
    LanguageCode?: string | undefined;
}
export type FaqSummaryItems = FaqSummary[];
export interface ListFaqsResponse {
    NextToken?: string | undefined;
    FaqSummaryItems?: FaqSummary[] | undefined;
}
export type MaxResultsIntegerForListFeaturedResultsSetsRequest = number;
export interface ListFeaturedResultsSetsRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FeaturedResultsSetSummary {
    FeaturedResultsSetId?: string | undefined;
    FeaturedResultsSetName?: string | undefined;
    Status?: FeaturedResultsSetStatus | undefined;
    LastUpdatedTimestamp?: number | undefined;
    CreationTimestamp?: number | undefined;
}
export type FeaturedResultsSetSummaryItems = FeaturedResultsSetSummary[];
export interface ListFeaturedResultsSetsResponse {
    FeaturedResultsSetSummaryItems?: FeaturedResultsSetSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListPrincipalsRequest = number;
export interface ListGroupsOlderThanOrderingIdRequest {
    IndexId: string;
    DataSourceId?: string | undefined;
    OrderingId: number;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface GroupSummary {
    GroupId?: string | undefined;
    OrderingId?: number | undefined;
}
export type ListOfGroupSummaries = GroupSummary[];
export interface ListGroupsOlderThanOrderingIdResponse {
    GroupsSummaries?: GroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListIndicesRequest = number;
export interface ListIndicesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface IndexConfigurationSummary {
    Name?: string | undefined;
    Id?: string | undefined;
    Edition?: IndexEdition | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    Status: IndexStatus;
}
export type IndexConfigurationSummaryList = IndexConfigurationSummary[];
export interface ListIndicesResponse {
    IndexConfigurationSummaryItems?: IndexConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsIntegerForListQuerySuggestionsBlockLists = number;
export interface ListQuerySuggestionsBlockListsRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface QuerySuggestionsBlockListSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: QuerySuggestionsBlockListStatus | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ItemCount?: number | undefined;
}
export type QuerySuggestionsBlockListSummaryItems = QuerySuggestionsBlockListSummary[];
export interface ListQuerySuggestionsBlockListsResponse {
    BlockListSummaryItems?: QuerySuggestionsBlockListSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type MaxResultsIntegerForListThesauriRequest = number;
export interface ListThesauriRequest {
    IndexId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ThesaurusSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: ThesaurusStatus | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type ThesaurusSummaryItems = ThesaurusSummary[];
export interface ListThesauriResponse {
    NextToken?: string | undefined;
    ThesaurusSummaryItems?: ThesaurusSummary[] | undefined;
}
export interface MemberGroup {
    GroupId: string;
    DataSourceId?: string | undefined;
}
export type MemberGroups = MemberGroup[];
export type UserId = string;
export interface MemberUser {
    UserId: string;
}
export type MemberUsers = MemberUser[];
export interface GroupMembers {
    MemberGroups?: MemberGroup[] | undefined;
    MemberUsers?: MemberUser[] | undefined;
    S3PathforGroupMembers?: S3Path | undefined;
}
export interface PutPrincipalMappingRequest {
    IndexId: string;
    DataSourceId?: string | undefined;
    GroupId: string;
    GroupMembers: GroupMembers;
    OrderingId?: number | undefined;
    RoleArn?: string | undefined;
}
export interface PutPrincipalMappingResponse {
}
export type TopDocumentAttributeValueCountPairsSize = number;
export interface Facet {
    DocumentAttributeKey?: string | undefined;
    Facets?: Facet[] | undefined;
    MaxResults?: number | undefined;
}
export type FacetList = Facet[];
export type QueryResultType = "DOCUMENT" | "QUESTION_ANSWER" | "ANSWER" | (string & {});
export interface DocumentRelevanceConfiguration {
    Name: string;
    Relevance: Relevance;
}
export type DocumentRelevanceOverrideConfigurationList = DocumentRelevanceConfiguration[];
export type SortOrder = "DESC" | "ASC" | (string & {});
export interface SortingConfiguration {
    DocumentAttributeKey: string;
    SortOrder: SortOrder;
}
export type SortingConfigurationList = SortingConfiguration[];
export type VisitorId = string;
export interface SpellCorrectionConfiguration {
    IncludeQuerySpellCheckSuggestions: boolean;
}
export type MissingAttributeKeyStrategy = "IGNORE" | "COLLAPSE" | "EXPAND" | (string & {});
export interface ExpandConfiguration {
    MaxResultItemsToExpand?: number | undefined;
    MaxExpandedResultsPerItem?: number | undefined;
}
export interface CollapseConfiguration {
    DocumentAttributeKey: string;
    SortingConfigurations?: SortingConfiguration[] | undefined;
    MissingAttributeKeyStrategy?: MissingAttributeKeyStrategy | undefined;
    Expand?: boolean | undefined;
    ExpandConfiguration?: ExpandConfiguration | undefined;
}
export interface QueryRequest {
    IndexId: string;
    QueryText?: string | undefined;
    AttributeFilter?: AttributeFilter | undefined;
    Facets?: Facet[] | undefined;
    RequestedDocumentAttributes?: string[] | undefined;
    QueryResultTypeFilter?: QueryResultType | undefined;
    DocumentRelevanceOverrideConfigurations?: DocumentRelevanceConfiguration[] | undefined;
    PageNumber?: number | undefined;
    PageSize?: number | undefined;
    SortingConfiguration?: SortingConfiguration | undefined;
    SortingConfigurations?: SortingConfiguration[] | undefined;
    UserContext?: UserContext | undefined;
    VisitorId?: string | undefined;
    SpellCorrectionConfiguration?: SpellCorrectionConfiguration | undefined;
    CollapseConfiguration?: CollapseConfiguration | undefined;
}
export type QueryId = string;
export type QueryResultFormat = "TABLE" | "TEXT" | (string & {});
export type AdditionalResultAttributeValueType = "TEXT_WITH_HIGHLIGHTS_VALUE" | (string & {});
export type HighlightType = "STANDARD" | "THESAURUS_SYNONYM" | (string & {});
export interface Highlight {
    BeginOffset: number;
    EndOffset: number;
    TopAnswer?: boolean | undefined;
    Type?: HighlightType | undefined;
}
export type HighlightList = Highlight[];
export interface TextWithHighlights {
    Text?: string | undefined;
    Highlights?: Highlight[] | undefined;
}
export interface AdditionalResultAttributeValue {
    TextWithHighlightsValue?: TextWithHighlights | undefined;
}
export interface AdditionalResultAttribute {
    Key: string;
    ValueType: AdditionalResultAttributeValueType;
    Value: AdditionalResultAttributeValue;
}
export type AdditionalResultAttributeList = AdditionalResultAttribute[];
export type ScoreConfidence = "VERY_HIGH" | "HIGH" | "MEDIUM" | "LOW" | "NOT_AVAILABLE" | (string & {});
export interface ScoreAttributes {
    ScoreConfidence?: ScoreConfidence | undefined;
}
export type FeedbackToken = string;
export interface TableCell {
    Value?: string | undefined;
    TopAnswer?: boolean | undefined;
    Highlighted?: boolean | undefined;
    Header?: boolean | undefined;
}
export type TableCellList = TableCell[];
export interface TableRow {
    Cells?: TableCell[] | undefined;
}
export type TableRowList = TableRow[];
export interface TableExcerpt {
    Rows?: TableRow[] | undefined;
    TotalNumberOfRows?: number | undefined;
}
export interface ExpandedResultItem {
    Id?: string | undefined;
    DocumentId?: string | undefined;
    DocumentTitle?: TextWithHighlights | undefined;
    DocumentExcerpt?: TextWithHighlights | undefined;
    DocumentURI?: string | undefined;
    DocumentAttributes?: DocumentAttribute[] | undefined;
}
export type ExpandedResultList = ExpandedResultItem[];
export interface CollapsedResultDetail {
    DocumentAttribute: DocumentAttribute;
    ExpandedResults?: ExpandedResultItem[] | undefined;
}
export interface QueryResultItem {
    Id?: string | undefined;
    Type?: QueryResultType | undefined;
    Format?: QueryResultFormat | undefined;
    AdditionalAttributes?: AdditionalResultAttribute[] | undefined;
    DocumentId?: string | undefined;
    DocumentTitle?: TextWithHighlights | undefined;
    DocumentExcerpt?: TextWithHighlights | undefined;
    DocumentURI?: string | undefined;
    DocumentAttributes?: DocumentAttribute[] | undefined;
    ScoreAttributes?: ScoreAttributes | undefined;
    FeedbackToken?: string | undefined;
    TableExcerpt?: TableExcerpt | undefined;
    CollapsedResultDetail?: CollapsedResultDetail | undefined;
}
export type QueryResultItemList = QueryResultItem[];
export interface DocumentAttributeValueCountPair {
    DocumentAttributeValue?: DocumentAttributeValue | undefined;
    Count?: number | undefined;
    FacetResults?: FacetResult[] | undefined;
}
export type DocumentAttributeValueCountPairList = DocumentAttributeValueCountPair[];
export interface FacetResult {
    DocumentAttributeKey?: string | undefined;
    DocumentAttributeValueType?: DocumentAttributeValueType | undefined;
    DocumentAttributeValueCountPairs?: DocumentAttributeValueCountPair[] | undefined;
}
export type FacetResultList = FacetResult[];
export type WarningMessage = string;
export type WarningCode = "QUERY_LANGUAGE_INVALID_SYNTAX" | (string & {});
export interface Warning {
    Message?: string | undefined;
    Code?: WarningCode | undefined;
}
export type WarningList = Warning[];
export type SuggestedQueryText = string;
export interface Correction {
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Term?: string | undefined;
    CorrectedTerm?: string | undefined;
}
export type CorrectionList = Correction[];
export interface SpellCorrectedQuery {
    SuggestedQueryText?: string | undefined;
    Corrections?: Correction[] | undefined;
}
export type SpellCorrectedQueryList = SpellCorrectedQuery[];
export interface FeaturedResultsItem {
    Id?: string | undefined;
    Type?: QueryResultType | undefined;
    AdditionalAttributes?: AdditionalResultAttribute[] | undefined;
    DocumentId?: string | undefined;
    DocumentTitle?: TextWithHighlights | undefined;
    DocumentExcerpt?: TextWithHighlights | undefined;
    DocumentURI?: string | undefined;
    DocumentAttributes?: DocumentAttribute[] | undefined;
    FeedbackToken?: string | undefined;
}
export type FeaturedResultsItemList = FeaturedResultsItem[];
export interface QueryResult {
    QueryId?: string | undefined;
    ResultItems?: QueryResultItem[] | undefined;
    FacetResults?: FacetResult[] | undefined;
    TotalNumberOfResults?: number | undefined;
    Warnings?: Warning[] | undefined;
    SpellCorrectedQueries?: SpellCorrectedQuery[] | undefined;
    FeaturedResultsItems?: FeaturedResultsItem[] | undefined;
}
export interface RetrieveRequest {
    IndexId: string;
    QueryText: string;
    AttributeFilter?: AttributeFilter | undefined;
    RequestedDocumentAttributes?: string[] | undefined;
    DocumentRelevanceOverrideConfigurations?: DocumentRelevanceConfiguration[] | undefined;
    PageNumber?: number | undefined;
    PageSize?: number | undefined;
    UserContext?: UserContext | undefined;
}
export type DocumentTitle = string;
export type Content = string;
export interface RetrieveResultItem {
    Id?: string | undefined;
    DocumentId?: string | undefined;
    DocumentTitle?: string | undefined;
    Content?: string | undefined;
    DocumentURI?: string | undefined;
    DocumentAttributes?: DocumentAttribute[] | undefined;
    ScoreAttributes?: ScoreAttributes | undefined;
}
export type RetrieveResultItemList = RetrieveResultItem[];
export interface RetrieveResult {
    QueryId?: string | undefined;
    ResultItems?: RetrieveResultItem[] | undefined;
}
export interface StartDataSourceSyncJobRequest {
    Id: string;
    IndexId: string;
}
export interface StartDataSourceSyncJobResponse {
    ExecutionId?: string | undefined;
}
export interface StopDataSourceSyncJobRequest {
    Id: string;
    IndexId: string;
}
export interface StopDataSourceSyncJobResponse {
}
export interface ClickFeedback {
    ResultId: string;
    ClickTime: Date;
}
export type ClickFeedbackList = ClickFeedback[];
export type RelevanceType = "RELEVANT" | "NOT_RELEVANT" | (string & {});
export interface RelevanceFeedback {
    ResultId: string;
    RelevanceValue: RelevanceType;
}
export type RelevanceFeedbackList = RelevanceFeedback[];
export interface SubmitFeedbackRequest {
    IndexId: string;
    QueryId: string;
    ClickFeedbackItems?: ClickFeedback[] | undefined;
    RelevanceFeedbackItems?: RelevanceFeedback[] | undefined;
}
export interface SubmitFeedbackResponse {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessControlConfigurationRequest {
    IndexId: string;
    Id: string;
    Name?: string | undefined;
    Description?: string | undefined;
    AccessControlList?: Principal[] | undefined;
    HierarchicalAccessControlList?: HierarchicalPrincipal[] | undefined;
}
export interface UpdateAccessControlConfigurationResponse {
}
export interface UpdateDataSourceRequest {
    Id: string;
    Name?: string | undefined;
    IndexId: string;
    Configuration?: DataSourceConfiguration | undefined;
    VpcConfiguration?: DataSourceVpcConfiguration | undefined;
    Description?: string | undefined;
    Schedule?: string | undefined;
    RoleArn?: string | undefined;
    LanguageCode?: string | undefined;
    CustomDocumentEnrichmentConfiguration?: CustomDocumentEnrichmentConfiguration | undefined;
}
export interface UpdateDataSourceResponse {
}
export interface UpdateExperienceRequest {
    Id: string;
    Name?: string | undefined;
    IndexId: string;
    RoleArn?: string | undefined;
    Configuration?: ExperienceConfiguration | undefined;
    Description?: string | undefined;
}
export interface UpdateExperienceResponse {
}
export interface UpdateFeaturedResultsSetRequest {
    IndexId: string;
    FeaturedResultsSetId: string;
    FeaturedResultsSetName?: string | undefined;
    Description?: string | undefined;
    Status?: FeaturedResultsSetStatus | undefined;
    QueryTexts?: string[] | undefined;
    FeaturedDocuments?: FeaturedDocument[] | undefined;
}
export interface UpdateFeaturedResultsSetResponse {
    FeaturedResultsSet?: FeaturedResultsSet | undefined;
}
export interface UpdateIndexRequest {
    Id: string;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    Description?: string | undefined;
    DocumentMetadataConfigurationUpdates?: DocumentMetadataConfiguration[] | undefined;
    CapacityUnits?: CapacityUnitsConfiguration | undefined;
    UserTokenConfigurations?: UserTokenConfiguration[] | undefined;
    UserContextPolicy?: UserContextPolicy | undefined;
    UserGroupResolutionConfiguration?: UserGroupResolutionConfiguration | undefined;
}
export interface UpdateIndexResponse {
}
export interface UpdateQuerySuggestionsBlockListRequest {
    IndexId: string;
    Id: string;
    Name?: string | undefined;
    Description?: string | undefined;
    SourceS3Path?: S3Path | undefined;
    RoleArn?: string | undefined;
}
export interface UpdateQuerySuggestionsBlockListResponse {
}
export interface AttributeSuggestionsUpdateConfig {
    SuggestableConfigList?: SuggestableConfig[] | undefined;
    AttributeSuggestionsMode?: AttributeSuggestionsMode | undefined;
}
export interface UpdateQuerySuggestionsConfigRequest {
    IndexId: string;
    Mode?: Mode | undefined;
    QueryLogLookBackWindowInDays?: number | undefined;
    IncludeQueriesWithoutUserInformation?: boolean | undefined;
    MinimumNumberOfQueryingUsers?: number | undefined;
    MinimumQueryCount?: number | undefined;
    AttributeSuggestionsConfig?: AttributeSuggestionsUpdateConfig | undefined;
}
export interface UpdateQuerySuggestionsConfigResponse {
}
export interface UpdateThesaurusRequest {
    Id: string;
    Name?: string | undefined;
    IndexId: string;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    SourceS3Path?: S3Path | undefined;
}
export interface UpdateThesaurusResponse {
}
export interface ConflictingItem {
    QueryText?: string | undefined;
    SetName?: string | undefined;
    SetId?: string | undefined;
}
export type ConflictingItems = ConflictingItem[];
export type AssociateEntitiesToExperienceError = AccessDeniedException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants users or groups in your IAM Identity Center identity source access
 * to your Amazon Kendra experience. You can create an Amazon Kendra experience such as a
 * search application. For more information on creating a search application
 * experience, see Building
 * a search experience with no code.
 */
export declare const associateEntitiesToExperience: API.OperationMethod<AssociateEntitiesToExperienceRequest & RegionInput, AssociateEntitiesToExperienceResponse, AssociateEntitiesToExperienceError, Credentials | HttpClient.HttpClient>;
export type AssociatePersonasToEntitiesError = AccessDeniedException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the specific permissions of users or groups in your IAM Identity Center
 * identity source with access to your Amazon Kendra experience. You can create an Amazon Kendra
 * experience such as a search application. For more information on creating a
 * search application experience, see Building
 * a search experience with no code.
 */
export declare const associatePersonasToEntities: API.OperationMethod<AssociatePersonasToEntitiesRequest & RegionInput, AssociatePersonasToEntitiesResponse, AssociatePersonasToEntitiesError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more documents from an index. The documents must have been added with
 * the `BatchPutDocument` API.
 *
 * The documents are deleted asynchronously. You can see the progress of the deletion by
 * using Amazon Web Services
 * CloudWatch. Any error messages related to the processing of the batch are sent to
 * your Amazon Web Services
 * CloudWatch log. You can also use the `BatchGetDocumentStatus` API to
 * monitor the progress of deleting your documents.
 *
 * Deleting documents from an index using `BatchDeleteDocument` could take up
 * to an hour or more, depending on the number of documents you want to delete.
 */
export declare const batchDeleteDocument: API.OperationMethod<BatchDeleteDocumentRequest & RegionInput, BatchDeleteDocumentResponse, BatchDeleteDocumentError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteFeaturedResultsSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more sets of featured results. Features results are placed
 * above all other results for certain queries. If there's an exact match of a
 * query, then one or more specific documents are featured in the search results.
 */
export declare const batchDeleteFeaturedResultsSet: API.OperationMethod<BatchDeleteFeaturedResultsSetRequest & RegionInput, BatchDeleteFeaturedResultsSetResponse, BatchDeleteFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type BatchGetDocumentStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the indexing status for one or more documents submitted with the
 * BatchPutDocument API.
 *
 * When you use the `BatchPutDocument` API, documents are indexed
 * asynchronously. You can use the `BatchGetDocumentStatus` API to get the
 * current status of a list of documents so that you can determine if they have been
 * successfully indexed.
 *
 * You can also use the `BatchGetDocumentStatus` API to check the status of
 * the
 * BatchDeleteDocument API. When a document is deleted from the index, Amazon Kendra returns `NOT_FOUND` as the status.
 */
export declare const batchGetDocumentStatus: API.OperationMethod<BatchGetDocumentStatusRequest & RegionInput, BatchGetDocumentStatusResponse, BatchGetDocumentStatusError, Credentials | HttpClient.HttpClient>;
export type BatchPutDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more documents to an index.
 *
 * The `BatchPutDocument` API enables you to ingest inline documents or a set
 * of documents stored in an Amazon S3 bucket. Use this API to ingest your text and
 * unstructured text into an index, add custom attributes to the documents, and to attach
 * an access control list to the documents added to the index.
 *
 * The documents are indexed asynchronously. You can see the progress of the batch using
 * Amazon Web Services
 * CloudWatch. Any error messages related to processing the batch are sent to your
 * Amazon Web Services
 * CloudWatch log. You can also use the `BatchGetDocumentStatus` API to
 * monitor the progress of indexing your documents.
 *
 * For an example of ingesting inline documents using Python and Java SDKs, see Adding files
 * directly to an index.
 */
export declare const batchPutDocument: API.OperationMethod<BatchPutDocumentRequest & RegionInput, BatchPutDocumentResponse, BatchPutDocumentError, Credentials | HttpClient.HttpClient>;
export type ClearQuerySuggestionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Clears existing query suggestions from an index.
 *
 * This deletes existing suggestions only, not the queries
 * in the query log. After you clear suggestions, Amazon Kendra learns
 * new suggestions based on new queries added to the query log
 * from the time you cleared suggestions. If you do not see any
 * new suggestions, then please allow Amazon Kendra to collect
 * enough queries to learn new suggestions.
 *
 * `ClearQuerySuggestions` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const clearQuerySuggestions: API.OperationMethod<ClearQuerySuggestionsRequest & RegionInput, ClearQuerySuggestionsResponse, ClearQuerySuggestionsError, Credentials | HttpClient.HttpClient>;
export type CreateAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access configuration for your documents. This includes user and group
 * access information for your documents. This is useful for user context filtering, where
 * search results are filtered based on the user or their group access to documents.
 *
 * You can use this to re-configure your existing document level access control without
 * indexing all of your documents again. For example, your index contains top-secret
 * company documents that only certain employees or users should access. One of these users
 * leaves the company or switches to a team that should be blocked from accessing
 * top-secret documents. The user still has access to top-secret documents because the user
 * had access when your documents were previously indexed. You can create a specific access
 * control configuration for the user with deny access. You can later update the access
 * control configuration to allow access if the user returns to the company and re-joins
 * the 'top-secret' team. You can re-configure access control for your documents as
 * circumstances change.
 *
 * To apply your access control configuration to certain documents, you call the BatchPutDocument API with the `AccessControlConfigurationId`
 * included in the Document object. If you use an S3 bucket as a data source, you update the
 * `.metadata.json` with the `AccessControlConfigurationId` and
 * synchronize your data source. Amazon Kendra currently only supports access control
 * configuration for S3 data sources and documents indexed using the
 * `BatchPutDocument` API.
 *
 * You can't configure access control using
 * `CreateAccessControlConfiguration` for an Amazon Kendra Gen AI Enterprise
 * Edition index. Amazon Kendra will return a `ValidationException` error for a
 * `Gen_AI_ENTERPRISE_EDITION` index.
 */
export declare const createAccessControlConfiguration: API.OperationMethod<CreateAccessControlConfigurationRequest & RegionInput, CreateAccessControlConfigurationResponse, CreateAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data source connector that you want to use with an Amazon Kendra
 * index.
 *
 * You specify a name, data source connector type and description for your data source. You
 * also specify configuration information for the data source connector.
 *
 * `CreateDataSource` is a synchronous operation. The operation returns 200 if the
 * data source was successfully created. Otherwise, an exception is raised.
 *
 * For an example of creating an index and data source using the Python SDK, see Getting started with Python
 * SDK. For an example of creating an index and data source using the Java SDK, see
 * Getting started with Java
 * SDK.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest & RegionInput, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Kendra experience such as a search application. For more information
 * on creating a search application experience, including using the Python and Java SDKs,
 * see Building a
 * search experience with no code.
 */
export declare const createExperience: API.OperationMethod<CreateExperienceRequest & RegionInput, CreateExperienceResponse, CreateExperienceError, Credentials | HttpClient.HttpClient>;
export type CreateFaqError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a set of frequently ask questions (FAQs) using a specified FAQ file stored
 * in an Amazon S3 bucket.
 *
 * Adding FAQs to an index is an asynchronous operation.
 *
 * For an example of adding an FAQ to an index using Python and Java SDKs, see Using your FAQ file.
 */
export declare const createFaq: API.OperationMethod<CreateFaqRequest & RegionInput, CreateFaqResponse, CreateFaqError, Credentials | HttpClient.HttpClient>;
export type CreateFeaturedResultsSetError = AccessDeniedException | ConflictException | FeaturedResultsConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a set of featured results to display at the top of the search results page.
 * Featured results are placed above all other results for certain queries. You map
 * specific queries to specific documents for featuring in the results. If a query
 * contains an exact match, then one or more specific documents are featured in the
 * search results.
 *
 * You can create up to 50 sets of featured results per index. You can request to
 * increase this limit by contacting Support.
 */
export declare const createFeaturedResultsSet: API.OperationMethod<CreateFeaturedResultsSetRequest & RegionInput, CreateFeaturedResultsSetResponse, CreateFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistException | ServiceQuotaExceededException | ThrottlingException | ValidationException | NotAuthorizedException | KendraClosedToNewCustomers | CommonErrors;
/**
 * Creates an Amazon Kendra index. Index creation is an asynchronous API. To determine
 * if index creation has completed, check the `Status` field returned from a call to
 * `DescribeIndex`. The `Status` field is set to `ACTIVE` when
 * the index is ready to use.
 *
 * Once the index is active, you can index your documents using the
 * `BatchPutDocument` API or using one of the supported data sources.
 *
 * For an example of creating an index and data source using the Python SDK, see Getting started with Python
 * SDK. For an example of creating an index and data source using the Java SDK, see
 * Getting started with Java
 * SDK.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest & RegionInput, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a block list to exlcude certain queries from suggestions.
 *
 * Any query that contains words or phrases specified in the block
 * list is blocked or filtered out from being shown as a suggestion.
 *
 * You need to provide the file location of your block list text file
 * in your S3 bucket. In your text file, enter each block word or phrase
 * on a separate line.
 *
 * For information on the current quota limits for block lists, see
 * Quotas
 * for Amazon Kendra.
 *
 * `CreateQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 *
 * For an example of creating a block list for query suggestions using the
 * Python SDK, see Query
 * suggestions block list.
 */
export declare const createQuerySuggestionsBlockList: API.OperationMethod<CreateQuerySuggestionsBlockListRequest & RegionInput, CreateQuerySuggestionsBlockListResponse, CreateQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type CreateThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a thesaurus for an index. The thesaurus
 * contains a list of synonyms in Solr format.
 *
 * For an example of adding a thesaurus file to an index, see
 * Adding
 * custom synonyms to an index.
 */
export declare const createThesaurus: API.OperationMethod<CreateThesaurusRequest & RegionInput, CreateThesaurusResponse, CreateThesaurusError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an access control configuration that you created for your documents in an
 * index. This includes user and group access information for your documents. This is
 * useful for user context filtering, where search results are filtered based on the user
 * or their group access to documents.
 */
export declare const deleteAccessControlConfiguration: API.OperationMethod<DeleteAccessControlConfigurationRequest & RegionInput, DeleteAccessControlConfigurationResponse, DeleteAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra data source connector. An exception is not thrown if the
 * data source is already being deleted. While the data source is being deleted, the
 * `Status` field returned by a call to the `DescribeDataSource` API is
 * set to `DELETING`. For more information, see Deleting Data Sources.
 *
 * Deleting an entire data source or re-syncing your index after deleting specific documents
 * from a data source could take up to an hour or more, depending on the number of documents you
 * want to delete.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes your Amazon Kendra experience such as a search application. For more information on
 * creating a search application experience, see Building a search
 * experience with no code.
 */
export declare const deleteExperience: API.OperationMethod<DeleteExperienceRequest & RegionInput, DeleteExperienceResponse, DeleteExperienceError, Credentials | HttpClient.HttpClient>;
export type DeleteFaqError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a FAQ from an index.
 */
export declare const deleteFaq: API.OperationMethod<DeleteFaqRequest & RegionInput, DeleteFaqResponse, DeleteFaqError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra index. An exception is not thrown if the index is already
 * being deleted. While the index is being deleted, the `Status` field returned by a
 * call to the `DescribeIndex` API is set to `DELETING`.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest & RegionInput, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeletePrincipalMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group so that all users that belong to the group can no
 * longer access documents only available to that group.
 *
 * For example, after deleting the group "Summer Interns", all interns who belonged to
 * that group no longer see intern-only documents in their search results.
 *
 * If you want to delete or replace users or sub groups of a group, you need to use the
 * `PutPrincipalMapping` operation. For example, if a user in the group
 * "Engineering" leaves the engineering team and another user takes their place, you
 * provide an updated list of users or sub groups that belong to the "Engineering" group
 * when calling `PutPrincipalMapping`. You can update your internal list of
 * users or sub groups and input this list when calling
 * `PutPrincipalMapping`.
 *
 * `DeletePrincipalMapping` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const deletePrincipalMapping: API.OperationMethod<DeletePrincipalMappingRequest & RegionInput, DeletePrincipalMappingResponse, DeletePrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a block list used for query suggestions for an index.
 *
 * A deleted block list might not take effect right away. Amazon Kendra
 * needs to refresh the entire suggestions list to add back the
 * queries that were previously blocked.
 *
 * `DeleteQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const deleteQuerySuggestionsBlockList: API.OperationMethod<DeleteQuerySuggestionsBlockListRequest & RegionInput, DeleteQuerySuggestionsBlockListResponse, DeleteQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type DeleteThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Kendra thesaurus.
 */
export declare const deleteThesaurus: API.OperationMethod<DeleteThesaurusRequest & RegionInput, DeleteThesaurusResponse, DeleteThesaurusError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessControlConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an access control configuration that you created for your
 * documents in an index. This includes user and group access information for your
 * documents. This is useful for user context filtering, where search results are filtered
 * based on the user or their group access to documents.
 */
export declare const describeAccessControlConfiguration: API.OperationMethod<DescribeAccessControlConfigurationRequest & RegionInput, DescribeAccessControlConfigurationResponse, DescribeAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra data source connector.
 */
export declare const describeDataSource: API.OperationMethod<DescribeDataSourceRequest & RegionInput, DescribeDataSourceResponse, DescribeDataSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeExperienceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about your Amazon Kendra experience such as a search application.
 * For more information on creating a search application experience,
 * see Building
 * a search experience with no code.
 */
export declare const describeExperience: API.OperationMethod<DescribeExperienceRequest & RegionInput, DescribeExperienceResponse, DescribeExperienceError, Credentials | HttpClient.HttpClient>;
export type DescribeFaqError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a FAQ.
 */
export declare const describeFaq: API.OperationMethod<DescribeFaqRequest & RegionInput, DescribeFaqResponse, DescribeFaqError, Credentials | HttpClient.HttpClient>;
export type DescribeFeaturedResultsSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a set of featured results. Features results are placed
 * above all other results for certain queries. If there's an exact match of a query,
 * then one or more specific documents are featured in the search results.
 */
export declare const describeFeaturedResultsSet: API.OperationMethod<DescribeFeaturedResultsSetRequest & RegionInput, DescribeFeaturedResultsSetResponse, DescribeFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type DescribeIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra index.
 */
export declare const describeIndex: API.OperationMethod<DescribeIndexRequest & RegionInput, DescribeIndexResponse, DescribeIndexError, Credentials | HttpClient.HttpClient>;
export type DescribePrincipalMappingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the processing of `PUT` and `DELETE` actions for
 * mapping users to their groups. This includes information on the status of actions
 * currently processing or yet to be processed, when actions were last updated, when
 * actions were received by Amazon Kendra, the latest action that should process and
 * apply after other actions, and useful error messages if an action could not be
 * processed.
 *
 * `DescribePrincipalMapping` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const describePrincipalMapping: API.OperationMethod<DescribePrincipalMappingRequest & RegionInput, DescribePrincipalMappingResponse, DescribePrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type DescribeQuerySuggestionsBlockListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a block list used for query suggestions for
 * an index.
 *
 * This is used to check the current settings that are applied to a
 * block list.
 *
 * `DescribeQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const describeQuerySuggestionsBlockList: API.OperationMethod<DescribeQuerySuggestionsBlockListRequest & RegionInput, DescribeQuerySuggestionsBlockListResponse, DescribeQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type DescribeQuerySuggestionsConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information on the settings of query suggestions for an index.
 *
 * This is used to check the current settings applied
 * to query suggestions.
 *
 * `DescribeQuerySuggestionsConfig` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const describeQuerySuggestionsConfig: API.OperationMethod<DescribeQuerySuggestionsConfigRequest & RegionInput, DescribeQuerySuggestionsConfigResponse, DescribeQuerySuggestionsConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeThesaurusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an Amazon Kendra thesaurus.
 */
export declare const describeThesaurus: API.OperationMethod<DescribeThesaurusRequest & RegionInput, DescribeThesaurusResponse, DescribeThesaurusError, Credentials | HttpClient.HttpClient>;
export type DisassociateEntitiesFromExperienceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Prevents users or groups in your IAM Identity Center identity source
 * from accessing your Amazon Kendra experience. You can create an Amazon Kendra experience
 * such as a search application. For more information on creating a search
 * application experience, see Building
 * a search experience with no code.
 */
export declare const disassociateEntitiesFromExperience: API.OperationMethod<DisassociateEntitiesFromExperienceRequest & RegionInput, DisassociateEntitiesFromExperienceResponse, DisassociateEntitiesFromExperienceError, Credentials | HttpClient.HttpClient>;
export type DisassociatePersonasFromEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specific permissions of users or groups in your IAM Identity Center
 * identity source with access to your Amazon Kendra experience. You can create an Amazon Kendra
 * experience such as a search application. For more information on creating a
 * search application experience, see Building a
 * search experience with no code.
 */
export declare const disassociatePersonasFromEntities: API.OperationMethod<DisassociatePersonasFromEntitiesRequest & RegionInput, DisassociatePersonasFromEntitiesResponse, DisassociatePersonasFromEntitiesError, Credentials | HttpClient.HttpClient>;
export type GetQuerySuggestionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetches the queries that are suggested to your users.
 *
 * `GetQuerySuggestions` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const getQuerySuggestions: API.OperationMethod<GetQuerySuggestionsRequest & RegionInput, GetQuerySuggestionsResponse, GetQuerySuggestionsError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotsError = AccessDeniedException | InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves search metrics data. The data provides a snapshot of how your users interact
 * with your search application and how effective the application is.
 */
export declare const getSnapshots: API.PaginatedOperationMethod<GetSnapshotsRequest & RegionInput, GetSnapshotsResponse, GetSnapshotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAccessControlConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more access control configurations for an index. This includes user and
 * group access information for your documents. This is useful for user context filtering,
 * where search results are filtered based on the user or their group access to
 * documents.
 */
export declare const listAccessControlConfigurations: API.PaginatedOperationMethod<ListAccessControlConfigurationsRequest & RegionInput, ListAccessControlConfigurationsResponse, ListAccessControlConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data source connectors that you have created.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataSourceSyncJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets statistics about synchronizing a data source connector.
 */
export declare const listDataSourceSyncJobs: API.PaginatedOperationMethod<ListDataSourceSyncJobsRequest & RegionInput, ListDataSourceSyncJobsResponse, ListDataSourceSyncJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityPersonasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists specific permissions of users and groups with access to your
 * Amazon Kendra experience.
 */
export declare const listEntityPersonas: API.PaginatedOperationMethod<ListEntityPersonasRequest & RegionInput, ListEntityPersonasResponse, ListEntityPersonasError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExperienceEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists users or groups in your IAM Identity Center identity source that are
 * granted access to your Amazon Kendra experience. You can create an Amazon Kendra experience
 * such as a search application. For more information on creating a search
 * application experience, see Building
 * a search experience with no code.
 */
export declare const listExperienceEntities: API.PaginatedOperationMethod<ListExperienceEntitiesRequest & RegionInput, ListExperienceEntitiesResponse, ListExperienceEntitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExperiencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more Amazon Kendra experiences. You can create an Amazon Kendra experience such
 * as a search application. For more information on creating a search application
 * experience, see Building a
 * search experience with no code.
 */
export declare const listExperiences: API.PaginatedOperationMethod<ListExperiencesRequest & RegionInput, ListExperiencesResponse, ListExperiencesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFaqsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of FAQs associated with an index.
 */
export declare const listFaqs: API.PaginatedOperationMethod<ListFaqsRequest & RegionInput, ListFaqsResponse, ListFaqsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFeaturedResultsSetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all your sets of featured results for a given index. Features results
 * are placed above all other results for certain queries. If there's an exact match
 * of a query, then one or more specific documents are featured in the search results.
 */
export declare const listFeaturedResultsSets: API.OperationMethod<ListFeaturedResultsSetsRequest & RegionInput, ListFeaturedResultsSetsResponse, ListFeaturedResultsSetsError, Credentials | HttpClient.HttpClient>;
export type ListGroupsOlderThanOrderingIdError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of groups that are mapped to users before a given ordering or
 * timestamp identifier.
 *
 * `ListGroupsOlderThanOrderingId` is currently not supported in the Amazon Web Services GovCloud (US-West) region.
 */
export declare const listGroupsOlderThanOrderingId: API.PaginatedOperationMethod<ListGroupsOlderThanOrderingIdRequest & RegionInput, ListGroupsOlderThanOrderingIdResponse, ListGroupsOlderThanOrderingIdError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIndicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Kendra indexes that you created.
 */
export declare const listIndices: API.PaginatedOperationMethod<ListIndicesRequest & RegionInput, ListIndicesResponse, ListIndicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListQuerySuggestionsBlockListsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the block lists used for query suggestions for an index.
 *
 * For information on the current quota limits for block lists, see
 * Quotas
 * for Amazon Kendra.
 *
 * `ListQuerySuggestionsBlockLists` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const listQuerySuggestionsBlockLists: API.PaginatedOperationMethod<ListQuerySuggestionsBlockListsRequest & RegionInput, ListQuerySuggestionsBlockListsResponse, ListQuerySuggestionsBlockListsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Gets a list of tags associated with a resource. Indexes, FAQs, data sources, and
 * other resources can have tags associated with them.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThesauriError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the thesauri for an index.
 */
export declare const listThesauri: API.PaginatedOperationMethod<ListThesauriRequest & RegionInput, ListThesauriResponse, ListThesauriError, Credentials | HttpClient.HttpClient, unknown>;
export type PutPrincipalMappingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Maps users to their groups so that you only need to provide the user ID when you issue
 * the query.
 *
 * You can also map sub groups to groups. For example, the group "Company Intellectual
 * Property Teams" includes sub groups "Research" and "Engineering". These sub groups
 * include their own list of users or people who work in these teams. Only users who work
 * in research and engineering, and therefore belong in the intellectual property group,
 * can see top-secret company documents in their search results.
 *
 * This is useful for user context filtering, where search results are filtered based on
 * the user or their group access to documents. For more information, see Filtering on
 * user context.
 *
 * If more than five `PUT` actions for a group are currently processing, a
 * validation exception is thrown.
 */
export declare const putPrincipalMapping: API.OperationMethod<PutPrincipalMappingRequest & RegionInput, PutPrincipalMappingResponse, PutPrincipalMappingError, Credentials | HttpClient.HttpClient>;
export type QueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches an index given an input query.
 *
 * If you are working with large language models (LLMs) or implementing retrieval
 * augmented generation (RAG) systems, you can use Amazon Kendra's Retrieve API, which can return longer semantically relevant passages. We
 * recommend using the `Retrieve` API instead of filing a service limit increase
 * to increase the `Query` API document excerpt length.
 *
 * You can configure boosting or relevance tuning at the query level to override boosting
 * at the index level, filter based on document fields/attributes and faceted search, and
 * filter based on the user or their group access to documents. You can also include certain
 * fields in the response that might provide useful additional information.
 *
 * A query response contains three types of results.
 *
 * - Relevant suggested answers. The answers can be either a text excerpt or table
 * excerpt. The answer can be highlighted in the excerpt.
 *
 * - Matching FAQs or questions-answer from your FAQ file.
 *
 * - Relevant documents. This result type includes an excerpt of the document with the
 * document title. The searched terms can be highlighted in the excerpt.
 *
 * You can specify that the query return only one type of result using the
 * `QueryResultTypeFilter` parameter. Each query returns the 100 most relevant
 * results. If you filter result type to only question-answers, a maximum of four results are
 * returned. If you filter result type to only answers, a maximum of three results are
 * returned.
 *
 * If you're using an Amazon Kendra Gen AI Enterprise Edition index, you can only use
 * `ATTRIBUTE_FILTER` to filter search results by user context. If you're
 * using an Amazon Kendra Gen AI Enterprise Edition index and you try to use
 * `USER_TOKEN` to configure user context policy, Amazon Kendra returns a
 * `ValidationException` error.
 */
export declare const query: API.OperationMethod<QueryRequest & RegionInput, QueryResult, QueryError, Credentials | HttpClient.HttpClient>;
export type RetrieveError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves relevant passages or text excerpts given an input query.
 *
 * This API is similar to the Query API. However, by
 * default, the `Query` API only returns excerpt passages of up to 100 token
 * words. With the `Retrieve` API, you can retrieve longer passages of up to 200
 * token words and up to 100 semantically relevant passages. This doesn't include
 * question-answer or FAQ type responses from your index. The passages are text excerpts
 * that can be semantically extracted from multiple documents and multiple parts of the
 * same document. If in extreme cases your documents produce zero passages using the
 * `Retrieve` API, you can alternatively use the `Query` API and
 * its types of responses.
 *
 * You can also do the following:
 *
 * - Override boosting at the index level
 *
 * - Filter based on document fields or attributes
 *
 * - Filter based on the user or their group access to documents
 *
 * - View the confidence score bucket for a retrieved passage result. The
 * confidence bucket provides a relative ranking that indicates how confident
 * Amazon Kendra is that the response is relevant to the query.
 *
 * Confidence score buckets are currently available only for English.
 *
 * You can also include certain fields in the response that might provide useful
 * additional information.
 *
 * The `Retrieve` API shares the number of query capacity
 * units that you set for your index. For more information on what's included
 * in a single capacity unit and the default base capacity for an index, see Adjusting
 * capacity.
 *
 * If you're using an Amazon Kendra Gen AI Enterprise Edition index, you can only use
 * `ATTRIBUTE_FILTER` to filter search results by user context. If
 * you're using an Amazon Kendra Gen AI Enterprise Edition index and you try to use
 * `USER_TOKEN` to configure user context policy, Amazon Kendra returns a
 * `ValidationException` error.
 */
export declare const retrieve: API.OperationMethod<RetrieveRequest & RegionInput, RetrieveResult, RetrieveError, Credentials | HttpClient.HttpClient>;
export type StartDataSourceSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a synchronization job for a data source connector. If a synchronization job is
 * already in progress, Amazon Kendra returns a `ResourceInUseException`
 * exception.
 *
 * Re-syncing your data source with your index after modifying, adding, or deleting
 * documents from your data source respository could take up to an hour or more, depending on
 * the number of documents to sync.
 */
export declare const startDataSourceSyncJob: API.OperationMethod<StartDataSourceSyncJobRequest & RegionInput, StartDataSourceSyncJobResponse, StartDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type StopDataSourceSyncJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a synchronization job that is currently running. You can't stop a scheduled
 * synchronization job.
 */
export declare const stopDataSourceSyncJob: API.OperationMethod<StopDataSourceSyncJobRequest & RegionInput, StopDataSourceSyncJobResponse, StopDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type SubmitFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables you to provide feedback to Amazon Kendra to improve the
 * performance of your index.
 *
 * `SubmitFeedback` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const submitFeedback: API.OperationMethod<SubmitFeedbackRequest & RegionInput, SubmitFeedbackResponse, SubmitFeedbackError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the specified tag to the specified index, FAQ, data source, or other resource. If
 * the tag already exists, the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from an index, FAQ, data source, or other resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessControlConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an access control configuration for your documents in an index. This includes
 * user and group access information for your documents. This is useful for user context
 * filtering, where search results are filtered based on the user or their group access to
 * documents.
 *
 * You can update an access control configuration you created without indexing all of
 * your documents again. For example, your index contains top-secret company documents that
 * only certain employees or users should access. You created an 'allow' access control
 * configuration for one user who recently joined the 'top-secret' team, switching from a
 * team with 'deny' access to top-secret documents. However, the user suddenly returns to
 * their previous team and should no longer have access to top secret documents. You can
 * update the access control configuration to re-configure access control for your
 * documents as circumstances change.
 *
 * You call the BatchPutDocument API to
 * apply the updated access control configuration, with the
 * `AccessControlConfigurationId` included in the Document
 * object. If you use an S3 bucket as a data source, you synchronize your data source to
 * apply the `AccessControlConfigurationId` in the `.metadata.json`
 * file. Amazon Kendra currently only supports access control configuration for S3
 * data sources and documents indexed using the `BatchPutDocument` API.
 *
 * You can't configure access control using
 * `CreateAccessControlConfiguration` for an Amazon Kendra Gen AI Enterprise
 * Edition index. Amazon Kendra will return a `ValidationException` error for a
 * `Gen_AI_ENTERPRISE_EDITION` index.
 */
export declare const updateAccessControlConfiguration: API.OperationMethod<UpdateAccessControlConfigurationRequest & RegionInput, UpdateAccessControlConfigurationResponse, UpdateAccessControlConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Kendra data source connector.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates your Amazon Kendra experience such as a search application. For more information on
 * creating a search application experience, see Building a
 * search experience with no code.
 */
export declare const updateExperience: API.OperationMethod<UpdateExperienceRequest & RegionInput, UpdateExperienceResponse, UpdateExperienceError, Credentials | HttpClient.HttpClient>;
export type UpdateFeaturedResultsSetError = AccessDeniedException | FeaturedResultsConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a set of featured results. Features results are placed
 * above
 * all other results for certain queries. You map specific queries to specific documents
 * for featuring in the results. If a query contains an exact match of a query, then one
 * or more specific documents are featured in the search results.
 */
export declare const updateFeaturedResultsSet: API.OperationMethod<UpdateFeaturedResultsSetRequest & RegionInput, UpdateFeaturedResultsSetResponse, UpdateFeaturedResultsSetError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Kendra index.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest & RegionInput, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdateQuerySuggestionsBlockListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a block list used for query suggestions for an index.
 *
 * Updates to a block list might not take effect right away. Amazon Kendra
 * needs to refresh the entire suggestions list to apply any updates to the
 * block list. Other changes not related to the block list apply immediately.
 *
 * If a block list is updating, then you need to wait for the first update to
 * finish before submitting another update.
 *
 * Amazon Kendra supports partial updates, so you only need to provide the fields
 * you want to update.
 *
 * `UpdateQuerySuggestionsBlockList` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const updateQuerySuggestionsBlockList: API.OperationMethod<UpdateQuerySuggestionsBlockListRequest & RegionInput, UpdateQuerySuggestionsBlockListResponse, UpdateQuerySuggestionsBlockListError, Credentials | HttpClient.HttpClient>;
export type UpdateQuerySuggestionsConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings of query suggestions for an index.
 *
 * Amazon Kendra supports partial updates, so you only need to provide
 * the fields you want to update.
 *
 * If an update is currently processing, you
 * need to wait for the update to finish before making another update.
 *
 * Updates to query suggestions settings might not take effect right away.
 * The time for your updated settings to take effect depends on the updates
 * made and the number of search queries in your index.
 *
 * You can still enable/disable query suggestions at any time.
 *
 * `UpdateQuerySuggestionsConfig` is currently not supported in the
 * Amazon Web Services GovCloud (US-West) region.
 */
export declare const updateQuerySuggestionsConfig: API.OperationMethod<UpdateQuerySuggestionsConfigRequest & RegionInput, UpdateQuerySuggestionsConfigResponse, UpdateQuerySuggestionsConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateThesaurusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a thesaurus for an index.
 */
export declare const updateThesaurus: API.OperationMethod<UpdateThesaurusRequest & RegionInput, UpdateThesaurusResponse, UpdateThesaurusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kendra.d.ts.map