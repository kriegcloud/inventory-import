import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface DeleteManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export interface DeleteManagedTransformResponse {
}
export interface ListManagedTransformsRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export type ListResultManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface ListResultManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResultManagedRequestHeadersItemConflictsWithList | null | undefined;
}
export type ListResultManagedRequestHeadersList = Array<ListResultManagedRequestHeadersItem>;
export type ListResultManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface ListResultManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResultManagedResponseHeadersItemConflictsWithList | null | undefined;
}
export type ListResultManagedResponseHeadersList = Array<ListResultManagedResponseHeadersItem>;
export interface ListResult {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: ListResultManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: ListResultManagedResponseHeadersList;
}
export type ListManagedTransformsResponse = ListResult;
export type EditRequestManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface EditRequestManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean | undefined;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedRequestHeadersItemConflictsWithList | undefined;
}
export type EditRequestManagedRequestHeadersList = Array<EditRequestManagedRequestHeadersItem>;
export type EditRequestManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface EditRequestManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean | undefined;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedResponseHeadersItemConflictsWithList | undefined;
}
export type EditRequestManagedResponseHeadersList = Array<EditRequestManagedResponseHeadersItem>;
export interface PatchManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** The list of Managed Request Transforms. */
    managedRequestHeaders?: EditRequestManagedRequestHeadersList | undefined;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders?: EditRequestManagedResponseHeadersList | undefined;
}
export type EditResultManagedRequestHeadersItemConflictsWithList = Array<string>;
export interface EditResultManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResultManagedRequestHeadersItemConflictsWithList | null | undefined;
}
export type EditResultManagedRequestHeadersList = Array<EditResultManagedRequestHeadersItem>;
export type EditResultManagedResponseHeadersItemConflictsWithList = Array<string>;
export interface EditResultManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResultManagedResponseHeadersItemConflictsWithList | null | undefined;
}
export type EditResultManagedResponseHeadersList = Array<EditResultManagedResponseHeadersItem>;
export interface EditResult {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: EditResultManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: EditResultManagedResponseHeadersList;
}
export type PatchManagedTransformResponse = EditResult;
export type DeleteManagedTransformError = Forbidden | CloudflareOpError;
/** Disables all Managed Transforms. */
export declare const deleteManagedTransform: API.OperationMethod<DeleteManagedTransformRequest, DeleteManagedTransformResponse, DeleteManagedTransformError, CloudflareOpContext>;
export type ListManagedTransformsError = Forbidden | CloudflareOpError;
/** Fetches a list of all Managed Transforms. */
export declare const listManagedTransforms: API.OperationMethod<ListManagedTransformsRequest, ListManagedTransformsResponse, ListManagedTransformsError, CloudflareOpContext>;
export type PatchManagedTransformError = Forbidden | CloudflareOpError;
/** Updates the status of one or more Managed Transforms. */
export declare const patchManagedTransform: API.OperationMethod<PatchManagedTransformRequest, PatchManagedTransformResponse, PatchManagedTransformError, CloudflareOpContext>;
//# sourceMappingURL=managed_transforms.d.ts.map