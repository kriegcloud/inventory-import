import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const GroupAlreadyExists_base: S.TaggedErrorClass<"GroupAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class GroupAlreadyExists extends /*@__PURE__*/ GroupAlreadyExists_base {
}
declare const GroupNotFound_base: S.TaggedErrorClass<"GroupNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class GroupNotFound extends /*@__PURE__*/ GroupNotFound_base {
}
declare const InvalidPolicyRevisionIdException_base: S.TaggedErrorClass<"InvalidPolicyRevisionIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPolicyRevisionIdException extends /*@__PURE__*/ InvalidPolicyRevisionIdException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LockoutPreventionException_base: S.TaggedErrorClass<"LockoutPreventionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LockoutPreventionException extends /*@__PURE__*/ LockoutPreventionException_base {
}
declare const MalformedPolicyDocumentException_base: S.TaggedErrorClass<"MalformedPolicyDocumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedPolicyDocumentException extends /*@__PURE__*/ MalformedPolicyDocumentException_base {
}
declare const PolicyCountLimitExceededException_base: S.TaggedErrorClass<"PolicyCountLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyCountLimitExceededException extends /*@__PURE__*/ PolicyCountLimitExceededException_base {
}
declare const PolicySizeLimitExceededException_base: S.TaggedErrorClass<"PolicySizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicySizeLimitExceededException extends /*@__PURE__*/ PolicySizeLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RuleLimitExceededException_base: S.TaggedErrorClass<"RuleLimitExceededException", {
    readonly message: any;
}>;
export declare class RuleLimitExceededException extends /*@__PURE__*/ RuleLimitExceededException_base {
}
declare const SamplingRuleAlreadyExists_base: S.TaggedErrorClass<"SamplingRuleAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SamplingRuleAlreadyExists extends /*@__PURE__*/ SamplingRuleAlreadyExists_base {
}
declare const SamplingRuleNotFound_base: S.TaggedErrorClass<"SamplingRuleNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SamplingRuleNotFound extends /*@__PURE__*/ SamplingRuleNotFound_base {
}
declare const ThrottledException_base: S.TaggedErrorClass<"ThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type TraceId = string;
export type TraceIdList = string[];
export interface BatchGetTracesRequest {
    TraceIds: string[];
    NextToken?: string | undefined;
}
export type SegmentId = string;
export type SegmentDocument = string;
export interface Segment {
    Id?: string | undefined;
    Document?: string | undefined;
}
export type SegmentList = Segment[];
export interface Trace {
    Id?: string | undefined;
    Duration?: number | undefined;
    LimitExceeded?: boolean | undefined;
    Segments?: Segment[] | undefined;
}
export type TraceList = Trace[];
export type UnprocessedTraceIdList = string[];
export interface BatchGetTracesResult {
    Traces?: Trace[] | undefined;
    UnprocessedTraceIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export type RetrievalToken = string;
export interface CancelTraceRetrievalRequest {
    RetrievalToken: string;
}
export interface CancelTraceRetrievalResult {
}
export type GroupName = string;
export type FilterExpression = string;
export interface InsightsConfiguration {
    InsightsEnabled?: boolean | undefined;
    NotificationsEnabled?: boolean | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateGroupRequest {
    GroupName: string;
    FilterExpression?: string | undefined;
    InsightsConfiguration?: InsightsConfiguration | undefined;
    Tags?: Tag[] | undefined;
}
export interface Group {
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
    FilterExpression?: string | undefined;
    InsightsConfiguration?: InsightsConfiguration | undefined;
}
export interface CreateGroupResult {
    Group?: Group | undefined;
}
export type RuleName = string;
export type ResourceARN = string;
export type Priority = number;
export type FixedRate = number;
export type ReservoirSize = number;
export type ServiceName = string;
export type ServiceType = string;
export type Host = string;
export type HTTPMethod = string;
export type URLPath = string;
export type Version = number;
export type AttributeKey = string;
export type AttributeValue = string;
export type AttributeMap = {
    [key: string]: string | undefined;
};
export type MaxRate = number;
export type CooldownWindowMinutes = number;
export interface SamplingRateBoost {
    MaxRate: number;
    CooldownWindowMinutes: number;
}
export interface SamplingRule {
    RuleName?: string | undefined;
    RuleARN?: string | undefined;
    ResourceARN: string;
    Priority: number;
    FixedRate: number;
    ReservoirSize: number;
    ServiceName: string;
    ServiceType: string;
    Host: string;
    HTTPMethod: string;
    URLPath: string;
    Version: number;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    SamplingRateBoost?: SamplingRateBoost | undefined;
}
export interface CreateSamplingRuleRequest {
    SamplingRule: SamplingRule;
    Tags?: Tag[] | undefined;
}
export interface SamplingRuleRecord {
    SamplingRule?: SamplingRule | undefined;
    CreatedAt?: Date | undefined;
    ModifiedAt?: Date | undefined;
}
export interface CreateSamplingRuleResult {
    SamplingRuleRecord?: SamplingRuleRecord | undefined;
}
export type GroupARN = string;
export interface DeleteGroupRequest {
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
}
export interface DeleteGroupResult {
}
export type PolicyName = string;
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyRequest {
    PolicyName: string;
    PolicyRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyResult {
}
export interface DeleteSamplingRuleRequest {
    RuleName?: string | undefined;
    RuleARN?: string | undefined;
}
export interface DeleteSamplingRuleResult {
    SamplingRuleRecord?: SamplingRuleRecord | undefined;
}
export interface GetEncryptionConfigRequest {
}
export type EncryptionStatus = "UPDATING" | "ACTIVE" | (string & {});
export type EncryptionType = "NONE" | "KMS" | (string & {});
export interface EncryptionConfig {
    KeyId?: string | undefined;
    Status?: EncryptionStatus | undefined;
    Type?: EncryptionType | undefined;
}
export interface GetEncryptionConfigResult {
    EncryptionConfig?: EncryptionConfig | undefined;
}
export interface GetGroupRequest {
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
}
export interface GetGroupResult {
    Group?: Group | undefined;
}
export type GetGroupsNextToken = string;
export interface GetGroupsRequest {
    NextToken?: string | undefined;
}
export interface GroupSummary {
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
    FilterExpression?: string | undefined;
    InsightsConfiguration?: InsightsConfiguration | undefined;
}
export type GroupSummaryList = GroupSummary[];
export interface GetGroupsResult {
    Groups?: GroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface GetIndexingRulesRequest {
    NextToken?: string | undefined;
}
export interface ProbabilisticRuleValue {
    DesiredSamplingPercentage: number;
    ActualSamplingPercentage?: number | undefined;
}
export type IndexingRuleValue = {
    Probabilistic: ProbabilisticRuleValue;
};
export interface IndexingRule {
    Name?: string | undefined;
    ModifiedAt?: Date | undefined;
    Rule?: IndexingRuleValue | undefined;
}
export type IndexingRuleList = IndexingRule[];
export interface GetIndexingRulesResult {
    IndexingRules?: IndexingRule[] | undefined;
    NextToken?: string | undefined;
}
export type InsightId = string;
export interface GetInsightRequest {
    InsightId: string;
}
export type ServiceNames = string[];
export interface ServiceId {
    Name?: string | undefined;
    Names?: string[] | undefined;
    AccountId?: string | undefined;
    Type?: string | undefined;
}
export type InsightCategory = "FAULT" | (string & {});
export type InsightCategoryList = InsightCategory[];
export type InsightState = "ACTIVE" | "CLOSED" | (string & {});
export type InsightSummaryText = string;
export interface RequestImpactStatistics {
    FaultCount?: number | undefined;
    OkCount?: number | undefined;
    TotalCount?: number | undefined;
}
export interface AnomalousService {
    ServiceId?: ServiceId | undefined;
}
export type AnomalousServiceList = AnomalousService[];
export interface Insight {
    InsightId?: string | undefined;
    GroupARN?: string | undefined;
    GroupName?: string | undefined;
    RootCauseServiceId?: ServiceId | undefined;
    Categories?: InsightCategory[] | undefined;
    State?: InsightState | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Summary?: string | undefined;
    ClientRequestImpactStatistics?: RequestImpactStatistics | undefined;
    RootCauseServiceRequestImpactStatistics?: RequestImpactStatistics | undefined;
    TopAnomalousServices?: AnomalousService[] | undefined;
}
export interface GetInsightResult {
    Insight?: Insight | undefined;
}
export type GetInsightEventsMaxResults = number;
export type Token = string;
export interface GetInsightEventsRequest {
    InsightId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type EventSummaryText = string;
export interface InsightEvent {
    Summary?: string | undefined;
    EventTime?: Date | undefined;
    ClientRequestImpactStatistics?: RequestImpactStatistics | undefined;
    RootCauseServiceRequestImpactStatistics?: RequestImpactStatistics | undefined;
    TopAnomalousServices?: AnomalousService[] | undefined;
}
export type InsightEventList = InsightEvent[];
export interface GetInsightEventsResult {
    InsightEvents?: InsightEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface GetInsightImpactGraphRequest {
    InsightId: string;
    StartTime: Date;
    EndTime: Date;
    NextToken?: string | undefined;
}
export interface InsightImpactGraphEdge {
    ReferenceId?: number | undefined;
}
export type InsightImpactGraphEdgeList = InsightImpactGraphEdge[];
export interface InsightImpactGraphService {
    ReferenceId?: number | undefined;
    Type?: string | undefined;
    Name?: string | undefined;
    Names?: string[] | undefined;
    AccountId?: string | undefined;
    Edges?: InsightImpactGraphEdge[] | undefined;
}
export type InsightImpactGraphServiceList = InsightImpactGraphService[];
export interface GetInsightImpactGraphResult {
    InsightId?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ServiceGraphStartTime?: Date | undefined;
    ServiceGraphEndTime?: Date | undefined;
    Services?: InsightImpactGraphService[] | undefined;
    NextToken?: string | undefined;
}
export type InsightStateList = InsightState[];
export type GetInsightSummariesMaxResults = number;
export interface GetInsightSummariesRequest {
    States?: InsightState[] | undefined;
    GroupARN?: string | undefined;
    GroupName?: string | undefined;
    StartTime: Date;
    EndTime: Date;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface InsightSummary {
    InsightId?: string | undefined;
    GroupARN?: string | undefined;
    GroupName?: string | undefined;
    RootCauseServiceId?: ServiceId | undefined;
    Categories?: InsightCategory[] | undefined;
    State?: InsightState | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Summary?: string | undefined;
    ClientRequestImpactStatistics?: RequestImpactStatistics | undefined;
    RootCauseServiceRequestImpactStatistics?: RequestImpactStatistics | undefined;
    TopAnomalousServices?: AnomalousService[] | undefined;
    LastUpdateTime?: Date | undefined;
}
export type InsightSummaryList = InsightSummary[];
export interface GetInsightSummariesResult {
    InsightSummaries?: InsightSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface GetRetrievedTracesGraphRequest {
    RetrievalToken: string;
    NextToken?: string | undefined;
}
export type RetrievalStatus = "SCHEDULED" | "RUNNING" | "COMPLETE" | "FAILED" | "CANCELLED" | "TIMEOUT" | (string & {});
export interface ErrorStatistics {
    ThrottleCount?: number | undefined;
    OtherCount?: number | undefined;
    TotalCount?: number | undefined;
}
export interface FaultStatistics {
    OtherCount?: number | undefined;
    TotalCount?: number | undefined;
}
export interface EdgeStatistics {
    OkCount?: number | undefined;
    ErrorStatistics?: ErrorStatistics | undefined;
    FaultStatistics?: FaultStatistics | undefined;
    TotalCount?: number | undefined;
    TotalResponseTime?: number | undefined;
}
export interface HistogramEntry {
    Value?: number | undefined;
    Count?: number | undefined;
}
export type Histogram = HistogramEntry[];
export type AliasNames = string[];
export interface Alias {
    Name?: string | undefined;
    Names?: string[] | undefined;
    Type?: string | undefined;
}
export type AliasList = Alias[];
export interface Edge {
    ReferenceId?: number | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    SummaryStatistics?: EdgeStatistics | undefined;
    ResponseTimeHistogram?: HistogramEntry[] | undefined;
    Aliases?: Alias[] | undefined;
    EdgeType?: string | undefined;
    ReceivedEventAgeHistogram?: HistogramEntry[] | undefined;
}
export type EdgeList = Edge[];
export interface ServiceStatistics {
    OkCount?: number | undefined;
    ErrorStatistics?: ErrorStatistics | undefined;
    FaultStatistics?: FaultStatistics | undefined;
    TotalCount?: number | undefined;
    TotalResponseTime?: number | undefined;
}
export interface Service {
    ReferenceId?: number | undefined;
    Name?: string | undefined;
    Names?: string[] | undefined;
    Root?: boolean | undefined;
    AccountId?: string | undefined;
    Type?: string | undefined;
    State?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Edges?: Edge[] | undefined;
    SummaryStatistics?: ServiceStatistics | undefined;
    DurationHistogram?: HistogramEntry[] | undefined;
    ResponseTimeHistogram?: HistogramEntry[] | undefined;
}
export interface GraphLink {
    ReferenceType?: string | undefined;
    SourceTraceId?: string | undefined;
    DestinationTraceIds?: string[] | undefined;
}
export type LinksList = GraphLink[];
export interface RetrievedService {
    Service?: Service | undefined;
    Links?: GraphLink[] | undefined;
}
export type RetrievedServicesList = RetrievedService[];
export interface GetRetrievedTracesGraphResult {
    RetrievalStatus?: RetrievalStatus | undefined;
    Services?: RetrievedService[] | undefined;
    NextToken?: string | undefined;
}
export interface GetSamplingRulesRequest {
    NextToken?: string | undefined;
}
export type SamplingRuleRecordList = SamplingRuleRecord[];
export interface GetSamplingRulesResult {
    SamplingRuleRecords?: SamplingRuleRecord[] | undefined;
    NextToken?: string | undefined;
}
export interface GetSamplingStatisticSummariesRequest {
    NextToken?: string | undefined;
}
export interface SamplingStatisticSummary {
    RuleName?: string | undefined;
    Timestamp?: Date | undefined;
    RequestCount?: number | undefined;
    BorrowCount?: number | undefined;
    SampledCount?: number | undefined;
}
export type SamplingStatisticSummaryList = SamplingStatisticSummary[];
export interface GetSamplingStatisticSummariesResult {
    SamplingStatisticSummaries?: SamplingStatisticSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ClientID = string;
export type RequestCount = number;
export type SampledCount = number;
export type BorrowCount = number;
export interface SamplingStatisticsDocument {
    RuleName: string;
    ClientID: string;
    Timestamp: Date;
    RequestCount: number;
    SampledCount: number;
    BorrowCount?: number | undefined;
}
export type SamplingStatisticsDocumentList = SamplingStatisticsDocument[];
export type AnomalyCount = number;
export type TotalCount = number;
export type SampledAnomalyCount = number;
export interface SamplingBoostStatisticsDocument {
    RuleName: string;
    ServiceName: string;
    Timestamp: Date;
    AnomalyCount: number;
    TotalCount: number;
    SampledAnomalyCount: number;
}
export type SamplingBoostStatisticsDocumentList = SamplingBoostStatisticsDocument[];
export interface GetSamplingTargetsRequest {
    SamplingStatisticsDocuments: SamplingStatisticsDocument[];
    SamplingBoostStatisticsDocuments?: SamplingBoostStatisticsDocument[] | undefined;
}
export interface SamplingBoost {
    BoostRate: number;
    BoostRateTTL: Date;
}
export interface SamplingTargetDocument {
    RuleName?: string | undefined;
    FixedRate?: number | undefined;
    ReservoirQuota?: number | undefined;
    ReservoirQuotaTTL?: Date | undefined;
    Interval?: number | undefined;
    SamplingBoost?: SamplingBoost | undefined;
}
export type SamplingTargetDocumentList = SamplingTargetDocument[];
export interface UnprocessedStatistics {
    RuleName?: string | undefined;
    ErrorCode?: string | undefined;
    Message?: string | undefined;
}
export type UnprocessedStatisticsList = UnprocessedStatistics[];
export interface GetSamplingTargetsResult {
    SamplingTargetDocuments?: SamplingTargetDocument[] | undefined;
    LastRuleModification?: Date | undefined;
    UnprocessedStatistics?: UnprocessedStatistics[] | undefined;
    UnprocessedBoostStatistics?: UnprocessedStatistics[] | undefined;
}
export interface GetServiceGraphRequest {
    StartTime: Date;
    EndTime: Date;
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
    NextToken?: string | undefined;
}
export type ServiceList = Service[];
export interface GetServiceGraphResult {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Services?: Service[] | undefined;
    ContainsOldGroupVersions?: boolean | undefined;
    NextToken?: string | undefined;
}
export type EntitySelectorExpression = string;
export interface GetTimeSeriesServiceStatisticsRequest {
    StartTime: Date;
    EndTime: Date;
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
    EntitySelectorExpression?: string | undefined;
    Period?: number | undefined;
    ForecastStatistics?: boolean | undefined;
    NextToken?: string | undefined;
}
export interface ForecastStatistics {
    FaultCountHigh?: number | undefined;
    FaultCountLow?: number | undefined;
}
export interface TimeSeriesServiceStatistics {
    Timestamp?: Date | undefined;
    EdgeSummaryStatistics?: EdgeStatistics | undefined;
    ServiceSummaryStatistics?: ServiceStatistics | undefined;
    ServiceForecastStatistics?: ForecastStatistics | undefined;
    ResponseTimeHistogram?: HistogramEntry[] | undefined;
}
export type TimeSeriesServiceStatisticsList = TimeSeriesServiceStatistics[];
export interface GetTimeSeriesServiceStatisticsResult {
    TimeSeriesServiceStatistics?: TimeSeriesServiceStatistics[] | undefined;
    ContainsOldGroupVersions?: boolean | undefined;
    NextToken?: string | undefined;
}
export interface GetTraceGraphRequest {
    TraceIds: string[];
    NextToken?: string | undefined;
}
export interface GetTraceGraphResult {
    Services?: Service[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTraceSegmentDestinationRequest {
}
export type TraceSegmentDestination = "XRay" | "CloudWatchLogs" | (string & {});
export type TraceSegmentDestinationStatus = "PENDING" | "ACTIVE" | (string & {});
export interface GetTraceSegmentDestinationResult {
    Destination?: TraceSegmentDestination | undefined;
    Status?: TraceSegmentDestinationStatus | undefined;
}
export type TimeRangeType = "TraceId" | "Event" | "Service" | (string & {});
export type SamplingStrategyName = "PartialScan" | "FixedRate" | (string & {});
export interface SamplingStrategy {
    Name?: SamplingStrategyName | undefined;
    Value?: number | undefined;
}
export interface GetTraceSummariesRequest {
    StartTime: Date;
    EndTime: Date;
    TimeRangeType?: TimeRangeType | undefined;
    Sampling?: boolean | undefined;
    SamplingStrategy?: SamplingStrategy | undefined;
    FilterExpression?: string | undefined;
    NextToken?: string | undefined;
}
export interface Http {
    HttpURL?: string | undefined;
    HttpStatus?: number | undefined;
    HttpMethod?: string | undefined;
    UserAgent?: string | undefined;
    ClientIp?: string | undefined;
}
export type AnnotationKey = string;
export type AnnotationValue = {
    NumberValue: number;
    BooleanValue?: undefined;
    StringValue?: undefined;
} | {
    NumberValue?: undefined;
    BooleanValue: boolean;
    StringValue?: undefined;
} | {
    NumberValue?: undefined;
    BooleanValue?: undefined;
    StringValue: string;
};
export type ServiceIds = ServiceId[];
export interface ValueWithServiceIds {
    AnnotationValue?: AnnotationValue | undefined;
    ServiceIds?: ServiceId[] | undefined;
}
export type ValuesWithServiceIds = ValueWithServiceIds[];
export type Annotations = {
    [key: string]: ValueWithServiceIds[] | undefined;
};
export interface TraceUser {
    UserName?: string | undefined;
    ServiceIds?: ServiceId[] | undefined;
}
export type TraceUsers = TraceUser[];
export interface ResourceARNDetail {
    ARN?: string | undefined;
}
export type TraceResourceARNs = ResourceARNDetail[];
export interface InstanceIdDetail {
    Id?: string | undefined;
}
export type TraceInstanceIds = InstanceIdDetail[];
export interface AvailabilityZoneDetail {
    Name?: string | undefined;
}
export type TraceAvailabilityZones = AvailabilityZoneDetail[];
export interface RootCauseException {
    Name?: string | undefined;
    Message?: string | undefined;
}
export type RootCauseExceptions = RootCauseException[];
export interface FaultRootCauseEntity {
    Name?: string | undefined;
    Exceptions?: RootCauseException[] | undefined;
    Remote?: boolean | undefined;
}
export type FaultRootCauseEntityPath = FaultRootCauseEntity[];
export interface FaultRootCauseService {
    Name?: string | undefined;
    Names?: string[] | undefined;
    Type?: string | undefined;
    AccountId?: string | undefined;
    EntityPath?: FaultRootCauseEntity[] | undefined;
    Inferred?: boolean | undefined;
}
export type FaultRootCauseServices = FaultRootCauseService[];
export interface FaultRootCause {
    Services?: FaultRootCauseService[] | undefined;
    ClientImpacting?: boolean | undefined;
}
export type FaultRootCauses = FaultRootCause[];
export interface ErrorRootCauseEntity {
    Name?: string | undefined;
    Exceptions?: RootCauseException[] | undefined;
    Remote?: boolean | undefined;
}
export type ErrorRootCauseEntityPath = ErrorRootCauseEntity[];
export interface ErrorRootCauseService {
    Name?: string | undefined;
    Names?: string[] | undefined;
    Type?: string | undefined;
    AccountId?: string | undefined;
    EntityPath?: ErrorRootCauseEntity[] | undefined;
    Inferred?: boolean | undefined;
}
export type ErrorRootCauseServices = ErrorRootCauseService[];
export interface ErrorRootCause {
    Services?: ErrorRootCauseService[] | undefined;
    ClientImpacting?: boolean | undefined;
}
export type ErrorRootCauses = ErrorRootCause[];
export interface ResponseTimeRootCauseEntity {
    Name?: string | undefined;
    Coverage?: number | undefined;
    Remote?: boolean | undefined;
}
export type ResponseTimeRootCauseEntityPath = ResponseTimeRootCauseEntity[];
export interface ResponseTimeRootCauseService {
    Name?: string | undefined;
    Names?: string[] | undefined;
    Type?: string | undefined;
    AccountId?: string | undefined;
    EntityPath?: ResponseTimeRootCauseEntity[] | undefined;
    Inferred?: boolean | undefined;
}
export type ResponseTimeRootCauseServices = ResponseTimeRootCauseService[];
export interface ResponseTimeRootCause {
    Services?: ResponseTimeRootCauseService[] | undefined;
    ClientImpacting?: boolean | undefined;
}
export type ResponseTimeRootCauses = ResponseTimeRootCause[];
export interface TraceSummary {
    Id?: string | undefined;
    StartTime?: Date | undefined;
    Duration?: number | undefined;
    ResponseTime?: number | undefined;
    HasFault?: boolean | undefined;
    HasError?: boolean | undefined;
    HasThrottle?: boolean | undefined;
    IsPartial?: boolean | undefined;
    Http?: Http | undefined;
    Annotations?: {
        [key: string]: ValueWithServiceIds[] | undefined;
    } | undefined;
    Users?: TraceUser[] | undefined;
    ServiceIds?: ServiceId[] | undefined;
    ResourceARNs?: ResourceARNDetail[] | undefined;
    InstanceIds?: InstanceIdDetail[] | undefined;
    AvailabilityZones?: AvailabilityZoneDetail[] | undefined;
    EntryPoint?: ServiceId | undefined;
    FaultRootCauses?: FaultRootCause[] | undefined;
    ErrorRootCauses?: ErrorRootCause[] | undefined;
    ResponseTimeRootCauses?: ResponseTimeRootCause[] | undefined;
    Revision?: number | undefined;
    MatchedEventTime?: Date | undefined;
}
export type TraceSummaryList = TraceSummary[];
export interface GetTraceSummariesResult {
    TraceSummaries?: TraceSummary[] | undefined;
    ApproximateTime?: Date | undefined;
    TracesProcessedCount?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourcePolicyNextToken = string;
export interface ListResourcePoliciesRequest {
    NextToken?: string | undefined;
}
export type PolicyDocument = string;
export interface ResourcePolicy {
    PolicyName?: string | undefined;
    PolicyDocument?: string | undefined;
    PolicyRevisionId?: string | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type ResourcePolicyList = ResourcePolicy[];
export interface ListResourcePoliciesResult {
    ResourcePolicies?: ResourcePolicy[] | undefined;
    NextToken?: string | undefined;
}
export type TraceFormatType = "XRAY" | "OTEL" | (string & {});
export interface ListRetrievedTracesRequest {
    RetrievalToken: string;
    TraceFormat?: TraceFormatType | undefined;
    NextToken?: string | undefined;
}
export type SpanId = string;
export type SpanDocument = string;
export interface Span {
    Id?: string | undefined;
    Document?: string | undefined;
}
export type SpanList = Span[];
export interface RetrievedTrace {
    Id?: string | undefined;
    Duration?: number | undefined;
    Spans?: Span[] | undefined;
}
export type TraceSpanList = RetrievedTrace[];
export interface ListRetrievedTracesResult {
    RetrievalStatus?: RetrievalStatus | undefined;
    TraceFormat?: TraceFormatType | undefined;
    Traces?: RetrievedTrace[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export type EncryptionKeyId = string;
export interface PutEncryptionConfigRequest {
    KeyId?: string | undefined;
    Type: EncryptionType;
}
export interface PutEncryptionConfigResult {
    EncryptionConfig?: EncryptionConfig | undefined;
}
export interface PutResourcePolicyRequest {
    PolicyName: string;
    PolicyDocument: string;
    PolicyRevisionId?: string | undefined;
    BypassPolicyLockoutCheck?: boolean | undefined;
}
export interface PutResourcePolicyResult {
    ResourcePolicy?: ResourcePolicy | undefined;
}
export interface BackendConnectionErrors {
    TimeoutCount?: number | undefined;
    ConnectionRefusedCount?: number | undefined;
    HTTPCode4XXCount?: number | undefined;
    HTTPCode5XXCount?: number | undefined;
    UnknownHostCount?: number | undefined;
    OtherCount?: number | undefined;
}
export interface TelemetryRecord {
    Timestamp: Date;
    SegmentsReceivedCount?: number | undefined;
    SegmentsSentCount?: number | undefined;
    SegmentsSpilloverCount?: number | undefined;
    SegmentsRejectedCount?: number | undefined;
    BackendConnectionErrors?: BackendConnectionErrors | undefined;
}
export type TelemetryRecordList = TelemetryRecord[];
export type EC2InstanceId = string;
export type Hostname = string;
export interface PutTelemetryRecordsRequest {
    TelemetryRecords: TelemetryRecord[];
    EC2InstanceId?: string | undefined;
    Hostname?: string | undefined;
    ResourceARN?: string | undefined;
}
export interface PutTelemetryRecordsResult {
}
export type TraceSegmentDocument = string;
export type TraceSegmentDocumentList = string[];
export interface PutTraceSegmentsRequest {
    TraceSegmentDocuments: string[];
}
export interface UnprocessedTraceSegment {
    Id?: string | undefined;
    ErrorCode?: string | undefined;
    Message?: string | undefined;
}
export type UnprocessedTraceSegmentList = UnprocessedTraceSegment[];
export interface PutTraceSegmentsResult {
    UnprocessedTraceSegments?: UnprocessedTraceSegment[] | undefined;
}
export type TraceIdListForRetrieval = string[];
export interface StartTraceRetrievalRequest {
    TraceIds: string[];
    StartTime: Date;
    EndTime: Date;
}
export interface StartTraceRetrievalResult {
    RetrievalToken?: string | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateGroupRequest {
    GroupName?: string | undefined;
    GroupARN?: string | undefined;
    FilterExpression?: string | undefined;
    InsightsConfiguration?: InsightsConfiguration | undefined;
}
export interface UpdateGroupResult {
    Group?: Group | undefined;
}
export interface ProbabilisticRuleValueUpdate {
    DesiredSamplingPercentage: number;
}
export type IndexingRuleValueUpdate = {
    Probabilistic: ProbabilisticRuleValueUpdate;
};
export interface UpdateIndexingRuleRequest {
    Name: string;
    Rule: IndexingRuleValueUpdate;
}
export interface UpdateIndexingRuleResult {
    IndexingRule?: IndexingRule | undefined;
}
export interface SamplingRuleUpdate {
    RuleName?: string | undefined;
    RuleARN?: string | undefined;
    ResourceARN?: string | undefined;
    Priority?: number | undefined;
    FixedRate?: number | undefined;
    ReservoirSize?: number | undefined;
    Host?: string | undefined;
    ServiceName?: string | undefined;
    ServiceType?: string | undefined;
    HTTPMethod?: string | undefined;
    URLPath?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    SamplingRateBoost?: SamplingRateBoost | undefined;
}
export interface UpdateSamplingRuleRequest {
    SamplingRuleUpdate: SamplingRuleUpdate;
}
export interface UpdateSamplingRuleResult {
    SamplingRuleRecord?: SamplingRuleRecord | undefined;
}
export type KmsKeyId = string;
export interface CloudWatchLogsConfiguration {
    SpansLogGroupKmsKeyId?: string | undefined;
}
export interface UpdateTraceSegmentDestinationRequest {
    Destination?: TraceSegmentDestination | undefined;
    CloudWatchLogsConfiguration?: CloudWatchLogsConfiguration | undefined;
}
export interface UpdateTraceSegmentDestinationResult {
    Destination?: TraceSegmentDestination | undefined;
    Status?: TraceSegmentDestinationStatus | undefined;
}
export type ErrorMessage = string;
export type BatchGetTracesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * You cannot find traces through this API if Transaction Search is enabled since trace is not indexed in X-Ray.
 *
 * Retrieves a list of traces specified by ID. Each trace is a collection of segment
 * documents that originates from a single request. Use `GetTraceSummaries` to get a
 * list of trace IDs.
 */
export declare const batchGetTraces: API.PaginatedOperationMethod<BatchGetTracesRequest & RegionInput, BatchGetTracesResult, BatchGetTracesError, Credentials | HttpClient.HttpClient, Trace>;
export type CancelTraceRetrievalError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Cancels an ongoing trace retrieval job initiated by `StartTraceRetrieval` using the provided `RetrievalToken`. A successful cancellation will return an HTTP 200 response.
 */
export declare const cancelTraceRetrieval: API.OperationMethod<CancelTraceRetrievalRequest & RegionInput, CancelTraceRetrievalResult, CancelTraceRetrievalError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = InvalidRequestException | ThrottledException | GroupAlreadyExists | CommonErrors;
/**
 * Creates a group resource with a name and a filter expression.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResult, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateSamplingRuleError = InvalidRequestException | RuleLimitExceededException | ThrottledException | SamplingRuleAlreadyExists | CommonErrors;
/**
 * Creates a rule to control sampling behavior for instrumented applications. Services
 * retrieve rules with GetSamplingRules, and evaluate each rule in ascending
 * order of *priority* for each request. If a rule matches, the service
 * records a trace, borrowing it from the reservoir size. After 10 seconds, the service
 * reports back to X-Ray with GetSamplingTargets to get updated versions of
 * each in-use rule. The updated rule contains a trace quota that the service can use instead
 * of borrowing from the reservoir.
 */
export declare const createSamplingRule: API.OperationMethod<CreateSamplingRuleRequest & RegionInput, CreateSamplingRuleResult, CreateSamplingRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = InvalidRequestException | ThrottledException | GroupNotFound | CommonErrors;
/**
 * Deletes a group resource.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResult, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InvalidPolicyRevisionIdException | InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Deletes a resource policy from the target Amazon Web Services account.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResult, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSamplingRuleError = InvalidRequestException | ThrottledException | SamplingRuleNotFound | CommonErrors;
/**
 * Deletes a sampling rule.
 */
export declare const deleteSamplingRule: API.OperationMethod<DeleteSamplingRuleRequest & RegionInput, DeleteSamplingRuleResult, DeleteSamplingRuleError, Credentials | HttpClient.HttpClient>;
export type GetEncryptionConfigError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves the current encryption configuration for X-Ray data.
 */
export declare const getEncryptionConfig: API.OperationMethod<GetEncryptionConfigRequest & RegionInput, GetEncryptionConfigResult, GetEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = InvalidRequestException | ThrottledException | GroupNotFound | CommonErrors;
/**
 * Retrieves group resource details.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest & RegionInput, GetGroupResult, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetGroupsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves all active group details.
 */
export declare const getGroups: API.PaginatedOperationMethod<GetGroupsRequest & RegionInput, GetGroupsResult, GetGroupsError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type GetIndexingRulesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves all indexing rules.
 *
 * Indexing rules are used to determine the server-side sampling rate for spans ingested through the CloudWatchLogs destination and indexed by X-Ray. For more information, see Transaction Search.
 */
export declare const getIndexingRules: API.OperationMethod<GetIndexingRulesRequest & RegionInput, GetIndexingRulesResult, GetIndexingRulesError, Credentials | HttpClient.HttpClient>;
export type GetInsightError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves the summary information of an insight. This includes impact to clients and
 * root cause services, the top anomalous services, the category, the state of the insight,
 * and the start and end time of the insight.
 */
export declare const getInsight: API.OperationMethod<GetInsightRequest & RegionInput, GetInsightResult, GetInsightError, Credentials | HttpClient.HttpClient>;
export type GetInsightEventsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * X-Ray reevaluates insights periodically until they're resolved, and records each intermediate state as an
 * event. You can review an insight's events in the Impact Timeline on the Inspect page in the X-Ray
 * console.
 */
export declare const getInsightEvents: API.PaginatedOperationMethod<GetInsightEventsRequest & RegionInput, GetInsightEventsResult, GetInsightEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetInsightImpactGraphError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves a service graph structure filtered by the specified insight. The service graph is limited to only
 * structural information. For a complete service graph, use this API with the GetServiceGraph API.
 */
export declare const getInsightImpactGraph: API.OperationMethod<GetInsightImpactGraphRequest & RegionInput, GetInsightImpactGraphResult, GetInsightImpactGraphError, Credentials | HttpClient.HttpClient>;
export type GetInsightSummariesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves the summaries of all insights in the specified group matching the provided filter values.
 */
export declare const getInsightSummaries: API.PaginatedOperationMethod<GetInsightSummariesRequest & RegionInput, GetInsightSummariesResult, GetInsightSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetRetrievedTracesGraphError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Retrieves a service graph for traces based on the specified `RetrievalToken` from the CloudWatch log group generated by Transaction Search. This API does not initiate a retrieval job. You must first execute `StartTraceRetrieval` to obtain the required `RetrievalToken`.
 *
 * The trace graph describes services that process incoming requests and any downstream services they call, which may include Amazon Web Services resources, external APIs, or databases.
 *
 * The response is empty until the `RetrievalStatus` is *COMPLETE*. Retry the request after the status changes from *RUNNING* or *SCHEDULED* to *COMPLETE* to access the full service graph.
 *
 * When CloudWatch log is the destination, this API can support cross-account observability and service graph retrieval across linked accounts.
 *
 * For retrieving graphs from X-Ray directly as opposed to the Transaction-Search Log group, see GetTraceGraph.
 */
export declare const getRetrievedTracesGraph: API.OperationMethod<GetRetrievedTracesGraphRequest & RegionInput, GetRetrievedTracesGraphResult, GetRetrievedTracesGraphError, Credentials | HttpClient.HttpClient>;
export type GetSamplingRulesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves all sampling rules.
 */
export declare const getSamplingRules: API.PaginatedOperationMethod<GetSamplingRulesRequest & RegionInput, GetSamplingRulesResult, GetSamplingRulesError, Credentials | HttpClient.HttpClient, SamplingRuleRecord>;
export type GetSamplingStatisticSummariesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves information about recent sampling results for all sampling rules.
 */
export declare const getSamplingStatisticSummaries: API.PaginatedOperationMethod<GetSamplingStatisticSummariesRequest & RegionInput, GetSamplingStatisticSummariesResult, GetSamplingStatisticSummariesError, Credentials | HttpClient.HttpClient, SamplingStatisticSummary>;
export type GetSamplingTargetsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Requests a sampling quota for rules that the service is using to sample requests.
 */
export declare const getSamplingTargets: API.OperationMethod<GetSamplingTargetsRequest & RegionInput, GetSamplingTargetsResult, GetSamplingTargetsError, Credentials | HttpClient.HttpClient>;
export type GetServiceGraphError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves a document that describes services that process incoming requests, and
 * downstream services that they call as a result. Root services process incoming requests and
 * make calls to downstream services. Root services are applications that use the Amazon Web Services X-Ray SDK.
 * Downstream services can be other applications, Amazon Web Services resources, HTTP web APIs, or SQL
 * databases.
 */
export declare const getServiceGraph: API.PaginatedOperationMethod<GetServiceGraphRequest & RegionInput, GetServiceGraphResult, GetServiceGraphError, Credentials | HttpClient.HttpClient, Service>;
export type GetTimeSeriesServiceStatisticsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Get an aggregation of service statistics defined by a specific time
 * range.
 */
export declare const getTimeSeriesServiceStatistics: API.PaginatedOperationMethod<GetTimeSeriesServiceStatisticsRequest & RegionInput, GetTimeSeriesServiceStatisticsResult, GetTimeSeriesServiceStatisticsError, Credentials | HttpClient.HttpClient, TimeSeriesServiceStatistics>;
export type GetTraceGraphError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves a service graph for one or more specific trace IDs.
 */
export declare const getTraceGraph: API.PaginatedOperationMethod<GetTraceGraphRequest & RegionInput, GetTraceGraphResult, GetTraceGraphError, Credentials | HttpClient.HttpClient, Service>;
export type GetTraceSegmentDestinationError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves the current destination of data sent to `PutTraceSegments` and *OpenTelemetry protocol (OTLP)* endpoint. The Transaction Search feature requires a CloudWatchLogs destination. For more information, see Transaction Search and OpenTelemetry.
 */
export declare const getTraceSegmentDestination: API.OperationMethod<GetTraceSegmentDestinationRequest & RegionInput, GetTraceSegmentDestinationResult, GetTraceSegmentDestinationError, Credentials | HttpClient.HttpClient>;
export type GetTraceSummariesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Retrieves IDs and annotations for traces available for a specified time frame using an
 * optional filter. To get the full traces, pass the trace IDs to
 * `BatchGetTraces`.
 *
 * A filter expression can target traced requests that hit specific service nodes or
 * edges, have errors, or come from a known user. For example, the following filter expression
 * targets traces that pass through `api.example.com`:
 *
 * `service("api.example.com")`
 *
 * This filter expression finds traces that have an annotation named `account`
 * with the value `12345`:
 *
 * `annotation.account = "12345"`
 *
 * For a full list of indexed fields and keywords that you can use in filter expressions,
 * see Use filter
 * expressions in the *Amazon Web Services X-Ray Developer Guide*.
 */
export declare const getTraceSummaries: API.PaginatedOperationMethod<GetTraceSummariesRequest & RegionInput, GetTraceSummariesResult, GetTraceSummariesError, Credentials | HttpClient.HttpClient, TraceSummary>;
export type ListResourcePoliciesError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Returns the list of resource policies in the target Amazon Web Services account.
 */
export declare const listResourcePolicies: API.PaginatedOperationMethod<ListResourcePoliciesRequest & RegionInput, ListResourcePoliciesResult, ListResourcePoliciesError, Credentials | HttpClient.HttpClient, ResourcePolicy>;
export type ListRetrievedTracesError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Retrieves a list of traces for a given `RetrievalToken` from the CloudWatch log group generated by Transaction Search. For information on what each trace returns, see BatchGetTraces.
 *
 * This API does not initiate a retrieval process. To start a trace retrieval, use `StartTraceRetrieval`, which generates the required `RetrievalToken`.
 *
 * When the `RetrievalStatus` is not *COMPLETE*, the API will return an empty response. Retry the request once the retrieval has completed to access the full list of traces.
 *
 * For cross-account observability, this API can retrieve traces from linked accounts when CloudWatch log is set as the destination across relevant accounts. For more details, see CloudWatch cross-account observability.
 *
 * For retrieving data from X-Ray directly as opposed to the Transaction Search generated log group, see BatchGetTraces.
 */
export declare const listRetrievedTraces: API.OperationMethod<ListRetrievedTracesRequest & RegionInput, ListRetrievedTracesResult, ListRetrievedTracesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Returns a list of tags that are applied to the specified Amazon Web Services X-Ray group or sampling rule.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type PutEncryptionConfigError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Updates the encryption configuration for X-Ray data.
 */
export declare const putEncryptionConfig: API.OperationMethod<PutEncryptionConfigRequest & RegionInput, PutEncryptionConfigResult, PutEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InvalidPolicyRevisionIdException | LockoutPreventionException | MalformedPolicyDocumentException | PolicyCountLimitExceededException | PolicySizeLimitExceededException | ThrottledException | CommonErrors;
/**
 * Sets the resource policy to grant one or more Amazon Web Services services and accounts permissions to
 * access X-Ray. Each resource policy will be associated with a specific Amazon Web Services account.
 * Each Amazon Web Services account can have a maximum of 5 resource policies, and each policy name must be
 * unique within that account. The maximum size of each resource policy is 5KB.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResult, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutTelemetryRecordsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Used by the Amazon Web Services X-Ray daemon to upload telemetry.
 */
export declare const putTelemetryRecords: API.OperationMethod<PutTelemetryRecordsRequest & RegionInput, PutTelemetryRecordsResult, PutTelemetryRecordsError, Credentials | HttpClient.HttpClient>;
export type PutTraceSegmentsError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Uploads segment documents to Amazon Web Services X-Ray.
 * A segment document can be a completed segment, an in-progress segment, or an array of
 * subsegments.
 *
 * Segments must include the following fields. For the full segment document schema, see
 * Amazon Web Services X-Ray
 * Segment Documents in the *Amazon Web Services X-Ray Developer Guide*.
 *
 * **Required segment document fields**
 *
 * - `name` - The name of the service that handled the request.
 *
 * - `id` - A 64-bit identifier for the segment, unique among segments in the same trace, in 16
 * hexadecimal digits.
 *
 * - `trace_id` - A unique identifier that connects all segments and subsegments originating from
 * a single client request.
 *
 * - `start_time` - Time the segment or subsegment was created, in floating point seconds in
 * epoch time, accurate to milliseconds. For example, `1480615200.010` or
 * `1.480615200010E9`.
 *
 * - `end_time` - Time the segment or subsegment was closed. For example,
 * `1480615200.090` or `1.480615200090E9`. Specify either an `end_time` or
 * `in_progress`.
 *
 * - `in_progress` - Set to `true` instead of specifying an `end_time` to
 * record that a segment has been started, but is not complete. Send an in-progress segment when your application
 * receives a request that will take a long time to serve, to trace that the request was received. When the
 * response is sent, send the complete segment to overwrite the in-progress segment.
 *
 * A `trace_id` consists of three numbers separated by hyphens. For example,
 * 1-58406520-a006649127e371903a2de979. For trace IDs created by an X-Ray SDK, or by Amazon Web Services services
 * integrated with X-Ray, a trace ID includes:
 *
 * **Trace ID Format**
 *
 * - The version number, for instance, `1`.
 *
 * - The time of the original request, in Unix epoch time, in 8 hexadecimal digits. For
 * example, 10:00AM December 2nd, 2016 PST in epoch time is `1480615200` seconds,
 * or `58406520` in hexadecimal.
 *
 * - A 96-bit identifier for the trace, globally unique, in 24 hexadecimal
 * digits.
 *
 * Trace IDs created via OpenTelemetry have a different format based on the
 * W3C Trace Context specification.
 * A W3C trace ID must be formatted in the X-Ray trace ID format when sending to X-Ray. For example, a W3C
 * trace ID `4efaaf4d1e8720b39541901950019ee5` should be formatted as
 * `1-4efaaf4d-1e8720b39541901950019ee5` when sending to X-Ray. While X-Ray trace IDs include
 * the original request timestamp in Unix epoch time, this is not required or validated.
 */
export declare const putTraceSegments: API.OperationMethod<PutTraceSegmentsRequest & RegionInput, PutTraceSegmentsResult, PutTraceSegmentsError, Credentials | HttpClient.HttpClient>;
export type StartTraceRetrievalError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Initiates a trace retrieval process using the specified time range and for the given trace IDs in the Transaction Search generated CloudWatch log group. For more information, see Transaction Search.
 *
 * API returns a `RetrievalToken`, which can be used with `ListRetrievedTraces` or `GetRetrievedTracesGraph` to fetch results. Retrievals will time out after 60 minutes. To execute long time ranges, consider segmenting into multiple retrievals.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation in a monitoring account to retrieve data from a linked source account, as long as both accounts have transaction search enabled.
 *
 * For retrieving data from X-Ray directly as opposed to the Transaction-Search Log group, see BatchGetTraces.
 */
export declare const startTraceRetrieval: API.OperationMethod<StartTraceRetrievalRequest & RegionInput, StartTraceRetrievalResult, StartTraceRetrievalError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidRequestException | ResourceNotFoundException | ThrottledException | TooManyTagsException | CommonErrors;
/**
 * Applies tags to an existing Amazon Web Services X-Ray group or sampling rule.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services X-Ray group or sampling rule. You cannot edit or delete system
 * tags (those with an `aws:` prefix).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = InvalidRequestException | ThrottledException | GroupNotFound | CommonErrors;
/**
 * Updates a group resource.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResult, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexingRuleError = InvalidRequestException | ResourceNotFoundException | ThrottledException | CommonErrors;
/**
 * Modifies an indexing rule's configuration.
 *
 * Indexing rules are used for determining the sampling rate for spans indexed from CloudWatch Logs. For more information, see Transaction Search.
 */
export declare const updateIndexingRule: API.OperationMethod<UpdateIndexingRuleRequest & RegionInput, UpdateIndexingRuleResult, UpdateIndexingRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateSamplingRuleError = InvalidRequestException | ThrottledException | SamplingRuleNotFound | CommonErrors;
/**
 * Modifies a sampling rule's configuration.
 */
export declare const updateSamplingRule: API.OperationMethod<UpdateSamplingRuleRequest & RegionInput, UpdateSamplingRuleResult, UpdateSamplingRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateTraceSegmentDestinationError = InvalidRequestException | ThrottledException | CommonErrors;
/**
 * Modifies the destination of data sent to `PutTraceSegments`. The Transaction Search feature requires the CloudWatchLogs destination. For more information, see Transaction Search.
 */
export declare const updateTraceSegmentDestination: API.OperationMethod<UpdateTraceSegmentDestinationRequest & RegionInput, UpdateTraceSegmentDestinationResult, UpdateTraceSegmentDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=xray.d.ts.map