/**
 * The region an operation is dispatched to.
 *
 * Every credentials layer resolves a region as part of authenticating -- the
 * environment variables, the profile, the SSO session all carry one -- so
 * {@link ResolvedCredentials.region} is where the region normally comes from
 * and it is never absent.
 *
 * Two overrides sit on top of that: the {@link Region} layer for every call
 * in a scope (`Region.of("us-west-2")`), and the `region` member every
 * operation input accepts for one call. A caller who already said
 * "authenticate with the `dev` profile" doesn't have to repeat which region
 * `dev` uses, but a caller who wants other calls in another region can say so.
 *
 * `Region`, `RegionName`, `RegionInput` and `of` come from
 * `@distilled.cloud/s3`; this module adds the environment.
 */
import * as Config from "@distilled.cloud/core/config";
import { Region, type RegionName } from "@distilled.cloud/s3/Region";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
export * from "@distilled.cloud/s3/Region";
declare const MissingRegion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::MissingRegion";
} & Readonly<A>;
/**
 * No region is configured: a credentials layer resolved a set of credentials
 * without one, or `Region.fromEnv()` found neither variable set.
 *
 * A credential-resolution failure like any other, rather than a defect: the
 * caller's fix is the same shape as for a missing key -- configure the
 * environment, the profile, or pass it explicitly.
 */
export declare class MissingRegion extends /*@__PURE__*/ MissingRegion_base<{
    message: string;
    hints?: ReadonlyArray<string>;
}> {
}
/**
 * `AWS_REGION`, then `AWS_DEFAULT_REGION` -- the variables every AWS tool
 * reads. Credentials providers use this as their region source; it fails
 * (rather than dying) so a provider can turn it into a typed
 * `MissingRegion` alongside its other credential-resolution failures.
 */
export declare const fromEnvironment: Effect.Effect<RegionName, Config.ConfigError | import("effect/ConfigProvider").SourceError, never>;
/**
 * Override the region with whatever the environment names. Each operation
 * fails with {@link MissingRegion} when neither variable is set.
 */
export declare const fromEnv: () => Layer.Layer<Region, never, never>;
//# sourceMappingURL=region.d.ts.map