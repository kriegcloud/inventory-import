import type { Kit, Model } from "../Kit.ts";
import type { Eval, Site, V } from "../Value.ts";
/**
 * `Ref` and the `Mutable` cells, `Redacted`, `Filter`, `Ordering`,
 * `UndefinedOr` and `Console`. A cell a handler makes is one only it holds:
 * what it reads is what it last wrote, so it is read as a local variable is.
 * `call` runs another model of the library, by its `module:path`.
 */
export declare const make: (kit: Kit, call: (key: string, args: ReadonlyArray<V>, site: Site) => Eval<V>) => {
    models: Readonly<Record<string, Model>>;
};
//# sourceMappingURL=Cells.d.ts.map