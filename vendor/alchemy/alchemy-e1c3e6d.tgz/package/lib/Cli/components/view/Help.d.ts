import * as CliOutput from "effect/cli/CliOutput";
import type { Interaction } from "../../../Interaction.ts";
export declare const brandedCliFormatter: (cli: Interaction["Service"]) => CliOutput.Formatter;
//# sourceMappingURL=Help.d.ts.map