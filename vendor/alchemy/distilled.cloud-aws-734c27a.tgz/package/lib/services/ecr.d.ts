import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BlockedByOrganizationPolicyException_base: S.TaggedErrorClass<"BlockedByOrganizationPolicyException", {
    readonly message: any;
}>;
export declare class BlockedByOrganizationPolicyException extends /*@__PURE__*/ BlockedByOrganizationPolicyException_base {
}
declare const EmptyUploadException_base: S.TaggedErrorClass<"EmptyUploadException", {
    readonly message: any;
}>;
export declare class EmptyUploadException extends /*@__PURE__*/ EmptyUploadException_base {
}
declare const ExclusionAlreadyExistsException_base: S.TaggedErrorClass<"ExclusionAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ExclusionAlreadyExistsException extends /*@__PURE__*/ ExclusionAlreadyExistsException_base {
}
declare const ExclusionNotFoundException_base: S.TaggedErrorClass<"ExclusionNotFoundException", {
    readonly message: any;
}>;
export declare class ExclusionNotFoundException extends /*@__PURE__*/ ExclusionNotFoundException_base {
}
declare const ImageAlreadyExistsException_base: S.TaggedErrorClass<"ImageAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageAlreadyExistsException extends /*@__PURE__*/ ImageAlreadyExistsException_base {
}
declare const ImageArchivedException_base: S.TaggedErrorClass<"ImageArchivedException", {
    readonly message: any;
}>;
export declare class ImageArchivedException extends /*@__PURE__*/ ImageArchivedException_base {
}
declare const ImageDigestDoesNotMatchException_base: S.TaggedErrorClass<"ImageDigestDoesNotMatchException", {
    readonly message: any;
}>;
export declare class ImageDigestDoesNotMatchException extends /*@__PURE__*/ ImageDigestDoesNotMatchException_base {
}
declare const ImageNotFoundException_base: S.TaggedErrorClass<"ImageNotFoundException", {
    readonly message: any;
}>;
export declare class ImageNotFoundException extends /*@__PURE__*/ ImageNotFoundException_base {
}
declare const ImageStorageClassUpdateNotSupportedException_base: S.TaggedErrorClass<"ImageStorageClassUpdateNotSupportedException", {
    readonly message: any;
}>;
export declare class ImageStorageClassUpdateNotSupportedException extends /*@__PURE__*/ ImageStorageClassUpdateNotSupportedException_base {
}
declare const ImageTagAlreadyExistsException_base: S.TaggedErrorClass<"ImageTagAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageTagAlreadyExistsException extends /*@__PURE__*/ ImageTagAlreadyExistsException_base {
}
declare const InvalidLayerException_base: S.TaggedErrorClass<"InvalidLayerException", {
    readonly message: any;
}>;
export declare class InvalidLayerException extends /*@__PURE__*/ InvalidLayerException_base {
}
declare const InvalidLayerPartException_base: S.TaggedErrorClass<"InvalidLayerPartException", {
    readonly registryId: any;
    readonly repositoryName: any;
    readonly uploadId: any;
    readonly lastValidByteReceived: any;
    readonly message: any;
}>;
export declare class InvalidLayerPartException extends /*@__PURE__*/ InvalidLayerPartException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidTagParameterException_base: S.TaggedErrorClass<"InvalidTagParameterException", {
    readonly message: any;
}>;
export declare class InvalidTagParameterException extends /*@__PURE__*/ InvalidTagParameterException_base {
}
declare const KmsException_base: S.TaggedErrorClass<"KmsException", {
    readonly message: any;
    readonly kmsError: any;
}>;
export declare class KmsException extends /*@__PURE__*/ KmsException_base {
}
declare const LayerAlreadyExistsException_base: S.TaggedErrorClass<"LayerAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class LayerAlreadyExistsException extends /*@__PURE__*/ LayerAlreadyExistsException_base {
}
declare const LayerInaccessibleException_base: S.TaggedErrorClass<"LayerInaccessibleException", {
    readonly message: any;
}>;
export declare class LayerInaccessibleException extends /*@__PURE__*/ LayerInaccessibleException_base {
}
declare const LayerPartTooSmallException_base: S.TaggedErrorClass<"LayerPartTooSmallException", {
    readonly message: any;
}>;
export declare class LayerPartTooSmallException extends /*@__PURE__*/ LayerPartTooSmallException_base {
}
declare const LayersNotFoundException_base: S.TaggedErrorClass<"LayersNotFoundException", {
    readonly message: any;
}>;
export declare class LayersNotFoundException extends /*@__PURE__*/ LayersNotFoundException_base {
}
declare const LifecyclePolicyNotFoundException_base: S.TaggedErrorClass<"LifecyclePolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LifecyclePolicyNotFoundException extends /*@__PURE__*/ LifecyclePolicyNotFoundException_base {
}
declare const LifecyclePolicyPreviewInProgressException_base: S.TaggedErrorClass<"LifecyclePolicyPreviewInProgressException", {
    readonly message: any;
}>;
export declare class LifecyclePolicyPreviewInProgressException extends /*@__PURE__*/ LifecyclePolicyPreviewInProgressException_base {
}
declare const LifecyclePolicyPreviewNotFoundException_base: S.TaggedErrorClass<"LifecyclePolicyPreviewNotFoundException", {
    readonly message: any;
}>;
export declare class LifecyclePolicyPreviewNotFoundException extends /*@__PURE__*/ LifecyclePolicyPreviewNotFoundException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PullThroughCacheRuleAlreadyExistsException_base: S.TaggedErrorClass<"PullThroughCacheRuleAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PullThroughCacheRuleAlreadyExistsException extends /*@__PURE__*/ PullThroughCacheRuleAlreadyExistsException_base {
}
declare const PullThroughCacheRuleNotFoundException_base: S.TaggedErrorClass<"PullThroughCacheRuleNotFoundException", {
    readonly message: any;
}>;
export declare class PullThroughCacheRuleNotFoundException extends /*@__PURE__*/ PullThroughCacheRuleNotFoundException_base {
}
declare const ReferencedImagesNotFoundException_base: S.TaggedErrorClass<"ReferencedImagesNotFoundException", {
    readonly message: any;
}>;
export declare class ReferencedImagesNotFoundException extends /*@__PURE__*/ ReferencedImagesNotFoundException_base {
}
declare const RegistryPolicyNotFoundException_base: S.TaggedErrorClass<"RegistryPolicyNotFoundException", {
    readonly message: any;
}>;
export declare class RegistryPolicyNotFoundException extends /*@__PURE__*/ RegistryPolicyNotFoundException_base {
}
declare const ReplicationBackfillInProgressException_base: S.TaggedErrorClass<"ReplicationBackfillInProgressException", {
    readonly message: any;
}>;
export declare class ReplicationBackfillInProgressException extends /*@__PURE__*/ ReplicationBackfillInProgressException_base {
}
declare const ReplicationBackfillInvalidStatusException_base: S.TaggedErrorClass<"ReplicationBackfillInvalidStatusException", {
    readonly message: any;
}>;
export declare class ReplicationBackfillInvalidStatusException extends /*@__PURE__*/ ReplicationBackfillInvalidStatusException_base {
}
declare const ReplicationBackfillNotFoundException_base: S.TaggedErrorClass<"ReplicationBackfillNotFoundException", {
    readonly message: any;
}>;
export declare class ReplicationBackfillNotFoundException extends /*@__PURE__*/ ReplicationBackfillNotFoundException_base {
}
declare const RepositoryAlreadyExistsException_base: S.TaggedErrorClass<"RepositoryAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RepositoryAlreadyExistsException extends /*@__PURE__*/ RepositoryAlreadyExistsException_base {
}
declare const RepositoryNotEmptyException_base: S.TaggedErrorClass<"RepositoryNotEmptyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class RepositoryNotEmptyException extends /*@__PURE__*/ RepositoryNotEmptyException_base {
}
declare const RepositoryNotFoundException_base: S.TaggedErrorClass<"RepositoryNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RepositoryNotFoundException extends /*@__PURE__*/ RepositoryNotFoundException_base {
}
declare const RepositoryPolicyNotFoundException_base: S.TaggedErrorClass<"RepositoryPolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RepositoryPolicyNotFoundException extends /*@__PURE__*/ RepositoryPolicyNotFoundException_base {
}
declare const ScanNotFoundException_base: S.TaggedErrorClass<"ScanNotFoundException", {
    readonly message: any;
}>;
export declare class ScanNotFoundException extends /*@__PURE__*/ ScanNotFoundException_base {
}
declare const SecretNotFoundException_base: S.TaggedErrorClass<"SecretNotFoundException", {
    readonly message: any;
}>;
export declare class SecretNotFoundException extends /*@__PURE__*/ SecretNotFoundException_base {
}
declare const ServerException_base: S.TaggedErrorClass<"ServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const SigningConfigurationNotFoundException_base: S.TaggedErrorClass<"SigningConfigurationNotFoundException", {
    readonly message: any;
}>;
export declare class SigningConfigurationNotFoundException extends /*@__PURE__*/ SigningConfigurationNotFoundException_base {
}
declare const TemplateAlreadyExistsException_base: S.TaggedErrorClass<"TemplateAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TemplateAlreadyExistsException extends /*@__PURE__*/ TemplateAlreadyExistsException_base {
}
declare const TemplateNotFoundException_base: S.TaggedErrorClass<"TemplateNotFoundException", {
    readonly message: any;
}>;
export declare class TemplateNotFoundException extends /*@__PURE__*/ TemplateNotFoundException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToAccessSecretException_base: S.TaggedErrorClass<"UnableToAccessSecretException", {
    readonly message: any;
}>;
export declare class UnableToAccessSecretException extends /*@__PURE__*/ UnableToAccessSecretException_base {
}
declare const UnableToDecryptSecretValueException_base: S.TaggedErrorClass<"UnableToDecryptSecretValueException", {
    readonly message: any;
}>;
export declare class UnableToDecryptSecretValueException extends /*@__PURE__*/ UnableToDecryptSecretValueException_base {
}
declare const UnableToGetUpstreamImageException_base: S.TaggedErrorClass<"UnableToGetUpstreamImageException", {
    readonly message: any;
}>;
export declare class UnableToGetUpstreamImageException extends /*@__PURE__*/ UnableToGetUpstreamImageException_base {
}
declare const UnableToGetUpstreamLayerException_base: S.TaggedErrorClass<"UnableToGetUpstreamLayerException", {
    readonly message: any;
}>;
export declare class UnableToGetUpstreamLayerException extends /*@__PURE__*/ UnableToGetUpstreamLayerException_base {
}
declare const UnableToListUpstreamImageReferrersException_base: S.TaggedErrorClass<"UnableToListUpstreamImageReferrersException", {
    readonly message: any;
}>;
export declare class UnableToListUpstreamImageReferrersException extends /*@__PURE__*/ UnableToListUpstreamImageReferrersException_base {
}
declare const UnsupportedImageTypeException_base: S.TaggedErrorClass<"UnsupportedImageTypeException", {
    readonly message: any;
}>;
export declare class UnsupportedImageTypeException extends /*@__PURE__*/ UnsupportedImageTypeException_base {
}
declare const UnsupportedUpstreamRegistryException_base: S.TaggedErrorClass<"UnsupportedUpstreamRegistryException", {
    readonly message: any;
}>;
export declare class UnsupportedUpstreamRegistryException extends /*@__PURE__*/ UnsupportedUpstreamRegistryException_base {
}
declare const UploadNotFoundException_base: S.TaggedErrorClass<"UploadNotFoundException", {
    readonly message: any;
}>;
export declare class UploadNotFoundException extends /*@__PURE__*/ UploadNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryId = string;
export type RepositoryName = string;
export type BatchedOperationLayerDigest = string;
export type BatchedOperationLayerDigestList = string[];
export interface BatchCheckLayerAvailabilityRequest {
    registryId?: string | undefined;
    repositoryName: string;
    layerDigests: string[];
}
export type LayerDigest = string;
export type LayerAvailability = "AVAILABLE" | "UNAVAILABLE" | "ARCHIVED" | (string & {});
export type LayerSizeInBytes = number;
export type MediaType = string;
export interface Layer {
    layerDigest?: string | undefined;
    layerAvailability?: LayerAvailability | undefined;
    layerSize?: number | undefined;
    mediaType?: string | undefined;
}
export type LayerList = Layer[];
export type LayerFailureCode = "InvalidLayerDigest" | "MissingLayerDigest" | (string & {});
export type LayerFailureReason = string;
export interface LayerFailure {
    layerDigest?: string | undefined;
    failureCode?: LayerFailureCode | undefined;
    failureReason?: string | undefined;
}
export type LayerFailureList = LayerFailure[];
export interface BatchCheckLayerAvailabilityResponse {
    layers?: Layer[] | undefined;
    failures?: LayerFailure[] | undefined;
}
export type ImageDigest = string;
export type ImageTag = string;
export interface ImageIdentifier {
    imageDigest?: string | undefined;
    imageTag?: string | undefined;
}
export type ImageIdentifierList = ImageIdentifier[];
export interface BatchDeleteImageRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageIds: ImageIdentifier[];
}
export type ImageFailureCode = "InvalidImageDigest" | "InvalidImageTag" | "ImageTagDoesNotMatchDigest" | "ImageNotFound" | "MissingDigestAndTag" | "ImageReferencedByManifestList" | "KmsError" | "UpstreamAccessDenied" | "UpstreamTooManyRequests" | "UpstreamUnavailable" | "ImageInaccessible" | (string & {});
export type ImageFailureReason = string;
export interface ImageFailure {
    imageId?: ImageIdentifier | undefined;
    failureCode?: ImageFailureCode | undefined;
    failureReason?: string | undefined;
}
export type ImageFailureList = ImageFailure[];
export interface BatchDeleteImageResponse {
    imageIds?: ImageIdentifier[] | undefined;
    failures?: ImageFailure[] | undefined;
}
export type MediaTypeList = string[];
export interface BatchGetImageRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageIds: ImageIdentifier[];
    acceptedMediaTypes?: string[] | undefined;
}
export type ImageManifest = string;
export interface Image {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    imageManifest?: string | undefined;
    imageManifestMediaType?: string | undefined;
}
export type ImageList = Image[];
export interface BatchGetImageResponse {
    images?: Image[] | undefined;
    failures?: ImageFailure[] | undefined;
}
export type ScanningConfigurationRepositoryNameList = string[];
export interface BatchGetRepositoryScanningConfigurationRequest {
    repositoryNames: string[];
}
export type Arn = string;
export type ScanOnPushFlag = boolean;
export type ScanFrequency = "SCAN_ON_PUSH" | "CONTINUOUS_SCAN" | "MANUAL" | (string & {});
export type ScanningRepositoryFilterValue = string;
export type ScanningRepositoryFilterType = "WILDCARD" | (string & {});
export interface ScanningRepositoryFilter {
    filter: string;
    filterType: ScanningRepositoryFilterType;
}
export type ScanningRepositoryFilterList = ScanningRepositoryFilter[];
export interface RepositoryScanningConfiguration {
    repositoryArn?: string | undefined;
    repositoryName?: string | undefined;
    scanOnPush?: boolean | undefined;
    scanFrequency?: ScanFrequency | undefined;
    appliedScanFilters?: ScanningRepositoryFilter[] | undefined;
}
export type RepositoryScanningConfigurationList = RepositoryScanningConfiguration[];
export type ScanningConfigurationFailureCode = "REPOSITORY_NOT_FOUND" | (string & {});
export type ScanningConfigurationFailureReason = string;
export interface RepositoryScanningConfigurationFailure {
    repositoryName?: string | undefined;
    failureCode?: ScanningConfigurationFailureCode | undefined;
    failureReason?: string | undefined;
}
export type RepositoryScanningConfigurationFailureList = RepositoryScanningConfigurationFailure[];
export interface BatchGetRepositoryScanningConfigurationResponse {
    scanningConfigurations?: RepositoryScanningConfiguration[] | undefined;
    failures?: RepositoryScanningConfigurationFailure[] | undefined;
}
export type UploadId = string;
export type LayerDigestList = string[];
export interface CompleteLayerUploadRequest {
    registryId?: string | undefined;
    repositoryName: string;
    uploadId: string;
    layerDigests: string[];
}
export interface CompleteLayerUploadResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    uploadId?: string | undefined;
    layerDigest?: string | undefined;
}
export type PullThroughCacheRuleRepositoryPrefix = string;
export type Url = string;
export type UpstreamRegistry = "ecr" | "ecr-public" | "quay" | "k8s" | "docker-hub" | "github-container-registry" | "azure-container-registry" | "gitlab-container-registry" | "chainguard" | (string & {});
export type CredentialArn = string;
export type CustomRoleArn = string;
export interface CreatePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    upstreamRegistryUrl: string;
    registryId?: string | undefined;
    upstreamRegistry?: UpstreamRegistry | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
}
export type CreationTimestamp = Date;
export interface CreatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string | undefined;
    upstreamRegistryUrl?: string | undefined;
    createdAt?: Date | undefined;
    registryId?: string | undefined;
    upstreamRegistry?: UpstreamRegistry | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type ImageTagMutability = "MUTABLE" | "IMMUTABLE" | "IMMUTABLE_WITH_EXCLUSION" | "MUTABLE_WITH_EXCLUSION" | (string & {});
export type ImageTagMutabilityExclusionFilterType = "WILDCARD" | (string & {});
export type ImageTagMutabilityExclusionFilterValue = string;
export interface ImageTagMutabilityExclusionFilter {
    filterType: ImageTagMutabilityExclusionFilterType;
    filter: string;
}
export type ImageTagMutabilityExclusionFilters = ImageTagMutabilityExclusionFilter[];
export interface ImageScanningConfiguration {
    scanOnPush?: boolean | undefined;
}
export type EncryptionType = "AES256" | "KMS" | "KMS_DSSE" | (string & {});
export type KmsKey = string;
export interface EncryptionConfiguration {
    encryptionType: EncryptionType;
    kmsKey?: string | undefined;
}
export interface CreateRepositoryRequest {
    registryId?: string | undefined;
    repositoryName: string;
    tags?: Tag[] | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface Repository {
    repositoryArn?: string | undefined;
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    repositoryUri?: string | undefined;
    createdAt?: Date | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface CreateRepositoryResponse {
    repository?: Repository | undefined;
}
export type Prefix = string;
export type RepositoryTemplateDescription = string;
export type KmsKeyForRepositoryCreationTemplate = string;
export interface EncryptionConfigurationForRepositoryCreationTemplate {
    encryptionType: EncryptionType;
    kmsKey?: string | undefined;
}
export type RepositoryPolicyText = string;
export type LifecyclePolicyTextForRepositoryCreationTemplate = string;
export type RCTAppliedFor = "REPLICATION" | "PULL_THROUGH_CACHE" | "CREATE_ON_PUSH" | (string & {});
export type RCTAppliedForList = RCTAppliedFor[];
export interface CreateRepositoryCreationTemplateRequest {
    prefix: string;
    description?: string | undefined;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate | undefined;
    resourceTags?: Tag[] | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
    repositoryPolicy?: string | undefined;
    lifecyclePolicy?: string | undefined;
    appliedFor: RCTAppliedFor[];
    customRoleArn?: string | undefined;
}
export interface RepositoryCreationTemplate {
    prefix?: string | undefined;
    description?: string | undefined;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate | undefined;
    resourceTags?: Tag[] | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
    repositoryPolicy?: string | undefined;
    lifecyclePolicy?: string | undefined;
    appliedFor?: RCTAppliedFor[] | undefined;
    customRoleArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateRepositoryCreationTemplateResponse {
    registryId?: string | undefined;
    repositoryCreationTemplate?: RepositoryCreationTemplate | undefined;
}
export interface DeleteLifecyclePolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
}
export type LifecyclePolicyText = string;
export type EvaluationTimestamp = Date;
export interface DeleteLifecyclePolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    lifecyclePolicyText?: string | undefined;
    lastEvaluatedAt?: Date | undefined;
}
export interface DeletePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    registryId?: string | undefined;
}
export interface DeletePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string | undefined;
    upstreamRegistryUrl?: string | undefined;
    createdAt?: Date | undefined;
    registryId?: string | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
}
export interface DeleteRegistryPolicyRequest {
}
export type RegistryPolicyText = string;
export interface DeleteRegistryPolicyResponse {
    registryId?: string | undefined;
    policyText?: string | undefined;
}
export type ForceFlag = boolean;
export interface DeleteRepositoryRequest {
    registryId?: string | undefined;
    repositoryName: string;
    force?: boolean | undefined;
}
export interface DeleteRepositoryResponse {
    repository?: Repository | undefined;
}
export interface DeleteRepositoryCreationTemplateRequest {
    prefix: string;
}
export interface DeleteRepositoryCreationTemplateResponse {
    registryId?: string | undefined;
    repositoryCreationTemplate?: RepositoryCreationTemplate | undefined;
}
export interface DeleteRepositoryPolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
}
export interface DeleteRepositoryPolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    policyText?: string | undefined;
}
export interface DeleteSigningConfigurationRequest {
}
export type SigningProfileArn = string;
export type SigningRepositoryFilterValue = string;
export type SigningRepositoryFilterType = "WILDCARD_MATCH" | (string & {});
export interface SigningRepositoryFilter {
    filter: string;
    filterType: SigningRepositoryFilterType;
}
export type SigningRepositoryFilterList = SigningRepositoryFilter[];
export interface SigningRule {
    signingProfileArn: string;
    repositoryFilters?: SigningRepositoryFilter[] | undefined;
}
export type SigningRuleList = SigningRule[];
export interface SigningConfiguration {
    rules: SigningRule[];
}
export interface DeleteSigningConfigurationResponse {
    registryId?: string | undefined;
    signingConfiguration?: SigningConfiguration | undefined;
}
export type PrincipalArn = string;
export interface DeregisterPullTimeUpdateExclusionRequest {
    principalArn: string;
}
export interface DeregisterPullTimeUpdateExclusionResponse {
    principalArn?: string | undefined;
}
export interface DescribeImageReplicationStatusRequest {
    repositoryName: string;
    imageId: ImageIdentifier;
    registryId?: string | undefined;
}
export type Region = string;
export type ReplicationStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export type ReplicationError = string;
export interface ImageReplicationStatus {
    region?: string | undefined;
    registryId?: string | undefined;
    status?: ReplicationStatus | undefined;
    failureCode?: string | undefined;
}
export type ImageReplicationStatusList = ImageReplicationStatus[];
export interface DescribeImageReplicationStatusResponse {
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    replicationStatuses?: ImageReplicationStatus[] | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export type TagStatus = "TAGGED" | "UNTAGGED" | "ANY" | (string & {});
export type ImageStatusFilter = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | "ANY" | (string & {});
export interface DescribeImagesFilter {
    tagStatus?: TagStatus | undefined;
    imageStatus?: ImageStatusFilter | undefined;
}
export interface DescribeImagesRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageIds?: ImageIdentifier[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: DescribeImagesFilter | undefined;
}
export type ImageTagList = string[];
export type ImageSizeInBytes = number;
export type PushTimestamp = Date;
export type ScanStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | "UNSUPPORTED_IMAGE" | "ACTIVE" | "PENDING" | "SCAN_ELIGIBILITY_EXPIRED" | "FINDINGS_UNAVAILABLE" | "LIMIT_EXCEEDED" | "IMAGE_ARCHIVED" | (string & {});
export type ScanStatusDescription = string;
export interface ImageScanStatus {
    status?: ScanStatus | undefined;
    description?: string | undefined;
}
export type ScanTimestamp = Date;
export type VulnerabilitySourceUpdateTimestamp = Date;
export type FindingSeverity = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | "UNDEFINED" | (string & {});
export type SeverityCount = number;
export type FindingSeverityCounts = {
    [key in FindingSeverity]?: number | undefined;
};
export interface ImageScanFindingsSummary {
    imageScanCompletedAt?: Date | undefined;
    vulnerabilitySourceUpdatedAt?: Date | undefined;
    findingSeverityCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type RecordedPullTimestamp = Date;
export type ImageStatus = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | (string & {});
export type LastArchivedAtTimestamp = Date;
export type LastActivatedAtTimestamp = Date;
export interface ImageDetail {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageDigest?: string | undefined;
    imageTags?: string[] | undefined;
    imageSizeInBytes?: number | undefined;
    imagePushedAt?: Date | undefined;
    imageScanStatus?: ImageScanStatus | undefined;
    imageScanFindingsSummary?: ImageScanFindingsSummary | undefined;
    imageManifestMediaType?: string | undefined;
    artifactMediaType?: string | undefined;
    lastRecordedPullTime?: Date | undefined;
    subjectManifestDigest?: string | undefined;
    imageStatus?: ImageStatus | undefined;
    lastArchivedAt?: Date | undefined;
    lastActivatedAt?: Date | undefined;
}
export type ImageDetailList = ImageDetail[];
export interface DescribeImagesResponse {
    imageDetails?: ImageDetail[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeImageScanFindingsRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageId: ImageIdentifier;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type FindingName = string;
export type FindingDescription = string;
export type AttributeKey = string;
export type AttributeValue = string;
export interface Attribute {
    key: string;
    value?: string | undefined;
}
export type AttributeList = Attribute[];
export interface ImageScanFinding {
    name?: string | undefined;
    description?: string | undefined;
    uri?: string | undefined;
    severity?: FindingSeverity | undefined;
    attributes?: Attribute[] | undefined;
}
export type ImageScanFindingList = ImageScanFinding[];
export type FindingArn = string;
export type BaseScore = number;
export type ScoringVector = string;
export type Source = string;
export type Version = string;
export interface CvssScore {
    baseScore?: number | undefined;
    scoringVector?: string | undefined;
    source?: string | undefined;
    version?: string | undefined;
}
export type CvssScoreList = CvssScore[];
export type ReferenceUrlsList = string[];
export type RelatedVulnerability = string;
export type RelatedVulnerabilitiesList = string[];
export type Severity = string;
export type VulnerabilityId = string;
export type Arch = string;
export type Epoch = number;
export type FilePath = string;
export type VulnerablePackageName = string;
export type PackageManager = string;
export type Release = string;
export type SourceLayerHash = string;
export type FixedInVersion = string;
export interface VulnerablePackage {
    arch?: string | undefined;
    epoch?: number | undefined;
    filePath?: string | undefined;
    name?: string | undefined;
    packageManager?: string | undefined;
    release?: string | undefined;
    sourceLayerHash?: string | undefined;
    version?: string | undefined;
    fixedInVersion?: string | undefined;
}
export type VulnerablePackagesList = VulnerablePackage[];
export interface PackageVulnerabilityDetails {
    cvss?: CvssScore[] | undefined;
    referenceUrls?: string[] | undefined;
    relatedVulnerabilities?: string[] | undefined;
    source?: string | undefined;
    sourceUrl?: string | undefined;
    vendorCreatedAt?: Date | undefined;
    vendorSeverity?: string | undefined;
    vendorUpdatedAt?: Date | undefined;
    vulnerabilityId?: string | undefined;
    vulnerablePackages?: VulnerablePackage[] | undefined;
}
export type RecommendationText = string;
export interface Recommendation {
    url?: string | undefined;
    text?: string | undefined;
}
export interface Remediation {
    recommendation?: Recommendation | undefined;
}
export type Author = string;
export type ImageTagsList = string[];
export type Platform = string;
export type InUseCount = number;
export interface AwsEcrContainerImageDetails {
    architecture?: string | undefined;
    author?: string | undefined;
    imageHash?: string | undefined;
    imageTags?: string[] | undefined;
    platform?: string | undefined;
    pushedAt?: Date | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
    registry?: string | undefined;
    repositoryName?: string | undefined;
}
export interface ResourceDetails {
    awsEcrContainerImage?: AwsEcrContainerImageDetails | undefined;
}
export type ResourceId = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type Type = string;
export interface Resource {
    details?: ResourceDetails | undefined;
    id?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    type?: string | undefined;
}
export type ResourceList = Resource[];
export type Score = number;
export type Metric = string;
export type Reason = string;
export interface CvssScoreAdjustment {
    metric?: string | undefined;
    reason?: string | undefined;
}
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export interface CvssScoreDetails {
    adjustments?: CvssScoreAdjustment[] | undefined;
    score?: number | undefined;
    scoreSource?: string | undefined;
    scoringVector?: string | undefined;
    version?: string | undefined;
}
export interface ScoreDetails {
    cvss?: CvssScoreDetails | undefined;
}
export type Status = string;
export type Title = string;
export type FixAvailable = string;
export type ExploitAvailable = string;
export interface EnhancedImageScanFinding {
    awsAccountId?: string | undefined;
    description?: string | undefined;
    findingArn?: string | undefined;
    firstObservedAt?: Date | undefined;
    lastObservedAt?: Date | undefined;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails | undefined;
    remediation?: Remediation | undefined;
    resources?: Resource[] | undefined;
    score?: number | undefined;
    scoreDetails?: ScoreDetails | undefined;
    severity?: string | undefined;
    status?: string | undefined;
    title?: string | undefined;
    type?: string | undefined;
    updatedAt?: Date | undefined;
    fixAvailable?: string | undefined;
    exploitAvailable?: string | undefined;
}
export type EnhancedImageScanFindingList = EnhancedImageScanFinding[];
export interface ImageScanFindings {
    imageScanCompletedAt?: Date | undefined;
    vulnerabilitySourceUpdatedAt?: Date | undefined;
    findingSeverityCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    findings?: ImageScanFinding[] | undefined;
    enhancedFindings?: EnhancedImageScanFinding[] | undefined;
}
export interface DescribeImageScanFindingsResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    imageScanStatus?: ImageScanStatus | undefined;
    imageScanFindings?: ImageScanFindings | undefined;
    nextToken?: string | undefined;
}
export interface DescribeImageSigningStatusRequest {
    repositoryName: string;
    imageId: ImageIdentifier;
    registryId?: string | undefined;
}
export type SigningStatusFailureCode = string;
export type SigningStatusFailureReason = string;
export type SigningStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export interface ImageSigningStatus {
    signingProfileArn?: string | undefined;
    failureCode?: string | undefined;
    failureReason?: string | undefined;
    status?: SigningStatus | undefined;
}
export type ImageSigningStatusList = ImageSigningStatus[];
export interface DescribeImageSigningStatusResponse {
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    registryId?: string | undefined;
    signingStatuses?: ImageSigningStatus[] | undefined;
}
export type PullThroughCacheRuleRepositoryPrefixList = string[];
export interface DescribePullThroughCacheRulesRequest {
    registryId?: string | undefined;
    ecrRepositoryPrefixes?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type UpdatedTimestamp = Date;
export interface PullThroughCacheRule {
    ecrRepositoryPrefix?: string | undefined;
    upstreamRegistryUrl?: string | undefined;
    createdAt?: Date | undefined;
    registryId?: string | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
    upstreamRegistry?: UpstreamRegistry | undefined;
    updatedAt?: Date | undefined;
}
export type PullThroughCacheRuleList = PullThroughCacheRule[];
export interface DescribePullThroughCacheRulesResponse {
    pullThroughCacheRules?: PullThroughCacheRule[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeRegistryRequest {
}
export interface ReplicationDestination {
    region: string;
    registryId: string;
}
export type ReplicationDestinationList = ReplicationDestination[];
export type RepositoryFilterValue = string;
export type RepositoryFilterType = "PREFIX_MATCH" | (string & {});
export interface RepositoryFilter {
    filter: string;
    filterType: RepositoryFilterType;
}
export type RepositoryFilterList = RepositoryFilter[];
export interface ReplicationRule {
    destinations: ReplicationDestination[];
    repositoryFilters?: RepositoryFilter[] | undefined;
}
export type ReplicationRuleList = ReplicationRule[];
export interface ReplicationConfiguration {
    rules: ReplicationRule[];
}
export interface DescribeRegistryResponse {
    registryId?: string | undefined;
    replicationConfiguration?: ReplicationConfiguration | undefined;
}
export type ReplicationBackfillId = string;
export type ReplicationBackfillResultStatus = "COMPLETE" | "FAILED" | (string & {});
export interface DescribeReplicationBackfillResultsRequest {
    registryId?: string | undefined;
    replicationBackfillId: string;
    resultStatusFilter?: ReplicationBackfillResultStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ReplicationBackfillStatus = "PREPARING" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export type ReplicationBackfillError = string;
export type NonNegativeInteger = number;
export type ReplicationErrorList = string[];
export interface ReplicationBackfillProgress {
    totalReplicationCount: number;
    completedReplicationCount: number;
    failedReplicationCount: number;
    failureCodes: string[];
}
export interface ReplicationBackfillResult {
    repositoryName: string;
    imageId: ImageIdentifier;
    status: ReplicationBackfillResultStatus;
    failureCode?: string | undefined;
    subImageFailureCodes?: string[] | undefined;
}
export type ReplicationBackfillResultList = ReplicationBackfillResult[];
export interface DescribeReplicationBackfillResultsResponse {
    registryId?: string | undefined;
    replicationBackfillId?: string | undefined;
    destination?: ReplicationDestination | undefined;
    status?: ReplicationBackfillStatus | undefined;
    failureCode?: string | undefined;
    progress?: ReplicationBackfillProgress | undefined;
    results?: ReplicationBackfillResult[] | undefined;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    nextToken?: string | undefined;
}
export type RepositoryNameList = string[];
export interface DescribeRepositoriesRequest {
    registryId?: string | undefined;
    repositoryNames?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type RepositoryList = Repository[];
export interface DescribeRepositoriesResponse {
    repositories?: Repository[] | undefined;
    nextToken?: string | undefined;
}
export type PrefixList = string[];
export interface DescribeRepositoryCreationTemplatesRequest {
    prefixes?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type RepositoryCreationTemplateList = RepositoryCreationTemplate[];
export interface DescribeRepositoryCreationTemplatesResponse {
    registryId?: string | undefined;
    repositoryCreationTemplates?: RepositoryCreationTemplate[] | undefined;
    nextToken?: string | undefined;
}
export type AccountSettingName = string;
export interface GetAccountSettingRequest {
    name: string;
}
export interface GetAccountSettingResponse {
    name?: string | undefined;
    value?: string | undefined;
}
export type GetAuthorizationTokenRegistryIdList = string[];
export interface GetAuthorizationTokenRequest {
    registryIds?: string[] | undefined;
}
export type Base64 = string;
export type ExpirationTimestamp = Date;
export type ProxyEndpoint = string;
export interface AuthorizationData {
    authorizationToken?: string | redacted.Redacted<string> | undefined;
    expiresAt?: Date | undefined;
    proxyEndpoint?: string | undefined;
}
export type AuthorizationDataList = AuthorizationData[];
export interface GetAuthorizationTokenResponse {
    authorizationData?: AuthorizationData[] | undefined;
}
export interface GetDownloadUrlForLayerRequest {
    registryId?: string | undefined;
    repositoryName: string;
    layerDigest: string;
}
export interface GetDownloadUrlForLayerResponse {
    downloadUrl?: string | undefined;
    layerDigest?: string | undefined;
}
export interface GetLifecyclePolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
}
export interface GetLifecyclePolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    lifecyclePolicyText?: string | undefined;
    lastEvaluatedAt?: Date | undefined;
}
export type LifecyclePreviewMaxResults = number;
export interface LifecyclePolicyPreviewFilter {
    tagStatus?: TagStatus | undefined;
}
export interface GetLifecyclePolicyPreviewRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageIds?: ImageIdentifier[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: LifecyclePolicyPreviewFilter | undefined;
}
export type LifecyclePolicyPreviewStatus = "IN_PROGRESS" | "COMPLETE" | "EXPIRED" | "FAILED" | (string & {});
export type ImageActionType = "EXPIRE" | "TRANSITION" | (string & {});
export type LifecyclePolicyTargetStorageClass = "ARCHIVE" | (string & {});
export interface LifecyclePolicyRuleAction {
    type?: ImageActionType | undefined;
    targetStorageClass?: LifecyclePolicyTargetStorageClass | undefined;
}
export type LifecyclePolicyRulePriority = number;
export type LifecyclePolicyStorageClass = "ARCHIVE" | "STANDARD" | (string & {});
export interface LifecyclePolicyPreviewResult {
    imageTags?: string[] | undefined;
    imageDigest?: string | undefined;
    imagePushedAt?: Date | undefined;
    action?: LifecyclePolicyRuleAction | undefined;
    appliedRulePriority?: number | undefined;
    storageClass?: LifecyclePolicyStorageClass | undefined;
}
export type LifecyclePolicyPreviewResultList = LifecyclePolicyPreviewResult[];
export type ImageCount = number;
export interface TransitioningImageTotalCount {
    targetStorageClass?: LifecyclePolicyTargetStorageClass | undefined;
    imageTotalCount?: number | undefined;
}
export type TransitioningImageTotalCounts = TransitioningImageTotalCount[];
export interface LifecyclePolicyPreviewSummary {
    expiringImageTotalCount?: number | undefined;
    transitioningImageTotalCounts?: TransitioningImageTotalCount[] | undefined;
}
export interface GetLifecyclePolicyPreviewResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    lifecyclePolicyText?: string | undefined;
    status?: LifecyclePolicyPreviewStatus | undefined;
    nextToken?: string | undefined;
    previewResults?: LifecyclePolicyPreviewResult[] | undefined;
    summary?: LifecyclePolicyPreviewSummary | undefined;
}
export interface GetRegistryPolicyRequest {
}
export interface GetRegistryPolicyResponse {
    registryId?: string | undefined;
    policyText?: string | undefined;
}
export interface GetRegistryScanningConfigurationRequest {
}
export type ScanType = "BASIC" | "ENHANCED" | (string & {});
export interface RegistryScanningRule {
    scanFrequency: ScanFrequency;
    repositoryFilters: ScanningRepositoryFilter[];
}
export type RegistryScanningRuleList = RegistryScanningRule[];
export interface RegistryScanningConfiguration {
    scanType?: ScanType | undefined;
    rules?: RegistryScanningRule[] | undefined;
}
export interface GetRegistryScanningConfigurationResponse {
    registryId?: string | undefined;
    scanningConfiguration?: RegistryScanningConfiguration | undefined;
}
export interface GetRepositoryPolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
}
export interface GetRepositoryPolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    policyText?: string | undefined;
}
export interface GetSigningConfigurationRequest {
}
export interface GetSigningConfigurationResponse {
    registryId?: string | undefined;
    signingConfiguration?: SigningConfiguration | undefined;
}
export interface InitiateLayerUploadRequest {
    registryId?: string | undefined;
    repositoryName: string;
}
export type PartSize = number;
export interface InitiateLayerUploadResponse {
    uploadId?: string | undefined;
    partSize?: number | undefined;
}
export interface SubjectIdentifier {
    imageDigest: string;
}
export type ArtifactType = string;
export type ArtifactTypeList = string[];
export type ArtifactStatusFilter = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | "ANY" | (string & {});
export interface ListImageReferrersFilter {
    artifactTypes?: string[] | undefined;
    artifactStatus?: ArtifactStatusFilter | undefined;
}
export type FiftyMaxResults = number;
export interface ListImageReferrersRequest {
    registryId?: string | undefined;
    repositoryName: string;
    subjectId: SubjectIdentifier;
    filter?: ListImageReferrersFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Annotations = {
    [key: string]: string | undefined;
};
export type ArtifactStatus = "ACTIVE" | "ARCHIVED" | "ACTIVATING" | (string & {});
export interface ImageReferrer {
    digest: string;
    mediaType: string;
    artifactType?: string | undefined;
    size: number;
    annotations?: {
        [key: string]: string | undefined;
    } | undefined;
    artifactStatus?: ArtifactStatus | undefined;
}
export type ImageReferrerList = ImageReferrer[];
export interface ListImageReferrersResponse {
    referrers?: ImageReferrer[] | undefined;
    nextToken?: string | undefined;
}
export interface ListImagesFilter {
    tagStatus?: TagStatus | undefined;
    imageStatus?: ImageStatusFilter | undefined;
}
export interface ListImagesRequest {
    registryId?: string | undefined;
    repositoryName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: ListImagesFilter | undefined;
}
export interface ListImagesResponse {
    imageIds?: ImageIdentifier[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPullTimeUpdateExclusionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type PullTimeUpdateExclusionList = string[];
export interface ListPullTimeUpdateExclusionsResponse {
    pullTimeUpdateExclusions?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListReplicationBackfillsRequest {
    registryId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ReplicationBackfillSummary {
    replicationBackfillId: string;
    destination: ReplicationDestination;
    status: ReplicationBackfillStatus;
    failureCode?: string | undefined;
    progress?: ReplicationBackfillProgress | undefined;
    startedAt: Date;
    endedAt?: Date | undefined;
}
export type ReplicationBackfillSummaryList = ReplicationBackfillSummary[];
export interface ListReplicationBackfillsResponse {
    registryId?: string | undefined;
    backfills?: ReplicationBackfillSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export type AccountSettingValue = string;
export interface PutAccountSettingRequest {
    name: string;
    value: string;
}
export interface PutAccountSettingResponse {
    name?: string | undefined;
    value?: string | undefined;
}
export interface PutImageRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageManifest: string;
    imageManifestMediaType?: string | undefined;
    imageTag?: string | undefined;
    imageDigest?: string | undefined;
}
export interface PutImageResponse {
    image?: Image | undefined;
}
export interface PutImageScanningConfigurationRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageScanningConfiguration: ImageScanningConfiguration;
}
export interface PutImageScanningConfigurationResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageScanningConfiguration?: ImageScanningConfiguration | undefined;
}
export interface PutImageTagMutabilityRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageTagMutability: ImageTagMutability;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
}
export interface PutImageTagMutabilityResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
}
export interface PutLifecyclePolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
    lifecyclePolicyText: string;
}
export interface PutLifecyclePolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    lifecyclePolicyText?: string | undefined;
}
export interface PutRegistryPolicyRequest {
    policyText: string;
}
export interface PutRegistryPolicyResponse {
    registryId?: string | undefined;
    policyText?: string | undefined;
}
export interface PutRegistryScanningConfigurationRequest {
    scanType?: ScanType | undefined;
    rules?: RegistryScanningRule[] | undefined;
}
export interface PutRegistryScanningConfigurationResponse {
    registryScanningConfiguration?: RegistryScanningConfiguration | undefined;
}
export interface PutReplicationConfigurationRequest {
    replicationConfiguration: ReplicationConfiguration;
}
export interface PutReplicationConfigurationResponse {
    replicationConfiguration?: ReplicationConfiguration | undefined;
}
export interface PutSigningConfigurationRequest {
    signingConfiguration: SigningConfiguration;
}
export interface PutSigningConfigurationResponse {
    signingConfiguration?: SigningConfiguration | undefined;
}
export interface RegisterPullTimeUpdateExclusionRequest {
    principalArn: string;
}
export interface RegisterPullTimeUpdateExclusionResponse {
    principalArn?: string | undefined;
    createdAt?: Date | undefined;
}
export interface SetRepositoryPolicyRequest {
    registryId?: string | undefined;
    repositoryName: string;
    policyText: string;
    force?: boolean | undefined;
}
export interface SetRepositoryPolicyResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    policyText?: string | undefined;
}
export interface StartImageScanRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageId: ImageIdentifier;
}
export interface StartImageScanResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    imageScanStatus?: ImageScanStatus | undefined;
}
export interface StartLifecyclePolicyPreviewRequest {
    registryId?: string | undefined;
    repositoryName: string;
    lifecyclePolicyText?: string | undefined;
}
export interface StartLifecyclePolicyPreviewResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    lifecyclePolicyText?: string | undefined;
    status?: LifecyclePolicyPreviewStatus | undefined;
}
export interface StartReplicationBackfillRequest {
    registryId?: string | undefined;
    destination: ReplicationDestination;
}
export interface StartReplicationBackfillResponse {
    replicationBackfillId?: string | undefined;
    registryId?: string | undefined;
    destination?: ReplicationDestination | undefined;
    status?: ReplicationBackfillStatus | undefined;
    startedAt?: Date | undefined;
}
export interface StopReplicationBackfillRequest {
    registryId?: string | undefined;
    replicationBackfillId: string;
}
export interface StopReplicationBackfillResponse {
    registryId?: string | undefined;
    replicationBackfillId?: string | undefined;
    destination?: ReplicationDestination | undefined;
    status?: ReplicationBackfillStatus | undefined;
    startedAt?: Date | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type TargetStorageClass = "STANDARD" | "ARCHIVE" | (string & {});
export interface UpdateImageStorageClassRequest {
    registryId?: string | undefined;
    repositoryName: string;
    imageId: ImageIdentifier;
    targetStorageClass: TargetStorageClass;
}
export interface UpdateImageStorageClassResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    imageId?: ImageIdentifier | undefined;
    imageStatus?: ImageStatus | undefined;
}
export interface UpdatePullThroughCacheRuleRequest {
    registryId?: string | undefined;
    ecrRepositoryPrefix: string;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
}
export interface UpdatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string | undefined;
    registryId?: string | undefined;
    updatedAt?: Date | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
}
export interface UpdateRepositoryCreationTemplateRequest {
    prefix: string;
    description?: string | undefined;
    encryptionConfiguration?: EncryptionConfigurationForRepositoryCreationTemplate | undefined;
    resourceTags?: Tag[] | undefined;
    imageTagMutability?: ImageTagMutability | undefined;
    imageTagMutabilityExclusionFilters?: ImageTagMutabilityExclusionFilter[] | undefined;
    repositoryPolicy?: string | undefined;
    lifecyclePolicy?: string | undefined;
    appliedFor?: RCTAppliedFor[] | undefined;
    customRoleArn?: string | undefined;
}
export interface UpdateRepositoryCreationTemplateResponse {
    registryId?: string | undefined;
    repositoryCreationTemplate?: RepositoryCreationTemplate | undefined;
}
export type LayerPartBlob = Uint8Array;
export interface UploadLayerPartRequest {
    registryId?: string | undefined;
    repositoryName: string;
    uploadId: string;
    partFirstByte: number;
    partLastByte: number;
    layerPartBlob: Uint8Array;
}
export interface UploadLayerPartResponse {
    registryId?: string | undefined;
    repositoryName?: string | undefined;
    uploadId?: string | undefined;
    lastByteReceived?: number | undefined;
}
export interface ValidatePullThroughCacheRuleRequest {
    ecrRepositoryPrefix: string;
    registryId?: string | undefined;
}
export type IsPTCRuleValid = boolean;
export type PTCValidateFailure = string;
export interface ValidatePullThroughCacheRuleResponse {
    ecrRepositoryPrefix?: string | undefined;
    registryId?: string | undefined;
    upstreamRegistryUrl?: string | undefined;
    credentialArn?: string | undefined;
    customRoleArn?: string | undefined;
    upstreamRepositoryPrefix?: string | undefined;
    isValid?: boolean | undefined;
    failure?: string | undefined;
}
export type ExceptionMessage = string;
export type KmsError = string;
export type BatchCheckLayerAvailabilityError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Checks the availability of one or more image layers in a repository.
 *
 * When an image is pushed to a repository, each image layer is checked to verify if it
 * has been uploaded before. If it has been uploaded, then the image layer is
 * skipped.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const batchCheckLayerAvailability: API.OperationMethod<BatchCheckLayerAvailabilityRequest & RegionInput, BatchCheckLayerAvailabilityResponse, BatchCheckLayerAvailabilityError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteImageError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a list of specified images within a repository. Images are specified with
 * either an `imageTag` or `imageDigest`.
 *
 * You can remove a tag from an image by specifying the image's tag in your request. When
 * you remove the last tag from an image, the image is deleted from your repository.
 *
 * You can completely delete an image (and all of its tags) by specifying the image's
 * digest in your request.
 */
export declare const batchDeleteImage: API.OperationMethod<BatchDeleteImageRequest & RegionInput, BatchDeleteImageResponse, BatchDeleteImageError, Credentials | HttpClient.HttpClient>;
export type BatchGetImageError = InvalidParameterException | LimitExceededException | RepositoryNotFoundException | ServerException | UnableToGetUpstreamImageException | CommonErrors;
/**
 * Gets detailed information for an image. Images are specified with either an
 * `imageTag` or `imageDigest`.
 *
 * When an image is pulled, the BatchGetImage API is called once to retrieve the image
 * manifest.
 */
export declare const batchGetImage: API.OperationMethod<BatchGetImageRequest & RegionInput, BatchGetImageResponse, BatchGetImageError, Credentials | HttpClient.HttpClient>;
export type BatchGetRepositoryScanningConfigurationError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Gets the scanning configuration for one or more repositories.
 */
export declare const batchGetRepositoryScanningConfiguration: API.OperationMethod<BatchGetRepositoryScanningConfigurationRequest & RegionInput, BatchGetRepositoryScanningConfigurationResponse, BatchGetRepositoryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type CompleteLayerUploadError = EmptyUploadException | InvalidLayerException | InvalidParameterException | KmsException | LayerAlreadyExistsException | LayerPartTooSmallException | RepositoryNotFoundException | ServerException | UploadNotFoundException | CommonErrors;
/**
 * Informs Amazon ECR that the image layer upload has completed for a specified registry,
 * repository name, and upload ID. You can optionally provide a `sha256` digest
 * of the image layer for data validation purposes.
 *
 * When an image is pushed, the CompleteLayerUpload API is called once per each new image
 * layer to verify that the upload has completed.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const completeLayerUpload: API.OperationMethod<CompleteLayerUploadRequest & RegionInput, CompleteLayerUploadResponse, CompleteLayerUploadError, Credentials | HttpClient.HttpClient>;
export type CreatePullThroughCacheRuleError = InvalidParameterException | LimitExceededException | PullThroughCacheRuleAlreadyExistsException | SecretNotFoundException | ServerException | UnableToAccessSecretException | UnableToDecryptSecretValueException | UnsupportedUpstreamRegistryException | ValidationException | CommonErrors;
/**
 * Creates a pull through cache rule. A pull through cache rule provides a way to cache
 * images from an upstream registry source in your Amazon ECR private registry. For more
 * information, see Using pull through cache
 * rules in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const createPullThroughCacheRule: API.OperationMethod<CreatePullThroughCacheRuleRequest & RegionInput, CreatePullThroughCacheRuleResponse, CreatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = InvalidParameterException | InvalidTagParameterException | KmsException | LimitExceededException | RepositoryAlreadyExistsException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Creates a repository. For more information, see Amazon ECR repositories in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryRequest & RegionInput, CreateRepositoryResponse, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryCreationTemplateError = InvalidParameterException | LimitExceededException | ServerException | TemplateAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a repository creation template. This template is used to define the settings
 * for repositories created by Amazon ECR on your behalf. For example, repositories created
 * through pull through cache actions. For more information, see Private
 * repository creation templates in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const createRepositoryCreationTemplate: API.OperationMethod<CreateRepositoryCreationTemplateRequest & RegionInput, CreateRepositoryCreationTemplateResponse, CreateRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = InvalidParameterException | LifecyclePolicyNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes the lifecycle policy associated with the specified repository.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest & RegionInput, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes a pull through cache rule.
 */
export declare const deletePullThroughCacheRule: API.OperationMethod<DeletePullThroughCacheRuleRequest & RegionInput, DeletePullThroughCacheRuleResponse, DeletePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryPolicyError = InvalidParameterException | RegistryPolicyNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Deletes the registry permissions policy.
 */
export declare const deleteRegistryPolicy: API.OperationMethod<DeleteRegistryPolicyRequest & RegionInput, DeleteRegistryPolicyResponse, DeleteRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = InvalidParameterException | KmsException | RepositoryNotEmptyException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Deletes a repository. If the repository isn't empty, you must either delete the
 * contents of the repository or use the `force` option to delete the repository
 * and have Amazon ECR delete all of its contents on your behalf.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryRequest & RegionInput, DeleteRepositoryResponse, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryCreationTemplateError = InvalidParameterException | ServerException | TemplateNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a repository creation template.
 */
export declare const deleteRepositoryCreationTemplate: API.OperationMethod<DeleteRepositoryCreationTemplateRequest & RegionInput, DeleteRepositoryCreationTemplateResponse, DeleteRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | CommonErrors;
/**
 * Deletes the repository policy associated with the specified repository.
 */
export declare const deleteRepositoryPolicy: API.OperationMethod<DeleteRepositoryPolicyRequest & RegionInput, DeleteRepositoryPolicyResponse, DeleteRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSigningConfigurationError = ServerException | SigningConfigurationNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the registry's signing configuration. Images pushed after deletion of the signing
 * configuration will no longer be automatically signed.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 *
 * Deleting the signing configuration does not affect existing image signatures.
 */
export declare const deleteSigningConfiguration: API.OperationMethod<DeleteSigningConfigurationRequest & RegionInput, DeleteSigningConfigurationResponse, DeleteSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeregisterPullTimeUpdateExclusionError = ExclusionNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Removes a principal from the pull time update exclusion list for a registry. Once removed, Amazon ECR will resume updating the pull time if the specified principal pulls an image.
 */
export declare const deregisterPullTimeUpdateExclusion: API.OperationMethod<DeregisterPullTimeUpdateExclusionRequest & RegionInput, DeregisterPullTimeUpdateExclusionResponse, DeregisterPullTimeUpdateExclusionError, Credentials | HttpClient.HttpClient>;
export type DescribeImageReplicationStatusError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the replication status for a specified image.
 */
export declare const describeImageReplicationStatus: API.OperationMethod<DescribeImageReplicationStatusRequest & RegionInput, DescribeImageReplicationStatusResponse, DescribeImageReplicationStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeImagesError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Returns metadata about the images in a repository.
 *
 * Starting with Docker version 1.9, the Docker client compresses image layers before
 * pushing them to a V2 Docker registry. The output of the `docker images`
 * command shows the uncompressed image size. Therefore, Docker might return a larger
 * image than the image shown in the Amazon Web Services Management Console.
 *
 * The new version of Amazon ECR
 * *Basic Scanning* doesn't use the ImageDetail$imageScanFindingsSummary and ImageDetail$imageScanStatus attributes from the API response to
 * return scan results. Use the DescribeImageScanFindings API
 * instead. For more information about Amazon Web Services native basic scanning, see Scan
 * images for software vulnerabilities in Amazon ECR.
 */
export declare const describeImages: API.PaginatedOperationMethod<DescribeImagesRequest & RegionInput, DescribeImagesResponse, DescribeImagesError, Credentials | HttpClient.HttpClient, ImageDetail>;
export type DescribeImageScanFindingsError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ScanNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the scan findings for the specified image.
 */
export declare const describeImageScanFindings: API.PaginatedOperationMethod<DescribeImageScanFindingsRequest & RegionInput, DescribeImageScanFindingsResponse, DescribeImageScanFindingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeImageSigningStatusError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the signing status for a specified image. If the image matched
 * signing rules that reference different signing profiles, a status is returned
 * for each profile.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const describeImageSigningStatus: API.OperationMethod<DescribeImageSigningStatusRequest & RegionInput, DescribeImageSigningStatusResponse, DescribeImageSigningStatusError, Credentials | HttpClient.HttpClient>;
export type DescribePullThroughCacheRulesError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the pull through cache rules for a registry.
 */
export declare const describePullThroughCacheRules: API.PaginatedOperationMethod<DescribePullThroughCacheRulesRequest & RegionInput, DescribePullThroughCacheRulesResponse, DescribePullThroughCacheRulesError, Credentials | HttpClient.HttpClient, PullThroughCacheRule>;
export type DescribeRegistryError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Describes the settings for a registry. The replication configuration for a repository
 * can be created or updated with the PutReplicationConfiguration API
 * action.
 */
export declare const describeRegistry: API.OperationMethod<DescribeRegistryRequest & RegionInput, DescribeRegistryResponse, DescribeRegistryError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicationBackfillResultsError = InvalidParameterException | ReplicationBackfillNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Returns the status, progress, and per-image results for a replication backfill. The
 * backfill to describe is identified by the `replicationBackfillId` returned by
 * the StartReplicationBackfill operation.
 *
 * The per-image results are available only after the replication backfill reaches a
 * terminal status.
 */
export declare const describeReplicationBackfillResults: API.PaginatedOperationMethod<DescribeReplicationBackfillResultsRequest & RegionInput, DescribeReplicationBackfillResultsResponse, DescribeReplicationBackfillResultsError, Credentials | HttpClient.HttpClient, ReplicationBackfillResult>;
export type DescribeRepositoriesError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Describes image repositories in a registry.
 */
export declare const describeRepositories: API.PaginatedOperationMethod<DescribeRepositoriesRequest & RegionInput, DescribeRepositoriesResponse, DescribeRepositoriesError, Credentials | HttpClient.HttpClient, Repository>;
export type DescribeRepositoryCreationTemplatesError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Returns details about the repository creation templates in a registry. The
 * `prefixes` request parameter can be used to return the details for a
 * specific repository creation template.
 */
export declare const describeRepositoryCreationTemplates: API.PaginatedOperationMethod<DescribeRepositoryCreationTemplatesRequest & RegionInput, DescribeRepositoryCreationTemplatesResponse, DescribeRepositoryCreationTemplatesError, Credentials | HttpClient.HttpClient, RepositoryCreationTemplate>;
export type GetAccountSettingError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the account setting value for the specified setting name.
 */
export declare const getAccountSetting: API.OperationMethod<GetAccountSettingRequest & RegionInput, GetAccountSettingResponse, GetAccountSettingError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizationTokenError = InvalidParameterException | ServerException | CommonErrors;
/**
 * Retrieves an authorization token. An authorization token represents your IAM
 * authentication credentials and can be used to access any Amazon ECR registry that your IAM
 * principal has access to. The authorization token is valid for 12 hours.
 *
 * The `authorizationToken` returned is a base64 encoded string that can be
 * decoded and used in a `docker login` command to authenticate to a registry.
 * The CLI offers an `get-login-password` command that simplifies the login
 * process. For more information, see Registry
 * authentication in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const getAuthorizationToken: API.OperationMethod<GetAuthorizationTokenRequest & RegionInput, GetAuthorizationTokenResponse, GetAuthorizationTokenError, Credentials | HttpClient.HttpClient>;
export type GetDownloadUrlForLayerError = InvalidParameterException | LayerInaccessibleException | LayersNotFoundException | RepositoryNotFoundException | ServerException | UnableToGetUpstreamLayerException | CommonErrors;
/**
 * Retrieves the pre-signed Amazon S3 download URL corresponding to an image layer. You can
 * only get URLs for image layers that are referenced in an image.
 *
 * When an image is pulled, the GetDownloadUrlForLayer API is called once per image layer
 * that is not already cached.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const getDownloadUrlForLayer: API.OperationMethod<GetDownloadUrlForLayerRequest & RegionInput, GetDownloadUrlForLayerResponse, GetDownloadUrlForLayerError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = InvalidParameterException | LifecyclePolicyNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the lifecycle policy for the specified repository.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest & RegionInput, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyPreviewError = InvalidParameterException | LifecyclePolicyPreviewNotFoundException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the results of the lifecycle policy preview request for the specified
 * repository.
 */
export declare const getLifecyclePolicyPreview: API.PaginatedOperationMethod<GetLifecyclePolicyPreviewRequest & RegionInput, GetLifecyclePolicyPreviewResponse, GetLifecyclePolicyPreviewError, Credentials | HttpClient.HttpClient, LifecyclePolicyPreviewResult>;
export type GetRegistryPolicyError = InvalidParameterException | RegistryPolicyNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the permissions policy for a registry.
 */
export declare const getRegistryPolicy: API.OperationMethod<GetRegistryPolicyRequest & RegionInput, GetRegistryPolicyResponse, GetRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRegistryScanningConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Retrieves the scanning configuration for a registry.
 */
export declare const getRegistryScanningConfiguration: API.OperationMethod<GetRegistryScanningConfigurationRequest & RegionInput, GetRegistryScanningConfigurationResponse, GetRegistryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | CommonErrors;
/**
 * Retrieves the repository policy for the specified repository.
 */
export declare const getRepositoryPolicy: API.OperationMethod<GetRepositoryPolicyRequest & RegionInput, GetRepositoryPolicyResponse, GetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type GetSigningConfigurationError = InvalidParameterException | ServerException | SigningConfigurationNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the registry's signing configuration, which defines
 * rules for automatically signing images using Amazon Web Services Signer.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 */
export declare const getSigningConfiguration: API.OperationMethod<GetSigningConfigurationRequest & RegionInput, GetSigningConfigurationResponse, GetSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type InitiateLayerUploadError = InvalidParameterException | KmsException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Notifies Amazon ECR that you intend to upload an image layer.
 *
 * When an image is pushed, the InitiateLayerUpload API is called once per image layer
 * that has not already been uploaded. Whether or not an image layer has been uploaded is
 * determined by the BatchCheckLayerAvailability API action.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const initiateLayerUpload: API.OperationMethod<InitiateLayerUploadRequest & RegionInput, InitiateLayerUploadResponse, InitiateLayerUploadError, Credentials | HttpClient.HttpClient>;
export type ListImageReferrersError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnableToListUpstreamImageReferrersException | ValidationException | CommonErrors;
/**
 * Lists the artifacts associated with a specified subject image.
 *
 * The IAM principal invoking this operation must have the `ecr:BatchGetImage` permission.
 */
export declare const listImageReferrers: API.OperationMethod<ListImageReferrersRequest & RegionInput, ListImageReferrersResponse, ListImageReferrersError, Credentials | HttpClient.HttpClient>;
export type ListImagesError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Lists all the image IDs for the specified repository.
 *
 * You can filter images based on whether or not they are tagged by using the
 * `tagStatus` filter and specifying either `TAGGED`,
 * `UNTAGGED` or `ANY`. For example, you can filter your results
 * to return only `UNTAGGED` images and then pipe that result to a BatchDeleteImage operation to delete them. Or, you can filter your
 * results to return only `TAGGED` images to list all of the tags in your
 * repository.
 */
export declare const listImages: API.PaginatedOperationMethod<ListImagesRequest & RegionInput, ListImagesResponse, ListImagesError, Credentials | HttpClient.HttpClient, ImageIdentifier>;
export type ListPullTimeUpdateExclusionsError = InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Lists the IAM principals that are excluded from having their image pull times recorded.
 */
export declare const listPullTimeUpdateExclusions: API.OperationMethod<ListPullTimeUpdateExclusionsRequest & RegionInput, ListPullTimeUpdateExclusionsResponse, ListPullTimeUpdateExclusionsError, Credentials | HttpClient.HttpClient>;
export type ListReplicationBackfillsError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Lists the replication backfills for a registry, including their status and
 * progress.
 *
 * Replication backfills that have reached a terminal status are retained for 90 days
 * after they end, after which they are no longer returned.
 */
export declare const listReplicationBackfills: API.PaginatedOperationMethod<ListReplicationBackfillsRequest & RegionInput, ListReplicationBackfillsResponse, ListReplicationBackfillsError, Credentials | HttpClient.HttpClient, ReplicationBackfillSummary>;
export type ListTagsForResourceError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * List the tags for an Amazon ECR resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingError = InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Allows you to change the basic scan type version or registry policy scope.
 */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest & RegionInput, PutAccountSettingResponse, PutAccountSettingError, Credentials | HttpClient.HttpClient>;
export type PutImageError = ImageAlreadyExistsException | ImageDigestDoesNotMatchException | ImageTagAlreadyExistsException | InvalidParameterException | KmsException | LayersNotFoundException | LimitExceededException | ReferencedImagesNotFoundException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Creates or updates the image manifest and tags associated with an image.
 *
 * When an image is pushed and all new image layers have been uploaded, the PutImage API
 * is called once to create or update the image manifest and the tags associated with the
 * image.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const putImage: API.OperationMethod<PutImageRequest & RegionInput, PutImageResponse, PutImageError, Credentials | HttpClient.HttpClient>;
export type PutImageScanningConfigurationError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * The `PutImageScanningConfiguration` API is being deprecated, in favor
 * of specifying the image scanning configuration at the registry level. For more
 * information, see PutRegistryScanningConfiguration.
 *
 * Updates the image scanning configuration for the specified repository.
 */
export declare const putImageScanningConfiguration: API.OperationMethod<PutImageScanningConfigurationRequest & RegionInput, PutImageScanningConfigurationResponse, PutImageScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutImageTagMutabilityError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Updates the image tag mutability settings for the specified repository. For more
 * information, see Image tag
 * mutability in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const putImageTagMutability: API.OperationMethod<PutImageTagMutabilityRequest & RegionInput, PutImageTagMutabilityResponse, PutImageTagMutabilityError, Credentials | HttpClient.HttpClient>;
export type PutLifecyclePolicyError = InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the lifecycle policy for the specified repository. For more
 * information, see Lifecycle policy
 * template.
 */
export declare const putLifecyclePolicy: API.OperationMethod<PutLifecyclePolicyRequest & RegionInput, PutLifecyclePolicyResponse, PutLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type PutRegistryPolicyError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the permissions policy for your registry.
 *
 * A registry policy is used to specify permissions for another Amazon Web Services account and is used
 * when configuring cross-account replication. For more information, see Registry permissions in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const putRegistryPolicy: API.OperationMethod<PutRegistryPolicyRequest & RegionInput, PutRegistryPolicyResponse, PutRegistryPolicyError, Credentials | HttpClient.HttpClient>;
export type PutRegistryScanningConfigurationError = BlockedByOrganizationPolicyException | InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the scanning configuration for your private registry.
 */
export declare const putRegistryScanningConfiguration: API.OperationMethod<PutRegistryScanningConfigurationRequest & RegionInput, PutRegistryScanningConfigurationResponse, PutRegistryScanningConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutReplicationConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the replication configuration for a registry. The existing
 * replication configuration for a repository can be retrieved with the DescribeRegistry API action. The first time the
 * PutReplicationConfiguration API is called, a service-linked IAM role is created in
 * your account for the replication process. For more information, see Using
 * service-linked roles for Amazon ECR in the *Amazon Elastic Container Registry User Guide*.
 * For more information on the custom role for replication, see Creating an IAM role for replication.
 *
 * When configuring cross-account replication, the destination account must grant the
 * source account permission to replicate. This permission is controlled using a
 * registry permissions policy. For more information, see PutRegistryPolicy.
 */
export declare const putReplicationConfiguration: API.OperationMethod<PutReplicationConfigurationRequest & RegionInput, PutReplicationConfigurationResponse, PutReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutSigningConfigurationError = InvalidParameterException | ServerException | ValidationException | CommonErrors;
/**
 * Creates or updates the registry's signing configuration, which defines
 * rules for automatically signing images with Amazon Web Services Signer.
 *
 * For more information, see Managed signing in the
 * *Amazon Elastic Container Registry User Guide*.
 *
 * To successfully generate a signature, the IAM principal pushing images must have
 * permission to sign payloads with the Amazon Web Services Signer signing profile referenced in the signing
 * configuration.
 */
export declare const putSigningConfiguration: API.OperationMethod<PutSigningConfigurationRequest & RegionInput, PutSigningConfigurationResponse, PutSigningConfigurationError, Credentials | HttpClient.HttpClient>;
export type RegisterPullTimeUpdateExclusionError = ExclusionAlreadyExistsException | InvalidParameterException | LimitExceededException | ServerException | ValidationException | CommonErrors;
/**
 * Adds an IAM principal to the pull time update exclusion list for a registry. Amazon ECR will not record the pull time if an excluded principal pulls an image.
 */
export declare const registerPullTimeUpdateExclusion: API.OperationMethod<RegisterPullTimeUpdateExclusionRequest & RegionInput, RegisterPullTimeUpdateExclusionResponse, RegisterPullTimeUpdateExclusionError, Credentials | HttpClient.HttpClient>;
export type SetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | ServerException | CommonErrors;
/**
 * Applies a repository policy to the specified repository to control access permissions.
 * For more information, see Amazon ECR Repository
 * policies in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const setRepositoryPolicy: API.OperationMethod<SetRepositoryPolicyRequest & RegionInput, SetRepositoryPolicyResponse, SetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type StartImageScanError = ImageArchivedException | ImageNotFoundException | InvalidParameterException | LimitExceededException | RepositoryNotFoundException | ServerException | UnsupportedImageTypeException | ValidationException | CommonErrors;
/**
 * Starts a basic image vulnerability scan.
 *
 * A basic image scan can only be started once per 24 hours on an individual image. This
 * limit includes if an image was scanned on initial push. You can start up to 100,000
 * basic scans per 24 hours. This limit includes both scans on initial push and scans
 * initiated by the StartImageScan API. For more information, see Basic scanning in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const startImageScan: API.OperationMethod<StartImageScanRequest & RegionInput, StartImageScanResponse, StartImageScanError, Credentials | HttpClient.HttpClient>;
export type StartLifecyclePolicyPreviewError = InvalidParameterException | LifecyclePolicyNotFoundException | LifecyclePolicyPreviewInProgressException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Starts a preview of a lifecycle policy for the specified repository. This allows you
 * to see the results before associating the lifecycle policy with the repository.
 */
export declare const startLifecyclePolicyPreview: API.OperationMethod<StartLifecyclePolicyPreviewRequest & RegionInput, StartLifecyclePolicyPreviewResponse, StartLifecyclePolicyPreviewError, Credentials | HttpClient.HttpClient>;
export type StartReplicationBackfillError = InvalidParameterException | LimitExceededException | ReplicationBackfillInProgressException | ServerException | ValidationException | CommonErrors;
/**
 * Starts a replication backfill for a registry. A replication backfill replicates a
 * registry's existing images that match its replication configuration to the specified
 * destination. Use the DescribeReplicationBackfillResults operation to
 * monitor the progress of a replication backfill, and to retrieve its per-image results
 * after it reaches a terminal status.
 *
 * The destination must already be configured in the registry's replication
 * configuration.
 *
 * Only one replication backfill can be in progress for a given destination Region at
 * a time. Starting a replication backfill for a destination Region that already has one
 * in progress fails with a `ReplicationBackfillInProgressException`. In
 * addition, a registry can have at most 10 replication backfills in progress at once.
 * Starting a replication backfill that would exceed this limit fails with a
 * `LimitExceededException`.
 */
export declare const startReplicationBackfill: API.OperationMethod<StartReplicationBackfillRequest & RegionInput, StartReplicationBackfillResponse, StartReplicationBackfillError, Credentials | HttpClient.HttpClient>;
export type StopReplicationBackfillError = InvalidParameterException | ReplicationBackfillInvalidStatusException | ReplicationBackfillNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Stops an in progress replication backfill for a registry. The backfill to stop is
 * identified by the `replicationBackfillId` returned by the StartReplicationBackfill operation.
 *
 * Images that have already been replicated are not affected, and replications that
 * are already in progress continue to completion.
 */
export declare const stopReplicationBackfill: API.OperationMethod<StopReplicationBackfillRequest & RegionInput, StopReplicationBackfillResponse, StopReplicationBackfillError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Adds specified tags to a resource with the specified ARN. Existing tags on a resource
 * are not changed if they are not specified in the request parameters.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateImageStorageClassError = ImageNotFoundException | ImageStorageClassUpdateNotSupportedException | InvalidParameterException | RepositoryNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Transitions an image between storage classes. You can transition images from Amazon ECR standard storage class to Amazon ECR archival storage class for long-term storage, or restore archived images back to Amazon ECR standard.
 */
export declare const updateImageStorageClass: API.OperationMethod<UpdateImageStorageClassRequest & RegionInput, UpdateImageStorageClassResponse, UpdateImageStorageClassError, Credentials | HttpClient.HttpClient>;
export type UpdatePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | SecretNotFoundException | ServerException | UnableToAccessSecretException | UnableToDecryptSecretValueException | ValidationException | CommonErrors;
/**
 * Updates an existing pull through cache rule.
 */
export declare const updatePullThroughCacheRule: API.OperationMethod<UpdatePullThroughCacheRuleRequest & RegionInput, UpdatePullThroughCacheRuleResponse, UpdatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryCreationTemplateError = InvalidParameterException | ServerException | TemplateNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing repository creation template.
 */
export declare const updateRepositoryCreationTemplate: API.OperationMethod<UpdateRepositoryCreationTemplateRequest & RegionInput, UpdateRepositoryCreationTemplateResponse, UpdateRepositoryCreationTemplateError, Credentials | HttpClient.HttpClient>;
export type UploadLayerPartError = InvalidLayerPartException | InvalidParameterException | KmsException | LimitExceededException | RepositoryNotFoundException | ServerException | UploadNotFoundException | CommonErrors;
/**
 * Uploads an image layer part to Amazon ECR.
 *
 * When an image is pushed, each new image layer is uploaded in parts. The maximum size
 * of each image layer part can be 20971520 bytes (or about 20MB). The UploadLayerPart API
 * is called once per each new image layer part.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by
 * customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const uploadLayerPart: API.OperationMethod<UploadLayerPartRequest & RegionInput, UploadLayerPartResponse, UploadLayerPartError, Credentials | HttpClient.HttpClient>;
export type ValidatePullThroughCacheRuleError = InvalidParameterException | PullThroughCacheRuleNotFoundException | ServerException | ValidationException | CommonErrors;
/**
 * Validates an existing pull through cache rule for an upstream registry that requires
 * authentication. This will retrieve the contents of the Amazon Web Services Secrets Manager secret, verify the
 * syntax, and then validate that authentication to the upstream registry is
 * successful.
 */
export declare const validatePullThroughCacheRule: API.OperationMethod<ValidatePullThroughCacheRuleRequest & RegionInput, ValidatePullThroughCacheRuleResponse, ValidatePullThroughCacheRuleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ecr.d.ts.map