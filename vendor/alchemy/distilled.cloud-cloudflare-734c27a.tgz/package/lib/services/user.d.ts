import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidApiToken_base: S.TaggedErrorClass<"InvalidApiToken", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidApiToken extends /*@__PURE__*/ InvalidApiToken_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.TaggedErrorClass<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const PermissionGroupNotFound_base: S.TaggedErrorClass<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | undefined;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | undefined;
    /** Additional information about the permission group. */
    description?: string | undefined;
    /** Indicates whether the permission group can be edited. */
    editable?: string | undefined;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | undefined;
    /** A label identifying the permission group. */
    label?: string | undefined;
    /** The scope associated with the permission group. */
    scopes?: string | undefined;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | undefined;
}
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta | undefined;
    /** Name of the permission group. */
    name?: string | undefined;
}
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList | undefined;
}
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp | undefined;
}
export interface CreateTokenRequest {
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | undefined;
}
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null | undefined;
}
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export interface TokensCreateResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null | undefined;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null | undefined;
    /** Additional information about the permission group. */
    description?: string | null | undefined;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null | undefined;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null | undefined;
    /** A label identifying the permission group. */
    label?: string | null | undefined;
    /** The scope associated with the permission group. */
    scopes?: string | null | undefined;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null | undefined;
}
export interface TokensCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateResponsePoliciesItemPermissionGroupsItemMeta | null | undefined;
    /** Name of the permission group. */
    name?: string | null | undefined;
}
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensCreateResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
    /** The token value. */
    value?: string | null | undefined;
}
export interface DeleteOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteOrganizationResponse {
    /** Identifier */
    id?: string | null | undefined;
}
export interface DeleteSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null | undefined;
}
export interface DeleteTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export interface GetBillingProfileRequest {
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null | undefined;
    accountType?: string | null | undefined;
    address?: string | null | undefined;
    address2?: string | null | undefined;
    balance?: string | null | undefined;
    cardExpiryMonth?: number | null | undefined;
    cardExpiryYear?: number | null | undefined;
    cardNumber?: string | null | undefined;
    city?: string | null | undefined;
    company?: string | null | undefined;
    country?: string | null | undefined;
    createdOn?: string | null | undefined;
    deviceData?: string | null | undefined;
    editedOn?: string | null | undefined;
    enterpriseBillingEmail?: string | null | undefined;
    enterprisePrimaryEmail?: string | null | undefined;
    firstName?: string | null | undefined;
    isPartner?: boolean | null | undefined;
    lastName?: string | null | undefined;
    nextBillDate?: string | null | undefined;
    paymentAddress?: string | null | undefined;
    paymentAddress2?: string | null | undefined;
    paymentCity?: string | null | undefined;
    paymentCountry?: string | null | undefined;
    paymentEmail?: string | null | undefined;
    paymentFirstName?: string | null | undefined;
    paymentGateway?: string | null | undefined;
    paymentLastName?: string | null | undefined;
    paymentNonce?: string | null | undefined;
    paymentState?: string | null | undefined;
    paymentZipcode?: string | null | undefined;
    primaryEmail?: string | null | undefined;
    state?: string | null | undefined;
    taxIdType?: string | null | undefined;
    telephone?: string | null | undefined;
    validationCode?: string | null | undefined;
    vat?: string | null | undefined;
    zipcode?: string | null | undefined;
}
export interface GetInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
}
export type InvitesGetResponseRolesList = Array<string>;
export type InvitesGetResponseStatus = "pending" | "accepted" | "rejected" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null | undefined;
    /** When the invite is no longer active. */
    expiresOn?: string | null | undefined;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null | undefined;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null | undefined;
    /** When the invite was sent. */
    invitedOn?: string | null | undefined;
    organizationIsEnforcingTwofactor?: boolean | null | undefined;
    /** Organization name. */
    organizationName?: string | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: InvitesGetResponseRolesList | null | undefined;
    /** Current status of the invitation. */
    status?: InvitesGetResponseStatus | null | undefined;
}
export interface GetOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
export type GetOrganizationResponse = unknown;
export interface GetSpectrumAnalyticsZonesReportRequest {
    /** Include CDN traffic in the bandwidth aggregation. */
    cdnTraffic?: boolean | undefined;
    /** Start of time interval to query, defaults to `until` - 6 hours. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    since?: string | undefined;
    /** End of time interval to query, defaults to current time. Timestamp must be in RFC3339 format and uses UTC unless otherwise specified. */
    until?: string | undefined;
}
export interface GetSpectrumAnalyticsZonesReportResultItemTotalsBandwidth {
    /** Sum of ingress and egress bytes transferred. */
    all: number;
    /** Sum of egress bytes transferred. */
    egress: number;
    /** Sum of ingress bytes transferred. */
    ingress: number;
}
export interface GetSpectrumAnalyticsZonesReportResultItemTotals {
    bandwidth: GetSpectrumAnalyticsZonesReportResultItemTotalsBandwidth;
}
export interface GetSpectrumAnalyticsZonesReportResultItem {
    totals: GetSpectrumAnalyticsZonesReportResultItemTotals;
    /** Identifier. */
    zoneId: string;
}
export type GetSpectrumAnalyticsZonesReportResultList = Array<GetSpectrumAnalyticsZonesReportResultItem>;
export type GetSpectrumAnalyticsZonesReportResponse = GetSpectrumAnalyticsZonesReportResultList;
export interface GetSubscriptionRequest {
}
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null | undefined;
}
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null | undefined;
}
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface GetTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null | undefined;
}
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensGetResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export interface GetUserRequest {
}
export type GetResponseBetasList = Array<string>;
export type GetResponseOrganizationsItemPermissionsList = Array<unknown>;
export type GetResponseOrganizationsItemRolesList = Array<string>;
export type GetResponseOrganizationsItemStatus = "member" | "invited";
export interface GetResponseOrganizationsItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Organization name. */
    name?: string | null | undefined;
    /** Access permissions for this User. */
    permissions?: GetResponseOrganizationsItemPermissionsList | null | undefined;
    /** List of roles that a user has within an organization. */
    roles?: GetResponseOrganizationsItemRolesList | null | undefined;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: GetResponseOrganizationsItemStatus | null | undefined;
}
export type GetResponseOrganizationsList = Array<GetResponseOrganizationsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: GetResponseBetasList | null | undefined;
    /** The country in which the user lives. */
    country?: string | null | undefined;
    /** User's first name */
    firstName?: string | null | undefined;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null | undefined;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null | undefined;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null | undefined;
    /** User's last name */
    lastName?: string | null | undefined;
    organizations?: GetResponseOrganizationsList | null | undefined;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null | undefined;
    /** User's telephone number */
    telephone?: string | null | undefined;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null | undefined;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null | undefined;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null | undefined;
}
export interface AuditLogsListRequestAction {
    /** Filters by the action type. */
    type?: string | undefined;
}
export interface AuditLogsListRequestActor {
    /** Filters by the email address of the actor that made the change. */
    email?: string | undefined;
    /** Filters by the IP address of the request that made the change by specific IP address or valid CIDR Range. */
    ip?: string | undefined;
}
export type AuditLogsListRequestDirection = "desc" | "asc";
export interface AuditLogsListRequestZone {
    /** Filters by the name of the zone associated to the change. */
    name?: string | undefined;
}
export interface ListAuditLogsRequest {
    /** Finds a specific log by its ID. */
    id?: string | undefined;
    action?: AuditLogsListRequestAction | undefined;
    actor?: AuditLogsListRequestActor | undefined;
    /** Limits the returned results to logs older than the specified date. A `full-date` that conforms to RFC3339. */
    before?: string | undefined;
    /** Changes the direction of the chronological sorting. */
    direction?: AuditLogsListRequestDirection | (string & {}) | undefined;
    /** Indicates that this request is an export of logs in CSV format. */
    export?: boolean | undefined;
    /** Indicates whether or not to hide user level audit logs. */
    hideUserLogs?: boolean | undefined;
    /** Defines which page of results to return. */
    page?: number | undefined;
    /** Sets the number of results to return per page. */
    perPage?: number | undefined;
    /** Limits the returned results to logs newer than the specified date. A `full-date` that conforms to RFC3339. */
    since?: string | undefined;
    zone?: AuditLogsListRequestZone | undefined;
}
export interface AuditLogsListResultItemAction {
    /** A boolean that indicates if the action attempted was successful. */
    result?: boolean | null | undefined;
    /** A short string that describes the action that was performed. */
    type?: string | null | undefined;
}
export type AuditLogsListResultItemActorType = "user" | "admin" | "Cloudflare";
export interface AuditLogsListResultItemActor {
    /** The ID of the actor that performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The email of the user that performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ip?: string | null | undefined;
    /** The type of actor, whether a User, Cloudflare Admin, or an Automated System. */
    type?: AuditLogsListResultItemActorType | null | undefined;
}
export interface AuditLogsListResultItemOwner {
    /** Identifier */
    id?: string | null | undefined;
}
export interface AuditLogsListResultItemResource {
    /** An identifier for the resource that was affected by the action. */
    id?: string | null | undefined;
    /** A short string that describes the resource that was affected by the action. */
    type?: string | null | undefined;
}
export interface AuditLogsListResultItem {
    /** A string that uniquely identifies the audit log. */
    id?: string | null | undefined;
    action?: AuditLogsListResultItemAction | null | undefined;
    actor?: AuditLogsListResultItemActor | null | undefined;
    /** The source of the event. */
    interface?: string | null | undefined;
    /** An object which can lend more context to the action being logged. This is a flexible value and varies between different actions. */
    metadata?: unknown | null | undefined;
    /** The new value of the resource that was modified. */
    newValue?: string | null | undefined;
    /** The value of the resource before it was modified. */
    oldValue?: string | null | undefined;
    owner?: AuditLogsListResultItemOwner | null | undefined;
    resource?: AuditLogsListResultItemResource | null | undefined;
    /** A UTC RFC3339 timestamp that specifies when the action being logged occured. */
    when?: string | null | undefined;
}
export type AuditLogsListResultList = Array<AuditLogsListResultItem>;
export interface ListAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AuditLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type BillingHistoryListRequestOrder = "type" | "occurred_at" | "action";
export interface ListBillingHistoriesRequest {
    /** The billing item action. */
    action?: string | undefined;
    /** When the billing item was created. */
    occurredAt?: string | undefined;
    /** Field to order billing history by. */
    order?: BillingHistoryListRequestOrder | (string & {}) | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of items per page. */
    perPage?: number | undefined;
    /** The billing item type. */
    type?: string | undefined;
}
export interface BillingHistoryListResultItemZone {
    name?: string | null | undefined;
}
export interface BillingHistoryListResultItem {
    /** Billing item identifier tag. */
    id: string;
    /** The billing item action. */
    action: string;
    /** The amount associated with this billing item. */
    amount: number;
    /** The monetary unit in which pricing information is displayed. */
    currency: string;
    /** The billing item description. */
    description: string;
    /** When the billing item was created. */
    occurredAt: string;
    /** The billing item type. */
    type: string;
    zone: BillingHistoryListResultItemZone;
}
export type BillingHistoryListResultList = Array<BillingHistoryListResultItem>;
export interface ListBillingHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BillingHistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListInvitesRequest {
}
export type InvitesListResultItemRolesList = Array<string>;
export type InvitesListResultItemStatus = "pending" | "accepted" | "rejected" | "expired";
export interface InvitesListResultItem {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null | undefined;
    /** When the invite is no longer active. */
    expiresOn?: string | null | undefined;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null | undefined;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null | undefined;
    /** When the invite was sent. */
    invitedOn?: string | null | undefined;
    organizationIsEnforcingTwofactor?: boolean | null | undefined;
    /** Organization name. */
    organizationName?: string | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: InvitesListResultItemRolesList | null | undefined;
    /** Current status of the invitation. */
    status?: InvitesListResultItemStatus | null | undefined;
}
export type InvitesListResultList = Array<InvitesListResultItem>;
export interface ListInvitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type OrganizationsListRequestDirection = "asc" | "desc";
export type OrganizationsListRequestMatch = "any" | "all";
export type OrganizationsListRequestOrder = "id" | "name" | "status";
export type OrganizationsListRequestStatus = "member" | "invited";
export interface ListOrganizationsRequest {
    /** Direction to order organizations. */
    direction?: OrganizationsListRequestDirection | (string & {}) | undefined;
    /** Whether to match all search requirements or at least one (any). */
    match?: OrganizationsListRequestMatch | (string & {}) | undefined;
    /** Organization name. */
    name?: string | undefined;
    /** Field to order organizations by. */
    order?: OrganizationsListRequestOrder | (string & {}) | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of organizations per page. */
    perPage?: number | undefined;
    /** Whether the user is a member of the organization or has an inivitation pending. */
    status?: OrganizationsListRequestStatus | (string & {}) | undefined;
}
export type OrganizationsListResultItemPermissionsList = Array<unknown>;
export type OrganizationsListResultItemRolesList = Array<string>;
export type OrganizationsListResultItemStatus = "member" | "invited";
export interface OrganizationsListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Organization name. */
    name?: string | null | undefined;
    /** Access permissions for this User. */
    permissions?: OrganizationsListResultItemPermissionsList | null | undefined;
    /** List of roles that a user has within an organization. */
    roles?: OrganizationsListResultItemRolesList | null | undefined;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: OrganizationsListResultItemStatus | null | undefined;
}
export type OrganizationsListResultList = Array<OrganizationsListResultItem>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OrganizationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListTenantsRequest {
}
export interface TenantsListResultItemTenantContacts {
    email?: string | null | undefined;
    website?: string | null | undefined;
}
export type TenantsListResultItemTenantLabelsList = Array<string>;
export interface TenantsListResultItemTenantMetadataDnsNsPool {
    primary: string;
    secondary: string;
}
export interface TenantsListResultItemTenantMetadataDns {
    nsPool: TenantsListResultItemTenantMetadataDnsNsPool;
}
export type TenantsListResultItemTenantMetadataFlagsMap = {
    [key: string]: string | undefined;
};
export type TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValueCase4List = Array<unknown>;
export type TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValue = string | number | boolean | TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValueCase3Map | TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValueCase4List;
export interface TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocation {
    type: string;
    value: TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocationValue;
}
export interface TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemFeature {
    key: string;
}
export interface TenantsListResultItemTenantMetadataInnateAccountEntitlementsItem {
    allocation: TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemAllocation;
    feature: TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemFeature;
}
export type TenantsListResultItemTenantMetadataInnateAccountEntitlementsList = Array<TenantsListResultItemTenantMetadataInnateAccountEntitlementsItem>;
export type TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValueCase3Map = {
    [key: string]: unknown | undefined;
};
export type TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValueCase4List = Array<unknown>;
export type TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValue = string | number | boolean | TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValueCase3Map | TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValueCase4List;
export interface TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocation {
    type: string;
    value: TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocationValue;
}
export type TenantsListResultItemTenantMetadataTenantEntitlementsItemFeature = TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemFeature;
export interface TenantsListResultItemTenantMetadataTenantEntitlementsItem {
    allocation: TenantsListResultItemTenantMetadataTenantEntitlementsItemAllocation;
    feature: TenantsListResultItemTenantMetadataInnateAccountEntitlementsItemFeature;
}
export type TenantsListResultItemTenantMetadataTenantEntitlementsList = Array<TenantsListResultItemTenantMetadataTenantEntitlementsItem>;
export interface TenantsListResultItemTenantMetadata {
    billingAccountType?: string | null | undefined;
    configurationAccount?: string | null | undefined;
    createdBy?: string | null | undefined;
    dns?: TenantsListResultItemTenantMetadataDns | null | undefined;
    flags?: TenantsListResultItemTenantMetadataFlagsMap | null | undefined;
    innateAccountEntitlements?: TenantsListResultItemTenantMetadataInnateAccountEntitlementsList | null | undefined;
    tenantEntitlements?: TenantsListResultItemTenantMetadataTenantEntitlementsList | null | undefined;
}
export type TenantsListResultItemTenantNetworkChoicesMap = {
    [key: string]: unknown | undefined;
};
export interface TenantsListResultItemTenantNetwork {
    choices?: TenantsListResultItemTenantNetworkChoicesMap | null | undefined;
}
export interface TenantsListResultItemTenantUnitsItemUnitMembershipsItem {
    memberMetadata: unknown;
    memberStatus: string;
    memberTag: string;
}
export type TenantsListResultItemTenantUnitsItemUnitMembershipsList = Array<TenantsListResultItemTenantUnitsItemUnitMembershipsItem>;
export interface TenantsListResultItemTenantUnitsItem {
    unitMemberships: TenantsListResultItemTenantUnitsItemUnitMembershipsList;
    unitMetadata: unknown;
    unitName: string;
    unitStatus: string;
    unitTag: string;
}
export type TenantsListResultItemTenantUnitsList = Array<TenantsListResultItemTenantUnitsItem>;
export interface TenantsListResultItemUiFlags {
    /** Render the Organizations experience for this tenant. */
    showOrgsUi: boolean;
    /** Render the legacy Tenants experience for this tenant. */
    showTenantsUi: boolean;
}
export interface TenantsListResultItem {
    cdate: string;
    customerId: string;
    edate: string;
    tenantContacts: TenantsListResultItemTenantContacts;
    tenantLabels: TenantsListResultItemTenantLabelsList;
    tenantMetadata: TenantsListResultItemTenantMetadata;
    tenantName: string;
    tenantNetwork: TenantsListResultItemTenantNetwork;
    tenantStatus: string;
    tenantTag: string;
    tenantType: string;
    tenantUnits: TenantsListResultItemTenantUnitsList;
    /** Which top-level dashboard experiences to render for this tenant; both may be true. */
    uiFlags: TenantsListResultItemUiFlags;
}
export type TenantsListResultList = Array<TenantsListResultItem>;
export interface ListTenantsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TenantsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListTokenPermissionGroupsRequest {
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string | undefined;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string | undefined;
}
export type TokensPermissionGroupsListResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type TokensPermissionGroupsListResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type TokensPermissionGroupsListResultItemScopesList = Array<TokensPermissionGroupsListResultItemScopesItem>;
export interface TokensPermissionGroupsListResultItem {
    /** Public ID. */
    id?: string | null | undefined;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsListResultItemCategory | null | undefined;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null | undefined;
    /** Permission Group Name */
    name?: string | null | undefined;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsListResultItemScopesList | null | undefined;
}
export type TokensPermissionGroupsListResultList = Array<TokensPermissionGroupsListResultItem>;
export interface ListTokenPermissionGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensPermissionGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type TokensListRequestDirection = "asc" | "desc";
export interface ListTokensRequest {
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {}) | undefined;
    /** When true, includes recently-expired tokens in the response. */
    includeExpired?: boolean | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. */
    perPage?: number | undefined;
}
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null | undefined;
}
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null | undefined;
}
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensListResultItemCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type InvitesEditRequestStatus = "accepted" | "rejected";
export interface PatchInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
    /** Status of your response to the invitation (rejected or accepted). */
    status: InvitesEditRequestStatus | (string & {});
}
export type InvitesEditResponseRolesList = Array<string>;
export type InvitesEditResponseStatus = "pending" | "accepted" | "rejected" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null | undefined;
    /** When the invite is no longer active. */
    expiresOn?: string | null | undefined;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null | undefined;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null | undefined;
    /** When the invite was sent. */
    invitedOn?: string | null | undefined;
    organizationIsEnforcingTwofactor?: boolean | null | undefined;
    /** Organization name. */
    organizationName?: string | null | undefined;
    /** List of role names the membership has for this account. */
    roles?: InvitesEditResponseRolesList | null | undefined;
    /** Current status of the invitation. */
    status?: InvitesEditResponseStatus | null | undefined;
}
export interface PatchUserRequest {
    /** The country in which the user lives. */
    country?: string | undefined;
    /** User's first name */
    firstName?: string | undefined;
    /** User's last name */
    lastName?: string | undefined;
    /** User's telephone number */
    telephone?: string | undefined;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | undefined;
}
export type EditResponseBetasList = Array<string>;
export type EditResponseOrganizationsItemPermissionsList = Array<unknown>;
export type EditResponseOrganizationsItemRolesList = Array<string>;
export type EditResponseOrganizationsItemStatus = "member" | "invited";
export interface EditResponseOrganizationsItem {
    /** Identifier */
    id?: string | null | undefined;
    /** Organization name. */
    name?: string | null | undefined;
    /** Access permissions for this User. */
    permissions?: EditResponseOrganizationsItemPermissionsList | null | undefined;
    /** List of roles that a user has within an organization. */
    roles?: EditResponseOrganizationsItemRolesList | null | undefined;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: EditResponseOrganizationsItemStatus | null | undefined;
}
export type EditResponseOrganizationsList = Array<EditResponseOrganizationsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: EditResponseBetasList | null | undefined;
    /** The country in which the user lives. */
    country?: string | null | undefined;
    /** User's first name */
    firstName?: string | null | undefined;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null | undefined;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null | undefined;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null | undefined;
    /** User's last name */
    lastName?: string | null | undefined;
    organizations?: EditResponseOrganizationsList | null | undefined;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null | undefined;
    /** User's telephone number */
    telephone?: string | null | undefined;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null | undefined;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null | undefined;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null | undefined;
}
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {}) | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | undefined;
    /** The full name of the rate plan. */
    publicName?: string | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList | undefined;
}
export interface PutSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {}) | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan | undefined;
}
export type PutSubscriptionResponse = unknown;
export interface PutTokenValueRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export type PutTokenValueResponse = unknown;
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList | undefined;
}
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp | undefined;
}
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export interface UpdateTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | undefined;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {}) | undefined;
}
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null | undefined;
}
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensUpdateResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export interface VerifyTokenRequest {
}
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
}
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new access token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteOrganizationError = CloudflareOpError;
/** Removes association to an organization. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type DeleteSubscriptionError = CloudflareOpError;
/** Deletes a user's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | CloudflareOpError;
/** Destroy a token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type GetBillingProfileError = CloudflareOpError;
/** Accesses your billing profile object. */
export declare const getBillingProfile: API.OperationMethod<GetBillingProfileRequest, GetBillingProfileResponse, GetBillingProfileError, CloudflareOpContext>;
export type GetInviteError = CloudflareOpError;
/** Gets the details of an invitation. */
export declare const getInvite: API.OperationMethod<GetInviteRequest, GetInviteResponse, GetInviteError, CloudflareOpContext>;
export type GetOrganizationError = CloudflareOpError;
/** Gets a specific organization the user is associated with. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetSpectrumAnalyticsZonesReportError = CloudflareOpError;
/** Retrieves a list of total bandwidth by zone over a given time period. */
export declare const getSpectrumAnalyticsZonesReport: API.OperationMethod<GetSpectrumAnalyticsZonesReportRequest, GetSpectrumAnalyticsZonesReportResponse, GetSpectrumAnalyticsZonesReportError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of a user's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetUserError = CloudflareOpError;
/** Retrieves detailed information about the currently authenticated user, including email, name, and account memberships. */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, CloudflareOpContext>;
export type ListAuditLogsError = CloudflareOpError;
/** Gets a list of audit logs for a user account. Can be filtered by who made the change, on which zone, and the timeframe of the change. */
export declare const listAuditLogs: API.PaginatedOperationMethod<ListAuditLogsRequest, ListAuditLogsResponse, ListAuditLogsError, CloudflareOpContext, AuditLogsListResultItem>;
export type ListBillingHistoriesError = CloudflareOpError;
/** Accesses your billing history object. */
export declare const listBillingHistories: API.PaginatedOperationMethod<ListBillingHistoriesRequest, ListBillingHistoriesResponse, ListBillingHistoriesError, CloudflareOpContext, BillingHistoryListResultItem>;
export type ListInvitesError = CloudflareOpError;
/** Lists all invitations associated with my user. */
export declare const listInvites: API.PaginatedOperationMethod<ListInvitesRequest, ListInvitesResponse, ListInvitesError, CloudflareOpContext, InvitesListResultItem>;
export type ListOrganizationsError = CloudflareOpError;
/** Lists organizations the user is associated with. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, OrganizationsListResultItem>;
export type ListTenantsError = CloudflareOpError;
/** Lists the Cloudflare tenants in which the authenticated user has direct membership using the legacy Tenant response shape. Use `GET /organizations` to list Organizations the user can access, including through hierarchy, using the modern Organization response shape. */
export declare const listTenants: API.PaginatedOperationMethod<ListTenantsRequest, ListTenantsResponse, ListTenantsError, CloudflareOpContext, TenantsListResultItem>;
export type ListTokenPermissionGroupsError = CloudflareOpError;
/** Find all available permission groups for API Tokens. */
export declare const listTokenPermissionGroups: API.PaginatedOperationMethod<ListTokenPermissionGroupsRequest, ListTokenPermissionGroupsResponse, ListTokenPermissionGroupsError, CloudflareOpContext, TokensPermissionGroupsListResultItem>;
export type ListTokensError = CloudflareOpError;
/** List all access tokens you created. Results include active, disabled, and recently-expired tokens when include_expired is set to true. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type PatchInviteError = CloudflareOpError;
/** Responds to an invitation. */
export declare const patchInvite: API.OperationMethod<PatchInviteRequest, PatchInviteResponse, PatchInviteError, CloudflareOpContext>;
export type PatchUserError = CloudflareOpError;
/** Edit part of your user details. */
export declare const patchUser: API.OperationMethod<PatchUserRequest, PatchUserResponse, PatchUserError, CloudflareOpContext>;
export type PutSubscriptionError = CloudflareOpError;
/** Updates a user's subscriptions. */
export declare const putSubscription: API.OperationMethod<PutSubscriptionRequest, PutSubscriptionResponse, PutSubscriptionError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = Forbidden | InvalidApiToken | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
//# sourceMappingURL=user.d.ts.map