import * as Effect from "effect/Effect";
import * as HttpApi from "effect/http-api/HttpApi";
import * as HttpApiEndpoint from "effect/http-api/HttpApiEndpoint";
import * as HttpApiGroup from "effect/http-api/HttpApiGroup";
import * as Layer from "effect/Layer";
import type * as Rpc from "effect/rpc/Rpc";
import type * as RpcGroup from "effect/rpc/RpcGroup";
import type * as RpcMiddleware from "effect/rpc/RpcMiddleware";
import * as Scope from "effect/Scope";
import type { Annotations } from "./Annotations.ts";
import type { Servable } from "./Api.ts";
import { type CallName, type ClientOf } from "./ReadRpcs.ts";
/**
 * What {@link toHttpApi} reads from an Api class: what it serves, its RPCs,
 * and its in-process client (`clientInProcess`), which runs every call
 * through the Api's own handlers and middleware.
 */
export interface Publishable {
    readonly apiName: string;
    readonly annotations: Annotations;
    readonly serves: ReadonlyArray<Servable>;
    readonly group: RpcGroup.RpcGroup<Rpc.Any>;
    readonly clientInProcess: Effect.Effect<unknown, never, any>;
}
/**
 * What serving the HTTP API needs: the hosted model and the Layers of the
 * middleware what the Api serves declares, as for the Api itself. Not the
 * client half of any middleware: the HTTP caller sends its own headers.
 */
export type Requirements<A extends Publishable> = Exclude<Effect.Services<A["clientInProcess"]>, Scope.Scope | RpcMiddleware.ForClient<any>>;
/**
 * A call {@link toHttpApi} can publish: a command's tag (`DepositMoney`), or a
 * read as `<Name>.<operation>` (`AccountSummary.get`, `AccountSummary.watch`).
 */
export type Exposable<A extends Publishable> = CallName<ClientOf<A>>;
/** What {@link toHttpApi} publishes. */
export interface HttpApiOptions<A extends Publishable> {
    /**
     * The calls to publish, by name. Nothing is published unless it is listed,
     * so a call the Api later adds, or a field a reply later gains, is never
     * public by accident: list each call on purpose.
     * @default []
     */
    readonly expose?: ReadonlyArray<Exposable<A>>;
}
/** The group, an HttpApi holding only it, and the Layers that serve it. */
export interface HttpApiSurface<Name extends string, R> {
    /** One endpoint per published call. Add it to your own `HttpApi` to serve it with other groups. */
    readonly group: HttpApiGroup.HttpApiGroup<Name, HttpApiEndpoint.Top>;
    /** An `HttpApi` with only {@link group}, for `HttpApiBuilder.layer` and `OpenApi.fromApi`. */
    readonly api: HttpApi.HttpApi<Name, HttpApiGroup.HttpApiGroup<Name, HttpApiEndpoint.Top>>;
    /** The handlers of {@link group} in {@link api}. */
    readonly layer: Layer.Layer<HttpApiGroup.Service<Name, Name>, never, R>;
    /**
     * The handlers of {@link group} in your own `HttpApi`, which may add a
     * prefix, middleware or other groups.
     */
    readonly layerFor: <ApiId extends string, Groups extends HttpApiGroup.Constraint>(api: HttpApi.HttpApi<ApiId, Groups>) => Layer.Layer<HttpApiGroup.Service<ApiId, Name>, never, R>;
}
/**
 * Publish an Api's calls as a plain HTTP JSON API, with an OpenAPI document,
 * from the same Api. Each published call is one endpoint:
 *
 * | Call          | Method and path              | Input                                          |
 * | ------------- | ---------------------------- | ---------------------------------------------- |
 * | a command     | `POST /<Command>`            | JSON body: `commandId`, input, `consistency`   |
 * | a query       | `QUERY /<Query>`             | JSON body: `input`, `atLeast`, `after`, `take` |
 * | `get`, `peek` | `GET /<Name>/{key}`          | `?stream=&version=` waits for a write          |
 * | `snapshot`    | `GET /<Name>/{key}/snapshot` | `?stream=&version=` waits for a write          |
 * | `list`        | `GET /<Name>/{key}/list`     | `?order=&take=&after=`                         |
 * | `watch`       | `GET /<Name>/{key}/watch`    | Server-Sent Events                             |
 * | `events`      | `GET /<Name>/{key}/events`   | Server-Sent Events, `?after=` a cursor         |
 *
 * A command answers with its receipt; a query with its result (a paged one
 * with `{ entries, cursor }`); a read with what the Api's own client gets
 * (`null` for an empty key). A typed failure answers with its `_tag`
 * and data, at the status its schema's `httpApiStatus` annotation gives it
 * (`Domain.Rejection("NotOwner", {}, { httpApiStatus: 403 })`), and 422 if it
 * has none: a rejection is a refused request, not a server fault. Input its
 * schema refuses is a 400.
 *
 * A live read (`watch`, `events`) answers with a Server-Sent Events stream:
 * each value is one event's JSON `data`. A failure before the first value,
 * such as its middleware refusing the caller, answers with its status like
 * any other call. A failure after it, such as `validate` refusing a change,
 * ends the stream with an `effect/http-api/stream/failure` event whose
 * `data` is the typed failure.
 *
 * Every response carries `cache-control: private, no-store`: it is for one
 * caller, and stale after the next write. A query's or a read's declaration
 * can loosen that for its successful answers with the `httpApiCacheControl`
 * annotation (`{ httpApiCacheControl: "public, max-age=60" }`).
 *
 * Every call goes through the Api's own handlers in process, with the HTTP
 * request's headers, so its middleware, its checks and its rejections run as
 * for any client, and its input is decoded once. A read's `where` filter is
 * not published.
 *
 * Nothing is published by default: `expose` lists each call to publish, so
 * what an Api serves its own clients never reaches HTTP by accident. It is
 * convenient for internal tools. A public or partner API is better written
 * as its own `HttpApi`, with response schemas of its own, that calls the
 * Api in process.
 *
 * **Example:** Serve an Api, with its OpenAPI document
 * ```typescript
 * import * as DomainHttp from "@alchemy.run/domain/Http";
 * import * as HttpApiBuilder from "effect/http-api/HttpApiBuilder";
 * import * as OpenApi from "effect/http-api/OpenApi";
 *
 * const BankHttp = DomainHttp.toHttpApi(CustomerApi, {
 *   expose: ["DepositMoney", "AccountSummary.get", "AccountSummary.watch"],
 * });
 * const BankHttpLive = HttpApiBuilder.layer(BankHttp.api, { openapiPath: "/openapi.json" }).pipe(
 *   Layer.provide(BankHttp.layer),
 *   Layer.provide(BankLive),
 * );
 * const spec = OpenApi.fromApi(BankHttp.api);
 * ```
 *
 * **Example:** Watch a view from a browser
 * ```typescript
 * // in the browser: one event per change, each `{ state, cursor }`
 * const source = new EventSource(`/AccountSummary/${accountId}/watch`);
 * source.onmessage = (event) => render(JSON.parse(event.data).state);
 * ```
 */
export declare const toHttpApi: <A extends Publishable>(api: A, options?: HttpApiOptions<A>) => HttpApiSurface<A["apiName"], Requirements<A>>;
//# sourceMappingURL=Http.d.ts.map