import { Endpoint } from "@distilled.cloud/s3/Endpoint";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
export * from "@distilled.cloud/s3/Endpoint";
/**
 * `AWS_ENDPOINT_URL` -- the LocalStack-standard endpoint override that local
 * emulators (floci, LocalStack) inject into runtime environments (e.g.
 * Lambda containers). Resolves `undefined` when unset, so the SDK's
 * default endpoint resolver runs.
 */
export declare const fromEnvironment: Effect.Effect<string | undefined, import("effect/ConfigProvider").SourceError, never>;
/** Override the endpoint with whatever the environment names, if anything. */
export declare const fromEnv: () => Layer.Layer<Endpoint, never, never>;
/** Override the endpoint for a scope, e.g. `Endpoint.of("http://localhost:4566")`. */
export declare const of: (endpoint: string) => Layer.Layer<Endpoint, never, never>;
//# sourceMappingURL=endpoint.d.ts.map