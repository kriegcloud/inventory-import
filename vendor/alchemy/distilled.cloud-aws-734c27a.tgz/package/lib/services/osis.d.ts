import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DisabledOperationException_base: S.TaggedErrorClass<"DisabledOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PipelineName = string;
export type PipelineUnits = number;
export type PipelineConfigurationBody = string;
export type LogGroup = string;
export interface CloudWatchLogDestination {
    LogGroup: string;
}
export interface LogPublishingOptions {
    IsLoggingEnabled?: boolean | undefined;
    CloudWatchLogDestination?: CloudWatchLogDestination | undefined;
}
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type CidrBlock = string;
export interface VpcAttachmentOptions {
    AttachToVpc: boolean;
    CidrBlock?: string | undefined;
}
export type VpcEndpointManagement = "CUSTOMER" | "SERVICE" | (string & {});
export interface VpcOptions {
    SubnetIds: string[];
    SecurityGroupIds?: string[] | undefined;
    VpcAttachmentOptions?: VpcAttachmentOptions | undefined;
    VpcEndpointManagement?: VpcEndpointManagement | undefined;
}
export interface BufferOptions {
    PersistentBufferEnabled: boolean;
}
export type KmsKeyArn = string;
export interface EncryptionAtRestOptions {
    KmsKeyArn: string;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type PipelineRoleArn = string;
export interface CreatePipelineRequest {
    PipelineName: string;
    MinUnits: number;
    MaxUnits: number;
    PipelineConfigurationBody: string;
    LogPublishingOptions?: LogPublishingOptions | undefined;
    VpcOptions?: VpcOptions | undefined;
    BufferOptions?: BufferOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    Tags?: Tag[] | undefined;
    PipelineRoleArn?: string | undefined;
}
export type PipelineStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "STARTING" | "START_FAILED" | "STOPPING" | "STOPPED" | (string & {});
export interface PipelineStatusReason {
    Description?: string | undefined;
}
export type IngestEndpointUrlsList = string[];
export interface VpcEndpoint {
    VpcEndpointId?: string | undefined;
    VpcId?: string | undefined;
    VpcOptions?: VpcOptions | undefined;
}
export type VpcEndpointsList = VpcEndpoint[];
export type VpcEndpointServiceName = "OPENSEARCH_SERVERLESS" | (string & {});
export interface ServiceVpcEndpoint {
    ServiceName?: VpcEndpointServiceName | undefined;
    VpcEndpointId?: string | undefined;
}
export type ServiceVpcEndpointsList = ServiceVpcEndpoint[];
export interface PipelineDestination {
    ServiceName?: string | undefined;
    Endpoint?: string | undefined;
}
export type PipelineDestinationList = PipelineDestination[];
export interface Pipeline {
    PipelineName?: string | undefined;
    PipelineArn?: string | undefined;
    MinUnits?: number | undefined;
    MaxUnits?: number | undefined;
    Status?: PipelineStatus | undefined;
    StatusReason?: PipelineStatusReason | undefined;
    PipelineConfigurationBody?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    IngestEndpointUrls?: string[] | undefined;
    LogPublishingOptions?: LogPublishingOptions | undefined;
    VpcEndpoints?: VpcEndpoint[] | undefined;
    BufferOptions?: BufferOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    VpcEndpointService?: string | undefined;
    ServiceVpcEndpoints?: ServiceVpcEndpoint[] | undefined;
    Destinations?: PipelineDestination[] | undefined;
    Tags?: Tag[] | undefined;
    PipelineRoleArn?: string | undefined;
}
export interface CreatePipelineResponse {
    Pipeline?: Pipeline | undefined;
}
export type PipelineArn = string;
export interface PipelineEndpointVpcOptions {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export interface CreatePipelineEndpointRequest {
    PipelineArn: string;
    VpcOptions: PipelineEndpointVpcOptions;
}
export type PipelineEndpointId = string;
export type PipelineEndpointStatus = "CREATING" | "ACTIVE" | "CREATE_FAILED" | "DELETING" | "REVOKING" | "REVOKED" | (string & {});
export interface CreatePipelineEndpointResponse {
    PipelineArn?: string | undefined;
    EndpointId?: string | undefined;
    Status?: PipelineEndpointStatus | undefined;
    VpcId?: string | undefined;
}
export interface DeletePipelineRequest {
    PipelineName: string;
}
export interface DeletePipelineResponse {
}
export interface DeletePipelineEndpointRequest {
    EndpointId: string;
}
export interface DeletePipelineEndpointResponse {
}
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface GetPipelineRequest {
    PipelineName: string;
}
export interface GetPipelineResponse {
    Pipeline?: Pipeline | undefined;
}
export type BlueprintFormat = string;
export interface GetPipelineBlueprintRequest {
    BlueprintName: string;
    Format?: string | undefined;
}
export interface PipelineBlueprint {
    BlueprintName?: string | undefined;
    PipelineConfigurationBody?: string | undefined;
    DisplayName?: string | undefined;
    DisplayDescription?: string | undefined;
    Service?: string | undefined;
    UseCase?: string | undefined;
}
export interface GetPipelineBlueprintResponse {
    Blueprint?: PipelineBlueprint | undefined;
    Format?: string | undefined;
}
export interface GetPipelineChangeProgressRequest {
    PipelineName: string;
}
export type ChangeProgressStatuses = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type ChangeProgressStageStatuses = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface ChangeProgressStage {
    Name?: string | undefined;
    Status?: ChangeProgressStageStatuses | undefined;
    Description?: string | undefined;
    LastUpdatedAt?: Date | undefined;
}
export type ChangeProgressStageList = ChangeProgressStage[];
export interface ChangeProgressStatus {
    StartTime?: Date | undefined;
    Status?: ChangeProgressStatuses | undefined;
    TotalNumberOfStages?: number | undefined;
    ChangeProgressStages?: ChangeProgressStage[] | undefined;
}
export type ChangeProgressStatusList = ChangeProgressStatus[];
export interface GetPipelineChangeProgressResponse {
    ChangeProgressStatuses?: ChangeProgressStatus[] | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    ResourceArn?: string | undefined;
    Policy?: string | undefined;
}
export interface ListPipelineBlueprintsRequest {
}
export interface PipelineBlueprintSummary {
    BlueprintName?: string | undefined;
    DisplayName?: string | undefined;
    DisplayDescription?: string | undefined;
    Service?: string | undefined;
    UseCase?: string | undefined;
}
export type PipelineBlueprintsSummaryList = PipelineBlueprintSummary[];
export interface ListPipelineBlueprintsResponse {
    Blueprints?: PipelineBlueprintSummary[] | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListPipelineEndpointConnectionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AwsAccountId = string;
export interface PipelineEndpointConnection {
    PipelineArn?: string | undefined;
    EndpointId?: string | undefined;
    Status?: PipelineEndpointStatus | undefined;
    VpcEndpointOwner?: string | undefined;
}
export type PipelineEndpointConnectionsSummaryList = PipelineEndpointConnection[];
export interface ListPipelineEndpointConnectionsResponse {
    NextToken?: string | undefined;
    PipelineEndpointConnections?: PipelineEndpointConnection[] | undefined;
}
export interface ListPipelineEndpointsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PipelineEndpoint {
    PipelineArn?: string | undefined;
    EndpointId?: string | undefined;
    Status?: PipelineEndpointStatus | undefined;
    VpcId?: string | undefined;
    VpcOptions?: PipelineEndpointVpcOptions | undefined;
    IngestEndpointUrl?: string | undefined;
}
export type PipelineEndpointsSummaryList = PipelineEndpoint[];
export interface ListPipelineEndpointsResponse {
    NextToken?: string | undefined;
    PipelineEndpoints?: PipelineEndpoint[] | undefined;
}
export interface ListPipelinesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PipelineSummary {
    Status?: PipelineStatus | undefined;
    StatusReason?: PipelineStatusReason | undefined;
    PipelineName?: string | undefined;
    PipelineArn?: string | undefined;
    MinUnits?: number | undefined;
    MaxUnits?: number | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Destinations?: PipelineDestination[] | undefined;
    Tags?: Tag[] | undefined;
}
export type PipelineSummaryList = PipelineSummary[];
export interface ListPipelinesResponse {
    NextToken?: string | undefined;
    Pipelines?: PipelineSummary[] | undefined;
}
export interface ListTagsForResourceRequest {
    Arn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export interface PutResourcePolicyResponse {
    ResourceArn?: string | undefined;
    Policy?: string | undefined;
}
export type PipelineEndpointIdsList = string[];
export interface RevokePipelineEndpointConnectionsRequest {
    PipelineArn: string;
    EndpointIds: string[];
}
export interface RevokePipelineEndpointConnectionsResponse {
    PipelineArn?: string | undefined;
}
export interface StartPipelineRequest {
    PipelineName: string;
}
export interface StartPipelineResponse {
    Pipeline?: Pipeline | undefined;
}
export interface StopPipelineRequest {
    PipelineName: string;
}
export interface StopPipelineResponse {
    Pipeline?: Pipeline | undefined;
}
export interface TagResourceRequest {
    Arn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type StringList = string[];
export interface UntagResourceRequest {
    Arn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdatePipelineRequest {
    PipelineName: string;
    MinUnits?: number | undefined;
    MaxUnits?: number | undefined;
    PipelineConfigurationBody?: string | undefined;
    LogPublishingOptions?: LogPublishingOptions | undefined;
    BufferOptions?: BufferOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    PipelineRoleArn?: string | undefined;
}
export interface UpdatePipelineResponse {
    Pipeline?: Pipeline | undefined;
}
export interface ValidatePipelineRequest {
    PipelineConfigurationBody: string;
}
export interface ValidationMessage {
    Message?: string | undefined;
}
export type ValidationMessageList = ValidationMessage[];
export interface ValidatePipelineResponse {
    isValid?: boolean | undefined;
    Errors?: ValidationMessage[] | undefined;
}
export type ErrorMessage = string;
export type CreatePipelineError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch Ingestion pipeline. For more information, see Creating Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const createPipeline: API.OperationMethod<CreatePipelineRequest & RegionInput, CreatePipelineResponse, CreatePipelineError, Credentials | HttpClient.HttpClient>;
export type CreatePipelineEndpointError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a VPC endpoint for an OpenSearch Ingestion pipeline. Pipeline endpoints allow you to
 * ingest data from your VPC into pipelines that you have access to.
 */
export declare const createPipelineEndpoint: API.OperationMethod<CreatePipelineEndpointRequest & RegionInput, CreatePipelineEndpointResponse, CreatePipelineEndpointError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Ingestion pipeline. For more information, see Deleting Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const deletePipeline: API.OperationMethod<DeletePipelineRequest & RegionInput, DeletePipelineResponse, DeletePipelineError, Credentials | HttpClient.HttpClient>;
export type DeletePipelineEndpointError = AccessDeniedException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Deletes a VPC endpoint for an OpenSearch Ingestion pipeline.
 */
export declare const deletePipelineEndpoint: API.OperationMethod<DeletePipelineEndpointRequest & RegionInput, DeletePipelineEndpointResponse, DeletePipelineEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a resource-based policy from an OpenSearch Ingestion resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetPipelineError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about an OpenSearch Ingestion pipeline.
 */
export declare const getPipeline: API.OperationMethod<GetPipelineRequest & RegionInput, GetPipelineResponse, GetPipelineError, Credentials | HttpClient.HttpClient>;
export type GetPipelineBlueprintError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific blueprint for OpenSearch Ingestion. Blueprints are
 * templates for the configuration needed for a `CreatePipeline` request. For more
 * information, see Using
 * blueprints to create a pipeline.
 */
export declare const getPipelineBlueprint: API.OperationMethod<GetPipelineBlueprintRequest & RegionInput, GetPipelineBlueprintResponse, GetPipelineBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetPipelineChangeProgressError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns progress information for the current change happening on an OpenSearch Ingestion
 * pipeline. Currently, this operation only returns information when a pipeline is being
 * created.
 *
 * For more information, see Tracking the status of pipeline creation.
 */
export declare const getPipelineChangeProgress: API.OperationMethod<GetPipelineChangeProgressRequest & RegionInput, GetPipelineChangeProgressResponse, GetPipelineChangeProgressError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to an OpenSearch Ingestion resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListPipelineBlueprintsError = AccessDeniedException | DisabledOperationException | InternalException | InvalidPaginationTokenException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all available blueprints for Data Prepper. For more information, see
 * Using
 * blueprints to create a pipeline.
 */
export declare const listPipelineBlueprints: API.OperationMethod<ListPipelineBlueprintsRequest & RegionInput, ListPipelineBlueprintsResponse, ListPipelineBlueprintsError, Credentials | HttpClient.HttpClient>;
export type ListPipelineEndpointConnectionsError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Lists the pipeline endpoints connected to pipelines in your account.
 */
export declare const listPipelineEndpointConnections: API.PaginatedOperationMethod<ListPipelineEndpointConnectionsRequest & RegionInput, ListPipelineEndpointConnectionsResponse, ListPipelineEndpointConnectionsError, Credentials | HttpClient.HttpClient, PipelineEndpointConnection>;
export type ListPipelineEndpointsError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Lists all pipeline endpoints in your account.
 */
export declare const listPipelineEndpoints: API.PaginatedOperationMethod<ListPipelineEndpointsRequest & RegionInput, ListPipelineEndpointsResponse, ListPipelineEndpointsError, Credentials | HttpClient.HttpClient, PipelineEndpoint>;
export type ListPipelinesError = AccessDeniedException | DisabledOperationException | InternalException | InvalidPaginationTokenException | ValidationException | CommonErrors;
/**
 * Lists all OpenSearch Ingestion pipelines in the current Amazon Web Services account and Region.
 * For more information, see Viewing Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const listPipelines: API.PaginatedOperationMethod<ListPipelinesRequest & RegionInput, ListPipelinesResponse, ListPipelinesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all resource tags associated with an OpenSearch Ingestion pipeline. For more information,
 * see Tagging Amazon OpenSearch Ingestion pipelines.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Attaches a resource-based policy to an OpenSearch Ingestion resource. Resource-based
 * policies grant permissions to principals to perform actions on the resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RevokePipelineEndpointConnectionsError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Revokes pipeline endpoints from specified endpoint IDs.
 */
export declare const revokePipelineEndpointConnections: API.OperationMethod<RevokePipelineEndpointConnectionsRequest & RegionInput, RevokePipelineEndpointConnectionsResponse, RevokePipelineEndpointConnectionsError, Credentials | HttpClient.HttpClient>;
export type StartPipelineError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts an OpenSearch Ingestion pipeline. For more information, see Starting an OpenSearch Ingestion pipeline.
 */
export declare const startPipeline: API.OperationMethod<StartPipelineRequest & RegionInput, StartPipelineResponse, StartPipelineError, Credentials | HttpClient.HttpClient>;
export type StopPipelineError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops an OpenSearch Ingestion pipeline. For more information, see Stopping
 * an OpenSearch Ingestion pipeline.
 */
export declare const stopPipeline: API.OperationMethod<StopPipelineRequest & RegionInput, StopPipelineResponse, StopPipelineError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tags an OpenSearch Ingestion pipeline. For more information, see Tagging Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from an OpenSearch Ingestion pipeline. For more information, see Tagging
 * Amazon OpenSearch Ingestion pipelines.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePipelineError = AccessDeniedException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Ingestion pipeline. For more information, see Updating Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const updatePipeline: API.OperationMethod<UpdatePipelineRequest & RegionInput, UpdatePipelineResponse, UpdatePipelineError, Credentials | HttpClient.HttpClient>;
export type ValidatePipelineError = AccessDeniedException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Checks whether an OpenSearch Ingestion pipeline configuration is valid prior to creation. For
 * more information, see Creating Amazon OpenSearch
 * Ingestion pipelines.
 */
export declare const validatePipeline: API.OperationMethod<ValidatePipelineRequest & RegionInput, ValidatePipelineResponse, ValidatePipelineError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=osis.d.ts.map