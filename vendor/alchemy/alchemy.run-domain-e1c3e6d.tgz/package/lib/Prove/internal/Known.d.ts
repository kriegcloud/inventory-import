import type { V } from "./Value.ts";
/** The modules whose functions are run as they are, where the prover knows every argument. */
export declare const modules: ReadonlyArray<string>;
/**
 * What a pure module of the library gives under a name, as the runtime loads
 * it: `undefined` for a module that is not one of those, and for a function
 * that reads the clock.
 */
export declare const hostOf: (module: string, path: ReadonlyArray<string>) => unknown;
/**
 * What `effect/Schema` gives under a name. A schema is built, never run: the
 * prover calls none of these on an input, and builds a schema from them only
 * where it knows every part.
 */
export declare const schemaOf: (module: string, path: ReadonlyArray<string>) => unknown;
/**
 * The schema, or the check of one, each value the prover does not look inside
 * stands for: a schema built from it is then built from the real one.
 */
export declare const schemas: WeakMap<object, unknown>;
/**
 * The real value of one the prover knows all of: `undefined` when any part
 * of it depends on an input, or is something only the prover has.
 */
export declare const real: (v: V) => {
    readonly value: unknown;
} | undefined;
/**
 * What the library gave, as a value the prover holds: `undefined` for an
 * effect, a stream or a promise, which are not values of a pure function.
 * `name` is how a message names what could not be seen into.
 */
export declare const known: (value: unknown, name: string) => V | undefined;
/**
 * A pure function of the library on values the prover knows all of: what the
 * real function gives. `undefined` when an argument depends on an input, or
 * the function throws or gives something that is not a plain value.
 */
export declare const applied: (fn: (...args: ReadonlyArray<unknown>) => unknown, args: ReadonlyArray<V>, name: string) => V | undefined;
//# sourceMappingURL=Known.d.ts.map