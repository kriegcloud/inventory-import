import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ClusterLimitExceededException_base: S.TaggedErrorClass<"ClusterLimitExceededException", {
    readonly message: any;
}>;
export declare class ClusterLimitExceededException extends /*@__PURE__*/ ClusterLimitExceededException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ConflictResource: any;
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const Ec2RequestFailedException_base: S.TaggedErrorClass<"Ec2RequestFailedException", {
    readonly message: any;
}>;
export declare class Ec2RequestFailedException extends /*@__PURE__*/ Ec2RequestFailedException_base {
}
declare const InvalidAddressException_base: S.TaggedErrorClass<"InvalidAddressException", {
    readonly message: any;
}>;
export declare class InvalidAddressException extends /*@__PURE__*/ InvalidAddressException_base {
}
declare const InvalidInputCombinationException_base: S.TaggedErrorClass<"InvalidInputCombinationException", {
    readonly message: any;
}>;
export declare class InvalidInputCombinationException extends /*@__PURE__*/ InvalidInputCombinationException_base {
}
declare const InvalidJobStateException_base: S.TaggedErrorClass<"InvalidJobStateException", {
    readonly message: any;
}>;
export declare class InvalidJobStateException extends /*@__PURE__*/ InvalidJobStateException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidResourceException_base: S.TaggedErrorClass<"InvalidResourceException", {
    readonly message: any;
    readonly ResourceType: any;
}>;
export declare class InvalidResourceException extends /*@__PURE__*/ InvalidResourceException_base {
}
declare const KMSRequestFailedException_base: S.TaggedErrorClass<"KMSRequestFailedException", {
    readonly message: any;
}>;
export declare class KMSRequestFailedException extends /*@__PURE__*/ KMSRequestFailedException_base {
}
declare const ReturnShippingLabelAlreadyExistsException_base: S.TaggedErrorClass<"ReturnShippingLabelAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReturnShippingLabelAlreadyExistsException extends /*@__PURE__*/ ReturnShippingLabelAlreadyExistsException_base {
}
declare const UnsupportedAddressException_base: S.TaggedErrorClass<"UnsupportedAddressException", {
    readonly message: any;
}>;
export declare class UnsupportedAddressException extends /*@__PURE__*/ UnsupportedAddressException_base {
}
export type ClusterId = string;
export interface CancelClusterRequest {
    ClusterId: string;
}
export interface CancelClusterResult {
}
export type JobId = string;
export interface CancelJobRequest {
    JobId: string;
}
export interface CancelJobResult {
}
export type AddressId = string;
export type AddressType = "CUST_PICKUP" | "AWS_SHIP" | (string & {});
export interface Address {
    AddressId?: string | undefined;
    Name?: string | undefined;
    Company?: string | undefined;
    Street1?: string | undefined;
    Street2?: string | undefined;
    Street3?: string | undefined;
    City?: string | undefined;
    StateOrProvince?: string | undefined;
    PrefectureOrDistrict?: string | undefined;
    Landmark?: string | undefined;
    Country?: string | undefined;
    PostalCode?: string | undefined;
    PhoneNumber?: string | undefined;
    IsRestricted?: boolean | undefined;
    Type?: AddressType | undefined;
}
export interface CreateAddressRequest {
    Address: Address;
}
export interface CreateAddressResult {
    AddressId?: string | undefined;
}
export type JobType = "IMPORT" | "EXPORT" | "LOCAL_USE" | (string & {});
export type ResourceARN = string;
export interface KeyRange {
    BeginMarker?: string | undefined;
    EndMarker?: string | undefined;
}
export type DeviceServiceName = "NFS_ON_DEVICE_SERVICE" | "S3_ON_DEVICE_SERVICE" | (string & {});
export type TransferOption = "IMPORT" | "EXPORT" | "LOCAL_USE" | (string & {});
export interface TargetOnDeviceService {
    ServiceName?: DeviceServiceName | undefined;
    TransferOption?: TransferOption | undefined;
}
export type TargetOnDeviceServiceList = TargetOnDeviceService[];
export interface S3Resource {
    BucketArn?: string | undefined;
    KeyRange?: KeyRange | undefined;
    TargetOnDeviceServices?: TargetOnDeviceService[] | undefined;
}
export type S3ResourceList = S3Resource[];
export interface EventTriggerDefinition {
    EventResourceARN?: string | undefined;
}
export type EventTriggerDefinitionList = EventTriggerDefinition[];
export interface LambdaResource {
    LambdaArn?: string | undefined;
    EventTriggers?: EventTriggerDefinition[] | undefined;
}
export type LambdaResourceList = LambdaResource[];
export type AmiId = string;
export interface Ec2AmiResource {
    AmiId: string;
    SnowballAmiId?: string | undefined;
}
export type Ec2AmiResourceList = Ec2AmiResource[];
export interface JobResource {
    S3Resources?: S3Resource[] | undefined;
    LambdaResources?: LambdaResource[] | undefined;
    Ec2AmiResources?: Ec2AmiResource[] | undefined;
}
export type StorageLimit = number;
export type StorageUnit = "TB" | (string & {});
export interface NFSOnDeviceServiceConfiguration {
    StorageLimit?: number | undefined;
    StorageUnit?: StorageUnit | undefined;
}
export interface TGWOnDeviceServiceConfiguration {
    StorageLimit?: number | undefined;
    StorageUnit?: StorageUnit | undefined;
}
export interface EKSOnDeviceServiceConfiguration {
    KubernetesVersion?: string | undefined;
    EKSAnywhereVersion?: string | undefined;
}
export type S3StorageLimit = number;
export type ServiceSize = number;
export type NodeFaultTolerance = number;
export interface S3OnDeviceServiceConfiguration {
    StorageLimit?: number | undefined;
    StorageUnit?: StorageUnit | undefined;
    ServiceSize?: number | undefined;
    FaultTolerance?: number | undefined;
}
export interface OnDeviceServiceConfiguration {
    NFSOnDeviceService?: NFSOnDeviceServiceConfiguration | undefined;
    TGWOnDeviceService?: TGWOnDeviceServiceConfiguration | undefined;
    EKSOnDeviceService?: EKSOnDeviceServiceConfiguration | undefined;
    S3OnDeviceService?: S3OnDeviceServiceConfiguration | undefined;
}
export type KmsKeyARN = string;
export type RoleARN = string;
export type SnowballType = "STANDARD" | "EDGE" | "EDGE_C" | "EDGE_CG" | "EDGE_S" | "SNC1_HDD" | "SNC1_SSD" | "V3_5C" | "V3_5S" | "RACK_5U_C" | (string & {});
export type ShippingOption = "SECOND_DAY" | "NEXT_DAY" | "EXPRESS" | "STANDARD" | (string & {});
export type SnsTopicARN = string;
export type JobState = "New" | "PreparingAppliance" | "PreparingShipment" | "InTransitToCustomer" | "WithCustomer" | "InTransitToAWS" | "WithAWSSortingFacility" | "WithAWS" | "InProgress" | "Complete" | "Cancelled" | "Listing" | "Pending" | (string & {});
export type JobStateList = JobState[];
export interface Notification {
    SnsTopicARN?: string | undefined;
    JobStatesToNotify?: JobState[] | undefined;
    NotifyAll?: boolean | undefined;
    DevicePickupSnsTopicARN?: string | undefined;
}
export type GSTIN = string;
export interface INDTaxDocuments {
    GSTIN?: string | undefined;
}
export interface TaxDocuments {
    IND?: INDTaxDocuments | undefined;
}
export type RemoteManagement = "INSTALLED_ONLY" | "INSTALLED_AUTOSTART" | "NOT_INSTALLED" | (string & {});
export type InitialClusterSize = number;
export type LongTermPricingId = string;
export type LongTermPricingIdList = string[];
export type SnowballCapacity = "T50" | "T80" | "T100" | "T42" | "T98" | "T8" | "T14" | "T32" | "NoPreference" | "T240" | "T13" | (string & {});
export interface CreateClusterRequest {
    JobType: JobType;
    Resources?: JobResource | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
    Description?: string | undefined;
    AddressId: string;
    KmsKeyARN?: string | undefined;
    RoleARN?: string | undefined;
    SnowballType: SnowballType;
    ShippingOption: ShippingOption;
    Notification?: Notification | undefined;
    ForwardingAddressId?: string | undefined;
    TaxDocuments?: TaxDocuments | undefined;
    RemoteManagement?: RemoteManagement | undefined;
    InitialClusterSize?: number | undefined;
    ForceCreateJobs?: boolean | undefined;
    LongTermPricingIds?: string[] | undefined;
    SnowballCapacityPreference?: SnowballCapacity | undefined;
}
export interface JobListEntry {
    JobId?: string | undefined;
    JobState?: JobState | undefined;
    IsMaster?: boolean | undefined;
    JobType?: JobType | undefined;
    SnowballType?: SnowballType | undefined;
    CreationDate?: Date | undefined;
    Description?: string | undefined;
}
export type JobListEntryList = JobListEntry[];
export interface CreateClusterResult {
    ClusterId?: string | undefined;
    JobListEntries?: JobListEntry[] | undefined;
}
export interface WirelessConnection {
    IsWifiEnabled?: boolean | undefined;
}
export interface SnowconeDeviceConfiguration {
    WirelessConnection?: WirelessConnection | undefined;
}
export interface DeviceConfiguration {
    SnowconeDeviceConfiguration?: SnowconeDeviceConfiguration | undefined;
}
export type ImpactLevel = "IL2" | "IL4" | "IL5" | "IL6" | "IL99" | (string & {});
export type PhoneNumber = string | redacted.Redacted<string>;
export type Email = string | redacted.Redacted<string>;
export type DevicePickupId = string;
export interface PickupDetails {
    Name?: string | undefined;
    PhoneNumber?: string | redacted.Redacted<string> | undefined;
    Email?: string | redacted.Redacted<string> | undefined;
    IdentificationNumber?: string | undefined;
    IdentificationExpirationDate?: Date | undefined;
    IdentificationIssuingOrg?: string | undefined;
    DevicePickupId?: string | undefined;
}
export interface CreateJobRequest {
    JobType?: JobType | undefined;
    Resources?: JobResource | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
    Description?: string | undefined;
    AddressId?: string | undefined;
    KmsKeyARN?: string | undefined;
    RoleARN?: string | undefined;
    SnowballCapacityPreference?: SnowballCapacity | undefined;
    ShippingOption?: ShippingOption | undefined;
    Notification?: Notification | undefined;
    ClusterId?: string | undefined;
    SnowballType?: SnowballType | undefined;
    ForwardingAddressId?: string | undefined;
    TaxDocuments?: TaxDocuments | undefined;
    DeviceConfiguration?: DeviceConfiguration | undefined;
    RemoteManagement?: RemoteManagement | undefined;
    LongTermPricingId?: string | undefined;
    ImpactLevel?: ImpactLevel | undefined;
    PickupDetails?: PickupDetails | undefined;
}
export interface CreateJobResult {
    JobId?: string | undefined;
}
export type LongTermPricingType = "OneYear" | "ThreeYear" | "OneMonth" | (string & {});
export type JavaBoolean = boolean;
export interface CreateLongTermPricingRequest {
    LongTermPricingType: LongTermPricingType;
    IsLongTermPricingAutoRenew?: boolean | undefined;
    SnowballType: SnowballType;
}
export interface CreateLongTermPricingResult {
    LongTermPricingId?: string | undefined;
}
export interface CreateReturnShippingLabelRequest {
    JobId: string;
    ShippingOption?: ShippingOption | undefined;
}
export type ShippingLabelStatus = "InProgress" | "TimedOut" | "Succeeded" | "Failed" | (string & {});
export interface CreateReturnShippingLabelResult {
    Status?: ShippingLabelStatus | undefined;
}
export interface DescribeAddressRequest {
    AddressId: string;
}
export interface DescribeAddressResult {
    Address?: Address | undefined;
}
export type ListLimit = number;
export interface DescribeAddressesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AddressList = Address[];
export interface DescribeAddressesResult {
    Addresses?: Address[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeClusterRequest {
    ClusterId: string;
}
export type ClusterState = "AwaitingQuorum" | "Pending" | "InUse" | "Complete" | "Cancelled" | (string & {});
export interface ClusterMetadata {
    ClusterId?: string | undefined;
    Description?: string | undefined;
    KmsKeyARN?: string | undefined;
    RoleARN?: string | undefined;
    ClusterState?: ClusterState | undefined;
    JobType?: JobType | undefined;
    SnowballType?: SnowballType | undefined;
    CreationDate?: Date | undefined;
    Resources?: JobResource | undefined;
    AddressId?: string | undefined;
    ShippingOption?: ShippingOption | undefined;
    Notification?: Notification | undefined;
    ForwardingAddressId?: string | undefined;
    TaxDocuments?: TaxDocuments | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
}
export interface DescribeClusterResult {
    ClusterMetadata?: ClusterMetadata | undefined;
}
export interface DescribeJobRequest {
    JobId: string;
}
export interface Shipment {
    Status?: string | undefined;
    TrackingNumber?: string | undefined;
}
export interface ShippingDetails {
    ShippingOption?: ShippingOption | undefined;
    InboundShipment?: Shipment | undefined;
    OutboundShipment?: Shipment | undefined;
}
export interface DataTransfer {
    BytesTransferred?: number | undefined;
    ObjectsTransferred?: number | undefined;
    TotalBytes?: number | undefined;
    TotalObjects?: number | undefined;
}
export interface JobLogs {
    JobCompletionReportURI?: string | undefined;
    JobSuccessLogURI?: string | undefined;
    JobFailureLogURI?: string | undefined;
}
export interface JobMetadata {
    JobId?: string | undefined;
    JobState?: JobState | undefined;
    JobType?: JobType | undefined;
    SnowballType?: SnowballType | undefined;
    CreationDate?: Date | undefined;
    Resources?: JobResource | undefined;
    Description?: string | undefined;
    KmsKeyARN?: string | undefined;
    RoleARN?: string | undefined;
    AddressId?: string | undefined;
    ShippingDetails?: ShippingDetails | undefined;
    SnowballCapacityPreference?: SnowballCapacity | undefined;
    Notification?: Notification | undefined;
    DataTransferProgress?: DataTransfer | undefined;
    JobLogInfo?: JobLogs | undefined;
    ClusterId?: string | undefined;
    ForwardingAddressId?: string | undefined;
    TaxDocuments?: TaxDocuments | undefined;
    DeviceConfiguration?: DeviceConfiguration | undefined;
    RemoteManagement?: RemoteManagement | undefined;
    LongTermPricingId?: string | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
    ImpactLevel?: ImpactLevel | undefined;
    PickupDetails?: PickupDetails | undefined;
    SnowballId?: string | undefined;
}
export type JobMetadataList = JobMetadata[];
export interface DescribeJobResult {
    JobMetadata?: JobMetadata | undefined;
    SubJobMetadata?: JobMetadata[] | undefined;
}
export interface DescribeReturnShippingLabelRequest {
    JobId: string;
}
export interface DescribeReturnShippingLabelResult {
    Status?: ShippingLabelStatus | undefined;
    ExpirationDate?: Date | undefined;
    ReturnShippingLabelURI?: string | undefined;
}
export interface GetJobManifestRequest {
    JobId: string;
}
export interface GetJobManifestResult {
    ManifestURI?: string | undefined;
}
export interface GetJobUnlockCodeRequest {
    JobId: string;
}
export interface GetJobUnlockCodeResult {
    UnlockCode?: string | undefined;
}
export interface GetSnowballUsageRequest {
}
export interface GetSnowballUsageResult {
    SnowballLimit?: number | undefined;
    SnowballsInUse?: number | undefined;
}
export interface GetSoftwareUpdatesRequest {
    JobId: string;
}
export interface GetSoftwareUpdatesResult {
    UpdatesURI?: string | undefined;
}
export interface ListClusterJobsRequest {
    ClusterId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListClusterJobsResult {
    JobListEntries?: JobListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClustersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ClusterListEntry {
    ClusterId?: string | undefined;
    ClusterState?: ClusterState | undefined;
    CreationDate?: Date | undefined;
    Description?: string | undefined;
}
export type ClusterListEntryList = ClusterListEntry[];
export interface ListClustersResult {
    ClusterListEntries?: ClusterListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCompatibleImagesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface CompatibleImage {
    AmiId?: string | undefined;
    Name?: string | undefined;
}
export type CompatibleImageList = CompatibleImage[];
export interface ListCompatibleImagesResult {
    CompatibleImages?: CompatibleImage[] | undefined;
    NextToken?: string | undefined;
}
export interface ListJobsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListJobsResult {
    JobListEntries?: JobListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLongTermPricingRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LongTermPricingAssociatedJobIdList = string[];
export interface LongTermPricingListEntry {
    LongTermPricingId?: string | undefined;
    LongTermPricingEndDate?: Date | undefined;
    LongTermPricingStartDate?: Date | undefined;
    LongTermPricingType?: LongTermPricingType | undefined;
    CurrentActiveJob?: string | undefined;
    ReplacementJob?: string | undefined;
    IsLongTermPricingAutoRenew?: boolean | undefined;
    LongTermPricingStatus?: string | undefined;
    SnowballType?: SnowballType | undefined;
    JobIds?: string[] | undefined;
}
export type LongTermPricingEntryList = LongTermPricingListEntry[];
export interface ListLongTermPricingResult {
    LongTermPricingEntries?: LongTermPricingListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPickupLocationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListPickupLocationsResult {
    Addresses?: Address[] | undefined;
    NextToken?: string | undefined;
}
export type ServiceName = "KUBERNETES" | "EKS_ANYWHERE" | (string & {});
export interface ServiceVersion {
    Version?: string | undefined;
}
export interface DependentService {
    ServiceName?: ServiceName | undefined;
    ServiceVersion?: ServiceVersion | undefined;
}
export type DependentServiceList = DependentService[];
export interface ListServiceVersionsRequest {
    ServiceName: ServiceName;
    DependentServices?: DependentService[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ServiceVersionList = ServiceVersion[];
export interface ListServiceVersionsResult {
    ServiceVersions: ServiceVersion[];
    ServiceName: ServiceName;
    DependentServices?: DependentService[] | undefined;
    NextToken?: string | undefined;
}
export interface UpdateClusterRequest {
    ClusterId: string;
    RoleARN?: string | undefined;
    Description?: string | undefined;
    Resources?: JobResource | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
    AddressId?: string | undefined;
    ShippingOption?: ShippingOption | undefined;
    Notification?: Notification | undefined;
    ForwardingAddressId?: string | undefined;
}
export interface UpdateClusterResult {
}
export interface UpdateJobRequest {
    JobId: string;
    RoleARN?: string | undefined;
    Notification?: Notification | undefined;
    Resources?: JobResource | undefined;
    OnDeviceServiceConfiguration?: OnDeviceServiceConfiguration | undefined;
    AddressId?: string | undefined;
    ShippingOption?: ShippingOption | undefined;
    Description?: string | undefined;
    SnowballCapacityPreference?: SnowballCapacity | undefined;
    ForwardingAddressId?: string | undefined;
    PickupDetails?: PickupDetails | undefined;
}
export interface UpdateJobResult {
}
export type ShipmentState = "RECEIVED" | "RETURNED" | (string & {});
export interface UpdateJobShipmentStateRequest {
    JobId: string;
    ShipmentState: ShipmentState;
}
export interface UpdateJobShipmentStateResult {
}
export interface UpdateLongTermPricingRequest {
    LongTermPricingId: string;
    ReplacementJob?: string | undefined;
    IsLongTermPricingAutoRenew?: boolean | undefined;
}
export interface UpdateLongTermPricingResult {
}
export type CancelClusterError = InvalidJobStateException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * Cancels a cluster job. You can only cancel a cluster job while it's in the
 * `AwaitingQuorum` status. You'll have at least an hour after creating a cluster
 * job to cancel it.
 */
export declare const cancelCluster: API.OperationMethod<CancelClusterRequest & RegionInput, CancelClusterResult, CancelClusterError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = InvalidJobStateException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * Cancels the specified job. You can only cancel a job before its `JobState`
 * value changes to `PreparingAppliance`. Requesting the `ListJobs` or
 * `DescribeJob` action returns a job's `JobState` as part of the
 * response element data returned.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest & RegionInput, CancelJobResult, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateAddressError = InvalidAddressException | UnsupportedAddressException | CommonErrors;
/**
 * Creates an address for a Snow device to be shipped to. In most regions,
 * addresses are validated at the time of creation. The address you provide must be located
 * within the serviceable area of your region. If the address is invalid or unsupported, then an
 * exception is thrown. If providing an address as a JSON file through the `cli-input-json` option, include the full file path. For example, `--cli-input-json file://create-address.json`.
 */
export declare const createAddress: API.OperationMethod<CreateAddressRequest & RegionInput, CreateAddressResult, CreateAddressError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = Ec2RequestFailedException | InvalidInputCombinationException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * Creates an empty cluster. Each cluster supports five nodes. You use the CreateJob action separately to create the jobs for each of these nodes. The
 * cluster does not ship until these five node jobs have been created.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResult, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = ClusterLimitExceededException | Ec2RequestFailedException | InvalidInputCombinationException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * Creates a job to import or export data between Amazon S3 and your on-premises data
 * center. Your Amazon Web Services account must have the right trust policies and permissions in
 * place to create a job for a Snow device. If you're creating a job for a node in a cluster, you
 * only need to provide the `clusterId` value; the other job attributes are inherited
 * from the cluster.
 *
 * Only the Snowball; Edge device type is supported when ordering clustered jobs.
 *
 * The device capacity is optional.
 *
 * Availability of device types differ by Amazon Web Services Region. For more information
 * about Region availability, see Amazon Web Services Regional Services.
 *
 * **Snow Family devices and their capacities.**
 *
 * - Device type: **SNC1_SSD**
 *
 * - Capacity: T14
 *
 * - Description: Snowcone
 *
 * - Device type: **SNC1_HDD**
 *
 * - Capacity: T8
 *
 * - Description: Snowcone
 *
 * - Device type: **EDGE_S**
 *
 * - Capacity: T98
 *
 * - Description: Snowball Edge Storage Optimized for data transfer only
 *
 * - Device type: **EDGE_CG**
 *
 * - Capacity: T42
 *
 * - Description: Snowball Edge Compute Optimized with GPU
 *
 * - Device type: **EDGE_C**
 *
 * - Capacity: T42
 *
 * - Description: Snowball Edge Compute Optimized without GPU
 *
 * - Device type: **EDGE**
 *
 * - Capacity: T100
 *
 * - Description: Snowball Edge Storage Optimized with EC2 Compute
 *
 * This device is replaced with T98.
 *
 * - Device type: **STANDARD**
 *
 * - Capacity: T50
 *
 * - Description: Original Snowball device
 *
 * This device is only available in the Ningxia, Beijing, and Singapore Amazon Web Services Region
 *
 * - Device type: **STANDARD**
 *
 * - Capacity: T80
 *
 * - Description: Original Snowball device
 *
 * This device is only available in the Ningxia, Beijing, and Singapore Amazon Web Services Region.
 *
 * - Snow Family device type: **RACK_5U_C**
 *
 * - Capacity: T13
 *
 * - Description: Snowblade.
 *
 * - Device type: **V3_5S**
 *
 * - Capacity: T240
 *
 * - Description: Snowball Edge Storage Optimized 210TB
 */
export declare const createJob: API.OperationMethod<CreateJobRequest & RegionInput, CreateJobResult, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateLongTermPricingError = InvalidResourceException | CommonErrors;
/**
 * Creates a job with the long-term usage option for a device. The long-term usage is a
 * 1-year or 3-year long-term pricing type for the device. You are billed upfront, and Amazon Web Services provides discounts for long-term pricing.
 */
export declare const createLongTermPricing: API.OperationMethod<CreateLongTermPricingRequest & RegionInput, CreateLongTermPricingResult, CreateLongTermPricingError, Credentials | HttpClient.HttpClient>;
export type CreateReturnShippingLabelError = ConflictException | InvalidInputCombinationException | InvalidJobStateException | InvalidResourceException | ReturnShippingLabelAlreadyExistsException | CommonErrors;
/**
 * Creates a shipping label that will be used to return the Snow device to Amazon Web Services.
 */
export declare const createReturnShippingLabel: API.OperationMethod<CreateReturnShippingLabelRequest & RegionInput, CreateReturnShippingLabelResult, CreateReturnShippingLabelError, Credentials | HttpClient.HttpClient>;
export type DescribeAddressError = InvalidResourceException | CommonErrors;
/**
 * Takes an `AddressId` and returns specific details about that address in the
 * form of an `Address` object.
 */
export declare const describeAddress: API.OperationMethod<DescribeAddressRequest & RegionInput, DescribeAddressResult, DescribeAddressError, Credentials | HttpClient.HttpClient>;
export type DescribeAddressesError = InvalidNextTokenException | InvalidResourceException | CommonErrors;
/**
 * Returns a specified number of `ADDRESS` objects. Calling this API in one of
 * the US regions will return addresses from the list of all addresses associated with this
 * account in all US regions.
 */
export declare const describeAddresses: API.PaginatedOperationMethod<DescribeAddressesRequest & RegionInput, DescribeAddressesResult, DescribeAddressesError, Credentials | HttpClient.HttpClient, Address>;
export type DescribeClusterError = InvalidResourceException | CommonErrors;
/**
 * Returns information about a specific cluster including shipping information, cluster
 * status, and other important metadata.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest & RegionInput, DescribeClusterResult, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeJobError = InvalidResourceException | CommonErrors;
/**
 * Returns information about a specific job including shipping information, job status,
 * and other important metadata.
 */
export declare const describeJob: API.OperationMethod<DescribeJobRequest & RegionInput, DescribeJobResult, DescribeJobError, Credentials | HttpClient.HttpClient>;
export type DescribeReturnShippingLabelError = ConflictException | InvalidJobStateException | InvalidResourceException | CommonErrors;
/**
 * Information on the shipping label of a Snow device that is being returned to Amazon Web Services.
 */
export declare const describeReturnShippingLabel: API.OperationMethod<DescribeReturnShippingLabelRequest & RegionInput, DescribeReturnShippingLabelResult, DescribeReturnShippingLabelError, Credentials | HttpClient.HttpClient>;
export type GetJobManifestError = InvalidJobStateException | InvalidResourceException | CommonErrors;
/**
 * Returns a link to an Amazon S3 presigned URL for the manifest file associated with the
 * specified `JobId` value. You can access the manifest file for up to 60 minutes
 * after this request has been made. To access the manifest file after 60 minutes have passed,
 * you'll have to make another call to the `GetJobManifest` action.
 *
 * The manifest is an encrypted file that you can download after your job enters the
 * `WithCustomer` status. This is the only valid status for calling this API as the
 * manifest and `UnlockCode` code value are used for securing your device and should
 * only be used when you have the device. The manifest is decrypted by using the
 * `UnlockCode` code value, when you pass both values to the Snow device through the
 * Snowball client when the client is started for the first time.
 *
 * As a best practice, we recommend that you don't save a copy of an
 * `UnlockCode` value in the same location as the manifest file for that job. Saving
 * these separately helps prevent unauthorized parties from gaining access to the Snow device
 * associated with that job.
 *
 * The credentials of a given job, including its manifest file and unlock code, expire 360
 * days after the job is created.
 */
export declare const getJobManifest: API.OperationMethod<GetJobManifestRequest & RegionInput, GetJobManifestResult, GetJobManifestError, Credentials | HttpClient.HttpClient>;
export type GetJobUnlockCodeError = InvalidJobStateException | InvalidResourceException | CommonErrors;
/**
 * Returns the `UnlockCode` code value for the specified job. A particular
 * `UnlockCode` value can be accessed for up to 360 days after the associated job
 * has been created.
 *
 * The `UnlockCode` value is a 29-character code with 25 alphanumeric
 * characters and 4 hyphens. This code is used to decrypt the manifest file when it is passed
 * along with the manifest to the Snow device through the Snowball client when the client is
 * started for the first time. The only valid status for calling this API is
 * `WithCustomer` as the manifest and `Unlock` code values are used for
 * securing your device and should only be used when you have the device.
 *
 * As a best practice, we recommend that you don't save a copy of the
 * `UnlockCode` in the same location as the manifest file for that job. Saving these
 * separately helps prevent unauthorized parties from gaining access to the Snow device
 * associated with that job.
 */
export declare const getJobUnlockCode: API.OperationMethod<GetJobUnlockCodeRequest & RegionInput, GetJobUnlockCodeResult, GetJobUnlockCodeError, Credentials | HttpClient.HttpClient>;
export type GetSnowballUsageError = CommonErrors;
/**
 * Returns information about the Snow Family service limit for your account, and also the
 * number of Snow devices your account has in use.
 *
 * The default service limit for the number of Snow devices that you can have at one time
 * is 1. If you want to increase your service limit, contact Amazon Web Services Support.
 */
export declare const getSnowballUsage: API.OperationMethod<GetSnowballUsageRequest & RegionInput, GetSnowballUsageResult, GetSnowballUsageError, Credentials | HttpClient.HttpClient>;
export type GetSoftwareUpdatesError = InvalidJobStateException | InvalidResourceException | CommonErrors;
/**
 * Returns an Amazon S3 presigned URL for an update file associated with a specified
 * `JobId`.
 */
export declare const getSoftwareUpdates: API.OperationMethod<GetSoftwareUpdatesRequest & RegionInput, GetSoftwareUpdatesResult, GetSoftwareUpdatesError, Credentials | HttpClient.HttpClient>;
export type ListClusterJobsError = InvalidNextTokenException | InvalidResourceException | CommonErrors;
/**
 * Returns an array of `JobListEntry` objects of the specified length. Each
 * `JobListEntry` object is for a job in the specified cluster and contains a job's
 * state, a job's ID, and other information.
 */
export declare const listClusterJobs: API.PaginatedOperationMethod<ListClusterJobsRequest & RegionInput, ListClusterJobsResult, ListClusterJobsError, Credentials | HttpClient.HttpClient, JobListEntry>;
export type ListClustersError = InvalidNextTokenException | CommonErrors;
/**
 * Returns an array of `ClusterListEntry` objects of the specified length. Each
 * `ClusterListEntry` object contains a cluster's state, a cluster's ID, and other
 * important status information.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResult, ListClustersError, Credentials | HttpClient.HttpClient, ClusterListEntry>;
export type ListCompatibleImagesError = Ec2RequestFailedException | InvalidNextTokenException | CommonErrors;
/**
 * This action returns a list of the different Amazon EC2-compatible Amazon Machine Images (AMIs)
 * that are owned by your Amazon Web Services accountthat would be supported for use on a Snow
 * device. Currently, supported AMIs are based on the Amazon Linux-2, Ubuntu 20.04 LTS - Focal, or Ubuntu 22.04 LTS - Jammy images, available on the
 * Amazon Web Services Marketplace. Ubuntu 16.04 LTS - Xenial (HVM) images are no longer supported in the Market, but still supported for use on devices through Amazon EC2 VM Import/Export and running locally in AMIs.
 */
export declare const listCompatibleImages: API.PaginatedOperationMethod<ListCompatibleImagesRequest & RegionInput, ListCompatibleImagesResult, ListCompatibleImagesError, Credentials | HttpClient.HttpClient, CompatibleImage>;
export type ListJobsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns an array of `JobListEntry` objects of the specified length. Each
 * `JobListEntry` object contains a job's state, a job's ID, and a value that
 * indicates whether the job is a job part, in the case of export jobs. Calling this API action
 * in one of the US regions will return jobs from the list of all jobs associated with this
 * account in all US regions.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResult, ListJobsError, Credentials | HttpClient.HttpClient, JobListEntry>;
export type ListLongTermPricingError = InvalidNextTokenException | InvalidResourceException | CommonErrors;
/**
 * Lists all long-term pricing types.
 */
export declare const listLongTermPricing: API.PaginatedOperationMethod<ListLongTermPricingRequest & RegionInput, ListLongTermPricingResult, ListLongTermPricingError, Credentials | HttpClient.HttpClient, LongTermPricingListEntry>;
export type ListPickupLocationsError = InvalidResourceException | CommonErrors;
/**
 * A list of locations from which the customer can choose to pickup a device.
 */
export declare const listPickupLocations: API.PaginatedOperationMethod<ListPickupLocationsRequest & RegionInput, ListPickupLocationsResult, ListPickupLocationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServiceVersionsError = InvalidNextTokenException | InvalidResourceException | CommonErrors;
/**
 * Lists all supported versions for Snow on-device services. Returns an
 * array of `ServiceVersion` object containing the supported versions for a particular service.
 */
export declare const listServiceVersions: API.OperationMethod<ListServiceVersionsRequest & RegionInput, ListServiceVersionsResult, ListServiceVersionsError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = Ec2RequestFailedException | InvalidInputCombinationException | InvalidJobStateException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * While a cluster's `ClusterState` value is in the `AwaitingQuorum`
 * state, you can update some of the information associated with a cluster. Once the cluster
 * changes to a different job state, usually 60 minutes after the cluster being created, this
 * action is no longer available.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest & RegionInput, UpdateClusterResult, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateJobError = ClusterLimitExceededException | Ec2RequestFailedException | InvalidInputCombinationException | InvalidJobStateException | InvalidResourceException | KMSRequestFailedException | CommonErrors;
/**
 * While a job's `JobState` value is `New`, you can update some of
 * the information associated with a job. Once the job changes to a different job state, usually
 * within 60 minutes of the job being created, this action is no longer available.
 */
export declare const updateJob: API.OperationMethod<UpdateJobRequest & RegionInput, UpdateJobResult, UpdateJobError, Credentials | HttpClient.HttpClient>;
export type UpdateJobShipmentStateError = InvalidJobStateException | InvalidResourceException | CommonErrors;
/**
 * Updates the state when a shipment state changes to a different state.
 */
export declare const updateJobShipmentState: API.OperationMethod<UpdateJobShipmentStateRequest & RegionInput, UpdateJobShipmentStateResult, UpdateJobShipmentStateError, Credentials | HttpClient.HttpClient>;
export type UpdateLongTermPricingError = InvalidResourceException | CommonErrors;
/**
 * Updates the long-term pricing type.
 */
export declare const updateLongTermPricing: API.OperationMethod<UpdateLongTermPricingRequest & RegionInput, UpdateLongTermPricingResult, UpdateLongTermPricingError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=snowball.d.ts.map