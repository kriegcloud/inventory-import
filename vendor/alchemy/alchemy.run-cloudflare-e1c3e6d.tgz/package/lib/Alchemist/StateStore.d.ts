import type { StateStoreImpl, StateStoreLifecycle } from "alchemy/Contributions";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as CloudflareAccess from "../Access.ts";
import * as CloudflareEnvironment from "../CloudflareEnvironment.ts";
import * as CloudflareCredentials from "../Credentials.ts";
/**
 * The profile, Cloudflare account and clients a store's lifecycle operation
 * runs with, under the profile config and auth registry core provides.
 */
export declare const stateStoreScope: (name: string | undefined) => Effect.Effect<{
    layer: Layer.Layer<CloudflareAccess.Access | CloudflareEnvironment.CloudflareEnvironment | CloudflareCredentials.Credentials, never, import("alchemy").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("alchemy/Auth/Profile").ProfileStore>;
    profile: string;
    accountId: string;
    workerName: string;
}, import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError | import("alchemy/State/State").StateStoreError, import("alchemy").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("alchemy/Auth/Profile").ProfileStore>;
/** The state-store Worker's options. */
export interface CloudflareStateStoreOptions {
    /** The store's full Worker name, for a store other than the default. */
    readonly name?: string;
    /** Hostname the store is served on, when it has a custom domain. */
    readonly domain?: string;
}
/** The state-store Worker's lifecycle, for `Alchemist.State` and `alchemy state`. */
export declare const lifecycle: StateStoreLifecycle<CloudflareStateStoreOptions>;
/** The state store Cloudflare contributes. */
export declare const stateStore: StateStoreImpl<CloudflareStateStoreOptions>;
//# sourceMappingURL=StateStore.d.ts.map