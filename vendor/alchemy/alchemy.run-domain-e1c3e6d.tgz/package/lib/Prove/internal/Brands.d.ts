import * as BigDecimal from "effect/BigDecimal";
import * as Rational from "effect/Rational";
import type { Term } from "./Smt.ts";
import type { Brand, V } from "./Value.ts";
/** A duration of so many milliseconds: a whole number the prover knows, or a formula for one. */
export declare const duration: (millis: V) => V;
/** The milliseconds of a duration: `undefined` when the value is not one. */
export declare const durationOf: (v: V | undefined) => V | undefined;
/** `Result.succeed(value)`. */
export declare const success: (value: V) => V;
/** `Result.fail(error)`. */
export declare const failure: (error: V) => V;
/** What a `Result` holds: `undefined` when the value is not one. */
export declare const resultOf: (v: V | undefined) => {
    readonly _tag: "Success";
    readonly success: V;
} | {
    readonly _tag: "Failure";
    readonly failure: V;
} | undefined;
/** A decimal the prover knows, or a real number of the solver's that stands for one. */
export type Decimal = BigDecimal.BigDecimal | Term;
export declare const isKnown: (decimal: Decimal) => decimal is BigDecimal.BigDecimal;
/** A `BigDecimal`. One the prover knows is kept as its shortest text, so equal decimals read the same. */
export declare const decimal: (value: Decimal) => V;
/** What a `BigDecimal` is: `undefined` when the value is not one. */
export declare const decimalOf: (v: V | undefined) => Decimal | undefined;
/** A decimal as the solver's real number: exactly, as one whole number over a power of ten. */
export declare const realOf: (value: Decimal) => Term;
/** A fraction the prover knows, or a real number of the solver's that stands for one. */
export type Fraction = Rational.Rational | Term;
export declare const isFraction: (fraction: Fraction) => fraction is Rational.Rational;
/** A `Rational`. One the prover knows is kept as the library writes it, in lowest terms. */
export declare const rational: (value: Fraction) => V;
/** What a `Rational` is: `undefined` when the value is not one. */
export declare const rationalOf: (v: V | undefined) => Fraction | undefined;
/** A fraction as the solver's real number: one whole number over another. */
export declare const realOfFraction: (value: Fraction) => Term;
/** A hash set of these items: an array, or the list an input holds. */
export declare const hashSet: (items: V) => V;
/** A hash map of these pairs of a key and its value: an array, or the list an input holds. */
export declare const hashMap: (entries: V) => V;
/** The items of a hash set, as the prover holds them: `undefined` when the value is not one. */
export declare const setOf: (v: V | undefined) => V | undefined;
/** The pairs of a hash map, as the prover holds them: `undefined` when the value is not one. */
export declare const mapOf: (v: V | undefined) => V | undefined;
/** The brands whose values are read only through their module, never by what they are made of. */
export declare const SEALED: ReadonlySet<Brand["kind"]>;
/** The brands whose values have the library's `.pipe`. */
export declare const PIPED: ReadonlySet<Brand["kind"]>;
//# sourceMappingURL=Brands.d.ts.map