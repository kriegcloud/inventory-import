import * as Schema from "@distilled.cloud/core/schema-lite-typed";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientError from "effect/http/HttpClientError";
import * as Redacted from "effect/Redacted";
import { GithubParseError } from "./errors.ts";
/** github.com's web host. GHES uses `https://HOSTNAME`. */
export declare const DEFAULT_WEB_BASE_URL = "https://github.com";
declare const BadVerificationCode_base: Schema.TaggedErrorClass<"BadVerificationCode", {
    message: import("effect/Schema").String;
    /** GitHub's page about the error. */
    error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The `code` is wrong, already used, or expired (codes last ten minutes). */
export declare class BadVerificationCode extends /*@__PURE__*/ BadVerificationCode_base {
}
declare const IncorrectClientCredentials_base: Schema.TaggedErrorClass<"IncorrectClientCredentials", {
    message: import("effect/Schema").String;
    /** GitHub's page about the error. */
    error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/** The `client_id` or `client_secret` is wrong. */
export declare class IncorrectClientCredentials extends /*@__PURE__*/ IncorrectClientCredentials_base {
}
declare const RedirectUriMismatch_base: Schema.TaggedErrorClass<"RedirectUriMismatch", {
    message: import("effect/Schema").String;
    /** GitHub's page about the error. */
    error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The `redirect_uri` does not match the one the App registered. */
export declare class RedirectUriMismatch extends /*@__PURE__*/ RedirectUriMismatch_base {
}
declare const UnverifiedUserEmail_base: Schema.TaggedErrorClass<"UnverifiedUserEmail", {
    message: import("effect/Schema").String;
    /** GitHub's page about the error. */
    error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The user has no verified primary email address. */
export declare class UnverifiedUserEmail extends /*@__PURE__*/ UnverifiedUserEmail_base {
}
declare const BadRefreshToken_base: Schema.TaggedErrorClass<"BadRefreshToken", {
    message: import("effect/Schema").String;
    /** GitHub's page about the error. */
    error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** The `refresh_token` is wrong, already used, or expired. */
export declare class BadRefreshToken extends /*@__PURE__*/ BadRefreshToken_base {
}
declare const GithubOAuthError_base: Schema.TaggedErrorClass<"GithubOAuthError", {
    readonly message: import("effect/Schema").String;
    readonly error_uri: import("effect/Schema").optional<import("effect/Schema").String>;
    /** GitHub's `error` code. */
    readonly error: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** A refused exchange whose `error` has no class of its own. */
export declare class GithubOAuthError extends /*@__PURE__*/ GithubOAuthError_base {
}
/** A user access token. */
export interface UserAccessToken {
    readonly access_token: Redacted.Redacted<string>;
    /** `bearer`. */
    readonly token_type: string;
    /** Comma-separated scopes the user granted (OAuth Apps; empty for GitHub Apps). */
    readonly scope: string;
    /** Seconds until `access_token` expires, when the App expires user tokens. */
    readonly expires_in?: number;
    /** Trades for a new token with {@link refreshUserAccessToken}. */
    readonly refresh_token?: Redacted.Redacted<string>;
    /** Seconds until `refresh_token` expires. */
    readonly refresh_token_expires_in?: number;
}
export type OAuthExchangeError = BadVerificationCode | IncorrectClientCredentials | RedirectUriMismatch | UnverifiedUserEmail | BadRefreshToken | GithubOAuthError | GithubParseError | HttpClientError.HttpClientError;
interface Endpoint {
    /** Defaults to `https://github.com`; GHES uses `https://HOSTNAME`. */
    readonly webBaseUrl?: string;
    readonly userAgent?: string;
}
export interface ExchangeWebFlowCodeRequest extends Endpoint {
    readonly client_id: string;
    readonly client_secret: string | Redacted.Redacted<string>;
    /** The `code` GitHub redirected back with. */
    readonly code: string;
    /** The `redirect_uri` the authorize request sent, if it sent one. */
    readonly redirect_uri?: string;
    /** The PKCE verifier whose challenge the authorize request sent. */
    readonly code_verifier?: string;
}
export interface RefreshUserAccessTokenRequest extends Endpoint {
    readonly client_id: string;
    readonly client_secret: string | Redacted.Redacted<string>;
    readonly refresh_token: string | Redacted.Redacted<string>;
}
/**
 * Trade the `code` from the web application flow's redirect for a user
 * access token. A wrong, used or expired code fails with
 * `BadVerificationCode`; wrong App credentials with
 * `IncorrectClientCredentials`.
 */
export declare const exchangeWebFlowCode: (request: ExchangeWebFlowCodeRequest) => Effect.Effect<UserAccessToken, OAuthExchangeError, HttpClient.HttpClient>;
/**
 * Trade a refresh token for a new user access token (GitHub Apps that
 * expire user tokens). A wrong, used or expired refresh token fails with
 * `BadRefreshToken`.
 */
export declare const refreshUserAccessToken: (request: RefreshUserAccessTokenRequest) => Effect.Effect<UserAccessToken, OAuthExchangeError, HttpClient.HttpClient>;
export {};
//# sourceMappingURL=oauth.d.ts.map