/**
 * GitHub App authentication -- hand-written.
 *
 * A GitHub App authenticates in two steps
 * (https://docs.github.com/apps/creating-github-apps/authenticating-with-a-github-app/about-authentication-with-a-github-app):
 *
 * 1. As the App itself, with a short-lived JWT signed by the App's private
 *    key ({@link appJwt}, {@link appCredentials}). This reaches the
 *    App-level endpoints: `apps.getAuthenticated`, `apps.listInstallations`,
 *    `apps.createInstallationAccessToken`.
 * 2. As one installation, with an installation access token the App mints
 *    using that JWT ({@link installationCredentials}). The token lasts an
 *    hour and reaches what the installation was granted.
 *
 * Both layers mint on the first request, reuse the result, and mint again
 * shortly before it expires; concurrent requests share one mint. Signing uses
 * WebCrypto, so it runs in Node, Bun, workers and browsers.
 *
 * @example
 * ```ts
 * import * as Issues from "@distilled.cloud/github/issues";
 * import * as App from "@distilled.cloud/github/App";
 *
 * const issue = Issues.get({ owner, repo, issue_number: 1 }).pipe(
 *   Effect.provide(
 *     App.installationCredentials({
 *       appId: "123456",
 *       privateKey: Redacted.make(pem),
 *       installationId: 7890,
 *     }),
 *   ),
 * );
 * ```
 */
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import { Credentials } from "./credentials.ts";
import { GithubAppAuthError } from "./errors.ts";
import { type AppPermissions } from "./services/apps.ts";
export interface AppConfig {
    /**
     * The App's id, or its client id (`Iv1.<hex>`). Either identifies the App as
     * the JWT's issuer.
     */
    readonly appId: string | number;
    /**
     * The App's private key as GitHub issues it: a PEM, either PKCS #1
     * (`-----BEGIN RSA PRIVATE KEY-----`) or PKCS #8
     * (`-----BEGIN PRIVATE KEY-----`).
     */
    readonly privateKey: Redacted.Redacted<string>;
    /** Defaults to `https://api.github.com`; GHES uses `https://HOSTNAME/api/v3`. */
    readonly apiBaseUrl?: string;
    readonly userAgent?: string;
}
export interface InstallationConfig extends AppConfig {
    /** The installation to act as. */
    readonly installationId: number;
    /** Narrow the token to these repositories, by name. */
    readonly repositories?: ReadonlyArray<string>;
    /** Narrow the token to these repositories, by id. */
    readonly repositoryIds?: ReadonlyArray<number>;
    /** Narrow the token to these permissions (a subset of the installation's). */
    readonly permissions?: AppPermissions;
}
/**
 * Sign the App's JWT: RS256, `iss` the App, `iat` backdated a minute, `exp`
 * nine minutes out. Use it as the bearer token for App-level endpoints, or
 * let {@link appCredentials} mint and refresh it.
 */
export declare const appJwt: (config: Pick<AppConfig, "appId" | "privateKey">) => Effect.Effect<Redacted.Redacted<string>, GithubAppAuthError>;
/**
 * Authenticate as the App itself, with its JWT, minted again shortly before
 * it expires. For the App-level endpoints (`apps.getAuthenticated`,
 * `apps.listInstallations`, `apps.createInstallationAccessToken`); repository
 * endpoints need {@link installationCredentials}.
 */
export declare const appCredentials: (config: AppConfig) => Layer.Layer<Credentials>;
/**
 * Authenticate as one installation of the App: an installation access token
 * minted with the App's JWT (`apps.createInstallationAccessToken`), optionally
 * narrowed to some repositories or permissions, and minted again shortly
 * before its hour runs out. A refusal (an unknown installation, a revoked
 * key) fails the operation with `GithubAppAuthError`, the API error as its
 * `cause`.
 */
export declare const installationCredentials: (config: InstallationConfig) => Layer.Layer<Credentials>;
//# sourceMappingURL=app.d.ts.map