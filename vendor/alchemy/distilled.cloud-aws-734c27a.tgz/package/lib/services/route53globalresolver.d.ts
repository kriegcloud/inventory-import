import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type HostedZoneId = string;
export type ResourceArn = string;
export type ResourceName = string;
export interface AssociateHostedZoneInput {
    hostedZoneId: string;
    resourceArn: string;
    name: string;
}
export type ResourceId = string;
export type HostedZoneName = string;
export type ISO8601TimeString = Date;
export type HostedZoneAssociationStatus = "CREATING" | "OPERATIONAL" | "DELETING" | (string & {});
export interface AssociateHostedZoneOutput {
    id: string;
    resourceArn: string;
    hostedZoneId: string;
    hostedZoneName: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    status: HostedZoneAssociationStatus;
}
export type FirewallRuleAction = "ALLOW" | "ALERT" | "BLOCK" | (string & {});
export type BlockOverrideDnsQueryType = "CNAME" | (string & {});
export type Domain = string;
export type BlockOverrideTtl = number;
export type FirewallBlockResponse = "NODATA" | "NXDOMAIN" | "OVERRIDE" | (string & {});
export type ClientToken = string;
export type ConfidenceThreshold = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type ResourceDescription = string;
export type DnsAdvancedProtection = "DGA" | "DNS_TUNNELING" | "DICTIONARY_DGA" | (string & {});
export type FirewallRulePriority = number;
export type DnsQueryType = string;
export interface BatchCreateFirewallRuleInputItem {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    clientToken: string;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    name: string;
    priority?: number | undefined;
    dnsViewId: string;
    qType?: string | undefined;
}
export type BatchCreateFirewallRuleInputItems = BatchCreateFirewallRuleInputItem[];
export interface BatchCreateFirewallRuleInput {
    firewallRules: BatchCreateFirewallRuleInputItem[];
}
export type CRResourceStatus = "CREATING" | "OPERATIONAL" | "UPDATING" | "DELETING" | (string & {});
export interface BatchCreateFirewallRuleResult {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    clientToken: string;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id?: string | undefined;
    managedDomainListName?: string | undefined;
    name: string;
    priority?: number | undefined;
    dnsViewId: string;
    queryType?: string | undefined;
    status?: CRResourceStatus | undefined;
    updatedAt?: Date | undefined;
}
export interface BatchCreateFirewallRuleOutputItem {
    firewallRule: BatchCreateFirewallRuleResult;
    code: number;
    message?: string | undefined;
}
export type BatchCreateFirewallRuleOutputItems = BatchCreateFirewallRuleOutputItem[];
export interface BatchCreateFirewallRuleOutput {
    failures: BatchCreateFirewallRuleOutputItem[];
    successes: BatchCreateFirewallRuleOutputItem[];
}
export interface BatchDeleteFirewallRuleInputItem {
    firewallRuleId: string;
}
export type BatchDeleteFirewallRuleInputItems = BatchDeleteFirewallRuleInputItem[];
export interface BatchDeleteFirewallRuleInput {
    firewallRules: BatchDeleteFirewallRuleInputItem[];
}
export interface BatchDeleteFirewallRuleResult {
    clientToken?: string | undefined;
    id: string;
    name?: string | undefined;
    status?: CRResourceStatus | undefined;
}
export interface BatchDeleteFirewallRuleOutputItem {
    firewallRule: BatchDeleteFirewallRuleResult;
    code: number;
    message?: string | undefined;
}
export type BatchDeleteFirewallRuleOutputItems = BatchDeleteFirewallRuleOutputItem[];
export interface BatchDeleteFirewallRuleOutput {
    failures: BatchDeleteFirewallRuleOutputItem[];
    successes: BatchDeleteFirewallRuleOutputItem[];
}
export interface BatchUpdateFirewallRuleInputItem {
    action?: FirewallRuleAction | undefined;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallRuleId: string;
    name?: string | undefined;
    priority?: number | undefined;
}
export type BatchUpdateFirewallRuleInputItems = BatchUpdateFirewallRuleInputItem[];
export interface BatchUpdateFirewallRuleInput {
    firewallRules: BatchUpdateFirewallRuleInputItem[];
}
export interface BatchUpdateFirewallRuleResult {
    action?: FirewallRuleAction | undefined;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    clientToken?: string | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name?: string | undefined;
    priority?: number | undefined;
    dnsViewId?: string | undefined;
    queryType?: string | undefined;
    status?: CRResourceStatus | undefined;
    updatedAt?: Date | undefined;
}
export interface BatchUpdateFirewallRuleOutputItem {
    firewallRule: BatchUpdateFirewallRuleResult;
    code: number;
    message?: string | undefined;
}
export type BatchUpdateFirewallRuleOutputItems = BatchUpdateFirewallRuleOutputItem[];
export interface BatchUpdateFirewallRuleOutput {
    failures: BatchUpdateFirewallRuleOutputItem[];
    successes: BatchUpdateFirewallRuleOutputItem[];
}
export type Cidr = string;
export type IpAddressType = "IPV4" | "IPV6" | (string & {});
export type ResourceNameShort = string;
export type DnsProtocol = "DO53" | "DOH" | "DOT" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateAccessSourceInput {
    cidr: string;
    clientToken?: string | undefined;
    ipAddressType?: IpAddressType | undefined;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAccessSourceOutput {
    arn: string;
    cidr: string;
    createdAt: Date;
    id: string;
    ipAddressType: IpAddressType;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface CreateAccessTokenInput {
    clientToken?: string | undefined;
    dnsViewId: string;
    expiresAt?: Date | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TokenStatus = "CREATING" | "OPERATIONAL" | "DELETING" | (string & {});
export type AccessTokenValue = string | redacted.Redacted<string>;
export interface CreateAccessTokenOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    createdAt: Date;
    dnsViewId: string;
    expiresAt: Date;
    name?: string | undefined;
    status: TokenStatus;
    value: string | redacted.Redacted<string>;
}
export type DnsSecValidationType = "ENABLED" | "DISABLED" | (string & {});
export type EdnsClientSubnetType = "ENABLED" | "DISABLED" | (string & {});
export type FirewallRulesFailOpenType = "ENABLED" | "DISABLED" | (string & {});
export interface CreateDNSViewInput {
    globalResolverId: string;
    clientToken?: string | undefined;
    name: string;
    dnssecValidation?: DnsSecValidationType | undefined;
    ednsClientSubnet?: EdnsClientSubnetType | undefined;
    firewallRulesFailOpen?: FirewallRulesFailOpenType | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProfileResourceStatus = "CREATING" | "OPERATIONAL" | "UPDATING" | "ENABLING" | "DISABLING" | "DISABLED" | "DELETING" | (string & {});
export interface CreateDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface CreateFirewallDomainListInput {
    clientToken?: string | undefined;
    globalResolverId: string;
    description?: string | undefined;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateFirewallDomainListOutput {
    arn: string;
    globalResolverId: string;
    createdAt: Date;
    description?: string | undefined;
    domainCount: number;
    id: string;
    name: string;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface CreateFirewallRuleInput {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    clientToken?: string | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    name: string;
    priority?: number | undefined;
    dnsViewId: string;
    qType?: string | undefined;
}
export interface CreateFirewallRuleOutput {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt: Date;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name: string;
    priority: number;
    dnsViewId: string;
    queryType?: string | undefined;
    status: CRResourceStatus;
    updatedAt: Date;
}
export type GlobalResolverIpAddressType = "IPV4" | "DUAL_STACK" | (string & {});
export type Region = string;
export type Regions = string[];
export interface CreateGlobalResolverInput {
    clientToken?: string | undefined;
    description?: string | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
    name: string;
    observabilityRegion?: string | undefined;
    regions: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Sni = string;
export type IPv4Address = string;
export type IPv4Addresses = string[];
export type IPv6Address = string;
export type IPv6Addresses = string[];
export interface CreateGlobalResolverOutput {
    id: string;
    arn: string;
    clientToken: string;
    createdAt: Date;
    description?: string | undefined;
    dnsName: string;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
    ipv4Addresses: string[];
    ipv6Addresses?: string[] | undefined;
    name: string;
    observabilityRegion?: string | undefined;
    regions: string[];
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface DeleteAccessSourceInput {
    accessSourceId: string;
}
export interface DeleteAccessSourceOutput {
    arn: string;
    cidr: string;
    createdAt: Date;
    id: string;
    ipAddressType: IpAddressType;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface DeleteAccessTokenInput {
    accessTokenId: string;
}
export interface DeleteAccessTokenOutput {
    id: string;
    status: TokenStatus;
    deletedAt: Date;
}
export interface DeleteDNSViewInput {
    dnsViewId: string;
}
export interface DeleteDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface DeleteFirewallDomainListInput {
    firewallDomainListId: string;
}
export interface DeleteFirewallDomainListOutput {
    arn: string;
    id: string;
    name: string;
    status: CRResourceStatus;
}
export interface DeleteFirewallRuleInput {
    firewallRuleId: string;
}
export interface DeleteFirewallRuleOutput {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt: Date;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name: string;
    priority: number;
    dnsViewId: string;
    queryType?: string | undefined;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface DeleteGlobalResolverInput {
    globalResolverId: string;
}
export interface DeleteGlobalResolverOutput {
    id: string;
    arn: string;
    clientToken: string;
    dnsName: string;
    observabilityRegion?: string | undefined;
    name: string;
    description?: string | undefined;
    regions: string[];
    createdAt: Date;
    updatedAt: Date;
    status: CRResourceStatus;
    ipv4Addresses: string[];
    ipv6Addresses?: string[] | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
}
export interface DisableDNSViewInput {
    dnsViewId: string;
}
export interface DisableDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface DisassociateHostedZoneInput {
    hostedZoneId: string;
    resourceArn: string;
}
export interface DisassociateHostedZoneOutput {
    id: string;
    resourceArn: string;
    hostedZoneId: string;
    hostedZoneName: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    status: HostedZoneAssociationStatus;
}
export interface EnableDNSViewInput {
    dnsViewId: string;
}
export interface EnableDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface GetAccessSourceInput {
    accessSourceId: string;
}
export interface GetAccessSourceOutput {
    arn: string;
    cidr: string;
    createdAt: Date;
    id: string;
    ipAddressType: IpAddressType;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface GetAccessTokenInput {
    accessTokenId: string;
}
export interface GetAccessTokenOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    createdAt: Date;
    dnsViewId: string;
    expiresAt: Date;
    globalResolverId: string;
    name?: string | undefined;
    status: TokenStatus;
    updatedAt: Date;
    value: string | redacted.Redacted<string>;
}
export interface GetDNSViewInput {
    dnsViewId: string;
}
export interface GetDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface GetFirewallDomainListInput {
    firewallDomainListId: string;
}
export interface GetFirewallDomainListOutput {
    arn: string;
    globalResolverId: string;
    clientToken?: string | undefined;
    createdAt: Date;
    description?: string | undefined;
    domainCount: number;
    id: string;
    name: string;
    status: CRResourceStatus;
    statusMessage?: string | undefined;
    updatedAt: Date;
}
export interface GetFirewallRuleInput {
    firewallRuleId: string;
}
export interface GetFirewallRuleOutput {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt: Date;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name: string;
    priority: number;
    dnsViewId: string;
    queryType?: string | undefined;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface GetGlobalResolverInput {
    globalResolverId: string;
}
export interface GetGlobalResolverOutput {
    id: string;
    arn: string;
    clientToken: string;
    dnsName: string;
    observabilityRegion?: string | undefined;
    name: string;
    description?: string | undefined;
    regions: string[];
    createdAt: Date;
    updatedAt: Date;
    status: CRResourceStatus;
    ipv4Addresses: string[];
    ipv6Addresses?: string[] | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
}
export interface GetHostedZoneAssociationInput {
    hostedZoneAssociationId: string;
}
export interface GetHostedZoneAssociationOutput {
    id: string;
    resourceArn: string;
    hostedZoneId: string;
    hostedZoneName: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    status: HostedZoneAssociationStatus;
}
export interface GetManagedFirewallDomainListInput {
    managedFirewallDomainListId: string;
}
export interface GetManagedFirewallDomainListOutput {
    description?: string | undefined;
    id: string;
    name: string;
    managedListType: string;
}
export interface ImportFirewallDomainsInput {
    domainFileUrl: string;
    firewallDomainListId: string;
    operation: string;
}
export interface ImportFirewallDomainsOutput {
    id: string;
    name: string;
    status: CRResourceStatus;
}
export type Strings = string[];
export type Filters = {
    [key: string]: string[] | undefined;
};
export interface ListAccessSourcesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface AccessSourcesItem {
    arn: string;
    cidr: string;
    createdAt: Date;
    id: string;
    ipAddressType: IpAddressType;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    status: CRResourceStatus;
    updatedAt: Date;
}
export type AccessSources = AccessSourcesItem[];
export interface ListAccessSourcesOutput {
    nextToken?: string | undefined;
    accessSources: AccessSourcesItem[];
}
export interface ListAccessTokensInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    dnsViewId: string;
    filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface AccessTokenItem {
    id: string;
    arn: string;
    createdAt: Date;
    dnsViewId: string;
    expiresAt: Date;
    globalResolverId: string;
    name?: string | undefined;
    status: TokenStatus;
    updatedAt: Date;
}
export type AccessTokens = AccessTokenItem[];
export interface ListAccessTokensOutput {
    nextToken?: string | undefined;
    accessTokens?: AccessTokenItem[] | undefined;
}
export interface ListDNSViewsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    globalResolverId: string;
}
export interface DNSViewSummary {
    id: string;
    arn: string;
    clientToken: string;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export type DNSViews = DNSViewSummary[];
export interface ListDNSViewsOutput {
    nextToken?: string | undefined;
    dnsViews: DNSViewSummary[];
}
export interface ListFirewallDomainListsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    globalResolverId?: string | undefined;
}
export interface FirewallDomainListsItem {
    arn: string;
    globalResolverId: string;
    createdAt: Date;
    description?: string | undefined;
    id: string;
    name: string;
    status: CRResourceStatus;
    updatedAt: Date;
}
export type FirewallDomainLists = FirewallDomainListsItem[];
export interface ListFirewallDomainListsOutput {
    nextToken?: string | undefined;
    firewallDomainLists: FirewallDomainListsItem[];
}
export interface ListFirewallDomainsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    firewallDomainListId: string;
}
export type Domains = string[];
export interface ListFirewallDomainsOutput {
    nextToken?: string | undefined;
    domains: string[];
}
export interface ListFirewallRulesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    dnsViewId: string;
    filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface FirewallRulesItem {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt: Date;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name: string;
    priority: number;
    dnsViewId: string;
    queryType?: string | undefined;
    status: CRResourceStatus;
    updatedAt: Date;
}
export type FirewallRules = FirewallRulesItem[];
export interface ListFirewallRulesOutput {
    nextToken?: string | undefined;
    firewallRules: FirewallRulesItem[];
}
export interface ListGlobalResolversInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GlobalResolversItem {
    id: string;
    arn: string;
    clientToken: string;
    dnsName: string;
    observabilityRegion?: string | undefined;
    name: string;
    description?: string | undefined;
    regions: string[];
    createdAt: Date;
    updatedAt: Date;
    status: CRResourceStatus;
    ipv4Addresses: string[];
    ipv6Addresses?: string[] | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
}
export type GlobalResolvers = GlobalResolversItem[];
export interface ListGlobalResolversOutput {
    nextToken?: string | undefined;
    globalResolvers: GlobalResolversItem[];
}
export interface ListHostedZoneAssociationsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    resourceArn?: string | undefined;
}
export interface HostedZoneAssociationSummary {
    id: string;
    resourceArn: string;
    hostedZoneId: string;
    hostedZoneName: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    status: HostedZoneAssociationStatus;
}
export type HostedZoneAssociations = HostedZoneAssociationSummary[];
export interface ListHostedZoneAssociationsOutput {
    nextToken?: string | undefined;
    hostedZoneAssociations: HostedZoneAssociationSummary[];
}
export interface ListManagedFirewallDomainListsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    managedFirewallDomainListType: string;
}
export interface ManagedFirewallDomainListsItem {
    description?: string | undefined;
    id: string;
    name: string;
    managedListType: string;
}
export type ManagedFirewallDomainLists = ManagedFirewallDomainListsItem[];
export interface ListManagedFirewallDomainListsOutput {
    nextToken?: string | undefined;
    managedFirewallDomainLists: ManagedFirewallDomainListsItem[];
}
export interface ListSharedDNSViewsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AccountId = string;
export interface SharedDNSViewSummary {
    id: string;
    arn: string;
    clientToken: string;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
    ownerAccountId: string;
}
export type SharedDNSViews = SharedDNSViewSummary[];
export interface ListSharedDNSViewsOutput {
    nextToken?: string | undefined;
    dnsViews: SharedDNSViewSummary[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessSourceInput {
    accessSourceId: string;
    cidr?: string | undefined;
    ipAddressType?: IpAddressType | undefined;
    name?: string | undefined;
    protocol?: DnsProtocol | undefined;
}
export interface UpdateAccessSourceOutput {
    arn: string;
    cidr: string;
    createdAt: Date;
    id: string;
    ipAddressType: IpAddressType;
    name?: string | undefined;
    dnsViewId: string;
    protocol: DnsProtocol;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface UpdateAccessTokenInput {
    accessTokenId: string;
    name: string;
}
export interface UpdateAccessTokenOutput {
    id: string;
    name: string;
}
export interface UpdateDNSViewInput {
    dnsViewId: string;
    name?: string | undefined;
    description?: string | undefined;
    dnssecValidation?: DnsSecValidationType | undefined;
    ednsClientSubnet?: EdnsClientSubnetType | undefined;
    firewallRulesFailOpen?: FirewallRulesFailOpenType | undefined;
}
export interface UpdateDNSViewOutput {
    id: string;
    arn: string;
    clientToken?: string | undefined;
    dnssecValidation: DnsSecValidationType;
    ednsClientSubnet: EdnsClientSubnetType;
    firewallRulesFailOpen: FirewallRulesFailOpenType;
    name: string;
    description?: string | undefined;
    globalResolverId: string;
    createdAt: Date;
    updatedAt: Date;
    status: ProfileResourceStatus;
}
export interface UpdateFirewallDomainsInput {
    domains: string[];
    firewallDomainListId: string;
    operation: string;
}
export interface UpdateFirewallDomainsOutput {
    id: string;
    name: string;
    status: CRResourceStatus;
}
export interface UpdateFirewallRuleInput {
    action?: FirewallRuleAction | undefined;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    clientToken: string;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallRuleId: string;
    name?: string | undefined;
    priority?: number | undefined;
}
export interface UpdateFirewallRuleOutput {
    action: FirewallRuleAction;
    blockOverrideDnsType?: BlockOverrideDnsQueryType | undefined;
    blockOverrideDomain?: string | undefined;
    blockOverrideTtl?: number | undefined;
    blockResponse?: FirewallBlockResponse | undefined;
    confidenceThreshold?: ConfidenceThreshold | undefined;
    createdAt: Date;
    description?: string | undefined;
    dnsAdvancedProtection?: DnsAdvancedProtection | undefined;
    firewallDomainListId?: string | undefined;
    id: string;
    name: string;
    priority: number;
    dnsViewId: string;
    queryType?: string | undefined;
    status: CRResourceStatus;
    updatedAt: Date;
}
export interface UpdateGlobalResolverInput {
    globalResolverId: string;
    name?: string | undefined;
    observabilityRegion?: string | undefined;
    description?: string | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
    regions?: string[] | undefined;
}
export interface UpdateGlobalResolverOutput {
    id: string;
    arn: string;
    clientToken: string;
    dnsName: string;
    observabilityRegion?: string | undefined;
    name: string;
    description?: string | undefined;
    regions: string[];
    createdAt: Date;
    updatedAt: Date;
    status: CRResourceStatus;
    ipv4Addresses: string[];
    ipv6Addresses?: string[] | undefined;
    ipAddressType?: GlobalResolverIpAddressType | undefined;
}
export interface UpdateHostedZoneAssociationInput {
    hostedZoneAssociationId: string;
    name?: string | undefined;
}
export interface UpdateHostedZoneAssociationOutput {
    id: string;
    resourceArn: string;
    hostedZoneId: string;
    hostedZoneName: string;
    name: string;
    createdAt: Date;
    updatedAt: Date;
    status: HostedZoneAssociationStatus;
}
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateHostedZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a Route 53 private hosted zone with a Route 53 Global Resolver resource. This allows the resolver to resolve DNS queries for the private hosted zone from anywhere globally.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const associateHostedZone: API.OperationMethod<AssociateHostedZoneInput & RegionInput, AssociateHostedZoneOutput, AssociateHostedZoneError, Credentials | HttpClient.HttpClient>;
export type BatchCreateFirewallRuleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates multiple DNS firewall rules in a single operation. This is more efficient than creating rules individually when you need to set up multiple rules at once.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const batchCreateFirewallRule: API.OperationMethod<BatchCreateFirewallRuleInput & RegionInput, BatchCreateFirewallRuleOutput, BatchCreateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteFirewallRuleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes multiple DNS firewall rules in a single operation. This is more efficient than deleting rules individually.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const batchDeleteFirewallRule: API.OperationMethod<BatchDeleteFirewallRuleInput & RegionInput, BatchDeleteFirewallRuleOutput, BatchDeleteFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFirewallRuleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates multiple DNS firewall rules in a single operation. This is more efficient than updating rules individually.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const batchUpdateFirewallRule: API.OperationMethod<BatchUpdateFirewallRuleInput & RegionInput, BatchUpdateFirewallRuleOutput, BatchUpdateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAccessSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access source for a DNS view. Access sources define IP addresses or CIDR ranges that are allowed to send DNS queries to the Route 53 Global Resolver, along with the permitted DNS protocols.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createAccessSource: API.OperationMethod<CreateAccessSourceInput & RegionInput, CreateAccessSourceOutput, CreateAccessSourceError, Credentials | HttpClient.HttpClient>;
export type CreateAccessTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an access token for a DNS view. Access tokens provide token-based authentication for DNS-over-HTTPS (DoH) and DNS-over-TLS (DoT) connections to the Route 53 Global Resolver.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createAccessToken: API.OperationMethod<CreateAccessTokenInput & RegionInput, CreateAccessTokenOutput, CreateAccessTokenError, Credentials | HttpClient.HttpClient>;
export type CreateDNSViewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a DNS view within a Route 53 Global Resolver. A DNS view models end users, user groups, networks, and devices, and serves as a parent resource that holds configurations controlling access, authorization, DNS firewall rules, and forwarding rules.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createDNSView: API.OperationMethod<CreateDNSViewInput & RegionInput, CreateDNSViewOutput, CreateDNSViewError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallDomainListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a firewall domain list. Domain lists are reusable sets of domain specifications that you use in DNS firewall rules to allow, block, or alert on DNS queries to specific domains.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createFirewallDomainList: API.OperationMethod<CreateFirewallDomainListInput & RegionInput, CreateFirewallDomainListOutput, CreateFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a DNS firewall rule. Firewall rules define actions (ALLOW, BLOCK, or ALERT) to take on DNS queries that match specified domain lists, managed domain lists, or advanced threat protections.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createFirewallRule: API.OperationMethod<CreateFirewallRuleInput & RegionInput, CreateFirewallRuleOutput, CreateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalResolverError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Route 53 Global Resolver instance. A Route 53 Global Resolver is a global, internet-accessible DNS resolver that provides secure DNS resolution for both public and private domains through global anycast IP addresses.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const createGlobalResolver: API.OperationMethod<CreateGlobalResolverInput & RegionInput, CreateGlobalResolverOutput, CreateGlobalResolverError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an access source. This operation cannot be undone.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteAccessSource: API.OperationMethod<DeleteAccessSourceInput & RegionInput, DeleteAccessSourceOutput, DeleteAccessSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an access token. This operation cannot be undone.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteAccessToken: API.OperationMethod<DeleteAccessTokenInput & RegionInput, DeleteAccessTokenOutput, DeleteAccessTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteDNSViewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a DNS view. This operation cannot be undone.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteDNSView: API.OperationMethod<DeleteDNSViewInput & RegionInput, DeleteDNSViewOutput, DeleteDNSViewError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallDomainListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a firewall domain list. This operation cannot be undone.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteFirewallDomainList: API.OperationMethod<DeleteFirewallDomainListInput & RegionInput, DeleteFirewallDomainListOutput, DeleteFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a DNS firewall rule. This operation cannot be undone.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteFirewallRule: API.OperationMethod<DeleteFirewallRuleInput & RegionInput, DeleteFirewallRuleOutput, DeleteFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalResolverError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Route 53 Global Resolver instance. This operation cannot be undone. All associated DNS views, access sources, tokens, and firewall rules are also deleted.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const deleteGlobalResolver: API.OperationMethod<DeleteGlobalResolverInput & RegionInput, DeleteGlobalResolverOutput, DeleteGlobalResolverError, Credentials | HttpClient.HttpClient>;
export type DisableDNSViewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables a DNS view, preventing it from serving DNS queries.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const disableDNSView: API.OperationMethod<DisableDNSViewInput & RegionInput, DisableDNSViewOutput, DisableDNSViewError, Credentials | HttpClient.HttpClient>;
export type DisassociateHostedZoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a Route 53 private hosted zone from a Route 53 Global Resolver resource.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const disassociateHostedZone: API.OperationMethod<DisassociateHostedZoneInput & RegionInput, DisassociateHostedZoneOutput, DisassociateHostedZoneError, Credentials | HttpClient.HttpClient>;
export type EnableDNSViewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables a disabled DNS view, allowing it to serve DNS queries again.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const enableDNSView: API.OperationMethod<EnableDNSViewInput & RegionInput, EnableDNSViewOutput, EnableDNSViewError, Credentials | HttpClient.HttpClient>;
export type GetAccessSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an access source.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getAccessSource: API.OperationMethod<GetAccessSourceInput & RegionInput, GetAccessSourceOutput, GetAccessSourceError, Credentials | HttpClient.HttpClient>;
export type GetAccessTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an access token.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getAccessToken: API.OperationMethod<GetAccessTokenInput & RegionInput, GetAccessTokenOutput, GetAccessTokenError, Credentials | HttpClient.HttpClient>;
export type GetDNSViewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a DNS view.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getDNSView: API.OperationMethod<GetDNSViewInput & RegionInput, GetDNSViewOutput, GetDNSViewError, Credentials | HttpClient.HttpClient>;
export type GetFirewallDomainListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a firewall domain list.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getFirewallDomainList: API.OperationMethod<GetFirewallDomainListInput & RegionInput, GetFirewallDomainListOutput, GetFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type GetFirewallRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a DNS firewall rule.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getFirewallRule: API.OperationMethod<GetFirewallRuleInput & RegionInput, GetFirewallRuleOutput, GetFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type GetGlobalResolverError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a Route 53 Global Resolver instance.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getGlobalResolver: API.OperationMethod<GetGlobalResolverInput & RegionInput, GetGlobalResolverOutput, GetGlobalResolverError, Credentials | HttpClient.HttpClient>;
export type GetHostedZoneAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a hosted zone association.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getHostedZoneAssociation: API.OperationMethod<GetHostedZoneAssociationInput & RegionInput, GetHostedZoneAssociationOutput, GetHostedZoneAssociationError, Credentials | HttpClient.HttpClient>;
export type GetManagedFirewallDomainListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an Amazon Web Services-managed firewall domain list. Managed domain lists contain domains associated with malicious activity, content categories, or specific threats.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const getManagedFirewallDomainList: API.OperationMethod<GetManagedFirewallDomainListInput & RegionInput, GetManagedFirewallDomainListOutput, GetManagedFirewallDomainListError, Credentials | HttpClient.HttpClient>;
export type ImportFirewallDomainsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports a list of domains from an Amazon S3 file into a firewall domain list. The file should contain one domain per line.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const importFirewallDomains: API.OperationMethod<ImportFirewallDomainsInput & RegionInput, ImportFirewallDomainsOutput, ImportFirewallDomainsError, Credentials | HttpClient.HttpClient>;
export type ListAccessSourcesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all access sources with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listAccessSources: API.PaginatedOperationMethod<ListAccessSourcesInput & RegionInput, ListAccessSourcesOutput, ListAccessSourcesError, Credentials | HttpClient.HttpClient, AccessSourcesItem>;
export type ListAccessTokensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all access tokens for a DNS view with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listAccessTokens: API.PaginatedOperationMethod<ListAccessTokensInput & RegionInput, ListAccessTokensOutput, ListAccessTokensError, Credentials | HttpClient.HttpClient, AccessTokenItem>;
export type ListDNSViewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all DNS views for a Route 53 Global Resolver with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listDNSViews: API.PaginatedOperationMethod<ListDNSViewsInput & RegionInput, ListDNSViewsOutput, ListDNSViewsError, Credentials | HttpClient.HttpClient, DNSViewSummary>;
export type ListFirewallDomainListsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all firewall domain lists for a Route 53 Global Resolver with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listFirewallDomainLists: API.PaginatedOperationMethod<ListFirewallDomainListsInput & RegionInput, ListFirewallDomainListsOutput, ListFirewallDomainListsError, Credentials | HttpClient.HttpClient, FirewallDomainListsItem>;
export type ListFirewallDomainsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the domains in DNS Firewall domain list you have created.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listFirewallDomains: API.PaginatedOperationMethod<ListFirewallDomainsInput & RegionInput, ListFirewallDomainsOutput, ListFirewallDomainsError, Credentials | HttpClient.HttpClient, Domain>;
export type ListFirewallRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all DNS firewall rules for a DNS view with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listFirewallRules: API.PaginatedOperationMethod<ListFirewallRulesInput & RegionInput, ListFirewallRulesOutput, ListFirewallRulesError, Credentials | HttpClient.HttpClient, FirewallRulesItem>;
export type ListGlobalResolversError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Route 53 Global Resolver instances in your account with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listGlobalResolvers: API.PaginatedOperationMethod<ListGlobalResolversInput & RegionInput, ListGlobalResolversOutput, ListGlobalResolversError, Credentials | HttpClient.HttpClient, GlobalResolversItem>;
export type ListHostedZoneAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists hosted zone associations with pagination support. Specify a DNS view through the `resourceArn` parameter to list the hosted zone associations for that DNS view, or omit it to list all hosted zone associations in your Amazon Web Services account.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listHostedZoneAssociations: API.PaginatedOperationMethod<ListHostedZoneAssociationsInput & RegionInput, ListHostedZoneAssociationsOutput, ListHostedZoneAssociationsError, Credentials | HttpClient.HttpClient, HostedZoneAssociationSummary>;
export type ListManagedFirewallDomainListsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of the Amazon Web Services Managed DNS Lists and the categories for DNS Firewall. The categories are either `THREAT` or `CONTENT`.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listManagedFirewallDomainLists: API.PaginatedOperationMethod<ListManagedFirewallDomainListsInput & RegionInput, ListManagedFirewallDomainListsOutput, ListManagedFirewallDomainListsError, Credentials | HttpClient.HttpClient, ManagedFirewallDomainListsItem>;
export type ListSharedDNSViewsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the DNS views that have been shared with your Amazon Web Services account through Amazon Web Services Resource Access Manager (Amazon Web Services RAM), with pagination support.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listSharedDNSViews: API.PaginatedOperationMethod<ListSharedDNSViewsInput & RegionInput, ListSharedDNSViewsOutput, ListSharedDNSViewsError, Credentials | HttpClient.HttpClient, SharedDNSViewSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags associated with a Route 53 Global Resolver resource.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a Route 53 Global Resolver resource. Tags are key-value pairs that help you organize and identify your resources.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from a Route 53 Global Resolver resource.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an access source.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateAccessSource: API.OperationMethod<UpdateAccessSourceInput & RegionInput, UpdateAccessSourceOutput, UpdateAccessSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessTokenError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an access token.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateAccessToken: API.OperationMethod<UpdateAccessTokenInput & RegionInput, UpdateAccessTokenOutput, UpdateAccessTokenError, Credentials | HttpClient.HttpClient>;
export type UpdateDNSViewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a DNS view.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateDNSView: API.OperationMethod<UpdateDNSViewInput & RegionInput, UpdateDNSViewOutput, UpdateDNSViewError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallDomainsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a DNS Firewall domain list from an array of specified domains.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateFirewallDomains: API.OperationMethod<UpdateFirewallDomainsInput & RegionInput, UpdateFirewallDomainsOutput, UpdateFirewallDomainsError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a DNS firewall rule.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateFirewallRule: API.OperationMethod<UpdateFirewallRuleInput & RegionInput, UpdateFirewallRuleOutput, UpdateFirewallRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalResolverError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a Route 53 Global Resolver instance. You can modify the name, description, and observability Region.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateGlobalResolver: API.OperationMethod<UpdateGlobalResolverInput & RegionInput, UpdateGlobalResolverOutput, UpdateGlobalResolverError, Credentials | HttpClient.HttpClient>;
export type UpdateHostedZoneAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a hosted zone association.
 *
 * Route 53 Global Resolver is a global service that supports resolvers in multiple Amazon Web Services Regions but you must specify the US East (Ohio) Region to create, update, or otherwise work with Route 53 Global Resolver resources. That is, for example, specify `--region us-east-2` on Amazon Web Services CLI commands.
 */
export declare const updateHostedZoneAssociation: API.OperationMethod<UpdateHostedZoneAssociationInput & RegionInput, UpdateHostedZoneAssociationOutput, UpdateHostedZoneAssociationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=route53globalresolver.d.ts.map