import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DuplicateResourceException_base: S.TaggedErrorClass<"DuplicateResourceException", {
    readonly message: any;
}>;
export declare class DuplicateResourceException extends /*@__PURE__*/ DuplicateResourceException_base {
}
declare const InvalidParametersException_base: S.TaggedErrorClass<"InvalidParametersException", {
    readonly message: any;
}>;
export declare class InvalidParametersException extends /*@__PURE__*/ InvalidParametersException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OperationNotSupportedException_base: S.TaggedErrorClass<"OperationNotSupportedException", {
    readonly message: any;
}>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const ProvisionedProductNotFound_base: S.TaggedErrorClass<"ProvisionedProductNotFound", {
    readonly message: any;
}>;
export declare class ProvisionedProductNotFound extends /*@__PURE__*/ ProvisionedProductNotFound_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TagOptionNotMigratedException_base: S.TaggedErrorClass<"TagOptionNotMigratedException", {
    readonly message: any;
}>;
export declare class TagOptionNotMigratedException extends /*@__PURE__*/ TagOptionNotMigratedException_base {
}
export type AcceptLanguage = string;
export type Id = string;
export type PortfolioShareType = "IMPORTED" | "AWS_SERVICECATALOG" | "AWS_ORGANIZATIONS" | (string & {});
export interface AcceptPortfolioShareInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    PortfolioShareType?: PortfolioShareType | undefined;
}
export interface AcceptPortfolioShareOutput {
}
export type BudgetName = string;
export interface AssociateBudgetWithResourceInput {
    BudgetName: string;
    ResourceId: string;
}
export interface AssociateBudgetWithResourceOutput {
}
export type PrincipalARN = string;
export type PrincipalType = "IAM" | "IAM_PATTERN" | (string & {});
export interface AssociatePrincipalWithPortfolioInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    PrincipalARN: string;
    PrincipalType: PrincipalType;
}
export interface AssociatePrincipalWithPortfolioOutput {
}
export interface AssociateProductWithPortfolioInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    PortfolioId: string;
    SourcePortfolioId?: string | undefined;
}
export interface AssociateProductWithPortfolioOutput {
}
export type IdempotencyToken = string;
export interface AssociateServiceActionWithProvisioningArtifactInput {
    ProductId: string;
    ProvisioningArtifactId: string;
    ServiceActionId: string;
    AcceptLanguage?: string | undefined;
    IdempotencyToken?: string | undefined;
}
export interface AssociateServiceActionWithProvisioningArtifactOutput {
}
export type ResourceId = string;
export type TagOptionId = string;
export interface AssociateTagOptionWithResourceInput {
    ResourceId: string;
    TagOptionId: string;
}
export interface AssociateTagOptionWithResourceOutput {
}
export interface ServiceActionAssociation {
    ServiceActionId: string;
    ProductId: string;
    ProvisioningArtifactId: string;
}
export type ServiceActionAssociations = ServiceActionAssociation[];
export interface BatchAssociateServiceActionWithProvisioningArtifactInput {
    ServiceActionAssociations: ServiceActionAssociation[];
    AcceptLanguage?: string | undefined;
}
export type ServiceActionAssociationErrorCode = "DUPLICATE_RESOURCE" | "INTERNAL_FAILURE" | "LIMIT_EXCEEDED" | "RESOURCE_NOT_FOUND" | "THROTTLING" | "INVALID_PARAMETER" | (string & {});
export type ServiceActionAssociationErrorMessage = string;
export interface FailedServiceActionAssociation {
    ServiceActionId?: string | undefined;
    ProductId?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ErrorCode?: ServiceActionAssociationErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type FailedServiceActionAssociations = FailedServiceActionAssociation[];
export interface BatchAssociateServiceActionWithProvisioningArtifactOutput {
    FailedServiceActionAssociations?: FailedServiceActionAssociation[] | undefined;
}
export interface BatchDisassociateServiceActionFromProvisioningArtifactInput {
    ServiceActionAssociations: ServiceActionAssociation[];
    AcceptLanguage?: string | undefined;
}
export interface BatchDisassociateServiceActionFromProvisioningArtifactOutput {
    FailedServiceActionAssociations?: FailedServiceActionAssociation[] | undefined;
}
export type ProductArn = string;
export type ProductViewName = string;
export type ProvisioningArtifactPropertyName = "Id" | (string & {});
export type ProvisioningArtifactPropertyValue = string;
export type SourceProvisioningArtifactPropertiesMap = {
    [key in ProvisioningArtifactPropertyName]?: string | undefined;
};
export type SourceProvisioningArtifactProperties = {
    [key: string]: string | undefined;
}[];
export type CopyOption = "CopyTags" | (string & {});
export type CopyOptions = CopyOption[];
export interface CopyProductInput {
    AcceptLanguage?: string | undefined;
    SourceProductArn: string;
    TargetProductId?: string | undefined;
    TargetProductName?: string | undefined;
    SourceProvisioningArtifactIdentifiers?: {
        [key: string]: string | undefined;
    }[] | undefined;
    CopyOptions?: CopyOption[] | undefined;
    IdempotencyToken: string;
}
export interface CopyProductOutput {
    CopyProductToken?: string | undefined;
}
export type ConstraintParameters = string;
export type ConstraintType = string;
export type ConstraintDescription = string;
export interface CreateConstraintInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    ProductId: string;
    Parameters: string;
    Type: string;
    Description?: string | undefined;
    IdempotencyToken: string;
}
export type AccountId = string;
export interface ConstraintDetail {
    ConstraintId?: string | undefined;
    Type?: string | undefined;
    Description?: string | undefined;
    Owner?: string | undefined;
    ProductId?: string | undefined;
    PortfolioId?: string | undefined;
}
export type Status = "AVAILABLE" | "CREATING" | "FAILED" | (string & {});
export interface CreateConstraintOutput {
    ConstraintDetail?: ConstraintDetail | undefined;
    ConstraintParameters?: string | undefined;
    Status?: Status | undefined;
}
export type PortfolioDisplayName = string;
export type PortfolioDescription = string;
export type ProviderName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type AddTags = Tag[];
export interface CreatePortfolioInput {
    AcceptLanguage?: string | undefined;
    DisplayName: string;
    Description?: string | undefined;
    ProviderName: string;
    Tags?: Tag[] | undefined;
    IdempotencyToken: string;
}
export type ResourceARN = string;
export type CreationTime = Date;
export interface PortfolioDetail {
    Id?: string | undefined;
    ARN?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    CreatedTime?: Date | undefined;
    ProviderName?: string | undefined;
}
export type Tags = Tag[];
export interface CreatePortfolioOutput {
    PortfolioDetail?: PortfolioDetail | undefined;
    Tags?: Tag[] | undefined;
}
export type OrganizationNodeType = "ORGANIZATION" | "ORGANIZATIONAL_UNIT" | "ACCOUNT" | (string & {});
export type OrganizationNodeValue = string;
export interface OrganizationNode {
    Type?: OrganizationNodeType | undefined;
    Value?: string | undefined;
}
export interface CreatePortfolioShareInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    AccountId?: string | undefined;
    OrganizationNode?: OrganizationNode | undefined;
    ShareTagOptions?: boolean | undefined;
    SharePrincipals?: boolean | undefined;
}
export interface CreatePortfolioShareOutput {
    PortfolioShareToken?: string | undefined;
}
export type ProductViewOwner = string;
export type ProductViewShortDescription = string;
export type SupportDescription = string;
export type SupportEmail = string;
export type SupportUrl = string;
export type ProductType = "CLOUD_FORMATION_TEMPLATE" | "MARKETPLACE" | "TERRAFORM_OPEN_SOURCE" | "TERRAFORM_CLOUD" | "EXTERNAL" | (string & {});
export type ProvisioningArtifactName = string;
export type ProvisioningArtifactDescription = string;
export type ProvisioningArtifactInfoKey = string;
export type ProvisioningArtifactInfoValue = string;
export type ProvisioningArtifactInfo = {
    [key: string]: string | undefined;
};
export type ProvisioningArtifactType = "CLOUD_FORMATION_TEMPLATE" | "MARKETPLACE_AMI" | "MARKETPLACE_CAR" | "TERRAFORM_OPEN_SOURCE" | "TERRAFORM_CLOUD" | "EXTERNAL" | (string & {});
export type DisableTemplateValidation = boolean;
export interface ProvisioningArtifactProperties {
    Name?: string | undefined;
    Description?: string | undefined;
    Info?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: ProvisioningArtifactType | undefined;
    DisableTemplateValidation?: boolean | undefined;
}
export type SourceType = "CODESTAR" | (string & {});
export type CodeStarConnectionArn = string;
export type Repository = string;
export type RepositoryBranch = string;
export type RepositoryArtifactPath = string;
export interface CodeStarParameters {
    ConnectionArn: string;
    Repository: string;
    Branch: string;
    ArtifactPath: string;
}
export interface SourceConnectionParameters {
    CodeStar?: CodeStarParameters | undefined;
}
export interface SourceConnection {
    Type?: SourceType | undefined;
    ConnectionParameters: SourceConnectionParameters;
}
export interface CreateProductInput {
    AcceptLanguage?: string | undefined;
    Name: string;
    Owner: string;
    Description?: string | undefined;
    Distributor?: string | undefined;
    SupportDescription?: string | undefined;
    SupportEmail?: string | undefined;
    SupportUrl?: string | undefined;
    ProductType: ProductType;
    Tags?: Tag[] | undefined;
    ProvisioningArtifactParameters?: ProvisioningArtifactProperties | undefined;
    IdempotencyToken: string;
    SourceConnection?: SourceConnection | undefined;
}
export type ProductViewDistributor = string;
export type HasDefaultPath = boolean;
export interface ProductViewSummary {
    Id?: string | undefined;
    ProductId?: string | undefined;
    Name?: string | undefined;
    Owner?: string | undefined;
    ShortDescription?: string | undefined;
    Type?: ProductType | undefined;
    Distributor?: string | undefined;
    HasDefaultPath?: boolean | undefined;
    SupportEmail?: string | undefined;
    SupportDescription?: string | undefined;
    SupportUrl?: string | undefined;
}
export type CreatedTime = Date;
export type LastSyncTime = Date;
export type LastSyncStatus = "SUCCEEDED" | "FAILED" | (string & {});
export type LastSyncStatusMessage = string;
export type LastSuccessfulSyncTime = Date;
export interface LastSync {
    LastSyncTime?: Date | undefined;
    LastSyncStatus?: LastSyncStatus | undefined;
    LastSyncStatusMessage?: string | undefined;
    LastSuccessfulSyncTime?: Date | undefined;
    LastSuccessfulSyncProvisioningArtifactId?: string | undefined;
}
export interface SourceConnectionDetail {
    Type?: SourceType | undefined;
    ConnectionParameters?: SourceConnectionParameters | undefined;
    LastSync?: LastSync | undefined;
}
export interface ProductViewDetail {
    ProductViewSummary?: ProductViewSummary | undefined;
    Status?: Status | undefined;
    ProductARN?: string | undefined;
    CreatedTime?: Date | undefined;
    SourceConnection?: SourceConnectionDetail | undefined;
}
export type ProvisioningArtifactActive = boolean;
export type ProvisioningArtifactGuidance = "DEFAULT" | "DEPRECATED" | (string & {});
export type SourceRevision = string;
export interface ProvisioningArtifactDetail {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Type?: ProvisioningArtifactType | undefined;
    CreatedTime?: Date | undefined;
    Active?: boolean | undefined;
    Guidance?: ProvisioningArtifactGuidance | undefined;
    SourceRevision?: string | undefined;
}
export interface CreateProductOutput {
    ProductViewDetail?: ProductViewDetail | undefined;
    ProvisioningArtifactDetail?: ProvisioningArtifactDetail | undefined;
    Tags?: Tag[] | undefined;
}
export type ProvisionedProductPlanName = string;
export type ProvisionedProductPlanType = "CLOUDFORMATION" | (string & {});
export type NotificationArn = string;
export type NotificationArns = string[];
export type ProvisionedProductName = string;
export type ParameterKey = string;
export type ParameterValue = string;
export type UsePreviousValue = boolean;
export interface UpdateProvisioningParameter {
    Key?: string | undefined;
    Value?: string | undefined;
    UsePreviousValue?: boolean | undefined;
}
export type UpdateProvisioningParameters = UpdateProvisioningParameter[];
export interface CreateProvisionedProductPlanInput {
    AcceptLanguage?: string | undefined;
    PlanName: string;
    PlanType: ProvisionedProductPlanType;
    NotificationArns?: string[] | undefined;
    PathId?: string | undefined;
    ProductId: string;
    ProvisionedProductName: string;
    ProvisioningArtifactId: string;
    ProvisioningParameters?: UpdateProvisioningParameter[] | undefined;
    IdempotencyToken: string;
    Tags?: Tag[] | undefined;
}
export interface CreateProvisionedProductPlanOutput {
    PlanName?: string | undefined;
    PlanId?: string | undefined;
    ProvisionProductId?: string | undefined;
    ProvisionedProductName?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
}
export interface CreateProvisioningArtifactInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    Parameters: ProvisioningArtifactProperties;
    IdempotencyToken: string;
}
export interface CreateProvisioningArtifactOutput {
    ProvisioningArtifactDetail?: ProvisioningArtifactDetail | undefined;
    Info?: {
        [key: string]: string | undefined;
    } | undefined;
    Status?: Status | undefined;
}
export type ServiceActionName = string;
export type ServiceActionDefinitionType = "SSM_AUTOMATION" | (string & {});
export type ServiceActionDefinitionKey = "Name" | "Version" | "AssumeRole" | "Parameters" | (string & {});
export type ServiceActionDefinitionValue = string;
export type ServiceActionDefinitionMap = {
    [key in ServiceActionDefinitionKey]?: string | undefined;
};
export type ServiceActionDescription = string;
export interface CreateServiceActionInput {
    Name: string;
    DefinitionType: ServiceActionDefinitionType;
    Definition: {
        [key: string]: string | undefined;
    };
    Description?: string | undefined;
    AcceptLanguage?: string | undefined;
    IdempotencyToken: string;
}
export interface ServiceActionSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    DefinitionType?: ServiceActionDefinitionType | undefined;
}
export interface ServiceActionDetail {
    ServiceActionSummary?: ServiceActionSummary | undefined;
    Definition?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateServiceActionOutput {
    ServiceActionDetail?: ServiceActionDetail | undefined;
}
export type TagOptionKey = string;
export type TagOptionValue = string;
export interface CreateTagOptionInput {
    Key: string;
    Value: string;
}
export type TagOptionActive = boolean;
export type Owner = string;
export interface TagOptionDetail {
    Key?: string | undefined;
    Value?: string | undefined;
    Active?: boolean | undefined;
    Id?: string | undefined;
    Owner?: string | undefined;
}
export interface CreateTagOptionOutput {
    TagOptionDetail?: TagOptionDetail | undefined;
}
export interface DeleteConstraintInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export interface DeleteConstraintOutput {
}
export interface DeletePortfolioInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export interface DeletePortfolioOutput {
}
export interface DeletePortfolioShareInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    AccountId?: string | undefined;
    OrganizationNode?: OrganizationNode | undefined;
}
export interface DeletePortfolioShareOutput {
    PortfolioShareToken?: string | undefined;
}
export interface DeleteProductInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export interface DeleteProductOutput {
}
export type IgnoreErrors = boolean;
export interface DeleteProvisionedProductPlanInput {
    AcceptLanguage?: string | undefined;
    PlanId: string;
    IgnoreErrors?: boolean | undefined;
}
export interface DeleteProvisionedProductPlanOutput {
}
export interface DeleteProvisioningArtifactInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    ProvisioningArtifactId: string;
}
export interface DeleteProvisioningArtifactOutput {
}
export interface DeleteServiceActionInput {
    Id: string;
    AcceptLanguage?: string | undefined;
    IdempotencyToken?: string | undefined;
}
export interface DeleteServiceActionOutput {
}
export interface DeleteTagOptionInput {
    Id: string;
}
export interface DeleteTagOptionOutput {
}
export interface DescribeConstraintInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export interface DescribeConstraintOutput {
    ConstraintDetail?: ConstraintDetail | undefined;
    ConstraintParameters?: string | undefined;
    Status?: Status | undefined;
}
export interface DescribeCopyProductStatusInput {
    AcceptLanguage?: string | undefined;
    CopyProductToken: string;
}
export type CopyProductStatus = "SUCCEEDED" | "IN_PROGRESS" | "FAILED" | (string & {});
export type StatusDetail = string;
export interface DescribeCopyProductStatusOutput {
    CopyProductStatus?: CopyProductStatus | undefined;
    TargetProductId?: string | undefined;
    StatusDetail?: string | undefined;
}
export interface DescribePortfolioInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export type TagOptionDetails = TagOptionDetail[];
export interface BudgetDetail {
    BudgetName?: string | undefined;
}
export type Budgets = BudgetDetail[];
export interface DescribePortfolioOutput {
    PortfolioDetail?: PortfolioDetail | undefined;
    Tags?: Tag[] | undefined;
    TagOptions?: TagOptionDetail[] | undefined;
    Budgets?: BudgetDetail[] | undefined;
}
export type DescribePortfolioShareType = "ACCOUNT" | "ORGANIZATION" | "ORGANIZATIONAL_UNIT" | "ORGANIZATION_MEMBER_ACCOUNT" | (string & {});
export type PageToken = string;
export type PageSizeMax100 = number;
export interface DescribePortfolioSharesInput {
    PortfolioId: string;
    Type: DescribePortfolioShareType;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface PortfolioShareDetail {
    PrincipalId?: string | undefined;
    Type?: DescribePortfolioShareType | undefined;
    Accepted?: boolean | undefined;
    ShareTagOptions?: boolean | undefined;
    SharePrincipals?: boolean | undefined;
}
export type PortfolioShareDetails = PortfolioShareDetail[];
export interface DescribePortfolioSharesOutput {
    NextPageToken?: string | undefined;
    PortfolioShareDetails?: PortfolioShareDetail[] | undefined;
}
export interface DescribePortfolioShareStatusInput {
    PortfolioShareToken: string;
}
export type ShareStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "ERROR" | (string & {});
export type SuccessfulShares = string[];
export type Namespaces = string[];
export type Message = string;
export interface ShareError {
    Accounts?: string[] | undefined;
    Message?: string | undefined;
    Error?: string | undefined;
}
export type ShareErrors = ShareError[];
export interface ShareDetails {
    SuccessfulShares?: string[] | undefined;
    ShareErrors?: ShareError[] | undefined;
}
export interface DescribePortfolioShareStatusOutput {
    PortfolioShareToken?: string | undefined;
    PortfolioId?: string | undefined;
    OrganizationNodeValue?: string | undefined;
    Status?: ShareStatus | undefined;
    ShareDetails?: ShareDetails | undefined;
}
export interface DescribeProductInput {
    AcceptLanguage?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
}
export type ProvisioningArtifactCreatedTime = Date;
export interface ProvisioningArtifact {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedTime?: Date | undefined;
    Guidance?: ProvisioningArtifactGuidance | undefined;
}
export type ProvisioningArtifacts = ProvisioningArtifact[];
export type PortfolioName = string;
export interface LaunchPath {
    Id?: string | undefined;
    Name?: string | undefined;
}
export type LaunchPaths = LaunchPath[];
export interface DescribeProductOutput {
    ProductViewSummary?: ProductViewSummary | undefined;
    ProvisioningArtifacts?: ProvisioningArtifact[] | undefined;
    Budgets?: BudgetDetail[] | undefined;
    LaunchPaths?: LaunchPath[] | undefined;
}
export interface DescribeProductAsAdminInput {
    AcceptLanguage?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    SourcePortfolioId?: string | undefined;
}
export interface ProvisioningArtifactSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedTime?: Date | undefined;
    ProvisioningArtifactMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProvisioningArtifactSummaries = ProvisioningArtifactSummary[];
export interface DescribeProductAsAdminOutput {
    ProductViewDetail?: ProductViewDetail | undefined;
    ProvisioningArtifactSummaries?: ProvisioningArtifactSummary[] | undefined;
    Tags?: Tag[] | undefined;
    TagOptions?: TagOptionDetail[] | undefined;
    Budgets?: BudgetDetail[] | undefined;
}
export interface DescribeProductViewInput {
    AcceptLanguage?: string | undefined;
    Id: string;
}
export interface DescribeProductViewOutput {
    ProductViewSummary?: ProductViewSummary | undefined;
    ProvisioningArtifacts?: ProvisioningArtifact[] | undefined;
}
export interface DescribeProvisionedProductInput {
    AcceptLanguage?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
}
export type ProvisionedProductNameOrArn = string;
export type ProvisionedProductType = string;
export type ProvisionedProductId = string;
export type ProvisionedProductStatus = "AVAILABLE" | "UNDER_CHANGE" | "TAINTED" | "ERROR" | "PLAN_IN_PROGRESS" | (string & {});
export type ProvisionedProductStatusMessage = string;
export type LastRequestId = string;
export type RoleArn = string;
export interface ProvisionedProductDetail {
    Name?: string | undefined;
    Arn?: string | undefined;
    Type?: string | undefined;
    Id?: string | undefined;
    Status?: ProvisionedProductStatus | undefined;
    StatusMessage?: string | undefined;
    CreatedTime?: Date | undefined;
    IdempotencyToken?: string | undefined;
    LastRecordId?: string | undefined;
    LastProvisioningRecordId?: string | undefined;
    LastSuccessfulProvisioningRecordId?: string | undefined;
    ProductId?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    LaunchRoleArn?: string | undefined;
}
export type CloudWatchDashboardName = string;
export interface CloudWatchDashboard {
    Name?: string | undefined;
}
export type CloudWatchDashboards = CloudWatchDashboard[];
export interface DescribeProvisionedProductOutput {
    ProvisionedProductDetail?: ProvisionedProductDetail | undefined;
    CloudWatchDashboards?: CloudWatchDashboard[] | undefined;
}
export type PageSize = number;
export interface DescribeProvisionedProductPlanInput {
    AcceptLanguage?: string | undefined;
    PlanId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type ProvisionedProductPlanStatus = "CREATE_IN_PROGRESS" | "CREATE_SUCCESS" | "CREATE_FAILED" | "EXECUTE_IN_PROGRESS" | "EXECUTE_SUCCESS" | "EXECUTE_FAILED" | (string & {});
export type UpdatedTime = Date;
export type StatusMessage = string;
export interface ProvisionedProductPlanDetails {
    CreatedTime?: Date | undefined;
    PathId?: string | undefined;
    ProductId?: string | undefined;
    PlanName?: string | undefined;
    PlanId?: string | undefined;
    ProvisionProductId?: string | undefined;
    ProvisionProductName?: string | undefined;
    PlanType?: ProvisionedProductPlanType | undefined;
    ProvisioningArtifactId?: string | undefined;
    Status?: ProvisionedProductPlanStatus | undefined;
    UpdatedTime?: Date | undefined;
    NotificationArns?: string[] | undefined;
    ProvisioningParameters?: UpdateProvisioningParameter[] | undefined;
    Tags?: Tag[] | undefined;
    StatusMessage?: string | undefined;
}
export type ChangeAction = "ADD" | "MODIFY" | "REMOVE" | (string & {});
export type LogicalResourceId = string;
export type PhysicalResourceId = string;
export type PlanResourceType = string;
export type Replacement = "TRUE" | "FALSE" | "CONDITIONAL" | (string & {});
export type ResourceAttribute = "PROPERTIES" | "METADATA" | "CREATIONPOLICY" | "UPDATEPOLICY" | "DELETIONPOLICY" | "TAGS" | (string & {});
export type Scope = ResourceAttribute[];
export type PropertyName = string;
export type RequiresRecreation = "NEVER" | "CONDITIONALLY" | "ALWAYS" | (string & {});
export interface ResourceTargetDefinition {
    Attribute?: ResourceAttribute | undefined;
    Name?: string | undefined;
    RequiresRecreation?: RequiresRecreation | undefined;
}
export type EvaluationType = "STATIC" | "DYNAMIC" | (string & {});
export type CausingEntity = string;
export interface ResourceChangeDetail {
    Target?: ResourceTargetDefinition | undefined;
    Evaluation?: EvaluationType | undefined;
    CausingEntity?: string | undefined;
}
export type ResourceChangeDetails = ResourceChangeDetail[];
export interface ResourceChange {
    Action?: ChangeAction | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Replacement?: Replacement | undefined;
    Scope?: ResourceAttribute[] | undefined;
    Details?: ResourceChangeDetail[] | undefined;
}
export type ResourceChanges = ResourceChange[];
export interface DescribeProvisionedProductPlanOutput {
    ProvisionedProductPlanDetails?: ProvisionedProductPlanDetails | undefined;
    ResourceChanges?: ResourceChange[] | undefined;
    NextPageToken?: string | undefined;
}
export type Verbose = boolean;
export interface DescribeProvisioningArtifactInput {
    AcceptLanguage?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ProductId?: string | undefined;
    ProvisioningArtifactName?: string | undefined;
    ProductName?: string | undefined;
    Verbose?: boolean | undefined;
    IncludeProvisioningArtifactParameters?: boolean | undefined;
}
export type DefaultValue = string;
export type ParameterType = string;
export type NoEcho = boolean;
export type Description = string;
export type AllowedValues = string[];
export interface ParameterConstraints {
    AllowedValues?: string[] | undefined;
    AllowedPattern?: string | undefined;
    ConstraintDescription?: string | undefined;
    MaxLength?: string | undefined;
    MinLength?: string | undefined;
    MaxValue?: string | undefined;
    MinValue?: string | undefined;
}
export interface ProvisioningArtifactParameter {
    ParameterKey?: string | undefined;
    DefaultValue?: string | undefined;
    ParameterType?: string | undefined;
    IsNoEcho?: boolean | undefined;
    Description?: string | undefined;
    ParameterConstraints?: ParameterConstraints | undefined;
}
export type ProvisioningArtifactParameters = ProvisioningArtifactParameter[];
export interface DescribeProvisioningArtifactOutput {
    ProvisioningArtifactDetail?: ProvisioningArtifactDetail | undefined;
    Info?: {
        [key: string]: string | undefined;
    } | undefined;
    Status?: Status | undefined;
    ProvisioningArtifactParameters?: ProvisioningArtifactParameter[] | undefined;
}
export interface DescribeProvisioningParametersInput {
    AcceptLanguage?: string | undefined;
    ProductId?: string | undefined;
    ProductName?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ProvisioningArtifactName?: string | undefined;
    PathId?: string | undefined;
    PathName?: string | undefined;
}
export interface ConstraintSummary {
    Type?: string | undefined;
    Description?: string | undefined;
}
export type ConstraintSummaries = ConstraintSummary[];
export type InstructionType = string;
export type InstructionValue = string;
export interface UsageInstruction {
    Type?: string | undefined;
    Value?: string | undefined;
}
export type UsageInstructions = UsageInstruction[];
export type TagOptionValues = string[];
export interface TagOptionSummary {
    Key?: string | undefined;
    Values?: string[] | undefined;
}
export type TagOptionSummaries = TagOptionSummary[];
export type StackSetAccounts = string[];
export type Region = string;
export type StackSetRegions = string[];
export interface ProvisioningArtifactPreferences {
    StackSetAccounts?: string[] | undefined;
    StackSetRegions?: string[] | undefined;
}
export type ProvisioningArtifactOutputKey = string;
export type OutputDescription = string;
export interface ProvisioningArtifactOutput {
    Key?: string | undefined;
    Description?: string | undefined;
}
export type ProvisioningArtifactOutputs = ProvisioningArtifactOutput[];
export interface DescribeProvisioningParametersOutput {
    ProvisioningArtifactParameters?: ProvisioningArtifactParameter[] | undefined;
    ConstraintSummaries?: ConstraintSummary[] | undefined;
    UsageInstructions?: UsageInstruction[] | undefined;
    TagOptions?: TagOptionSummary[] | undefined;
    ProvisioningArtifactPreferences?: ProvisioningArtifactPreferences | undefined;
    ProvisioningArtifactOutputs?: ProvisioningArtifactOutput[] | undefined;
    ProvisioningArtifactOutputKeys?: ProvisioningArtifactOutput[] | undefined;
}
export interface DescribeRecordInput {
    AcceptLanguage?: string | undefined;
    Id: string;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export type RecordStatus = "CREATED" | "IN_PROGRESS" | "IN_PROGRESS_IN_ERROR" | "SUCCEEDED" | "FAILED" | (string & {});
export type RecordType = string;
export type ErrorCode = string;
export type ErrorDescription = string;
export interface RecordError {
    Code?: string | undefined;
    Description?: string | undefined;
}
export type RecordErrors = RecordError[];
export type RecordTagKey = string;
export type RecordTagValue = string;
export interface RecordTag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type RecordTags = RecordTag[];
export interface RecordDetail {
    RecordId?: string | undefined;
    ProvisionedProductName?: string | undefined;
    Status?: RecordStatus | undefined;
    CreatedTime?: Date | undefined;
    UpdatedTime?: Date | undefined;
    ProvisionedProductType?: string | undefined;
    RecordType?: string | undefined;
    ProvisionedProductId?: string | undefined;
    ProductId?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    PathId?: string | undefined;
    RecordErrors?: RecordError[] | undefined;
    RecordTags?: RecordTag[] | undefined;
    LaunchRoleArn?: string | undefined;
}
export type OutputKey = string;
export type OutputValue = string;
export interface RecordOutput {
    OutputKey?: string | undefined;
    OutputValue?: string | undefined;
    Description?: string | undefined;
}
export type RecordOutputs = RecordOutput[];
export interface DescribeRecordOutput {
    RecordDetail?: RecordDetail | undefined;
    RecordOutputs?: RecordOutput[] | undefined;
    NextPageToken?: string | undefined;
}
export interface DescribeServiceActionInput {
    Id: string;
    AcceptLanguage?: string | undefined;
}
export interface DescribeServiceActionOutput {
    ServiceActionDetail?: ServiceActionDetail | undefined;
}
export interface DescribeServiceActionExecutionParametersInput {
    ProvisionedProductId: string;
    ServiceActionId: string;
    AcceptLanguage?: string | undefined;
}
export type ExecutionParameterKey = string;
export type ExecutionParameterType = string;
export type ExecutionParameterValue = string;
export type ExecutionParameterValueList = string[];
export interface ExecutionParameter {
    Name?: string | undefined;
    Type?: string | undefined;
    DefaultValues?: string[] | undefined;
}
export type ExecutionParameters = ExecutionParameter[];
export interface DescribeServiceActionExecutionParametersOutput {
    ServiceActionParameters?: ExecutionParameter[] | undefined;
}
export interface DescribeTagOptionInput {
    Id: string;
}
export interface DescribeTagOptionOutput {
    TagOptionDetail?: TagOptionDetail | undefined;
}
export interface DisableAWSOrganizationsAccessInput {
}
export interface DisableAWSOrganizationsAccessOutput {
}
export interface DisassociateBudgetFromResourceInput {
    BudgetName: string;
    ResourceId: string;
}
export interface DisassociateBudgetFromResourceOutput {
}
export interface DisassociatePrincipalFromPortfolioInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    PrincipalARN: string;
    PrincipalType?: PrincipalType | undefined;
}
export interface DisassociatePrincipalFromPortfolioOutput {
}
export interface DisassociateProductFromPortfolioInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    PortfolioId: string;
}
export interface DisassociateProductFromPortfolioOutput {
}
export interface DisassociateServiceActionFromProvisioningArtifactInput {
    ProductId: string;
    ProvisioningArtifactId: string;
    ServiceActionId: string;
    AcceptLanguage?: string | undefined;
    IdempotencyToken?: string | undefined;
}
export interface DisassociateServiceActionFromProvisioningArtifactOutput {
}
export interface DisassociateTagOptionFromResourceInput {
    ResourceId: string;
    TagOptionId: string;
}
export interface DisassociateTagOptionFromResourceOutput {
}
export interface EnableAWSOrganizationsAccessInput {
}
export interface EnableAWSOrganizationsAccessOutput {
}
export interface ExecuteProvisionedProductPlanInput {
    AcceptLanguage?: string | undefined;
    PlanId: string;
    IdempotencyToken: string;
}
export interface ExecuteProvisionedProductPlanOutput {
    RecordDetail?: RecordDetail | undefined;
}
export type ExecutionParameterMap = {
    [key: string]: string[] | undefined;
};
export interface ExecuteProvisionedProductServiceActionInput {
    ProvisionedProductId: string;
    ServiceActionId: string;
    ExecuteToken: string;
    AcceptLanguage?: string | undefined;
    Parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface ExecuteProvisionedProductServiceActionOutput {
    RecordDetail?: RecordDetail | undefined;
}
export interface GetAWSOrganizationsAccessStatusInput {
}
export type AccessStatus = "ENABLED" | "UNDER_CHANGE" | "DISABLED" | (string & {});
export interface GetAWSOrganizationsAccessStatusOutput {
    AccessStatus?: AccessStatus | undefined;
}
export type OutputKeys = string[];
export interface GetProvisionedProductOutputsInput {
    AcceptLanguage?: string | undefined;
    ProvisionedProductId?: string | undefined;
    ProvisionedProductName?: string | undefined;
    OutputKeys?: string[] | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export interface GetProvisionedProductOutputsOutput {
    Outputs?: RecordOutput[] | undefined;
    NextPageToken?: string | undefined;
}
export type PhysicalId = string;
export interface ImportAsProvisionedProductInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    ProvisioningArtifactId: string;
    ProvisionedProductName: string;
    PhysicalId: string;
    IdempotencyToken: string;
}
export interface ImportAsProvisionedProductOutput {
    RecordDetail?: RecordDetail | undefined;
}
export interface ListAcceptedPortfolioSharesInput {
    AcceptLanguage?: string | undefined;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
    PortfolioShareType?: PortfolioShareType | undefined;
}
export type PortfolioDetails = PortfolioDetail[];
export interface ListAcceptedPortfolioSharesOutput {
    PortfolioDetails?: PortfolioDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListBudgetsForResourceInput {
    AcceptLanguage?: string | undefined;
    ResourceId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export interface ListBudgetsForResourceOutput {
    Budgets?: BudgetDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListConstraintsForPortfolioInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    ProductId?: string | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type ConstraintDetails = ConstraintDetail[];
export interface ListConstraintsForPortfolioOutput {
    ConstraintDetails?: ConstraintDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListLaunchPathsInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export interface LaunchPathSummary {
    Id?: string | undefined;
    ConstraintSummaries?: ConstraintSummary[] | undefined;
    Tags?: Tag[] | undefined;
    Name?: string | undefined;
}
export type LaunchPathSummaries = LaunchPathSummary[];
export interface ListLaunchPathsOutput {
    LaunchPathSummaries?: LaunchPathSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListOrganizationPortfolioAccessInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    OrganizationNodeType: OrganizationNodeType;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export type OrganizationNodes = OrganizationNode[];
export interface ListOrganizationPortfolioAccessOutput {
    OrganizationNodes?: OrganizationNode[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListPortfolioAccessInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    OrganizationParentId?: string | undefined;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export type AccountIds = string[];
export interface ListPortfolioAccessOutput {
    AccountIds?: string[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListPortfoliosInput {
    AcceptLanguage?: string | undefined;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface ListPortfoliosOutput {
    PortfolioDetails?: PortfolioDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListPortfoliosForProductInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface ListPortfoliosForProductOutput {
    PortfolioDetails?: PortfolioDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListPrincipalsForPortfolioInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export interface Principal {
    PrincipalARN?: string | undefined;
    PrincipalType?: PrincipalType | undefined;
}
export type Principals = Principal[];
export interface ListPrincipalsForPortfolioOutput {
    Principals?: Principal[] | undefined;
    NextPageToken?: string | undefined;
}
export type AccessLevelFilterKey = "Account" | "Role" | "User" | (string & {});
export type AccessLevelFilterValue = string;
export interface AccessLevelFilter {
    Key?: AccessLevelFilterKey | undefined;
    Value?: string | undefined;
}
export interface ListProvisionedProductPlansInput {
    AcceptLanguage?: string | undefined;
    ProvisionProductId?: string | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
    AccessLevelFilter?: AccessLevelFilter | undefined;
}
export interface ProvisionedProductPlanSummary {
    PlanName?: string | undefined;
    PlanId?: string | undefined;
    ProvisionProductId?: string | undefined;
    ProvisionProductName?: string | undefined;
    PlanType?: ProvisionedProductPlanType | undefined;
    ProvisioningArtifactId?: string | undefined;
}
export type ProvisionedProductPlans = ProvisionedProductPlanSummary[];
export interface ListProvisionedProductPlansOutput {
    ProvisionedProductPlans?: ProvisionedProductPlanSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListProvisioningArtifactsInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
}
export type ProvisioningArtifactDetails = ProvisioningArtifactDetail[];
export interface ListProvisioningArtifactsOutput {
    ProvisioningArtifactDetails?: ProvisioningArtifactDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListProvisioningArtifactsForServiceActionInput {
    ServiceActionId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
    AcceptLanguage?: string | undefined;
}
export interface ProvisioningArtifactView {
    ProductViewSummary?: ProductViewSummary | undefined;
    ProvisioningArtifact?: ProvisioningArtifact | undefined;
}
export type ProvisioningArtifactViews = ProvisioningArtifactView[];
export interface ListProvisioningArtifactsForServiceActionOutput {
    ProvisioningArtifactViews?: ProvisioningArtifactView[] | undefined;
    NextPageToken?: string | undefined;
}
export type SearchFilterKey = string;
export type SearchFilterValue = string;
export interface ListRecordHistorySearchFilter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export interface ListRecordHistoryInput {
    AcceptLanguage?: string | undefined;
    AccessLevelFilter?: AccessLevelFilter | undefined;
    SearchFilter?: ListRecordHistorySearchFilter | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type RecordDetails = RecordDetail[];
export interface ListRecordHistoryOutput {
    RecordDetails?: RecordDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export type ResourceType = string;
export interface ListResourcesForTagOptionInput {
    TagOptionId: string;
    ResourceType?: string | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type ResourceDetailId = string;
export type ResourceDetailARN = string;
export type ResourceDetailName = string;
export type ResourceDetailDescription = string;
export type ResourceDetailCreatedTime = Date;
export interface ResourceDetail {
    Id?: string | undefined;
    ARN?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedTime?: Date | undefined;
}
export type ResourceDetails = ResourceDetail[];
export interface ListResourcesForTagOptionOutput {
    ResourceDetails?: ResourceDetail[] | undefined;
    PageToken?: string | undefined;
}
export interface ListServiceActionsInput {
    AcceptLanguage?: string | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type ServiceActionSummaries = ServiceActionSummary[];
export interface ListServiceActionsOutput {
    ServiceActionSummaries?: ServiceActionSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListServiceActionsForProvisioningArtifactInput {
    ProductId: string;
    ProvisioningArtifactId: string;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
    AcceptLanguage?: string | undefined;
}
export interface ListServiceActionsForProvisioningArtifactOutput {
    ServiceActionSummaries?: ServiceActionSummary[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListStackInstancesForProvisionedProductInput {
    AcceptLanguage?: string | undefined;
    ProvisionedProductId: string;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
}
export type StackInstanceStatus = "CURRENT" | "OUTDATED" | "INOPERABLE" | (string & {});
export interface StackInstance {
    Account?: string | undefined;
    Region?: string | undefined;
    StackInstanceStatus?: StackInstanceStatus | undefined;
}
export type StackInstances = StackInstance[];
export interface ListStackInstancesForProvisionedProductOutput {
    StackInstances?: StackInstance[] | undefined;
    NextPageToken?: string | undefined;
}
export interface ListTagOptionsFilters {
    Key?: string | undefined;
    Value?: string | undefined;
    Active?: boolean | undefined;
}
export interface ListTagOptionsInput {
    Filters?: ListTagOptionsFilters | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export interface ListTagOptionsOutput {
    TagOptionDetails?: TagOptionDetail[] | undefined;
    PageToken?: string | undefined;
}
export type EngineWorkflowToken = string;
export type EngineWorkflowStatus = "SUCCEEDED" | "FAILED" | (string & {});
export type EngineWorkflowFailureReason = string;
export type UniqueTagKey = string;
export type UniqueTagValue = string;
export interface UniqueTagResourceIdentifier {
    Key?: string | undefined;
    Value?: string | undefined;
}
export interface EngineWorkflowResourceIdentifier {
    UniqueTag?: UniqueTagResourceIdentifier | undefined;
}
export interface NotifyProvisionProductEngineWorkflowResultInput {
    WorkflowToken: string;
    RecordId: string;
    Status: EngineWorkflowStatus;
    FailureReason?: string | undefined;
    ResourceIdentifier?: EngineWorkflowResourceIdentifier | undefined;
    Outputs?: RecordOutput[] | undefined;
    IdempotencyToken: string;
}
export interface NotifyProvisionProductEngineWorkflowResultOutput {
}
export interface NotifyTerminateProvisionedProductEngineWorkflowResultInput {
    WorkflowToken: string;
    RecordId: string;
    Status: EngineWorkflowStatus;
    FailureReason?: string | undefined;
    IdempotencyToken: string;
}
export interface NotifyTerminateProvisionedProductEngineWorkflowResultOutput {
}
export interface NotifyUpdateProvisionedProductEngineWorkflowResultInput {
    WorkflowToken: string;
    RecordId: string;
    Status: EngineWorkflowStatus;
    FailureReason?: string | undefined;
    Outputs?: RecordOutput[] | undefined;
    IdempotencyToken: string;
}
export interface NotifyUpdateProvisionedProductEngineWorkflowResultOutput {
}
export interface ProvisioningParameter {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ProvisioningParameters = ProvisioningParameter[];
export type StackSetFailureToleranceCount = number;
export type StackSetFailureTolerancePercentage = number;
export type StackSetMaxConcurrencyCount = number;
export type StackSetMaxConcurrencyPercentage = number;
export interface ProvisioningPreferences {
    StackSetAccounts?: string[] | undefined;
    StackSetRegions?: string[] | undefined;
    StackSetFailureToleranceCount?: number | undefined;
    StackSetFailureTolerancePercentage?: number | undefined;
    StackSetMaxConcurrencyCount?: number | undefined;
    StackSetMaxConcurrencyPercentage?: number | undefined;
}
export interface ProvisionProductInput {
    AcceptLanguage?: string | undefined;
    ProductId?: string | undefined;
    ProductName?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ProvisioningArtifactName?: string | undefined;
    PathId?: string | undefined;
    PathName?: string | undefined;
    ProvisionedProductName: string;
    ProvisioningParameters?: ProvisioningParameter[] | undefined;
    ProvisioningPreferences?: ProvisioningPreferences | undefined;
    Tags?: Tag[] | undefined;
    NotificationArns?: string[] | undefined;
    ProvisionToken: string;
}
export interface ProvisionProductOutput {
    RecordDetail?: RecordDetail | undefined;
}
export interface RejectPortfolioShareInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    PortfolioShareType?: PortfolioShareType | undefined;
}
export interface RejectPortfolioShareOutput {
}
export interface ScanProvisionedProductsInput {
    AcceptLanguage?: string | undefined;
    AccessLevelFilter?: AccessLevelFilter | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type ProvisionedProductDetails = ProvisionedProductDetail[];
export interface ScanProvisionedProductsOutput {
    ProvisionedProducts?: ProvisionedProductDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export type ProductViewFilterBy = "FullTextSearch" | "Owner" | "ProductType" | "SourceProductId" | (string & {});
export type ProductViewFilterValue = string;
export type ProductViewFilterValues = string[];
export type ProductViewFilters = {
    [key in ProductViewFilterBy]?: string[] | undefined;
};
export type ProductViewSortBy = "Title" | "VersionCount" | "CreationDate" | (string & {});
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface SearchProductsInput {
    AcceptLanguage?: string | undefined;
    Filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    PageSize?: number | undefined;
    SortBy?: ProductViewSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    PageToken?: string | undefined;
}
export type ProductViewSummaries = ProductViewSummary[];
export type ProductViewAggregationType = string;
export type AttributeValue = string;
export type ApproximateCount = number;
export interface ProductViewAggregationValue {
    Value?: string | undefined;
    ApproximateCount?: number | undefined;
}
export type ProductViewAggregationValues = ProductViewAggregationValue[];
export type ProductViewAggregations = {
    [key: string]: ProductViewAggregationValue[] | undefined;
};
export interface SearchProductsOutput {
    ProductViewSummaries?: ProductViewSummary[] | undefined;
    ProductViewAggregations?: {
        [key: string]: ProductViewAggregationValue[] | undefined;
    } | undefined;
    NextPageToken?: string | undefined;
}
export type ProductSource = "ACCOUNT" | (string & {});
export interface SearchProductsAsAdminInput {
    AcceptLanguage?: string | undefined;
    PortfolioId?: string | undefined;
    Filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    SortBy?: ProductViewSortBy | undefined;
    SortOrder?: SortOrder | undefined;
    PageToken?: string | undefined;
    PageSize?: number | undefined;
    ProductSource?: ProductSource | undefined;
}
export type ProductViewDetails = ProductViewDetail[];
export interface SearchProductsAsAdminOutput {
    ProductViewDetails?: ProductViewDetail[] | undefined;
    NextPageToken?: string | undefined;
}
export type ProvisionedProductViewFilterBy = "SearchQuery" | (string & {});
export type ProvisionedProductViewFilterValue = string;
export type ProvisionedProductViewFilterValues = string[];
export type ProvisionedProductFilters = {
    [key in ProvisionedProductViewFilterBy]?: string[] | undefined;
};
export type SortField = string;
export type SearchProvisionedProductsPageSize = number;
export interface SearchProvisionedProductsInput {
    AcceptLanguage?: string | undefined;
    AccessLevelFilter?: AccessLevelFilter | undefined;
    Filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    SortBy?: string | undefined;
    SortOrder?: SortOrder | undefined;
    PageSize?: number | undefined;
    PageToken?: string | undefined;
}
export type UserArn = string;
export type UserArnSession = string;
export interface ProvisionedProductAttribute {
    Name?: string | undefined;
    Arn?: string | undefined;
    Type?: string | undefined;
    Id?: string | undefined;
    Status?: ProvisionedProductStatus | undefined;
    StatusMessage?: string | undefined;
    CreatedTime?: Date | undefined;
    IdempotencyToken?: string | undefined;
    LastRecordId?: string | undefined;
    LastProvisioningRecordId?: string | undefined;
    LastSuccessfulProvisioningRecordId?: string | undefined;
    Tags?: Tag[] | undefined;
    PhysicalId?: string | undefined;
    ProductId?: string | undefined;
    ProductName?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ProvisioningArtifactName?: string | undefined;
    UserArn?: string | undefined;
    UserArnSession?: string | undefined;
}
export type ProvisionedProductAttributes = ProvisionedProductAttribute[];
export type TotalResultsCount = number;
export interface SearchProvisionedProductsOutput {
    ProvisionedProducts?: ProvisionedProductAttribute[] | undefined;
    TotalResultsCount?: number | undefined;
    NextPageToken?: string | undefined;
}
export type RetainPhysicalResources = boolean;
export interface TerminateProvisionedProductInput {
    ProvisionedProductName?: string | undefined;
    ProvisionedProductId?: string | undefined;
    TerminateToken: string;
    IgnoreErrors?: boolean | undefined;
    AcceptLanguage?: string | undefined;
    RetainPhysicalResources?: boolean | undefined;
}
export interface TerminateProvisionedProductOutput {
    RecordDetail?: RecordDetail | undefined;
}
export interface UpdateConstraintInput {
    AcceptLanguage?: string | undefined;
    Id: string;
    Description?: string | undefined;
    Parameters?: string | undefined;
}
export interface UpdateConstraintOutput {
    ConstraintDetail?: ConstraintDetail | undefined;
    ConstraintParameters?: string | undefined;
    Status?: Status | undefined;
}
export type TagKeys = string[];
export interface UpdatePortfolioInput {
    AcceptLanguage?: string | undefined;
    Id: string;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    ProviderName?: string | undefined;
    AddTags?: Tag[] | undefined;
    RemoveTags?: string[] | undefined;
}
export interface UpdatePortfolioOutput {
    PortfolioDetail?: PortfolioDetail | undefined;
    Tags?: Tag[] | undefined;
}
export interface UpdatePortfolioShareInput {
    AcceptLanguage?: string | undefined;
    PortfolioId: string;
    AccountId?: string | undefined;
    OrganizationNode?: OrganizationNode | undefined;
    ShareTagOptions?: boolean | undefined;
    SharePrincipals?: boolean | undefined;
}
export interface UpdatePortfolioShareOutput {
    PortfolioShareToken?: string | undefined;
    Status?: ShareStatus | undefined;
}
export interface UpdateProductInput {
    AcceptLanguage?: string | undefined;
    Id: string;
    Name?: string | undefined;
    Owner?: string | undefined;
    Description?: string | undefined;
    Distributor?: string | undefined;
    SupportDescription?: string | undefined;
    SupportEmail?: string | undefined;
    SupportUrl?: string | undefined;
    AddTags?: Tag[] | undefined;
    RemoveTags?: string[] | undefined;
    SourceConnection?: SourceConnection | undefined;
}
export interface UpdateProductOutput {
    ProductViewDetail?: ProductViewDetail | undefined;
    Tags?: Tag[] | undefined;
}
export type StackSetOperationType = "CREATE" | "UPDATE" | "DELETE" | (string & {});
export interface UpdateProvisioningPreferences {
    StackSetAccounts?: string[] | undefined;
    StackSetRegions?: string[] | undefined;
    StackSetFailureToleranceCount?: number | undefined;
    StackSetFailureTolerancePercentage?: number | undefined;
    StackSetMaxConcurrencyCount?: number | undefined;
    StackSetMaxConcurrencyPercentage?: number | undefined;
    StackSetOperationType?: StackSetOperationType | undefined;
}
export interface UpdateProvisionedProductInput {
    AcceptLanguage?: string | undefined;
    ProvisionedProductName?: string | undefined;
    ProvisionedProductId?: string | undefined;
    ProductId?: string | undefined;
    ProductName?: string | undefined;
    ProvisioningArtifactId?: string | undefined;
    ProvisioningArtifactName?: string | undefined;
    PathId?: string | undefined;
    PathName?: string | undefined;
    ProvisioningParameters?: UpdateProvisioningParameter[] | undefined;
    ProvisioningPreferences?: UpdateProvisioningPreferences | undefined;
    Tags?: Tag[] | undefined;
    UpdateToken: string;
}
export interface UpdateProvisionedProductOutput {
    RecordDetail?: RecordDetail | undefined;
}
export type PropertyKey = "OWNER" | "LAUNCH_ROLE" | (string & {});
export type PropertyValue = string;
export type ProvisionedProductProperties = {
    [key in PropertyKey]?: string | undefined;
};
export interface UpdateProvisionedProductPropertiesInput {
    AcceptLanguage?: string | undefined;
    ProvisionedProductId: string;
    ProvisionedProductProperties: {
        [key: string]: string | undefined;
    };
    IdempotencyToken: string;
}
export interface UpdateProvisionedProductPropertiesOutput {
    ProvisionedProductId?: string | undefined;
    ProvisionedProductProperties?: {
        [key: string]: string | undefined;
    } | undefined;
    RecordId?: string | undefined;
    Status?: RecordStatus | undefined;
}
export interface UpdateProvisioningArtifactInput {
    AcceptLanguage?: string | undefined;
    ProductId: string;
    ProvisioningArtifactId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Active?: boolean | undefined;
    Guidance?: ProvisioningArtifactGuidance | undefined;
}
export interface UpdateProvisioningArtifactOutput {
    ProvisioningArtifactDetail?: ProvisioningArtifactDetail | undefined;
    Info?: {
        [key: string]: string | undefined;
    } | undefined;
    Status?: Status | undefined;
}
export interface UpdateServiceActionInput {
    Id: string;
    Name?: string | undefined;
    Definition?: {
        [key: string]: string | undefined;
    } | undefined;
    Description?: string | undefined;
    AcceptLanguage?: string | undefined;
}
export interface UpdateServiceActionOutput {
    ServiceActionDetail?: ServiceActionDetail | undefined;
}
export interface UpdateTagOptionInput {
    Id: string;
    Value?: string | undefined;
    Active?: boolean | undefined;
}
export interface UpdateTagOptionOutput {
    TagOptionDetail?: TagOptionDetail | undefined;
}
export type ErrorMessage = string;
export type AcceptPortfolioShareError = InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Accepts an offer to share the specified portfolio.
 */
export declare const acceptPortfolioShare: API.OperationMethod<AcceptPortfolioShareInput & RegionInput, AcceptPortfolioShareOutput, AcceptPortfolioShareError, Credentials | HttpClient.HttpClient>;
export type AssociateBudgetWithResourceError = DuplicateResourceException | InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified budget with the specified resource.
 */
export declare const associateBudgetWithResource: API.OperationMethod<AssociateBudgetWithResourceInput & RegionInput, AssociateBudgetWithResourceOutput, AssociateBudgetWithResourceError, Credentials | HttpClient.HttpClient>;
export type AssociatePrincipalWithPortfolioError = InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified principal ARN with the specified portfolio.
 *
 * If you share the portfolio with principal name sharing enabled, the `PrincipalARN` association is
 * included in the share.
 *
 * The `PortfolioID`, `PrincipalARN`, and `PrincipalType` parameters are
 * required.
 *
 * You can associate a maximum of 10 Principals with a portfolio using `PrincipalType` as `IAM_PATTERN`.
 *
 * When you associate a principal with portfolio, a potential privilege escalation path may occur when that portfolio is
 * then shared with other accounts. For a user in a recipient account who is *not* an Service Catalog Admin,
 * but still has the ability to create Principals (Users/Groups/Roles), that user could create a role that matches a principal
 * name association for the portfolio. Although this user may not know which principal names are associated through
 * Service Catalog, they may be able to guess the user. If this potential escalation path is a concern, then
 * Service Catalog recommends using `PrincipalType` as `IAM`. With this configuration,
 * the `PrincipalARN` must already exist in the recipient account before it can be associated.
 */
export declare const associatePrincipalWithPortfolio: API.OperationMethod<AssociatePrincipalWithPortfolioInput & RegionInput, AssociatePrincipalWithPortfolioOutput, AssociatePrincipalWithPortfolioError, Credentials | HttpClient.HttpClient>;
export type AssociateProductWithPortfolioError = InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified product with the specified portfolio.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const associateProductWithPortfolio: API.OperationMethod<AssociateProductWithPortfolioInput & RegionInput, AssociateProductWithPortfolioOutput, AssociateProductWithPortfolioError, Credentials | HttpClient.HttpClient>;
export type AssociateServiceActionWithProvisioningArtifactError = DuplicateResourceException | InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates a self-service action with a provisioning artifact.
 */
export declare const associateServiceActionWithProvisioningArtifact: API.OperationMethod<AssociateServiceActionWithProvisioningArtifactInput & RegionInput, AssociateServiceActionWithProvisioningArtifactOutput, AssociateServiceActionWithProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type AssociateTagOptionWithResourceError = DuplicateResourceException | InvalidParametersException | InvalidStateException | LimitExceededException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Associate the specified TagOption with the specified portfolio or product.
 */
export declare const associateTagOptionWithResource: API.OperationMethod<AssociateTagOptionWithResourceInput & RegionInput, AssociateTagOptionWithResourceOutput, AssociateTagOptionWithResourceError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateServiceActionWithProvisioningArtifactError = InvalidParametersException | CommonErrors;
/**
 * Associates multiple self-service actions with provisioning artifacts.
 */
export declare const batchAssociateServiceActionWithProvisioningArtifact: API.OperationMethod<BatchAssociateServiceActionWithProvisioningArtifactInput & RegionInput, BatchAssociateServiceActionWithProvisioningArtifactOutput, BatchAssociateServiceActionWithProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateServiceActionFromProvisioningArtifactError = InvalidParametersException | CommonErrors;
/**
 * Disassociates a batch of self-service actions from the specified provisioning artifact.
 */
export declare const batchDisassociateServiceActionFromProvisioningArtifact: API.OperationMethod<BatchDisassociateServiceActionFromProvisioningArtifactInput & RegionInput, BatchDisassociateServiceActionFromProvisioningArtifactOutput, BatchDisassociateServiceActionFromProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type CopyProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Copies the specified source product to the specified target product or a new
 * product.
 *
 * You can copy a product to the same account or another account. You can copy a product
 * to the same Region or another Region. If you copy a product to another account, you must
 * first share the product in a portfolio using CreatePortfolioShare.
 *
 * This operation is performed asynchronously. To track the progress of the
 * operation, use DescribeCopyProductStatus.
 */
export declare const copyProduct: API.OperationMethod<CopyProductInput & RegionInput, CopyProductOutput, CopyProductError, Credentials | HttpClient.HttpClient>;
export type CreateConstraintError = DuplicateResourceException | InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a constraint.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const createConstraint: API.OperationMethod<CreateConstraintInput & RegionInput, CreateConstraintOutput, CreateConstraintError, Credentials | HttpClient.HttpClient>;
export type CreatePortfolioError = InvalidParametersException | LimitExceededException | TagOptionNotMigratedException | CommonErrors;
/**
 * Creates a portfolio.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const createPortfolio: API.OperationMethod<CreatePortfolioInput & RegionInput, CreatePortfolioOutput, CreatePortfolioError, Credentials | HttpClient.HttpClient>;
export type CreatePortfolioShareError = InvalidParametersException | InvalidStateException | LimitExceededException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Shares the specified portfolio with the specified account or organization node.
 * Shares to an organization node can only be created by the management account of an
 * organization or by a delegated administrator. You can share portfolios to an organization,
 * an organizational unit, or a specific account.
 *
 * Note that if a delegated admin is de-registered, they can no longer create portfolio shares.
 *
 * `AWSOrganizationsAccess` must be enabled in order to create a portfolio share to an organization node.
 *
 * You can't share a shared resource, including portfolios that contain a shared product.
 *
 * If the portfolio share with the specified account or organization node already exists, this action will have no effect
 * and will not return an error. To update an existing share, you must use the ` UpdatePortfolioShare` API instead.
 *
 * When you associate a principal with portfolio, a potential privilege escalation path may occur when that portfolio is
 * then shared with other accounts. For a user in a recipient account who is *not* an Service Catalog Admin,
 * but still has the ability to create Principals (Users/Groups/Roles), that user could create a role that matches a principal
 * name association for the portfolio. Although this user may not know which principal names are associated through
 * Service Catalog, they may be able to guess the user. If this potential escalation path is a concern, then
 * Service Catalog recommends using `PrincipalType` as `IAM`. With this configuration,
 * the `PrincipalARN` must already exist in the recipient account before it can be associated.
 */
export declare const createPortfolioShare: API.OperationMethod<CreatePortfolioShareInput & RegionInput, CreatePortfolioShareOutput, CreatePortfolioShareError, Credentials | HttpClient.HttpClient>;
export type CreateProductError = InvalidParametersException | LimitExceededException | TagOptionNotMigratedException | CommonErrors;
/**
 * Creates a product.
 *
 * A delegated admin is authorized to invoke this command.
 *
 * The user or role that performs this operation must have the
 * `cloudformation:GetTemplate` IAM policy permission. This policy permission is
 * required when using the `ImportFromPhysicalId` template source in the
 * information data section.
 */
export declare const createProduct: API.OperationMethod<CreateProductInput & RegionInput, CreateProductOutput, CreateProductError, Credentials | HttpClient.HttpClient>;
export type CreateProvisionedProductPlanError = InvalidParametersException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a plan.
 *
 * A plan includes the list of resources to be
 * created (when provisioning a new product) or modified (when updating a provisioned product)
 * when the plan is executed.
 *
 * You can create one plan for each provisioned product. To create a plan for an existing
 * provisioned product, the product status must be AVAILABLE or TAINTED.
 *
 * To view the resource changes in the change set, use DescribeProvisionedProductPlan.
 * To create or modify the provisioned product, use ExecuteProvisionedProductPlan.
 */
export declare const createProvisionedProductPlan: API.OperationMethod<CreateProvisionedProductPlanInput & RegionInput, CreateProvisionedProductPlanOutput, CreateProvisionedProductPlanError, Credentials | HttpClient.HttpClient>;
export type CreateProvisioningArtifactError = InvalidParametersException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a provisioning artifact (also known as a version) for the specified product.
 *
 * You cannot create a provisioning artifact for a product that was shared with you.
 *
 * The user or role that performs this operation must have the `cloudformation:GetTemplate`
 * IAM policy permission. This policy permission is required when using the
 * `ImportFromPhysicalId` template source in the information data section.
 */
export declare const createProvisioningArtifact: API.OperationMethod<CreateProvisioningArtifactInput & RegionInput, CreateProvisioningArtifactOutput, CreateProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type CreateServiceActionError = InvalidParametersException | LimitExceededException | CommonErrors;
/**
 * Creates a self-service action.
 */
export declare const createServiceAction: API.OperationMethod<CreateServiceActionInput & RegionInput, CreateServiceActionOutput, CreateServiceActionError, Credentials | HttpClient.HttpClient>;
export type CreateTagOptionError = DuplicateResourceException | LimitExceededException | TagOptionNotMigratedException | CommonErrors;
/**
 * Creates a TagOption.
 */
export declare const createTagOption: API.OperationMethod<CreateTagOptionInput & RegionInput, CreateTagOptionOutput, CreateTagOptionError, Credentials | HttpClient.HttpClient>;
export type DeleteConstraintError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified constraint.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const deleteConstraint: API.OperationMethod<DeleteConstraintInput & RegionInput, DeleteConstraintOutput, DeleteConstraintError, Credentials | HttpClient.HttpClient>;
export type DeletePortfolioError = InvalidParametersException | ResourceInUseException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Deletes the specified portfolio.
 *
 * You cannot delete a portfolio if it was shared with you or if it has associated
 * products, users, constraints, or shared accounts.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const deletePortfolio: API.OperationMethod<DeletePortfolioInput & RegionInput, DeletePortfolioOutput, DeletePortfolioError, Credentials | HttpClient.HttpClient>;
export type DeletePortfolioShareError = InvalidParametersException | InvalidStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Stops sharing the specified portfolio with the specified account or organization
 * node. Shares to an organization node can only be deleted by the management account of an
 * organization or by a delegated administrator.
 *
 * Note that if a delegated admin is de-registered, portfolio shares created from that account are removed.
 */
export declare const deletePortfolioShare: API.OperationMethod<DeletePortfolioShareInput & RegionInput, DeletePortfolioShareOutput, DeletePortfolioShareError, Credentials | HttpClient.HttpClient>;
export type DeleteProductError = InvalidParametersException | ResourceInUseException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Deletes the specified product.
 *
 * You cannot delete a product if it was shared with you or is associated with a portfolio.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const deleteProduct: API.OperationMethod<DeleteProductInput & RegionInput, DeleteProductOutput, DeleteProductError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisionedProductPlanError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified plan.
 */
export declare const deleteProvisionedProductPlan: API.OperationMethod<DeleteProvisionedProductPlanInput & RegionInput, DeleteProvisionedProductPlanOutput, DeleteProvisionedProductPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisioningArtifactError = InvalidParametersException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified provisioning artifact (also known as a version) for the specified product.
 *
 * You cannot delete a provisioning artifact associated with a product that was shared with you.
 * You cannot delete the last provisioning artifact for a product, because a product must have at
 * least one provisioning artifact.
 */
export declare const deleteProvisioningArtifact: API.OperationMethod<DeleteProvisioningArtifactInput & RegionInput, DeleteProvisioningArtifactOutput, DeleteProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceActionError = InvalidParametersException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a self-service action.
 */
export declare const deleteServiceAction: API.OperationMethod<DeleteServiceActionInput & RegionInput, DeleteServiceActionOutput, DeleteServiceActionError, Credentials | HttpClient.HttpClient>;
export type DeleteTagOptionError = ResourceInUseException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Deletes the specified TagOption.
 *
 * You cannot delete a TagOption if it is associated with a product or portfolio.
 */
export declare const deleteTagOption: API.OperationMethod<DeleteTagOptionInput & RegionInput, DeleteTagOptionOutput, DeleteTagOptionError, Credentials | HttpClient.HttpClient>;
export type DescribeConstraintError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified constraint.
 */
export declare const describeConstraint: API.OperationMethod<DescribeConstraintInput & RegionInput, DescribeConstraintOutput, DescribeConstraintError, Credentials | HttpClient.HttpClient>;
export type DescribeCopyProductStatusError = ResourceNotFoundException | CommonErrors;
/**
 * Gets the status of the specified copy product operation.
 */
export declare const describeCopyProductStatus: API.OperationMethod<DescribeCopyProductStatusInput & RegionInput, DescribeCopyProductStatusOutput, DescribeCopyProductStatusError, Credentials | HttpClient.HttpClient>;
export type DescribePortfolioError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified portfolio.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const describePortfolio: API.OperationMethod<DescribePortfolioInput & RegionInput, DescribePortfolioOutput, DescribePortfolioError, Credentials | HttpClient.HttpClient>;
export type DescribePortfolioSharesError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a summary of each of the portfolio shares that were created for the specified portfolio.
 *
 * You can use this API to determine which accounts or organizational nodes this
 * portfolio have been shared, whether the recipient entity has imported the share, and
 * whether TagOptions are included with the share.
 *
 * The `PortfolioId` and `Type` parameters are both required.
 */
export declare const describePortfolioShares: API.PaginatedOperationMethod<DescribePortfolioSharesInput & RegionInput, DescribePortfolioSharesOutput, DescribePortfolioSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePortfolioShareStatusError = InvalidParametersException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the status of the specified portfolio share operation. This API can only be called
 * by the management account in the organization or by a delegated admin.
 */
export declare const describePortfolioShareStatus: API.OperationMethod<DescribePortfolioShareStatusInput & RegionInput, DescribePortfolioShareStatusOutput, DescribePortfolioShareStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified product.
 *
 * Running this operation
 * with administrator access
 * results
 * in a failure.
 * DescribeProductAsAdmin should be used instead.
 */
export declare const describeProduct: API.OperationMethod<DescribeProductInput & RegionInput, DescribeProductOutput, DescribeProductError, Credentials | HttpClient.HttpClient>;
export type DescribeProductAsAdminError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified product. This operation is run with administrator access.
 */
export declare const describeProductAsAdmin: API.OperationMethod<DescribeProductAsAdminInput & RegionInput, DescribeProductAsAdminOutput, DescribeProductAsAdminError, Credentials | HttpClient.HttpClient>;
export type DescribeProductViewError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified product.
 */
export declare const describeProductView: API.OperationMethod<DescribeProductViewInput & RegionInput, DescribeProductViewOutput, DescribeProductViewError, Credentials | HttpClient.HttpClient>;
export type DescribeProvisionedProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified provisioned product.
 */
export declare const describeProvisionedProduct: API.OperationMethod<DescribeProvisionedProductInput & RegionInput, DescribeProvisionedProductOutput, DescribeProvisionedProductError, Credentials | HttpClient.HttpClient>;
export type DescribeProvisionedProductPlanError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the resource changes for the specified plan.
 */
export declare const describeProvisionedProductPlan: API.OperationMethod<DescribeProvisionedProductPlanInput & RegionInput, DescribeProvisionedProductPlanOutput, DescribeProvisionedProductPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeProvisioningArtifactError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified provisioning artifact (also known as a version) for the specified product.
 */
export declare const describeProvisioningArtifact: API.OperationMethod<DescribeProvisioningArtifactInput & RegionInput, DescribeProvisioningArtifactOutput, DescribeProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type DescribeProvisioningParametersError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the configuration required to provision the specified product using
 * the specified provisioning artifact.
 *
 * If the output contains a TagOption key with an empty list of values, there is a
 * TagOption conflict for that key. The end user cannot take action to fix the conflict, and
 * launch is not blocked. In subsequent calls to ProvisionProduct,
 * do not include conflicted TagOption keys as tags, or this causes the error
 * "Parameter validation failed: Missing required parameter in Tags[*N*]:*Value*".
 * Tag the provisioned product with the value `sc-tagoption-conflict-portfolioId-productId`.
 */
export declare const describeProvisioningParameters: API.OperationMethod<DescribeProvisioningParametersInput & RegionInput, DescribeProvisioningParametersOutput, DescribeProvisioningParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeRecordError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the specified request operation.
 *
 * Use this operation after calling a request operation (for example, ProvisionProduct,
 * TerminateProvisionedProduct, or UpdateProvisionedProduct).
 *
 * If a provisioned product was transferred to a new owner using UpdateProvisionedProductProperties, the new owner
 * will be able to describe all past records for that product. The previous owner will no longer be able to describe the records, but will be able to
 * use ListRecordHistory to see the product's history from when he was the owner.
 */
export declare const describeRecord: API.OperationMethod<DescribeRecordInput & RegionInput, DescribeRecordOutput, DescribeRecordError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceActionError = ResourceNotFoundException | CommonErrors;
/**
 * Describes a self-service action.
 */
export declare const describeServiceAction: API.OperationMethod<DescribeServiceActionInput & RegionInput, DescribeServiceActionOutput, DescribeServiceActionError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceActionExecutionParametersError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Finds the default parameters for a specific self-service action on a specific provisioned product and returns a map of the results to the user.
 */
export declare const describeServiceActionExecutionParameters: API.OperationMethod<DescribeServiceActionExecutionParametersInput & RegionInput, DescribeServiceActionExecutionParametersOutput, DescribeServiceActionExecutionParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeTagOptionError = ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Gets information about the specified TagOption.
 */
export declare const describeTagOption: API.OperationMethod<DescribeTagOptionInput & RegionInput, DescribeTagOptionOutput, DescribeTagOptionError, Credentials | HttpClient.HttpClient>;
export type DisableAWSOrganizationsAccessError = InvalidStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Disable portfolio sharing through the Organizations service. This command will not
 * delete your current shares, but prevents you from creating new shares throughout your
 * organization. Current shares are not kept in sync with your organization structure if the structure
 * changes after calling this API. Only the management account in the organization can call this API.
 *
 * You cannot call this API if there are active delegated administrators in the organization.
 *
 * Note that a delegated administrator is not authorized to invoke `DisableAWSOrganizationsAccess`.
 *
 * If you share an Service Catalog portfolio in an organization within
 * Organizations, and then disable Organizations access for Service Catalog,
 * the portfolio access permissions will not sync with the latest changes to the organization
 * structure. Specifically, accounts that you removed from the organization after
 * disabling Service Catalog access will retain access to the previously shared portfolio.
 */
export declare const disableAWSOrganizationsAccess: API.OperationMethod<DisableAWSOrganizationsAccessInput & RegionInput, DisableAWSOrganizationsAccessOutput, DisableAWSOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type DisassociateBudgetFromResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified budget from the specified resource.
 */
export declare const disassociateBudgetFromResource: API.OperationMethod<DisassociateBudgetFromResourceInput & RegionInput, DisassociateBudgetFromResourceOutput, DisassociateBudgetFromResourceError, Credentials | HttpClient.HttpClient>;
export type DisassociatePrincipalFromPortfolioError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a previously associated principal ARN from a specified
 * portfolio.
 *
 * The `PrincipalType` and `PrincipalARN` must match the
 * `AssociatePrincipalWithPortfolio` call request details. For example,
 * to disassociate an association created with a `PrincipalARN` of `PrincipalType`
 * IAM you must use the `PrincipalType` IAM when calling `DisassociatePrincipalFromPortfolio`.
 *
 * For portfolios that have been shared with principal name sharing enabled: after disassociating a principal,
 * share recipient accounts will no longer be able to provision products in this portfolio using a role matching the name
 * of the associated principal.
 *
 * For more information, review associate-principal-with-portfolio
 * in the Amazon Web Services CLI Command Reference.
 *
 * If you disassociate a principal from a portfolio, with PrincipalType as `IAM`, the same principal will
 * still have access to the portfolio if it matches one of the associated principals of type `IAM_PATTERN`.
 * To fully remove access for a principal, verify all the associated Principals of type `IAM_PATTERN`,
 * and then ensure you disassociate any `IAM_PATTERN` principals that match the principal
 * whose access you are removing.
 */
export declare const disassociatePrincipalFromPortfolio: API.OperationMethod<DisassociatePrincipalFromPortfolioInput & RegionInput, DisassociatePrincipalFromPortfolioOutput, DisassociatePrincipalFromPortfolioError, Credentials | HttpClient.HttpClient>;
export type DisassociateProductFromPortfolioError = InvalidParametersException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified product from the specified portfolio.
 *
 * A delegated admin is authorized to invoke this command.
 */
export declare const disassociateProductFromPortfolio: API.OperationMethod<DisassociateProductFromPortfolioInput & RegionInput, DisassociateProductFromPortfolioOutput, DisassociateProductFromPortfolioError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceActionFromProvisioningArtifactError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified self-service action association from the specified provisioning artifact.
 */
export declare const disassociateServiceActionFromProvisioningArtifact: API.OperationMethod<DisassociateServiceActionFromProvisioningArtifactInput & RegionInput, DisassociateServiceActionFromProvisioningArtifactOutput, DisassociateServiceActionFromProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type DisassociateTagOptionFromResourceError = ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Disassociates the specified TagOption from the specified resource.
 */
export declare const disassociateTagOptionFromResource: API.OperationMethod<DisassociateTagOptionFromResourceInput & RegionInput, DisassociateTagOptionFromResourceOutput, DisassociateTagOptionFromResourceError, Credentials | HttpClient.HttpClient>;
export type EnableAWSOrganizationsAccessError = InvalidStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Enable portfolio sharing feature through Organizations. This API will allow Service Catalog to receive updates on your organization in order to sync your shares with the
 * current structure. This API can only be called by the management account in the organization.
 *
 * When you call this API, Service Catalog calls `organizations:EnableAWSServiceAccess` on your behalf so that your shares stay in sync with any changes in your Organizations structure.
 *
 * Note that a delegated administrator is not authorized to invoke `EnableAWSOrganizationsAccess`.
 *
 * If you have previously disabled Organizations access for Service Catalog, and then
 * enable access again, the portfolio access permissions might not sync with the latest changes to
 * the organization structure. Specifically, accounts that you removed from the organization after
 * disabling Service Catalog access, and before you enabled access again, can retain access to the
 * previously shared portfolio. As a result, an account that has been removed from the organization
 * might still be able to create or manage Amazon Web Services resources when it is no longer
 * authorized to do so. Amazon Web Services is working to resolve this issue.
 */
export declare const enableAWSOrganizationsAccess: API.OperationMethod<EnableAWSOrganizationsAccessInput & RegionInput, EnableAWSOrganizationsAccessOutput, EnableAWSOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type ExecuteProvisionedProductPlanError = InvalidParametersException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Provisions or modifies a product based on the resource changes for the specified plan.
 */
export declare const executeProvisionedProductPlan: API.OperationMethod<ExecuteProvisionedProductPlanInput & RegionInput, ExecuteProvisionedProductPlanOutput, ExecuteProvisionedProductPlanError, Credentials | HttpClient.HttpClient>;
export type ExecuteProvisionedProductServiceActionError = InvalidParametersException | InvalidStateException | ResourceNotFoundException | ProvisionedProductNotFound | CommonErrors;
/**
 * Executes a self-service action against a provisioned product.
 */
export declare const executeProvisionedProductServiceAction: API.OperationMethod<ExecuteProvisionedProductServiceActionInput & RegionInput, ExecuteProvisionedProductServiceActionOutput, ExecuteProvisionedProductServiceActionError, Credentials | HttpClient.HttpClient>;
export type GetAWSOrganizationsAccessStatusError = OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Get the Access Status for Organizations portfolio share feature. This API can only be
 * called by the management account in the organization or by a delegated admin.
 */
export declare const getAWSOrganizationsAccessStatus: API.OperationMethod<GetAWSOrganizationsAccessStatusInput & RegionInput, GetAWSOrganizationsAccessStatusOutput, GetAWSOrganizationsAccessStatusError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedProductOutputsError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * This API takes either a `ProvisonedProductId` or a `ProvisionedProductName`, along with a list of one or more output keys, and responds with the key/value pairs of those outputs.
 */
export declare const getProvisionedProductOutputs: API.PaginatedOperationMethod<GetProvisionedProductOutputsInput & RegionInput, GetProvisionedProductOutputsOutput, GetProvisionedProductOutputsError, Credentials | HttpClient.HttpClient, unknown>;
export type ImportAsProvisionedProductError = DuplicateResourceException | InvalidParametersException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Requests the import of a resource as an Service Catalog provisioned product
 * that is associated to an Service Catalog product and provisioning artifact.
 * Once imported, all supported governance actions are supported on the provisioned product.
 *
 * Resource import only supports CloudFormation stack ARNs. CloudFormation StackSets,
 * and non-root nested stacks, are not supported.
 *
 * The CloudFormation stack must have one
 * of the following statuses
 * to be imported: `CREATE_COMPLETE`, `UPDATE_COMPLETE`,
 * `UPDATE_ROLLBACK_COMPLETE`, `IMPORT_COMPLETE`, and
 * `IMPORT_ROLLBACK_COMPLETE`.
 *
 * Import of the resource requires that the CloudFormation stack template matches
 * the associated Service Catalog product provisioning artifact.
 *
 * When you import an existing CloudFormation stack
 * into a portfolio, Service Catalog does not apply the product's associated constraints
 * during the import process. Service Catalog applies the constraints
 * after you call `UpdateProvisionedProduct` for the provisioned product.
 *
 * The user or role that performs this operation must have the `cloudformation:GetTemplate`
 * and `cloudformation:DescribeStacks` IAM policy permissions.
 *
 * You can only import one provisioned product at a time. The product's CloudFormation stack must have the
 * `IMPORT_COMPLETE` status before you import another.
 */
export declare const importAsProvisionedProduct: API.OperationMethod<ImportAsProvisionedProductInput & RegionInput, ImportAsProvisionedProductOutput, ImportAsProvisionedProductError, Credentials | HttpClient.HttpClient>;
export type ListAcceptedPortfolioSharesError = InvalidParametersException | OperationNotSupportedException | CommonErrors;
/**
 * Lists all imported portfolios for which account-to-account shares were accepted by
 * this account. By specifying the `PortfolioShareType`, you can list portfolios for which
 * organizational shares were accepted by this account.
 */
export declare const listAcceptedPortfolioShares: API.PaginatedOperationMethod<ListAcceptedPortfolioSharesInput & RegionInput, ListAcceptedPortfolioSharesOutput, ListAcceptedPortfolioSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListBudgetsForResourceError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all the budgets associated to the specified resource.
 */
export declare const listBudgetsForResource: API.PaginatedOperationMethod<ListBudgetsForResourceInput & RegionInput, ListBudgetsForResourceOutput, ListBudgetsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConstraintsForPortfolioError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the constraints for the specified portfolio and product.
 */
export declare const listConstraintsForPortfolio: API.PaginatedOperationMethod<ListConstraintsForPortfolioInput & RegionInput, ListConstraintsForPortfolioOutput, ListConstraintsForPortfolioError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLaunchPathsError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the paths
 * to the specified product.
 * A path describes
 * how the user
 * gets access
 * to a specified product
 * and is necessary
 * when provisioning a product.
 * A path also determines the constraints
 * that are put on a product.
 * A path is dependent
 * on a specific product, porfolio, and principal.
 *
 * When provisioning a product
 * that's been added
 * to a portfolio,
 * you must grant your user, group, or role access
 * to the portfolio.
 * For more information,
 * see Granting users access
 * in the *Service Catalog User Guide*.
 */
export declare const listLaunchPaths: API.PaginatedOperationMethod<ListLaunchPathsInput & RegionInput, ListLaunchPathsOutput, ListLaunchPathsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOrganizationPortfolioAccessError = InvalidParametersException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the organization nodes that have access to the specified portfolio. This API can
 * only be called by the management account in the organization or by a delegated
 * admin.
 *
 * If a delegated admin is de-registered, they can no longer perform this operation.
 */
export declare const listOrganizationPortfolioAccess: API.PaginatedOperationMethod<ListOrganizationPortfolioAccessInput & RegionInput, ListOrganizationPortfolioAccessOutput, ListOrganizationPortfolioAccessError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPortfolioAccessError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the account IDs that have access to the specified portfolio.
 *
 * A delegated admin can list the accounts that have access to the shared portfolio. Note that if a delegated admin is de-registered, they can no longer perform this operation.
 */
export declare const listPortfolioAccess: API.PaginatedOperationMethod<ListPortfolioAccessInput & RegionInput, ListPortfolioAccessOutput, ListPortfolioAccessError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPortfoliosError = InvalidParametersException | CommonErrors;
/**
 * Lists all portfolios in the catalog.
 */
export declare const listPortfolios: API.PaginatedOperationMethod<ListPortfoliosInput & RegionInput, ListPortfoliosOutput, ListPortfoliosError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPortfoliosForProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all portfolios that the specified product is associated with.
 */
export declare const listPortfoliosForProduct: API.PaginatedOperationMethod<ListPortfoliosForProductInput & RegionInput, ListPortfoliosForProductOutput, ListPortfoliosForProductError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPrincipalsForPortfolioError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all `PrincipalARN`s and corresponding `PrincipalType`s associated with the specified portfolio.
 */
export declare const listPrincipalsForPortfolio: API.PaginatedOperationMethod<ListPrincipalsForPortfolioInput & RegionInput, ListPrincipalsForPortfolioOutput, ListPrincipalsForPortfolioError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProvisionedProductPlansError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the plans for the specified provisioned product or all plans to which the user has access.
 */
export declare const listProvisionedProductPlans: API.PaginatedOperationMethod<ListProvisionedProductPlansInput & RegionInput, ListProvisionedProductPlansOutput, ListProvisionedProductPlansError, Credentials | HttpClient.HttpClient, ProvisionedProductPlanSummary>;
export type ListProvisioningArtifactsError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all provisioning artifacts (also known as versions) for the specified product.
 */
export declare const listProvisioningArtifacts: API.OperationMethod<ListProvisioningArtifactsInput & RegionInput, ListProvisioningArtifactsOutput, ListProvisioningArtifactsError, Credentials | HttpClient.HttpClient>;
export type ListProvisioningArtifactsForServiceActionError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all provisioning artifacts (also known as versions) for the specified self-service action.
 */
export declare const listProvisioningArtifactsForServiceAction: API.PaginatedOperationMethod<ListProvisioningArtifactsForServiceActionInput & RegionInput, ListProvisioningArtifactsForServiceActionOutput, ListProvisioningArtifactsForServiceActionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecordHistoryError = InvalidParametersException | CommonErrors;
/**
 * Lists the specified requests or all performed requests.
 */
export declare const listRecordHistory: API.PaginatedOperationMethod<ListRecordHistoryInput & RegionInput, ListRecordHistoryOutput, ListRecordHistoryError, Credentials | HttpClient.HttpClient, RecordDetail>;
export type ListResourcesForTagOptionError = InvalidParametersException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Lists the resources associated with the specified TagOption.
 */
export declare const listResourcesForTagOption: API.PaginatedOperationMethod<ListResourcesForTagOptionInput & RegionInput, ListResourcesForTagOptionOutput, ListResourcesForTagOptionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServiceActionsError = InvalidParametersException | CommonErrors;
/**
 * Lists all self-service actions.
 */
export declare const listServiceActions: API.PaginatedOperationMethod<ListServiceActionsInput & RegionInput, ListServiceActionsOutput, ListServiceActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServiceActionsForProvisioningArtifactError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a paginated list of self-service actions associated with the specified Product ID and Provisioning Artifact ID.
 */
export declare const listServiceActionsForProvisioningArtifact: API.PaginatedOperationMethod<ListServiceActionsForProvisioningArtifactInput & RegionInput, ListServiceActionsForProvisioningArtifactOutput, ListServiceActionsForProvisioningArtifactError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStackInstancesForProvisionedProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Returns summary information about stack instances that are associated with the specified `CFN_STACKSET` type provisioned product. You can filter for stack instances that are associated with a specific Amazon Web Services account name or Region.
 */
export declare const listStackInstancesForProvisionedProduct: API.PaginatedOperationMethod<ListStackInstancesForProvisionedProductInput & RegionInput, ListStackInstancesForProvisionedProductOutput, ListStackInstancesForProvisionedProductError, Credentials | HttpClient.HttpClient, StackInstance>;
export type ListTagOptionsError = InvalidParametersException | TagOptionNotMigratedException | CommonErrors;
/**
 * Lists the specified TagOptions or all TagOptions.
 */
export declare const listTagOptions: API.PaginatedOperationMethod<ListTagOptionsInput & RegionInput, ListTagOptionsOutput, ListTagOptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type NotifyProvisionProductEngineWorkflowResultError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Notifies the result
 * of the provisioning engine execution.
 */
export declare const notifyProvisionProductEngineWorkflowResult: API.OperationMethod<NotifyProvisionProductEngineWorkflowResultInput & RegionInput, NotifyProvisionProductEngineWorkflowResultOutput, NotifyProvisionProductEngineWorkflowResultError, Credentials | HttpClient.HttpClient>;
export type NotifyTerminateProvisionedProductEngineWorkflowResultError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Notifies the result
 * of the terminate engine execution.
 */
export declare const notifyTerminateProvisionedProductEngineWorkflowResult: API.OperationMethod<NotifyTerminateProvisionedProductEngineWorkflowResultInput & RegionInput, NotifyTerminateProvisionedProductEngineWorkflowResultOutput, NotifyTerminateProvisionedProductEngineWorkflowResultError, Credentials | HttpClient.HttpClient>;
export type NotifyUpdateProvisionedProductEngineWorkflowResultError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Notifies the result
 * of the update engine execution.
 */
export declare const notifyUpdateProvisionedProductEngineWorkflowResult: API.OperationMethod<NotifyUpdateProvisionedProductEngineWorkflowResultInput & RegionInput, NotifyUpdateProvisionedProductEngineWorkflowResultOutput, NotifyUpdateProvisionedProductEngineWorkflowResultError, Credentials | HttpClient.HttpClient>;
export type ProvisionProductError = DuplicateResourceException | InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Provisions the specified product.
 *
 * A provisioned product is a resourced instance
 * of a product.
 * For example,
 * provisioning a product
 * that's based
 * on an CloudFormation template
 * launches an CloudFormation stack and its underlying resources.
 * You can check the status
 * of this request
 * using DescribeRecord.
 *
 * If the request contains a tag key
 * with an empty list
 * of values,
 * there's a tag conflict
 * for that key.
 * Don't include conflicted keys
 * as tags,
 * or this will cause the error "Parameter validation failed: Missing required parameter in Tags[*N*]:*Value*".
 *
 * When provisioning a product
 * that's been added
 * to a portfolio,
 * you must grant your user, group, or role access
 * to the portfolio.
 * For more information,
 * see Granting users access
 * in the *Service Catalog User Guide*.
 */
export declare const provisionProduct: API.OperationMethod<ProvisionProductInput & RegionInput, ProvisionProductOutput, ProvisionProductError, Credentials | HttpClient.HttpClient>;
export type RejectPortfolioShareError = ResourceNotFoundException | CommonErrors;
/**
 * Rejects an offer to share the specified portfolio.
 */
export declare const rejectPortfolioShare: API.OperationMethod<RejectPortfolioShareInput & RegionInput, RejectPortfolioShareOutput, RejectPortfolioShareError, Credentials | HttpClient.HttpClient>;
export type ScanProvisionedProductsError = InvalidParametersException | CommonErrors;
/**
 * Lists the provisioned products that are available (not terminated).
 *
 * To use additional filtering, see SearchProvisionedProducts.
 */
export declare const scanProvisionedProducts: API.PaginatedOperationMethod<ScanProvisionedProductsInput & RegionInput, ScanProvisionedProductsOutput, ScanProvisionedProductsError, Credentials | HttpClient.HttpClient, ProvisionedProductDetail>;
export type SearchProductsError = InvalidParametersException | CommonErrors;
/**
 * Gets information about the products to which the caller has access.
 */
export declare const searchProducts: API.PaginatedOperationMethod<SearchProductsInput & RegionInput, SearchProductsOutput, SearchProductsError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchProductsAsAdminError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Gets information about the products for the specified portfolio or all products.
 */
export declare const searchProductsAsAdmin: API.PaginatedOperationMethod<SearchProductsAsAdminInput & RegionInput, SearchProductsAsAdminOutput, SearchProductsAsAdminError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchProvisionedProductsError = InvalidParametersException | CommonErrors;
/**
 * Gets information about the provisioned products that meet the specified criteria.
 */
export declare const searchProvisionedProducts: API.PaginatedOperationMethod<SearchProvisionedProductsInput & RegionInput, SearchProvisionedProductsOutput, SearchProvisionedProductsError, Credentials | HttpClient.HttpClient, unknown>;
export type TerminateProvisionedProductError = ResourceNotFoundException | CommonErrors;
/**
 * Terminates the specified provisioned product.
 *
 * This operation does not delete any records associated with the provisioned product.
 *
 * You can check the status of this request using DescribeRecord.
 */
export declare const terminateProvisionedProduct: API.OperationMethod<TerminateProvisionedProductInput & RegionInput, TerminateProvisionedProductOutput, TerminateProvisionedProductError, Credentials | HttpClient.HttpClient>;
export type UpdateConstraintError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified constraint.
 */
export declare const updateConstraint: API.OperationMethod<UpdateConstraintInput & RegionInput, UpdateConstraintOutput, UpdateConstraintError, Credentials | HttpClient.HttpClient>;
export type UpdatePortfolioError = InvalidParametersException | LimitExceededException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Updates the specified portfolio.
 *
 * You cannot update a product that was shared with you.
 */
export declare const updatePortfolio: API.OperationMethod<UpdatePortfolioInput & RegionInput, UpdatePortfolioOutput, UpdatePortfolioError, Credentials | HttpClient.HttpClient>;
export type UpdatePortfolioShareError = InvalidParametersException | InvalidStateException | OperationNotSupportedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified portfolio share. You can use this API to enable or disable `TagOptions` sharing
 * or Principal sharing for an existing portfolio share.
 *
 * The portfolio share cannot be updated if the `CreatePortfolioShare` operation is `IN_PROGRESS`, as the share is not available to recipient entities.
 * In this case, you must wait for the portfolio share to be completed.
 *
 * You must provide the `accountId` or organization node in the input, but not both.
 *
 * If the portfolio is shared to both an external account and an organization node, and both shares need to be updated, you must invoke `UpdatePortfolioShare` separately for each share type.
 *
 * This API cannot be used for removing the portfolio share. You must use `DeletePortfolioShare` API for that action.
 *
 * When you associate a principal with portfolio, a potential privilege escalation path may occur when that portfolio is
 * then shared with other accounts. For a user in a recipient account who is *not* an Service Catalog Admin,
 * but still has the ability to create Principals (Users/Groups/Roles), that user could create a role that matches a principal
 * name association for the portfolio. Although this user may not know which principal names are associated through
 * Service Catalog, they may be able to guess the user. If this potential escalation path is a concern, then
 * Service Catalog recommends using `PrincipalType` as `IAM`. With this configuration,
 * the `PrincipalARN` must already exist in the recipient account before it can be associated.
 */
export declare const updatePortfolioShare: API.OperationMethod<UpdatePortfolioShareInput & RegionInput, UpdatePortfolioShareOutput, UpdatePortfolioShareError, Credentials | HttpClient.HttpClient>;
export type UpdateProductError = InvalidParametersException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Updates the specified product.
 */
export declare const updateProduct: API.OperationMethod<UpdateProductInput & RegionInput, UpdateProductOutput, UpdateProductError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedProductError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Requests updates to the configuration of the specified provisioned product.
 *
 * If there are tags associated with the object, they cannot be updated or added.
 * Depending on the specific updates requested, this operation can update with no
 * interruption, with some interruption, or replace the provisioned product entirely.
 *
 * You can check the status of this request using DescribeRecord.
 */
export declare const updateProvisionedProduct: API.OperationMethod<UpdateProvisionedProductInput & RegionInput, UpdateProvisionedProductOutput, UpdateProvisionedProductError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedProductPropertiesError = InvalidParametersException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Requests updates to the properties of the specified provisioned product.
 */
export declare const updateProvisionedProductProperties: API.OperationMethod<UpdateProvisionedProductPropertiesInput & RegionInput, UpdateProvisionedProductPropertiesOutput, UpdateProvisionedProductPropertiesError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisioningArtifactError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified provisioning artifact (also known as a version) for the specified product.
 *
 * You cannot update a provisioning artifact for a product that was shared with you.
 */
export declare const updateProvisioningArtifact: API.OperationMethod<UpdateProvisioningArtifactInput & RegionInput, UpdateProvisioningArtifactOutput, UpdateProvisioningArtifactError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceActionError = InvalidParametersException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a self-service action.
 */
export declare const updateServiceAction: API.OperationMethod<UpdateServiceActionInput & RegionInput, UpdateServiceActionOutput, UpdateServiceActionError, Credentials | HttpClient.HttpClient>;
export type UpdateTagOptionError = DuplicateResourceException | InvalidParametersException | ResourceNotFoundException | TagOptionNotMigratedException | CommonErrors;
/**
 * Updates the specified TagOption.
 */
export declare const updateTagOption: API.OperationMethod<UpdateTagOptionInput & RegionInput, UpdateTagOptionOutput, UpdateTagOptionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=service-catalog.d.ts.map