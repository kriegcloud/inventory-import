import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DetectedLanguageLowConfidenceException_base: S.TaggedErrorClass<"DetectedLanguageLowConfidenceException", {
    readonly message: any;
    readonly DetectedLanguageCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DetectedLanguageLowConfidenceException extends /*@__PURE__*/ DetectedLanguageLowConfidenceException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidFilterException_base: S.TaggedErrorClass<"InvalidFilterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFilterException extends /*@__PURE__*/ InvalidFilterException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TextSizeLimitExceededException_base: S.TaggedErrorClass<"TextSizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextSizeLimitExceededException extends /*@__PURE__*/ TextSizeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceArn: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedDisplayLanguageCodeException_base: S.TaggedErrorClass<"UnsupportedDisplayLanguageCodeException", {
    readonly message: any;
    readonly DisplayLanguageCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDisplayLanguageCodeException extends /*@__PURE__*/ UnsupportedDisplayLanguageCodeException_base {
}
declare const UnsupportedLanguagePairException_base: S.TaggedErrorClass<"UnsupportedLanguagePairException", {
    readonly message: any;
    readonly SourceLanguageCode: any;
    readonly TargetLanguageCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedLanguagePairException extends /*@__PURE__*/ UnsupportedLanguagePairException_base {
}
export type ResourceName = string;
export type Description = string;
export type S3Uri = string;
export type ParallelDataFormat = "TSV" | "CSV" | "TMX" | (string & {});
export interface ParallelDataConfig {
    S3Uri?: string | undefined;
    Format?: ParallelDataFormat | undefined;
}
export type EncryptionKeyType = "KMS" | (string & {});
export type EncryptionKeyID = string;
export interface EncryptionKey {
    Type: EncryptionKeyType;
    Id: string;
}
export type ClientTokenString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateParallelDataRequest {
    Name: string;
    Description?: string | undefined;
    ParallelDataConfig: ParallelDataConfig;
    EncryptionKey?: EncryptionKey | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type ParallelDataStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export interface CreateParallelDataResponse {
    Name?: string | undefined;
    Status?: ParallelDataStatus | undefined;
}
export interface DeleteParallelDataRequest {
    Name: string;
}
export interface DeleteParallelDataResponse {
    Name?: string | undefined;
    Status?: ParallelDataStatus | undefined;
}
export interface DeleteTerminologyRequest {
    Name: string;
}
export interface DeleteTerminologyResponse {
}
export type JobId = string;
export interface DescribeTextTranslationJobRequest {
    JobId: string;
}
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERROR" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export interface JobDetails {
    TranslatedDocumentsCount?: number | undefined;
    DocumentsWithErrorsCount?: number | undefined;
    InputDocumentsCount?: number | undefined;
}
export type LanguageCodeString = string;
export type TargetLanguageCodeStringList = string[];
export type ResourceNameList = string[];
export type UnboundedLengthString = string;
export type ContentType = string;
export interface InputDataConfig {
    S3Uri: string;
    ContentType: string;
}
export interface OutputDataConfig {
    S3Uri: string;
    EncryptionKey?: EncryptionKey | undefined;
}
export type IamRoleArn = string;
export type Formality = "FORMAL" | "INFORMAL" | (string & {});
export type Profanity = "MASK" | (string & {});
export type Brevity = "ON" | (string & {});
export interface TranslationSettings {
    Formality?: Formality | undefined;
    Profanity?: Profanity | undefined;
    Brevity?: Brevity | undefined;
}
export interface TextTranslationJobProperties {
    JobId?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    JobDetails?: JobDetails | undefined;
    SourceLanguageCode?: string | undefined;
    TargetLanguageCodes?: string[] | undefined;
    TerminologyNames?: string[] | undefined;
    ParallelDataNames?: string[] | undefined;
    Message?: string | undefined;
    SubmittedTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    DataAccessRoleArn?: string | undefined;
    Settings?: TranslationSettings | undefined;
}
export interface DescribeTextTranslationJobResponse {
    TextTranslationJobProperties?: TextTranslationJobProperties | undefined;
}
export interface GetParallelDataRequest {
    Name: string;
}
export type ParallelDataArn = string;
export type LanguageCodeStringList = string[];
export interface ParallelDataProperties {
    Name?: string | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
    Status?: ParallelDataStatus | undefined;
    SourceLanguageCode?: string | undefined;
    TargetLanguageCodes?: string[] | undefined;
    ParallelDataConfig?: ParallelDataConfig | undefined;
    Message?: string | undefined;
    ImportedDataSize?: number | undefined;
    ImportedRecordCount?: number | undefined;
    FailedRecordCount?: number | undefined;
    SkippedRecordCount?: number | undefined;
    EncryptionKey?: EncryptionKey | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    LatestUpdateAttemptStatus?: ParallelDataStatus | undefined;
    LatestUpdateAttemptAt?: Date | undefined;
}
export interface ParallelDataDataLocation {
    RepositoryType: string;
    Location: string;
}
export interface GetParallelDataResponse {
    ParallelDataProperties?: ParallelDataProperties | undefined;
    DataLocation?: ParallelDataDataLocation | undefined;
    AuxiliaryDataLocation?: ParallelDataDataLocation | undefined;
    LatestUpdateAttemptAuxiliaryDataLocation?: ParallelDataDataLocation | undefined;
}
export type TerminologyDataFormat = "CSV" | "TMX" | "TSV" | (string & {});
export interface GetTerminologyRequest {
    Name: string;
    TerminologyDataFormat?: TerminologyDataFormat | undefined;
}
export type TerminologyArn = string;
export type Directionality = "UNI" | "MULTI" | (string & {});
export interface TerminologyProperties {
    Name?: string | undefined;
    Description?: string | undefined;
    Arn?: string | undefined;
    SourceLanguageCode?: string | undefined;
    TargetLanguageCodes?: string[] | undefined;
    EncryptionKey?: EncryptionKey | undefined;
    SizeBytes?: number | undefined;
    TermCount?: number | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Directionality?: Directionality | undefined;
    Message?: string | undefined;
    SkippedTermCount?: number | undefined;
    Format?: TerminologyDataFormat | undefined;
}
export interface TerminologyDataLocation {
    RepositoryType: string;
    Location: string;
}
export interface GetTerminologyResponse {
    TerminologyProperties?: TerminologyProperties | undefined;
    TerminologyDataLocation?: TerminologyDataLocation | undefined;
    AuxiliaryDataLocation?: TerminologyDataLocation | undefined;
}
export type MergeStrategy = "OVERWRITE" | (string & {});
export type TerminologyFile = Uint8Array | redacted.Redacted<Uint8Array>;
export interface TerminologyData {
    File: Uint8Array | redacted.Redacted<Uint8Array>;
    Format: TerminologyDataFormat;
    Directionality?: Directionality | undefined;
}
export interface ImportTerminologyRequest {
    Name: string;
    MergeStrategy: MergeStrategy;
    Description?: string | undefined;
    TerminologyData: TerminologyData;
    EncryptionKey?: EncryptionKey | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportTerminologyResponse {
    TerminologyProperties?: TerminologyProperties | undefined;
    AuxiliaryDataLocation?: TerminologyDataLocation | undefined;
}
export type DisplayLanguageCode = "de" | "en" | "es" | "fr" | "it" | "ja" | "ko" | "pt" | "zh" | "zh-TW" | (string & {});
export type NextToken = string;
export type MaxResultsInteger = number;
export interface ListLanguagesRequest {
    DisplayLanguageCode?: DisplayLanguageCode | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type LocalizedNameString = string;
export interface Language {
    LanguageName: string;
    LanguageCode: string;
}
export type LanguagesList = Language[];
export interface ListLanguagesResponse {
    Languages?: Language[] | undefined;
    DisplayLanguageCode?: DisplayLanguageCode | undefined;
    NextToken?: string | undefined;
}
export interface ListParallelDataRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ParallelDataPropertiesList = ParallelDataProperties[];
export interface ListParallelDataResponse {
    ParallelDataPropertiesList?: ParallelDataProperties[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListTerminologiesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TerminologyPropertiesList = TerminologyProperties[];
export interface ListTerminologiesResponse {
    TerminologyPropertiesList?: TerminologyProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface TextTranslationJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmittedBeforeTime?: Date | undefined;
    SubmittedAfterTime?: Date | undefined;
}
export interface ListTextTranslationJobsRequest {
    Filter?: TextTranslationJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TextTranslationJobPropertiesList = TextTranslationJobProperties[];
export interface ListTextTranslationJobsResponse {
    TextTranslationJobPropertiesList?: TextTranslationJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface StartTextTranslationJobRequest {
    JobName?: string | undefined;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    SourceLanguageCode: string;
    TargetLanguageCodes: string[];
    TerminologyNames?: string[] | undefined;
    ParallelDataNames?: string[] | undefined;
    ClientToken: string;
    Settings?: TranslationSettings | undefined;
}
export interface StartTextTranslationJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopTextTranslationJobRequest {
    JobId: string;
}
export interface StopTextTranslationJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type DocumentContent = Uint8Array | redacted.Redacted<Uint8Array>;
export interface Document {
    Content: Uint8Array | redacted.Redacted<Uint8Array>;
    ContentType: string;
}
export interface TranslateDocumentRequest {
    Document: Document;
    TerminologyNames?: string[] | undefined;
    SourceLanguageCode: string;
    TargetLanguageCode: string;
    Settings?: TranslationSettings | undefined;
}
export type TranslatedDocumentContent = Uint8Array | redacted.Redacted<Uint8Array>;
export interface TranslatedDocument {
    Content: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface Term {
    SourceText?: string | undefined;
    TargetText?: string | undefined;
}
export type TermList = Term[];
export interface AppliedTerminology {
    Name?: string | undefined;
    Terms?: Term[] | undefined;
}
export type AppliedTerminologyList = AppliedTerminology[];
export interface TranslateDocumentResponse {
    TranslatedDocument: TranslatedDocument;
    SourceLanguageCode: string;
    TargetLanguageCode: string;
    AppliedTerminologies?: AppliedTerminology[] | undefined;
    AppliedSettings?: TranslationSettings | undefined;
}
export type BoundedLengthString = string;
export interface TranslateTextRequest {
    Text: string;
    TerminologyNames?: string[] | undefined;
    SourceLanguageCode: string;
    TargetLanguageCode: string;
    Settings?: TranslationSettings | undefined;
}
export type TranslatedTextString = string;
export interface TranslateTextResponse {
    TranslatedText: string;
    SourceLanguageCode: string;
    TargetLanguageCode: string;
    AppliedTerminologies?: AppliedTerminology[] | undefined;
    AppliedSettings?: TranslationSettings | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateParallelDataRequest {
    Name: string;
    Description?: string | undefined;
    ParallelDataConfig: ParallelDataConfig;
    ClientToken: string;
}
export interface UpdateParallelDataResponse {
    Name?: string | undefined;
    Status?: ParallelDataStatus | undefined;
    LatestUpdateAttemptStatus?: ParallelDataStatus | undefined;
    LatestUpdateAttemptAt?: Date | undefined;
}
export type CreateParallelDataError = ConcurrentModificationException | ConflictException | InternalServerException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a parallel data resource in Amazon Translate by importing an input file from
 * Amazon S3. Parallel data files contain examples that show how you want segments of text to be
 * translated. By adding parallel data, you can influence the style, tone, and word choice in
 * your translation output.
 */
export declare const createParallelData: API.OperationMethod<CreateParallelDataRequest & RegionInput, CreateParallelDataResponse, CreateParallelDataError, Credentials | HttpClient.HttpClient>;
export type DeleteParallelDataError = ConcurrentModificationException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a parallel data resource in Amazon Translate.
 */
export declare const deleteParallelData: API.OperationMethod<DeleteParallelDataRequest & RegionInput, DeleteParallelDataResponse, DeleteParallelDataError, Credentials | HttpClient.HttpClient>;
export type DeleteTerminologyError = InternalServerException | InvalidParameterValueException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * A synchronous action that deletes a custom terminology.
 */
export declare const deleteTerminology: API.OperationMethod<DeleteTerminologyRequest & RegionInput, DeleteTerminologyResponse, DeleteTerminologyError, Credentials | HttpClient.HttpClient>;
export type DescribeTextTranslationJobError = InternalServerException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an asynchronous batch translation job including name,
 * ID, status, source and target languages, input/output S3 buckets, and so on.
 */
export declare const describeTextTranslationJob: API.OperationMethod<DescribeTextTranslationJobRequest & RegionInput, DescribeTextTranslationJobResponse, DescribeTextTranslationJobError, Credentials | HttpClient.HttpClient>;
export type GetParallelDataError = InternalServerException | InvalidParameterValueException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about a parallel data resource.
 */
export declare const getParallelData: API.OperationMethod<GetParallelDataRequest & RegionInput, GetParallelDataResponse, GetParallelDataError, Credentials | HttpClient.HttpClient>;
export type GetTerminologyError = InternalServerException | InvalidParameterValueException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a custom terminology.
 */
export declare const getTerminology: API.OperationMethod<GetTerminologyRequest & RegionInput, GetTerminologyResponse, GetTerminologyError, Credentials | HttpClient.HttpClient>;
export type ImportTerminologyError = ConcurrentModificationException | InternalServerException | InvalidParameterValueException | LimitExceededException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates or updates a custom terminology, depending on whether one already exists for the
 * given terminology name. Importing a terminology with the same name as an existing one will
 * merge the terminologies based on the chosen merge strategy. The only supported merge strategy
 * is OVERWRITE, where the imported terminology overwrites the existing terminology of the same
 * name.
 *
 * If you import a terminology that overwrites an existing one, the new terminology takes up
 * to 10 minutes to fully propagate. After that, translations have access to the new
 * terminology.
 */
export declare const importTerminology: API.OperationMethod<ImportTerminologyRequest & RegionInput, ImportTerminologyResponse, ImportTerminologyError, Credentials | HttpClient.HttpClient>;
export type ListLanguagesError = InternalServerException | InvalidParameterValueException | TooManyRequestsException | UnsupportedDisplayLanguageCodeException | CommonErrors;
/**
 * Provides a list of languages (RFC-5646 codes and names) that Amazon Translate supports.
 */
export declare const listLanguages: API.PaginatedOperationMethod<ListLanguagesRequest & RegionInput, ListLanguagesResponse, ListLanguagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListParallelDataError = InternalServerException | InvalidParameterValueException | TooManyRequestsException | CommonErrors;
/**
 * Provides a list of your parallel data resources in Amazon Translate.
 */
export declare const listParallelData: API.PaginatedOperationMethod<ListParallelDataRequest & RegionInput, ListParallelDataResponse, ListParallelDataError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | InvalidParameterValueException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a given Amazon Translate resource.
 * For more information, see
 * Tagging your resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTerminologiesError = InternalServerException | InvalidParameterValueException | TooManyRequestsException | CommonErrors;
/**
 * Provides a list of custom terminologies associated with your account.
 */
export declare const listTerminologies: API.PaginatedOperationMethod<ListTerminologiesRequest & RegionInput, ListTerminologiesResponse, ListTerminologiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTextTranslationJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the batch translation jobs that you have submitted.
 */
export declare const listTextTranslationJobs: API.PaginatedOperationMethod<ListTextTranslationJobsRequest & RegionInput, ListTextTranslationJobsResponse, ListTextTranslationJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type StartTextTranslationJobError = InternalServerException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | UnsupportedLanguagePairException | CommonErrors;
/**
 * Starts an asynchronous batch translation job. Use batch translation jobs to
 * translate large volumes of text across multiple documents at once.
 * For batch translation, you can input documents with different source languages (specify `auto`
 * as the source language). You can specify one
 * or more target languages. Batch translation translates each input document into each of the target languages.
 * For more information, see
 * Asynchronous batch processing.
 *
 * Batch translation jobs can be described with the DescribeTextTranslationJob operation, listed with the ListTextTranslationJobs operation, and stopped with the StopTextTranslationJob operation.
 */
export declare const startTextTranslationJob: API.OperationMethod<StartTextTranslationJobRequest & RegionInput, StartTextTranslationJobResponse, StartTextTranslationJobError, Credentials | HttpClient.HttpClient>;
export type StopTextTranslationJobError = InternalServerException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops an asynchronous batch translation job that is in progress.
 *
 * If the job's state is `IN_PROGRESS`, the job will be marked for termination and
 * put into the `STOP_REQUESTED` state. If the job completes before it can be stopped,
 * it is put into the `COMPLETED` state. Otherwise, the job is put into the
 * `STOPPED` state.
 *
 * Asynchronous batch translation jobs are started with the StartTextTranslationJob operation. You can use the DescribeTextTranslationJob or ListTextTranslationJobs
 * operations to get a batch translation job's `JobId`.
 */
export declare const stopTextTranslationJob: API.OperationMethod<StopTextTranslationJobRequest & RegionInput, StopTextTranslationJobResponse, StopTextTranslationJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InternalServerException | InvalidParameterValueException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Associates a specific tag with a resource. A tag is a key-value pair
 * that adds as a metadata to a resource.
 * For more information, see
 * Tagging your resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TranslateDocumentError = InternalServerException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | TooManyRequestsException | UnsupportedLanguagePairException | CommonErrors;
/**
 * Translates the input document from the source language to the target language.
 * This synchronous operation supports text, HTML, or Word documents as the input document.
 *
 * `TranslateDocument` supports translations from English to any supported language,
 * and from any supported language to English. Therefore, specify either the source language code
 * or the target language code as "en" (English).
 *
 * If you set the `Formality` parameter, the request will fail if the target language does
 * not support formality. For a list of target languages that support formality, see
 * Setting formality.
 */
export declare const translateDocument: API.OperationMethod<TranslateDocumentRequest & RegionInput, TranslateDocumentResponse, TranslateDocumentError, Credentials | HttpClient.HttpClient>;
export type TranslateTextError = DetectedLanguageLowConfidenceException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | UnsupportedLanguagePairException | CommonErrors;
/**
 * Translates input text from the source language to the target language. For a list of
 * available languages and language codes, see Supported languages.
 */
export declare const translateText: API.OperationMethod<TranslateTextRequest & RegionInput, TranslateTextResponse, TranslateTextError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InternalServerException | InvalidParameterValueException | ResourceNotFoundException | CommonErrors;
/**
 * Removes a specific tag associated with an Amazon Translate resource.
 * For more information, see
 * Tagging your resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateParallelDataError = ConcurrentModificationException | ConflictException | InternalServerException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a previously created parallel data resource by importing a new input file from
 * Amazon S3.
 */
export declare const updateParallelData: API.OperationMethod<UpdateParallelDataRequest & RegionInput, UpdateParallelDataResponse, UpdateParallelDataError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=translate.d.ts.map