import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import { type ReplayInput, type ReplayResult, type Routed } from "./CatchUp.ts";
import type { Delivery } from "./Platform.ts";
/**
 * Backfill: how a view or projection added after its sources recorded events
 * (or rebuilt by bumping its version) receives their history, in timestamp
 * order, without a central coordinator.
 *
 * Roles, each a durable object that owns its own storage:
 *
 * - **Directory nodes** form a tree (fan-out 16, one subtree per source) that
 *   lists every source instance. It is only an index: a run reads it.
 * - **A run** per consumer generation: its root lists the directory into
 *   subtrees and paces them through **relays**, each fanning out six ways,
 *   backing off when the account's load is refused. A consumer keyed by its
 *   source needs one pass; any other needs two, with a barrier between.
 * - **Sources** (aggregate instances, and view keys other consumers read)
 *   serve their stored rows on any code, and switch a consumer to live
 *   delivery once a reader has read all of them.
 * - **Scanners**, one per source instance and consumer generation, read its
 *   rows, route them with the consumer's code and push each key its part.
 * - **Consumer keys** (view keys, projection keys) buffer what they receive
 *   ordered by `(at, stream, seq)` and, told that every source's history is
 *   in, apply it in that order. A key keyed by its source reads its source's
 *   rows itself and applies them as it reads.
 *
 * Every step does a bounded amount of work, records its progress before it
 * answers, and is idempotent, so a crash, a retry or a redeploy at any point
 * resumes where it left off. Every continuation is a scheduled job, never a
 * nested call.
 *
 * @internal
 */
/** A key-ordered store, as a Durable Object's storage is. */
export interface Storage {
    readonly get: <A>(key: string) => Effect.Effect<A | undefined>;
    readonly put: (entries: Readonly<Record<string, unknown>>) => Effect.Effect<void>;
    readonly delete: (keys: ReadonlyArray<string>) => Effect.Effect<void>;
    /** Entries under `prefix`, in key order, after `startAfter`. */
    readonly list: <A>(options: {
        readonly prefix: string;
        readonly startAfter?: string;
        readonly limit?: number;
    }) => Effect.Effect<ReadonlyArray<readonly [string, A]>>;
    /** Run `effect` with every other call on this object held back. */
    readonly exclusive: <A, E>(effect: Effect.Effect<A, E>) => Effect.Effect<A, E>;
}
/** Durable, at-least-once jobs on one object: a job with the same id replaces a pending one. */
export interface Jobs {
    /**
     * Run job `id` after `afterMillis`. The earliest request wins: a job already due
     * sooner isn't postponed (every job is idempotent, so running early is safe),
     * including one asked for while that job runs.
     */
    readonly schedule: (id: string, afterMillis: number) => Effect.Effect<void>;
}
/** An instance listed in the directory: its source (aggregate or view) and id. */
export interface SourceRef {
    readonly source: string;
    readonly id: string;
    /**
     * A view key's generation, once its view has been rebuilt: each generation's
     * keys are their own objects, so this names the one that holds its entries.
     */
    readonly generation?: number;
}
/**
 * What a run needs to know of a consumer. The deploy that adds the consumer
 * passes it to the run, so the run never depends on what an object's code knows.
 */
export interface Plan {
    /** The sources (aggregates and views, by name) the consumer reads: the subtrees a run lists (all if absent). */
    readonly sources?: ReadonlyArray<string>;
    /** Each key reads one instance, the one with its own id: the leaf starts the keys itself. */
    readonly singleSource: boolean;
    /** The generation of each source that is a rebuilt view (see {@link SourceRef.generation}). */
    readonly generations?: Readonly<Record<string, number>>;
}
/** `ref` with its source's generation, by the plan. */
export declare const withGeneration: (ref: SourceRef, plan: Plan | undefined) => SourceRef;
export interface NodeRpc {
    readonly register: (path: string, ref: SourceRef) => Effect.Effect<void>;
    readonly child: (path: string, child: string) => Effect.Effect<void>;
    /**
     * A page of what a node lists: its own instances after `after`, and (on the
     * first page) its children. Any code answers it, whatever consumers it knows.
     */
    readonly list: (path: string, after: string | undefined) => Effect.Effect<Listing>;
}
/** A page of a directory node's listing. */
export interface Listing {
    readonly rows: ReadonlyArray<SourceRef>;
    readonly children: ReadonlyArray<string>;
    /** Where the next page starts, if there is one. */
    readonly next?: string;
}
export interface SourceRpc {
    /**
     * `cursor`, `log` and, at the end of the log, `handoff`, in one call: what a
     * reader of a short history needs. Older code doesn't have it: a reader falls
     * back to the three calls.
     */
    readonly read: (ref: SourceRef, target: string, key: string, after: number, limit: number) => Effect.Effect<Read>;
    /**
     * The last seq it routed live to `target`: a reader reads after it, since the
     * rows up to it reached their keys live. An instance with no cursors predates
     * catch-up: everything is live, up to its version.
     */
    readonly cursor: (ref: SourceRef, target: string) => Effect.Effect<number>;
    /**
     * Its stored rows (events, or a view key's entries) after `after`, as stored.
     * Any code answers it: nothing in it depends on the consumer asking.
     */
    readonly log: (ref: SourceRef, after: number, limit: number) => Effect.Effect<ReadonlyArray<unknown>>;
    /**
     * Route `target` live from now on, if the reader has read every row up to its
     * version (`through`): `"more"` if rows were added since, `"stale"` on code
     * without the target. `key` names the reader, for traces.
     */
    readonly handoff: (ref: SourceRef, target: string, key: string, through: number) => Effect.Effect<Handoff>;
}
/** What a source answers to `handoff`. */
export type Handoff = "live" | "more" | "stale";
/** What a reader gets from one `read`: rows after `from`, and at the end of the log, the handoff. */
export interface Read {
    /** Where it read from: after `after`, or where live routing stopped (for `after` 0). */
    readonly from: number;
    readonly rows: ReadonlyArray<unknown>;
    /** Fewer rows than asked for: the end of the log, and whether it switched the target to live there. */
    readonly handoff?: Handoff;
}
/** A page a key read from its source. */
export interface Pulled {
    readonly deliveries: ReadonlyArray<Delivery>;
    /** The source switched the key to live delivery: nothing more to read. */
    readonly live: boolean;
    /**
     * The last seq the source read for this page: the key's cursor moves past it,
     * even when those rows held nothing for the key.
     */
    readonly through?: number;
    /**
     * Nothing followed this page when it was read: the key reads again at once to
     * switch to live, rather than wait.
     */
    readonly end?: boolean;
}
export interface ConsumerRpc {
    /** History for a key, from a scanner: it buffers it until it is told every source's is in. */
    readonly push: (target: string, key: string, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<void>;
    /**
     * Every source's history is with the key: apply it. `"settled"` once applied;
     * it works on it for up to `waitMillis` before it answers.
     */
    readonly ready: (target: string, key: string, waitMillis?: number) => Effect.Effect<"pending" | "settled">;
    /**
     * Start a key of a consumer keyed by its source: it reads `ref`'s log itself.
     * `"settled"` once it has its history: it works on it for up to `waitMillis`
     * before it answers.
     */
    readonly start: (target: string, key: string, ref: SourceRef, waitMillis?: number) => Effect.Effect<"pending" | "settled">;
}
/**
 * A scanner reads one source instance's log for a consumer, routes it with the
 * consumer's code, and pushes each key its history: one object per source
 * instance and consumer generation, new with the deploy.
 */
export interface ScannerRpc {
    /** Push every key its history from `ref`, up to now: `true` once done, after up to `waitMillis`. */
    readonly scan: (target: string, ref: SourceRef, waitMillis: number) => Effect.Effect<boolean>;
    /** Tell every key it pushed to that all history is in: `true` once each has applied it. */
    readonly ready: (target: string, ref: SourceRef, waitMillis: number) => Effect.Effect<boolean>;
    /** A commit found the target behind on `ref` with no reader: read it and push what is new. */
    readonly kick: (target: string, ref: SourceRef) => Effect.Effect<void>;
}
/** What a relay works through: directory nodes to list, and source instances. */
export type RelayItem = {
    readonly path: string;
} | {
    readonly ref: SourceRef;
};
/** A pass of a relay tree over the directory, for one consumer. */
export interface RelayRun {
    readonly target: string;
    readonly plan: Plan;
    /**
     * `discover`: start each key (keyed by its source), or scan each source;
     * `ready`: tell each source's keys that every source's history is in.
     */
    readonly phase: "discover" | "ready";
    /**
     * When the pass answers (epoch ms): each relay keeps at its items until then,
     * and answers `false` if not all of them are done. Now, for one try at everything.
     */
    readonly deadline: number;
}
export interface RelayRpc {
    /**
     * Work through `items` for a run, and answer `true` once all of it is done.
     * `name` is the relay's place in the tree: each one is its own object.
     */
    readonly run: (name: string, run: RelayRun, items: ReadonlyArray<RelayItem>) => Effect.Effect<RelayResult>;
}
/** What a relay answers: which of its items are done, and how many calls the account's load refused. */
export interface RelayResult {
    readonly done: ReadonlyArray<boolean>;
    readonly refused: number;
    /** Source instances done under it. */
    readonly instances?: number;
    /** A call it gave up on, and why. */
    readonly failure?: string;
}
/** How far a consumer's run has got: `ready` once every source's history is with its keys. */
export type Phase = "unknown" | "discover" | "ready" | "complete";
/** The root of a consumer's run: one object per consumer generation. */
export interface RunRpc {
    /**
     * Start the run, once. A run already started (or complete) is found, not
     * started again; one started with a different plan (the consumer reads other
     * sources now, without a version bump) answers `changed`.
     */
    readonly begin: (target: string, plan: Plan) => Effect.Effect<Begin>;
    readonly phase: (target: string) => Effect.Effect<Phase>;
    readonly progress: (target: string) => Effect.Effect<Progress>;
}
/** What starting a run answers. */
export type Begin = {
    readonly status: "started" | "complete";
}
/** Started with another plan: it reads what `started` says, not what was asked. */
 | {
    readonly status: "changed";
    readonly started: Plan;
};
/** Whether two plans read the same sources, at the same generations, the same way. */
export declare const samePlan: (a: Plan, b: Plan) => boolean;
/**
 * Why a deploy can't wait on a run started with another plan: the consumer now
 * reads sources its run doesn't, and only a new generation reads them.
 */
export declare const planChanged: (target: string, started: Plan, asked: Plan) => string;
declare const PlanChanged_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "BackfillPlanChanged";
} & Readonly<A>;
/** A consumer reads other sources than its backfill was started with, at the same version. */
export declare class PlanChanged extends PlanChanged_base<{
    readonly message: string;
}> {
}
/** How far a run has got, for a deploy to report while it waits. */
export interface Progress {
    readonly target: string;
    readonly phase: Phase;
    /** The subtrees of the directory this phase works through, and how many are done. */
    readonly subtrees: number;
    readonly done: number;
    /** Source instances (keys keyed by their source, or scanners) done in this phase. */
    readonly instances: number;
    /** Passes over the directory so far: a pass that isn't done in time is followed by another. */
    readonly passes: number;
    /** Calls Cloudflare refused for the account's load: the run backs off when it does. */
    readonly refused: number;
    /** When the run began, and when it last moved, in epoch milliseconds. */
    readonly startedAt?: number;
    readonly updatedAt?: number;
    /** The last call it gave up on, if any, and why. */
    readonly lastError?: string;
}
/** How the roles reach each other. */
export interface Network {
    readonly node: NodeRpc;
    readonly source: SourceRpc;
    readonly consumer: ConsumerRpc;
    readonly scanner: ScannerRpc;
    readonly relay: RelayRpc;
    readonly run: RunRpc;
}
/** Tuning, in rows and calls per step. */
export interface Limits {
    /** History rows a reader (a key keyed by its source, or a scanner) reads per call. */
    readonly page: number;
    /** Source instances a directory node handles per step, and calls it makes at once. */
    readonly nodePage: number;
    readonly concurrency: number;
    /** Buffered rows a key applies per step. */
    readonly apply: number;
    /** How long to wait before calling a stale source again, in milliseconds. */
    readonly staleRetryMillis: number;
    /**
     * How long before the first retry of a refused or failed call, in milliseconds:
     * right after a deploy its new code may not have reached the object yet.
     */
    readonly firstRetryMillis: number;
    /** How long a key without sources waits before asking whether discovery is complete again. */
    readonly pollMillis: number;
    /**
     * Instances a directory node lists before it splits into 16 children, so every
     * node's share of a listing stays bounded and the tree grows as log16 of the instances.
     */
    readonly leafSize: number;
    /** The depth instances list themselves at, before any split. */
    readonly depth: number;
}
/**
 * The depth instances list themselves at: 256 leaves, each splitting once it
 * fills. Wide enough that first commits spread over many objects, few enough
 * that a small Domain's directory stays small (every node costs a listing).
 */
export declare const DEPTH = 2;
export declare const defaultLimits: Limits;
/**
 * The directory has one subtree per source (`Account:`, `Deposits:`), so a run
 * for a consumer walks only the sources it reads. Within a subtree a node's path
 * is the source, a colon and a prefix of the instance's hash: `Account:a3`.
 */
export declare const leafOf: (ref: SourceRef, depth?: number) => string;
/** The source a node's subtree lists, or `undefined` for the root (and news relays). */
export declare const sourceOfPath: (path: string) => string | undefined;
/** A buffered delivery's place in a key's merge: timestamp, then stream, then seq. */
export declare const orderKey: (target: string, delivery: Delivery) => string;
/**
 * Cloudflare refuses calls when an account puts too much load on Durable
 * Objects, and resets an isolate whose objects (many share one) use too much
 * memory. Either is a sign to send less: a refused call is tried again later,
 * not at once, so a wide run backs off to the load the account can take
 * rather than collapse under its own retries.
 */
export declare const overloaded: (cause: Cause.Cause<unknown>) => boolean;
/** What a source instance gives the protocol. */
export interface SourceHost {
    readonly ref: SourceRef;
    /** Every consumer in the model this instance's code runs: a target outside it is from newer code. */
    readonly model: () => ReadonlyArray<string>;
    /** The consumers this instance's events reach, in the code it runs now. */
    readonly targets: () => ReadonlyArray<string>;
    /** Whether `target`'s keys are keyed by their source: each reads its own source's log. */
    readonly singleSource?: (target: string) => boolean;
    /** Its current version: the seq of its last event or entry. */
    readonly version: Effect.Effect<number>;
    readonly routed: Effect.Effect<Routed | undefined>;
    /** Route `target` live from the current version on. Called holding the exclusive section. */
    readonly markLive: (target: string) => Effect.Effect<void>;
    /** Its stored rows after `after`, as stored: what a reader routes with its own code. */
    readonly log: (after: number, limit: number) => Effect.Effect<ReadonlyArray<unknown>>;
}
/**
 * A source instance's part of the protocol: it serves its log as stored, on
 * any code, and switches a target to live delivery once a reader has read all
 * of it. Until then a commit withholds the target's deliveries (the reader
 * reads them from the log). The first commit to withhold them on code that
 * knows the target asks for a reader: an instance no run listed (one created
 * on older code during a rollout) is caught up that way.
 */
export declare const makeSource: (storage: Storage, jobs: Jobs, net: Network, host: SourceHost, limits?: Limits) => {
    /**
     * A commit withheld `target`'s deliveries: it is behind here. Ask for a
     * reader, once. Call inside the commit's exclusive section.
     */
    onCommit: (target: string) => Effect.Effect<void, never, never>;
    /**
     * Ask for a reader for each target this instance is behind on. An instance
     * lists itself in the directory after its first commit, so a consumer
     * deployed in between may have listed the directory without it: the next
     * commit would ask for a reader (see `onCommit`), and this does not wait
     * for one. Call it once the instance is listed.
     */
    catchUp: Effect.Effect<void, never, never>;
    log: (after: number, limit: number) => Effect.Effect<readonly unknown[], never, never>;
    cursor: (target: string) => Effect.Effect<number, never, never>;
    read: (target: string, key: string, after: number, limit: number) => Effect.Effect<{
        from: number;
        rows: readonly unknown[];
        handoff?: undefined;
    } | {
        from: number;
        rows: readonly unknown[];
        handoff: Handoff;
    }, never, never>;
    handoff: (target: string, key: string, through: number) => Effect.Effect<Handoff, never, never>;
    /** The backstop job: send what is staged. */
    flush: Effect.Effect<void, never, never>;
};
export type Source = ReturnType<typeof makeSource>;
/** What a scanner gives the protocol: the consumer's routing, in the code it runs. */
export interface ScannerHost {
    /** Route a source's stored rows (from its `log`) to `target`: each row's seq and its deliveries. */
    readonly route: (target: string, ref: SourceRef, rows: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<{
        readonly seq: number;
        readonly deliveries: ReadonlyArray<Delivery>;
    }>>;
}
/**
 * A scanner: reads one source instance's log, as stored, routes it with the
 * consumer's code, and pushes each key the deliveries it gets. At the end of
 * the log it asks the source to route the target live from there; a source
 * still on older code can't, so the scanner reads on later (what it reads then
 * is newer than the deploy, and arrives as live deliveries would).
 */
export declare const makeScanner: (storage: Storage, jobs: Jobs, net: Network, host: ScannerHost, limits?: Limits) => {
    scan: (target: string, ref: SourceRef, waitMillis: number) => Effect.Effect<boolean, never, never>;
    ready: (target: string, waitMillis: number) => Effect.Effect<boolean, never, never>;
    kick: (target: string, ref: SourceRef) => Effect.Effect<void, never, never>;
    /** Run a scheduled job by its id. */
    run: (id: string) => Effect.Effect<void, never, never>;
};
export type Scanner = ReturnType<typeof makeScanner>;
/** What a consumer key gives the protocol. */
export interface ConsumerHost {
    readonly key: string;
    /** This consumer's target id in the code this instance runs. */
    readonly target: () => string;
    /**
     * Whether each key hears only from the source instance with its own id: then
     * it reads that instance's log itself, as soon as its leaf starts it (no
     * barrier), and applies what it reads directly (nothing to merge).
     */
    readonly singleSource?: () => boolean;
    /**
     * Route a source's stored rows (from its `log`) to this consumer: each row's
     * seq and its deliveries. Runs this key's code, whatever code the source runs.
     */
    readonly history?: (ref: SourceRef, rows: ReadonlyArray<unknown>) => Effect.Effect<ReadonlyArray<{
        readonly seq: number;
        readonly deliveries: ReadonlyArray<Delivery>;
    }>>;
    /** The sources this consumer reads (`Account`, `Deposits`): where it asks about discovery. */
    readonly sources?: () => ReadonlyArray<string>;
    /**
     * Apply deliveries in order, as the live path would. Called holding the
     * exclusive section.
     */
    readonly apply: (deliveries: ReadonlyArray<Delivery>) => Effect.Effect<void>;
    /** Work an `apply` left for after its exclusive section commits (pushes, sends). */
    readonly after?: Effect.Effect<void>;
}
/**
 * A consumer key's part of the protocol. Its host passes every delivery for
 * the current target through {@link Consumer.admit} before applying it, and
 * serves `source` and `ready`.
 */
export declare const makeConsumer: (storage: Storage, jobs: Jobs, net: Network, host: ConsumerHost, limits?: Limits) => {
    /**
     * Deliveries for `target` arriving at this key. `true`: apply them now, as
     * usual. `false`: the key is backfilling, and they were buffered.
     */
    admit: (target: string, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<boolean, never, never>;
    push: (target: string, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<void, never, never>;
    start: (target: string, ref: SourceRef, waitMillis?: number) => Effect.Effect<"pending" | "settled", never, never>;
    ready: (target: string, waitMillis?: number) => Effect.Effect<"pending" | "settled", never, never>;
    /** The merge job for one target. */
    merge: (target: string) => Effect.Effect<boolean>;
    /** Is a backfill of `target` still running on this key? */
    backfilling: (target: string) => Effect.Effect<boolean, never, never>;
};
export type Consumer = ReturnType<typeof makeConsumer>;
/**
 * A directory node: lists instances, links itself into its parent, and splits
 * into 16 children once it lists more than `leafSize`. Runs only read it.
 */
export declare const makeNode: (storage: Storage, jobs: Jobs, net: Network, limits?: Limits) => {
    register: (path: string, ref: SourceRef) => Effect.Effect<void, never, never>;
    child: (path: string, child: string) => Effect.Effect<void, never, never>;
    list: (path: string, after: string | undefined) => Effect.Effect<{
        rows: SourceRef[];
        children: string[];
        next?: string | undefined;
    }, never, never>;
    /** Run a scheduled job by its id. */
    run: (id: string) => Effect.Effect<void, never, never>;
};
export type Node = ReturnType<typeof makeNode>;
/**
 * How many calls a relay makes at once: Cloudflare runs at most six outgoing
 * calls per invocation, so a wider relay would queue its own calls.
 */
export declare const RELAY_FANOUT = 6;
/**
 * A relay: one node of the tree a pass of a run fans out over, each its own
 * object. Given more than {@link RELAY_FANOUT} items it splits them among as
 * many child relays; given one directory node, it lists it and works through
 * what it lists; given a few, it handles each source instance itself and
 * hands each directory node to a child relay. Every relay answers once
 * everything under it is done, so a pass is done when the first one answers,
 * after about log6 of the instances levels of calls.
 *
 * For each source instance, it starts the instance's key (a consumer keyed by
 * its source), or calls the instance's scanner: to push its history
 * (`discover`), or to tell the keys it pushed to that all history is in
 * (`ready`).
 *
 * It keeps no state: a relay that fails is called again, and work already
 * done answers at once. It reads the directory, which any code serves, and
 * calls keys and scanners, which are new with the deploy: so a run never
 * waits for an existing object to run the deployed code.
 */
export declare const makeRelay: (net: Network) => {
    run: (name: string, relayRun: RelayRun, items: ReadonlyArray<RelayItem>) => Effect.Effect<RelayResult>;
    frontier: (run: RelayRun, until: number) => Effect.Effect<readonly RelayItem[] | undefined, never, never>;
};
export type Relay = ReturnType<typeof makeRelay>;
/**
 * The root of a consumer's run: it drives passes of a relay tree from its own
 * jobs. A consumer keyed by its source needs one pass (each key reads its own
 * source). Any other needs two, with a barrier between: `discover` pushes every
 * source's history to its keys, and only once all of it is in does `ready`
 * tell the keys to apply it, in timestamp order. Each pass is repeated until
 * it is done.
 */
export declare const makeRun: (storage: Storage, jobs: Jobs, net: Network, options: {
    /** How long a pass keeps at it before it answers (0: one try at everything). */
    readonly waitMillis: number;
    /** How long before a pass that wasn't done runs again, doubling each time up to 30s. */
    readonly againMillis: number;
}) => {
    begin: (target: string, plan: Plan) => Effect.Effect<{
        status: "changed";
        started: Plan;
    } | {
        started?: undefined;
        status: "complete" | "started";
    }, never, never>;
    phase: (target: string) => Effect.Effect<Phase, never, never>;
    /** How far the run has got; its phase is the run's own, so it never reads ahead of it. */
    progress: (target: string) => Effect.Effect<{
        startedAt?: number;
        updatedAt?: number;
        lastError?: string;
        target: string;
        subtrees: number;
        done: number;
        instances: number;
        passes: number;
        refused: number;
        phase: Phase;
    }, never, never>;
    /** Run a scheduled job by its id. */
    run: (id: string) => Effect.Effect<void, never, never>;
};
export type Run = ReturnType<typeof makeRun>;
/**
 * Route a commit's deliveries (an aggregate's events, or a view key's entries):
 * live to caught-up consumers, and through the backfill to lagging ones. Call
 * inside the commit's exclusive section; returns what to send and the new cursors.
 */
export declare const routeCommit: (source: Source, targets: ReadonlyArray<string>, routed: Routed | undefined, before: number, after: number, deliveries: ReadonlyArray<Delivery>) => Effect.Effect<{
    send: readonly Delivery[];
    routed: Readonly<Record<string, number>>;
}, never, never>;
/** Route stored rows to one target only, as history: each row's seq and its deliveries. */
export declare const routeRows: <Row>(replay: (input: ReplayInput<Row>) => Effect.Effect<ReplayResult>, id: string, targets: ReadonlyArray<string>, target: string, rows: ReadonlyArray<Row>, seqOf: (row: Row) => number) => Effect.Effect<{
    seq: number;
    deliveries: readonly Delivery[];
}[], never, never>;
/** A consumer's kind and name from its target id: `view:Name#2` is the view `Name`. */
export declare const consumerOf: (target: string) => {
    kind: "view" | "projection";
    name: string;
};
export {};
//# sourceMappingURL=Backfill.d.ts.map