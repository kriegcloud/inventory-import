/**
 * Shared stream utilities for AWS protocols.
 * Provides helpers for converting between Effect Streams, ReadableStreams, and text.
 */
import * as Effect from "effect/Effect";
import * as Stream from "effect/Stream";
import { ParseError } from "../errors.ts";
import type { StreamingInputBody } from "../traits.ts";
export declare const readEffectStreamAsText: <Err>(stream: Stream.Stream<Uint8Array, Err>) => Effect.Effect<string, Err>;
/**
 * Read a body as text (for non-streaming responses), in the calling fiber.
 * This is lazy - only consumes when called.
 */
export declare const readStreamAsText: (stream: string | StreamBody) => Effect.Effect<string, ParseError>;
/**
 * Read a body fully as raw bytes (for non-streaming binary responses such
 * as httpPayload blobs), in the calling fiber.
 * This is lazy - only consumes when called.
 */
export declare const readStreamAsBytes: (stream: string | StreamBody) => Effect.Effect<Uint8Array, ParseError>;
/**
 * A streaming body: a web stream, or an Effect stream that runs in the
 * caller's fiber. A response body is the HttpClient's Effect stream.
 */
export type StreamBody = ReadableStream<Uint8Array> | Stream.Stream<Uint8Array, unknown>;
/** Whether a body streams (is not a buffered string or bytes). */
export declare const isStreamBody: (body: unknown) => body is StreamBody;
/**
 * A streaming body as an Effect stream. An Effect stream is returned as is,
 * so it runs in the fiber that sends the request, with its context and
 * tracing; a web stream is read from that fiber.
 */
export declare const bodyStream: (body: StreamBody) => Stream.Stream<Uint8Array, unknown>;
/**
 * Check if a value is an Effect Stream.
 * Uses duck typing since Stream doesn't have a built-in type guard.
 */
export declare function isEffectStream(u: unknown): u is Stream.Stream<unknown, unknown, unknown>;
/**
 * Convert various streaming input types to a format suitable for fetch.
 * Handles strings, Uint8Array, ArrayBuffer, Blob, ReadableStream, and Effect Stream.
 */
export declare function convertStreamingInput(value: string | StreamingInputBody): string | Uint8Array | StreamBody;
/**
 * A streaming response body as the Effect Stream the caller reads. The
 * HttpClient's stream is returned as is, so it is read in the caller's fiber.
 */
export declare const readableToEffectStream: (stream: string | StreamBody) => Stream.Stream<Uint8Array, Error, never>;
/**
 * `stream` with its chunks joined until each is at least `minSize` bytes,
 * as the AWS SDK's `createBufferedReadableStream` does. A chunk already that
 * large passes through when nothing is buffered; the last chunk can be any
 * size.
 */
export declare const minChunkSize: (minSize: number) => <E, R>(stream: Stream.Stream<Uint8Array, E, R>) => Stream.Stream<Uint8Array, E, R>;
//# sourceMappingURL=stream.d.ts.map