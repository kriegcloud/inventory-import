import type * as AST from "effect/SchemaAST";
/** Legacy Signature Version 2 auth (SimpleDB); see `AwsAuthSigv2Trait`. */
export declare const AwsAuthSigv2: (trait: {
    name: string;
}) => import("@distilled.cloud/core/trait").Annotation;
/** aws.protocols#restJson1 */
export declare const awsProtocolsRestJson1Symbol: "distilled-aws/aws.protocols#restJson1";
export interface AwsProtocolsRestJson1Trait {
    http?: string[];
    eventStreamHttp?: string[];
}
export declare const AwsProtocolsRestJson1: (trait?: AwsProtocolsRestJson1Trait) => import("@distilled.cloud/core/trait").Annotation;
/** aws.protocols#awsJson1_0 */
export declare const awsProtocolsAwsJson1_0Symbol: "distilled-aws/aws.protocols#awsJson1_0";
export interface AwsProtocolsAwsJson1_0Trait {
    http?: string[];
    eventStreamHttp?: string[];
    /** `aws.protocols#awsQueryCompatible`: the service was an awsQuery one. */
    awsQueryCompatible?: boolean;
}
export declare const AwsProtocolsAwsJson1_0: (trait?: AwsProtocolsAwsJson1_0Trait) => import("@distilled.cloud/core/trait").Annotation;
/** aws.protocols#awsJson1_1 */
export declare const awsProtocolsAwsJson1_1Symbol: "distilled-aws/aws.protocols#awsJson1_1";
export interface AwsProtocolsAwsJson1_1Trait {
    http?: string[];
    eventStreamHttp?: string[];
    /** `aws.protocols#awsQueryCompatible`: the service was an awsQuery one. */
    awsQueryCompatible?: boolean;
}
export declare const AwsProtocolsAwsJson1_1: (trait?: AwsProtocolsAwsJson1_1Trait) => import("@distilled.cloud/core/trait").Annotation;
/** aws.protocols#awsQuery */
export declare const awsProtocolsAwsQuerySymbol: "distilled-aws/aws.protocols#awsQuery";
export declare const AwsProtocolsAwsQuery: () => import("@distilled.cloud/core/trait").Annotation;
/** aws.protocols#ec2Query */
export declare const awsProtocolsEc2QuerySymbol: "distilled-aws/aws.protocols#ec2Query";
export declare const AwsProtocolsEc2Query: () => import("@distilled.cloud/core/trait").Annotation;
export declare const hasRestJson1Protocol: (ast: AST.AST) => boolean;
export declare const hasAwsJson1_0Protocol: (ast: AST.AST) => boolean;
export declare const hasAwsJson1_1Protocol: (ast: AST.AST) => boolean;
export declare const hasAwsQueryProtocol: (ast: AST.AST) => boolean;
export declare const hasEc2QueryProtocol: (ast: AST.AST) => boolean;
//# sourceMappingURL=protocol-traits.d.ts.map