import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AddFlowOutputs420Exception_base: S.TaggedErrorClass<"AddFlowOutputs420Exception", {
    readonly message: any;
}>;
export declare class AddFlowOutputs420Exception extends /*@__PURE__*/ AddFlowOutputs420Exception_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CreateBridge420Exception_base: S.TaggedErrorClass<"CreateBridge420Exception", {
    readonly message: any;
}>;
export declare class CreateBridge420Exception extends /*@__PURE__*/ CreateBridge420Exception_base {
}
declare const CreateFlow420Exception_base: S.TaggedErrorClass<"CreateFlow420Exception", {
    readonly message: any;
}>;
export declare class CreateFlow420Exception extends /*@__PURE__*/ CreateFlow420Exception_base {
}
declare const CreateGateway420Exception_base: S.TaggedErrorClass<"CreateGateway420Exception", {
    readonly message: any;
}>;
export declare class CreateGateway420Exception extends /*@__PURE__*/ CreateGateway420Exception_base {
}
declare const DestinationEndpointServiceQuotaExceededException_base: S.TaggedErrorClass<"DestinationEndpointServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class DestinationEndpointServiceQuotaExceededException extends /*@__PURE__*/ DestinationEndpointServiceQuotaExceededException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GrantFlowEntitlements420Exception_base: S.TaggedErrorClass<"GrantFlowEntitlements420Exception", {
    readonly message: any;
}>;
export declare class GrantFlowEntitlements420Exception extends /*@__PURE__*/ GrantFlowEntitlements420Exception_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const RouterInputServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterInputServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterInputServiceQuotaExceededException extends /*@__PURE__*/ RouterInputServiceQuotaExceededException_base {
}
declare const RouterNetworkInterfaceServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterNetworkInterfaceServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterNetworkInterfaceServiceQuotaExceededException extends /*@__PURE__*/ RouterNetworkInterfaceServiceQuotaExceededException_base {
}
declare const RouterOutputServiceQuotaExceededException_base: S.TaggedErrorClass<"RouterOutputServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class RouterOutputServiceQuotaExceededException extends /*@__PURE__*/ RouterOutputServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const SourceEndpointServiceQuotaExceededException_base: S.TaggedErrorClass<"SourceEndpointServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class SourceEndpointServiceQuotaExceededException extends /*@__PURE__*/ SourceEndpointServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type BridgeArn = string;
export type Protocol = "zixi-push" | "rtp-fec" | "rtp" | "zixi-pull" | "rist" | "st2110-jpegxs" | "cdi" | "srt-listener" | "srt-caller" | "fujitsu-qos" | "udp" | "ndi-speed-hq" | "rtmp-push" | (string & {});
export interface AddBridgeNetworkOutputRequest {
    IpAddress?: string | undefined;
    Name?: string | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
    Ttl?: number | undefined;
}
export interface AddBridgeOutputRequest {
    NetworkOutput?: AddBridgeNetworkOutputRequest | undefined;
}
export type __listOfAddBridgeOutputRequest = AddBridgeOutputRequest[];
export interface AddBridgeOutputsRequest {
    BridgeArn: string;
    Outputs?: AddBridgeOutputRequest[] | undefined;
}
export interface BridgeFlowOutput {
    FlowArn?: string | undefined;
    FlowSourceArn?: string | undefined;
    Name?: string | undefined;
}
export interface BridgeNetworkOutput {
    IpAddress?: string | undefined;
    Name?: string | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
    Ttl?: number | undefined;
}
export interface BridgeOutput {
    FlowOutput?: BridgeFlowOutput | undefined;
    NetworkOutput?: BridgeNetworkOutput | undefined;
}
export type __listOfBridgeOutput = BridgeOutput[];
export interface AddBridgeOutputsResponse {
    BridgeArn?: string | undefined;
    Outputs?: (BridgeOutput & {
        FlowOutput: BridgeFlowOutput & {
            FlowArn: string;
            FlowSourceArn: string;
            Name: string;
        };
        NetworkOutput: BridgeNetworkOutput & {
            IpAddress: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
            Ttl: number;
        };
    })[] | undefined;
}
export interface VpcInterfaceAttachment {
    VpcInterfaceName?: string | undefined;
}
export interface AddBridgeFlowSourceRequest {
    FlowArn?: string | undefined;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
    Name?: string | undefined;
}
export interface MulticastSourceSettings {
    MulticastSourceIp?: string | undefined;
}
export interface AddBridgeNetworkSourceRequest {
    MulticastIp?: string | undefined;
    MulticastSourceSettings?: MulticastSourceSettings | undefined;
    Name?: string | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
}
export interface AddBridgeSourceRequest {
    FlowSource?: AddBridgeFlowSourceRequest | undefined;
    NetworkSource?: AddBridgeNetworkSourceRequest | undefined;
}
export type __listOfAddBridgeSourceRequest = AddBridgeSourceRequest[];
export interface AddBridgeSourcesRequest {
    BridgeArn: string;
    Sources?: AddBridgeSourceRequest[] | undefined;
}
export interface BridgeFlowSource {
    FlowArn?: string | undefined;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
    Name?: string | undefined;
    OutputArn?: string | undefined;
}
export interface BridgeNetworkSource {
    MulticastIp?: string | undefined;
    MulticastSourceSettings?: MulticastSourceSettings | undefined;
    Name?: string | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
}
export interface BridgeSource {
    FlowSource?: BridgeFlowSource | undefined;
    NetworkSource?: BridgeNetworkSource | undefined;
}
export type __listOfBridgeSource = BridgeSource[];
export interface AddBridgeSourcesResponse {
    BridgeArn?: string | undefined;
    Sources?: (BridgeSource & {
        FlowSource: BridgeFlowSource & {
            FlowArn: string;
            Name: string;
        };
        NetworkSource: BridgeNetworkSource & {
            MulticastIp: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
        };
    })[] | undefined;
}
export type FlowArn = string;
export type Colorimetry = "BT601" | "BT709" | "BT2020" | "BT2100" | "ST2065-1" | "ST2065-3" | "XYZ" | (string & {});
export type Range = "NARROW" | "FULL" | "FULLPROTECT" | (string & {});
export type ScanMode = "progressive" | "interlace" | "progressive-segmented-frame" | (string & {});
export type Tcs = "SDR" | "PQ" | "HLG" | "LINEAR" | "BT2100LINPQ" | "BT2100LINHLG" | "ST2065-1" | "ST428-1" | "DENSITY" | (string & {});
export interface FmtpRequest {
    ChannelOrder?: string | undefined;
    Colorimetry?: Colorimetry | undefined;
    ExactFramerate?: string | undefined;
    Par?: string | undefined;
    Range?: Range | undefined;
    ScanMode?: ScanMode | undefined;
    Tcs?: Tcs | undefined;
}
export interface MediaStreamAttributesRequest {
    Fmtp?: FmtpRequest | undefined;
    Lang?: string | undefined;
}
export type MediaStreamType = "video" | "audio" | "ancillary-data" | (string & {});
export type __mapOfString = {
    [key: string]: string | undefined;
};
export interface AddMediaStreamRequest {
    Attributes?: MediaStreamAttributesRequest | undefined;
    ClockRate?: number | undefined;
    Description?: string | undefined;
    MediaStreamId?: number | undefined;
    MediaStreamName?: string | undefined;
    MediaStreamType?: MediaStreamType | undefined;
    VideoFormat?: string | undefined;
    MediaStreamTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfAddMediaStreamRequest = AddMediaStreamRequest[];
export interface AddFlowMediaStreamsRequest {
    FlowArn: string;
    MediaStreams?: AddMediaStreamRequest[] | undefined;
}
export interface Fmtp {
    ChannelOrder?: string | undefined;
    Colorimetry?: Colorimetry | undefined;
    ExactFramerate?: string | undefined;
    Par?: string | undefined;
    Range?: Range | undefined;
    ScanMode?: ScanMode | undefined;
    Tcs?: Tcs | undefined;
}
export interface MediaStreamAttributes {
    Fmtp?: Fmtp | undefined;
    Lang?: string | undefined;
}
export interface MediaStream {
    Attributes?: MediaStreamAttributes | undefined;
    ClockRate?: number | undefined;
    Description?: string | undefined;
    Fmt?: number | undefined;
    MediaStreamId?: number | undefined;
    MediaStreamName?: string | undefined;
    MediaStreamType?: MediaStreamType | undefined;
    VideoFormat?: string | undefined;
}
export type __listOfMediaStream = MediaStream[];
export interface AddFlowMediaStreamsResponse {
    FlowArn?: string | undefined;
    MediaStreams?: (MediaStream & {
        Fmt: number;
        MediaStreamId: number;
        MediaStreamName: string;
        MediaStreamType: MediaStreamType;
        Attributes: MediaStreamAttributes & {
            Fmtp: Fmtp;
        };
    })[] | undefined;
}
export type __listOfString = string[];
export type Algorithm = "aes128" | "aes192" | "aes256" | (string & {});
export type KeyType = "speke" | "static-key" | "srt-password" | (string & {});
export interface Encryption {
    Algorithm?: Algorithm | undefined;
    ConstantInitializationVector?: string | undefined;
    DeviceId?: string | undefined;
    KeyType?: KeyType | undefined;
    Region?: string | undefined;
    ResourceId?: string | undefined;
    RoleArn?: string | undefined;
    SecretArn?: string | undefined;
    Url?: string | undefined;
}
export interface InterfaceRequest {
    Name?: string | undefined;
}
export interface DestinationConfigurationRequest {
    DestinationIp?: string | undefined;
    DestinationPort?: number | undefined;
    Interface?: InterfaceRequest | undefined;
}
export type __listOfDestinationConfigurationRequest = DestinationConfigurationRequest[];
export type EncodingName = "jxsv" | "raw" | "smpte291" | "pcm" | (string & {});
export type EncoderProfile = "main" | "high" | (string & {});
export interface EncodingParametersRequest {
    CompressionFactor?: number | undefined;
    EncoderProfile?: EncoderProfile | undefined;
}
export interface MediaStreamOutputConfigurationRequest {
    DestinationConfigurations?: DestinationConfigurationRequest[] | undefined;
    EncodingName?: EncodingName | undefined;
    EncodingParameters?: EncodingParametersRequest | undefined;
    MediaStreamName?: string | undefined;
}
export type __listOfMediaStreamOutputConfigurationRequest = MediaStreamOutputConfigurationRequest[];
export type OutputStatus = "ENABLED" | "DISABLED" | (string & {});
export type State = "ENABLED" | "DISABLED" | (string & {});
export type FlowTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type SecretArn = string;
export type RoleArn = string;
export interface SecretsManagerEncryptionKeyConfiguration {
    SecretArn: string;
    RoleArn: string;
}
export interface AutomaticEncryptionKeyConfiguration {
}
export type FlowTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: undefined;
} | {
    SecretsManager?: undefined;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface FlowTransitEncryption {
    EncryptionKeyType?: FlowTransitEncryptionKeyType | undefined;
    EncryptionKeyConfiguration: FlowTransitEncryptionKeyConfiguration;
}
export type NdiOutputTimecodeSource = "EMBEDDED_TIMECODE" | "UTC_SYSTEM_TIME" | (string & {});
export type NdiAudioReferenceLevel = number;
export type TlsEncryptionType = "PUBLIC" | (string & {});
export interface PublicTlsEncryptionConfiguration {
}
export type TlsEncryptionConfiguration = {
    Public: PublicTlsEncryptionConfiguration;
};
export interface TlsEncryption {
    EncryptionType?: TlsEncryptionType | undefined;
    EncryptionConfiguration: TlsEncryptionConfiguration;
}
export interface RtmpPushOutputSettings {
    ApplicationName?: string | undefined;
    StreamName?: string | undefined;
    TlsEncryption?: TlsEncryption | undefined;
}
export interface AddOutputRequest {
    CidrAllowList?: string[] | undefined;
    Description?: string | undefined;
    Destination?: string | undefined;
    Encryption?: Encryption | undefined;
    MaxLatency?: number | undefined;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfigurationRequest[] | undefined;
    MinLatency?: number | undefined;
    Name?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
    RemoteId?: string | undefined;
    SenderControlPort?: number | undefined;
    SmoothingLatency?: number | undefined;
    StreamId?: string | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
    OutputStatus?: OutputStatus | undefined;
    NdiSpeedHqQuality?: number | undefined;
    NdiProgramName?: string | undefined;
    OutputTags?: {
        [key: string]: string | undefined;
    } | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption | undefined;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource | undefined;
    NdiAudioReferenceLevel?: number | undefined;
    RtmpPushSettings?: RtmpPushOutputSettings | undefined;
}
export type __listOfAddOutputRequest = AddOutputRequest[];
export interface AddFlowOutputsRequest {
    FlowArn: string;
    Outputs?: AddOutputRequest[] | undefined;
}
export interface Interface {
    Name?: string | undefined;
}
export interface DestinationConfiguration {
    DestinationIp?: string | undefined;
    DestinationPort?: number | undefined;
    Interface?: Interface | undefined;
    OutboundIp?: string | undefined;
}
export type __listOfDestinationConfiguration = DestinationConfiguration[];
export interface EncodingParameters {
    CompressionFactor?: number | undefined;
    EncoderProfile?: EncoderProfile | undefined;
}
export interface MediaStreamOutputConfiguration {
    DestinationConfigurations?: DestinationConfiguration[] | undefined;
    EncodingName?: EncodingName | undefined;
    EncodingParameters?: EncodingParameters | undefined;
    MediaStreamName?: string | undefined;
}
export type __listOfMediaStreamOutputConfiguration = MediaStreamOutputConfiguration[];
export interface NdiSourceSettings {
    SourceName?: string | undefined;
    AudioReferenceLevel?: number | undefined;
}
export type RtmpPushNamingType = "MANUAL" | "AUTOMATIC" | (string & {});
export interface RtmpPushSourceSettings {
    ApplicationName?: string | undefined;
    StreamName?: string | undefined;
    NamingType?: RtmpPushNamingType | undefined;
}
export interface Transport {
    CidrAllowList?: string[] | undefined;
    MaxBitrate?: number | undefined;
    MaxLatency?: number | undefined;
    MaxSyncBuffer?: number | undefined;
    MinLatency?: number | undefined;
    Protocol?: Protocol | undefined;
    RemoteId?: string | undefined;
    SenderControlPort?: number | undefined;
    SenderIpAddress?: string | undefined;
    SmoothingLatency?: number | undefined;
    SourceListenerAddress?: string | undefined;
    SourceListenerPort?: number | undefined;
    StreamId?: string | undefined;
    NdiSpeedHqQuality?: number | undefined;
    NdiProgramName?: string | undefined;
    NdiSourceSettings?: NdiSourceSettings | undefined;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource | undefined;
    NdiAudioReferenceLevel?: number | undefined;
    RtmpPushSourceSettings?: RtmpPushSourceSettings | undefined;
    RtmpPushOutputSettings?: RtmpPushOutputSettings | undefined;
}
export type __listOfInteger = number[];
export interface Output {
    DataTransferSubscriberFeePercent?: number | undefined;
    Description?: string | undefined;
    Destination?: string | undefined;
    Encryption?: Encryption | undefined;
    EntitlementArn?: string | undefined;
    ListenerAddress?: string | undefined;
    MediaLiveInputArn?: string | undefined;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfiguration[] | undefined;
    Name?: string | undefined;
    OutputArn?: string | undefined;
    Port?: number | undefined;
    Transport?: Transport | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
    BridgeArn?: string | undefined;
    BridgePorts?: number[] | undefined;
    OutputStatus?: OutputStatus | undefined;
    PeerIpAddress?: string | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption | undefined;
    ConnectedRouterInputArn?: string | undefined;
}
export type __listOfOutput = Output[];
export interface AddFlowOutputsResponse {
    FlowArn?: string | undefined;
    Outputs?: (Output & {
        Name: string;
        OutputArn: string;
        Encryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            DestinationConfigurations: (DestinationConfiguration & {
                DestinationIp: string;
                DestinationPort: number;
                Interface: Interface & {
                    Name: string;
                };
                OutboundIp: string;
            })[];
            EncodingParameters: EncodingParameters & {
                CompressionFactor: number;
                EncoderProfile: EncoderProfile;
            };
        })[];
        Transport: Transport & {
            Protocol: Protocol;
            RtmpPushSourceSettings: RtmpPushSourceSettings & {
                ApplicationName: string;
                StreamName: string;
                NamingType: RtmpPushNamingType;
            };
            RtmpPushOutputSettings: RtmpPushOutputSettings & {
                ApplicationName: string;
                StreamName: string;
            };
        };
    })[] | undefined;
}
export interface InputConfigurationRequest {
    InputPort?: number | undefined;
    Interface?: InterfaceRequest | undefined;
}
export type __listOfInputConfigurationRequest = InputConfigurationRequest[];
export interface MediaStreamSourceConfigurationRequest {
    EncodingName?: EncodingName | undefined;
    InputConfigurations?: InputConfigurationRequest[] | undefined;
    MediaStreamName?: string | undefined;
}
export type __listOfMediaStreamSourceConfigurationRequest = MediaStreamSourceConfigurationRequest[];
export interface SetGatewayBridgeSourceRequest {
    BridgeArn?: string | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
}
export interface ManualRtmpPushNamingConfiguration {
    ApplicationName: string;
    StreamName: string;
}
export interface AutomaticRtmpPushNamingConfiguration {
}
export type RtmpPushNamingConfiguration = {
    Manual: ManualRtmpPushNamingConfiguration;
    Automatic?: undefined;
} | {
    Manual?: undefined;
    Automatic: AutomaticRtmpPushNamingConfiguration;
};
export interface SetRtmpPushSourceSettings {
    NamingConfiguration?: RtmpPushNamingConfiguration | undefined;
}
export interface SetSourceRequest {
    Decryption?: Encryption | undefined;
    Description?: string | undefined;
    EntitlementArn?: string | undefined;
    IngestPort?: number | undefined;
    MaxBitrate?: number | undefined;
    MaxLatency?: number | undefined;
    MaxSyncBuffer?: number | undefined;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfigurationRequest[] | undefined;
    MinLatency?: number | undefined;
    Name?: string | undefined;
    Protocol?: Protocol | undefined;
    SenderControlPort?: number | undefined;
    SenderIpAddress?: string | undefined;
    SourceListenerAddress?: string | undefined;
    SourceListenerPort?: number | undefined;
    StreamId?: string | undefined;
    VpcInterfaceName?: string | undefined;
    WhitelistCidr?: string | undefined;
    GatewayBridgeSource?: SetGatewayBridgeSourceRequest | undefined;
    NdiSourceSettings?: NdiSourceSettings | undefined;
    SourceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption | undefined;
    RtmpPushSettings?: SetRtmpPushSourceSettings | undefined;
}
export type __listOfSetSourceRequest = SetSourceRequest[];
export interface AddFlowSourcesRequest {
    FlowArn: string;
    Sources?: SetSourceRequest[] | undefined;
}
export interface InputConfiguration {
    InputIp?: string | undefined;
    InputPort?: number | undefined;
    Interface?: Interface | undefined;
}
export type __listOfInputConfiguration = InputConfiguration[];
export interface MediaStreamSourceConfiguration {
    EncodingName?: EncodingName | undefined;
    InputConfigurations?: InputConfiguration[] | undefined;
    MediaStreamName?: string | undefined;
}
export type __listOfMediaStreamSourceConfiguration = MediaStreamSourceConfiguration[];
export interface GatewayBridgeSource {
    BridgeArn?: string | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
}
export interface Source {
    DataTransferSubscriberFeePercent?: number | undefined;
    Decryption?: Encryption | undefined;
    Description?: string | undefined;
    EntitlementArn?: string | undefined;
    IngestIp?: string | undefined;
    IngestPort?: number | undefined;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfiguration[] | undefined;
    Name?: string | undefined;
    SenderControlPort?: number | undefined;
    SenderIpAddress?: string | undefined;
    SourceArn?: string | undefined;
    Transport?: Transport | undefined;
    VpcInterfaceName?: string | undefined;
    WhitelistCidr?: string | undefined;
    GatewayBridgeSource?: GatewayBridgeSource | undefined;
    PeerIpAddress?: string | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption | undefined;
    ConnectedRouterOutputArn?: string | undefined;
}
export type __listOfSource = Source[];
export interface AddFlowSourcesResponse {
    FlowArn?: string | undefined;
    Sources?: (Source & {
        Name: string;
        SourceArn: string;
        Decryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            InputConfigurations: (InputConfiguration & {
                InputIp: string;
                InputPort: number;
                Interface: Interface & {
                    Name: string;
                };
            })[];
        })[];
        Transport: Transport & {
            Protocol: Protocol;
            RtmpPushSourceSettings: RtmpPushSourceSettings & {
                ApplicationName: string;
                StreamName: string;
                NamingType: RtmpPushNamingType;
            };
            RtmpPushOutputSettings: RtmpPushOutputSettings & {
                ApplicationName: string;
                StreamName: string;
            };
        };
        GatewayBridgeSource: GatewayBridgeSource & {
            BridgeArn: string;
        };
    })[] | undefined;
}
export type NetworkInterfaceType = "ena" | "efa" | (string & {});
export interface VpcInterfaceRequest {
    Name?: string | undefined;
    NetworkInterfaceType?: NetworkInterfaceType | undefined;
    RoleArn?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetId?: string | undefined;
    VpcInterfaceTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfVpcInterfaceRequest = VpcInterfaceRequest[];
export interface AddFlowVpcInterfacesRequest {
    FlowArn: string;
    VpcInterfaces?: VpcInterfaceRequest[] | undefined;
}
export interface VpcInterface {
    Name?: string | undefined;
    NetworkInterfaceIds?: string[] | undefined;
    NetworkInterfaceType?: NetworkInterfaceType | undefined;
    RoleArn?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetId?: string | undefined;
}
export type __listOfVpcInterface = VpcInterface[];
export interface AddFlowVpcInterfacesResponse {
    FlowArn?: string | undefined;
    VpcInterfaces?: (VpcInterface & {
        Name: string;
        NetworkInterfaceIds: __listOfString;
        NetworkInterfaceType: NetworkInterfaceType;
        RoleArn: string;
        SecurityGroupIds: __listOfString;
        SubnetId: string;
    })[] | undefined;
}
export type DestinationEndpointArn = string;
export type DestinationEndpointArnList = string[];
export interface BatchGetDestinationEndpointRequest {
    Arns: string[];
}
export type EndpointLifecycle = "MANAGED" | "UNMANAGED" | (string & {});
export interface DestinationEndpointMessage {
    Code: string;
    Message: string;
}
export type DestinationEndpointMessageList = DestinationEndpointMessage[];
export type DestinationEndpointType = "STANDARD" | "ROUTER_INPUT" | (string & {});
export interface PublicDestinationEndpointNetworkingConfigurationAllowRule {
    Cidr: string;
}
export type PublicDestinationEndpointNetworkingConfigurationAllowRuleList = PublicDestinationEndpointNetworkingConfigurationAllowRule[];
export interface PublicDestinationEndpointNetworkingConfiguration {
    DestinationAllowRules: PublicDestinationEndpointNetworkingConfigurationAllowRule[];
}
export type SecurityGroupIdList = string[];
export interface VpcDestinationEndpointNetworkingConfiguration {
    SecurityGroupIds: string[];
    SubnetId: string;
}
export type StandardDestinationEndpointNetworkingConfiguration = {
    Public: PublicDestinationEndpointNetworkingConfiguration;
    Vpc?: undefined;
} | {
    Public?: undefined;
    Vpc: VpcDestinationEndpointNetworkingConfiguration;
};
export interface RistStandardDestinationEndpointConfiguration {
    DestinationAddress: string;
    DestinationIngestPort: number;
}
export interface EndpointEncryptionSecretConfiguration {
    SecretArn: string;
}
export interface SrtListenerStandardDestinationEndpointConfiguration {
    DestinationAddress: string;
    DestinationIngestPort: number;
    MinimumLatencyMilliseconds: number;
    StreamId?: string | undefined;
    EncryptionPassphrase?: EndpointEncryptionSecretConfiguration | undefined;
}
export interface SrtCallerStandardDestinationEndpointConfiguration {
    SourceListenerPort: number;
    MinimumLatencyMilliseconds: number;
    EncryptionPassphrase?: EndpointEncryptionSecretConfiguration | undefined;
}
export type ForwardErrorCorrectionState = "ENABLED" | "DISABLED" | (string & {});
export interface RtpStandardDestinationEndpointConfiguration {
    DestinationAddress: string;
    DestinationIngestPort: number;
    ForwardErrorCorrectionState: ForwardErrorCorrectionState;
}
export type StandardDestinationEndpointProtocolConfiguration = {
    Rist: RistStandardDestinationEndpointConfiguration;
    SrtListener?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener: SrtListenerStandardDestinationEndpointConfiguration;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller: SrtCallerStandardDestinationEndpointConfiguration;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller?: undefined;
    Rtp: RtpStandardDestinationEndpointConfiguration;
};
export type DestinationEndpointNetworkingType = "PUBLIC" | "VPC" | (string & {});
export type DestinationEndpointProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | (string & {});
export interface StandardDestinationEndpointConfiguration {
    Name: string;
    DestinationNetworkingConfiguration: StandardDestinationEndpointNetworkingConfiguration;
    ProtocolConfiguration: StandardDestinationEndpointProtocolConfiguration;
    DestinationNetworkingType?: DestinationEndpointNetworkingType | undefined;
    Protocol?: DestinationEndpointProtocol | undefined;
}
export type RouterInputArn = string;
export interface RouterInputDestinationEndpointConfiguration {
    RouterInputArn: string;
}
export type DestinationEndpointConfiguration = {
    Standard: StandardDestinationEndpointConfiguration;
    RouterInput?: undefined;
} | {
    Standard?: undefined;
    RouterInput: RouterInputDestinationEndpointConfiguration;
};
export type ResourceShareOwnership = "OWNED" | "CONSUMED" | (string & {});
export type ResourceShareState = "SHARED" | "UNSHARED" | (string & {});
export interface OwnedResourceShareDetails {
    ShareState: ResourceShareState;
}
export interface ConsumedResourceShareDetails {
    OwnerAccountId: string;
}
export type ResourceShareDetails = {
    Owned: OwnedResourceShareDetails;
    Consumed?: undefined;
} | {
    Owned?: undefined;
    Consumed: ConsumedResourceShareDetails;
};
export type DestinationEndpointRegistrationState = "REGISTERED" | "REGISTERING" | "DEREGISTERING" | "REGISTRATION_FAILED" | (string & {});
export type EndpointEncryptionType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type EndpointEncryptionSecretType = "AES_128_KEY" | "AES_192_KEY" | "AES_256_KEY" | "SRT_PASSPHRASE" | (string & {});
export interface SecretsManagerEndpointEncryptionConfiguration {
    EncryptionSecretType?: EndpointEncryptionSecretType | undefined;
    EncryptionSecret: EndpointEncryptionSecretConfiguration;
}
export interface AutomaticEndpointEncryptionConfiguration {
}
export type EndpointEncryptionConfiguration = {
    SecretsManager: SecretsManagerEndpointEncryptionConfiguration;
    Automatic?: undefined;
} | {
    SecretsManager?: undefined;
    Automatic: AutomaticEndpointEncryptionConfiguration;
};
export type SourceEndpointType = "STANDARD" | "ROUTER_OUTPUT" | (string & {});
export interface StandardDestinationEndpointConnectionDetails {
    SourceIpAddress?: string | undefined;
    SourceListenerPort?: number | undefined;
    SourceEncryptionType?: EndpointEncryptionType | undefined;
    SourceEncryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    SourceEndpointType?: SourceEndpointType | undefined;
}
export interface RouterInputDestinationEndpointConnectionDetails {
    SourceEncryptionType?: EndpointEncryptionType | undefined;
    SourceEncryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    SourceEndpointType?: SourceEndpointType | undefined;
}
export type DestinationEndpointConnectionDetails = {
    Standard: StandardDestinationEndpointConnectionDetails;
    RouterInput?: undefined;
} | {
    Standard?: undefined;
    RouterInput: RouterInputDestinationEndpointConnectionDetails;
};
export type DestinationEndpointConnectionState = "CONNECTED" | "DISCONNECTED" | "CONNECTING" | "DISCONNECTING" | (string & {});
export type SourceEndpointArn = string;
export interface StandardDestinationEndpointAssociatedResourceDetails {
}
export type RouterInputState = "CREATING" | "STANDBY" | "STARTING" | "ACTIVE" | "STOPPING" | "DELETING" | "UPDATING" | "ERROR" | "RECOVERING" | "MIGRATING" | (string & {});
export interface RouterInputMessage {
    Code: string;
    Message: string;
}
export type RouterInputMessages = RouterInputMessage[];
export interface RouterInputDestinationEndpointAssociatedResourceDetails {
    Name: string;
    MaximumBitrate: number;
    State: RouterInputState;
    Messages: RouterInputMessage[];
}
export type DestinationEndpointAssociatedResourceDetails = {
    Standard: StandardDestinationEndpointAssociatedResourceDetails;
    RouterInput?: undefined;
} | {
    Standard?: undefined;
    RouterInput: RouterInputDestinationEndpointAssociatedResourceDetails;
};
export interface DestinationEndpoint {
    Name: string;
    Arn: string;
    Id: string;
    Description: string;
    RegionName: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    LifecycleManagement: EndpointLifecycle;
    Messages: DestinationEndpointMessage[];
    DestinationType: DestinationEndpointType;
    Configuration: DestinationEndpointConfiguration;
    ResourceShareOwnership: ResourceShareOwnership;
    ResourceShareDetails: ResourceShareDetails;
    RegistrationState: DestinationEndpointRegistrationState;
    ConnectionDetails?: DestinationEndpointConnectionDetails | undefined;
    ConnectionState: DestinationEndpointConnectionState;
    ConnectedSource?: string | undefined;
    DecryptionType?: EndpointEncryptionType | undefined;
    DecryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    AssociatedResourceDetails: DestinationEndpointAssociatedResourceDetails;
    Tags: {
        [key: string]: string | undefined;
    };
}
export type DestinationEndpointList = DestinationEndpoint[];
export interface BatchGetDestinationEndpointError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetDestinationEndpointErrorList = BatchGetDestinationEndpointError_[];
export interface BatchGetDestinationEndpointResponse {
    DestinationEndpoints: DestinationEndpoint[];
    Errors: BatchGetDestinationEndpointError_[];
}
export type RouterInputArnList = string[];
export interface BatchGetRouterInputRequest {
    Arns: string[];
}
export type RouterInputType = "STANDARD" | "FAILOVER" | "MERGE" | "MEDIACONNECT_FLOW" | "MEDIALIVE_CHANNEL" | "DESTINATION_ENDPOINT" | (string & {});
export interface DestinationEndpointRouterInputConfiguration {
    EndpointLifecycleManagement: EndpointLifecycle;
    SourceTransitDecryptionType?: EndpointEncryptionType | undefined;
    SourceTransitDecryption: EndpointEncryptionConfiguration;
}
export type RouterNetworkInterfaceArn = string;
export interface RistRouterInputConfiguration {
    Port: number;
    RecoveryLatencyMilliseconds: number;
}
export interface SrtDecryptionConfiguration {
    EncryptionKey: SecretsManagerEncryptionKeyConfiguration;
}
export interface SrtListenerRouterInputConfiguration {
    Port: number;
    MinimumLatencyMilliseconds: number;
    DecryptionConfiguration?: SrtDecryptionConfiguration | undefined;
}
export interface RtmpPushRouterInputConfiguration {
    Port: number;
    NamingType?: RtmpPushNamingType | undefined;
    NamingConfiguration: RtmpPushNamingConfiguration;
}
export interface SrtCallerRouterInputConfiguration {
    SourceAddress: string;
    SourcePort: number;
    MinimumLatencyMilliseconds: number;
    StreamId?: string | undefined;
    DecryptionConfiguration?: SrtDecryptionConfiguration | undefined;
}
export interface RtpRouterInputConfiguration {
    Port: number;
    ForwardErrorCorrection?: ForwardErrorCorrectionState | undefined;
}
export type RouterInputProtocolConfiguration = {
    Rist: RistRouterInputConfiguration;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener: SrtListenerRouterInputConfiguration;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush: RtmpPushRouterInputConfiguration;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller: SrtCallerRouterInputConfiguration;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp: RtpRouterInputConfiguration;
};
export type RouterInputProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | "RTMP_PUSH" | (string & {});
export interface StandardRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfiguration: RouterInputProtocolConfiguration;
    Protocol?: RouterInputProtocol | undefined;
}
export type MediaLiveChannelArn = string;
export type MediaLiveChannelPipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export type MediaLiveTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type MediaLiveTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: undefined;
} | {
    SecretsManager?: undefined;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface MediaLiveTransitEncryption {
    EncryptionKeyType?: MediaLiveTransitEncryptionKeyType | undefined;
    EncryptionKeyConfiguration: MediaLiveTransitEncryptionKeyConfiguration;
}
export interface MediaLiveChannelRouterInputConfiguration {
    MediaLiveChannelArn?: string | undefined;
    MediaLivePipelineId?: MediaLiveChannelPipelineId | undefined;
    MediaLiveChannelOutputName?: string | undefined;
    SourceTransitDecryption: MediaLiveTransitEncryption;
}
export type FailoverRouterInputProtocolConfiguration = {
    Rist: RistRouterInputConfiguration;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener: SrtListenerRouterInputConfiguration;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush: RtmpPushRouterInputConfiguration;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller: SrtCallerRouterInputConfiguration;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp: RtpRouterInputConfiguration;
};
export type FailoverRouterInputProtocolConfigurationList = FailoverRouterInputProtocolConfiguration[];
export type FailoverInputSourcePriorityMode = "NO_PRIORITY" | "PRIMARY_SECONDARY" | (string & {});
export interface FailoverRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfigurations: FailoverRouterInputProtocolConfiguration[];
    SourcePriorityMode: FailoverInputSourcePriorityMode;
    PrimarySourceIndex?: number | undefined;
}
export type FlowOutputArn = string;
export interface MediaConnectFlowRouterInputConfiguration {
    FlowArn?: string | undefined;
    FlowOutputArn?: string | undefined;
    SourceTransitDecryption: FlowTransitEncryption;
}
export type MergeRouterInputProtocolConfiguration = {
    Rtp: RtpRouterInputConfiguration;
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller?: undefined;
} | {
    Rtp?: undefined;
    Rist: RistRouterInputConfiguration;
    SrtListener?: undefined;
    SrtCaller?: undefined;
} | {
    Rtp?: undefined;
    Rist?: undefined;
    SrtListener: SrtListenerRouterInputConfiguration;
    SrtCaller?: undefined;
} | {
    Rtp?: undefined;
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller: SrtCallerRouterInputConfiguration;
};
export type MergeRouterInputProtocolConfigurationList = MergeRouterInputProtocolConfiguration[];
export interface MergeRouterInputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfigurations: MergeRouterInputProtocolConfiguration[];
    MergeRecoveryWindowMilliseconds: number;
}
export type RouterInputConfiguration = {
    DestinationEndpoint: DestinationEndpointRouterInputConfiguration;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard: StandardRouterInputConfiguration;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel: MediaLiveChannelRouterInputConfiguration;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover: FailoverRouterInputConfiguration;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow: MediaConnectFlowRouterInputConfiguration;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge: MergeRouterInputConfiguration;
};
export type RouterInputTier = "INPUT_100" | "INPUT_50" | "INPUT_20" | "INPUT_500" | "INPUT_250" | (string & {});
export type RoutingScope = "REGIONAL" | "GLOBAL" | (string & {});
export type RouterInputTransitEncryptionKeyType = "SECRETS_MANAGER" | "AUTOMATIC" | (string & {});
export type RouterInputTransitEncryptionKeyConfiguration = {
    SecretsManager: SecretsManagerEncryptionKeyConfiguration;
    Automatic?: undefined;
} | {
    SecretsManager?: undefined;
    Automatic: AutomaticEncryptionKeyConfiguration;
};
export interface RouterInputTransitEncryption {
    EncryptionKeyType?: RouterInputTransitEncryptionKeyType | undefined;
    EncryptionKeyConfiguration: RouterInputTransitEncryptionKeyConfiguration;
}
export interface DestinationEndpointRouterInputStreamDetails {
}
export interface RtmpPushStreamDetails {
    ApplicationName: string;
    StreamName: string;
}
export interface StandardRouterInputStreamDetails {
    SourceIpAddress?: string | undefined;
    RtmpPush?: RtmpPushStreamDetails | undefined;
}
export interface MediaLiveChannelRouterInputStreamDetails {
}
export interface FailoverRouterInputIndexedStreamDetails {
    SourceIndex: number;
    SourceIpAddress?: string | undefined;
    RtmpPush?: RtmpPushStreamDetails | undefined;
}
export interface FailoverRouterInputStreamDetails {
    SourceIndexZeroStreamDetails: FailoverRouterInputIndexedStreamDetails;
    SourceIndexOneStreamDetails: FailoverRouterInputIndexedStreamDetails;
}
export interface MediaConnectFlowRouterInputStreamDetails {
}
export interface MergeRouterInputIndexedStreamDetails {
    SourceIndex: number;
    SourceIpAddress?: string | undefined;
}
export interface MergeRouterInputStreamDetails {
    SourceIndexZeroStreamDetails: MergeRouterInputIndexedStreamDetails;
    SourceIndexOneStreamDetails: MergeRouterInputIndexedStreamDetails;
}
export type RouterInputStreamDetails = {
    DestinationEndpoint: DestinationEndpointRouterInputStreamDetails;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard: StandardRouterInputStreamDetails;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel: MediaLiveChannelRouterInputStreamDetails;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover: FailoverRouterInputStreamDetails;
    MediaConnectFlow?: undefined;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow: MediaConnectFlowRouterInputStreamDetails;
    Merge?: undefined;
} | {
    DestinationEndpoint?: undefined;
    Standard?: undefined;
    MediaLiveChannel?: undefined;
    Failover?: undefined;
    MediaConnectFlow?: undefined;
    Merge: MergeRouterInputStreamDetails;
};
export type MaintenanceType = "PREFERRED_DAY_TIME" | "DEFAULT" | (string & {});
export type Day = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface PreferredDayTimeMaintenanceConfiguration {
    Day: Day;
    Time: string;
}
export interface DefaultMaintenanceConfiguration {
}
export type MaintenanceConfiguration = {
    PreferredDayTime: PreferredDayTimeMaintenanceConfiguration;
    Default?: undefined;
} | {
    PreferredDayTime?: undefined;
    Default: DefaultMaintenanceConfiguration;
};
export type MaintenanceScheduleType = "WINDOW" | (string & {});
export interface WindowMaintenanceSchedule {
    Start: Date;
    End: Date;
    ScheduledTime: Date;
}
export type MaintenanceSchedule = {
    Window: WindowMaintenanceSchedule;
};
export type RouterContentQualityAnalysisType = "CONTENT_LEVEL" | (string & {});
export type ContentQualityAnalysisState = "ENABLED" | "DISABLED" | (string & {});
export type RouterCqaThresholdSeconds = number;
export interface BlackFramesConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface FrozenFramesConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface SilentAudioConfiguration {
    State: ContentQualityAnalysisState;
    ThresholdSeconds: number;
}
export interface ContentQualityAnalysisFeatureConfiguration {
    BlackFrames?: BlackFramesConfiguration | undefined;
    FrozenFrames?: FrozenFramesConfiguration | undefined;
    SilentAudio?: SilentAudioConfiguration | undefined;
}
export type RouterContentQualityAnalysisConfiguration = {
    ContentLevel: ContentQualityAnalysisFeatureConfiguration;
};
export interface RouterInput {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterInputState;
    InputType: RouterInputType;
    Configuration: RouterInputConfiguration;
    RoutedOutputs: number;
    MaximumRoutedOutputs?: number | undefined;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    Tier: RouterInputTier;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    Messages: RouterInputMessage[];
    TransitEncryption: RouterInputTransitEncryption;
    Tags: {
        [key: string]: string | undefined;
    };
    StreamDetails: RouterInputStreamDetails;
    IpAddress?: string | undefined;
    MaintenanceType: MaintenanceType;
    MaintenanceConfiguration: MaintenanceConfiguration;
    MaintenanceScheduleType?: MaintenanceScheduleType | undefined;
    MaintenanceSchedule?: MaintenanceSchedule | undefined;
    ContentQualityAnalysisType?: RouterContentQualityAnalysisType | undefined;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration | undefined;
    AssociatedDestinationEndpointArns?: string[] | undefined;
}
export type RouterInputList = RouterInput[];
export interface BatchGetRouterInputError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterInputErrorList = BatchGetRouterInputError_[];
export interface BatchGetRouterInputResponse {
    RouterInputs: (RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    })[];
    Errors: BatchGetRouterInputError_[];
}
export type RouterNetworkInterfaceArnList = string[];
export interface BatchGetRouterNetworkInterfaceRequest {
    Arns: string[];
}
export type RouterNetworkInterfaceState = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "ERROR" | "RECOVERING" | (string & {});
export type RouterNetworkInterfaceType = "PUBLIC" | "VPC" | (string & {});
export interface PublicRouterNetworkInterfaceRule {
    Cidr: string;
}
export type NetworkInterfaceRuleList = PublicRouterNetworkInterfaceRule[];
export interface PublicRouterNetworkInterfaceConfiguration {
    AllowRules: PublicRouterNetworkInterfaceRule[];
}
export interface VpcRouterNetworkInterfaceConfiguration {
    SecurityGroupIds: string[];
    SubnetId: string;
}
export type RouterNetworkInterfaceConfiguration = {
    Public: PublicRouterNetworkInterfaceConfiguration;
    Vpc?: undefined;
} | {
    Public?: undefined;
    Vpc: VpcRouterNetworkInterfaceConfiguration;
};
export interface RouterNetworkInterface {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterNetworkInterfaceState;
    NetworkInterfaceType: RouterNetworkInterfaceType;
    Configuration: RouterNetworkInterfaceConfiguration;
    AssociatedOutputCount: number;
    AssociatedInputCount: number;
    RegionName: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags: {
        [key: string]: string | undefined;
    };
}
export type RouterNetworkInterfaceList = RouterNetworkInterface[];
export interface BatchGetRouterNetworkInterfaceError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterNetworkInterfaceErrorList = BatchGetRouterNetworkInterfaceError_[];
export interface BatchGetRouterNetworkInterfaceResponse {
    RouterNetworkInterfaces: RouterNetworkInterface[];
    Errors: BatchGetRouterNetworkInterfaceError_[];
}
export type RouterOutputArn = string;
export type RouterOutputArnList = string[];
export interface BatchGetRouterOutputRequest {
    Arns: string[];
}
export type RouterOutputState = "CREATING" | "STANDBY" | "STARTING" | "ACTIVE" | "STOPPING" | "DELETING" | "UPDATING" | "ERROR" | "RECOVERING" | "MIGRATING" | (string & {});
export type RouterOutputType = "STANDARD" | "MEDIACONNECT_FLOW" | "MEDIALIVE_INPUT" | "SOURCE_ENDPOINT" | (string & {});
export interface RistRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
}
export interface SrtEncryptionConfiguration {
    EncryptionKey: SecretsManagerEncryptionKeyConfiguration;
}
export interface SrtListenerRouterOutputConfiguration {
    Port: number;
    MinimumLatencyMilliseconds: number;
    EncryptionConfiguration?: SrtEncryptionConfiguration | undefined;
}
export interface RtmpPushRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    ApplicationName: string;
    StreamName: string;
    TlsEncryption?: TlsEncryption | undefined;
}
export interface SrtCallerRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    MinimumLatencyMilliseconds: number;
    StreamId?: string | undefined;
    EncryptionConfiguration?: SrtEncryptionConfiguration | undefined;
}
export interface RtpRouterOutputConfiguration {
    DestinationAddress: string;
    DestinationPort: number;
    ForwardErrorCorrection?: ForwardErrorCorrectionState | undefined;
}
export type RouterOutputProtocolConfiguration = {
    Rist: RistRouterOutputConfiguration;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener: SrtListenerRouterOutputConfiguration;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush: RtmpPushRouterOutputConfiguration;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller: SrtCallerRouterOutputConfiguration;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    RtmpPush?: undefined;
    SrtCaller?: undefined;
    Rtp: RtpRouterOutputConfiguration;
};
export type RouterOutputProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | "RTMP_PUSH" | (string & {});
export interface StandardRouterOutputConfiguration {
    NetworkInterfaceArn: string;
    ProtocolConfiguration: RouterOutputProtocolConfiguration;
    Protocol?: RouterOutputProtocol | undefined;
}
export type FlowSourceArn = string;
export interface MediaConnectFlowRouterOutputConfiguration {
    FlowArn?: string | undefined;
    FlowSourceArn?: string | undefined;
    DestinationTransitEncryption: FlowTransitEncryption;
}
export type MediaLiveInputArn = string;
export type MediaLiveInputPipelineId = "PIPELINE_0" | "PIPELINE_1" | (string & {});
export interface MediaLiveInputRouterOutputConfiguration {
    MediaLiveInputArn?: string | undefined;
    MediaLivePipelineId?: MediaLiveInputPipelineId | undefined;
    DestinationTransitEncryption: MediaLiveTransitEncryption;
}
export interface SourceEndpointRouterOutputConfiguration {
    EndpointLifecycleManagement: EndpointLifecycle;
    DestinationTransitEncryptionType?: EndpointEncryptionType | undefined;
    DestinationTransitEncryption: EndpointEncryptionConfiguration;
}
export type RouterOutputConfiguration = {
    Standard: StandardRouterOutputConfiguration;
    MediaConnectFlow?: undefined;
    MediaLiveInput?: undefined;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow: MediaConnectFlowRouterOutputConfiguration;
    MediaLiveInput?: undefined;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow?: undefined;
    MediaLiveInput: MediaLiveInputRouterOutputConfiguration;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow?: undefined;
    MediaLiveInput?: undefined;
    SourceEndpoint: SourceEndpointRouterOutputConfiguration;
};
export type RouterOutputRoutedState = "ROUTED" | "ROUTING" | "UNROUTED" | (string & {});
export type RouterOutputTier = "OUTPUT_100" | "OUTPUT_50" | "OUTPUT_20" | "OUTPUT_500" | "OUTPUT_250" | (string & {});
export interface RouterOutputMessage {
    Code: string;
    Message: string;
}
export type RouterOutputMessages = RouterOutputMessage[];
export interface StandardRouterOutputStreamDetails {
    DestinationIpAddress?: string | undefined;
}
export interface MediaConnectFlowRouterOutputStreamDetails {
}
export interface MediaLiveInputRouterOutputStreamDetails {
}
export interface SourceEndpointRouterOutputStreamDetails {
}
export type RouterOutputStreamDetails = {
    Standard: StandardRouterOutputStreamDetails;
    MediaConnectFlow?: undefined;
    MediaLiveInput?: undefined;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow: MediaConnectFlowRouterOutputStreamDetails;
    MediaLiveInput?: undefined;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow?: undefined;
    MediaLiveInput: MediaLiveInputRouterOutputStreamDetails;
    SourceEndpoint?: undefined;
} | {
    Standard?: undefined;
    MediaConnectFlow?: undefined;
    MediaLiveInput?: undefined;
    SourceEndpoint: SourceEndpointRouterOutputStreamDetails;
};
export type FabricLatencyMode = "BALANCED" | "LOW_LATENCY" | (string & {});
export type FabricSwitchingMode = "IMMEDIATE" | "KEY_FRAME" | (string & {});
export interface ImmediateFabricSwitchingConfiguration {
}
export interface KeyFrameFabricSwitchingConfiguration {
    KeyFrameWaitMilliseconds?: number | undefined;
}
export type FabricSwitchingConfiguration = {
    Immediate: ImmediateFabricSwitchingConfiguration;
    KeyFrame?: undefined;
} | {
    Immediate?: undefined;
    KeyFrame: KeyFrameFabricSwitchingConfiguration;
};
export interface FabricConfiguration {
    RecoveryLatencyMode: FabricLatencyMode;
    SwitchingMode?: FabricSwitchingMode | undefined;
    SwitchingConfiguration?: FabricSwitchingConfiguration | undefined;
}
export type ActionString = string;
export interface PidMapRule {
    MatchExpression: string;
    Action: string;
}
export type PidMapRules = PidMapRule[];
export interface Passthrough {
}
export type TransportStreamIdConfiguration = {
    Passthrough: Passthrough;
    Set?: undefined;
} | {
    Passthrough?: undefined;
    Set: number;
};
export type ProgramNumberConfiguration = {
    Passthrough: Passthrough;
    Set?: undefined;
} | {
    Passthrough?: undefined;
    Set: number;
};
export type Pid = number;
export type ProgramMapTablePidConfiguration = {
    Passthrough: Passthrough;
    Set?: undefined;
} | {
    Passthrough?: undefined;
    Set: number;
};
export type ProgramClockReferencePidConfiguration = {
    Passthrough: Passthrough;
    Set?: undefined;
} | {
    Passthrough?: undefined;
    Set: number;
};
export interface AutoPidMapConfiguration {
    StartPid: number;
    PidsPerProgram: number;
}
export interface SingleProgramTransportStreamPidMapConfiguration {
    Rules: PidMapRule[];
    DefaultAction: string;
    TransportStreamId?: TransportStreamIdConfiguration | undefined;
    ProgramNumber?: ProgramNumberConfiguration | undefined;
    ProgramMapTablePid?: ProgramMapTablePidConfiguration | undefined;
    ProgramClockReferencePid?: ProgramClockReferencePidConfiguration | undefined;
    Auto?: AutoPidMapConfiguration | undefined;
}
export interface RouterOutputProcessors {
    SingleProgramTransportStreamPidMap?: SingleProgramTransportStreamPidMapConfiguration | undefined;
}
export type SourceEndpointArnList = string[];
export interface RouterOutput {
    Name: string;
    Arn: string;
    Id: string;
    State: RouterOutputState;
    OutputType: RouterOutputType;
    Configuration: RouterOutputConfiguration;
    RoutedState: RouterOutputRoutedState;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterOutputTier;
    CreatedAt: Date;
    UpdatedAt: Date;
    Messages: RouterOutputMessage[];
    Tags: {
        [key: string]: string | undefined;
    };
    StreamDetails: RouterOutputStreamDetails;
    IpAddress?: string | undefined;
    RoutedInputArn?: string | undefined;
    MaintenanceType: MaintenanceType;
    MaintenanceConfiguration: MaintenanceConfiguration;
    MaintenanceScheduleType?: MaintenanceScheduleType | undefined;
    MaintenanceSchedule?: MaintenanceSchedule | undefined;
    FabricConfiguration?: FabricConfiguration | undefined;
    Processors?: RouterOutputProcessors | undefined;
    AssociatedSourceEndpointArns?: string[] | undefined;
}
export type RouterOutputList = RouterOutput[];
export interface BatchGetRouterOutputError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetRouterOutputErrorList = BatchGetRouterOutputError_[];
export interface BatchGetRouterOutputResponse {
    RouterOutputs: (RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    })[];
    Errors: BatchGetRouterOutputError_[];
}
export interface BatchGetSourceEndpointRequest {
    Arns: string[];
}
export interface SourceEndpointMessage {
    Code: string;
    Message: string;
}
export type SourceEndpointMessageList = SourceEndpointMessage[];
export interface PublicSourceEndpointNetworkingConfigurationAllowRule {
    Cidr: string;
}
export type PublicSourceEndpointNetworkingConfigurationAllowRuleList = PublicSourceEndpointNetworkingConfigurationAllowRule[];
export interface PublicSourceEndpointNetworkingConfiguration {
    SourceAllowRules: PublicSourceEndpointNetworkingConfigurationAllowRule[];
}
export interface VpcSourceEndpointNetworkingConfiguration {
    SecurityGroupIds: string[];
    SubnetId: string;
}
export type StandardSourceEndpointNetworkingConfiguration = {
    Public: PublicSourceEndpointNetworkingConfiguration;
    Vpc?: undefined;
} | {
    Public?: undefined;
    Vpc: VpcSourceEndpointNetworkingConfiguration;
};
export interface RistStandardSourceEndpointConfiguration {
    DestinationIngestPort: number;
    RecoveryLatencyMilliseconds: number;
}
export interface SrtListenerStandardSourceEndpointConfiguration {
    SourceListenerPort: number;
    SourceAddress: string;
    MinimumLatencyMilliseconds: number;
    StreamId?: string | undefined;
    EncryptionPassphrase?: EndpointEncryptionSecretConfiguration | undefined;
}
export interface SrtCallerStandardSourceEndpointConfiguration {
    DestinationIngestPort: number;
    MinimumLatencyMilliseconds: number;
    EncryptionPassphrase?: EndpointEncryptionSecretConfiguration | undefined;
}
export interface RtpStandardSourceEndpointConfiguration {
    DestinationIngestPort: number;
    ForwardErrorCorrectionState: ForwardErrorCorrectionState;
}
export type StandardSourceEndpointProtocolConfiguration = {
    Rist: RistStandardSourceEndpointConfiguration;
    SrtListener?: undefined;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener: SrtListenerStandardSourceEndpointConfiguration;
    SrtCaller?: undefined;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller: SrtCallerStandardSourceEndpointConfiguration;
    Rtp?: undefined;
} | {
    Rist?: undefined;
    SrtListener?: undefined;
    SrtCaller?: undefined;
    Rtp: RtpStandardSourceEndpointConfiguration;
};
export type SourceEndpointNetworkingType = "PUBLIC" | "VPC" | (string & {});
export type SourceEndpointProtocol = "RTP" | "RIST" | "SRT_CALLER" | "SRT_LISTENER" | (string & {});
export interface StandardSourceEndpointConfiguration {
    Name: string;
    SourceNetworkingConfiguration: StandardSourceEndpointNetworkingConfiguration;
    ProtocolConfiguration: StandardSourceEndpointProtocolConfiguration;
    SourceNetworkingType?: SourceEndpointNetworkingType | undefined;
    Protocol?: SourceEndpointProtocol | undefined;
}
export interface RouterOutputSourceEndpointConfiguration {
    RouterOutputArn: string;
}
export type SourceEndpointConfiguration = {
    Standard: StandardSourceEndpointConfiguration;
    RouterOutput?: undefined;
} | {
    Standard?: undefined;
    RouterOutput: RouterOutputSourceEndpointConfiguration;
};
export type SourceEndpointRegistrationState = "REGISTERED" | "REGISTERING" | "DEREGISTERING" | "REGISTRATION_FAILED" | (string & {});
export type SourceEndpointConnectionState = "CONNECTED" | "DISCONNECTED" | "CONNECTING" | "DISCONNECTING" | (string & {});
export interface StandardSourceEndpointConnectionDetails {
    DestinationIpAddress?: string | undefined;
    DestinationIngestPort?: number | undefined;
    DestinationDecryptionType?: EndpointEncryptionType | undefined;
    DestinationDecryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    DestinationEndpointType?: DestinationEndpointType | undefined;
}
export interface RouterOutputSourceEndpointConnectionDetails {
    DestinationDecryptionType?: EndpointEncryptionType | undefined;
    DestinationDecryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    DestinationEndpointType?: DestinationEndpointType | undefined;
}
export type SourceEndpointConnectionDetails = {
    Standard: StandardSourceEndpointConnectionDetails;
    RouterOutput?: undefined;
} | {
    Standard?: undefined;
    RouterOutput: RouterOutputSourceEndpointConnectionDetails;
};
export interface StandardSourceEndpointAssociatedResourceDetails {
}
export interface RouterOutputSourceEndpointAssociatedResourceDetails {
    Name: string;
    MaximumBitrate: number;
    State: RouterOutputState;
    Messages: RouterOutputMessage[];
}
export type SourceEndpointAssociatedResourceDetails = {
    Standard: StandardSourceEndpointAssociatedResourceDetails;
    RouterOutput?: undefined;
} | {
    Standard?: undefined;
    RouterOutput: RouterOutputSourceEndpointAssociatedResourceDetails;
};
export interface SourceEndpoint {
    Name: string;
    Arn: string;
    Id: string;
    Description: string;
    RegionName: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    LifecycleManagement: EndpointLifecycle;
    Messages: SourceEndpointMessage[];
    SourceType: SourceEndpointType;
    Configuration: SourceEndpointConfiguration;
    ResourceShareOwnership: ResourceShareOwnership;
    ResourceShareDetails: ResourceShareDetails;
    RegistrationState: SourceEndpointRegistrationState;
    ConnectionState: SourceEndpointConnectionState;
    ConnectionDetails?: SourceEndpointConnectionDetails | undefined;
    ConnectedDestinations: string[];
    EncryptionType?: EndpointEncryptionType | undefined;
    EncryptionConfiguration?: EndpointEncryptionConfiguration | undefined;
    AssociatedResourceDetails: SourceEndpointAssociatedResourceDetails;
    Tags: {
        [key: string]: string | undefined;
    };
}
export type SourceEndpointList = SourceEndpoint[];
export interface BatchGetSourceEndpointError_ {
    Arn: string;
    Code: string;
    Message: string;
}
export type BatchGetSourceEndpointErrorList = BatchGetSourceEndpointError_[];
export interface BatchGetSourceEndpointResponse {
    SourceEndpoints: SourceEndpoint[];
    Errors: BatchGetSourceEndpointError_[];
}
export interface ConnectEndpointsRequest {
    DestinationEndpointArn: string;
    SourceEndpointArn: string;
}
export interface ConnectEndpointsResponse {
    DestinationEndpointArn: string;
    DestinationEndpointName: string;
    SourceEndpointArn: string;
    SourceEndpointName: string;
}
export interface AddEgressGatewayBridgeRequest {
    MaxBitrate?: number | undefined;
}
export interface AddIngressGatewayBridgeRequest {
    MaxBitrate?: number | undefined;
    MaxOutputs?: number | undefined;
}
export type FailoverMode = "MERGE" | "FAILOVER" | (string & {});
export interface SourcePriority {
    PrimarySource?: string | undefined;
}
export interface FailoverConfig {
    FailoverMode?: FailoverMode | undefined;
    RecoveryWindow?: number | undefined;
    SourcePriority?: SourcePriority | undefined;
    State?: State | undefined;
}
export interface CreateBridgeRequest {
    EgressGatewayBridge?: AddEgressGatewayBridgeRequest | undefined;
    IngressGatewayBridge?: AddIngressGatewayBridgeRequest | undefined;
    Name?: string | undefined;
    Outputs?: AddBridgeOutputRequest[] | undefined;
    PlacementArn?: string | undefined;
    SourceFailoverConfig?: FailoverConfig | undefined;
    Sources?: AddBridgeSourceRequest[] | undefined;
}
export interface MessageDetail {
    Code?: string | undefined;
    Message?: string | undefined;
    ResourceName?: string | undefined;
}
export type __listOfMessageDetail = MessageDetail[];
export type BridgeState = "CREATING" | "STANDBY" | "STARTING" | "DEPLOYING" | "ACTIVE" | "STOPPING" | "DELETING" | "DELETED" | "START_FAILED" | "START_PENDING" | "STOP_FAILED" | "UPDATING" | (string & {});
export interface EgressGatewayBridge {
    InstanceId?: string | undefined;
    MaxBitrate?: number | undefined;
}
export interface IngressGatewayBridge {
    InstanceId?: string | undefined;
    MaxBitrate?: number | undefined;
    MaxOutputs?: number | undefined;
}
export interface Bridge {
    BridgeArn?: string | undefined;
    BridgeMessages?: MessageDetail[] | undefined;
    BridgeState?: BridgeState | undefined;
    EgressGatewayBridge?: EgressGatewayBridge | undefined;
    IngressGatewayBridge?: IngressGatewayBridge | undefined;
    Name?: string | undefined;
    Outputs?: BridgeOutput[] | undefined;
    PlacementArn?: string | undefined;
    SourceFailoverConfig?: FailoverConfig | undefined;
    Sources?: BridgeSource[] | undefined;
}
export interface CreateBridgeResponse {
    Bridge?: (Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    }) | undefined;
}
export type EntitlementStatus = "ENABLED" | "DISABLED" | (string & {});
export interface GrantEntitlementRequest {
    DataTransferSubscriberFeePercent?: number | undefined;
    Description?: string | undefined;
    Encryption?: Encryption | undefined;
    EntitlementStatus?: EntitlementStatus | undefined;
    Name?: string | undefined;
    Subscribers?: string[] | undefined;
    EntitlementTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfGrantEntitlementRequest = GrantEntitlementRequest[];
export type MaintenanceDay = "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday" | (string & {});
export interface AddMaintenance {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceStartHour?: string | undefined;
}
export type ThumbnailState = "ENABLED" | "DISABLED" | (string & {});
export interface SilentAudio {
    State?: State | undefined;
    ThresholdSeconds?: number | undefined;
}
export interface AudioMonitoringSetting {
    SilentAudio?: SilentAudio | undefined;
}
export type __listOfAudioMonitoringSetting = AudioMonitoringSetting[];
export interface BlackFrames {
    State?: State | undefined;
    ThresholdSeconds?: number | undefined;
}
export interface FrozenFrames {
    State?: State | undefined;
    ThresholdSeconds?: number | undefined;
}
export interface VideoMonitoringSetting {
    BlackFrames?: BlackFrames | undefined;
    FrozenFrames?: FrozenFrames | undefined;
}
export type __listOfVideoMonitoringSetting = VideoMonitoringSetting[];
export interface MonitoringConfig {
    ThumbnailState?: ThumbnailState | undefined;
    AudioMonitoringSettings?: AudioMonitoringSetting[] | undefined;
    ContentQualityAnalysisState?: ContentQualityAnalysisState | undefined;
    VideoMonitoringSettings?: VideoMonitoringSetting[] | undefined;
}
export type FlowSize = "MEDIUM" | "LARGE" | "LARGE_4X" | (string & {});
export type NdiState = "ENABLED" | "DISABLED" | (string & {});
export interface NdiDiscoveryServerConfig {
    DiscoveryServerAddress?: string | undefined;
    DiscoveryServerPort?: number | undefined;
    VpcInterfaceAdapter?: string | undefined;
}
export type __listOfNdiDiscoveryServerConfig = NdiDiscoveryServerConfig[];
export interface NdiConfig {
    NdiState?: NdiState | undefined;
    MachineName?: string | undefined;
    NdiDiscoveryServers?: NdiDiscoveryServerConfig[] | undefined;
}
export type EncodingProfile = "DISTRIBUTION_H264_DEFAULT" | "CONTRIBUTION_H264_DEFAULT" | (string & {});
export interface EncodingConfig {
    EncodingProfile?: EncodingProfile | undefined;
    VideoMaxBitrate?: number | undefined;
}
export interface CreateFlowRequest {
    AvailabilityZone?: string | undefined;
    Entitlements?: GrantEntitlementRequest[] | undefined;
    MediaStreams?: AddMediaStreamRequest[] | undefined;
    Name?: string | undefined;
    Outputs?: AddOutputRequest[] | undefined;
    Source?: SetSourceRequest | undefined;
    SourceFailoverConfig?: FailoverConfig | undefined;
    Sources?: SetSourceRequest[] | undefined;
    VpcInterfaces?: VpcInterfaceRequest[] | undefined;
    Maintenance?: AddMaintenance | undefined;
    SourceMonitoringConfig?: MonitoringConfig | undefined;
    FlowSize?: FlowSize | undefined;
    NdiConfig?: NdiConfig | undefined;
    EncodingConfig?: EncodingConfig | undefined;
    FlowTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Entitlement {
    DataTransferSubscriberFeePercent?: number | undefined;
    Description?: string | undefined;
    Encryption?: Encryption | undefined;
    EntitlementArn?: string | undefined;
    EntitlementStatus?: EntitlementStatus | undefined;
    Name?: string | undefined;
    Subscribers?: string[] | undefined;
}
export type __listOfEntitlement = Entitlement[];
export type Status = "STANDBY" | "ACTIVE" | "UPDATING" | "DELETING" | "STARTING" | "STOPPING" | "ERROR" | (string & {});
export interface Maintenance {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceDeadline?: string | undefined;
    MaintenanceScheduledDate?: string | undefined;
    MaintenanceStartHour?: string | undefined;
}
export interface Flow {
    AvailabilityZone?: string | undefined;
    Description?: string | undefined;
    EgressIp?: string | undefined;
    Entitlements?: Entitlement[] | undefined;
    FlowArn?: string | undefined;
    MediaStreams?: MediaStream[] | undefined;
    Name?: string | undefined;
    Outputs?: Output[] | undefined;
    Source?: Source | undefined;
    SourceFailoverConfig?: FailoverConfig | undefined;
    Sources?: Source[] | undefined;
    Status?: Status | undefined;
    VpcInterfaces?: VpcInterface[] | undefined;
    Maintenance?: Maintenance | undefined;
    SourceMonitoringConfig?: MonitoringConfig | undefined;
    FlowSize?: FlowSize | undefined;
    NdiConfig?: NdiConfig | undefined;
    EncodingConfig?: EncodingConfig | undefined;
}
export interface CreateFlowResponse {
    Flow?: (Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    }) | undefined;
}
export interface GatewayNetwork {
    CidrBlock?: string | undefined;
    Name?: string | undefined;
}
export type __listOfGatewayNetwork = GatewayNetwork[];
export interface CreateGatewayRequest {
    EgressCidrBlocks?: string[] | undefined;
    Name?: string | undefined;
    Networks?: GatewayNetwork[] | undefined;
}
export type GatewayState = "CREATING" | "ACTIVE" | "UPDATING" | "ERROR" | "DELETING" | "DELETED" | (string & {});
export interface Gateway {
    EgressCidrBlocks?: string[] | undefined;
    GatewayArn?: string | undefined;
    GatewayMessages?: MessageDetail[] | undefined;
    GatewayState?: GatewayState | undefined;
    Name?: string | undefined;
    Networks?: GatewayNetwork[] | undefined;
}
export interface CreateGatewayResponse {
    Gateway?: (Gateway & {
        EgressCidrBlocks: __listOfString;
        GatewayArn: string;
        Name: string;
        Networks: (GatewayNetwork & {
            CidrBlock: string;
            Name: string;
        })[];
        GatewayMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    }) | undefined;
}
export type ClientToken = string;
export interface CreateRouterInputRequest {
    Name: string;
    Configuration: RouterInputConfiguration;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterInputTier;
    RegionName?: string | undefined;
    AvailabilityZone?: string | undefined;
    TransitEncryption?: RouterInputTransitEncryption | undefined;
    MaintenanceConfiguration?: MaintenanceConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration | undefined;
}
export interface CreateRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface CreateRouterNetworkInterfaceRequest {
    Name: string;
    Configuration: RouterNetworkInterfaceConfiguration;
    RegionName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface CreateRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface CreateRouterOutputRequest {
    Name: string;
    Configuration: RouterOutputConfiguration;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    Tier: RouterOutputTier;
    RegionName?: string | undefined;
    AvailabilityZone?: string | undefined;
    MaintenanceConfiguration?: MaintenanceConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    FabricConfiguration?: FabricConfiguration | undefined;
    ClientToken?: string | undefined;
    Processors?: RouterOutputProcessors | undefined;
}
export interface CreateRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export interface DeleteBridgeRequest {
    BridgeArn: string;
}
export interface DeleteBridgeResponse {
    BridgeArn?: string | undefined;
}
export interface DeleteFlowRequest {
    FlowArn: string;
}
export interface DeleteFlowResponse {
    FlowArn?: string | undefined;
    Status?: Status | undefined;
}
export type GatewayArn = string;
export interface DeleteGatewayRequest {
    GatewayArn: string;
}
export interface DeleteGatewayResponse {
    GatewayArn?: string | undefined;
}
export interface DeleteRouterInputRequest {
    Arn: string;
}
export interface DeleteRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface DeleteRouterNetworkInterfaceRequest {
    Arn: string;
}
export interface DeleteRouterNetworkInterfaceResponse {
    Arn: string;
    Name: string;
    State: RouterNetworkInterfaceState;
}
export interface DeleteRouterOutputRequest {
    Arn: string;
}
export interface DeleteRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export interface DeregisterDestinationEndpointRequest {
    Arn: string;
}
export interface DeregisterDestinationEndpointResponse {
    Arn: string;
    Name: string;
}
export type GatewayInstanceArn = string;
export interface DeregisterGatewayInstanceRequest {
    Force?: boolean | undefined;
    GatewayInstanceArn: string;
}
export type InstanceState = "REGISTERING" | "ACTIVE" | "DEREGISTERING" | "DEREGISTERED" | "REGISTRATION_ERROR" | "DEREGISTRATION_ERROR" | (string & {});
export interface DeregisterGatewayInstanceResponse {
    GatewayInstanceArn?: string | undefined;
    InstanceState?: InstanceState | undefined;
}
export interface DeregisterSourceEndpointRequest {
    Arn: string;
}
export interface DeregisterSourceEndpointResponse {
    Arn: string;
    Name: string;
}
export interface DescribeBridgeRequest {
    BridgeArn: string;
}
export interface DescribeBridgeResponse {
    Bridge?: (Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    }) | undefined;
}
export interface DescribeFlowRequest {
    FlowArn: string;
}
export interface Messages {
    Errors?: string[] | undefined;
}
export interface DescribeFlowResponse {
    Flow?: (Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    }) | undefined;
    Messages?: (Messages & {
        Errors: __listOfString;
    }) | undefined;
}
export interface DescribeFlowSourceMetadataRequest {
    FlowArn: string;
}
export type VideoColorimetry = "BT709" | "BT470M" | "BT470BG" | "BT601" | "SMPTE240M" | "GENERIC_FILM" | "BT2020" | "SMPTE428" | "SMPTE431" | "SMPTE432" | (string & {});
export type VideoTransferCharacteristics = "BT709" | "BT470M" | "BT470BG" | "BT601" | "SMPTE240M" | "LINEAR" | "LOG100" | "LOG316" | "IEC61966_2_4" | "BT1361_ECG" | "IEC61966_2_1" | "BT2020_10" | "BT2020_12" | "BT2100_PQ" | "SMPTE428" | "BT2100_HLG" | (string & {});
export type VideoMatrixCoefficients = "IDENTITY" | "BT709" | "FCC" | "BT470BG" | "BT601" | "SMPTE240M" | "YCGCO" | "BT2020_NCL" | "BT2020_CL" | "SMPTE2085" | "CHROMATICITY_DERIVED_NCL" | "CHROMATICITY_DERIVED_CL" | "BT2100_ICTCP" | "IPT_C2" | (string & {});
export interface ColorInformation {
    Colorimetry?: VideoColorimetry | undefined;
    TransferCharacteristics?: VideoTransferCharacteristics | undefined;
    MatrixCoefficients?: VideoMatrixCoefficients | undefined;
}
export interface FrameResolution {
    FrameHeight?: number | undefined;
    FrameWidth?: number | undefined;
}
export interface TransportStream {
    Channels?: number | undefined;
    Codec?: string | undefined;
    Color?: ColorInformation | undefined;
    FrameRate?: string | undefined;
    FrameResolution?: FrameResolution | undefined;
    Pid?: number | undefined;
    SampleRate?: number | undefined;
    SampleSize?: number | undefined;
    ScanMode?: ScanMode | undefined;
    StreamType?: string | undefined;
    Language?: string | undefined;
}
export type __listOfTransportStream = TransportStream[];
export interface TransportStreamProgram {
    PcrPid?: number | undefined;
    ProgramName?: string | undefined;
    ProgramNumber?: number | undefined;
    ProgramPid?: number | undefined;
    Streams?: TransportStream[] | undefined;
}
export type __listOfTransportStreamProgram = TransportStreamProgram[];
export interface TransportMediaInfo {
    Programs?: TransportStreamProgram[] | undefined;
    TsId?: number | undefined;
}
export interface NdiSourceInfo {
    SourceName?: string | undefined;
}
export type __listOfNdiSourceInfo = NdiSourceInfo[];
export interface NdiMediaStreamInfo {
    StreamType?: string | undefined;
    Codec?: string | undefined;
    StreamId?: number | undefined;
    ScanMode?: ScanMode | undefined;
    Color?: ColorInformation | undefined;
    FrameResolution?: FrameResolution | undefined;
    FrameRate?: string | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
}
export type __listOfNdiMediaStreamInfo = NdiMediaStreamInfo[];
export interface NdiMediaInfo {
    Streams?: NdiMediaStreamInfo[] | undefined;
}
export interface NdiSourceMetadataInfo {
    ActiveSource?: NdiSourceInfo | undefined;
    DiscoveredSources?: NdiSourceInfo[] | undefined;
    MediaInfo?: NdiMediaInfo | undefined;
    Messages?: MessageDetail[] | undefined;
}
export type SourceMediaStreamType = "VIDEO" | "AUDIO" | "DATA" | "UNKNOWN" | (string & {});
export interface RtmpMediaStreamInfo {
    StreamId?: number | undefined;
    StreamType?: SourceMediaStreamType | undefined;
    Codec?: string | undefined;
    FrameRate?: string | undefined;
    FrameResolution?: FrameResolution | undefined;
    ScanMode?: ScanMode | undefined;
    Color?: ColorInformation | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
    SampleSize?: number | undefined;
    Language?: string | undefined;
}
export type RtmpMediaStreamInfoList = RtmpMediaStreamInfo[];
export interface RtmpMediaInfo {
    Streams?: RtmpMediaStreamInfo[] | undefined;
}
export interface RtmpSourceMetadataInfo {
    ApplicationName?: string | undefined;
    StreamName?: string | undefined;
    MediaInfo?: RtmpMediaInfo | undefined;
}
export interface DescribeFlowSourceMetadataResponse {
    FlowArn?: string | undefined;
    Messages?: (MessageDetail & {
        Code: string;
        Message: string;
    })[] | undefined;
    Timestamp?: Date | undefined;
    TransportMediaInfo?: (TransportMediaInfo & {
        Programs: (TransportStreamProgram & {
            PcrPid: number;
            ProgramNumber: number;
            ProgramPid: number;
            Streams: (TransportStream & {
                Pid: number;
                StreamType: string;
                FrameResolution: FrameResolution & {
                    FrameHeight: number;
                    FrameWidth: number;
                };
            })[];
        })[];
    }) | undefined;
    NdiInfo?: (NdiSourceMetadataInfo & {
        DiscoveredSources: (NdiSourceInfo & {
            SourceName: string;
        })[];
        MediaInfo: NdiMediaInfo & {
            Streams: (NdiMediaStreamInfo & {
                StreamType: string;
                Codec: string;
                StreamId: number;
                FrameResolution: FrameResolution & {
                    FrameHeight: number;
                    FrameWidth: number;
                };
            })[];
        };
        Messages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        ActiveSource: NdiSourceInfo & {
            SourceName: string;
        };
    }) | undefined;
    RtmpInfo?: (RtmpSourceMetadataInfo & {
        MediaInfo: RtmpMediaInfo & {
            Streams: (RtmpMediaStreamInfo & {
                StreamId: number;
                StreamType: SourceMediaStreamType;
                Codec: string;
                FrameResolution: FrameResolution & {
                    FrameHeight: number;
                    FrameWidth: number;
                };
            })[];
        };
    }) | undefined;
}
export interface DescribeFlowSourceThumbnailRequest {
    FlowArn: string;
}
export interface ThumbnailDetails {
    FlowArn?: string | undefined;
    Thumbnail?: string | undefined;
    ThumbnailMessages?: MessageDetail[] | undefined;
    Timecode?: string | undefined;
    Timestamp?: Date | undefined;
}
export interface DescribeFlowSourceThumbnailResponse {
    ThumbnailDetails?: (ThumbnailDetails & {
        FlowArn: string;
        ThumbnailMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    }) | undefined;
}
export interface DescribeGatewayRequest {
    GatewayArn: string;
}
export interface DescribeGatewayResponse {
    Gateway?: (Gateway & {
        EgressCidrBlocks: __listOfString;
        GatewayArn: string;
        Name: string;
        Networks: (GatewayNetwork & {
            CidrBlock: string;
            Name: string;
        })[];
        GatewayMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    }) | undefined;
}
export interface DescribeGatewayInstanceRequest {
    GatewayInstanceArn: string;
}
export type BridgePlacement = "AVAILABLE" | "LOCKED" | (string & {});
export type ConnectionStatus = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface GatewayInstance {
    BridgePlacement?: BridgePlacement | undefined;
    ConnectionStatus?: ConnectionStatus | undefined;
    GatewayArn?: string | undefined;
    GatewayInstanceArn?: string | undefined;
    InstanceId?: string | undefined;
    InstanceMessages?: MessageDetail[] | undefined;
    InstanceState?: InstanceState | undefined;
    RunningBridgeCount?: number | undefined;
}
export interface DescribeGatewayInstanceResponse {
    GatewayInstance?: (GatewayInstance & {
        BridgePlacement: BridgePlacement;
        ConnectionStatus: ConnectionStatus;
        GatewayArn: string;
        GatewayInstanceArn: string;
        InstanceId: string;
        InstanceState: InstanceState;
        RunningBridgeCount: number;
        InstanceMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
    }) | undefined;
}
export type OfferingArn = string;
export interface DescribeOfferingRequest {
    OfferingArn: string;
}
export type DurationUnits = "MONTHS" | (string & {});
export type PriceUnits = "HOURLY" | (string & {});
export type ResourceType = "Mbps_Outbound_Bandwidth" | (string & {});
export interface ResourceSpecification {
    ReservedBitrate?: number | undefined;
    ResourceType?: ResourceType | undefined;
}
export interface Offering {
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: DurationUnits | undefined;
    OfferingArn?: string | undefined;
    OfferingDescription?: string | undefined;
    PricePerUnit?: string | undefined;
    PriceUnits?: PriceUnits | undefined;
    ResourceSpecification?: ResourceSpecification | undefined;
}
export interface DescribeOfferingResponse {
    Offering?: (Offering & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
    }) | undefined;
}
export type ReservationArn = string;
export interface DescribeReservationRequest {
    ReservationArn: string;
}
export type ReservationState = "ACTIVE" | "EXPIRED" | "PROCESSING" | "CANCELED" | (string & {});
export interface Reservation {
    CurrencyCode?: string | undefined;
    Duration?: number | undefined;
    DurationUnits?: DurationUnits | undefined;
    End?: string | undefined;
    OfferingArn?: string | undefined;
    OfferingDescription?: string | undefined;
    PricePerUnit?: string | undefined;
    PriceUnits?: PriceUnits | undefined;
    ReservationArn?: string | undefined;
    ReservationName?: string | undefined;
    ReservationState?: ReservationState | undefined;
    ResourceSpecification?: ResourceSpecification | undefined;
    Start?: string | undefined;
}
export interface DescribeReservationResponse {
    Reservation?: (Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    }) | undefined;
}
export interface DisconnectEndpointsRequest {
    DestinationEndpointArn: string;
    SourceEndpointArn: string;
}
export interface DisconnectEndpointsResponse {
    DestinationEndpointArn: string;
    DestinationEndpointName: string;
    SourceEndpointArn: string;
    SourceEndpointName: string;
}
export interface GetDestinationEndpointRequest {
    Arn: string;
}
export interface GetDestinationEndpointResponse {
    DestinationEndpoint: DestinationEndpoint;
}
export interface GetRouterInputRequest {
    Arn: string;
}
export interface GetRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface GetRouterInputSourceMetadataRequest {
    Arn: string;
}
export type RouterInputMetadata = {
    TransportStreamMediaInfo: TransportMediaInfo;
    RtmpInfo?: undefined;
} | {
    TransportStreamMediaInfo?: undefined;
    RtmpInfo: RtmpSourceMetadataInfo;
};
export interface RouterInputSourceMetadataDetails {
    SourceMetadataMessages: RouterInputMessage[];
    Timestamp: Date;
    RouterInputMetadata?: RouterInputMetadata | undefined;
}
export interface GetRouterInputSourceMetadataResponse {
    Arn: string;
    Name: string;
    SourceMetadataDetails: RouterInputSourceMetadataDetails;
}
export interface GetRouterInputThumbnailRequest {
    Arn: string;
}
export interface RouterInputThumbnailDetails {
    ThumbnailMessages: RouterInputMessage[];
    Thumbnail?: Uint8Array | undefined;
    Timecode?: string | undefined;
    Timestamp?: Date | undefined;
}
export interface GetRouterInputThumbnailResponse {
    Arn: string;
    Name: string;
    ThumbnailDetails: RouterInputThumbnailDetails;
}
export interface GetRouterNetworkInterfaceRequest {
    Arn: string;
}
export interface GetRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface GetRouterOutputRequest {
    Arn: string;
}
export interface GetRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export interface GetSourceEndpointRequest {
    Arn: string;
}
export interface GetSourceEndpointResponse {
    SourceEndpoint: SourceEndpoint;
}
export interface GrantFlowEntitlementsRequest {
    Entitlements?: GrantEntitlementRequest[] | undefined;
    FlowArn: string;
}
export interface GrantFlowEntitlementsResponse {
    Entitlements?: (Entitlement & {
        EntitlementArn: string;
        Name: string;
        Subscribers: __listOfString;
        Encryption: Encryption & {
            RoleArn: string;
        };
    })[] | undefined;
    FlowArn?: string | undefined;
}
export type MaxResults = number;
export interface ListBridgesRequest {
    FilterArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedBridge {
    BridgeArn?: string | undefined;
    BridgeState?: BridgeState | undefined;
    BridgeType?: string | undefined;
    Name?: string | undefined;
    PlacementArn?: string | undefined;
}
export type __listOfListedBridge = ListedBridge[];
export interface ListBridgesResponse {
    Bridges?: (ListedBridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        BridgeType: string;
        Name: string;
        PlacementArn: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type StringList = string[];
export type DestinationEndpointTypeList = DestinationEndpointType[];
export type DestinationEndpointFilter = {
    RegionNames: string[];
    DestinationTypes?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    DestinationTypes: DestinationEndpointType[];
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    DestinationTypes?: undefined;
    NameContains: string[];
};
export type DestinationEndpointFilterList = DestinationEndpointFilter[];
export interface ListDestinationEndpointsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: DestinationEndpointFilter[] | undefined;
}
export interface ListedDestinationEndpoint {
    Name: string;
    Arn: string;
    Id: string;
    DestinationType: DestinationEndpointType;
    RegionName: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    LifecycleManagement: EndpointLifecycle;
    MessageCount: number;
    ResourceShareOwnership: ResourceShareOwnership;
    ResourceShareState: ResourceShareState;
    RegistrationState: DestinationEndpointRegistrationState;
    ConnectionState: DestinationEndpointConnectionState;
    DecryptionType?: EndpointEncryptionType | undefined;
    ConnectedSource?: string | undefined;
    AssociatedResourceArn?: string | undefined;
}
export type ListedDestinationEndpointList = ListedDestinationEndpoint[];
export interface ListDestinationEndpointsResponse {
    DestinationEndpoints: ListedDestinationEndpoint[];
    NextToken?: string | undefined;
}
export interface ListEntitlementsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedEntitlement {
    DataTransferSubscriberFeePercent?: number | undefined;
    EntitlementArn?: string | undefined;
    EntitlementName?: string | undefined;
}
export type __listOfListedEntitlement = ListedEntitlement[];
export interface ListEntitlementsResponse {
    Entitlements?: (ListedEntitlement & {
        EntitlementArn: string;
        EntitlementName: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFlowsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SourceType = "OWNED" | "ENTITLED" | (string & {});
export interface ListedFlow {
    AvailabilityZone?: string | undefined;
    Description?: string | undefined;
    FlowArn?: string | undefined;
    Name?: string | undefined;
    SourceType?: SourceType | undefined;
    Status?: Status | undefined;
    Maintenance?: Maintenance | undefined;
}
export type __listOfListedFlow = ListedFlow[];
export interface ListFlowsResponse {
    Flows?: (ListedFlow & {
        AvailabilityZone: string;
        Description: string;
        FlowArn: string;
        Name: string;
        SourceType: SourceType;
        Status: Status;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGatewayInstancesRequest {
    FilterArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedGatewayInstance {
    GatewayArn?: string | undefined;
    GatewayInstanceArn?: string | undefined;
    InstanceId?: string | undefined;
    InstanceState?: InstanceState | undefined;
}
export type __listOfListedGatewayInstance = ListedGatewayInstance[];
export interface ListGatewayInstancesResponse {
    Instances?: (ListedGatewayInstance & {
        GatewayArn: string;
        GatewayInstanceArn: string;
        InstanceId: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGatewaysRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedGateway {
    GatewayArn?: string | undefined;
    GatewayState?: GatewayState | undefined;
    Name?: string | undefined;
}
export type __listOfListedGateway = ListedGateway[];
export interface ListGatewaysResponse {
    Gateways?: (ListedGateway & {
        GatewayArn: string;
        GatewayState: GatewayState;
        Name: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOfferingsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfOffering = Offering[];
export interface ListOfferingsResponse {
    NextToken?: string | undefined;
    Offerings?: (Offering & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
    })[] | undefined;
}
export interface ListReservationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfReservation = Reservation[];
export interface ListReservationsResponse {
    NextToken?: string | undefined;
    Reservations?: (Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    })[] | undefined;
}
export type RoutingScopeList = RoutingScope[];
export type RouterInputTypeList = RouterInputType[];
export type RouterInputFilter = {
    NameContains: string[];
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    InputTypes?: undefined;
} | {
    NameContains?: undefined;
    RegionNames: string[];
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    InputTypes?: undefined;
} | {
    NameContains?: undefined;
    RegionNames?: undefined;
    NetworkInterfaceArns: string[];
    RoutingScopes?: undefined;
    InputTypes?: undefined;
} | {
    NameContains?: undefined;
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes: RoutingScope[];
    InputTypes?: undefined;
} | {
    NameContains?: undefined;
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    InputTypes: RouterInputType[];
};
export type RouterInputFilterList = RouterInputFilter[];
export interface ListRouterInputsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: RouterInputFilter[] | undefined;
}
export interface ListedRouterInput {
    Name: string;
    Arn: string;
    Id: string;
    InputType: RouterInputType;
    State: RouterInputState;
    RoutedOutputs: number;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    MessageCount: number;
    NetworkInterfaceArn?: string | undefined;
    MaintenanceScheduleType?: MaintenanceScheduleType | undefined;
    MaintenanceSchedule?: MaintenanceSchedule | undefined;
}
export type ListedRouterInputList = ListedRouterInput[];
export interface ListRouterInputsResponse {
    RouterInputs: ListedRouterInput[];
    NextToken?: string | undefined;
}
export type RouterNetworkInterfaceTypeList = RouterNetworkInterfaceType[];
export type RouterNetworkInterfaceFilter = {
    RegionNames: string[];
    NetworkInterfaceTypes?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceTypes: RouterNetworkInterfaceType[];
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceTypes?: undefined;
    NameContains: string[];
};
export type RouterNetworkInterfaceFilterList = RouterNetworkInterfaceFilter[];
export interface ListRouterNetworkInterfacesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: RouterNetworkInterfaceFilter[] | undefined;
}
export interface ListedRouterNetworkInterface {
    Name: string;
    Arn: string;
    Id: string;
    NetworkInterfaceType: RouterNetworkInterfaceType;
    AssociatedOutputCount: number;
    AssociatedInputCount: number;
    State: RouterNetworkInterfaceState;
    RegionName: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListedRouterNetworkInterfaceList = ListedRouterNetworkInterface[];
export interface ListRouterNetworkInterfacesResponse {
    RouterNetworkInterfaces: ListedRouterNetworkInterface[];
    NextToken?: string | undefined;
}
export type RouterOutputTypeList = RouterOutputType[];
export type RouterOutputFilter = {
    RegionNames: string[];
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    OutputTypes?: undefined;
    RoutedInputArns?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceArns: string[];
    RoutingScopes?: undefined;
    OutputTypes?: undefined;
    RoutedInputArns?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes: RoutingScope[];
    OutputTypes?: undefined;
    RoutedInputArns?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    OutputTypes: RouterOutputType[];
    RoutedInputArns?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    OutputTypes?: undefined;
    RoutedInputArns: string[];
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    NetworkInterfaceArns?: undefined;
    RoutingScopes?: undefined;
    OutputTypes?: undefined;
    RoutedInputArns?: undefined;
    NameContains: string[];
};
export type RouterOutputFilterList = RouterOutputFilter[];
export interface ListRouterOutputsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: RouterOutputFilter[] | undefined;
}
export interface ListedRouterOutput {
    Name: string;
    Arn: string;
    Id: string;
    OutputType: RouterOutputType;
    State: RouterOutputState;
    RoutedState: RouterOutputRoutedState;
    RegionName: string;
    AvailabilityZone: string;
    MaximumBitrate: number;
    RoutingScope: RoutingScope;
    CreatedAt: Date;
    UpdatedAt: Date;
    MessageCount: number;
    RoutedInputArn?: string | undefined;
    NetworkInterfaceArn?: string | undefined;
    MaintenanceScheduleType?: MaintenanceScheduleType | undefined;
    MaintenanceSchedule?: MaintenanceSchedule | undefined;
}
export type ListedRouterOutputList = ListedRouterOutput[];
export interface ListRouterOutputsResponse {
    RouterOutputs: ListedRouterOutput[];
    NextToken?: string | undefined;
}
export type SourceEndpointTypeList = SourceEndpointType[];
export type SourceEndpointFilter = {
    RegionNames: string[];
    SourceTypes?: undefined;
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    SourceTypes: SourceEndpointType[];
    NameContains?: undefined;
} | {
    RegionNames?: undefined;
    SourceTypes?: undefined;
    NameContains: string[];
};
export type SourceEndpointFilterList = SourceEndpointFilter[];
export interface ListSourceEndpointsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: SourceEndpointFilter[] | undefined;
}
export interface ListedSourceEndpoint {
    Name: string;
    Arn: string;
    Id: string;
    SourceType: SourceEndpointType;
    RegionName: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    LifecycleManagement: EndpointLifecycle;
    MessageCount: number;
    ResourceShareOwnership: ResourceShareOwnership;
    ResourceShareState: ResourceShareState;
    RegistrationState: SourceEndpointRegistrationState;
    ConnectionState: SourceEndpointConnectionState;
    EncryptionType?: EndpointEncryptionType | undefined;
    ConnectedDestinationCount: number;
    AssociatedResourceArn?: string | undefined;
}
export type ListedSourceEndpointList = ListedSourceEndpoint[];
export interface ListSourceEndpointsResponse {
    SourceEndpoints: ListedSourceEndpoint[];
    NextToken?: string | undefined;
}
export interface ListTagsForGlobalResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForGlobalResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PurchaseOfferingRequest {
    OfferingArn: string;
    ReservationName?: string | undefined;
    Start?: string | undefined;
}
export interface PurchaseOfferingResponse {
    Reservation?: (Reservation & {
        CurrencyCode: string;
        Duration: number;
        DurationUnits: DurationUnits;
        End: string;
        OfferingArn: string;
        OfferingDescription: string;
        PricePerUnit: string;
        PriceUnits: PriceUnits;
        ReservationArn: string;
        ReservationName: string;
        ReservationState: ReservationState;
        ResourceSpecification: ResourceSpecification & {
            ResourceType: ResourceType;
        };
        Start: string;
    }) | undefined;
}
export interface RegisterDestinationEndpointRequest {
    Description?: string | undefined;
    Configuration: DestinationEndpointConfiguration;
    RegionName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface RegisterDestinationEndpointResponse {
    DestinationEndpoint: DestinationEndpoint;
}
export interface RegisterSourceEndpointRequest {
    RegionName?: string | undefined;
    Description?: string | undefined;
    Configuration: SourceEndpointConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface RegisterSourceEndpointResponse {
    SourceEndpoint: SourceEndpoint;
}
export interface RemoveBridgeOutputRequest {
    BridgeArn: string;
    OutputName: string;
}
export interface RemoveBridgeOutputResponse {
    BridgeArn?: string | undefined;
    OutputName?: string | undefined;
}
export interface RemoveBridgeSourceRequest {
    BridgeArn: string;
    SourceName: string;
}
export interface RemoveBridgeSourceResponse {
    BridgeArn?: string | undefined;
    SourceName?: string | undefined;
}
export interface RemoveFlowMediaStreamRequest {
    FlowArn: string;
    MediaStreamName: string;
}
export interface RemoveFlowMediaStreamResponse {
    FlowArn?: string | undefined;
    MediaStreamName?: string | undefined;
}
export interface RemoveFlowOutputRequest {
    FlowArn: string;
    OutputArn: string;
}
export interface RemoveFlowOutputResponse {
    FlowArn?: string | undefined;
    OutputArn?: string | undefined;
}
export interface RemoveFlowSourceRequest {
    FlowArn: string;
    SourceArn: string;
}
export interface RemoveFlowSourceResponse {
    FlowArn?: string | undefined;
    SourceArn?: string | undefined;
}
export interface RemoveFlowVpcInterfaceRequest {
    FlowArn: string;
    VpcInterfaceName: string;
}
export interface RemoveFlowVpcInterfaceResponse {
    FlowArn?: string | undefined;
    NonDeletedNetworkInterfaceIds?: string[] | undefined;
    VpcInterfaceName?: string | undefined;
}
export interface RestartRouterInputRequest {
    Arn: string;
}
export interface RestartRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface RestartRouterOutputRequest {
    Arn: string;
}
export interface RestartRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export interface RevokeFlowEntitlementRequest {
    EntitlementArn: string;
    FlowArn: string;
}
export interface RevokeFlowEntitlementResponse {
    EntitlementArn?: string | undefined;
    FlowArn?: string | undefined;
}
export interface StartFlowRequest {
    FlowArn: string;
}
export interface StartFlowResponse {
    FlowArn?: string | undefined;
    Status?: Status | undefined;
}
export interface StartRouterInputRequest {
    Arn: string;
}
export interface StartRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
    MaintenanceScheduleType: MaintenanceScheduleType;
    MaintenanceSchedule: MaintenanceSchedule;
}
export interface StartRouterOutputRequest {
    Arn: string;
}
export interface StartRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
    MaintenanceScheduleType: MaintenanceScheduleType;
    MaintenanceSchedule: MaintenanceSchedule;
}
export interface StopFlowRequest {
    FlowArn: string;
}
export interface StopFlowResponse {
    FlowArn?: string | undefined;
    Status?: Status | undefined;
}
export interface StopRouterInputRequest {
    Arn: string;
}
export interface StopRouterInputResponse {
    Arn: string;
    Name: string;
    State: RouterInputState;
}
export interface StopRouterOutputRequest {
    Arn: string;
}
export interface StopRouterOutputResponse {
    Arn: string;
    Name: string;
    State: RouterOutputState;
}
export interface TagGlobalResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagGlobalResourceResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface TakeRouterInputRequest {
    RouterOutputArn: string;
    RouterInputArn?: string | undefined;
}
export interface TakeRouterInputResponse {
    RoutedState: RouterOutputRoutedState;
    RouterOutputArn: string;
    RouterOutputName: string;
    RouterInputArn?: string | undefined;
    RouterInputName?: string | undefined;
}
export interface UntagGlobalResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagGlobalResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateEgressGatewayBridgeRequest {
    MaxBitrate?: number | undefined;
}
export interface UpdateIngressGatewayBridgeRequest {
    MaxBitrate?: number | undefined;
    MaxOutputs?: number | undefined;
}
export interface UpdateFailoverConfig {
    FailoverMode?: FailoverMode | undefined;
    RecoveryWindow?: number | undefined;
    SourcePriority?: SourcePriority | undefined;
    State?: State | undefined;
}
export interface UpdateBridgeRequest {
    BridgeArn: string;
    EgressGatewayBridge?: UpdateEgressGatewayBridgeRequest | undefined;
    IngressGatewayBridge?: UpdateIngressGatewayBridgeRequest | undefined;
    SourceFailoverConfig?: UpdateFailoverConfig | undefined;
}
export interface UpdateBridgeResponse {
    Bridge?: (Bridge & {
        BridgeArn: string;
        BridgeState: BridgeState;
        Name: string;
        PlacementArn: string;
        BridgeMessages: (MessageDetail & {
            Code: string;
            Message: string;
        })[];
        EgressGatewayBridge: EgressGatewayBridge & {
            MaxBitrate: number;
        };
        IngressGatewayBridge: IngressGatewayBridge & {
            MaxBitrate: number;
            MaxOutputs: number;
        };
        Outputs: (BridgeOutput & {
            FlowOutput: BridgeFlowOutput & {
                FlowArn: string;
                FlowSourceArn: string;
                Name: string;
            };
            NetworkOutput: BridgeNetworkOutput & {
                IpAddress: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
                Ttl: number;
            };
        })[];
        Sources: (BridgeSource & {
            FlowSource: BridgeFlowSource & {
                FlowArn: string;
                Name: string;
            };
            NetworkSource: BridgeNetworkSource & {
                MulticastIp: string;
                Name: string;
                NetworkName: string;
                Port: number;
                Protocol: Protocol;
            };
        })[];
    }) | undefined;
}
export interface UpdateBridgeNetworkOutputRequest {
    IpAddress?: string | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
    Ttl?: number | undefined;
}
export interface UpdateBridgeOutputRequest {
    BridgeArn: string;
    NetworkOutput?: UpdateBridgeNetworkOutputRequest | undefined;
    OutputName: string;
}
export interface UpdateBridgeOutputResponse {
    BridgeArn?: string | undefined;
    Output?: (BridgeOutput & {
        FlowOutput: BridgeFlowOutput & {
            FlowArn: string;
            FlowSourceArn: string;
            Name: string;
        };
        NetworkOutput: BridgeNetworkOutput & {
            IpAddress: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
            Ttl: number;
        };
    }) | undefined;
}
export interface UpdateBridgeFlowSourceRequest {
    FlowArn?: string | undefined;
    FlowVpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
}
export interface UpdateBridgeNetworkSourceRequest {
    MulticastIp?: string | undefined;
    MulticastSourceSettings?: MulticastSourceSettings | undefined;
    NetworkName?: string | undefined;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
}
export interface UpdateBridgeSourceRequest {
    BridgeArn: string;
    FlowSource?: UpdateBridgeFlowSourceRequest | undefined;
    NetworkSource?: UpdateBridgeNetworkSourceRequest | undefined;
    SourceName: string;
}
export interface UpdateBridgeSourceResponse {
    BridgeArn?: string | undefined;
    Source?: (BridgeSource & {
        FlowSource: BridgeFlowSource & {
            FlowArn: string;
            Name: string;
        };
        NetworkSource: BridgeNetworkSource & {
            MulticastIp: string;
            Name: string;
            NetworkName: string;
            Port: number;
            Protocol: Protocol;
        };
    }) | undefined;
}
export type DesiredState = "ACTIVE" | "STANDBY" | "DELETED" | (string & {});
export interface UpdateBridgeStateRequest {
    BridgeArn: string;
    DesiredState?: DesiredState | undefined;
}
export interface UpdateBridgeStateResponse {
    BridgeArn?: string | undefined;
    DesiredState?: DesiredState | undefined;
}
export interface UpdateDestinationEndpointRequest {
    Arn: string;
    Description?: string | undefined;
    Configuration?: DestinationEndpointConfiguration | undefined;
}
export interface UpdateDestinationEndpointResponse {
    DestinationEndpoint: DestinationEndpoint;
}
export interface UpdateMaintenance {
    MaintenanceDay?: MaintenanceDay | undefined;
    MaintenanceScheduledDate?: string | undefined;
    MaintenanceStartHour?: string | undefined;
}
export interface UpdateFlowRequest {
    FlowArn: string;
    SourceFailoverConfig?: UpdateFailoverConfig | undefined;
    Maintenance?: UpdateMaintenance | undefined;
    SourceMonitoringConfig?: MonitoringConfig | undefined;
    NdiConfig?: NdiConfig | undefined;
    FlowSize?: FlowSize | undefined;
    EncodingConfig?: EncodingConfig | undefined;
}
export interface UpdateFlowResponse {
    Flow?: (Flow & {
        AvailabilityZone: string;
        Entitlements: (Entitlement & {
            EntitlementArn: string;
            Name: string;
            Subscribers: __listOfString;
            Encryption: Encryption & {
                RoleArn: string;
            };
        })[];
        FlowArn: string;
        Name: string;
        Outputs: (Output & {
            Name: string;
            OutputArn: string;
            Encryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                DestinationConfigurations: (DestinationConfiguration & {
                    DestinationIp: string;
                    DestinationPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                    OutboundIp: string;
                })[];
                EncodingParameters: EncodingParameters & {
                    CompressionFactor: number;
                    EncoderProfile: EncoderProfile;
                };
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
        })[];
        Source: Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        };
        Status: Status;
        MediaStreams: (MediaStream & {
            Fmt: number;
            MediaStreamId: number;
            MediaStreamName: string;
            MediaStreamType: MediaStreamType;
            Attributes: MediaStreamAttributes & {
                Fmtp: Fmtp;
            };
        })[];
        Sources: (Source & {
            Name: string;
            SourceArn: string;
            Decryption: Encryption & {
                RoleArn: string;
            };
            MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
                EncodingName: EncodingName;
                MediaStreamName: string;
                InputConfigurations: (InputConfiguration & {
                    InputIp: string;
                    InputPort: number;
                    Interface: Interface & {
                        Name: string;
                    };
                })[];
            })[];
            Transport: Transport & {
                Protocol: Protocol;
                RtmpPushSourceSettings: RtmpPushSourceSettings & {
                    ApplicationName: string;
                    StreamName: string;
                    NamingType: RtmpPushNamingType;
                };
                RtmpPushOutputSettings: RtmpPushOutputSettings & {
                    ApplicationName: string;
                    StreamName: string;
                };
            };
            GatewayBridgeSource: GatewayBridgeSource & {
                BridgeArn: string;
            };
        })[];
        VpcInterfaces: (VpcInterface & {
            Name: string;
            NetworkInterfaceIds: __listOfString;
            NetworkInterfaceType: NetworkInterfaceType;
            RoleArn: string;
            SecurityGroupIds: __listOfString;
            SubnetId: string;
        })[];
        NdiConfig: NdiConfig & {
            NdiDiscoveryServers: (NdiDiscoveryServerConfig & {
                DiscoveryServerAddress: string;
                VpcInterfaceAdapter: string;
            })[];
        };
    }) | undefined;
}
export interface UpdateEncryption {
    Algorithm?: Algorithm | undefined;
    ConstantInitializationVector?: string | undefined;
    DeviceId?: string | undefined;
    KeyType?: KeyType | undefined;
    Region?: string | undefined;
    ResourceId?: string | undefined;
    RoleArn?: string | undefined;
    SecretArn?: string | undefined;
    Url?: string | undefined;
}
export interface UpdateFlowEntitlementRequest {
    Description?: string | undefined;
    Encryption?: UpdateEncryption | undefined;
    EntitlementArn: string;
    EntitlementStatus?: EntitlementStatus | undefined;
    FlowArn: string;
    Subscribers?: string[] | undefined;
}
export interface UpdateFlowEntitlementResponse {
    Entitlement?: (Entitlement & {
        EntitlementArn: string;
        Name: string;
        Subscribers: __listOfString;
        Encryption: Encryption & {
            RoleArn: string;
        };
    }) | undefined;
    FlowArn?: string | undefined;
}
export interface UpdateFlowMediaStreamRequest {
    Attributes?: MediaStreamAttributesRequest | undefined;
    ClockRate?: number | undefined;
    Description?: string | undefined;
    FlowArn: string;
    MediaStreamName: string;
    MediaStreamType?: MediaStreamType | undefined;
    VideoFormat?: string | undefined;
}
export interface UpdateFlowMediaStreamResponse {
    FlowArn?: string | undefined;
    MediaStream?: (MediaStream & {
        Fmt: number;
        MediaStreamId: number;
        MediaStreamName: string;
        MediaStreamType: MediaStreamType;
        Attributes: MediaStreamAttributes & {
            Fmtp: Fmtp;
        };
    }) | undefined;
}
export interface UpdateFlowOutputRequest {
    CidrAllowList?: string[] | undefined;
    Description?: string | undefined;
    Destination?: string | undefined;
    Encryption?: UpdateEncryption | undefined;
    FlowArn: string;
    MaxLatency?: number | undefined;
    MediaStreamOutputConfigurations?: MediaStreamOutputConfigurationRequest[] | undefined;
    MinLatency?: number | undefined;
    OutputArn: string;
    Port?: number | undefined;
    Protocol?: Protocol | undefined;
    RemoteId?: string | undefined;
    SenderControlPort?: number | undefined;
    SenderIpAddress?: string | undefined;
    SmoothingLatency?: number | undefined;
    StreamId?: string | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
    OutputStatus?: OutputStatus | undefined;
    NdiProgramName?: string | undefined;
    NdiSpeedHqQuality?: number | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitEncryption?: FlowTransitEncryption | undefined;
    NdiOutputTimecodeSource?: NdiOutputTimecodeSource | undefined;
    NdiAudioReferenceLevel?: number | undefined;
    RtmpPushSettings?: RtmpPushOutputSettings | undefined;
}
export interface UpdateFlowOutputResponse {
    FlowArn?: string | undefined;
    Output?: (Output & {
        Name: string;
        OutputArn: string;
        Encryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamOutputConfigurations: (MediaStreamOutputConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            DestinationConfigurations: (DestinationConfiguration & {
                DestinationIp: string;
                DestinationPort: number;
                Interface: Interface & {
                    Name: string;
                };
                OutboundIp: string;
            })[];
            EncodingParameters: EncodingParameters & {
                CompressionFactor: number;
                EncoderProfile: EncoderProfile;
            };
        })[];
        Transport: Transport & {
            Protocol: Protocol;
            RtmpPushSourceSettings: RtmpPushSourceSettings & {
                ApplicationName: string;
                StreamName: string;
                NamingType: RtmpPushNamingType;
            };
            RtmpPushOutputSettings: RtmpPushOutputSettings & {
                ApplicationName: string;
                StreamName: string;
            };
        };
    }) | undefined;
}
export interface UpdateGatewayBridgeSourceRequest {
    BridgeArn?: string | undefined;
    VpcInterfaceAttachment?: VpcInterfaceAttachment | undefined;
}
export interface UpdateFlowSourceRequest {
    Decryption?: UpdateEncryption | undefined;
    Description?: string | undefined;
    EntitlementArn?: string | undefined;
    FlowArn: string;
    IngestPort?: number | undefined;
    MaxBitrate?: number | undefined;
    MaxLatency?: number | undefined;
    MaxSyncBuffer?: number | undefined;
    MediaStreamSourceConfigurations?: MediaStreamSourceConfigurationRequest[] | undefined;
    MinLatency?: number | undefined;
    Protocol?: Protocol | undefined;
    SenderControlPort?: number | undefined;
    SenderIpAddress?: string | undefined;
    SourceArn: string;
    SourceListenerAddress?: string | undefined;
    SourceListenerPort?: number | undefined;
    StreamId?: string | undefined;
    VpcInterfaceName?: string | undefined;
    WhitelistCidr?: string | undefined;
    GatewayBridgeSource?: UpdateGatewayBridgeSourceRequest | undefined;
    NdiSourceSettings?: NdiSourceSettings | undefined;
    RouterIntegrationState?: State | undefined;
    RouterIntegrationTransitDecryption?: FlowTransitEncryption | undefined;
    RtmpPushSettings?: SetRtmpPushSourceSettings | undefined;
}
export interface UpdateFlowSourceResponse {
    FlowArn?: string | undefined;
    Source?: (Source & {
        Name: string;
        SourceArn: string;
        Decryption: Encryption & {
            RoleArn: string;
        };
        MediaStreamSourceConfigurations: (MediaStreamSourceConfiguration & {
            EncodingName: EncodingName;
            MediaStreamName: string;
            InputConfigurations: (InputConfiguration & {
                InputIp: string;
                InputPort: number;
                Interface: Interface & {
                    Name: string;
                };
            })[];
        })[];
        Transport: Transport & {
            Protocol: Protocol;
            RtmpPushSourceSettings: RtmpPushSourceSettings & {
                ApplicationName: string;
                StreamName: string;
                NamingType: RtmpPushNamingType;
            };
            RtmpPushOutputSettings: RtmpPushOutputSettings & {
                ApplicationName: string;
                StreamName: string;
            };
        };
        GatewayBridgeSource: GatewayBridgeSource & {
            BridgeArn: string;
        };
    }) | undefined;
}
export interface UpdateGatewayInstanceRequest {
    BridgePlacement?: BridgePlacement | undefined;
    GatewayInstanceArn: string;
}
export interface UpdateGatewayInstanceResponse {
    BridgePlacement?: BridgePlacement | undefined;
    GatewayInstanceArn?: string | undefined;
}
export interface UpdateRouterInputRequest {
    Arn: string;
    Name?: string | undefined;
    Configuration?: RouterInputConfiguration | undefined;
    MaximumBitrate?: number | undefined;
    RoutingScope?: RoutingScope | undefined;
    Tier?: RouterInputTier | undefined;
    TransitEncryption?: RouterInputTransitEncryption | undefined;
    MaintenanceConfiguration?: MaintenanceConfiguration | undefined;
    ContentQualityAnalysisConfiguration?: RouterContentQualityAnalysisConfiguration | undefined;
}
export interface UpdateRouterInputResponse {
    RouterInput: RouterInput & {
        ContentQualityAnalysisType: RouterContentQualityAnalysisType;
        ContentQualityAnalysisConfiguration: RouterContentQualityAnalysisConfiguration;
    };
}
export interface UpdateRouterNetworkInterfaceRequest {
    Arn: string;
    Name?: string | undefined;
    Configuration?: RouterNetworkInterfaceConfiguration | undefined;
}
export interface UpdateRouterNetworkInterfaceResponse {
    RouterNetworkInterface: RouterNetworkInterface;
}
export interface UpdateRouterOutputRequest {
    Arn: string;
    Name?: string | undefined;
    Configuration?: RouterOutputConfiguration | undefined;
    MaximumBitrate?: number | undefined;
    RoutingScope?: RoutingScope | undefined;
    Tier?: RouterOutputTier | undefined;
    MaintenanceConfiguration?: MaintenanceConfiguration | undefined;
    FabricConfiguration?: FabricConfiguration | undefined;
    Processors?: RouterOutputProcessors | undefined;
}
export interface UpdateRouterOutputResponse {
    RouterOutput: RouterOutput & {
        FabricConfiguration: FabricConfiguration;
    };
}
export interface UpdateSourceEndpointRequest {
    Arn: string;
    Description?: string | undefined;
    Configuration?: SourceEndpointConfiguration | undefined;
}
export interface UpdateSourceEndpointResponse {
    SourceEndpoint: SourceEndpoint;
}
export type AddBridgeOutputsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds outputs to an existing bridge.
 */
export declare const addBridgeOutputs: API.OperationMethod<AddBridgeOutputsRequest & RegionInput, AddBridgeOutputsResponse, AddBridgeOutputsError, Credentials | HttpClient.HttpClient>;
export type AddBridgeSourcesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds sources to an existing bridge.
 */
export declare const addBridgeSources: API.OperationMethod<AddBridgeSourcesRequest & RegionInput, AddBridgeSourcesResponse, AddBridgeSourcesError, Credentials | HttpClient.HttpClient>;
export type AddFlowMediaStreamsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds media streams to an existing flow. After you add a media stream to a flow, you can associate it with a source and/or an output that uses the ST 2110 JPEG XS or CDI protocol.
 */
export declare const addFlowMediaStreams: API.OperationMethod<AddFlowMediaStreamsRequest & RegionInput, AddFlowMediaStreamsResponse, AddFlowMediaStreamsError, Credentials | HttpClient.HttpClient>;
export type AddFlowOutputsError = AddFlowOutputs420Exception | BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds outputs to an existing flow. You can create up to 50 outputs per flow.
 */
export declare const addFlowOutputs: API.OperationMethod<AddFlowOutputsRequest & RegionInput, AddFlowOutputsResponse, AddFlowOutputsError, Credentials | HttpClient.HttpClient>;
export type AddFlowSourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds sources to a flow.
 */
export declare const addFlowSources: API.OperationMethod<AddFlowSourcesRequest & RegionInput, AddFlowSourcesResponse, AddFlowSourcesError, Credentials | HttpClient.HttpClient>;
export type AddFlowVpcInterfacesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Adds VPC interfaces to a flow.
 */
export declare const addFlowVpcInterfaces: API.OperationMethod<AddFlowVpcInterfacesRequest & RegionInput, AddFlowVpcInterfacesResponse, AddFlowVpcInterfacesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDestinationEndpointError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple destination endpoints in a single request.
 */
export declare const batchGetDestinationEndpoint: API.OperationMethod<BatchGetDestinationEndpointRequest & RegionInput, BatchGetDestinationEndpointResponse, BatchGetDestinationEndpointError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterInputError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router inputs in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterInput: API.OperationMethod<BatchGetRouterInputRequest & RegionInput, BatchGetRouterInputResponse, BatchGetRouterInputError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterNetworkInterfaceError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router network interfaces in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterNetworkInterface: API.OperationMethod<BatchGetRouterNetworkInterfaceRequest & RegionInput, BatchGetRouterNetworkInterfaceResponse, BatchGetRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type BatchGetRouterOutputError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple router outputs in AWS Elemental MediaConnect.
 */
export declare const batchGetRouterOutput: API.OperationMethod<BatchGetRouterOutputRequest & RegionInput, BatchGetRouterOutputResponse, BatchGetRouterOutputError, Credentials | HttpClient.HttpClient>;
export type BatchGetSourceEndpointError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about multiple source endpoints in a single request.
 */
export declare const batchGetSourceEndpoint: API.OperationMethod<BatchGetSourceEndpointRequest & RegionInput, BatchGetSourceEndpointResponse, BatchGetSourceEndpointError, Credentials | HttpClient.HttpClient>;
export type ConnectEndpointsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Connects a source endpoint to a destination endpoint.
 */
export declare const connectEndpoints: API.OperationMethod<ConnectEndpointsRequest & RegionInput, ConnectEndpointsResponse, ConnectEndpointsError, Credentials | HttpClient.HttpClient>;
export type CreateBridgeError = BadRequestException | ConflictException | CreateBridge420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new bridge. The request must include one source.
 */
export declare const createBridge: API.OperationMethod<CreateBridgeRequest & RegionInput, CreateBridgeResponse, CreateBridgeError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = BadRequestException | CreateFlow420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new flow. The request must include one source. The request optionally can include outputs (up to 50) and entitlements (up to 50).
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest & RegionInput, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = BadRequestException | ConflictException | CreateGateway420Exception | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new gateway. The request must include at least one network (up to four).
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest & RegionInput, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterInputServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router input in AWS Elemental MediaConnect.
 */
export declare const createRouterInput: API.OperationMethod<CreateRouterInputRequest & RegionInput, CreateRouterInputResponse, CreateRouterInputError, Credentials | HttpClient.HttpClient>;
export type CreateRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterNetworkInterfaceServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router network interface in AWS Elemental MediaConnect.
 */
export declare const createRouterNetworkInterface: API.OperationMethod<CreateRouterNetworkInterfaceRequest & RegionInput, CreateRouterNetworkInterfaceResponse, CreateRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | RouterOutputServiceQuotaExceededException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new router output in AWS Elemental MediaConnect.
 */
export declare const createRouterOutput: API.OperationMethod<CreateRouterOutputRequest & RegionInput, CreateRouterOutputResponse, CreateRouterOutputError, Credentials | HttpClient.HttpClient>;
export type DeleteBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a bridge. Before you can delete a bridge, you must stop the bridge.
 */
export declare const deleteBridge: API.OperationMethod<DeleteBridgeRequest & RegionInput, DeleteBridgeResponse, DeleteBridgeError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a flow. Before you can delete a flow, you must stop the flow.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest & RegionInput, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a gateway. Before you can delete a gateway, you must deregister its instances and delete its bridges.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest & RegionInput, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router input from AWS Elemental MediaConnect.
 */
export declare const deleteRouterInput: API.OperationMethod<DeleteRouterInputRequest & RegionInput, DeleteRouterInputResponse, DeleteRouterInputError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router network interface from AWS Elemental MediaConnect.
 */
export declare const deleteRouterNetworkInterface: API.OperationMethod<DeleteRouterNetworkInterfaceRequest & RegionInput, DeleteRouterNetworkInterfaceResponse, DeleteRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type DeleteRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a router output from AWS Elemental MediaConnect.
 */
export declare const deleteRouterOutput: API.OperationMethod<DeleteRouterOutputRequest & RegionInput, DeleteRouterOutputResponse, DeleteRouterOutputError, Credentials | HttpClient.HttpClient>;
export type DeregisterDestinationEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deregisters a destination endpoint from MediaConnect.
 */
export declare const deregisterDestinationEndpoint: API.OperationMethod<DeregisterDestinationEndpointRequest & RegionInput, DeregisterDestinationEndpointResponse, DeregisterDestinationEndpointError, Credentials | HttpClient.HttpClient>;
export type DeregisterGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deregisters an instance. Before you deregister an instance, all bridges running on the instance must be stopped. If you want to deregister an instance without stopping the bridges, you must use the --force option.
 */
export declare const deregisterGatewayInstance: API.OperationMethod<DeregisterGatewayInstanceRequest & RegionInput, DeregisterGatewayInstanceResponse, DeregisterGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type DeregisterSourceEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deregisters a source endpoint from MediaConnect.
 */
export declare const deregisterSourceEndpoint: API.OperationMethod<DeregisterSourceEndpointRequest & RegionInput, DeregisterSourceEndpointResponse, DeregisterSourceEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a bridge.
 */
export declare const describeBridge: API.OperationMethod<DescribeBridgeRequest & RegionInput, DescribeBridgeResponse, DescribeBridgeError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a flow. The response includes the flow Amazon Resource Name (ARN), name, and Availability Zone, as well as details about the source, outputs, and entitlements.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest & RegionInput, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowSourceMetadataError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * The `DescribeFlowSourceMetadata` API is used to view information about the flow's source transport stream and programs. This API displays status messages about the flow's source as well as details about the program's video, audio, and other data.
 */
export declare const describeFlowSourceMetadata: API.OperationMethod<DescribeFlowSourceMetadataRequest & RegionInput, DescribeFlowSourceMetadataResponse, DescribeFlowSourceMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowSourceThumbnailError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes the thumbnail for the flow source.
 */
export declare const describeFlowSourceThumbnail: API.OperationMethod<DescribeFlowSourceThumbnailRequest & RegionInput, DescribeFlowSourceThumbnailResponse, DescribeFlowSourceThumbnailError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a gateway. The response includes the gateway Amazon Resource Name (ARN), name, and CIDR blocks, as well as details about the networks.
 */
export declare const describeGateway: API.OperationMethod<DescribeGatewayRequest & RegionInput, DescribeGatewayResponse, DescribeGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of an instance.
 */
export declare const describeGatewayInstance: API.OperationMethod<DescribeGatewayInstanceRequest & RegionInput, DescribeGatewayInstanceResponse, DescribeGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeOfferingError = BadRequestException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of an offering. The response includes the offering description, duration, outbound bandwidth, price, and Amazon Resource Name (ARN).
 */
export declare const describeOffering: API.OperationMethod<DescribeOfferingRequest & RegionInput, DescribeOfferingResponse, DescribeOfferingError, Credentials | HttpClient.HttpClient>;
export type DescribeReservationError = BadRequestException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays the details of a reservation. The response includes the reservation name, state, start date and time, and the details of the offering that make up the rest of the reservation (such as price, duration, and outbound bandwidth).
 */
export declare const describeReservation: API.OperationMethod<DescribeReservationRequest & RegionInput, DescribeReservationResponse, DescribeReservationError, Credentials | HttpClient.HttpClient>;
export type DisconnectEndpointsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Disconnects a source endpoint from a destination endpoint.
 */
export declare const disconnectEndpoints: API.OperationMethod<DisconnectEndpointsRequest & RegionInput, DisconnectEndpointsResponse, DisconnectEndpointsError, Credentials | HttpClient.HttpClient>;
export type GetDestinationEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a destination endpoint.
 */
export declare const getDestinationEndpoint: API.OperationMethod<GetDestinationEndpointRequest & RegionInput, GetDestinationEndpointResponse, GetDestinationEndpointError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router input in AWS Elemental MediaConnect.
 */
export declare const getRouterInput: API.OperationMethod<GetRouterInputRequest & RegionInput, GetRouterInputResponse, GetRouterInputError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputSourceMetadataError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves detailed metadata information about a specific router input source, including stream details and connection state.
 */
export declare const getRouterInputSourceMetadata: API.OperationMethod<GetRouterInputSourceMetadataRequest & RegionInput, GetRouterInputSourceMetadataResponse, GetRouterInputSourceMetadataError, Credentials | HttpClient.HttpClient>;
export type GetRouterInputThumbnailError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the thumbnail for a router input in AWS Elemental MediaConnect.
 */
export declare const getRouterInputThumbnail: API.OperationMethod<GetRouterInputThumbnailRequest & RegionInput, GetRouterInputThumbnailResponse, GetRouterInputThumbnailError, Credentials | HttpClient.HttpClient>;
export type GetRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router network interface in AWS Elemental MediaConnect.
 */
export declare const getRouterNetworkInterface: API.OperationMethod<GetRouterNetworkInterfaceRequest & RegionInput, GetRouterNetworkInterfaceResponse, GetRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type GetRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific router output in AWS Elemental MediaConnect.
 */
export declare const getRouterOutput: API.OperationMethod<GetRouterOutputRequest & RegionInput, GetRouterOutputResponse, GetRouterOutputError, Credentials | HttpClient.HttpClient>;
export type GetSourceEndpointError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a source endpoint.
 */
export declare const getSourceEndpoint: API.OperationMethod<GetSourceEndpointRequest & RegionInput, GetSourceEndpointResponse, GetSourceEndpointError, Credentials | HttpClient.HttpClient>;
export type GrantFlowEntitlementsError = BadRequestException | ForbiddenException | GrantFlowEntitlements420Exception | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Grants entitlements to an existing flow.
 */
export declare const grantFlowEntitlements: API.OperationMethod<GrantFlowEntitlementsRequest & RegionInput, GrantFlowEntitlementsResponse, GrantFlowEntitlementsError, Credentials | HttpClient.HttpClient>;
export type ListBridgesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of bridges that are associated with this account and an optionally specified Amazon Resource Name (ARN). This request returns a paginated result.
 */
export declare const listBridges: API.PaginatedOperationMethod<ListBridgesRequest & RegionInput, ListBridgesResponse, ListBridgesError, Credentials | HttpClient.HttpClient, ListedBridge>;
export type ListDestinationEndpointsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of the destination endpoints in your account. The results are paginated. Use the NextToken value that's returned to retrieve additional results.
 */
export declare const listDestinationEndpoints: API.PaginatedOperationMethod<ListDestinationEndpointsRequest & RegionInput, ListDestinationEndpointsResponse, ListDestinationEndpointsError, Credentials | HttpClient.HttpClient, ListedDestinationEndpoint>;
export type ListEntitlementsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all entitlements that have been granted to this account. This request returns 20 results per page.
 */
export declare const listEntitlements: API.PaginatedOperationMethod<ListEntitlementsRequest & RegionInput, ListEntitlementsResponse, ListEntitlementsError, Credentials | HttpClient.HttpClient, ListedEntitlement>;
export type ListFlowsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of flows that are associated with this account. This request returns a paginated result.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest & RegionInput, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, ListedFlow>;
export type ListGatewayInstancesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of instances associated with the Amazon Web Services account. This request returns a paginated result. You can use the filterArn property to display only the instances associated with the selected Gateway Amazon Resource Name (ARN).
 */
export declare const listGatewayInstances: API.PaginatedOperationMethod<ListGatewayInstancesRequest & RegionInput, ListGatewayInstancesResponse, ListGatewayInstancesError, Credentials | HttpClient.HttpClient, ListedGatewayInstance>;
export type ListGatewaysError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of gateways that are associated with this account. This request returns a paginated result.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest & RegionInput, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, ListedGateway>;
export type ListOfferingsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all offerings that are available to this account in the current Amazon Web Services Region. If you have an active reservation (which means you've purchased an offering that has already started and hasn't expired yet), your account isn't eligible for other offerings.
 */
export declare const listOfferings: API.PaginatedOperationMethod<ListOfferingsRequest & RegionInput, ListOfferingsResponse, ListOfferingsError, Credentials | HttpClient.HttpClient, Offering>;
export type ListReservationsError = BadRequestException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Displays a list of all reservations that have been purchased by this account in the current Amazon Web Services Region. This list includes all reservations in all states (such as active and expired).
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest & RegionInput, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListRouterInputsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router inputs in AWS Elemental MediaConnect.
 */
export declare const listRouterInputs: API.PaginatedOperationMethod<ListRouterInputsRequest & RegionInput, ListRouterInputsResponse, ListRouterInputsError, Credentials | HttpClient.HttpClient, ListedRouterInput>;
export type ListRouterNetworkInterfacesError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router network interfaces in AWS Elemental MediaConnect.
 */
export declare const listRouterNetworkInterfaces: API.PaginatedOperationMethod<ListRouterNetworkInterfacesRequest & RegionInput, ListRouterNetworkInterfacesResponse, ListRouterNetworkInterfacesError, Credentials | HttpClient.HttpClient, ListedRouterNetworkInterface>;
export type ListRouterOutputsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of router outputs in AWS Elemental MediaConnect.
 */
export declare const listRouterOutputs: API.PaginatedOperationMethod<ListRouterOutputsRequest & RegionInput, ListRouterOutputsResponse, ListRouterOutputsError, Credentials | HttpClient.HttpClient, ListedRouterOutput>;
export type ListSourceEndpointsError = BadRequestException | ConflictException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves a list of the source endpoints in your account. The results are paginated. Use the NextToken value that's returned to retrieve additional results.
 */
export declare const listSourceEndpoints: API.PaginatedOperationMethod<ListSourceEndpointsRequest & RegionInput, ListSourceEndpointsResponse, ListSourceEndpointsError, Credentials | HttpClient.HttpClient, ListedSourceEndpoint>;
export type ListTagsForGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists the tags associated with a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const listTagsForGlobalResource: API.OperationMethod<ListTagsForGlobalResourceRequest & RegionInput, ListTagsForGlobalResourceResponse, ListTagsForGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * List all tags on a MediaConnect resource in the current region.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PurchaseOfferingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Submits a request to purchase an offering. If you already have an active reservation, you can't purchase another offering.
 */
export declare const purchaseOffering: API.OperationMethod<PurchaseOfferingRequest & RegionInput, PurchaseOfferingResponse, PurchaseOfferingError, Credentials | HttpClient.HttpClient>;
export type RegisterDestinationEndpointError = BadRequestException | ConflictException | DestinationEndpointServiceQuotaExceededException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Registers a new destination endpoint in MediaConnect.
 */
export declare const registerDestinationEndpoint: API.OperationMethod<RegisterDestinationEndpointRequest & RegionInput, RegisterDestinationEndpointResponse, RegisterDestinationEndpointError, Credentials | HttpClient.HttpClient>;
export type RegisterSourceEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | SourceEndpointServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Registers a new source endpoint in MediaConnect.
 */
export declare const registerSourceEndpoint: API.OperationMethod<RegisterSourceEndpointRequest & RegionInput, RegisterSourceEndpointResponse, RegisterSourceEndpointError, Credentials | HttpClient.HttpClient>;
export type RemoveBridgeOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes an output from a bridge.
 */
export declare const removeBridgeOutput: API.OperationMethod<RemoveBridgeOutputRequest & RegionInput, RemoveBridgeOutputResponse, RemoveBridgeOutputError, Credentials | HttpClient.HttpClient>;
export type RemoveBridgeSourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a source from a bridge.
 */
export declare const removeBridgeSource: API.OperationMethod<RemoveBridgeSourceRequest & RegionInput, RemoveBridgeSourceResponse, RemoveBridgeSourceError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowMediaStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a media stream from a flow. This action is only available if the media stream is not associated with a source or output.
 */
export declare const removeFlowMediaStream: API.OperationMethod<RemoveFlowMediaStreamRequest & RegionInput, RemoveFlowMediaStreamResponse, RemoveFlowMediaStreamError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowOutputError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes an output from an existing flow. This request can be made only on an output that does not have an entitlement associated with it. If the output has an entitlement, you must revoke the entitlement instead. When an entitlement is revoked from a flow, the service automatically removes the associated output.
 */
export declare const removeFlowOutput: API.OperationMethod<RemoveFlowOutputRequest & RegionInput, RemoveFlowOutputResponse, RemoveFlowOutputError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a source from an existing flow. This request can be made only if there is more than one source on the flow.
 */
export declare const removeFlowSource: API.OperationMethod<RemoveFlowSourceRequest & RegionInput, RemoveFlowSourceResponse, RemoveFlowSourceError, Credentials | HttpClient.HttpClient>;
export type RemoveFlowVpcInterfaceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Removes a VPC Interface from an existing flow. This request can be made only on a VPC interface that does not have a Source or Output associated with it. If the VPC interface is referenced by a Source or Output, you must first delete or update the Source or Output to no longer reference the VPC interface.
 */
export declare const removeFlowVpcInterface: API.OperationMethod<RemoveFlowVpcInterfaceRequest & RegionInput, RemoveFlowVpcInterfaceResponse, RemoveFlowVpcInterfaceError, Credentials | HttpClient.HttpClient>;
export type RestartRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Restarts a router input. This operation can be used to recover from errors or refresh the input state.
 */
export declare const restartRouterInput: API.OperationMethod<RestartRouterInputRequest & RegionInput, RestartRouterInputResponse, RestartRouterInputError, Credentials | HttpClient.HttpClient>;
export type RestartRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Restarts a router output. This operation can be used to recover from errors or refresh the output state.
 */
export declare const restartRouterOutput: API.OperationMethod<RestartRouterOutputRequest & RegionInput, RestartRouterOutputResponse, RestartRouterOutputError, Credentials | HttpClient.HttpClient>;
export type RevokeFlowEntitlementError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Revokes an entitlement from a flow. Once an entitlement is revoked, the content becomes unavailable to the subscriber and the associated output is removed.
 */
export declare const revokeFlowEntitlement: API.OperationMethod<RevokeFlowEntitlementRequest & RegionInput, RevokeFlowEntitlementResponse, RevokeFlowEntitlementError, Credentials | HttpClient.HttpClient>;
export type StartFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a flow.
 */
export declare const startFlow: API.OperationMethod<StartFlowRequest & RegionInput, StartFlowResponse, StartFlowError, Credentials | HttpClient.HttpClient>;
export type StartRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a router input in AWS Elemental MediaConnect.
 */
export declare const startRouterInput: API.OperationMethod<StartRouterInputRequest & RegionInput, StartRouterInputResponse, StartRouterInputError, Credentials | HttpClient.HttpClient>;
export type StartRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Starts a router output in AWS Elemental MediaConnect.
 */
export declare const startRouterOutput: API.OperationMethod<StartRouterOutputRequest & RegionInput, StartRouterOutputResponse, StartRouterOutputError, Credentials | HttpClient.HttpClient>;
export type StopFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a flow.
 */
export declare const stopFlow: API.OperationMethod<StopFlowRequest & RegionInput, StopFlowResponse, StopFlowError, Credentials | HttpClient.HttpClient>;
export type StopRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a router input in AWS Elemental MediaConnect.
 */
export declare const stopRouterInput: API.OperationMethod<StopRouterInputRequest & RegionInput, StopRouterInputResponse, StopRouterInputError, Credentials | HttpClient.HttpClient>;
export type StopRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Stops a router output in AWS Elemental MediaConnect.
 */
export declare const stopRouterOutput: API.OperationMethod<StopRouterOutputRequest & RegionInput, StopRouterOutputResponse, StopRouterOutputError, Credentials | HttpClient.HttpClient>;
export type TagGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const tagGlobalResource: API.OperationMethod<TagGlobalResourceRequest & RegionInput, TagGlobalResourceResponse, TagGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn` in the current region. If existing tags on a resource are not specified in the request parameters, they are not changed. When a resource is deleted, the tags associated with that resource are deleted as well.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TakeRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Associates a router input with a router output in AWS Elemental MediaConnect.
 */
export declare const takeRouterInput: API.OperationMethod<TakeRouterInputRequest & RegionInput, TakeRouterInputResponse, TakeRouterInputError, Credentials | HttpClient.HttpClient>;
export type UntagGlobalResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags from a global resource in AWS Elemental MediaConnect. The API supports the following global resources: router inputs, router outputs and router network interfaces.
 */
export declare const untagGlobalResource: API.OperationMethod<UntagGlobalResourceRequest & RegionInput, UntagGlobalResourceResponse, UntagGlobalResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes specified tags from a resource in the current region.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the bridge.
 */
export declare const updateBridge: API.OperationMethod<UpdateBridgeRequest & RegionInput, UpdateBridgeResponse, UpdateBridgeError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing bridge output.
 */
export declare const updateBridgeOutput: API.OperationMethod<UpdateBridgeOutputRequest & RegionInput, UpdateBridgeOutputResponse, UpdateBridgeOutputError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeSourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing bridge source.
 */
export declare const updateBridgeSource: API.OperationMethod<UpdateBridgeSourceRequest & RegionInput, UpdateBridgeSourceResponse, UpdateBridgeSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBridgeStateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the bridge state.
 */
export declare const updateBridgeState: API.OperationMethod<UpdateBridgeStateRequest & RegionInput, UpdateBridgeStateResponse, UpdateBridgeStateError, Credentials | HttpClient.HttpClient>;
export type UpdateDestinationEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of a destination endpoint.
 */
export declare const updateDestinationEndpoint: API.OperationMethod<UpdateDestinationEndpointRequest & RegionInput, UpdateDestinationEndpointResponse, UpdateDestinationEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing flow.
 *
 * Because `UpdateFlowSources` and `UpdateFlow` are separate operations, you can't change both the source type AND the flow size in a single request.
 *
 * - If you have a `MEDIUM` flow and you want to change the flow source to NDI®:
 *
 * - First, use the `UpdateFlow` operation to upgrade the flow size to `LARGE`.
 *
 * - After that, you can then use the `UpdateFlowSource` operation to configure the NDI source.
 *
 * - If you're switching from an NDI source to a transport stream (TS) source and want to downgrade the flow size:
 *
 * - First, use the `UpdateFlowSource` operation to change the flow source type.
 *
 * - After that, you can then use the `UpdateFlow` operation to downgrade the flow size to `MEDIUM`.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest & RegionInput, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowEntitlementError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an entitlement. You can change an entitlement's description, subscribers, and encryption. If you change the subscribers, the service will remove the outputs that are are used by the subscribers that are removed.
 */
export declare const updateFlowEntitlement: API.OperationMethod<UpdateFlowEntitlementRequest & RegionInput, UpdateFlowEntitlementResponse, UpdateFlowEntitlementError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowMediaStreamError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing media stream.
 */
export declare const updateFlowMediaStream: API.OperationMethod<UpdateFlowMediaStreamRequest & RegionInput, UpdateFlowMediaStreamResponse, UpdateFlowMediaStreamError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowOutputError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing flow output.
 */
export declare const updateFlowOutput: API.OperationMethod<UpdateFlowOutputRequest & RegionInput, UpdateFlowOutputResponse, UpdateFlowOutputError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the source of a flow.
 *
 * Because `UpdateFlowSources` and `UpdateFlow` are separate operations, you can't change both the source type AND the flow size in a single request.
 *
 * - If you have a `MEDIUM` flow and you want to change the flow source to NDI®:
 *
 * - First, use the `UpdateFlow` operation to upgrade the flow size to `LARGE`.
 *
 * - After that, you can then use the `UpdateFlowSource` operation to configure the NDI source.
 *
 * - If you're switching from an NDI source to a transport stream (TS) source and want to downgrade the flow size:
 *
 * - First, use the `UpdateFlowSource` operation to change the flow source type.
 *
 * - After that, you can then use the `UpdateFlow` operation to downgrade the flow size to `MEDIUM`.
 */
export declare const updateFlowSource: API.OperationMethod<UpdateFlowSourceRequest & RegionInput, UpdateFlowSourceResponse, UpdateFlowSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInstanceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing gateway instance.
 */
export declare const updateGatewayInstance: API.OperationMethod<UpdateGatewayInstanceRequest & RegionInput, UpdateGatewayInstanceResponse, UpdateGatewayInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterInputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router input in AWS Elemental MediaConnect.
 */
export declare const updateRouterInput: API.OperationMethod<UpdateRouterInputRequest & RegionInput, UpdateRouterInputResponse, UpdateRouterInputError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterNetworkInterfaceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router network interface in AWS Elemental MediaConnect.
 */
export declare const updateRouterNetworkInterface: API.OperationMethod<UpdateRouterNetworkInterfaceRequest & RegionInput, UpdateRouterNetworkInterfaceResponse, UpdateRouterNetworkInterfaceError, Credentials | HttpClient.HttpClient>;
export type UpdateRouterOutputError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing router output in AWS Elemental MediaConnect.
 */
export declare const updateRouterOutput: API.OperationMethod<UpdateRouterOutputRequest & RegionInput, UpdateRouterOutputResponse, UpdateRouterOutputError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceEndpointError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of a source endpoint.
 */
export declare const updateSourceEndpoint: API.OperationMethod<UpdateSourceEndpointRequest & RegionInput, UpdateSourceEndpointResponse, UpdateSourceEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediaconnect.d.ts.map