import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationId = string;
export type JobRunId = string;
export type ShutdownGracePeriodInSeconds = number;
export interface CancelJobRunRequest {
    applicationId: string;
    jobRunId: string;
    shutdownGracePeriodInSeconds?: number | undefined;
}
export interface CancelJobRunResponse {
    applicationId: string;
    jobRunId: string;
}
export type ApplicationName = string;
export type ReleaseLabel = string;
export type EngineType = string;
export type ClientToken = string;
export type WorkerTypeString = string;
export type WorkerCounts = number;
export type CpuSize = string;
export type MemorySize = string;
export type DiskSize = string;
export type DiskType = string;
export interface WorkerResourceConfig {
    cpu: string;
    memory: string;
    disk?: string | undefined;
    diskType?: string | undefined;
}
export interface InitialCapacityConfig {
    workerCount: number;
    workerConfiguration?: WorkerResourceConfig | undefined;
}
export type InitialCapacityConfigMap = {
    [key: string]: InitialCapacityConfig | undefined;
};
export interface MaximumAllowedResources {
    cpu: string;
    memory: string;
    disk?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface AutoStartConfig {
    enabled?: boolean | undefined;
}
export interface AutoStopConfig {
    enabled?: boolean | undefined;
    idleTimeoutMinutes?: number | undefined;
}
export type SubnetString = string;
export type SubnetIds = string[];
export type SecurityGroupString = string;
export type SecurityGroupIds = string[];
export interface NetworkConfiguration {
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
}
export type Architecture = string;
export type ImageUri = string;
export interface ImageConfigurationInput {
    imageUri?: string | undefined;
    applicationLevelDigestResolution?: boolean | undefined;
}
export interface WorkerTypeSpecificationInput {
    imageConfiguration?: ImageConfigurationInput | undefined;
}
export type WorkerTypeSpecificationInputMap = {
    [key: string]: WorkerTypeSpecificationInput | undefined;
};
export type String1024 = string;
export type ConfigurationPropertyKey = string;
export type ConfigurationPropertyValue = string;
export type SensitivePropertiesMap = {
    [key: string]: string | undefined;
};
export interface Configuration {
    classification: string;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
    configurations?: Configuration[] | undefined;
}
export type ConfigurationList = Configuration[];
export type UriString = string;
export type EncryptionKeyArn = string;
export interface S3MonitoringConfiguration {
    logUri?: string | undefined;
    encryptionKeyArn?: string | undefined;
}
export interface ManagedPersistenceMonitoringConfiguration {
    enabled?: boolean | undefined;
    encryptionKeyArn?: string | undefined;
}
export type LogGroupName = string;
export type LogStreamNamePrefix = string;
export type LogTypeString = string;
export type LogTypeList = string[];
export type LogTypeMap = {
    [key: string]: string[] | undefined;
};
export interface CloudWatchLoggingConfiguration {
    enabled: boolean;
    logGroupName?: string | undefined;
    logStreamNamePrefix?: string | undefined;
    encryptionKeyArn?: string | undefined;
    logTypes?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type PrometheusUrlString = string;
export interface PrometheusMonitoringConfiguration {
    remoteWriteUrl?: string | undefined;
}
export interface MonitoringConfiguration {
    s3MonitoringConfiguration?: S3MonitoringConfiguration | undefined;
    managedPersistenceMonitoringConfiguration?: ManagedPersistenceMonitoringConfiguration | undefined;
    cloudWatchLoggingConfiguration?: CloudWatchLoggingConfiguration | undefined;
    prometheusMonitoringConfiguration?: PrometheusMonitoringConfiguration | undefined;
}
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type EncryptionContext = {
    [key: string]: string | undefined;
};
export interface DiskEncryptionConfiguration {
    encryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    encryptionKeyArn?: string | undefined;
}
export interface InteractiveConfiguration {
    studioEnabled?: boolean | undefined;
    livyEndpointEnabled?: boolean | undefined;
    sessionEnabled?: boolean | undefined;
}
export interface SchedulerConfiguration {
    queueTimeoutMinutes?: number | undefined;
    maxConcurrentRuns?: number | undefined;
}
export type IdentityCenterInstanceArn = string;
export interface IdentityCenterConfigurationInput {
    identityCenterInstanceArn?: string | undefined;
    userBackgroundSessionsEnabled?: boolean | undefined;
}
export interface JobLevelCostAllocationConfiguration {
    enabled?: boolean | undefined;
}
export interface CreateApplicationRequest {
    name?: string | undefined;
    releaseLabel: string;
    type: string;
    clientToken: string;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    } | undefined;
    maximumCapacity?: MaximumAllowedResources | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    autoStartConfiguration?: AutoStartConfig | undefined;
    autoStopConfiguration?: AutoStopConfig | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    architecture?: string | undefined;
    imageConfiguration?: ImageConfigurationInput | undefined;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecificationInput | undefined;
    } | undefined;
    runtimeConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: MonitoringConfiguration | undefined;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration | undefined;
    interactiveConfiguration?: InteractiveConfiguration | undefined;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
    identityCenterConfiguration?: IdentityCenterConfigurationInput | undefined;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration | undefined;
}
export type ApplicationArn = string;
export interface CreateApplicationResponse {
    applicationId: string;
    name?: string | undefined;
    arn: string;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationState = string;
export type String256 = string;
export type ImageDigest = string;
export interface ImageConfiguration {
    imageUri: string;
    resolvedImageDigest?: string | undefined;
    applicationLevelDigestResolution?: boolean | undefined;
}
export interface WorkerTypeSpecification {
    imageConfiguration?: ImageConfiguration | undefined;
}
export type WorkerTypeSpecificationMap = {
    [key: string]: WorkerTypeSpecification | undefined;
};
export type IdentityCenterApplicationArn = string;
export interface IdentityCenterConfiguration {
    identityCenterInstanceArn?: string | undefined;
    identityCenterApplicationArn?: string | undefined;
    userBackgroundSessionsEnabled?: boolean | undefined;
}
export interface Application {
    applicationId: string;
    name?: string | undefined;
    arn: string;
    releaseLabel: string;
    type: string;
    state: string;
    stateDetails?: string | undefined;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    } | undefined;
    maximumCapacity?: MaximumAllowedResources | undefined;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    autoStartConfiguration?: AutoStartConfig | undefined;
    autoStopConfiguration?: AutoStopConfig | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    architecture?: string | undefined;
    imageConfiguration?: ImageConfiguration | undefined;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecification | undefined;
    } | undefined;
    runtimeConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: MonitoringConfiguration | undefined;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration | undefined;
    interactiveConfiguration?: InteractiveConfiguration | undefined;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
    identityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration | undefined;
}
export interface GetApplicationResponse {
    application: Application;
}
export type AttemptNumber = number;
export interface GetDashboardForJobRunRequest {
    applicationId: string;
    jobRunId: string;
    attempt?: number | undefined;
    accessSystemProfileLogs?: boolean | undefined;
}
export type Url = string;
export interface GetDashboardForJobRunResponse {
    url?: string | undefined;
}
export interface GetJobRunRequest {
    applicationId: string;
    jobRunId: string;
    attempt?: number | undefined;
}
export type JobArn = string;
export type RequestIdentityUserArn = string;
export type IAMRoleArn = string;
export type PolicyDocument = string;
export type Arn = string;
export type PolicyArnList = string[];
export interface JobRunExecutionIamPolicy {
    policy?: string | undefined;
    policyArns?: string[] | undefined;
}
export type JobRunState = string;
export interface ConfigurationOverrides {
    applicationConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: MonitoringConfiguration | undefined;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration | undefined;
}
export type EntryPointPath = string | redacted.Redacted<string>;
export type EntryPointArgument = string | redacted.Redacted<string>;
export type EntryPointArguments = (string | redacted.Redacted<string>)[];
export type SparkSubmitParameters = string | redacted.Redacted<string>;
export interface SparkSubmit {
    entryPoint: string | redacted.Redacted<string>;
    entryPointArguments?: (string | redacted.Redacted<string>)[] | undefined;
    sparkSubmitParameters?: string | redacted.Redacted<string> | undefined;
}
export type Query = string | redacted.Redacted<string>;
export type InitScriptPath = string | redacted.Redacted<string>;
export type HiveCliParameters = string | redacted.Redacted<string>;
export interface Hive {
    query: string | redacted.Redacted<string>;
    initQueryFile?: string | redacted.Redacted<string> | undefined;
    parameters?: string | redacted.Redacted<string> | undefined;
}
export type JobDriver = {
    sparkSubmit: SparkSubmit;
    hive?: undefined;
} | {
    sparkSubmit?: undefined;
    hive: Hive;
};
export interface TotalResourceUtilization {
    vCPUHour?: number | undefined;
    memoryGBHour?: number | undefined;
    storageGBHour?: number | undefined;
}
export type Duration = number;
export interface ResourceUtilization {
    vCPUHour?: number | undefined;
    memoryGBHour?: number | undefined;
    storageGBHour?: number | undefined;
}
export type JobRunMode = string;
export interface RetryPolicy {
    maxAttempts?: number | undefined;
    maxFailedAttemptsPerHour?: number | undefined;
}
export interface JobRun {
    applicationId: string;
    jobRunId: string;
    name?: string | undefined;
    arn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    executionIamPolicy?: JobRunExecutionIamPolicy | undefined;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    configurationOverrides?: ConfigurationOverrides | undefined;
    jobDriver: JobDriver;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    totalResourceUtilization?: TotalResourceUtilization | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    totalExecutionDurationSeconds?: number | undefined;
    executionTimeoutMinutes?: number | undefined;
    billedResourceUtilization?: ResourceUtilization | undefined;
    mode?: string | undefined;
    retryPolicy?: RetryPolicy | undefined;
    attempt?: number | undefined;
    attemptCreatedAt?: Date | undefined;
    attemptUpdatedAt?: Date | undefined;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    queuedDurationMilliseconds?: number | undefined;
    imageConfiguration?: ImageConfiguration | undefined;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecification | undefined;
    } | undefined;
}
export interface GetJobRunResponse {
    jobRun: JobRun;
}
export type ResourceId = string;
export type ResourceType = string;
export interface GetResourceDashboardRequest {
    applicationId: string;
    resourceId: string;
    resourceType: string;
    accessSystemProfileLogs?: boolean | undefined;
}
export interface GetResourceDashboardResponse {
    url?: string | undefined;
}
export type SessionId = string;
export interface GetSessionRequest {
    applicationId: string;
    sessionId: string;
}
export type SessionArn = string;
export type SessionState = string;
export interface SessionConfigurationOverrides {
    runtimeConfiguration?: Configuration[] | undefined;
}
export interface Session {
    applicationId: string;
    sessionId: string;
    arn: string;
    name?: string | undefined;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    executionRoleArn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    idleSince?: Date | undefined;
    configurationOverrides?: SessionConfigurationOverrides | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    idleTimeoutMinutes?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    totalResourceUtilization?: TotalResourceUtilization | undefined;
    billedResourceUtilization?: ResourceUtilization | undefined;
    totalExecutionDurationSeconds?: number | undefined;
}
export interface GetSessionResponse {
    session: Session;
}
export interface GetSessionEndpointRequest {
    applicationId: string;
    sessionId: string;
}
export type EndpointUrl = string;
export type SessionAuthToken = string | redacted.Redacted<string>;
export interface GetSessionEndpointResponse {
    applicationId: string;
    sessionId: string;
    endpoint: string;
    authToken: string | redacted.Redacted<string>;
    authTokenExpiresAt: Date;
}
export type NextToken = string;
export type ApplicationStateSet = string[];
export interface ListApplicationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    states?: string[] | undefined;
}
export interface ApplicationSummary {
    id: string;
    name?: string | undefined;
    arn: string;
    releaseLabel: string;
    type: string;
    state: string;
    stateDetails?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    architecture?: string | undefined;
}
export type ApplicationList = ApplicationSummary[];
export interface ListApplicationsResponse {
    applications: ApplicationSummary[];
    nextToken?: string | undefined;
}
export interface ListJobRunAttemptsRequest {
    applicationId: string;
    jobRunId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type JobRunType = string;
export interface JobRunAttemptSummary {
    applicationId: string;
    id: string;
    name?: string | undefined;
    mode?: string | undefined;
    arn: string;
    createdBy: string;
    jobCreatedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    type?: string | undefined;
    attempt?: number | undefined;
}
export type JobRunAttempts = JobRunAttemptSummary[];
export interface ListJobRunAttemptsResponse {
    jobRunAttempts: JobRunAttemptSummary[];
    nextToken?: string | undefined;
}
export type JobRunStateSet = string[];
export interface ListJobRunsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    createdAtAfter?: Date | undefined;
    createdAtBefore?: Date | undefined;
    states?: string[] | undefined;
    mode?: string | undefined;
}
export interface JobRunSummary {
    applicationId: string;
    id: string;
    name?: string | undefined;
    mode?: string | undefined;
    arn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    type?: string | undefined;
    attempt?: number | undefined;
    attemptCreatedAt?: Date | undefined;
    attemptUpdatedAt?: Date | undefined;
}
export type JobRuns = JobRunSummary[];
export interface ListJobRunsResponse {
    jobRuns: JobRunSummary[];
    nextToken?: string | undefined;
}
export type SessionStateSet = string[];
export interface ListSessionsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    states?: string[] | undefined;
    createdAtAfter?: Date | undefined;
    createdAtBefore?: Date | undefined;
}
export interface SessionSummary {
    applicationId: string;
    sessionId: string;
    arn: string;
    name?: string | undefined;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    executionRoleArn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
}
export type Sessions = SessionSummary[];
export interface ListSessionsResponse {
    sessions: SessionSummary[];
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartApplicationRequest {
    applicationId: string;
}
export interface StartApplicationResponse {
}
export interface StartJobRunRequest {
    applicationId: string;
    clientToken: string;
    executionRoleArn: string;
    executionIamPolicy?: JobRunExecutionIamPolicy | undefined;
    jobDriver?: JobDriver | undefined;
    configurationOverrides?: ConfigurationOverrides | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    executionTimeoutMinutes?: number | undefined;
    name?: string | undefined;
    mode?: string | undefined;
    retryPolicy?: RetryPolicy | undefined;
}
export interface StartJobRunResponse {
    applicationId: string;
    jobRunId: string;
    arn: string;
}
export interface StartSessionRequest {
    applicationId: string;
    clientToken: string;
    executionRoleArn: string;
    configurationOverrides?: SessionConfigurationOverrides | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    idleTimeoutMinutes?: number | undefined;
    name?: string | undefined;
}
export interface StartSessionResponse {
    applicationId: string;
    sessionId: string;
    arn: string;
}
export interface StopApplicationRequest {
    applicationId: string;
}
export interface StopApplicationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface TerminateSessionRequest {
    applicationId: string;
    sessionId: string;
}
export interface TerminateSessionResponse {
    applicationId: string;
    sessionId: string;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    applicationId: string;
    clientToken: string;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    } | undefined;
    maximumCapacity?: MaximumAllowedResources | undefined;
    autoStartConfiguration?: AutoStartConfig | undefined;
    autoStopConfiguration?: AutoStopConfig | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    architecture?: string | undefined;
    imageConfiguration?: ImageConfigurationInput | undefined;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecificationInput | undefined;
    } | undefined;
    interactiveConfiguration?: InteractiveConfiguration | undefined;
    releaseLabel?: string | undefined;
    runtimeConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: MonitoringConfiguration | undefined;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration | undefined;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
    identityCenterConfiguration?: IdentityCenterConfigurationInput | undefined;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration | undefined;
}
export interface UpdateApplicationResponse {
    application: Application;
}
export type CancelJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a job run.
 */
export declare const cancelJobRun: API.OperationMethod<CancelJobRunRequest & RegionInput, CancelJobRunResponse, CancelJobRunError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an application. An application has to be in a stopped or created state in order to be deleted.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a specified application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetDashboardForJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates and returns a URL that you can use to access the application UIs for a job run.
 *
 * For jobs in a running state, the application UI is a live user interface such as the Spark or Tez web UI. For completed jobs, the application UI is a persistent application user interface such as the Spark History Server or persistent Tez UI.
 *
 * The URL is valid for one hour after you generate it. To access the application UI after that hour elapses, you must invoke the API again to generate a new URL.
 */
export declare const getDashboardForJobRun: API.OperationMethod<GetDashboardForJobRunRequest & RegionInput, GetDashboardForJobRunResponse, GetDashboardForJobRunError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunRequest & RegionInput, GetJobRunResponse, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetResourceDashboardError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a URL that you can use to access the application UIs for a specified resource, such as a session.
 *
 * For resources in a running state, the application UI is a live user interface such as the Spark web UI. For terminated resources, the application UI is a persistent application user interface such as the Spark History Server.
 *
 * The URL is valid for one hour after you generate it. To access the application UI after that hour elapses, you must invoke the API again to generate a new URL.
 */
export declare const getResourceDashboard: API.OperationMethod<GetResourceDashboardRequest & RegionInput, GetResourceDashboardResponse, GetResourceDashboardError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the session endpoint URL and a time-limited authentication token for the specified session. Use the endpoint and token to connect a client to the session. Call this operation again when the authentication token expires to obtain a new token.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest & RegionInput, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists applications based on a set of parameters.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListJobRunAttemptsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all attempt of a job run.
 */
export declare const listJobRunAttempts: API.PaginatedOperationMethod<ListJobRunAttemptsRequest & RegionInput, ListJobRunAttemptsResponse, ListJobRunAttemptsError, Credentials | HttpClient.HttpClient, JobRunAttemptSummary>;
export type ListJobRunsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists job runs based on a set of parameters.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest & RegionInput, ListJobRunsResponse, ListJobRunsError, Credentials | HttpClient.HttpClient, JobRunSummary>;
export type ListSessionsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists sessions for the specified application. You can filter sessions by state and creation time.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to the resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts a specified application and initializes initial capacity if configured.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest & RegionInput, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartJobRunError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts a job run.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest & RegionInput, StartJobRunResponse, StartJobRunError, Credentials | HttpClient.HttpClient>;
export type StartSessionError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates and starts a new session on the specified application. The application must be in the `STARTED` state or have `AutoStart` enabled, and have interactive sessions enabled. This operation is supported for EMR release 7.13.0 and later.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest & RegionInput, StartSessionResponse, StartSessionError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops a specified application and releases initial capacity if configured. All scheduled and running jobs must be completed or cancelled before stopping an application.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest & RegionInput, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Assigns tags to resources. A tag is a label that you assign to an Amazon Web Services resource. Each tag consists of a key and an optional value, both of which you define. Tags enable you to categorize your Amazon Web Services resources by attributes such as purpose, owner, or environment. When you have many resources of the same type, you can quickly identify a specific resource based on the tags you've assigned to it.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Terminates the specified session. After you terminate a session, it enters the `TERMINATING` state and then the `TERMINATED` state. You can still access the Spark History Server for a terminated session through the `GetResourceDashboard` operation.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionRequest & RegionInput, TerminateSessionResponse, TerminateSessionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a specified application. An application has to be in a stopped or created state in order to be updated.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr-serverless.d.ts.map