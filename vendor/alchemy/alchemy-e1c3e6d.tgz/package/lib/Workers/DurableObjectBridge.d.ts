import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import type * as Tracer from "effect/Tracer";
import type { HttpEffect } from "../Http.ts";
import { RuntimeContext } from "../RuntimeContext.ts";
import { type InstanceTelemetry } from "../TelemetryRuntime.ts";
import type { DurableObjectExport, DurableObjectShape } from "./DurableObject.ts";
import { EventLifetime } from "./EventLifetime.ts";
import { type Pin, type WorkerBuild } from "./Worker.ts";
/**
 * Lifecycle handlers dispatched by the bridge itself — never RPC methods.
 */
export declare const RESERVED_DURABLE_OBJECT_HANDLERS: ReadonlySet<string>;
/** The built instance shape: the lifecycle handlers plus the RPC surface. */
export type DurableObjectInstanceShape = DurableObjectShape & Record<string, unknown>;
/** A built Durable Object instance plus the context its calls run under. */
export interface BuiltDurableObject {
    readonly instance: DurableObjectInstanceShape;
    readonly services: Context.Context<never>;
    readonly context: Context.Context<any>;
    /** The instance's decorated runtime context. */
    readonly runtime: RuntimeContext["Service"];
    readonly telemetry: () => Layer.Layer<never, any, any> | undefined;
    /**
     * The instance's own exporters: fibers its initializer forks record into
     * them, as do fibers an event leaves running once the event has ended.
     * Every event flushes them on its way out.
     */
    readonly instanceTelemetry: InstanceTelemetry;
}
export interface DurableObjectInstanceOptions {
    /** The class export resolved against the shared build. */
    readonly build: (pin: Pin) => Promise<WorkerBuild<DurableObjectExport, any>>;
    /**
     * Engine services available during construction and every call (the
     * engine's Durable Object state service).
     */
    readonly services: Context.Context<never>;
    /**
     * Decorate the instance's runtime context (e.g. its durable callback
     * factory), given the shared build's context.
     */
    readonly runtimeContext?: (runtime: RuntimeContext["Service"], context: Context.Context<any>) => RuntimeContext["Service"];
    /** Open callback registration for inner initialization; return its seal hook. */
    readonly initialize?: () => () => void;
    /** Keep the instance alive until `promise` settles (`state.waitUntil`). */
    readonly waitUntil: Pin;
    /**
     * How RPC methods reach the instance:
     *
     * - `"proxy"` — the engine resolves method names dynamically (workerd's
     *   JSRPC dispatches through the bridge class's `Proxy`); `dispatch`
     *   builds each method on demand.
     * - `"static"` — the RPC surface is materialized as real methods on
     *   `target` once the instance builds (for engines whose RPC stalls on
     *   Proxy-returning constructors), and {@link DurableObjectInstance.fetch}
     *   serves the fetch-RPC protocol over the instance's own `fetch` so
     *   streaming results ride HTTP chunked bodies end-to-end (for engines
     *   whose native RPC cannot transfer `ReadableStream`s).
     */
    readonly dispatch: "proxy" | "static";
    /** `"static"` only: the object the RPC surface is materialized onto. */
    readonly target?: object | undefined;
    /**
     * Runs the instance build. Engines whose object constructor has no I/O
     * context outside a concurrency gate (workerd: `state.blockConcurrencyWhile`)
     * pass that gate here so an init that performs I/O — a D1 `CREATE TABLE`,
     * a migration — runs INSIDE it. Default: run immediately.
     */
    readonly gate?: (run: () => Promise<BuiltDurableObject>) => Promise<BuiltDurableObject>;
}
export interface DurableObjectInstance {
    /**
     * The instance, built once per in-memory activation: the export's
     * two-phase constructor runs with the state service and the captured
     * services provided. Rejects if the build fails (not memoized — see
     * `getWorkerExport`).
     */
    readonly instance: Promise<BuiltDurableObject>;
    /**
     * Run one call against the instance under a fresh `Scope` (provided as
     * `Scope.Scope`), the instance's state service, and the event
     * telemetry. `onExit` turns the exit into the returned value (default:
     * the success value, or the squashed cause thrown); the scope closes into
     * `waitUntil` after the result, once the work the call was told about
     * through its {@link EventLifetime} has settled.
     */
    readonly execute: <T = unknown>(fn: (instance: DurableObjectInstanceShape) => Effect.Effect<any, any, any>, onExit?: (exit: Exit.Exit<any, any>, lifetime: EventLifetime["Service"]) => Promise<T>) => Promise<T>;
    /**
     * An RPC method: run the named member of the shape and encode its exit for
     * the wire, as a child of `parent` (the caller's span) when given.
     */
    readonly dispatch: (method: string, parent?: Tracer.AnySpan) => (...args: readonly unknown[]) => Promise<unknown>;
    /**
     * The HTTP handler served for one request: in `"static"` mode a request
     * on the RPC path is served by `serveRpc` over the instance's RPC
     * surface; everything else is the instance's own `fetch` (404 when it has
     * none).
     */
    readonly fetch: (instance: DurableObjectInstanceShape, request: {
        readonly url: string;
    }) => HttpEffect<any>;
}
export declare const makeDurableObjectInstance: ({ build, services: engineServices, waitUntil, dispatch: mode, target, gate, runtimeContext, initialize, }: DurableObjectInstanceOptions) => DurableObjectInstance;
//# sourceMappingURL=DurableObjectBridge.d.ts.map