import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type WorkloadId = string;
export type LensAlias = string;
export type LensAliases = string[];
export interface AssociateLensesInput {
    WorkloadId: string;
    LensAliases?: string[] | undefined;
}
export interface AssociateLensesResponse {
}
export type ProfileArn = string;
export type ProfileArns = string[];
export interface AssociateProfilesInput {
    WorkloadId: string;
    ProfileArns?: string[] | undefined;
}
export interface AssociateProfilesResponse {
}
export type AgentProfileArn = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type ContextType = "APPLICATION" | (string & {});
export type ContextAccountIdList = string[];
export type ContextRegionList = string[];
export type ContextAwsServiceList = string[];
export type ContextResourceTypeList = string[];
export interface ContextResourceTag {
    key: string;
    value: string;
}
export type ContextResourceTagList = ContextResourceTag[];
export type ApplicationType = "SAS" | "DESKTOP_APPLICATION" | "OTHER" | (string & {});
export type Criticality = "MISSION_CRITICAL" | "BUSINESS_CRITICAL" | "NON_CRITICAL" | "TEST_DEVELOPMENT" | (string & {});
export interface ContextContent {
    accountIds?: string[] | undefined;
    regions?: string[] | undefined;
    awsServices?: string[] | undefined;
    resourceTypes?: string[] | undefined;
    resourceTags?: ContextResourceTag[] | undefined;
    applicationOverview?: string | redacted.Redacted<string> | undefined;
    industry?: string | redacted.Redacted<string> | undefined;
    applicationType?: ApplicationType | undefined;
    criticality?: Criticality | undefined;
    architectureOverview?: string | redacted.Redacted<string> | undefined;
    additionalContext?: string | redacted.Redacted<string> | undefined;
}
export interface CreateAgentContextRequest {
    clientToken?: string | undefined;
    profileArn: string;
    title: string | redacted.Redacted<string>;
    contextType: ContextType;
    content: ContextContent;
}
export type UUID = string;
export interface ContextSummary {
    id: string;
    profileArn: string;
    title: string | redacted.Redacted<string>;
    contextType: ContextType;
    content: ContextContent;
    applicationType?: ApplicationType | undefined;
    criticality?: Criticality | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export interface CreateAgentContextResponse {
    context: ContextSummary;
}
export type Pillar = "COST_OPTIMIZATION" | "SECURITY" | "RESILIENCE" | "PERFORMANCE" | "OPERATIONAL_EXCELLENCE" | (string & {});
export type Pillars = Pillar[];
export interface CreateAgentGoalRequest {
    clientToken?: string | undefined;
    profileArn: string;
    pillars: Pillar[];
    title: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface GoalSummary {
    id: string;
    profileArn: string;
    pillars: Pillar[];
    title: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export interface CreateAgentGoalResponse {
    goal: GoalSummary;
}
export type RoleArn = string;
export type AccountId = string;
export type Region = string;
export type Regions = string[];
export interface AggregationConfiguration {
    accountId: string;
    regions: string[];
    accessRoleArn: string;
}
export type AggregationConfigurations = AggregationConfiguration[];
export interface Tag {
    key: string;
    value: string;
}
export type Tags = Tag[];
export interface CreateAgentProfileRequest {
    name: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars: Pillar[];
    deletionProtection?: boolean | undefined;
    executionRoleArn: string;
    aggregationConfiguration: AggregationConfiguration[];
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export type FieldErrorPath = string;
export type FieldErrorMessage = string;
export type FieldErrors = {
    [key: string]: string | undefined;
};
export interface CreateAgentProfileResponse {
    name: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars: Pillar[];
    deletionProtection?: boolean | undefined;
    executionRoleArn: string;
    aggregationConfiguration: AggregationConfiguration[];
    arn: string;
    eligibleForScheduledGeneration?: boolean | undefined;
    eligibleForArchitectureGeneration?: boolean | undefined;
    fieldErrors?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: Tag[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type SharedWith = string;
export type ClientRequestToken = string;
export interface CreateLensShareInput {
    LensAlias: string;
    SharedWith?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export type ShareId = string;
export interface CreateLensShareOutput {
    ShareId?: string | undefined;
}
export type LensVersion = string;
export type IsMajorVersion = boolean;
export interface CreateLensVersionInput {
    LensAlias: string;
    LensVersion?: string | undefined;
    IsMajorVersion?: boolean | undefined;
    ClientRequestToken?: string | undefined;
}
export type LensArn = string;
export interface CreateLensVersionOutput {
    LensArn?: string | undefined;
    LensVersion?: string | undefined;
}
export type MilestoneName = string;
export interface CreateMilestoneInput {
    WorkloadId: string;
    MilestoneName?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export type MilestoneNumber = number;
export interface CreateMilestoneOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
}
export type ProfileName = string;
export type ProfileDescription = string;
export type QuestionId = string;
export type ChoiceId = string;
export type SelectedProfileChoiceIds = string[];
export interface ProfileQuestionUpdate {
    QuestionId?: string | undefined;
    SelectedChoiceIds?: string[] | undefined;
}
export type ProfileQuestionUpdates = ProfileQuestionUpdate[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateProfileInput {
    ProfileName?: string | undefined;
    ProfileDescription?: string | undefined;
    ProfileQuestions?: ProfileQuestionUpdate[] | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProfileVersion = string;
export interface CreateProfileOutput {
    ProfileArn?: string | undefined;
    ProfileVersion?: string | undefined;
}
export interface CreateProfileShareInput {
    ProfileArn: string;
    SharedWith?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface CreateProfileShareOutput {
    ShareId?: string | undefined;
    ProfileArn?: string | undefined;
}
export type TemplateName = string;
export type TemplateDescription = string;
export type ReviewTemplateLenses = string[];
export type Notes = string;
export interface CreateReviewTemplateInput {
    TemplateName?: string | undefined;
    Description?: string | undefined;
    Lenses?: string[] | undefined;
    Notes?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientRequestToken?: string | undefined;
}
export type TemplateArn = string;
export interface CreateReviewTemplateOutput {
    TemplateArn?: string | undefined;
}
export interface CreateTemplateShareInput {
    TemplateArn: string;
    SharedWith?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface CreateTemplateShareOutput {
    TemplateArn?: string | undefined;
    ShareId?: string | undefined;
}
export type WorkloadName = string;
export type WorkloadDescription = string;
export type WorkloadEnvironment = "PRODUCTION" | "PREPRODUCTION" | (string & {});
export type AwsAccountId = string;
export type WorkloadAccountIds = string[];
export type AwsRegion = string;
export type WorkloadAwsRegions = string[];
export type WorkloadNonAwsRegion = string;
export type WorkloadNonAwsRegions = string[];
export type PillarId = string;
export type WorkloadPillarPriorities = string[];
export type WorkloadArchitecturalDesign = string;
export type WorkloadReviewOwner = string;
export type WorkloadIndustryType = string;
export type WorkloadIndustry = string;
export type WorkloadLenses = string[];
export type TrustedAdvisorIntegrationStatus = "ENABLED" | "DISABLED" | (string & {});
export type DefinitionType = "WORKLOAD_METADATA" | "APP_REGISTRY" | (string & {});
export type WorkloadResourceDefinition = DefinitionType[];
export interface WorkloadDiscoveryConfig {
    TrustedAdvisorIntegrationStatus?: TrustedAdvisorIntegrationStatus | undefined;
    WorkloadResourceDefinition?: DefinitionType[] | undefined;
}
export type ApplicationArn = string;
export type WorkloadApplications = string[];
export type WorkloadProfileArns = string[];
export type ReviewTemplateArns = string[];
export type WorkloadIssueManagementStatus = "ENABLED" | "DISABLED" | "INHERIT" | (string & {});
export type IssueManagementType = "AUTO" | "MANUAL" | (string & {});
export type JiraProjectKey = string;
export interface WorkloadJiraConfigurationInput {
    IssueManagementStatus?: WorkloadIssueManagementStatus | undefined;
    IssueManagementType?: IssueManagementType | undefined;
    JiraProjectKey?: string | undefined;
}
export interface CreateWorkloadInput {
    WorkloadName?: string | undefined;
    Description?: string | undefined;
    Environment?: WorkloadEnvironment | undefined;
    AccountIds?: string[] | undefined;
    AwsRegions?: string[] | undefined;
    NonAwsRegions?: string[] | undefined;
    PillarPriorities?: string[] | undefined;
    ArchitecturalDesign?: string | undefined;
    ReviewOwner?: string | undefined;
    IndustryType?: string | undefined;
    Industry?: string | undefined;
    Lenses?: string[] | undefined;
    Notes?: string | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    DiscoveryConfig?: WorkloadDiscoveryConfig | undefined;
    Applications?: string[] | undefined;
    ProfileArns?: string[] | undefined;
    ReviewTemplateArns?: string[] | undefined;
    JiraConfiguration?: WorkloadJiraConfigurationInput | undefined;
}
export type WorkloadArn = string;
export interface CreateWorkloadOutput {
    WorkloadId?: string | undefined;
    WorkloadArn?: string | undefined;
}
export type PermissionType = "READONLY" | "CONTRIBUTOR" | (string & {});
export interface CreateWorkloadShareInput {
    WorkloadId: string;
    SharedWith?: string | undefined;
    PermissionType?: PermissionType | undefined;
    ClientRequestToken?: string | undefined;
}
export interface CreateWorkloadShareOutput {
    WorkloadId?: string | undefined;
    ShareId?: string | undefined;
}
export interface DeleteAgentContextRequest {
    profileArn: string;
    id: string;
}
export interface DeleteAgentContextResponse {
}
export interface DeleteAgentGoalRequest {
    profileArn: string;
    id: string;
}
export interface DeleteAgentGoalResponse {
}
export interface DeleteAgentProfileRequest {
    profileArn: string;
}
export interface DeleteAgentProfileResponse {
}
export type LensStatusType = "ALL" | "DRAFT" | "PUBLISHED" | (string & {});
export interface DeleteLensInput {
    LensAlias: string;
    ClientRequestToken?: string | undefined;
    LensStatus?: LensStatusType | undefined;
}
export interface DeleteLensResponse {
}
export interface DeleteLensShareInput {
    ShareId: string;
    LensAlias: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteLensShareResponse {
}
export interface DeleteProfileInput {
    ProfileArn: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteProfileResponse {
}
export interface DeleteProfileShareInput {
    ShareId: string;
    ProfileArn: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteProfileShareResponse {
}
export interface DeleteReviewTemplateInput {
    TemplateArn: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteReviewTemplateResponse {
}
export interface DeleteTemplateShareInput {
    ShareId: string;
    TemplateArn: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteTemplateShareResponse {
}
export interface DeleteWorkloadInput {
    WorkloadId: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteWorkloadResponse {
}
export interface DeleteWorkloadShareInput {
    ShareId: string;
    WorkloadId: string;
    ClientRequestToken?: string | undefined;
}
export interface DeleteWorkloadShareResponse {
}
export interface DisassociateLensesInput {
    WorkloadId: string;
    LensAliases?: string[] | undefined;
}
export interface DisassociateLensesResponse {
}
export interface DisassociateProfilesInput {
    WorkloadId: string;
    ProfileArns?: string[] | undefined;
}
export interface DisassociateProfilesResponse {
}
export interface ExportLensInput {
    LensAlias: string;
    LensVersion?: string | undefined;
}
export type LensJSON = string;
export interface ExportLensOutput {
    LensJSON?: string | undefined;
}
export interface GetAgentContextRequest {
    profileArn: string;
    id: string;
}
export interface GetAgentContextResponse {
    context: ContextSummary;
}
export interface GetAgentGoalRequest {
    profileArn: string;
    id: string;
}
export interface GetAgentGoalResponse {
    goal: GoalSummary;
}
export interface GetAgentProfileRequest {
    profileArn: string;
}
export interface GetAgentProfileResponse {
    name: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars: Pillar[];
    deletionProtection?: boolean | undefined;
    executionRoleArn: string;
    aggregationConfiguration: AggregationConfiguration[];
    arn: string;
    eligibleForScheduledGeneration?: boolean | undefined;
    eligibleForArchitectureGeneration?: boolean | undefined;
    fieldErrors?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: Tag[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentRecommendationArn = string;
export type RemediationType = "AUTO_REMEDIATION" | "CONSOLE" | "CLI" | "SDK" | "IAC" | "MCP" | (string & {});
export interface GetAgentRecommendationRequest {
    recommendationArn: string;
    remediationType?: RemediationType | undefined;
}
export type RecommendationArn = string;
export type RecommendationType = "RESOURCE" | "ARCHITECTURE" | "APPLICATION" | (string & {});
export type Priority = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type Effort = "LARGE" | "MEDIUM" | "SMALL" | (string & {});
export type RecommendationStatus = "ACTIVE" | "SUPPRESSED" | "COMPLETED" | (string & {});
export type RecommendationState = "OPEN" | "CLOSED" | (string & {});
export type ImpactCategory = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export interface Roi {
    estimate?: string | undefined;
    detail: string;
}
export type StringList = string[];
export type ImpactDetail = string;
export type ImpactDetails = string[];
export interface Insight {
    usagePattern: string;
    signalsDetected?: string | undefined;
}
export type InsightList = Insight[];
export type Highlight = string;
export type Highlights = string[];
export type RecommendedFixStep = string;
export type RecommendedFixSteps = string[];
export interface RemediationSummary {
    recommendation: string;
    steps: string[];
}
export interface CrossPillarBenefit {
    pillar: Pillar;
    title: string;
    description: string;
    impact: ImpactCategory;
}
export type CrossPillarBenefits = CrossPillarBenefit[];
export type RiskRating = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface TradeOff {
    pillar: Pillar;
    title: string;
    description: string;
    risk: RiskRating;
    mitigation: string;
    riskExplanation?: string | undefined;
}
export type TradeOffs = TradeOff[];
export type RecommendationSource = "TRUSTED_ADVISOR" | "COST_EXPLORER" | "CLOUDWATCH" | "WELL_ARCHITECTED_TOOL" | "WELL_ARCHITECTED_AGENT" | "CUSTOMER_IAC" | (string & {});
export type RecommendationSourceList = RecommendationSource[];
export interface RecommendationGoal {
    title: string;
}
export type RecommendationGoals = RecommendationGoal[];
export interface RemediationStep {
    title?: string | redacted.Redacted<string> | undefined;
    content: string | redacted.Redacted<string>;
}
export type RemediationSteps = RemediationStep[];
export interface ResourceLink {
    url: string;
    title?: string | undefined;
}
export type ResourceLinks = ResourceLink[];
export interface AgentRecommendationRemediation {
    recommendationArn: string;
    type: RemediationType;
    steps: RemediationStep[];
    resourceLinks?: ResourceLink[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentRecommendationRemediations = AgentRecommendationRemediation[];
export interface GetAgentRecommendationResponse {
    recommendationArn: string;
    profileArn: string;
    generationId?: string | undefined;
    title: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    type: RecommendationType;
    pillar: Pillar;
    priority: Priority;
    effort: Effort;
    status: RecommendationStatus;
    state: RecommendationState;
    updateReason?: string | redacted.Redacted<string> | undefined;
    impact: ImpactCategory;
    roi: Roi;
    numberOfResources?: number | undefined;
    awsServices?: string[] | undefined;
    businessUnits?: string[] | undefined;
    applications?: string[] | undefined;
    impactDetails: string[];
    insights: Insight[];
    highlights: string[];
    remediationSummary: RemediationSummary;
    crossPillarBenefits?: CrossPillarBenefit[] | undefined;
    tradeOffs?: TradeOff[] | undefined;
    sources?: RecommendationSource[] | undefined;
    goals?: RecommendationGoal[] | undefined;
    tags?: Tag[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
    remediations?: AgentRecommendationRemediation[] | undefined;
}
export interface GetAgentRecommendationGenerationRequest {
    profileArn: string;
    generationId: string;
}
export type GenerationStatus = "QUEUED" | "IN_PROGRESS" | "COMPLETED" | "ERROR" | (string & {});
export type GoalIdList = string[];
export type ItemId = string;
export type ItemIds = string[];
export interface PillarItem {
    pillar: Pillar;
    ids: string[];
}
export type PillarItems = PillarItem[];
export interface Scope {
    pillars: Pillar[];
    goalIds?: string[] | undefined;
    items?: PillarItem[] | undefined;
}
export interface Progress {
    stepsCompleted: number;
    totalSteps: number;
    completionPercentage: number;
}
export interface ErrorDetails {
    code: string;
    message: string;
}
export interface GetAgentRecommendationGenerationResponse {
    id: string;
    profileArn: string;
    name?: string | undefined;
    status: GenerationStatus;
    estimatedCompletionTime?: Date | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
    additionalContext?: any | undefined;
    scope?: Scope | undefined;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    progress?: Progress | undefined;
    errorDetails?: ErrorDetails | undefined;
}
export interface GetAnswerInput {
    WorkloadId: string;
    LensAlias: string;
    QuestionId: string;
    MilestoneNumber?: number | undefined;
}
export type QuestionTitle = string;
export type QuestionDescription = string;
export type ImprovementPlanUrl = string;
export type HelpfulResourceUrl = string;
export type DisplayText = string;
export type ChoiceTitle = string;
export type ChoiceDescription = string;
export type ChoiceContentDisplayText = string;
export type ChoiceContentUrl = string;
export interface ChoiceContent {
    DisplayText?: string | undefined;
    Url?: string | undefined;
}
export type AdditionalResourceType = "HELPFUL_RESOURCE" | "IMPROVEMENT_PLAN" | (string & {});
export type Urls = ChoiceContent[];
export interface AdditionalResources {
    Type?: AdditionalResourceType | undefined;
    Content?: ChoiceContent[] | undefined;
}
export type AdditionalResourcesList = AdditionalResources[];
export interface Choice {
    ChoiceId?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    HelpfulResource?: ChoiceContent | undefined;
    ImprovementPlan?: ChoiceContent | undefined;
    AdditionalResources?: AdditionalResources[] | undefined;
}
export type Choices = Choice[];
export type SelectedChoices = string[];
export type ChoiceStatus = "SELECTED" | "NOT_APPLICABLE" | "UNSELECTED" | (string & {});
export type ChoiceReason = "OUT_OF_SCOPE" | "BUSINESS_PRIORITIES" | "ARCHITECTURE_CONSTRAINTS" | "OTHER" | "NONE" | (string & {});
export type ChoiceNotes = string;
export interface ChoiceAnswer {
    ChoiceId?: string | undefined;
    Status?: ChoiceStatus | undefined;
    Reason?: ChoiceReason | undefined;
    Notes?: string | undefined;
}
export type ChoiceAnswers = ChoiceAnswer[];
export type IsApplicable = boolean;
export type Risk = "UNANSWERED" | "HIGH" | "MEDIUM" | "NONE" | "NOT_APPLICABLE" | (string & {});
export type AnswerReason = "OUT_OF_SCOPE" | "BUSINESS_PRIORITIES" | "ARCHITECTURE_CONSTRAINTS" | "OTHER" | "NONE" | (string & {});
export type JiraIssueUrl = string;
export interface JiraConfiguration {
    JiraIssueUrl?: string | undefined;
    LastSyncedTime?: Date | undefined;
}
export interface Answer {
    QuestionId?: string | undefined;
    PillarId?: string | undefined;
    QuestionTitle?: string | undefined;
    QuestionDescription?: string | undefined;
    ImprovementPlanUrl?: string | undefined;
    HelpfulResourceUrl?: string | undefined;
    HelpfulResourceDisplayText?: string | undefined;
    Choices?: Choice[] | undefined;
    SelectedChoices?: string[] | undefined;
    ChoiceAnswers?: ChoiceAnswer[] | undefined;
    IsApplicable?: boolean | undefined;
    Risk?: Risk | undefined;
    Notes?: string | undefined;
    Reason?: AnswerReason | undefined;
    JiraConfiguration?: JiraConfiguration | undefined;
}
export interface GetAnswerOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    Answer?: Answer | undefined;
}
export type ReportFormat = "PDF" | "JSON" | (string & {});
export type IncludeSharedResources = boolean;
export type NextToken = string;
export type MaxResults = number;
export interface GetConsolidatedReportInput {
    Format?: ReportFormat | undefined;
    IncludeSharedResources?: boolean | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type MetricType = "WORKLOAD" | (string & {});
export type Count = number;
export type RiskCounts = {
    [key in Risk]?: number | undefined;
};
export interface BestPractice {
    ChoiceId?: string | undefined;
    ChoiceTitle?: string | undefined;
}
export type BestPractices = BestPractice[];
export interface QuestionMetric {
    QuestionId?: string | undefined;
    Risk?: Risk | undefined;
    BestPractices?: BestPractice[] | undefined;
}
export type QuestionMetrics = QuestionMetric[];
export interface PillarMetric {
    PillarId?: string | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    Questions?: QuestionMetric[] | undefined;
}
export type PillarMetrics = PillarMetric[];
export interface LensMetric {
    LensArn?: string | undefined;
    Pillars?: PillarMetric[] | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type LensMetrics = LensMetric[];
export type LensesAppliedCount = number;
export interface ConsolidatedReportMetric {
    MetricType?: MetricType | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    WorkloadId?: string | undefined;
    WorkloadName?: string | undefined;
    WorkloadArn?: string | undefined;
    UpdatedAt?: Date | undefined;
    Lenses?: LensMetric[] | undefined;
    LensesAppliedCount?: number | undefined;
}
export type ConsolidatedReportMetrics = ConsolidatedReportMetric[];
export type Base64String = string;
export interface GetConsolidatedReportOutput {
    Metrics?: ConsolidatedReportMetric[] | undefined;
    NextToken?: string | undefined;
    Base64String?: string | undefined;
}
export interface GetGlobalSettingsRequest {
}
export type OrganizationSharingStatus = "ENABLED" | "DISABLED" | (string & {});
export type DiscoveryIntegrationStatus = "ENABLED" | "DISABLED" | (string & {});
export type IntegrationStatus = "CONFIGURED" | "NOT_CONFIGURED" | (string & {});
export type AccountJiraIssueManagementStatus = "ENABLED" | "DISABLED" | (string & {});
export type Subdomain = string;
export type StatusMessage = string;
export interface AccountJiraConfigurationOutput {
    IntegrationStatus?: IntegrationStatus | undefined;
    IssueManagementStatus?: AccountJiraIssueManagementStatus | undefined;
    IssueManagementType?: IssueManagementType | undefined;
    Subdomain?: string | undefined;
    JiraProjectKey?: string | undefined;
    StatusMessage?: string | undefined;
}
export interface GetGlobalSettingsOutput {
    OrganizationSharingStatus?: OrganizationSharingStatus | undefined;
    DiscoveryIntegrationStatus?: DiscoveryIntegrationStatus | undefined;
    JiraConfiguration?: AccountJiraConfigurationOutput | undefined;
}
export interface GetLensInput {
    LensAlias: string;
    LensVersion?: string | undefined;
}
export type LensName = string;
export type LensDescription = string;
export type LensOwner = string;
export type ShareInvitationId = string;
export interface Lens {
    LensArn?: string | undefined;
    LensVersion?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Owner?: string | undefined;
    ShareInvitationId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetLensOutput {
    Lens?: Lens | undefined;
}
export interface GetLensReviewInput {
    WorkloadId: string;
    LensAlias: string;
    MilestoneNumber?: number | undefined;
}
export type LensStatus = "CURRENT" | "NOT_CURRENT" | "DEPRECATED" | "DELETED" | "UNSHARED" | (string & {});
export type PillarName = string;
export interface PillarReviewSummary {
    PillarId?: string | undefined;
    PillarName?: string | undefined;
    Notes?: string | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    PrioritizedRiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type PillarReviewSummaries = PillarReviewSummary[];
export type SelectedQuestionId = string;
export type SelectedQuestionIds = string[];
export interface SelectedPillar {
    PillarId?: string | undefined;
    SelectedQuestionIds?: string[] | undefined;
}
export type SelectedPillars = SelectedPillar[];
export interface JiraSelectedQuestionConfiguration {
    SelectedPillars?: SelectedPillar[] | undefined;
}
export interface WorkloadProfile {
    ProfileArn?: string | undefined;
    ProfileVersion?: string | undefined;
}
export type WorkloadProfiles = WorkloadProfile[];
export interface LensReview {
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    LensVersion?: string | undefined;
    LensName?: string | undefined;
    LensStatus?: LensStatus | undefined;
    PillarReviewSummaries?: PillarReviewSummary[] | undefined;
    JiraConfiguration?: JiraSelectedQuestionConfiguration | undefined;
    UpdatedAt?: Date | undefined;
    Notes?: string | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    NextToken?: string | undefined;
    Profiles?: WorkloadProfile[] | undefined;
    PrioritizedRiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface GetLensReviewOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensReview?: LensReview | undefined;
}
export interface GetLensReviewReportInput {
    WorkloadId: string;
    LensAlias: string;
    MilestoneNumber?: number | undefined;
}
export interface LensReviewReport {
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    Base64String?: string | undefined;
}
export interface GetLensReviewReportOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensReviewReport?: LensReviewReport | undefined;
}
export interface GetLensVersionDifferenceInput {
    LensAlias: string;
    BaseLensVersion?: string | undefined;
    TargetLensVersion?: string | undefined;
}
export type DifferenceStatus = "UPDATED" | "NEW" | "DELETED" | (string & {});
export interface QuestionDifference {
    QuestionId?: string | undefined;
    QuestionTitle?: string | undefined;
    DifferenceStatus?: DifferenceStatus | undefined;
}
export type QuestionDifferences = QuestionDifference[];
export interface PillarDifference {
    PillarId?: string | undefined;
    PillarName?: string | undefined;
    DifferenceStatus?: DifferenceStatus | undefined;
    QuestionDifferences?: QuestionDifference[] | undefined;
}
export type PillarDifferences = PillarDifference[];
export interface VersionDifferences {
    PillarDifferences?: PillarDifference[] | undefined;
}
export interface GetLensVersionDifferenceOutput {
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    BaseLensVersion?: string | undefined;
    TargetLensVersion?: string | undefined;
    LatestLensVersion?: string | undefined;
    VersionDifferences?: VersionDifferences | undefined;
}
export interface GetMilestoneInput {
    WorkloadId: string;
    MilestoneNumber: number;
}
export type IsReviewOwnerUpdateAcknowledged = boolean;
export type WorkloadImprovementStatus = "NOT_APPLICABLE" | "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "RISK_ACKNOWLEDGED" | (string & {});
export interface WorkloadJiraConfigurationOutput {
    IssueManagementStatus?: WorkloadIssueManagementStatus | undefined;
    IssueManagementType?: IssueManagementType | undefined;
    JiraProjectKey?: string | undefined;
    StatusMessage?: string | undefined;
}
export interface Workload {
    WorkloadId?: string | undefined;
    WorkloadArn?: string | undefined;
    WorkloadName?: string | undefined;
    Description?: string | undefined;
    Environment?: WorkloadEnvironment | undefined;
    UpdatedAt?: Date | undefined;
    AccountIds?: string[] | undefined;
    AwsRegions?: string[] | undefined;
    NonAwsRegions?: string[] | undefined;
    ArchitecturalDesign?: string | undefined;
    ReviewOwner?: string | undefined;
    ReviewRestrictionDate?: Date | undefined;
    IsReviewOwnerUpdateAcknowledged?: boolean | undefined;
    IndustryType?: string | undefined;
    Industry?: string | undefined;
    Notes?: string | undefined;
    ImprovementStatus?: WorkloadImprovementStatus | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    PillarPriorities?: string[] | undefined;
    Lenses?: string[] | undefined;
    Owner?: string | undefined;
    ShareInvitationId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    DiscoveryConfig?: WorkloadDiscoveryConfig | undefined;
    Applications?: string[] | undefined;
    Profiles?: WorkloadProfile[] | undefined;
    PrioritizedRiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    JiraConfiguration?: WorkloadJiraConfigurationOutput | undefined;
}
export interface Milestone {
    MilestoneNumber?: number | undefined;
    MilestoneName?: string | undefined;
    RecordedAt?: Date | undefined;
    Workload?: Workload | undefined;
}
export interface GetMilestoneOutput {
    WorkloadId?: string | undefined;
    Milestone?: Milestone | undefined;
}
export interface GetProfileInput {
    ProfileArn: string;
    ProfileVersion?: string | undefined;
}
export interface ProfileChoice {
    ChoiceId?: string | undefined;
    ChoiceTitle?: string | undefined;
    ChoiceDescription?: string | undefined;
}
export type ProfileQuestionChoices = ProfileChoice[];
export type SelectedChoiceIds = string[];
export type MinSelectedProfileChoices = number;
export type MaxSelectedProfileChoices = number;
export interface ProfileQuestion {
    QuestionId?: string | undefined;
    QuestionTitle?: string | undefined;
    QuestionDescription?: string | undefined;
    QuestionChoices?: ProfileChoice[] | undefined;
    SelectedChoiceIds?: string[] | undefined;
    MinSelectedChoices?: number | undefined;
    MaxSelectedChoices?: number | undefined;
}
export type ProfileQuestions = ProfileQuestion[];
export interface Profile {
    ProfileArn?: string | undefined;
    ProfileVersion?: string | undefined;
    ProfileName?: string | undefined;
    ProfileDescription?: string | undefined;
    ProfileQuestions?: ProfileQuestion[] | undefined;
    Owner?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ShareInvitationId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetProfileOutput {
    Profile?: Profile | undefined;
}
export interface GetProfileTemplateInput {
}
export interface ProfileTemplateChoice {
    ChoiceId?: string | undefined;
    ChoiceTitle?: string | undefined;
    ChoiceDescription?: string | undefined;
}
export type ProfileTemplateQuestionChoices = ProfileTemplateChoice[];
export interface ProfileTemplateQuestion {
    QuestionId?: string | undefined;
    QuestionTitle?: string | undefined;
    QuestionDescription?: string | undefined;
    QuestionChoices?: ProfileTemplateChoice[] | undefined;
    MinSelectedChoices?: number | undefined;
    MaxSelectedChoices?: number | undefined;
}
export type TemplateQuestions = ProfileTemplateQuestion[];
export interface ProfileTemplate {
    TemplateName?: string | undefined;
    TemplateQuestions?: ProfileTemplateQuestion[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetProfileTemplateOutput {
    ProfileTemplate?: ProfileTemplate | undefined;
}
export interface GetReviewTemplateInput {
    TemplateArn: string;
}
export type Question = "UNANSWERED" | "ANSWERED" | (string & {});
export type QuestionCounts = {
    [key in Question]?: number | undefined;
};
export type ReviewTemplateUpdateStatus = "CURRENT" | "LENS_NOT_CURRENT" | (string & {});
export interface ReviewTemplate {
    Description?: string | undefined;
    Lenses?: string[] | undefined;
    Notes?: string | undefined;
    QuestionCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    Owner?: string | undefined;
    UpdatedAt?: Date | undefined;
    TemplateArn?: string | undefined;
    TemplateName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdateStatus?: ReviewTemplateUpdateStatus | undefined;
    ShareInvitationId?: string | undefined;
}
export interface GetReviewTemplateOutput {
    ReviewTemplate?: ReviewTemplate | undefined;
}
export interface GetReviewTemplateAnswerInput {
    TemplateArn: string;
    LensAlias: string;
    QuestionId: string;
}
export type ReviewTemplateAnswerStatus = "UNANSWERED" | "ANSWERED" | (string & {});
export interface ReviewTemplateAnswer {
    QuestionId?: string | undefined;
    PillarId?: string | undefined;
    QuestionTitle?: string | undefined;
    QuestionDescription?: string | undefined;
    ImprovementPlanUrl?: string | undefined;
    HelpfulResourceUrl?: string | undefined;
    HelpfulResourceDisplayText?: string | undefined;
    Choices?: Choice[] | undefined;
    SelectedChoices?: string[] | undefined;
    ChoiceAnswers?: ChoiceAnswer[] | undefined;
    IsApplicable?: boolean | undefined;
    AnswerStatus?: ReviewTemplateAnswerStatus | undefined;
    Notes?: string | undefined;
    Reason?: AnswerReason | undefined;
}
export interface GetReviewTemplateAnswerOutput {
    TemplateArn?: string | undefined;
    LensAlias?: string | undefined;
    Answer?: ReviewTemplateAnswer | undefined;
}
export interface GetReviewTemplateLensReviewInput {
    TemplateArn: string;
    LensAlias: string;
}
export interface ReviewTemplatePillarReviewSummary {
    PillarId?: string | undefined;
    PillarName?: string | undefined;
    Notes?: string | undefined;
    QuestionCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type ReviewTemplatePillarReviewSummaries = ReviewTemplatePillarReviewSummary[];
export interface ReviewTemplateLensReview {
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    LensVersion?: string | undefined;
    LensName?: string | undefined;
    LensStatus?: LensStatus | undefined;
    PillarReviewSummaries?: ReviewTemplatePillarReviewSummary[] | undefined;
    UpdatedAt?: Date | undefined;
    Notes?: string | undefined;
    QuestionCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    NextToken?: string | undefined;
}
export interface GetReviewTemplateLensReviewOutput {
    TemplateArn?: string | undefined;
    LensReview?: ReviewTemplateLensReview | undefined;
}
export interface GetWorkloadInput {
    WorkloadId: string;
}
export interface GetWorkloadOutput {
    Workload?: Workload | undefined;
}
export interface ImportLensInput {
    LensAlias?: string | undefined;
    JSONString?: string | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ImportLensStatus = "IN_PROGRESS" | "COMPLETE" | "ERROR" | (string & {});
export interface ImportLensOutput {
    LensArn?: string | undefined;
    Status?: ImportLensStatus | undefined;
}
export interface ListAgentContextsRequest {
    profileArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ContextSummaries = ContextSummary[];
export interface ListAgentContextsResponse {
    items: ContextSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentGoalsRequest {
    profileArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type GoalSummaries = GoalSummary[];
export interface ListAgentGoalsResponse {
    items: GoalSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentProfilesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentProfileSummary {
    name: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars: Pillar[];
    deletionProtection?: boolean | undefined;
    executionRoleArn: string;
    aggregationConfiguration: AggregationConfiguration[];
    arn: string;
    eligibleForScheduledGeneration?: boolean | undefined;
    eligibleForArchitectureGeneration?: boolean | undefined;
    fieldErrors?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: Tag[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentProfileSummaries = AgentProfileSummary[];
export interface ListAgentProfilesResponse {
    items: AgentProfileSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentRecommendationGenerationsRequest {
    profileArn: string;
    recommendationType?: RecommendationType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentRecommendationGenerationSummary {
    id: string;
    profileArn: string;
    name?: string | undefined;
    status: GenerationStatus;
    estimatedCompletionTime?: Date | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentRecommendationGenerationSummaries = AgentRecommendationGenerationSummary[];
export interface ListAgentRecommendationGenerationsResponse {
    items: AgentRecommendationGenerationSummary[];
    nextToken?: string | undefined;
}
export type RecommendationItemType = "AWS_RESOURCE" | "RECOMMENDATION" | (string & {});
export interface ListAgentRecommendationItemsRequest {
    recommendationArn: string;
    type?: RecommendationItemType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentRecommendationItemSummary {
    id: string;
    recommendationArn: string;
    type: RecommendationItemType;
    metadata: any;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentRecommendationItemSummaries = AgentRecommendationItemSummary[];
export interface ListAgentRecommendationItemsResponse {
    items: AgentRecommendationItemSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentRecommendationsRequest {
    profileArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    state?: RecommendationState | undefined;
    pillar?: Pillar | undefined;
}
export interface AgentRecommendationSummary {
    recommendationArn: string;
    profileArn: string;
    generationId?: string | undefined;
    title: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    type: RecommendationType;
    pillar: Pillar;
    priority: Priority;
    effort: Effort;
    status: RecommendationStatus;
    state: RecommendationState;
    updateReason?: string | redacted.Redacted<string> | undefined;
    impact: ImpactCategory;
    roi: Roi;
    numberOfResources?: number | undefined;
    awsServices?: string[] | undefined;
    businessUnits?: string[] | undefined;
    applications?: string[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export type AgentRecommendationSummaries = AgentRecommendationSummary[];
export interface ListAgentRecommendationsResponse {
    items: AgentRecommendationSummary[];
    nextToken?: string | undefined;
}
export type QuestionPriority = "PRIORITIZED" | "NONE" | (string & {});
export interface ListAnswersInput {
    WorkloadId: string;
    LensAlias: string;
    PillarId?: string | undefined;
    MilestoneNumber?: number | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    QuestionPriority?: QuestionPriority | undefined;
}
export interface ChoiceAnswerSummary {
    ChoiceId?: string | undefined;
    Status?: ChoiceStatus | undefined;
    Reason?: ChoiceReason | undefined;
}
export type ChoiceAnswerSummaries = ChoiceAnswerSummary[];
export type QuestionType = "PRIORITIZED" | "NON_PRIORITIZED" | (string & {});
export interface AnswerSummary {
    QuestionId?: string | undefined;
    PillarId?: string | undefined;
    QuestionTitle?: string | undefined;
    Choices?: Choice[] | undefined;
    SelectedChoices?: string[] | undefined;
    ChoiceAnswerSummaries?: ChoiceAnswerSummary[] | undefined;
    IsApplicable?: boolean | undefined;
    Risk?: Risk | undefined;
    Reason?: AnswerReason | undefined;
    QuestionType?: QuestionType | undefined;
    JiraConfiguration?: JiraConfiguration | undefined;
}
export type AnswerSummaries = AnswerSummary[];
export interface ListAnswersOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    AnswerSummaries?: AnswerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCheckDetailsInput {
    WorkloadId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    LensArn?: string | undefined;
    PillarId?: string | undefined;
    QuestionId?: string | undefined;
    ChoiceId?: string | undefined;
}
export type CheckId = string;
export type CheckName = string;
export type CheckDescription = string;
export type CheckProvider = "TRUSTED_ADVISOR" | (string & {});
export type CheckStatus = "OKAY" | "WARNING" | "ERROR" | "NOT_AVAILABLE" | "FETCH_FAILED" | (string & {});
export type FlaggedResources = number;
export type CheckFailureReason = "ASSUME_ROLE_ERROR" | "ACCESS_DENIED" | "UNKNOWN_ERROR" | "PREMIUM_SUPPORT_REQUIRED" | (string & {});
export interface CheckDetail {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Provider?: CheckProvider | undefined;
    LensArn?: string | undefined;
    PillarId?: string | undefined;
    QuestionId?: string | undefined;
    ChoiceId?: string | undefined;
    Status?: CheckStatus | undefined;
    AccountId?: string | undefined;
    FlaggedResources?: number | undefined;
    Reason?: CheckFailureReason | undefined;
    UpdatedAt?: Date | undefined;
}
export type CheckDetails = CheckDetail[];
export interface ListCheckDetailsOutput {
    CheckDetails?: CheckDetail[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCheckSummariesInput {
    WorkloadId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    LensArn?: string | undefined;
    PillarId?: string | undefined;
    QuestionId?: string | undefined;
    ChoiceId?: string | undefined;
}
export type CheckStatusCount = number;
export type AccountSummary = {
    [key in CheckStatus]?: number | undefined;
};
export interface CheckSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Provider?: CheckProvider | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
    LensArn?: string | undefined;
    PillarId?: string | undefined;
    QuestionId?: string | undefined;
    ChoiceId?: string | undefined;
    Status?: CheckStatus | undefined;
    AccountSummary?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type CheckSummaries = CheckSummary[];
export interface ListCheckSummariesOutput {
    CheckSummaries?: CheckSummary[] | undefined;
    NextToken?: string | undefined;
}
export type LensType = "AWS_OFFICIAL" | "CUSTOM_SHARED" | "CUSTOM_SELF" | (string & {});
export interface ListLensesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    LensType?: LensType | undefined;
    LensStatus?: LensStatusType | undefined;
    LensName?: string | undefined;
}
export interface LensSummary {
    LensArn?: string | undefined;
    LensAlias?: string | undefined;
    LensName?: string | undefined;
    LensType?: LensType | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    LensVersion?: string | undefined;
    Owner?: string | undefined;
    LensStatus?: LensStatus | undefined;
}
export type LensSummaries = LensSummary[];
export interface ListLensesOutput {
    LensSummaries?: LensSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLensReviewImprovementsInput {
    WorkloadId: string;
    LensAlias: string;
    PillarId?: string | undefined;
    MilestoneNumber?: number | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    QuestionPriority?: QuestionPriority | undefined;
}
export interface ChoiceImprovementPlan {
    ChoiceId?: string | undefined;
    DisplayText?: string | undefined;
    ImprovementPlanUrl?: string | undefined;
}
export type ChoiceImprovementPlans = ChoiceImprovementPlan[];
export interface ImprovementSummary {
    QuestionId?: string | undefined;
    PillarId?: string | undefined;
    QuestionTitle?: string | undefined;
    Risk?: Risk | undefined;
    ImprovementPlanUrl?: string | undefined;
    ImprovementPlans?: ChoiceImprovementPlan[] | undefined;
    JiraConfiguration?: JiraConfiguration | undefined;
}
export type ImprovementSummaries = ImprovementSummary[];
export interface ListLensReviewImprovementsOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    ImprovementSummaries?: ImprovementSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLensReviewsInput {
    WorkloadId: string;
    MilestoneNumber?: number | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LensReviewSummary {
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    LensVersion?: string | undefined;
    LensName?: string | undefined;
    LensStatus?: LensStatus | undefined;
    UpdatedAt?: Date | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    Profiles?: WorkloadProfile[] | undefined;
    PrioritizedRiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type LensReviewSummaries = LensReviewSummary[];
export interface ListLensReviewsOutput {
    WorkloadId?: string | undefined;
    MilestoneNumber?: number | undefined;
    LensReviewSummaries?: LensReviewSummary[] | undefined;
    NextToken?: string | undefined;
}
export type SharedWithPrefix = string;
export type ShareStatus = "ACCEPTED" | "REJECTED" | "PENDING" | "REVOKED" | "EXPIRED" | "ASSOCIATING" | "ASSOCIATED" | "FAILED" | (string & {});
export interface ListLensSharesInput {
    LensAlias: string;
    SharedWithPrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ShareStatus | undefined;
}
export interface LensShareSummary {
    ShareId?: string | undefined;
    SharedWith?: string | undefined;
    Status?: ShareStatus | undefined;
    StatusMessage?: string | undefined;
}
export type LensShareSummaries = LensShareSummary[];
export interface ListLensSharesOutput {
    LensShareSummaries?: LensShareSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMilestonesInput {
    WorkloadId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface WorkloadSummary {
    WorkloadId?: string | undefined;
    WorkloadArn?: string | undefined;
    WorkloadName?: string | undefined;
    Owner?: string | undefined;
    UpdatedAt?: Date | undefined;
    Lenses?: string[] | undefined;
    RiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
    ImprovementStatus?: WorkloadImprovementStatus | undefined;
    Profiles?: WorkloadProfile[] | undefined;
    PrioritizedRiskCounts?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface MilestoneSummary {
    MilestoneNumber?: number | undefined;
    MilestoneName?: string | undefined;
    RecordedAt?: Date | undefined;
    WorkloadSummary?: WorkloadSummary | undefined;
}
export type MilestoneSummaries = MilestoneSummary[];
export interface ListMilestonesOutput {
    WorkloadId?: string | undefined;
    MilestoneSummaries?: MilestoneSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListNotificationsInput {
    WorkloadId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResourceArn?: string | undefined;
}
export type NotificationType = "LENS_VERSION_UPGRADED" | "LENS_VERSION_DEPRECATED" | (string & {});
export interface LensUpgradeSummary {
    WorkloadId?: string | undefined;
    WorkloadName?: string | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    CurrentLensVersion?: string | undefined;
    LatestLensVersion?: string | undefined;
    ResourceArn?: string | undefined;
    ResourceName?: string | undefined;
}
export interface NotificationSummary {
    Type?: NotificationType | undefined;
    LensUpgradeSummary?: LensUpgradeSummary | undefined;
}
export type NotificationSummaries = NotificationSummary[];
export interface ListNotificationsOutput {
    NotificationSummaries?: NotificationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfileNotificationsInput {
    WorkloadId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ProfileNotificationType = "PROFILE_ANSWERS_UPDATED" | "PROFILE_DELETED" | (string & {});
export interface ProfileNotificationSummary {
    CurrentProfileVersion?: string | undefined;
    LatestProfileVersion?: string | undefined;
    Type?: ProfileNotificationType | undefined;
    ProfileArn?: string | undefined;
    ProfileName?: string | undefined;
    WorkloadId?: string | undefined;
    WorkloadName?: string | undefined;
}
export type ProfileNotificationSummaries = ProfileNotificationSummary[];
export interface ListProfileNotificationsOutput {
    NotificationSummaries?: ProfileNotificationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ProfileNamePrefix = string;
export type ProfileOwnerType = "SELF" | "SHARED" | (string & {});
export interface ListProfilesInput {
    ProfileNamePrefix?: string | undefined;
    ProfileOwnerType?: ProfileOwnerType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ProfileSummary {
    ProfileArn?: string | undefined;
    ProfileVersion?: string | undefined;
    ProfileName?: string | undefined;
    ProfileDescription?: string | undefined;
    Owner?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type ProfileSummaries = ProfileSummary[];
export interface ListProfilesOutput {
    ProfileSummaries?: ProfileSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProfileSharesInput {
    ProfileArn: string;
    SharedWithPrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ShareStatus | undefined;
}
export interface ProfileShareSummary {
    ShareId?: string | undefined;
    SharedWith?: string | undefined;
    Status?: ShareStatus | undefined;
    StatusMessage?: string | undefined;
}
export type ProfileShareSummaries = ProfileShareSummary[];
export interface ListProfileSharesOutput {
    ProfileShareSummaries?: ProfileShareSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReviewTemplateAnswersInput {
    TemplateArn: string;
    LensAlias: string;
    PillarId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ReviewTemplateAnswerSummary {
    QuestionId?: string | undefined;
    PillarId?: string | undefined;
    QuestionTitle?: string | undefined;
    Choices?: Choice[] | undefined;
    SelectedChoices?: string[] | undefined;
    ChoiceAnswerSummaries?: ChoiceAnswerSummary[] | undefined;
    IsApplicable?: boolean | undefined;
    AnswerStatus?: ReviewTemplateAnswerStatus | undefined;
    Reason?: AnswerReason | undefined;
    QuestionType?: QuestionType | undefined;
}
export type ReviewTemplateAnswerSummaries = ReviewTemplateAnswerSummary[];
export interface ListReviewTemplateAnswersOutput {
    TemplateArn?: string | undefined;
    LensAlias?: string | undefined;
    AnswerSummaries?: ReviewTemplateAnswerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReviewTemplatesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ReviewTemplateSummary {
    Description?: string | undefined;
    Lenses?: string[] | undefined;
    Owner?: string | undefined;
    UpdatedAt?: Date | undefined;
    TemplateArn?: string | undefined;
    TemplateName?: string | undefined;
    UpdateStatus?: ReviewTemplateUpdateStatus | undefined;
}
export type ReviewTemplates = ReviewTemplateSummary[];
export interface ListReviewTemplatesOutput {
    ReviewTemplates?: ReviewTemplateSummary[] | undefined;
    NextToken?: string | undefined;
}
export type WorkloadNamePrefix = string;
export type LensNamePrefix = string;
export type ShareResourceType = "WORKLOAD" | "LENS" | "PROFILE" | "TEMPLATE" | (string & {});
export type TemplateNamePrefix = string;
export interface ListShareInvitationsInput {
    WorkloadNamePrefix?: string | undefined;
    LensNamePrefix?: string | undefined;
    ShareResourceType?: ShareResourceType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ProfileNamePrefix?: string | undefined;
    TemplateNamePrefix?: string | undefined;
}
export interface ShareInvitationSummary {
    ShareInvitationId?: string | undefined;
    SharedBy?: string | undefined;
    SharedWith?: string | undefined;
    PermissionType?: PermissionType | undefined;
    ShareResourceType?: ShareResourceType | undefined;
    WorkloadName?: string | undefined;
    WorkloadId?: string | undefined;
    LensName?: string | undefined;
    LensArn?: string | undefined;
    ProfileName?: string | undefined;
    ProfileArn?: string | undefined;
    TemplateName?: string | undefined;
    TemplateArn?: string | undefined;
}
export type ShareInvitationSummaries = ShareInvitationSummary[];
export interface ListShareInvitationsOutput {
    ShareInvitationSummaries?: ShareInvitationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    WorkloadArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTemplateSharesInput {
    TemplateArn: string;
    SharedWithPrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ShareStatus | undefined;
}
export interface TemplateShareSummary {
    ShareId?: string | undefined;
    SharedWith?: string | undefined;
    Status?: ShareStatus | undefined;
    StatusMessage?: string | undefined;
}
export type TemplateShareSummaries = TemplateShareSummary[];
export interface ListTemplateSharesOutput {
    TemplateArn?: string | undefined;
    TemplateShareSummaries?: TemplateShareSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListWorkloadsInput {
    WorkloadNamePrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type WorkloadSummaries = WorkloadSummary[];
export interface ListWorkloadsOutput {
    WorkloadSummaries?: WorkloadSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListWorkloadSharesInput {
    WorkloadId: string;
    SharedWithPrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ShareStatus | undefined;
}
export interface WorkloadShareSummary {
    ShareId?: string | undefined;
    SharedWith?: string | undefined;
    PermissionType?: PermissionType | undefined;
    Status?: ShareStatus | undefined;
    StatusMessage?: string | undefined;
}
export type WorkloadShareSummaries = WorkloadShareSummary[];
export interface ListWorkloadSharesOutput {
    WorkloadId?: string | undefined;
    WorkloadShareSummaries?: WorkloadShareSummary[] | undefined;
    NextToken?: string | undefined;
}
export type RecommendationFeedbackType = "USEFUL" | "NOT_USEFUL" | (string & {});
export type FeedbackCategory = "OTHER" | "RECOMMENDATION_NOT_RELEVANT" | "RESOURCE_NOT_IMPORTANT" | "RESOURCE_TYPE_NOT_IMPORTANT" | "RECOMMENDATION_INCORRECT" | (string & {});
export interface PutAgentRecommendationFeedbackRequest {
    recommendationArn: string;
    type: RecommendationFeedbackType;
    feedbackCategory?: FeedbackCategory | undefined;
    comments?: string | undefined;
}
export interface PutAgentRecommendationFeedbackResponse {
}
export type RecommendationTypes = RecommendationType[];
export interface StartAgentRecommendationGenerationRequest {
    profileArn: string;
    types: RecommendationType[];
    name?: string | undefined;
    additionalContext?: any | undefined;
    scope: Scope;
}
export interface StartAgentRecommendationGenerationResponse {
    id: string;
    profileArn: string;
    name?: string | undefined;
    status: GenerationStatus;
    estimatedCompletionTime?: Date | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export interface TagResourceInput {
    WorkloadArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    WorkloadArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceOutput {
}
export interface UpdateAgentContextRequest {
    clientToken?: string | undefined;
    profileArn: string;
    id: string;
    title?: string | redacted.Redacted<string> | undefined;
    content?: ContextContent | undefined;
}
export interface UpdateAgentContextResponse {
    context: ContextSummary;
}
export interface UpdateAgentGoalRequest {
    clientToken?: string | undefined;
    profileArn: string;
    id: string;
    pillars?: Pillar[] | undefined;
    title?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateAgentGoalResponse {
    goal: GoalSummary;
}
export interface UpdateAgentProfileRequest {
    clientToken?: string | undefined;
    profileArn: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    executionRoleArn?: string | undefined;
    aggregationConfiguration?: AggregationConfiguration[] | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars?: Pillar[] | undefined;
    deletionProtection?: boolean | undefined;
}
export interface UpdateAgentProfileResponse {
    name: string;
    displayName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    businessOverview?: string | redacted.Redacted<string> | undefined;
    pillars: Pillar[];
    deletionProtection?: boolean | undefined;
    executionRoleArn: string;
    aggregationConfiguration: AggregationConfiguration[];
    arn: string;
    eligibleForScheduledGeneration?: boolean | undefined;
    eligibleForArchitectureGeneration?: boolean | undefined;
    fieldErrors?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: Tag[] | undefined;
    createdBy: string;
    createdAt: Date;
    lastModifiedBy?: string | undefined;
    lastModifiedAt?: Date | undefined;
}
export interface UpdateAgentRecommendationStatusRequest {
    recommendationArn: string;
    status: RecommendationStatus;
    updateReason?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateAgentRecommendationStatusResponse {
}
export interface ChoiceUpdate {
    Status?: ChoiceStatus | undefined;
    Reason?: ChoiceReason | undefined;
    Notes?: string | undefined;
}
export type ChoiceUpdates = {
    [key: string]: ChoiceUpdate | undefined;
};
export interface UpdateAnswerInput {
    WorkloadId: string;
    LensAlias: string;
    QuestionId: string;
    SelectedChoices?: string[] | undefined;
    ChoiceUpdates?: {
        [key: string]: ChoiceUpdate | undefined;
    } | undefined;
    Notes?: string | undefined;
    IsApplicable?: boolean | undefined;
    Reason?: AnswerReason | undefined;
}
export interface UpdateAnswerOutput {
    WorkloadId?: string | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    Answer?: Answer | undefined;
}
export type IntegrationStatusInput = "NOT_CONFIGURED" | (string & {});
export interface AccountJiraConfigurationInput {
    IssueManagementStatus?: AccountJiraIssueManagementStatus | undefined;
    IssueManagementType?: IssueManagementType | undefined;
    JiraProjectKey?: string | undefined;
    IntegrationStatus?: IntegrationStatusInput | undefined;
}
export interface UpdateGlobalSettingsInput {
    OrganizationSharingStatus?: OrganizationSharingStatus | undefined;
    DiscoveryIntegrationStatus?: DiscoveryIntegrationStatus | undefined;
    JiraConfiguration?: AccountJiraConfigurationInput | undefined;
}
export interface UpdateGlobalSettingsResponse {
}
export type IntegratingService = "JIRA" | (string & {});
export interface UpdateIntegrationInput {
    WorkloadId: string;
    ClientRequestToken?: string | undefined;
    IntegratingService?: IntegratingService | undefined;
}
export interface UpdateIntegrationResponse {
}
export type PillarNotes = {
    [key: string]: string | undefined;
};
export interface UpdateLensReviewInput {
    WorkloadId: string;
    LensAlias: string;
    LensNotes?: string | undefined;
    PillarNotes?: {
        [key: string]: string | undefined;
    } | undefined;
    JiraConfiguration?: JiraSelectedQuestionConfiguration | undefined;
}
export interface UpdateLensReviewOutput {
    WorkloadId?: string | undefined;
    LensReview?: LensReview | undefined;
}
export interface UpdateProfileInput {
    ProfileArn: string;
    ProfileDescription?: string | undefined;
    ProfileQuestions?: ProfileQuestionUpdate[] | undefined;
}
export interface UpdateProfileOutput {
    Profile?: Profile | undefined;
}
export type ReviewTemplateLensAliases = string[];
export interface UpdateReviewTemplateInput {
    TemplateArn: string;
    TemplateName?: string | undefined;
    Description?: string | undefined;
    Notes?: string | undefined;
    LensesToAssociate?: string[] | undefined;
    LensesToDisassociate?: string[] | undefined;
}
export interface UpdateReviewTemplateOutput {
    ReviewTemplate?: ReviewTemplate | undefined;
}
export interface UpdateReviewTemplateAnswerInput {
    TemplateArn: string;
    LensAlias: string;
    QuestionId: string;
    SelectedChoices?: string[] | undefined;
    ChoiceUpdates?: {
        [key: string]: ChoiceUpdate | undefined;
    } | undefined;
    Notes?: string | undefined;
    IsApplicable?: boolean | undefined;
    Reason?: AnswerReason | undefined;
}
export interface UpdateReviewTemplateAnswerOutput {
    TemplateArn?: string | undefined;
    LensAlias?: string | undefined;
    Answer?: ReviewTemplateAnswer | undefined;
}
export interface UpdateReviewTemplateLensReviewInput {
    TemplateArn: string;
    LensAlias: string;
    LensNotes?: string | undefined;
    PillarNotes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateReviewTemplateLensReviewOutput {
    TemplateArn?: string | undefined;
    LensReview?: ReviewTemplateLensReview | undefined;
}
export type ShareInvitationAction = "ACCEPT" | "REJECT" | (string & {});
export interface UpdateShareInvitationInput {
    ShareInvitationId: string;
    ShareInvitationAction?: ShareInvitationAction | undefined;
}
export interface ShareInvitation {
    ShareInvitationId?: string | undefined;
    ShareResourceType?: ShareResourceType | undefined;
    WorkloadId?: string | undefined;
    LensAlias?: string | undefined;
    LensArn?: string | undefined;
    ProfileArn?: string | undefined;
    TemplateArn?: string | undefined;
}
export interface UpdateShareInvitationOutput {
    ShareInvitation?: ShareInvitation | undefined;
}
export interface UpdateWorkloadInput {
    WorkloadId: string;
    WorkloadName?: string | undefined;
    Description?: string | undefined;
    Environment?: WorkloadEnvironment | undefined;
    AccountIds?: string[] | undefined;
    AwsRegions?: string[] | undefined;
    NonAwsRegions?: string[] | undefined;
    PillarPriorities?: string[] | undefined;
    ArchitecturalDesign?: string | undefined;
    ReviewOwner?: string | undefined;
    IsReviewOwnerUpdateAcknowledged?: boolean | undefined;
    IndustryType?: string | undefined;
    Industry?: string | undefined;
    Notes?: string | undefined;
    ImprovementStatus?: WorkloadImprovementStatus | undefined;
    DiscoveryConfig?: WorkloadDiscoveryConfig | undefined;
    Applications?: string[] | undefined;
    JiraConfiguration?: WorkloadJiraConfigurationInput | undefined;
}
export interface UpdateWorkloadOutput {
    Workload?: Workload | undefined;
}
export interface UpdateWorkloadShareInput {
    ShareId: string;
    WorkloadId: string;
    PermissionType?: PermissionType | undefined;
}
export interface WorkloadShare {
    ShareId?: string | undefined;
    SharedBy?: string | undefined;
    SharedWith?: string | undefined;
    PermissionType?: PermissionType | undefined;
    Status?: ShareStatus | undefined;
    WorkloadName?: string | undefined;
    WorkloadId?: string | undefined;
}
export interface UpdateWorkloadShareOutput {
    WorkloadId?: string | undefined;
    WorkloadShare?: WorkloadShare | undefined;
}
export interface UpgradeLensReviewInput {
    WorkloadId: string;
    LensAlias: string;
    MilestoneName?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface UpgradeLensReviewResponse {
}
export interface UpgradeProfileVersionInput {
    WorkloadId: string;
    ProfileArn: string;
    MilestoneName?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface UpgradeProfileVersionResponse {
}
export interface UpgradeReviewTemplateLensReviewInput {
    TemplateArn: string;
    LensAlias: string;
    ClientRequestToken?: string | undefined;
}
export interface UpgradeReviewTemplateLensReviewResponse {
}
export type ExceptionMessage = string;
export type ExceptionResourceId = string;
export type ExceptionResourceType = string;
export type QuotaCode = string;
export type ServiceCode = string;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export type ValidationExceptionFieldName = string;
export interface ValidationExceptionField {
    Name?: string | undefined;
    Message?: string | undefined;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateLensesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate a lens to a workload.
 *
 * Up to 10 lenses can be associated with a workload in a single API operation. A maximum of 20 lenses can be associated with a workload.
 *
 * **Disclaimer**
 *
 * By accessing and/or applying custom lenses created by another Amazon Web Services user or account, you acknowledge that custom lenses created by other users and shared with you are Third Party Content as defined in the Amazon Web Services Customer Agreement.
 */
export declare const associateLenses: API.OperationMethod<AssociateLensesInput & RegionInput, AssociateLensesResponse, AssociateLensesError, Credentials | HttpClient.HttpClient>;
export type AssociateProfilesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate a profile with a workload.
 */
export declare const associateProfiles: API.OperationMethod<AssociateProfilesInput & RegionInput, AssociateProfilesResponse, AssociateProfilesError, Credentials | HttpClient.HttpClient>;
export type CreateAgentContextError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a context associated with an optimization profile. Contexts provide application and environment information used during recommendation generation.
 */
export declare const createAgentContext: API.OperationMethod<CreateAgentContextRequest & RegionInput, CreateAgentContextResponse, CreateAgentContextError, Credentials | HttpClient.HttpClient>;
export type CreateAgentGoalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an optimization goal associated with a profile. Goals define specific targets and objectives for the optimization process.
 */
export declare const createAgentGoal: API.OperationMethod<CreateAgentGoalRequest & RegionInput, CreateAgentGoalResponse, CreateAgentGoalError, Credentials | HttpClient.HttpClient>;
export type CreateAgentProfileError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an optimization profile that defines the scope and configuration for generating recommendations. A profile specifies the execution role, target pillars, and aggregation settings for analyzing your Amazon Web Services resources.
 */
export declare const createAgentProfile: API.OperationMethod<CreateAgentProfileRequest & RegionInput, CreateAgentProfileResponse, CreateAgentProfileError, Credentials | HttpClient.HttpClient>;
export type CreateLensShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a lens share.
 *
 * The owner of a lens can share it with other Amazon Web Services accounts, users, an organization, and organizational units (OUs) in the same Amazon Web Services Region. Lenses provided by Amazon Web Services (Amazon Web Services Official Content) cannot be shared.
 *
 * Shared access to a lens is not removed until the lens invitation is deleted.
 *
 * If you share a lens with an organization or OU, all accounts in the organization or OU are granted access to the lens.
 *
 * For more information, see Sharing a custom lens in the *Well-Architected Tool User Guide*.
 *
 * **Disclaimer**
 *
 * By sharing your custom lenses with other Amazon Web Services accounts, you acknowledge that Amazon Web Services will make your custom lenses available to those other accounts. Those other accounts may continue to access and use your shared custom lenses even if you delete the custom lenses from your own Amazon Web Services account or terminate your Amazon Web Services account.
 */
export declare const createLensShare: API.OperationMethod<CreateLensShareInput & RegionInput, CreateLensShareOutput, CreateLensShareError, Credentials | HttpClient.HttpClient>;
export type CreateLensVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new lens version.
 *
 * A lens can have up to 100 versions.
 *
 * Use this operation to publish a new lens version after you have imported a lens. The `LensAlias` is used to identify the lens to be published. The owner of a lens can share the lens with other Amazon Web Services accounts and users in the same Amazon Web Services Region. Only the owner of a lens can delete it.
 */
export declare const createLensVersion: API.OperationMethod<CreateLensVersionInput & RegionInput, CreateLensVersionOutput, CreateLensVersionError, Credentials | HttpClient.HttpClient>;
export type CreateMilestoneError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a milestone for an existing workload.
 */
export declare const createMilestone: API.OperationMethod<CreateMilestoneInput & RegionInput, CreateMilestoneOutput, CreateMilestoneError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a profile.
 */
export declare const createProfile: API.OperationMethod<CreateProfileInput & RegionInput, CreateProfileOutput, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateProfileShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a profile share.
 */
export declare const createProfileShare: API.OperationMethod<CreateProfileShareInput & RegionInput, CreateProfileShareOutput, CreateProfileShareError, Credentials | HttpClient.HttpClient>;
export type CreateReviewTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a review template.
 *
 * **Disclaimer**
 *
 * Do not include or gather personal identifiable information (PII) of end users or other identifiable individuals in or via your review templates. If your review template or those shared with you and used in your account do include or collect PII you are responsible for: ensuring that the included PII is processed in accordance with applicable law, providing adequate privacy notices, and obtaining necessary consents for processing such data.
 */
export declare const createReviewTemplate: API.OperationMethod<CreateReviewTemplateInput & RegionInput, CreateReviewTemplateOutput, CreateReviewTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a review template share.
 *
 * The owner of a review template can share it with other Amazon Web Services accounts, users, an organization, and organizational units (OUs) in the same Amazon Web Services Region.
 *
 * Shared access to a review template is not removed until the review template share invitation is deleted.
 *
 * If you share a review template with an organization or OU, all accounts in the organization or OU are granted access to the review template.
 *
 * **Disclaimer**
 *
 * By sharing your review template with other Amazon Web Services accounts, you acknowledge that Amazon Web Services will make your review template available to those other accounts.
 */
export declare const createTemplateShare: API.OperationMethod<CreateTemplateShareInput & RegionInput, CreateTemplateShareOutput, CreateTemplateShareError, Credentials | HttpClient.HttpClient>;
export type CreateWorkloadError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new workload.
 *
 * The owner of a workload can share the workload with other Amazon Web Services accounts, users, an organization, and organizational units (OUs) in the same Amazon Web Services Region. Only the owner of a workload can delete it.
 *
 * For more information, see Defining a Workload in the *Well-Architected Tool User Guide*.
 *
 * Either `AwsRegions`, `NonAwsRegions`, or both must be specified when creating a workload.
 *
 * You also must specify `ReviewOwner`, even though the parameter is listed as not being required in the following section.
 *
 * When creating a workload using a review template, you must have the following IAM permissions:
 *
 * - `wellarchitected:GetReviewTemplate`
 *
 * - `wellarchitected:GetReviewTemplateAnswer`
 *
 * - `wellarchitected:ListReviewTemplateAnswers`
 *
 * - `wellarchitected:GetReviewTemplateLensReview`
 */
export declare const createWorkload: API.OperationMethod<CreateWorkloadInput & RegionInput, CreateWorkloadOutput, CreateWorkloadError, Credentials | HttpClient.HttpClient>;
export type CreateWorkloadShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a workload share.
 *
 * The owner of a workload can share it with other Amazon Web Services accounts and users in the same Amazon Web Services Region. Shared access to a workload is not removed until the workload invitation is deleted.
 *
 * If you share a workload with an organization or OU, all accounts in the organization or OU are granted access to the workload.
 *
 * For more information, see Sharing a workload in the *Well-Architected Tool User Guide*.
 */
export declare const createWorkloadShare: API.OperationMethod<CreateWorkloadShareInput & RegionInput, CreateWorkloadShareOutput, CreateWorkloadShareError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentContextError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a context associated with a profile.
 */
export declare const deleteAgentContext: API.OperationMethod<DeleteAgentContextRequest & RegionInput, DeleteAgentContextResponse, DeleteAgentContextError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentGoalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an optimization goal from a profile.
 */
export declare const deleteAgentGoal: API.OperationMethod<DeleteAgentGoalRequest & RegionInput, DeleteAgentGoalResponse, DeleteAgentGoalError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an optimization profile and its associated configuration. This action cannot be undone.
 */
export declare const deleteAgentProfile: API.OperationMethod<DeleteAgentProfileRequest & RegionInput, DeleteAgentProfileResponse, DeleteAgentProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteLensError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an existing lens.
 *
 * Only the owner of a lens can delete it. After the lens is deleted, Amazon Web Services accounts and users that you shared the lens with can continue to use it, but they will no longer be able to apply it to new workloads.
 *
 * **Disclaimer**
 *
 * By sharing your custom lenses with other Amazon Web Services accounts, you acknowledge that Amazon Web Services will make your custom lenses available to those other accounts. Those other accounts may continue to access and use your shared custom lenses even if you delete the custom lenses from your own Amazon Web Services account or terminate your Amazon Web Services account.
 */
export declare const deleteLens: API.OperationMethod<DeleteLensInput & RegionInput, DeleteLensResponse, DeleteLensError, Credentials | HttpClient.HttpClient>;
export type DeleteLensShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a lens share.
 *
 * After the lens share is deleted, Amazon Web Services accounts, users, organizations, and organizational units (OUs) that you shared the lens with can continue to use it, but they will no longer be able to apply it to new workloads.
 *
 * **Disclaimer**
 *
 * By sharing your custom lenses with other Amazon Web Services accounts, you acknowledge that Amazon Web Services will make your custom lenses available to those other accounts. Those other accounts may continue to access and use your shared custom lenses even if you delete the custom lenses from your own Amazon Web Services account or terminate your Amazon Web Services account.
 */
export declare const deleteLensShare: API.OperationMethod<DeleteLensShareInput & RegionInput, DeleteLensShareResponse, DeleteLensShareError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a profile.
 *
 * **Disclaimer**
 *
 * By sharing your profile with other Amazon Web Services accounts, you acknowledge that Amazon Web Services will make your profile available to those other accounts. Those other accounts may continue to access and use your shared profile even if you delete the profile from your own Amazon Web Services account or terminate your Amazon Web Services account.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileInput & RegionInput, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a profile share.
 */
export declare const deleteProfileShare: API.OperationMethod<DeleteProfileShareInput & RegionInput, DeleteProfileShareResponse, DeleteProfileShareError, Credentials | HttpClient.HttpClient>;
export type DeleteReviewTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a review template.
 *
 * Only the owner of a review template can delete it.
 *
 * After the review template is deleted, Amazon Web Services accounts, users, organizations, and organizational units (OUs) that you shared the review template with will no longer be able to apply it to new workloads.
 */
export declare const deleteReviewTemplate: API.OperationMethod<DeleteReviewTemplateInput & RegionInput, DeleteReviewTemplateResponse, DeleteReviewTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a review template share.
 *
 * After the review template share is deleted, Amazon Web Services accounts, users, organizations, and organizational units (OUs) that you shared the review template with will no longer be able to apply it to new workloads.
 */
export declare const deleteTemplateShare: API.OperationMethod<DeleteTemplateShareInput & RegionInput, DeleteTemplateShareResponse, DeleteTemplateShareError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkloadError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an existing workload.
 */
export declare const deleteWorkload: API.OperationMethod<DeleteWorkloadInput & RegionInput, DeleteWorkloadResponse, DeleteWorkloadError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkloadShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a workload share.
 */
export declare const deleteWorkloadShare: API.OperationMethod<DeleteWorkloadShareInput & RegionInput, DeleteWorkloadShareResponse, DeleteWorkloadShareError, Credentials | HttpClient.HttpClient>;
export type DisassociateLensesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociate a lens from a workload.
 *
 * Up to 10 lenses can be disassociated from a workload in a single API operation.
 *
 * The Amazon Web Services Well-Architected Framework lens (`wellarchitected`) cannot be removed from a workload.
 */
export declare const disassociateLenses: API.OperationMethod<DisassociateLensesInput & RegionInput, DisassociateLensesResponse, DisassociateLensesError, Credentials | HttpClient.HttpClient>;
export type DisassociateProfilesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociate a profile from a workload.
 */
export declare const disassociateProfiles: API.OperationMethod<DisassociateProfilesInput & RegionInput, DisassociateProfilesResponse, DisassociateProfilesError, Credentials | HttpClient.HttpClient>;
export type ExportLensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export an existing lens.
 *
 * Only the owner of a lens can export it. Lenses provided by Amazon Web Services (Amazon Web Services Official Content) cannot be exported.
 *
 * Lenses are defined in JSON. For more information, see JSON format specification in the *Well-Architected Tool User Guide*.
 *
 * **Disclaimer**
 *
 * Do not include or gather personal identifiable information (PII) of end users or other identifiable individuals in or via your custom lenses. If your custom lens or those shared with you and used in your account do include or collect PII you are responsible for: ensuring that the included PII is processed in accordance with applicable law, providing adequate privacy notices, and obtaining necessary consents for processing such data.
 */
export declare const exportLens: API.OperationMethod<ExportLensInput & RegionInput, ExportLensOutput, ExportLensError, Credentials | HttpClient.HttpClient>;
export type GetAgentContextError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific context associated with a profile.
 */
export declare const getAgentContext: API.OperationMethod<GetAgentContextRequest & RegionInput, GetAgentContextResponse, GetAgentContextError, Credentials | HttpClient.HttpClient>;
export type GetAgentGoalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific optimization goal.
 */
export declare const getAgentGoal: API.OperationMethod<GetAgentGoalRequest & RegionInput, GetAgentGoalResponse, GetAgentGoalError, Credentials | HttpClient.HttpClient>;
export type GetAgentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an optimization profile, including its configuration and metadata.
 */
export declare const getAgentProfile: API.OperationMethod<GetAgentProfileRequest & RegionInput, GetAgentProfileResponse, GetAgentProfileError, Credentials | HttpClient.HttpClient>;
export type GetAgentRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific optimization recommendation, including its impact analysis, content, and implementation guidance.
 */
export declare const getAgentRecommendation: API.OperationMethod<GetAgentRecommendationRequest & RegionInput, GetAgentRecommendationResponse, GetAgentRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetAgentRecommendationGenerationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a recommendation generation process, including its status, progress, and results. Recommendation generation is asynchronous: poll this operation until status reaches a terminal value of COMPLETED (results are ready) or ERROR (see errorDetails). Intermediate values are QUEUED and IN_PROGRESS.
 */
export declare const getAgentRecommendationGeneration: API.OperationMethod<GetAgentRecommendationGenerationRequest & RegionInput, GetAgentRecommendationGenerationResponse, GetAgentRecommendationGenerationError, Credentials | HttpClient.HttpClient>;
export type GetAnswerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the answer to a specific question in a workload review.
 */
export declare const getAnswer: API.OperationMethod<GetAnswerInput & RegionInput, GetAnswerOutput, GetAnswerError, Credentials | HttpClient.HttpClient>;
export type GetConsolidatedReportError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a consolidated report of your workloads.
 *
 * You can optionally choose to include workloads that have been shared with you.
 */
export declare const getConsolidatedReport: API.PaginatedOperationMethod<GetConsolidatedReportInput & RegionInput, GetConsolidatedReportOutput, GetConsolidatedReportError, Credentials | HttpClient.HttpClient, unknown>;
export type GetGlobalSettingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Global settings for all workloads.
 */
export declare const getGlobalSettings: API.OperationMethod<GetGlobalSettingsRequest & RegionInput, GetGlobalSettingsOutput, GetGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type GetLensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an existing lens.
 */
export declare const getLens: API.OperationMethod<GetLensInput & RegionInput, GetLensOutput, GetLensError, Credentials | HttpClient.HttpClient>;
export type GetLensReviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get lens review.
 */
export declare const getLensReview: API.OperationMethod<GetLensReviewInput & RegionInput, GetLensReviewOutput, GetLensReviewError, Credentials | HttpClient.HttpClient>;
export type GetLensReviewReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get lens review report.
 */
export declare const getLensReviewReport: API.OperationMethod<GetLensReviewReportInput & RegionInput, GetLensReviewReportOutput, GetLensReviewReportError, Credentials | HttpClient.HttpClient>;
export type GetLensVersionDifferenceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get lens version differences.
 */
export declare const getLensVersionDifference: API.OperationMethod<GetLensVersionDifferenceInput & RegionInput, GetLensVersionDifferenceOutput, GetLensVersionDifferenceError, Credentials | HttpClient.HttpClient>;
export type GetMilestoneError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a milestone for an existing workload.
 */
export declare const getMilestone: API.OperationMethod<GetMilestoneInput & RegionInput, GetMilestoneOutput, GetMilestoneError, Credentials | HttpClient.HttpClient>;
export type GetProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get profile information.
 */
export declare const getProfile: API.OperationMethod<GetProfileInput & RegionInput, GetProfileOutput, GetProfileError, Credentials | HttpClient.HttpClient>;
export type GetProfileTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get profile template.
 */
export declare const getProfileTemplate: API.OperationMethod<GetProfileTemplateInput & RegionInput, GetProfileTemplateOutput, GetProfileTemplateError, Credentials | HttpClient.HttpClient>;
export type GetReviewTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get review template.
 */
export declare const getReviewTemplate: API.OperationMethod<GetReviewTemplateInput & RegionInput, GetReviewTemplateOutput, GetReviewTemplateError, Credentials | HttpClient.HttpClient>;
export type GetReviewTemplateAnswerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get review template answer.
 */
export declare const getReviewTemplateAnswer: API.OperationMethod<GetReviewTemplateAnswerInput & RegionInput, GetReviewTemplateAnswerOutput, GetReviewTemplateAnswerError, Credentials | HttpClient.HttpClient>;
export type GetReviewTemplateLensReviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a lens review associated with a review template.
 */
export declare const getReviewTemplateLensReview: API.OperationMethod<GetReviewTemplateLensReviewInput & RegionInput, GetReviewTemplateLensReviewOutput, GetReviewTemplateLensReviewError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get an existing workload.
 */
export declare const getWorkload: API.OperationMethod<GetWorkloadInput & RegionInput, GetWorkloadOutput, GetWorkloadError, Credentials | HttpClient.HttpClient>;
export type ImportLensError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Import a new custom lens or update an existing custom lens.
 *
 * To update an existing custom lens, specify its ARN as the `LensAlias`. If no ARN is specified, a new custom lens is created.
 *
 * The new or updated lens will have a status of `DRAFT`. The lens cannot be applied to workloads or shared with other Amazon Web Services accounts until it's published with CreateLensVersion.
 *
 * Lenses are defined in JSON. For more information, see JSON format specification in the *Well-Architected Tool User Guide*.
 *
 * A custom lens cannot exceed 500 KB in size.
 *
 * **Disclaimer**
 *
 * Do not include or gather personal identifiable information (PII) of end users or other identifiable individuals in or via your custom lenses. If your custom lens or those shared with you and used in your account do include or collect PII you are responsible for: ensuring that the included PII is processed in accordance with applicable law, providing adequate privacy notices, and obtaining necessary consents for processing such data.
 */
export declare const importLens: API.OperationMethod<ImportLensInput & RegionInput, ImportLensOutput, ImportLensError, Credentials | HttpClient.HttpClient>;
export type ListAgentContextsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists contexts associated with a profile.
 */
export declare const listAgentContexts: API.PaginatedOperationMethod<ListAgentContextsRequest & RegionInput, ListAgentContextsResponse, ListAgentContextsError, Credentials | HttpClient.HttpClient, ContextSummary>;
export type ListAgentGoalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists optimization goals associated with a specified profile. Goals define specific targets and objectives for the optimization process.
 */
export declare const listAgentGoals: API.PaginatedOperationMethod<ListAgentGoalsRequest & RegionInput, ListAgentGoalsResponse, ListAgentGoalsError, Credentials | HttpClient.HttpClient, GoalSummary>;
export type ListAgentProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists optimization profiles in your account. Profiles define the scope and configuration for generating optimization recommendations.
 */
export declare const listAgentProfiles: API.PaginatedOperationMethod<ListAgentProfilesRequest & RegionInput, ListAgentProfilesResponse, ListAgentProfilesError, Credentials | HttpClient.HttpClient, AgentProfileSummary>;
export type ListAgentRecommendationGenerationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists recommendation generation processes for a specified profile.
 */
export declare const listAgentRecommendationGenerations: API.PaginatedOperationMethod<ListAgentRecommendationGenerationsRequest & RegionInput, ListAgentRecommendationGenerationsResponse, ListAgentRecommendationGenerationsError, Credentials | HttpClient.HttpClient, AgentRecommendationGenerationSummary>;
export type ListAgentRecommendationItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists recommendation items for a specific recommendation. Recommendation items provide detailed information about individual optimization opportunities.
 */
export declare const listAgentRecommendationItems: API.PaginatedOperationMethod<ListAgentRecommendationItemsRequest & RegionInput, ListAgentRecommendationItemsResponse, ListAgentRecommendationItemsError, Credentials | HttpClient.HttpClient, AgentRecommendationItemSummary>;
export type ListAgentRecommendationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists active optimization recommendations for a specified profile with optional filtering by state.
 */
export declare const listAgentRecommendations: API.PaginatedOperationMethod<ListAgentRecommendationsRequest & RegionInput, ListAgentRecommendationsResponse, ListAgentRecommendationsError, Credentials | HttpClient.HttpClient, AgentRecommendationSummary>;
export type ListAnswersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List of answers for a particular workload and lens.
 */
export declare const listAnswers: API.PaginatedOperationMethod<ListAnswersInput & RegionInput, ListAnswersOutput, ListAnswersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCheckDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List of Trusted Advisor check details by account related to the workload.
 */
export declare const listCheckDetails: API.PaginatedOperationMethod<ListCheckDetailsInput & RegionInput, ListCheckDetailsOutput, ListCheckDetailsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCheckSummariesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List of Trusted Advisor checks summarized for all accounts related to the workload.
 */
export declare const listCheckSummaries: API.PaginatedOperationMethod<ListCheckSummariesInput & RegionInput, ListCheckSummariesOutput, ListCheckSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLensesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the available lenses.
 */
export declare const listLenses: API.PaginatedOperationMethod<ListLensesInput & RegionInput, ListLensesOutput, ListLensesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLensReviewImprovementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the improvements of a particular lens review.
 */
export declare const listLensReviewImprovements: API.PaginatedOperationMethod<ListLensReviewImprovementsInput & RegionInput, ListLensReviewImprovementsOutput, ListLensReviewImprovementsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLensReviewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List lens reviews for a particular workload.
 */
export declare const listLensReviews: API.PaginatedOperationMethod<ListLensReviewsInput & RegionInput, ListLensReviewsOutput, ListLensReviewsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLensSharesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the lens shares associated with the lens.
 */
export declare const listLensShares: API.PaginatedOperationMethod<ListLensSharesInput & RegionInput, ListLensSharesOutput, ListLensSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMilestonesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all milestones for an existing workload.
 */
export declare const listMilestones: API.PaginatedOperationMethod<ListMilestonesInput & RegionInput, ListMilestonesOutput, ListMilestonesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNotificationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List lens notifications.
 */
export declare const listNotifications: API.PaginatedOperationMethod<ListNotificationsInput & RegionInput, ListNotificationsOutput, ListNotificationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProfileNotificationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List profile notifications.
 */
export declare const listProfileNotifications: API.PaginatedOperationMethod<ListProfileNotificationsInput & RegionInput, ListProfileNotificationsOutput, ListProfileNotificationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List profiles.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesInput & RegionInput, ListProfilesOutput, ListProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProfileSharesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List profile shares.
 */
export declare const listProfileShares: API.PaginatedOperationMethod<ListProfileSharesInput & RegionInput, ListProfileSharesOutput, ListProfileSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListReviewTemplateAnswersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the answers of a review template.
 */
export declare const listReviewTemplateAnswers: API.PaginatedOperationMethod<ListReviewTemplateAnswersInput & RegionInput, ListReviewTemplateAnswersOutput, ListReviewTemplateAnswersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListReviewTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List review templates.
 */
export declare const listReviewTemplates: API.PaginatedOperationMethod<ListReviewTemplatesInput & RegionInput, ListReviewTemplatesOutput, ListReviewTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListShareInvitationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the share invitations.
 *
 * `WorkloadNamePrefix`, `LensNamePrefix`, `ProfileNamePrefix`, and `TemplateNamePrefix` are mutually exclusive. Use the parameter that matches your `ShareResourceType`.
 */
export declare const listShareInvitations: API.PaginatedOperationMethod<ListShareInvitationsInput & RegionInput, ListShareInvitationsOutput, ListShareInvitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * List the tags for a resource.
 *
 * The WorkloadArn parameter can be a workload ARN, a custom lens ARN, a profile ARN, or review template ARN.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplateSharesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List review template shares.
 */
export declare const listTemplateShares: API.PaginatedOperationMethod<ListTemplateSharesInput & RegionInput, ListTemplateSharesOutput, ListTemplateSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListWorkloadsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Paginated list of workloads.
 */
export declare const listWorkloads: API.PaginatedOperationMethod<ListWorkloadsInput & RegionInput, ListWorkloadsOutput, ListWorkloadsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListWorkloadSharesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the workload shares associated with the workload.
 */
export declare const listWorkloadShares: API.PaginatedOperationMethod<ListWorkloadSharesInput & RegionInput, ListWorkloadSharesOutput, ListWorkloadSharesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutAgentRecommendationFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits user feedback on a recommendation to help improve future optimization suggestions and track implementation outcomes.
 */
export declare const putAgentRecommendationFeedback: API.OperationMethod<PutAgentRecommendationFeedbackRequest & RegionInput, PutAgentRecommendationFeedbackResponse, PutAgentRecommendationFeedbackError, Credentials | HttpClient.HttpClient>;
export type StartAgentRecommendationGenerationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a new recommendation generation process for the specified optimization profile. This asynchronous operation analyzes your Amazon Web Services resources and generates optimization recommendations based on the configured pillars and scope. Use GetAgentRecommendationGeneration to check status.
 */
export declare const startAgentRecommendationGeneration: API.OperationMethod<StartAgentRecommendationGenerationRequest & RegionInput, StartAgentRecommendationGenerationResponse, StartAgentRecommendationGenerationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to the specified resource.
 *
 * The WorkloadArn parameter can be a workload ARN, a custom lens ARN, a profile ARN, or review template ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 *
 * The WorkloadArn parameter can be a workload ARN, a custom lens ARN, a profile ARN, or review template ARN.
 *
 * To specify multiple tags, use separate **tagKeys** parameters, for example:
 *
 * `DELETE /tags/WorkloadArn?tagKeys=key1&tagKeys=key2`
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentContextError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing context associated with a profile.
 */
export declare const updateAgentContext: API.OperationMethod<UpdateAgentContextRequest & RegionInput, UpdateAgentContextResponse, UpdateAgentContextError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentGoalError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the pillars and title of an existing goal associated with a profile.
 */
export declare const updateAgentGoal: API.OperationMethod<UpdateAgentGoalRequest & RegionInput, UpdateAgentGoalResponse, UpdateAgentGoalError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing optimization profile's configuration, including its pillars, execution role, and aggregation settings.
 */
export declare const updateAgentProfile: API.OperationMethod<UpdateAgentProfileRequest & RegionInput, UpdateAgentProfileResponse, UpdateAgentProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentRecommendationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a recommendation to track its progress through the implementation lifecycle.
 */
export declare const updateAgentRecommendationStatus: API.OperationMethod<UpdateAgentRecommendationStatusRequest & RegionInput, UpdateAgentRecommendationStatusResponse, UpdateAgentRecommendationStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateAnswerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the answer to a specific question in a workload review.
 */
export declare const updateAnswer: API.OperationMethod<UpdateAnswerInput & RegionInput, UpdateAnswerOutput, UpdateAnswerError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update whether the Amazon Web Services account is opted into organization sharing and discovery integration features.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsInput & RegionInput, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update integration features.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationInput & RegionInput, UpdateIntegrationResponse, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateLensReviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update lens review for a particular workload.
 */
export declare const updateLensReview: API.OperationMethod<UpdateLensReviewInput & RegionInput, UpdateLensReviewOutput, UpdateLensReviewError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a profile.
 */
export declare const updateProfile: API.OperationMethod<UpdateProfileInput & RegionInput, UpdateProfileOutput, UpdateProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateReviewTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a review template.
 */
export declare const updateReviewTemplate: API.OperationMethod<UpdateReviewTemplateInput & RegionInput, UpdateReviewTemplateOutput, UpdateReviewTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateReviewTemplateAnswerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a review template answer.
 */
export declare const updateReviewTemplateAnswer: API.OperationMethod<UpdateReviewTemplateAnswerInput & RegionInput, UpdateReviewTemplateAnswerOutput, UpdateReviewTemplateAnswerError, Credentials | HttpClient.HttpClient>;
export type UpdateReviewTemplateLensReviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a lens review associated with a review template.
 */
export declare const updateReviewTemplateLensReview: API.OperationMethod<UpdateReviewTemplateLensReviewInput & RegionInput, UpdateReviewTemplateLensReviewOutput, UpdateReviewTemplateLensReviewError, Credentials | HttpClient.HttpClient>;
export type UpdateShareInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a workload or custom lens share invitation.
 *
 * This API operation can be called independently of any resource. Previous documentation implied that a workload ARN must be specified.
 */
export declare const updateShareInvitation: API.OperationMethod<UpdateShareInvitationInput & RegionInput, UpdateShareInvitationOutput, UpdateShareInvitationError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an existing workload.
 */
export declare const updateWorkload: API.OperationMethod<UpdateWorkloadInput & RegionInput, UpdateWorkloadOutput, UpdateWorkloadError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadShareError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a workload share.
 */
export declare const updateWorkloadShare: API.OperationMethod<UpdateWorkloadShareInput & RegionInput, UpdateWorkloadShareOutput, UpdateWorkloadShareError, Credentials | HttpClient.HttpClient>;
export type UpgradeLensReviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Upgrade lens review for a particular workload.
 */
export declare const upgradeLensReview: API.OperationMethod<UpgradeLensReviewInput & RegionInput, UpgradeLensReviewResponse, UpgradeLensReviewError, Credentials | HttpClient.HttpClient>;
export type UpgradeProfileVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Upgrade a profile.
 */
export declare const upgradeProfileVersion: API.OperationMethod<UpgradeProfileVersionInput & RegionInput, UpgradeProfileVersionResponse, UpgradeProfileVersionError, Credentials | HttpClient.HttpClient>;
export type UpgradeReviewTemplateLensReviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Upgrade the lens review of a review template.
 */
export declare const upgradeReviewTemplateLensReview: API.OperationMethod<UpgradeReviewTemplateLensReviewInput & RegionInput, UpgradeReviewTemplateLensReviewResponse, UpgradeReviewTemplateLensReviewError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=wellarchitected.d.ts.map