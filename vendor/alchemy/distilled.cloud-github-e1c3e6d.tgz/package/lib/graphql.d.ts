import * as Category from "@distilled.cloud/core/category";
import { type FieldWithArgs, type Query, type TypeMeta } from "@distilled.cloud/core/graphql";
import * as S from "effect/Schema";
declare const GitHubForbidden_base: S.Class<GitHubForbidden, S.TaggedStruct<"GitHubForbidden", {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
/** The token lacks the permission the field or mutation requires. */
export declare class GitHubForbidden extends GitHubForbidden_base {
}
declare const GitHubInternalError_base: S.Class<GitHubInternalError, S.TaggedStruct<"GitHubInternalError", {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/** GitHub failed to resolve the query. */
export declare class GitHubInternalError extends GitHubInternalError_base {
}
declare const GitHubNotFound_base: S.Class<GitHubNotFound, S.TaggedStruct<"GitHubNotFound", {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
/** The node, or something the query refers to, does not exist or the token cannot see it. */
export declare class GitHubNotFound extends GitHubNotFound_base {
}
declare const GitHubRateLimited_base: S.Class<GitHubRateLimited, S.TaggedStruct<"GitHubRateLimited", {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/retryable": Category.RetryableInfo;
});
/** The token's GraphQL rate limit is exhausted. */
export declare class GitHubRateLimited extends GitHubRateLimited_base {
}
declare const GitHubUnprocessable_base: S.Class<GitHubUnprocessable, S.TaggedStruct<"GitHubUnprocessable", {
    message: S.String;
    code: S.optional<S.String>;
    path: S.optional<S.$Array<S.Union<readonly [S.String, S.Number]>>>;
    locations: S.optional<S.$Array<S.Struct<{
        readonly line: S.Number;
        readonly column: S.Number;
    }>>>;
    extensions: S.optional<S.Unknown>;
    traceId: S.optional<S.String>;
    status: S.optional<S.Number>;
    retryAfter: S.optional<S.Number>;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/** GitHub refused the mutation for the object's current state, e.g. a draft transition on a closed pull request. */
export declare class GitHubUnprocessable extends GitHubUnprocessable_base {
}
/** Errors every GitHub root field can return. */
export type GitHubGlobalError = GitHubForbidden | GitHubInternalError | GitHubNotFound | GitHubRateLimited | GitHubUnprocessable;
/** Every typed error the GitHub SDK declares. */
export type GitHubError = GitHubForbidden | GitHubInternalError | GitHubNotFound | GitHubRateLimited | GitHubUnprocessable;
/** The actor's type. */
export type ActorType = "TEAM" | "USER";
/** Properties by which Audit Log connections can be ordered. */
export type AuditLogOrderField = "CREATED_AT";
/** Represents an annotation's information level. */
export type CheckAnnotationLevel = "FAILURE" | "NOTICE" | "WARNING";
/** The possible states for a check suite or run conclusion. */
export type CheckConclusionState = "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT";
/** The possible states of a check run in a status rollup. */
export type CheckRunState = "ACTION_REQUIRED" | "CANCELLED" | "COMPLETED" | "FAILURE" | "IN_PROGRESS" | "NEUTRAL" | "PENDING" | "QUEUED" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | "WAITING";
/** The possible types of check runs. */
export type CheckRunType = "ALL" | "LATEST";
/** The possible states for a check suite or run status. */
export type CheckStatusState = "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING";
/** The lowest severity level at which code quality reviews need to be resolved before commits can be merged. */
export type CodeQualitySeverity = "ALL" | "ERRORS" | "NOTES" | "WARNINGS";
/** Collaborators affiliation level with a subject. */
export type CollaboratorAffiliation = "ALL" | "DIRECT" | "OUTSIDE";
/** A comment author association with repository. */
export type CommentAuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** The possible errors that will prevent a user from updating a comment. */
export type CommentCannotUpdateReason = "ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED";
/** Properties by which commit contribution connections can be ordered. */
export type CommitContributionOrderField = "COMMIT_COUNT" | "OCCURRED_AT";
/** The status of a git comparison between two refs. */
export type ComparisonStatus = "AHEAD" | "BEHIND" | "DIVERGED" | "IDENTICAL";
/** Varying levels of contributions from none to many. */
export type ContributionLevel = "FIRST_QUARTILE" | "FOURTH_QUARTILE" | "NONE" | "SECOND_QUARTILE" | "THIRD_QUARTILE";
/** The allowed value types for a custom property definition. */
export type CustomPropertyValueType = "MULTI_SELECT" | "SINGLE_SELECT" | "STRING" | "TRUE_FALSE" | "URL";
/** The possible base permissions for repositories. */
export type DefaultRepositoryPermissionField = "ADMIN" | "NONE" | "READ" | "WRITE";
/** The possible ecosystems of a dependency graph package. */
export type DependencyGraphEcosystem = "ACTIONS" | "COMPOSER" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT";
/** Properties by which deployment connections can be ordered. */
export type DeploymentOrderField = "CREATED_AT";
/** The possible protection rule types. */
export type DeploymentProtectionRuleType = "BRANCH_POLICY" | "REQUIRED_REVIEWERS" | "WAIT_TIMER";
/** The possible states for a deployment review. */
export type DeploymentReviewState = "APPROVED" | "REJECTED";
/** The possible states in which a deployment can be. */
export type DeploymentState = "ABANDONED" | "ACTIVE" | "DESTROYED" | "ERROR" | "FAILURE" | "INACTIVE" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "SUCCESS" | "WAITING";
/** The possible states for a deployment status. */
export type DeploymentStatusState = "ERROR" | "FAILURE" | "INACTIVE" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "SUCCESS" | "WAITING";
/** The possible sides of a diff. */
export type DiffSide = "LEFT" | "RIGHT";
/** The possible reasons for closing a discussion. */
export type DiscussionCloseReason = "DUPLICATE" | "OUTDATED" | "RESOLVED";
/** Properties by which discussion connections can be ordered. */
export type DiscussionOrderField = "CREATED_AT" | "UPDATED_AT";
/** Properties by which discussion poll option connections can be ordered. */
export type DiscussionPollOptionOrderField = "AUTHORED_ORDER" | "VOTE_COUNT";
/** The possible states of a discussion. */
export type DiscussionState = "CLOSED" | "OPEN";
/** The possible state reasons of a discussion. */
export type DiscussionStateReason = "DUPLICATE" | "OUTDATED" | "REOPENED" | "RESOLVED";
/** The possible reasons that a Dependabot alert was dismissed. */
export type DismissReason = "FIX_STARTED" | "INACCURATE" | "NOT_USED" | "NO_BANDWIDTH" | "TOLERABLE_RISK";
/** Properties by which enterprise administrator invitation connections can be ordered. */
export type EnterpriseAdministratorInvitationOrderField = "CREATED_AT";
/** The possible administrator roles in an enterprise account. */
export type EnterpriseAdministratorRole = "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED";
/** The possible values for the enterprise allow private repository forking policy value. */
export type EnterpriseAllowPrivateRepositoryForkingPolicyValue = "ENTERPRISE_ORGANIZATIONS" | "ENTERPRISE_ORGANIZATIONS_USER_ACCOUNTS" | "EVERYWHERE" | "SAME_ORGANIZATION" | "SAME_ORGANIZATION_USER_ACCOUNTS" | "USER_ACCOUNTS";
/** The possible values for the enterprise base repository permission setting. */
export type EnterpriseDefaultRepositoryPermissionSettingValue = "ADMIN" | "NONE" | "NO_POLICY" | "READ" | "WRITE";
/** The possible values for an enabled/no policy enterprise setting. */
export type EnterpriseDisallowedMethodsSettingValue = "INSECURE" | "NO_POLICY";
/** The possible values for an enabled/disabled enterprise setting. */
export type EnterpriseEnabledDisabledSettingValue = "DISABLED" | "ENABLED" | "NO_POLICY";
/** The possible values for an enabled/no policy enterprise setting. */
export type EnterpriseEnabledSettingValue = "ENABLED" | "NO_POLICY";
/** Properties by which enterprise member invitation connections can be ordered. */
export type EnterpriseMemberInvitationOrderField = "CREATED_AT";
/** Properties by which enterprise member connections can be ordered. */
export type EnterpriseMemberOrderField = "CREATED_AT" | "LOGIN";
/** The possible values for the enterprise members can create repositories setting. */
export type EnterpriseMembersCanCreateRepositoriesSettingValue = "ALL" | "DISABLED" | "NO_POLICY" | "PRIVATE" | "PUBLIC";
/** The possible values for the members can make purchases setting. */
export type EnterpriseMembersCanMakePurchasesSettingValue = "DISABLED" | "ENABLED";
/** The possible values we have for filtering Platform::Objects::User#enterprises. */
export type EnterpriseMembershipType = "ADMIN" | "ALL" | "BILLING_MANAGER" | "ORG_MEMBERSHIP";
/** Properties by which enterprise connections can be ordered. */
export type EnterpriseOrderField = "NAME";
/** Properties by which Enterprise Server installation connections can be ordered. */
export type EnterpriseServerInstallationOrderField = "CREATED_AT" | "CUSTOMER_NAME" | "HOST_NAME";
/** Properties by which Enterprise Server user account email connections can be ordered. */
export type EnterpriseServerUserAccountEmailOrderField = "EMAIL";
/** Properties by which Enterprise Server user account connections can be ordered. */
export type EnterpriseServerUserAccountOrderField = "LOGIN" | "REMOTE_CREATED_AT";
/** Properties by which Enterprise Server user accounts upload connections can be ordered. */
export type EnterpriseServerUserAccountsUploadOrderField = "CREATED_AT";
/** Synchronization state of the Enterprise Server user accounts upload */
export type EnterpriseServerUserAccountsUploadSyncState = "FAILURE" | "PENDING" | "SUCCESS";
/** Properties by which enterprise team member connections can be ordered. */
export type EnterpriseTeamMemberOrderField = "CREATED_AT" | "ID" | "LOGIN";
/** Properties by which enterprise team connections can be ordered. */
export type EnterpriseTeamOrderField = "CREATED_AT" | "ID" | "NAME";
/** Properties by which enterprise team organization connections can be ordered. */
export type EnterpriseTeamOrganizationOrderField = "CREATED_AT" | "ID" | "LOGIN";
/** The possible organization selection types for an enterprise team. */
export type EnterpriseTeamOrganizationSelectionType = "ALL" | "DISABLED" | "SELECTED";
/** The possible roles for enterprise membership. */
export type EnterpriseUserAccountMembershipRole = "MEMBER" | "OWNER" | "UNAFFILIATED";
/** The possible GitHub Enterprise deployments where this user can exist. */
export type EnterpriseUserDeployment = "CLOUD" | "SERVER";
/** Properties by which environments connections can be ordered */
export type EnvironmentOrderField = "NAME";
/** Properties by which environments connections can be ordered */
export type EnvironmentPinnedFilterField = "ALL" | "NONE" | "ONLY";
/** The possible viewed states of a file . */
export type FileViewedState = "DISMISSED" | "UNVIEWED" | "VIEWED";
/** The possible funding platforms for repository funding links. */
export type FundingPlatform = "BUY_ME_A_COFFEE" | "COMMUNITY_BRIDGE" | "CUSTOM" | "GITHUB" | "ISSUEHUNT" | "KO_FI" | "LFX_CROWDFUNDING" | "LIBERAPAY" | "OPEN_COLLECTIVE" | "PATREON" | "POLAR" | "THANKS_DEV" | "TIDELIFT";
/** Properties by which gist connections can be ordered. */
export type GistOrderField = "CREATED_AT" | "PUSHED_AT" | "UPDATED_AT";
/** The privacy of a Gist */
export type GistPrivacy = "ALL" | "PUBLIC" | "SECRET";
/** The state of a Git signature. */
export type GitSignatureState = "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
/** The possible states in which authentication can be configured with an identity provider. */
export type IdentityProviderConfigurationState = "CONFIGURED" | "ENFORCED" | "UNCONFIGURED";
/** The possible values for the IP allow list enabled setting. */
export type IpAllowListEnabledSettingValue = "DISABLED" | "ENABLED";
/** Properties by which IP allow list entry connections can be ordered. */
export type IpAllowListEntryOrderField = "ALLOW_LIST_VALUE" | "CREATED_AT";
/** The possible values for the IP allow list configuration for installed GitHub Apps setting. */
export type IpAllowListForInstalledAppsEnabledSettingValue = "DISABLED" | "ENABLED";
/** The possible values for the IP allow list user-level enforcement enabled setting. */
export type IpAllowListUserLevelEnforcementEnabledSettingValue = "DISABLED" | "ENABLED";
/** The possible state reasons of a closed issue. */
export type IssueClosedStateReason = "COMPLETED" | "DUPLICATE" | "NOT_PLANNED";
/** Properties by which issue comment connections can be ordered. */
export type IssueCommentOrderField = "UPDATED_AT";
/** The policy controlling who can create issues in a repository. */
export type IssueCreationPolicy = "ALL" | "COLLABORATORS_ONLY";
/** Properties by which issue dependencies can be ordered. */
export type IssueDependencyOrderField = "CREATED_AT" | "DEPENDENCY_ADDED_AT";
/** The confidence level associated with an agent's issue event action. */
export type IssueEventConfidenceLevel = "HIGH" | "LOW" | "MEDIUM";
/** The type of an issue field. */
export type IssueFieldDataType = "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
/** Properties by which issue field connections can be ordered. */
export type IssueFieldOrderField = "CREATED_AT" | "NAME";
/** The display color of a single-select field option. */
export type IssueFieldSingleSelectOptionColor = "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
/** The operation to perform on an issue field value. */
export type IssueFieldUpdateOperation = "ADD" | "CLEAR" | "REMOVE" | "SET";
/** The visibility of an issue field. */
export type IssueFieldVisibility = "ALL" | "ORG_ONLY";
/** Properties by which issue connections can be ordered. */
export type IssueOrderField = "COMMENTS" | "CREATED_AT" | "UPDATED_AT";
/** Properties by which related issues can be ordered. */
export type IssueRelatesToOrderField = "CREATED_AT" | "RELATES_TO_ADDED_AT";
/** Type of issue search performed */
export type IssueSearchType = "HYBRID" | "LEXICAL" | "SEMANTIC";
/** The possible states of an issue. */
export type IssueState = "CLOSED" | "OPEN";
/** The possible state reasons of an issue. */
export type IssueStateReason = "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | "REOPENED";
/** The possible item types found in a timeline. */
export type IssueTimelineItemsItemType = "ADDED_TO_PROJECT_EVENT" | "ADDED_TO_PROJECT_V2_EVENT" | "ASSIGNED_EVENT" | "BLOCKED_BY_ADDED_EVENT" | "BLOCKED_BY_REMOVED_EVENT" | "BLOCKING_ADDED_EVENT" | "BLOCKING_REMOVED_EVENT" | "CLOSED_EVENT" | "COMMENT_DELETED_EVENT" | "CONNECTED_EVENT" | "CONVERTED_FROM_DRAFT_EVENT" | "CONVERTED_NOTE_TO_ISSUE_EVENT" | "CONVERTED_TO_DISCUSSION_EVENT" | "CROSS_REFERENCED_EVENT" | "DEMILESTONED_EVENT" | "DISCONNECTED_EVENT" | "ISSUE_COMMENT" | "ISSUE_COMMENT_PINNED_EVENT" | "ISSUE_COMMENT_UNPINNED_EVENT" | "ISSUE_FIELD_ADDED_EVENT" | "ISSUE_FIELD_CHANGED_EVENT" | "ISSUE_FIELD_REMOVED_EVENT" | "ISSUE_TYPE_ADDED_EVENT" | "ISSUE_TYPE_CHANGED_EVENT" | "ISSUE_TYPE_REMOVED_EVENT" | "LABELED_EVENT" | "LOCKED_EVENT" | "MARKED_AS_DUPLICATE_EVENT" | "MENTIONED_EVENT" | "MILESTONED_EVENT" | "MOVED_COLUMNS_IN_PROJECT_EVENT" | "PARENT_ISSUE_ADDED_EVENT" | "PARENT_ISSUE_REMOVED_EVENT" | "PINNED_EVENT" | "PROJECT_V2_ITEM_STATUS_CHANGED_EVENT" | "REFERENCED_EVENT" | "REMOVED_FROM_PROJECT_EVENT" | "REMOVED_FROM_PROJECT_V2_EVENT" | "RENAMED_TITLE_EVENT" | "REOPENED_EVENT" | "SUBSCRIBED_EVENT" | "SUB_ISSUE_ADDED_EVENT" | "SUB_ISSUE_REMOVED_EVENT" | "TRANSFERRED_EVENT" | "UNASSIGNED_EVENT" | "UNLABELED_EVENT" | "UNLOCKED_EVENT" | "UNMARKED_AS_DUPLICATE_EVENT" | "UNPINNED_EVENT" | "UNSUBSCRIBED_EVENT" | "USER_BLOCKED_EVENT";
/** The possible color for an issue type */
export type IssueTypeColor = "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
/** Properties by which issue type connections can be ordered. */
export type IssueTypeOrderField = "CREATED_AT" | "NAME";
/** Properties by which label connections can be ordered. */
export type LabelOrderField = "CREATED_AT" | "ISSUE_COUNT" | "NAME";
/** Properties by which language connections can be ordered. */
export type LanguageOrderField = "SIZE";
/** Reason why a semantic or hybrid issue search fell back to lexical search */
export type LexicalFallbackReason = "NON_ISSUE_TARGET" | "NO_ACCESSIBLE_REPOS" | "NO_TEXT_TERMS" | "ONLY_NON_SEMANTIC_FIELDS_REQUESTED" | "OR_BOOLEAN_NOT_SUPPORTED" | "QUOTED_TEXT" | "SERVER_ERROR";
/** The possible reasons that an issue or pull request was locked. */
export type LockReason = "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED";
/** Properties by which mannequins can be ordered. */
export type MannequinOrderField = "CREATED_AT" | "LOGIN";
/** The possible default commit messages for merges. */
export type MergeCommitMessage = "BLANK" | "PR_BODY" | "PR_TITLE";
/** The possible default commit titles for merges. */
export type MergeCommitTitle = "MERGE_MESSAGE" | "PR_TITLE";
/** The possible states for a merge queue entry. */
export type MergeQueueEntryState = "AWAITING_CHECKS" | "LOCKED" | "MERGEABLE" | "QUEUED" | "UNMERGEABLE";
/** When set to ALLGREEN, the merge commit created by merge queue for each PR in the
group must pass all required checks to merge. When set to HEADGREEN, only the
commit at the head of the merge group, i.e. the commit containing changes from
all of the PRs in the group, must pass its required checks to merge. */
export type MergeQueueGroupingStrategy = "ALLGREEN" | "HEADGREEN";
/** Method to use when merging changes from queued pull requests. */
export type MergeQueueMergeMethod = "MERGE" | "REBASE" | "SQUASH";
/** The possible merging strategies for a merge queue. */
export type MergeQueueMergingStrategy = "ALLGREEN" | "HEADGREEN";
/** Detailed status information about a pull request merge. */
export type MergeStateStatus = "BEHIND" | "BLOCKED" | "CLEAN" | "DIRTY" | "DRAFT" | "HAS_HOOKS" | "UNKNOWN" | "UNSTABLE";
/** Whether or not a PullRequest can be merged. */
export type MergeableState = "CONFLICTING" | "MERGEABLE" | "UNKNOWN";
/** Represents the different GitHub Enterprise Importer (GEI) migration sources. */
export type MigrationSourceType = "AZURE_DEVOPS" | "BITBUCKET_SERVER" | "GITHUB_ARCHIVE" | "GITLAB";
/** The GitHub Enterprise Importer (GEI) migration state. */
export type MigrationState = "FAILED" | "FAILED_VALIDATION" | "IN_PROGRESS" | "NOT_STARTED" | "PENDING_VALIDATION" | "QUEUED" | "SUCCEEDED";
/** Properties by which milestone connections can be ordered. */
export type MilestoneOrderField = "CREATED_AT" | "DUE_DATE" | "NUMBER" | "UPDATED_AT";
/** The possible states of a milestone. */
export type MilestoneState = "CLOSED" | "OPEN";
/** The possible values for the notification restriction setting. */
export type NotificationRestrictionSettingValue = "DISABLED" | "ENABLED";
/** The OIDC identity provider type */
export type OIDCProviderType = "AAD";
/** The state of an OAuth application when it was created. */
export type OauthApplicationCreateAuditEntryState = "ACTIVE" | "PENDING_DELETION" | "SUSPENDED";
/** The corresponding operation type for the action */
export type OperationType = "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER";
/** Possible directions in which to order a list of items when provided an `orderBy` argument. */
export type OrderDirection = "ASC" | "DESC";
/** The permissions available to members on an Organization. */
export type OrgAddMemberAuditEntryPermission = "ADMIN" | "READ";
/** The billing plans available for organizations. */
export type OrgCreateAuditEntryBillingPlan = "BUSINESS" | "BUSINESS_PLUS" | "FREE" | "TIERED_PER_SEAT" | "UNLIMITED";
/** Properties by which enterprise owners can be ordered. */
export type OrgEnterpriseOwnerOrderField = "LOGIN";
/** The reason a billing manager was removed from an Organization. */
export type OrgRemoveBillingManagerAuditEntryReason = "SAML_EXTERNAL_IDENTITY_MISSING" | "SAML_SSO_ENFORCEMENT_REQUIRES_EXTERNAL_IDENTITY" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE";
/** The type of membership a user has with an Organization. */
export type OrgRemoveMemberAuditEntryMembershipType = "ADMIN" | "BILLING_MANAGER" | "DIRECT_MEMBER" | "OUTSIDE_COLLABORATOR" | "SUSPENDED" | "UNAFFILIATED";
/** The reason a member was removed from an Organization. */
export type OrgRemoveMemberAuditEntryReason = "SAML_EXTERNAL_IDENTITY_MISSING" | "SAML_SSO_ENFORCEMENT_REQUIRES_EXTERNAL_IDENTITY" | "TWO_FACTOR_ACCOUNT_RECOVERY" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE" | "USER_ACCOUNT_DELETED";
/** The type of membership a user has with an Organization. */
export type OrgRemoveOutsideCollaboratorAuditEntryMembershipType = "BILLING_MANAGER" | "OUTSIDE_COLLABORATOR" | "UNAFFILIATED";
/** The reason an outside collaborator was removed from an Organization. */
export type OrgRemoveOutsideCollaboratorAuditEntryReason = "SAML_EXTERNAL_IDENTITY_MISSING" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE";
/** The default permission a repository can have in an Organization. */
export type OrgUpdateDefaultRepositoryPermissionAuditEntryPermission = "ADMIN" | "NONE" | "READ" | "WRITE";
/** The permissions available to members on an Organization. */
export type OrgUpdateMemberAuditEntryPermission = "ADMIN" | "READ";
/** The permissions available for repository creation on an Organization. */
export type OrgUpdateMemberRepositoryCreationPermissionAuditEntryVisibility = "ALL" | "INTERNAL" | "NONE" | "PRIVATE" | "PRIVATE_INTERNAL" | "PUBLIC" | "PUBLIC_INTERNAL" | "PUBLIC_PRIVATE";
/** The possible organization invitation roles. */
export type OrganizationInvitationRole = "ADMIN" | "BILLING_MANAGER" | "DIRECT_MEMBER" | "REINSTATE";
/** The possible organization invitation sources. */
export type OrganizationInvitationSource = "ENTERPRISE_ORGANIZATION_CREATION" | "MEMBER" | "SCIM" | "UNKNOWN";
/** The possible organization invitation types. */
export type OrganizationInvitationType = "EMAIL" | "USER";
/** The possible roles within an organization for its members. */
export type OrganizationMemberRole = "ADMIN" | "MEMBER";
/** The possible values for the members can create repositories setting on an organization. */
export type OrganizationMembersCanCreateRepositoriesSettingValue = "ALL" | "DISABLED" | "INTERNAL" | "PRIVATE";
/** The Octoshift Organization migration state. */
export type OrganizationMigrationState = "FAILED" | "FAILED_VALIDATION" | "IN_PROGRESS" | "NOT_STARTED" | "PENDING_VALIDATION" | "POST_REPO_MIGRATION" | "PRE_REPO_MIGRATION" | "QUEUED" | "REPO_MIGRATION" | "SUCCEEDED";
/** Properties by which organization connections can be ordered. */
export type OrganizationOrderField = "CREATED_AT" | "LOGIN";
/** Properties by which package file connections can be ordered. */
export type PackageFileOrderField = "CREATED_AT";
/** Properties by which package connections can be ordered. */
export type PackageOrderField = "CREATED_AT";
/** The possible types of a package. */
export type PackageType = "DEBIAN" | "DOCKER" | "MAVEN" | "NPM" | "NUGET" | "PYPI" | "RUBYGEMS";
/** Properties by which package version connections can be ordered. */
export type PackageVersionOrderField = "CREATED_AT";
/** The possible types of patch statuses. */
export type PatchStatus = "ADDED" | "CHANGED" | "COPIED" | "DELETED" | "MODIFIED" | "RENAMED";
/** The kind of pending issue suggestion being applied. */
export type PendingIssueSuggestionKind = "ASSIGNEE" | "CLOSE" | "FIELD" | "LABEL" | "TYPE";
/** Represents items that can be pinned to a profile page or dashboard. */
export type PinnableItemType = "GIST" | "ISSUE" | "ORGANIZATION" | "PROJECT" | "PULL_REQUEST" | "REPOSITORY" | "TEAM" | "USER";
/** Preconfigured gradients that may be used to style discussions pinned within a repository. */
export type PinnedDiscussionGradient = "BLUE_MINT" | "BLUE_PURPLE" | "PINK_BLUE" | "PURPLE_CORAL" | "RED_ORANGE";
/** Preconfigured background patterns that may be used to style discussions pinned within a repository. */
export type PinnedDiscussionPattern = "CHEVRON_UP" | "DOT" | "DOT_FILL" | "HEART_FILL" | "PLUS" | "ZAP";
/** Properties by which pinned environments connections can be ordered */
export type PinnedEnvironmentOrderField = "POSITION";
/** The possible archived states of a project card. */
export type ProjectCardArchivedState = "ARCHIVED" | "NOT_ARCHIVED";
/** Various content states of a ProjectCard */
export type ProjectCardState = "CONTENT_ONLY" | "NOTE_ONLY" | "REDACTED";
/** The semantic purpose of the column - todo, in progress, or done. */
export type ProjectColumnPurpose = "DONE" | "IN_PROGRESS" | "TODO";
/** Properties by which project connections can be ordered. */
export type ProjectOrderField = "CREATED_AT" | "NAME" | "UPDATED_AT";
/** State of the project; either 'open' or 'closed' */
export type ProjectState = "CLOSED" | "OPEN";
/** GitHub-provided templates for Projects */
export type ProjectTemplate = "AUTOMATED_KANBAN_V2" | "AUTOMATED_REVIEWS_KANBAN" | "BASIC_KANBAN" | "BUG_TRIAGE";
/** The type of a project field. */
export type ProjectV2CustomFieldType = "DATE" | "ITERATION" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
/** Properties by which project v2 field connections can be ordered. */
export type ProjectV2FieldOrderField = "CREATED_AT" | "NAME" | "POSITION";
/** The type of a project field. */
export type ProjectV2FieldType = "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
/** The possible archived states of a `ProjectV2Item`. */
export type ProjectV2ItemArchivedState = "ARCHIVED" | "NOT_ARCHIVED";
/** Properties by which project v2 item field value connections can be ordered. */
export type ProjectV2ItemFieldValueOrderField = "POSITION";
/** Properties by which project v2 item connections can be ordered. */
export type ProjectV2ItemOrderField = "POSITION";
/** The type of a project item. */
export type ProjectV2ItemType = "DRAFT_ISSUE" | "ISSUE" | "PULL_REQUEST" | "REDACTED";
/** Properties by which projects can be ordered. */
export type ProjectV2OrderField = "CREATED_AT" | "NUMBER" | "TITLE" | "UPDATED_AT";
/** The possible roles of a collaborator on a project. */
export type ProjectV2PermissionLevel = "ADMIN" | "READ" | "WRITE";
/** The possible roles of a collaborator on a project. */
export type ProjectV2Roles = "ADMIN" | "NONE" | "READER" | "WRITER";
/** The display color of a single-select field option. */
export type ProjectV2SingleSelectFieldOptionColor = "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
/** The possible states of a project v2. */
export type ProjectV2State = "CLOSED" | "OPEN";
/** Properties by which project v2 status updates can be ordered. */
export type ProjectV2StatusUpdateOrderField = "CREATED_AT";
/** The possible statuses of a project v2. */
export type ProjectV2StatusUpdateStatus = "AT_RISK" | "COMPLETE" | "INACTIVE" | "OFF_TRACK" | "ON_TRACK";
/** The layout of a project v2 view. */
export type ProjectV2ViewLayout = "BOARD_LAYOUT" | "ROADMAP_LAYOUT" | "TABLE_LAYOUT";
/** Properties by which project v2 view connections can be ordered. */
export type ProjectV2ViewOrderField = "CREATED_AT" | "NAME" | "POSITION";
/** Properties by which project workflows can be ordered. */
export type ProjectV2WorkflowsOrderField = "CREATED_AT" | "NAME" | "NUMBER" | "UPDATED_AT";
/** Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. */
export type PullRequestAllowedMergeMethods = "MERGE" | "REBASE" | "SQUASH";
/** The possible methods for updating a pull request's head branch with the base branch. */
export type PullRequestBranchUpdateMethod = "MERGE" | "REBASE";
/** The policy controlling who can create pull requests in a repository. */
export type PullRequestCreationPolicy = "ALL" | "COLLABORATORS_ONLY";
/** Represents available types of methods to use when merging a pull request. */
export type PullRequestMergeMethod = "MERGE" | "REBASE" | "SQUASH";
/** Properties by which pull_requests connections can be ordered. */
export type PullRequestOrderField = "CREATED_AT" | "UPDATED_AT";
/** The possible states of a pull request review comment. */
export type PullRequestReviewCommentState = "PENDING" | "SUBMITTED";
/** The review status of a pull request. */
export type PullRequestReviewDecision = "APPROVED" | "CHANGES_REQUESTED" | "REVIEW_REQUIRED";
/** The possible events to perform on a pull request review. */
export type PullRequestReviewEvent = "APPROVE" | "COMMENT" | "DISMISS" | "REQUEST_CHANGES";
/** The possible states of a pull request review. */
export type PullRequestReviewState = "APPROVED" | "CHANGES_REQUESTED" | "COMMENTED" | "DISMISSED" | "PENDING";
/** The possible reasons a pull request review thread was resolved. */
export type PullRequestReviewThreadResolutionReason = "ADDRESSED" | "INVALID" | "WONT_FIX";
/** The possible subject types of a pull request review comment. */
export type PullRequestReviewThreadSubjectType = "FILE" | "LINE";
/** The possible states of a pull request. */
export type PullRequestState = "CLOSED" | "MERGED" | "OPEN";
/** The possible item types found in a timeline. */
export type PullRequestTimelineItemsItemType = "ADDED_TO_MERGE_QUEUE_EVENT" | "ADDED_TO_PROJECT_EVENT" | "ADDED_TO_PROJECT_V2_EVENT" | "ADDED_TO_STACK_EVENT" | "ARCHIVED_EVENT" | "ASSIGNED_EVENT" | "AUTOMATIC_BASE_CHANGE_FAILED_EVENT" | "AUTOMATIC_BASE_CHANGE_SUCCEEDED_EVENT" | "AUTO_MERGE_DISABLED_EVENT" | "AUTO_MERGE_ENABLED_EVENT" | "AUTO_REBASE_ENABLED_EVENT" | "AUTO_SQUASH_ENABLED_EVENT" | "BASE_REF_CHANGED_EVENT" | "BASE_REF_DELETED_EVENT" | "BASE_REF_FORCE_PUSHED_EVENT" | "BLOCKED_BY_ADDED_EVENT" | "BLOCKED_BY_REMOVED_EVENT" | "BLOCKING_ADDED_EVENT" | "BLOCKING_REMOVED_EVENT" | "CLOSED_EVENT" | "COMMENT_DELETED_EVENT" | "CONNECTED_EVENT" | "CONVERTED_FROM_DRAFT_EVENT" | "CONVERTED_NOTE_TO_ISSUE_EVENT" | "CONVERTED_TO_DISCUSSION_EVENT" | "CONVERT_TO_DRAFT_EVENT" | "CROSS_REFERENCED_EVENT" | "DEMILESTONED_EVENT" | "DEPLOYED_EVENT" | "DEPLOYMENT_ENVIRONMENT_CHANGED_EVENT" | "DISCONNECTED_EVENT" | "HEAD_REF_DELETED_EVENT" | "HEAD_REF_FORCE_PUSHED_EVENT" | "HEAD_REF_RESTORED_EVENT" | "ISSUE_COMMENT" | "ISSUE_COMMENT_PINNED_EVENT" | "ISSUE_COMMENT_UNPINNED_EVENT" | "ISSUE_FIELD_ADDED_EVENT" | "ISSUE_FIELD_CHANGED_EVENT" | "ISSUE_FIELD_REMOVED_EVENT" | "ISSUE_TYPE_ADDED_EVENT" | "ISSUE_TYPE_CHANGED_EVENT" | "ISSUE_TYPE_REMOVED_EVENT" | "LABELED_EVENT" | "LOCKED_EVENT" | "MARKED_AS_DUPLICATE_EVENT" | "MENTIONED_EVENT" | "MERGED_EVENT" | "MILESTONED_EVENT" | "MOVED_COLUMNS_IN_PROJECT_EVENT" | "PARENT_ISSUE_ADDED_EVENT" | "PARENT_ISSUE_REMOVED_EVENT" | "PINNED_EVENT" | "PROJECT_V2_ITEM_STATUS_CHANGED_EVENT" | "PULL_REQUEST_COMMIT" | "PULL_REQUEST_COMMIT_COMMENT_THREAD" | "PULL_REQUEST_REVIEW" | "PULL_REQUEST_REVIEW_THREAD" | "PULL_REQUEST_REVISION_MARKER" | "READY_FOR_REVIEW_EVENT" | "REFERENCED_EVENT" | "REMOVED_FROM_MERGE_QUEUE_EVENT" | "REMOVED_FROM_PROJECT_EVENT" | "REMOVED_FROM_PROJECT_V2_EVENT" | "REMOVED_FROM_STACK_EVENT" | "RENAMED_TITLE_EVENT" | "REOPENED_EVENT" | "REVIEW_DISMISSED_EVENT" | "REVIEW_REQUESTED_EVENT" | "REVIEW_REQUEST_REMOVED_EVENT" | "SUBSCRIBED_EVENT" | "SUB_ISSUE_ADDED_EVENT" | "SUB_ISSUE_REMOVED_EVENT" | "TRANSFERRED_EVENT" | "UNARCHIVED_EVENT" | "UNASSIGNED_EVENT" | "UNLABELED_EVENT" | "UNLOCKED_EVENT" | "UNMARKED_AS_DUPLICATE_EVENT" | "UNPINNED_EVENT" | "UNSUBSCRIBED_EVENT" | "USER_BLOCKED_EVENT";
/** The possible target states when updating a pull request. */
export type PullRequestUpdateState = "CLOSED" | "OPEN";
/** Emojis that can be attached to Issues, Pull Requests and Comments. */
export type ReactionContent = "CONFUSED" | "EYES" | "HEART" | "HOORAY" | "LAUGH" | "ROCKET" | "THUMBS_DOWN" | "THUMBS_UP";
/** A list of fields that reactions can be ordered by. */
export type ReactionOrderField = "CREATED_AT";
/** Properties by which ref connections can be ordered. */
export type RefOrderField = "ALPHABETICAL" | "TAG_COMMIT_DATE";
/** Properties by which release connections can be ordered. */
export type ReleaseOrderField = "CREATED_AT" | "NAME";
/** The privacy of a repository */
export type RepoAccessAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The privacy of a repository */
export type RepoAddMemberAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The privacy of a repository */
export type RepoArchivedAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The merge options available for pull requests to this repository. */
export type RepoChangeMergeSettingAuditEntryMergeType = "MERGE" | "REBASE" | "SQUASH";
/** The privacy of a repository */
export type RepoCreateAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The privacy of a repository */
export type RepoDestroyAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The privacy of a repository */
export type RepoRemoveMemberAuditEntryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The reasons a piece of content can be reported or minimized. */
export type ReportedContentClassifiers = "ABUSE" | "DUPLICATE" | "LOW_QUALITY" | "OFF_TOPIC" | "OUTDATED" | "RESOLVED" | "SPAM";
/** The affiliation of a user to a repository */
export type RepositoryAffiliation = "COLLABORATOR" | "ORGANIZATION_MEMBER" | "OWNER";
/** The reason a repository is listed as 'contributed'. */
export type RepositoryContributionType = "COMMIT" | "ISSUE" | "PULL_REQUEST" | "PULL_REQUEST_REVIEW" | "REPOSITORY";
/** The allowed actors who can edit the values of a custom property. */
export type RepositoryCustomPropertyValuesEditableBy = "ORG_ACTORS" | "ORG_AND_REPO_ACTORS";
/** A repository interaction limit. */
export type RepositoryInteractionLimit = "COLLABORATORS_ONLY" | "CONTRIBUTORS_ONLY" | "EXISTING_USERS" | "NO_LIMIT";
/** The length for a repository interaction limit to be enabled for. */
export type RepositoryInteractionLimitExpiry = "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "SIX_MONTHS" | "THREE_DAYS";
/** Indicates where an interaction limit is configured. */
export type RepositoryInteractionLimitOrigin = "ORGANIZATION" | "REPOSITORY" | "USER";
/** Properties by which repository invitation connections can be ordered. */
export type RepositoryInvitationOrderField = "CREATED_AT";
/** The possible reasons a given repository could be in a locked state. */
export type RepositoryLockReason = "BILLING" | "MIGRATING" | "MOVING" | "RENAME" | "TRADE_RESTRICTION" | "TRANSFERRING_OWNERSHIP";
/** Possible directions in which to order a list of repository migrations when provided an `orderBy` argument. */
export type RepositoryMigrationOrderDirection = "ASC" | "DESC";
/** Properties by which repository migrations can be ordered. */
export type RepositoryMigrationOrderField = "CREATED_AT";
/** Properties by which repository connections can be ordered. */
export type RepositoryOrderField = "CREATED_AT" | "NAME" | "PUSHED_AT" | "STARGAZERS" | "UPDATED_AT";
/** The access level to a repository */
export type RepositoryPermission = "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE";
/** The privacy of a repository */
export type RepositoryPrivacy = "PRIVATE" | "PUBLIC";
/** Properties by which repository rule connections can be ordered. */
export type RepositoryRuleOrderField = "CREATED_AT" | "TYPE" | "UPDATED_AT";
/** The rule types supported in rulesets */
export type RepositoryRuleType = "AUTHORIZATION" | "BRANCH_NAME_PATTERN" | "CODE_COVERAGE" | "CODE_QUALITY" | "CODE_SCANNING" | "COMMITTER_EMAIL_PATTERN" | "COMMIT_AUTHOR_EMAIL_PATTERN" | "COMMIT_MESSAGE_PATTERN" | "COPILOT_CODE_REVIEW" | "CREATION" | "DELETION" | "FILE_EXTENSION_RESTRICTION" | "FILE_PATH_RESTRICTION" | "LICENSE_COMPLIANCE_SCANNING" | "LOCK_BRANCH" | "MAX_FILE_PATH_LENGTH" | "MAX_FILE_SIZE" | "MAX_REF_UPDATES" | "MERGE_QUEUE" | "MERGE_QUEUE_LOCKED_REF" | "NON_FAST_FORWARD" | "PULL_REQUEST" | "REQUIRED_DEPLOYMENTS" | "REQUIRED_LINEAR_HISTORY" | "REQUIRED_REVIEW_THREAD_RESOLUTION" | "REQUIRED_SIGNATURES" | "REQUIRED_STATUS_CHECKS" | "REQUIRED_WORKFLOW_STATUS_CHECKS" | "SECRET_SCANNING" | "TAG" | "TAG_NAME_PATTERN" | "UPDATE" | "WORKFLOWS" | "WORKFLOW_UPDATES";
/** The bypass mode for a specific actor on a ruleset. */
export type RepositoryRulesetBypassActorBypassMode = "ALWAYS" | "EXEMPT" | "PULL_REQUEST";
/** The targets supported for rulesets. */
export type RepositoryRulesetTarget = "BRANCH" | "PUSH" | "REPOSITORY" | "TAG";
/** The possible filters for suggested actors in a repository */
export type RepositorySuggestedActorFilter = "CAN_BE_ASSIGNED" | "CAN_BE_AUTHOR";
/** The repository's visibility level. */
export type RepositoryVisibility = "INTERNAL" | "PRIVATE" | "PUBLIC";
/** The possible relationships of an alert's dependency. */
export type RepositoryVulnerabilityAlertDependencyRelationship = "DIRECT" | "INCONCLUSIVE" | "TRANSITIVE" | "UNKNOWN";
/** The possible scopes of an alert's dependency. */
export type RepositoryVulnerabilityAlertDependencyScope = "DEVELOPMENT" | "RUNTIME";
/** The possible states of an alert */
export type RepositoryVulnerabilityAlertState = "AUTO_DISMISSED" | "DISMISSED" | "FIXED" | "OPEN";
/** The possible states that can be requested when creating a check run. */
export type RequestableCheckStatusState = "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "WAITING";
/** Possible roles a user may have in relation to an organization. */
export type RoleInOrganization = "DIRECT_MEMBER" | "OWNER" | "UNAFFILIATED";
/** The level of enforcement for a rule or ruleset. */
export type RuleEnforcement = "ACTIVE" | "DISABLED" | "EVALUATE";
/** The possible digest algorithms used to sign SAML requests for an identity provider. */
export type SamlDigestAlgorithm = "SHA1" | "SHA256" | "SHA384" | "SHA512";
/** The possible signature algorithms used to sign SAML requests for a Identity Provider. */
export type SamlSignatureAlgorithm = "RSA_SHA1" | "RSA_SHA256" | "RSA_SHA384" | "RSA_SHA512";
/** Properties by which saved reply connections can be ordered. */
export type SavedReplyOrderField = "UPDATED_AT";
/** Represents the individual results of a search. */
export type SearchType = "DISCUSSION" | "ISSUE" | "ISSUE_ADVANCED" | "ISSUE_HYBRID" | "ISSUE_SEMANTIC" | "REPOSITORY" | "USER";
/** Classification of the advisory. */
export type SecurityAdvisoryClassification = "GENERAL" | "MALWARE";
/** The possible ecosystems of a security vulnerability's package. */
export type SecurityAdvisoryEcosystem = "ACTIONS" | "COMPOSER" | "ERLANG" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT";
/** Identifier formats available for advisories. */
export type SecurityAdvisoryIdentifierType = "CVE" | "GHSA";
/** Properties by which security advisory connections can be ordered. */
export type SecurityAdvisoryOrderField = "EPSS_PERCENTAGE" | "EPSS_PERCENTILE" | "PUBLISHED_AT" | "UPDATED_AT";
/** Severity of the vulnerability. */
export type SecurityAdvisorySeverity = "CRITICAL" | "HIGH" | "LOW" | "MODERATE" | "UNKNOWN";
/** Properties by which security vulnerability connections can be ordered. */
export type SecurityVulnerabilityOrderField = "UPDATED_AT";
/** Software or company that hosts social media accounts. */
export type SocialAccountProvider = "BLUESKY" | "FACEBOOK" | "GENERIC" | "HOMETOWN" | "INSTAGRAM" | "LINKEDIN" | "MASTODON" | "NPM" | "REDDIT" | "THREADS" | "TWITCH" | "TWITTER" | "YOUTUBE";
/** Properties by which sponsor and lifetime value connections can be ordered. */
export type SponsorAndLifetimeValueOrderField = "LIFETIME_VALUE" | "SPONSOR_LOGIN" | "SPONSOR_RELEVANCE";
/** Properties by which sponsor connections can be ordered. */
export type SponsorOrderField = "LOGIN" | "RELEVANCE";
/** Properties by which sponsorable connections can be ordered. */
export type SponsorableOrderField = "LOGIN";
/** The possible actions that GitHub Sponsors activities can represent. */
export type SponsorsActivityAction = "CANCELLED_SPONSORSHIP" | "NEW_SPONSORSHIP" | "PENDING_CHANGE" | "REFUND" | "SPONSOR_MATCH_DISABLED" | "TIER_CHANGE";
/** Properties by which GitHub Sponsors activity connections can be ordered. */
export type SponsorsActivityOrderField = "TIMESTAMP";
/** The possible time periods for which Sponsors activities can be requested. */
export type SponsorsActivityPeriod = "ALL" | "DAY" | "MONTH" | "WEEK";
/** Represents countries or regions for billing and residence for a GitHub Sponsors profile. */
export type SponsorsCountryOrRegionCode = "AD" | "AE" | "AF" | "AG" | "AI" | "AL" | "AM" | "AO" | "AQ" | "AR" | "AS" | "AT" | "AU" | "AW" | "AX" | "AZ" | "BA" | "BB" | "BD" | "BE" | "BF" | "BG" | "BH" | "BI" | "BJ" | "BL" | "BM" | "BN" | "BO" | "BQ" | "BR" | "BS" | "BT" | "BV" | "BW" | "BY" | "BZ" | "CA" | "CC" | "CD" | "CF" | "CG" | "CH" | "CI" | "CK" | "CL" | "CM" | "CN" | "CO" | "CR" | "CV" | "CW" | "CX" | "CY" | "CZ" | "DE" | "DJ" | "DK" | "DM" | "DO" | "DZ" | "EC" | "EE" | "EG" | "EH" | "ER" | "ES" | "ET" | "FI" | "FJ" | "FK" | "FM" | "FO" | "FR" | "GA" | "GB" | "GD" | "GE" | "GF" | "GG" | "GH" | "GI" | "GL" | "GM" | "GN" | "GP" | "GQ" | "GR" | "GS" | "GT" | "GU" | "GW" | "GY" | "HK" | "HM" | "HN" | "HR" | "HT" | "HU" | "ID" | "IE" | "IL" | "IM" | "IN" | "IO" | "IQ" | "IR" | "IS" | "IT" | "JE" | "JM" | "JO" | "JP" | "KE" | "KG" | "KH" | "KI" | "KM" | "KN" | "KR" | "KW" | "KY" | "KZ" | "LA" | "LB" | "LC" | "LI" | "LK" | "LR" | "LS" | "LT" | "LU" | "LV" | "LY" | "MA" | "MC" | "MD" | "ME" | "MF" | "MG" | "MH" | "MK" | "ML" | "MM" | "MN" | "MO" | "MP" | "MQ" | "MR" | "MS" | "MT" | "MU" | "MV" | "MW" | "MX" | "MY" | "MZ" | "NA" | "NC" | "NE" | "NF" | "NG" | "NI" | "NL" | "NO" | "NP" | "NR" | "NU" | "NZ" | "OM" | "PA" | "PE" | "PF" | "PG" | "PH" | "PK" | "PL" | "PM" | "PN" | "PR" | "PS" | "PT" | "PW" | "PY" | "QA" | "RE" | "RO" | "RS" | "RU" | "RW" | "SA" | "SB" | "SC" | "SD" | "SE" | "SG" | "SH" | "SI" | "SJ" | "SK" | "SL" | "SM" | "SN" | "SO" | "SR" | "SS" | "ST" | "SV" | "SX" | "SY" | "SZ" | "TC" | "TD" | "TF" | "TG" | "TH" | "TJ" | "TK" | "TL" | "TM" | "TN" | "TO" | "TR" | "TT" | "TV" | "TW" | "TZ" | "UA" | "UG" | "UM" | "US" | "UY" | "UZ" | "VA" | "VC" | "VE" | "VG" | "VI" | "VN" | "VU" | "WF" | "WS" | "YE" | "YT" | "ZA" | "ZM" | "ZW";
/** The different kinds of goals a GitHub Sponsors member can have. */
export type SponsorsGoalKind = "MONTHLY_SPONSORSHIP_AMOUNT" | "TOTAL_SPONSORS_COUNT";
/** The different kinds of records that can be featured on a GitHub Sponsors profile page. */
export type SponsorsListingFeaturedItemFeatureableType = "REPOSITORY" | "USER";
/** Properties by which Sponsors tiers connections can be ordered. */
export type SponsorsTierOrderField = "CREATED_AT" | "MONTHLY_PRICE_IN_CENTS";
/** Properties by which sponsorship update connections can be ordered. */
export type SponsorshipNewsletterOrderField = "CREATED_AT";
/** Properties by which sponsorship connections can be ordered. */
export type SponsorshipOrderField = "CREATED_AT";
/** How payment was made for funding a GitHub Sponsors sponsorship. */
export type SponsorshipPaymentSource = "GITHUB" | "PATREON";
/** The privacy of a sponsorship */
export type SponsorshipPrivacy = "PRIVATE" | "PUBLIC";
/** The possible default commit messages for squash merges. */
export type SquashMergeCommitMessage = "BLANK" | "COMMIT_MESSAGES" | "PR_BODY";
/** The possible default commit titles for squash merges. */
export type SquashMergeCommitTitle = "COMMIT_OR_PR_TITLE" | "PR_TITLE";
/** Properties by which star connections can be ordered. */
export type StarOrderField = "STARRED_AT";
/** The possible commit status states. */
export type StatusState = "ERROR" | "EXPECTED" | "FAILURE" | "PENDING" | "SUCCESS";
/** The possible states of a subscription. */
export type SubscriptionState = "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED";
/** Properties by which team member connections can be ordered. */
export type TeamMemberOrderField = "CREATED_AT" | "LOGIN";
/** The possible team member roles; either 'maintainer' or 'member'. */
export type TeamMemberRole = "MAINTAINER" | "MEMBER";
/** Defines which types of team members are included in the returned list. Can be one of IMMEDIATE, CHILD_TEAM or ALL. */
export type TeamMembershipType = "ALL" | "CHILD_TEAM" | "IMMEDIATE";
/** The possible team notification values. */
export type TeamNotificationSetting = "NOTIFICATIONS_DISABLED" | "NOTIFICATIONS_ENABLED";
/** Properties by which team connections can be ordered. */
export type TeamOrderField = "NAME";
/** The possible team privacy values. */
export type TeamPrivacy = "SECRET" | "VISIBLE";
/** Properties by which team repository connections can be ordered. */
export type TeamRepositoryOrderField = "CREATED_AT" | "NAME" | "PERMISSION" | "PUSHED_AT" | "STARGAZERS" | "UPDATED_AT";
/** The possible team review assignment algorithms */
export type TeamReviewAssignmentAlgorithm = "LOAD_BALANCE" | "ROUND_ROBIN";
/** The role of a user on a team. */
export type TeamRole = "ADMIN" | "MEMBER";
/** The possible states of a thread subscription form action */
export type ThreadSubscriptionFormAction = "NONE" | "SUBSCRIBE" | "UNSUBSCRIBE";
/** The possible states of a subscription. */
export type ThreadSubscriptionState = "DISABLED" | "IGNORING_LIST" | "IGNORING_THREAD" | "NONE" | "SUBSCRIBED_TO_LIST" | "SUBSCRIBED_TO_THREAD" | "SUBSCRIBED_TO_THREAD_EVENTS" | "SUBSCRIBED_TO_THREAD_TYPE" | "UNAVAILABLE";
/** Reason that the suggested topic is declined. */
export type TopicSuggestionDeclineReason = "NOT_RELEVANT" | "PERSONAL_PREFERENCE" | "TOO_GENERAL" | "TOO_SPECIFIC";
/** The possible states of a tracked issue. */
export type TrackedIssueStates = "CLOSED" | "OPEN";
/** Filters by whether or not 2FA is enabled and if the method configured is considered secure or insecure. */
export type TwoFactorCredentialSecurityType = "DISABLED" | "INSECURE" | "SECURE";
/** The possible durations that a user can be blocked for. */
export type UserBlockDuration = "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "PERMANENT" | "THREE_DAYS";
/** Properties by which user status connections can be ordered. */
export type UserStatusOrderField = "UPDATED_AT";
/** Whether a user being viewed contains public or private information. */
export type UserViewType = "PRIVATE" | "PUBLIC";
/** Properties by which verifiable domain connections can be ordered. */
export type VerifiableDomainOrderField = "CREATED_AT" | "DOMAIN";
/** Properties by which workflow run connections can be ordered. */
export type WorkflowRunOrderField = "CREATED_AT";
/** The possible states for a workflow. */
export type WorkflowState = "ACTIVE" | "DELETED" | "DISABLED_FORK" | "DISABLED_INACTIVITY" | "DISABLED_MANUALLY";
/** Autogenerated input type of AbortQueuedMigrations */
export interface AbortQueuedMigrationsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
}
/** Autogenerated input type of AbortRepositoryMigration */
export interface AbortRepositoryMigrationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly migrationId: string;
}
/** Autogenerated input type of AcceptEnterpriseAdministratorInvitation */
export interface AcceptEnterpriseAdministratorInvitationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly invitationId: string;
}
/** Autogenerated input type of AcceptEnterpriseMemberInvitation */
export interface AcceptEnterpriseMemberInvitationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly invitationId: string;
}
/** Autogenerated input type of AcceptTopicSuggestion */
export interface AcceptTopicSuggestionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name?: string | null | undefined;
    readonly repositoryId?: string | null | undefined;
}
/** Autogenerated input type of AccessUserNamespaceRepository */
export interface AccessUserNamespaceRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of AddAssigneesToAssignable */
export interface AddAssigneesToAssignableInput {
    readonly agentAssignment?: AgentAssignmentInput | null | undefined;
    readonly assignableId: string;
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly assignees?: ReadonlyArray<AssigneeUpdateInput> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
}
/** Autogenerated input type of AddBlockedBy */
export interface AddBlockedByInput {
    readonly blockingIssueId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Autogenerated input type of AddCloseIssueReferences */
export interface AddCloseIssueReferencesInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly pullRequestIds: ReadonlyArray<string>;
}
/** Autogenerated input type of AddComment */
export interface AddCommentInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly subjectId: string;
}
/** Autogenerated input type of AddDiscussionComment */
export interface AddDiscussionCommentInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly discussionId: string;
    readonly replyToId?: string | null | undefined;
}
/** Autogenerated input type of AddDiscussionPollVote */
export interface AddDiscussionPollVoteInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pollOptionId: string;
}
/** Autogenerated input type of AddEnterpriseOrganizationMember */
export interface AddEnterpriseOrganizationMemberInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly organizationId: string;
    readonly role?: "ADMIN" | "MEMBER" | null | undefined;
    readonly userIds: ReadonlyArray<string>;
}
/** Autogenerated input type of AddEnterpriseSupportEntitlement */
export interface AddEnterpriseSupportEntitlementInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
}
/** Autogenerated input type of AddLabelsToLabelable */
export interface AddLabelsToLabelableInput {
    readonly clientMutationId?: string | null | undefined;
    readonly labelIds?: ReadonlyArray<string> | null | undefined;
    readonly labelableId: string;
    readonly labels?: ReadonlyArray<LabelUpdateInput> | null | undefined;
}
/** Autogenerated input type of AddProjectCard */
export interface AddProjectCardInput {
    readonly clientMutationId?: string | null | undefined;
    readonly contentId?: string | null | undefined;
    readonly note?: string | null | undefined;
    readonly projectColumnId: string;
}
/** Autogenerated input type of AddProjectColumn */
export interface AddProjectColumnInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name: string;
    readonly projectId: string;
}
/** Autogenerated input type of AddProjectV2DraftIssue */
export interface AddProjectV2DraftIssueInput {
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly title: string;
}
/** Autogenerated input type of AddProjectV2ItemById */
export interface AddProjectV2ItemByIdInput {
    readonly clientMutationId?: string | null | undefined;
    readonly contentId: string;
    readonly projectId: string;
}
/** Autogenerated input type of AddPullRequestCreationCapBypassUsers */
export interface AddPullRequestCreationCapBypassUsersInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
    readonly userIds: ReadonlyArray<string>;
}
/** Autogenerated input type of AddPullRequestReviewComment */
export interface AddPullRequestReviewCommentInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly commitOID?: string | null | undefined;
    readonly inReplyTo?: string | null | undefined;
    readonly path?: string | null | undefined;
    readonly position?: number | null | undefined;
    readonly pullRequestId?: string | null | undefined;
    readonly pullRequestReviewId?: string | null | undefined;
}
/** Autogenerated input type of AddPullRequestReview */
export interface AddPullRequestReviewInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly comments?: ReadonlyArray<DraftPullRequestReviewComment | null> | null | undefined;
    readonly commitOID?: string | null | undefined;
    readonly event?: "APPROVE" | "COMMENT" | "DISMISS" | "REQUEST_CHANGES" | null | undefined;
    readonly pullRequestId: string;
    readonly threads?: ReadonlyArray<DraftPullRequestReviewThread | null> | null | undefined;
}
/** Autogenerated input type of AddPullRequestReviewThread */
export interface AddPullRequestReviewThreadInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly line?: number | null | undefined;
    readonly path?: string | null | undefined;
    readonly pullRequestId?: string | null | undefined;
    readonly pullRequestReviewId?: string | null | undefined;
    readonly side?: "LEFT" | "RIGHT" | null | undefined;
    readonly startLine?: number | null | undefined;
    readonly startSide?: "LEFT" | "RIGHT" | null | undefined;
    readonly subjectType?: "FILE" | "LINE" | null | undefined;
}
/** Autogenerated input type of AddPullRequestReviewThreadReply */
export interface AddPullRequestReviewThreadReplyInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestReviewId?: string | null | undefined;
    readonly pullRequestReviewThreadId: string;
}
/** Autogenerated input type of AddReaction */
export interface AddReactionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly content: "CONFUSED" | "EYES" | "HEART" | "HOORAY" | "LAUGH" | "ROCKET" | "THUMBS_DOWN" | "THUMBS_UP";
    readonly subjectId: string;
}
/** Autogenerated input type of AddRelatesTo */
export interface AddRelatesToInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly relatedIssueId: string;
}
/** Autogenerated input type of AddStar */
export interface AddStarInput {
    readonly clientMutationId?: string | null | undefined;
    readonly starrableId: string;
}
/** Autogenerated input type of AddSubIssue */
export interface AddSubIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly replaceParent?: boolean | null | undefined;
    readonly subIssueId?: string | null | undefined;
    readonly subIssueUrl?: string | null | undefined;
}
/** Autogenerated input type of AddUpvote */
export interface AddUpvoteInput {
    readonly clientMutationId?: string | null | undefined;
    readonly subjectId: string;
}
/** Autogenerated input type of AddVerifiableDomain */
export interface AddVerifiableDomainInput {
    readonly clientMutationId?: string | null | undefined;
    readonly domain: string;
    readonly ownerId: string;
}
/** Represents configuration for assigning Copilot to an issue (public variant) */
export interface AgentAssignmentInput {
    readonly baseRef?: string | null | undefined;
    readonly customAgent?: string | null | undefined;
    readonly customInstructions?: string | null | undefined;
    readonly targetRepositoryId?: string | null | undefined;
}
/** Autogenerated input type of ApplyPendingIssueSuggestions */
export interface ApplyPendingIssueSuggestionsInput {
    readonly actorId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly suggestions: ReadonlyArray<PendingIssueSuggestionRef>;
}
/** Autogenerated input type of ApproveDeployments */
export interface ApproveDeploymentsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly comment?: string | null | undefined;
    readonly environmentIds: ReadonlyArray<string>;
    readonly workflowRunId: string;
}
/** Autogenerated input type of ApproveVerifiableDomain */
export interface ApproveVerifiableDomainInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of ArchiveProjectV2Item */
export interface ArchiveProjectV2ItemInput {
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly projectId: string;
}
/** Autogenerated input type of ArchivePullRequest */
export interface ArchivePullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Autogenerated input type of ArchiveRepository */
export interface ArchiveRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
}
/** Specifies an actor (user or bot) to assign to an issue, with optional metadata such as a rationale. */
export interface AssigneeUpdateInput {
    readonly actorId: string;
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly rationale?: string | null | undefined;
    readonly suggest?: boolean | null | undefined;
}
/** Ordering options for Audit Log connections. */
export interface AuditLogOrder {
    readonly direction?: "ASC" | "DESC" | null | undefined;
    readonly field?: "CREATED_AT" | null | undefined;
}
/** Parameters to be used for the branch_name_pattern rule */
export interface BranchNamePatternParametersInput {
    readonly name?: string | null | undefined;
    readonly negate?: boolean | null | undefined;
    readonly operator: string;
    readonly pattern: string;
}
/** Information about a sponsorship to make for a user or organization with a GitHub
Sponsors profile, as part of sponsoring many users or organizations at once. */
export interface BulkSponsorship {
    readonly amount: number;
    readonly sponsorableId?: string | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
}
/** Autogenerated input type of CancelEnterpriseAdminInvitation */
export interface CancelEnterpriseAdminInvitationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly invitationId: string;
}
/** Autogenerated input type of CancelEnterpriseMemberInvitation */
export interface CancelEnterpriseMemberInvitationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly invitationId: string;
}
/** Autogenerated input type of CancelSponsorship */
export interface CancelSponsorshipInput {
    readonly clientMutationId?: string | null | undefined;
    readonly sponsorId?: string | null | undefined;
    readonly sponsorLogin?: string | null | undefined;
    readonly sponsorableId?: string | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
}
/** Autogenerated input type of ChangeUserStatus */
export interface ChangeUserStatusInput {
    readonly clientMutationId?: string | null | undefined;
    readonly emoji?: string | null | undefined;
    readonly expiresAt?: string | null | undefined;
    readonly limitedAvailability?: boolean | null | undefined;
    readonly message?: string | null | undefined;
    readonly organizationId?: string | null | undefined;
}
/** Information from a check run analysis to specific lines of code. */
export interface CheckAnnotationData {
    readonly annotationLevel: "FAILURE" | "NOTICE" | "WARNING";
    readonly location: CheckAnnotationRange;
    readonly message: string;
    readonly path: string;
    readonly rawDetails?: string | null | undefined;
    readonly title?: string | null | undefined;
}
/** Information from a check run analysis to specific lines of code. */
export interface CheckAnnotationRange {
    readonly endColumn?: number | null | undefined;
    readonly endLine: number;
    readonly startColumn?: number | null | undefined;
    readonly startLine: number;
}
/** Possible further actions the integrator can perform. */
export interface CheckRunAction {
    readonly description: string;
    readonly identifier: string;
    readonly label: string;
}
/** The filters that are available when fetching check runs. */
export interface CheckRunFilter {
    readonly appId?: number | null | undefined;
    readonly checkName?: string | null | undefined;
    readonly checkType?: "ALL" | "LATEST" | null | undefined;
    readonly conclusions?: ReadonlyArray<"ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT"> | null | undefined;
    readonly status?: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING" | null | undefined;
    readonly statuses?: ReadonlyArray<"COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING"> | null | undefined;
}
/** Descriptive details about the check run. */
export interface CheckRunOutput {
    readonly annotations?: ReadonlyArray<CheckAnnotationData> | null | undefined;
    readonly images?: ReadonlyArray<CheckRunOutputImage> | null | undefined;
    readonly summary: string;
    readonly text?: string | null | undefined;
    readonly title: string;
}
/** Images attached to the check run output displayed in the GitHub pull request UI. */
export interface CheckRunOutputImage {
    readonly alt: string;
    readonly caption?: string | null | undefined;
    readonly imageUrl: string;
}
/** The auto-trigger preferences that are available for check suites. */
export interface CheckSuiteAutoTriggerPreference {
    readonly appId: string;
    readonly setting: boolean;
}
/** The filters that are available when fetching check suites. */
export interface CheckSuiteFilter {
    readonly appId?: number | null | undefined;
    readonly checkName?: string | null | undefined;
}
/** Autogenerated input type of ClearLabelsFromLabelable */
export interface ClearLabelsFromLabelableInput {
    readonly clientMutationId?: string | null | undefined;
    readonly labelableId: string;
}
/** Autogenerated input type of ClearProjectV2ItemFieldValue */
export interface ClearProjectV2ItemFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
    readonly itemId: string;
    readonly projectId: string;
}
/** Autogenerated input type of CloneProject */
export interface CloneProjectInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly includeWorkflows: boolean;
    readonly name: string;
    readonly public?: boolean | null | undefined;
    readonly sourceId: string;
    readonly targetOwnerId: string;
}
/** Autogenerated input type of CloneTemplateRepository */
export interface CloneTemplateRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly includeAllBranches?: boolean | null | undefined;
    readonly name: string;
    readonly ownerId: string;
    readonly repositoryId: string;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC";
}
/** Autogenerated input type of CloseDiscussion */
export interface CloseDiscussionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly discussionId: string;
    readonly reason?: "DUPLICATE" | "OUTDATED" | "RESOLVED" | null | undefined;
}
/** Autogenerated input type of CloseIssue */
export interface CloseIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly duplicateIssueId?: string | null | undefined;
    readonly isSuggestion?: boolean | null | undefined;
    readonly issueId: string;
    readonly rationale?: string | null | undefined;
    readonly stateReason?: "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | null | undefined;
}
/** Autogenerated input type of ClosePullRequest */
export interface ClosePullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Enforce minimum line coverage thresholds on pull requests. This rule evaluates
uploaded coverage data but does not wait for coverage uploads. To ensure
coverage is evaluated before merging, make each status check associated with a
coverage upload a required status check. */
export interface CodeCoverageParametersInput {
    readonly maxCoverageDrop?: number | null | undefined;
    readonly minimumCoverage?: number | null | undefined;
}
/** Choose which severity levels of code quality results should block pull request
merges. When configured, a code quality analysis must be done on the pull
request before the changes can be merged. */
export interface CodeQualityParametersInput {
    readonly severity: "ALL" | "ERRORS" | "NOTES" | "WARNINGS";
}
/** Choose which tools must provide code scanning results before the reference is
updated. When configured, code scanning must be enabled and have results for
both the commit and the reference being updated. */
export interface CodeScanningParametersInput {
    readonly codeScanningTools: ReadonlyArray<CodeScanningToolInput>;
}
/** A tool that must provide code scanning results for this rule to pass. */
export interface CodeScanningToolInput {
    readonly alertsThreshold: string;
    readonly securityAlertsThreshold: string;
    readonly tool: string;
}
/** Specifies an author for filtering Git commits. */
export interface CommitAuthor {
    readonly emails?: ReadonlyArray<string> | null | undefined;
    readonly id?: string | null | undefined;
}
/** Parameters to be used for the commit_author_email_pattern rule */
export interface CommitAuthorEmailPatternParametersInput {
    readonly name?: string | null | undefined;
    readonly negate?: boolean | null | undefined;
    readonly operator: string;
    readonly pattern: string;
}
/** Ordering options for commit contribution connections. */
export interface CommitContributionOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "COMMIT_COUNT" | "OCCURRED_AT";
}
/** A message to include with a new commit */
export interface CommitMessage {
    readonly body?: string | null | undefined;
    readonly headline: string;
}
/** Parameters to be used for the commit_message_pattern rule */
export interface CommitMessagePatternParametersInput {
    readonly name?: string | null | undefined;
    readonly negate?: boolean | null | undefined;
    readonly operator: string;
    readonly pattern: string;
}
/** A git ref for a commit to be appended to.

The ref must be a branch, i.e. its fully qualified name must start
with `refs/heads/` (although the input is not required to be fully
qualified).

The Ref may be specified by its global node ID or by the
`repositoryNameWithOwner` and `branchName`.

### Examples

Specify a branch using a global node ID:

    { "id": "MDM6UmVmMTpyZWZzL2hlYWRzL21haW4=" }

Specify a branch using `repositoryNameWithOwner` and `branchName`:

    {
      "repositoryNameWithOwner": "github/graphql-client",
      "branchName": "main"
    } */
export interface CommittableBranch {
    readonly branchName?: string | null | undefined;
    readonly id?: string | null | undefined;
    readonly repositoryNameWithOwner?: string | null | undefined;
}
/** Parameters to be used for the committer_email_pattern rule */
export interface CommitterEmailPatternParametersInput {
    readonly name?: string | null | undefined;
    readonly negate?: boolean | null | undefined;
    readonly operator: string;
    readonly pattern: string;
}
/** Ordering options for contribution connections. */
export interface ContributionOrder {
    readonly direction: "ASC" | "DESC";
}
/** Autogenerated input type of ConvertProjectCardNoteToIssue */
export interface ConvertProjectCardNoteToIssueInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly projectCardId: string;
    readonly repositoryId: string;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of ConvertProjectV2DraftIssueItemToIssue */
export interface ConvertProjectV2DraftIssueItemToIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of ConvertPullRequestToDraft */
export interface ConvertPullRequestToDraftInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Request Copilot code review for new pull requests automatically if the author
has access to Copilot code review and AI credits. */
export interface CopilotCodeReviewParametersInput {
    readonly reviewDraftPullRequests?: boolean | null | undefined;
    readonly reviewOnPush?: boolean | null | undefined;
}
/** Autogenerated input type of CopyProjectV2 */
export interface CopyProjectV2Input {
    readonly clientMutationId?: string | null | undefined;
    readonly includeDraftIssues?: boolean | null | undefined;
    readonly ownerId: string;
    readonly projectId: string;
    readonly title: string;
}
/** Autogenerated input type of CreateAttributionInvitation */
export interface CreateAttributionInvitationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly sourceId: string;
    readonly targetId: string;
}
/** Autogenerated input type of CreateBranchProtectionRule */
export interface CreateBranchProtectionRuleInput {
    readonly allowsDeletions?: boolean | null | undefined;
    readonly allowsForcePushes?: boolean | null | undefined;
    readonly blocksCreations?: boolean | null | undefined;
    readonly bypassForcePushActorIds?: ReadonlyArray<string> | null | undefined;
    readonly bypassPullRequestActorIds?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly dismissesStaleReviews?: boolean | null | undefined;
    readonly isAdminEnforced?: boolean | null | undefined;
    readonly lockAllowsFetchAndMerge?: boolean | null | undefined;
    readonly lockBranch?: boolean | null | undefined;
    readonly pattern: string;
    readonly pushActorIds?: ReadonlyArray<string> | null | undefined;
    readonly repositoryId: string;
    readonly requireLastPushApproval?: boolean | null | undefined;
    readonly requiredApprovingReviewCount?: number | null | undefined;
    readonly requiredDeploymentEnvironments?: ReadonlyArray<string> | null | undefined;
    readonly requiredStatusCheckContexts?: ReadonlyArray<string> | null | undefined;
    readonly requiredStatusChecks?: ReadonlyArray<RequiredStatusCheckInput> | null | undefined;
    readonly requiresApprovingReviews?: boolean | null | undefined;
    readonly requiresCodeOwnerReviews?: boolean | null | undefined;
    readonly requiresCommitSignatures?: boolean | null | undefined;
    readonly requiresConversationResolution?: boolean | null | undefined;
    readonly requiresDeployments?: boolean | null | undefined;
    readonly requiresLinearHistory?: boolean | null | undefined;
    readonly requiresStatusChecks?: boolean | null | undefined;
    readonly requiresStrictStatusChecks?: boolean | null | undefined;
    readonly restrictsPushes?: boolean | null | undefined;
    readonly restrictsReviewDismissals?: boolean | null | undefined;
    readonly reviewDismissalActorIds?: ReadonlyArray<string> | null | undefined;
}
/** Autogenerated input type of CreateCheckRun */
export interface CreateCheckRunInput {
    readonly actions?: ReadonlyArray<CheckRunAction> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly completedAt?: string | null | undefined;
    readonly conclusion?: "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | null | undefined;
    readonly detailsUrl?: string | null | undefined;
    readonly externalId?: string | null | undefined;
    readonly headSha: string;
    readonly name: string;
    readonly output?: CheckRunOutput | null | undefined;
    readonly repositoryId: string;
    readonly startedAt?: string | null | undefined;
    readonly status?: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "WAITING" | null | undefined;
}
/** Autogenerated input type of CreateCheckSuite */
export interface CreateCheckSuiteInput {
    readonly clientMutationId?: string | null | undefined;
    readonly headSha: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of CreateCommitOnBranch */
export interface CreateCommitOnBranchInput {
    readonly branch: CommittableBranch;
    readonly clientMutationId?: string | null | undefined;
    readonly expectedHeadOid: string;
    readonly fileChanges?: FileChanges | null | undefined;
    readonly message: CommitMessage;
}
/** Autogenerated input type of CreateDeployment */
export interface CreateDeploymentInput {
    readonly autoMerge?: boolean | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly environment?: string | null | undefined;
    readonly payload?: string | null | undefined;
    readonly refId: string;
    readonly repositoryId: string;
    readonly requiredContexts?: ReadonlyArray<string> | null | undefined;
    readonly task?: string | null | undefined;
}
/** Autogenerated input type of CreateDeploymentStatus */
export interface CreateDeploymentStatusInput {
    readonly autoInactive?: boolean | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly deploymentId: string;
    readonly description?: string | null | undefined;
    readonly environment?: string | null | undefined;
    readonly environmentUrl?: string | null | undefined;
    readonly logUrl?: string | null | undefined;
    readonly state: "ERROR" | "FAILURE" | "INACTIVE" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "SUCCESS" | "WAITING";
}
/** Autogenerated input type of CreateDiscussion */
export interface CreateDiscussionInput {
    readonly body: string;
    readonly categoryId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
    readonly title: string;
}
/** Autogenerated input type of CreateEnterpriseOrganization */
export interface CreateEnterpriseOrganizationInput {
    readonly adminLogins: ReadonlyArray<string>;
    readonly billingEmail: string;
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
    readonly profileName: string;
}
/** Autogenerated input type of CreateEnvironment */
export interface CreateEnvironmentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of CreateIpAllowListEntry */
export interface CreateIpAllowListEntryInput {
    readonly allowListValue: string;
    readonly clientMutationId?: string | null | undefined;
    readonly isActive: boolean;
    readonly name?: string | null | undefined;
    readonly ownerId: string;
}
/** Autogenerated input type of CreateIssueField */
export interface CreateIssueFieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description?: string | null | undefined;
    readonly name: string;
    readonly options?: ReadonlyArray<IssueFieldSingleSelectOptionInput> | null | undefined;
    readonly ownerId: string;
    readonly visibility?: "ALL" | "ORG_ONLY" | null | undefined;
}
/** Autogenerated input type of CreateIssueFieldValue */
export interface CreateIssueFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueField: IssueFieldCreateOrUpdateInput;
    readonly issueId: string;
}
/** Autogenerated input type of CreateIssue */
export interface CreateIssueInput {
    readonly agentAssignment?: AgentAssignmentInput | null | undefined;
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly issueFields?: ReadonlyArray<IssueFieldCreateOrUpdateInput> | null | undefined;
    readonly issueTemplate?: string | null | undefined;
    readonly issueTypeId?: string | null | undefined;
    readonly labelIds?: ReadonlyArray<string> | null | undefined;
    readonly milestoneId?: string | null | undefined;
    readonly parentIssueId?: string | null | undefined;
    readonly projectIds?: ReadonlyArray<string> | null | undefined;
    readonly projectV2Ids?: ReadonlyArray<string> | null | undefined;
    readonly repositoryId: string;
    readonly title: string;
}
/** Autogenerated input type of CreateIssueType */
export interface CreateIssueTypeInput {
    readonly clientMutationId?: string | null | undefined;
    readonly color?: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW" | null | undefined;
    readonly description?: string | null | undefined;
    readonly isEnabled: boolean;
    readonly name: string;
    readonly ownerId: string;
}
/** Autogenerated input type of CreateLabel */
export interface CreateLabelInput {
    readonly clientMutationId?: string | null | undefined;
    readonly color: string;
    readonly description?: string | null | undefined;
    readonly name: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of CreateLinkedBranch */
export interface CreateLinkedBranchInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly name?: string | null | undefined;
    readonly oid: string;
    readonly repositoryId?: string | null | undefined;
}
/** Autogenerated input type of CreateMigrationSource */
export interface CreateMigrationSourceInput {
    readonly accessToken?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly githubPat?: string | null | undefined;
    readonly name: string;
    readonly ownerId: string;
    readonly type: "AZURE_DEVOPS" | "BITBUCKET_SERVER" | "GITHUB_ARCHIVE" | "GITLAB";
    readonly url?: string | null | undefined;
}
/** Autogenerated input type of CreateProject */
export interface CreateProjectInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly name: string;
    readonly ownerId: string;
    readonly repositoryIds?: ReadonlyArray<string> | null | undefined;
    readonly template?: "AUTOMATED_KANBAN_V2" | "AUTOMATED_REVIEWS_KANBAN" | "BASIC_KANBAN" | "BUG_TRIAGE" | null | undefined;
}
/** Autogenerated input type of CreateProjectV2Field */
export interface CreateProjectV2FieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly dataType: "DATE" | "ITERATION" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly iterationConfiguration?: ProjectV2IterationFieldConfigurationInput | null | undefined;
    readonly multiSelectOptions?: ReadonlyArray<ProjectV2MultiSelectFieldOptionInput> | null | undefined;
    readonly name: string;
    readonly projectId: string;
    readonly singleSelectOptions?: ReadonlyArray<ProjectV2SingleSelectFieldOptionInput> | null | undefined;
}
/** Autogenerated input type of CreateProjectV2 */
export interface CreateProjectV2Input {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly repositoryId?: string | null | undefined;
    readonly teamId?: string | null | undefined;
    readonly title: string;
}
/** Autogenerated input type of CreateProjectV2IssueField */
export interface CreateProjectV2IssueFieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueFieldId: string;
    readonly projectId: string;
}
/** Autogenerated input type of CreateProjectV2StatusUpdate */
export interface CreateProjectV2StatusUpdateInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly startDate?: string | null | undefined;
    readonly status?: "AT_RISK" | "COMPLETE" | "INACTIVE" | "OFF_TRACK" | "ON_TRACK" | null | undefined;
    readonly targetDate?: string | null | undefined;
}
/** Autogenerated input type of CreateProjectV2View */
export interface CreateProjectV2ViewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly configuration?: ProjectV2ViewConfigurationInput | null | undefined;
    readonly layout: "BOARD_LAYOUT" | "ROADMAP_LAYOUT" | "TABLE_LAYOUT";
    readonly name: string;
    readonly projectId: string;
}
/** Autogenerated input type of CreatePullRequest */
export interface CreatePullRequestInput {
    readonly baseRefName: string;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly draft?: boolean | null | undefined;
    readonly headRefName: string;
    readonly headRepositoryId?: string | null | undefined;
    readonly maintainerCanModify?: boolean | null | undefined;
    readonly repositoryId: string;
    readonly title: string;
}
/** Autogenerated input type of CreateRef */
export interface CreateRefInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name: string;
    readonly oid: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of CreateRepositoryCustomProperty */
export interface CreateRepositoryCustomPropertyInput {
    readonly allowedValues?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly defaultValue?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly propertyName: string;
    readonly regex?: string | null | undefined;
    readonly requireExplicitValues?: boolean | null | undefined;
    readonly required?: boolean | null | undefined;
    readonly sourceId: string;
    readonly valueType: "MULTI_SELECT" | "SINGLE_SELECT" | "STRING" | "TRUE_FALSE" | "URL";
    readonly valuesEditableBy?: "ORG_ACTORS" | "ORG_AND_REPO_ACTORS" | null | undefined;
}
/** Autogenerated input type of CreateRepository */
export interface CreateRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly hasIssuesEnabled?: boolean | null | undefined;
    readonly hasWikiEnabled?: boolean | null | undefined;
    readonly homepageUrl?: string | null | undefined;
    readonly name: string;
    readonly ownerId?: string | null | undefined;
    readonly teamId?: string | null | undefined;
    readonly template?: boolean | null | undefined;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC";
}
/** Autogenerated input type of CreateRepositoryRuleset */
export interface CreateRepositoryRulesetInput {
    readonly bypassActors?: ReadonlyArray<RepositoryRulesetBypassActorInput> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly conditions: RepositoryRuleConditionsInput;
    readonly enforcement: "ACTIVE" | "DISABLED" | "EVALUATE";
    readonly name: string;
    readonly rules?: ReadonlyArray<RepositoryRuleInput> | null | undefined;
    readonly sourceId: string;
    readonly target?: "BRANCH" | "PUSH" | "REPOSITORY" | "TAG" | null | undefined;
}
/** Autogenerated input type of CreateSponsorsListing */
export interface CreateSponsorsListingInput {
    readonly billingCountryOrRegionCode?: "AD" | "AE" | "AF" | "AG" | "AI" | "AL" | "AM" | "AO" | "AQ" | "AR" | "AS" | "AT" | "AU" | "AW" | "AX" | "AZ" | "BA" | "BB" | "BD" | "BE" | "BF" | "BG" | "BH" | "BI" | "BJ" | "BL" | "BM" | "BN" | "BO" | "BQ" | "BR" | "BS" | "BT" | "BV" | "BW" | "BY" | "BZ" | "CA" | "CC" | "CD" | "CF" | "CG" | "CH" | "CI" | "CK" | "CL" | "CM" | "CN" | "CO" | "CR" | "CV" | "CW" | "CX" | "CY" | "CZ" | "DE" | "DJ" | "DK" | "DM" | "DO" | "DZ" | "EC" | "EE" | "EG" | "EH" | "ER" | "ES" | "ET" | "FI" | "FJ" | "FK" | "FM" | "FO" | "FR" | "GA" | "GB" | "GD" | "GE" | "GF" | "GG" | "GH" | "GI" | "GL" | "GM" | "GN" | "GP" | "GQ" | "GR" | "GS" | "GT" | "GU" | "GW" | "GY" | "HK" | "HM" | "HN" | "HR" | "HT" | "HU" | "ID" | "IE" | "IL" | "IM" | "IN" | "IO" | "IQ" | "IR" | "IS" | "IT" | "JE" | "JM" | "JO" | "JP" | "KE" | "KG" | "KH" | "KI" | "KM" | "KN" | "KR" | "KW" | "KY" | "KZ" | "LA" | "LB" | "LC" | "LI" | "LK" | "LR" | "LS" | "LT" | "LU" | "LV" | "LY" | "MA" | "MC" | "MD" | "ME" | "MF" | "MG" | "MH" | "MK" | "ML" | "MM" | "MN" | "MO" | "MP" | "MQ" | "MR" | "MS" | "MT" | "MU" | "MV" | "MW" | "MX" | "MY" | "MZ" | "NA" | "NC" | "NE" | "NF" | "NG" | "NI" | "NL" | "NO" | "NP" | "NR" | "NU" | "NZ" | "OM" | "PA" | "PE" | "PF" | "PG" | "PH" | "PK" | "PL" | "PM" | "PN" | "PR" | "PS" | "PT" | "PW" | "PY" | "QA" | "RE" | "RO" | "RS" | "RU" | "RW" | "SA" | "SB" | "SC" | "SD" | "SE" | "SG" | "SH" | "SI" | "SJ" | "SK" | "SL" | "SM" | "SN" | "SO" | "SR" | "SS" | "ST" | "SV" | "SX" | "SY" | "SZ" | "TC" | "TD" | "TF" | "TG" | "TH" | "TJ" | "TK" | "TL" | "TM" | "TN" | "TO" | "TR" | "TT" | "TV" | "TW" | "TZ" | "UA" | "UG" | "UM" | "US" | "UY" | "UZ" | "VA" | "VC" | "VE" | "VG" | "VI" | "VN" | "VU" | "WF" | "WS" | "YE" | "YT" | "ZA" | "ZM" | "ZW" | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly contactEmail?: string | null | undefined;
    readonly fiscalHostLogin?: string | null | undefined;
    readonly fiscallyHostedProjectProfileUrl?: string | null | undefined;
    readonly fullDescription?: string | null | undefined;
    readonly residenceCountryOrRegionCode?: "AD" | "AE" | "AF" | "AG" | "AI" | "AL" | "AM" | "AO" | "AQ" | "AR" | "AS" | "AT" | "AU" | "AW" | "AX" | "AZ" | "BA" | "BB" | "BD" | "BE" | "BF" | "BG" | "BH" | "BI" | "BJ" | "BL" | "BM" | "BN" | "BO" | "BQ" | "BR" | "BS" | "BT" | "BV" | "BW" | "BY" | "BZ" | "CA" | "CC" | "CD" | "CF" | "CG" | "CH" | "CI" | "CK" | "CL" | "CM" | "CN" | "CO" | "CR" | "CV" | "CW" | "CX" | "CY" | "CZ" | "DE" | "DJ" | "DK" | "DM" | "DO" | "DZ" | "EC" | "EE" | "EG" | "EH" | "ER" | "ES" | "ET" | "FI" | "FJ" | "FK" | "FM" | "FO" | "FR" | "GA" | "GB" | "GD" | "GE" | "GF" | "GG" | "GH" | "GI" | "GL" | "GM" | "GN" | "GP" | "GQ" | "GR" | "GS" | "GT" | "GU" | "GW" | "GY" | "HK" | "HM" | "HN" | "HR" | "HT" | "HU" | "ID" | "IE" | "IL" | "IM" | "IN" | "IO" | "IQ" | "IR" | "IS" | "IT" | "JE" | "JM" | "JO" | "JP" | "KE" | "KG" | "KH" | "KI" | "KM" | "KN" | "KR" | "KW" | "KY" | "KZ" | "LA" | "LB" | "LC" | "LI" | "LK" | "LR" | "LS" | "LT" | "LU" | "LV" | "LY" | "MA" | "MC" | "MD" | "ME" | "MF" | "MG" | "MH" | "MK" | "ML" | "MM" | "MN" | "MO" | "MP" | "MQ" | "MR" | "MS" | "MT" | "MU" | "MV" | "MW" | "MX" | "MY" | "MZ" | "NA" | "NC" | "NE" | "NF" | "NG" | "NI" | "NL" | "NO" | "NP" | "NR" | "NU" | "NZ" | "OM" | "PA" | "PE" | "PF" | "PG" | "PH" | "PK" | "PL" | "PM" | "PN" | "PR" | "PS" | "PT" | "PW" | "PY" | "QA" | "RE" | "RO" | "RS" | "RU" | "RW" | "SA" | "SB" | "SC" | "SD" | "SE" | "SG" | "SH" | "SI" | "SJ" | "SK" | "SL" | "SM" | "SN" | "SO" | "SR" | "SS" | "ST" | "SV" | "SX" | "SY" | "SZ" | "TC" | "TD" | "TF" | "TG" | "TH" | "TJ" | "TK" | "TL" | "TM" | "TN" | "TO" | "TR" | "TT" | "TV" | "TW" | "TZ" | "UA" | "UG" | "UM" | "US" | "UY" | "UZ" | "VA" | "VC" | "VE" | "VG" | "VI" | "VN" | "VU" | "WF" | "WS" | "YE" | "YT" | "ZA" | "ZM" | "ZW" | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
}
/** Autogenerated input type of CreateSponsorsTier */
export interface CreateSponsorsTierInput {
    readonly amount: number;
    readonly clientMutationId?: string | null | undefined;
    readonly description: string;
    readonly isRecurring?: boolean | null | undefined;
    readonly publish?: boolean | null | undefined;
    readonly repositoryId?: string | null | undefined;
    readonly repositoryName?: string | null | undefined;
    readonly repositoryOwnerLogin?: string | null | undefined;
    readonly sponsorableId?: string | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
    readonly welcomeMessage?: string | null | undefined;
}
/** Autogenerated input type of CreateSponsorship */
export interface CreateSponsorshipInput {
    readonly amount?: number | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly isRecurring?: boolean | null | undefined;
    readonly privacyLevel?: "PRIVATE" | "PUBLIC" | null | undefined;
    readonly receiveEmails?: boolean | null | undefined;
    readonly sponsorId?: string | null | undefined;
    readonly sponsorLogin?: string | null | undefined;
    readonly sponsorableId?: string | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
    readonly tierId?: string | null | undefined;
}
/** Autogenerated input type of CreateSponsorships */
export interface CreateSponsorshipsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly privacyLevel?: "PRIVATE" | "PUBLIC" | null | undefined;
    readonly receiveEmails?: boolean | null | undefined;
    readonly recurring?: boolean | null | undefined;
    readonly sponsorLogin: string;
    readonly sponsorships: ReadonlyArray<BulkSponsorship>;
}
/** Autogenerated input type of CreateUserList */
export interface CreateUserListInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly isPrivate?: boolean | null | undefined;
    readonly name: string;
}
/** The custom property name and value to be set. */
export interface CustomPropertyValueInput {
    readonly propertyName: string;
    readonly value?: unknown | null | undefined;
}
/** Autogenerated input type of DeclineTopicSuggestion */
export interface DeclineTopicSuggestionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name?: string | null | undefined;
    readonly reason?: "NOT_RELEVANT" | "PERSONAL_PREFERENCE" | "TOO_GENERAL" | "TOO_SPECIFIC" | null | undefined;
    readonly repositoryId?: string | null | undefined;
}
/** Autogenerated input type of DeleteBranchProtectionRule */
export interface DeleteBranchProtectionRuleInput {
    readonly branchProtectionRuleId: string;
    readonly clientMutationId?: string | null | undefined;
}
/** Autogenerated input type of DeleteDeployment */
export interface DeleteDeploymentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteDiscussionComment */
export interface DeleteDiscussionCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteDiscussion */
export interface DeleteDiscussionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteEnvironment */
export interface DeleteEnvironmentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteIpAllowListEntry */
export interface DeleteIpAllowListEntryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ipAllowListEntryId: string;
}
/** Autogenerated input type of DeleteIssueComment */
export interface DeleteIssueCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteIssueField */
export interface DeleteIssueFieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
}
/** Autogenerated input type of DeleteIssueFieldValue */
export interface DeleteIssueFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
    readonly issueId: string;
}
/** Autogenerated input type of DeleteIssue */
export interface DeleteIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Autogenerated input type of DeleteIssueType */
export interface DeleteIssueTypeInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueTypeId: string;
}
/** Autogenerated input type of DeleteLabel */
export interface DeleteLabelInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteLinkedBranch */
export interface DeleteLinkedBranchInput {
    readonly clientMutationId?: string | null | undefined;
    readonly linkedBranchId: string;
}
/** Autogenerated input type of DeletePackageVersion */
export interface DeletePackageVersionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly packageVersionId: string;
}
/** Autogenerated input type of DeleteProjectCard */
export interface DeleteProjectCardInput {
    readonly cardId: string;
    readonly clientMutationId?: string | null | undefined;
}
/** Autogenerated input type of DeleteProjectColumn */
export interface DeleteProjectColumnInput {
    readonly clientMutationId?: string | null | undefined;
    readonly columnId: string;
}
/** Autogenerated input type of DeleteProject */
export interface DeleteProjectInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
}
/** Autogenerated input type of DeleteProjectV2Field */
export interface DeleteProjectV2FieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
}
/** Autogenerated input type of DeleteProjectV2 */
export interface DeleteProjectV2Input {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
}
/** Autogenerated input type of DeleteProjectV2Item */
export interface DeleteProjectV2ItemInput {
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly projectId: string;
}
/** Autogenerated input type of DeleteProjectV2StatusUpdate */
export interface DeleteProjectV2StatusUpdateInput {
    readonly clientMutationId?: string | null | undefined;
    readonly statusUpdateId: string;
}
/** Autogenerated input type of DeleteProjectV2View */
export interface DeleteProjectV2ViewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly viewId: string;
}
/** Autogenerated input type of DeleteProjectV2Workflow */
export interface DeleteProjectV2WorkflowInput {
    readonly clientMutationId?: string | null | undefined;
    readonly workflowId: string;
}
/** Autogenerated input type of DeletePullRequestReviewComment */
export interface DeletePullRequestReviewCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeletePullRequestReview */
export interface DeletePullRequestReviewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestReviewId: string;
}
/** Autogenerated input type of DeleteRef */
export interface DeleteRefInput {
    readonly clientMutationId?: string | null | undefined;
    readonly refId: string;
}
/** Autogenerated input type of DeleteRepositoryCustomProperty */
export interface DeleteRepositoryCustomPropertyInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DeleteRepositoryRuleset */
export interface DeleteRepositoryRulesetInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryRulesetId: string;
}
/** Autogenerated input type of DeleteUserList */
export interface DeleteUserListInput {
    readonly clientMutationId?: string | null | undefined;
    readonly listId: string;
}
/** Autogenerated input type of DeleteVerifiableDomain */
export interface DeleteVerifiableDomainInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Ordering options for deployment connections */
export interface DeploymentOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Autogenerated input type of DequeuePullRequest */
export interface DequeuePullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of DisablePullRequestAutoMerge */
export interface DisablePullRequestAutoMergeInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Ways in which lists of discussions can be ordered upon return. */
export interface DiscussionOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "UPDATED_AT";
}
/** Ordering options for discussion poll option connections. */
export interface DiscussionPollOptionOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "AUTHORED_ORDER" | "VOTE_COUNT";
}
/** Autogenerated input type of DismissPullRequestReview */
export interface DismissPullRequestReviewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly message: string;
    readonly pullRequestReviewId: string;
}
/** Autogenerated input type of DismissRepositoryVulnerabilityAlert */
export interface DismissRepositoryVulnerabilityAlertInput {
    readonly clientMutationId?: string | null | undefined;
    readonly dismissReason: "FIX_STARTED" | "INACCURATE" | "NOT_USED" | "NO_BANDWIDTH" | "TOLERABLE_RISK";
    readonly repositoryVulnerabilityAlertId: string;
}
/** Specify people, teams, or apps allowed to dismiss pull request reviews. */
export interface DismissalRestrictionInput {
    readonly allowedActors?: ReadonlyArray<string> | null | undefined;
    readonly enabled: boolean;
}
/** Specifies a review comment to be left with a Pull Request Review. */
export interface DraftPullRequestReviewComment {
    readonly body: string;
    readonly path: string;
    readonly position: number;
}
/** Specifies a review comment thread to be left with a Pull Request Review. */
export interface DraftPullRequestReviewThread {
    readonly body: string;
    readonly line?: number | null | undefined;
    readonly path?: string | null | undefined;
    readonly side?: "LEFT" | "RIGHT" | null | undefined;
    readonly startLine?: number | null | undefined;
    readonly startSide?: "LEFT" | "RIGHT" | null | undefined;
}
/** Autogenerated input type of EnablePullRequestAutoMerge */
export interface EnablePullRequestAutoMergeInput {
    readonly authorEmail?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly commitBody?: string | null | undefined;
    readonly commitHeadline?: string | null | undefined;
    readonly expectedHeadOid?: string | null | undefined;
    readonly mergeMethod?: "MERGE" | "REBASE" | "SQUASH" | null | undefined;
    readonly pullRequestId: string;
}
/** Autogenerated input type of EnqueuePullRequest */
export interface EnqueuePullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly expectedHeadOid?: string | null | undefined;
    readonly jump?: boolean | null | undefined;
    readonly pullRequestId: string;
}
/** Ordering options for enterprise administrator invitation connections */
export interface EnterpriseAdministratorInvitationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ordering options for enterprise administrator invitation connections */
export interface EnterpriseMemberInvitationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ordering options for enterprise member connections. */
export interface EnterpriseMemberOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "LOGIN";
}
/** Ordering options for enterprises. */
export interface EnterpriseOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "NAME";
}
/** Ordering options for Enterprise Server installation connections. */
export interface EnterpriseServerInstallationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "CUSTOMER_NAME" | "HOST_NAME";
}
/** Ordering options for Enterprise Server user account email connections. */
export interface EnterpriseServerUserAccountEmailOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "EMAIL";
}
/** Ordering options for Enterprise Server user account connections. */
export interface EnterpriseServerUserAccountOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "LOGIN" | "REMOTE_CREATED_AT";
}
/** Ordering options for Enterprise Server user accounts upload connections. */
export interface EnterpriseServerUserAccountsUploadOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ordering options for enterprise team member connections. */
export interface EnterpriseTeamMemberOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "ID" | "LOGIN";
}
/** Ordering options for enterprise team connections. */
export interface EnterpriseTeamOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "ID" | "NAME";
}
/** Ordering options for enterprise team organization connections. */
export interface EnterpriseTeamOrganizationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "ID" | "LOGIN";
}
/** Ordering options for environments */
export interface Environments {
    readonly direction: "ASC" | "DESC";
    readonly field: "NAME";
}
/** A command to add a file at the given path with the given contents as part of a
commit.  Any existing file at that that path will be replaced. */
export interface FileAddition {
    readonly contents: string;
    readonly path: string;
}
/** A description of a set of changes to a file tree to be made as part of
a git commit, modeled as zero or more file `additions` and zero or more
file `deletions`.

Both fields are optional; omitting both will produce a commit with no
file changes.

`deletions` and `additions` describe changes to files identified
by their path in the git tree using unix-style path separators, i.e.
`/`.  The root of a git tree is an empty string, so paths are not
slash-prefixed.

`path` values must be unique across all `additions` and `deletions`
provided.  Any duplication will result in a validation error.

### Encoding

File contents must be provided in full for each `FileAddition`.

The `contents` of a `FileAddition` must be encoded using RFC 4648
compliant base64, i.e. correct padding is required and no characters
outside the standard alphabet may be used.  Invalid base64
encoding will be rejected with a validation error.

The encoded contents may be binary.

For text files, no assumptions are made about the character encoding of
the file contents (after base64 decoding).  No charset transcoding or
line-ending normalization will be performed; it is the client's
responsibility to manage the character encoding of files they provide.
However, for maximum compatibility we recommend using UTF-8 encoding
and ensuring that all files in a repository use a consistent
line-ending convention (`\n` or `\r\n`), and that all files end
with a newline.

### Modeling file changes

Each of the the five types of conceptual changes that can be made in a
git commit can be described using the `FileChanges` type as follows:

1. New file addition: create file `hello world\n` at path `docs/README.txt`:

       {
         "additions" [
           {
             "path": "docs/README.txt",
             "contents": base64encode("hello world\n")
           }
         ]
       }

2. Existing file modification: change existing `docs/README.txt` to have new
   content `new content here\n`:

       {
         "additions" [
           {
             "path": "docs/README.txt",
             "contents": base64encode("new content here\n")
           }
         ]
       }

3. Existing file deletion: remove existing file `docs/README.txt`.
   Note that the path is required to exist -- specifying a
   path that does not exist on the given branch will abort the
   commit and return an error.

       {
         "deletions" [
           {
             "path": "docs/README.txt"
           }
         ]
       }


4. File rename with no changes: rename `docs/README.txt` with
   previous content `hello world\n` to the same content at
   `newdocs/README.txt`:

       {
         "deletions" [
           {
             "path": "docs/README.txt",
           }
         ],
         "additions" [
           {
             "path": "newdocs/README.txt",
             "contents": base64encode("hello world\n")
           }
         ]
       }


5. File rename with changes: rename `docs/README.txt` with
   previous content `hello world\n` to a file at path
   `newdocs/README.txt` with content `new contents\n`:

       {
         "deletions" [
           {
             "path": "docs/README.txt",
           }
         ],
         "additions" [
           {
             "path": "newdocs/README.txt",
             "contents": base64encode("new contents\n")
           }
         ]
       } */
export interface FileChanges {
    readonly additions?: ReadonlyArray<FileAddition> | null | undefined;
    readonly deletions?: ReadonlyArray<FileDeletion> | null | undefined;
}
/** A command to delete the file at the given path as part of a commit. */
export interface FileDeletion {
    readonly path: string;
}
/** Prevent commits that include files with specified file extensions from being pushed to the commit graph. */
export interface FileExtensionRestrictionParametersInput {
    readonly restrictedFileExtensions: ReadonlyArray<string>;
}
/** Prevent commits that include changes in specified file and folder paths from
being pushed to the commit graph. This includes absolute paths that contain file names. */
export interface FilePathRestrictionParametersInput {
    readonly ignoredFilePaths?: ReadonlyArray<string> | null | undefined;
    readonly restrictedFilePaths: ReadonlyArray<string>;
}
/** Autogenerated input type of FollowOrganization */
export interface FollowOrganizationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
}
/** Autogenerated input type of FollowUser */
export interface FollowUserInput {
    readonly clientMutationId?: string | null | undefined;
    readonly userId: string;
}
/** Ordering options for gist connections */
export interface GistOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "PUSHED_AT" | "UPDATED_AT";
}
/** Autogenerated input type of GrantEnterpriseOrganizationsMigratorRole */
export interface GrantEnterpriseOrganizationsMigratorRoleInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
}
/** Autogenerated input type of GrantMigratorRole */
export interface GrantMigratorRoleInput {
    readonly actor: string;
    readonly actorType: "TEAM" | "USER";
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
}
/** Autogenerated input type of ImportProject */
export interface ImportProjectInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly columnImports: ReadonlyArray<ProjectColumnImport>;
    readonly name: string;
    readonly ownerName: string;
    readonly public?: boolean | null | undefined;
}
/** Autogenerated input type of InviteEnterpriseAdmin */
export interface InviteEnterpriseAdminInput {
    readonly clientMutationId?: string | null | undefined;
    readonly email?: string | null | undefined;
    readonly enterpriseId: string;
    readonly invitee?: string | null | undefined;
    readonly role?: "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED" | null | undefined;
}
/** Autogenerated input type of InviteEnterpriseMember */
export interface InviteEnterpriseMemberInput {
    readonly clientMutationId?: string | null | undefined;
    readonly email?: string | null | undefined;
    readonly enterpriseId: string;
    readonly invitee?: string | null | undefined;
}
/** Ordering options for IP allow list entry connections. */
export interface IpAllowListEntryOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "ALLOW_LIST_VALUE" | "CREATED_AT";
}
/** Ways in which lists of issue comments can be ordered upon return. */
export interface IssueCommentOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "UPDATED_AT";
}
/** Ordering options issue dependencies */
export interface IssueDependencyOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "DEPENDENCY_ADDED_AT";
}
/** Represents an issue field value that must be set on an issue during issue creation */
export interface IssueFieldCreateOrUpdateInput {
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly dateValue?: string | null | undefined;
    readonly delete?: boolean | null | undefined;
    readonly fieldId: string;
    readonly multiSelectOptionIds?: ReadonlyArray<string> | null | undefined;
    readonly numberValue?: number | null | undefined;
    readonly rationale?: string | null | undefined;
    readonly singleSelectOptionId?: string | null | undefined;
    readonly suggest?: boolean | null | undefined;
    readonly textValue?: string | null | undefined;
}
/** Ordering options for issue field connections */
export interface IssueFieldOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME";
}
/** A single selection option for an issue field. */
export interface IssueFieldSingleSelectOptionInput {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description?: string | null | undefined;
    readonly name: string;
    readonly priority: number;
}
/** Updates an issue field using its user-facing name. */
export interface IssueFieldUpdateInput {
    readonly fieldName: string;
    readonly operation: "ADD" | "CLEAR" | "REMOVE" | "SET";
    readonly value?: string | null | undefined;
}
/** A filter for matching an issue field value. Exactly one value argument should be provided. */
export interface IssueFieldValueFilter {
    readonly dateValue?: string | null | undefined;
    readonly fieldId?: string | null | undefined;
    readonly fieldName?: string | null | undefined;
    readonly multiSelectOptionIds?: ReadonlyArray<string> | null | undefined;
    readonly multiSelectOptionValues?: ReadonlyArray<string> | null | undefined;
    readonly numberValue?: number | null | undefined;
    readonly singleSelectOptionId?: string | null | undefined;
    readonly singleSelectOptionValue?: string | null | undefined;
    readonly textValue?: string | null | undefined;
}
/** Ways in which to filter lists of issues. */
export interface IssueFilters {
    readonly assignee?: string | null | undefined;
    readonly createdBy?: string | null | undefined;
    readonly issueFieldValues?: ReadonlyArray<IssueFieldValueFilter> | null | undefined;
    readonly labels?: ReadonlyArray<string> | null | undefined;
    readonly mentioned?: string | null | undefined;
    readonly milestone?: string | null | undefined;
    readonly milestoneNumber?: string | null | undefined;
    readonly since?: string | null | undefined;
    readonly states?: ReadonlyArray<"CLOSED" | "OPEN"> | null | undefined;
    readonly type?: string | null | undefined;
    readonly viewerSubscribed?: boolean | null | undefined;
}
/** Ways in which lists of issues can be ordered upon return. */
export interface IssueOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "COMMENTS" | "CREATED_AT" | "UPDATED_AT";
}
/** Ordering options for related issues */
export interface IssueRelatesToOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "RELATES_TO_ADDED_AT";
}
/** Specifies a target state for an issue, with optional metadata such as a
rationale, close reason, or duplicate reference. Suggestion metadata
(`rationale`, `confidence`, `suggest`) is only meaningful when `value` is
`CLOSED`; it is silently ignored otherwise. */
export interface IssueStateUpdateInput {
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly duplicateIssueId?: string | null | undefined;
    readonly rationale?: string | null | undefined;
    readonly stateReason?: "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | null | undefined;
    readonly suggest?: boolean | null | undefined;
    readonly value: "CLOSED" | "OPEN";
}
/** Ordering options for issue types connections */
export interface IssueTypeOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME";
}
/** Specifies an Issue Type to set on an issue, with optional metadata such as a rationale. */
export interface IssueTypeUpdateInput {
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly issueTypeId?: string | null | undefined;
    readonly rationale?: string | null | undefined;
    readonly suggest?: boolean | null | undefined;
}
/** Ways in which lists of labels can be ordered upon return. */
export interface LabelOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "ISSUE_COUNT" | "NAME";
}
/** Specifies a Label to set on an issue, with optional metadata such as a rationale. */
export interface LabelUpdateInput {
    readonly confidence?: "HIGH" | "LOW" | "MEDIUM" | null | undefined;
    readonly labelId: string;
    readonly rationale?: string | null | undefined;
    readonly suggest?: boolean | null | undefined;
}
/** Ordering options for language connections. */
export interface LanguageOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "SIZE";
}
/** Autogenerated input type of LinkProjectV2ToRepository */
export interface LinkProjectV2ToRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of LinkProjectV2ToTeam */
export interface LinkProjectV2ToTeamInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly teamId: string;
}
/** Autogenerated input type of LinkRepositoryToProject */
export interface LinkRepositoryToProjectInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of LockLockable */
export interface LockLockableInput {
    readonly clientMutationId?: string | null | undefined;
    readonly lockReason?: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null | undefined;
    readonly lockableId: string;
}
/** Ordering options for mannequins. */
export interface MannequinOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "LOGIN";
}
/** Autogenerated input type of MarkDiscussionCommentAsAnswer */
export interface MarkDiscussionCommentAsAnswerInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of MarkFileAsViewed */
export interface MarkFileAsViewedInput {
    readonly clientMutationId?: string | null | undefined;
    readonly path: string;
    readonly pullRequestId: string;
}
/** Autogenerated input type of MarkProjectV2AsTemplate */
export interface MarkProjectV2AsTemplateInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
}
/** Autogenerated input type of MarkPullRequestReadyForReview */
export interface MarkPullRequestReadyForReviewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph. */
export interface MaxFilePathLengthParametersInput {
    readonly maxFilePathLength: number;
}
/** Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph. */
export interface MaxFileSizeParametersInput {
    readonly ignoredFilePaths?: ReadonlyArray<string> | null | undefined;
    readonly maxFileSize: number;
}
/** Autogenerated input type of MergeBranch */
export interface MergeBranchInput {
    readonly authorEmail?: string | null | undefined;
    readonly base: string;
    readonly clientMutationId?: string | null | undefined;
    readonly commitMessage?: string | null | undefined;
    readonly head: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of MergePullRequest */
export interface MergePullRequestInput {
    readonly authorEmail?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly commitBody?: string | null | undefined;
    readonly commitHeadline?: string | null | undefined;
    readonly expectedHeadOid?: string | null | undefined;
    readonly mergeMethod?: "MERGE" | "REBASE" | "SQUASH" | null | undefined;
    readonly pullRequestId: string;
}
/** Merges must be performed via a merge queue. */
export interface MergeQueueParametersInput {
    readonly checkResponseTimeoutMinutes: number;
    readonly groupingStrategy: "ALLGREEN" | "HEADGREEN";
    readonly maxEntriesToBuild: number;
    readonly maxEntriesToMerge: number;
    readonly mergeMethod: "MERGE" | "REBASE" | "SQUASH";
    readonly minEntriesToMerge: number;
    readonly minEntriesToMergeWaitMinutes: number;
}
/** Ordering options for milestone connections. */
export interface MilestoneOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "DUE_DATE" | "NUMBER" | "UPDATED_AT";
}
/** Autogenerated input type of MinimizeComment */
export interface MinimizeCommentInput {
    readonly classifier: "ABUSE" | "DUPLICATE" | "LOW_QUALITY" | "OFF_TOPIC" | "OUTDATED" | "RESOLVED" | "SPAM";
    readonly clientMutationId?: string | null | undefined;
    readonly subjectId: string;
}
/** Autogenerated input type of MoveProjectCard */
export interface MoveProjectCardInput {
    readonly afterCardId?: string | null | undefined;
    readonly cardId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly columnId: string;
}
/** Autogenerated input type of MoveProjectColumn */
export interface MoveProjectColumnInput {
    readonly afterColumnId?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly columnId: string;
}
/** Ordering options for an organization's enterprise owner connections. */
export interface OrgEnterpriseOwnerOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "LOGIN";
}
/** Ordering options for organization connections. */
export interface OrganizationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "LOGIN";
}
/** Parameters to be used for the organization_property condition */
export interface OrganizationPropertyConditionTargetInput {
    readonly exclude: ReadonlyArray<OrganizationPropertyTargetDefinitionInput>;
    readonly include: ReadonlyArray<OrganizationPropertyTargetDefinitionInput>;
}
/** A property that must match */
export interface OrganizationPropertyTargetDefinitionInput {
    readonly name: string;
    readonly propertyValues: ReadonlyArray<string>;
}
/** Ways in which lists of package files can be ordered upon return. */
export interface PackageFileOrder {
    readonly direction?: "ASC" | "DESC" | null | undefined;
    readonly field?: "CREATED_AT" | null | undefined;
}
/** Ways in which lists of packages can be ordered upon return. */
export interface PackageOrder {
    readonly direction?: "ASC" | "DESC" | null | undefined;
    readonly field?: "CREATED_AT" | null | undefined;
}
/** Ways in which lists of package versions can be ordered upon return. */
export interface PackageVersionOrder {
    readonly direction?: "ASC" | "DESC" | null | undefined;
    readonly field?: "CREATED_AT" | null | undefined;
}
/** A reference to a single pending issue suggestion to apply. */
export interface PendingIssueSuggestionRef {
    readonly assigneeId?: string | null | undefined;
    readonly issueFieldId?: string | null | undefined;
    readonly issueTypeId?: string | null | undefined;
    readonly kind: "ASSIGNEE" | "CLOSE" | "FIELD" | "LABEL" | "TYPE";
    readonly labelId?: string | null | undefined;
}
/** Autogenerated input type of PinEnvironment */
export interface PinEnvironmentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly environmentId: string;
    readonly pinned: boolean;
}
/** Autogenerated input type of PinIssueComment */
export interface PinIssueCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueCommentId: string;
}
/** Autogenerated input type of PinIssue */
export interface PinIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Ordering options for pinned environments */
export interface PinnedEnvironmentOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "POSITION";
}
/** An issue or PR and its owning repository to be used in a project card. */
export interface ProjectCardImport {
    readonly number: number;
    readonly repository: string;
}
/** A project column and a list of its issues and PRs. */
export interface ProjectColumnImport {
    readonly columnName: string;
    readonly issues?: ReadonlyArray<ProjectCardImport> | null | undefined;
    readonly position: number;
}
/** Ways in which lists of projects can be ordered upon return. */
export interface ProjectOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "UPDATED_AT";
}
/** A collaborator to update on a project. Only one of the userId or teamId should be provided. */
export interface ProjectV2Collaborator {
    readonly role: "ADMIN" | "NONE" | "READER" | "WRITER";
    readonly teamId?: string | null | undefined;
    readonly userId?: string | null | undefined;
}
/** Ordering options for project v2 field connections */
export interface ProjectV2FieldOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "POSITION";
}
/** The values that can be used to update a field of an item inside a Project. Only 1 value can be updated at a time. */
export interface ProjectV2FieldValue {
    readonly date?: string | null | undefined;
    readonly iterationId?: string | null | undefined;
    readonly multiSelectOptionIds?: ReadonlyArray<string> | null | undefined;
    readonly number?: number | null | undefined;
    readonly singleSelectOptionId?: string | null | undefined;
    readonly text?: string | null | undefined;
}
/** Ways in which to filter lists of projects. */
export interface ProjectV2Filters {
    readonly state?: "CLOSED" | "OPEN" | null | undefined;
}
/** Ordering options for project v2 item field value connections */
export interface ProjectV2ItemFieldValueOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "POSITION";
}
/** Ordering options for project v2 item connections */
export interface ProjectV2ItemOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "POSITION";
}
/** Represents an iteration */
export interface ProjectV2Iteration {
    readonly duration: number;
    readonly id?: string | null | undefined;
    readonly startDate: string;
    readonly title: string;
}
/** Represents an iteration field configuration. */
export interface ProjectV2IterationFieldConfigurationInput {
    readonly duration: number;
    readonly iterations: ReadonlyArray<ProjectV2Iteration>;
    readonly startDate: string;
}
/** Represents a multi select field option */
export interface ProjectV2MultiSelectFieldOptionInput {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string;
    readonly id?: string | null | undefined;
    readonly name: string;
}
/** Ways in which lists of projects can be ordered upon return. */
export interface ProjectV2Order {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NUMBER" | "TITLE" | "UPDATED_AT";
}
/** Represents a single select field option */
export interface ProjectV2SingleSelectFieldOptionInput {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string;
    readonly id?: string | null | undefined;
    readonly name: string;
}
/** Ways in which project v2 status updates can be ordered. */
export interface ProjectV2StatusOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Configuration for a ProjectV2 view. */
export interface ProjectV2ViewConfigurationInput {
    readonly visibleFieldIds?: ReadonlyArray<string> | null | undefined;
}
/** Ordering options for project v2 view connections */
export interface ProjectV2ViewOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "POSITION";
}
/** Ordering options for project v2 workflows connections */
export interface ProjectV2WorkflowOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "NUMBER" | "UPDATED_AT";
}
/** Autogenerated input type of PromoteRepositoryCustomProperty */
export interface PromoteRepositoryCustomPropertyInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryCustomPropertyId: string;
}
/** A property that must match */
export interface PropertyTargetDefinitionInput {
    readonly name: string;
    readonly propertyValues: ReadonlyArray<string>;
    readonly source?: string | null | undefined;
}
/** Autogenerated input type of PublishSponsorsTier */
export interface PublishSponsorsTierInput {
    readonly clientMutationId?: string | null | undefined;
    readonly tierId: string;
}
/** Ways in which lists of issues can be ordered upon return. */
export interface PullRequestOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "UPDATED_AT";
}
/** Require all commits be made to a non-target branch and submitted via a pull request before they can be merged. */
export interface PullRequestParametersInput {
    readonly allowedMergeMethods?: ReadonlyArray<"MERGE" | "REBASE" | "SQUASH"> | null | undefined;
    readonly dismissStaleReviewsOnPush: boolean;
    readonly dismissalRestriction?: DismissalRestrictionInput | null | undefined;
    readonly requireCodeOwnerReview: boolean;
    readonly requireExtraApprovalForUnattributedChanges?: boolean | null | undefined;
    readonly requireLastPushApproval: boolean;
    readonly requiredApprovingReviewCount: number;
    readonly requiredReviewThreadResolution: boolean;
    readonly requiredReviewers?: ReadonlyArray<RequiredReviewerConfigurationInput> | null | undefined;
}
/** Ways in which lists of reactions can be ordered upon return. */
export interface ReactionOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Parameters to be used for the ref_name condition */
export interface RefNameConditionTargetInput {
    readonly exclude: ReadonlyArray<string>;
    readonly include: ReadonlyArray<string>;
}
/** Ways in which lists of git refs can be ordered upon return. */
export interface RefOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "ALPHABETICAL" | "TAG_COMMIT_DATE";
}
/** A ref update */
export interface RefUpdate {
    readonly afterOid: string;
    readonly beforeOid?: string | null | undefined;
    readonly force?: boolean | null | undefined;
    readonly name: string;
}
/** Autogenerated input type of RegenerateEnterpriseIdentityProviderRecoveryCodes */
export interface RegenerateEnterpriseIdentityProviderRecoveryCodesInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
}
/** Autogenerated input type of RegenerateVerifiableDomainToken */
export interface RegenerateVerifiableDomainTokenInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of RejectDeployments */
export interface RejectDeploymentsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly comment?: string | null | undefined;
    readonly environmentIds: ReadonlyArray<string>;
    readonly workflowRunId: string;
}
/** Autogenerated input type of RejectPendingIssueSuggestions */
export interface RejectPendingIssueSuggestionsInput {
    readonly actorId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly suggestions: ReadonlyArray<PendingIssueSuggestionRef>;
}
/** Ways in which lists of releases can be ordered upon return. */
export interface ReleaseOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME";
}
/** Autogenerated input type of RemoveAssigneesFromAssignable */
export interface RemoveAssigneesFromAssignableInput {
    readonly assignableId: string;
    readonly assigneeIds: ReadonlyArray<string>;
    readonly clientMutationId?: string | null | undefined;
}
/** Autogenerated input type of RemoveBlockedBy */
export interface RemoveBlockedByInput {
    readonly blockingIssueId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Autogenerated input type of RemoveCloseIssueReferences */
export interface RemoveCloseIssueReferencesInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly pullRequestIds: ReadonlyArray<string>;
}
/** Autogenerated input type of RemoveEnterpriseAdmin */
export interface RemoveEnterpriseAdminInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
}
/** Autogenerated input type of RemoveEnterpriseIdentityProvider */
export interface RemoveEnterpriseIdentityProviderInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
}
/** Autogenerated input type of RemoveEnterpriseMember */
export interface RemoveEnterpriseMemberInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly userId: string;
}
/** Autogenerated input type of RemoveEnterpriseOrganization */
export interface RemoveEnterpriseOrganizationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly organizationId: string;
}
/** Autogenerated input type of RemoveEnterpriseSupportEntitlement */
export interface RemoveEnterpriseSupportEntitlementInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
}
/** Autogenerated input type of RemoveLabelsFromLabelable */
export interface RemoveLabelsFromLabelableInput {
    readonly clientMutationId?: string | null | undefined;
    readonly labelIds: ReadonlyArray<string>;
    readonly labelableId: string;
}
/** Autogenerated input type of RemoveOutsideCollaborator */
export interface RemoveOutsideCollaboratorInput {
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
    readonly userId: string;
}
/** Autogenerated input type of RemovePullRequestCreationCapBypassUsers */
export interface RemovePullRequestCreationCapBypassUsersInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
    readonly userIds: ReadonlyArray<string>;
}
/** Autogenerated input type of RemoveReaction */
export interface RemoveReactionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly content: "CONFUSED" | "EYES" | "HEART" | "HOORAY" | "LAUGH" | "ROCKET" | "THUMBS_DOWN" | "THUMBS_UP";
    readonly subjectId: string;
}
/** Autogenerated input type of RemoveRelatesTo */
export interface RemoveRelatesToInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly relatedIssueId: string;
}
/** Autogenerated input type of RemoveStar */
export interface RemoveStarInput {
    readonly clientMutationId?: string | null | undefined;
    readonly starrableId: string;
}
/** Autogenerated input type of RemoveSubIssue */
export interface RemoveSubIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly subIssueId: string;
}
/** Autogenerated input type of RemoveUpvote */
export interface RemoveUpvoteInput {
    readonly clientMutationId?: string | null | undefined;
    readonly subjectId: string;
}
/** Autogenerated input type of ReopenDiscussion */
export interface ReopenDiscussionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly discussionId: string;
}
/** Autogenerated input type of ReopenIssue */
export interface ReopenIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Autogenerated input type of ReopenPullRequest */
export interface ReopenPullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Autogenerated input type of ReorderEnvironment */
export interface ReorderEnvironmentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly environmentId: string;
    readonly position: number;
}
/** Autogenerated input type of ReplaceActorsForAssignable */
export interface ReplaceActorsForAssignableInput {
    readonly actorIds?: ReadonlyArray<string> | null | undefined;
    readonly actorLogins?: ReadonlyArray<string> | null | undefined;
    readonly agentAssignment?: AgentAssignmentInput | null | undefined;
    readonly assignableId: string;
    readonly assignees?: ReadonlyArray<AssigneeUpdateInput> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
}
/** Parameters to be used for the repository_id condition */
export interface RepositoryIdConditionTargetInput {
    readonly repositoryIds: ReadonlyArray<string>;
}
/** Ordering options for repository invitation connections. */
export interface RepositoryInvitationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ordering options for repository migrations. */
export interface RepositoryMigrationOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Parameters to be used for the repository_name condition */
export interface RepositoryNameConditionTargetInput {
    readonly exclude: ReadonlyArray<string>;
    readonly include: ReadonlyArray<string>;
    readonly protected?: boolean | null | undefined;
}
/** Ordering options for repository connections */
export interface RepositoryOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "PUSHED_AT" | "STARGAZERS" | "UPDATED_AT";
}
/** Parameters to be used for the repository_property condition */
export interface RepositoryPropertyConditionTargetInput {
    readonly exclude: ReadonlyArray<PropertyTargetDefinitionInput>;
    readonly include: ReadonlyArray<PropertyTargetDefinitionInput>;
}
/** Specifies the conditions required for a ruleset to evaluate */
export interface RepositoryRuleConditionsInput {
    readonly organizationProperty?: OrganizationPropertyConditionTargetInput | null | undefined;
    readonly refName?: RefNameConditionTargetInput | null | undefined;
    readonly repositoryId?: RepositoryIdConditionTargetInput | null | undefined;
    readonly repositoryName?: RepositoryNameConditionTargetInput | null | undefined;
    readonly repositoryProperty?: RepositoryPropertyConditionTargetInput | null | undefined;
}
/** Specifies the attributes for a new or updated rule. */
export interface RepositoryRuleInput {
    readonly id?: string | null | undefined;
    readonly parameters?: RuleParametersInput | null | undefined;
    readonly type: "AUTHORIZATION" | "BRANCH_NAME_PATTERN" | "CODE_COVERAGE" | "CODE_QUALITY" | "CODE_SCANNING" | "COMMITTER_EMAIL_PATTERN" | "COMMIT_AUTHOR_EMAIL_PATTERN" | "COMMIT_MESSAGE_PATTERN" | "COPILOT_CODE_REVIEW" | "CREATION" | "DELETION" | "FILE_EXTENSION_RESTRICTION" | "FILE_PATH_RESTRICTION" | "LICENSE_COMPLIANCE_SCANNING" | "LOCK_BRANCH" | "MAX_FILE_PATH_LENGTH" | "MAX_FILE_SIZE" | "MAX_REF_UPDATES" | "MERGE_QUEUE" | "MERGE_QUEUE_LOCKED_REF" | "NON_FAST_FORWARD" | "PULL_REQUEST" | "REQUIRED_DEPLOYMENTS" | "REQUIRED_LINEAR_HISTORY" | "REQUIRED_REVIEW_THREAD_RESOLUTION" | "REQUIRED_SIGNATURES" | "REQUIRED_STATUS_CHECKS" | "REQUIRED_WORKFLOW_STATUS_CHECKS" | "SECRET_SCANNING" | "TAG" | "TAG_NAME_PATTERN" | "UPDATE" | "WORKFLOWS" | "WORKFLOW_UPDATES";
}
/** Ordering options for repository rules. */
export interface RepositoryRuleOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "TYPE" | "UPDATED_AT";
}
/** Specifies the attributes for a new or updated ruleset bypass actor. Exactly one
of `actor_id`, `repository_role_database_id`, `organization_admin`,
`enterprise_owner`, `enterprise_role_database_id`, or `deploy_key` should be specified. */
export interface RepositoryRulesetBypassActorInput {
    readonly actorId?: string | null | undefined;
    readonly bypassMode: "ALWAYS" | "EXEMPT" | "PULL_REQUEST";
    readonly deployKey?: boolean | null | undefined;
    readonly enterpriseOwner?: boolean | null | undefined;
    readonly enterpriseRole?: boolean | null | undefined;
    readonly enterpriseRoleDatabaseId?: string | null | undefined;
    readonly organizationAdmin?: boolean | null | undefined;
    readonly repositoryRoleDatabaseId?: number | null | undefined;
}
/** Autogenerated input type of ReprioritizeSubIssue */
export interface ReprioritizeSubIssueInput {
    readonly afterId?: string | null | undefined;
    readonly beforeId?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly subIssueId: string;
}
/** Autogenerated input type of RequestReviewsByLogin */
export interface RequestReviewsByLoginInput {
    readonly botLogins?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
    readonly teamSlugs?: ReadonlyArray<string> | null | undefined;
    readonly union?: boolean | null | undefined;
    readonly userLogins?: ReadonlyArray<string> | null | undefined;
}
/** Autogenerated input type of RequestReviews */
export interface RequestReviewsInput {
    readonly botIds?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
    readonly teamIds?: ReadonlyArray<string> | null | undefined;
    readonly union?: boolean | null | undefined;
    readonly userIds?: ReadonlyArray<string> | null | undefined;
}
/** Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule. */
export interface RequiredDeploymentsParametersInput {
    readonly requiredDeploymentEnvironments: ReadonlyArray<string>;
}
/** A reviewing team, and file patterns describing which files they must approve changes to. */
export interface RequiredReviewerConfigurationInput {
    readonly filePatterns: ReadonlyArray<string>;
    readonly minimumApprovals: number;
    readonly reviewerId: string;
}
/** Specifies the attributes for a new or updated required status check. */
export interface RequiredStatusCheckInput {
    readonly appId?: string | null | undefined;
    readonly context: string;
}
/** Choose which status checks must pass before the ref is updated. When enabled,
commits must first be pushed to another ref where the checks pass. */
export interface RequiredStatusChecksParametersInput {
    readonly doNotEnforceOnCreate?: boolean | null | undefined;
    readonly requiredStatusChecks: ReadonlyArray<StatusCheckConfigurationInput>;
    readonly strictRequiredStatusChecksPolicy: boolean;
}
/** Autogenerated input type of RerequestCheckSuite */
export interface RerequestCheckSuiteInput {
    readonly checkSuiteId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
}
/** Autogenerated input type of RerequestReviews */
export interface RerequestReviewsInput {
    readonly botIds?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
    readonly teamIds?: ReadonlyArray<string> | null | undefined;
    readonly userIds?: ReadonlyArray<string> | null | undefined;
}
/** Autogenerated input type of ResolveReviewThread */
export interface ResolveReviewThreadInput {
    readonly clientMutationId?: string | null | undefined;
    readonly resolutionReason?: "ADDRESSED" | "INVALID" | "WONT_FIX" | null | undefined;
    readonly threadId: string;
}
/** Autogenerated input type of RetireSponsorsTier */
export interface RetireSponsorsTierInput {
    readonly clientMutationId?: string | null | undefined;
    readonly tierId: string;
}
/** Autogenerated input type of RevertPullRequest */
export interface RevertPullRequestInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly draft?: boolean | null | undefined;
    readonly pullRequestId: string;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of RevokeEnterpriseOrganizationsMigratorRole */
export interface RevokeEnterpriseOrganizationsMigratorRoleInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
}
/** Autogenerated input type of RevokeMigratorRole */
export interface RevokeMigratorRoleInput {
    readonly actor: string;
    readonly actorType: "TEAM" | "USER";
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
}
/** Specifies the parameters for a `RepositoryRule` object. Only one of the fields should be specified. */
export interface RuleParametersInput {
    readonly branchNamePattern?: BranchNamePatternParametersInput | null | undefined;
    readonly codeCoverage?: CodeCoverageParametersInput | null | undefined;
    readonly codeQuality?: CodeQualityParametersInput | null | undefined;
    readonly codeScanning?: CodeScanningParametersInput | null | undefined;
    readonly commitAuthorEmailPattern?: CommitAuthorEmailPatternParametersInput | null | undefined;
    readonly commitMessagePattern?: CommitMessagePatternParametersInput | null | undefined;
    readonly committerEmailPattern?: CommitterEmailPatternParametersInput | null | undefined;
    readonly copilotCodeReview?: CopilotCodeReviewParametersInput | null | undefined;
    readonly fileExtensionRestriction?: FileExtensionRestrictionParametersInput | null | undefined;
    readonly filePathRestriction?: FilePathRestrictionParametersInput | null | undefined;
    readonly maxFilePathLength?: MaxFilePathLengthParametersInput | null | undefined;
    readonly maxFileSize?: MaxFileSizeParametersInput | null | undefined;
    readonly mergeQueue?: MergeQueueParametersInput | null | undefined;
    readonly pullRequest?: PullRequestParametersInput | null | undefined;
    readonly requiredDeployments?: RequiredDeploymentsParametersInput | null | undefined;
    readonly requiredStatusChecks?: RequiredStatusChecksParametersInput | null | undefined;
    readonly tagNamePattern?: TagNamePatternParametersInput | null | undefined;
    readonly update?: UpdateParametersInput | null | undefined;
    readonly workflows?: WorkflowsParametersInput | null | undefined;
}
/** Ordering options for saved reply connections. */
export interface SavedReplyOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "UPDATED_AT";
}
/** An advisory identifier to filter results on. */
export interface SecurityAdvisoryIdentifierFilter {
    readonly type: "CVE" | "GHSA";
    readonly value: string;
}
/** Ordering options for security advisory connections */
export interface SecurityAdvisoryOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "EPSS_PERCENTAGE" | "EPSS_PERCENTILE" | "PUBLISHED_AT" | "UPDATED_AT";
}
/** Ordering options for security vulnerability connections */
export interface SecurityVulnerabilityOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "UPDATED_AT";
}
/** Autogenerated input type of SetEnterpriseIdentityProvider */
export interface SetEnterpriseIdentityProviderInput {
    readonly clientMutationId?: string | null | undefined;
    readonly digestMethod: "SHA1" | "SHA256" | "SHA384" | "SHA512";
    readonly enterpriseId: string;
    readonly idpCertificate: string;
    readonly issuer?: string | null | undefined;
    readonly signatureMethod: "RSA_SHA1" | "RSA_SHA256" | "RSA_SHA384" | "RSA_SHA512";
    readonly ssoUrl: string;
}
/** Autogenerated input type of SetIssueFieldValue */
export interface SetIssueFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueFields: ReadonlyArray<IssueFieldCreateOrUpdateInput>;
    readonly issueId: string;
}
/** Autogenerated input type of SetOrganizationInteractionLimit */
export interface SetOrganizationInteractionLimitInput {
    readonly clientMutationId?: string | null | undefined;
    readonly expiry?: "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "SIX_MONTHS" | "THREE_DAYS" | null | undefined;
    readonly limit: "COLLABORATORS_ONLY" | "CONTRIBUTORS_ONLY" | "EXISTING_USERS" | "NO_LIMIT";
    readonly organizationId: string;
}
/** Autogenerated input type of SetRepositoryCustomPropertyValues */
export interface SetRepositoryCustomPropertyValuesInput {
    readonly clientMutationId?: string | null | undefined;
    readonly properties: ReadonlyArray<CustomPropertyValueInput>;
    readonly repositoryId: string;
}
/** Autogenerated input type of SetRepositoryInteractionLimit */
export interface SetRepositoryInteractionLimitInput {
    readonly clientMutationId?: string | null | undefined;
    readonly expiry?: "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "SIX_MONTHS" | "THREE_DAYS" | null | undefined;
    readonly limit: "COLLABORATORS_ONLY" | "CONTRIBUTORS_ONLY" | "EXISTING_USERS" | "NO_LIMIT";
    readonly repositoryId: string;
}
/** Autogenerated input type of SetUserInteractionLimit */
export interface SetUserInteractionLimitInput {
    readonly clientMutationId?: string | null | undefined;
    readonly expiry?: "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "SIX_MONTHS" | "THREE_DAYS" | null | undefined;
    readonly limit: "COLLABORATORS_ONLY" | "CONTRIBUTORS_ONLY" | "EXISTING_USERS" | "NO_LIMIT";
    readonly userId: string;
}
/** Ordering options for connections to get sponsor entities and associated USD amounts for GitHub Sponsors. */
export interface SponsorAndLifetimeValueOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "LIFETIME_VALUE" | "SPONSOR_LOGIN" | "SPONSOR_RELEVANCE";
}
/** Ordering options for connections to get sponsor entities for GitHub Sponsors. */
export interface SponsorOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "LOGIN" | "RELEVANCE";
}
/** Ordering options for connections to get sponsorable entities for GitHub Sponsors. */
export interface SponsorableOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "LOGIN";
}
/** Ordering options for GitHub Sponsors activity connections. */
export interface SponsorsActivityOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "TIMESTAMP";
}
/** Ordering options for Sponsors tiers connections. */
export interface SponsorsTierOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "MONTHLY_PRICE_IN_CENTS";
}
/** Ordering options for sponsorship newsletter connections. */
export interface SponsorshipNewsletterOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ordering options for sponsorship connections. */
export interface SponsorshipOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Ways in which star connections can be ordered. */
export interface StarOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "STARRED_AT";
}
/** Autogenerated input type of StartOrganizationMigration */
export interface StartOrganizationMigrationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly sourceAccessToken: string;
    readonly sourceOrgUrl: string;
    readonly targetEnterpriseId: string;
    readonly targetOrgName: string;
}
/** Autogenerated input type of StartRepositoryMigration */
export interface StartRepositoryMigrationInput {
    readonly accessToken?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly continueOnError?: boolean | null | undefined;
    readonly gitArchiveUrl?: string | null | undefined;
    readonly githubPat?: string | null | undefined;
    readonly lockSource?: boolean | null | undefined;
    readonly metadataArchiveUrl?: string | null | undefined;
    readonly ownerId: string;
    readonly repositoryName: string;
    readonly skipReleases?: boolean | null | undefined;
    readonly sourceId: string;
    readonly sourceRepositoryUrl: string;
    readonly targetRepoVisibility?: string | null | undefined;
}
/** Required status check */
export interface StatusCheckConfigurationInput {
    readonly context: string;
    readonly integrationId?: number | null | undefined;
}
/** Autogenerated input type of SubmitPullRequestReview */
export interface SubmitPullRequestReviewInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly event: "APPROVE" | "COMMENT" | "DISMISS" | "REQUEST_CHANGES";
    readonly pullRequestId?: string | null | undefined;
    readonly pullRequestReviewId?: string | null | undefined;
}
/** Parameters to be used for the tag_name_pattern rule */
export interface TagNamePatternParametersInput {
    readonly name?: string | null | undefined;
    readonly negate?: boolean | null | undefined;
    readonly operator: string;
    readonly pattern: string;
}
/** Ordering options for team member connections */
export interface TeamMemberOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "LOGIN";
}
/** Ways in which team connections can be ordered. */
export interface TeamOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "NAME";
}
/** Ordering options for team repository connections */
export interface TeamRepositoryOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "NAME" | "PERMISSION" | "PUSHED_AT" | "STARGAZERS" | "UPDATED_AT";
}
/** Autogenerated input type of TransferEnterpriseOrganization */
export interface TransferEnterpriseOrganizationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly destinationEnterpriseId: string;
    readonly organizationId: string;
}
/** Autogenerated input type of TransferIssue */
export interface TransferIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly createLabelsIfMissing?: boolean | null | undefined;
    readonly issueId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of UnarchiveProjectV2Item */
export interface UnarchiveProjectV2ItemInput {
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly projectId: string;
}
/** Autogenerated input type of UnarchivePullRequest */
export interface UnarchivePullRequestInput {
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestId: string;
}
/** Autogenerated input type of UnarchiveRepository */
export interface UnarchiveRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
}
/** Autogenerated input type of UnfollowOrganization */
export interface UnfollowOrganizationInput {
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
}
/** Autogenerated input type of UnfollowUser */
export interface UnfollowUserInput {
    readonly clientMutationId?: string | null | undefined;
    readonly userId: string;
}
/** Autogenerated input type of UnlinkProjectV2FromRepository */
export interface UnlinkProjectV2FromRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of UnlinkProjectV2FromTeam */
export interface UnlinkProjectV2FromTeamInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly teamId: string;
}
/** Autogenerated input type of UnlinkRepositoryFromProject */
export interface UnlinkRepositoryFromProjectInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
    readonly repositoryId: string;
}
/** Autogenerated input type of UnlockLockable */
export interface UnlockLockableInput {
    readonly clientMutationId?: string | null | undefined;
    readonly lockableId: string;
}
/** Autogenerated input type of UnmarkDiscussionCommentAsAnswer */
export interface UnmarkDiscussionCommentAsAnswerInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of UnmarkFileAsViewed */
export interface UnmarkFileAsViewedInput {
    readonly clientMutationId?: string | null | undefined;
    readonly path: string;
    readonly pullRequestId: string;
}
/** Autogenerated input type of UnmarkIssueAsDuplicate */
export interface UnmarkIssueAsDuplicateInput {
    readonly canonicalId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly duplicateId: string;
}
/** Autogenerated input type of UnmarkProjectV2AsTemplate */
export interface UnmarkProjectV2AsTemplateInput {
    readonly clientMutationId?: string | null | undefined;
    readonly projectId: string;
}
/** Autogenerated input type of UnminimizeComment */
export interface UnminimizeCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly subjectId: string;
}
/** Autogenerated input type of UnpinIssueComment */
export interface UnpinIssueCommentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueCommentId: string;
}
/** Autogenerated input type of UnpinIssue */
export interface UnpinIssueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
}
/** Autogenerated input type of UnresolveReviewThread */
export interface UnresolveReviewThreadInput {
    readonly clientMutationId?: string | null | undefined;
    readonly threadId: string;
}
/** Autogenerated input type of UpdateBranchProtectionRule */
export interface UpdateBranchProtectionRuleInput {
    readonly allowsDeletions?: boolean | null | undefined;
    readonly allowsForcePushes?: boolean | null | undefined;
    readonly blocksCreations?: boolean | null | undefined;
    readonly branchProtectionRuleId: string;
    readonly bypassForcePushActorIds?: ReadonlyArray<string> | null | undefined;
    readonly bypassPullRequestActorIds?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly dismissesStaleReviews?: boolean | null | undefined;
    readonly isAdminEnforced?: boolean | null | undefined;
    readonly lockAllowsFetchAndMerge?: boolean | null | undefined;
    readonly lockBranch?: boolean | null | undefined;
    readonly pattern?: string | null | undefined;
    readonly pushActorIds?: ReadonlyArray<string> | null | undefined;
    readonly requireLastPushApproval?: boolean | null | undefined;
    readonly requiredApprovingReviewCount?: number | null | undefined;
    readonly requiredDeploymentEnvironments?: ReadonlyArray<string> | null | undefined;
    readonly requiredStatusCheckContexts?: ReadonlyArray<string> | null | undefined;
    readonly requiredStatusChecks?: ReadonlyArray<RequiredStatusCheckInput> | null | undefined;
    readonly requiresApprovingReviews?: boolean | null | undefined;
    readonly requiresCodeOwnerReviews?: boolean | null | undefined;
    readonly requiresCommitSignatures?: boolean | null | undefined;
    readonly requiresConversationResolution?: boolean | null | undefined;
    readonly requiresDeployments?: boolean | null | undefined;
    readonly requiresLinearHistory?: boolean | null | undefined;
    readonly requiresStatusChecks?: boolean | null | undefined;
    readonly requiresStrictStatusChecks?: boolean | null | undefined;
    readonly restrictsPushes?: boolean | null | undefined;
    readonly restrictsReviewDismissals?: boolean | null | undefined;
    readonly reviewDismissalActorIds?: ReadonlyArray<string> | null | undefined;
}
/** Autogenerated input type of UpdateCheckRun */
export interface UpdateCheckRunInput {
    readonly actions?: ReadonlyArray<CheckRunAction> | null | undefined;
    readonly checkRunId: string;
    readonly clientMutationId?: string | null | undefined;
    readonly completedAt?: string | null | undefined;
    readonly conclusion?: "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | null | undefined;
    readonly detailsUrl?: string | null | undefined;
    readonly externalId?: string | null | undefined;
    readonly name?: string | null | undefined;
    readonly output?: CheckRunOutput | null | undefined;
    readonly repositoryId: string;
    readonly startedAt?: string | null | undefined;
    readonly status?: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "WAITING" | null | undefined;
}
/** Autogenerated input type of UpdateCheckSuitePreferences */
export interface UpdateCheckSuitePreferencesInput {
    readonly autoTriggerPreferences: ReadonlyArray<CheckSuiteAutoTriggerPreference>;
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
}
/** Autogenerated input type of UpdateDiscussionComment */
export interface UpdateDiscussionCommentInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly commentId: string;
}
/** Autogenerated input type of UpdateDiscussion */
export interface UpdateDiscussionInput {
    readonly body?: string | null | undefined;
    readonly categoryId?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly discussionId: string;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of UpdateEnterpriseAdministratorRole */
export interface UpdateEnterpriseAdministratorRoleInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly login: string;
    readonly role: "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED";
}
/** Autogenerated input type of UpdateEnterpriseAllowPrivateRepositoryForkingSetting */
export interface UpdateEnterpriseAllowPrivateRepositoryForkingSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly policyValue?: "ENTERPRISE_ORGANIZATIONS" | "ENTERPRISE_ORGANIZATIONS_USER_ACCOUNTS" | "EVERYWHERE" | "SAME_ORGANIZATION" | "SAME_ORGANIZATION_USER_ACCOUNTS" | "USER_ACCOUNTS" | null | undefined;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseDefaultRepositoryPermissionSetting */
export interface UpdateEnterpriseDefaultRepositoryPermissionSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "ADMIN" | "NONE" | "NO_POLICY" | "READ" | "WRITE";
}
/** Autogenerated input type of UpdateEnterpriseDeployKeySetting */
export interface UpdateEnterpriseDeployKeySettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanChangeRepositoryVisibilitySetting */
export interface UpdateEnterpriseMembersCanChangeRepositoryVisibilitySettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanCreateRepositoriesSetting */
export interface UpdateEnterpriseMembersCanCreateRepositoriesSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly membersCanCreateInternalRepositories?: boolean | null | undefined;
    readonly membersCanCreatePrivateRepositories?: boolean | null | undefined;
    readonly membersCanCreatePublicRepositories?: boolean | null | undefined;
    readonly membersCanCreateRepositoriesPolicyEnabled?: boolean | null | undefined;
    readonly settingValue?: "ALL" | "DISABLED" | "NO_POLICY" | "PRIVATE" | "PUBLIC" | null | undefined;
}
/** Autogenerated input type of UpdateEnterpriseMembersCanDeleteIssuesSetting */
export interface UpdateEnterpriseMembersCanDeleteIssuesSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanDeleteRepositoriesSetting */
export interface UpdateEnterpriseMembersCanDeleteRepositoriesSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanInviteCollaboratorsSetting */
export interface UpdateEnterpriseMembersCanInviteCollaboratorsSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanMakePurchasesSetting */
export interface UpdateEnterpriseMembersCanMakePurchasesSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanUpdateProtectedBranchesSetting */
export interface UpdateEnterpriseMembersCanUpdateProtectedBranchesSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseMembersCanViewDependencyInsightsSetting */
export interface UpdateEnterpriseMembersCanViewDependencyInsightsSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseOrganizationProjectsSetting */
export interface UpdateEnterpriseOrganizationProjectsSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseOwnerOrganizationRole */
export interface UpdateEnterpriseOwnerOrganizationRoleInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly organizationId: string;
    readonly organizationRole: "DIRECT_MEMBER" | "OWNER" | "UNAFFILIATED";
}
/** Autogenerated input type of UpdateEnterpriseProfile */
export interface UpdateEnterpriseProfileInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly enterpriseId: string;
    readonly location?: string | null | undefined;
    readonly name?: string | null | undefined;
    readonly securityContactEmail?: string | null | undefined;
    readonly websiteUrl?: string | null | undefined;
}
/** Autogenerated input type of UpdateEnterpriseRepositoryProjectsSetting */
export interface UpdateEnterpriseRepositoryProjectsSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "DISABLED" | "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSetting */
export interface UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "INSECURE" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnterpriseTwoFactorAuthenticationRequiredSetting */
export interface UpdateEnterpriseTwoFactorAuthenticationRequiredSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enterpriseId: string;
    readonly settingValue: "ENABLED" | "NO_POLICY";
}
/** Autogenerated input type of UpdateEnvironment */
export interface UpdateEnvironmentInput {
    readonly clientMutationId?: string | null | undefined;
    readonly environmentId: string;
    readonly preventSelfReview?: boolean | null | undefined;
    readonly reviewers?: ReadonlyArray<string> | null | undefined;
    readonly waitTimer?: number | null | undefined;
}
/** Autogenerated input type of UpdateIpAllowListEnabledSetting */
export interface UpdateIpAllowListEnabledSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly settingValue: "DISABLED" | "ENABLED";
}
/** Autogenerated input type of UpdateIpAllowListEntry */
export interface UpdateIpAllowListEntryInput {
    readonly allowListValue: string;
    readonly clientMutationId?: string | null | undefined;
    readonly ipAllowListEntryId: string;
    readonly isActive: boolean;
    readonly name?: string | null | undefined;
}
/** Autogenerated input type of UpdateIpAllowListForInstalledAppsEnabledSetting */
export interface UpdateIpAllowListForInstalledAppsEnabledSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly settingValue: "DISABLED" | "ENABLED";
}
/** Autogenerated input type of UpdateIpAllowListUserLevelEnforcementEnabledSetting */
export interface UpdateIpAllowListUserLevelEnforcementEnabledSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly settingValue: "DISABLED" | "ENABLED";
}
/** Autogenerated input type of UpdateIssueComment */
export interface UpdateIssueCommentInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** Autogenerated input type of UpdateIssueField */
export interface UpdateIssueFieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly id: string;
    readonly name?: string | null | undefined;
    readonly options?: ReadonlyArray<IssueFieldSingleSelectOptionInput> | null | undefined;
    readonly visibility?: "ALL" | "ORG_ONLY" | null | undefined;
}
/** Autogenerated input type of UpdateIssueFieldValue */
export interface UpdateIssueFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueField: IssueFieldCreateOrUpdateInput;
    readonly issueId: string;
}
/** Autogenerated input type of UpdateIssue */
export interface UpdateIssueInput {
    readonly agentAssignment?: AgentAssignmentInput | null | undefined;
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly assignees?: ReadonlyArray<AssigneeUpdateInput> | null | undefined;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
    readonly issueFieldUpdates?: ReadonlyArray<IssueFieldUpdateInput> | null | undefined;
    readonly issueType?: IssueTypeUpdateInput | null | undefined;
    readonly issueTypeId?: string | null | undefined;
    readonly labelIds?: ReadonlyArray<string> | null | undefined;
    readonly labels?: ReadonlyArray<LabelUpdateInput> | null | undefined;
    readonly milestoneId?: string | null | undefined;
    readonly projectIds?: ReadonlyArray<string> | null | undefined;
    readonly state?: "CLOSED" | "OPEN" | null | undefined;
    readonly stateInput?: IssueStateUpdateInput | null | undefined;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of UpdateIssueIssueType */
export interface UpdateIssueIssueTypeInput {
    readonly clientMutationId?: string | null | undefined;
    readonly issueId: string;
    readonly issueTypeId?: string | null | undefined;
}
/** Autogenerated input type of UpdateIssueType */
export interface UpdateIssueTypeInput {
    readonly clientMutationId?: string | null | undefined;
    readonly color?: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW" | null | undefined;
    readonly description?: string | null | undefined;
    readonly isEnabled?: boolean | null | undefined;
    readonly issueTypeId: string;
    readonly name?: string | null | undefined;
}
/** Autogenerated input type of UpdateLabel */
export interface UpdateLabelInput {
    readonly clientMutationId?: string | null | undefined;
    readonly color?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly id: string;
    readonly name?: string | null | undefined;
}
/** Autogenerated input type of UpdateNotificationRestrictionSetting */
export interface UpdateNotificationRestrictionSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly ownerId: string;
    readonly settingValue: "DISABLED" | "ENABLED";
}
/** Autogenerated input type of UpdateOrganizationAllowPrivateRepositoryForkingSetting */
export interface UpdateOrganizationAllowPrivateRepositoryForkingSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly forkingEnabled: boolean;
    readonly organizationId: string;
}
/** Autogenerated input type of UpdateOrganizationWebCommitSignoffSetting */
export interface UpdateOrganizationWebCommitSignoffSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly organizationId: string;
    readonly webCommitSignoffRequired: boolean;
}
/** Only allow users with bypass permission to update matching refs. */
export interface UpdateParametersInput {
    readonly updateAllowsFetchAndMerge: boolean;
}
/** Autogenerated input type of UpdatePatreonSponsorability */
export interface UpdatePatreonSponsorabilityInput {
    readonly clientMutationId?: string | null | undefined;
    readonly enablePatreonSponsorships: boolean;
    readonly sponsorableLogin?: string | null | undefined;
}
/** Autogenerated input type of UpdateProjectCard */
export interface UpdateProjectCardInput {
    readonly clientMutationId?: string | null | undefined;
    readonly isArchived?: boolean | null | undefined;
    readonly note?: string | null | undefined;
    readonly projectCardId: string;
}
/** Autogenerated input type of UpdateProjectColumn */
export interface UpdateProjectColumnInput {
    readonly clientMutationId?: string | null | undefined;
    readonly name: string;
    readonly projectColumnId: string;
}
/** Autogenerated input type of UpdateProject */
export interface UpdateProjectInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly name?: string | null | undefined;
    readonly projectId: string;
    readonly public?: boolean | null | undefined;
    readonly state?: "CLOSED" | "OPEN" | null | undefined;
}
/** Autogenerated input type of UpdateProjectV2Collaborators */
export interface UpdateProjectV2CollaboratorsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly collaborators: ReadonlyArray<ProjectV2Collaborator>;
    readonly projectId: string;
}
/** Autogenerated input type of UpdateProjectV2DraftIssue */
export interface UpdateProjectV2DraftIssueInput {
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly draftIssueId: string;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of UpdateProjectV2Field */
export interface UpdateProjectV2FieldInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
    readonly iterationConfiguration?: ProjectV2IterationFieldConfigurationInput | null | undefined;
    readonly multiSelectOptions?: ReadonlyArray<ProjectV2MultiSelectFieldOptionInput> | null | undefined;
    readonly name?: string | null | undefined;
    readonly singleSelectOptions?: ReadonlyArray<ProjectV2SingleSelectFieldOptionInput> | null | undefined;
}
/** Autogenerated input type of UpdateProjectV2 */
export interface UpdateProjectV2Input {
    readonly clientMutationId?: string | null | undefined;
    readonly closed?: boolean | null | undefined;
    readonly projectId: string;
    readonly public?: boolean | null | undefined;
    readonly readme?: string | null | undefined;
    readonly shortDescription?: string | null | undefined;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of UpdateProjectV2ItemFieldValue */
export interface UpdateProjectV2ItemFieldValueInput {
    readonly clientMutationId?: string | null | undefined;
    readonly fieldId: string;
    readonly itemId: string;
    readonly projectId: string;
    readonly value: ProjectV2FieldValue;
}
/** Autogenerated input type of UpdateProjectV2ItemPosition */
export interface UpdateProjectV2ItemPositionInput {
    readonly afterId?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly projectId: string;
}
/** Autogenerated input type of UpdateProjectV2StatusUpdate */
export interface UpdateProjectV2StatusUpdateInput {
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly startDate?: string | null | undefined;
    readonly status?: "AT_RISK" | "COMPLETE" | "INACTIVE" | "OFF_TRACK" | "ON_TRACK" | null | undefined;
    readonly statusUpdateId: string;
    readonly targetDate?: string | null | undefined;
}
/** Autogenerated input type of UpdateProjectV2View */
export interface UpdateProjectV2ViewInput {
    readonly clientMutationId?: string | null | undefined;
    readonly configuration?: ProjectV2ViewConfigurationInput | null | undefined;
    readonly filter?: string | null | undefined;
    readonly layout?: "BOARD_LAYOUT" | "ROADMAP_LAYOUT" | "TABLE_LAYOUT" | null | undefined;
    readonly name?: string | null | undefined;
    readonly viewId: string;
}
/** Autogenerated input type of UpdatePullRequestBranch */
export interface UpdatePullRequestBranchInput {
    readonly clientMutationId?: string | null | undefined;
    readonly expectedHeadOid?: string | null | undefined;
    readonly pullRequestId: string;
    readonly updateMethod?: "MERGE" | "REBASE" | null | undefined;
}
/** Autogenerated input type of UpdatePullRequest */
export interface UpdatePullRequestInput {
    readonly assigneeIds?: ReadonlyArray<string> | null | undefined;
    readonly baseRefName?: string | null | undefined;
    readonly body?: string | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly labelIds?: ReadonlyArray<string> | null | undefined;
    readonly maintainerCanModify?: boolean | null | undefined;
    readonly milestoneId?: string | null | undefined;
    readonly projectIds?: ReadonlyArray<string> | null | undefined;
    readonly pullRequestId: string;
    readonly state?: "CLOSED" | "OPEN" | null | undefined;
    readonly title?: string | null | undefined;
}
/** Autogenerated input type of UpdatePullRequestReviewComment */
export interface UpdatePullRequestReviewCommentInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestReviewCommentId: string;
}
/** Autogenerated input type of UpdatePullRequestReview */
export interface UpdatePullRequestReviewInput {
    readonly body: string;
    readonly clientMutationId?: string | null | undefined;
    readonly pullRequestReviewId: string;
}
/** Autogenerated input type of UpdateRef */
export interface UpdateRefInput {
    readonly clientMutationId?: string | null | undefined;
    readonly force?: boolean | null | undefined;
    readonly oid: string;
    readonly refId: string;
}
/** Autogenerated input type of UpdateRefs */
export interface UpdateRefsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly refUpdates: ReadonlyArray<RefUpdate>;
    readonly repositoryId: string;
}
/** Autogenerated input type of UpdateRepositoryCustomProperty */
export interface UpdateRepositoryCustomPropertyInput {
    readonly allowedValues?: ReadonlyArray<string> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly defaultValue?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly regex?: string | null | undefined;
    readonly repositoryCustomPropertyId: string;
    readonly requireExplicitValues?: boolean | null | undefined;
    readonly required?: boolean | null | undefined;
    readonly valuesEditableBy?: "ORG_ACTORS" | "ORG_AND_REPO_ACTORS" | null | undefined;
}
/** Autogenerated input type of UpdateRepository */
export interface UpdateRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly hasDiscussionsEnabled?: boolean | null | undefined;
    readonly hasIssuesEnabled?: boolean | null | undefined;
    readonly hasProjectsEnabled?: boolean | null | undefined;
    readonly hasPullRequestsEnabled?: boolean | null | undefined;
    readonly hasSponsorshipsEnabled?: boolean | null | undefined;
    readonly hasWikiEnabled?: boolean | null | undefined;
    readonly homepageUrl?: string | null | undefined;
    readonly issueCreationPolicy?: "ALL" | "COLLABORATORS_ONLY" | null | undefined;
    readonly name?: string | null | undefined;
    readonly pullRequestCreationPolicy?: "ALL" | "COLLABORATORS_ONLY" | null | undefined;
    readonly repositoryId: string;
    readonly template?: boolean | null | undefined;
}
/** Autogenerated input type of UpdateRepositoryRuleset */
export interface UpdateRepositoryRulesetInput {
    readonly bypassActors?: ReadonlyArray<RepositoryRulesetBypassActorInput> | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly conditions?: RepositoryRuleConditionsInput | null | undefined;
    readonly enforcement?: "ACTIVE" | "DISABLED" | "EVALUATE" | null | undefined;
    readonly name?: string | null | undefined;
    readonly repositoryRulesetId: string;
    readonly rules?: ReadonlyArray<RepositoryRuleInput> | null | undefined;
    readonly target?: "BRANCH" | "PUSH" | "REPOSITORY" | "TAG" | null | undefined;
}
/** Autogenerated input type of UpdateRepositoryWebCommitSignoffSetting */
export interface UpdateRepositoryWebCommitSignoffSettingInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
    readonly webCommitSignoffRequired: boolean;
}
/** Autogenerated input type of UpdateSponsorshipPreferences */
export interface UpdateSponsorshipPreferencesInput {
    readonly clientMutationId?: string | null | undefined;
    readonly privacyLevel?: "PRIVATE" | "PUBLIC" | null | undefined;
    readonly receiveEmails?: boolean | null | undefined;
    readonly sponsorId?: string | null | undefined;
    readonly sponsorLogin?: string | null | undefined;
    readonly sponsorableId?: string | null | undefined;
    readonly sponsorableLogin?: string | null | undefined;
}
/** Autogenerated input type of UpdateSubscription */
export interface UpdateSubscriptionInput {
    readonly clientMutationId?: string | null | undefined;
    readonly state: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED";
    readonly subscribableId: string;
}
/** Autogenerated input type of UpdateTeamReviewAssignment */
export interface UpdateTeamReviewAssignmentInput {
    readonly algorithm?: "LOAD_BALANCE" | "ROUND_ROBIN" | null | undefined;
    readonly clientMutationId?: string | null | undefined;
    readonly countMembersAlreadyRequested?: boolean | null | undefined;
    readonly enabled: boolean;
    readonly excludedTeamMemberIds?: ReadonlyArray<string> | null | undefined;
    readonly id: string;
    readonly includeChildTeamMembers?: boolean | null | undefined;
    readonly notifyTeam?: boolean | null | undefined;
    readonly removeTeamRequest?: boolean | null | undefined;
    readonly teamMemberCount?: number | null | undefined;
}
/** Autogenerated input type of UpdateTeamsRepository */
export interface UpdateTeamsRepositoryInput {
    readonly clientMutationId?: string | null | undefined;
    readonly permission: "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE";
    readonly repositoryId: string;
    readonly teamIds: ReadonlyArray<string>;
}
/** Autogenerated input type of UpdateTopics */
export interface UpdateTopicsInput {
    readonly clientMutationId?: string | null | undefined;
    readonly repositoryId: string;
    readonly topicNames: ReadonlyArray<string>;
}
/** Autogenerated input type of UpdateUserList */
export interface UpdateUserListInput {
    readonly clientMutationId?: string | null | undefined;
    readonly description?: string | null | undefined;
    readonly isPrivate?: boolean | null | undefined;
    readonly listId: string;
    readonly name?: string | null | undefined;
}
/** Autogenerated input type of UpdateUserListsForItem */
export interface UpdateUserListsForItemInput {
    readonly clientMutationId?: string | null | undefined;
    readonly itemId: string;
    readonly listIds: ReadonlyArray<string>;
    readonly suggestedListIds?: ReadonlyArray<string> | null | undefined;
}
/** Ordering options for user status connections. */
export interface UserStatusOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "UPDATED_AT";
}
/** Ordering options for verifiable domain connections. */
export interface VerifiableDomainOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT" | "DOMAIN";
}
/** Autogenerated input type of VerifyVerifiableDomain */
export interface VerifyVerifiableDomainInput {
    readonly clientMutationId?: string | null | undefined;
    readonly id: string;
}
/** A workflow that must run for this rule to pass */
export interface WorkflowFileReferenceInput {
    readonly path: string;
    readonly ref?: string | null | undefined;
    readonly repositoryId: number;
    readonly sha?: string | null | undefined;
}
/** Ways in which lists of workflow runs can be ordered upon return. */
export interface WorkflowRunOrder {
    readonly direction: "ASC" | "DESC";
    readonly field: "CREATED_AT";
}
/** Require all changes made to a targeted branch to pass the specified workflows before they can be merged. */
export interface WorkflowsParametersInput {
    readonly doNotEnforceOnCreate?: boolean | null | undefined;
    readonly workflows: ReadonlyArray<WorkflowFileReferenceInput>;
}
/** Types that can be assigned to issues. */
export type Assignee = Bot | Mannequin | Organization | User;
/** Types that can initiate an audit log event. */
export type AuditEntryActor = Bot | Organization | User;
/** Types which can be actors for `BranchActorAllowance` objects. */
export type BranchActorAllowanceActor = App | Team | User;
/** Types that can represent a repository ruleset bypass actor. */
export type BypassActor = App | EnterpriseTeam | Team | User;
/** An object which can have its data claimed or claim data from another. */
export type Claimable = Mannequin | User;
/** The object which triggered a `ClosedEvent`. */
export type Closer = Commit | ProjectV2 | PullRequest;
/** Represents either a issue the viewer can access or a restricted contribution. */
export type CreatedIssueOrRestrictedContribution = CreatedIssueContribution | RestrictedContribution;
/** Represents either a pull request the viewer can access or a restricted contribution. */
export type CreatedPullRequestOrRestrictedContribution = CreatedPullRequestContribution | RestrictedContribution;
/** Represents either a repository the viewer can access or a restricted contribution. */
export type CreatedRepositoryOrRestrictedContribution = CreatedRepositoryContribution | RestrictedContribution;
/** Sources which can have custom properties defined. */
export type CustomPropertySource = Enterprise | Organization;
/** Users and teams. */
export type DeploymentReviewer = Team | User;
/** An object that is a member of an enterprise. */
export type EnterpriseMember = EnterpriseUserAccount | User;
/** Types that can own an IP allow list. */
export type IpAllowListOwner = App | Enterprise | Organization;
/** Issue field values */
export type IssueFieldValue = IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue;
/** Possible issue fields. */
export type IssueFields = IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText;
/** Used for return value of Repository.issueOrPullRequest. */
export type IssueOrPullRequest = Issue | PullRequest;
/** An item in an issue timeline */
export type IssueTimelineItem = AssignedEvent | ClosedEvent | Commit | CrossReferencedEvent | DemilestonedEvent | IssueComment | LabeledEvent | LockedEvent | MilestonedEvent | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent;
/** An item in an issue timeline */
export type IssueTimelineItems = AddedToProjectEvent | AddedToProjectV2Event | AssignedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DisconnectedEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | ReferencedEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RenamedTitleEvent | ReopenedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent;
/** Types that can be inside a Milestone. */
export type MilestoneItem = Issue | PullRequest;
/** Types of memberships that can be restored for an Organization member. */
export type OrgRestoreMemberAuditEntryMembership = OrgRestoreMemberMembershipOrganizationAuditEntryData | OrgRestoreMemberMembershipRepositoryAuditEntryData | OrgRestoreMemberMembershipTeamAuditEntryData;
/** An audit entry in an organization audit log. */
export type OrganizationAuditEntry = MembersCanDeleteReposClearAuditEntry | MembersCanDeleteReposDisableAuditEntry | MembersCanDeleteReposEnableAuditEntry | OauthApplicationCreateAuditEntry | OrgAddBillingManagerAuditEntry | OrgAddMemberAuditEntry | OrgBlockUserAuditEntry | OrgConfigDisableCollaboratorsOnlyAuditEntry | OrgConfigEnableCollaboratorsOnlyAuditEntry | OrgCreateAuditEntry | OrgDisableOauthAppRestrictionsAuditEntry | OrgDisableSamlAuditEntry | OrgDisableTwoFactorRequirementAuditEntry | OrgEnableOauthAppRestrictionsAuditEntry | OrgEnableSamlAuditEntry | OrgEnableTwoFactorRequirementAuditEntry | OrgInviteMemberAuditEntry | OrgInviteToBusinessAuditEntry | OrgOauthAppAccessApprovedAuditEntry | OrgOauthAppAccessBlockedAuditEntry | OrgOauthAppAccessDeniedAuditEntry | OrgOauthAppAccessRequestedAuditEntry | OrgOauthAppAccessUnblockedAuditEntry | OrgRemoveBillingManagerAuditEntry | OrgRemoveMemberAuditEntry | OrgRemoveOutsideCollaboratorAuditEntry | OrgRestoreMemberAuditEntry | OrgUnblockUserAuditEntry | OrgUpdateDefaultRepositoryPermissionAuditEntry | OrgUpdateMemberAuditEntry | OrgUpdateMemberRepositoryCreationPermissionAuditEntry | OrgUpdateMemberRepositoryInvitationPermissionAuditEntry | PrivateRepositoryForkingDisableAuditEntry | PrivateRepositoryForkingEnableAuditEntry | RepoAccessAuditEntry | RepoAddMemberAuditEntry | RepoAddTopicAuditEntry | RepoArchivedAuditEntry | RepoChangeMergeSettingAuditEntry | RepoConfigDisableAnonymousGitAccessAuditEntry | RepoConfigDisableCollaboratorsOnlyAuditEntry | RepoConfigDisableContributorsOnlyAuditEntry | RepoConfigDisableSockpuppetDisallowedAuditEntry | RepoConfigEnableAnonymousGitAccessAuditEntry | RepoConfigEnableCollaboratorsOnlyAuditEntry | RepoConfigEnableContributorsOnlyAuditEntry | RepoConfigEnableSockpuppetDisallowedAuditEntry | RepoConfigLockAnonymousGitAccessAuditEntry | RepoConfigUnlockAnonymousGitAccessAuditEntry | RepoCreateAuditEntry | RepoDestroyAuditEntry | RepoRemoveMemberAuditEntry | RepoRemoveTopicAuditEntry | RepositoryVisibilityChangeDisableAuditEntry | RepositoryVisibilityChangeEnableAuditEntry | TeamAddMemberAuditEntry | TeamAddRepositoryAuditEntry | TeamChangeParentTeamAuditEntry | TeamRemoveMemberAuditEntry | TeamRemoveRepositoryAuditEntry;
/** Used for argument of CreateProjectV2 mutation. */
export type OrganizationOrUser = Organization | User;
/** A pending suggestion for an issue. May target the issue's type, labels, field values, assignees, or close state. */
export type PendingIssueSuggestion = PendingAssigneeSuggestion | PendingCloseSuggestion | PendingFieldSuggestion | PendingLabelSuggestion | PendingTypeSuggestion;
/** Types that can grant permissions on a repository to a user */
export type PermissionGranter = EnterpriseTeam | Organization | Repository | Team;
/** Types that can be pinned to a profile page. */
export type PinnableItem = Gist | Repository;
/** Types that can be inside Project Cards. */
export type ProjectCardItem = Issue | PullRequest;
/** Possible collaborators for a project. */
export type ProjectV2Actor = Team | User;
/** Configurations for project fields. */
export type ProjectV2FieldConfiguration = ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
/** Possible issue field values for a Project item. */
export type ProjectV2IssueFieldValues = IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue;
/** Types that can be inside Project Items. */
export type ProjectV2ItemContent = DraftIssue | Issue | PullRequest;
/** Project field values */
export type ProjectV2ItemFieldValue = ProjectV2ItemFieldDateValue | ProjectV2ItemFieldIterationValue | ProjectV2ItemFieldLabelValue | ProjectV2ItemFieldMilestoneValue | ProjectV2ItemFieldMultiSelectValue | ProjectV2ItemFieldNumberValue | ProjectV2ItemFieldPullRequestValue | ProjectV2ItemFieldRepositoryValue | ProjectV2ItemFieldReviewerValue | ProjectV2ItemFieldSingleSelectValue | ProjectV2ItemFieldTextValue | ProjectV2ItemFieldUserValue | ProjectV2ItemIssueFieldValue;
/** An item in a pull request timeline */
export type PullRequestTimelineItem = AssignedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | ClosedEvent | Commit | CommitCommentThread | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | LabeledEvent | LockedEvent | MergedEvent | MilestonedEvent | PullRequestReview | PullRequestReviewComment | PullRequestReviewThread | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubscribedEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent;
/** An item in a pull request timeline */
export type PullRequestTimelineItems = AddedToMergeQueueEvent | AddedToProjectEvent | AddedToProjectV2Event | AddedToStackEvent | AssignedEvent | AutoMergeDisabledEvent | AutoMergeEnabledEvent | AutoRebaseEnabledEvent | AutoSquashEnabledEvent | AutomaticBaseChangeFailedEvent | AutomaticBaseChangeSucceededEvent | BaseRefChangedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertToDraftEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | DisconnectedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MergedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | PullRequestCommit | PullRequestCommitCommentThread | PullRequestReview | PullRequestReviewThread | PullRequestRevisionMarker | ReadyForReviewEvent | ReferencedEvent | RemovedFromMergeQueueEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RemovedFromStackEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent;
/** Types that can be an actor. */
export type PushAllowanceActor = App | Team | User;
/** Types that can be assigned to reactions. */
export type Reactor = Bot | Mannequin | Organization | User;
/** Any referencable object */
export type ReferencedSubject = Issue | PullRequest;
/** An object which has a renamable title */
export type RenamedTitleSubject = Issue | PullRequest;
/** Types that can be requested reviewers. */
export type RequestedReviewer = Bot | EnterpriseTeam | Mannequin | Team | User;
/** Types that can be an actor. */
export type ReviewDismissalAllowanceActor = App | Team | User;
/** Types which can be parameters for `RepositoryRule` objects. */
export type RuleParameters = BranchNamePatternParameters | CodeCoverageParameters | CodeQualityParameters | CodeScanningParameters | CommitAuthorEmailPatternParameters | CommitMessagePatternParameters | CommitterEmailPatternParameters | CopilotCodeReviewParameters | FileExtensionRestrictionParameters | FilePathRestrictionParameters | MaxFilePathLengthParameters | MaxFileSizeParameters | MergeQueueParameters | PullRequestParameters | RequiredDeploymentsParameters | RequiredStatusChecksParameters | TagNamePatternParameters | UpdateParameters | WorkflowsParameters;
/** Types which can have `RepositoryRule` objects. */
export type RuleSource = Enterprise | Organization | Repository;
/** The results of a search. */
export type SearchResultItem = App | Discussion | Issue | MarketplaceListing | Organization | PullRequest | Repository | User;
/** Entities that can sponsor others via GitHub Sponsors */
export type Sponsor = Organization | User;
/** Entities that can be sponsored via GitHub Sponsors */
export type SponsorableItem = Organization | User;
/** A record that can be featured on a GitHub Sponsors profile. */
export type SponsorsListingFeatureableItem = Repository | User;
/** Types that can be inside a StatusCheckRollup context. */
export type StatusCheckRollupContext = CheckRun | StatusContext;
/** Types that can be added to a user list. */
export type UserListItems = Repository;
/** Types that can own a verifiable domain. */
export type VerifiableDomainOwner = Enterprise | Organization;
/** Autogenerated return type of AbortQueuedMigrations. */
export interface AbortQueuedMigrationsPayload {
    readonly clientMutationId: string | null;
    readonly success: boolean | null;
}
/** Autogenerated return type of AbortRepositoryMigration. */
export interface AbortRepositoryMigrationPayload {
    readonly clientMutationId: string | null;
    readonly success: boolean | null;
}
/** Autogenerated return type of AcceptEnterpriseAdministratorInvitation. */
export interface AcceptEnterpriseAdministratorInvitationPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseAdministratorInvitation | null;
    readonly message: string | null;
}
/** Autogenerated return type of AcceptEnterpriseMemberInvitation. */
export interface AcceptEnterpriseMemberInvitationPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseMemberInvitation | null;
    readonly message: string | null;
}
/** Autogenerated return type of AcceptTopicSuggestion. */
export interface AcceptTopicSuggestionPayload {
    readonly clientMutationId: string | null;
    readonly topic: Topic | null;
}
/** Autogenerated return type of AccessUserNamespaceRepository. */
export interface AccessUserNamespaceRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly expiresAt: string | null;
    readonly repository: Repository | null;
}
/** Represents an object which can take actions on GitHub. Typically a User or Bot. */
export interface Actor {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly login: string;
    readonly resourcePath: string;
    readonly url: string;
}
/** The connection type for Actor. */
export interface ActorConnection {
    readonly edges: ReadonlyArray<ActorEdge | null> | null;
    readonly nodes: ReadonlyArray<Actor | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ActorEdge {
    readonly cursor: string;
    readonly node: Actor | null;
}
/** Location information for an actor */
export interface ActorLocation {
    readonly city: string | null;
    readonly country: string | null;
    readonly countryCode: string | null;
    readonly region: string | null;
    readonly regionCode: string | null;
}
/** Autogenerated return type of AddAssigneesToAssignable. */
export interface AddAssigneesToAssignablePayload {
    readonly assignable: Assignable | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of AddBlockedBy. */
export interface AddBlockedByPayload {
    readonly blockingIssue: Issue | null;
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of AddCloseIssueReferences. */
export interface AddCloseIssueReferencesPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of AddComment. */
export interface AddCommentPayload {
    readonly clientMutationId: string | null;
    readonly commentEdge: IssueCommentEdge | null;
    readonly subject: Node | null;
    readonly timelineEdge: IssueTimelineItemEdge | null;
}
/** Autogenerated return type of AddDiscussionComment. */
export interface AddDiscussionCommentPayload {
    readonly clientMutationId: string | null;
    readonly comment: DiscussionComment | null;
}
/** Autogenerated return type of AddDiscussionPollVote. */
export interface AddDiscussionPollVotePayload {
    readonly clientMutationId: string | null;
    readonly pollOption: DiscussionPollOption | null;
}
/** Autogenerated return type of AddEnterpriseOrganizationMember. */
export interface AddEnterpriseOrganizationMemberPayload {
    readonly clientMutationId: string | null;
    readonly users: ReadonlyArray<User> | null;
}
/** Autogenerated return type of AddEnterpriseSupportEntitlement. */
export interface AddEnterpriseSupportEntitlementPayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
}
/** Autogenerated return type of AddLabelsToLabelable. */
export interface AddLabelsToLabelablePayload {
    readonly clientMutationId: string | null;
    readonly labelable: Labelable | null;
}
/** Autogenerated return type of AddProjectCard. */
export interface AddProjectCardPayload {
    readonly cardEdge: ProjectCardEdge | null;
    readonly clientMutationId: string | null;
    readonly projectColumn: ProjectColumn | null;
}
/** Autogenerated return type of AddProjectColumn. */
export interface AddProjectColumnPayload {
    readonly clientMutationId: string | null;
    readonly columnEdge: ProjectColumnEdge | null;
    readonly project: Project | null;
}
/** Autogenerated return type of AddProjectV2DraftIssue. */
export interface AddProjectV2DraftIssuePayload {
    readonly clientMutationId: string | null;
    readonly projectItem: ProjectV2Item | null;
}
/** Autogenerated return type of AddProjectV2ItemById. */
export interface AddProjectV2ItemByIdPayload {
    readonly clientMutationId: string | null;
    readonly item: ProjectV2Item | null;
}
/** Autogenerated return type of AddPullRequestCreationCapBypassUsers. */
export interface AddPullRequestCreationCapBypassUsersPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of AddPullRequestReviewComment. */
export interface AddPullRequestReviewCommentPayload {
    readonly clientMutationId: string | null;
    readonly comment: PullRequestReviewComment | null;
    readonly commentEdge: PullRequestReviewCommentEdge | null;
}
/** Autogenerated return type of AddPullRequestReview. */
export interface AddPullRequestReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
    readonly reviewEdge: PullRequestReviewEdge | null;
}
/** Autogenerated return type of AddPullRequestReviewThread. */
export interface AddPullRequestReviewThreadPayload {
    readonly clientMutationId: string | null;
    readonly thread: PullRequestReviewThread | null;
}
/** Autogenerated return type of AddPullRequestReviewThreadReply. */
export interface AddPullRequestReviewThreadReplyPayload {
    readonly clientMutationId: string | null;
    readonly comment: PullRequestReviewComment | null;
}
/** Autogenerated return type of AddReaction. */
export interface AddReactionPayload {
    readonly clientMutationId: string | null;
    readonly reaction: Reaction | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly subject: Reactable | null;
}
/** Autogenerated return type of AddRelatesTo. */
export interface AddRelatesToPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly relatedIssue: Issue | null;
}
/** Autogenerated return type of AddStar. */
export interface AddStarPayload {
    readonly clientMutationId: string | null;
    readonly starrable: Starrable | null;
}
/** Autogenerated return type of AddSubIssue. */
export interface AddSubIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly subIssue: Issue | null;
}
/** Autogenerated return type of AddUpvote. */
export interface AddUpvotePayload {
    readonly clientMutationId: string | null;
    readonly subject: Votable | null;
}
/** Autogenerated return type of AddVerifiableDomain. */
export interface AddVerifiableDomainPayload {
    readonly clientMutationId: string | null;
    readonly domain: VerifiableDomain | null;
}
/** Represents an 'added_to_merge_queue' event on a given pull request. */
export interface AddedToMergeQueueEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly enqueuer: User | null;
    readonly id: string;
    readonly mergeQueue: MergeQueue | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'added_to_project' event on a given issue or pull request. */
export interface AddedToProjectEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly project: Project | null;
    readonly projectCard: ProjectCard | null;
    readonly projectColumnName: string;
}
/** Represents a 'added_to_project_v2' event on a given issue or pull request. */
export interface AddedToProjectV2Event {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly project: ProjectV2 | null;
    readonly wasAutomated: boolean;
}
/** Represents an 'added_to_stack' event on a given pull request. */
export interface AddedToStackEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
    readonly stackId: string | null;
    readonly stackNumber: number | null;
}
/** Copilot Agentic fields in context of the current viewer. */
export interface Agentic {
    readonly viewerCopilotAgentCreatesChannel: string | null;
    readonly viewerCopilotAgentLogUpdatesChannel: string | null;
    readonly viewerCopilotAgentTaskUpdatesChannel: string | null;
    readonly viewerCopilotAgentUpdatesChannel: string | null;
}
/** An announcement banner for an enterprise or organization. */
export interface AnnouncementBanner {
    readonly createdAt: string;
    readonly expiresAt: string | null;
    readonly isUserDismissible: boolean;
    readonly message: string | null;
}
/** A GitHub App. */
export interface App {
    readonly clientId: string | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly id: string;
    readonly ipAllowListEntries: ReadonlyArray<IpAllowListEntry>;
    readonly logoBackgroundColor: string;
    readonly logoUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly name: string;
    readonly slug: string;
    readonly updatedAt: string;
    readonly url: string;
}
/** Autogenerated return type of ApplyPendingIssueSuggestions. */
export interface ApplyPendingIssueSuggestionsPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of ApproveDeployments. */
export interface ApproveDeploymentsPayload {
    readonly clientMutationId: string | null;
    readonly deployments: ReadonlyArray<Deployment> | null;
}
/** Autogenerated return type of ApproveVerifiableDomain. */
export interface ApproveVerifiableDomainPayload {
    readonly clientMutationId: string | null;
    readonly domain: VerifiableDomain | null;
}
/** Autogenerated return type of ArchiveProjectV2Item. */
export interface ArchiveProjectV2ItemPayload {
    readonly clientMutationId: string | null;
    readonly item: ProjectV2Item | null;
}
/** Autogenerated return type of ArchivePullRequest. */
export interface ArchivePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of ArchiveRepository. */
export interface ArchiveRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** An object that can have users assigned to it. */
export interface Assignable {
    readonly assignedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly assignees: ReadonlyArray<User>;
    readonly suggestedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly viewerCanAssign: boolean;
}
/** Represents an 'assigned' event on any assignable object. */
export interface AssignedEvent {
    readonly actor: Actor | null;
    readonly assignable: Assignable;
    readonly assignee: Bot | Mannequin | Organization | User | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly user: User | null;
}
/** The connection type for Assignee. */
export interface AssigneeConnection {
    readonly edges: ReadonlyArray<AssigneeEdge | null> | null;
    readonly nodes: ReadonlyArray<Bot | Mannequin | Organization | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface AssigneeEdge {
    readonly cursor: string;
    readonly node: Bot | Mannequin | Organization | User | null;
}
/** An entry in the audit log. */
export interface AuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Represents a 'auto_merge_disabled' event on a given pull request. */
export interface AutoMergeDisabledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly disabler: User | null;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
    readonly reason: string | null;
    readonly reasonCode: string | null;
}
/** Represents a 'auto_merge_enabled' event on a given pull request. */
export interface AutoMergeEnabledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly enabler: User | null;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
}
/** Represents an auto-merge request for a pull request */
export interface AutoMergeRequest {
    readonly authorEmail: string | null;
    readonly commitBody: string | null;
    readonly commitHeadline: string | null;
    readonly enabledAt: string | null;
    readonly enabledBy: Actor | null;
    readonly mergeMethod: "MERGE" | "REBASE" | "SQUASH";
    readonly pullRequest: PullRequest;
}
/** Represents a 'auto_rebase_enabled' event on a given pull request. */
export interface AutoRebaseEnabledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly enabler: User | null;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'auto_squash_enabled' event on a given pull request. */
export interface AutoSquashEnabledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly enabler: User | null;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'automatic_base_change_failed' event on a given pull request. */
export interface AutomaticBaseChangeFailedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly newBase: string;
    readonly oldBase: string;
    readonly pullRequest: PullRequest;
}
/** Represents a 'automatic_base_change_succeeded' event on a given pull request. */
export interface AutomaticBaseChangeSucceededEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly newBase: string;
    readonly oldBase: string;
    readonly pullRequest: PullRequest;
}
/** Represents a 'base_ref_changed' event on a given issue or pull request. */
export interface BaseRefChangedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly currentRefName: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly previousRefName: string;
    readonly pullRequest: PullRequest;
}
/** Represents a 'base_ref_deleted' event on a given pull request. */
export interface BaseRefDeletedEvent {
    readonly actor: Actor | null;
    readonly baseRefName: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'base_ref_force_pushed' event on a given pull request. */
export interface BaseRefForcePushedEvent {
    readonly actor: Actor | null;
    readonly afterCommit: Commit | null;
    readonly beforeCommit: Commit | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly ref: Ref | null;
}
/** Represents a Git blame. */
export interface Blame {
    readonly ranges: ReadonlyArray<BlameRange>;
}
/** Represents a range of information from a Git blame. */
export interface BlameRange {
    readonly age: number;
    readonly commit: Commit;
    readonly endingLine: number;
    readonly startingLine: number;
}
/** Represents a Git blob. */
export interface Blob {
    readonly abbreviatedOid: string;
    readonly byteSize: number;
    readonly commitResourcePath: string;
    readonly commitUrl: string;
    readonly id: string;
    readonly isBinary: boolean | null;
    readonly isTruncated: boolean;
    readonly oid: string;
    readonly repository: Repository;
    readonly text: string | null;
}
/** Represents a 'blocked_by_added' event on a given issue. */
export interface BlockedByAddedEvent {
    readonly actor: Actor | null;
    readonly blockingIssue: Issue | null;
    readonly createdAt: string;
    readonly id: string;
}
/** Represents a 'blocked_by_removed' event on a given issue. */
export interface BlockedByRemovedEvent {
    readonly actor: Actor | null;
    readonly blockingIssue: Issue | null;
    readonly createdAt: string;
    readonly id: string;
}
/** Represents a 'blocking_added' event on a given issue. */
export interface BlockingAddedEvent {
    readonly actor: Actor | null;
    readonly blockedIssue: Issue | null;
    readonly createdAt: string;
    readonly id: string;
}
/** Represents a 'blocking_removed' event on a given issue. */
export interface BlockingRemovedEvent {
    readonly actor: Actor | null;
    readonly blockedIssue: Issue | null;
    readonly createdAt: string;
    readonly id: string;
}
/** A special type of user which takes actions on behalf of GitHub Apps. */
export interface Bot {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly login: string;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
}
/** Parameters to be used for the branch_name_pattern rule */
export interface BranchNamePatternParameters {
    readonly name: string | null;
    readonly negate: boolean;
    readonly operator: string;
    readonly pattern: string;
}
/** A branch protection rule. */
export interface BranchProtectionRule {
    readonly allowsDeletions: boolean;
    readonly allowsForcePushes: boolean;
    readonly blocksCreations: boolean;
    readonly branchProtectionRuleConflicts: ReadonlyArray<BranchProtectionRuleConflict>;
    readonly bypassForcePushAllowances: ReadonlyArray<BypassForcePushAllowance>;
    readonly bypassPullRequestAllowances: ReadonlyArray<BypassPullRequestAllowance>;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly dismissesStaleReviews: boolean;
    readonly id: string;
    readonly isAdminEnforced: boolean;
    readonly lockAllowsFetchAndMerge: boolean;
    readonly lockBranch: boolean;
    readonly matchingRefs: ReadonlyArray<Ref>;
    readonly pattern: string;
    readonly pushAllowances: ReadonlyArray<PushAllowance>;
    readonly repository: Repository | null;
    readonly requiredApprovingReviewCount: number | null;
    readonly requiredDeploymentEnvironments: ReadonlyArray<string | null> | null;
    readonly requiredStatusCheckContexts: ReadonlyArray<string | null> | null;
    readonly requiredStatusChecks: ReadonlyArray<RequiredStatusCheckDescription> | null;
    readonly requireLastPushApproval: boolean;
    readonly requiresApprovingReviews: boolean;
    readonly requiresCodeOwnerReviews: boolean;
    readonly requiresCommitSignatures: boolean;
    readonly requiresConversationResolution: boolean;
    readonly requiresDeployments: boolean;
    readonly requiresLinearHistory: boolean;
    readonly requiresStatusChecks: boolean;
    readonly requiresStrictStatusChecks: boolean;
    readonly restrictsPushes: boolean;
    readonly restrictsReviewDismissals: boolean;
    readonly reviewDismissalAllowances: ReadonlyArray<ReviewDismissalAllowance>;
}
/** A conflict between two branch protection rules. */
export interface BranchProtectionRuleConflict {
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly conflictingBranchProtectionRule: BranchProtectionRule | null;
    readonly ref: Ref | null;
}
/** The connection type for BranchProtectionRuleConflict. */
export interface BranchProtectionRuleConflictConnection {
    readonly edges: ReadonlyArray<BranchProtectionRuleConflictEdge | null> | null;
    readonly nodes: ReadonlyArray<BranchProtectionRuleConflict | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface BranchProtectionRuleConflictEdge {
    readonly cursor: string;
    readonly node: BranchProtectionRuleConflict | null;
}
/** The connection type for BranchProtectionRule. */
export interface BranchProtectionRuleConnection {
    readonly edges: ReadonlyArray<BranchProtectionRuleEdge | null> | null;
    readonly nodes: ReadonlyArray<BranchProtectionRule | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface BranchProtectionRuleEdge {
    readonly cursor: string;
    readonly node: BranchProtectionRule | null;
}
/** A user, team, or app who has the ability to bypass a force push requirement on a protected branch. */
export interface BypassForcePushAllowance {
    readonly actor: App | Team | User | null;
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly id: string;
}
/** The connection type for BypassForcePushAllowance. */
export interface BypassForcePushAllowanceConnection {
    readonly edges: ReadonlyArray<BypassForcePushAllowanceEdge | null> | null;
    readonly nodes: ReadonlyArray<BypassForcePushAllowance | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface BypassForcePushAllowanceEdge {
    readonly cursor: string;
    readonly node: BypassForcePushAllowance | null;
}
/** A user, team, or app who has the ability to bypass a pull request requirement on a protected branch. */
export interface BypassPullRequestAllowance {
    readonly actor: App | Team | User | null;
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly id: string;
}
/** The connection type for BypassPullRequestAllowance. */
export interface BypassPullRequestAllowanceConnection {
    readonly edges: ReadonlyArray<BypassPullRequestAllowanceEdge | null> | null;
    readonly nodes: ReadonlyArray<BypassPullRequestAllowance | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface BypassPullRequestAllowanceEdge {
    readonly cursor: string;
    readonly node: BypassPullRequestAllowance | null;
}
/** The Common Vulnerability Scoring System */
export interface CVSS {
    readonly score: number;
    readonly vectorString: string | null;
}
/** A common weakness enumeration */
export interface CWE {
    readonly cweId: string;
    readonly description: string;
    readonly id: string;
    readonly name: string;
}
/** The connection type for CWE. */
export interface CWEConnection {
    readonly edges: ReadonlyArray<CWEEdge | null> | null;
    readonly nodes: ReadonlyArray<CWE | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CWEEdge {
    readonly cursor: string;
    readonly node: CWE | null;
}
/** Autogenerated return type of CancelEnterpriseAdminInvitation. */
export interface CancelEnterpriseAdminInvitationPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseAdministratorInvitation | null;
    readonly message: string | null;
}
/** Autogenerated return type of CancelEnterpriseMemberInvitation. */
export interface CancelEnterpriseMemberInvitationPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseMemberInvitation | null;
    readonly message: string | null;
}
/** Autogenerated return type of CancelSponsorship. */
export interface CancelSponsorshipPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsTier: SponsorsTier | null;
}
/** Autogenerated return type of ChangeUserStatus. */
export interface ChangeUserStatusPayload {
    readonly clientMutationId: string | null;
    readonly status: UserStatus | null;
}
/** A single check annotation. */
export interface CheckAnnotation {
    readonly annotationLevel: "FAILURE" | "NOTICE" | "WARNING" | null;
    readonly blobUrl: string;
    readonly databaseId: number | null;
    readonly fullDatabaseId: string | null;
    readonly location: CheckAnnotationSpan;
    readonly message: string;
    readonly path: string;
    readonly rawDetails: string | null;
    readonly title: string | null;
}
/** The connection type for CheckAnnotation. */
export interface CheckAnnotationConnection {
    readonly edges: ReadonlyArray<CheckAnnotationEdge | null> | null;
    readonly nodes: ReadonlyArray<CheckAnnotation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CheckAnnotationEdge {
    readonly cursor: string;
    readonly node: CheckAnnotation | null;
}
/** A character position in a check annotation. */
export interface CheckAnnotationPosition {
    readonly column: number | null;
    readonly line: number;
}
/** An inclusive pair of positions for a check annotation. */
export interface CheckAnnotationSpan {
    readonly end: CheckAnnotationPosition;
    readonly start: CheckAnnotationPosition;
}
/** A check run. */
export interface CheckRun {
    readonly annotations: ReadonlyArray<CheckAnnotation> | null;
    readonly checkSuite: CheckSuite;
    readonly completedAt: string | null;
    readonly conclusion: "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | null;
    readonly databaseId: number | null;
    readonly deployment: Deployment | null;
    readonly detailsUrl: string | null;
    readonly externalId: string | null;
    readonly id: string;
    readonly isRequired: FieldWithArgs<boolean, {
        readonly pullRequestId?: string | null | undefined;
        readonly pullRequestNumber?: number | null | undefined;
    }, false>;
    readonly name: string;
    readonly pendingDeploymentRequest: DeploymentRequest | null;
    readonly permalink: string;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly startedAt: string | null;
    readonly status: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING";
    readonly steps: ReadonlyArray<CheckStep> | null;
    readonly summary: string | null;
    readonly text: string | null;
    readonly title: string | null;
    readonly url: string;
}
/** The connection type for CheckRun. */
export interface CheckRunConnection {
    readonly edges: ReadonlyArray<CheckRunEdge | null> | null;
    readonly nodes: ReadonlyArray<CheckRun | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CheckRunEdge {
    readonly cursor: string;
    readonly node: CheckRun | null;
}
/** Represents a count of the state of a check run. */
export interface CheckRunStateCount {
    readonly count: number;
    readonly state: "ACTION_REQUIRED" | "CANCELLED" | "COMPLETED" | "FAILURE" | "IN_PROGRESS" | "NEUTRAL" | "PENDING" | "QUEUED" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | "WAITING";
}
/** A single check step. */
export interface CheckStep {
    readonly completedAt: string | null;
    readonly conclusion: "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | null;
    readonly externalId: string | null;
    readonly name: string;
    readonly number: number;
    readonly secondsToCompletion: number | null;
    readonly startedAt: string | null;
    readonly status: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING";
}
/** The connection type for CheckStep. */
export interface CheckStepConnection {
    readonly edges: ReadonlyArray<CheckStepEdge | null> | null;
    readonly nodes: ReadonlyArray<CheckStep | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CheckStepEdge {
    readonly cursor: string;
    readonly node: CheckStep | null;
}
/** A check suite. */
export interface CheckSuite {
    readonly app: App | null;
    readonly branch: Ref | null;
    readonly checkRuns: ReadonlyArray<CheckRun> | null;
    readonly commit: Commit;
    readonly conclusion: "ACTION_REQUIRED" | "CANCELLED" | "FAILURE" | "NEUTRAL" | "SKIPPED" | "STALE" | "STARTUP_FAILURE" | "SUCCESS" | "TIMED_OUT" | null;
    readonly createdAt: string;
    readonly creator: User | null;
    readonly databaseId: number | null;
    readonly id: string;
    readonly matchingPullRequests: ReadonlyArray<PullRequest> | null;
    readonly push: Push | null;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly status: "COMPLETED" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "REQUESTED" | "WAITING";
    readonly updatedAt: string;
    readonly url: string;
    readonly workflowRun: WorkflowRun | null;
}
/** The connection type for CheckSuite. */
export interface CheckSuiteConnection {
    readonly edges: ReadonlyArray<CheckSuiteEdge | null> | null;
    readonly nodes: ReadonlyArray<CheckSuite | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CheckSuiteEdge {
    readonly cursor: string;
    readonly node: CheckSuite | null;
}
/** Autogenerated return type of ClearLabelsFromLabelable. */
export interface ClearLabelsFromLabelablePayload {
    readonly clientMutationId: string | null;
    readonly labelable: Labelable | null;
}
/** Autogenerated return type of ClearProjectV2ItemFieldValue. */
export interface ClearProjectV2ItemFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly projectV2Item: ProjectV2Item | null;
}
/** Autogenerated return type of CloneProject. */
export interface CloneProjectPayload {
    readonly clientMutationId: string | null;
    readonly jobStatusId: string | null;
    readonly project: Project | null;
}
/** Autogenerated return type of CloneTemplateRepository. */
export interface CloneTemplateRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** An object that can be closed */
export interface Closable {
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly viewerCanClose: boolean;
    readonly viewerCanReopen: boolean;
}
/** Autogenerated return type of CloseDiscussion. */
export interface CloseDiscussionPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of CloseIssue. */
export interface CloseIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of ClosePullRequest. */
export interface ClosePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'closed' event on any `Closable`. */
export interface ClosedEvent {
    readonly actor: Actor | null;
    readonly closable: Closable;
    readonly closer: Commit | ProjectV2 | PullRequest | null;
    readonly createdAt: string;
    readonly duplicateOf: Issue | PullRequest | null;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly resourcePath: string;
    readonly stateReason: "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | "REOPENED" | null;
    readonly url: string;
}
/** Enforce minimum line coverage thresholds on pull requests. This rule evaluates
uploaded coverage data but does not wait for coverage uploads. To ensure
coverage is evaluated before merging, make each status check associated with a
coverage upload a required status check. */
export interface CodeCoverageParameters {
    readonly maxCoverageDrop: number | null;
    readonly minimumCoverage: number | null;
}
/** The Code of Conduct for a repository */
export interface CodeOfConduct {
    readonly body: string | null;
    readonly id: string;
    readonly key: string;
    readonly name: string;
    readonly resourcePath: string | null;
    readonly url: string | null;
}
/** Choose which severity levels of code quality results should block pull request
merges. When configured, a code quality analysis must be done on the pull
request before the changes can be merged. */
export interface CodeQualityParameters {
    readonly severity: "ALL" | "ERRORS" | "NOTES" | "WARNINGS";
}
/** Choose which tools must provide code scanning results before the reference is
updated. When configured, code scanning must be enabled and have results for
both the commit and the reference being updated. */
export interface CodeScanningParameters {
    readonly codeScanningTools: ReadonlyArray<CodeScanningTool>;
}
/** A tool that must provide code scanning results for this rule to pass. */
export interface CodeScanningTool {
    readonly alertsThreshold: string;
    readonly securityAlertsThreshold: string;
    readonly tool: string;
}
/** Represents a comment. */
export interface Comment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly editor: Actor | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly lastEditedAt: string | null;
    readonly publishedAt: string | null;
    readonly updatedAt: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerDidAuthor: boolean;
}
/** Represents a 'comment_deleted' event on a given issue or pull request. */
export interface CommentDeletedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly deletedCommentAuthor: Actor | null;
    readonly id: string;
}
/** Represents a Git commit. */
export interface Commit {
    readonly abbreviatedOid: string;
    readonly additions: number;
    readonly associatedPullRequests: ReadonlyArray<PullRequest> | null;
    readonly author: GitActor | null;
    readonly authoredByCommitter: boolean;
    readonly authoredDate: string;
    readonly authors: ReadonlyArray<GitActor>;
    readonly blame: FieldWithArgs<Blame, {
        readonly path: string;
    }>;
    readonly changedFiles: number;
    readonly changedFilesIfAvailable: number | null;
    readonly checkSuites: ReadonlyArray<CheckSuite> | null;
    readonly comments: ReadonlyArray<CommitComment>;
    readonly commitResourcePath: string;
    readonly committedDate: string;
    readonly committedViaWeb: boolean;
    readonly committer: GitActor | null;
    readonly commitUrl: string;
    readonly deletions: number;
    readonly deployments: ReadonlyArray<Deployment> | null;
    readonly file: FieldWithArgs<TreeEntry | null, {
        readonly path: string;
    }>;
    readonly history: ReadonlyArray<Commit>;
    readonly id: string;
    readonly message: string;
    readonly messageBody: string;
    readonly messageBodyHTML: string;
    readonly messageHeadline: string;
    readonly messageHeadlineHTML: string;
    readonly oid: string;
    readonly onBehalfOf: Organization | null;
    readonly parents: ReadonlyArray<Commit>;
    readonly pushedDate: string | null;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly signature: GitSignature | null;
    readonly status: Status | null;
    readonly statusCheckRollup: StatusCheckRollup | null;
    readonly submodules: ReadonlyArray<Submodule>;
    readonly tarballUrl: string;
    readonly tree: Tree;
    readonly treeResourcePath: string;
    readonly treeUrl: string;
    readonly url: string;
    readonly viewerCanSubscribe: boolean;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
    readonly zipballUrl: string;
}
/** Parameters to be used for the commit_author_email_pattern rule */
export interface CommitAuthorEmailPatternParameters {
    readonly name: string | null;
    readonly negate: boolean;
    readonly operator: string;
    readonly pattern: string;
}
/** Represents a comment on a given Commit. */
export interface CommitComment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly commit: Commit | null;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly editor: Actor | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isMinimized: boolean;
    readonly lastEditedAt: string | null;
    readonly minimizedReason: string | null;
    readonly path: string | null;
    readonly position: number | null;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerDidAuthor: boolean;
}
/** The connection type for CommitComment. */
export interface CommitCommentConnection {
    readonly edges: ReadonlyArray<CommitCommentEdge | null> | null;
    readonly nodes: ReadonlyArray<CommitComment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CommitCommentEdge {
    readonly cursor: string;
    readonly node: CommitComment | null;
}
/** A thread of comments on a commit. */
export interface CommitCommentThread {
    readonly comments: ReadonlyArray<CommitComment>;
    readonly commit: Commit | null;
    readonly id: string;
    readonly path: string | null;
    readonly position: number | null;
    readonly repository: Repository;
}
/** The connection type for Commit. */
export interface CommitConnection {
    readonly edges: ReadonlyArray<CommitEdge | null> | null;
    readonly nodes: ReadonlyArray<Commit | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** This aggregates commits made by a user within one repository. */
export interface CommitContributionsByRepository {
    readonly contributions: ReadonlyArray<CreatedCommitContribution>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly url: string;
}
/** An edge in a connection. */
export interface CommitEdge {
    readonly cursor: string;
    readonly node: Commit | null;
}
/** The connection type for Commit. */
export interface CommitHistoryConnection {
    readonly edges: ReadonlyArray<CommitEdge | null> | null;
    readonly nodes: ReadonlyArray<Commit | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Parameters to be used for the commit_message_pattern rule */
export interface CommitMessagePatternParameters {
    readonly name: string | null;
    readonly negate: boolean;
    readonly operator: string;
    readonly pattern: string;
}
/** Parameters to be used for the committer_email_pattern rule */
export interface CommitterEmailPatternParameters {
    readonly name: string | null;
    readonly negate: boolean;
    readonly operator: string;
    readonly pattern: string;
}
/** Represents a comparison between two commit revisions. */
export interface Comparison {
    readonly aheadBy: number;
    readonly baseTarget: GitObject;
    readonly behindBy: number;
    readonly commits: ReadonlyArray<Commit>;
    readonly headTarget: GitObject;
    readonly id: string;
    readonly status: "AHEAD" | "BEHIND" | "DIVERGED" | "IDENTICAL";
}
/** The connection type for Commit. */
export interface ComparisonCommitConnection {
    readonly authorCount: number;
    readonly edges: ReadonlyArray<CommitEdge | null> | null;
    readonly nodes: ReadonlyArray<Commit | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a 'connected' event on a given issue or pull request. */
export interface ConnectedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isCrossRepository: boolean;
    readonly source: Issue | PullRequest;
    readonly subject: Issue | PullRequest;
}
/** The content warning for a repository */
export interface ContentWarning {
    readonly category: string;
    readonly customSubCategory: string | null;
    readonly subCategory: string | null;
    readonly subTitle: string | null;
    readonly title: string;
    readonly type: string;
}
/** The Contributing Guidelines for a repository. */
export interface ContributingGuidelines {
    readonly body: string | null;
    readonly resourcePath: string | null;
    readonly url: string | null;
}
/** Represents a contribution a user made on GitHub, such as opening an issue. */
export interface Contribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** A calendar of contributions made on GitHub by a user. */
export interface ContributionCalendar {
    readonly colors: ReadonlyArray<string>;
    readonly isHalloween: boolean;
    readonly months: ReadonlyArray<ContributionCalendarMonth>;
    readonly totalContributions: number;
    readonly weeks: ReadonlyArray<ContributionCalendarWeek>;
}
/** Represents a single day of contributions on GitHub by a user. */
export interface ContributionCalendarDay {
    readonly color: string;
    readonly contributionCount: number;
    readonly contributionLevel: "FIRST_QUARTILE" | "FOURTH_QUARTILE" | "NONE" | "SECOND_QUARTILE" | "THIRD_QUARTILE";
    readonly date: string;
    readonly weekday: number;
}
/** A month of contributions in a user's contribution graph. */
export interface ContributionCalendarMonth {
    readonly firstDay: string;
    readonly name: string;
    readonly totalWeeks: number;
    readonly year: number;
}
/** A week of contributions in a user's contribution graph. */
export interface ContributionCalendarWeek {
    readonly contributionDays: ReadonlyArray<ContributionCalendarDay>;
    readonly firstDay: string;
}
/** A collection of contributions made by a user, including opened issues, commits, and pull requests.
Contributions in private and internal repositories are only included with the optional read:user scope. */
export interface ContributionsCollection {
    readonly commitContributionsByRepository: ReadonlyArray<CommitContributionsByRepository>;
    readonly contributionCalendar: ContributionCalendar;
    readonly contributionYears: ReadonlyArray<number>;
    readonly doesEndInCurrentMonth: boolean;
    readonly earliestRestrictedContributionDate: string | null;
    readonly endedAt: string;
    readonly firstIssueContribution: CreatedIssueContribution | RestrictedContribution | null;
    readonly firstPullRequestContribution: CreatedPullRequestContribution | RestrictedContribution | null;
    readonly firstRepositoryContribution: CreatedRepositoryContribution | RestrictedContribution | null;
    readonly hasActivityInThePast: boolean;
    readonly hasAnyContributions: boolean;
    readonly hasAnyRestrictedContributions: boolean;
    readonly isSingleDay: boolean;
    readonly issueContributions: ReadonlyArray<CreatedIssueContribution>;
    readonly issueContributionsByRepository: ReadonlyArray<IssueContributionsByRepository>;
    readonly joinedGitHubContribution: JoinedGitHubContribution | null;
    readonly latestRestrictedContributionDate: string | null;
    readonly mostRecentCollectionWithActivity: ContributionsCollection | null;
    readonly mostRecentCollectionWithoutActivity: ContributionsCollection | null;
    readonly popularIssueContribution: CreatedIssueContribution | null;
    readonly popularPullRequestContribution: CreatedPullRequestContribution | null;
    readonly pullRequestContributions: ReadonlyArray<CreatedPullRequestContribution>;
    readonly pullRequestContributionsByRepository: ReadonlyArray<PullRequestContributionsByRepository>;
    readonly pullRequestReviewContributions: ReadonlyArray<CreatedPullRequestReviewContribution>;
    readonly pullRequestReviewContributionsByRepository: ReadonlyArray<PullRequestReviewContributionsByRepository>;
    readonly repositoryContributions: ReadonlyArray<CreatedRepositoryContribution>;
    readonly restrictedContributionsCount: number;
    readonly startedAt: string;
    readonly totalCommitContributions: number;
    readonly totalIssueContributions: FieldWithArgs<number, {
        readonly excludeFirst?: boolean | null | undefined;
        readonly excludePopular?: boolean | null | undefined;
    }, false>;
    readonly totalPullRequestContributions: FieldWithArgs<number, {
        readonly excludeFirst?: boolean | null | undefined;
        readonly excludePopular?: boolean | null | undefined;
    }, false>;
    readonly totalPullRequestReviewContributions: number;
    readonly totalRepositoriesWithContributedCommits: number;
    readonly totalRepositoriesWithContributedIssues: FieldWithArgs<number, {
        readonly excludeFirst?: boolean | null | undefined;
        readonly excludePopular?: boolean | null | undefined;
    }, false>;
    readonly totalRepositoriesWithContributedPullRequestReviews: number;
    readonly totalRepositoriesWithContributedPullRequests: FieldWithArgs<number, {
        readonly excludeFirst?: boolean | null | undefined;
        readonly excludePopular?: boolean | null | undefined;
    }, false>;
    readonly totalRepositoryContributions: FieldWithArgs<number, {
        readonly excludeFirst?: boolean | null | undefined;
    }, false>;
    readonly user: User;
}
/** Autogenerated return type of ConvertProjectCardNoteToIssue. */
export interface ConvertProjectCardNoteToIssuePayload {
    readonly clientMutationId: string | null;
    readonly projectCard: ProjectCard | null;
}
/** Autogenerated return type of ConvertProjectV2DraftIssueItemToIssue. */
export interface ConvertProjectV2DraftIssueItemToIssuePayload {
    readonly clientMutationId: string | null;
    readonly item: ProjectV2Item | null;
}
/** Autogenerated return type of ConvertPullRequestToDraft. */
export interface ConvertPullRequestToDraftPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'convert_to_draft' event on a given pull request. */
export interface ConvertToDraftEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly resourcePath: string;
    readonly url: string;
}
/** Represents a 'converted_from_draft' event on a given issue or pull request. */
export interface ConvertedFromDraftEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly project: ProjectV2 | null;
    readonly wasAutomated: boolean;
}
/** Represents a 'converted_note_to_issue' event on a given issue or pull request. */
export interface ConvertedNoteToIssueEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly project: Project | null;
    readonly projectCard: ProjectCard | null;
    readonly projectColumnName: string;
}
/** Represents a 'converted_to_discussion' event on a given issue. */
export interface ConvertedToDiscussionEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly discussion: Discussion | null;
    readonly id: string;
}
/** Request Copilot code review for new pull requests automatically if the author
has access to Copilot code review and AI credits. */
export interface CopilotCodeReviewParameters {
    readonly reviewDraftPullRequests: boolean;
    readonly reviewOnPush: boolean;
}
/** Copilot endpoint information */
export interface CopilotEndpoints {
    readonly api: string;
    readonly exp: string | null;
    readonly originTracker: string;
    readonly proxy: string;
    readonly telemetry: string;
}
/** Autogenerated return type of CopyProjectV2. */
export interface CopyProjectV2Payload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of CreateAttributionInvitation. */
export interface CreateAttributionInvitationPayload {
    readonly clientMutationId: string | null;
    readonly owner: Organization | null;
    readonly source: Mannequin | User | null;
    readonly target: Mannequin | User | null;
}
/** Autogenerated return type of CreateBranchProtectionRule. */
export interface CreateBranchProtectionRulePayload {
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of CreateCheckRun. */
export interface CreateCheckRunPayload {
    readonly checkRun: CheckRun | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of CreateCheckSuite. */
export interface CreateCheckSuitePayload {
    readonly checkSuite: CheckSuite | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of CreateCommitOnBranch. */
export interface CreateCommitOnBranchPayload {
    readonly clientMutationId: string | null;
    readonly commit: Commit | null;
    readonly ref: Ref | null;
}
/** Autogenerated return type of CreateDeployment. */
export interface CreateDeploymentPayload {
    readonly autoMerged: boolean | null;
    readonly clientMutationId: string | null;
    readonly deployment: Deployment | null;
}
/** Autogenerated return type of CreateDeploymentStatus. */
export interface CreateDeploymentStatusPayload {
    readonly clientMutationId: string | null;
    readonly deploymentStatus: DeploymentStatus | null;
}
/** Autogenerated return type of CreateDiscussion. */
export interface CreateDiscussionPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of CreateEnterpriseOrganization. */
export interface CreateEnterpriseOrganizationPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of CreateEnvironment. */
export interface CreateEnvironmentPayload {
    readonly clientMutationId: string | null;
    readonly environment: Environment | null;
}
/** Autogenerated return type of CreateIpAllowListEntry. */
export interface CreateIpAllowListEntryPayload {
    readonly clientMutationId: string | null;
    readonly ipAllowListEntry: IpAllowListEntry | null;
}
/** Autogenerated return type of CreateIssueField. */
export interface CreateIssueFieldPayload {
    readonly clientMutationId: string | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
}
/** Autogenerated return type of CreateIssueFieldValue. */
export interface CreateIssueFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly issueFieldValue: IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue | null;
}
/** Autogenerated return type of CreateIssue. */
export interface CreateIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of CreateIssueType. */
export interface CreateIssueTypePayload {
    readonly clientMutationId: string | null;
    readonly issueType: IssueType | null;
}
/** Autogenerated return type of CreateLabel. */
export interface CreateLabelPayload {
    readonly clientMutationId: string | null;
    readonly label: Label | null;
}
/** Autogenerated return type of CreateLinkedBranch. */
export interface CreateLinkedBranchPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly linkedBranch: LinkedBranch | null;
}
/** Autogenerated return type of CreateMigrationSource. */
export interface CreateMigrationSourcePayload {
    readonly clientMutationId: string | null;
    readonly migrationSource: MigrationSource | null;
}
/** Autogenerated return type of CreateProject. */
export interface CreateProjectPayload {
    readonly clientMutationId: string | null;
    readonly project: Project | null;
}
/** Autogenerated return type of CreateProjectV2Field. */
export interface CreateProjectV2FieldPayload {
    readonly clientMutationId: string | null;
    readonly projectV2Field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null;
}
/** Autogenerated return type of CreateProjectV2IssueField. */
export interface CreateProjectV2IssueFieldPayload {
    readonly clientMutationId: string | null;
    readonly projectV2Field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null;
}
/** Autogenerated return type of CreateProjectV2. */
export interface CreateProjectV2Payload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of CreateProjectV2StatusUpdate. */
export interface CreateProjectV2StatusUpdatePayload {
    readonly clientMutationId: string | null;
    readonly statusUpdate: ProjectV2StatusUpdate | null;
}
/** Autogenerated return type of CreateProjectV2View. */
export interface CreateProjectV2ViewPayload {
    readonly clientMutationId: string | null;
    readonly projectV2View: ProjectV2View | null;
}
/** Autogenerated return type of CreatePullRequest. */
export interface CreatePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of CreateRef. */
export interface CreateRefPayload {
    readonly clientMutationId: string | null;
    readonly ref: Ref | null;
}
/** Autogenerated return type of CreateRepositoryCustomProperty. */
export interface CreateRepositoryCustomPropertyPayload {
    readonly clientMutationId: string | null;
    readonly repositoryCustomProperty: RepositoryCustomProperty | null;
}
/** Autogenerated return type of CreateRepository. */
export interface CreateRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of CreateRepositoryRuleset. */
export interface CreateRepositoryRulesetPayload {
    readonly clientMutationId: string | null;
    readonly ruleset: RepositoryRuleset | null;
}
/** Autogenerated return type of CreateSponsorsListing. */
export interface CreateSponsorsListingPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsListing: SponsorsListing | null;
}
/** Autogenerated return type of CreateSponsorsTier. */
export interface CreateSponsorsTierPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsTier: SponsorsTier | null;
}
/** Autogenerated return type of CreateSponsorship. */
export interface CreateSponsorshipPayload {
    readonly clientMutationId: string | null;
    readonly sponsorship: Sponsorship | null;
}
/** Autogenerated return type of CreateSponsorships. */
export interface CreateSponsorshipsPayload {
    readonly clientMutationId: string | null;
    readonly sponsorables: ReadonlyArray<Sponsorable> | null;
}
/** Autogenerated return type of CreateUserList. */
export interface CreateUserListPayload {
    readonly clientMutationId: string | null;
    readonly list: UserList | null;
    readonly viewer: User | null;
}
/** Represents the contribution a user made by committing to a repository. */
export interface CreatedCommitContribution {
    readonly commitCount: number;
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** The connection type for CreatedCommitContribution. */
export interface CreatedCommitContributionConnection {
    readonly edges: ReadonlyArray<CreatedCommitContributionEdge | null> | null;
    readonly nodes: ReadonlyArray<CreatedCommitContribution | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CreatedCommitContributionEdge {
    readonly cursor: string;
    readonly node: CreatedCommitContribution | null;
}
/** Represents the contribution a user made on GitHub by opening an issue. */
export interface CreatedIssueContribution {
    readonly isRestricted: boolean;
    readonly issue: Issue;
    readonly occurredAt: string;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** The connection type for CreatedIssueContribution. */
export interface CreatedIssueContributionConnection {
    readonly edges: ReadonlyArray<CreatedIssueContributionEdge | null> | null;
    readonly nodes: ReadonlyArray<CreatedIssueContribution | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CreatedIssueContributionEdge {
    readonly cursor: string;
    readonly node: CreatedIssueContribution | null;
}
/** Represents the contribution a user made on GitHub by opening a pull request. */
export interface CreatedPullRequestContribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly pullRequest: PullRequest;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** The connection type for CreatedPullRequestContribution. */
export interface CreatedPullRequestContributionConnection {
    readonly edges: ReadonlyArray<CreatedPullRequestContributionEdge | null> | null;
    readonly nodes: ReadonlyArray<CreatedPullRequestContribution | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CreatedPullRequestContributionEdge {
    readonly cursor: string;
    readonly node: CreatedPullRequestContribution | null;
}
/** Represents the contribution a user made by leaving a review on a pull request. */
export interface CreatedPullRequestReviewContribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly pullRequest: PullRequest;
    readonly pullRequestReview: PullRequestReview;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** The connection type for CreatedPullRequestReviewContribution. */
export interface CreatedPullRequestReviewContributionConnection {
    readonly edges: ReadonlyArray<CreatedPullRequestReviewContributionEdge | null> | null;
    readonly nodes: ReadonlyArray<CreatedPullRequestReviewContribution | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CreatedPullRequestReviewContributionEdge {
    readonly cursor: string;
    readonly node: CreatedPullRequestReviewContribution | null;
}
/** Represents the contribution a user made on GitHub by creating a repository. */
export interface CreatedRepositoryContribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** The connection type for CreatedRepositoryContribution. */
export interface CreatedRepositoryContributionConnection {
    readonly edges: ReadonlyArray<CreatedRepositoryContributionEdge | null> | null;
    readonly nodes: ReadonlyArray<CreatedRepositoryContribution | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface CreatedRepositoryContributionEdge {
    readonly cursor: string;
    readonly node: CreatedRepositoryContribution | null;
}
/** Represents a mention made by one issue or pull request to another. */
export interface CrossReferencedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isCrossRepository: boolean;
    readonly referencedAt: string;
    readonly resourcePath: string;
    readonly source: Issue | PullRequest;
    readonly target: Issue | PullRequest;
    readonly url: string;
    readonly willCloseTarget: boolean;
}
/** The Common Vulnerability Scoring System */
export interface CvssSeverities {
    readonly cvssV3: CVSS | null;
    readonly cvssV4: CVSS | null;
}
/** Autogenerated return type of DeclineTopicSuggestion. */
export interface DeclineTopicSuggestionPayload {
    readonly clientMutationId: string | null;
    readonly topic: Topic | null;
}
/** Entities that can be deleted. */
export interface Deletable {
    readonly viewerCanDelete: boolean;
}
/** Autogenerated return type of DeleteBranchProtectionRule. */
export interface DeleteBranchProtectionRulePayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteDeployment. */
export interface DeleteDeploymentPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteDiscussionComment. */
export interface DeleteDiscussionCommentPayload {
    readonly clientMutationId: string | null;
    readonly comment: DiscussionComment | null;
}
/** Autogenerated return type of DeleteDiscussion. */
export interface DeleteDiscussionPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of DeleteEnvironment. */
export interface DeleteEnvironmentPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteIpAllowListEntry. */
export interface DeleteIpAllowListEntryPayload {
    readonly clientMutationId: string | null;
    readonly ipAllowListEntry: IpAllowListEntry | null;
}
/** Autogenerated return type of DeleteIssueComment. */
export interface DeleteIssueCommentPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteIssueField. */
export interface DeleteIssueFieldPayload {
    readonly clientMutationId: string | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
}
/** Autogenerated return type of DeleteIssueFieldValue. */
export interface DeleteIssueFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly success: boolean | null;
}
/** Autogenerated return type of DeleteIssue. */
export interface DeleteIssuePayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of DeleteIssueType. */
export interface DeleteIssueTypePayload {
    readonly clientMutationId: string | null;
    readonly deletedIssueTypeId: string | null;
}
/** Autogenerated return type of DeleteLabel. */
export interface DeleteLabelPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteLinkedBranch. */
export interface DeleteLinkedBranchPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of DeletePackageVersion. */
export interface DeletePackageVersionPayload {
    readonly clientMutationId: string | null;
    readonly success: boolean | null;
}
/** Autogenerated return type of DeleteProjectCard. */
export interface DeleteProjectCardPayload {
    readonly clientMutationId: string | null;
    readonly column: ProjectColumn | null;
    readonly deletedCardId: string | null;
}
/** Autogenerated return type of DeleteProjectColumn. */
export interface DeleteProjectColumnPayload {
    readonly clientMutationId: string | null;
    readonly deletedColumnId: string | null;
    readonly project: Project | null;
}
/** Autogenerated return type of DeleteProject. */
export interface DeleteProjectPayload {
    readonly clientMutationId: string | null;
    readonly owner: ProjectOwner | null;
}
/** Autogenerated return type of DeleteProjectV2Field. */
export interface DeleteProjectV2FieldPayload {
    readonly clientMutationId: string | null;
    readonly projectV2Field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null;
}
/** Autogenerated return type of DeleteProjectV2Item. */
export interface DeleteProjectV2ItemPayload {
    readonly clientMutationId: string | null;
    readonly deletedItemId: string | null;
}
/** Autogenerated return type of DeleteProjectV2. */
export interface DeleteProjectV2Payload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of DeleteProjectV2StatusUpdate. */
export interface DeleteProjectV2StatusUpdatePayload {
    readonly clientMutationId: string | null;
    readonly deletedStatusUpdateId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of DeleteProjectV2View. */
export interface DeleteProjectV2ViewPayload {
    readonly clientMutationId: string | null;
    readonly projectV2View: ProjectV2View | null;
}
/** Autogenerated return type of DeleteProjectV2Workflow. */
export interface DeleteProjectV2WorkflowPayload {
    readonly clientMutationId: string | null;
    readonly deletedWorkflowId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of DeletePullRequestReviewComment. */
export interface DeletePullRequestReviewCommentPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
    readonly pullRequestReviewComment: PullRequestReviewComment | null;
}
/** Autogenerated return type of DeletePullRequestReview. */
export interface DeletePullRequestReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
}
/** Autogenerated return type of DeleteRef. */
export interface DeleteRefPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteRepositoryCustomProperty. */
export interface DeleteRepositoryCustomPropertyPayload {
    readonly clientMutationId: string | null;
    readonly repositoryCustomProperty: RepositoryCustomProperty | null;
}
/** Autogenerated return type of DeleteRepositoryRuleset. */
export interface DeleteRepositoryRulesetPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of DeleteUserList. */
export interface DeleteUserListPayload {
    readonly clientMutationId: string | null;
    readonly user: User | null;
}
/** Autogenerated return type of DeleteVerifiableDomain. */
export interface DeleteVerifiableDomainPayload {
    readonly clientMutationId: string | null;
    readonly owner: Enterprise | Organization | null;
}
/** Represents a 'demilestoned' event on a given issue or pull request. */
export interface DemilestonedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly milestoneTitle: string;
    readonly subject: Issue | PullRequest;
}
/** A Dependabot Update for a dependency in a repository */
export interface DependabotUpdate {
    readonly error: DependabotUpdateError | null;
    readonly pullRequest: PullRequest | null;
    readonly repository: Repository;
}
/** An error produced from a Dependabot Update */
export interface DependabotUpdateError {
    readonly body: string;
    readonly errorType: string;
    readonly title: string;
}
/** A dependency manifest entry */
export interface DependencyGraphDependency {
    readonly hasDependencies: boolean;
    readonly packageLabel: string;
    readonly packageManager: string | null;
    readonly packageName: string;
    readonly packageUrl: string | null;
    readonly relationship: string;
    readonly repository: Repository | null;
    readonly requirements: string;
}
/** The connection type for DependencyGraphDependency. */
export interface DependencyGraphDependencyConnection {
    readonly edges: ReadonlyArray<DependencyGraphDependencyEdge | null> | null;
    readonly nodes: ReadonlyArray<DependencyGraphDependency | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DependencyGraphDependencyEdge {
    readonly cursor: string;
    readonly node: DependencyGraphDependency | null;
}
/** Dependency manifest for a repository */
export interface DependencyGraphManifest {
    readonly blobPath: string;
    readonly dependencies: ReadonlyArray<DependencyGraphDependency> | null;
    readonly dependenciesCount: number | null;
    readonly exceedsMaxSize: boolean;
    readonly filename: string;
    readonly id: string;
    readonly parseable: boolean;
    readonly repository: Repository;
}
/** The connection type for DependencyGraphManifest. */
export interface DependencyGraphManifestConnection {
    readonly edges: ReadonlyArray<DependencyGraphManifestEdge | null> | null;
    readonly nodes: ReadonlyArray<DependencyGraphManifest | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DependencyGraphManifestEdge {
    readonly cursor: string;
    readonly node: DependencyGraphManifest | null;
}
/** A repository deploy key. */
export interface DeployKey {
    readonly createdAt: string;
    readonly enabled: boolean;
    readonly id: string;
    readonly key: string;
    readonly readOnly: boolean;
    readonly title: string;
    readonly verified: boolean;
}
/** The connection type for DeployKey. */
export interface DeployKeyConnection {
    readonly edges: ReadonlyArray<DeployKeyEdge | null> | null;
    readonly nodes: ReadonlyArray<DeployKey | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeployKeyEdge {
    readonly cursor: string;
    readonly node: DeployKey | null;
}
/** Represents a 'deployed' event on a given pull request. */
export interface DeployedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly deployment: Deployment;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly ref: Ref | null;
}
/** Represents triggered deployment instance. */
export interface Deployment {
    readonly commit: Commit | null;
    readonly commitOid: string;
    readonly createdAt: string;
    readonly creator: Actor;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly environment: string | null;
    readonly id: string;
    readonly latestEnvironment: string | null;
    readonly latestStatus: DeploymentStatus | null;
    readonly originalEnvironment: string | null;
    readonly payload: string | null;
    readonly ref: Ref | null;
    readonly repository: Repository;
    readonly state: "ABANDONED" | "ACTIVE" | "DESTROYED" | "ERROR" | "FAILURE" | "INACTIVE" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "SUCCESS" | "WAITING" | null;
    readonly statuses: ReadonlyArray<DeploymentStatus> | null;
    readonly task: string | null;
    readonly updatedAt: string;
}
/** The connection type for Deployment. */
export interface DeploymentConnection {
    readonly edges: ReadonlyArray<DeploymentEdge | null> | null;
    readonly nodes: ReadonlyArray<Deployment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentEdge {
    readonly cursor: string;
    readonly node: Deployment | null;
}
/** Represents a 'deployment_environment_changed' event on a given pull request. */
export interface DeploymentEnvironmentChangedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly deploymentStatus: DeploymentStatus;
    readonly id: string;
    readonly pullRequest: PullRequest;
}
/** A protection rule. */
export interface DeploymentProtectionRule {
    readonly databaseId: number | null;
    readonly preventSelfReview: boolean | null;
    readonly reviewers: ReadonlyArray<Team | User>;
    readonly timeout: number;
    readonly type: "BRANCH_POLICY" | "REQUIRED_REVIEWERS" | "WAIT_TIMER";
}
/** The connection type for DeploymentProtectionRule. */
export interface DeploymentProtectionRuleConnection {
    readonly edges: ReadonlyArray<DeploymentProtectionRuleEdge | null> | null;
    readonly nodes: ReadonlyArray<DeploymentProtectionRule | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentProtectionRuleEdge {
    readonly cursor: string;
    readonly node: DeploymentProtectionRule | null;
}
/** A request to deploy a workflow run to an environment. */
export interface DeploymentRequest {
    readonly currentUserCanApprove: boolean;
    readonly environment: Environment;
    readonly reviewers: ReadonlyArray<Team | User>;
    readonly waitTimer: number;
    readonly waitTimerStartedAt: string | null;
}
/** The connection type for DeploymentRequest. */
export interface DeploymentRequestConnection {
    readonly edges: ReadonlyArray<DeploymentRequestEdge | null> | null;
    readonly nodes: ReadonlyArray<DeploymentRequest | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentRequestEdge {
    readonly cursor: string;
    readonly node: DeploymentRequest | null;
}
/** A deployment review. */
export interface DeploymentReview {
    readonly comment: string;
    readonly databaseId: number | null;
    readonly environments: ReadonlyArray<Environment>;
    readonly id: string;
    readonly state: "APPROVED" | "REJECTED";
    readonly user: User;
}
/** The connection type for DeploymentReview. */
export interface DeploymentReviewConnection {
    readonly edges: ReadonlyArray<DeploymentReviewEdge | null> | null;
    readonly nodes: ReadonlyArray<DeploymentReview | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentReviewEdge {
    readonly cursor: string;
    readonly node: DeploymentReview | null;
}
/** The connection type for DeploymentReviewer. */
export interface DeploymentReviewerConnection {
    readonly edges: ReadonlyArray<DeploymentReviewerEdge | null> | null;
    readonly nodes: ReadonlyArray<Team | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentReviewerEdge {
    readonly cursor: string;
    readonly node: Team | User | null;
}
/** Describes the status of a given deployment attempt. */
export interface DeploymentStatus {
    readonly createdAt: string;
    readonly creator: Actor;
    readonly deployment: Deployment;
    readonly description: string | null;
    readonly environment: string | null;
    readonly environmentUrl: string | null;
    readonly id: string;
    readonly logUrl: string | null;
    readonly state: "ERROR" | "FAILURE" | "INACTIVE" | "IN_PROGRESS" | "PENDING" | "QUEUED" | "SUCCESS" | "WAITING";
    readonly updatedAt: string;
}
/** The connection type for DeploymentStatus. */
export interface DeploymentStatusConnection {
    readonly edges: ReadonlyArray<DeploymentStatusEdge | null> | null;
    readonly nodes: ReadonlyArray<DeploymentStatus | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DeploymentStatusEdge {
    readonly cursor: string;
    readonly node: DeploymentStatus | null;
}
/** Autogenerated return type of DequeuePullRequest. */
export interface DequeuePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly mergeQueueEntry: MergeQueueEntry | null;
}
/** Autogenerated return type of DisablePullRequestAutoMerge. */
export interface DisablePullRequestAutoMergePayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'disconnected' event on a given issue or pull request. */
export interface DisconnectedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isCrossRepository: boolean;
    readonly source: Issue | PullRequest;
    readonly subject: Issue | PullRequest;
}
/** A discussion in a repository. */
export interface Discussion {
    readonly activeLockReason: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null;
    readonly answer: DiscussionComment | null;
    readonly answerChosenAt: string | null;
    readonly answerChosenBy: Actor | null;
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly category: DiscussionCategory;
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly comments: ReadonlyArray<DiscussionComment>;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly editor: Actor | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isAnswered: boolean | null;
    readonly labels: ReadonlyArray<Label> | null;
    readonly lastEditedAt: string | null;
    readonly locked: boolean;
    readonly number: number;
    readonly poll: DiscussionPoll | null;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly stateReason: "DUPLICATE" | "OUTDATED" | "REOPENED" | "RESOLVED" | null;
    readonly title: string;
    readonly updatedAt: string;
    readonly upvoteCount: number;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanClose: boolean;
    readonly viewerCanDelete: boolean;
    readonly viewerCanLabel: boolean;
    readonly viewerCanReact: boolean;
    readonly viewerCanReopen: boolean;
    readonly viewerCanSubscribe: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerCanUpvote: boolean;
    readonly viewerDidAuthor: boolean;
    readonly viewerHasUpvoted: boolean;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
}
/** A category for discussions in a repository. */
export interface DiscussionCategory {
    readonly createdAt: string;
    readonly description: string | null;
    readonly emoji: string;
    readonly emojiHTML: string;
    readonly id: string;
    readonly isAnswerable: boolean;
    readonly name: string;
    readonly repository: Repository;
    readonly slug: string;
    readonly updatedAt: string;
}
/** The connection type for DiscussionCategory. */
export interface DiscussionCategoryConnection {
    readonly edges: ReadonlyArray<DiscussionCategoryEdge | null> | null;
    readonly nodes: ReadonlyArray<DiscussionCategory | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DiscussionCategoryEdge {
    readonly cursor: string;
    readonly node: DiscussionCategory | null;
}
/** A comment on a discussion. */
export interface DiscussionComment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly deletedAt: string | null;
    readonly discussion: Discussion | null;
    readonly editor: Actor | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isAnswer: boolean;
    readonly isMinimized: boolean;
    readonly lastEditedAt: string | null;
    readonly minimizedReason: string | null;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly replies: ReadonlyArray<DiscussionComment>;
    readonly replyTo: DiscussionComment | null;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly upvoteCount: number;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMarkAsAnswer: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanUnmarkAsAnswer: boolean;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerCanUpvote: boolean;
    readonly viewerDidAuthor: boolean;
    readonly viewerHasUpvoted: boolean;
}
/** The connection type for DiscussionComment. */
export interface DiscussionCommentConnection {
    readonly edges: ReadonlyArray<DiscussionCommentEdge | null> | null;
    readonly nodes: ReadonlyArray<DiscussionComment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DiscussionCommentEdge {
    readonly cursor: string;
    readonly node: DiscussionComment | null;
}
/** The connection type for Discussion. */
export interface DiscussionConnection {
    readonly edges: ReadonlyArray<DiscussionEdge | null> | null;
    readonly nodes: ReadonlyArray<Discussion | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DiscussionEdge {
    readonly cursor: string;
    readonly node: Discussion | null;
}
/** A poll for a discussion. */
export interface DiscussionPoll {
    readonly discussion: Discussion | null;
    readonly id: string;
    readonly options: ReadonlyArray<DiscussionPollOption> | null;
    readonly question: string;
    readonly totalVoteCount: number;
    readonly viewerCanVote: boolean;
    readonly viewerHasVoted: boolean;
}
/** An option for a discussion poll. */
export interface DiscussionPollOption {
    readonly id: string;
    readonly option: string;
    readonly poll: DiscussionPoll | null;
    readonly totalVoteCount: number;
    readonly viewerHasVoted: boolean;
}
/** The connection type for DiscussionPollOption. */
export interface DiscussionPollOptionConnection {
    readonly edges: ReadonlyArray<DiscussionPollOptionEdge | null> | null;
    readonly nodes: ReadonlyArray<DiscussionPollOption | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface DiscussionPollOptionEdge {
    readonly cursor: string;
    readonly node: DiscussionPollOption | null;
}
/** Autogenerated return type of DismissPullRequestReview. */
export interface DismissPullRequestReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
}
/** Autogenerated return type of DismissRepositoryVulnerabilityAlert. */
export interface DismissRepositoryVulnerabilityAlertPayload {
    readonly clientMutationId: string | null;
    readonly repositoryVulnerabilityAlert: RepositoryVulnerabilityAlert | null;
}
/** Specify people, teams, or apps allowed to dismiss pull request reviews. */
export interface DismissalRestriction {
    readonly allowedActors: ReadonlyArray<string> | null;
    readonly enabled: boolean;
}
/** A draft issue within a project. */
export interface DraftIssue {
    readonly assignees: ReadonlyArray<User>;
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly id: string;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2Items: ReadonlyArray<ProjectV2Item>;
    readonly title: string;
    readonly updatedAt: string;
}
/** The Exploit Prediction Scoring System */
export interface EPSS {
    readonly percentage: number | null;
    readonly percentile: number | null;
}
/** Autogenerated return type of EnablePullRequestAutoMerge. */
export interface EnablePullRequestAutoMergePayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of EnqueuePullRequest. */
export interface EnqueuePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly mergeQueueEntry: MergeQueueEntry | null;
}
/** An account to manage multiple organizations with consolidated policy and billing. */
export interface Enterprise {
    readonly announcementBanner: AnnouncementBanner | null;
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly billingEmail: string | null;
    readonly billingInfo: EnterpriseBillingInfo | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly descriptionHTML: string;
    readonly enterpriseTeam: FieldWithArgs<EnterpriseTeam | null, {
        readonly slug: string;
    }>;
    readonly enterpriseTeams: ReadonlyArray<EnterpriseTeam>;
    readonly id: string;
    readonly innersourceVulnerabilities: ReadonlyArray<SecurityVulnerability>;
    readonly location: string | null;
    readonly members: ReadonlyArray<EnterpriseUserAccount | User>;
    readonly name: string;
    readonly organizations: ReadonlyArray<Organization>;
    readonly ownerInfo: EnterpriseOwnerInfo | null;
    readonly readme: string | null;
    readonly readmeHTML: string;
    readonly repositoryCustomProperties: ReadonlyArray<RepositoryCustomProperty> | null;
    readonly repositoryCustomProperty: FieldWithArgs<RepositoryCustomProperty | null, {
        readonly propertyName: string;
    }>;
    readonly resourcePath: string;
    readonly ruleset: FieldWithArgs<RepositoryRuleset | null, {
        readonly databaseId: number;
    }>;
    readonly rulesets: ReadonlyArray<RepositoryRuleset> | null;
    readonly securityContactEmail: string | null;
    readonly slug: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly userNamespaceRepositories: ReadonlyArray<UserNamespaceRepository>;
    readonly viewerIsAdmin: boolean;
    readonly websiteUrl: string | null;
}
/** The connection type for User. */
export interface EnterpriseAdministratorConnection {
    readonly edges: ReadonlyArray<EnterpriseAdministratorEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** A User who is an administrator of an enterprise. */
export interface EnterpriseAdministratorEdge {
    readonly cursor: string;
    readonly node: User | null;
    readonly role: "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED";
}
/** An invitation for a user to become an owner or billing manager of an enterprise. */
export interface EnterpriseAdministratorInvitation {
    readonly createdAt: string;
    readonly email: string | null;
    readonly enterprise: Enterprise;
    readonly id: string;
    readonly invitee: User | null;
    readonly inviter: User | null;
    readonly role: "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED";
}
/** The connection type for EnterpriseAdministratorInvitation. */
export interface EnterpriseAdministratorInvitationConnection {
    readonly edges: ReadonlyArray<EnterpriseAdministratorInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseAdministratorInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseAdministratorInvitationEdge {
    readonly cursor: string;
    readonly node: EnterpriseAdministratorInvitation | null;
}
/** Metadata for an audit entry containing enterprise account information. */
export interface EnterpriseAuditEntryData {
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
}
/** Enterprise billing information visible to enterprise billing managers and owners. */
export interface EnterpriseBillingInfo {
    readonly allLicensableUsersCount: number;
    readonly assetPacks: number;
    readonly bandwidthQuota: number;
    readonly bandwidthUsage: number;
    readonly bandwidthUsagePercentage: number;
    readonly storageQuota: number;
    readonly storageUsage: number;
    readonly storageUsagePercentage: number;
    readonly totalAvailableLicenses: number;
    readonly totalLicenses: number;
}
/** The connection type for Enterprise. */
export interface EnterpriseConnection {
    readonly edges: ReadonlyArray<EnterpriseEdge | null> | null;
    readonly nodes: ReadonlyArray<Enterprise | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseEdge {
    readonly cursor: string;
    readonly node: Enterprise | null;
}
/** The connection type for OrganizationInvitation. */
export interface EnterpriseFailedInvitationConnection {
    readonly edges: ReadonlyArray<EnterpriseFailedInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<OrganizationInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly totalUniqueUserCount: number;
}
/** A failed invitation to be a member in an enterprise organization. */
export interface EnterpriseFailedInvitationEdge {
    readonly cursor: string;
    readonly node: OrganizationInvitation | null;
}
/** An identity provider configured to provision identities for an enterprise.
Visible to enterprise owners or enterprise owners' personal access tokens
(classic) with read:enterprise or admin:enterprise scope. */
export interface EnterpriseIdentityProvider {
    readonly digestMethod: "SHA1" | "SHA256" | "SHA384" | "SHA512" | null;
    readonly enterprise: Enterprise | null;
    readonly externalIdentities: ReadonlyArray<ExternalIdentity>;
    readonly id: string;
    readonly idpCertificate: string | null;
    readonly issuer: string | null;
    readonly recoveryCodes: ReadonlyArray<string> | null;
    readonly signatureMethod: "RSA_SHA1" | "RSA_SHA256" | "RSA_SHA384" | "RSA_SHA512" | null;
    readonly ssoUrl: string | null;
}
/** The connection type for EnterpriseMember. */
export interface EnterpriseMemberConnection {
    readonly edges: ReadonlyArray<EnterpriseMemberEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseUserAccount | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** A User who is a member of an enterprise through one or more organizations. */
export interface EnterpriseMemberEdge {
    readonly cursor: string;
    readonly node: EnterpriseUserAccount | User | null;
}
/** An invitation for a user to become an unaffiliated member of an enterprise. */
export interface EnterpriseMemberInvitation {
    readonly createdAt: string;
    readonly email: string | null;
    readonly enterprise: Enterprise;
    readonly id: string;
    readonly invitee: User | null;
    readonly inviter: User | null;
}
/** The connection type for EnterpriseMemberInvitation. */
export interface EnterpriseMemberInvitationConnection {
    readonly edges: ReadonlyArray<EnterpriseMemberInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseMemberInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseMemberInvitationEdge {
    readonly cursor: string;
    readonly node: EnterpriseMemberInvitation | null;
}
/** The connection type for Organization. */
export interface EnterpriseOrganizationMembershipConnection {
    readonly edges: ReadonlyArray<EnterpriseOrganizationMembershipEdge | null> | null;
    readonly nodes: ReadonlyArray<Organization | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An enterprise organization that a user is a member of. */
export interface EnterpriseOrganizationMembershipEdge {
    readonly cursor: string;
    readonly node: Organization | null;
    readonly role: "MEMBER" | "OWNER" | "UNAFFILIATED";
}
/** The connection type for User. */
export interface EnterpriseOutsideCollaboratorConnection {
    readonly edges: ReadonlyArray<EnterpriseOutsideCollaboratorEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** A User who is an outside collaborator of an enterprise through one or more organizations. */
export interface EnterpriseOutsideCollaboratorEdge {
    readonly cursor: string;
    readonly node: User | null;
    readonly repositories: ReadonlyArray<EnterpriseRepositoryInfo>;
}
/** Enterprise information visible to enterprise owners or enterprise owners'
personal access tokens (classic) with read:enterprise or admin:enterprise scope. */
export interface EnterpriseOwnerInfo {
    readonly admins: ReadonlyArray<User>;
    readonly affiliatedUsersWithTwoFactorDisabled: ReadonlyArray<User>;
    readonly affiliatedUsersWithTwoFactorDisabledExist: boolean;
    readonly allowPrivateRepositoryForkingSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly allowPrivateRepositoryForkingSettingOrganizations: ReadonlyArray<Organization>;
    readonly allowPrivateRepositoryForkingSettingPolicyValue: "ENTERPRISE_ORGANIZATIONS" | "ENTERPRISE_ORGANIZATIONS_USER_ACCOUNTS" | "EVERYWHERE" | "SAME_ORGANIZATION" | "SAME_ORGANIZATION_USER_ACCOUNTS" | "USER_ACCOUNTS" | null;
    readonly defaultRepositoryPermissionSetting: "ADMIN" | "NONE" | "NO_POLICY" | "READ" | "WRITE";
    readonly defaultRepositoryPermissionSettingOrganizations: ReadonlyArray<Organization>;
    readonly domains: ReadonlyArray<VerifiableDomain>;
    readonly enterpriseServerInstallations: ReadonlyArray<EnterpriseServerInstallation>;
    readonly failedInvitations: ReadonlyArray<OrganizationInvitation>;
    readonly ipAllowListEnabledSetting: "DISABLED" | "ENABLED";
    readonly ipAllowListEntries: ReadonlyArray<IpAllowListEntry>;
    readonly ipAllowListForInstalledAppsEnabledSetting: "DISABLED" | "ENABLED";
    readonly ipAllowListUserLevelEnforcementEnabledSetting: "DISABLED" | "ENABLED";
    readonly isUpdatingDefaultRepositoryPermission: boolean;
    readonly isUpdatingTwoFactorRequirement: boolean;
    readonly membersCanChangeRepositoryVisibilitySetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanChangeRepositoryVisibilitySettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanCreateInternalRepositoriesSetting: boolean | null;
    readonly membersCanCreatePrivateRepositoriesSetting: boolean | null;
    readonly membersCanCreatePublicRepositoriesSetting: boolean | null;
    readonly membersCanCreateRepositoriesSetting: "ALL" | "DISABLED" | "NO_POLICY" | "PRIVATE" | "PUBLIC" | null;
    readonly membersCanCreateRepositoriesSettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanDeleteIssuesSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanDeleteIssuesSettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanDeleteRepositoriesSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanDeleteRepositoriesSettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanInviteCollaboratorsSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanInviteCollaboratorsSettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanMakePurchasesSetting: "DISABLED" | "ENABLED";
    readonly membersCanUpdateProtectedBranchesSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanUpdateProtectedBranchesSettingOrganizations: ReadonlyArray<Organization>;
    readonly membersCanViewDependencyInsightsSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly membersCanViewDependencyInsightsSettingOrganizations: ReadonlyArray<Organization>;
    readonly notificationDeliveryRestrictionEnabledSetting: "DISABLED" | "ENABLED";
    readonly oidcProvider: OIDCProvider | null;
    readonly organizationProjectsSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly organizationProjectsSettingOrganizations: ReadonlyArray<Organization>;
    readonly outsideCollaborators: ReadonlyArray<User>;
    readonly pendingAdminInvitations: ReadonlyArray<EnterpriseAdministratorInvitation>;
    readonly pendingCollaboratorInvitations: ReadonlyArray<RepositoryInvitation>;
    readonly pendingMemberInvitations: ReadonlyArray<OrganizationInvitation>;
    readonly pendingUnaffiliatedMemberInvitations: ReadonlyArray<EnterpriseMemberInvitation>;
    readonly repositoryDeployKeySetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly repositoryDeployKeySettingOrganizations: ReadonlyArray<Organization>;
    readonly repositoryProjectsSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly repositoryProjectsSettingOrganizations: ReadonlyArray<Organization>;
    readonly samlIdentityProvider: EnterpriseIdentityProvider | null;
    readonly samlIdentityProviderSettingOrganizations: ReadonlyArray<Organization>;
    readonly supportEntitlements: ReadonlyArray<EnterpriseUserAccount | User>;
    readonly teamDiscussionsSetting: "DISABLED" | "ENABLED" | "NO_POLICY";
    readonly twoFactorDisallowedMethodsSetting: "INSECURE" | "NO_POLICY";
    readonly twoFactorRequiredSetting: "ENABLED" | "NO_POLICY";
    readonly twoFactorRequiredSettingOrganizations: ReadonlyArray<Organization>;
}
/** The connection type for OrganizationInvitation. */
export interface EnterprisePendingMemberInvitationConnection {
    readonly edges: ReadonlyArray<EnterprisePendingMemberInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<OrganizationInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly totalUniqueUserCount: number;
}
/** An invitation to be a member in an enterprise organization. */
export interface EnterprisePendingMemberInvitationEdge {
    readonly cursor: string;
    readonly node: OrganizationInvitation | null;
}
/** A subset of repository information queryable from an enterprise. */
export interface EnterpriseRepositoryInfo {
    readonly id: string;
    readonly isPrivate: boolean;
    readonly name: string;
    readonly nameWithOwner: string;
}
/** The connection type for EnterpriseRepositoryInfo. */
export interface EnterpriseRepositoryInfoConnection {
    readonly edges: ReadonlyArray<EnterpriseRepositoryInfoEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseRepositoryInfo | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseRepositoryInfoEdge {
    readonly cursor: string;
    readonly node: EnterpriseRepositoryInfo | null;
}
/** An Enterprise Server installation. */
export interface EnterpriseServerInstallation {
    readonly createdAt: string;
    readonly customerName: string;
    readonly hostName: string;
    readonly id: string;
    readonly isConnected: boolean;
    readonly updatedAt: string;
    readonly userAccounts: ReadonlyArray<EnterpriseServerUserAccount>;
    readonly userAccountsUploads: ReadonlyArray<EnterpriseServerUserAccountsUpload>;
}
/** The connection type for EnterpriseServerInstallation. */
export interface EnterpriseServerInstallationConnection {
    readonly edges: ReadonlyArray<EnterpriseServerInstallationEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseServerInstallation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseServerInstallationEdge {
    readonly cursor: string;
    readonly node: EnterpriseServerInstallation | null;
}
/** The connection type for EnterpriseServerInstallation. */
export interface EnterpriseServerInstallationMembershipConnection {
    readonly edges: ReadonlyArray<EnterpriseServerInstallationMembershipEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseServerInstallation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An Enterprise Server installation that a user is a member of. */
export interface EnterpriseServerInstallationMembershipEdge {
    readonly cursor: string;
    readonly node: EnterpriseServerInstallation | null;
    readonly role: "MEMBER" | "OWNER" | "UNAFFILIATED";
}
/** A user account on an Enterprise Server installation. */
export interface EnterpriseServerUserAccount {
    readonly createdAt: string;
    readonly emails: ReadonlyArray<EnterpriseServerUserAccountEmail>;
    readonly enterpriseServerInstallation: EnterpriseServerInstallation;
    readonly id: string;
    readonly isSiteAdmin: boolean;
    readonly login: string;
    readonly profileName: string | null;
    readonly remoteCreatedAt: string;
    readonly remoteUserId: number;
    readonly updatedAt: string;
}
/** The connection type for EnterpriseServerUserAccount. */
export interface EnterpriseServerUserAccountConnection {
    readonly edges: ReadonlyArray<EnterpriseServerUserAccountEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseServerUserAccount | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseServerUserAccountEdge {
    readonly cursor: string;
    readonly node: EnterpriseServerUserAccount | null;
}
/** An email belonging to a user account on an Enterprise Server installation. */
export interface EnterpriseServerUserAccountEmail {
    readonly createdAt: string;
    readonly email: string;
    readonly id: string;
    readonly isPrimary: boolean;
    readonly updatedAt: string;
    readonly userAccount: EnterpriseServerUserAccount;
}
/** The connection type for EnterpriseServerUserAccountEmail. */
export interface EnterpriseServerUserAccountEmailConnection {
    readonly edges: ReadonlyArray<EnterpriseServerUserAccountEmailEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseServerUserAccountEmail | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseServerUserAccountEmailEdge {
    readonly cursor: string;
    readonly node: EnterpriseServerUserAccountEmail | null;
}
/** A user accounts upload from an Enterprise Server installation. */
export interface EnterpriseServerUserAccountsUpload {
    readonly createdAt: string;
    readonly enterprise: Enterprise;
    readonly enterpriseServerInstallation: EnterpriseServerInstallation;
    readonly id: string;
    readonly name: string;
    readonly syncState: "FAILURE" | "PENDING" | "SUCCESS";
    readonly updatedAt: string;
}
/** The connection type for EnterpriseServerUserAccountsUpload. */
export interface EnterpriseServerUserAccountsUploadConnection {
    readonly edges: ReadonlyArray<EnterpriseServerUserAccountsUploadEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseServerUserAccountsUpload | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseServerUserAccountsUploadEdge {
    readonly cursor: string;
    readonly node: EnterpriseServerUserAccountsUpload | null;
}
/** A team that belongs to an enterprise and can be assigned to multiple organizations. */
export interface EnterpriseTeam {
    readonly assignedOrganizations: ReadonlyArray<Organization>;
    readonly combinedSlug: string;
    readonly createdAt: string;
    readonly description: string | null;
    readonly enterprise: Enterprise | null;
    readonly enterpriseTeamMembers: ReadonlyArray<User>;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly isViewerMember: boolean;
    readonly name: string;
    readonly notificationSetting: "NOTIFICATIONS_DISABLED" | "NOTIFICATIONS_ENABLED";
    readonly organizationSelectionType: "ALL" | "DISABLED" | "SELECTED";
    readonly privacy: "SECRET" | "VISIBLE";
    readonly slug: string;
    readonly updatedAt: string;
    readonly viewerCanAdminister: boolean;
}
/** The connection type for Organization. */
export interface EnterpriseTeamAssignedOrganizationConnection {
    readonly edges: ReadonlyArray<EnterpriseTeamAssignedOrganizationEdge | null> | null;
    readonly nodes: ReadonlyArray<Organization | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents an organization that an enterprise team is assigned to. */
export interface EnterpriseTeamAssignedOrganizationEdge {
    readonly cursor: string;
    readonly node: Organization | null;
}
/** A list of enterprise teams owned by the enterprise. */
export interface EnterpriseTeamConnection {
    readonly edges: ReadonlyArray<EnterpriseTeamEdge | null> | null;
    readonly nodes: ReadonlyArray<EnterpriseTeam | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnterpriseTeamEdge {
    readonly cursor: string;
    readonly node: EnterpriseTeam | null;
}
/** The connection type for User. */
export interface EnterpriseTeamMemberConnection {
    readonly edges: ReadonlyArray<EnterpriseTeamMemberEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user who is a member of an enterprise team. */
export interface EnterpriseTeamMemberEdge {
    readonly cursor: string;
    readonly node: User | null;
}
/** An account for a user who is an admin of an enterprise or a member of an enterprise through one or more organizations. */
export interface EnterpriseUserAccount {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly createdAt: string;
    readonly enterprise: Enterprise;
    readonly enterpriseInstallations: ReadonlyArray<EnterpriseServerInstallation>;
    readonly id: string;
    readonly login: string;
    readonly name: string | null;
    readonly organizations: ReadonlyArray<Organization>;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly user: User | null;
}
/** An environment. */
export interface Environment {
    readonly databaseId: number | null;
    readonly id: string;
    readonly isPinned: boolean | null;
    readonly latestCompletedDeployment: Deployment | null;
    readonly name: string;
    readonly pinnedPosition: number | null;
    readonly protectionRules: ReadonlyArray<DeploymentProtectionRule>;
}
/** The connection type for Environment. */
export interface EnvironmentConnection {
    readonly edges: ReadonlyArray<EnvironmentEdge | null> | null;
    readonly nodes: ReadonlyArray<Environment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface EnvironmentEdge {
    readonly cursor: string;
    readonly node: Environment | null;
}
/** An external identity provisioned by SAML SSO or SCIM. If SAML is configured on
the organization, the external identity is visible to (1) organization owners,
(2) organization owners' personal access tokens (classic) with read:org or
admin:org scope, (3) GitHub App with an installation token with read or write
access to members. If SAML is configured on the enterprise, the external
identity is visible to (1) enterprise owners, (2) enterprise owners' personal
access tokens (classic) with read:enterprise or admin:enterprise scope. */
export interface ExternalIdentity {
    readonly guid: string;
    readonly id: string;
    readonly organizationInvitation: OrganizationInvitation | null;
    readonly samlIdentity: ExternalIdentitySamlAttributes | null;
    readonly scimIdentity: ExternalIdentityScimAttributes | null;
    readonly user: User | null;
}
/** An attribute for the External Identity attributes collection */
export interface ExternalIdentityAttribute {
    readonly metadata: string | null;
    readonly name: string;
    readonly value: string;
}
/** The connection type for ExternalIdentity. */
export interface ExternalIdentityConnection {
    readonly edges: ReadonlyArray<ExternalIdentityEdge | null> | null;
    readonly nodes: ReadonlyArray<ExternalIdentity | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ExternalIdentityEdge {
    readonly cursor: string;
    readonly node: ExternalIdentity | null;
}
/** SAML attributes for the External Identity */
export interface ExternalIdentitySamlAttributes {
    readonly attributes: ReadonlyArray<ExternalIdentityAttribute>;
    readonly emails: ReadonlyArray<UserEmailMetadata> | null;
    readonly familyName: string | null;
    readonly givenName: string | null;
    readonly groups: ReadonlyArray<string> | null;
    readonly nameId: string | null;
    readonly username: string | null;
}
/** SCIM attributes for the External Identity */
export interface ExternalIdentityScimAttributes {
    readonly emails: ReadonlyArray<UserEmailMetadata> | null;
    readonly familyName: string | null;
    readonly givenName: string | null;
    readonly groups: ReadonlyArray<string> | null;
    readonly username: string | null;
}
/** Prevent commits that include files with specified file extensions from being pushed to the commit graph. */
export interface FileExtensionRestrictionParameters {
    readonly restrictedFileExtensions: ReadonlyArray<string>;
}
/** Prevent commits that include changes in specified file and folder paths from
being pushed to the commit graph. This includes absolute paths that contain file names. */
export interface FilePathRestrictionParameters {
    readonly ignoredFilePaths: ReadonlyArray<string> | null;
    readonly restrictedFilePaths: ReadonlyArray<string>;
}
/** Autogenerated return type of FollowOrganization. */
export interface FollowOrganizationPayload {
    readonly clientMutationId: string | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of FollowUser. */
export interface FollowUserPayload {
    readonly clientMutationId: string | null;
    readonly user: User | null;
}
/** The connection type for User. */
export interface FollowerConnection {
    readonly edges: ReadonlyArray<UserEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** The connection type for User. */
export interface FollowingConnection {
    readonly edges: ReadonlyArray<UserEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** A funding platform link for a repository. */
export interface FundingLink {
    readonly platform: "BUY_ME_A_COFFEE" | "COMMUNITY_BRIDGE" | "CUSTOM" | "GITHUB" | "ISSUEHUNT" | "KO_FI" | "LFX_CROWDFUNDING" | "LIBERAPAY" | "OPEN_COLLECTIVE" | "PATREON" | "POLAR" | "THANKS_DEV" | "TIDELIFT";
    readonly url: string;
}
/** A generic hovercard context with a message and icon */
export interface GenericHovercardContext {
    readonly message: string;
    readonly octicon: string;
}
/** A Gist. */
export interface Gist {
    readonly comments: ReadonlyArray<GistComment>;
    readonly createdAt: string;
    readonly description: string | null;
    readonly files: ReadonlyArray<GistFile | null> | null;
    readonly forks: ReadonlyArray<Gist>;
    readonly id: string;
    readonly isFork: boolean;
    readonly isPublic: boolean;
    readonly name: string;
    readonly owner: RepositoryOwner | null;
    readonly pushedAt: string | null;
    readonly resourcePath: string;
    readonly stargazerCount: number;
    readonly stargazers: ReadonlyArray<User>;
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerHasStarred: boolean;
}
/** Represents a comment on an Gist. */
export interface GistComment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly editor: Actor | null;
    readonly gist: Gist;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isMinimized: boolean;
    readonly lastEditedAt: string | null;
    readonly minimizedReason: string | null;
    readonly publishedAt: string | null;
    readonly updatedAt: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerDidAuthor: boolean;
}
/** The connection type for GistComment. */
export interface GistCommentConnection {
    readonly edges: ReadonlyArray<GistCommentEdge | null> | null;
    readonly nodes: ReadonlyArray<GistComment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface GistCommentEdge {
    readonly cursor: string;
    readonly node: GistComment | null;
}
/** The connection type for Gist. */
export interface GistConnection {
    readonly edges: ReadonlyArray<GistEdge | null> | null;
    readonly nodes: ReadonlyArray<Gist | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface GistEdge {
    readonly cursor: string;
    readonly node: Gist | null;
}
/** A file in a gist. */
export interface GistFile {
    readonly encodedName: string | null;
    readonly encoding: string | null;
    readonly extension: string | null;
    readonly isImage: boolean;
    readonly isTruncated: boolean;
    readonly language: Language | null;
    readonly name: string | null;
    readonly size: number | null;
    readonly text: FieldWithArgs<string | null, {
        readonly truncate?: number | null | undefined;
    }, false>;
}
/** Represents an actor in a Git commit (ie. an author or committer). */
export interface GitActor {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly date: string | null;
    readonly email: string | null;
    readonly name: string | null;
    readonly user: User | null;
}
/** The connection type for GitActor. */
export interface GitActorConnection {
    readonly edges: ReadonlyArray<GitActorEdge | null> | null;
    readonly nodes: ReadonlyArray<GitActor | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface GitActorEdge {
    readonly cursor: string;
    readonly node: GitActor | null;
}
/** Represents information about the GitHub instance. */
export interface GitHubMetadata {
    readonly githubEnterpriseImporterIpAddresses: ReadonlyArray<string> | null;
    readonly gitHubServicesSha: string;
    readonly gitIpAddresses: ReadonlyArray<string> | null;
    readonly hookIpAddresses: ReadonlyArray<string> | null;
    readonly importerIpAddresses: ReadonlyArray<string> | null;
    readonly isPasswordAuthenticationVerifiable: boolean;
    readonly pagesIpAddresses: ReadonlyArray<string> | null;
}
/** Represents a Git object. */
export interface GitObject {
    readonly abbreviatedOid: string;
    readonly commitResourcePath: string;
    readonly commitUrl: string;
    readonly id: string;
    readonly oid: string;
    readonly repository: Repository;
}
/** Information about a signature (GPG or S/MIME) on a Commit or Tag. */
export interface GitSignature {
    readonly email: string;
    readonly isValid: boolean;
    readonly payload: string;
    readonly signature: string;
    readonly signer: User | null;
    readonly state: "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
    readonly verifiedAt: string | null;
    readonly wasSignedByGitHub: boolean;
}
/** Represents a GPG signature on a Commit or Tag. */
export interface GpgSignature {
    readonly email: string;
    readonly isValid: boolean;
    readonly keyId: string | null;
    readonly payload: string;
    readonly signature: string;
    readonly signer: User | null;
    readonly state: "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
    readonly verifiedAt: string | null;
    readonly wasSignedByGitHub: boolean;
}
/** Autogenerated return type of GrantEnterpriseOrganizationsMigratorRole. */
export interface GrantEnterpriseOrganizationsMigratorRolePayload {
    readonly clientMutationId: string | null;
    readonly organizations: ReadonlyArray<Organization> | null;
}
/** Autogenerated return type of GrantMigratorRole. */
export interface GrantMigratorRolePayload {
    readonly clientMutationId: string | null;
    readonly success: boolean | null;
}
/** Represents a 'head_ref_deleted' event on a given pull request. */
export interface HeadRefDeletedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly headRef: Ref | null;
    readonly headRefName: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
}
/** Represents a 'head_ref_force_pushed' event on a given pull request. */
export interface HeadRefForcePushedEvent {
    readonly actor: Actor | null;
    readonly afterCommit: Commit | null;
    readonly beforeCommit: Commit | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly ref: Ref | null;
}
/** Represents a 'head_ref_restored' event on a given pull request. */
export interface HeadRefRestoredEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
}
/** Detail needed to display a hovercard for a user */
export interface Hovercard {
    readonly contexts: ReadonlyArray<HovercardContext>;
}
/** An individual line of a hovercard */
export interface HovercardContext {
    readonly message: string;
    readonly octicon: string;
}
/** Autogenerated return type of ImportProject. */
export interface ImportProjectPayload {
    readonly clientMutationId: string | null;
    readonly project: Project | null;
}
/** Autogenerated return type of InviteEnterpriseAdmin. */
export interface InviteEnterpriseAdminPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseAdministratorInvitation | null;
}
/** Autogenerated return type of InviteEnterpriseMember. */
export interface InviteEnterpriseMemberPayload {
    readonly clientMutationId: string | null;
    readonly invitation: EnterpriseMemberInvitation | null;
}
/** An IP address or range of addresses that is allowed to access an owner's resources. */
export interface IpAllowListEntry {
    readonly allowListValue: string;
    readonly createdAt: string;
    readonly id: string;
    readonly isActive: boolean;
    readonly name: string | null;
    readonly owner: App | Enterprise | Organization;
    readonly updatedAt: string;
}
/** The connection type for IpAllowListEntry. */
export interface IpAllowListEntryConnection {
    readonly edges: ReadonlyArray<IpAllowListEntryEdge | null> | null;
    readonly nodes: ReadonlyArray<IpAllowListEntry | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IpAllowListEntryEdge {
    readonly cursor: string;
    readonly node: IpAllowListEntry | null;
}
/** An Issue is a place to discuss ideas, enhancements, tasks, and bugs for a project. */
export interface Issue {
    readonly activeLockReason: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null;
    readonly assignedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly assignees: ReadonlyArray<User>;
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly blockedBy: ReadonlyArray<Issue>;
    readonly blocking: ReadonlyArray<Issue>;
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyResourcePath: string;
    readonly bodyText: string;
    readonly bodyUrl: string;
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly closedByPullRequestsReferences: ReadonlyArray<PullRequest> | null;
    readonly comments: ReadonlyArray<IssueComment>;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly duplicateOf: Issue | null;
    readonly editor: Actor | null;
    readonly fullDatabaseId: string | null;
    readonly hovercard: FieldWithArgs<Hovercard, {
        readonly includeNotificationContexts?: boolean | null | undefined;
    }, false>;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isPinned: boolean | null;
    readonly isReadByViewer: boolean | null;
    readonly issueDependenciesSummary: IssueDependenciesSummary;
    readonly issueFieldValues: ReadonlyArray<IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue> | null;
    readonly issueType: IssueType | null;
    readonly labels: ReadonlyArray<Label> | null;
    readonly lastEditedAt: string | null;
    readonly linkedBranches: ReadonlyArray<LinkedBranch>;
    readonly locked: boolean;
    readonly milestone: Milestone | null;
    readonly number: number;
    readonly parent: Issue | null;
    readonly participants: ReadonlyArray<User>;
    readonly pendingSuggestions: ReadonlyArray<PendingAssigneeSuggestion | PendingCloseSuggestion | PendingFieldSuggestion | PendingLabelSuggestion | PendingTypeSuggestion> | null;
    readonly pinnedIssueComment: PinnedIssueComment | null;
    readonly projectCards: ReadonlyArray<ProjectCard>;
    readonly projectItems: ReadonlyArray<ProjectV2Item> | null;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly relatesTo: ReadonlyArray<Issue>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly state: "CLOSED" | "OPEN";
    readonly stateReason: FieldWithArgs<"COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | "REOPENED" | null, {
        readonly enableDuplicate?: boolean | null | undefined;
    }, false>;
    readonly subIssues: ReadonlyArray<Issue>;
    readonly subIssuesSummary: SubIssuesSummary;
    readonly suggestedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly timeline: ReadonlyArray<AssignedEvent | ClosedEvent | Commit | CrossReferencedEvent | DemilestonedEvent | IssueComment | LabeledEvent | LockedEvent | MilestonedEvent | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent>;
    readonly timelineItems: ReadonlyArray<AddedToProjectEvent | AddedToProjectV2Event | AssignedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DisconnectedEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | ReferencedEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RenamedTitleEvent | ReopenedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent>;
    readonly title: string;
    readonly titleHTML: string;
    readonly trackedInIssues: ReadonlyArray<Issue>;
    readonly trackedIssues: ReadonlyArray<Issue>;
    readonly trackedIssuesCount: FieldWithArgs<number, {
        readonly states?: ReadonlyArray<"CLOSED" | "OPEN" | null> | null | undefined;
    }, false>;
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanAssign: boolean;
    readonly viewerCanClose: boolean;
    readonly viewerCanDelete: boolean;
    readonly viewerCanLabel: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanReopen: boolean;
    readonly viewerCanSetFields: boolean | null;
    readonly viewerCanSetMilestone: boolean;
    readonly viewerCanSubscribe: boolean;
    readonly viewerCanType: boolean | null;
    readonly viewerCanUpdate: boolean;
    readonly viewerCanUpdateMetadata: boolean | null;
    readonly viewerDidAuthor: boolean;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
    readonly viewerThreadSubscriptionFormAction: "NONE" | "SUBSCRIBE" | "UNSUBSCRIBE" | null;
    readonly viewerThreadSubscriptionStatus: "DISABLED" | "IGNORING_LIST" | "IGNORING_THREAD" | "NONE" | "SUBSCRIBED_TO_LIST" | "SUBSCRIBED_TO_THREAD" | "SUBSCRIBED_TO_THREAD_EVENTS" | "SUBSCRIBED_TO_THREAD_TYPE" | "UNAVAILABLE" | null;
}
/** Represents a comment on an Issue. */
export interface IssueComment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly editor: Actor | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isMinimized: boolean;
    readonly isPinned: boolean | null;
    readonly issue: Issue;
    readonly lastEditedAt: string | null;
    readonly minimizedReason: string | null;
    readonly pinnedAt: string | null;
    readonly pinnedBy: User | null;
    readonly publishedAt: string | null;
    readonly pullRequest: PullRequest | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanPin: boolean;
    readonly viewerCanReact: boolean;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUnpin: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerDidAuthor: boolean;
}
/** The connection type for IssueComment. */
export interface IssueCommentConnection {
    readonly edges: ReadonlyArray<IssueCommentEdge | null> | null;
    readonly nodes: ReadonlyArray<IssueComment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IssueCommentEdge {
    readonly cursor: string;
    readonly node: IssueComment | null;
}
/** Represents a 'issue_comment_pinned' event on a given issue. */
export interface IssueCommentPinnedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issueComment: IssueComment | null;
}
/** Represents a 'issue_comment_unpinned' event on a given issue. */
export interface IssueCommentUnpinnedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issueComment: IssueComment | null;
}
/** The connection type for Issue. */
export interface IssueConnection {
    readonly edges: ReadonlyArray<IssueEdge | null> | null;
    readonly nodes: ReadonlyArray<Issue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** This aggregates issues opened by a user within one repository. */
export interface IssueContributionsByRepository {
    readonly contributions: ReadonlyArray<CreatedIssueContribution>;
    readonly repository: Repository;
}
/** Summary of the state of an issue's dependencies */
export interface IssueDependenciesSummary {
    readonly blockedBy: number;
    readonly blocking: number;
    readonly totalBlockedBy: number;
    readonly totalBlocking: number;
}
/** An edge in a connection. */
export interface IssueEdge {
    readonly cursor: string;
    readonly node: Issue | null;
}
/** Represents a 'issue_field_added' event on a given issue. */
export interface IssueFieldAddedEvent {
    readonly actor: Actor | null;
    readonly color: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly options: ReadonlyArray<IssueFieldTimelineOption> | null;
    readonly value: string | null;
}
/** Represents a 'issue_field_changed' event on a given issue. */
export interface IssueFieldChangedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly newColor: string | null;
    readonly newOptions: ReadonlyArray<IssueFieldTimelineOption> | null;
    readonly newValue: string | null;
    readonly previousColor: string | null;
    readonly previousOptions: ReadonlyArray<IssueFieldTimelineOption> | null;
    readonly previousValue: string | null;
}
/** Common fields across different issue field types */
export interface IssueFieldCommon {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly name: string;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** Represents a date issue field. */
export interface IssueFieldDate {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** The value of a date field in an Issue item. */
export interface IssueFieldDateValue {
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly id: string;
    readonly value: string;
}
/** Represents a multi select issue field. */
export interface IssueFieldMultiSelect {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly options: ReadonlyArray<IssueFieldSingleSelectOption>;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** The value of a multi select field in an Issue item. */
export interface IssueFieldMultiSelectValue {
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly id: string;
    readonly options: ReadonlyArray<IssueFieldSingleSelectOption>;
    readonly value: string | null;
}
/** Represents a number issue field. */
export interface IssueFieldNumber {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** The value of a number field in an Issue item. */
export interface IssueFieldNumberValue {
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly id: string;
    readonly value: number;
}
/** Represents a 'issue_field_removed' event on a given issue. */
export interface IssueFieldRemovedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly options: ReadonlyArray<IssueFieldTimelineOption> | null;
}
/** Represents a single select issue field. */
export interface IssueFieldSingleSelect {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly options: ReadonlyArray<IssueFieldSingleSelectOption>;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** Represents an option in a single-select issue field. */
export interface IssueFieldSingleSelectOption {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly priority: number | null;
}
/** The value of a single select field in an Issue item. */
export interface IssueFieldSingleSelectValue {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string | null;
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly id: string;
    readonly name: string;
    readonly optionId: string | null;
    readonly value: string;
}
/** Represents a text issue field. */
export interface IssueFieldText {
    readonly createdAt: string;
    readonly dataType: "DATE" | "MULTI_SELECT" | "NUMBER" | "SINGLE_SELECT" | "TEXT";
    readonly description: string | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly visibility: "ALL" | "ORG_ONLY";
}
/** The value of a text field in an Issue item. */
export interface IssueFieldTextValue {
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly id: string;
    readonly value: string;
}
/** Represents a selected option for a timeline issue field event. */
export interface IssueFieldTimelineOption {
    readonly color: string | null;
    readonly name: string;
}
/** Common fields across different issue field value types */
export interface IssueFieldValueCommon {
    readonly field: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
}
/** The connection type for IssueFieldValue. */
export interface IssueFieldValueConnection {
    readonly edges: ReadonlyArray<IssueFieldValueEdge | null> | null;
    readonly nodes: ReadonlyArray<IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IssueFieldValueEdge {
    readonly cursor: string;
    readonly node: IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue | null;
}
/** The connection type for IssueFields. */
export interface IssueFieldsConnection {
    readonly edges: ReadonlyArray<IssueFieldsEdge | null> | null;
    readonly nodes: ReadonlyArray<IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IssueFieldsEdge {
    readonly cursor: string;
    readonly node: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
}
/** A repository issue template. */
export interface IssueTemplate {
    readonly about: string | null;
    readonly assignees: ReadonlyArray<User>;
    readonly body: string | null;
    readonly filename: string;
    readonly labels: ReadonlyArray<Label> | null;
    readonly name: string;
    readonly title: string | null;
    readonly type: IssueType | null;
}
/** The connection type for IssueTimelineItem. */
export interface IssueTimelineConnection {
    readonly edges: ReadonlyArray<IssueTimelineItemEdge | null> | null;
    readonly nodes: ReadonlyArray<AssignedEvent | ClosedEvent | Commit | CrossReferencedEvent | DemilestonedEvent | IssueComment | LabeledEvent | LockedEvent | MilestonedEvent | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IssueTimelineItemEdge {
    readonly cursor: string;
    readonly node: AssignedEvent | ClosedEvent | Commit | CrossReferencedEvent | DemilestonedEvent | IssueComment | LabeledEvent | LockedEvent | MilestonedEvent | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent | null;
}
/** The connection type for IssueTimelineItems. */
export interface IssueTimelineItemsConnection {
    readonly edges: ReadonlyArray<IssueTimelineItemsEdge | null> | null;
    readonly filteredCount: number;
    readonly nodes: ReadonlyArray<AddedToProjectEvent | AddedToProjectV2Event | AssignedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DisconnectedEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | ReferencedEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RenamedTitleEvent | ReopenedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent | null> | null;
    readonly pageCount: number;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly updatedAt: string;
}
/** An edge in a connection. */
export interface IssueTimelineItemsEdge {
    readonly cursor: string;
    readonly node: AddedToProjectEvent | AddedToProjectV2Event | AssignedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DisconnectedEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | ReferencedEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RenamedTitleEvent | ReopenedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent | null;
}
/** Represents the type of Issue. */
export interface IssueType {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string | null;
    readonly id: string;
    readonly isEnabled: boolean;
    readonly isPrivate: boolean;
    readonly issues: ReadonlyArray<Issue>;
    readonly name: string;
    readonly pinnedFields: ReadonlyArray<IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText> | null;
}
/** Represents a 'issue_type_added' event on a given issue. */
export interface IssueTypeAddedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueType: IssueType | null;
}
/** Represents a 'issue_type_changed' event on a given issue. */
export interface IssueTypeChangedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueType: IssueType | null;
    readonly prevIssueType: IssueType | null;
}
/** The connection type for IssueType. */
export interface IssueTypeConnection {
    readonly edges: ReadonlyArray<IssueTypeEdge | null> | null;
    readonly nodes: ReadonlyArray<IssueType | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface IssueTypeEdge {
    readonly cursor: string;
    readonly node: IssueType | null;
}
/** Represents a 'issue_type_removed' event on a given issue. */
export interface IssueTypeRemovedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly issueType: IssueType | null;
}
/** The intent behind an agent's issue event action, including rationale and confidence. */
export interface IssueUpdateIntent {
    readonly confidence: "HIGH" | "LOW" | "MEDIUM" | null;
    readonly databaseId: number | null;
    readonly intentId: string | null;
    readonly rationale: string | null;
}
/** Represents a user signing up for a GitHub account. */
export interface JoinedGitHubContribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** A label for categorizing Issues, Pull Requests, Milestones, or Discussions with a given Repository. */
export interface Label {
    readonly color: string;
    readonly createdAt: string | null;
    readonly description: string | null;
    readonly id: string;
    readonly isDefault: boolean;
    readonly issues: ReadonlyArray<Issue>;
    readonly name: string;
    readonly pullRequests: ReadonlyArray<PullRequest>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly updatedAt: string | null;
    readonly url: string;
}
/** The connection type for Label. */
export interface LabelConnection {
    readonly edges: ReadonlyArray<LabelEdge | null> | null;
    readonly nodes: ReadonlyArray<Label | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface LabelEdge {
    readonly cursor: string;
    readonly node: Label | null;
}
/** An object that can have labels assigned to it. */
export interface Labelable {
    readonly labels: ReadonlyArray<Label> | null;
    readonly viewerCanLabel: boolean;
}
/** Represents a 'labeled' event on a given issue or pull request. */
export interface LabeledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly label: Label;
    readonly labelable: Labelable;
}
/** Represents a given language found in repositories. */
export interface Language {
    readonly color: string | null;
    readonly id: string;
    readonly name: string;
}
/** A list of languages associated with the parent. */
export interface LanguageConnection {
    readonly edges: ReadonlyArray<LanguageEdge | null> | null;
    readonly nodes: ReadonlyArray<Language | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly totalSize: number;
}
/** Represents the language of a repository. */
export interface LanguageEdge {
    readonly cursor: string;
    readonly node: Language;
    readonly size: number;
}
/** A repository's open source license */
export interface License {
    readonly body: string;
    readonly conditions: ReadonlyArray<LicenseRule | null>;
    readonly description: string | null;
    readonly featured: boolean;
    readonly hidden: boolean;
    readonly id: string;
    readonly implementation: string | null;
    readonly key: string;
    readonly limitations: ReadonlyArray<LicenseRule | null>;
    readonly name: string;
    readonly nickname: string | null;
    readonly permissions: ReadonlyArray<LicenseRule | null>;
    readonly pseudoLicense: boolean;
    readonly spdxId: string | null;
    readonly url: string | null;
}
/** Describes a License's conditions, permissions, and limitations */
export interface LicenseRule {
    readonly description: string;
    readonly key: string;
    readonly label: string;
}
/** Autogenerated return type of LinkProjectV2ToRepository. */
export interface LinkProjectV2ToRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of LinkProjectV2ToTeam. */
export interface LinkProjectV2ToTeamPayload {
    readonly clientMutationId: string | null;
    readonly team: Team | null;
}
/** Autogenerated return type of LinkRepositoryToProject. */
export interface LinkRepositoryToProjectPayload {
    readonly clientMutationId: string | null;
    readonly project: Project | null;
    readonly repository: Repository | null;
}
/** A branch linked to an issue. */
export interface LinkedBranch {
    readonly id: string;
    readonly ref: Ref | null;
}
/** A list of branches linked to an issue. */
export interface LinkedBranchConnection {
    readonly edges: ReadonlyArray<LinkedBranchEdge | null> | null;
    readonly nodes: ReadonlyArray<LinkedBranch | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface LinkedBranchEdge {
    readonly cursor: string;
    readonly node: LinkedBranch | null;
}
/** Autogenerated return type of LockLockable. */
export interface LockLockablePayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly lockedRecord: Lockable | null;
}
/** An object that can be locked. */
export interface Lockable {
    readonly activeLockReason: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null;
    readonly locked: boolean;
}
/** Represents a 'locked' event on a given issue or pull request. */
export interface LockedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly lockable: Lockable;
    readonly lockReason: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null;
}
/** A placeholder user for attribution of imported data on GitHub. */
export interface Mannequin {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly claimant: User | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly email: string | null;
    readonly id: string;
    readonly login: string;
    readonly name: string | null;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
}
/** A list of mannequins. */
export interface MannequinConnection {
    readonly edges: ReadonlyArray<MannequinEdge | null> | null;
    readonly nodes: ReadonlyArray<Mannequin | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a mannequin. */
export interface MannequinEdge {
    readonly cursor: string;
    readonly node: Mannequin | null;
}
/** Autogenerated return type of MarkDiscussionCommentAsAnswer. */
export interface MarkDiscussionCommentAsAnswerPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of MarkFileAsViewed. */
export interface MarkFileAsViewedPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of MarkProjectV2AsTemplate. */
export interface MarkProjectV2AsTemplatePayload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of MarkPullRequestReadyForReview. */
export interface MarkPullRequestReadyForReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'marked_as_duplicate' event on a given issue or pull request. */
export interface MarkedAsDuplicateEvent {
    readonly actor: Actor | null;
    readonly canonical: Issue | PullRequest | null;
    readonly createdAt: string;
    readonly duplicate: Issue | PullRequest | null;
    readonly id: string;
    readonly isCrossRepository: boolean;
}
/** A public description of a Marketplace category. */
export interface MarketplaceCategory {
    readonly description: string | null;
    readonly howItWorks: string | null;
    readonly id: string;
    readonly name: string;
    readonly primaryListingCount: number;
    readonly resourcePath: string;
    readonly secondaryListingCount: number;
    readonly slug: string;
    readonly url: string;
}
/** A listing in the GitHub integration marketplace. */
export interface MarketplaceListing {
    readonly app: App | null;
    readonly companyUrl: string | null;
    readonly configurationResourcePath: string;
    readonly configurationUrl: string;
    readonly documentationUrl: string | null;
    readonly extendedDescription: string | null;
    readonly extendedDescriptionHTML: string;
    readonly fullDescription: string;
    readonly fullDescriptionHTML: string;
    readonly hasPublishedFreeTrialPlans: boolean;
    readonly hasTermsOfService: boolean;
    readonly hasVerifiedOwner: boolean;
    readonly howItWorks: string | null;
    readonly howItWorksHTML: string;
    readonly id: string;
    readonly installationUrl: string | null;
    readonly installedForViewer: boolean;
    readonly isArchived: boolean;
    readonly isDraft: boolean;
    readonly isPaid: boolean;
    readonly isPublic: boolean;
    readonly isRejected: boolean;
    readonly isUnverified: boolean;
    readonly isUnverifiedPending: boolean;
    readonly isVerificationPendingFromDraft: boolean;
    readonly isVerificationPendingFromUnverified: boolean;
    readonly isVerified: boolean;
    readonly logoBackgroundColor: string;
    readonly logoUrl: FieldWithArgs<string | null, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly name: string;
    readonly normalizedShortDescription: string;
    readonly pricingUrl: string | null;
    readonly primaryCategory: MarketplaceCategory;
    readonly privacyPolicyUrl: string;
    readonly resourcePath: string;
    readonly screenshotUrls: ReadonlyArray<string | null>;
    readonly secondaryCategory: MarketplaceCategory | null;
    readonly shortDescription: string;
    readonly slug: string;
    readonly statusUrl: string | null;
    readonly supportEmail: string | null;
    readonly supportUrl: string;
    readonly termsOfServiceUrl: string | null;
    readonly url: string;
    readonly viewerCanAddPlans: boolean;
    readonly viewerCanApprove: boolean;
    readonly viewerCanDelist: boolean;
    readonly viewerCanEdit: boolean;
    readonly viewerCanEditCategories: boolean;
    readonly viewerCanEditPlans: boolean;
    readonly viewerCanRedraft: boolean;
    readonly viewerCanReject: boolean;
    readonly viewerCanRequestApproval: boolean;
    readonly viewerHasPurchased: boolean;
    readonly viewerHasPurchasedForAllOrganizations: boolean;
    readonly viewerIsListingAdmin: boolean;
}
/** Look up Marketplace Listings */
export interface MarketplaceListingConnection {
    readonly edges: ReadonlyArray<MarketplaceListingEdge | null> | null;
    readonly nodes: ReadonlyArray<MarketplaceListing | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface MarketplaceListingEdge {
    readonly cursor: string;
    readonly node: MarketplaceListing | null;
}
/** Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph. */
export interface MaxFilePathLengthParameters {
    readonly maxFilePathLength: number;
}
/** Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph. */
export interface MaxFileSizeParameters {
    readonly ignoredFilePaths: ReadonlyArray<string> | null;
    readonly maxFileSize: number;
}
/** Represents a member feature request notification */
export interface MemberFeatureRequestNotification {
    readonly body: string;
    readonly id: string;
    readonly title: string;
    readonly updatedAt: string;
}
/** Entities that have members who can set status messages. */
export interface MemberStatusable {
    readonly memberStatuses: ReadonlyArray<UserStatus>;
}
/** Audit log entry for a members_can_delete_repos.clear event. */
export interface MembersCanDeleteReposClearAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a members_can_delete_repos.disable event. */
export interface MembersCanDeleteReposDisableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a members_can_delete_repos.enable event. */
export interface MembersCanDeleteReposEnableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Represents a 'mentioned' event on a given issue or pull request. */
export interface MentionedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
}
/** Autogenerated return type of MergeBranch. */
export interface MergeBranchPayload {
    readonly clientMutationId: string | null;
    readonly mergeCommit: Commit | null;
}
/** Autogenerated return type of MergePullRequest. */
export interface MergePullRequestPayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** The queue of pull request entries to be merged into a protected branch in a repository. */
export interface MergeQueue {
    readonly configuration: MergeQueueConfiguration | null;
    readonly entries: ReadonlyArray<MergeQueueEntry> | null;
    readonly id: string;
    readonly nextEntryEstimatedTimeToMerge: number | null;
    readonly repository: Repository | null;
    readonly resourcePath: string;
    readonly url: string;
}
/** Configuration for a MergeQueue */
export interface MergeQueueConfiguration {
    readonly checkResponseTimeout: number | null;
    readonly maximumEntriesToBuild: number | null;
    readonly maximumEntriesToMerge: number | null;
    readonly mergeMethod: "MERGE" | "REBASE" | "SQUASH" | null;
    readonly mergingStrategy: "ALLGREEN" | "HEADGREEN" | null;
    readonly minimumEntriesToMerge: number | null;
    readonly minimumEntriesToMergeWaitTime: number | null;
}
/** Entries in a MergeQueue */
export interface MergeQueueEntry {
    readonly baseCommit: Commit | null;
    readonly enqueuedAt: string;
    readonly enqueuer: Actor;
    readonly estimatedTimeToMerge: number | null;
    readonly headCommit: Commit | null;
    readonly id: string;
    readonly jump: boolean;
    readonly mergeQueue: MergeQueue | null;
    readonly position: number;
    readonly pullRequest: PullRequest | null;
    readonly solo: boolean;
    readonly state: "AWAITING_CHECKS" | "LOCKED" | "MERGEABLE" | "QUEUED" | "UNMERGEABLE";
}
/** The connection type for MergeQueueEntry. */
export interface MergeQueueEntryConnection {
    readonly edges: ReadonlyArray<MergeQueueEntryEdge | null> | null;
    readonly nodes: ReadonlyArray<MergeQueueEntry | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface MergeQueueEntryEdge {
    readonly cursor: string;
    readonly node: MergeQueueEntry | null;
}
/** Merges must be performed via a merge queue. */
export interface MergeQueueParameters {
    readonly checkResponseTimeoutMinutes: number;
    readonly groupingStrategy: "ALLGREEN" | "HEADGREEN";
    readonly maxEntriesToBuild: number;
    readonly maxEntriesToMerge: number;
    readonly mergeMethod: "MERGE" | "REBASE" | "SQUASH";
    readonly minEntriesToMerge: number;
    readonly minEntriesToMergeWaitMinutes: number;
}
/** Represents a 'merged' event on a given pull request. */
export interface MergedEvent {
    readonly actor: Actor | null;
    readonly commit: Commit | null;
    readonly createdAt: string;
    readonly id: string;
    readonly mergeRef: Ref | null;
    readonly mergeRefName: string;
    readonly pullRequest: PullRequest;
    readonly resourcePath: string;
    readonly url: string;
}
/** Represents a GitHub Enterprise Importer (GEI) migration. */
export interface Migration {
    readonly continueOnError: boolean;
    readonly createdAt: string;
    readonly databaseId: string | null;
    readonly failureReason: string | null;
    readonly id: string;
    readonly migrationLogUrl: string | null;
    readonly migrationSource: MigrationSource;
    readonly repositoryName: string;
    readonly sourceUrl: string;
    readonly state: "FAILED" | "FAILED_VALIDATION" | "IN_PROGRESS" | "NOT_STARTED" | "PENDING_VALIDATION" | "QUEUED" | "SUCCEEDED";
    readonly warningsCount: number;
}
/** A GitHub Enterprise Importer (GEI) migration source. */
export interface MigrationSource {
    readonly id: string;
    readonly name: string;
    readonly type: "AZURE_DEVOPS" | "BITBUCKET_SERVER" | "GITHUB_ARCHIVE" | "GITLAB";
    readonly url: string;
}
/** Represents a Milestone object on a given repository. */
export interface Milestone {
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly closedIssueCount: number;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly description: string | null;
    readonly descriptionHTML: string | null;
    readonly dueOn: string | null;
    readonly id: string;
    readonly issues: ReadonlyArray<Issue>;
    readonly number: number;
    readonly openIssueCount: number;
    readonly progressPercentage: number;
    readonly pullRequests: ReadonlyArray<PullRequest>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly state: "CLOSED" | "OPEN";
    readonly title: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerCanClose: boolean;
    readonly viewerCanReopen: boolean;
}
/** The connection type for Milestone. */
export interface MilestoneConnection {
    readonly edges: ReadonlyArray<MilestoneEdge | null> | null;
    readonly nodes: ReadonlyArray<Milestone | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface MilestoneEdge {
    readonly cursor: string;
    readonly node: Milestone | null;
}
/** Represents a 'milestoned' event on a given issue or pull request. */
export interface MilestonedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly milestoneTitle: string;
    readonly subject: Issue | PullRequest;
}
/** Entities that can be minimized. */
export interface Minimizable {
    readonly isMinimized: boolean;
    readonly minimizedReason: string | null;
    readonly viewerCanMinimize: boolean;
    readonly viewerCanUnminimize: boolean;
}
/** Autogenerated return type of MinimizeComment. */
export interface MinimizeCommentPayload {
    readonly clientMutationId: string | null;
    readonly minimizedComment: Minimizable | null;
}
/** Autogenerated return type of MoveProjectCard. */
export interface MoveProjectCardPayload {
    readonly cardEdge: ProjectCardEdge | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of MoveProjectColumn. */
export interface MoveProjectColumnPayload {
    readonly clientMutationId: string | null;
    readonly columnEdge: ProjectColumnEdge | null;
}
/** Represents a 'moved_columns_in_project' event on a given issue or pull request. */
export interface MovedColumnsInProjectEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly previousProjectColumnName: string;
    readonly project: Project | null;
    readonly projectCard: ProjectCard | null;
    readonly projectColumnName: string;
}
/** An object with an ID. */
export interface Node {
    readonly id: string;
}
/** An OIDC identity provider configured to provision identities for an enterprise.
Visible to enterprise owners or enterprise owners' personal access tokens
(classic) with read:enterprise or admin:enterprise scope. */
export interface OIDCProvider {
    readonly enterprise: Enterprise | null;
    readonly externalIdentities: ReadonlyArray<ExternalIdentity>;
    readonly id: string;
    readonly providerType: "AAD";
    readonly tenantId: string;
}
/** Metadata for an audit entry with action oauth_application.* */
export interface OauthApplicationAuditEntryData {
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
}
/** Audit log entry for a oauth_application.create event. */
export interface OauthApplicationCreateAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly applicationUrl: string | null;
    readonly callbackUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly rateLimit: number | null;
    readonly state: "ACTIVE" | "PENDING_DELETION" | "SUSPENDED" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.add_billing_manager */
export interface OrgAddBillingManagerAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly invitationEmail: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.add_member */
export interface OrgAddMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly permission: "ADMIN" | "READ" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.block_user */
export interface OrgBlockUserAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly blockedUser: User | null;
    readonly blockedUserName: string | null;
    readonly blockedUserResourcePath: string | null;
    readonly blockedUserUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.config.disable_collaborators_only event. */
export interface OrgConfigDisableCollaboratorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.config.enable_collaborators_only event. */
export interface OrgConfigEnableCollaboratorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.create event. */
export interface OrgCreateAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly billingPlan: "BUSINESS" | "BUSINESS_PLUS" | "FREE" | "TIERED_PER_SEAT" | "UNLIMITED" | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.disable_oauth_app_restrictions event. */
export interface OrgDisableOauthAppRestrictionsAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.disable_saml event. */
export interface OrgDisableSamlAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly digestMethodUrl: string | null;
    readonly id: string;
    readonly issuerUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly signatureMethodUrl: string | null;
    readonly singleSignOnUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.disable_two_factor_requirement event. */
export interface OrgDisableTwoFactorRequirementAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.enable_oauth_app_restrictions event. */
export interface OrgEnableOauthAppRestrictionsAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.enable_saml event. */
export interface OrgEnableSamlAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly digestMethodUrl: string | null;
    readonly id: string;
    readonly issuerUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly signatureMethodUrl: string | null;
    readonly singleSignOnUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.enable_two_factor_requirement event. */
export interface OrgEnableTwoFactorRequirementAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.invite_member event. */
export interface OrgInviteMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly email: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationInvitation: OrganizationInvitation | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.invite_to_business event. */
export interface OrgInviteToBusinessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.oauth_app_access_approved event. */
export interface OrgOauthAppAccessApprovedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.oauth_app_access_blocked event. */
export interface OrgOauthAppAccessBlockedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.oauth_app_access_denied event. */
export interface OrgOauthAppAccessDeniedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.oauth_app_access_requested event. */
export interface OrgOauthAppAccessRequestedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.oauth_app_access_unblocked event. */
export interface OrgOauthAppAccessUnblockedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly oauthApplicationName: string | null;
    readonly oauthApplicationResourcePath: string | null;
    readonly oauthApplicationUrl: string | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.remove_billing_manager event. */
export interface OrgRemoveBillingManagerAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly reason: "SAML_EXTERNAL_IDENTITY_MISSING" | "SAML_SSO_ENFORCEMENT_REQUIRES_EXTERNAL_IDENTITY" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.remove_member event. */
export interface OrgRemoveMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly membershipTypes: ReadonlyArray<"ADMIN" | "BILLING_MANAGER" | "DIRECT_MEMBER" | "OUTSIDE_COLLABORATOR" | "SUSPENDED" | "UNAFFILIATED"> | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly reason: "SAML_EXTERNAL_IDENTITY_MISSING" | "SAML_SSO_ENFORCEMENT_REQUIRES_EXTERNAL_IDENTITY" | "TWO_FACTOR_ACCOUNT_RECOVERY" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE" | "USER_ACCOUNT_DELETED" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.remove_outside_collaborator event. */
export interface OrgRemoveOutsideCollaboratorAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly membershipTypes: ReadonlyArray<"BILLING_MANAGER" | "OUTSIDE_COLLABORATOR" | "UNAFFILIATED"> | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly reason: "SAML_EXTERNAL_IDENTITY_MISSING" | "TWO_FACTOR_REQUIREMENT_NON_COMPLIANCE" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.restore_member event. */
export interface OrgRestoreMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly restoredCustomEmailRoutingsCount: number | null;
    readonly restoredIssueAssignmentsCount: number | null;
    readonly restoredMemberships: ReadonlyArray<OrgRestoreMemberMembershipOrganizationAuditEntryData | OrgRestoreMemberMembershipRepositoryAuditEntryData | OrgRestoreMemberMembershipTeamAuditEntryData> | null;
    readonly restoredMembershipsCount: number | null;
    readonly restoredRepositoriesCount: number | null;
    readonly restoredRepositoryStarsCount: number | null;
    readonly restoredRepositoryWatchesCount: number | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Metadata for an organization membership for org.restore_member actions */
export interface OrgRestoreMemberMembershipOrganizationAuditEntryData {
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
}
/** Metadata for a repository membership for org.restore_member actions */
export interface OrgRestoreMemberMembershipRepositoryAuditEntryData {
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
}
/** Metadata for a team membership for org.restore_member actions */
export interface OrgRestoreMemberMembershipTeamAuditEntryData {
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
}
/** Audit log entry for a org.unblock_user */
export interface OrgUnblockUserAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly blockedUser: User | null;
    readonly blockedUserName: string | null;
    readonly blockedUserResourcePath: string | null;
    readonly blockedUserUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.update_default_repository_permission */
export interface OrgUpdateDefaultRepositoryPermissionAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly permission: "ADMIN" | "NONE" | "READ" | "WRITE" | null;
    readonly permissionWas: "ADMIN" | "NONE" | "READ" | "WRITE" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.update_member event. */
export interface OrgUpdateMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly permission: "ADMIN" | "READ" | null;
    readonly permissionWas: "ADMIN" | "READ" | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a org.update_member_repository_creation_permission event. */
export interface OrgUpdateMemberRepositoryCreationPermissionAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly canCreateRepositories: boolean | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "ALL" | "INTERNAL" | "NONE" | "PRIVATE" | "PRIVATE_INTERNAL" | "PUBLIC" | "PUBLIC_INTERNAL" | "PUBLIC_PRIVATE" | null;
}
/** Audit log entry for a org.update_member_repository_invitation_permission event. */
export interface OrgUpdateMemberRepositoryInvitationPermissionAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly canInviteOutsideCollaboratorsToRepositories: boolean | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** An account on GitHub, with one or more owners, that has repositories, members and teams. */
export interface Organization {
    readonly announcementBanner: AnnouncementBanner | null;
    readonly anyPinnableItems: FieldWithArgs<boolean, {
        readonly type?: "GIST" | "ISSUE" | "ORGANIZATION" | "PROJECT" | "PULL_REQUEST" | "REPOSITORY" | "TEAM" | "USER" | null | undefined;
    }, false>;
    readonly archivedAt: string | null;
    readonly auditLog: ReadonlyArray<MembersCanDeleteReposClearAuditEntry | MembersCanDeleteReposDisableAuditEntry | MembersCanDeleteReposEnableAuditEntry | OauthApplicationCreateAuditEntry | OrgAddBillingManagerAuditEntry | OrgAddMemberAuditEntry | OrgBlockUserAuditEntry | OrgConfigDisableCollaboratorsOnlyAuditEntry | OrgConfigEnableCollaboratorsOnlyAuditEntry | OrgCreateAuditEntry | OrgDisableOauthAppRestrictionsAuditEntry | OrgDisableSamlAuditEntry | OrgDisableTwoFactorRequirementAuditEntry | OrgEnableOauthAppRestrictionsAuditEntry | OrgEnableSamlAuditEntry | OrgEnableTwoFactorRequirementAuditEntry | OrgInviteMemberAuditEntry | OrgInviteToBusinessAuditEntry | OrgOauthAppAccessApprovedAuditEntry | OrgOauthAppAccessBlockedAuditEntry | OrgOauthAppAccessDeniedAuditEntry | OrgOauthAppAccessRequestedAuditEntry | OrgOauthAppAccessUnblockedAuditEntry | OrgRemoveBillingManagerAuditEntry | OrgRemoveMemberAuditEntry | OrgRemoveOutsideCollaboratorAuditEntry | OrgRestoreMemberAuditEntry | OrgUnblockUserAuditEntry | OrgUpdateDefaultRepositoryPermissionAuditEntry | OrgUpdateMemberAuditEntry | OrgUpdateMemberRepositoryCreationPermissionAuditEntry | OrgUpdateMemberRepositoryInvitationPermissionAuditEntry | PrivateRepositoryForkingDisableAuditEntry | PrivateRepositoryForkingEnableAuditEntry | RepoAccessAuditEntry | RepoAddMemberAuditEntry | RepoAddTopicAuditEntry | RepoArchivedAuditEntry | RepoChangeMergeSettingAuditEntry | RepoConfigDisableAnonymousGitAccessAuditEntry | RepoConfigDisableCollaboratorsOnlyAuditEntry | RepoConfigDisableContributorsOnlyAuditEntry | RepoConfigDisableSockpuppetDisallowedAuditEntry | RepoConfigEnableAnonymousGitAccessAuditEntry | RepoConfigEnableCollaboratorsOnlyAuditEntry | RepoConfigEnableContributorsOnlyAuditEntry | RepoConfigEnableSockpuppetDisallowedAuditEntry | RepoConfigLockAnonymousGitAccessAuditEntry | RepoConfigUnlockAnonymousGitAccessAuditEntry | RepoCreateAuditEntry | RepoDestroyAuditEntry | RepoRemoveMemberAuditEntry | RepoRemoveTopicAuditEntry | RepositoryVisibilityChangeDisableAuditEntry | RepositoryVisibilityChangeEnableAuditEntry | TeamAddMemberAuditEntry | TeamAddRepositoryAuditEntry | TeamChangeParentTeamAuditEntry | TeamRemoveMemberAuditEntry | TeamRemoveRepositoryAuditEntry>;
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly descriptionHTML: string | null;
    readonly domains: ReadonlyArray<VerifiableDomain> | null;
    readonly email: string | null;
    readonly enterpriseOwners: ReadonlyArray<User>;
    readonly estimatedNextSponsorsPayoutInCents: number;
    readonly hasSponsorsListing: boolean;
    readonly id: string;
    readonly innersourceVulnerabilities: ReadonlyArray<SecurityVulnerability>;
    readonly interactionAbility: RepositoryInteractionAbility | null;
    readonly ipAllowListEnabledSetting: "DISABLED" | "ENABLED";
    readonly ipAllowListEntries: ReadonlyArray<IpAllowListEntry>;
    readonly ipAllowListForInstalledAppsEnabledSetting: "DISABLED" | "ENABLED";
    readonly isSponsoredBy: FieldWithArgs<boolean, {
        readonly accountLogin: string;
    }>;
    readonly isSponsoringViewer: boolean;
    readonly issueFields: ReadonlyArray<IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText> | null;
    readonly issueTypes: ReadonlyArray<IssueType> | null;
    readonly isVerified: boolean;
    readonly itemShowcase: ProfileItemShowcase;
    readonly lifetimeReceivedSponsorshipValues: ReadonlyArray<SponsorAndLifetimeValue>;
    readonly location: string | null;
    readonly login: string;
    readonly mannequins: ReadonlyArray<Mannequin>;
    readonly membersCanForkPrivateRepositories: boolean;
    readonly memberStatuses: ReadonlyArray<UserStatus>;
    readonly membersWithRole: ReadonlyArray<User>;
    readonly monthlyEstimatedSponsorsIncomeInCents: number;
    readonly name: string | null;
    readonly newTeamResourcePath: string;
    readonly newTeamUrl: string;
    readonly notificationDeliveryRestrictionEnabledSetting: "DISABLED" | "ENABLED";
    readonly organizationBillingEmail: string | null;
    readonly packages: ReadonlyArray<Package>;
    readonly pendingMembers: ReadonlyArray<User>;
    readonly pinnableItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedIssueFields: ReadonlyArray<IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText> | null;
    readonly pinnedItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedItemsRemaining: number;
    readonly project: FieldWithArgs<Project | null, {
        readonly number: number;
    }>;
    readonly projects: ReadonlyArray<Project>;
    readonly projectsResourcePath: string;
    readonly projectsUrl: string;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly recentProjects: ReadonlyArray<ProjectV2>;
    readonly repositories: ReadonlyArray<Repository>;
    readonly repository: FieldWithArgs<Repository | null, {
        readonly name: string;
        readonly followRenames?: boolean | null | undefined;
    }>;
    readonly repositoryCustomProperties: ReadonlyArray<RepositoryCustomProperty> | null;
    readonly repositoryCustomProperty: FieldWithArgs<RepositoryCustomProperty | null, {
        readonly propertyName: string;
    }>;
    readonly repositoryDiscussionComments: ReadonlyArray<DiscussionComment>;
    readonly repositoryDiscussions: ReadonlyArray<Discussion>;
    readonly repositoryMigrations: ReadonlyArray<RepositoryMigration>;
    readonly requiresTwoFactorAuthentication: boolean | null;
    readonly resourcePath: string;
    readonly ruleset: FieldWithArgs<RepositoryRuleset | null, {
        readonly databaseId: number;
        readonly includeParents?: boolean | null | undefined;
    }>;
    readonly rulesets: ReadonlyArray<RepositoryRuleset> | null;
    readonly samlIdentityProvider: OrganizationIdentityProvider | null;
    readonly sponsoring: ReadonlyArray<Organization | User>;
    readonly sponsors: ReadonlyArray<Organization | User>;
    readonly sponsorsActivities: ReadonlyArray<SponsorsActivity>;
    readonly sponsorshipForViewerAsSponsor: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipForViewerAsSponsorable: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipNewsletters: ReadonlyArray<SponsorshipNewsletter>;
    readonly sponsorshipsAsMaintainer: ReadonlyArray<Sponsorship>;
    readonly sponsorshipsAsSponsor: ReadonlyArray<Sponsorship>;
    readonly sponsorsListing: SponsorsListing | null;
    readonly team: FieldWithArgs<Team | null, {
        readonly slug: string;
    }>;
    readonly teams: ReadonlyArray<Team>;
    readonly teamsResourcePath: string;
    readonly teamsUrl: string;
    readonly totalSponsorshipAmountAsSponsorInCents: FieldWithArgs<number | null, {
        readonly since?: string | null | undefined;
        readonly sponsorableLogins?: ReadonlyArray<string> | null | undefined;
        readonly until?: string | null | undefined;
    }, false>;
    readonly twitterUsername: string | null;
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerCanAdminister: boolean;
    readonly viewerCanChangePinnedItems: boolean;
    readonly viewerCanCreateProjects: boolean;
    readonly viewerCanCreateRepositories: boolean;
    readonly viewerCanCreateTeams: boolean;
    readonly viewerCanSponsor: boolean;
    readonly viewerIsAMember: boolean;
    readonly viewerIsFollowing: boolean;
    readonly viewerIsSponsoring: boolean;
    readonly webCommitSignoffRequired: boolean;
    readonly websiteUrl: string | null;
}
/** The connection type for OrganizationAuditEntry. */
export interface OrganizationAuditEntryConnection {
    readonly edges: ReadonlyArray<OrganizationAuditEntryEdge | null> | null;
    readonly nodes: ReadonlyArray<MembersCanDeleteReposClearAuditEntry | MembersCanDeleteReposDisableAuditEntry | MembersCanDeleteReposEnableAuditEntry | OauthApplicationCreateAuditEntry | OrgAddBillingManagerAuditEntry | OrgAddMemberAuditEntry | OrgBlockUserAuditEntry | OrgConfigDisableCollaboratorsOnlyAuditEntry | OrgConfigEnableCollaboratorsOnlyAuditEntry | OrgCreateAuditEntry | OrgDisableOauthAppRestrictionsAuditEntry | OrgDisableSamlAuditEntry | OrgDisableTwoFactorRequirementAuditEntry | OrgEnableOauthAppRestrictionsAuditEntry | OrgEnableSamlAuditEntry | OrgEnableTwoFactorRequirementAuditEntry | OrgInviteMemberAuditEntry | OrgInviteToBusinessAuditEntry | OrgOauthAppAccessApprovedAuditEntry | OrgOauthAppAccessBlockedAuditEntry | OrgOauthAppAccessDeniedAuditEntry | OrgOauthAppAccessRequestedAuditEntry | OrgOauthAppAccessUnblockedAuditEntry | OrgRemoveBillingManagerAuditEntry | OrgRemoveMemberAuditEntry | OrgRemoveOutsideCollaboratorAuditEntry | OrgRestoreMemberAuditEntry | OrgUnblockUserAuditEntry | OrgUpdateDefaultRepositoryPermissionAuditEntry | OrgUpdateMemberAuditEntry | OrgUpdateMemberRepositoryCreationPermissionAuditEntry | OrgUpdateMemberRepositoryInvitationPermissionAuditEntry | PrivateRepositoryForkingDisableAuditEntry | PrivateRepositoryForkingEnableAuditEntry | RepoAccessAuditEntry | RepoAddMemberAuditEntry | RepoAddTopicAuditEntry | RepoArchivedAuditEntry | RepoChangeMergeSettingAuditEntry | RepoConfigDisableAnonymousGitAccessAuditEntry | RepoConfigDisableCollaboratorsOnlyAuditEntry | RepoConfigDisableContributorsOnlyAuditEntry | RepoConfigDisableSockpuppetDisallowedAuditEntry | RepoConfigEnableAnonymousGitAccessAuditEntry | RepoConfigEnableCollaboratorsOnlyAuditEntry | RepoConfigEnableContributorsOnlyAuditEntry | RepoConfigEnableSockpuppetDisallowedAuditEntry | RepoConfigLockAnonymousGitAccessAuditEntry | RepoConfigUnlockAnonymousGitAccessAuditEntry | RepoCreateAuditEntry | RepoDestroyAuditEntry | RepoRemoveMemberAuditEntry | RepoRemoveTopicAuditEntry | RepositoryVisibilityChangeDisableAuditEntry | RepositoryVisibilityChangeEnableAuditEntry | TeamAddMemberAuditEntry | TeamAddRepositoryAuditEntry | TeamChangeParentTeamAuditEntry | TeamRemoveMemberAuditEntry | TeamRemoveRepositoryAuditEntry | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Metadata for an audit entry with action org.* */
export interface OrganizationAuditEntryData {
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
}
/** An edge in a connection. */
export interface OrganizationAuditEntryEdge {
    readonly cursor: string;
    readonly node: MembersCanDeleteReposClearAuditEntry | MembersCanDeleteReposDisableAuditEntry | MembersCanDeleteReposEnableAuditEntry | OauthApplicationCreateAuditEntry | OrgAddBillingManagerAuditEntry | OrgAddMemberAuditEntry | OrgBlockUserAuditEntry | OrgConfigDisableCollaboratorsOnlyAuditEntry | OrgConfigEnableCollaboratorsOnlyAuditEntry | OrgCreateAuditEntry | OrgDisableOauthAppRestrictionsAuditEntry | OrgDisableSamlAuditEntry | OrgDisableTwoFactorRequirementAuditEntry | OrgEnableOauthAppRestrictionsAuditEntry | OrgEnableSamlAuditEntry | OrgEnableTwoFactorRequirementAuditEntry | OrgInviteMemberAuditEntry | OrgInviteToBusinessAuditEntry | OrgOauthAppAccessApprovedAuditEntry | OrgOauthAppAccessBlockedAuditEntry | OrgOauthAppAccessDeniedAuditEntry | OrgOauthAppAccessRequestedAuditEntry | OrgOauthAppAccessUnblockedAuditEntry | OrgRemoveBillingManagerAuditEntry | OrgRemoveMemberAuditEntry | OrgRemoveOutsideCollaboratorAuditEntry | OrgRestoreMemberAuditEntry | OrgUnblockUserAuditEntry | OrgUpdateDefaultRepositoryPermissionAuditEntry | OrgUpdateMemberAuditEntry | OrgUpdateMemberRepositoryCreationPermissionAuditEntry | OrgUpdateMemberRepositoryInvitationPermissionAuditEntry | PrivateRepositoryForkingDisableAuditEntry | PrivateRepositoryForkingEnableAuditEntry | RepoAccessAuditEntry | RepoAddMemberAuditEntry | RepoAddTopicAuditEntry | RepoArchivedAuditEntry | RepoChangeMergeSettingAuditEntry | RepoConfigDisableAnonymousGitAccessAuditEntry | RepoConfigDisableCollaboratorsOnlyAuditEntry | RepoConfigDisableContributorsOnlyAuditEntry | RepoConfigDisableSockpuppetDisallowedAuditEntry | RepoConfigEnableAnonymousGitAccessAuditEntry | RepoConfigEnableCollaboratorsOnlyAuditEntry | RepoConfigEnableContributorsOnlyAuditEntry | RepoConfigEnableSockpuppetDisallowedAuditEntry | RepoConfigLockAnonymousGitAccessAuditEntry | RepoConfigUnlockAnonymousGitAccessAuditEntry | RepoCreateAuditEntry | RepoDestroyAuditEntry | RepoRemoveMemberAuditEntry | RepoRemoveTopicAuditEntry | RepositoryVisibilityChangeDisableAuditEntry | RepositoryVisibilityChangeEnableAuditEntry | TeamAddMemberAuditEntry | TeamAddRepositoryAuditEntry | TeamChangeParentTeamAuditEntry | TeamRemoveMemberAuditEntry | TeamRemoveRepositoryAuditEntry | null;
}
/** A list of organizations managed by an enterprise. */
export interface OrganizationConnection {
    readonly edges: ReadonlyArray<OrganizationEdge | null> | null;
    readonly nodes: ReadonlyArray<Organization | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface OrganizationEdge {
    readonly cursor: string;
    readonly node: Organization | null;
}
/** The connection type for User. */
export interface OrganizationEnterpriseOwnerConnection {
    readonly edges: ReadonlyArray<OrganizationEnterpriseOwnerEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An enterprise owner in the context of an organization that is part of the enterprise. */
export interface OrganizationEnterpriseOwnerEdge {
    readonly cursor: string;
    readonly node: User | null;
    readonly organizationRole: "DIRECT_MEMBER" | "OWNER" | "UNAFFILIATED";
}
/** An Identity Provider configured to provision SAML and SCIM identities for
Organizations. Visible to (1) organization owners, (2) organization owners'
personal access tokens (classic) with read:org or admin:org scope, (3) GitHub
App with an installation token with read or write access to members. */
export interface OrganizationIdentityProvider {
    readonly digestMethod: string | null;
    readonly externalIdentities: ReadonlyArray<ExternalIdentity>;
    readonly id: string;
    readonly idpCertificate: string | null;
    readonly issuer: string | null;
    readonly organization: Organization | null;
    readonly signatureMethod: string | null;
    readonly ssoUrl: string | null;
}
/** An Invitation for a user to an organization. */
export interface OrganizationInvitation {
    readonly createdAt: string;
    readonly email: string | null;
    readonly id: string;
    readonly invitationSource: "ENTERPRISE_ORGANIZATION_CREATION" | "MEMBER" | "SCIM" | "UNKNOWN";
    readonly invitationType: "EMAIL" | "USER";
    readonly invitee: User | null;
    readonly inviter: User;
    readonly inviterActor: User | null;
    readonly organization: Organization;
    readonly role: "ADMIN" | "BILLING_MANAGER" | "DIRECT_MEMBER" | "REINSTATE";
}
/** The connection type for OrganizationInvitation. */
export interface OrganizationInvitationConnection {
    readonly edges: ReadonlyArray<OrganizationInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<OrganizationInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface OrganizationInvitationEdge {
    readonly cursor: string;
    readonly node: OrganizationInvitation | null;
}
/** A list of users who belong to the organization. */
export interface OrganizationMemberConnection {
    readonly edges: ReadonlyArray<OrganizationMemberEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user within an organization. */
export interface OrganizationMemberEdge {
    readonly cursor: string;
    readonly hasTwoFactorEnabled: boolean | null;
    readonly node: User | null;
    readonly role: "ADMIN" | "MEMBER" | null;
}
/** A GitHub Enterprise Importer (GEI) organization migration. */
export interface OrganizationMigration {
    readonly createdAt: string;
    readonly databaseId: string | null;
    readonly failureReason: string | null;
    readonly id: string;
    readonly remainingRepositoriesCount: number | null;
    readonly sourceOrgName: string;
    readonly sourceOrgUrl: string;
    readonly state: "FAILED" | "FAILED_VALIDATION" | "IN_PROGRESS" | "NOT_STARTED" | "PENDING_VALIDATION" | "POST_REPO_MIGRATION" | "PRE_REPO_MIGRATION" | "QUEUED" | "REPO_MIGRATION" | "SUCCEEDED";
    readonly targetOrgName: string;
    readonly totalRepositoriesCount: number | null;
}
/** Parameters to be used for the organization_property condition */
export interface OrganizationPropertyConditionTarget {
    readonly exclude: ReadonlyArray<OrganizationPropertyTargetDefinition>;
    readonly include: ReadonlyArray<OrganizationPropertyTargetDefinition>;
}
/** A property that must match */
export interface OrganizationPropertyTargetDefinition {
    readonly name: string;
    readonly propertyValues: ReadonlyArray<string>;
}
/** An organization teams hovercard context */
export interface OrganizationTeamsHovercardContext {
    readonly message: string;
    readonly octicon: string;
    readonly relevantTeams: ReadonlyArray<Team>;
    readonly teamsResourcePath: string;
    readonly teamsUrl: string;
    readonly totalTeamCount: number;
}
/** An organization list hovercard context */
export interface OrganizationsHovercardContext {
    readonly message: string;
    readonly octicon: string;
    readonly relevantOrganizations: ReadonlyArray<Organization>;
    readonly totalOrganizationCount: number;
}
/** Information for an uploaded package. */
export interface Package {
    readonly id: string;
    readonly latestVersion: PackageVersion | null;
    readonly name: string;
    readonly packageType: "DEBIAN" | "DOCKER" | "MAVEN" | "NPM" | "NUGET" | "PYPI" | "RUBYGEMS";
    readonly repository: Repository | null;
    readonly statistics: PackageStatistics | null;
    readonly version: FieldWithArgs<PackageVersion | null, {
        readonly version: string;
    }>;
    readonly versions: ReadonlyArray<PackageVersion>;
}
/** The connection type for Package. */
export interface PackageConnection {
    readonly edges: ReadonlyArray<PackageEdge | null> | null;
    readonly nodes: ReadonlyArray<Package | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PackageEdge {
    readonly cursor: string;
    readonly node: Package | null;
}
/** A file in a package version. */
export interface PackageFile {
    readonly id: string;
    readonly md5: string | null;
    readonly name: string;
    readonly packageVersion: PackageVersion | null;
    readonly sha1: string | null;
    readonly sha256: string | null;
    readonly size: number | null;
    readonly updatedAt: string;
    readonly url: string | null;
}
/** The connection type for PackageFile. */
export interface PackageFileConnection {
    readonly edges: ReadonlyArray<PackageFileEdge | null> | null;
    readonly nodes: ReadonlyArray<PackageFile | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PackageFileEdge {
    readonly cursor: string;
    readonly node: PackageFile | null;
}
/** Represents an owner of a package. */
export interface PackageOwner {
    readonly id: string;
    readonly packages: ReadonlyArray<Package>;
}
/** Represents a object that contains package activity statistics such as downloads. */
export interface PackageStatistics {
    readonly downloadsTotalCount: number;
}
/** A version tag contains the mapping between a tag name and a version. */
export interface PackageTag {
    readonly id: string;
    readonly name: string;
    readonly version: PackageVersion | null;
}
/** Information about a specific package version. */
export interface PackageVersion {
    readonly files: ReadonlyArray<PackageFile>;
    readonly id: string;
    readonly package: Package | null;
    readonly platform: string | null;
    readonly preRelease: boolean;
    readonly readme: string | null;
    readonly release: Release | null;
    readonly statistics: PackageVersionStatistics | null;
    readonly summary: string | null;
    readonly version: string;
}
/** The connection type for PackageVersion. */
export interface PackageVersionConnection {
    readonly edges: ReadonlyArray<PackageVersionEdge | null> | null;
    readonly nodes: ReadonlyArray<PackageVersion | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PackageVersionEdge {
    readonly cursor: string;
    readonly node: PackageVersion | null;
}
/** Represents a object that contains package version activity statistics such as downloads. */
export interface PackageVersionStatistics {
    readonly downloadsTotalCount: number;
}
/** Information about pagination in a connection. */
export interface PageInfo {
    readonly endCursor: string | null;
    readonly hasNextPage: boolean;
    readonly hasPreviousPage: boolean;
    readonly startCursor: string | null;
}
/** Represents a 'parent_issue_added' event on a given issue. */
export interface ParentIssueAddedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly parent: Issue | null;
}
/** Represents a 'parent_issue_removed' event on a given issue. */
export interface ParentIssueRemovedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly parent: Issue | null;
}
/** A pending suggestion to assign a user to an issue. */
export interface PendingAssigneeSuggestion {
    readonly actor: Actor | null;
    readonly assignee: Bot | Mannequin | Organization | User | null;
    readonly createdAt: string;
    readonly id: string;
    readonly rationale: string | null;
    readonly updatedAt: string | null;
}
/** A pending suggestion to close an issue. */
export interface PendingCloseSuggestion {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly duplicateOf: Issue | PullRequest | null;
    readonly id: string;
    readonly rationale: string | null;
    readonly stateReason: "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | "REOPENED" | null;
    readonly updatedAt: string | null;
}
/** A pending suggestion to set an issue field's value. */
export interface PendingFieldSuggestion {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly rationale: string | null;
    readonly suggestedValue: string | null;
    readonly updatedAt: string | null;
}
/** A pending suggestion to add a label to an issue. */
export interface PendingLabelSuggestion {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly label: Label | null;
    readonly rationale: string | null;
    readonly updatedAt: string | null;
}
/** A pending suggestion to change an issue's type. */
export interface PendingTypeSuggestion {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issueType: IssueType | null;
    readonly rationale: string | null;
    readonly updatedAt: string | null;
}
/** A level of permission and source for a user's access to a repository. */
export interface PermissionSource {
    readonly organization: Organization;
    readonly permission: "ADMIN" | "NONE" | "READ" | "WRITE";
    readonly roleName: string | null;
    readonly source: EnterpriseTeam | Organization | Repository | Team;
}
/** Autogenerated return type of PinEnvironment. */
export interface PinEnvironmentPayload {
    readonly clientMutationId: string | null;
    readonly environment: Environment | null;
    readonly pinnedEnvironment: PinnedEnvironment | null;
}
/** Autogenerated return type of PinIssueComment. */
export interface PinIssueCommentPayload {
    readonly clientMutationId: string | null;
    readonly issueComment: IssueComment | null;
}
/** Autogenerated return type of PinIssue. */
export interface PinIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Entities that can be pinned. */
export interface Pinnable {
    readonly isPinned: boolean | null;
    readonly pinnedAt: string | null;
    readonly pinnedBy: User | null;
    readonly viewerCanPin: boolean;
    readonly viewerCanUnpin: boolean;
}
/** The connection type for PinnableItem. */
export interface PinnableItemConnection {
    readonly edges: ReadonlyArray<PinnableItemEdge | null> | null;
    readonly nodes: ReadonlyArray<Gist | Repository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PinnableItemEdge {
    readonly cursor: string;
    readonly node: Gist | Repository | null;
}
/** A Pinned Discussion is a discussion pinned to a repository's index page. */
export interface PinnedDiscussion {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly discussion: Discussion;
    readonly gradientStopColors: ReadonlyArray<string>;
    readonly id: string;
    readonly pattern: "CHEVRON_UP" | "DOT" | "DOT_FILL" | "HEART_FILL" | "PLUS" | "ZAP";
    readonly pinnedBy: Actor;
    readonly preconfiguredGradient: "BLUE_MINT" | "BLUE_PURPLE" | "PINK_BLUE" | "PURPLE_CORAL" | "RED_ORANGE" | null;
    readonly repository: Repository;
    readonly updatedAt: string;
}
/** The connection type for PinnedDiscussion. */
export interface PinnedDiscussionConnection {
    readonly edges: ReadonlyArray<PinnedDiscussionEdge | null> | null;
    readonly nodes: ReadonlyArray<PinnedDiscussion | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PinnedDiscussionEdge {
    readonly cursor: string;
    readonly node: PinnedDiscussion | null;
}
/** Represents a pinned environment on a given repository */
export interface PinnedEnvironment {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly environment: Environment;
    readonly id: string;
    readonly position: number;
    readonly repository: Repository;
}
/** The connection type for PinnedEnvironment. */
export interface PinnedEnvironmentConnection {
    readonly edges: ReadonlyArray<PinnedEnvironmentEdge | null> | null;
    readonly nodes: ReadonlyArray<PinnedEnvironment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PinnedEnvironmentEdge {
    readonly cursor: string;
    readonly node: PinnedEnvironment | null;
}
/** Represents a 'pinned' event on a given issue or pull request. */
export interface PinnedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issue: Issue;
}
/** A Pinned Issue is a issue pinned to a repository's index page. */
export interface PinnedIssue {
    readonly databaseId: number | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly issue: Issue;
    readonly pinnedBy: Actor;
    readonly repository: Repository;
}
/** A comment pinned to an Issue. */
export interface PinnedIssueComment {
    readonly databaseId: number | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly issue: Issue;
    readonly issueComment: IssueComment;
    readonly pinnedAt: string;
    readonly pinnedBy: Actor;
}
/** The connection type for PinnedIssue. */
export interface PinnedIssueConnection {
    readonly edges: ReadonlyArray<PinnedIssueEdge | null> | null;
    readonly nodes: ReadonlyArray<PinnedIssue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PinnedIssueEdge {
    readonly cursor: string;
    readonly node: PinnedIssue | null;
}
/** Audit log entry for a private_repository_forking.disable event. */
export interface PrivateRepositoryForkingDisableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a private_repository_forking.enable event. */
export interface PrivateRepositoryForkingEnableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** A curatable list of repositories relating to a repository owner, which defaults
to showing the most popular repositories they own. */
export interface ProfileItemShowcase {
    readonly hasPinnedItems: boolean;
    readonly items: ReadonlyArray<Gist | Repository>;
}
/** Represents any entity on GitHub that has a profile page. */
export interface ProfileOwner {
    readonly anyPinnableItems: FieldWithArgs<boolean, {
        readonly type?: "GIST" | "ISSUE" | "ORGANIZATION" | "PROJECT" | "PULL_REQUEST" | "REPOSITORY" | "TEAM" | "USER" | null | undefined;
    }, false>;
    readonly email: string | null;
    readonly id: string;
    readonly itemShowcase: ProfileItemShowcase;
    readonly location: string | null;
    readonly login: string;
    readonly name: string | null;
    readonly pinnableItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedItemsRemaining: number;
    readonly viewerCanChangePinnedItems: boolean;
    readonly websiteUrl: string | null;
}
/** Projects manage issues, pull requests and notes within a project owner. */
export interface Project {
    readonly body: string | null;
    readonly bodyHTML: string;
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly columns: ReadonlyArray<ProjectColumn>;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly id: string;
    readonly name: string;
    readonly number: number;
    readonly owner: ProjectOwner;
    readonly pendingCards: ReadonlyArray<ProjectCard>;
    readonly progress: ProjectProgress;
    readonly resourcePath: string;
    readonly state: "CLOSED" | "OPEN";
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerCanClose: boolean;
    readonly viewerCanReopen: boolean;
    readonly viewerCanUpdate: boolean;
}
/** A card in a project. */
export interface ProjectCard {
    readonly column: ProjectColumn | null;
    readonly content: Issue | PullRequest | null;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly id: string;
    readonly isArchived: boolean;
    readonly note: string | null;
    readonly project: Project;
    readonly resourcePath: string;
    readonly state: "CONTENT_ONLY" | "NOTE_ONLY" | "REDACTED" | null;
    readonly updatedAt: string;
    readonly url: string;
}
/** The connection type for ProjectCard. */
export interface ProjectCardConnection {
    readonly edges: ReadonlyArray<ProjectCardEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectCard | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectCardEdge {
    readonly cursor: string;
    readonly node: ProjectCard | null;
}
/** A column inside a project. */
export interface ProjectColumn {
    readonly cards: ReadonlyArray<ProjectCard>;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly name: string;
    readonly project: Project;
    readonly purpose: "DONE" | "IN_PROGRESS" | "TODO" | null;
    readonly resourcePath: string;
    readonly updatedAt: string;
    readonly url: string;
}
/** The connection type for ProjectColumn. */
export interface ProjectColumnConnection {
    readonly edges: ReadonlyArray<ProjectColumnEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectColumn | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectColumnEdge {
    readonly cursor: string;
    readonly node: ProjectColumn | null;
}
/** A list of projects associated with the owner. */
export interface ProjectConnection {
    readonly edges: ReadonlyArray<ProjectEdge | null> | null;
    readonly nodes: ReadonlyArray<Project | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectEdge {
    readonly cursor: string;
    readonly node: Project | null;
}
/** Represents an owner of a Project. */
export interface ProjectOwner {
    readonly id: string;
    readonly project: FieldWithArgs<Project | null, {
        readonly number: number;
    }>;
    readonly projects: ReadonlyArray<Project>;
    readonly projectsResourcePath: string;
    readonly projectsUrl: string;
    readonly viewerCanCreateProjects: boolean;
}
/** Project progress stats. */
export interface ProjectProgress {
    readonly doneCount: number;
    readonly donePercentage: number;
    readonly enabled: boolean;
    readonly inProgressCount: number;
    readonly inProgressPercentage: number;
    readonly todoCount: number;
    readonly todoPercentage: number;
}
/** New projects that manage issues, pull requests and drafts using tables and boards. */
export interface ProjectV2 {
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly field: FieldWithArgs<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null, {
        readonly name: string;
    }>;
    readonly fields: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField>;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly items: ReadonlyArray<ProjectV2Item>;
    readonly number: number;
    readonly owner: ProjectV2Owner;
    readonly public: boolean;
    readonly readme: string | null;
    readonly repositories: ReadonlyArray<Repository>;
    readonly resourcePath: string;
    readonly shortDescription: string | null;
    readonly statusUpdates: ReadonlyArray<ProjectV2StatusUpdate>;
    readonly teams: ReadonlyArray<Team>;
    readonly template: boolean;
    readonly title: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly view: FieldWithArgs<ProjectV2View | null, {
        readonly number: number;
    }>;
    readonly viewerCanClose: boolean;
    readonly viewerCanReopen: boolean;
    readonly viewerCanUpdate: boolean;
    readonly views: ReadonlyArray<ProjectV2View>;
    readonly workflow: FieldWithArgs<ProjectV2Workflow | null, {
        readonly number: number;
    }>;
    readonly workflows: ReadonlyArray<ProjectV2Workflow>;
}
/** The connection type for ProjectV2Actor. */
export interface ProjectV2ActorConnection {
    readonly edges: ReadonlyArray<ProjectV2ActorEdge | null> | null;
    readonly nodes: ReadonlyArray<Team | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2ActorEdge {
    readonly cursor: string;
    readonly node: Team | User | null;
}
/** The connection type for ProjectV2. */
export interface ProjectV2Connection {
    readonly edges: ReadonlyArray<ProjectV2Edge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2 | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2Edge {
    readonly cursor: string;
    readonly node: ProjectV2 | null;
}
/** Represents an event related to a project on the timeline of an issue or pull request. */
export interface ProjectV2Event {
    readonly project: ProjectV2 | null;
    readonly wasAutomated: boolean;
}
/** A field inside a project. */
export interface ProjectV2Field {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dataType: "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
    readonly id: string;
    readonly isIssueField: boolean;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly name: string;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** Common fields across different project field types */
export interface ProjectV2FieldCommon {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dataType: "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
    readonly id: string;
    readonly isIssueField: boolean;
    readonly name: string;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** The connection type for ProjectV2FieldConfiguration. */
export interface ProjectV2FieldConfigurationConnection {
    readonly edges: ReadonlyArray<ProjectV2FieldConfigurationEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2FieldConfigurationEdge {
    readonly cursor: string;
    readonly node: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null;
}
/** The connection type for ProjectV2Field. */
export interface ProjectV2FieldConnection {
    readonly edges: ReadonlyArray<ProjectV2FieldEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2Field | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2FieldEdge {
    readonly cursor: string;
    readonly node: ProjectV2Field | null;
}
/** An item within a Project. */
export interface ProjectV2Item {
    readonly content: DraftIssue | Issue | PullRequest | null;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly fieldValueByName: FieldWithArgs<ProjectV2ItemFieldDateValue | ProjectV2ItemFieldIterationValue | ProjectV2ItemFieldLabelValue | ProjectV2ItemFieldMilestoneValue | ProjectV2ItemFieldMultiSelectValue | ProjectV2ItemFieldNumberValue | ProjectV2ItemFieldPullRequestValue | ProjectV2ItemFieldRepositoryValue | ProjectV2ItemFieldReviewerValue | ProjectV2ItemFieldSingleSelectValue | ProjectV2ItemFieldTextValue | ProjectV2ItemFieldUserValue | ProjectV2ItemIssueFieldValue | null, {
        readonly name: string;
    }>;
    readonly fieldValues: ReadonlyArray<ProjectV2ItemFieldDateValue | ProjectV2ItemFieldIterationValue | ProjectV2ItemFieldLabelValue | ProjectV2ItemFieldMilestoneValue | ProjectV2ItemFieldMultiSelectValue | ProjectV2ItemFieldNumberValue | ProjectV2ItemFieldPullRequestValue | ProjectV2ItemFieldRepositoryValue | ProjectV2ItemFieldReviewerValue | ProjectV2ItemFieldSingleSelectValue | ProjectV2ItemFieldTextValue | ProjectV2ItemFieldUserValue | ProjectV2ItemIssueFieldValue>;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly isArchived: boolean;
    readonly project: ProjectV2;
    readonly type: "DRAFT_ISSUE" | "ISSUE" | "PULL_REQUEST" | "REDACTED";
    readonly updatedAt: string;
}
/** The connection type for ProjectV2Item. */
export interface ProjectV2ItemConnection {
    readonly edges: ReadonlyArray<ProjectV2ItemEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2Item | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2ItemEdge {
    readonly cursor: string;
    readonly node: ProjectV2Item | null;
}
/** The value of a date field in a Project item. */
export interface ProjectV2ItemFieldDateValue {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly date: string | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly updatedAt: string;
}
/** The value of an iteration field in a Project item. */
export interface ProjectV2ItemFieldIterationValue {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly duration: number;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly iterationId: string;
    readonly startDate: string;
    readonly title: string;
    readonly titleHTML: string;
    readonly updatedAt: string;
}
/** The value of the labels field in a Project item. */
export interface ProjectV2ItemFieldLabelValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly labels: ReadonlyArray<Label> | null;
}
/** The value of a milestone field in a Project item. */
export interface ProjectV2ItemFieldMilestoneValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly milestone: Milestone | null;
}
/** The value of a multi select field in a Project item. */
export interface ProjectV2ItemFieldMultiSelectValue {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly options: ReadonlyArray<ProjectV2MultiSelectFieldOption> | null;
    readonly updatedAt: string;
    readonly value: string;
}
/** The value of a number field in a Project item. */
export interface ProjectV2ItemFieldNumberValue {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly number: number | null;
    readonly updatedAt: string;
}
/** The value of a pull request field in a Project item. */
export interface ProjectV2ItemFieldPullRequestValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly pullRequests: ReadonlyArray<PullRequest> | null;
}
/** The value of a repository field in a Project item. */
export interface ProjectV2ItemFieldRepositoryValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly repository: Repository | null;
}
/** The value of a reviewers field in a Project item. */
export interface ProjectV2ItemFieldReviewerValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly reviewers: ReadonlyArray<Bot | EnterpriseTeam | Mannequin | Team | User> | null;
}
/** The value of a single select field in a Project item. */
export interface ProjectV2ItemFieldSingleSelectValue {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly descriptionHTML: string | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly name: string | null;
    readonly nameHTML: string | null;
    readonly optionId: string | null;
    readonly updatedAt: string;
}
/** The value of a text field in a Project item. */
export interface ProjectV2ItemFieldTextValue {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly text: string | null;
    readonly updatedAt: string;
}
/** The value of a user field in a Project item. */
export interface ProjectV2ItemFieldUserValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly users: ReadonlyArray<User> | null;
}
/** Common fields across different project field value types */
export interface ProjectV2ItemFieldValueCommon {
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly id: string;
    readonly item: ProjectV2Item;
    readonly updatedAt: string;
}
/** The connection type for ProjectV2ItemFieldValue. */
export interface ProjectV2ItemFieldValueConnection {
    readonly edges: ReadonlyArray<ProjectV2ItemFieldValueEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2ItemFieldDateValue | ProjectV2ItemFieldIterationValue | ProjectV2ItemFieldLabelValue | ProjectV2ItemFieldMilestoneValue | ProjectV2ItemFieldMultiSelectValue | ProjectV2ItemFieldNumberValue | ProjectV2ItemFieldPullRequestValue | ProjectV2ItemFieldRepositoryValue | ProjectV2ItemFieldReviewerValue | ProjectV2ItemFieldSingleSelectValue | ProjectV2ItemFieldTextValue | ProjectV2ItemFieldUserValue | ProjectV2ItemIssueFieldValue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2ItemFieldValueEdge {
    readonly cursor: string;
    readonly node: ProjectV2ItemFieldDateValue | ProjectV2ItemFieldIterationValue | ProjectV2ItemFieldLabelValue | ProjectV2ItemFieldMilestoneValue | ProjectV2ItemFieldMultiSelectValue | ProjectV2ItemFieldNumberValue | ProjectV2ItemFieldPullRequestValue | ProjectV2ItemFieldRepositoryValue | ProjectV2ItemFieldReviewerValue | ProjectV2ItemFieldSingleSelectValue | ProjectV2ItemFieldTextValue | ProjectV2ItemFieldUserValue | ProjectV2ItemIssueFieldValue | null;
}
/** The value of an issue field in a Project item. */
export interface ProjectV2ItemIssueFieldValue {
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
    readonly issueFieldValue: IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue | null;
}
/** Represents a 'project_v2_item_status_changed' event on a given issue or pull request. */
export interface ProjectV2ItemStatusChangedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly previousStatus: string;
    readonly project: ProjectV2 | null;
    readonly status: string;
    readonly wasAutomated: boolean;
}
/** An iteration field inside a project. */
export interface ProjectV2IterationField {
    readonly configuration: ProjectV2IterationFieldConfiguration;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dataType: "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
    readonly id: string;
    readonly isIssueField: boolean;
    readonly name: string;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** Iteration field configuration for a project. */
export interface ProjectV2IterationFieldConfiguration {
    readonly completedIterations: ReadonlyArray<ProjectV2IterationFieldIteration>;
    readonly duration: number;
    readonly iterations: ReadonlyArray<ProjectV2IterationFieldIteration>;
    readonly startDay: number;
}
/** Iteration field iteration settings for a project. */
export interface ProjectV2IterationFieldIteration {
    readonly duration: number;
    readonly id: string;
    readonly startDate: string;
    readonly title: string;
    readonly titleHTML: string;
}
/** A multi select field inside a project. */
export interface ProjectV2MultiSelectField {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dataType: "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
    readonly id: string;
    readonly isIssueField: boolean;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly multiSelectOptions: ReadonlyArray<ProjectV2MultiSelectFieldOption>;
    readonly name: string;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** Multi select field option for a configuration for a project. */
export interface ProjectV2MultiSelectFieldOption {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string;
    readonly descriptionHTML: string;
    readonly id: string;
    readonly name: string;
    readonly nameHTML: string;
}
/** Represents an owner of a project. */
export interface ProjectV2Owner {
    readonly id: string;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
}
/** Recent projects for the owner. */
export interface ProjectV2Recent {
    readonly recentProjects: ReadonlyArray<ProjectV2>;
}
/** A single select field inside a project. */
export interface ProjectV2SingleSelectField {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dataType: "ASSIGNEES" | "CLOSED" | "CREATED" | "DATE" | "ISSUE_TYPE" | "ITERATION" | "LABELS" | "LINKED_PULL_REQUESTS" | "MILESTONE" | "MULTI_SELECT" | "NUMBER" | "PARENT_ISSUE" | "REPOSITORY" | "REVIEWERS" | "SINGLE_SELECT" | "SUB_ISSUES_PROGRESS" | "TEXT" | "TITLE" | "TRACKED_BY" | "TRACKS" | "UPDATED";
    readonly id: string;
    readonly isIssueField: boolean;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
    readonly name: string;
    readonly options: ReadonlyArray<ProjectV2SingleSelectFieldOption>;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** Single select field option for a configuration for a project. */
export interface ProjectV2SingleSelectFieldOption {
    readonly color: "BLUE" | "GRAY" | "GREEN" | "ORANGE" | "PINK" | "PURPLE" | "RED" | "YELLOW";
    readonly description: string;
    readonly descriptionHTML: string;
    readonly id: string;
    readonly name: string;
    readonly nameHTML: string;
}
/** Represents a sort by field and direction. */
export interface ProjectV2SortBy {
    readonly direction: "ASC" | "DESC";
    readonly field: ProjectV2Field;
}
/** The connection type for ProjectV2SortBy. */
export interface ProjectV2SortByConnection {
    readonly edges: ReadonlyArray<ProjectV2SortByEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2SortBy | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2SortByEdge {
    readonly cursor: string;
    readonly node: ProjectV2SortBy | null;
}
/** Represents a sort by field and direction. */
export interface ProjectV2SortByField {
    readonly direction: "ASC" | "DESC";
    readonly field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField;
}
/** The connection type for ProjectV2SortByField. */
export interface ProjectV2SortByFieldConnection {
    readonly edges: ReadonlyArray<ProjectV2SortByFieldEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2SortByField | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2SortByFieldEdge {
    readonly cursor: string;
    readonly node: ProjectV2SortByField | null;
}
/** A status update within a project. */
export interface ProjectV2StatusUpdate {
    readonly body: string | null;
    readonly bodyHTML: string | null;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly databaseId: number | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly project: ProjectV2;
    readonly startDate: string | null;
    readonly status: "AT_RISK" | "COMPLETE" | "INACTIVE" | "OFF_TRACK" | "ON_TRACK" | null;
    readonly targetDate: string | null;
    readonly updatedAt: string;
}
/** The connection type for ProjectV2StatusUpdate. */
export interface ProjectV2StatusUpdateConnection {
    readonly edges: ReadonlyArray<ProjectV2StatusUpdateEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2StatusUpdate | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2StatusUpdateEdge {
    readonly cursor: string;
    readonly node: ProjectV2StatusUpdate | null;
}
/** A view within a ProjectV2. */
export interface ProjectV2View {
    readonly configuration: ProjectV2ViewConfiguration;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly fields: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField> | null;
    readonly filter: string | null;
    readonly fullDatabaseId: string | null;
    readonly groupBy: ReadonlyArray<ProjectV2Field> | null;
    readonly groupByFields: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField> | null;
    readonly id: string;
    readonly layout: "BOARD_LAYOUT" | "ROADMAP_LAYOUT" | "TABLE_LAYOUT";
    readonly name: string;
    readonly number: number;
    readonly project: ProjectV2;
    readonly sortBy: ReadonlyArray<ProjectV2SortBy> | null;
    readonly sortByFields: ReadonlyArray<ProjectV2SortByField> | null;
    readonly updatedAt: string;
    readonly verticalGroupBy: ReadonlyArray<ProjectV2Field> | null;
    readonly verticalGroupByFields: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField> | null;
    readonly visibleFields: ReadonlyArray<ProjectV2Field> | null;
}
/** Configuration for a ProjectV2 view. */
export interface ProjectV2ViewConfiguration {
    readonly visibleFields: ReadonlyArray<ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField>;
}
/** The connection type for ProjectV2View. */
export interface ProjectV2ViewConnection {
    readonly edges: ReadonlyArray<ProjectV2ViewEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2View | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2ViewEdge {
    readonly cursor: string;
    readonly node: ProjectV2View | null;
}
/** A workflow inside a project. */
export interface ProjectV2Workflow {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly enabled: boolean;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly name: string;
    readonly number: number;
    readonly project: ProjectV2;
    readonly updatedAt: string;
}
/** The connection type for ProjectV2Workflow. */
export interface ProjectV2WorkflowConnection {
    readonly edges: ReadonlyArray<ProjectV2WorkflowEdge | null> | null;
    readonly nodes: ReadonlyArray<ProjectV2Workflow | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ProjectV2WorkflowEdge {
    readonly cursor: string;
    readonly node: ProjectV2Workflow | null;
}
/** Autogenerated return type of PromoteRepositoryCustomProperty. */
export interface PromoteRepositoryCustomPropertyPayload {
    readonly clientMutationId: string | null;
    readonly repositoryCustomProperty: RepositoryCustomProperty | null;
}
/** A property that must match */
export interface PropertyTargetDefinition {
    readonly name: string;
    readonly propertyValues: ReadonlyArray<string>;
    readonly source: string | null;
}
/** A user's public key. */
export interface PublicKey {
    readonly accessedAt: string | null;
    readonly createdAt: string | null;
    readonly fingerprint: string;
    readonly id: string;
    readonly isReadOnly: boolean | null;
    readonly key: string;
    readonly updatedAt: string | null;
}
/** The connection type for PublicKey. */
export interface PublicKeyConnection {
    readonly edges: ReadonlyArray<PublicKeyEdge | null> | null;
    readonly nodes: ReadonlyArray<PublicKey | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PublicKeyEdge {
    readonly cursor: string;
    readonly node: PublicKey | null;
}
/** Autogenerated return type of PublishSponsorsTier. */
export interface PublishSponsorsTierPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsTier: SponsorsTier | null;
}
/** A repository pull request. */
export interface PullRequest {
    readonly activeLockReason: "OFF_TOPIC" | "RESOLVED" | "SPAM" | "TOO_HEATED" | null;
    readonly additions: number;
    readonly assignedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly assignees: ReadonlyArray<User>;
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly autoMergeRequest: AutoMergeRequest | null;
    readonly baseRef: Ref | null;
    readonly baseRefName: string;
    readonly baseRefOid: string;
    readonly baseRepository: Repository | null;
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly canBeRebased: boolean;
    readonly changedFiles: number;
    readonly checksResourcePath: string;
    readonly checksUrl: string;
    readonly closed: boolean;
    readonly closedAt: string | null;
    readonly closingIssuesReferences: ReadonlyArray<Issue> | null;
    readonly comments: ReadonlyArray<IssueComment>;
    readonly commits: ReadonlyArray<PullRequestCommit>;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly deletions: number;
    readonly editor: Actor | null;
    readonly files: ReadonlyArray<PullRequestChangedFile> | null;
    readonly fullDatabaseId: string | null;
    readonly headRef: Ref | null;
    readonly headRefName: string;
    readonly headRefOid: string;
    readonly headRepository: Repository | null;
    readonly headRepositoryOwner: RepositoryOwner | null;
    readonly hovercard: FieldWithArgs<Hovercard, {
        readonly includeNotificationContexts?: boolean | null | undefined;
    }, false>;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isCrossRepository: boolean;
    readonly isDraft: boolean;
    readonly isInMergeQueue: boolean;
    readonly isMergeQueueEnabled: boolean;
    readonly isReadByViewer: boolean | null;
    readonly labels: ReadonlyArray<Label> | null;
    readonly lastEditedAt: string | null;
    readonly latestOpinionatedReviews: ReadonlyArray<PullRequestReview> | null;
    readonly latestReviews: ReadonlyArray<PullRequestReview> | null;
    readonly locked: boolean;
    readonly maintainerCanModify: boolean;
    readonly mergeable: "CONFLICTING" | "MERGEABLE" | "UNKNOWN";
    readonly mergeCommit: Commit | null;
    readonly merged: boolean;
    readonly mergedAt: string | null;
    readonly mergedBy: Actor | null;
    readonly mergeQueue: MergeQueue | null;
    readonly mergeQueueEntry: MergeQueueEntry | null;
    readonly mergeStateStatus: "BEHIND" | "BLOCKED" | "CLEAN" | "DIRTY" | "DRAFT" | "HAS_HOOKS" | "UNKNOWN" | "UNSTABLE";
    readonly milestone: Milestone | null;
    readonly number: number;
    readonly participants: ReadonlyArray<User>;
    readonly permalink: string;
    readonly potentialMergeCommit: Commit | null;
    readonly projectCards: ReadonlyArray<ProjectCard>;
    readonly projectItems: ReadonlyArray<ProjectV2Item> | null;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly revertResourcePath: string;
    readonly revertUrl: string;
    readonly reviewDecision: "APPROVED" | "CHANGES_REQUESTED" | "REVIEW_REQUIRED" | null;
    readonly reviewRequests: ReadonlyArray<ReviewRequest> | null;
    readonly reviews: ReadonlyArray<PullRequestReview> | null;
    readonly reviewThreads: ReadonlyArray<PullRequestReviewThread>;
    readonly stack: PullRequestStack | null;
    readonly stackEntry: PullRequestStackEntry | null;
    readonly state: "CLOSED" | "MERGED" | "OPEN";
    readonly statusCheckRollup: StatusCheckRollup | null;
    readonly suggestedActors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly suggestedReviewerActors: ReadonlyArray<SuggestedReviewerActor>;
    readonly suggestedReviewers: ReadonlyArray<SuggestedReviewer | null>;
    readonly timeline: ReadonlyArray<AssignedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | ClosedEvent | Commit | CommitCommentThread | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | LabeledEvent | LockedEvent | MergedEvent | MilestonedEvent | PullRequestReview | PullRequestReviewComment | PullRequestReviewThread | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubscribedEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent>;
    readonly timelineItems: ReadonlyArray<AddedToMergeQueueEvent | AddedToProjectEvent | AddedToProjectV2Event | AddedToStackEvent | AssignedEvent | AutoMergeDisabledEvent | AutoMergeEnabledEvent | AutoRebaseEnabledEvent | AutoSquashEnabledEvent | AutomaticBaseChangeFailedEvent | AutomaticBaseChangeSucceededEvent | BaseRefChangedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertToDraftEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | DisconnectedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MergedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | PullRequestCommit | PullRequestCommitCommentThread | PullRequestReview | PullRequestReviewThread | PullRequestRevisionMarker | ReadyForReviewEvent | ReferencedEvent | RemovedFromMergeQueueEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RemovedFromStackEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent>;
    readonly title: string;
    readonly titleHTML: string;
    readonly totalCommentsCount: number | null;
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanApplySuggestion: boolean;
    readonly viewerCanAssign: boolean;
    readonly viewerCanClose: boolean;
    readonly viewerCanDeleteHeadRef: boolean;
    readonly viewerCanDisableAutoMerge: boolean;
    readonly viewerCanEditFiles: boolean;
    readonly viewerCanEnableAutoMerge: boolean;
    readonly viewerCanLabel: boolean;
    readonly viewerCanMergeAsAdmin: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanReopen: boolean;
    readonly viewerCanSubscribe: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerCanUpdateBranch: boolean;
    readonly viewerDidAuthor: boolean;
    readonly viewerLatestReview: PullRequestReview | null;
    readonly viewerLatestReviewRequest: ReviewRequest | null;
    readonly viewerMergeBodyText: FieldWithArgs<string, {
        readonly mergeType?: "MERGE" | "REBASE" | "SQUASH" | null | undefined;
    }, false>;
    readonly viewerMergeHeadlineText: FieldWithArgs<string, {
        readonly mergeType?: "MERGE" | "REBASE" | "SQUASH" | null | undefined;
    }, false>;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
}
/** A file changed in a pull request. */
export interface PullRequestChangedFile {
    readonly additions: number;
    readonly changeType: "ADDED" | "CHANGED" | "COPIED" | "DELETED" | "MODIFIED" | "RENAMED";
    readonly deletions: number;
    readonly path: string;
    readonly viewerViewedState: "DISMISSED" | "UNVIEWED" | "VIEWED";
}
/** The connection type for PullRequestChangedFile. */
export interface PullRequestChangedFileConnection {
    readonly edges: ReadonlyArray<PullRequestChangedFileEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestChangedFile | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestChangedFileEdge {
    readonly cursor: string;
    readonly node: PullRequestChangedFile | null;
}
/** Represents a Git commit part of a pull request. */
export interface PullRequestCommit {
    readonly commit: Commit;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly resourcePath: string;
    readonly url: string;
}
/** Represents a commit comment thread part of a pull request. */
export interface PullRequestCommitCommentThread {
    readonly comments: ReadonlyArray<CommitComment>;
    readonly commit: Commit;
    readonly id: string;
    readonly path: string | null;
    readonly position: number | null;
    readonly pullRequest: PullRequest;
    readonly repository: Repository;
}
/** The connection type for PullRequestCommit. */
export interface PullRequestCommitConnection {
    readonly edges: ReadonlyArray<PullRequestCommitEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestCommit | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestCommitEdge {
    readonly cursor: string;
    readonly node: PullRequestCommit | null;
}
/** The connection type for PullRequest. */
export interface PullRequestConnection {
    readonly edges: ReadonlyArray<PullRequestEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequest | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** This aggregates pull requests opened by a user within one repository. */
export interface PullRequestContributionsByRepository {
    readonly contributions: ReadonlyArray<CreatedPullRequestContribution>;
    readonly repository: Repository;
}
/** Users who are exempt from the pull request creation cap on a repository. */
export interface PullRequestCreationCapConfig {
    readonly bypassedUsers: ReadonlyArray<User>;
}
/** An edge in a connection. */
export interface PullRequestEdge {
    readonly cursor: string;
    readonly node: PullRequest | null;
}
/** Require all commits be made to a non-target branch and submitted via a pull request before they can be merged. */
export interface PullRequestParameters {
    readonly allowedMergeMethods: ReadonlyArray<"MERGE" | "REBASE" | "SQUASH"> | null;
    readonly dismissalRestriction: DismissalRestriction | null;
    readonly dismissStaleReviewsOnPush: boolean;
    readonly requireCodeOwnerReview: boolean;
    readonly requiredApprovingReviewCount: number;
    readonly requiredReviewers: ReadonlyArray<RequiredReviewerConfiguration> | null;
    readonly requiredReviewThreadResolution: boolean;
    readonly requireExtraApprovalForUnattributedChanges: boolean;
    readonly requireLastPushApproval: boolean;
}
/** A review object for a given pull request. */
export interface PullRequestReview {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly authorCanPushToRepository: boolean;
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly comments: ReadonlyArray<PullRequestReviewComment>;
    readonly commit: Commit | null;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly editor: Actor | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isMinimized: boolean;
    readonly lastEditedAt: string | null;
    readonly minimizedReason: string | null;
    readonly onBehalfOf: ReadonlyArray<Team>;
    readonly publishedAt: string | null;
    readonly pullRequest: PullRequest;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly state: "APPROVED" | "CHANGES_REQUESTED" | "COMMENTED" | "DISMISSED" | "PENDING";
    readonly submittedAt: string | null;
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerDidAuthor: boolean;
}
/** A review comment associated with a given repository pull request. */
export interface PullRequestReviewComment {
    readonly author: Actor | null;
    readonly authorAssociation: "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
    readonly body: string;
    readonly bodyHTML: string;
    readonly bodyText: string;
    readonly commit: Commit | null;
    readonly createdAt: string;
    readonly createdViaEmail: boolean;
    readonly databaseId: number | null;
    readonly diffHunk: string;
    readonly draftedAt: string;
    readonly editor: Actor | null;
    readonly fullDatabaseId: string | null;
    readonly id: string;
    readonly includesCreatedEdit: boolean;
    readonly isMinimized: boolean;
    readonly lastEditedAt: string | null;
    readonly line: number | null;
    readonly minimizedReason: string | null;
    readonly originalCommit: Commit | null;
    readonly originalLine: number | null;
    readonly originalPosition: number;
    readonly originalStartLine: number | null;
    readonly outdated: boolean;
    readonly path: string;
    readonly position: number | null;
    readonly publishedAt: string | null;
    readonly pullRequest: PullRequest;
    readonly pullRequestReview: PullRequestReview | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly replyTo: PullRequestReviewComment | null;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly startLine: number | null;
    readonly state: "PENDING" | "SUBMITTED";
    readonly subjectType: "FILE" | "LINE";
    readonly updatedAt: string;
    readonly url: string;
    readonly userContentEdits: ReadonlyArray<UserContentEdit> | null;
    readonly viewerCanDelete: boolean;
    readonly viewerCanMinimize: boolean;
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
    readonly viewerCanReact: boolean;
    readonly viewerCanUnminimize: boolean;
    readonly viewerCanUpdate: boolean;
    readonly viewerDidAuthor: boolean;
}
/** The connection type for PullRequestReviewComment. */
export interface PullRequestReviewCommentConnection {
    readonly edges: ReadonlyArray<PullRequestReviewCommentEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestReviewComment | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestReviewCommentEdge {
    readonly cursor: string;
    readonly node: PullRequestReviewComment | null;
}
/** The connection type for PullRequestReview. */
export interface PullRequestReviewConnection {
    readonly edges: ReadonlyArray<PullRequestReviewEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestReview | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** This aggregates pull request reviews made by a user within one repository. */
export interface PullRequestReviewContributionsByRepository {
    readonly contributions: ReadonlyArray<CreatedPullRequestReviewContribution>;
    readonly repository: Repository;
}
/** An edge in a connection. */
export interface PullRequestReviewEdge {
    readonly cursor: string;
    readonly node: PullRequestReview | null;
}
/** A threaded list of comments for a given pull request. */
export interface PullRequestReviewThread {
    readonly comments: ReadonlyArray<PullRequestReviewComment>;
    readonly diffSide: "LEFT" | "RIGHT";
    readonly id: string;
    readonly isCollapsed: boolean;
    readonly isOutdated: boolean;
    readonly isResolved: boolean;
    readonly line: number | null;
    readonly originalLine: number | null;
    readonly originalStartLine: number | null;
    readonly path: string;
    readonly pullRequest: PullRequest;
    readonly repository: Repository;
    readonly resolvedBy: User | null;
    readonly startDiffSide: "LEFT" | "RIGHT" | null;
    readonly startLine: number | null;
    readonly subjectType: "FILE" | "LINE";
    readonly viewerCanReply: boolean;
    readonly viewerCanResolve: boolean;
    readonly viewerCanUnresolve: boolean;
}
/** Review comment threads for a pull request review. */
export interface PullRequestReviewThreadConnection {
    readonly edges: ReadonlyArray<PullRequestReviewThreadEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestReviewThread | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestReviewThreadEdge {
    readonly cursor: string;
    readonly node: PullRequestReviewThread | null;
}
/** Represents the latest point in the pull request timeline for which the viewer has seen the pull request's commits. */
export interface PullRequestRevisionMarker {
    readonly createdAt: string;
    readonly lastSeenCommit: Commit;
    readonly pullRequest: PullRequest;
}
/** A stack of PullRequests */
export interface PullRequestStack {
    readonly baseRefName: string;
    readonly entries: ReadonlyArray<PullRequestStackEntry>;
    readonly id: string;
    readonly number: number;
    readonly size: number;
}
/** A member of a PullRequestStack */
export interface PullRequestStackEntry {
    readonly id: string;
    readonly position: number;
    readonly pullRequest: PullRequest | null;
    readonly stack: PullRequestStack | null;
}
/** Entries in a pull request stack */
export interface PullRequestStackEntryConnection {
    readonly edges: ReadonlyArray<PullRequestStackEntryEdge | null> | null;
    readonly nodes: ReadonlyArray<PullRequestStackEntry | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestStackEntryEdge {
    readonly cursor: string;
    readonly node: PullRequestStackEntry | null;
}
/** A repository pull request template. */
export interface PullRequestTemplate {
    readonly body: string | null;
    readonly filename: string | null;
    readonly repository: Repository;
}
/** A threaded list of comments for a given pull request. */
export interface PullRequestThread {
    readonly comments: ReadonlyArray<PullRequestReviewComment>;
    readonly diffSide: "LEFT" | "RIGHT";
    readonly id: string;
    readonly isCollapsed: boolean;
    readonly isOutdated: boolean;
    readonly isResolved: boolean;
    readonly line: number | null;
    readonly path: string;
    readonly pullRequest: PullRequest;
    readonly repository: Repository;
    readonly resolvedBy: User | null;
    readonly startDiffSide: "LEFT" | "RIGHT" | null;
    readonly startLine: number | null;
    readonly subjectType: "FILE" | "LINE";
    readonly viewerCanReply: boolean;
    readonly viewerCanResolve: boolean;
    readonly viewerCanUnresolve: boolean;
}
/** The connection type for PullRequestTimelineItem. */
export interface PullRequestTimelineConnection {
    readonly edges: ReadonlyArray<PullRequestTimelineItemEdge | null> | null;
    readonly nodes: ReadonlyArray<AssignedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | ClosedEvent | Commit | CommitCommentThread | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | LabeledEvent | LockedEvent | MergedEvent | MilestonedEvent | PullRequestReview | PullRequestReviewComment | PullRequestReviewThread | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubscribedEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PullRequestTimelineItemEdge {
    readonly cursor: string;
    readonly node: AssignedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | ClosedEvent | Commit | CommitCommentThread | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | LabeledEvent | LockedEvent | MergedEvent | MilestonedEvent | PullRequestReview | PullRequestReviewComment | PullRequestReviewThread | ReferencedEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubscribedEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnsubscribedEvent | UserBlockedEvent | null;
}
/** The connection type for PullRequestTimelineItems. */
export interface PullRequestTimelineItemsConnection {
    readonly edges: ReadonlyArray<PullRequestTimelineItemsEdge | null> | null;
    readonly filteredCount: number;
    readonly nodes: ReadonlyArray<AddedToMergeQueueEvent | AddedToProjectEvent | AddedToProjectV2Event | AddedToStackEvent | AssignedEvent | AutoMergeDisabledEvent | AutoMergeEnabledEvent | AutoRebaseEnabledEvent | AutoSquashEnabledEvent | AutomaticBaseChangeFailedEvent | AutomaticBaseChangeSucceededEvent | BaseRefChangedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertToDraftEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | DisconnectedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MergedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | PullRequestCommit | PullRequestCommitCommentThread | PullRequestReview | PullRequestReviewThread | PullRequestRevisionMarker | ReadyForReviewEvent | ReferencedEvent | RemovedFromMergeQueueEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RemovedFromStackEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent | null> | null;
    readonly pageCount: number;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly updatedAt: string;
}
/** An edge in a connection. */
export interface PullRequestTimelineItemsEdge {
    readonly cursor: string;
    readonly node: AddedToMergeQueueEvent | AddedToProjectEvent | AddedToProjectV2Event | AddedToStackEvent | AssignedEvent | AutoMergeDisabledEvent | AutoMergeEnabledEvent | AutoRebaseEnabledEvent | AutoSquashEnabledEvent | AutomaticBaseChangeFailedEvent | AutomaticBaseChangeSucceededEvent | BaseRefChangedEvent | BaseRefDeletedEvent | BaseRefForcePushedEvent | BlockedByAddedEvent | BlockedByRemovedEvent | BlockingAddedEvent | BlockingRemovedEvent | ClosedEvent | CommentDeletedEvent | ConnectedEvent | ConvertToDraftEvent | ConvertedFromDraftEvent | ConvertedNoteToIssueEvent | ConvertedToDiscussionEvent | CrossReferencedEvent | DemilestonedEvent | DeployedEvent | DeploymentEnvironmentChangedEvent | DisconnectedEvent | HeadRefDeletedEvent | HeadRefForcePushedEvent | HeadRefRestoredEvent | IssueComment | IssueCommentPinnedEvent | IssueCommentUnpinnedEvent | IssueFieldAddedEvent | IssueFieldChangedEvent | IssueFieldRemovedEvent | IssueTypeAddedEvent | IssueTypeChangedEvent | IssueTypeRemovedEvent | LabeledEvent | LockedEvent | MarkedAsDuplicateEvent | MentionedEvent | MergedEvent | MilestonedEvent | MovedColumnsInProjectEvent | ParentIssueAddedEvent | ParentIssueRemovedEvent | PinnedEvent | ProjectV2ItemStatusChangedEvent | PullRequestCommit | PullRequestCommitCommentThread | PullRequestReview | PullRequestReviewThread | PullRequestRevisionMarker | ReadyForReviewEvent | ReferencedEvent | RemovedFromMergeQueueEvent | RemovedFromProjectEvent | RemovedFromProjectV2Event | RemovedFromStackEvent | RenamedTitleEvent | ReopenedEvent | ReviewDismissedEvent | ReviewRequestRemovedEvent | ReviewRequestedEvent | SubIssueAddedEvent | SubIssueRemovedEvent | SubscribedEvent | TransferredEvent | UnassignedEvent | UnlabeledEvent | UnlockedEvent | UnmarkedAsDuplicateEvent | UnpinnedEvent | UnsubscribedEvent | UserBlockedEvent | null;
}
/** A Git push. */
export interface Push {
    readonly id: string;
    readonly nextSha: string | null;
    readonly permalink: string;
    readonly previousSha: string | null;
    readonly pusher: Actor;
    readonly repository: Repository;
}
/** A team, user, or app who has the ability to push to a protected branch. */
export interface PushAllowance {
    readonly actor: App | Team | User | null;
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly id: string;
}
/** The connection type for PushAllowance. */
export interface PushAllowanceConnection {
    readonly edges: ReadonlyArray<PushAllowanceEdge | null> | null;
    readonly nodes: ReadonlyArray<PushAllowance | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface PushAllowanceEdge {
    readonly cursor: string;
    readonly node: PushAllowance | null;
}
/** Represents the client's rate limit. */
export interface RateLimit {
    readonly cost: number;
    readonly limit: number;
    readonly nodeCount: number;
    readonly remaining: number;
    readonly resetAt: string;
    readonly used: number;
}
/** Represents a subject that can be reacted on. */
export interface Reactable {
    readonly databaseId: number | null;
    readonly id: string;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly viewerCanReact: boolean;
}
/** The connection type for User. */
export interface ReactingUserConnection {
    readonly edges: ReadonlyArray<ReactingUserEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user that's made a reaction. */
export interface ReactingUserEdge {
    readonly cursor: string;
    readonly node: User;
    readonly reactedAt: string;
}
/** An emoji reaction to a particular piece of content. */
export interface Reaction {
    readonly content: "CONFUSED" | "EYES" | "HEART" | "HOORAY" | "LAUGH" | "ROCKET" | "THUMBS_DOWN" | "THUMBS_UP";
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly reactable: Reactable;
    readonly user: User | null;
}
/** A list of reactions that have been left on the subject. */
export interface ReactionConnection {
    readonly edges: ReadonlyArray<ReactionEdge | null> | null;
    readonly nodes: ReadonlyArray<Reaction | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly viewerHasReacted: boolean;
}
/** An edge in a connection. */
export interface ReactionEdge {
    readonly cursor: string;
    readonly node: Reaction | null;
}
/** A group of emoji reactions to a particular piece of content. */
export interface ReactionGroup {
    readonly content: "CONFUSED" | "EYES" | "HEART" | "HOORAY" | "LAUGH" | "ROCKET" | "THUMBS_DOWN" | "THUMBS_UP";
    readonly createdAt: string | null;
    readonly reactors: ReadonlyArray<Bot | Mannequin | Organization | User>;
    readonly subject: Reactable;
    readonly users: ReadonlyArray<User>;
    readonly viewerHasReacted: boolean;
}
/** The connection type for Reactor. */
export interface ReactorConnection {
    readonly edges: ReadonlyArray<ReactorEdge | null> | null;
    readonly nodes: ReadonlyArray<Bot | Mannequin | Organization | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents an author of a reaction. */
export interface ReactorEdge {
    readonly cursor: string;
    readonly node: Bot | Mannequin | Organization | User;
    readonly reactedAt: string;
}
/** Represents a 'ready_for_review' event on a given pull request. */
export interface ReadyForReviewEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly resourcePath: string;
    readonly url: string;
}
/** Represents a Git reference. */
export interface Ref {
    readonly associatedPullRequests: ReadonlyArray<PullRequest>;
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly compare: FieldWithArgs<Comparison | null, {
        readonly headRef: string;
    }>;
    readonly id: string;
    readonly name: string;
    readonly prefix: string;
    readonly refUpdateRule: RefUpdateRule | null;
    readonly repository: Repository;
    readonly rules: ReadonlyArray<RepositoryRule> | null;
    readonly target: GitObject | null;
}
/** The connection type for Ref. */
export interface RefConnection {
    readonly edges: ReadonlyArray<RefEdge | null> | null;
    readonly nodes: ReadonlyArray<Ref | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RefEdge {
    readonly cursor: string;
    readonly node: Ref | null;
}
/** Parameters to be used for the ref_name condition */
export interface RefNameConditionTarget {
    readonly exclude: ReadonlyArray<string>;
    readonly include: ReadonlyArray<string>;
}
/** Branch protection rules that are enforced on the viewer. */
export interface RefUpdateRule {
    readonly allowsDeletions: boolean;
    readonly allowsForcePushes: boolean;
    readonly blocksCreations: boolean;
    readonly pattern: string;
    readonly requiredApprovingReviewCount: number | null;
    readonly requiredStatusCheckContexts: ReadonlyArray<string | null> | null;
    readonly requiresCodeOwnerReviews: boolean;
    readonly requiresConversationResolution: boolean;
    readonly requiresLinearHistory: boolean;
    readonly requiresSignatures: boolean;
    readonly viewerAllowedToDismissReviews: boolean;
    readonly viewerCanPush: boolean;
}
/** Represents a 'referenced' event on a given `ReferencedSubject`. */
export interface ReferencedEvent {
    readonly actor: Actor | null;
    readonly commit: Commit | null;
    readonly commitRepository: Repository;
    readonly createdAt: string;
    readonly id: string;
    readonly isCrossRepository: boolean;
    readonly isDirectReference: boolean;
    readonly subject: Issue | PullRequest;
}
/** Autogenerated return type of RegenerateEnterpriseIdentityProviderRecoveryCodes. */
export interface RegenerateEnterpriseIdentityProviderRecoveryCodesPayload {
    readonly clientMutationId: string | null;
    readonly identityProvider: EnterpriseIdentityProvider | null;
}
/** Autogenerated return type of RegenerateVerifiableDomainToken. */
export interface RegenerateVerifiableDomainTokenPayload {
    readonly clientMutationId: string | null;
    readonly verificationToken: string | null;
}
/** Autogenerated return type of RejectDeployments. */
export interface RejectDeploymentsPayload {
    readonly clientMutationId: string | null;
    readonly deployments: ReadonlyArray<Deployment> | null;
}
/** Autogenerated return type of RejectPendingIssueSuggestions. */
export interface RejectPendingIssueSuggestionsPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** A release contains the content for a release. */
export interface Release {
    readonly author: User | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly descriptionHTML: string | null;
    readonly id: string;
    readonly immutable: boolean;
    readonly isDraft: boolean;
    readonly isLatest: boolean;
    readonly isPrerelease: boolean;
    readonly mentions: ReadonlyArray<User> | null;
    readonly name: string | null;
    readonly publishedAt: string | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly reactions: ReadonlyArray<Reaction>;
    readonly releaseAssets: ReadonlyArray<ReleaseAsset>;
    readonly repository: Repository;
    readonly resourcePath: string;
    readonly shortDescriptionHTML: FieldWithArgs<string | null, {
        readonly limit?: number | null | undefined;
    }, false>;
    readonly tag: Ref | null;
    readonly tagCommit: Commit | null;
    readonly tagName: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerCanReact: boolean;
}
/** A release asset contains the content for a release asset. */
export interface ReleaseAsset {
    readonly contentType: string;
    readonly createdAt: string;
    readonly digest: string | null;
    readonly downloadCount: number;
    readonly downloadUrl: string;
    readonly id: string;
    readonly name: string;
    readonly release: Release | null;
    readonly size: number;
    readonly updatedAt: string;
    readonly uploadedBy: User;
    readonly url: string;
}
/** The connection type for ReleaseAsset. */
export interface ReleaseAssetConnection {
    readonly edges: ReadonlyArray<ReleaseAssetEdge | null> | null;
    readonly nodes: ReadonlyArray<ReleaseAsset | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ReleaseAssetEdge {
    readonly cursor: string;
    readonly node: ReleaseAsset | null;
}
/** The connection type for Release. */
export interface ReleaseConnection {
    readonly edges: ReadonlyArray<ReleaseEdge | null> | null;
    readonly nodes: ReadonlyArray<Release | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ReleaseEdge {
    readonly cursor: string;
    readonly node: Release | null;
}
/** Autogenerated return type of RemoveAssigneesFromAssignable. */
export interface RemoveAssigneesFromAssignablePayload {
    readonly assignable: Assignable | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of RemoveBlockedBy. */
export interface RemoveBlockedByPayload {
    readonly blockingIssue: Issue | null;
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of RemoveCloseIssueReferences. */
export interface RemoveCloseIssueReferencesPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of RemoveEnterpriseAdmin. */
export interface RemoveEnterpriseAdminPayload {
    readonly admin: User | null;
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
    readonly viewer: User | null;
}
/** Autogenerated return type of RemoveEnterpriseIdentityProvider. */
export interface RemoveEnterpriseIdentityProviderPayload {
    readonly clientMutationId: string | null;
    readonly identityProvider: EnterpriseIdentityProvider | null;
}
/** Autogenerated return type of RemoveEnterpriseMember. */
export interface RemoveEnterpriseMemberPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly user: User | null;
    readonly viewer: User | null;
}
/** Autogenerated return type of RemoveEnterpriseOrganization. */
export interface RemoveEnterpriseOrganizationPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly organization: Organization | null;
    readonly viewer: User | null;
}
/** Autogenerated return type of RemoveEnterpriseSupportEntitlement. */
export interface RemoveEnterpriseSupportEntitlementPayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
}
/** Autogenerated return type of RemoveLabelsFromLabelable. */
export interface RemoveLabelsFromLabelablePayload {
    readonly clientMutationId: string | null;
    readonly labelable: Labelable | null;
}
/** Autogenerated return type of RemoveOutsideCollaborator. */
export interface RemoveOutsideCollaboratorPayload {
    readonly clientMutationId: string | null;
    readonly removedUser: User | null;
}
/** Autogenerated return type of RemovePullRequestCreationCapBypassUsers. */
export interface RemovePullRequestCreationCapBypassUsersPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of RemoveReaction. */
export interface RemoveReactionPayload {
    readonly clientMutationId: string | null;
    readonly reaction: Reaction | null;
    readonly reactionGroups: ReadonlyArray<ReactionGroup> | null;
    readonly subject: Reactable | null;
}
/** Autogenerated return type of RemoveRelatesTo. */
export interface RemoveRelatesToPayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly relatedIssue: Issue | null;
}
/** Autogenerated return type of RemoveStar. */
export interface RemoveStarPayload {
    readonly clientMutationId: string | null;
    readonly starrable: Starrable | null;
}
/** Autogenerated return type of RemoveSubIssue. */
export interface RemoveSubIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly subIssue: Issue | null;
}
/** Autogenerated return type of RemoveUpvote. */
export interface RemoveUpvotePayload {
    readonly clientMutationId: string | null;
    readonly subject: Votable | null;
}
/** Represents a 'removed_from_merge_queue' event on a given pull request. */
export interface RemovedFromMergeQueueEvent {
    readonly actor: Actor | null;
    readonly beforeCommit: Commit | null;
    readonly createdAt: string;
    readonly enqueuer: User | null;
    readonly id: string;
    readonly mergeQueue: MergeQueue | null;
    readonly pullRequest: PullRequest | null;
    readonly reason: string | null;
}
/** Represents a 'removed_from_project' event on a given issue or pull request. */
export interface RemovedFromProjectEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly project: Project | null;
    readonly projectColumnName: string;
}
/** Represents a 'removed_from_project_v2' event on a given issue or pull request. */
export interface RemovedFromProjectV2Event {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly project: ProjectV2 | null;
    readonly wasAutomated: boolean;
}
/** Represents a 'removed_from_stack' event on a given pull request. */
export interface RemovedFromStackEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest | null;
    readonly stackId: string | null;
    readonly stackNumber: number | null;
}
/** Represents a 'renamed' event on a given issue or pull request */
export interface RenamedTitleEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly currentTitle: string;
    readonly id: string;
    readonly previousTitle: string;
    readonly subject: Issue | PullRequest;
}
/** Autogenerated return type of ReopenDiscussion. */
export interface ReopenDiscussionPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of ReopenIssue. */
export interface ReopenIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of ReopenPullRequest. */
export interface ReopenPullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Represents a 'reopened' event on any `Closable`. */
export interface ReopenedEvent {
    readonly actor: Actor | null;
    readonly closable: Closable;
    readonly createdAt: string;
    readonly id: string;
    readonly stateReason: "COMPLETED" | "DUPLICATE" | "NOT_PLANNED" | "REOPENED" | null;
}
/** Autogenerated return type of ReorderEnvironment. */
export interface ReorderEnvironmentPayload {
    readonly clientMutationId: string | null;
    readonly environment: Environment | null;
}
/** Autogenerated return type of ReplaceActorsForAssignable. */
export interface ReplaceActorsForAssignablePayload {
    readonly assignable: Assignable | null;
    readonly clientMutationId: string | null;
}
/** Audit log entry for a repo.access event. */
export interface RepoAccessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.add_member event. */
export interface RepoAddMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.add_topic event. */
export interface RepoAddTopicAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly topic: Topic | null;
    readonly topicName: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.archived event. */
export interface RepoArchivedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.change_merge_setting event. */
export interface RepoChangeMergeSettingAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isEnabled: boolean | null;
    readonly mergeType: "MERGE" | "REBASE" | "SQUASH" | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.disable_anonymous_git_access event. */
export interface RepoConfigDisableAnonymousGitAccessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.disable_collaborators_only event. */
export interface RepoConfigDisableCollaboratorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.disable_contributors_only event. */
export interface RepoConfigDisableContributorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.disable_sockpuppet_disallowed event. */
export interface RepoConfigDisableSockpuppetDisallowedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.enable_anonymous_git_access event. */
export interface RepoConfigEnableAnonymousGitAccessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.enable_collaborators_only event. */
export interface RepoConfigEnableCollaboratorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.enable_contributors_only event. */
export interface RepoConfigEnableContributorsOnlyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.enable_sockpuppet_disallowed event. */
export interface RepoConfigEnableSockpuppetDisallowedAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.lock_anonymous_git_access event. */
export interface RepoConfigLockAnonymousGitAccessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.config.unlock_anonymous_git_access event. */
export interface RepoConfigUnlockAnonymousGitAccessAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repo.create event. */
export interface RepoCreateAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly forkParentName: string | null;
    readonly forkSourceName: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.destroy event. */
export interface RepoDestroyAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.remove_member event. */
export interface RepoRemoveMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC" | null;
}
/** Audit log entry for a repo.remove_topic event. */
export interface RepoRemoveTopicAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly topic: Topic | null;
    readonly topicName: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** A repository contains the content for a project. */
export interface Repository {
    readonly allowUpdateBranch: boolean;
    readonly archivedAt: string | null;
    readonly assignableUsers: ReadonlyArray<User>;
    readonly autoMergeAllowed: boolean;
    readonly branchProtectionRules: ReadonlyArray<BranchProtectionRule>;
    readonly codeOfConduct: CodeOfConduct | null;
    readonly codeowners: FieldWithArgs<RepositoryCodeowners | null, {
        readonly refName?: string | null | undefined;
    }, false>;
    readonly collaborators: ReadonlyArray<User> | null;
    readonly commitComments: ReadonlyArray<CommitComment>;
    readonly contactLinks: ReadonlyArray<RepositoryContactLink> | null;
    readonly contributingGuidelines: ContributingGuidelines | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly defaultBranchRef: Ref | null;
    readonly deleteBranchOnMerge: boolean;
    readonly dependencyGraphManifests: ReadonlyArray<DependencyGraphManifest> | null;
    readonly deployKeys: ReadonlyArray<DeployKey>;
    readonly deployments: ReadonlyArray<Deployment>;
    readonly description: string | null;
    readonly descriptionHTML: string;
    readonly discussion: FieldWithArgs<Discussion | null, {
        readonly number: number;
    }>;
    readonly discussionCategories: ReadonlyArray<DiscussionCategory>;
    readonly discussionCategory: FieldWithArgs<DiscussionCategory | null, {
        readonly slug: string;
    }>;
    readonly discussions: ReadonlyArray<Discussion>;
    readonly diskUsage: number | null;
    readonly environment: FieldWithArgs<Environment | null, {
        readonly name: string;
    }>;
    readonly environments: ReadonlyArray<Environment>;
    readonly forkCount: number;
    readonly forkingAllowed: boolean;
    readonly forks: ReadonlyArray<Repository>;
    readonly fullDatabaseId: string | null;
    readonly fundingLinks: ReadonlyArray<FundingLink>;
    readonly hasDiscussionsEnabled: boolean;
    readonly hasIssuesEnabled: boolean;
    readonly hasProjectsEnabled: boolean;
    readonly hasPullRequestsEnabled: boolean;
    readonly hasSponsorshipsEnabled: boolean;
    readonly hasVulnerabilityAlertsEnabled: boolean;
    readonly hasWikiEnabled: boolean;
    readonly homepageUrl: string | null;
    readonly id: string;
    readonly interactionAbility: RepositoryInteractionAbility | null;
    readonly isArchived: boolean;
    readonly isBlankIssuesEnabled: boolean;
    readonly isDisabled: boolean;
    readonly isEmpty: boolean;
    readonly isFork: boolean;
    readonly isInOrganization: boolean;
    readonly isLocked: boolean;
    readonly isMirror: boolean;
    readonly isPrivate: boolean;
    readonly isSecurityPolicyEnabled: boolean | null;
    readonly issue: FieldWithArgs<Issue | null, {
        readonly number: number;
    }>;
    readonly issueCreationPolicy: "ALL" | "COLLABORATORS_ONLY" | null;
    readonly issueFields: ReadonlyArray<IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText> | null;
    readonly issueOrPullRequest: FieldWithArgs<Issue | PullRequest | null, {
        readonly number: number;
    }>;
    readonly issues: ReadonlyArray<Issue>;
    readonly issueTemplates: ReadonlyArray<IssueTemplate> | null;
    readonly issueType: FieldWithArgs<IssueType | null, {
        readonly name: string;
    }>;
    readonly issueTypes: ReadonlyArray<IssueType> | null;
    readonly isTemplate: boolean;
    readonly isUserConfigurationRepository: boolean;
    readonly label: FieldWithArgs<Label | null, {
        readonly name: string;
    }>;
    readonly labels: ReadonlyArray<Label> | null;
    readonly languages: ReadonlyArray<Language> | null;
    readonly latestRelease: Release | null;
    readonly licenseInfo: License | null;
    readonly lockReason: "BILLING" | "MIGRATING" | "MOVING" | "RENAME" | "TRADE_RESTRICTION" | "TRANSFERRING_OWNERSHIP" | null;
    readonly mentionableUsers: ReadonlyArray<User>;
    readonly mergeCommitAllowed: boolean;
    readonly mergeCommitMessage: "BLANK" | "PR_BODY" | "PR_TITLE";
    readonly mergeCommitTitle: "MERGE_MESSAGE" | "PR_TITLE";
    readonly mergeQueue: FieldWithArgs<MergeQueue | null, {
        readonly branch?: string | null | undefined;
    }, false>;
    readonly milestone: FieldWithArgs<Milestone | null, {
        readonly number: number;
    }>;
    readonly milestones: ReadonlyArray<Milestone> | null;
    readonly mirrorUrl: string | null;
    readonly name: string;
    readonly nameWithOwner: string;
    readonly object: FieldWithArgs<GitObject | null, {
        readonly expression?: string | null | undefined;
        readonly oid?: string | null | undefined;
    }, false>;
    readonly openGraphImageUrl: string;
    readonly owner: RepositoryOwner;
    readonly packages: ReadonlyArray<Package>;
    readonly parent: Repository | null;
    readonly pinnedDiscussions: ReadonlyArray<PinnedDiscussion>;
    readonly pinnedEnvironments: ReadonlyArray<PinnedEnvironment> | null;
    readonly pinnedIssues: ReadonlyArray<PinnedIssue> | null;
    readonly planFeatures: RepositoryPlanFeatures;
    readonly primaryLanguage: Language | null;
    readonly project: FieldWithArgs<Project | null, {
        readonly number: number;
    }>;
    readonly projects: ReadonlyArray<Project>;
    readonly projectsResourcePath: string;
    readonly projectsUrl: string;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly pullRequest: FieldWithArgs<PullRequest | null, {
        readonly number: number;
    }>;
    readonly pullRequestCreationCapConfig: PullRequestCreationCapConfig | null;
    readonly pullRequestCreationPolicy: "ALL" | "COLLABORATORS_ONLY" | null;
    readonly pullRequests: ReadonlyArray<PullRequest>;
    readonly pullRequestTemplates: ReadonlyArray<PullRequestTemplate> | null;
    readonly pushedAt: string | null;
    readonly rebaseMergeAllowed: boolean;
    readonly recentProjects: ReadonlyArray<ProjectV2>;
    readonly ref: FieldWithArgs<Ref | null, {
        readonly qualifiedName: string;
    }>;
    readonly refs: ReadonlyArray<Ref> | null;
    readonly release: FieldWithArgs<Release | null, {
        readonly tagName: string;
    }>;
    readonly releases: ReadonlyArray<Release>;
    readonly repositoryCustomPropertyValue: FieldWithArgs<RepositoryCustomPropertyValue | null, {
        readonly propertyName: string;
    }>;
    readonly repositoryCustomPropertyValues: ReadonlyArray<RepositoryCustomPropertyValue> | null;
    readonly repositoryTopics: ReadonlyArray<RepositoryTopic>;
    readonly resourcePath: string;
    readonly ruleset: FieldWithArgs<RepositoryRuleset | null, {
        readonly databaseId: number;
        readonly includeParents?: boolean | null | undefined;
    }>;
    readonly rulesets: ReadonlyArray<RepositoryRuleset> | null;
    readonly securityPolicyUrl: string | null;
    readonly shortDescriptionHTML: FieldWithArgs<string, {
        readonly limit?: number | null | undefined;
    }, false>;
    readonly squashMergeAllowed: boolean;
    readonly squashMergeCommitMessage: "BLANK" | "COMMIT_MESSAGES" | "PR_BODY";
    readonly squashMergeCommitTitle: "COMMIT_OR_PR_TITLE" | "PR_TITLE";
    readonly squashPrTitleUsedAsDefault: boolean;
    readonly sshUrl: string;
    readonly stargazerCount: number;
    readonly stargazers: ReadonlyArray<User>;
    readonly submodules: ReadonlyArray<Submodule>;
    readonly suggestedActors: ReadonlyArray<Actor>;
    readonly tempCloneToken: string | null;
    readonly templateRepository: Repository | null;
    readonly updatedAt: string;
    readonly url: string;
    readonly usesCustomOpenGraphImage: boolean;
    readonly viewerCanAdminister: boolean;
    readonly viewerCanCreateIssues: boolean;
    readonly viewerCanCreateProjects: boolean;
    readonly viewerCanSeeIssueFields: boolean;
    readonly viewerCanSubscribe: boolean;
    readonly viewerCanUpdateTopics: boolean;
    readonly viewerContentWarning: ContentWarning | null;
    readonly viewerDefaultCommitEmail: string | null;
    readonly viewerDefaultMergeMethod: "MERGE" | "REBASE" | "SQUASH";
    readonly viewerHasStarred: boolean;
    readonly viewerPermission: "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE" | null;
    readonly viewerPossibleCommitEmails: ReadonlyArray<string> | null;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC";
    readonly vulnerabilityAlert: FieldWithArgs<RepositoryVulnerabilityAlert | null, {
        readonly number: number;
    }>;
    readonly vulnerabilityAlerts: ReadonlyArray<RepositoryVulnerabilityAlert> | null;
    readonly watchers: ReadonlyArray<User>;
    readonly webCommitSignoffRequired: boolean;
}
/** Metadata for an audit entry with action repo.* */
export interface RepositoryAuditEntryData {
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
}
/** Information extracted from a repository's `CODEOWNERS` file. */
export interface RepositoryCodeowners {
    readonly errors: ReadonlyArray<RepositoryCodeownersError>;
}
/** An error in a `CODEOWNERS` file. */
export interface RepositoryCodeownersError {
    readonly column: number;
    readonly kind: string;
    readonly line: number;
    readonly message: string;
    readonly path: string;
    readonly source: string;
    readonly suggestion: string | null;
}
/** The connection type for User. */
export interface RepositoryCollaboratorConnection {
    readonly edges: ReadonlyArray<RepositoryCollaboratorEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user who is a collaborator of a repository. */
export interface RepositoryCollaboratorEdge {
    readonly cursor: string;
    readonly node: User;
    readonly permission: "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE";
    readonly permissionSources: ReadonlyArray<PermissionSource> | null;
}
/** A list of repositories owned by the subject. */
export interface RepositoryConnection {
    readonly edges: ReadonlyArray<RepositoryEdge | null> | null;
    readonly nodes: ReadonlyArray<Repository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly totalDiskUsage: number;
}
/** A repository contact link. */
export interface RepositoryContactLink {
    readonly about: string;
    readonly name: string;
    readonly url: string;
}
/** A repository custom property. */
export interface RepositoryCustomProperty {
    readonly allowedValues: ReadonlyArray<string> | null;
    readonly defaultValue: unknown | null;
    readonly description: string | null;
    readonly id: string;
    readonly propertyName: string;
    readonly regex: string | null;
    readonly required: boolean | null;
    readonly requireExplicitValues: boolean | null;
    readonly source: Enterprise | Organization;
    readonly valuesEditableBy: "ORG_ACTORS" | "ORG_AND_REPO_ACTORS";
    readonly valueType: "MULTI_SELECT" | "SINGLE_SELECT" | "STRING" | "TRUE_FALSE" | "URL";
}
/** The connection type for RepositoryCustomProperty. */
export interface RepositoryCustomPropertyConnection {
    readonly edges: ReadonlyArray<RepositoryCustomPropertyEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryCustomProperty | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryCustomPropertyEdge {
    readonly cursor: string;
    readonly node: RepositoryCustomProperty | null;
}
/** A value associated with a repository custom property. */
export interface RepositoryCustomPropertyValue {
    readonly propertyName: string;
    readonly value: unknown;
}
/** The connection type for RepositoryCustomPropertyValue. */
export interface RepositoryCustomPropertyValueConnection {
    readonly edges: ReadonlyArray<RepositoryCustomPropertyValueEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryCustomPropertyValue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryCustomPropertyValueEdge {
    readonly cursor: string;
    readonly node: RepositoryCustomPropertyValue | null;
}
/** Represents an author of discussions in repositories. */
export interface RepositoryDiscussionAuthor {
    readonly repositoryDiscussions: ReadonlyArray<Discussion>;
}
/** Represents an author of discussion comments in repositories. */
export interface RepositoryDiscussionCommentAuthor {
    readonly repositoryDiscussionComments: ReadonlyArray<DiscussionComment>;
}
/** An edge in a connection. */
export interface RepositoryEdge {
    readonly cursor: string;
    readonly node: Repository | null;
}
/** Parameters to be used for the repository_id condition */
export interface RepositoryIdConditionTarget {
    readonly repositoryIds: ReadonlyArray<string>;
}
/** A subset of repository info. */
export interface RepositoryInfo {
    readonly archivedAt: string | null;
    readonly createdAt: string;
    readonly description: string | null;
    readonly descriptionHTML: string;
    readonly forkCount: number;
    readonly hasDiscussionsEnabled: boolean;
    readonly hasIssuesEnabled: boolean;
    readonly hasProjectsEnabled: boolean;
    readonly hasPullRequestsEnabled: boolean;
    readonly hasSponsorshipsEnabled: boolean;
    readonly hasWikiEnabled: boolean;
    readonly homepageUrl: string | null;
    readonly isArchived: boolean;
    readonly isFork: boolean;
    readonly isInOrganization: boolean;
    readonly isLocked: boolean;
    readonly isMirror: boolean;
    readonly isPrivate: boolean;
    readonly issueCreationPolicy: "ALL" | "COLLABORATORS_ONLY" | null;
    readonly isTemplate: boolean;
    readonly licenseInfo: License | null;
    readonly lockReason: "BILLING" | "MIGRATING" | "MOVING" | "RENAME" | "TRADE_RESTRICTION" | "TRANSFERRING_OWNERSHIP" | null;
    readonly mirrorUrl: string | null;
    readonly name: string;
    readonly nameWithOwner: string;
    readonly openGraphImageUrl: string;
    readonly owner: RepositoryOwner;
    readonly pullRequestCreationPolicy: "ALL" | "COLLABORATORS_ONLY" | null;
    readonly pushedAt: string | null;
    readonly resourcePath: string;
    readonly shortDescriptionHTML: FieldWithArgs<string, {
        readonly limit?: number | null | undefined;
    }, false>;
    readonly updatedAt: string;
    readonly url: string;
    readonly usesCustomOpenGraphImage: boolean;
    readonly visibility: "INTERNAL" | "PRIVATE" | "PUBLIC";
}
/** Repository interaction limit that applies to this object. */
export interface RepositoryInteractionAbility {
    readonly expiresAt: string | null;
    readonly limit: "COLLABORATORS_ONLY" | "CONTRIBUTORS_ONLY" | "EXISTING_USERS" | "NO_LIMIT";
    readonly origin: "ORGANIZATION" | "REPOSITORY" | "USER";
}
/** An invitation for a user to be added to a repository. */
export interface RepositoryInvitation {
    readonly email: string | null;
    readonly id: string;
    readonly invitee: User | null;
    readonly inviter: User;
    readonly permalink: string;
    readonly permission: "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE";
    readonly repository: RepositoryInfo | null;
}
/** A list of repository invitations. */
export interface RepositoryInvitationConnection {
    readonly edges: ReadonlyArray<RepositoryInvitationEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryInvitation | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryInvitationEdge {
    readonly cursor: string;
    readonly node: RepositoryInvitation | null;
}
/** A GitHub Enterprise Importer (GEI) repository migration. */
export interface RepositoryMigration {
    readonly continueOnError: boolean;
    readonly createdAt: string;
    readonly databaseId: string | null;
    readonly failureReason: string | null;
    readonly id: string;
    readonly migrationLogUrl: string | null;
    readonly migrationSource: MigrationSource;
    readonly repositoryName: string;
    readonly sourceUrl: string;
    readonly state: "FAILED" | "FAILED_VALIDATION" | "IN_PROGRESS" | "NOT_STARTED" | "PENDING_VALIDATION" | "QUEUED" | "SUCCEEDED";
    readonly warningsCount: number;
}
/** A list of migrations. */
export interface RepositoryMigrationConnection {
    readonly edges: ReadonlyArray<RepositoryMigrationEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryMigration | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a repository migration. */
export interface RepositoryMigrationEdge {
    readonly cursor: string;
    readonly node: RepositoryMigration | null;
}
/** Parameters to be used for the repository_name condition */
export interface RepositoryNameConditionTarget {
    readonly exclude: ReadonlyArray<string>;
    readonly include: ReadonlyArray<string>;
    readonly protected: boolean;
}
/** Represents a object that belongs to a repository. */
export interface RepositoryNode {
    readonly repository: Repository;
}
/** Represents an owner of a Repository. */
export interface RepositoryOwner {
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly id: string;
    readonly login: string;
    readonly repositories: ReadonlyArray<Repository>;
    readonly repository: FieldWithArgs<Repository | null, {
        readonly name: string;
        readonly followRenames?: boolean | null | undefined;
    }>;
    readonly resourcePath: string;
    readonly url: string;
}
/** Information about the availability of features and limits for a repository based on its billing plan. */
export interface RepositoryPlanFeatures {
    readonly codeowners: boolean;
    readonly draftPullRequests: boolean;
    readonly maximumAssignees: number;
    readonly maximumManualReviewRequests: number;
    readonly teamReviewRequests: boolean;
}
/** Parameters to be used for the repository_property condition */
export interface RepositoryPropertyConditionTarget {
    readonly exclude: ReadonlyArray<PropertyTargetDefinition>;
    readonly include: ReadonlyArray<PropertyTargetDefinition>;
}
/** A repository rule. */
export interface RepositoryRule {
    readonly id: string;
    readonly parameters: BranchNamePatternParameters | CodeCoverageParameters | CodeQualityParameters | CodeScanningParameters | CommitAuthorEmailPatternParameters | CommitMessagePatternParameters | CommitterEmailPatternParameters | CopilotCodeReviewParameters | FileExtensionRestrictionParameters | FilePathRestrictionParameters | MaxFilePathLengthParameters | MaxFileSizeParameters | MergeQueueParameters | PullRequestParameters | RequiredDeploymentsParameters | RequiredStatusChecksParameters | TagNamePatternParameters | UpdateParameters | WorkflowsParameters | null;
    readonly repositoryRuleset: RepositoryRuleset | null;
    readonly type: "AUTHORIZATION" | "BRANCH_NAME_PATTERN" | "CODE_COVERAGE" | "CODE_QUALITY" | "CODE_SCANNING" | "COMMITTER_EMAIL_PATTERN" | "COMMIT_AUTHOR_EMAIL_PATTERN" | "COMMIT_MESSAGE_PATTERN" | "COPILOT_CODE_REVIEW" | "CREATION" | "DELETION" | "FILE_EXTENSION_RESTRICTION" | "FILE_PATH_RESTRICTION" | "LICENSE_COMPLIANCE_SCANNING" | "LOCK_BRANCH" | "MAX_FILE_PATH_LENGTH" | "MAX_FILE_SIZE" | "MAX_REF_UPDATES" | "MERGE_QUEUE" | "MERGE_QUEUE_LOCKED_REF" | "NON_FAST_FORWARD" | "PULL_REQUEST" | "REQUIRED_DEPLOYMENTS" | "REQUIRED_LINEAR_HISTORY" | "REQUIRED_REVIEW_THREAD_RESOLUTION" | "REQUIRED_SIGNATURES" | "REQUIRED_STATUS_CHECKS" | "REQUIRED_WORKFLOW_STATUS_CHECKS" | "SECRET_SCANNING" | "TAG" | "TAG_NAME_PATTERN" | "UPDATE" | "WORKFLOWS" | "WORKFLOW_UPDATES";
}
/** Set of conditions that determine if a ruleset will evaluate */
export interface RepositoryRuleConditions {
    readonly organizationProperty: OrganizationPropertyConditionTarget | null;
    readonly refName: RefNameConditionTarget | null;
    readonly repositoryId: RepositoryIdConditionTarget | null;
    readonly repositoryName: RepositoryNameConditionTarget | null;
    readonly repositoryProperty: RepositoryPropertyConditionTarget | null;
}
/** The connection type for RepositoryRule. */
export interface RepositoryRuleConnection {
    readonly edges: ReadonlyArray<RepositoryRuleEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryRule | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryRuleEdge {
    readonly cursor: string;
    readonly node: RepositoryRule | null;
}
/** A repository ruleset. */
export interface RepositoryRuleset {
    readonly bypassActors: ReadonlyArray<RepositoryRulesetBypassActor> | null;
    readonly conditions: RepositoryRuleConditions;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly enforcement: "ACTIVE" | "DISABLED" | "EVALUATE";
    readonly id: string;
    readonly name: string;
    readonly rules: ReadonlyArray<RepositoryRule> | null;
    readonly source: Enterprise | Organization | Repository;
    readonly target: "BRANCH" | "PUSH" | "REPOSITORY" | "TAG" | null;
    readonly updatedAt: string;
}
/** A team, app or user that has the ability to bypass rules defined on a ruleset */
export interface RepositoryRulesetBypassActor {
    readonly actor: App | EnterpriseTeam | Team | User | null;
    readonly bypassMode: "ALWAYS" | "EXEMPT" | "PULL_REQUEST" | null;
    readonly deployKey: boolean;
    readonly enterpriseOwner: boolean;
    readonly enterpriseRole: boolean;
    readonly enterpriseRoleDatabaseId: string | null;
    readonly id: string;
    readonly organizationAdmin: boolean;
    readonly repositoryRoleDatabaseId: number | null;
    readonly repositoryRoleName: string | null;
    readonly repositoryRuleset: RepositoryRuleset | null;
}
/** The connection type for RepositoryRulesetBypassActor. */
export interface RepositoryRulesetBypassActorConnection {
    readonly edges: ReadonlyArray<RepositoryRulesetBypassActorEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryRulesetBypassActor | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryRulesetBypassActorEdge {
    readonly cursor: string;
    readonly node: RepositoryRulesetBypassActor | null;
}
/** The connection type for RepositoryRuleset. */
export interface RepositoryRulesetConnection {
    readonly edges: ReadonlyArray<RepositoryRulesetEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryRuleset | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryRulesetEdge {
    readonly cursor: string;
    readonly node: RepositoryRuleset | null;
}
/** A repository-topic connects a repository to a topic. */
export interface RepositoryTopic {
    readonly id: string;
    readonly resourcePath: string;
    readonly topic: Topic;
    readonly url: string;
}
/** The connection type for RepositoryTopic. */
export interface RepositoryTopicConnection {
    readonly edges: ReadonlyArray<RepositoryTopicEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryTopic | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryTopicEdge {
    readonly cursor: string;
    readonly node: RepositoryTopic | null;
}
/** Audit log entry for a repository_visibility_change.disable event. */
export interface RepositoryVisibilityChangeDisableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a repository_visibility_change.enable event. */
export interface RepositoryVisibilityChangeEnableAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly enterpriseResourcePath: string | null;
    readonly enterpriseSlug: string | null;
    readonly enterpriseUrl: string | null;
    readonly id: string;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** A Dependabot alert for a repository with a dependency affected by a security vulnerability. */
export interface RepositoryVulnerabilityAlert {
    readonly autoDismissedAt: string | null;
    readonly createdAt: string;
    readonly dependabotUpdate: DependabotUpdate | null;
    readonly dependencyRelationship: "DIRECT" | "INCONCLUSIVE" | "TRANSITIVE" | "UNKNOWN" | null;
    readonly dependencyScope: "DEVELOPMENT" | "RUNTIME" | null;
    readonly dismissComment: string | null;
    readonly dismissedAt: string | null;
    readonly dismisser: User | null;
    readonly dismissReason: string | null;
    readonly fixedAt: string | null;
    readonly id: string;
    readonly number: number;
    readonly repository: Repository;
    readonly securityAdvisory: SecurityAdvisory | null;
    readonly securityVulnerability: SecurityVulnerability | null;
    readonly state: "AUTO_DISMISSED" | "DISMISSED" | "FIXED" | "OPEN";
    readonly vulnerableManifestFilename: string;
    readonly vulnerableManifestPath: string;
    readonly vulnerableRequirements: string | null;
}
/** The connection type for RepositoryVulnerabilityAlert. */
export interface RepositoryVulnerabilityAlertConnection {
    readonly edges: ReadonlyArray<RepositoryVulnerabilityAlertEdge | null> | null;
    readonly nodes: ReadonlyArray<RepositoryVulnerabilityAlert | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RepositoryVulnerabilityAlertEdge {
    readonly cursor: string;
    readonly node: RepositoryVulnerabilityAlert | null;
}
/** Autogenerated return type of ReprioritizeSubIssue. */
export interface ReprioritizeSubIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of RequestReviewsByLogin. */
export interface RequestReviewsByLoginPayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
    readonly requestedReviewersEdge: UserEdge | null;
}
/** Autogenerated return type of RequestReviews. */
export interface RequestReviewsPayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
    readonly requestedReviewersEdge: UserEdge | null;
}
/** The connection type for RequestedReviewer. */
export interface RequestedReviewerConnection {
    readonly edges: ReadonlyArray<RequestedReviewerEdge | null> | null;
    readonly nodes: ReadonlyArray<Bot | EnterpriseTeam | Mannequin | Team | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface RequestedReviewerEdge {
    readonly cursor: string;
    readonly node: Bot | EnterpriseTeam | Mannequin | Team | User | null;
}
/** Represents a type that can be required by a pull request for merging. */
export interface RequirableByPullRequest {
    readonly isRequired: FieldWithArgs<boolean, {
        readonly pullRequestId?: string | null | undefined;
        readonly pullRequestNumber?: number | null | undefined;
    }, false>;
}
/** Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule. */
export interface RequiredDeploymentsParameters {
    readonly requiredDeploymentEnvironments: ReadonlyArray<string>;
}
/** A reviewing team, and file patterns describing which files they must approve changes to. */
export interface RequiredReviewerConfiguration {
    readonly filePatterns: ReadonlyArray<string>;
    readonly minimumApprovals: number;
    readonly reviewerId: string;
}
/** Represents a required status check for a protected branch, but not any specific run of that check. */
export interface RequiredStatusCheckDescription {
    readonly app: App | null;
    readonly context: string;
}
/** Choose which status checks must pass before the ref is updated. When enabled,
commits must first be pushed to another ref where the checks pass. */
export interface RequiredStatusChecksParameters {
    readonly doNotEnforceOnCreate: boolean;
    readonly requiredStatusChecks: ReadonlyArray<StatusCheckConfiguration>;
    readonly strictRequiredStatusChecksPolicy: boolean;
}
/** Autogenerated return type of RerequestCheckSuite. */
export interface RerequestCheckSuitePayload {
    readonly checkSuite: CheckSuite | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of RerequestReviews. */
export interface RerequestReviewsPayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
    readonly requestedReviewersEdge: UserEdge | null;
}
/** Autogenerated return type of ResolveReviewThread. */
export interface ResolveReviewThreadPayload {
    readonly clientMutationId: string | null;
    readonly thread: PullRequestReviewThread | null;
}
/** Represents a private contribution a user made on GitHub. */
export interface RestrictedContribution {
    readonly isRestricted: boolean;
    readonly occurredAt: string;
    readonly resourcePath: string;
    readonly url: string;
    readonly user: User;
}
/** Autogenerated return type of RetireSponsorsTier. */
export interface RetireSponsorsTierPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsTier: SponsorsTier | null;
}
/** Autogenerated return type of RevertPullRequest. */
export interface RevertPullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
    readonly revertPullRequest: PullRequest | null;
}
/** A user, team, or app who has the ability to dismiss a review on a protected branch. */
export interface ReviewDismissalAllowance {
    readonly actor: App | Team | User | null;
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly id: string;
}
/** The connection type for ReviewDismissalAllowance. */
export interface ReviewDismissalAllowanceConnection {
    readonly edges: ReadonlyArray<ReviewDismissalAllowanceEdge | null> | null;
    readonly nodes: ReadonlyArray<ReviewDismissalAllowance | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ReviewDismissalAllowanceEdge {
    readonly cursor: string;
    readonly node: ReviewDismissalAllowance | null;
}
/** Represents a 'review_dismissed' event on a given issue or pull request. */
export interface ReviewDismissedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dismissalMessage: string | null;
    readonly dismissalMessageHTML: string | null;
    readonly id: string;
    readonly previousReviewState: "APPROVED" | "CHANGES_REQUESTED" | "COMMENTED" | "DISMISSED" | "PENDING";
    readonly pullRequest: PullRequest;
    readonly pullRequestCommit: PullRequestCommit | null;
    readonly resourcePath: string;
    readonly review: PullRequestReview | null;
    readonly url: string;
}
/** A request for a user to review a pull request. */
export interface ReviewRequest {
    readonly asCodeOwner: boolean;
    readonly databaseId: number | null;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly requestedReviewer: Bot | EnterpriseTeam | Mannequin | Team | User | null;
}
/** The connection type for ReviewRequest. */
export interface ReviewRequestConnection {
    readonly edges: ReadonlyArray<ReviewRequestEdge | null> | null;
    readonly nodes: ReadonlyArray<ReviewRequest | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface ReviewRequestEdge {
    readonly cursor: string;
    readonly node: ReviewRequest | null;
}
/** Represents an 'review_request_removed' event on a given pull request. */
export interface ReviewRequestRemovedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly requestedReviewer: Bot | EnterpriseTeam | Mannequin | Team | User | null;
}
/** Represents an 'review_requested' event on a given pull request. */
export interface ReviewRequestedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly pullRequest: PullRequest;
    readonly requestedReviewer: Bot | EnterpriseTeam | Mannequin | Team | User | null;
}
/** A hovercard context with a message describing the current code review state of the pull
request. */
export interface ReviewStatusHovercardContext {
    readonly message: string;
    readonly octicon: string;
    readonly reviewDecision: "APPROVED" | "CHANGES_REQUESTED" | "REVIEW_REQUIRED" | null;
}
/** Autogenerated return type of RevokeEnterpriseOrganizationsMigratorRole. */
export interface RevokeEnterpriseOrganizationsMigratorRolePayload {
    readonly clientMutationId: string | null;
    readonly organizations: ReadonlyArray<Organization> | null;
}
/** Autogenerated return type of RevokeMigratorRole. */
export interface RevokeMigratorRolePayload {
    readonly clientMutationId: string | null;
    readonly success: boolean | null;
}
/** A Saved Reply is text a user can use to reply quickly. */
export interface SavedReply {
    readonly body: string;
    readonly bodyHTML: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly title: string;
    readonly user: Actor | null;
}
/** The connection type for SavedReply. */
export interface SavedReplyConnection {
    readonly edges: ReadonlyArray<SavedReplyEdge | null> | null;
    readonly nodes: ReadonlyArray<SavedReply | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SavedReplyEdge {
    readonly cursor: string;
    readonly node: SavedReply | null;
}
/** A list of results that matched against a search query. Regardless of the number
of matches, a maximum of 1,000 results will be available across all types,
potentially split across many pages. */
export interface SearchResultItemConnection {
    readonly codeCount: number;
    readonly discussionCount: number;
    readonly edges: ReadonlyArray<SearchResultItemEdge | null> | null;
    readonly issueCount: number;
    readonly issueSearchType: "HYBRID" | "LEXICAL" | "SEMANTIC" | null;
    readonly lexicalFallbackReason: ReadonlyArray<"NON_ISSUE_TARGET" | "NO_ACCESSIBLE_REPOS" | "NO_TEXT_TERMS" | "ONLY_NON_SEMANTIC_FIELDS_REQUESTED" | "OR_BOOLEAN_NOT_SUPPORTED" | "QUOTED_TEXT" | "SERVER_ERROR"> | null;
    readonly nodes: ReadonlyArray<App | Discussion | Issue | MarketplaceListing | Organization | PullRequest | Repository | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly repositoryCount: number;
    readonly userCount: number;
    readonly wikiCount: number;
}
/** An edge in a connection. */
export interface SearchResultItemEdge {
    readonly cursor: string;
    readonly node: App | Discussion | Issue | MarketplaceListing | Organization | PullRequest | Repository | User | null;
    readonly textMatches: ReadonlyArray<TextMatch | null> | null;
}
/** A GitHub Security Advisory */
export interface SecurityAdvisory {
    readonly classification: "GENERAL" | "MALWARE";
    readonly cveId: string | null;
    readonly cvss: CVSS;
    readonly cvssSeverities: CvssSeverities;
    readonly cwes: ReadonlyArray<CWE>;
    readonly databaseId: number | null;
    readonly description: string;
    readonly epss: EPSS | null;
    readonly ghsaId: string;
    readonly githubReviewedAt: string | null;
    readonly id: string;
    readonly identifiers: ReadonlyArray<SecurityAdvisoryIdentifier>;
    readonly notificationsPermalink: string | null;
    readonly nvdPublishedAt: string | null;
    readonly origin: string;
    readonly permalink: string | null;
    readonly publishedAt: string;
    readonly references: ReadonlyArray<SecurityAdvisoryReference>;
    readonly repositoryAdvisoryUrl: string | null;
    readonly severity: "CRITICAL" | "HIGH" | "LOW" | "MODERATE" | "UNKNOWN";
    readonly sourceCodeLocation: string | null;
    readonly summary: string;
    readonly updatedAt: string;
    readonly vulnerabilities: ReadonlyArray<SecurityVulnerability>;
    readonly withdrawnAt: string | null;
}
/** The connection type for SecurityAdvisory. */
export interface SecurityAdvisoryConnection {
    readonly edges: ReadonlyArray<SecurityAdvisoryEdge | null> | null;
    readonly nodes: ReadonlyArray<SecurityAdvisory | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SecurityAdvisoryEdge {
    readonly cursor: string;
    readonly node: SecurityAdvisory | null;
}
/** A GitHub Security Advisory Identifier */
export interface SecurityAdvisoryIdentifier {
    readonly type: string;
    readonly value: string;
}
/** An individual package */
export interface SecurityAdvisoryPackage {
    readonly ecosystem: "ACTIONS" | "COMPOSER" | "ERLANG" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT";
    readonly name: string;
}
/** An individual package version */
export interface SecurityAdvisoryPackageVersion {
    readonly identifier: string;
}
/** A GitHub Security Advisory Reference */
export interface SecurityAdvisoryReference {
    readonly url: string;
}
/** An individual vulnerability within an Advisory */
export interface SecurityVulnerability {
    readonly advisory: SecurityAdvisory;
    readonly firstPatchedVersion: SecurityAdvisoryPackageVersion | null;
    readonly package: SecurityAdvisoryPackage;
    readonly severity: "CRITICAL" | "HIGH" | "LOW" | "MODERATE" | "UNKNOWN";
    readonly updatedAt: string;
    readonly vulnerableVersionRange: string;
}
/** The connection type for SecurityVulnerability. */
export interface SecurityVulnerabilityConnection {
    readonly edges: ReadonlyArray<SecurityVulnerabilityEdge | null> | null;
    readonly nodes: ReadonlyArray<SecurityVulnerability | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SecurityVulnerabilityEdge {
    readonly cursor: string;
    readonly node: SecurityVulnerability | null;
}
/** Autogenerated return type of SetEnterpriseIdentityProvider. */
export interface SetEnterpriseIdentityProviderPayload {
    readonly clientMutationId: string | null;
    readonly identityProvider: EnterpriseIdentityProvider | null;
}
/** Autogenerated return type of SetIssueFieldValue. */
export interface SetIssueFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly issueFieldValues: ReadonlyArray<IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue> | null;
}
/** Autogenerated return type of SetOrganizationInteractionLimit. */
export interface SetOrganizationInteractionLimitPayload {
    readonly clientMutationId: string | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of SetRepositoryCustomPropertyValues. */
export interface SetRepositoryCustomPropertyValuesPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of SetRepositoryInteractionLimit. */
export interface SetRepositoryInteractionLimitPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of SetUserInteractionLimit. */
export interface SetUserInteractionLimitPayload {
    readonly clientMutationId: string | null;
    readonly user: User | null;
}
/** Represents an S/MIME signature on a Commit or Tag. */
export interface SmimeSignature {
    readonly email: string;
    readonly isValid: boolean;
    readonly payload: string;
    readonly signature: string;
    readonly signer: User | null;
    readonly state: "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
    readonly verifiedAt: string | null;
    readonly wasSignedByGitHub: boolean;
}
/** Social media profile associated with a user. */
export interface SocialAccount {
    readonly displayName: string;
    readonly provider: "BLUESKY" | "FACEBOOK" | "GENERIC" | "HOMETOWN" | "INSTAGRAM" | "LINKEDIN" | "MASTODON" | "NPM" | "REDDIT" | "THREADS" | "TWITCH" | "TWITTER" | "YOUTUBE";
    readonly url: string;
}
/** The connection type for SocialAccount. */
export interface SocialAccountConnection {
    readonly edges: ReadonlyArray<SocialAccountEdge | null> | null;
    readonly nodes: ReadonlyArray<SocialAccount | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SocialAccountEdge {
    readonly cursor: string;
    readonly node: SocialAccount | null;
}
/** A GitHub account and the total amount in USD they've paid for sponsorships to a
particular maintainer. Does not include payments made via Patreon. */
export interface SponsorAndLifetimeValue {
    readonly amountInCents: number;
    readonly formattedAmount: string;
    readonly sponsor: Sponsorable;
    readonly sponsorable: Sponsorable;
}
/** The connection type for SponsorAndLifetimeValue. */
export interface SponsorAndLifetimeValueConnection {
    readonly edges: ReadonlyArray<SponsorAndLifetimeValueEdge | null> | null;
    readonly nodes: ReadonlyArray<SponsorAndLifetimeValue | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SponsorAndLifetimeValueEdge {
    readonly cursor: string;
    readonly node: SponsorAndLifetimeValue | null;
}
/** A list of users and organizations sponsoring someone via GitHub Sponsors. */
export interface SponsorConnection {
    readonly edges: ReadonlyArray<SponsorEdge | null> | null;
    readonly nodes: ReadonlyArray<Organization | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user or organization who is sponsoring someone in GitHub Sponsors. */
export interface SponsorEdge {
    readonly cursor: string;
    readonly node: Organization | User | null;
}
/** Entities that can sponsor or be sponsored through GitHub Sponsors. */
export interface Sponsorable {
    readonly estimatedNextSponsorsPayoutInCents: number;
    readonly hasSponsorsListing: boolean;
    readonly isSponsoredBy: FieldWithArgs<boolean, {
        readonly accountLogin: string;
    }>;
    readonly isSponsoringViewer: boolean;
    readonly lifetimeReceivedSponsorshipValues: ReadonlyArray<SponsorAndLifetimeValue>;
    readonly monthlyEstimatedSponsorsIncomeInCents: number;
    readonly sponsoring: ReadonlyArray<Organization | User>;
    readonly sponsors: ReadonlyArray<Organization | User>;
    readonly sponsorsActivities: ReadonlyArray<SponsorsActivity>;
    readonly sponsorshipForViewerAsSponsor: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipForViewerAsSponsorable: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipNewsletters: ReadonlyArray<SponsorshipNewsletter>;
    readonly sponsorshipsAsMaintainer: ReadonlyArray<Sponsorship>;
    readonly sponsorshipsAsSponsor: ReadonlyArray<Sponsorship>;
    readonly sponsorsListing: SponsorsListing | null;
    readonly totalSponsorshipAmountAsSponsorInCents: FieldWithArgs<number | null, {
        readonly since?: string | null | undefined;
        readonly sponsorableLogins?: ReadonlyArray<string> | null | undefined;
        readonly until?: string | null | undefined;
    }, false>;
    readonly viewerCanSponsor: boolean;
    readonly viewerIsSponsoring: boolean;
}
/** The connection type for SponsorableItem. */
export interface SponsorableItemConnection {
    readonly edges: ReadonlyArray<SponsorableItemEdge | null> | null;
    readonly nodes: ReadonlyArray<Organization | User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SponsorableItemEdge {
    readonly cursor: string;
    readonly node: Organization | User | null;
}
/** An event related to sponsorship activity. */
export interface SponsorsActivity {
    readonly action: "CANCELLED_SPONSORSHIP" | "NEW_SPONSORSHIP" | "PENDING_CHANGE" | "REFUND" | "SPONSOR_MATCH_DISABLED" | "TIER_CHANGE";
    readonly currentPrivacyLevel: "PRIVATE" | "PUBLIC" | null;
    readonly id: string;
    readonly paymentSource: "GITHUB" | "PATREON" | null;
    readonly previousSponsorsTier: SponsorsTier | null;
    readonly sponsor: Organization | User | null;
    readonly sponsorable: Sponsorable;
    readonly sponsorsTier: SponsorsTier | null;
    readonly timestamp: string | null;
    readonly viaBulkSponsorship: boolean;
}
/** The connection type for SponsorsActivity. */
export interface SponsorsActivityConnection {
    readonly edges: ReadonlyArray<SponsorsActivityEdge | null> | null;
    readonly nodes: ReadonlyArray<SponsorsActivity | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SponsorsActivityEdge {
    readonly cursor: string;
    readonly node: SponsorsActivity | null;
}
/** A goal associated with a GitHub Sponsors listing, representing a target the sponsored maintainer would like to attain. */
export interface SponsorsGoal {
    readonly description: string | null;
    readonly kind: "MONTHLY_SPONSORSHIP_AMOUNT" | "TOTAL_SPONSORS_COUNT";
    readonly percentComplete: number;
    readonly targetValue: number;
    readonly title: string;
}
/** A GitHub Sponsors listing. */
export interface SponsorsListing {
    readonly activeGoal: SponsorsGoal | null;
    readonly activeStripeConnectAccount: StripeConnectAccount | null;
    readonly billingCountryOrRegion: string | null;
    readonly contactEmailAddress: string | null;
    readonly createdAt: string;
    readonly dashboardResourcePath: string;
    readonly dashboardUrl: string;
    readonly featuredItems: ReadonlyArray<SponsorsListingFeaturedItem>;
    readonly fiscalHost: Organization | null;
    readonly fullDescription: string;
    readonly fullDescriptionHTML: string;
    readonly id: string;
    readonly isPublic: boolean;
    readonly name: string;
    readonly nextPayoutDate: string | null;
    readonly residenceCountryOrRegion: string | null;
    readonly resourcePath: string;
    readonly shortDescription: string;
    readonly slug: string;
    readonly sponsorable: Sponsorable;
    readonly tiers: ReadonlyArray<SponsorsTier> | null;
    readonly url: string;
}
/** A record that is promoted on a GitHub Sponsors profile. */
export interface SponsorsListingFeaturedItem {
    readonly createdAt: string;
    readonly description: string | null;
    readonly featureable: Repository | User;
    readonly id: string;
    readonly position: number;
    readonly sponsorsListing: SponsorsListing;
    readonly updatedAt: string;
}
/** A GitHub Sponsors tier associated with a GitHub Sponsors listing. */
export interface SponsorsTier {
    readonly adminInfo: SponsorsTierAdminInfo | null;
    readonly closestLesserValueTier: SponsorsTier | null;
    readonly createdAt: string;
    readonly description: string;
    readonly descriptionHTML: string;
    readonly id: string;
    readonly isCustomAmount: boolean;
    readonly isOneTime: boolean;
    readonly monthlyPriceInCents: number;
    readonly monthlyPriceInDollars: number;
    readonly name: string;
    readonly sponsorsListing: SponsorsListing;
    readonly updatedAt: string;
}
/** SponsorsTier information only visible to users that can administer the associated Sponsors listing. */
export interface SponsorsTierAdminInfo {
    readonly isDraft: boolean;
    readonly isPublished: boolean;
    readonly isRetired: boolean;
    readonly sponsorships: ReadonlyArray<Sponsorship>;
}
/** The connection type for SponsorsTier. */
export interface SponsorsTierConnection {
    readonly edges: ReadonlyArray<SponsorsTierEdge | null> | null;
    readonly nodes: ReadonlyArray<SponsorsTier | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SponsorsTierEdge {
    readonly cursor: string;
    readonly node: SponsorsTier | null;
}
/** A sponsorship relationship between a sponsor and a maintainer */
export interface Sponsorship {
    readonly createdAt: string;
    readonly id: string;
    readonly isActive: boolean;
    readonly isOneTimePayment: boolean;
    readonly isSponsorOptedIntoEmail: boolean | null;
    readonly maintainer: User;
    readonly paymentSource: "GITHUB" | "PATREON" | null;
    readonly privacyLevel: "PRIVATE" | "PUBLIC";
    readonly sponsor: User | null;
    readonly sponsorable: Sponsorable;
    readonly sponsorEntity: Organization | User | null;
    readonly tier: SponsorsTier | null;
    readonly tierSelectedAt: string | null;
}
/** A list of sponsorships either from the subject or received by the subject. */
export interface SponsorshipConnection {
    readonly edges: ReadonlyArray<SponsorshipEdge | null> | null;
    readonly nodes: ReadonlyArray<Sponsorship | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
    readonly totalRecurringMonthlyPriceInCents: number;
    readonly totalRecurringMonthlyPriceInDollars: number;
}
/** An edge in a connection. */
export interface SponsorshipEdge {
    readonly cursor: string;
    readonly node: Sponsorship | null;
}
/** An update sent to sponsors of a user or organization on GitHub Sponsors. */
export interface SponsorshipNewsletter {
    readonly author: User | null;
    readonly body: string;
    readonly createdAt: string;
    readonly id: string;
    readonly isPublished: boolean;
    readonly sponsorable: Sponsorable;
    readonly subject: string;
    readonly updatedAt: string;
}
/** The connection type for SponsorshipNewsletter. */
export interface SponsorshipNewsletterConnection {
    readonly edges: ReadonlyArray<SponsorshipNewsletterEdge | null> | null;
    readonly nodes: ReadonlyArray<SponsorshipNewsletter | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SponsorshipNewsletterEdge {
    readonly cursor: string;
    readonly node: SponsorshipNewsletter | null;
}
/** Represents an SSH signature on a Commit or Tag. */
export interface SshSignature {
    readonly email: string;
    readonly isValid: boolean;
    readonly keyFingerprint: string | null;
    readonly payload: string;
    readonly signature: string;
    readonly signer: User | null;
    readonly state: "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
    readonly verifiedAt: string | null;
    readonly wasSignedByGitHub: boolean;
}
/** The connection type for User. */
export interface StargazerConnection {
    readonly edges: ReadonlyArray<StargazerEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user that's starred a repository. */
export interface StargazerEdge {
    readonly cursor: string;
    readonly node: User;
    readonly starredAt: string;
}
/** Things that can be starred. */
export interface Starrable {
    readonly id: string;
    readonly stargazerCount: number;
    readonly stargazers: ReadonlyArray<User>;
    readonly viewerHasStarred: boolean;
}
/** The connection type for Repository. */
export interface StarredRepositoryConnection {
    readonly edges: ReadonlyArray<StarredRepositoryEdge | null> | null;
    readonly isOverLimit: boolean;
    readonly nodes: ReadonlyArray<Repository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a starred repository. */
export interface StarredRepositoryEdge {
    readonly cursor: string;
    readonly node: Repository;
    readonly starredAt: string;
}
/** Autogenerated return type of StartOrganizationMigration. */
export interface StartOrganizationMigrationPayload {
    readonly clientMutationId: string | null;
    readonly orgMigration: OrganizationMigration | null;
}
/** Autogenerated return type of StartRepositoryMigration. */
export interface StartRepositoryMigrationPayload {
    readonly clientMutationId: string | null;
    readonly repositoryMigration: RepositoryMigration | null;
}
/** Represents a commit status. */
export interface Status {
    readonly combinedContexts: ReadonlyArray<CheckRun | StatusContext>;
    readonly commit: Commit | null;
    readonly context: FieldWithArgs<StatusContext | null, {
        readonly name: string;
    }>;
    readonly contexts: ReadonlyArray<StatusContext>;
    readonly id: string;
    readonly state: "ERROR" | "EXPECTED" | "FAILURE" | "PENDING" | "SUCCESS";
}
/** Required status check */
export interface StatusCheckConfiguration {
    readonly context: string;
    readonly integrationId: number | null;
}
/** Represents the rollup for both the check runs and status for a commit. */
export interface StatusCheckRollup {
    readonly commit: Commit | null;
    readonly contexts: ReadonlyArray<CheckRun | StatusContext>;
    readonly id: string;
    readonly state: "ERROR" | "EXPECTED" | "FAILURE" | "PENDING" | "SUCCESS";
}
/** The connection type for StatusCheckRollupContext. */
export interface StatusCheckRollupContextConnection {
    readonly checkRunCount: number;
    readonly checkRunCountsByState: ReadonlyArray<CheckRunStateCount> | null;
    readonly edges: ReadonlyArray<StatusCheckRollupContextEdge | null> | null;
    readonly nodes: ReadonlyArray<CheckRun | StatusContext | null> | null;
    readonly pageInfo: PageInfo;
    readonly statusContextCount: number;
    readonly statusContextCountsByState: ReadonlyArray<StatusContextStateCount> | null;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface StatusCheckRollupContextEdge {
    readonly cursor: string;
    readonly node: CheckRun | StatusContext | null;
}
/** Represents an individual commit status context */
export interface StatusContext {
    readonly avatarUrl: FieldWithArgs<string | null, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly commit: Commit | null;
    readonly context: string;
    readonly createdAt: string;
    readonly creator: Actor | null;
    readonly description: string | null;
    readonly id: string;
    readonly isRequired: FieldWithArgs<boolean, {
        readonly pullRequestId?: string | null | undefined;
        readonly pullRequestNumber?: number | null | undefined;
    }, false>;
    readonly state: "ERROR" | "EXPECTED" | "FAILURE" | "PENDING" | "SUCCESS";
    readonly targetUrl: string | null;
    readonly updatedAt: string;
}
/** Represents a count of the state of a status context. */
export interface StatusContextStateCount {
    readonly count: number;
    readonly state: "ERROR" | "EXPECTED" | "FAILURE" | "PENDING" | "SUCCESS";
}
/** A Stripe Connect account for receiving sponsorship funds from GitHub Sponsors. */
export interface StripeConnectAccount {
    readonly accountId: string;
    readonly billingCountryOrRegion: string | null;
    readonly countryOrRegion: string | null;
    readonly isActive: boolean;
    readonly sponsorsListing: SponsorsListing;
    readonly stripeDashboardUrl: string;
}
/** Represents a 'sub_issue_added' event on a given issue. */
export interface SubIssueAddedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly subIssue: Issue | null;
}
/** Represents a 'sub_issue_removed' event on a given issue. */
export interface SubIssueRemovedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly subIssue: Issue | null;
}
/** Summary of the state of an issue's sub-issues */
export interface SubIssuesSummary {
    readonly completed: number;
    readonly percentCompleted: number;
    readonly total: number;
}
/** Autogenerated return type of SubmitPullRequestReview. */
export interface SubmitPullRequestReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
}
/** A pointer to a repository at a specific revision embedded inside another repository. */
export interface Submodule {
    readonly branch: string | null;
    readonly gitUrl: string;
    readonly name: string;
    readonly nameRaw: string;
    readonly path: string;
    readonly pathRaw: string;
    readonly subprojectCommitOid: string | null;
}
/** The connection type for Submodule. */
export interface SubmoduleConnection {
    readonly edges: ReadonlyArray<SubmoduleEdge | null> | null;
    readonly nodes: ReadonlyArray<Submodule | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SubmoduleEdge {
    readonly cursor: string;
    readonly node: Submodule | null;
}
/** Entities that can be subscribed to for web and email notifications. */
export interface Subscribable {
    readonly id: string;
    readonly viewerCanSubscribe: boolean;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
}
/** Entities that can be subscribed to for web and email notifications. */
export interface SubscribableThread {
    readonly id: string;
    readonly viewerThreadSubscriptionFormAction: "NONE" | "SUBSCRIBE" | "UNSUBSCRIBE" | null;
    readonly viewerThreadSubscriptionStatus: "DISABLED" | "IGNORING_LIST" | "IGNORING_THREAD" | "NONE" | "SUBSCRIBED_TO_LIST" | "SUBSCRIBED_TO_THREAD" | "SUBSCRIBED_TO_THREAD_EVENTS" | "SUBSCRIBED_TO_THREAD_TYPE" | "UNAVAILABLE" | null;
}
/** Represents a 'subscribed' event on a given `Subscribable`. */
export interface SubscribedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly subscribable: Subscribable;
}
/** A suggestion to review a pull request based on a user's commit history and review comments. */
export interface SuggestedReviewer {
    readonly isAuthor: boolean;
    readonly isCommenter: boolean;
    readonly reviewer: User;
}
/** A suggestion to review a pull request based on an actor's commit history, review comments, and integrations. */
export interface SuggestedReviewerActor {
    readonly isAuthor: boolean;
    readonly isCommenter: boolean;
    readonly reviewer: Actor;
}
/** A suggestion to review a pull request based on an actor's commit history, review comments, and integrations. */
export interface SuggestedReviewerActorConnection {
    readonly edges: ReadonlyArray<SuggestedReviewerActorEdge | null> | null;
    readonly nodes: ReadonlyArray<SuggestedReviewerActor | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface SuggestedReviewerActorEdge {
    readonly cursor: string;
    readonly node: SuggestedReviewerActor | null;
}
/** Represents a Git tag. */
export interface Tag {
    readonly abbreviatedOid: string;
    readonly commitResourcePath: string;
    readonly commitUrl: string;
    readonly id: string;
    readonly message: string | null;
    readonly name: string;
    readonly oid: string;
    readonly repository: Repository;
    readonly tagger: GitActor | null;
    readonly target: GitObject;
}
/** Parameters to be used for the tag_name_pattern rule */
export interface TagNamePatternParameters {
    readonly name: string | null;
    readonly negate: boolean;
    readonly operator: string;
    readonly pattern: string;
}
/** A team of users in an organization. */
export interface Team {
    readonly ancestors: ReadonlyArray<Team>;
    readonly avatarUrl: FieldWithArgs<string | null, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly childTeams: ReadonlyArray<Team>;
    readonly combinedSlug: string;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly description: string | null;
    readonly editTeamResourcePath: string;
    readonly editTeamUrl: string;
    readonly id: string;
    readonly invitations: ReadonlyArray<OrganizationInvitation> | null;
    readonly members: ReadonlyArray<User>;
    readonly membersResourcePath: string;
    readonly memberStatuses: ReadonlyArray<UserStatus>;
    readonly membersUrl: string;
    readonly name: string;
    readonly newTeamResourcePath: string;
    readonly newTeamUrl: string;
    readonly notificationSetting: "NOTIFICATIONS_DISABLED" | "NOTIFICATIONS_ENABLED";
    readonly organization: Organization;
    readonly parentTeam: Team | null;
    readonly privacy: "SECRET" | "VISIBLE";
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly repositories: ReadonlyArray<Repository>;
    readonly repositoriesResourcePath: string;
    readonly repositoriesUrl: string;
    readonly resourcePath: string;
    readonly reviewRequestDelegationAlgorithm: "LOAD_BALANCE" | "ROUND_ROBIN" | null;
    readonly reviewRequestDelegationEnabled: boolean;
    readonly reviewRequestDelegationMemberCount: number | null;
    readonly reviewRequestDelegationNotifyTeam: boolean;
    readonly slug: string;
    readonly teamsResourcePath: string;
    readonly teamsUrl: string;
    readonly updatedAt: string;
    readonly url: string;
    readonly viewerCanAdminister: boolean;
    readonly viewerCanSubscribe: boolean;
    readonly viewerSubscription: "IGNORED" | "SUBSCRIBED" | "UNSUBSCRIBED" | null;
}
/** Audit log entry for a team.add_member event. */
export interface TeamAddMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isLdapMapped: boolean | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a team.add_repository event. */
export interface TeamAddRepositoryAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isLdapMapped: boolean | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Metadata for an audit entry with action team.* */
export interface TeamAuditEntryData {
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
}
/** Audit log entry for a team.change_parent_team event. */
export interface TeamChangeParentTeamAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isLdapMapped: boolean | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly parentTeam: Team | null;
    readonly parentTeamName: string | null;
    readonly parentTeamNameWas: string | null;
    readonly parentTeamResourcePath: string | null;
    readonly parentTeamUrl: string | null;
    readonly parentTeamWas: Team | null;
    readonly parentTeamWasResourcePath: string | null;
    readonly parentTeamWasUrl: string | null;
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** The connection type for Team. */
export interface TeamConnection {
    readonly edges: ReadonlyArray<TeamEdge | null> | null;
    readonly nodes: ReadonlyArray<Team | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface TeamEdge {
    readonly cursor: string;
    readonly node: Team | null;
}
/** The connection type for User. */
export interface TeamMemberConnection {
    readonly edges: ReadonlyArray<TeamMemberEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a user who is a member of a team. */
export interface TeamMemberEdge {
    readonly cursor: string;
    readonly memberAccessResourcePath: string;
    readonly memberAccessUrl: string;
    readonly node: User;
    readonly role: "MAINTAINER" | "MEMBER";
}
/** Audit log entry for a team.remove_member event. */
export interface TeamRemoveMemberAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isLdapMapped: boolean | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** Audit log entry for a team.remove_repository event. */
export interface TeamRemoveRepositoryAuditEntry {
    readonly action: string;
    readonly actor: Bot | Organization | User | null;
    readonly actorIp: string | null;
    readonly actorLocation: ActorLocation | null;
    readonly actorLogin: string | null;
    readonly actorResourcePath: string | null;
    readonly actorUrl: string | null;
    readonly createdAt: string;
    readonly id: string;
    readonly isLdapMapped: boolean | null;
    readonly operationType: "ACCESS" | "AUTHENTICATION" | "CREATE" | "MODIFY" | "REMOVE" | "RESTORE" | "TRANSFER" | null;
    readonly organization: Organization | null;
    readonly organizationName: string | null;
    readonly organizationResourcePath: string | null;
    readonly organizationUrl: string | null;
    readonly repository: Repository | null;
    readonly repositoryName: string | null;
    readonly repositoryResourcePath: string | null;
    readonly repositoryUrl: string | null;
    readonly team: Team | null;
    readonly teamName: string | null;
    readonly teamResourcePath: string | null;
    readonly teamUrl: string | null;
    readonly user: User | null;
    readonly userLogin: string | null;
    readonly userResourcePath: string | null;
    readonly userUrl: string | null;
}
/** The connection type for Repository. */
export interface TeamRepositoryConnection {
    readonly edges: ReadonlyArray<TeamRepositoryEdge | null> | null;
    readonly nodes: ReadonlyArray<Repository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** Represents a team repository. */
export interface TeamRepositoryEdge {
    readonly cursor: string;
    readonly node: Repository;
    readonly permission: "ADMIN" | "MAINTAIN" | "READ" | "TRIAGE" | "TRIAGE_PLUS" | "WRITE";
}
/** Represents a team that can be requested to review a pull request. */
export interface TeamReviewRequestable {
    readonly id: string;
    readonly name: string;
    readonly slug: string;
}
/** A text match within a search result. */
export interface TextMatch {
    readonly fragment: string;
    readonly highlights: ReadonlyArray<TextMatchHighlight>;
    readonly property: string;
}
/** Represents a single highlight in a search result match. */
export interface TextMatchHighlight {
    readonly beginIndice: number;
    readonly endIndice: number;
    readonly text: string;
}
/** A topic aggregates entities that are related to a subject. */
export interface Topic {
    readonly id: string;
    readonly name: string;
    readonly relatedTopics: ReadonlyArray<Topic>;
    readonly repositories: ReadonlyArray<Repository>;
    readonly stargazerCount: number;
    readonly stargazers: ReadonlyArray<User>;
    readonly viewerHasStarred: boolean;
}
/** Metadata for an audit entry with a topic. */
export interface TopicAuditEntryData {
    readonly topic: Topic | null;
    readonly topicName: string | null;
}
/** Autogenerated return type of TransferEnterpriseOrganization. */
export interface TransferEnterpriseOrganizationPayload {
    readonly clientMutationId: string | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of TransferIssue. */
export interface TransferIssuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Represents a 'transferred' event on a given issue or pull request. */
export interface TransferredEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly fromRepository: Repository | null;
    readonly id: string;
    readonly issue: Issue;
}
/** Represents a Git tree. */
export interface Tree {
    readonly abbreviatedOid: string;
    readonly commitResourcePath: string;
    readonly commitUrl: string;
    readonly entries: ReadonlyArray<TreeEntry> | null;
    readonly id: string;
    readonly oid: string;
    readonly repository: Repository;
}
/** Represents a Git tree entry. */
export interface TreeEntry {
    readonly extension: string | null;
    readonly isGenerated: boolean;
    readonly language: Language | null;
    readonly lineCount: number | null;
    readonly mode: number;
    readonly name: string;
    readonly nameRaw: string;
    readonly object: GitObject | null;
    readonly oid: string;
    readonly path: string | null;
    readonly pathRaw: string | null;
    readonly repository: Repository;
    readonly size: number;
    readonly submodule: Submodule | null;
    readonly type: string;
}
/** Autogenerated return type of UnarchiveProjectV2Item. */
export interface UnarchiveProjectV2ItemPayload {
    readonly clientMutationId: string | null;
    readonly item: ProjectV2Item | null;
}
/** Autogenerated return type of UnarchivePullRequest. */
export interface UnarchivePullRequestPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of UnarchiveRepository. */
export interface UnarchiveRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Represents an 'unassigned' event on any assignable object. */
export interface UnassignedEvent {
    readonly actor: Actor | null;
    readonly assignable: Assignable;
    readonly assignee: Bot | Mannequin | Organization | User | null;
    readonly createdAt: string;
    readonly id: string;
    readonly user: User | null;
}
/** Autogenerated return type of UnfollowOrganization. */
export interface UnfollowOrganizationPayload {
    readonly clientMutationId: string | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of UnfollowUser. */
export interface UnfollowUserPayload {
    readonly clientMutationId: string | null;
    readonly user: User | null;
}
/** Represents a type that can be retrieved by a URL. */
export interface UniformResourceLocatable {
    readonly resourcePath: string;
    readonly url: string;
}
/** Represents an unknown signature on a Commit or Tag. */
export interface UnknownSignature {
    readonly email: string;
    readonly isValid: boolean;
    readonly payload: string;
    readonly signature: string;
    readonly signer: User | null;
    readonly state: "BAD_CERT" | "BAD_EMAIL" | "EXPIRED_KEY" | "GPGVERIFY_ERROR" | "GPGVERIFY_UNAVAILABLE" | "INVALID" | "MALFORMED_SIG" | "NOT_SIGNING_KEY" | "NO_USER" | "OCSP_ERROR" | "OCSP_PENDING" | "OCSP_REVOKED" | "UNKNOWN_KEY" | "UNKNOWN_SIG_TYPE" | "UNSIGNED" | "UNVERIFIED_EMAIL" | "VALID";
    readonly verifiedAt: string | null;
    readonly wasSignedByGitHub: boolean;
}
/** Represents an 'unlabeled' event on a given issue or pull request. */
export interface UnlabeledEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly intent: IssueUpdateIntent | null;
    readonly label: Label;
    readonly labelable: Labelable;
}
/** Autogenerated return type of UnlinkProjectV2FromRepository. */
export interface UnlinkProjectV2FromRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UnlinkProjectV2FromTeam. */
export interface UnlinkProjectV2FromTeamPayload {
    readonly clientMutationId: string | null;
    readonly team: Team | null;
}
/** Autogenerated return type of UnlinkRepositoryFromProject. */
export interface UnlinkRepositoryFromProjectPayload {
    readonly clientMutationId: string | null;
    readonly project: Project | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UnlockLockable. */
export interface UnlockLockablePayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly unlockedRecord: Lockable | null;
}
/** Represents an 'unlocked' event on a given issue or pull request. */
export interface UnlockedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly lockable: Lockable;
}
/** Autogenerated return type of UnmarkDiscussionCommentAsAnswer. */
export interface UnmarkDiscussionCommentAsAnswerPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of UnmarkFileAsViewed. */
export interface UnmarkFileAsViewedPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of UnmarkIssueAsDuplicate. */
export interface UnmarkIssueAsDuplicatePayload {
    readonly clientMutationId: string | null;
    readonly duplicate: Issue | PullRequest | null;
}
/** Autogenerated return type of UnmarkProjectV2AsTemplate. */
export interface UnmarkProjectV2AsTemplatePayload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Represents an 'unmarked_as_duplicate' event on a given issue or pull request. */
export interface UnmarkedAsDuplicateEvent {
    readonly actor: Actor | null;
    readonly canonical: Issue | PullRequest | null;
    readonly createdAt: string;
    readonly duplicate: Issue | PullRequest | null;
    readonly id: string;
    readonly isCrossRepository: boolean;
}
/** Autogenerated return type of UnminimizeComment. */
export interface UnminimizeCommentPayload {
    readonly clientMutationId: string | null;
    readonly unminimizedComment: Minimizable | null;
}
/** Autogenerated return type of UnpinIssueComment. */
export interface UnpinIssueCommentPayload {
    readonly clientMutationId: string | null;
    readonly issueComment: IssueComment | null;
}
/** Autogenerated return type of UnpinIssue. */
export interface UnpinIssuePayload {
    readonly clientMutationId: string | null;
    readonly id: string | null;
    readonly issue: Issue | null;
}
/** Represents an 'unpinned' event on a given issue or pull request. */
export interface UnpinnedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly issue: Issue;
}
/** Autogenerated return type of UnresolveReviewThread. */
export interface UnresolveReviewThreadPayload {
    readonly clientMutationId: string | null;
    readonly thread: PullRequestReviewThread | null;
}
/** Represents an 'unsubscribed' event on a given `Subscribable`. */
export interface UnsubscribedEvent {
    readonly actor: Actor | null;
    readonly createdAt: string;
    readonly id: string;
    readonly subscribable: Subscribable;
}
/** Entities that can be updated. */
export interface Updatable {
    readonly viewerCanUpdate: boolean;
}
/** Comments that can be updated. */
export interface UpdatableComment {
    readonly viewerCannotUpdateReasons: ReadonlyArray<"ARCHIVED" | "DENIED" | "INSUFFICIENT_ACCESS" | "LOCKED" | "LOGIN_REQUIRED" | "MAINTENANCE" | "VERIFIED_EMAIL_REQUIRED">;
}
/** Autogenerated return type of UpdateBranchProtectionRule. */
export interface UpdateBranchProtectionRulePayload {
    readonly branchProtectionRule: BranchProtectionRule | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of UpdateCheckRun. */
export interface UpdateCheckRunPayload {
    readonly checkRun: CheckRun | null;
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of UpdateCheckSuitePreferences. */
export interface UpdateCheckSuitePreferencesPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UpdateDiscussionComment. */
export interface UpdateDiscussionCommentPayload {
    readonly clientMutationId: string | null;
    readonly comment: DiscussionComment | null;
}
/** Autogenerated return type of UpdateDiscussion. */
export interface UpdateDiscussionPayload {
    readonly clientMutationId: string | null;
    readonly discussion: Discussion | null;
}
/** Autogenerated return type of UpdateEnterpriseAdministratorRole. */
export interface UpdateEnterpriseAdministratorRolePayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseAllowPrivateRepositoryForkingSetting. */
export interface UpdateEnterpriseAllowPrivateRepositoryForkingSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseDefaultRepositoryPermissionSetting. */
export interface UpdateEnterpriseDefaultRepositoryPermissionSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseDeployKeySetting. */
export interface UpdateEnterpriseDeployKeySettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanChangeRepositoryVisibilitySetting. */
export interface UpdateEnterpriseMembersCanChangeRepositoryVisibilitySettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanCreateRepositoriesSetting. */
export interface UpdateEnterpriseMembersCanCreateRepositoriesSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanDeleteIssuesSetting. */
export interface UpdateEnterpriseMembersCanDeleteIssuesSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanDeleteRepositoriesSetting. */
export interface UpdateEnterpriseMembersCanDeleteRepositoriesSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanInviteCollaboratorsSetting. */
export interface UpdateEnterpriseMembersCanInviteCollaboratorsSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanMakePurchasesSetting. */
export interface UpdateEnterpriseMembersCanMakePurchasesSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanUpdateProtectedBranchesSetting. */
export interface UpdateEnterpriseMembersCanUpdateProtectedBranchesSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseMembersCanViewDependencyInsightsSetting. */
export interface UpdateEnterpriseMembersCanViewDependencyInsightsSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseOrganizationProjectsSetting. */
export interface UpdateEnterpriseOrganizationProjectsSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseOwnerOrganizationRole. */
export interface UpdateEnterpriseOwnerOrganizationRolePayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseProfile. */
export interface UpdateEnterpriseProfilePayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
}
/** Autogenerated return type of UpdateEnterpriseRepositoryProjectsSetting. */
export interface UpdateEnterpriseRepositoryProjectsSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSetting. */
export interface UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnterpriseTwoFactorAuthenticationRequiredSetting. */
export interface UpdateEnterpriseTwoFactorAuthenticationRequiredSettingPayload {
    readonly clientMutationId: string | null;
    readonly enterprise: Enterprise | null;
    readonly message: string | null;
}
/** Autogenerated return type of UpdateEnvironment. */
export interface UpdateEnvironmentPayload {
    readonly clientMutationId: string | null;
    readonly environment: Environment | null;
}
/** Autogenerated return type of UpdateIpAllowListEnabledSetting. */
export interface UpdateIpAllowListEnabledSettingPayload {
    readonly clientMutationId: string | null;
    readonly owner: App | Enterprise | Organization | null;
}
/** Autogenerated return type of UpdateIpAllowListEntry. */
export interface UpdateIpAllowListEntryPayload {
    readonly clientMutationId: string | null;
    readonly ipAllowListEntry: IpAllowListEntry | null;
}
/** Autogenerated return type of UpdateIpAllowListForInstalledAppsEnabledSetting. */
export interface UpdateIpAllowListForInstalledAppsEnabledSettingPayload {
    readonly clientMutationId: string | null;
    readonly owner: App | Enterprise | Organization | null;
}
/** Autogenerated return type of UpdateIpAllowListUserLevelEnforcementEnabledSetting. */
export interface UpdateIpAllowListUserLevelEnforcementEnabledSettingPayload {
    readonly clientMutationId: string | null;
    readonly owner: App | Enterprise | Organization | null;
}
/** Autogenerated return type of UpdateIssueComment. */
export interface UpdateIssueCommentPayload {
    readonly clientMutationId: string | null;
    readonly issueComment: IssueComment | null;
}
/** Autogenerated return type of UpdateIssueField. */
export interface UpdateIssueFieldPayload {
    readonly clientMutationId: string | null;
    readonly issueField: IssueFieldDate | IssueFieldMultiSelect | IssueFieldNumber | IssueFieldSingleSelect | IssueFieldText | null;
}
/** Autogenerated return type of UpdateIssueFieldValue. */
export interface UpdateIssueFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
    readonly issueFieldValue: IssueFieldDateValue | IssueFieldMultiSelectValue | IssueFieldNumberValue | IssueFieldSingleSelectValue | IssueFieldTextValue | null;
}
/** Autogenerated return type of UpdateIssueIssueType. */
export interface UpdateIssueIssueTypePayload {
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of UpdateIssue. */
export interface UpdateIssuePayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly issue: Issue | null;
}
/** Autogenerated return type of UpdateIssueType. */
export interface UpdateIssueTypePayload {
    readonly clientMutationId: string | null;
    readonly issueType: IssueType | null;
}
/** Autogenerated return type of UpdateLabel. */
export interface UpdateLabelPayload {
    readonly clientMutationId: string | null;
    readonly label: Label | null;
}
/** Autogenerated return type of UpdateNotificationRestrictionSetting. */
export interface UpdateNotificationRestrictionSettingPayload {
    readonly clientMutationId: string | null;
    readonly owner: Enterprise | Organization | null;
}
/** Autogenerated return type of UpdateOrganizationAllowPrivateRepositoryForkingSetting. */
export interface UpdateOrganizationAllowPrivateRepositoryForkingSettingPayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
    readonly organization: Organization | null;
}
/** Autogenerated return type of UpdateOrganizationWebCommitSignoffSetting. */
export interface UpdateOrganizationWebCommitSignoffSettingPayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
    readonly organization: Organization | null;
}
/** Only allow users with bypass permission to update matching refs. */
export interface UpdateParameters {
    readonly updateAllowsFetchAndMerge: boolean;
}
/** Autogenerated return type of UpdatePatreonSponsorability. */
export interface UpdatePatreonSponsorabilityPayload {
    readonly clientMutationId: string | null;
    readonly sponsorsListing: SponsorsListing | null;
}
/** Autogenerated return type of UpdateProjectCard. */
export interface UpdateProjectCardPayload {
    readonly clientMutationId: string | null;
    readonly projectCard: ProjectCard | null;
}
/** Autogenerated return type of UpdateProjectColumn. */
export interface UpdateProjectColumnPayload {
    readonly clientMutationId: string | null;
    readonly projectColumn: ProjectColumn | null;
}
/** Autogenerated return type of UpdateProject. */
export interface UpdateProjectPayload {
    readonly clientMutationId: string | null;
    readonly project: Project | null;
}
/** Autogenerated return type of UpdateProjectV2Collaborators. */
export interface UpdateProjectV2CollaboratorsPayload {
    readonly clientMutationId: string | null;
    readonly collaborators: ReadonlyArray<Team | User> | null;
}
/** Autogenerated return type of UpdateProjectV2DraftIssue. */
export interface UpdateProjectV2DraftIssuePayload {
    readonly clientMutationId: string | null;
    readonly draftIssue: DraftIssue | null;
}
/** Autogenerated return type of UpdateProjectV2Field. */
export interface UpdateProjectV2FieldPayload {
    readonly clientMutationId: string | null;
    readonly projectV2Field: ProjectV2Field | ProjectV2IterationField | ProjectV2MultiSelectField | ProjectV2SingleSelectField | null;
}
/** Autogenerated return type of UpdateProjectV2ItemFieldValue. */
export interface UpdateProjectV2ItemFieldValuePayload {
    readonly clientMutationId: string | null;
    readonly projectV2Item: ProjectV2Item | null;
}
/** Autogenerated return type of UpdateProjectV2ItemPosition. */
export interface UpdateProjectV2ItemPositionPayload {
    readonly clientMutationId: string | null;
    readonly items: ReadonlyArray<ProjectV2Item> | null;
}
/** Autogenerated return type of UpdateProjectV2. */
export interface UpdateProjectV2Payload {
    readonly clientMutationId: string | null;
    readonly projectV2: ProjectV2 | null;
}
/** Autogenerated return type of UpdateProjectV2StatusUpdate. */
export interface UpdateProjectV2StatusUpdatePayload {
    readonly clientMutationId: string | null;
    readonly statusUpdate: ProjectV2StatusUpdate | null;
}
/** Autogenerated return type of UpdateProjectV2View. */
export interface UpdateProjectV2ViewPayload {
    readonly clientMutationId: string | null;
    readonly projectV2View: ProjectV2View | null;
}
/** Autogenerated return type of UpdatePullRequestBranch. */
export interface UpdatePullRequestBranchPayload {
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of UpdatePullRequest. */
export interface UpdatePullRequestPayload {
    readonly actor: Actor | null;
    readonly clientMutationId: string | null;
    readonly pullRequest: PullRequest | null;
}
/** Autogenerated return type of UpdatePullRequestReviewComment. */
export interface UpdatePullRequestReviewCommentPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReviewComment: PullRequestReviewComment | null;
}
/** Autogenerated return type of UpdatePullRequestReview. */
export interface UpdatePullRequestReviewPayload {
    readonly clientMutationId: string | null;
    readonly pullRequestReview: PullRequestReview | null;
}
/** Autogenerated return type of UpdateRef. */
export interface UpdateRefPayload {
    readonly clientMutationId: string | null;
    readonly ref: Ref | null;
}
/** Autogenerated return type of UpdateRefs. */
export interface UpdateRefsPayload {
    readonly clientMutationId: string | null;
}
/** Autogenerated return type of UpdateRepositoryCustomProperty. */
export interface UpdateRepositoryCustomPropertyPayload {
    readonly clientMutationId: string | null;
    readonly repositoryCustomProperty: RepositoryCustomProperty | null;
}
/** Autogenerated return type of UpdateRepository. */
export interface UpdateRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UpdateRepositoryRuleset. */
export interface UpdateRepositoryRulesetPayload {
    readonly clientMutationId: string | null;
    readonly ruleset: RepositoryRuleset | null;
}
/** Autogenerated return type of UpdateRepositoryWebCommitSignoffSetting. */
export interface UpdateRepositoryWebCommitSignoffSettingPayload {
    readonly clientMutationId: string | null;
    readonly message: string | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UpdateSponsorshipPreferences. */
export interface UpdateSponsorshipPreferencesPayload {
    readonly clientMutationId: string | null;
    readonly sponsorship: Sponsorship | null;
}
/** Autogenerated return type of UpdateSubscription. */
export interface UpdateSubscriptionPayload {
    readonly clientMutationId: string | null;
    readonly subscribable: Subscribable | null;
}
/** Autogenerated return type of UpdateTeamReviewAssignment. */
export interface UpdateTeamReviewAssignmentPayload {
    readonly clientMutationId: string | null;
    readonly team: Team | null;
}
/** Autogenerated return type of UpdateTeamsRepository. */
export interface UpdateTeamsRepositoryPayload {
    readonly clientMutationId: string | null;
    readonly repository: Repository | null;
    readonly teams: ReadonlyArray<Team> | null;
}
/** Autogenerated return type of UpdateTopics. */
export interface UpdateTopicsPayload {
    readonly clientMutationId: string | null;
    readonly invalidTopicNames: ReadonlyArray<string> | null;
    readonly repository: Repository | null;
}
/** Autogenerated return type of UpdateUserList. */
export interface UpdateUserListPayload {
    readonly clientMutationId: string | null;
    readonly list: UserList | null;
}
/** Autogenerated return type of UpdateUserListsForItem. */
export interface UpdateUserListsForItemPayload {
    readonly clientMutationId: string | null;
    readonly item: Repository | null;
    readonly lists: ReadonlyArray<UserList> | null;
    readonly user: User | null;
}
/** A user is an individual's account on GitHub that owns repositories and can make new content. */
export interface User {
    readonly anyPinnableItems: FieldWithArgs<boolean, {
        readonly type?: "GIST" | "ISSUE" | "ORGANIZATION" | "PROJECT" | "PULL_REQUEST" | "REPOSITORY" | "TEAM" | "USER" | null | undefined;
    }, false>;
    readonly avatarUrl: FieldWithArgs<string, {
        readonly size?: number | null | undefined;
    }, false>;
    readonly bio: string | null;
    readonly bioHTML: string;
    readonly canReceiveOrganizationEmailsWhenNotificationsRestricted: FieldWithArgs<boolean, {
        readonly login: string;
    }>;
    readonly commitComments: ReadonlyArray<CommitComment>;
    readonly company: string | null;
    readonly companyHTML: string;
    readonly contributionsCollection: FieldWithArgs<ContributionsCollection, {
        readonly from?: string | null | undefined;
        readonly organizationID?: string | null | undefined;
        readonly to?: string | null | undefined;
    }, false>;
    readonly copilotEndpoints: CopilotEndpoints | null;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly email: string;
    readonly enterprises: ReadonlyArray<Enterprise> | null;
    readonly estimatedNextSponsorsPayoutInCents: number;
    readonly followers: ReadonlyArray<User>;
    readonly following: ReadonlyArray<User>;
    readonly gist: FieldWithArgs<Gist | null, {
        readonly name: string;
    }>;
    readonly gistComments: ReadonlyArray<GistComment>;
    readonly gists: ReadonlyArray<Gist>;
    readonly hasSponsorsListing: boolean;
    readonly hovercard: FieldWithArgs<Hovercard, {
        readonly primarySubjectId?: string | null | undefined;
    }, false>;
    readonly id: string;
    readonly interactionAbility: RepositoryInteractionAbility | null;
    readonly isBountyHunter: boolean;
    readonly isCampusExpert: boolean;
    readonly isDeveloperProgramMember: boolean;
    readonly isEmployee: boolean;
    readonly isFollowingViewer: boolean;
    readonly isGitHubStar: boolean;
    readonly isHireable: boolean;
    readonly isSiteAdmin: boolean;
    readonly isSponsoredBy: FieldWithArgs<boolean, {
        readonly accountLogin: string;
    }>;
    readonly isSponsoringViewer: boolean;
    readonly issueComments: ReadonlyArray<IssueComment>;
    readonly issues: ReadonlyArray<Issue>;
    readonly isViewer: boolean;
    readonly itemShowcase: ProfileItemShowcase;
    readonly lifetimeReceivedSponsorshipValues: ReadonlyArray<SponsorAndLifetimeValue>;
    readonly lists: ReadonlyArray<UserList>;
    readonly location: string | null;
    readonly login: string;
    readonly monthlyEstimatedSponsorsIncomeInCents: number;
    readonly name: string | null;
    readonly organization: FieldWithArgs<Organization | null, {
        readonly login: string;
    }>;
    readonly organizations: ReadonlyArray<Organization>;
    readonly organizationVerifiedDomainEmails: ReadonlyArray<string>;
    readonly packages: ReadonlyArray<Package>;
    readonly pinnableItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedItems: ReadonlyArray<Gist | Repository>;
    readonly pinnedItemsRemaining: number;
    readonly project: FieldWithArgs<Project | null, {
        readonly number: number;
    }>;
    readonly projects: ReadonlyArray<Project>;
    readonly projectsResourcePath: string;
    readonly projectsUrl: string;
    readonly projectsV2: ReadonlyArray<ProjectV2>;
    readonly projectV2: FieldWithArgs<ProjectV2 | null, {
        readonly number: number;
    }>;
    readonly pronouns: string | null;
    readonly publicKeys: ReadonlyArray<PublicKey>;
    readonly pullRequests: ReadonlyArray<PullRequest>;
    readonly recentProjects: ReadonlyArray<ProjectV2>;
    readonly repositories: ReadonlyArray<Repository>;
    readonly repositoriesContributedTo: ReadonlyArray<Repository>;
    readonly repository: FieldWithArgs<Repository | null, {
        readonly name: string;
        readonly followRenames?: boolean | null | undefined;
    }>;
    readonly repositoryDiscussionComments: ReadonlyArray<DiscussionComment>;
    readonly repositoryDiscussions: ReadonlyArray<Discussion>;
    readonly resourcePath: string;
    readonly savedReplies: ReadonlyArray<SavedReply> | null;
    readonly socialAccounts: ReadonlyArray<SocialAccount>;
    readonly sponsoring: ReadonlyArray<Organization | User>;
    readonly sponsors: ReadonlyArray<Organization | User>;
    readonly sponsorsActivities: ReadonlyArray<SponsorsActivity>;
    readonly sponsorshipForViewerAsSponsor: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipForViewerAsSponsorable: FieldWithArgs<Sponsorship | null, {
        readonly activeOnly?: boolean | null | undefined;
    }, false>;
    readonly sponsorshipNewsletters: ReadonlyArray<SponsorshipNewsletter>;
    readonly sponsorshipsAsMaintainer: ReadonlyArray<Sponsorship>;
    readonly sponsorshipsAsSponsor: ReadonlyArray<Sponsorship>;
    readonly sponsorsListing: SponsorsListing | null;
    readonly starredRepositories: ReadonlyArray<Repository>;
    readonly status: UserStatus | null;
    readonly suggestedListNames: ReadonlyArray<UserListSuggestion>;
    readonly topRepositories: ReadonlyArray<Repository>;
    readonly totalSponsorshipAmountAsSponsorInCents: FieldWithArgs<number | null, {
        readonly since?: string | null | undefined;
        readonly sponsorableLogins?: ReadonlyArray<string> | null | undefined;
        readonly until?: string | null | undefined;
    }, false>;
    readonly twitterUsername: string | null;
    readonly updatedAt: string;
    readonly url: string;
    readonly userViewType: "PRIVATE" | "PUBLIC";
    readonly viewerCanChangePinnedItems: boolean;
    readonly viewerCanCreateProjects: boolean;
    readonly viewerCanFollow: boolean;
    readonly viewerCanSponsor: boolean;
    readonly viewerCopilotAgentCreatesChannel: string | null;
    readonly viewerCopilotAgentLogUpdatesChannel: string | null;
    readonly viewerCopilotAgentTaskUpdatesChannel: string | null;
    readonly viewerCopilotAgentUpdatesChannel: string | null;
    readonly viewerIsFollowing: boolean;
    readonly viewerIsSponsoring: boolean;
    readonly watching: ReadonlyArray<Repository>;
    readonly websiteUrl: string | null;
}
/** Represents a 'user_blocked' event on a given user. */
export interface UserBlockedEvent {
    readonly actor: Actor | null;
    readonly blockDuration: "ONE_DAY" | "ONE_MONTH" | "ONE_WEEK" | "PERMANENT" | "THREE_DAYS";
    readonly createdAt: string;
    readonly id: string;
    readonly subject: User | null;
}
/** A list of users. */
export interface UserConnection {
    readonly edges: ReadonlyArray<UserEdge | null> | null;
    readonly nodes: ReadonlyArray<User | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edit on user content */
export interface UserContentEdit {
    readonly createdAt: string;
    readonly deletedAt: string | null;
    readonly deletedBy: Actor | null;
    readonly diff: string | null;
    readonly editedAt: string;
    readonly editor: Actor | null;
    readonly id: string;
    readonly updatedAt: string;
}
/** A list of edits to content. */
export interface UserContentEditConnection {
    readonly edges: ReadonlyArray<UserContentEditEdge | null> | null;
    readonly nodes: ReadonlyArray<UserContentEdit | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface UserContentEditEdge {
    readonly cursor: string;
    readonly node: UserContentEdit | null;
}
/** Represents a user. */
export interface UserEdge {
    readonly cursor: string;
    readonly node: User | null;
}
/** Email attributes from External Identity */
export interface UserEmailMetadata {
    readonly primary: boolean | null;
    readonly type: string | null;
    readonly value: string;
}
/** A user-curated list of repositories */
export interface UserList {
    readonly createdAt: string;
    readonly description: string | null;
    readonly id: string;
    readonly isPrivate: boolean;
    readonly items: ReadonlyArray<Repository>;
    readonly lastAddedAt: string;
    readonly name: string;
    readonly slug: string;
    readonly updatedAt: string;
    readonly user: User;
}
/** The connection type for UserList. */
export interface UserListConnection {
    readonly edges: ReadonlyArray<UserListEdge | null> | null;
    readonly nodes: ReadonlyArray<UserList | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface UserListEdge {
    readonly cursor: string;
    readonly node: UserList | null;
}
/** The connection type for UserListItems. */
export interface UserListItemsConnection {
    readonly edges: ReadonlyArray<UserListItemsEdge | null> | null;
    readonly nodes: ReadonlyArray<Repository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface UserListItemsEdge {
    readonly cursor: string;
    readonly node: Repository | null;
}
/** Represents a suggested user list. */
export interface UserListSuggestion {
    readonly id: string | null;
    readonly name: string | null;
}
/** A repository owned by an Enterprise Managed user. */
export interface UserNamespaceRepository {
    readonly id: string;
    readonly name: string;
    readonly nameWithOwner: string;
    readonly owner: RepositoryOwner;
}
/** A list of repositories owned by users in an enterprise with Enterprise Managed Users. */
export interface UserNamespaceRepositoryConnection {
    readonly edges: ReadonlyArray<UserNamespaceRepositoryEdge | null> | null;
    readonly nodes: ReadonlyArray<UserNamespaceRepository | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface UserNamespaceRepositoryEdge {
    readonly cursor: string;
    readonly node: UserNamespaceRepository | null;
}
/** The user's description of what they're currently doing. */
export interface UserStatus {
    readonly createdAt: string;
    readonly emoji: string | null;
    readonly emojiHTML: string | null;
    readonly expiresAt: string | null;
    readonly id: string;
    readonly indicatesLimitedAvailability: boolean;
    readonly message: string | null;
    readonly organization: Organization | null;
    readonly updatedAt: string;
    readonly user: User;
}
/** The connection type for UserStatus. */
export interface UserStatusConnection {
    readonly edges: ReadonlyArray<UserStatusEdge | null> | null;
    readonly nodes: ReadonlyArray<UserStatus | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface UserStatusEdge {
    readonly cursor: string;
    readonly node: UserStatus | null;
}
/** A domain that can be verified or approved for an organization or an enterprise. */
export interface VerifiableDomain {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly dnsHostName: string | null;
    readonly domain: string;
    readonly hasFoundHostName: boolean;
    readonly hasFoundVerificationToken: boolean;
    readonly id: string;
    readonly isApproved: boolean;
    readonly isRequiredForPolicyEnforcement: boolean;
    readonly isVerified: boolean;
    readonly owner: Enterprise | Organization;
    readonly punycodeEncodedDomain: string;
    readonly tokenExpirationTime: string | null;
    readonly updatedAt: string;
    readonly verificationToken: string | null;
}
/** The connection type for VerifiableDomain. */
export interface VerifiableDomainConnection {
    readonly edges: ReadonlyArray<VerifiableDomainEdge | null> | null;
    readonly nodes: ReadonlyArray<VerifiableDomain | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface VerifiableDomainEdge {
    readonly cursor: string;
    readonly node: VerifiableDomain | null;
}
/** Autogenerated return type of VerifyVerifiableDomain. */
export interface VerifyVerifiableDomainPayload {
    readonly clientMutationId: string | null;
    readonly domain: VerifiableDomain | null;
}
/** A hovercard context with a message describing how the viewer is related. */
export interface ViewerHovercardContext {
    readonly message: string;
    readonly octicon: string;
    readonly viewer: User;
}
/** A subject that may be upvoted. */
export interface Votable {
    readonly upvoteCount: number;
    readonly viewerCanUpvote: boolean;
    readonly viewerHasUpvoted: boolean;
}
/** A workflow contains meta information about an Actions workflow file. */
export interface Workflow {
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly id: string;
    readonly name: string;
    readonly resourcePath: string;
    readonly runs: ReadonlyArray<WorkflowRun>;
    readonly state: "ACTIVE" | "DELETED" | "DISABLED_FORK" | "DISABLED_INACTIVITY" | "DISABLED_MANUALLY";
    readonly updatedAt: string;
    readonly url: string;
}
/** A workflow that must run for this rule to pass */
export interface WorkflowFileReference {
    readonly path: string;
    readonly ref: string | null;
    readonly repositoryId: number;
    readonly sha: string | null;
}
/** A workflow run. */
export interface WorkflowRun {
    readonly checkSuite: CheckSuite;
    readonly createdAt: string;
    readonly databaseId: number | null;
    readonly deploymentReviews: ReadonlyArray<DeploymentReview>;
    readonly displayTitle: string | null;
    readonly event: string;
    readonly file: WorkflowRunFile | null;
    readonly id: string;
    readonly pendingDeploymentRequests: ReadonlyArray<DeploymentRequest>;
    readonly resourcePath: string;
    readonly runAttempt: number;
    readonly runNumber: number;
    readonly updatedAt: string;
    readonly url: string;
    readonly workflow: Workflow;
}
/** The connection type for WorkflowRun. */
export interface WorkflowRunConnection {
    readonly edges: ReadonlyArray<WorkflowRunEdge | null> | null;
    readonly nodes: ReadonlyArray<WorkflowRun | null> | null;
    readonly pageInfo: PageInfo;
    readonly totalCount: number;
}
/** An edge in a connection. */
export interface WorkflowRunEdge {
    readonly cursor: string;
    readonly node: WorkflowRun | null;
}
/** An executed workflow file for a workflow run. */
export interface WorkflowRunFile {
    readonly id: string;
    readonly path: string;
    readonly repositoryFileUrl: string;
    readonly repositoryName: string;
    readonly resourcePath: string;
    readonly run: WorkflowRun;
    readonly url: string;
    readonly viewerCanPushRepository: boolean;
    readonly viewerCanReadRepository: boolean;
}
/** Require all changes made to a targeted branch to pass the specified workflows before they can be merged. */
export interface WorkflowsParameters {
    readonly doNotEnforceOnCreate: boolean;
    readonly workflows: ReadonlyArray<WorkflowFileReference>;
}
export declare const AbortQueuedMigrationsPayload: TypeMeta;
export declare const AbortRepositoryMigrationPayload: TypeMeta;
export declare const AcceptEnterpriseAdministratorInvitationPayload: TypeMeta;
export declare const AcceptEnterpriseMemberInvitationPayload: TypeMeta;
export declare const AcceptTopicSuggestionPayload: TypeMeta;
export declare const AccessUserNamespaceRepositoryPayload: TypeMeta;
export declare const Actor: TypeMeta;
export declare const ActorConnection: TypeMeta;
export declare const ActorEdge: TypeMeta;
export declare const ActorLocation: TypeMeta;
export declare const AddAssigneesToAssignablePayload: TypeMeta;
export declare const AddBlockedByPayload: TypeMeta;
export declare const AddCloseIssueReferencesPayload: TypeMeta;
export declare const AddCommentPayload: TypeMeta;
export declare const AddDiscussionCommentPayload: TypeMeta;
export declare const AddDiscussionPollVotePayload: TypeMeta;
export declare const AddEnterpriseOrganizationMemberPayload: TypeMeta;
export declare const AddEnterpriseSupportEntitlementPayload: TypeMeta;
export declare const AddLabelsToLabelablePayload: TypeMeta;
export declare const AddProjectCardPayload: TypeMeta;
export declare const AddProjectColumnPayload: TypeMeta;
export declare const AddProjectV2DraftIssuePayload: TypeMeta;
export declare const AddProjectV2ItemByIdPayload: TypeMeta;
export declare const AddPullRequestCreationCapBypassUsersPayload: TypeMeta;
export declare const AddPullRequestReviewCommentPayload: TypeMeta;
export declare const AddPullRequestReviewPayload: TypeMeta;
export declare const AddPullRequestReviewThreadPayload: TypeMeta;
export declare const AddPullRequestReviewThreadReplyPayload: TypeMeta;
export declare const AddReactionPayload: TypeMeta;
export declare const AddRelatesToPayload: TypeMeta;
export declare const AddStarPayload: TypeMeta;
export declare const AddSubIssuePayload: TypeMeta;
export declare const AddUpvotePayload: TypeMeta;
export declare const AddVerifiableDomainPayload: TypeMeta;
export declare const AddedToMergeQueueEvent: TypeMeta;
export declare const AddedToProjectEvent: TypeMeta;
export declare const AddedToProjectV2Event: TypeMeta;
export declare const AddedToStackEvent: TypeMeta;
export declare const Agentic: TypeMeta;
export declare const AnnouncementBanner: TypeMeta;
export declare const App: TypeMeta;
export declare const ApplyPendingIssueSuggestionsPayload: TypeMeta;
export declare const ApproveDeploymentsPayload: TypeMeta;
export declare const ApproveVerifiableDomainPayload: TypeMeta;
export declare const ArchiveProjectV2ItemPayload: TypeMeta;
export declare const ArchivePullRequestPayload: TypeMeta;
export declare const ArchiveRepositoryPayload: TypeMeta;
export declare const Assignable: TypeMeta;
export declare const AssignedEvent: TypeMeta;
export declare const AssigneeConnection: TypeMeta;
export declare const AssigneeEdge: TypeMeta;
export declare const AuditEntry: TypeMeta;
export declare const AutoMergeDisabledEvent: TypeMeta;
export declare const AutoMergeEnabledEvent: TypeMeta;
export declare const AutoMergeRequest: TypeMeta;
export declare const AutoRebaseEnabledEvent: TypeMeta;
export declare const AutoSquashEnabledEvent: TypeMeta;
export declare const AutomaticBaseChangeFailedEvent: TypeMeta;
export declare const AutomaticBaseChangeSucceededEvent: TypeMeta;
export declare const BaseRefChangedEvent: TypeMeta;
export declare const BaseRefDeletedEvent: TypeMeta;
export declare const BaseRefForcePushedEvent: TypeMeta;
export declare const Blame: TypeMeta;
export declare const BlameRange: TypeMeta;
export declare const Blob: TypeMeta;
export declare const BlockedByAddedEvent: TypeMeta;
export declare const BlockedByRemovedEvent: TypeMeta;
export declare const BlockingAddedEvent: TypeMeta;
export declare const BlockingRemovedEvent: TypeMeta;
export declare const Bot: TypeMeta;
export declare const BranchNamePatternParameters: TypeMeta;
export declare const BranchProtectionRule: TypeMeta;
export declare const BranchProtectionRuleConflict: TypeMeta;
export declare const BranchProtectionRuleConflictConnection: TypeMeta;
export declare const BranchProtectionRuleConflictEdge: TypeMeta;
export declare const BranchProtectionRuleConnection: TypeMeta;
export declare const BranchProtectionRuleEdge: TypeMeta;
export declare const BypassForcePushAllowance: TypeMeta;
export declare const BypassForcePushAllowanceConnection: TypeMeta;
export declare const BypassForcePushAllowanceEdge: TypeMeta;
export declare const BypassPullRequestAllowance: TypeMeta;
export declare const BypassPullRequestAllowanceConnection: TypeMeta;
export declare const BypassPullRequestAllowanceEdge: TypeMeta;
export declare const CVSS: TypeMeta;
export declare const CWE: TypeMeta;
export declare const CWEConnection: TypeMeta;
export declare const CWEEdge: TypeMeta;
export declare const CancelEnterpriseAdminInvitationPayload: TypeMeta;
export declare const CancelEnterpriseMemberInvitationPayload: TypeMeta;
export declare const CancelSponsorshipPayload: TypeMeta;
export declare const ChangeUserStatusPayload: TypeMeta;
export declare const CheckAnnotation: TypeMeta;
export declare const CheckAnnotationConnection: TypeMeta;
export declare const CheckAnnotationEdge: TypeMeta;
export declare const CheckAnnotationPosition: TypeMeta;
export declare const CheckAnnotationSpan: TypeMeta;
export declare const CheckRun: TypeMeta;
export declare const CheckRunConnection: TypeMeta;
export declare const CheckRunEdge: TypeMeta;
export declare const CheckRunStateCount: TypeMeta;
export declare const CheckStep: TypeMeta;
export declare const CheckStepConnection: TypeMeta;
export declare const CheckStepEdge: TypeMeta;
export declare const CheckSuite: TypeMeta;
export declare const CheckSuiteConnection: TypeMeta;
export declare const CheckSuiteEdge: TypeMeta;
export declare const ClearLabelsFromLabelablePayload: TypeMeta;
export declare const ClearProjectV2ItemFieldValuePayload: TypeMeta;
export declare const CloneProjectPayload: TypeMeta;
export declare const CloneTemplateRepositoryPayload: TypeMeta;
export declare const Closable: TypeMeta;
export declare const CloseDiscussionPayload: TypeMeta;
export declare const CloseIssuePayload: TypeMeta;
export declare const ClosePullRequestPayload: TypeMeta;
export declare const ClosedEvent: TypeMeta;
export declare const CodeCoverageParameters: TypeMeta;
export declare const CodeOfConduct: TypeMeta;
export declare const CodeQualityParameters: TypeMeta;
export declare const CodeScanningParameters: TypeMeta;
export declare const CodeScanningTool: TypeMeta;
export declare const Comment: TypeMeta;
export declare const CommentDeletedEvent: TypeMeta;
export declare const Commit: TypeMeta;
export declare const CommitAuthorEmailPatternParameters: TypeMeta;
export declare const CommitComment: TypeMeta;
export declare const CommitCommentConnection: TypeMeta;
export declare const CommitCommentEdge: TypeMeta;
export declare const CommitCommentThread: TypeMeta;
export declare const CommitConnection: TypeMeta;
export declare const CommitContributionsByRepository: TypeMeta;
export declare const CommitEdge: TypeMeta;
export declare const CommitHistoryConnection: TypeMeta;
export declare const CommitMessagePatternParameters: TypeMeta;
export declare const CommitterEmailPatternParameters: TypeMeta;
export declare const Comparison: TypeMeta;
export declare const ComparisonCommitConnection: TypeMeta;
export declare const ConnectedEvent: TypeMeta;
export declare const ContentWarning: TypeMeta;
export declare const ContributingGuidelines: TypeMeta;
export declare const Contribution: TypeMeta;
export declare const ContributionCalendar: TypeMeta;
export declare const ContributionCalendarDay: TypeMeta;
export declare const ContributionCalendarMonth: TypeMeta;
export declare const ContributionCalendarWeek: TypeMeta;
export declare const ContributionsCollection: TypeMeta;
export declare const ConvertProjectCardNoteToIssuePayload: TypeMeta;
export declare const ConvertProjectV2DraftIssueItemToIssuePayload: TypeMeta;
export declare const ConvertPullRequestToDraftPayload: TypeMeta;
export declare const ConvertToDraftEvent: TypeMeta;
export declare const ConvertedFromDraftEvent: TypeMeta;
export declare const ConvertedNoteToIssueEvent: TypeMeta;
export declare const ConvertedToDiscussionEvent: TypeMeta;
export declare const CopilotCodeReviewParameters: TypeMeta;
export declare const CopilotEndpoints: TypeMeta;
export declare const CopyProjectV2Payload: TypeMeta;
export declare const CreateAttributionInvitationPayload: TypeMeta;
export declare const CreateBranchProtectionRulePayload: TypeMeta;
export declare const CreateCheckRunPayload: TypeMeta;
export declare const CreateCheckSuitePayload: TypeMeta;
export declare const CreateCommitOnBranchPayload: TypeMeta;
export declare const CreateDeploymentPayload: TypeMeta;
export declare const CreateDeploymentStatusPayload: TypeMeta;
export declare const CreateDiscussionPayload: TypeMeta;
export declare const CreateEnterpriseOrganizationPayload: TypeMeta;
export declare const CreateEnvironmentPayload: TypeMeta;
export declare const CreateIpAllowListEntryPayload: TypeMeta;
export declare const CreateIssueFieldPayload: TypeMeta;
export declare const CreateIssueFieldValuePayload: TypeMeta;
export declare const CreateIssuePayload: TypeMeta;
export declare const CreateIssueTypePayload: TypeMeta;
export declare const CreateLabelPayload: TypeMeta;
export declare const CreateLinkedBranchPayload: TypeMeta;
export declare const CreateMigrationSourcePayload: TypeMeta;
export declare const CreateProjectPayload: TypeMeta;
export declare const CreateProjectV2FieldPayload: TypeMeta;
export declare const CreateProjectV2IssueFieldPayload: TypeMeta;
export declare const CreateProjectV2Payload: TypeMeta;
export declare const CreateProjectV2StatusUpdatePayload: TypeMeta;
export declare const CreateProjectV2ViewPayload: TypeMeta;
export declare const CreatePullRequestPayload: TypeMeta;
export declare const CreateRefPayload: TypeMeta;
export declare const CreateRepositoryCustomPropertyPayload: TypeMeta;
export declare const CreateRepositoryPayload: TypeMeta;
export declare const CreateRepositoryRulesetPayload: TypeMeta;
export declare const CreateSponsorsListingPayload: TypeMeta;
export declare const CreateSponsorsTierPayload: TypeMeta;
export declare const CreateSponsorshipPayload: TypeMeta;
export declare const CreateSponsorshipsPayload: TypeMeta;
export declare const CreateUserListPayload: TypeMeta;
export declare const CreatedCommitContribution: TypeMeta;
export declare const CreatedCommitContributionConnection: TypeMeta;
export declare const CreatedCommitContributionEdge: TypeMeta;
export declare const CreatedIssueContribution: TypeMeta;
export declare const CreatedIssueContributionConnection: TypeMeta;
export declare const CreatedIssueContributionEdge: TypeMeta;
export declare const CreatedPullRequestContribution: TypeMeta;
export declare const CreatedPullRequestContributionConnection: TypeMeta;
export declare const CreatedPullRequestContributionEdge: TypeMeta;
export declare const CreatedPullRequestReviewContribution: TypeMeta;
export declare const CreatedPullRequestReviewContributionConnection: TypeMeta;
export declare const CreatedPullRequestReviewContributionEdge: TypeMeta;
export declare const CreatedRepositoryContribution: TypeMeta;
export declare const CreatedRepositoryContributionConnection: TypeMeta;
export declare const CreatedRepositoryContributionEdge: TypeMeta;
export declare const CrossReferencedEvent: TypeMeta;
export declare const CvssSeverities: TypeMeta;
export declare const DeclineTopicSuggestionPayload: TypeMeta;
export declare const Deletable: TypeMeta;
export declare const DeleteBranchProtectionRulePayload: TypeMeta;
export declare const DeleteDeploymentPayload: TypeMeta;
export declare const DeleteDiscussionCommentPayload: TypeMeta;
export declare const DeleteDiscussionPayload: TypeMeta;
export declare const DeleteEnvironmentPayload: TypeMeta;
export declare const DeleteIpAllowListEntryPayload: TypeMeta;
export declare const DeleteIssueCommentPayload: TypeMeta;
export declare const DeleteIssueFieldPayload: TypeMeta;
export declare const DeleteIssueFieldValuePayload: TypeMeta;
export declare const DeleteIssuePayload: TypeMeta;
export declare const DeleteIssueTypePayload: TypeMeta;
export declare const DeleteLabelPayload: TypeMeta;
export declare const DeleteLinkedBranchPayload: TypeMeta;
export declare const DeletePackageVersionPayload: TypeMeta;
export declare const DeleteProjectCardPayload: TypeMeta;
export declare const DeleteProjectColumnPayload: TypeMeta;
export declare const DeleteProjectPayload: TypeMeta;
export declare const DeleteProjectV2FieldPayload: TypeMeta;
export declare const DeleteProjectV2ItemPayload: TypeMeta;
export declare const DeleteProjectV2Payload: TypeMeta;
export declare const DeleteProjectV2StatusUpdatePayload: TypeMeta;
export declare const DeleteProjectV2ViewPayload: TypeMeta;
export declare const DeleteProjectV2WorkflowPayload: TypeMeta;
export declare const DeletePullRequestReviewCommentPayload: TypeMeta;
export declare const DeletePullRequestReviewPayload: TypeMeta;
export declare const DeleteRefPayload: TypeMeta;
export declare const DeleteRepositoryCustomPropertyPayload: TypeMeta;
export declare const DeleteRepositoryRulesetPayload: TypeMeta;
export declare const DeleteUserListPayload: TypeMeta;
export declare const DeleteVerifiableDomainPayload: TypeMeta;
export declare const DemilestonedEvent: TypeMeta;
export declare const DependabotUpdate: TypeMeta;
export declare const DependabotUpdateError: TypeMeta;
export declare const DependencyGraphDependency: TypeMeta;
export declare const DependencyGraphDependencyConnection: TypeMeta;
export declare const DependencyGraphDependencyEdge: TypeMeta;
export declare const DependencyGraphManifest: TypeMeta;
export declare const DependencyGraphManifestConnection: TypeMeta;
export declare const DependencyGraphManifestEdge: TypeMeta;
export declare const DeployKey: TypeMeta;
export declare const DeployKeyConnection: TypeMeta;
export declare const DeployKeyEdge: TypeMeta;
export declare const DeployedEvent: TypeMeta;
export declare const Deployment: TypeMeta;
export declare const DeploymentConnection: TypeMeta;
export declare const DeploymentEdge: TypeMeta;
export declare const DeploymentEnvironmentChangedEvent: TypeMeta;
export declare const DeploymentProtectionRule: TypeMeta;
export declare const DeploymentProtectionRuleConnection: TypeMeta;
export declare const DeploymentProtectionRuleEdge: TypeMeta;
export declare const DeploymentRequest: TypeMeta;
export declare const DeploymentRequestConnection: TypeMeta;
export declare const DeploymentRequestEdge: TypeMeta;
export declare const DeploymentReview: TypeMeta;
export declare const DeploymentReviewConnection: TypeMeta;
export declare const DeploymentReviewEdge: TypeMeta;
export declare const DeploymentReviewerConnection: TypeMeta;
export declare const DeploymentReviewerEdge: TypeMeta;
export declare const DeploymentStatus: TypeMeta;
export declare const DeploymentStatusConnection: TypeMeta;
export declare const DeploymentStatusEdge: TypeMeta;
export declare const DequeuePullRequestPayload: TypeMeta;
export declare const DisablePullRequestAutoMergePayload: TypeMeta;
export declare const DisconnectedEvent: TypeMeta;
export declare const Discussion: TypeMeta;
export declare const DiscussionCategory: TypeMeta;
export declare const DiscussionCategoryConnection: TypeMeta;
export declare const DiscussionCategoryEdge: TypeMeta;
export declare const DiscussionComment: TypeMeta;
export declare const DiscussionCommentConnection: TypeMeta;
export declare const DiscussionCommentEdge: TypeMeta;
export declare const DiscussionConnection: TypeMeta;
export declare const DiscussionEdge: TypeMeta;
export declare const DiscussionPoll: TypeMeta;
export declare const DiscussionPollOption: TypeMeta;
export declare const DiscussionPollOptionConnection: TypeMeta;
export declare const DiscussionPollOptionEdge: TypeMeta;
export declare const DismissPullRequestReviewPayload: TypeMeta;
export declare const DismissRepositoryVulnerabilityAlertPayload: TypeMeta;
export declare const DismissalRestriction: TypeMeta;
export declare const DraftIssue: TypeMeta;
export declare const EPSS: TypeMeta;
export declare const EnablePullRequestAutoMergePayload: TypeMeta;
export declare const EnqueuePullRequestPayload: TypeMeta;
export declare const Enterprise: TypeMeta;
export declare const EnterpriseAdministratorConnection: TypeMeta;
export declare const EnterpriseAdministratorEdge: TypeMeta;
export declare const EnterpriseAdministratorInvitation: TypeMeta;
export declare const EnterpriseAdministratorInvitationConnection: TypeMeta;
export declare const EnterpriseAdministratorInvitationEdge: TypeMeta;
export declare const EnterpriseAuditEntryData: TypeMeta;
export declare const EnterpriseBillingInfo: TypeMeta;
export declare const EnterpriseConnection: TypeMeta;
export declare const EnterpriseEdge: TypeMeta;
export declare const EnterpriseFailedInvitationConnection: TypeMeta;
export declare const EnterpriseFailedInvitationEdge: TypeMeta;
export declare const EnterpriseIdentityProvider: TypeMeta;
export declare const EnterpriseMemberConnection: TypeMeta;
export declare const EnterpriseMemberEdge: TypeMeta;
export declare const EnterpriseMemberInvitation: TypeMeta;
export declare const EnterpriseMemberInvitationConnection: TypeMeta;
export declare const EnterpriseMemberInvitationEdge: TypeMeta;
export declare const EnterpriseOrganizationMembershipConnection: TypeMeta;
export declare const EnterpriseOrganizationMembershipEdge: TypeMeta;
export declare const EnterpriseOutsideCollaboratorConnection: TypeMeta;
export declare const EnterpriseOutsideCollaboratorEdge: TypeMeta;
export declare const EnterpriseOwnerInfo: TypeMeta;
export declare const EnterprisePendingMemberInvitationConnection: TypeMeta;
export declare const EnterprisePendingMemberInvitationEdge: TypeMeta;
export declare const EnterpriseRepositoryInfo: TypeMeta;
export declare const EnterpriseRepositoryInfoConnection: TypeMeta;
export declare const EnterpriseRepositoryInfoEdge: TypeMeta;
export declare const EnterpriseServerInstallation: TypeMeta;
export declare const EnterpriseServerInstallationConnection: TypeMeta;
export declare const EnterpriseServerInstallationEdge: TypeMeta;
export declare const EnterpriseServerInstallationMembershipConnection: TypeMeta;
export declare const EnterpriseServerInstallationMembershipEdge: TypeMeta;
export declare const EnterpriseServerUserAccount: TypeMeta;
export declare const EnterpriseServerUserAccountConnection: TypeMeta;
export declare const EnterpriseServerUserAccountEdge: TypeMeta;
export declare const EnterpriseServerUserAccountEmail: TypeMeta;
export declare const EnterpriseServerUserAccountEmailConnection: TypeMeta;
export declare const EnterpriseServerUserAccountEmailEdge: TypeMeta;
export declare const EnterpriseServerUserAccountsUpload: TypeMeta;
export declare const EnterpriseServerUserAccountsUploadConnection: TypeMeta;
export declare const EnterpriseServerUserAccountsUploadEdge: TypeMeta;
export declare const EnterpriseTeam: TypeMeta;
export declare const EnterpriseTeamAssignedOrganizationConnection: TypeMeta;
export declare const EnterpriseTeamAssignedOrganizationEdge: TypeMeta;
export declare const EnterpriseTeamConnection: TypeMeta;
export declare const EnterpriseTeamEdge: TypeMeta;
export declare const EnterpriseTeamMemberConnection: TypeMeta;
export declare const EnterpriseTeamMemberEdge: TypeMeta;
export declare const EnterpriseUserAccount: TypeMeta;
export declare const Environment: TypeMeta;
export declare const EnvironmentConnection: TypeMeta;
export declare const EnvironmentEdge: TypeMeta;
export declare const ExternalIdentity: TypeMeta;
export declare const ExternalIdentityAttribute: TypeMeta;
export declare const ExternalIdentityConnection: TypeMeta;
export declare const ExternalIdentityEdge: TypeMeta;
export declare const ExternalIdentitySamlAttributes: TypeMeta;
export declare const ExternalIdentityScimAttributes: TypeMeta;
export declare const FileExtensionRestrictionParameters: TypeMeta;
export declare const FilePathRestrictionParameters: TypeMeta;
export declare const FollowOrganizationPayload: TypeMeta;
export declare const FollowUserPayload: TypeMeta;
export declare const FollowerConnection: TypeMeta;
export declare const FollowingConnection: TypeMeta;
export declare const FundingLink: TypeMeta;
export declare const GenericHovercardContext: TypeMeta;
export declare const Gist: TypeMeta;
export declare const GistComment: TypeMeta;
export declare const GistCommentConnection: TypeMeta;
export declare const GistCommentEdge: TypeMeta;
export declare const GistConnection: TypeMeta;
export declare const GistEdge: TypeMeta;
export declare const GistFile: TypeMeta;
export declare const GitActor: TypeMeta;
export declare const GitActorConnection: TypeMeta;
export declare const GitActorEdge: TypeMeta;
export declare const GitHubMetadata: TypeMeta;
export declare const GitObject: TypeMeta;
export declare const GitSignature: TypeMeta;
export declare const GpgSignature: TypeMeta;
export declare const GrantEnterpriseOrganizationsMigratorRolePayload: TypeMeta;
export declare const GrantMigratorRolePayload: TypeMeta;
export declare const HeadRefDeletedEvent: TypeMeta;
export declare const HeadRefForcePushedEvent: TypeMeta;
export declare const HeadRefRestoredEvent: TypeMeta;
export declare const Hovercard: TypeMeta;
export declare const HovercardContext: TypeMeta;
export declare const ImportProjectPayload: TypeMeta;
export declare const InviteEnterpriseAdminPayload: TypeMeta;
export declare const InviteEnterpriseMemberPayload: TypeMeta;
export declare const IpAllowListEntry: TypeMeta;
export declare const IpAllowListEntryConnection: TypeMeta;
export declare const IpAllowListEntryEdge: TypeMeta;
export declare const Issue: TypeMeta;
export declare const IssueComment: TypeMeta;
export declare const IssueCommentConnection: TypeMeta;
export declare const IssueCommentEdge: TypeMeta;
export declare const IssueCommentPinnedEvent: TypeMeta;
export declare const IssueCommentUnpinnedEvent: TypeMeta;
export declare const IssueConnection: TypeMeta;
export declare const IssueContributionsByRepository: TypeMeta;
export declare const IssueDependenciesSummary: TypeMeta;
export declare const IssueEdge: TypeMeta;
export declare const IssueFieldAddedEvent: TypeMeta;
export declare const IssueFieldChangedEvent: TypeMeta;
export declare const IssueFieldCommon: TypeMeta;
export declare const IssueFieldDate: TypeMeta;
export declare const IssueFieldDateValue: TypeMeta;
export declare const IssueFieldMultiSelect: TypeMeta;
export declare const IssueFieldMultiSelectValue: TypeMeta;
export declare const IssueFieldNumber: TypeMeta;
export declare const IssueFieldNumberValue: TypeMeta;
export declare const IssueFieldRemovedEvent: TypeMeta;
export declare const IssueFieldSingleSelect: TypeMeta;
export declare const IssueFieldSingleSelectOption: TypeMeta;
export declare const IssueFieldSingleSelectValue: TypeMeta;
export declare const IssueFieldText: TypeMeta;
export declare const IssueFieldTextValue: TypeMeta;
export declare const IssueFieldTimelineOption: TypeMeta;
export declare const IssueFieldValueCommon: TypeMeta;
export declare const IssueFieldValueConnection: TypeMeta;
export declare const IssueFieldValueEdge: TypeMeta;
export declare const IssueFieldsConnection: TypeMeta;
export declare const IssueFieldsEdge: TypeMeta;
export declare const IssueTemplate: TypeMeta;
export declare const IssueTimelineConnection: TypeMeta;
export declare const IssueTimelineItemEdge: TypeMeta;
export declare const IssueTimelineItemsConnection: TypeMeta;
export declare const IssueTimelineItemsEdge: TypeMeta;
export declare const IssueType: TypeMeta;
export declare const IssueTypeAddedEvent: TypeMeta;
export declare const IssueTypeChangedEvent: TypeMeta;
export declare const IssueTypeConnection: TypeMeta;
export declare const IssueTypeEdge: TypeMeta;
export declare const IssueTypeRemovedEvent: TypeMeta;
export declare const IssueUpdateIntent: TypeMeta;
export declare const JoinedGitHubContribution: TypeMeta;
export declare const Label: TypeMeta;
export declare const LabelConnection: TypeMeta;
export declare const LabelEdge: TypeMeta;
export declare const Labelable: TypeMeta;
export declare const LabeledEvent: TypeMeta;
export declare const Language: TypeMeta;
export declare const LanguageConnection: TypeMeta;
export declare const LanguageEdge: TypeMeta;
export declare const License: TypeMeta;
export declare const LicenseRule: TypeMeta;
export declare const LinkProjectV2ToRepositoryPayload: TypeMeta;
export declare const LinkProjectV2ToTeamPayload: TypeMeta;
export declare const LinkRepositoryToProjectPayload: TypeMeta;
export declare const LinkedBranch: TypeMeta;
export declare const LinkedBranchConnection: TypeMeta;
export declare const LinkedBranchEdge: TypeMeta;
export declare const LockLockablePayload: TypeMeta;
export declare const Lockable: TypeMeta;
export declare const LockedEvent: TypeMeta;
export declare const Mannequin: TypeMeta;
export declare const MannequinConnection: TypeMeta;
export declare const MannequinEdge: TypeMeta;
export declare const MarkDiscussionCommentAsAnswerPayload: TypeMeta;
export declare const MarkFileAsViewedPayload: TypeMeta;
export declare const MarkProjectV2AsTemplatePayload: TypeMeta;
export declare const MarkPullRequestReadyForReviewPayload: TypeMeta;
export declare const MarkedAsDuplicateEvent: TypeMeta;
export declare const MarketplaceCategory: TypeMeta;
export declare const MarketplaceListing: TypeMeta;
export declare const MarketplaceListingConnection: TypeMeta;
export declare const MarketplaceListingEdge: TypeMeta;
export declare const MaxFilePathLengthParameters: TypeMeta;
export declare const MaxFileSizeParameters: TypeMeta;
export declare const MemberFeatureRequestNotification: TypeMeta;
export declare const MemberStatusable: TypeMeta;
export declare const MembersCanDeleteReposClearAuditEntry: TypeMeta;
export declare const MembersCanDeleteReposDisableAuditEntry: TypeMeta;
export declare const MembersCanDeleteReposEnableAuditEntry: TypeMeta;
export declare const MentionedEvent: TypeMeta;
export declare const MergeBranchPayload: TypeMeta;
export declare const MergePullRequestPayload: TypeMeta;
export declare const MergeQueue: TypeMeta;
export declare const MergeQueueConfiguration: TypeMeta;
export declare const MergeQueueEntry: TypeMeta;
export declare const MergeQueueEntryConnection: TypeMeta;
export declare const MergeQueueEntryEdge: TypeMeta;
export declare const MergeQueueParameters: TypeMeta;
export declare const MergedEvent: TypeMeta;
export declare const Migration: TypeMeta;
export declare const MigrationSource: TypeMeta;
export declare const Milestone: TypeMeta;
export declare const MilestoneConnection: TypeMeta;
export declare const MilestoneEdge: TypeMeta;
export declare const MilestonedEvent: TypeMeta;
export declare const Minimizable: TypeMeta;
export declare const MinimizeCommentPayload: TypeMeta;
export declare const MoveProjectCardPayload: TypeMeta;
export declare const MoveProjectColumnPayload: TypeMeta;
export declare const MovedColumnsInProjectEvent: TypeMeta;
export declare const Node: TypeMeta;
export declare const OIDCProvider: TypeMeta;
export declare const OauthApplicationAuditEntryData: TypeMeta;
export declare const OauthApplicationCreateAuditEntry: TypeMeta;
export declare const OrgAddBillingManagerAuditEntry: TypeMeta;
export declare const OrgAddMemberAuditEntry: TypeMeta;
export declare const OrgBlockUserAuditEntry: TypeMeta;
export declare const OrgConfigDisableCollaboratorsOnlyAuditEntry: TypeMeta;
export declare const OrgConfigEnableCollaboratorsOnlyAuditEntry: TypeMeta;
export declare const OrgCreateAuditEntry: TypeMeta;
export declare const OrgDisableOauthAppRestrictionsAuditEntry: TypeMeta;
export declare const OrgDisableSamlAuditEntry: TypeMeta;
export declare const OrgDisableTwoFactorRequirementAuditEntry: TypeMeta;
export declare const OrgEnableOauthAppRestrictionsAuditEntry: TypeMeta;
export declare const OrgEnableSamlAuditEntry: TypeMeta;
export declare const OrgEnableTwoFactorRequirementAuditEntry: TypeMeta;
export declare const OrgInviteMemberAuditEntry: TypeMeta;
export declare const OrgInviteToBusinessAuditEntry: TypeMeta;
export declare const OrgOauthAppAccessApprovedAuditEntry: TypeMeta;
export declare const OrgOauthAppAccessBlockedAuditEntry: TypeMeta;
export declare const OrgOauthAppAccessDeniedAuditEntry: TypeMeta;
export declare const OrgOauthAppAccessRequestedAuditEntry: TypeMeta;
export declare const OrgOauthAppAccessUnblockedAuditEntry: TypeMeta;
export declare const OrgRemoveBillingManagerAuditEntry: TypeMeta;
export declare const OrgRemoveMemberAuditEntry: TypeMeta;
export declare const OrgRemoveOutsideCollaboratorAuditEntry: TypeMeta;
export declare const OrgRestoreMemberAuditEntry: TypeMeta;
export declare const OrgRestoreMemberMembershipOrganizationAuditEntryData: TypeMeta;
export declare const OrgRestoreMemberMembershipRepositoryAuditEntryData: TypeMeta;
export declare const OrgRestoreMemberMembershipTeamAuditEntryData: TypeMeta;
export declare const OrgUnblockUserAuditEntry: TypeMeta;
export declare const OrgUpdateDefaultRepositoryPermissionAuditEntry: TypeMeta;
export declare const OrgUpdateMemberAuditEntry: TypeMeta;
export declare const OrgUpdateMemberRepositoryCreationPermissionAuditEntry: TypeMeta;
export declare const OrgUpdateMemberRepositoryInvitationPermissionAuditEntry: TypeMeta;
export declare const Organization: TypeMeta;
export declare const OrganizationAuditEntryConnection: TypeMeta;
export declare const OrganizationAuditEntryData: TypeMeta;
export declare const OrganizationAuditEntryEdge: TypeMeta;
export declare const OrganizationConnection: TypeMeta;
export declare const OrganizationEdge: TypeMeta;
export declare const OrganizationEnterpriseOwnerConnection: TypeMeta;
export declare const OrganizationEnterpriseOwnerEdge: TypeMeta;
export declare const OrganizationIdentityProvider: TypeMeta;
export declare const OrganizationInvitation: TypeMeta;
export declare const OrganizationInvitationConnection: TypeMeta;
export declare const OrganizationInvitationEdge: TypeMeta;
export declare const OrganizationMemberConnection: TypeMeta;
export declare const OrganizationMemberEdge: TypeMeta;
export declare const OrganizationMigration: TypeMeta;
export declare const OrganizationPropertyConditionTarget: TypeMeta;
export declare const OrganizationPropertyTargetDefinition: TypeMeta;
export declare const OrganizationTeamsHovercardContext: TypeMeta;
export declare const OrganizationsHovercardContext: TypeMeta;
export declare const Package: TypeMeta;
export declare const PackageConnection: TypeMeta;
export declare const PackageEdge: TypeMeta;
export declare const PackageFile: TypeMeta;
export declare const PackageFileConnection: TypeMeta;
export declare const PackageFileEdge: TypeMeta;
export declare const PackageOwner: TypeMeta;
export declare const PackageStatistics: TypeMeta;
export declare const PackageTag: TypeMeta;
export declare const PackageVersion: TypeMeta;
export declare const PackageVersionConnection: TypeMeta;
export declare const PackageVersionEdge: TypeMeta;
export declare const PackageVersionStatistics: TypeMeta;
export declare const PageInfo: TypeMeta;
export declare const ParentIssueAddedEvent: TypeMeta;
export declare const ParentIssueRemovedEvent: TypeMeta;
export declare const PendingAssigneeSuggestion: TypeMeta;
export declare const PendingCloseSuggestion: TypeMeta;
export declare const PendingFieldSuggestion: TypeMeta;
export declare const PendingLabelSuggestion: TypeMeta;
export declare const PendingTypeSuggestion: TypeMeta;
export declare const PermissionSource: TypeMeta;
export declare const PinEnvironmentPayload: TypeMeta;
export declare const PinIssueCommentPayload: TypeMeta;
export declare const PinIssuePayload: TypeMeta;
export declare const Pinnable: TypeMeta;
export declare const PinnableItemConnection: TypeMeta;
export declare const PinnableItemEdge: TypeMeta;
export declare const PinnedDiscussion: TypeMeta;
export declare const PinnedDiscussionConnection: TypeMeta;
export declare const PinnedDiscussionEdge: TypeMeta;
export declare const PinnedEnvironment: TypeMeta;
export declare const PinnedEnvironmentConnection: TypeMeta;
export declare const PinnedEnvironmentEdge: TypeMeta;
export declare const PinnedEvent: TypeMeta;
export declare const PinnedIssue: TypeMeta;
export declare const PinnedIssueComment: TypeMeta;
export declare const PinnedIssueConnection: TypeMeta;
export declare const PinnedIssueEdge: TypeMeta;
export declare const PrivateRepositoryForkingDisableAuditEntry: TypeMeta;
export declare const PrivateRepositoryForkingEnableAuditEntry: TypeMeta;
export declare const ProfileItemShowcase: TypeMeta;
export declare const ProfileOwner: TypeMeta;
export declare const Project: TypeMeta;
export declare const ProjectCard: TypeMeta;
export declare const ProjectCardConnection: TypeMeta;
export declare const ProjectCardEdge: TypeMeta;
export declare const ProjectColumn: TypeMeta;
export declare const ProjectColumnConnection: TypeMeta;
export declare const ProjectColumnEdge: TypeMeta;
export declare const ProjectConnection: TypeMeta;
export declare const ProjectEdge: TypeMeta;
export declare const ProjectOwner: TypeMeta;
export declare const ProjectProgress: TypeMeta;
export declare const ProjectV2: TypeMeta;
export declare const ProjectV2ActorConnection: TypeMeta;
export declare const ProjectV2ActorEdge: TypeMeta;
export declare const ProjectV2Connection: TypeMeta;
export declare const ProjectV2Edge: TypeMeta;
export declare const ProjectV2Event: TypeMeta;
export declare const ProjectV2Field: TypeMeta;
export declare const ProjectV2FieldCommon: TypeMeta;
export declare const ProjectV2FieldConfigurationConnection: TypeMeta;
export declare const ProjectV2FieldConfigurationEdge: TypeMeta;
export declare const ProjectV2FieldConnection: TypeMeta;
export declare const ProjectV2FieldEdge: TypeMeta;
export declare const ProjectV2Item: TypeMeta;
export declare const ProjectV2ItemConnection: TypeMeta;
export declare const ProjectV2ItemEdge: TypeMeta;
export declare const ProjectV2ItemFieldDateValue: TypeMeta;
export declare const ProjectV2ItemFieldIterationValue: TypeMeta;
export declare const ProjectV2ItemFieldLabelValue: TypeMeta;
export declare const ProjectV2ItemFieldMilestoneValue: TypeMeta;
export declare const ProjectV2ItemFieldMultiSelectValue: TypeMeta;
export declare const ProjectV2ItemFieldNumberValue: TypeMeta;
export declare const ProjectV2ItemFieldPullRequestValue: TypeMeta;
export declare const ProjectV2ItemFieldRepositoryValue: TypeMeta;
export declare const ProjectV2ItemFieldReviewerValue: TypeMeta;
export declare const ProjectV2ItemFieldSingleSelectValue: TypeMeta;
export declare const ProjectV2ItemFieldTextValue: TypeMeta;
export declare const ProjectV2ItemFieldUserValue: TypeMeta;
export declare const ProjectV2ItemFieldValueCommon: TypeMeta;
export declare const ProjectV2ItemFieldValueConnection: TypeMeta;
export declare const ProjectV2ItemFieldValueEdge: TypeMeta;
export declare const ProjectV2ItemIssueFieldValue: TypeMeta;
export declare const ProjectV2ItemStatusChangedEvent: TypeMeta;
export declare const ProjectV2IterationField: TypeMeta;
export declare const ProjectV2IterationFieldConfiguration: TypeMeta;
export declare const ProjectV2IterationFieldIteration: TypeMeta;
export declare const ProjectV2MultiSelectField: TypeMeta;
export declare const ProjectV2MultiSelectFieldOption: TypeMeta;
export declare const ProjectV2Owner: TypeMeta;
export declare const ProjectV2Recent: TypeMeta;
export declare const ProjectV2SingleSelectField: TypeMeta;
export declare const ProjectV2SingleSelectFieldOption: TypeMeta;
export declare const ProjectV2SortBy: TypeMeta;
export declare const ProjectV2SortByConnection: TypeMeta;
export declare const ProjectV2SortByEdge: TypeMeta;
export declare const ProjectV2SortByField: TypeMeta;
export declare const ProjectV2SortByFieldConnection: TypeMeta;
export declare const ProjectV2SortByFieldEdge: TypeMeta;
export declare const ProjectV2StatusUpdate: TypeMeta;
export declare const ProjectV2StatusUpdateConnection: TypeMeta;
export declare const ProjectV2StatusUpdateEdge: TypeMeta;
export declare const ProjectV2View: TypeMeta;
export declare const ProjectV2ViewConfiguration: TypeMeta;
export declare const ProjectV2ViewConnection: TypeMeta;
export declare const ProjectV2ViewEdge: TypeMeta;
export declare const ProjectV2Workflow: TypeMeta;
export declare const ProjectV2WorkflowConnection: TypeMeta;
export declare const ProjectV2WorkflowEdge: TypeMeta;
export declare const PromoteRepositoryCustomPropertyPayload: TypeMeta;
export declare const PropertyTargetDefinition: TypeMeta;
export declare const PublicKey: TypeMeta;
export declare const PublicKeyConnection: TypeMeta;
export declare const PublicKeyEdge: TypeMeta;
export declare const PublishSponsorsTierPayload: TypeMeta;
export declare const PullRequest: TypeMeta;
export declare const PullRequestChangedFile: TypeMeta;
export declare const PullRequestChangedFileConnection: TypeMeta;
export declare const PullRequestChangedFileEdge: TypeMeta;
export declare const PullRequestCommit: TypeMeta;
export declare const PullRequestCommitCommentThread: TypeMeta;
export declare const PullRequestCommitConnection: TypeMeta;
export declare const PullRequestCommitEdge: TypeMeta;
export declare const PullRequestConnection: TypeMeta;
export declare const PullRequestContributionsByRepository: TypeMeta;
export declare const PullRequestCreationCapConfig: TypeMeta;
export declare const PullRequestEdge: TypeMeta;
export declare const PullRequestParameters: TypeMeta;
export declare const PullRequestReview: TypeMeta;
export declare const PullRequestReviewComment: TypeMeta;
export declare const PullRequestReviewCommentConnection: TypeMeta;
export declare const PullRequestReviewCommentEdge: TypeMeta;
export declare const PullRequestReviewConnection: TypeMeta;
export declare const PullRequestReviewContributionsByRepository: TypeMeta;
export declare const PullRequestReviewEdge: TypeMeta;
export declare const PullRequestReviewThread: TypeMeta;
export declare const PullRequestReviewThreadConnection: TypeMeta;
export declare const PullRequestReviewThreadEdge: TypeMeta;
export declare const PullRequestRevisionMarker: TypeMeta;
export declare const PullRequestStack: TypeMeta;
export declare const PullRequestStackEntry: TypeMeta;
export declare const PullRequestStackEntryConnection: TypeMeta;
export declare const PullRequestStackEntryEdge: TypeMeta;
export declare const PullRequestTemplate: TypeMeta;
export declare const PullRequestThread: TypeMeta;
export declare const PullRequestTimelineConnection: TypeMeta;
export declare const PullRequestTimelineItemEdge: TypeMeta;
export declare const PullRequestTimelineItemsConnection: TypeMeta;
export declare const PullRequestTimelineItemsEdge: TypeMeta;
export declare const Push: TypeMeta;
export declare const PushAllowance: TypeMeta;
export declare const PushAllowanceConnection: TypeMeta;
export declare const PushAllowanceEdge: TypeMeta;
export declare const RateLimit: TypeMeta;
export declare const Reactable: TypeMeta;
export declare const ReactingUserConnection: TypeMeta;
export declare const ReactingUserEdge: TypeMeta;
export declare const Reaction: TypeMeta;
export declare const ReactionConnection: TypeMeta;
export declare const ReactionEdge: TypeMeta;
export declare const ReactionGroup: TypeMeta;
export declare const ReactorConnection: TypeMeta;
export declare const ReactorEdge: TypeMeta;
export declare const ReadyForReviewEvent: TypeMeta;
export declare const Ref: TypeMeta;
export declare const RefConnection: TypeMeta;
export declare const RefEdge: TypeMeta;
export declare const RefNameConditionTarget: TypeMeta;
export declare const RefUpdateRule: TypeMeta;
export declare const ReferencedEvent: TypeMeta;
export declare const RegenerateEnterpriseIdentityProviderRecoveryCodesPayload: TypeMeta;
export declare const RegenerateVerifiableDomainTokenPayload: TypeMeta;
export declare const RejectDeploymentsPayload: TypeMeta;
export declare const RejectPendingIssueSuggestionsPayload: TypeMeta;
export declare const Release: TypeMeta;
export declare const ReleaseAsset: TypeMeta;
export declare const ReleaseAssetConnection: TypeMeta;
export declare const ReleaseAssetEdge: TypeMeta;
export declare const ReleaseConnection: TypeMeta;
export declare const ReleaseEdge: TypeMeta;
export declare const RemoveAssigneesFromAssignablePayload: TypeMeta;
export declare const RemoveBlockedByPayload: TypeMeta;
export declare const RemoveCloseIssueReferencesPayload: TypeMeta;
export declare const RemoveEnterpriseAdminPayload: TypeMeta;
export declare const RemoveEnterpriseIdentityProviderPayload: TypeMeta;
export declare const RemoveEnterpriseMemberPayload: TypeMeta;
export declare const RemoveEnterpriseOrganizationPayload: TypeMeta;
export declare const RemoveEnterpriseSupportEntitlementPayload: TypeMeta;
export declare const RemoveLabelsFromLabelablePayload: TypeMeta;
export declare const RemoveOutsideCollaboratorPayload: TypeMeta;
export declare const RemovePullRequestCreationCapBypassUsersPayload: TypeMeta;
export declare const RemoveReactionPayload: TypeMeta;
export declare const RemoveRelatesToPayload: TypeMeta;
export declare const RemoveStarPayload: TypeMeta;
export declare const RemoveSubIssuePayload: TypeMeta;
export declare const RemoveUpvotePayload: TypeMeta;
export declare const RemovedFromMergeQueueEvent: TypeMeta;
export declare const RemovedFromProjectEvent: TypeMeta;
export declare const RemovedFromProjectV2Event: TypeMeta;
export declare const RemovedFromStackEvent: TypeMeta;
export declare const RenamedTitleEvent: TypeMeta;
export declare const ReopenDiscussionPayload: TypeMeta;
export declare const ReopenIssuePayload: TypeMeta;
export declare const ReopenPullRequestPayload: TypeMeta;
export declare const ReopenedEvent: TypeMeta;
export declare const ReorderEnvironmentPayload: TypeMeta;
export declare const ReplaceActorsForAssignablePayload: TypeMeta;
export declare const RepoAccessAuditEntry: TypeMeta;
export declare const RepoAddMemberAuditEntry: TypeMeta;
export declare const RepoAddTopicAuditEntry: TypeMeta;
export declare const RepoArchivedAuditEntry: TypeMeta;
export declare const RepoChangeMergeSettingAuditEntry: TypeMeta;
export declare const RepoConfigDisableAnonymousGitAccessAuditEntry: TypeMeta;
export declare const RepoConfigDisableCollaboratorsOnlyAuditEntry: TypeMeta;
export declare const RepoConfigDisableContributorsOnlyAuditEntry: TypeMeta;
export declare const RepoConfigDisableSockpuppetDisallowedAuditEntry: TypeMeta;
export declare const RepoConfigEnableAnonymousGitAccessAuditEntry: TypeMeta;
export declare const RepoConfigEnableCollaboratorsOnlyAuditEntry: TypeMeta;
export declare const RepoConfigEnableContributorsOnlyAuditEntry: TypeMeta;
export declare const RepoConfigEnableSockpuppetDisallowedAuditEntry: TypeMeta;
export declare const RepoConfigLockAnonymousGitAccessAuditEntry: TypeMeta;
export declare const RepoConfigUnlockAnonymousGitAccessAuditEntry: TypeMeta;
export declare const RepoCreateAuditEntry: TypeMeta;
export declare const RepoDestroyAuditEntry: TypeMeta;
export declare const RepoRemoveMemberAuditEntry: TypeMeta;
export declare const RepoRemoveTopicAuditEntry: TypeMeta;
export declare const Repository: TypeMeta;
export declare const RepositoryAuditEntryData: TypeMeta;
export declare const RepositoryCodeowners: TypeMeta;
export declare const RepositoryCodeownersError: TypeMeta;
export declare const RepositoryCollaboratorConnection: TypeMeta;
export declare const RepositoryCollaboratorEdge: TypeMeta;
export declare const RepositoryConnection: TypeMeta;
export declare const RepositoryContactLink: TypeMeta;
export declare const RepositoryCustomProperty: TypeMeta;
export declare const RepositoryCustomPropertyConnection: TypeMeta;
export declare const RepositoryCustomPropertyEdge: TypeMeta;
export declare const RepositoryCustomPropertyValue: TypeMeta;
export declare const RepositoryCustomPropertyValueConnection: TypeMeta;
export declare const RepositoryCustomPropertyValueEdge: TypeMeta;
export declare const RepositoryDiscussionAuthor: TypeMeta;
export declare const RepositoryDiscussionCommentAuthor: TypeMeta;
export declare const RepositoryEdge: TypeMeta;
export declare const RepositoryIdConditionTarget: TypeMeta;
export declare const RepositoryInfo: TypeMeta;
export declare const RepositoryInteractionAbility: TypeMeta;
export declare const RepositoryInvitation: TypeMeta;
export declare const RepositoryInvitationConnection: TypeMeta;
export declare const RepositoryInvitationEdge: TypeMeta;
export declare const RepositoryMigration: TypeMeta;
export declare const RepositoryMigrationConnection: TypeMeta;
export declare const RepositoryMigrationEdge: TypeMeta;
export declare const RepositoryNameConditionTarget: TypeMeta;
export declare const RepositoryNode: TypeMeta;
export declare const RepositoryOwner: TypeMeta;
export declare const RepositoryPlanFeatures: TypeMeta;
export declare const RepositoryPropertyConditionTarget: TypeMeta;
export declare const RepositoryRule: TypeMeta;
export declare const RepositoryRuleConditions: TypeMeta;
export declare const RepositoryRuleConnection: TypeMeta;
export declare const RepositoryRuleEdge: TypeMeta;
export declare const RepositoryRuleset: TypeMeta;
export declare const RepositoryRulesetBypassActor: TypeMeta;
export declare const RepositoryRulesetBypassActorConnection: TypeMeta;
export declare const RepositoryRulesetBypassActorEdge: TypeMeta;
export declare const RepositoryRulesetConnection: TypeMeta;
export declare const RepositoryRulesetEdge: TypeMeta;
export declare const RepositoryTopic: TypeMeta;
export declare const RepositoryTopicConnection: TypeMeta;
export declare const RepositoryTopicEdge: TypeMeta;
export declare const RepositoryVisibilityChangeDisableAuditEntry: TypeMeta;
export declare const RepositoryVisibilityChangeEnableAuditEntry: TypeMeta;
export declare const RepositoryVulnerabilityAlert: TypeMeta;
export declare const RepositoryVulnerabilityAlertConnection: TypeMeta;
export declare const RepositoryVulnerabilityAlertEdge: TypeMeta;
export declare const ReprioritizeSubIssuePayload: TypeMeta;
export declare const RequestReviewsByLoginPayload: TypeMeta;
export declare const RequestReviewsPayload: TypeMeta;
export declare const RequestedReviewerConnection: TypeMeta;
export declare const RequestedReviewerEdge: TypeMeta;
export declare const RequirableByPullRequest: TypeMeta;
export declare const RequiredDeploymentsParameters: TypeMeta;
export declare const RequiredReviewerConfiguration: TypeMeta;
export declare const RequiredStatusCheckDescription: TypeMeta;
export declare const RequiredStatusChecksParameters: TypeMeta;
export declare const RerequestCheckSuitePayload: TypeMeta;
export declare const RerequestReviewsPayload: TypeMeta;
export declare const ResolveReviewThreadPayload: TypeMeta;
export declare const RestrictedContribution: TypeMeta;
export declare const RetireSponsorsTierPayload: TypeMeta;
export declare const RevertPullRequestPayload: TypeMeta;
export declare const ReviewDismissalAllowance: TypeMeta;
export declare const ReviewDismissalAllowanceConnection: TypeMeta;
export declare const ReviewDismissalAllowanceEdge: TypeMeta;
export declare const ReviewDismissedEvent: TypeMeta;
export declare const ReviewRequest: TypeMeta;
export declare const ReviewRequestConnection: TypeMeta;
export declare const ReviewRequestEdge: TypeMeta;
export declare const ReviewRequestRemovedEvent: TypeMeta;
export declare const ReviewRequestedEvent: TypeMeta;
export declare const ReviewStatusHovercardContext: TypeMeta;
export declare const RevokeEnterpriseOrganizationsMigratorRolePayload: TypeMeta;
export declare const RevokeMigratorRolePayload: TypeMeta;
export declare const SavedReply: TypeMeta;
export declare const SavedReplyConnection: TypeMeta;
export declare const SavedReplyEdge: TypeMeta;
export declare const SearchResultItemConnection: TypeMeta;
export declare const SearchResultItemEdge: TypeMeta;
export declare const SecurityAdvisory: TypeMeta;
export declare const SecurityAdvisoryConnection: TypeMeta;
export declare const SecurityAdvisoryEdge: TypeMeta;
export declare const SecurityAdvisoryIdentifier: TypeMeta;
export declare const SecurityAdvisoryPackage: TypeMeta;
export declare const SecurityAdvisoryPackageVersion: TypeMeta;
export declare const SecurityAdvisoryReference: TypeMeta;
export declare const SecurityVulnerability: TypeMeta;
export declare const SecurityVulnerabilityConnection: TypeMeta;
export declare const SecurityVulnerabilityEdge: TypeMeta;
export declare const SetEnterpriseIdentityProviderPayload: TypeMeta;
export declare const SetIssueFieldValuePayload: TypeMeta;
export declare const SetOrganizationInteractionLimitPayload: TypeMeta;
export declare const SetRepositoryCustomPropertyValuesPayload: TypeMeta;
export declare const SetRepositoryInteractionLimitPayload: TypeMeta;
export declare const SetUserInteractionLimitPayload: TypeMeta;
export declare const SmimeSignature: TypeMeta;
export declare const SocialAccount: TypeMeta;
export declare const SocialAccountConnection: TypeMeta;
export declare const SocialAccountEdge: TypeMeta;
export declare const SponsorAndLifetimeValue: TypeMeta;
export declare const SponsorAndLifetimeValueConnection: TypeMeta;
export declare const SponsorAndLifetimeValueEdge: TypeMeta;
export declare const SponsorConnection: TypeMeta;
export declare const SponsorEdge: TypeMeta;
export declare const Sponsorable: TypeMeta;
export declare const SponsorableItemConnection: TypeMeta;
export declare const SponsorableItemEdge: TypeMeta;
export declare const SponsorsActivity: TypeMeta;
export declare const SponsorsActivityConnection: TypeMeta;
export declare const SponsorsActivityEdge: TypeMeta;
export declare const SponsorsGoal: TypeMeta;
export declare const SponsorsListing: TypeMeta;
export declare const SponsorsListingFeaturedItem: TypeMeta;
export declare const SponsorsTier: TypeMeta;
export declare const SponsorsTierAdminInfo: TypeMeta;
export declare const SponsorsTierConnection: TypeMeta;
export declare const SponsorsTierEdge: TypeMeta;
export declare const Sponsorship: TypeMeta;
export declare const SponsorshipConnection: TypeMeta;
export declare const SponsorshipEdge: TypeMeta;
export declare const SponsorshipNewsletter: TypeMeta;
export declare const SponsorshipNewsletterConnection: TypeMeta;
export declare const SponsorshipNewsletterEdge: TypeMeta;
export declare const SshSignature: TypeMeta;
export declare const StargazerConnection: TypeMeta;
export declare const StargazerEdge: TypeMeta;
export declare const Starrable: TypeMeta;
export declare const StarredRepositoryConnection: TypeMeta;
export declare const StarredRepositoryEdge: TypeMeta;
export declare const StartOrganizationMigrationPayload: TypeMeta;
export declare const StartRepositoryMigrationPayload: TypeMeta;
export declare const Status: TypeMeta;
export declare const StatusCheckConfiguration: TypeMeta;
export declare const StatusCheckRollup: TypeMeta;
export declare const StatusCheckRollupContextConnection: TypeMeta;
export declare const StatusCheckRollupContextEdge: TypeMeta;
export declare const StatusContext: TypeMeta;
export declare const StatusContextStateCount: TypeMeta;
export declare const StripeConnectAccount: TypeMeta;
export declare const SubIssueAddedEvent: TypeMeta;
export declare const SubIssueRemovedEvent: TypeMeta;
export declare const SubIssuesSummary: TypeMeta;
export declare const SubmitPullRequestReviewPayload: TypeMeta;
export declare const Submodule: TypeMeta;
export declare const SubmoduleConnection: TypeMeta;
export declare const SubmoduleEdge: TypeMeta;
export declare const Subscribable: TypeMeta;
export declare const SubscribableThread: TypeMeta;
export declare const SubscribedEvent: TypeMeta;
export declare const SuggestedReviewer: TypeMeta;
export declare const SuggestedReviewerActor: TypeMeta;
export declare const SuggestedReviewerActorConnection: TypeMeta;
export declare const SuggestedReviewerActorEdge: TypeMeta;
export declare const Tag: TypeMeta;
export declare const TagNamePatternParameters: TypeMeta;
export declare const Team: TypeMeta;
export declare const TeamAddMemberAuditEntry: TypeMeta;
export declare const TeamAddRepositoryAuditEntry: TypeMeta;
export declare const TeamAuditEntryData: TypeMeta;
export declare const TeamChangeParentTeamAuditEntry: TypeMeta;
export declare const TeamConnection: TypeMeta;
export declare const TeamEdge: TypeMeta;
export declare const TeamMemberConnection: TypeMeta;
export declare const TeamMemberEdge: TypeMeta;
export declare const TeamRemoveMemberAuditEntry: TypeMeta;
export declare const TeamRemoveRepositoryAuditEntry: TypeMeta;
export declare const TeamRepositoryConnection: TypeMeta;
export declare const TeamRepositoryEdge: TypeMeta;
export declare const TeamReviewRequestable: TypeMeta;
export declare const TextMatch: TypeMeta;
export declare const TextMatchHighlight: TypeMeta;
export declare const Topic: TypeMeta;
export declare const TopicAuditEntryData: TypeMeta;
export declare const TransferEnterpriseOrganizationPayload: TypeMeta;
export declare const TransferIssuePayload: TypeMeta;
export declare const TransferredEvent: TypeMeta;
export declare const Tree: TypeMeta;
export declare const TreeEntry: TypeMeta;
export declare const UnarchiveProjectV2ItemPayload: TypeMeta;
export declare const UnarchivePullRequestPayload: TypeMeta;
export declare const UnarchiveRepositoryPayload: TypeMeta;
export declare const UnassignedEvent: TypeMeta;
export declare const UnfollowOrganizationPayload: TypeMeta;
export declare const UnfollowUserPayload: TypeMeta;
export declare const UniformResourceLocatable: TypeMeta;
export declare const UnknownSignature: TypeMeta;
export declare const UnlabeledEvent: TypeMeta;
export declare const UnlinkProjectV2FromRepositoryPayload: TypeMeta;
export declare const UnlinkProjectV2FromTeamPayload: TypeMeta;
export declare const UnlinkRepositoryFromProjectPayload: TypeMeta;
export declare const UnlockLockablePayload: TypeMeta;
export declare const UnlockedEvent: TypeMeta;
export declare const UnmarkDiscussionCommentAsAnswerPayload: TypeMeta;
export declare const UnmarkFileAsViewedPayload: TypeMeta;
export declare const UnmarkIssueAsDuplicatePayload: TypeMeta;
export declare const UnmarkProjectV2AsTemplatePayload: TypeMeta;
export declare const UnmarkedAsDuplicateEvent: TypeMeta;
export declare const UnminimizeCommentPayload: TypeMeta;
export declare const UnpinIssueCommentPayload: TypeMeta;
export declare const UnpinIssuePayload: TypeMeta;
export declare const UnpinnedEvent: TypeMeta;
export declare const UnresolveReviewThreadPayload: TypeMeta;
export declare const UnsubscribedEvent: TypeMeta;
export declare const Updatable: TypeMeta;
export declare const UpdatableComment: TypeMeta;
export declare const UpdateBranchProtectionRulePayload: TypeMeta;
export declare const UpdateCheckRunPayload: TypeMeta;
export declare const UpdateCheckSuitePreferencesPayload: TypeMeta;
export declare const UpdateDiscussionCommentPayload: TypeMeta;
export declare const UpdateDiscussionPayload: TypeMeta;
export declare const UpdateEnterpriseAdministratorRolePayload: TypeMeta;
export declare const UpdateEnterpriseAllowPrivateRepositoryForkingSettingPayload: TypeMeta;
export declare const UpdateEnterpriseDefaultRepositoryPermissionSettingPayload: TypeMeta;
export declare const UpdateEnterpriseDeployKeySettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanChangeRepositoryVisibilitySettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanCreateRepositoriesSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanDeleteIssuesSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanDeleteRepositoriesSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanInviteCollaboratorsSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanMakePurchasesSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanUpdateProtectedBranchesSettingPayload: TypeMeta;
export declare const UpdateEnterpriseMembersCanViewDependencyInsightsSettingPayload: TypeMeta;
export declare const UpdateEnterpriseOrganizationProjectsSettingPayload: TypeMeta;
export declare const UpdateEnterpriseOwnerOrganizationRolePayload: TypeMeta;
export declare const UpdateEnterpriseProfilePayload: TypeMeta;
export declare const UpdateEnterpriseRepositoryProjectsSettingPayload: TypeMeta;
export declare const UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSettingPayload: TypeMeta;
export declare const UpdateEnterpriseTwoFactorAuthenticationRequiredSettingPayload: TypeMeta;
export declare const UpdateEnvironmentPayload: TypeMeta;
export declare const UpdateIpAllowListEnabledSettingPayload: TypeMeta;
export declare const UpdateIpAllowListEntryPayload: TypeMeta;
export declare const UpdateIpAllowListForInstalledAppsEnabledSettingPayload: TypeMeta;
export declare const UpdateIpAllowListUserLevelEnforcementEnabledSettingPayload: TypeMeta;
export declare const UpdateIssueCommentPayload: TypeMeta;
export declare const UpdateIssueFieldPayload: TypeMeta;
export declare const UpdateIssueFieldValuePayload: TypeMeta;
export declare const UpdateIssueIssueTypePayload: TypeMeta;
export declare const UpdateIssuePayload: TypeMeta;
export declare const UpdateIssueTypePayload: TypeMeta;
export declare const UpdateLabelPayload: TypeMeta;
export declare const UpdateNotificationRestrictionSettingPayload: TypeMeta;
export declare const UpdateOrganizationAllowPrivateRepositoryForkingSettingPayload: TypeMeta;
export declare const UpdateOrganizationWebCommitSignoffSettingPayload: TypeMeta;
export declare const UpdateParameters: TypeMeta;
export declare const UpdatePatreonSponsorabilityPayload: TypeMeta;
export declare const UpdateProjectCardPayload: TypeMeta;
export declare const UpdateProjectColumnPayload: TypeMeta;
export declare const UpdateProjectPayload: TypeMeta;
export declare const UpdateProjectV2CollaboratorsPayload: TypeMeta;
export declare const UpdateProjectV2DraftIssuePayload: TypeMeta;
export declare const UpdateProjectV2FieldPayload: TypeMeta;
export declare const UpdateProjectV2ItemFieldValuePayload: TypeMeta;
export declare const UpdateProjectV2ItemPositionPayload: TypeMeta;
export declare const UpdateProjectV2Payload: TypeMeta;
export declare const UpdateProjectV2StatusUpdatePayload: TypeMeta;
export declare const UpdateProjectV2ViewPayload: TypeMeta;
export declare const UpdatePullRequestBranchPayload: TypeMeta;
export declare const UpdatePullRequestPayload: TypeMeta;
export declare const UpdatePullRequestReviewCommentPayload: TypeMeta;
export declare const UpdatePullRequestReviewPayload: TypeMeta;
export declare const UpdateRefPayload: TypeMeta;
export declare const UpdateRefsPayload: TypeMeta;
export declare const UpdateRepositoryCustomPropertyPayload: TypeMeta;
export declare const UpdateRepositoryPayload: TypeMeta;
export declare const UpdateRepositoryRulesetPayload: TypeMeta;
export declare const UpdateRepositoryWebCommitSignoffSettingPayload: TypeMeta;
export declare const UpdateSponsorshipPreferencesPayload: TypeMeta;
export declare const UpdateSubscriptionPayload: TypeMeta;
export declare const UpdateTeamReviewAssignmentPayload: TypeMeta;
export declare const UpdateTeamsRepositoryPayload: TypeMeta;
export declare const UpdateTopicsPayload: TypeMeta;
export declare const UpdateUserListPayload: TypeMeta;
export declare const UpdateUserListsForItemPayload: TypeMeta;
export declare const User: TypeMeta;
export declare const UserBlockedEvent: TypeMeta;
export declare const UserConnection: TypeMeta;
export declare const UserContentEdit: TypeMeta;
export declare const UserContentEditConnection: TypeMeta;
export declare const UserContentEditEdge: TypeMeta;
export declare const UserEdge: TypeMeta;
export declare const UserEmailMetadata: TypeMeta;
export declare const UserList: TypeMeta;
export declare const UserListConnection: TypeMeta;
export declare const UserListEdge: TypeMeta;
export declare const UserListItemsConnection: TypeMeta;
export declare const UserListItemsEdge: TypeMeta;
export declare const UserListSuggestion: TypeMeta;
export declare const UserNamespaceRepository: TypeMeta;
export declare const UserNamespaceRepositoryConnection: TypeMeta;
export declare const UserNamespaceRepositoryEdge: TypeMeta;
export declare const UserStatus: TypeMeta;
export declare const UserStatusConnection: TypeMeta;
export declare const UserStatusEdge: TypeMeta;
export declare const VerifiableDomain: TypeMeta;
export declare const VerifiableDomainConnection: TypeMeta;
export declare const VerifiableDomainEdge: TypeMeta;
export declare const VerifyVerifiableDomainPayload: TypeMeta;
export declare const ViewerHovercardContext: TypeMeta;
export declare const Votable: TypeMeta;
export declare const Workflow: TypeMeta;
export declare const WorkflowFileReference: TypeMeta;
export declare const WorkflowRun: TypeMeta;
export declare const WorkflowRunConnection: TypeMeta;
export declare const WorkflowRunEdge: TypeMeta;
export declare const WorkflowRunFile: TypeMeta;
export declare const WorkflowsParameters: TypeMeta;
export declare const Assignee: TypeMeta;
export declare const AuditEntryActor: TypeMeta;
export declare const BranchActorAllowanceActor: TypeMeta;
export declare const BypassActor: TypeMeta;
export declare const Claimable: TypeMeta;
export declare const Closer: TypeMeta;
export declare const CreatedIssueOrRestrictedContribution: TypeMeta;
export declare const CreatedPullRequestOrRestrictedContribution: TypeMeta;
export declare const CreatedRepositoryOrRestrictedContribution: TypeMeta;
export declare const CustomPropertySource: TypeMeta;
export declare const DeploymentReviewer: TypeMeta;
export declare const EnterpriseMember: TypeMeta;
export declare const IpAllowListOwner: TypeMeta;
export declare const IssueFieldValue: TypeMeta;
export declare const IssueFields: TypeMeta;
export declare const IssueOrPullRequest: TypeMeta;
export declare const IssueTimelineItem: TypeMeta;
export declare const IssueTimelineItems: TypeMeta;
export declare const MilestoneItem: TypeMeta;
export declare const OrgRestoreMemberAuditEntryMembership: TypeMeta;
export declare const OrganizationAuditEntry: TypeMeta;
export declare const OrganizationOrUser: TypeMeta;
export declare const PendingIssueSuggestion: TypeMeta;
export declare const PermissionGranter: TypeMeta;
export declare const PinnableItem: TypeMeta;
export declare const ProjectCardItem: TypeMeta;
export declare const ProjectV2Actor: TypeMeta;
export declare const ProjectV2FieldConfiguration: TypeMeta;
export declare const ProjectV2IssueFieldValues: TypeMeta;
export declare const ProjectV2ItemContent: TypeMeta;
export declare const ProjectV2ItemFieldValue: TypeMeta;
export declare const PullRequestTimelineItem: TypeMeta;
export declare const PullRequestTimelineItems: TypeMeta;
export declare const PushAllowanceActor: TypeMeta;
export declare const Reactor: TypeMeta;
export declare const ReferencedSubject: TypeMeta;
export declare const RenamedTitleSubject: TypeMeta;
export declare const RequestedReviewer: TypeMeta;
export declare const ReviewDismissalAllowanceActor: TypeMeta;
export declare const RuleParameters: TypeMeta;
export declare const RuleSource: TypeMeta;
export declare const SearchResultItem: TypeMeta;
export declare const Sponsor: TypeMeta;
export declare const SponsorableItem: TypeMeta;
export declare const SponsorsListingFeatureableItem: TypeMeta;
export declare const StatusCheckRollupContext: TypeMeta;
export declare const UserListItems: TypeMeta;
export declare const VerifiableDomainOwner: TypeMeta;
export declare const GitHub: {
    codeOfConduct: (args: {
        readonly key: string;
    }) => Query<CodeOfConduct | null, GitHubGlobalError>;
    codesOfConduct: () => Query<ReadonlyArray<CodeOfConduct | null> | null, GitHubGlobalError>;
    enterprise: (args: {
        readonly slug: string;
        readonly invitationToken?: string | null | undefined;
    }) => Query<Enterprise | null, GitHubGlobalError>;
    enterpriseAdministratorInvitation: (args: {
        readonly enterpriseSlug: string;
        readonly role: "BILLING_MANAGER" | "OWNER" | "UNAFFILIATED";
        readonly userLogin: string;
    }) => Query<EnterpriseAdministratorInvitation | null, GitHubGlobalError>;
    enterpriseAdministratorInvitationByToken: (args: {
        readonly invitationToken: string;
    }) => Query<EnterpriseAdministratorInvitation | null, GitHubGlobalError>;
    enterpriseMemberInvitation: (args: {
        readonly enterpriseSlug: string;
        readonly userLogin: string;
    }) => Query<EnterpriseMemberInvitation | null, GitHubGlobalError>;
    enterpriseMemberInvitationByToken: (args: {
        readonly invitationToken: string;
    }) => Query<EnterpriseMemberInvitation | null, GitHubGlobalError>;
    id: () => Query<string, GitHubGlobalError>;
    license: (args: {
        readonly key: string;
    }) => Query<License | null, GitHubGlobalError>;
    licenses: () => Query<ReadonlyArray<License | null>, GitHubGlobalError>;
    marketplaceCategories: (args?: {
        readonly excludeEmpty?: boolean | null | undefined;
        readonly excludeSubcategories?: boolean | null | undefined;
        readonly includeCategories?: ReadonlyArray<string> | null | undefined;
    }) => Query<ReadonlyArray<MarketplaceCategory>, GitHubGlobalError>;
    marketplaceCategory: (args: {
        readonly slug: string;
        readonly useTopicAliases?: boolean | null | undefined;
    }) => Query<MarketplaceCategory | null, GitHubGlobalError>;
    marketplaceListing: (args: {
        readonly slug: string;
    }) => Query<MarketplaceListing | null, GitHubGlobalError>;
    marketplaceListings: (args?: {
        readonly adminId?: string | null | undefined;
        readonly after?: string | null | undefined;
        readonly allStates?: boolean | null | undefined;
        readonly before?: string | null | undefined;
        readonly categorySlug?: string | null | undefined;
        readonly first?: number | null | undefined;
        readonly last?: number | null | undefined;
        readonly organizationId?: string | null | undefined;
        readonly primaryCategoryOnly?: boolean | null | undefined;
        readonly slugs?: ReadonlyArray<string | null> | null | undefined;
        readonly useTopicAliases?: boolean | null | undefined;
        readonly viewerCanAdmin?: boolean | null | undefined;
        readonly withFreeTrialsOnly?: boolean | null | undefined;
    }) => Query<ReadonlyArray<MarketplaceListing>, GitHubGlobalError>;
    meta: () => Query<GitHubMetadata, GitHubGlobalError>;
    node: (args: {
        readonly id: string;
    }) => Query<Node | null, GitHubGlobalError>;
    nodes: (args: {
        readonly ids: ReadonlyArray<string>;
    }) => Query<ReadonlyArray<Node | null>, GitHubGlobalError>;
    organization: (args: {
        readonly login: string;
    }) => Query<Organization | null, GitHubGlobalError>;
    rateLimit: (args?: {
        readonly dryRun?: boolean | null | undefined;
    }) => Query<RateLimit | null, GitHubGlobalError>;
    repository: (args: {
        readonly name: string;
        readonly owner: string;
        readonly followRenames?: boolean | null | undefined;
    }) => Query<Repository | null, GitHubGlobalError>;
    repositoryOwner: (args: {
        readonly login: string;
    }) => Query<RepositoryOwner | null, GitHubGlobalError>;
    resource: (args: {
        readonly url: string;
    }) => Query<UniformResourceLocatable | null, GitHubGlobalError>;
    search: (args: {
        readonly query: string;
        readonly type: "DISCUSSION" | "ISSUE" | "ISSUE_ADVANCED" | "ISSUE_HYBRID" | "ISSUE_SEMANTIC" | "REPOSITORY" | "USER";
        readonly after?: string | null | undefined;
        readonly before?: string | null | undefined;
        readonly first?: number | null | undefined;
        readonly last?: number | null | undefined;
    }) => Query<ReadonlyArray<App | Discussion | Issue | MarketplaceListing | Organization | PullRequest | Repository | User>, GitHubGlobalError>;
    securityAdvisories: (args?: {
        readonly after?: string | null | undefined;
        readonly before?: string | null | undefined;
        readonly classifications?: ReadonlyArray<"GENERAL" | "MALWARE"> | null | undefined;
        readonly epssPercentage?: number | null | undefined;
        readonly epssPercentile?: number | null | undefined;
        readonly first?: number | null | undefined;
        readonly identifier?: SecurityAdvisoryIdentifierFilter | null | undefined;
        readonly isWithdrawn?: boolean | null | undefined;
        readonly last?: number | null | undefined;
        readonly orderBy?: SecurityAdvisoryOrder | null | undefined;
        readonly publishedSince?: string | null | undefined;
        readonly severities?: ReadonlyArray<"CRITICAL" | "HIGH" | "LOW" | "MODERATE" | "UNKNOWN"> | null | undefined;
        readonly updatedSince?: string | null | undefined;
    }) => Query<ReadonlyArray<SecurityAdvisory>, GitHubGlobalError>;
    securityAdvisory: (args: {
        readonly ghsaId: string;
    }) => Query<SecurityAdvisory | null, GitHubGlobalError>;
    securityVulnerabilities: (args?: {
        readonly after?: string | null | undefined;
        readonly before?: string | null | undefined;
        readonly classifications?: ReadonlyArray<"GENERAL" | "MALWARE"> | null | undefined;
        readonly ecosystem?: "ACTIONS" | "COMPOSER" | "ERLANG" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT" | null | undefined;
        readonly first?: number | null | undefined;
        readonly last?: number | null | undefined;
        readonly orderBy?: SecurityVulnerabilityOrder | null | undefined;
        readonly package?: string | null | undefined;
        readonly severities?: ReadonlyArray<"CRITICAL" | "HIGH" | "LOW" | "MODERATE" | "UNKNOWN"> | null | undefined;
    }) => Query<ReadonlyArray<SecurityVulnerability>, GitHubGlobalError>;
    sponsorables: (args?: {
        readonly after?: string | null | undefined;
        readonly before?: string | null | undefined;
        readonly dependencyEcosystem?: "ACTIONS" | "COMPOSER" | "ERLANG" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT" | null | undefined;
        readonly ecosystem?: "ACTIONS" | "COMPOSER" | "GO" | "MAVEN" | "NPM" | "NUGET" | "PIP" | "PUB" | "RUBYGEMS" | "RUST" | "SWIFT" | null | undefined;
        readonly first?: number | null | undefined;
        readonly last?: number | null | undefined;
        readonly onlyDependencies?: boolean | null | undefined;
        readonly orderBy?: SponsorableOrder | null | undefined;
        readonly orgLoginForDependencies?: string | null | undefined;
    }) => Query<ReadonlyArray<Organization | User>, GitHubGlobalError>;
    topic: (args: {
        readonly name: string;
    }) => Query<Topic | null, GitHubGlobalError>;
    user: (args: {
        readonly login: string;
    }) => Query<User | null, GitHubGlobalError>;
    viewer: () => Query<User, GitHubGlobalError>;
    abortQueuedMigrations: (args: {
        readonly input: AbortQueuedMigrationsInput;
    }) => Query<AbortQueuedMigrationsPayload | null, GitHubGlobalError>;
    abortRepositoryMigration: (args: {
        readonly input: AbortRepositoryMigrationInput;
    }) => Query<AbortRepositoryMigrationPayload | null, GitHubGlobalError>;
    acceptEnterpriseAdministratorInvitation: (args: {
        readonly input: AcceptEnterpriseAdministratorInvitationInput;
    }) => Query<AcceptEnterpriseAdministratorInvitationPayload | null, GitHubGlobalError>;
    acceptEnterpriseMemberInvitation: (args: {
        readonly input: AcceptEnterpriseMemberInvitationInput;
    }) => Query<AcceptEnterpriseMemberInvitationPayload | null, GitHubGlobalError>;
    acceptTopicSuggestion: (args: {
        readonly input: AcceptTopicSuggestionInput;
    }) => Query<AcceptTopicSuggestionPayload | null, GitHubGlobalError>;
    accessUserNamespaceRepository: (args: {
        readonly input: AccessUserNamespaceRepositoryInput;
    }) => Query<AccessUserNamespaceRepositoryPayload | null, GitHubGlobalError>;
    addAssigneesToAssignable: (args: {
        readonly input: AddAssigneesToAssignableInput;
    }) => Query<AddAssigneesToAssignablePayload | null, GitHubGlobalError>;
    addBlockedBy: (args: {
        readonly input: AddBlockedByInput;
    }) => Query<AddBlockedByPayload | null, GitHubGlobalError>;
    addCloseIssueReferences: (args: {
        readonly input: AddCloseIssueReferencesInput;
    }) => Query<AddCloseIssueReferencesPayload | null, GitHubGlobalError>;
    addComment: (args: {
        readonly input: AddCommentInput;
    }) => Query<AddCommentPayload | null, GitHubGlobalError>;
    addDiscussionComment: (args: {
        readonly input: AddDiscussionCommentInput;
    }) => Query<AddDiscussionCommentPayload | null, GitHubGlobalError>;
    addDiscussionPollVote: (args: {
        readonly input: AddDiscussionPollVoteInput;
    }) => Query<AddDiscussionPollVotePayload | null, GitHubGlobalError>;
    addEnterpriseOrganizationMember: (args: {
        readonly input: AddEnterpriseOrganizationMemberInput;
    }) => Query<AddEnterpriseOrganizationMemberPayload | null, GitHubGlobalError>;
    addEnterpriseSupportEntitlement: (args: {
        readonly input: AddEnterpriseSupportEntitlementInput;
    }) => Query<AddEnterpriseSupportEntitlementPayload | null, GitHubGlobalError>;
    addLabelsToLabelable: (args: {
        readonly input: AddLabelsToLabelableInput;
    }) => Query<AddLabelsToLabelablePayload | null, GitHubGlobalError>;
    addProjectCard: (args: {
        readonly input: AddProjectCardInput;
    }) => Query<AddProjectCardPayload | null, GitHubGlobalError>;
    addProjectColumn: (args: {
        readonly input: AddProjectColumnInput;
    }) => Query<AddProjectColumnPayload | null, GitHubGlobalError>;
    addProjectV2DraftIssue: (args: {
        readonly input: AddProjectV2DraftIssueInput;
    }) => Query<AddProjectV2DraftIssuePayload | null, GitHubGlobalError>;
    addProjectV2ItemById: (args: {
        readonly input: AddProjectV2ItemByIdInput;
    }) => Query<AddProjectV2ItemByIdPayload | null, GitHubGlobalError>;
    addPullRequestCreationCapBypassUsers: (args: {
        readonly input: AddPullRequestCreationCapBypassUsersInput;
    }) => Query<AddPullRequestCreationCapBypassUsersPayload | null, GitHubGlobalError>;
    addPullRequestReview: (args: {
        readonly input: AddPullRequestReviewInput;
    }) => Query<AddPullRequestReviewPayload | null, GitHubGlobalError>;
    addPullRequestReviewComment: (args: {
        readonly input: AddPullRequestReviewCommentInput;
    }) => Query<AddPullRequestReviewCommentPayload | null, GitHubGlobalError>;
    addPullRequestReviewThread: (args: {
        readonly input: AddPullRequestReviewThreadInput;
    }) => Query<AddPullRequestReviewThreadPayload | null, GitHubGlobalError>;
    addPullRequestReviewThreadReply: (args: {
        readonly input: AddPullRequestReviewThreadReplyInput;
    }) => Query<AddPullRequestReviewThreadReplyPayload | null, GitHubGlobalError>;
    addReaction: (args: {
        readonly input: AddReactionInput;
    }) => Query<AddReactionPayload | null, GitHubGlobalError>;
    addRelatesTo: (args: {
        readonly input: AddRelatesToInput;
    }) => Query<AddRelatesToPayload | null, GitHubGlobalError>;
    addStar: (args: {
        readonly input: AddStarInput;
    }) => Query<AddStarPayload | null, GitHubGlobalError>;
    addSubIssue: (args: {
        readonly input: AddSubIssueInput;
    }) => Query<AddSubIssuePayload | null, GitHubGlobalError>;
    addUpvote: (args: {
        readonly input: AddUpvoteInput;
    }) => Query<AddUpvotePayload | null, GitHubGlobalError>;
    addVerifiableDomain: (args: {
        readonly input: AddVerifiableDomainInput;
    }) => Query<AddVerifiableDomainPayload | null, GitHubGlobalError>;
    applyPendingIssueSuggestions: (args: {
        readonly input: ApplyPendingIssueSuggestionsInput;
    }) => Query<ApplyPendingIssueSuggestionsPayload | null, GitHubGlobalError>;
    approveDeployments: (args: {
        readonly input: ApproveDeploymentsInput;
    }) => Query<ApproveDeploymentsPayload | null, GitHubGlobalError>;
    approveVerifiableDomain: (args: {
        readonly input: ApproveVerifiableDomainInput;
    }) => Query<ApproveVerifiableDomainPayload | null, GitHubGlobalError>;
    archiveProjectV2Item: (args: {
        readonly input: ArchiveProjectV2ItemInput;
    }) => Query<ArchiveProjectV2ItemPayload | null, GitHubGlobalError>;
    archivePullRequest: (args: {
        readonly input: ArchivePullRequestInput;
    }) => Query<ArchivePullRequestPayload | null, GitHubGlobalError>;
    archiveRepository: (args: {
        readonly input: ArchiveRepositoryInput;
    }) => Query<ArchiveRepositoryPayload | null, GitHubGlobalError>;
    cancelEnterpriseAdminInvitation: (args: {
        readonly input: CancelEnterpriseAdminInvitationInput;
    }) => Query<CancelEnterpriseAdminInvitationPayload | null, GitHubGlobalError>;
    cancelEnterpriseMemberInvitation: (args: {
        readonly input: CancelEnterpriseMemberInvitationInput;
    }) => Query<CancelEnterpriseMemberInvitationPayload | null, GitHubGlobalError>;
    cancelSponsorship: (args: {
        readonly input: CancelSponsorshipInput;
    }) => Query<CancelSponsorshipPayload | null, GitHubGlobalError>;
    changeUserStatus: (args: {
        readonly input: ChangeUserStatusInput;
    }) => Query<ChangeUserStatusPayload | null, GitHubGlobalError>;
    clearLabelsFromLabelable: (args: {
        readonly input: ClearLabelsFromLabelableInput;
    }) => Query<ClearLabelsFromLabelablePayload | null, GitHubGlobalError>;
    clearProjectV2ItemFieldValue: (args: {
        readonly input: ClearProjectV2ItemFieldValueInput;
    }) => Query<ClearProjectV2ItemFieldValuePayload | null, GitHubGlobalError>;
    cloneProject: (args: {
        readonly input: CloneProjectInput;
    }) => Query<CloneProjectPayload | null, GitHubGlobalError>;
    cloneTemplateRepository: (args: {
        readonly input: CloneTemplateRepositoryInput;
    }) => Query<CloneTemplateRepositoryPayload | null, GitHubGlobalError>;
    closeDiscussion: (args: {
        readonly input: CloseDiscussionInput;
    }) => Query<CloseDiscussionPayload | null, GitHubGlobalError>;
    closeIssue: (args: {
        readonly input: CloseIssueInput;
    }) => Query<CloseIssuePayload | null, GitHubGlobalError>;
    closePullRequest: (args: {
        readonly input: ClosePullRequestInput;
    }) => Query<ClosePullRequestPayload | null, GitHubGlobalError>;
    convertProjectCardNoteToIssue: (args: {
        readonly input: ConvertProjectCardNoteToIssueInput;
    }) => Query<ConvertProjectCardNoteToIssuePayload | null, GitHubGlobalError>;
    convertProjectV2DraftIssueItemToIssue: (args: {
        readonly input: ConvertProjectV2DraftIssueItemToIssueInput;
    }) => Query<ConvertProjectV2DraftIssueItemToIssuePayload | null, GitHubGlobalError>;
    convertPullRequestToDraft: (args: {
        readonly input: ConvertPullRequestToDraftInput;
    }) => Query<ConvertPullRequestToDraftPayload | null, GitHubGlobalError>;
    copyProjectV2: (args: {
        readonly input: CopyProjectV2Input;
    }) => Query<CopyProjectV2Payload | null, GitHubGlobalError>;
    createAttributionInvitation: (args: {
        readonly input: CreateAttributionInvitationInput;
    }) => Query<CreateAttributionInvitationPayload | null, GitHubGlobalError>;
    createBranchProtectionRule: (args: {
        readonly input: CreateBranchProtectionRuleInput;
    }) => Query<CreateBranchProtectionRulePayload | null, GitHubGlobalError>;
    createCheckRun: (args: {
        readonly input: CreateCheckRunInput;
    }) => Query<CreateCheckRunPayload | null, GitHubGlobalError>;
    createCheckSuite: (args: {
        readonly input: CreateCheckSuiteInput;
    }) => Query<CreateCheckSuitePayload | null, GitHubGlobalError>;
    createCommitOnBranch: (args: {
        readonly input: CreateCommitOnBranchInput;
    }) => Query<CreateCommitOnBranchPayload | null, GitHubGlobalError>;
    createDeployment: (args: {
        readonly input: CreateDeploymentInput;
    }) => Query<CreateDeploymentPayload | null, GitHubGlobalError>;
    createDeploymentStatus: (args: {
        readonly input: CreateDeploymentStatusInput;
    }) => Query<CreateDeploymentStatusPayload | null, GitHubGlobalError>;
    createDiscussion: (args: {
        readonly input: CreateDiscussionInput;
    }) => Query<CreateDiscussionPayload | null, GitHubGlobalError>;
    createEnterpriseOrganization: (args: {
        readonly input: CreateEnterpriseOrganizationInput;
    }) => Query<CreateEnterpriseOrganizationPayload | null, GitHubGlobalError>;
    createEnvironment: (args: {
        readonly input: CreateEnvironmentInput;
    }) => Query<CreateEnvironmentPayload | null, GitHubGlobalError>;
    createIpAllowListEntry: (args: {
        readonly input: CreateIpAllowListEntryInput;
    }) => Query<CreateIpAllowListEntryPayload | null, GitHubGlobalError>;
    createIssue: (args: {
        readonly input: CreateIssueInput;
    }) => Query<CreateIssuePayload | null, GitHubGlobalError>;
    createIssueField: (args: {
        readonly input: CreateIssueFieldInput;
    }) => Query<CreateIssueFieldPayload | null, GitHubGlobalError>;
    createIssueFieldValue: (args: {
        readonly input: CreateIssueFieldValueInput;
    }) => Query<CreateIssueFieldValuePayload | null, GitHubGlobalError>;
    createIssueType: (args: {
        readonly input: CreateIssueTypeInput;
    }) => Query<CreateIssueTypePayload | null, GitHubGlobalError>;
    createLabel: (args: {
        readonly input: CreateLabelInput;
    }) => Query<CreateLabelPayload | null, GitHubGlobalError>;
    createLinkedBranch: (args: {
        readonly input: CreateLinkedBranchInput;
    }) => Query<CreateLinkedBranchPayload | null, GitHubGlobalError>;
    createMigrationSource: (args: {
        readonly input: CreateMigrationSourceInput;
    }) => Query<CreateMigrationSourcePayload | null, GitHubGlobalError>;
    createProject: (args: {
        readonly input: CreateProjectInput;
    }) => Query<CreateProjectPayload | null, GitHubGlobalError>;
    createProjectV2: (args: {
        readonly input: CreateProjectV2Input;
    }) => Query<CreateProjectV2Payload | null, GitHubGlobalError>;
    createProjectV2Field: (args: {
        readonly input: CreateProjectV2FieldInput;
    }) => Query<CreateProjectV2FieldPayload | null, GitHubGlobalError>;
    createProjectV2IssueField: (args: {
        readonly input: CreateProjectV2IssueFieldInput;
    }) => Query<CreateProjectV2IssueFieldPayload | null, GitHubGlobalError>;
    createProjectV2StatusUpdate: (args: {
        readonly input: CreateProjectV2StatusUpdateInput;
    }) => Query<CreateProjectV2StatusUpdatePayload | null, GitHubGlobalError>;
    createProjectV2View: (args: {
        readonly input: CreateProjectV2ViewInput;
    }) => Query<CreateProjectV2ViewPayload | null, GitHubGlobalError>;
    createPullRequest: (args: {
        readonly input: CreatePullRequestInput;
    }) => Query<CreatePullRequestPayload | null, GitHubGlobalError>;
    createRef: (args: {
        readonly input: CreateRefInput;
    }) => Query<CreateRefPayload | null, GitHubGlobalError>;
    createRepository: (args: {
        readonly input: CreateRepositoryInput;
    }) => Query<CreateRepositoryPayload | null, GitHubGlobalError>;
    createRepositoryCustomProperty: (args: {
        readonly input: CreateRepositoryCustomPropertyInput;
    }) => Query<CreateRepositoryCustomPropertyPayload | null, GitHubGlobalError>;
    createRepositoryRuleset: (args: {
        readonly input: CreateRepositoryRulesetInput;
    }) => Query<CreateRepositoryRulesetPayload | null, GitHubGlobalError>;
    createSponsorship: (args: {
        readonly input: CreateSponsorshipInput;
    }) => Query<CreateSponsorshipPayload | null, GitHubGlobalError>;
    createSponsorships: (args: {
        readonly input: CreateSponsorshipsInput;
    }) => Query<CreateSponsorshipsPayload | null, GitHubGlobalError>;
    createSponsorsListing: (args: {
        readonly input: CreateSponsorsListingInput;
    }) => Query<CreateSponsorsListingPayload | null, GitHubGlobalError>;
    createSponsorsTier: (args: {
        readonly input: CreateSponsorsTierInput;
    }) => Query<CreateSponsorsTierPayload | null, GitHubGlobalError>;
    createUserList: (args: {
        readonly input: CreateUserListInput;
    }) => Query<CreateUserListPayload | null, GitHubGlobalError>;
    declineTopicSuggestion: (args: {
        readonly input: DeclineTopicSuggestionInput;
    }) => Query<DeclineTopicSuggestionPayload | null, GitHubGlobalError>;
    deleteBranchProtectionRule: (args: {
        readonly input: DeleteBranchProtectionRuleInput;
    }) => Query<DeleteBranchProtectionRulePayload | null, GitHubGlobalError>;
    deleteDeployment: (args: {
        readonly input: DeleteDeploymentInput;
    }) => Query<DeleteDeploymentPayload | null, GitHubGlobalError>;
    deleteDiscussion: (args: {
        readonly input: DeleteDiscussionInput;
    }) => Query<DeleteDiscussionPayload | null, GitHubGlobalError>;
    deleteDiscussionComment: (args: {
        readonly input: DeleteDiscussionCommentInput;
    }) => Query<DeleteDiscussionCommentPayload | null, GitHubGlobalError>;
    deleteEnvironment: (args: {
        readonly input: DeleteEnvironmentInput;
    }) => Query<DeleteEnvironmentPayload | null, GitHubGlobalError>;
    deleteIpAllowListEntry: (args: {
        readonly input: DeleteIpAllowListEntryInput;
    }) => Query<DeleteIpAllowListEntryPayload | null, GitHubGlobalError>;
    deleteIssue: (args: {
        readonly input: DeleteIssueInput;
    }) => Query<DeleteIssuePayload | null, GitHubGlobalError>;
    deleteIssueComment: (args: {
        readonly input: DeleteIssueCommentInput;
    }) => Query<DeleteIssueCommentPayload | null, GitHubGlobalError>;
    deleteIssueField: (args: {
        readonly input: DeleteIssueFieldInput;
    }) => Query<DeleteIssueFieldPayload | null, GitHubGlobalError>;
    deleteIssueFieldValue: (args: {
        readonly input: DeleteIssueFieldValueInput;
    }) => Query<DeleteIssueFieldValuePayload | null, GitHubGlobalError>;
    deleteIssueType: (args: {
        readonly input: DeleteIssueTypeInput;
    }) => Query<DeleteIssueTypePayload | null, GitHubGlobalError>;
    deleteLabel: (args: {
        readonly input: DeleteLabelInput;
    }) => Query<DeleteLabelPayload | null, GitHubGlobalError>;
    deleteLinkedBranch: (args: {
        readonly input: DeleteLinkedBranchInput;
    }) => Query<DeleteLinkedBranchPayload | null, GitHubGlobalError>;
    deletePackageVersion: (args: {
        readonly input: DeletePackageVersionInput;
    }) => Query<DeletePackageVersionPayload | null, GitHubGlobalError>;
    deleteProject: (args: {
        readonly input: DeleteProjectInput;
    }) => Query<DeleteProjectPayload | null, GitHubGlobalError>;
    deleteProjectCard: (args: {
        readonly input: DeleteProjectCardInput;
    }) => Query<DeleteProjectCardPayload | null, GitHubGlobalError>;
    deleteProjectColumn: (args: {
        readonly input: DeleteProjectColumnInput;
    }) => Query<DeleteProjectColumnPayload | null, GitHubGlobalError>;
    deleteProjectV2: (args: {
        readonly input: DeleteProjectV2Input;
    }) => Query<DeleteProjectV2Payload | null, GitHubGlobalError>;
    deleteProjectV2Field: (args: {
        readonly input: DeleteProjectV2FieldInput;
    }) => Query<DeleteProjectV2FieldPayload | null, GitHubGlobalError>;
    deleteProjectV2Item: (args: {
        readonly input: DeleteProjectV2ItemInput;
    }) => Query<DeleteProjectV2ItemPayload | null, GitHubGlobalError>;
    deleteProjectV2StatusUpdate: (args: {
        readonly input: DeleteProjectV2StatusUpdateInput;
    }) => Query<DeleteProjectV2StatusUpdatePayload | null, GitHubGlobalError>;
    deleteProjectV2View: (args: {
        readonly input: DeleteProjectV2ViewInput;
    }) => Query<DeleteProjectV2ViewPayload | null, GitHubGlobalError>;
    deleteProjectV2Workflow: (args: {
        readonly input: DeleteProjectV2WorkflowInput;
    }) => Query<DeleteProjectV2WorkflowPayload | null, GitHubGlobalError>;
    deletePullRequestReview: (args: {
        readonly input: DeletePullRequestReviewInput;
    }) => Query<DeletePullRequestReviewPayload | null, GitHubGlobalError>;
    deletePullRequestReviewComment: (args: {
        readonly input: DeletePullRequestReviewCommentInput;
    }) => Query<DeletePullRequestReviewCommentPayload | null, GitHubGlobalError>;
    deleteRef: (args: {
        readonly input: DeleteRefInput;
    }) => Query<DeleteRefPayload | null, GitHubGlobalError>;
    deleteRepositoryCustomProperty: (args: {
        readonly input: DeleteRepositoryCustomPropertyInput;
    }) => Query<DeleteRepositoryCustomPropertyPayload | null, GitHubGlobalError>;
    deleteRepositoryRuleset: (args: {
        readonly input: DeleteRepositoryRulesetInput;
    }) => Query<DeleteRepositoryRulesetPayload | null, GitHubGlobalError>;
    deleteUserList: (args: {
        readonly input: DeleteUserListInput;
    }) => Query<DeleteUserListPayload | null, GitHubGlobalError>;
    deleteVerifiableDomain: (args: {
        readonly input: DeleteVerifiableDomainInput;
    }) => Query<DeleteVerifiableDomainPayload | null, GitHubGlobalError>;
    dequeuePullRequest: (args: {
        readonly input: DequeuePullRequestInput;
    }) => Query<DequeuePullRequestPayload | null, GitHubGlobalError>;
    disablePullRequestAutoMerge: (args: {
        readonly input: DisablePullRequestAutoMergeInput;
    }) => Query<DisablePullRequestAutoMergePayload | null, GitHubGlobalError>;
    dismissPullRequestReview: (args: {
        readonly input: DismissPullRequestReviewInput;
    }) => Query<DismissPullRequestReviewPayload | null, GitHubGlobalError>;
    dismissRepositoryVulnerabilityAlert: (args: {
        readonly input: DismissRepositoryVulnerabilityAlertInput;
    }) => Query<DismissRepositoryVulnerabilityAlertPayload | null, GitHubGlobalError>;
    enablePullRequestAutoMerge: (args: {
        readonly input: EnablePullRequestAutoMergeInput;
    }) => Query<EnablePullRequestAutoMergePayload | null, GitHubGlobalError>;
    enqueuePullRequest: (args: {
        readonly input: EnqueuePullRequestInput;
    }) => Query<EnqueuePullRequestPayload | null, GitHubGlobalError>;
    followOrganization: (args: {
        readonly input: FollowOrganizationInput;
    }) => Query<FollowOrganizationPayload | null, GitHubGlobalError>;
    followUser: (args: {
        readonly input: FollowUserInput;
    }) => Query<FollowUserPayload | null, GitHubGlobalError>;
    grantEnterpriseOrganizationsMigratorRole: (args: {
        readonly input: GrantEnterpriseOrganizationsMigratorRoleInput;
    }) => Query<GrantEnterpriseOrganizationsMigratorRolePayload | null, GitHubGlobalError>;
    grantMigratorRole: (args: {
        readonly input: GrantMigratorRoleInput;
    }) => Query<GrantMigratorRolePayload | null, GitHubGlobalError>;
    importProject: (args: {
        readonly input: ImportProjectInput;
    }) => Query<ImportProjectPayload | null, GitHubGlobalError>;
    inviteEnterpriseAdmin: (args: {
        readonly input: InviteEnterpriseAdminInput;
    }) => Query<InviteEnterpriseAdminPayload | null, GitHubGlobalError>;
    inviteEnterpriseMember: (args: {
        readonly input: InviteEnterpriseMemberInput;
    }) => Query<InviteEnterpriseMemberPayload | null, GitHubGlobalError>;
    linkProjectV2ToRepository: (args: {
        readonly input: LinkProjectV2ToRepositoryInput;
    }) => Query<LinkProjectV2ToRepositoryPayload | null, GitHubGlobalError>;
    linkProjectV2ToTeam: (args: {
        readonly input: LinkProjectV2ToTeamInput;
    }) => Query<LinkProjectV2ToTeamPayload | null, GitHubGlobalError>;
    linkRepositoryToProject: (args: {
        readonly input: LinkRepositoryToProjectInput;
    }) => Query<LinkRepositoryToProjectPayload | null, GitHubGlobalError>;
    lockLockable: (args: {
        readonly input: LockLockableInput;
    }) => Query<LockLockablePayload | null, GitHubGlobalError>;
    markDiscussionCommentAsAnswer: (args: {
        readonly input: MarkDiscussionCommentAsAnswerInput;
    }) => Query<MarkDiscussionCommentAsAnswerPayload | null, GitHubGlobalError>;
    markFileAsViewed: (args: {
        readonly input: MarkFileAsViewedInput;
    }) => Query<MarkFileAsViewedPayload | null, GitHubGlobalError>;
    markProjectV2AsTemplate: (args: {
        readonly input: MarkProjectV2AsTemplateInput;
    }) => Query<MarkProjectV2AsTemplatePayload | null, GitHubGlobalError>;
    markPullRequestReadyForReview: (args: {
        readonly input: MarkPullRequestReadyForReviewInput;
    }) => Query<MarkPullRequestReadyForReviewPayload | null, GitHubGlobalError>;
    mergeBranch: (args: {
        readonly input: MergeBranchInput;
    }) => Query<MergeBranchPayload | null, GitHubGlobalError>;
    mergePullRequest: (args: {
        readonly input: MergePullRequestInput;
    }) => Query<MergePullRequestPayload | null, GitHubGlobalError>;
    minimizeComment: (args: {
        readonly input: MinimizeCommentInput;
    }) => Query<MinimizeCommentPayload | null, GitHubGlobalError>;
    moveProjectCard: (args: {
        readonly input: MoveProjectCardInput;
    }) => Query<MoveProjectCardPayload | null, GitHubGlobalError>;
    moveProjectColumn: (args: {
        readonly input: MoveProjectColumnInput;
    }) => Query<MoveProjectColumnPayload | null, GitHubGlobalError>;
    pinEnvironment: (args: {
        readonly input: PinEnvironmentInput;
    }) => Query<PinEnvironmentPayload | null, GitHubGlobalError>;
    pinIssue: (args: {
        readonly input: PinIssueInput;
    }) => Query<PinIssuePayload | null, GitHubGlobalError>;
    pinIssueComment: (args: {
        readonly input: PinIssueCommentInput;
    }) => Query<PinIssueCommentPayload | null, GitHubGlobalError>;
    promoteRepositoryCustomProperty: (args: {
        readonly input: PromoteRepositoryCustomPropertyInput;
    }) => Query<PromoteRepositoryCustomPropertyPayload | null, GitHubGlobalError>;
    publishSponsorsTier: (args: {
        readonly input: PublishSponsorsTierInput;
    }) => Query<PublishSponsorsTierPayload | null, GitHubGlobalError>;
    regenerateEnterpriseIdentityProviderRecoveryCodes: (args: {
        readonly input: RegenerateEnterpriseIdentityProviderRecoveryCodesInput;
    }) => Query<RegenerateEnterpriseIdentityProviderRecoveryCodesPayload | null, GitHubGlobalError>;
    regenerateVerifiableDomainToken: (args: {
        readonly input: RegenerateVerifiableDomainTokenInput;
    }) => Query<RegenerateVerifiableDomainTokenPayload | null, GitHubGlobalError>;
    rejectDeployments: (args: {
        readonly input: RejectDeploymentsInput;
    }) => Query<RejectDeploymentsPayload | null, GitHubGlobalError>;
    rejectPendingIssueSuggestions: (args: {
        readonly input: RejectPendingIssueSuggestionsInput;
    }) => Query<RejectPendingIssueSuggestionsPayload | null, GitHubGlobalError>;
    removeAssigneesFromAssignable: (args: {
        readonly input: RemoveAssigneesFromAssignableInput;
    }) => Query<RemoveAssigneesFromAssignablePayload | null, GitHubGlobalError>;
    removeBlockedBy: (args: {
        readonly input: RemoveBlockedByInput;
    }) => Query<RemoveBlockedByPayload | null, GitHubGlobalError>;
    removeCloseIssueReferences: (args: {
        readonly input: RemoveCloseIssueReferencesInput;
    }) => Query<RemoveCloseIssueReferencesPayload | null, GitHubGlobalError>;
    removeEnterpriseAdmin: (args: {
        readonly input: RemoveEnterpriseAdminInput;
    }) => Query<RemoveEnterpriseAdminPayload | null, GitHubGlobalError>;
    removeEnterpriseIdentityProvider: (args: {
        readonly input: RemoveEnterpriseIdentityProviderInput;
    }) => Query<RemoveEnterpriseIdentityProviderPayload | null, GitHubGlobalError>;
    removeEnterpriseMember: (args: {
        readonly input: RemoveEnterpriseMemberInput;
    }) => Query<RemoveEnterpriseMemberPayload | null, GitHubGlobalError>;
    removeEnterpriseOrganization: (args: {
        readonly input: RemoveEnterpriseOrganizationInput;
    }) => Query<RemoveEnterpriseOrganizationPayload | null, GitHubGlobalError>;
    removeEnterpriseSupportEntitlement: (args: {
        readonly input: RemoveEnterpriseSupportEntitlementInput;
    }) => Query<RemoveEnterpriseSupportEntitlementPayload | null, GitHubGlobalError>;
    removeLabelsFromLabelable: (args: {
        readonly input: RemoveLabelsFromLabelableInput;
    }) => Query<RemoveLabelsFromLabelablePayload | null, GitHubGlobalError>;
    removeOutsideCollaborator: (args: {
        readonly input: RemoveOutsideCollaboratorInput;
    }) => Query<RemoveOutsideCollaboratorPayload | null, GitHubGlobalError>;
    removePullRequestCreationCapBypassUsers: (args: {
        readonly input: RemovePullRequestCreationCapBypassUsersInput;
    }) => Query<RemovePullRequestCreationCapBypassUsersPayload | null, GitHubGlobalError>;
    removeReaction: (args: {
        readonly input: RemoveReactionInput;
    }) => Query<RemoveReactionPayload | null, GitHubGlobalError>;
    removeRelatesTo: (args: {
        readonly input: RemoveRelatesToInput;
    }) => Query<RemoveRelatesToPayload | null, GitHubGlobalError>;
    removeStar: (args: {
        readonly input: RemoveStarInput;
    }) => Query<RemoveStarPayload | null, GitHubGlobalError>;
    removeSubIssue: (args: {
        readonly input: RemoveSubIssueInput;
    }) => Query<RemoveSubIssuePayload | null, GitHubGlobalError>;
    removeUpvote: (args: {
        readonly input: RemoveUpvoteInput;
    }) => Query<RemoveUpvotePayload | null, GitHubGlobalError>;
    reopenDiscussion: (args: {
        readonly input: ReopenDiscussionInput;
    }) => Query<ReopenDiscussionPayload | null, GitHubGlobalError>;
    reopenIssue: (args: {
        readonly input: ReopenIssueInput;
    }) => Query<ReopenIssuePayload | null, GitHubGlobalError>;
    reopenPullRequest: (args: {
        readonly input: ReopenPullRequestInput;
    }) => Query<ReopenPullRequestPayload | null, GitHubGlobalError>;
    reorderEnvironment: (args: {
        readonly input: ReorderEnvironmentInput;
    }) => Query<ReorderEnvironmentPayload | null, GitHubGlobalError>;
    replaceActorsForAssignable: (args: {
        readonly input: ReplaceActorsForAssignableInput;
    }) => Query<ReplaceActorsForAssignablePayload | null, GitHubGlobalError>;
    reprioritizeSubIssue: (args: {
        readonly input: ReprioritizeSubIssueInput;
    }) => Query<ReprioritizeSubIssuePayload | null, GitHubGlobalError>;
    requestReviews: (args: {
        readonly input: RequestReviewsInput;
    }) => Query<RequestReviewsPayload | null, GitHubGlobalError>;
    requestReviewsByLogin: (args: {
        readonly input: RequestReviewsByLoginInput;
    }) => Query<RequestReviewsByLoginPayload | null, GitHubGlobalError>;
    rerequestCheckSuite: (args: {
        readonly input: RerequestCheckSuiteInput;
    }) => Query<RerequestCheckSuitePayload | null, GitHubGlobalError>;
    rerequestReviews: (args: {
        readonly input: RerequestReviewsInput;
    }) => Query<RerequestReviewsPayload | null, GitHubGlobalError>;
    resolveReviewThread: (args: {
        readonly input: ResolveReviewThreadInput;
    }) => Query<ResolveReviewThreadPayload | null, GitHubGlobalError>;
    retireSponsorsTier: (args: {
        readonly input: RetireSponsorsTierInput;
    }) => Query<RetireSponsorsTierPayload | null, GitHubGlobalError>;
    revertPullRequest: (args: {
        readonly input: RevertPullRequestInput;
    }) => Query<RevertPullRequestPayload | null, GitHubGlobalError>;
    revokeEnterpriseOrganizationsMigratorRole: (args: {
        readonly input: RevokeEnterpriseOrganizationsMigratorRoleInput;
    }) => Query<RevokeEnterpriseOrganizationsMigratorRolePayload | null, GitHubGlobalError>;
    revokeMigratorRole: (args: {
        readonly input: RevokeMigratorRoleInput;
    }) => Query<RevokeMigratorRolePayload | null, GitHubGlobalError>;
    setEnterpriseIdentityProvider: (args: {
        readonly input: SetEnterpriseIdentityProviderInput;
    }) => Query<SetEnterpriseIdentityProviderPayload | null, GitHubGlobalError>;
    setIssueFieldValue: (args: {
        readonly input: SetIssueFieldValueInput;
    }) => Query<SetIssueFieldValuePayload | null, GitHubGlobalError>;
    setOrganizationInteractionLimit: (args: {
        readonly input: SetOrganizationInteractionLimitInput;
    }) => Query<SetOrganizationInteractionLimitPayload | null, GitHubGlobalError>;
    setRepositoryCustomPropertyValues: (args: {
        readonly input: SetRepositoryCustomPropertyValuesInput;
    }) => Query<SetRepositoryCustomPropertyValuesPayload | null, GitHubGlobalError>;
    setRepositoryInteractionLimit: (args: {
        readonly input: SetRepositoryInteractionLimitInput;
    }) => Query<SetRepositoryInteractionLimitPayload | null, GitHubGlobalError>;
    setUserInteractionLimit: (args: {
        readonly input: SetUserInteractionLimitInput;
    }) => Query<SetUserInteractionLimitPayload | null, GitHubGlobalError>;
    startOrganizationMigration: (args: {
        readonly input: StartOrganizationMigrationInput;
    }) => Query<StartOrganizationMigrationPayload | null, GitHubGlobalError>;
    startRepositoryMigration: (args: {
        readonly input: StartRepositoryMigrationInput;
    }) => Query<StartRepositoryMigrationPayload | null, GitHubGlobalError>;
    submitPullRequestReview: (args: {
        readonly input: SubmitPullRequestReviewInput;
    }) => Query<SubmitPullRequestReviewPayload | null, GitHubGlobalError>;
    transferEnterpriseOrganization: (args: {
        readonly input: TransferEnterpriseOrganizationInput;
    }) => Query<TransferEnterpriseOrganizationPayload | null, GitHubGlobalError>;
    transferIssue: (args: {
        readonly input: TransferIssueInput;
    }) => Query<TransferIssuePayload | null, GitHubGlobalError>;
    unarchiveProjectV2Item: (args: {
        readonly input: UnarchiveProjectV2ItemInput;
    }) => Query<UnarchiveProjectV2ItemPayload | null, GitHubGlobalError>;
    unarchivePullRequest: (args: {
        readonly input: UnarchivePullRequestInput;
    }) => Query<UnarchivePullRequestPayload | null, GitHubGlobalError>;
    unarchiveRepository: (args: {
        readonly input: UnarchiveRepositoryInput;
    }) => Query<UnarchiveRepositoryPayload | null, GitHubGlobalError>;
    unfollowOrganization: (args: {
        readonly input: UnfollowOrganizationInput;
    }) => Query<UnfollowOrganizationPayload | null, GitHubGlobalError>;
    unfollowUser: (args: {
        readonly input: UnfollowUserInput;
    }) => Query<UnfollowUserPayload | null, GitHubGlobalError>;
    unlinkProjectV2FromRepository: (args: {
        readonly input: UnlinkProjectV2FromRepositoryInput;
    }) => Query<UnlinkProjectV2FromRepositoryPayload | null, GitHubGlobalError>;
    unlinkProjectV2FromTeam: (args: {
        readonly input: UnlinkProjectV2FromTeamInput;
    }) => Query<UnlinkProjectV2FromTeamPayload | null, GitHubGlobalError>;
    unlinkRepositoryFromProject: (args: {
        readonly input: UnlinkRepositoryFromProjectInput;
    }) => Query<UnlinkRepositoryFromProjectPayload | null, GitHubGlobalError>;
    unlockLockable: (args: {
        readonly input: UnlockLockableInput;
    }) => Query<UnlockLockablePayload | null, GitHubGlobalError>;
    unmarkDiscussionCommentAsAnswer: (args: {
        readonly input: UnmarkDiscussionCommentAsAnswerInput;
    }) => Query<UnmarkDiscussionCommentAsAnswerPayload | null, GitHubGlobalError>;
    unmarkFileAsViewed: (args: {
        readonly input: UnmarkFileAsViewedInput;
    }) => Query<UnmarkFileAsViewedPayload | null, GitHubGlobalError>;
    unmarkIssueAsDuplicate: (args: {
        readonly input: UnmarkIssueAsDuplicateInput;
    }) => Query<UnmarkIssueAsDuplicatePayload | null, GitHubGlobalError>;
    unmarkProjectV2AsTemplate: (args: {
        readonly input: UnmarkProjectV2AsTemplateInput;
    }) => Query<UnmarkProjectV2AsTemplatePayload | null, GitHubGlobalError>;
    unminimizeComment: (args: {
        readonly input: UnminimizeCommentInput;
    }) => Query<UnminimizeCommentPayload | null, GitHubGlobalError>;
    unpinIssue: (args: {
        readonly input: UnpinIssueInput;
    }) => Query<UnpinIssuePayload | null, GitHubGlobalError>;
    unpinIssueComment: (args: {
        readonly input: UnpinIssueCommentInput;
    }) => Query<UnpinIssueCommentPayload | null, GitHubGlobalError>;
    unresolveReviewThread: (args: {
        readonly input: UnresolveReviewThreadInput;
    }) => Query<UnresolveReviewThreadPayload | null, GitHubGlobalError>;
    updateBranchProtectionRule: (args: {
        readonly input: UpdateBranchProtectionRuleInput;
    }) => Query<UpdateBranchProtectionRulePayload | null, GitHubGlobalError>;
    updateCheckRun: (args: {
        readonly input: UpdateCheckRunInput;
    }) => Query<UpdateCheckRunPayload | null, GitHubGlobalError>;
    updateCheckSuitePreferences: (args: {
        readonly input: UpdateCheckSuitePreferencesInput;
    }) => Query<UpdateCheckSuitePreferencesPayload | null, GitHubGlobalError>;
    updateDiscussion: (args: {
        readonly input: UpdateDiscussionInput;
    }) => Query<UpdateDiscussionPayload | null, GitHubGlobalError>;
    updateDiscussionComment: (args: {
        readonly input: UpdateDiscussionCommentInput;
    }) => Query<UpdateDiscussionCommentPayload | null, GitHubGlobalError>;
    updateEnterpriseAdministratorRole: (args: {
        readonly input: UpdateEnterpriseAdministratorRoleInput;
    }) => Query<UpdateEnterpriseAdministratorRolePayload | null, GitHubGlobalError>;
    updateEnterpriseAllowPrivateRepositoryForkingSetting: (args: {
        readonly input: UpdateEnterpriseAllowPrivateRepositoryForkingSettingInput;
    }) => Query<UpdateEnterpriseAllowPrivateRepositoryForkingSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseDefaultRepositoryPermissionSetting: (args: {
        readonly input: UpdateEnterpriseDefaultRepositoryPermissionSettingInput;
    }) => Query<UpdateEnterpriseDefaultRepositoryPermissionSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseDeployKeySetting: (args: {
        readonly input: UpdateEnterpriseDeployKeySettingInput;
    }) => Query<UpdateEnterpriseDeployKeySettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanChangeRepositoryVisibilitySetting: (args: {
        readonly input: UpdateEnterpriseMembersCanChangeRepositoryVisibilitySettingInput;
    }) => Query<UpdateEnterpriseMembersCanChangeRepositoryVisibilitySettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanCreateRepositoriesSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanCreateRepositoriesSettingInput;
    }) => Query<UpdateEnterpriseMembersCanCreateRepositoriesSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanDeleteIssuesSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanDeleteIssuesSettingInput;
    }) => Query<UpdateEnterpriseMembersCanDeleteIssuesSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanDeleteRepositoriesSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanDeleteRepositoriesSettingInput;
    }) => Query<UpdateEnterpriseMembersCanDeleteRepositoriesSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanInviteCollaboratorsSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanInviteCollaboratorsSettingInput;
    }) => Query<UpdateEnterpriseMembersCanInviteCollaboratorsSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanMakePurchasesSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanMakePurchasesSettingInput;
    }) => Query<UpdateEnterpriseMembersCanMakePurchasesSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanUpdateProtectedBranchesSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanUpdateProtectedBranchesSettingInput;
    }) => Query<UpdateEnterpriseMembersCanUpdateProtectedBranchesSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseMembersCanViewDependencyInsightsSetting: (args: {
        readonly input: UpdateEnterpriseMembersCanViewDependencyInsightsSettingInput;
    }) => Query<UpdateEnterpriseMembersCanViewDependencyInsightsSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseOrganizationProjectsSetting: (args: {
        readonly input: UpdateEnterpriseOrganizationProjectsSettingInput;
    }) => Query<UpdateEnterpriseOrganizationProjectsSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseOwnerOrganizationRole: (args: {
        readonly input: UpdateEnterpriseOwnerOrganizationRoleInput;
    }) => Query<UpdateEnterpriseOwnerOrganizationRolePayload | null, GitHubGlobalError>;
    updateEnterpriseProfile: (args: {
        readonly input: UpdateEnterpriseProfileInput;
    }) => Query<UpdateEnterpriseProfilePayload | null, GitHubGlobalError>;
    updateEnterpriseRepositoryProjectsSetting: (args: {
        readonly input: UpdateEnterpriseRepositoryProjectsSettingInput;
    }) => Query<UpdateEnterpriseRepositoryProjectsSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseTwoFactorAuthenticationDisallowedMethodsSetting: (args: {
        readonly input: UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSettingInput;
    }) => Query<UpdateEnterpriseTwoFactorAuthenticationDisallowedMethodsSettingPayload | null, GitHubGlobalError>;
    updateEnterpriseTwoFactorAuthenticationRequiredSetting: (args: {
        readonly input: UpdateEnterpriseTwoFactorAuthenticationRequiredSettingInput;
    }) => Query<UpdateEnterpriseTwoFactorAuthenticationRequiredSettingPayload | null, GitHubGlobalError>;
    updateEnvironment: (args: {
        readonly input: UpdateEnvironmentInput;
    }) => Query<UpdateEnvironmentPayload | null, GitHubGlobalError>;
    updateIpAllowListEnabledSetting: (args: {
        readonly input: UpdateIpAllowListEnabledSettingInput;
    }) => Query<UpdateIpAllowListEnabledSettingPayload | null, GitHubGlobalError>;
    updateIpAllowListEntry: (args: {
        readonly input: UpdateIpAllowListEntryInput;
    }) => Query<UpdateIpAllowListEntryPayload | null, GitHubGlobalError>;
    updateIpAllowListForInstalledAppsEnabledSetting: (args: {
        readonly input: UpdateIpAllowListForInstalledAppsEnabledSettingInput;
    }) => Query<UpdateIpAllowListForInstalledAppsEnabledSettingPayload | null, GitHubGlobalError>;
    updateIpAllowListUserLevelEnforcementEnabledSetting: (args: {
        readonly input: UpdateIpAllowListUserLevelEnforcementEnabledSettingInput;
    }) => Query<UpdateIpAllowListUserLevelEnforcementEnabledSettingPayload | null, GitHubGlobalError>;
    updateIssue: (args: {
        readonly input: UpdateIssueInput;
    }) => Query<UpdateIssuePayload | null, GitHubGlobalError>;
    updateIssueComment: (args: {
        readonly input: UpdateIssueCommentInput;
    }) => Query<UpdateIssueCommentPayload | null, GitHubGlobalError>;
    updateIssueField: (args: {
        readonly input: UpdateIssueFieldInput;
    }) => Query<UpdateIssueFieldPayload | null, GitHubGlobalError>;
    updateIssueFieldValue: (args: {
        readonly input: UpdateIssueFieldValueInput;
    }) => Query<UpdateIssueFieldValuePayload | null, GitHubGlobalError>;
    updateIssueIssueType: (args: {
        readonly input: UpdateIssueIssueTypeInput;
    }) => Query<UpdateIssueIssueTypePayload | null, GitHubGlobalError>;
    updateIssueType: (args: {
        readonly input: UpdateIssueTypeInput;
    }) => Query<UpdateIssueTypePayload | null, GitHubGlobalError>;
    updateLabel: (args: {
        readonly input: UpdateLabelInput;
    }) => Query<UpdateLabelPayload | null, GitHubGlobalError>;
    updateNotificationRestrictionSetting: (args: {
        readonly input: UpdateNotificationRestrictionSettingInput;
    }) => Query<UpdateNotificationRestrictionSettingPayload | null, GitHubGlobalError>;
    updateOrganizationAllowPrivateRepositoryForkingSetting: (args: {
        readonly input: UpdateOrganizationAllowPrivateRepositoryForkingSettingInput;
    }) => Query<UpdateOrganizationAllowPrivateRepositoryForkingSettingPayload | null, GitHubGlobalError>;
    updateOrganizationWebCommitSignoffSetting: (args: {
        readonly input: UpdateOrganizationWebCommitSignoffSettingInput;
    }) => Query<UpdateOrganizationWebCommitSignoffSettingPayload | null, GitHubGlobalError>;
    updatePatreonSponsorability: (args: {
        readonly input: UpdatePatreonSponsorabilityInput;
    }) => Query<UpdatePatreonSponsorabilityPayload | null, GitHubGlobalError>;
    updateProject: (args: {
        readonly input: UpdateProjectInput;
    }) => Query<UpdateProjectPayload | null, GitHubGlobalError>;
    updateProjectCard: (args: {
        readonly input: UpdateProjectCardInput;
    }) => Query<UpdateProjectCardPayload | null, GitHubGlobalError>;
    updateProjectColumn: (args: {
        readonly input: UpdateProjectColumnInput;
    }) => Query<UpdateProjectColumnPayload | null, GitHubGlobalError>;
    updateProjectV2: (args: {
        readonly input: UpdateProjectV2Input;
    }) => Query<UpdateProjectV2Payload | null, GitHubGlobalError>;
    updateProjectV2Collaborators: (args: {
        readonly input: UpdateProjectV2CollaboratorsInput;
    }) => Query<UpdateProjectV2CollaboratorsPayload | null, GitHubGlobalError>;
    updateProjectV2DraftIssue: (args: {
        readonly input: UpdateProjectV2DraftIssueInput;
    }) => Query<UpdateProjectV2DraftIssuePayload | null, GitHubGlobalError>;
    updateProjectV2Field: (args: {
        readonly input: UpdateProjectV2FieldInput;
    }) => Query<UpdateProjectV2FieldPayload | null, GitHubGlobalError>;
    updateProjectV2ItemFieldValue: (args: {
        readonly input: UpdateProjectV2ItemFieldValueInput;
    }) => Query<UpdateProjectV2ItemFieldValuePayload | null, GitHubGlobalError>;
    updateProjectV2ItemPosition: (args: {
        readonly input: UpdateProjectV2ItemPositionInput;
    }) => Query<UpdateProjectV2ItemPositionPayload | null, GitHubGlobalError>;
    updateProjectV2StatusUpdate: (args: {
        readonly input: UpdateProjectV2StatusUpdateInput;
    }) => Query<UpdateProjectV2StatusUpdatePayload | null, GitHubGlobalError>;
    updateProjectV2View: (args: {
        readonly input: UpdateProjectV2ViewInput;
    }) => Query<UpdateProjectV2ViewPayload | null, GitHubGlobalError>;
    updatePullRequest: (args: {
        readonly input: UpdatePullRequestInput;
    }) => Query<UpdatePullRequestPayload | null, GitHubGlobalError>;
    updatePullRequestBranch: (args: {
        readonly input: UpdatePullRequestBranchInput;
    }) => Query<UpdatePullRequestBranchPayload | null, GitHubGlobalError>;
    updatePullRequestReview: (args: {
        readonly input: UpdatePullRequestReviewInput;
    }) => Query<UpdatePullRequestReviewPayload | null, GitHubGlobalError>;
    updatePullRequestReviewComment: (args: {
        readonly input: UpdatePullRequestReviewCommentInput;
    }) => Query<UpdatePullRequestReviewCommentPayload | null, GitHubGlobalError>;
    updateRef: (args: {
        readonly input: UpdateRefInput;
    }) => Query<UpdateRefPayload | null, GitHubGlobalError>;
    updateRefs: (args: {
        readonly input: UpdateRefsInput;
    }) => Query<UpdateRefsPayload | null, GitHubGlobalError>;
    updateRepository: (args: {
        readonly input: UpdateRepositoryInput;
    }) => Query<UpdateRepositoryPayload | null, GitHubGlobalError>;
    updateRepositoryCustomProperty: (args: {
        readonly input: UpdateRepositoryCustomPropertyInput;
    }) => Query<UpdateRepositoryCustomPropertyPayload | null, GitHubGlobalError>;
    updateRepositoryRuleset: (args: {
        readonly input: UpdateRepositoryRulesetInput;
    }) => Query<UpdateRepositoryRulesetPayload | null, GitHubGlobalError>;
    updateRepositoryWebCommitSignoffSetting: (args: {
        readonly input: UpdateRepositoryWebCommitSignoffSettingInput;
    }) => Query<UpdateRepositoryWebCommitSignoffSettingPayload | null, GitHubGlobalError>;
    updateSponsorshipPreferences: (args: {
        readonly input: UpdateSponsorshipPreferencesInput;
    }) => Query<UpdateSponsorshipPreferencesPayload | null, GitHubGlobalError>;
    updateSubscription: (args: {
        readonly input: UpdateSubscriptionInput;
    }) => Query<UpdateSubscriptionPayload | null, GitHubGlobalError>;
    updateTeamReviewAssignment: (args: {
        readonly input: UpdateTeamReviewAssignmentInput;
    }) => Query<UpdateTeamReviewAssignmentPayload | null, GitHubGlobalError>;
    updateTeamsRepository: (args: {
        readonly input: UpdateTeamsRepositoryInput;
    }) => Query<UpdateTeamsRepositoryPayload | null, GitHubGlobalError>;
    updateTopics: (args: {
        readonly input: UpdateTopicsInput;
    }) => Query<UpdateTopicsPayload | null, GitHubGlobalError>;
    updateUserList: (args: {
        readonly input: UpdateUserListInput;
    }) => Query<UpdateUserListPayload | null, GitHubGlobalError>;
    updateUserListsForItem: (args: {
        readonly input: UpdateUserListsForItemInput;
    }) => Query<UpdateUserListsForItemPayload | null, GitHubGlobalError>;
    verifyVerifiableDomain: (args: {
        readonly input: VerifyVerifiableDomainInput;
    }) => Query<VerifyVerifiableDomainPayload | null, GitHubGlobalError>;
};
export {};
//# sourceMappingURL=graphql.d.ts.map