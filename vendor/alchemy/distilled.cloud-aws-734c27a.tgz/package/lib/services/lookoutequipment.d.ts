import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DatasetName = string;
export type SynthesizedJsonInlineDataSchema = string;
export interface DatasetSchema {
    InlineDataSchema?: string | undefined;
}
export type NameOrArn = string;
export type IdempotenceToken = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateDatasetRequest {
    DatasetName: string;
    DatasetSchema?: DatasetSchema | undefined;
    ServerSideKmsKeyId?: string | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type DatasetArn = string;
export type DatasetStatus = "CREATED" | "INGESTION_IN_PROGRESS" | "ACTIVE" | "IMPORT_IN_PROGRESS" | (string & {});
export interface CreateDatasetResponse {
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: DatasetStatus | undefined;
}
export type ModelName = string;
export type InferenceSchedulerName = string;
export type DataDelayOffsetInMinutes = number;
export type DataUploadFrequency = "PT5M" | "PT10M" | "PT15M" | "PT30M" | "PT1H" | (string & {});
export type S3Bucket = string;
export type S3Prefix = string;
export interface InferenceS3InputConfiguration {
    Bucket: string;
    Prefix?: string | undefined;
}
export type TimeZoneOffset = string;
export type FileNameTimestampFormat = string;
export type ComponentTimestampDelimiter = string;
export interface InferenceInputNameConfiguration {
    TimestampFormat?: string | undefined;
    ComponentTimestampDelimiter?: string | undefined;
}
export interface InferenceInputConfiguration {
    S3InputConfiguration?: InferenceS3InputConfiguration | undefined;
    InputTimeZoneOffset?: string | undefined;
    InferenceInputNameConfiguration?: InferenceInputNameConfiguration | undefined;
}
export interface InferenceS3OutputConfiguration {
    Bucket: string;
    Prefix?: string | undefined;
}
export interface InferenceOutputConfiguration {
    S3OutputConfiguration: InferenceS3OutputConfiguration;
    KmsKeyId?: string | undefined;
}
export type IamRoleArn = string;
export interface CreateInferenceSchedulerRequest {
    ModelName: string;
    InferenceSchedulerName: string;
    DataDelayOffsetInMinutes?: number | undefined;
    DataUploadFrequency: DataUploadFrequency;
    DataInputConfiguration: InferenceInputConfiguration;
    DataOutputConfiguration: InferenceOutputConfiguration;
    RoleArn: string;
    ServerSideKmsKeyId?: string | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type InferenceSchedulerArn = string;
export type InferenceSchedulerStatus = "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export type ModelQuality = "QUALITY_THRESHOLD_MET" | "CANNOT_DETERMINE_QUALITY" | "POOR_QUALITY_DETECTED" | (string & {});
export interface CreateInferenceSchedulerResponse {
    InferenceSchedulerArn?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
    ModelQuality?: ModelQuality | undefined;
}
export type LabelGroupName = string;
export type LabelRating = "ANOMALY" | "NO_ANOMALY" | "NEUTRAL" | (string & {});
export type FaultCode = string;
export type Comments = string;
export type Equipment = string;
export interface CreateLabelRequest {
    LabelGroupName: string;
    StartTime: Date;
    EndTime: Date;
    Rating: LabelRating;
    FaultCode?: string | undefined;
    Notes?: string | undefined;
    Equipment?: string | undefined;
    ClientToken: string;
}
export type LabelId = string;
export interface CreateLabelResponse {
    LabelId?: string | undefined;
}
export type FaultCodes = string[];
export interface CreateLabelGroupRequest {
    LabelGroupName: string;
    FaultCodes?: string[] | undefined;
    ClientToken: string;
    Tags?: Tag[] | undefined;
}
export type LabelGroupArn = string;
export interface CreateLabelGroupResponse {
    LabelGroupName?: string | undefined;
    LabelGroupArn?: string | undefined;
}
export type DatasetIdentifier = string;
export interface LabelsS3InputConfiguration {
    Bucket: string;
    Prefix?: string | undefined;
}
export interface LabelsInputConfiguration {
    S3InputConfiguration?: LabelsS3InputConfiguration | undefined;
    LabelGroupName?: string | undefined;
}
export type TargetSamplingRate = "PT1S" | "PT5S" | "PT10S" | "PT15S" | "PT30S" | "PT1M" | "PT5M" | "PT10M" | "PT15M" | "PT30M" | "PT1H" | (string & {});
export interface DataPreProcessingConfiguration {
    TargetSamplingRate?: TargetSamplingRate | undefined;
}
export type OffCondition = string;
export interface ModelDiagnosticsS3OutputConfiguration {
    Bucket: string;
    Prefix?: string | undefined;
}
export interface ModelDiagnosticsOutputConfiguration {
    S3OutputConfiguration: ModelDiagnosticsS3OutputConfiguration;
    KmsKeyId?: string | undefined;
}
export interface CreateModelRequest {
    ModelName: string;
    DatasetName: string;
    DatasetSchema?: DatasetSchema | undefined;
    LabelsInputConfiguration?: LabelsInputConfiguration | undefined;
    ClientToken: string;
    TrainingDataStartTime?: Date | undefined;
    TrainingDataEndTime?: Date | undefined;
    EvaluationDataStartTime?: Date | undefined;
    EvaluationDataEndTime?: Date | undefined;
    RoleArn?: string | undefined;
    DataPreProcessingConfiguration?: DataPreProcessingConfiguration | undefined;
    ServerSideKmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
    OffCondition?: string | undefined;
    ModelDiagnosticsOutputConfiguration?: ModelDiagnosticsOutputConfiguration | undefined;
}
export type ModelArn = string;
export type ModelStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | "IMPORT_IN_PROGRESS" | (string & {});
export interface CreateModelResponse {
    ModelArn?: string | undefined;
    Status?: ModelStatus | undefined;
}
export type RetrainingFrequency = string;
export type LookbackWindow = string;
export type ModelPromoteMode = "MANAGED" | "MANUAL" | (string & {});
export interface CreateRetrainingSchedulerRequest {
    ModelName: string;
    RetrainingStartDate?: Date | undefined;
    RetrainingFrequency: string;
    LookbackWindow: string;
    PromoteMode?: ModelPromoteMode | undefined;
    ClientToken: string;
}
export type RetrainingSchedulerStatus = "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export interface CreateRetrainingSchedulerResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
}
export interface DeleteDatasetRequest {
    DatasetName: string;
}
export interface DeleteDatasetResponse {
}
export type InferenceSchedulerIdentifier = string;
export interface DeleteInferenceSchedulerRequest {
    InferenceSchedulerName: string;
}
export interface DeleteInferenceSchedulerResponse {
}
export interface DeleteLabelRequest {
    LabelGroupName: string;
    LabelId: string;
}
export interface DeleteLabelResponse {
}
export interface DeleteLabelGroupRequest {
    LabelGroupName: string;
}
export interface DeleteLabelGroupResponse {
}
export interface DeleteModelRequest {
    ModelName: string;
}
export interface DeleteModelResponse {
}
export type ResourceArn = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteRetrainingSchedulerRequest {
    ModelName: string;
}
export interface DeleteRetrainingSchedulerResponse {
}
export type IngestionJobId = string;
export interface DescribeDataIngestionJobRequest {
    JobId: string;
}
export type KeyPattern = string;
export interface IngestionS3InputConfiguration {
    Bucket: string;
    Prefix?: string | undefined;
    KeyPattern?: string | undefined;
}
export interface IngestionInputConfiguration {
    S3InputConfiguration: IngestionS3InputConfiguration;
}
export type IngestionJobStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | "IMPORT_IN_PROGRESS" | (string & {});
export type BoundedLengthString = string;
export interface MissingCompleteSensorData {
    AffectedSensorCount: number;
}
export interface SensorsWithShortDateRange {
    AffectedSensorCount: number;
}
export interface InsufficientSensorData {
    MissingCompleteSensorData: MissingCompleteSensorData;
    SensorsWithShortDateRange: SensorsWithShortDateRange;
}
export interface MissingSensorData {
    AffectedSensorCount: number;
    TotalNumberOfMissingValues: number;
}
export interface InvalidSensorData {
    AffectedSensorCount: number;
    TotalNumberOfInvalidValues: number;
}
export interface UnsupportedTimestamps {
    TotalNumberOfUnsupportedTimestamps: number;
}
export interface DuplicateTimestamps {
    TotalNumberOfDuplicateTimestamps: number;
}
export interface DataQualitySummary {
    InsufficientSensorData: InsufficientSensorData;
    MissingSensorData: MissingSensorData;
    InvalidSensorData: InvalidSensorData;
    UnsupportedTimestamps: UnsupportedTimestamps;
    DuplicateTimestamps: DuplicateTimestamps;
}
export type S3Key = string;
export interface S3Object {
    Bucket: string;
    Key: string;
}
export type ListOfDiscardedFiles = S3Object[];
export interface IngestedFilesSummary {
    TotalNumberOfFiles: number;
    IngestedNumberOfFiles: number;
    DiscardedFiles?: S3Object[] | undefined;
}
export type DataSizeInBytes = number;
export interface DescribeDataIngestionJobResponse {
    JobId?: string | undefined;
    DatasetArn?: string | undefined;
    IngestionInputConfiguration?: IngestionInputConfiguration | undefined;
    RoleArn?: string | undefined;
    CreatedAt?: Date | undefined;
    Status?: IngestionJobStatus | undefined;
    FailedReason?: string | undefined;
    DataQualitySummary?: DataQualitySummary | undefined;
    IngestedFilesSummary?: IngestedFilesSummary | undefined;
    StatusDetail?: string | undefined;
    IngestedDataSize?: number | undefined;
    DataStartTime?: Date | undefined;
    DataEndTime?: Date | undefined;
    SourceDatasetArn?: string | undefined;
}
export interface DescribeDatasetRequest {
    DatasetName: string;
}
export type KmsKeyArn = string;
export interface DescribeDatasetResponse {
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Status?: DatasetStatus | undefined;
    Schema?: string | undefined;
    ServerSideKmsKeyId?: string | undefined;
    IngestionInputConfiguration?: IngestionInputConfiguration | undefined;
    DataQualitySummary?: DataQualitySummary | undefined;
    IngestedFilesSummary?: IngestedFilesSummary | undefined;
    RoleArn?: string | undefined;
    DataStartTime?: Date | undefined;
    DataEndTime?: Date | undefined;
    SourceDatasetArn?: string | undefined;
}
export interface DescribeInferenceSchedulerRequest {
    InferenceSchedulerName: string;
}
export type LatestInferenceResult = "ANOMALOUS" | "NORMAL" | (string & {});
export interface DescribeInferenceSchedulerResponse {
    ModelArn?: string | undefined;
    ModelName?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    InferenceSchedulerArn?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
    DataDelayOffsetInMinutes?: number | undefined;
    DataUploadFrequency?: DataUploadFrequency | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    DataInputConfiguration?: InferenceInputConfiguration | undefined;
    DataOutputConfiguration?: InferenceOutputConfiguration | undefined;
    RoleArn?: string | undefined;
    ServerSideKmsKeyId?: string | undefined;
    LatestInferenceResult?: LatestInferenceResult | undefined;
}
export interface DescribeLabelRequest {
    LabelGroupName: string;
    LabelId: string;
}
export interface DescribeLabelResponse {
    LabelGroupName?: string | undefined;
    LabelGroupArn?: string | undefined;
    LabelId?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Rating?: LabelRating | undefined;
    FaultCode?: string | undefined;
    Notes?: string | undefined;
    Equipment?: string | undefined;
    CreatedAt?: Date | undefined;
}
export interface DescribeLabelGroupRequest {
    LabelGroupName: string;
}
export interface DescribeLabelGroupResponse {
    LabelGroupName?: string | undefined;
    LabelGroupArn?: string | undefined;
    FaultCodes?: string[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface DescribeModelRequest {
    ModelName: string;
}
export type SynthesizedJsonModelMetrics = string;
export type ModelVersionArn = string;
export type ModelVersion = number;
export type ModelVersionStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | "IMPORT_IN_PROGRESS" | "CANCELED" | (string & {});
export interface DescribeModelResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Schema?: string | undefined;
    LabelsInputConfiguration?: LabelsInputConfiguration | undefined;
    TrainingDataStartTime?: Date | undefined;
    TrainingDataEndTime?: Date | undefined;
    EvaluationDataStartTime?: Date | undefined;
    EvaluationDataEndTime?: Date | undefined;
    RoleArn?: string | undefined;
    DataPreProcessingConfiguration?: DataPreProcessingConfiguration | undefined;
    Status?: ModelStatus | undefined;
    TrainingExecutionStartTime?: Date | undefined;
    TrainingExecutionEndTime?: Date | undefined;
    FailedReason?: string | undefined;
    ModelMetrics?: string | undefined;
    LastUpdatedTime?: Date | undefined;
    CreatedAt?: Date | undefined;
    ServerSideKmsKeyId?: string | undefined;
    OffCondition?: string | undefined;
    SourceModelVersionArn?: string | undefined;
    ImportJobStartTime?: Date | undefined;
    ImportJobEndTime?: Date | undefined;
    ActiveModelVersion?: number | undefined;
    ActiveModelVersionArn?: string | undefined;
    ModelVersionActivatedAt?: Date | undefined;
    PreviousActiveModelVersion?: number | undefined;
    PreviousActiveModelVersionArn?: string | undefined;
    PreviousModelVersionActivatedAt?: Date | undefined;
    PriorModelMetrics?: string | undefined;
    LatestScheduledRetrainingFailedReason?: string | undefined;
    LatestScheduledRetrainingStatus?: ModelVersionStatus | undefined;
    LatestScheduledRetrainingModelVersion?: number | undefined;
    LatestScheduledRetrainingStartTime?: Date | undefined;
    LatestScheduledRetrainingAvailableDataInDays?: number | undefined;
    NextScheduledRetrainingStartDate?: Date | undefined;
    AccumulatedInferenceDataStartTime?: Date | undefined;
    AccumulatedInferenceDataEndTime?: Date | undefined;
    RetrainingSchedulerStatus?: RetrainingSchedulerStatus | undefined;
    ModelDiagnosticsOutputConfiguration?: ModelDiagnosticsOutputConfiguration | undefined;
    ModelQuality?: ModelQuality | undefined;
}
export interface DescribeModelVersionRequest {
    ModelName: string;
    ModelVersion: number;
}
export type ModelVersionSourceType = "TRAINING" | "RETRAINING" | "IMPORT" | (string & {});
export type InlineDataSchema = string;
export type ModelMetrics = string;
export type AutoPromotionResult = "MODEL_PROMOTED" | "MODEL_NOT_PROMOTED" | "RETRAINING_INTERNAL_ERROR" | "RETRAINING_CUSTOMER_ERROR" | "RETRAINING_CANCELLED" | (string & {});
export type AutoPromotionResultReason = string;
export interface DescribeModelVersionResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    ModelVersion?: number | undefined;
    ModelVersionArn?: string | undefined;
    Status?: ModelVersionStatus | undefined;
    SourceType?: ModelVersionSourceType | undefined;
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Schema?: string | undefined;
    LabelsInputConfiguration?: LabelsInputConfiguration | undefined;
    TrainingDataStartTime?: Date | undefined;
    TrainingDataEndTime?: Date | undefined;
    EvaluationDataStartTime?: Date | undefined;
    EvaluationDataEndTime?: Date | undefined;
    RoleArn?: string | undefined;
    DataPreProcessingConfiguration?: DataPreProcessingConfiguration | undefined;
    TrainingExecutionStartTime?: Date | undefined;
    TrainingExecutionEndTime?: Date | undefined;
    FailedReason?: string | undefined;
    ModelMetrics?: string | undefined;
    LastUpdatedTime?: Date | undefined;
    CreatedAt?: Date | undefined;
    ServerSideKmsKeyId?: string | undefined;
    OffCondition?: string | undefined;
    SourceModelVersionArn?: string | undefined;
    ImportJobStartTime?: Date | undefined;
    ImportJobEndTime?: Date | undefined;
    ImportedDataSizeInBytes?: number | undefined;
    PriorModelMetrics?: string | undefined;
    RetrainingAvailableDataInDays?: number | undefined;
    AutoPromotionResult?: AutoPromotionResult | undefined;
    AutoPromotionResultReason?: string | undefined;
    ModelDiagnosticsOutputConfiguration?: ModelDiagnosticsOutputConfiguration | undefined;
    ModelDiagnosticsResultsObject?: S3Object | undefined;
    ModelQuality?: ModelQuality | undefined;
}
export interface DescribeResourcePolicyRequest {
    ResourceArn: string;
}
export type PolicyRevisionId = string;
export type Policy = string;
export interface DescribeResourcePolicyResponse {
    PolicyRevisionId?: string | undefined;
    ResourcePolicy?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DescribeRetrainingSchedulerRequest {
    ModelName: string;
}
export interface DescribeRetrainingSchedulerResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    RetrainingStartDate?: Date | undefined;
    RetrainingFrequency?: string | undefined;
    LookbackWindow?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
    PromoteMode?: ModelPromoteMode | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface ImportDatasetRequest {
    SourceDatasetArn: string;
    DatasetName?: string | undefined;
    ClientToken: string;
    ServerSideKmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportDatasetResponse {
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: DatasetStatus | undefined;
    JobId?: string | undefined;
}
export type InferenceDataImportStrategy = "NO_IMPORT" | "ADD_WHEN_EMPTY" | "OVERWRITE" | (string & {});
export interface ImportModelVersionRequest {
    SourceModelVersionArn: string;
    ModelName?: string | undefined;
    DatasetName: string;
    LabelsInputConfiguration?: LabelsInputConfiguration | undefined;
    ClientToken: string;
    RoleArn?: string | undefined;
    ServerSideKmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
    InferenceDataImportStrategy?: InferenceDataImportStrategy | undefined;
}
export interface ImportModelVersionResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    ModelVersionArn?: string | undefined;
    ModelVersion?: number | undefined;
    Status?: ModelVersionStatus | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListDataIngestionJobsRequest {
    DatasetName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: IngestionJobStatus | undefined;
}
export interface DataIngestionJobSummary {
    JobId?: string | undefined;
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    IngestionInputConfiguration?: IngestionInputConfiguration | undefined;
    Status?: IngestionJobStatus | undefined;
}
export type DataIngestionJobSummaries = DataIngestionJobSummary[];
export interface ListDataIngestionJobsResponse {
    NextToken?: string | undefined;
    DataIngestionJobSummaries?: DataIngestionJobSummary[] | undefined;
}
export interface ListDatasetsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DatasetNameBeginsWith?: string | undefined;
}
export interface DatasetSummary {
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: DatasetStatus | undefined;
    CreatedAt?: Date | undefined;
}
export type DatasetSummaries = DatasetSummary[];
export interface ListDatasetsResponse {
    NextToken?: string | undefined;
    DatasetSummaries?: DatasetSummary[] | undefined;
}
export interface ListInferenceEventsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    InferenceSchedulerName: string;
    IntervalStartTime: Date;
    IntervalEndTime: Date;
}
export type EventDurationInSeconds = number;
export interface InferenceEventSummary {
    InferenceSchedulerArn?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    EventStartTime?: Date | undefined;
    EventEndTime?: Date | undefined;
    Diagnostics?: string | undefined;
    EventDurationInSeconds?: number | undefined;
}
export type InferenceEventSummaries = InferenceEventSummary[];
export interface ListInferenceEventsResponse {
    NextToken?: string | undefined;
    InferenceEventSummaries?: InferenceEventSummary[] | undefined;
}
export type InferenceExecutionStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | (string & {});
export interface ListInferenceExecutionsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    InferenceSchedulerName: string;
    DataStartTimeAfter?: Date | undefined;
    DataEndTimeBefore?: Date | undefined;
    Status?: InferenceExecutionStatus | undefined;
}
export interface InferenceExecutionSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    InferenceSchedulerArn?: string | undefined;
    ScheduledStartTime?: Date | undefined;
    DataStartTime?: Date | undefined;
    DataEndTime?: Date | undefined;
    DataInputConfiguration?: InferenceInputConfiguration | undefined;
    DataOutputConfiguration?: InferenceOutputConfiguration | undefined;
    CustomerResultObject?: S3Object | undefined;
    Status?: InferenceExecutionStatus | undefined;
    FailedReason?: string | undefined;
    ModelVersion?: number | undefined;
    ModelVersionArn?: string | undefined;
}
export type InferenceExecutionSummaries = InferenceExecutionSummary[];
export interface ListInferenceExecutionsResponse {
    NextToken?: string | undefined;
    InferenceExecutionSummaries?: InferenceExecutionSummary[] | undefined;
}
export interface ListInferenceSchedulersRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    InferenceSchedulerNameBeginsWith?: string | undefined;
    ModelName?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
}
export interface InferenceSchedulerSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    InferenceSchedulerArn?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
    DataDelayOffsetInMinutes?: number | undefined;
    DataUploadFrequency?: DataUploadFrequency | undefined;
    LatestInferenceResult?: LatestInferenceResult | undefined;
}
export type InferenceSchedulerSummaries = InferenceSchedulerSummary[];
export interface ListInferenceSchedulersResponse {
    NextToken?: string | undefined;
    InferenceSchedulerSummaries?: InferenceSchedulerSummary[] | undefined;
}
export interface ListLabelGroupsRequest {
    LabelGroupNameBeginsWith?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LabelGroupSummary {
    LabelGroupName?: string | undefined;
    LabelGroupArn?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type LabelGroupSummaries = LabelGroupSummary[];
export interface ListLabelGroupsResponse {
    NextToken?: string | undefined;
    LabelGroupSummaries?: LabelGroupSummary[] | undefined;
}
export interface ListLabelsRequest {
    LabelGroupName: string;
    IntervalStartTime?: Date | undefined;
    IntervalEndTime?: Date | undefined;
    FaultCode?: string | undefined;
    Equipment?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LabelSummary {
    LabelGroupName?: string | undefined;
    LabelId?: string | undefined;
    LabelGroupArn?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Rating?: LabelRating | undefined;
    FaultCode?: string | undefined;
    Equipment?: string | undefined;
    CreatedAt?: Date | undefined;
}
export type LabelSummaries = LabelSummary[];
export interface ListLabelsResponse {
    NextToken?: string | undefined;
    LabelSummaries?: LabelSummary[] | undefined;
}
export interface ListModelsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ModelStatus | undefined;
    ModelNameBeginsWith?: string | undefined;
    DatasetNameBeginsWith?: string | undefined;
}
export interface ModelSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    DatasetName?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: ModelStatus | undefined;
    CreatedAt?: Date | undefined;
    ActiveModelVersion?: number | undefined;
    ActiveModelVersionArn?: string | undefined;
    LatestScheduledRetrainingStatus?: ModelVersionStatus | undefined;
    LatestScheduledRetrainingModelVersion?: number | undefined;
    LatestScheduledRetrainingStartTime?: Date | undefined;
    NextScheduledRetrainingStartDate?: Date | undefined;
    RetrainingSchedulerStatus?: RetrainingSchedulerStatus | undefined;
    ModelDiagnosticsOutputConfiguration?: ModelDiagnosticsOutputConfiguration | undefined;
    ModelQuality?: ModelQuality | undefined;
}
export type ModelSummaries = ModelSummary[];
export interface ListModelsResponse {
    NextToken?: string | undefined;
    ModelSummaries?: ModelSummary[] | undefined;
}
export interface ListModelVersionsRequest {
    ModelName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: ModelVersionStatus | undefined;
    SourceType?: ModelVersionSourceType | undefined;
    CreatedAtEndTime?: Date | undefined;
    CreatedAtStartTime?: Date | undefined;
    MaxModelVersion?: number | undefined;
    MinModelVersion?: number | undefined;
}
export interface ModelVersionSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    ModelVersion?: number | undefined;
    ModelVersionArn?: string | undefined;
    CreatedAt?: Date | undefined;
    Status?: ModelVersionStatus | undefined;
    SourceType?: ModelVersionSourceType | undefined;
    ModelQuality?: ModelQuality | undefined;
}
export type ModelVersionSummaries = ModelVersionSummary[];
export interface ListModelVersionsResponse {
    NextToken?: string | undefined;
    ModelVersionSummaries?: ModelVersionSummary[] | undefined;
}
export interface ListRetrainingSchedulersRequest {
    ModelNameBeginsWith?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RetrainingSchedulerSummary {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
    RetrainingStartDate?: Date | undefined;
    RetrainingFrequency?: string | undefined;
    LookbackWindow?: string | undefined;
}
export type RetrainingSchedulerSummaries = RetrainingSchedulerSummary[];
export interface ListRetrainingSchedulersResponse {
    RetrainingSchedulerSummaries?: RetrainingSchedulerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSensorStatisticsRequest {
    DatasetName: string;
    IngestionJobId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ComponentName = string;
export type SensorName = string;
export interface CountPercent {
    Count: number;
    Percentage: number;
}
export type StatisticalIssueStatus = "POTENTIAL_ISSUE_DETECTED" | "NO_ISSUE_DETECTED" | (string & {});
export interface CategoricalValues {
    Status: StatisticalIssueStatus;
    NumberOfCategory?: number | undefined;
}
export interface MultipleOperatingModes {
    Status: StatisticalIssueStatus;
}
export interface LargeTimestampGaps {
    Status: StatisticalIssueStatus;
    NumberOfLargeTimestampGaps?: number | undefined;
    MaxTimestampGapInDays?: number | undefined;
}
export type Monotonicity = "DECREASING" | "INCREASING" | "STATIC" | (string & {});
export interface MonotonicValues {
    Status: StatisticalIssueStatus;
    Monotonicity?: Monotonicity | undefined;
}
export interface SensorStatisticsSummary {
    ComponentName?: string | undefined;
    SensorName?: string | undefined;
    DataExists?: boolean | undefined;
    MissingValues?: CountPercent | undefined;
    InvalidValues?: CountPercent | undefined;
    InvalidDateEntries?: CountPercent | undefined;
    DuplicateTimestamps?: CountPercent | undefined;
    CategoricalValues?: CategoricalValues | undefined;
    MultipleOperatingModes?: MultipleOperatingModes | undefined;
    LargeTimestampGaps?: LargeTimestampGaps | undefined;
    MonotonicValues?: MonotonicValues | undefined;
    DataStartTime?: Date | undefined;
    DataEndTime?: Date | undefined;
}
export type SensorStatisticsSummaries = SensorStatisticsSummary[];
export interface ListSensorStatisticsResponse {
    SensorStatisticsSummaries?: SensorStatisticsSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    ResourcePolicy: string;
    PolicyRevisionId?: string | undefined;
    ClientToken: string;
}
export interface PutResourcePolicyResponse {
    ResourceArn?: string | undefined;
    PolicyRevisionId?: string | undefined;
}
export interface StartDataIngestionJobRequest {
    DatasetName: string;
    IngestionInputConfiguration: IngestionInputConfiguration;
    RoleArn: string;
    ClientToken: string;
}
export interface StartDataIngestionJobResponse {
    JobId?: string | undefined;
    Status?: IngestionJobStatus | undefined;
}
export interface StartInferenceSchedulerRequest {
    InferenceSchedulerName: string;
}
export interface StartInferenceSchedulerResponse {
    ModelArn?: string | undefined;
    ModelName?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    InferenceSchedulerArn?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
}
export interface StartRetrainingSchedulerRequest {
    ModelName: string;
}
export interface StartRetrainingSchedulerResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
}
export interface StopInferenceSchedulerRequest {
    InferenceSchedulerName: string;
}
export interface StopInferenceSchedulerResponse {
    ModelArn?: string | undefined;
    ModelName?: string | undefined;
    InferenceSchedulerName?: string | undefined;
    InferenceSchedulerArn?: string | undefined;
    Status?: InferenceSchedulerStatus | undefined;
}
export interface StopRetrainingSchedulerRequest {
    ModelName: string;
}
export interface StopRetrainingSchedulerResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    Status?: RetrainingSchedulerStatus | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateActiveModelVersionRequest {
    ModelName: string;
    ModelVersion: number;
}
export interface UpdateActiveModelVersionResponse {
    ModelName?: string | undefined;
    ModelArn?: string | undefined;
    CurrentActiveVersion?: number | undefined;
    PreviousActiveVersion?: number | undefined;
    CurrentActiveVersionArn?: string | undefined;
    PreviousActiveVersionArn?: string | undefined;
}
export interface UpdateInferenceSchedulerRequest {
    InferenceSchedulerName: string;
    DataDelayOffsetInMinutes?: number | undefined;
    DataUploadFrequency?: DataUploadFrequency | undefined;
    DataInputConfiguration?: InferenceInputConfiguration | undefined;
    DataOutputConfiguration?: InferenceOutputConfiguration | undefined;
    RoleArn?: string | undefined;
}
export interface UpdateInferenceSchedulerResponse {
}
export interface UpdateLabelGroupRequest {
    LabelGroupName: string;
    FaultCodes?: string[] | undefined;
}
export interface UpdateLabelGroupResponse {
}
export interface UpdateModelRequest {
    ModelName: string;
    LabelsInputConfiguration?: LabelsInputConfiguration | undefined;
    RoleArn?: string | undefined;
    ModelDiagnosticsOutputConfiguration?: ModelDiagnosticsOutputConfiguration | undefined;
}
export interface UpdateModelResponse {
}
export interface UpdateRetrainingSchedulerRequest {
    ModelName: string;
    RetrainingStartDate?: Date | undefined;
    RetrainingFrequency?: string | undefined;
    LookbackWindow?: string | undefined;
    PromoteMode?: ModelPromoteMode | undefined;
}
export interface UpdateRetrainingSchedulerResponse {
}
export type CreateDatasetError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a container for a collection of data being ingested for analysis. The dataset
 * contains the metadata describing where the data is and what the data actually looks like.
 * For example, it contains the location of the data source, the data schema, and other
 * information. A dataset also contains any tags associated with the ingested data.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest & RegionInput, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scheduled inference. Scheduling an inference is setting up a continuous
 * real-time inference plan to analyze new measurement data. When setting up the schedule, you
 * provide an S3 bucket location for the input data, assign it a delimiter between separate
 * entries in the data, set an offset delay if desired, and set the frequency of inferencing.
 * You must also provide an S3 bucket location for the output data.
 */
export declare const createInferenceScheduler: API.OperationMethod<CreateInferenceSchedulerRequest & RegionInput, CreateInferenceSchedulerResponse, CreateInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type CreateLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a label for an event.
 */
export declare const createLabel: API.OperationMethod<CreateLabelRequest & RegionInput, CreateLabelResponse, CreateLabelError, Credentials | HttpClient.HttpClient>;
export type CreateLabelGroupError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a group of labels.
 */
export declare const createLabelGroup: API.OperationMethod<CreateLabelGroupRequest & RegionInput, CreateLabelGroupResponse, CreateLabelGroupError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a machine learning model for data inference.
 *
 * A machine-learning (ML) model is a mathematical model that finds patterns in your data.
 * In Amazon Lookout for Equipment, the model learns the patterns of normal behavior and detects abnormal
 * behavior that could be potential equipment failure (or maintenance events). The models are
 * made by analyzing normal data and abnormalities in machine behavior that have already
 * occurred.
 *
 * Your model is trained using a portion of the data from your dataset and uses that data
 * to learn patterns of normal behavior and abnormal patterns that lead to equipment failure.
 * Another portion of the data is used to evaluate the model's accuracy.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest & RegionInput, CreateModelResponse, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateRetrainingSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a retraining scheduler on the specified model.
 */
export declare const createRetrainingScheduler: API.OperationMethod<CreateRetrainingSchedulerRequest & RegionInput, CreateRetrainingSchedulerResponse, CreateRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a dataset and associated artifacts. The operation will check to see if any
 * inference scheduler or data ingestion job is currently using the dataset, and if there
 * isn't, the dataset, its metadata, and any associated data stored in S3 will be deleted.
 * This does not affect any models that used this dataset for training and evaluation, but
 * does prevent it from being used in the future.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest & RegionInput, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteInferenceSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an inference scheduler that has been set up. Prior inference results will not be
 * deleted.
 */
export declare const deleteInferenceScheduler: API.OperationMethod<DeleteInferenceSchedulerRequest & RegionInput, DeleteInferenceSchedulerResponse, DeleteInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type DeleteLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a label.
 */
export declare const deleteLabel: API.OperationMethod<DeleteLabelRequest & RegionInput, DeleteLabelResponse, DeleteLabelError, Credentials | HttpClient.HttpClient>;
export type DeleteLabelGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group of labels.
 */
export declare const deleteLabelGroup: API.OperationMethod<DeleteLabelGroupRequest & RegionInput, DeleteLabelGroupResponse, DeleteLabelGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a machine learning model currently available for Amazon Lookout for Equipment. This will prevent it
 * from being used with an inference scheduler, even one that is already set up.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest & RegionInput, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy attached to the resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRetrainingSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a retraining scheduler from a model. The retraining scheduler must be in the
 * `STOPPED` status.
 */
export declare const deleteRetrainingScheduler: API.OperationMethod<DeleteRetrainingSchedulerRequest & RegionInput, DeleteRetrainingSchedulerResponse, DeleteRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export type DescribeDataIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides information on a specific data ingestion job such as creation time, dataset
 * ARN, and status.
 */
export declare const describeDataIngestionJob: API.OperationMethod<DescribeDataIngestionJobRequest & RegionInput, DescribeDataIngestionJobResponse, DescribeDataIngestionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a JSON description of the data in each time series dataset, including names,
 * column names, and data types.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest & RegionInput, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeInferenceSchedulerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies information about the inference scheduler being used, including name, model,
 * status, and associated metadata
 */
export declare const describeInferenceScheduler: API.OperationMethod<DescribeInferenceSchedulerRequest & RegionInput, DescribeInferenceSchedulerResponse, DescribeInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type DescribeLabelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the name of the label.
 */
export declare const describeLabel: API.OperationMethod<DescribeLabelRequest & RegionInput, DescribeLabelResponse, DescribeLabelError, Credentials | HttpClient.HttpClient>;
export type DescribeLabelGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the label group.
 */
export declare const describeLabelGroup: API.OperationMethod<DescribeLabelGroupRequest & RegionInput, DescribeLabelGroupResponse, DescribeLabelGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a JSON containing the overall information about a specific machine learning
 * model, including model name and ARN, dataset, training and evaluation information, status,
 * and so on.
 */
export declare const describeModel: API.OperationMethod<DescribeModelRequest & RegionInput, DescribeModelResponse, DescribeModelError, Credentials | HttpClient.HttpClient>;
export type DescribeModelVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific machine learning model version.
 */
export declare const describeModelVersion: API.OperationMethod<DescribeModelVersionRequest & RegionInput, DescribeModelVersionResponse, DescribeModelVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details of a resource policy attached to a resource.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeRetrainingSchedulerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a description of the retraining scheduler, including information such as the
 * model name and retraining parameters.
 */
export declare const describeRetrainingScheduler: API.OperationMethod<DescribeRetrainingSchedulerRequest & RegionInput, DescribeRetrainingSchedulerResponse, DescribeRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export type ImportDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports a dataset.
 */
export declare const importDataset: API.OperationMethod<ImportDatasetRequest & RegionInput, ImportDatasetResponse, ImportDatasetError, Credentials | HttpClient.HttpClient>;
export type ImportModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports a model that has been trained successfully.
 */
export declare const importModelVersion: API.OperationMethod<ImportModelVersionRequest & RegionInput, ImportModelVersionResponse, ImportModelVersionError, Credentials | HttpClient.HttpClient>;
export type ListDataIngestionJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of all data ingestion jobs, including dataset name and ARN, S3 location
 * of the input data, status, and so on.
 */
export declare const listDataIngestionJobs: API.PaginatedOperationMethod<ListDataIngestionJobsRequest & RegionInput, ListDataIngestionJobsResponse, ListDataIngestionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDatasetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all datasets currently available in your account, filtering on the dataset name.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest & RegionInput, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInferenceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all inference events that have been found for the specified inference scheduler.
 */
export declare const listInferenceEvents: API.PaginatedOperationMethod<ListInferenceEventsRequest & RegionInput, ListInferenceEventsResponse, ListInferenceEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInferenceExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all inference executions that have been performed by the specified inference
 * scheduler.
 */
export declare const listInferenceExecutions: API.PaginatedOperationMethod<ListInferenceExecutionsRequest & RegionInput, ListInferenceExecutionsResponse, ListInferenceExecutionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInferenceSchedulersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all inference schedulers currently available for your account.
 */
export declare const listInferenceSchedulers: API.PaginatedOperationMethod<ListInferenceSchedulersRequest & RegionInput, ListInferenceSchedulersResponse, ListInferenceSchedulersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLabelGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the label groups.
 */
export declare const listLabelGroups: API.PaginatedOperationMethod<ListLabelGroupsRequest & RegionInput, ListLabelGroupsResponse, ListLabelGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLabelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of labels.
 */
export declare const listLabels: API.PaginatedOperationMethod<ListLabelsRequest & RegionInput, ListLabelsResponse, ListLabelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a list of all models in the account, including model name and ARN, dataset,
 * and status.
 */
export declare const listModels: API.PaginatedOperationMethod<ListModelsRequest & RegionInput, ListModelsResponse, ListModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListModelVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a list of all model versions for a given model, including the model version,
 * model version ARN, and status. To list a subset of versions, use the
 * `MaxModelVersion` and `MinModelVersion` fields.
 */
export declare const listModelVersions: API.PaginatedOperationMethod<ListModelVersionsRequest & RegionInput, ListModelVersionsResponse, ListModelVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRetrainingSchedulersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all retraining schedulers in your account, filtering by model name prefix and
 * status.
 */
export declare const listRetrainingSchedulers: API.PaginatedOperationMethod<ListRetrainingSchedulersRequest & RegionInput, ListRetrainingSchedulersResponse, ListRetrainingSchedulersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSensorStatisticsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists statistics about the data collected for each of the sensors that have been
 * successfully ingested in the particular dataset. Can also be used to retreive Sensor
 * Statistics for a previous ingestion job.
 */
export declare const listSensorStatistics: API.PaginatedOperationMethod<ListSensorStatisticsRequest & RegionInput, ListSensorStatisticsResponse, ListSensorStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the tags for a specified resource, including key and value.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a resource control policy for a given resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartDataIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data ingestion job. Amazon Lookout for Equipment returns the job status.
 */
export declare const startDataIngestionJob: API.OperationMethod<StartDataIngestionJobRequest & RegionInput, StartDataIngestionJobResponse, StartDataIngestionJobError, Credentials | HttpClient.HttpClient>;
export type StartInferenceSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an inference scheduler.
 */
export declare const startInferenceScheduler: API.OperationMethod<StartInferenceSchedulerRequest & RegionInput, StartInferenceSchedulerResponse, StartInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type StartRetrainingSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a retraining scheduler.
 */
export declare const startRetrainingScheduler: API.OperationMethod<StartRetrainingSchedulerRequest & RegionInput, StartRetrainingSchedulerResponse, StartRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export type StopInferenceSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an inference scheduler.
 */
export declare const stopInferenceScheduler: API.OperationMethod<StopInferenceSchedulerRequest & RegionInput, StopInferenceSchedulerResponse, StopInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type StopRetrainingSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a retraining scheduler.
 */
export declare const stopRetrainingScheduler: API.OperationMethod<StopRetrainingSchedulerRequest & RegionInput, StopRetrainingSchedulerResponse, StopRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a given tag to a resource in your account. A tag is a key-value pair which
 * can be added to an Amazon Lookout for Equipment resource as metadata. Tags can be used for organizing your
 * resources as well as helping you to search and filter by tag. Multiple tags can be added to
 * a resource, either when you create it, or later. Up to 50 tags can be associated with each
 * resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a specific tag from a given resource. The tag is specified by its key.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateActiveModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the active model version for a given machine learning model.
 */
export declare const updateActiveModelVersion: API.OperationMethod<UpdateActiveModelVersionRequest & RegionInput, UpdateActiveModelVersionResponse, UpdateActiveModelVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateInferenceSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an inference scheduler.
 */
export declare const updateInferenceScheduler: API.OperationMethod<UpdateInferenceSchedulerRequest & RegionInput, UpdateInferenceSchedulerResponse, UpdateInferenceSchedulerError, Credentials | HttpClient.HttpClient>;
export type UpdateLabelGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the label group.
 */
export declare const updateLabelGroup: API.OperationMethod<UpdateLabelGroupRequest & RegionInput, UpdateLabelGroupResponse, UpdateLabelGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a model in the account.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest & RegionInput, UpdateModelResponse, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdateRetrainingSchedulerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a retraining scheduler.
 */
export declare const updateRetrainingScheduler: API.OperationMethod<UpdateRetrainingSchedulerRequest & RegionInput, UpdateRetrainingSchedulerResponse, UpdateRetrainingSchedulerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lookoutequipment.d.ts.map