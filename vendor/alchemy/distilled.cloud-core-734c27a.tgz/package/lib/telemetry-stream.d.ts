import { type AttributeRule, type SpanHold } from "./telemetry.ts";
export interface StreamRule {
    /** The output member holding the stream (the generated property name). */
    readonly member: string;
    /** Attribute for the seconds from the span's start to the first item. */
    readonly firstChunk?: string;
    /** Attributes read from each item, by event member (the generated property name). */
    readonly events?: Readonly<Record<string, ReadonlyArray<AttributeRule>>>;
}
export declare const holdForStream: (rule: StreamRule) => SpanHold;
//# sourceMappingURL=telemetry-stream.d.ts.map