import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const GatewayTimeoutException_base: S.TaggedErrorClass<"GatewayTimeoutException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly LimitType: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export interface CloneBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
    TargetEnvironmentName?: string | undefined;
}
export interface CloneBackendResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface ResourceConfig {
}
export interface CreateBackendRequest {
    AppId?: string | undefined;
    AppName?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    ResourceConfig?: ResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface CreateBackendResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export type Mode = "API_KEY" | "AWS_IAM" | "AMAZON_COGNITO_USER_POOLS" | "OPENID_CONNECT" | (string & {});
export interface BackendAPIAppSyncAuthSettings {
    CognitoUserPoolId?: string | undefined;
    Description?: string | undefined;
    ExpirationTime?: number | undefined;
    OpenIDAuthTTL?: string | undefined;
    OpenIDClientId?: string | undefined;
    OpenIDIatTTL?: string | undefined;
    OpenIDIssueURL?: string | undefined;
    OpenIDProviderName?: string | undefined;
}
export interface BackendAPIAuthType {
    Mode?: Mode | undefined;
    Settings?: BackendAPIAppSyncAuthSettings | undefined;
}
export type ListOfBackendAPIAuthType = BackendAPIAuthType[];
export type ResolutionStrategy = "OPTIMISTIC_CONCURRENCY" | "LAMBDA" | "AUTOMERGE" | "NONE" | (string & {});
export interface BackendAPIConflictResolution {
    ResolutionStrategy?: ResolutionStrategy | undefined;
}
export interface BackendAPIResourceConfig {
    AdditionalAuthTypes?: BackendAPIAuthType[] | undefined;
    ApiName?: string | undefined;
    ConflictResolution?: BackendAPIConflictResolution | undefined;
    DefaultAuthType?: BackendAPIAuthType | undefined;
    Service?: string | undefined;
    TransformSchema?: string | undefined;
}
export interface CreateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName?: string | undefined;
    ResourceConfig?: BackendAPIResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface CreateBackendAPIResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export type AuthResources = "USER_POOL_ONLY" | "IDENTITY_POOL_AND_USER_POOL" | (string & {});
export interface CreateBackendAuthIdentityPoolConfig {
    IdentityPoolName?: string | undefined;
    UnauthenticatedLogin?: boolean | undefined;
}
export type Service = "COGNITO" | (string & {});
export type DeliveryMethod = "EMAIL" | "SMS" | (string & {});
export interface EmailSettings {
    EmailMessage?: string | undefined;
    EmailSubject?: string | undefined;
}
export interface SmsSettings {
    SmsMessage?: string | undefined;
}
export interface CreateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod | undefined;
    EmailSettings?: EmailSettings | undefined;
    SmsSettings?: SmsSettings | undefined;
}
export type MFAMode = "ON" | "OFF" | "OPTIONAL" | (string & {});
export type MfaTypesElement = "SMS" | "TOTP" | (string & {});
export type ListOfMfaTypesElement = MfaTypesElement[];
export interface Settings {
    MfaTypes?: MfaTypesElement[] | undefined;
    SmsMessage?: string | undefined;
}
export interface CreateBackendAuthMFAConfig {
    MFAMode?: MFAMode | undefined;
    Settings?: Settings | undefined;
}
export type OAuthGrantType = "CODE" | "IMPLICIT" | (string & {});
export type OAuthScopesElement = "PHONE" | "EMAIL" | "OPENID" | "PROFILE" | "AWS_COGNITO_SIGNIN_USER_ADMIN" | (string & {});
export type ListOfOAuthScopesElement = OAuthScopesElement[];
export type ListOf__string = string[];
export interface BackendAuthSocialProviderConfig {
    ClientId?: string | undefined;
    ClientSecret?: string | undefined;
}
export interface BackendAuthAppleProviderConfig {
    ClientId?: string | undefined;
    KeyId?: string | undefined;
    PrivateKey?: string | undefined;
    TeamId?: string | undefined;
}
export interface SocialProviderSettings {
    Facebook?: BackendAuthSocialProviderConfig | undefined;
    Google?: BackendAuthSocialProviderConfig | undefined;
    LoginWithAmazon?: BackendAuthSocialProviderConfig | undefined;
    SignInWithApple?: BackendAuthAppleProviderConfig | undefined;
}
export interface CreateBackendAuthOAuthConfig {
    DomainPrefix?: string | undefined;
    OAuthGrantType?: OAuthGrantType | undefined;
    OAuthScopes?: OAuthScopesElement[] | undefined;
    RedirectSignInURIs?: string[] | undefined;
    RedirectSignOutURIs?: string[] | undefined;
    SocialProviderSettings?: SocialProviderSettings | undefined;
}
export type AdditionalConstraintsElement = "REQUIRE_DIGIT" | "REQUIRE_LOWERCASE" | "REQUIRE_SYMBOL" | "REQUIRE_UPPERCASE" | (string & {});
export type ListOfAdditionalConstraintsElement = AdditionalConstraintsElement[];
export interface CreateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[] | undefined;
    MinimumLength?: number | undefined;
}
export type RequiredSignUpAttributesElement = "ADDRESS" | "BIRTHDATE" | "EMAIL" | "FAMILY_NAME" | "GENDER" | "GIVEN_NAME" | "LOCALE" | "MIDDLE_NAME" | "NAME" | "NICKNAME" | "PHONE_NUMBER" | "PICTURE" | "PREFERRED_USERNAME" | "PROFILE" | "UPDATED_AT" | "WEBSITE" | "ZONE_INFO" | (string & {});
export type ListOfRequiredSignUpAttributesElement = RequiredSignUpAttributesElement[];
export type SignInMethod = "EMAIL" | "EMAIL_AND_PHONE_NUMBER" | "PHONE_NUMBER" | "USERNAME" | (string & {});
export interface CreateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod | undefined;
    EmailSettings?: EmailSettings | undefined;
    SmsSettings?: SmsSettings | undefined;
}
export interface CreateBackendAuthUserPoolConfig {
    ForgotPassword?: CreateBackendAuthForgotPasswordConfig | undefined;
    Mfa?: CreateBackendAuthMFAConfig | undefined;
    OAuth?: CreateBackendAuthOAuthConfig | undefined;
    PasswordPolicy?: CreateBackendAuthPasswordPolicyConfig | undefined;
    RequiredSignUpAttributes?: RequiredSignUpAttributesElement[] | undefined;
    SignInMethod?: SignInMethod | undefined;
    UserPoolName?: string | undefined;
    VerificationMessage?: CreateBackendAuthVerificationMessageConfig | undefined;
}
export interface CreateBackendAuthResourceConfig {
    AuthResources?: AuthResources | undefined;
    IdentityPoolConfigs?: CreateBackendAuthIdentityPoolConfig | undefined;
    Service?: Service | undefined;
    UserPoolConfigs?: CreateBackendAuthUserPoolConfig | undefined;
}
export interface CreateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName?: string | undefined;
    ResourceConfig?: CreateBackendAuthResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface CreateBackendAuthResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface CreateBackendConfigRequest {
    AppId: string;
    BackendManagerAppId?: string | undefined;
}
export interface CreateBackendConfigResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    JobId?: string | undefined;
    Status?: string | undefined;
}
export type AuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export type ListOfAuthenticatedElement = AuthenticatedElement[];
export type UnAuthenticatedElement = "READ" | "CREATE_AND_UPDATE" | "DELETE" | (string & {});
export type ListOfUnAuthenticatedElement = UnAuthenticatedElement[];
export interface BackendStoragePermissions {
    Authenticated?: AuthenticatedElement[] | undefined;
    UnAuthenticated?: UnAuthenticatedElement[] | undefined;
}
export type ServiceName = "S3" | (string & {});
export interface CreateBackendStorageResourceConfig {
    BucketName?: string | undefined;
    Permissions?: BackendStoragePermissions | undefined;
    ServiceName?: ServiceName | undefined;
}
export interface CreateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName?: string | undefined;
    ResourceConfig?: CreateBackendStorageResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface CreateBackendStorageResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    JobId?: string | undefined;
    Status?: string | undefined;
}
export interface CreateTokenRequest {
    AppId: string;
}
export interface CreateTokenResponse {
    AppId?: string | undefined;
    ChallengeCode?: string | undefined;
    SessionId?: string | undefined;
    Ttl?: string | undefined;
}
export interface DeleteBackendRequest {
    AppId: string;
    BackendEnvironmentName: string;
}
export interface DeleteBackendResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface DeleteBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface DeleteBackendAPIResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface DeleteBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
}
export interface DeleteBackendAuthResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface DeleteBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
    ServiceName?: ServiceName | undefined;
}
export interface DeleteBackendStorageResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    JobId?: string | undefined;
    Status?: string | undefined;
}
export interface DeleteTokenRequest {
    AppId: string;
    SessionId: string;
}
export interface DeleteTokenResponse {
    IsSuccess?: boolean | undefined;
}
export interface GenerateBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
}
export interface GenerateBackendAPIModelsResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface GetBackendRequest {
    AppId: string;
    BackendEnvironmentName?: string | undefined;
}
export interface GetBackendResponse {
    AmplifyFeatureFlags?: string | undefined;
    AmplifyMetaConfig?: string | undefined;
    AppId?: string | undefined;
    AppName?: string | undefined;
    BackendEnvironmentList?: string[] | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
}
export interface GetBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface GetBackendAPIResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    ResourceConfig?: BackendAPIResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface GetBackendAPIModelsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
}
export type Status = "LATEST" | "STALE" | (string & {});
export interface GetBackendAPIModelsResponse {
    Models?: string | undefined;
    Status?: Status | undefined;
    ModelIntrospectionSchema?: string | undefined;
}
export interface GetBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
}
export interface GetBackendAuthResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    ResourceConfig?: (CreateBackendAuthResourceConfig & {
        AuthResources: AuthResources;
        Service: Service;
        UserPoolConfigs: CreateBackendAuthUserPoolConfig & {
            RequiredSignUpAttributes: ListOfRequiredSignUpAttributesElement;
            SignInMethod: SignInMethod;
            UserPoolName: string;
            ForgotPassword: CreateBackendAuthForgotPasswordConfig & {
                DeliveryMethod: DeliveryMethod;
            };
            Mfa: CreateBackendAuthMFAConfig & {
                MFAMode: MFAMode;
            };
            OAuth: CreateBackendAuthOAuthConfig & {
                OAuthGrantType: OAuthGrantType;
                OAuthScopes: ListOfOAuthScopesElement;
                RedirectSignInURIs: ListOf__string;
                RedirectSignOutURIs: ListOf__string;
            };
            PasswordPolicy: CreateBackendAuthPasswordPolicyConfig & {
                MinimumLength: number;
            };
            VerificationMessage: CreateBackendAuthVerificationMessageConfig & {
                DeliveryMethod: DeliveryMethod;
            };
        };
        IdentityPoolConfigs: CreateBackendAuthIdentityPoolConfig & {
            IdentityPoolName: string;
            UnauthenticatedLogin: boolean;
        };
    }) | undefined;
    ResourceName?: string | undefined;
}
export interface GetBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
}
export interface GetBackendJobResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    CreateTime?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
    UpdateTime?: string | undefined;
}
export interface GetBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceName?: string | undefined;
}
export interface GetBackendStorageResourceConfig {
    BucketName?: string | undefined;
    Imported?: boolean | undefined;
    Permissions?: BackendStoragePermissions | undefined;
    ServiceName?: ServiceName | undefined;
}
export interface GetBackendStorageResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    ResourceConfig?: (GetBackendStorageResourceConfig & {
        Imported: boolean;
        ServiceName: ServiceName;
        Permissions: BackendStoragePermissions & {
            Authenticated: ListOfAuthenticatedElement;
        };
    }) | undefined;
    ResourceName?: string | undefined;
}
export interface GetTokenRequest {
    AppId: string;
    SessionId: string;
}
export interface GetTokenResponse {
    AppId?: string | undefined;
    ChallengeCode?: string | undefined;
    SessionId?: string | undefined;
    Ttl?: string | undefined;
}
export interface ImportBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    IdentityPoolId?: string | undefined;
    NativeClientId?: string | undefined;
    UserPoolId?: string | undefined;
    WebClientId?: string | undefined;
}
export interface ImportBackendAuthResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface ImportBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    BucketName?: string | undefined;
    ServiceName?: ServiceName | undefined;
}
export interface ImportBackendStorageResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    JobId?: string | undefined;
    Status?: string | undefined;
}
export type __integerMin1Max25 = number;
export interface ListBackendJobsRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface BackendJobRespObj {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    CreateTime?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
    UpdateTime?: string | undefined;
}
export type ListOfBackendJobRespObj = BackendJobRespObj[];
export interface ListBackendJobsResponse {
    Jobs?: (BackendJobRespObj & {
        AppId: string;
        BackendEnvironmentName: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListS3BucketsRequest {
    NextToken?: string | undefined;
}
export interface S3BucketInfo {
    CreationDate?: string | undefined;
    Name?: string | undefined;
}
export type ListOfS3BucketInfo = S3BucketInfo[];
export interface ListS3BucketsResponse {
    Buckets?: S3BucketInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface RemoveAllBackendsRequest {
    AppId: string;
    CleanAmplifyApp?: boolean | undefined;
}
export interface RemoveAllBackendsResponse {
    AppId?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface RemoveBackendConfigRequest {
    AppId: string;
}
export interface RemoveBackendConfigResponse {
    Error?: string | undefined;
}
export interface UpdateBackendAPIRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: BackendAPIResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface UpdateBackendAPIResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface UpdateBackendAuthIdentityPoolConfig {
    UnauthenticatedLogin?: boolean | undefined;
}
export interface UpdateBackendAuthForgotPasswordConfig {
    DeliveryMethod?: DeliveryMethod | undefined;
    EmailSettings?: EmailSettings | undefined;
    SmsSettings?: SmsSettings | undefined;
}
export interface UpdateBackendAuthMFAConfig {
    MFAMode?: MFAMode | undefined;
    Settings?: Settings | undefined;
}
export interface UpdateBackendAuthOAuthConfig {
    DomainPrefix?: string | undefined;
    OAuthGrantType?: OAuthGrantType | undefined;
    OAuthScopes?: OAuthScopesElement[] | undefined;
    RedirectSignInURIs?: string[] | undefined;
    RedirectSignOutURIs?: string[] | undefined;
    SocialProviderSettings?: SocialProviderSettings | undefined;
}
export interface UpdateBackendAuthPasswordPolicyConfig {
    AdditionalConstraints?: AdditionalConstraintsElement[] | undefined;
    MinimumLength?: number | undefined;
}
export interface UpdateBackendAuthVerificationMessageConfig {
    DeliveryMethod?: DeliveryMethod | undefined;
    EmailSettings?: EmailSettings | undefined;
    SmsSettings?: SmsSettings | undefined;
}
export interface UpdateBackendAuthUserPoolConfig {
    ForgotPassword?: UpdateBackendAuthForgotPasswordConfig | undefined;
    Mfa?: UpdateBackendAuthMFAConfig | undefined;
    OAuth?: UpdateBackendAuthOAuthConfig | undefined;
    PasswordPolicy?: UpdateBackendAuthPasswordPolicyConfig | undefined;
    VerificationMessage?: UpdateBackendAuthVerificationMessageConfig | undefined;
}
export interface UpdateBackendAuthResourceConfig {
    AuthResources?: AuthResources | undefined;
    IdentityPoolConfigs?: UpdateBackendAuthIdentityPoolConfig | undefined;
    Service?: Service | undefined;
    UserPoolConfigs?: UpdateBackendAuthUserPoolConfig | undefined;
}
export interface UpdateBackendAuthRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendAuthResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface UpdateBackendAuthResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface LoginAuthConfigReqObj {
    AwsCognitoIdentityPoolId?: string | undefined;
    AwsCognitoRegion?: string | undefined;
    AwsUserPoolsId?: string | undefined;
    AwsUserPoolsWebClientId?: string | undefined;
}
export interface UpdateBackendConfigRequest {
    AppId: string;
    LoginAuthConfig?: LoginAuthConfigReqObj | undefined;
}
export interface UpdateBackendConfigResponse {
    AppId?: string | undefined;
    BackendManagerAppId?: string | undefined;
    Error?: string | undefined;
    LoginAuthConfig?: LoginAuthConfigReqObj | undefined;
}
export interface UpdateBackendJobRequest {
    AppId: string;
    BackendEnvironmentName: string;
    JobId: string;
    Operation?: string | undefined;
    Status?: string | undefined;
}
export interface UpdateBackendJobResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    CreateTime?: string | undefined;
    Error?: string | undefined;
    JobId?: string | undefined;
    Operation?: string | undefined;
    Status?: string | undefined;
    UpdateTime?: string | undefined;
}
export interface UpdateBackendStorageResourceConfig {
    Permissions?: BackendStoragePermissions | undefined;
    ServiceName?: ServiceName | undefined;
}
export interface UpdateBackendStorageRequest {
    AppId: string;
    BackendEnvironmentName: string;
    ResourceConfig?: UpdateBackendStorageResourceConfig | undefined;
    ResourceName?: string | undefined;
}
export interface UpdateBackendStorageResponse {
    AppId?: string | undefined;
    BackendEnvironmentName?: string | undefined;
    JobId?: string | undefined;
    Status?: string | undefined;
}
export type CloneBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation clones an existing backend.
 */
export declare const cloneBackend: API.OperationMethod<CloneBackendRequest & RegionInput, CloneBackendResponse, CloneBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * This operation creates a backend for an Amplify app. Backends are automatically created at the time of app creation.
 */
export declare const createBackend: API.OperationMethod<CreateBackendRequest & RegionInput, CreateBackendResponse, CreateBackendError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend API resource.
 */
export declare const createBackendAPI: API.OperationMethod<CreateBackendAPIRequest & RegionInput, CreateBackendAPIResponse, CreateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type CreateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new backend authentication resource.
 */
export declare const createBackendAuth: API.OperationMethod<CreateBackendAuthRequest & RegionInput, CreateBackendAuthResponse, CreateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type CreateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a config object for a backend.
 */
export declare const createBackendConfig: API.OperationMethod<CreateBackendConfigRequest & RegionInput, CreateBackendConfigResponse, CreateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type CreateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a backend storage resource.
 */
export declare const createBackendStorage: API.OperationMethod<CreateBackendStorageRequest & RegionInput, CreateBackendStorageResponse, CreateBackendStorageError, Credentials | HttpClient.HttpClient>;
export type CreateTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a one-time challenge code to authenticate a user into your Amplify Admin UI.
 */
export declare const createToken: API.OperationMethod<CreateTokenRequest & RegionInput, CreateTokenResponse, CreateTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes an existing environment from your Amplify project.
 */
export declare const deleteBackend: API.OperationMethod<DeleteBackendRequest & RegionInput, DeleteBackendResponse, DeleteBackendError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend API resource.
 */
export declare const deleteBackendAPI: API.OperationMethod<DeleteBackendAPIRequest & RegionInput, DeleteBackendAPIResponse, DeleteBackendAPIError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing backend authentication resource.
 */
export declare const deleteBackendAuth: API.OperationMethod<DeleteBackendAuthRequest & RegionInput, DeleteBackendAuthResponse, DeleteBackendAuthError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified backend storage resource.
 */
export declare const deleteBackendStorage: API.OperationMethod<DeleteBackendStorageRequest & RegionInput, DeleteBackendStorageResponse, DeleteBackendStorageError, Credentials | HttpClient.HttpClient>;
export type DeleteTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the challenge token based on the given appId and sessionId.
 */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest & RegionInput, DeleteTokenResponse, DeleteTokenError, Credentials | HttpClient.HttpClient>;
export type GenerateBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Generates a model schema for an existing backend API resource.
 */
export declare const generateBackendAPIModels: API.OperationMethod<GenerateBackendAPIModelsRequest & RegionInput, GenerateBackendAPIModelsResponse, GenerateBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides project-level details for your Amplify UI project.
 */
export declare const getBackend: API.OperationMethod<GetBackendRequest & RegionInput, GetBackendResponse, GetBackendError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the details for a backend API.
 */
export declare const getBackendAPI: API.OperationMethod<GetBackendAPIRequest & RegionInput, GetBackendAPIResponse, GetBackendAPIError, Credentials | HttpClient.HttpClient>;
export type GetBackendAPIModelsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a model introspection schema for an existing backend API resource.
 */
export declare const getBackendAPIModels: API.OperationMethod<GetBackendAPIModelsRequest & RegionInput, GetBackendAPIModelsResponse, GetBackendAPIModelsError, Credentials | HttpClient.HttpClient>;
export type GetBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets a backend auth details.
 */
export declare const getBackendAuth: API.OperationMethod<GetBackendAuthRequest & RegionInput, GetBackendAuthResponse, GetBackendAuthError, Credentials | HttpClient.HttpClient>;
export type GetBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a specific job.
 */
export declare const getBackendJob: API.OperationMethod<GetBackendJobRequest & RegionInput, GetBackendJobResponse, GetBackendJobError, Credentials | HttpClient.HttpClient>;
export type GetBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets details for a backend storage resource.
 */
export declare const getBackendStorage: API.OperationMethod<GetBackendStorageRequest & RegionInput, GetBackendStorageResponse, GetBackendStorageError, Credentials | HttpClient.HttpClient>;
export type GetTokenError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the challenge token based on the given appId and sessionId.
 */
export declare const getToken: API.OperationMethod<GetTokenRequest & RegionInput, GetTokenResponse, GetTokenError, Credentials | HttpClient.HttpClient>;
export type ImportBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend authentication resource.
 */
export declare const importBackendAuth: API.OperationMethod<ImportBackendAuthRequest & RegionInput, ImportBackendAuthResponse, ImportBackendAuthError, Credentials | HttpClient.HttpClient>;
export type ImportBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Imports an existing backend storage resource.
 */
export declare const importBackendStorage: API.OperationMethod<ImportBackendStorageRequest & RegionInput, ImportBackendStorageResponse, ImportBackendStorageError, Credentials | HttpClient.HttpClient>;
export type ListBackendJobsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the jobs for the backend of an Amplify app.
 */
export declare const listBackendJobs: API.OperationMethod<ListBackendJobsRequest & RegionInput, ListBackendJobsResponse, ListBackendJobsError, Credentials | HttpClient.HttpClient>;
export type ListS3BucketsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * The list of S3 buckets in your account.
 */
export declare const listS3Buckets: API.OperationMethod<ListS3BucketsRequest & RegionInput, ListS3BucketsResponse, ListS3BucketsError, Credentials | HttpClient.HttpClient>;
export type RemoveAllBackendsError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes all backend environments from your Amplify project.
 */
export declare const removeAllBackends: API.OperationMethod<RemoveAllBackendsRequest & RegionInput, RemoveAllBackendsResponse, RemoveAllBackendsError, Credentials | HttpClient.HttpClient>;
export type RemoveBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes the AWS resources required to access the Amplify Admin UI.
 */
export declare const removeBackendConfig: API.OperationMethod<RemoveBackendConfigRequest & RegionInput, RemoveBackendConfigResponse, RemoveBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAPIError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend API resource.
 */
export declare const updateBackendAPI: API.OperationMethod<UpdateBackendAPIRequest & RegionInput, UpdateBackendAPIResponse, UpdateBackendAPIError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendAuthError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend authentication resource.
 */
export declare const updateBackendAuth: API.OperationMethod<UpdateBackendAuthRequest & RegionInput, UpdateBackendAuthResponse, UpdateBackendAuthError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendConfigError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the AWS resources required to access the Amplify Admin UI.
 */
export declare const updateBackendConfig: API.OperationMethod<UpdateBackendConfigRequest & RegionInput, UpdateBackendConfigResponse, UpdateBackendConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendJobError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates a specific job.
 */
export declare const updateBackendJob: API.OperationMethod<UpdateBackendJobRequest & RegionInput, UpdateBackendJobResponse, UpdateBackendJobError, Credentials | HttpClient.HttpClient>;
export type UpdateBackendStorageError = BadRequestException | GatewayTimeoutException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing backend storage resource.
 */
export declare const updateBackendStorage: API.OperationMethod<UpdateBackendStorageRequest & RegionInput, UpdateBackendStorageResponse, UpdateBackendStorageError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplifybackend.d.ts.map