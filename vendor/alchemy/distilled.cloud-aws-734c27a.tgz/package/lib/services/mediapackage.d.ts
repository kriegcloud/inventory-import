import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface EgressAccessLogs {
    LogGroupName?: string | undefined;
}
export interface IngressAccessLogs {
    LogGroupName?: string | undefined;
}
export interface ConfigureLogsRequest {
    EgressAccessLogs?: EgressAccessLogs | undefined;
    Id: string;
    IngressAccessLogs?: IngressAccessLogs | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface IngestEndpoint {
    Id?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Url?: string | undefined;
    Username?: string | redacted.Redacted<string> | undefined;
}
export type __listOfIngestEndpoint = IngestEndpoint[];
export interface HlsIngest {
    IngestEndpoints?: IngestEndpoint[] | undefined;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface ConfigureLogsResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateChannelRequest {
    Description?: string | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateChannelResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface S3Destination {
    BucketName?: string | undefined;
    ManifestKey?: string | undefined;
    RoleArn?: string | undefined;
}
export interface CreateHarvestJobRequest {
    EndTime?: string | undefined;
    Id?: string | undefined;
    OriginEndpointId?: string | undefined;
    S3Destination?: S3Destination | undefined;
    StartTime?: string | undefined;
}
export type Status = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface CreateHarvestJobResponse {
    Arn?: string | undefined;
    ChannelId?: string | undefined;
    CreatedAt?: string | undefined;
    EndTime?: string | undefined;
    Id?: string | undefined;
    OriginEndpointId?: string | undefined;
    S3Destination?: (S3Destination & {
        BucketName: string;
        ManifestKey: string;
        RoleArn: string;
    }) | undefined;
    StartTime?: string | undefined;
    Status?: Status | undefined;
}
export interface Authorization {
    CdnIdentifierSecret?: string | undefined;
    SecretsRoleArn?: string | undefined;
}
export type CmafEncryptionMethod = "SAMPLE_AES" | "AES_CTR" | (string & {});
export type PresetSpeke20Audio = "PRESET-AUDIO-1" | "PRESET-AUDIO-2" | "PRESET-AUDIO-3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET-VIDEO-1" | "PRESET-VIDEO-2" | "PRESET-VIDEO-3" | "PRESET-VIDEO-4" | "PRESET-VIDEO-5" | "PRESET-VIDEO-6" | "PRESET-VIDEO-7" | "PRESET-VIDEO-8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    PresetSpeke20Audio?: PresetSpeke20Audio | undefined;
    PresetSpeke20Video?: PresetSpeke20Video | undefined;
}
export type __listOf__string = string[];
export interface SpekeKeyProvider {
    CertificateArn?: string | undefined;
    EncryptionContractConfiguration?: EncryptionContractConfiguration | undefined;
    ResourceId?: string | undefined;
    RoleArn?: string | undefined;
    SystemIds?: string[] | undefined;
    Url?: string | undefined;
}
export interface CmafEncryption {
    ConstantInitializationVector?: string | undefined;
    EncryptionMethod?: CmafEncryptionMethod | undefined;
    KeyRotationIntervalSeconds?: number | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type AdMarkers = "NONE" | "SCTE35_ENHANCED" | "PASSTHROUGH" | "DATERANGE" | (string & {});
export type __AdTriggersElement = "SPLICE_INSERT" | "BREAK" | "PROVIDER_ADVERTISEMENT" | "DISTRIBUTOR_ADVERTISEMENT" | "PROVIDER_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_PLACEMENT_OPPORTUNITY" | "PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY" | "DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY" | (string & {});
export type AdTriggers = __AdTriggersElement[];
export type AdsOnDeliveryRestrictions = "NONE" | "RESTRICTED" | "UNRESTRICTED" | "BOTH" | (string & {});
export type PlaylistType = "NONE" | "EVENT" | "VOD" | (string & {});
export interface HlsManifestCreateOrUpdateParameters {
    AdMarkers?: AdMarkers | undefined;
    AdTriggers?: __AdTriggersElement[] | undefined;
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions | undefined;
    Id?: string | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    ManifestName?: string | undefined;
    PlaylistType?: PlaylistType | undefined;
    PlaylistWindowSeconds?: number | undefined;
    ProgramDateTimeIntervalSeconds?: number | undefined;
}
export type __listOfHlsManifestCreateOrUpdateParameters = HlsManifestCreateOrUpdateParameters[];
export type StreamOrder = "ORIGINAL" | "VIDEO_BITRATE_ASCENDING" | "VIDEO_BITRATE_DESCENDING" | (string & {});
export interface StreamSelection {
    MaxVideoBitsPerSecond?: number | undefined;
    MinVideoBitsPerSecond?: number | undefined;
    StreamOrder?: StreamOrder | undefined;
}
export interface CmafPackageCreateOrUpdateParameters {
    Encryption?: CmafEncryption | undefined;
    HlsManifests?: HlsManifestCreateOrUpdateParameters[] | undefined;
    SegmentDurationSeconds?: number | undefined;
    SegmentPrefix?: string | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export interface DashEncryption {
    KeyRotationIntervalSeconds?: number | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type ManifestLayout = "FULL" | "COMPACT" | "DRM_TOP_LEVEL_COMPACT" | (string & {});
export type __PeriodTriggersElement = "ADS" | (string & {});
export type __listOf__PeriodTriggersElement = __PeriodTriggersElement[];
export type Profile = "NONE" | "HBBTV_1_5" | "HYBRIDCAST" | "DVB_DASH_2014" | (string & {});
export type SegmentTemplateFormat = "NUMBER_WITH_TIMELINE" | "TIME_WITH_TIMELINE" | "NUMBER_WITH_DURATION" | (string & {});
export type UtcTiming = "NONE" | "HTTP-HEAD" | "HTTP-ISO" | "HTTP-XSDATE" | (string & {});
export interface DashPackage {
    AdTriggers?: __AdTriggersElement[] | undefined;
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions | undefined;
    Encryption?: DashEncryption | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    ManifestLayout?: ManifestLayout | undefined;
    ManifestWindowSeconds?: number | undefined;
    MinBufferTimeSeconds?: number | undefined;
    MinUpdatePeriodSeconds?: number | undefined;
    PeriodTriggers?: __PeriodTriggersElement[] | undefined;
    Profile?: Profile | undefined;
    SegmentDurationSeconds?: number | undefined;
    SegmentTemplateFormat?: SegmentTemplateFormat | undefined;
    StreamSelection?: StreamSelection | undefined;
    SuggestedPresentationDelaySeconds?: number | undefined;
    UtcTiming?: UtcTiming | undefined;
    UtcTimingUri?: string | undefined;
}
export type EncryptionMethod = "AES_128" | "SAMPLE_AES" | (string & {});
export interface HlsEncryption {
    ConstantInitializationVector?: string | undefined;
    EncryptionMethod?: EncryptionMethod | undefined;
    KeyRotationIntervalSeconds?: number | undefined;
    RepeatExtXKey?: boolean | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export interface HlsPackage {
    AdMarkers?: AdMarkers | undefined;
    AdTriggers?: __AdTriggersElement[] | undefined;
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions | undefined;
    Encryption?: HlsEncryption | undefined;
    IncludeDvbSubtitles?: boolean | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    PlaylistType?: PlaylistType | undefined;
    PlaylistWindowSeconds?: number | undefined;
    ProgramDateTimeIntervalSeconds?: number | undefined;
    SegmentDurationSeconds?: number | undefined;
    StreamSelection?: StreamSelection | undefined;
    UseAudioRenditionGroup?: boolean | undefined;
}
export interface MssEncryption {
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export interface MssPackage {
    Encryption?: MssEncryption | undefined;
    ManifestWindowSeconds?: number | undefined;
    SegmentDurationSeconds?: number | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export type Origination = "ALLOW" | "DENY" | (string & {});
export interface CreateOriginEndpointRequest {
    Authorization?: Authorization | undefined;
    ChannelId?: string | undefined;
    CmafPackage?: CmafPackageCreateOrUpdateParameters | undefined;
    DashPackage?: DashPackage | undefined;
    Description?: string | undefined;
    HlsPackage?: HlsPackage | undefined;
    Id?: string | undefined;
    ManifestName?: string | undefined;
    MssPackage?: MssPackage | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TimeDelaySeconds?: number | undefined;
    Whitelist?: string[] | undefined;
}
export interface HlsManifest {
    AdMarkers?: AdMarkers | undefined;
    Id?: string | undefined;
    IncludeIframeOnlyStream?: boolean | undefined;
    ManifestName?: string | undefined;
    PlaylistType?: PlaylistType | undefined;
    PlaylistWindowSeconds?: number | undefined;
    ProgramDateTimeIntervalSeconds?: number | undefined;
    Url?: string | undefined;
    AdTriggers?: __AdTriggersElement[] | undefined;
    AdsOnDeliveryRestrictions?: AdsOnDeliveryRestrictions | undefined;
}
export type __listOfHlsManifest = HlsManifest[];
export interface CmafPackage {
    Encryption?: CmafEncryption | undefined;
    HlsManifests?: HlsManifest[] | undefined;
    SegmentDurationSeconds?: number | undefined;
    SegmentPrefix?: string | undefined;
    StreamSelection?: StreamSelection | undefined;
}
export interface CreateOriginEndpointResponse {
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    ChannelId?: string | undefined;
    CmafPackage?: (CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    }) | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: (DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Description?: string | undefined;
    HlsPackage?: (HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Id?: string | undefined;
    ManifestName?: string | undefined;
    MssPackage?: (MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TimeDelaySeconds?: number | undefined;
    Url?: string | undefined;
    Whitelist?: string[] | undefined;
}
export interface DeleteChannelRequest {
    Id: string;
}
export interface DeleteChannelResponse {
}
export interface DeleteOriginEndpointRequest {
    Id: string;
}
export interface DeleteOriginEndpointResponse {
}
export interface DescribeChannelRequest {
    Id: string;
}
export interface DescribeChannelResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeHarvestJobRequest {
    Id: string;
}
export interface DescribeHarvestJobResponse {
    Arn?: string | undefined;
    ChannelId?: string | undefined;
    CreatedAt?: string | undefined;
    EndTime?: string | undefined;
    Id?: string | undefined;
    OriginEndpointId?: string | undefined;
    S3Destination?: (S3Destination & {
        BucketName: string;
        ManifestKey: string;
        RoleArn: string;
    }) | undefined;
    StartTime?: string | undefined;
    Status?: Status | undefined;
}
export interface DescribeOriginEndpointRequest {
    Id: string;
}
export interface DescribeOriginEndpointResponse {
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    ChannelId?: string | undefined;
    CmafPackage?: (CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    }) | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: (DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Description?: string | undefined;
    HlsPackage?: (HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Id?: string | undefined;
    ManifestName?: string | undefined;
    MssPackage?: (MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TimeDelaySeconds?: number | undefined;
    Url?: string | undefined;
    Whitelist?: string[] | undefined;
}
export type MaxResults = number;
export interface ListChannelsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Channel {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfChannel = Channel[];
export interface ListChannelsResponse {
    Channels?: Channel[] | undefined;
    NextToken?: string | undefined;
}
export interface ListHarvestJobsRequest {
    IncludeChannelId?: string | undefined;
    IncludeStatus?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface HarvestJob {
    Arn?: string | undefined;
    ChannelId?: string | undefined;
    CreatedAt?: string | undefined;
    EndTime?: string | undefined;
    Id?: string | undefined;
    OriginEndpointId?: string | undefined;
    S3Destination?: S3Destination | undefined;
    StartTime?: string | undefined;
    Status?: Status | undefined;
}
export type __listOfHarvestJob = HarvestJob[];
export interface ListHarvestJobsResponse {
    HarvestJobs?: (HarvestJob & {
        S3Destination: S3Destination & {
            BucketName: string;
            ManifestKey: string;
            RoleArn: string;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOriginEndpointsRequest {
    ChannelId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface OriginEndpoint {
    Arn?: string | undefined;
    Authorization?: Authorization | undefined;
    ChannelId?: string | undefined;
    CmafPackage?: CmafPackage | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: DashPackage | undefined;
    Description?: string | undefined;
    HlsPackage?: HlsPackage | undefined;
    Id?: string | undefined;
    ManifestName?: string | undefined;
    MssPackage?: MssPackage | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TimeDelaySeconds?: number | undefined;
    Url?: string | undefined;
    Whitelist?: string[] | undefined;
}
export type __listOfOriginEndpoint = OriginEndpoint[];
export interface ListOriginEndpointsResponse {
    NextToken?: string | undefined;
    OriginEndpoints?: (OriginEndpoint & {
        Authorization: Authorization & {
            CdnIdentifierSecret: string;
            SecretsRoleArn: string;
        };
        CmafPackage: CmafPackage & {
            Encryption: CmafEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
            HlsManifests: (HlsManifest & {
                Id: string;
            })[];
        };
        DashPackage: DashPackage & {
            Encryption: DashEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        HlsPackage: HlsPackage & {
            Encryption: HlsEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
        MssPackage: MssPackage & {
            Encryption: MssEncryption & {
                SpekeKeyProvider: SpekeKeyProvider & {
                    ResourceId: string;
                    RoleArn: string;
                    SystemIds: __listOf__string;
                    Url: string;
                    EncryptionContractConfiguration: EncryptionContractConfiguration & {
                        PresetSpeke20Audio: PresetSpeke20Audio;
                        PresetSpeke20Video: PresetSpeke20Video;
                    };
                };
            };
        };
    })[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RotateChannelCredentialsRequest {
    Id: string;
}
export interface RotateChannelCredentialsResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RotateIngestEndpointCredentialsRequest {
    Id: string;
    IngestEndpointId: string;
}
export interface RotateIngestEndpointCredentialsResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateChannelRequest {
    Description?: string | undefined;
    Id: string;
}
export interface UpdateChannelResponse {
    Arn?: string | undefined;
    CreatedAt?: string | undefined;
    Description?: string | undefined;
    EgressAccessLogs?: EgressAccessLogs | undefined;
    HlsIngest?: HlsIngest | undefined;
    Id?: string | undefined;
    IngressAccessLogs?: IngressAccessLogs | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateOriginEndpointRequest {
    Authorization?: Authorization | undefined;
    CmafPackage?: CmafPackageCreateOrUpdateParameters | undefined;
    DashPackage?: DashPackage | undefined;
    Description?: string | undefined;
    HlsPackage?: HlsPackage | undefined;
    Id: string;
    ManifestName?: string | undefined;
    MssPackage?: MssPackage | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    TimeDelaySeconds?: number | undefined;
    Whitelist?: string[] | undefined;
}
export interface UpdateOriginEndpointResponse {
    Arn?: string | undefined;
    Authorization?: (Authorization & {
        CdnIdentifierSecret: string;
        SecretsRoleArn: string;
    }) | undefined;
    ChannelId?: string | undefined;
    CmafPackage?: (CmafPackage & {
        Encryption: CmafEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
        HlsManifests: (HlsManifest & {
            Id: string;
        })[];
    }) | undefined;
    CreatedAt?: string | undefined;
    DashPackage?: (DashPackage & {
        Encryption: DashEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Description?: string | undefined;
    HlsPackage?: (HlsPackage & {
        Encryption: HlsEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Id?: string | undefined;
    ManifestName?: string | undefined;
    MssPackage?: (MssPackage & {
        Encryption: MssEncryption & {
            SpekeKeyProvider: SpekeKeyProvider & {
                ResourceId: string;
                RoleArn: string;
                SystemIds: __listOf__string;
                Url: string;
                EncryptionContractConfiguration: EncryptionContractConfiguration & {
                    PresetSpeke20Audio: PresetSpeke20Audio;
                    PresetSpeke20Video: PresetSpeke20Video;
                };
            };
        };
    }) | undefined;
    Origination?: Origination | undefined;
    StartoverWindowSeconds?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TimeDelaySeconds?: number | undefined;
    Url?: string | undefined;
    Whitelist?: string[] | undefined;
}
export type ConfigureLogsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the Channel's properities to configure log subscription
 */
export declare const configureLogs: API.OperationMethod<ConfigureLogsRequest & RegionInput, ConfigureLogsResponse, ConfigureLogsError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new Channel.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateHarvestJobError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new HarvestJob record.
 */
export declare const createHarvestJob: API.OperationMethod<CreateHarvestJobRequest & RegionInput, CreateHarvestJobResponse, CreateHarvestJobError, Credentials | HttpClient.HttpClient>;
export type CreateOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Creates a new OriginEndpoint record.
 */
export declare const createOriginEndpoint: API.OperationMethod<CreateOriginEndpointRequest & RegionInput, CreateOriginEndpointResponse, CreateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing Channel.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Deletes an existing OriginEndpoint.
 */
export declare const deleteOriginEndpoint: API.OperationMethod<DeleteOriginEndpointRequest & RegionInput, DeleteOriginEndpointResponse, DeleteOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about a Channel.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest & RegionInput, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeHarvestJobError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about an existing HarvestJob.
 */
export declare const describeHarvestJob: API.OperationMethod<DescribeHarvestJobRequest & RegionInput, DescribeHarvestJobResponse, DescribeHarvestJobError, Credentials | HttpClient.HttpClient>;
export type DescribeOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Gets details about an existing OriginEndpoint.
 */
export declare const describeOriginEndpoint: API.OperationMethod<DescribeOriginEndpointRequest & RegionInput, DescribeOriginEndpointResponse, DescribeOriginEndpointError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of Channels.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, Channel>;
export type ListHarvestJobsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of HarvestJob records.
 */
export declare const listHarvestJobs: API.PaginatedOperationMethod<ListHarvestJobsRequest & RegionInput, ListHarvestJobsResponse, ListHarvestJobsError, Credentials | HttpClient.HttpClient, HarvestJob>;
export type ListOriginEndpointsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Returns a collection of OriginEndpoint records.
 */
export declare const listOriginEndpoints: API.PaginatedOperationMethod<ListOriginEndpointsRequest & RegionInput, ListOriginEndpointsResponse, ListOriginEndpointsError, Credentials | HttpClient.HttpClient, OriginEndpoint>;
export type ListTagsForResourceError = CommonErrors;
/**
 *
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RotateChannelCredentialsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Changes the Channel's first IngestEndpoint's username and password. WARNING - This API is deprecated. Please use RotateIngestEndpointCredentials instead
 */
export declare const rotateChannelCredentials: API.OperationMethod<RotateChannelCredentialsRequest & RegionInput, RotateChannelCredentialsResponse, RotateChannelCredentialsError, Credentials | HttpClient.HttpClient>;
export type RotateIngestEndpointCredentialsError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Rotate the IngestEndpoint's username and password, as specified by the IngestEndpoint's id.
 */
export declare const rotateIngestEndpointCredentials: API.OperationMethod<RotateIngestEndpointCredentialsRequest & RegionInput, RotateIngestEndpointCredentialsResponse, RotateIngestEndpointCredentialsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 *
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 *
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates an existing Channel.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginEndpointError = ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Updates an existing OriginEndpoint.
 */
export declare const updateOriginEndpoint: API.OperationMethod<UpdateOriginEndpointRequest & RegionInput, UpdateOriginEndpointResponse, UpdateOriginEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediapackage.d.ts.map