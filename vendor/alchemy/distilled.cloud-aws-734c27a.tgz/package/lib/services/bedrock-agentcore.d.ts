import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DuplicateIdException_base: S.TaggedErrorClass<"DuplicateIdException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateIdException extends /*@__PURE__*/ DuplicateIdException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.TaggedErrorClass<"RetryableConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
declare const RuntimeClientError_base: S.TaggedErrorClass<"RuntimeClientError", {
    readonly message: any;
}>;
export declare class RuntimeClientError extends /*@__PURE__*/ RuntimeClientError_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const SubscriptionRequiredException_base: S.TaggedErrorClass<"SubscriptionRequiredException", {
    readonly message: any;
    readonly subscriptionUrl: any;
    readonly productName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class SubscriptionRequiredException extends /*@__PURE__*/ SubscriptionRequiredException_base {
}
declare const ThrottledException_base: S.TaggedErrorClass<"ThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottledException extends /*@__PURE__*/ ThrottledException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MemoryId = string;
export type RequestIdentifier = string;
export type Namespace = string;
export type NamespacesList = string[];
export type SensitiveString = string | redacted.Redacted<string>;
export type MemoryContent = {
    text: string | redacted.Redacted<string>;
};
export type MemoryStrategyId = string;
export type MetadataKey = string;
export type StringValue = string;
export type StringListMemberValue = string;
export type StringValueList = string[];
export type MemoryRecordMetadataValue = {
    stringValue: string;
    stringListValue?: undefined;
    numberValue?: undefined;
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue: string[];
    numberValue?: undefined;
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue?: undefined;
    numberValue: number;
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue?: undefined;
    numberValue?: undefined;
    dateTimeValue: Date;
};
export type MemoryRecordMetadataMap = {
    [key: string]: MemoryRecordMetadataValue | undefined;
};
export interface MemoryRecordCreateInput {
    requestIdentifier: string;
    namespaces: string[];
    content: MemoryContent;
    timestamp: Date;
    memoryStrategyId?: string | undefined;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    } | undefined;
}
export type MemoryRecordsCreateInputList = MemoryRecordCreateInput[];
export type RecordExpiryDurationDays = number;
export type RecordExpiryAction = "REMOVE" | (string & {});
export type RecordExpirySpecification = {
    recordExpiryDurationDays: number;
    action?: undefined;
} | {
    recordExpiryDurationDays?: undefined;
    action: RecordExpiryAction;
};
export interface BatchCreateMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordCreateInput[];
    clientToken?: string | undefined;
    recordExpirySpecification?: RecordExpirySpecification | undefined;
}
export type MemoryRecordId = string;
export type MemoryRecordStatus = "SUCCEEDED" | "FAILED" | (string & {});
export interface MemoryRecordOutput {
    memoryRecordId: string;
    status: MemoryRecordStatus;
    requestIdentifier?: string | undefined;
    errorCode?: number | undefined;
    errorMessage?: string | undefined;
}
export type MemoryRecordsOutputList = MemoryRecordOutput[];
export interface BatchCreateMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export interface MemoryRecordDeleteInput {
    memoryRecordId: string;
    namespace?: string | undefined;
}
export type MemoryRecordsDeleteInputList = MemoryRecordDeleteInput[];
export interface BatchDeleteMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordDeleteInput[];
}
export interface BatchDeleteMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export interface MemoryRecordUpdateInput {
    memoryRecordId: string;
    timestamp: Date;
    content?: MemoryContent | undefined;
    namespaces?: string[] | undefined;
    sourceNamespaces?: string[] | undefined;
    memoryStrategyId?: string | undefined;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    } | undefined;
}
export type MemoryRecordsUpdateInputList = MemoryRecordUpdateInput[];
export interface BatchUpdateMemoryRecordsInput {
    memoryId: string;
    records: MemoryRecordUpdateInput[];
    recordExpirySpecification?: RecordExpirySpecification | undefined;
}
export interface BatchUpdateMemoryRecordsOutput {
    successfulRecords: MemoryRecordOutput[];
    failedRecords: MemoryRecordOutput[];
}
export type UserTokenType = string | redacted.Redacted<string>;
export type UserIdType = string;
export type UserIdentifier = {
    userToken: string | redacted.Redacted<string>;
    userId?: undefined;
} | {
    userToken?: undefined;
    userId: string;
};
export type RequestUri = string;
export interface CompleteResourceTokenAuthRequest {
    userIdentifier: UserIdentifier;
    sessionUri: string;
}
export interface CompleteResourceTokenAuthResponse {
}
export type ABTestName = string;
export type ABTestDescription = string;
export type GatewayArn = string;
export type VariantName = string;
export type ConfigurationBundleArn = string;
export type ConfigurationBundleVersion = string;
export interface ConfigurationBundleRef {
    bundleArn: string;
    bundleVersion: string;
}
export type TargetName = string;
export interface TargetRef {
    name: string;
}
export interface VariantConfiguration {
    configurationBundle?: ConfigurationBundleRef | undefined;
    target?: TargetRef | undefined;
}
export interface Variant {
    name: string;
    weight: number;
    variantConfiguration: VariantConfiguration;
}
export type VariantList = Variant[];
export type PathPattern = string;
export type TargetPathList = string[];
export interface GatewayFilter {
    targetPaths?: string[] | undefined;
}
export type OnlineEvaluationConfigArn = string;
export interface PerVariantOnlineEvaluationConfig {
    name: string;
    onlineEvaluationConfigArn: string;
}
export type PerVariantOnlineEvaluationConfigList = PerVariantOnlineEvaluationConfig[];
export type ABTestEvaluationConfig = {
    onlineEvaluationConfigArn: string;
    perVariantOnlineEvaluationConfig?: undefined;
} | {
    onlineEvaluationConfigArn?: undefined;
    perVariantOnlineEvaluationConfig: PerVariantOnlineEvaluationConfig[];
};
export type RoleArn = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateABTestRequest {
    name: string;
    description?: string | undefined;
    gatewayArn: string;
    variants: Variant[];
    gatewayFilter?: GatewayFilter | undefined;
    evaluationConfig: ABTestEvaluationConfig;
    roleArn: string;
    enableOnCreate?: boolean | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ABTestId = string;
export type ABTestArn = string;
export type ABTestStatus = "CREATING" | "ACTIVE" | "CREATE_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | "FAILED" | (string & {});
export type ABTestExecutionStatus = "PAUSED" | "RUNNING" | "STOPPED" | "NOT_STARTED" | (string & {});
export interface CreateABTestResponse {
    abTestId: string;
    abTestArn: string;
    name?: string | undefined;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    createdAt: Date;
}
export type ActorId = string;
export type SessionId = string;
export type Content = {
    text: string | redacted.Redacted<string>;
};
export type Role = "ASSISTANT" | "USER" | "TOOL" | "OTHER" | (string & {});
export interface Conversational {
    content: Content;
    role: Role;
}
export type MemoryDocument = unknown;
export type MemoryJsonDataContent = unknown;
export interface MemoryJsonData {
    content: any;
}
export type PayloadType = {
    conversational: Conversational;
    blob?: undefined;
    json?: undefined;
} | {
    conversational?: undefined;
    blob: any;
    json?: undefined;
} | {
    conversational?: undefined;
    blob?: undefined;
    json: MemoryJsonData;
};
export type PayloadTypeList = PayloadType[];
export type EventId = string;
export type BranchName = string;
export interface Branch {
    rootEventId?: string | undefined;
    name: string;
}
export type MetadataValue = {
    stringValue: string;
};
export type MetadataMap = {
    [key: string]: MetadataValue | undefined;
};
export type ExtractionMode = "SKIP" | (string & {});
export type NamespaceVariableName = string;
export type NamespaceVariableValue = string;
export type NamespaceVariablesMap = {
    [key: string]: string | undefined;
};
export interface ExtractionConfig {
    namespaceVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventInput {
    memoryId: string;
    actorId: string;
    sessionId?: string | undefined;
    eventTimestamp: Date;
    payload: PayloadType[];
    branch?: Branch | undefined;
    clientToken?: string | undefined;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
    extractionMode?: ExtractionMode | undefined;
    extractionConfig?: ExtractionConfig | undefined;
}
export interface Event {
    memoryId: string;
    actorId: string;
    sessionId: string;
    eventId: string;
    eventTimestamp: Date;
    payload?: PayloadType[] | undefined;
    branch?: Branch | undefined;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
}
export interface CreateEventOutput {
    event: Event;
}
export type UserId = string;
export type PaymentAgentName = string;
export type PaymentManagerArn = string;
export type PaymentConnectorId = string;
export type PaymentInstrumentType = "EMBEDDED_CRYPTO_WALLET" | (string & {});
export type CryptoWalletNetwork = "ETHEREUM" | "SOLANA" | (string & {});
export type Email = string | redacted.Redacted<string>;
export interface LinkedAccountEmail {
    emailAddress: string | redacted.Redacted<string>;
}
export type PhoneNumber = string | redacted.Redacted<string>;
export interface LinkedAccountSms {
    phoneNumber: string | redacted.Redacted<string>;
}
export type JwtKeyId = string;
export interface LinkedAccountDeveloperJwt {
    kid: string;
    sub: string;
}
export interface OAuth2Authentication {
    sub: string;
    emailAddress?: string | redacted.Redacted<string> | undefined;
    name?: string | undefined;
    username?: string | undefined;
}
export type LinkedAccountOAuth2 = {
    google: OAuth2Authentication;
    apple?: undefined;
    x?: undefined;
    telegram?: undefined;
    github?: undefined;
} | {
    google?: undefined;
    apple: OAuth2Authentication;
    x?: undefined;
    telegram?: undefined;
    github?: undefined;
} | {
    google?: undefined;
    apple?: undefined;
    x: OAuth2Authentication;
    telegram?: undefined;
    github?: undefined;
} | {
    google?: undefined;
    apple?: undefined;
    x?: undefined;
    telegram: OAuth2Authentication;
    github?: undefined;
} | {
    google?: undefined;
    apple?: undefined;
    x?: undefined;
    telegram?: undefined;
    github: OAuth2Authentication;
};
export type LinkedAccount = {
    email: LinkedAccountEmail;
    sms?: undefined;
    developerJwt?: undefined;
    oAuth2?: undefined;
} | {
    email?: undefined;
    sms: LinkedAccountSms;
    developerJwt?: undefined;
    oAuth2?: undefined;
} | {
    email?: undefined;
    sms?: undefined;
    developerJwt: LinkedAccountDeveloperJwt;
    oAuth2?: undefined;
} | {
    email?: undefined;
    sms?: undefined;
    developerJwt?: undefined;
    oAuth2: LinkedAccountOAuth2;
};
export type LinkedAccountList = LinkedAccount[];
export interface EmbeddedCryptoWallet {
    network: CryptoWalletNetwork;
    linkedAccounts: LinkedAccount[];
    walletAddress?: string | undefined;
    redirectUrl?: string | undefined;
}
export type PaymentInstrumentDetails = {
    embeddedCryptoWallet: EmbeddedCryptoWallet;
};
export interface CreatePaymentInstrumentRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentType: PaymentInstrumentType;
    paymentInstrumentDetails: PaymentInstrumentDetails;
    clientToken?: string | undefined;
}
export type PaymentInstrumentId = string;
export type PaymentInstrumentStatus = "INITIATED" | "ACTIVE" | "FAILED" | "DELETED" | "BLOCKED" | (string & {});
export interface PaymentInstrument {
    paymentInstrumentId: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    userId: string;
    paymentInstrumentType: PaymentInstrumentType;
    paymentInstrumentDetails: PaymentInstrumentDetails;
    createdAt: Date;
    status: PaymentInstrumentStatus;
    updatedAt: Date;
}
export interface CreatePaymentInstrumentResponse {
    paymentInstrument: PaymentInstrument;
}
export type Currency = "USD" | (string & {});
export interface Amount {
    value: string;
    currency: Currency;
}
export interface SessionLimits {
    maxSpendAmount: Amount;
}
export interface CreatePaymentSessionRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    limits?: SessionLimits | undefined;
    expiryTimeInMinutes: number;
    clientToken?: string | undefined;
}
export type PaymentSessionId = string;
export interface AvailableLimits {
    availableSpendAmount?: Amount | undefined;
    updatedAt?: Date | undefined;
}
export interface PaymentSession {
    paymentSessionId: string;
    paymentManagerArn: string;
    limits?: SessionLimits | undefined;
    userId: string;
    expiryTimeInMinutes: number;
    createdAt: Date;
    availableLimits?: AvailableLimits | undefined;
    updatedAt: Date;
}
export interface CreatePaymentSessionResponse {
    paymentSession: PaymentSession;
}
export interface DeleteABTestRequest {
    abTestId: string;
}
export interface DeleteABTestResponse {
    abTestId: string;
    abTestArn: string;
    status: ABTestStatus;
}
export type BatchEvaluationId = string;
export interface DeleteBatchEvaluationRequest {
    batchEvaluationId: string;
}
export type BatchEvaluationArn = string;
export type BatchEvaluationStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | "STOPPING" | "STOPPED" | "DELETING" | (string & {});
export interface DeleteBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    status: BatchEvaluationStatus;
}
export type CapacityProviderId = string;
export interface DeleteCapacityProviderSessionRequest {
    capacityProviderId: string;
    sessionId: string;
}
export type CapacityProviderArn = string;
export type CapacityProviderSessionStatus = "Provisioning" | "Deprovisioning" | "Active" | "Deleting" | "Deleted" | "Stopped" | (string & {});
export interface DeleteCapacityProviderSessionResponse {
    capacityProviderArn: string;
    sessionId: string;
    status: CapacityProviderSessionStatus;
}
export interface DeleteEventInput {
    memoryId: string;
    sessionId: string;
    eventId: string;
    actorId: string;
}
export interface DeleteEventOutput {
    eventId: string;
}
export interface DeleteMemoryRecordInput {
    memoryId: string;
    memoryRecordId: string;
    namespace?: string | undefined;
}
export interface DeleteMemoryRecordOutput {
    memoryRecordId: string;
}
export interface DeletePaymentInstrumentRequest {
    userId?: string | undefined;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentId: string;
}
export interface DeletePaymentInstrumentResponse {
    status: PaymentInstrumentStatus;
}
export interface DeletePaymentSessionRequest {
    userId?: string | undefined;
    paymentManagerArn: string;
    paymentSessionId: string;
}
export type PaymentSessionStatus = "ACTIVE" | "EXPIRED" | "DELETED" | (string & {});
export interface DeletePaymentSessionResponse {
    status: PaymentSessionStatus;
}
export type RecommendationId = string;
export interface DeleteRecommendationRequest {
    recommendationId: string;
}
export type RecommendationStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "DELETING" | (string & {});
export interface DeleteRecommendationResponse {
    recommendationId: string;
    status: RecommendationStatus;
}
export type EvaluatorId = string;
export type Span = unknown;
export type Spans = any[];
export type EvaluationInput = {
    sessionSpans: any[];
};
export type SpanId = string;
export type SpanIds = string[];
export type TraceId = string;
export type TraceIds = string[];
export type EvaluationTarget = {
    spanIds: string[];
    traceIds?: undefined;
} | {
    spanIds?: undefined;
    traceIds: string[];
};
export interface SpanContext {
    sessionId: string;
    traceId?: string | undefined;
    spanId?: string | undefined;
}
export type Context = {
    spanContext: SpanContext;
};
export type EvaluationContent = {
    text: string;
};
export type EvaluationContentList = EvaluationContent[];
export type EvaluationToolName = string;
export type EvaluationToolNames = string[];
export interface EvaluationExpectedTrajectory {
    toolNames?: string[] | undefined;
}
export interface EvaluationReferenceInput {
    context: Context;
    expectedResponse?: EvaluationContent | undefined;
    assertions?: EvaluationContent[] | undefined;
    expectedTrajectory?: EvaluationExpectedTrajectory | undefined;
}
export type EvaluationReferenceInputs = EvaluationReferenceInput[];
export interface EvaluateRequest {
    evaluatorId: string;
    evaluationInput: EvaluationInput;
    evaluationTarget?: EvaluationTarget | undefined;
    evaluationReferenceInputs?: EvaluationReferenceInput[] | undefined;
}
export type EvaluatorArn = string;
export type EvaluatorName = string;
export type EvaluationDimensionName = string;
export type EvaluationExplanation = string | redacted.Redacted<string>;
export interface TokenUsage {
    inputTokens?: number | undefined;
    outputTokens?: number | undefined;
    totalTokens?: number | undefined;
}
export type EvaluationErrorMessage = string;
export type EvaluationErrorCode = string;
export type IgnoredReferenceInputField = string;
export type IgnoredReferenceInputFields = string[];
export interface EvaluationResultContent {
    evaluatorArn: string;
    evaluatorId: string;
    evaluatorName: string;
    evaluationDimensionName?: string | undefined;
    explanation?: string | redacted.Redacted<string> | undefined;
    context: Context;
    value?: number | undefined;
    label?: string | undefined;
    tokenUsage?: TokenUsage | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
    ignoredReferenceInputFields?: string[] | undefined;
}
export type EvaluationResults = EvaluationResultContent[];
export interface EvaluateResponse {
    evaluationResults: EvaluationResultContent[];
}
export interface GetABTestRequest {
    abTestId: string;
}
export type ErrorDetailsList = string[];
export interface ControlStats {
    variantName: string;
    sampleSize: number;
    mean: number;
}
export interface ConfidenceInterval {
    lower?: number | undefined;
    upper?: number | undefined;
}
export interface VariantResult {
    variantName: string;
    sampleSize: number;
    mean: number;
    absoluteChange?: number | undefined;
    percentChange?: number | undefined;
    pValue?: number | undefined;
    confidenceInterval?: ConfidenceInterval | undefined;
    isSignificant: boolean;
}
export type VariantResultList = VariantResult[];
export interface EvaluatorMetric {
    evaluatorArn: string;
    controlStats: ControlStats;
    variantResults: VariantResult[];
}
export type EvaluatorMetricList = EvaluatorMetric[];
export interface ABTestResults {
    analysisTimestamp?: Date | undefined;
    evaluatorMetrics: EvaluatorMetric[];
}
export interface GetABTestResponse {
    abTestId: string;
    abTestArn: string;
    name: string;
    description?: string | undefined;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    gatewayArn: string;
    variants: Variant[];
    gatewayFilter?: GatewayFilter | undefined;
    evaluationConfig: ABTestEvaluationConfig;
    roleArn?: string | undefined;
    currentRunId?: string | undefined;
    errorDetails?: string[] | undefined;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
    maxDurationExpiresAt?: Date | undefined;
    createdAt: Date;
    updatedAt: Date;
    results?: ABTestResults | undefined;
}
export type SessionType = string;
export interface GetAgentCardRequest {
    runtimeSessionId?: string | undefined;
    agentRuntimeArn: string;
    qualifier?: string | undefined;
}
export type AgentCard = unknown;
export type HttpResponseCode = number;
export interface GetAgentCardResponse {
    runtimeSessionId?: string | undefined;
    agentCard: any;
    statusCode?: number | undefined;
}
export interface GetBatchEvaluationRequest {
    batchEvaluationId: string;
}
export type BatchEvaluationName = string;
export interface Evaluator {
    evaluatorId: string;
}
export type EvaluatorList = Evaluator[];
export type InsightId = string;
export interface Insight {
    insightId: string;
}
export type InsightList = Insight[];
export type EvaluationStringList = string[];
export type LogGroupName = string;
export type LogGroupNameList = string[];
export type LogGroupNamePrefix = string;
export type LogGroupNamePrefixList = string[];
export interface SessionFilterConfig {
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type TraceIdList = string[];
export interface SessionTraceIds {
    sessionId: string;
    traceIds: string[];
}
export type SessionTraceIdsList = SessionTraceIds[];
export interface CloudWatchFilterConfig {
    sessionIds?: string[] | undefined;
    timeRange?: SessionFilterConfig | undefined;
    sessionTraceIds?: SessionTraceIds[] | undefined;
}
export interface CloudWatchLogsSource {
    serviceNames: string[];
    logGroupNames?: string[] | undefined;
    logGroupNamePrefixes?: string[] | undefined;
    filterConfig?: CloudWatchFilterConfig | undefined;
}
export interface OnlineEvaluationConfigSource {
    onlineEvaluationConfigArn: string;
    timeRange?: SessionFilterConfig | undefined;
}
export type DataSourceConfig = {
    cloudWatchLogs: CloudWatchLogsSource;
    onlineEvaluationConfigSource?: undefined;
} | {
    cloudWatchLogs?: undefined;
    onlineEvaluationConfigSource: OnlineEvaluationConfigSource;
};
export type OptionalLogGroupName = string;
export type LogStreamName = string;
export type MetricsNamespace = string;
export type ResultDestination = "DEDICATED_LOG_GROUP" | "SOURCE_LOG_GROUP" | (string & {});
export interface CloudWatchOutputConfig {
    logGroupName?: string | undefined;
    logStreamName?: string | undefined;
    metricsNamespace?: string | undefined;
    resultDestination?: ResultDestination | undefined;
}
export type OutputConfig = {
    cloudWatchConfig: CloudWatchOutputConfig;
};
export interface EvaluatorStatistics {
    averageScore?: number | undefined;
}
export interface EvaluatorSummary {
    evaluatorId?: string | undefined;
    evaluationDimensionName?: string | undefined;
    statistics?: EvaluatorStatistics | undefined;
    totalEvaluated?: number | undefined;
    totalFailed?: number | undefined;
}
export type EvaluatorSummaryList = EvaluatorSummary[];
export interface EvaluationJobResults {
    numberOfSessionsCompleted?: number | undefined;
    numberOfSessionsInProgress?: number | undefined;
    numberOfSessionsFailed?: number | undefined;
    totalNumberOfSessions?: number | undefined;
    numberOfSessionsIgnored?: number | undefined;
    evaluatorSummaries?: EvaluatorSummary[] | undefined;
}
export type InsightType = "FAILURE" | (string & {});
export type InsightName = string | redacted.Redacted<string>;
export type InsightDescription = string | redacted.Redacted<string>;
export type FindingTargetId = string;
export type FindingTargetType = "SPAN_ID" | "TRACE_ID" | "SPAN_NAME" | (string & {});
export type FindingDescription = string | redacted.Redacted<string>;
export interface SessionFinding {
    targetId?: string | undefined;
    targetType?: FindingTargetType | undefined;
    description: string | redacted.Redacted<string>;
    category?: string | undefined;
    confidence?: number | undefined;
}
export type SessionFindingList = SessionFinding[];
export interface SampleSession {
    sessionId: string;
    lastSeenAt?: Date | undefined;
    findings?: SessionFinding[] | undefined;
}
export type InsightSampleSessionList = SampleSession[];
export type RootCauseName = string | redacted.Redacted<string>;
export type RootCauseExplanation = string | redacted.Redacted<string>;
export type SuggestedFix = string | redacted.Redacted<string>;
export interface InsightRootCause {
    name: string | redacted.Redacted<string>;
    explanation: string | redacted.Redacted<string>;
    affectedSessionCount?: number | undefined;
    suggestedFix?: string | redacted.Redacted<string> | undefined;
    sampleSessions?: SampleSession[] | undefined;
}
export type InsightRootCauseList = InsightRootCause[];
export interface InsightResult {
    type: InsightType;
    name: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    createdAt: Date;
    affectedSessionCount?: number | undefined;
    sampleSessions?: SampleSession[] | undefined;
    rootCauses?: InsightRootCause[] | undefined;
}
export type InsightResultList = InsightResult[];
export type InsightsFailureCategory = "execution-error-category-authentication" | "execution-error-category-resource-not-found" | "execution-error-category-service-errors" | "execution-error-category-rate-limiting" | "execution-error-category-formatting" | "execution-error-category-timeout" | "execution-error-category-resource-exhaustion" | "execution-error-category-environment" | "execution-error-category-tool-schema" | "task-instruction-category-non-compliance" | "task-instruction-category-problem-id" | "incorrect-actions-category-tool-selection" | "incorrect-actions-category-poor-information-retrieval" | "incorrect-actions-category-clarification" | "incorrect-actions-category-inappropriate-info-request" | "context-handling-error-category-context-handling-failures" | "hallucination-category-hall-capabilities" | "hallucination-category-hall-misunderstand" | "hallucination-category-hall-usage" | "hallucination-category-hall-history" | "hallucination-category-hall-params" | "hallucination-category-fabricate-tool-outputs" | "repetitive-behavior-category-repetition-tool" | "repetitive-behavior-category-repetition-info" | "repetitive-behavior-category-step-repetition" | "orchestration-related-errors-category-reasoning-mismatch" | "orchestration-related-errors-category-goal-deviation" | "orchestration-related-errors-category-premature-termination" | "orchestration-related-errors-category-unaware-termination" | "llm-output-category-nonsensical" | "configuration-mismatch-category-tool-definition" | "coding-use-case-specific-failure-types-category-edge-case-oversights" | "coding-use-case-specific-failure-types-category-dependency-issues" | "other" | (string & {});
export interface InsightsFailureSignal {
    category: InsightsFailureCategory;
    evidence: string;
    confidence: number;
}
export type InsightsFailureSignalList = InsightsFailureSignal[];
export interface FailureSpanDetail {
    spanId: string;
    traceId: string;
    signals: InsightsFailureSignal[];
}
export type FailureSpanDetailList = FailureSpanDetail[];
export interface AffectedSession {
    sessionId: string;
    explanation: string;
    fixType: string;
    recommendation: string;
    failureSpans: FailureSpanDetail[];
}
export type AffectedSessionList = AffectedSession[];
export interface RootCauseCluster {
    clusterId: number;
    name: string;
    rootCause: string;
    recommendation: string;
    affectedSessionCount: number;
    affectedSessions: AffectedSession[];
}
export type RootCauseClusterList = RootCauseCluster[];
export interface FailureSubCategoryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    rootCauses: RootCauseCluster[];
}
export type FailureSubCategoryClusterList = FailureSubCategoryCluster[];
export interface FailureCategoryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    subCategories: FailureSubCategoryCluster[];
}
export type FailureCategoryClusterList = FailureCategoryCluster[];
export interface FailureAnalysisResultContent {
    failures: FailureCategoryCluster[];
}
export type UserIntentList = string[];
export interface UserIntentAffectedSession {
    sessionId: string;
    userMessages: string[];
}
export type UserIntentAffectedSessionList = UserIntentAffectedSession[];
export interface UserIntentCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    affectedSessions: UserIntentAffectedSession[];
}
export type UserIntentClusterList = UserIntentCluster[];
export interface UserIntentClusteringResultContent {
    userIntents: UserIntentCluster[];
}
export interface ExecutionSummaryAffectedSession {
    sessionId: string;
    approachTaken: string;
    finalOutcome: string;
}
export type ExecutionSummaryAffectedSessionList = ExecutionSummaryAffectedSession[];
export interface ExecutionSummaryCluster {
    clusterId: number;
    name: string;
    description: string;
    affectedSessionCount: number;
    affectedSessions: ExecutionSummaryAffectedSession[];
}
export type ExecutionSummaryClusterList = ExecutionSummaryCluster[];
export interface ExecutionSummaryClusteringResultContent {
    executionSummaries: ExecutionSummaryCluster[];
}
export type BatchEvaluationDescription = string;
export type KmsKeyArn = string;
export interface GetBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    status: BatchEvaluationStatus;
    createdAt: Date;
    evaluators?: Evaluator[] | undefined;
    insights?: Insight[] | undefined;
    dataSourceConfig?: DataSourceConfig | undefined;
    outputConfig?: OutputConfig | undefined;
    evaluationResults?: EvaluationJobResults | undefined;
    insightResults?: InsightResult[] | undefined;
    failureAnalysisResult?: FailureAnalysisResultContent | undefined;
    userIntentResult?: UserIntentClusteringResultContent | undefined;
    executionSummaryResult?: ExecutionSummaryClusteringResultContent | undefined;
    errorDetails?: string[] | undefined;
    description?: string | undefined;
    updatedAt?: Date | undefined;
    kmsKeyArn?: string | undefined;
}
export type BrowserSessionId = string;
export interface GetBrowserSessionRequest {
    browserIdentifier: string;
    sessionId: string;
}
export type Name = string;
export type ViewPortWidth = number;
export type ViewPortHeight = number;
export interface ViewPort {
    width: number;
    height: number;
}
export interface S3Location {
    bucket: string;
    prefix: string;
    versionId?: string | undefined;
}
export type ResourceLocation = {
    s3: S3Location;
};
export interface BrowserExtension {
    location: ResourceLocation;
}
export type BrowserExtensions = BrowserExtension[];
export type BrowserEnterprisePolicyType = "MANAGED" | "RECOMMENDED" | (string & {});
export interface BrowserEnterprisePolicy {
    location: ResourceLocation;
    type?: BrowserEnterprisePolicyType | undefined;
}
export type BrowserEnterprisePolicies = BrowserEnterprisePolicy[];
export type BrowserProfileId = string;
export interface BrowserProfileConfiguration {
    profileIdentifier: string;
}
export type BrowserSessionTimeout = number;
export type BrowserSessionStatus = "READY" | "TERMINATED" | (string & {});
export type BrowserStreamEndpoint = string;
export type AutomationStreamStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AutomationStream {
    streamEndpoint: string;
    streamStatus: AutomationStreamStatus;
}
export interface LiveViewStream {
    streamEndpoint?: string | undefined;
}
export interface BrowserSessionStream {
    automationStream: AutomationStream;
    liveViewStream?: LiveViewStream | undefined;
}
export type HostName = string;
export type DomainPattern = string;
export type DomainPatterns = string[];
export type SecretArn = string;
export interface BasicAuth {
    secretArn: string;
}
export type ProxyCredentials = {
    basicAuth: BasicAuth;
};
export interface ExternalProxy {
    server: string;
    port: number;
    domainPatterns?: string[] | undefined;
    credentials?: ProxyCredentials | undefined;
}
export type Proxy = {
    externalProxy: ExternalProxy;
};
export type Proxies = Proxy[];
export interface ProxyBypass {
    domainPatterns?: string[] | undefined;
}
export interface ProxyConfiguration {
    proxies: Proxy[];
    bypass?: ProxyBypass | undefined;
}
export interface SecretsManagerLocation {
    secretArn: string;
}
export type CertificateLocation = {
    secretsManager: SecretsManagerLocation;
};
export interface Certificate {
    location: CertificateLocation;
}
export type Certificates = Certificate[];
export type S3FilesAccessPointArn = string;
export type MountPath = string;
export type S3FilesFileSystemArn = string;
export interface S3FilesConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export type EfsAccessPointArn = string;
export type EfsFileSystemArn = string;
export interface EfsConfiguration {
    accessPointArn: string;
    mountPath: string;
    fileSystemArn: string;
}
export type ToolsFileSystemConfiguration = {
    s3FilesConfiguration: S3FilesConfiguration;
    efsConfiguration?: undefined;
} | {
    s3FilesConfiguration?: undefined;
    efsConfiguration: EfsConfiguration;
};
export type ToolsFileSystemConfigurations = ToolsFileSystemConfiguration[];
export interface GetBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    name?: string | undefined;
    createdAt: Date;
    viewPort?: ViewPort | undefined;
    extensions?: BrowserExtension[] | undefined;
    enterprisePolicies?: BrowserEnterprisePolicy[] | undefined;
    profileConfiguration?: BrowserProfileConfiguration | undefined;
    sessionTimeoutSeconds?: number | undefined;
    status?: BrowserSessionStatus | undefined;
    streams?: BrowserSessionStream | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    certificates?: Certificate[] | undefined;
    filesystemConfigurations?: ToolsFileSystemConfiguration[] | undefined;
    sessionReplayArtifact?: string | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type CodeInterpreterSessionId = string;
export interface GetCodeInterpreterSessionRequest {
    codeInterpreterIdentifier: string;
    sessionId: string;
}
export type CodeInterpreterSessionTimeout = number;
export type CodeInterpreterSessionStatus = "READY" | "TERMINATED" | (string & {});
export interface GetCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    name?: string | undefined;
    createdAt: Date;
    sessionTimeoutSeconds?: number | undefined;
    status?: CodeInterpreterSessionStatus | undefined;
    certificates?: Certificate[] | undefined;
    filesystemConfigurations?: ToolsFileSystemConfiguration[] | undefined;
}
export interface GetEventInput {
    memoryId: string;
    sessionId: string;
    actorId: string;
    eventId: string;
}
export interface GetEventOutput {
    event: Event;
}
export interface GetMemoryRecordInput {
    memoryId: string;
    memoryRecordId: string;
    namespace?: string | undefined;
}
export interface MemoryRecord {
    memoryRecordId: string;
    content: MemoryContent;
    memoryStrategyId?: string | undefined;
    namespaces: string[];
    createdAt: Date;
    timestamp?: Date | undefined;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    } | undefined;
    expiresAt?: Date | undefined;
}
export interface GetMemoryRecordOutput {
    memoryRecord: MemoryRecord;
}
export interface GetPaymentInstrumentRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentConnectorId?: string | undefined;
    paymentInstrumentId: string;
}
export interface GetPaymentInstrumentResponse {
    paymentInstrument: PaymentInstrument;
}
export type BlockchainChainId = "BASE" | "BASE_SEPOLIA" | "ETHEREUM" | "SOLANA" | "SOLANA_DEVNET" | (string & {});
export type InstrumentBalanceToken = "USDC" | (string & {});
export interface GetPaymentInstrumentBalanceRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentConnectorId: string;
    paymentInstrumentId: string;
    chain: BlockchainChainId;
    token: InstrumentBalanceToken;
}
export interface TokenBalance {
    amount: string;
    decimals: number;
    token: InstrumentBalanceToken;
    network: CryptoWalletNetwork;
    chain: BlockchainChainId;
}
export interface GetPaymentInstrumentBalanceResponse {
    paymentInstrumentId: string;
    tokenBalance: TokenBalance;
}
export interface GetPaymentSessionRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentSessionId: string;
}
export interface GetPaymentSessionResponse {
    paymentSession: PaymentSession;
}
export interface GetRecommendationRequest {
    recommendationId: string;
}
export type RecommendationArn = string;
export type RecommendationName = string;
export type RecommendationDescription = string;
export type RecommendationType = "SYSTEM_PROMPT_RECOMMENDATION" | "TOOL_DESCRIPTION_RECOMMENDATION" | (string & {});
export type SystemPromptText = string | redacted.Redacted<string>;
export type ConfigurationBundleVersionId = string;
export interface SystemPromptConfigurationBundle {
    bundleArn: string;
    versionId: string;
    systemPromptJsonPath: string;
}
export type SystemPromptConfig = {
    text: string | redacted.Redacted<string>;
    configurationBundle?: undefined;
} | {
    text?: undefined;
    configurationBundle: SystemPromptConfigurationBundle;
};
export type LogGroupArnList = string[];
export type ServiceName = string;
export type ServiceNameList = string[];
export type CloudWatchLogsFilterOperator = "Equals" | "NotEquals" | "GreaterThan" | "LessThan" | "GreaterThanOrEqual" | "LessThanOrEqual" | "Contains" | "NotContains" | (string & {});
export type FilterStringValue = string;
export type FilterValue = {
    stringValue: string;
    doubleValue?: undefined;
    booleanValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue: number;
    booleanValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue: boolean;
};
export interface CloudWatchLogsFilter {
    key: string;
    operator: CloudWatchLogsFilterOperator;
    value: FilterValue;
}
export type CloudWatchLogsFilterList = CloudWatchLogsFilter[];
export interface CloudWatchLogsRule {
    filters?: CloudWatchLogsFilter[] | undefined;
}
export interface CloudWatchLogsTraceConfig {
    logGroupArns: string[];
    serviceNames: string[];
    startTime: Date;
    endTime: Date;
    rule?: CloudWatchLogsRule | undefined;
}
export interface BatchEvaluationTraceConfig {
    batchEvaluationArn: string;
}
export interface OnlineEvaluationTraceConfig {
    onlineEvaluationConfigArn: string;
    startTime: Date;
    endTime: Date;
}
export type AgentTracesConfig = {
    sessionSpans: any[];
    cloudwatchLogs?: undefined;
    batchEvaluation?: undefined;
    onlineEvaluation?: undefined;
} | {
    sessionSpans?: undefined;
    cloudwatchLogs: CloudWatchLogsTraceConfig;
    batchEvaluation?: undefined;
    onlineEvaluation?: undefined;
} | {
    sessionSpans?: undefined;
    cloudwatchLogs?: undefined;
    batchEvaluation: BatchEvaluationTraceConfig;
    onlineEvaluation?: undefined;
} | {
    sessionSpans?: undefined;
    cloudwatchLogs?: undefined;
    batchEvaluation?: undefined;
    onlineEvaluation: OnlineEvaluationTraceConfig;
};
export interface RecommendationEvaluatorReference {
    evaluatorArn: string;
}
export type RecommendationEvaluatorList = RecommendationEvaluatorReference[];
export interface RecommendationEvaluationConfig {
    evaluators: RecommendationEvaluatorReference[];
}
export interface SystemPromptRecommendationConfig {
    systemPrompt: SystemPromptConfig;
    agentTraces: AgentTracesConfig;
    evaluationConfig?: RecommendationEvaluationConfig | undefined;
}
export type RecommendationToolName = string;
export type ToolDescriptionText = string | redacted.Redacted<string>;
export type ToolDescriptionConfig = {
    text: string | redacted.Redacted<string>;
};
export interface ToolDescriptionInput {
    toolName: string;
    toolDescription: ToolDescriptionConfig;
}
export type ToolDescriptionList = ToolDescriptionInput[];
export interface ToolDescriptionTextInput {
    tools: ToolDescriptionInput[];
}
export interface ConfigurationBundleToolEntry {
    toolName: string;
    toolDescriptionJsonPath: string;
}
export type ConfigurationBundleToolEntryList = ConfigurationBundleToolEntry[];
export interface ToolDescriptionConfigurationBundle {
    bundleArn: string;
    versionId: string;
    tools: ConfigurationBundleToolEntry[];
}
export type ToolDescriptionSource = {
    toolDescriptionText: ToolDescriptionTextInput;
    configurationBundle?: undefined;
} | {
    toolDescriptionText?: undefined;
    configurationBundle: ToolDescriptionConfigurationBundle;
};
export interface ToolDescriptionRecommendationConfig {
    toolDescription: ToolDescriptionSource;
    agentTraces: AgentTracesConfig;
}
export type RecommendationConfig = {
    systemPromptRecommendationConfig: SystemPromptRecommendationConfig;
    toolDescriptionRecommendationConfig?: undefined;
} | {
    systemPromptRecommendationConfig?: undefined;
    toolDescriptionRecommendationConfig: ToolDescriptionRecommendationConfig;
};
export interface RecommendationResultConfigurationBundle {
    bundleArn: string;
    versionId: string;
}
export type RecommendationExplanation = string;
export type RecommendationErrorCode = string;
export type RecommendationErrorMessage = string;
export interface SystemPromptRecommendationResult {
    recommendedSystemPrompt?: string | redacted.Redacted<string> | undefined;
    configurationBundle?: RecommendationResultConfigurationBundle | undefined;
    explanation?: string | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
}
export interface ToolDescriptionOutput {
    toolName: string;
    recommendedToolDescription?: string | redacted.Redacted<string> | undefined;
    explanation?: string | undefined;
}
export type ToolDescriptionResultList = ToolDescriptionOutput[];
export interface ToolDescriptionRecommendationResult {
    tools?: ToolDescriptionOutput[] | undefined;
    configurationBundle?: RecommendationResultConfigurationBundle | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
}
export type RecommendationResult = {
    systemPromptRecommendationResult: SystemPromptRecommendationResult;
    toolDescriptionRecommendationResult?: undefined;
} | {
    systemPromptRecommendationResult?: undefined;
    toolDescriptionRecommendationResult: ToolDescriptionRecommendationResult;
};
export interface GetRecommendationResponse {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string | undefined;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
    recommendationResult?: RecommendationResult | undefined;
    kmsKeyArn?: string | undefined;
}
export type WorkloadIdentityTokenType = string | redacted.Redacted<string>;
export type CredentialProviderName = string;
export interface GetResourceApiKeyRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
}
export type ApiKeyType = string | redacted.Redacted<string>;
export interface GetResourceApiKeyResponse {
    apiKey: string | redacted.Redacted<string>;
}
export type ScopeType = string;
export type ScopesListType = string[];
export type Oauth2FlowType = "USER_FEDERATION" | "M2M" | "ON_BEHALF_OF_TOKEN_EXCHANGE" | (string & {});
export type ResourceOauth2ReturnUrlType = string;
export type CustomRequestKeyType = string;
export type CustomRequestValueType = string | redacted.Redacted<string>;
export type CustomRequestParametersType = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type State = string | redacted.Redacted<string>;
export type ResourceType = string;
export type ResourcesListType = string[];
export type AudienceType = string;
export type AudiencesListType = string[];
export interface GetResourceOauth2TokenRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
    scopes: string[];
    oauth2Flow: Oauth2FlowType;
    sessionUri?: string | undefined;
    resourceOauth2ReturnUrl?: string | undefined;
    forceAuthentication?: boolean | undefined;
    customParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    customState?: string | redacted.Redacted<string> | undefined;
    resources?: string[] | undefined;
    audiences?: string[] | undefined;
}
export type AuthorizationUrlType = string | redacted.Redacted<string>;
export type AccessTokenType = string | redacted.Redacted<string>;
export type SessionStatus = "IN_PROGRESS" | "FAILED" | (string & {});
export interface GetResourceOauth2TokenResponse {
    authorizationUrl?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    sessionUri?: string | undefined;
    sessionStatus?: SessionStatus | undefined;
}
export type PaymentHttpMethodType = "GET" | "POST" | "PUT" | "DELETE" | "PATCH" | (string & {});
export type PaymentRequestHostType = string;
export type PaymentRequestPathType = string;
export type CoinbaseCdpPaymentRequestBodyType = string;
export interface CoinbaseCdpTokenRequestInput {
    requestMethod: PaymentHttpMethodType;
    requestHost?: string | undefined;
    requestPath: string;
    includeWalletAuthToken?: boolean | undefined;
    requestBody?: string | undefined;
}
export type StripePrivyRequestHostType = string;
export type StripePrivyRequestPathType = string;
export type StripePrivyRequestBodyType = string | redacted.Redacted<string>;
export interface StripePrivyTokenRequestInput {
    requestHost?: string | undefined;
    requestPath: string;
    requestBody: string | redacted.Redacted<string>;
    includeAuthorizationSignature?: boolean | undefined;
}
export type PaymentTokenRequestInput = {
    coinbaseCdpTokenRequest: CoinbaseCdpTokenRequestInput;
    stripePrivyTokenRequest?: undefined;
} | {
    coinbaseCdpTokenRequest?: undefined;
    stripePrivyTokenRequest: StripePrivyTokenRequestInput;
};
export interface GetResourcePaymentTokenRequest {
    workloadIdentityToken: string | redacted.Redacted<string>;
    resourceCredentialProviderName: string;
    paymentTokenRequest: PaymentTokenRequestInput;
}
export type CoinbaseCdpPaymentJwtTokenType = string | redacted.Redacted<string>;
export interface CoinbaseCdpTokenResponseOutput {
    bearerToken: string | redacted.Redacted<string>;
    walletAuthToken?: string | redacted.Redacted<string> | undefined;
}
export type StripePrivyAuthorizationSignatureType = string | redacted.Redacted<string>;
export type StripePrivyAppIdType = string;
export type StripePrivyBasicAuthTokenType = string | redacted.Redacted<string>;
export interface StripePrivyTokenResponseOutput {
    authorizationSignature?: string | redacted.Redacted<string> | undefined;
    requestExpiry?: number | undefined;
    appId: string;
    basicAuthToken: string | redacted.Redacted<string>;
}
export type PaymentTokenResponseOutput = {
    coinbaseCdpTokenResponse: CoinbaseCdpTokenResponseOutput;
    stripePrivyTokenResponse?: undefined;
} | {
    coinbaseCdpTokenResponse?: undefined;
    stripePrivyTokenResponse: StripePrivyTokenResponseOutput;
};
export interface GetResourcePaymentTokenResponse {
    paymentTokenResponse: PaymentTokenResponseOutput;
}
export type WorkloadIdentityNameType = string;
export interface GetWorkloadAccessTokenRequest {
    workloadName: string;
}
export interface GetWorkloadAccessTokenResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export interface GetWorkloadAccessTokenForJWTRequest {
    workloadName: string;
    userToken: string | redacted.Redacted<string>;
}
export interface GetWorkloadAccessTokenForJWTResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export interface GetWorkloadAccessTokenForUserIdRequest {
    workloadName: string;
    userId: string;
}
export interface GetWorkloadAccessTokenForUserIdResponse {
    workloadAccessToken: string | redacted.Redacted<string>;
}
export type IngestPayloadType = {
    conversational: Conversational;
    json?: undefined;
} | {
    conversational?: undefined;
    json: MemoryJsonData;
};
export type IngestPayloadList = IngestPayloadType[];
export interface InlineMemoryContent {
    payload: IngestPayloadType[];
}
export type ContentSource = {
    inline: InlineMemoryContent;
};
export interface IngestDataInput {
    memoryId: string;
    source: ContentSource;
    contentTimestamp: Date;
    actorId: string;
    sessionId?: string | undefined;
    extractionConfig?: ExtractionConfig | undefined;
    metadata?: {
        [key: string]: MetadataValue | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface IngestDataOutput {
    sessionId: string;
}
export type MimeType = string;
export type StringType = string;
export type Body = Uint8Array | redacted.Redacted<Uint8Array>;
export interface InvokeAgentRuntimeRequest {
    contentType?: string | undefined;
    accept?: string | undefined;
    mcpSessionId?: string | undefined;
    runtimeSessionId?: string | undefined;
    mcpProtocolVersion?: string | undefined;
    mcpMethod?: string | undefined;
    mcpName?: string | undefined;
    runtimeUserId?: string | undefined;
    traceId?: string | undefined;
    traceParent?: string | undefined;
    traceState?: string | undefined;
    baggage?: string | undefined;
    agentRuntimeArn: string;
    qualifier?: string | undefined;
    accountId?: string | undefined;
    payload: T.StreamingInputBody;
}
export interface InvokeAgentRuntimeResponse {
    runtimeSessionId?: string | undefined;
    sessionEndpointUrl?: string | undefined;
    mcpSessionId?: string | undefined;
    mcpProtocolVersion?: string | undefined;
    traceId?: string | undefined;
    traceParent?: string | undefined;
    traceState?: string | undefined;
    baggage?: string | undefined;
    contentType: string;
    response?: T.StreamingOutputBody | undefined;
    statusCode?: number | undefined;
}
export interface InvokeAgentRuntimeCommandRequestBody {
    command: string;
    timeout?: number | undefined;
}
export interface InvokeAgentRuntimeCommandRequest {
    contentType?: string | undefined;
    accept?: string | undefined;
    runtimeSessionId?: string | undefined;
    traceId?: string | undefined;
    traceParent?: string | undefined;
    traceState?: string | undefined;
    baggage?: string | undefined;
    agentRuntimeArn: string;
    qualifier?: string | undefined;
    accountId?: string | undefined;
    body: InvokeAgentRuntimeCommandRequestBody;
}
export interface ContentStartEvent {
}
export interface ContentDeltaEvent {
    stdout?: string | undefined;
    stderr?: string | undefined;
}
export type CommandExecutionStatus = "COMPLETED" | "TIMED_OUT" | (string & {});
export interface ContentStopEvent {
    exitCode: number;
    status: CommandExecutionStatus;
}
export interface ResponseChunk {
    contentStart?: ContentStartEvent | undefined;
    contentDelta?: ContentDeltaEvent | undefined;
    contentStop?: ContentStopEvent | undefined;
}
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type InvokeAgentRuntimeCommandStreamOutput = {
    chunk: ResponseChunk;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException: AccessDeniedException;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException: InternalServerException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    validationException?: undefined;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException: ValidationException;
    runtimeClientError?: undefined;
} | {
    chunk?: undefined;
    accessDeniedException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    runtimeClientError: RuntimeClientError;
};
export interface InvokeAgentRuntimeCommandResponse {
    runtimeSessionId?: string | undefined;
    traceId?: string | undefined;
    traceParent?: string | undefined;
    traceState?: string | undefined;
    baggage?: string | undefined;
    contentType: string;
    statusCode?: number | undefined;
    stream: stream.Stream<InvokeAgentRuntimeCommandStreamOutput, Error, never>;
}
export type MouseButton = "LEFT" | "RIGHT" | "MIDDLE" | (string & {});
export interface MouseClickArguments {
    x: number;
    y: number;
    button?: MouseButton | undefined;
    clickCount?: number | undefined;
}
export interface MouseMoveArguments {
    x: number;
    y: number;
}
export interface MouseDragArguments {
    endX: number;
    endY: number;
    startX: number;
    startY: number;
    button?: MouseButton | undefined;
}
export interface MouseScrollArguments {
    x: number;
    y: number;
    deltaX?: number | undefined;
    deltaY?: number | undefined;
}
export interface KeyTypeArguments {
    text: string;
}
export interface KeyPressArguments {
    key: string;
    presses?: number | undefined;
}
export type KeyList = string[];
export interface KeyShortcutArguments {
    keys: string[];
}
export type ScreenshotFormat = "PNG" | (string & {});
export interface ScreenshotArguments {
    format?: ScreenshotFormat | undefined;
}
export type BrowserAction = {
    mouseClick: MouseClickArguments;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove: MouseMoveArguments;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag: MouseDragArguments;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll: MouseScrollArguments;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType: KeyTypeArguments;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress: KeyPressArguments;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut: KeyShortcutArguments;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot: ScreenshotArguments;
};
export interface InvokeBrowserRequest {
    browserIdentifier: string;
    sessionId: string;
    action: BrowserAction;
}
export type BrowserActionStatus = "SUCCESS" | "FAILED" | (string & {});
export interface MouseClickResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface MouseMoveResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface MouseDragResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface MouseScrollResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface KeyTypeResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface KeyPressResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface KeyShortcutResult {
    status: BrowserActionStatus;
    error?: string | undefined;
}
export interface ScreenshotResult {
    status: BrowserActionStatus;
    error?: string | undefined;
    data?: Uint8Array | undefined;
}
export type BrowserActionResult = {
    mouseClick: MouseClickResult;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove: MouseMoveResult;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag: MouseDragResult;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll: MouseScrollResult;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType: KeyTypeResult;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress: KeyPressResult;
    keyShortcut?: undefined;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut: KeyShortcutResult;
    screenshot?: undefined;
} | {
    mouseClick?: undefined;
    mouseMove?: undefined;
    mouseDrag?: undefined;
    mouseScroll?: undefined;
    keyType?: undefined;
    keyPress?: undefined;
    keyShortcut?: undefined;
    screenshot: ScreenshotResult;
};
export interface InvokeBrowserResponse {
    result: BrowserActionResult;
    sessionId: string;
}
export type ToolName = "executeCode" | "executeCommand" | "readFiles" | "listFiles" | "removeFiles" | "writeFiles" | "startCommandExecution" | "getTask" | "stopTask" | (string & {});
export type MaxLenString = string;
export type ProgrammingLanguage = "python" | "javascript" | "typescript" | (string & {});
export type StringList = string[];
export interface InputContentBlock {
    path: string;
    text?: string | undefined;
    blob?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type InputContentBlockList = InputContentBlock[];
export type LanguageRuntime = "nodejs" | "deno" | "python" | (string & {});
export interface ToolArguments {
    code?: string | undefined;
    language?: ProgrammingLanguage | undefined;
    clearContext?: boolean | undefined;
    command?: string | undefined;
    path?: string | undefined;
    paths?: string[] | undefined;
    content?: InputContentBlock[] | undefined;
    directoryPath?: string | undefined;
    taskId?: string | undefined;
    runtime?: LanguageRuntime | undefined;
}
export interface InvokeCodeInterpreterRequest {
    codeInterpreterIdentifier: string;
    sessionId?: string | undefined;
    traceId?: string | undefined;
    traceParent?: string | undefined;
    name: ToolName;
    arguments?: ToolArguments | undefined;
}
export type ContentBlockType = "text" | "image" | "resource" | "resource_link" | (string & {});
export type ResourceContentType = "text" | "blob" | (string & {});
export interface ResourceContent {
    type: ResourceContentType;
    uri?: string | undefined;
    mimeType?: string | undefined;
    text?: string | undefined;
    blob?: Uint8Array | undefined;
}
export interface ContentBlock {
    type: ContentBlockType;
    text?: string | undefined;
    data?: Uint8Array | undefined;
    mimeType?: string | undefined;
    uri?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    size?: number | undefined;
    resource?: ResourceContent | undefined;
}
export type ContentBlockList = ContentBlock[];
export type TaskStatus = "submitted" | "working" | "completed" | "canceled" | "failed" | (string & {});
export interface ToolResultStructuredContent {
    taskId?: string | undefined;
    taskStatus?: TaskStatus | undefined;
    stdout?: string | undefined;
    stderr?: string | undefined;
    exitCode?: number | undefined;
    executionTime?: number | undefined;
}
export interface CodeInterpreterResult {
    content: ContentBlock[];
    structuredContent?: ToolResultStructuredContent | undefined;
    isError?: boolean | undefined;
}
export type CodeInterpreterStreamOutput = {
    result: CodeInterpreterResult;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException: InternalServerException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    validationException?: undefined;
} | {
    result?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    internalServerException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    validationException: ValidationException;
};
export interface InvokeCodeInterpreterResponse {
    sessionId?: string | undefined;
    stream: stream.Stream<CodeInterpreterStreamOutput, Error, never>;
}
export type HarnessArn = string;
export type HarnessEndpointName = string;
export type HarnessConversationRole = "user" | "assistant" | (string & {});
export type SensitiveText = string | redacted.Redacted<string>;
export type HarnessToolName = string;
export type HarnessToolUseId = string;
export type SensitiveJson = unknown;
export type HarnessToolUseType = "tool_use" | "server_tool_use" | "mcp_tool_use" | (string & {});
export interface HarnessToolUseBlock {
    name: string;
    toolUseId: string;
    input: any;
    type?: HarnessToolUseType | undefined;
    serverName?: string | undefined;
}
export type HarnessToolResultContentBlock = {
    text: string | redacted.Redacted<string>;
    json?: undefined;
} | {
    text?: undefined;
    json: any;
};
export type HarnessToolResultContentBlocks = HarnessToolResultContentBlock[];
export type HarnessToolUseStatus = "success" | "error" | (string & {});
export interface HarnessToolResultBlock {
    toolUseId: string;
    content: HarnessToolResultContentBlock[];
    status?: HarnessToolUseStatus | undefined;
    type?: HarnessToolUseType | undefined;
}
export interface HarnessReasoningTextBlock {
    text: string;
    signature?: string | undefined;
}
export type HarnessReasoningContentBlock = {
    reasoningText: HarnessReasoningTextBlock;
    redactedContent?: undefined;
} | {
    reasoningText?: undefined;
    redactedContent: Uint8Array;
};
export type HarnessContentBlock = {
    text: string | redacted.Redacted<string>;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
} | {
    text?: undefined;
    toolUse: HarnessToolUseBlock;
    toolResult?: undefined;
    reasoningContent?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult: HarnessToolResultBlock;
    reasoningContent?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent: HarnessReasoningContentBlock;
};
export type HarnessContentBlocks = HarnessContentBlock[];
export interface HarnessMessage {
    role: HarnessConversationRole;
    content: HarnessContentBlock[];
}
export type HarnessMessages = HarnessMessage[];
export type ModelId = string;
export type MaxTokens = number;
export type Temperature = number;
export type TopP = number;
export type HarnessBedrockApiFormat = "converse_stream" | "responses" | "chat_completions" | (string & {});
export interface HarnessBedrockModelConfig {
    modelId: string;
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    apiFormat?: HarnessBedrockApiFormat | undefined;
    additionalParams?: any | undefined;
}
export type ApiKeyArn = string;
export type HarnessOpenAiApiBase = string | redacted.Redacted<string>;
export type HarnessOpenAiApiFormat = "chat_completions" | "responses" | (string & {});
export interface HarnessOpenAiModelConfig {
    modelId: string;
    apiKeyArn: string;
    apiBase?: string | redacted.Redacted<string> | undefined;
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    apiFormat?: HarnessOpenAiApiFormat | undefined;
    additionalParams?: any | undefined;
}
export type TopK = number;
export interface HarnessGeminiModelConfig {
    modelId: string;
    apiKeyArn: string;
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    topK?: number | undefined;
    additionalParams?: any | undefined;
}
export type HarnessLiteLlmApiBase = string | redacted.Redacted<string>;
export interface HarnessLiteLlmModelConfig {
    modelId: string;
    apiKeyArn?: string | undefined;
    apiBase?: string | redacted.Redacted<string> | undefined;
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    additionalParams?: any | undefined;
}
export type HarnessModelConfiguration = {
    bedrockModelConfig: HarnessBedrockModelConfig;
    openAiModelConfig?: undefined;
    geminiModelConfig?: undefined;
    liteLlmModelConfig?: undefined;
} | {
    bedrockModelConfig?: undefined;
    openAiModelConfig: HarnessOpenAiModelConfig;
    geminiModelConfig?: undefined;
    liteLlmModelConfig?: undefined;
} | {
    bedrockModelConfig?: undefined;
    openAiModelConfig?: undefined;
    geminiModelConfig: HarnessGeminiModelConfig;
    liteLlmModelConfig?: undefined;
} | {
    bedrockModelConfig?: undefined;
    openAiModelConfig?: undefined;
    geminiModelConfig?: undefined;
    liteLlmModelConfig: HarnessLiteLlmModelConfig;
};
export type HarnessSystemContentBlock = {
    text: string | redacted.Redacted<string>;
};
export type HarnessSystemPrompt = HarnessSystemContentBlock[];
export type HarnessToolType = "remote_mcp" | "agentcore_browser" | "agentcore_gateway" | "inline_function" | "agentcore_code_interpreter" | (string & {});
export type HarnessRemoteMcpUrl = string | redacted.Redacted<string>;
export type HttpHeaderKey = string;
export type HttpHeaderValue = string;
export type HttpHeadersMap = {
    [key: string]: string | undefined;
};
export interface IamCredentialProvider {
    service: string;
    region?: string | undefined;
}
export type HarnessRemoteMcpOutboundAuth = {
    awsIam: IamCredentialProvider;
    none?: undefined;
} | {
    awsIam?: undefined;
    none: Record<string, never>;
};
export interface HarnessRemoteMcpConfig {
    url: string | redacted.Redacted<string>;
    headers?: {
        [key: string]: string | undefined;
    } | undefined;
    outboundAuth?: HarnessRemoteMcpOutboundAuth | undefined;
}
export type HarnessBrowserArn = string;
export interface HarnessAgentCoreBrowserConfig {
    browserArn?: string | undefined;
}
export type OAuthCredentialProviderArn = string;
export type OAuthScope = string;
export type OAuthScopes = string[];
export type OAuthCustomParametersKey = string;
export type OAuthCustomParametersValue = string | redacted.Redacted<string>;
export type OAuthCustomParameters = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type OAuthGrantType = "CLIENT_CREDENTIALS" | "AUTHORIZATION_CODE" | "TOKEN_EXCHANGE" | (string & {});
export type OAuthDefaultReturnUrl = string;
export interface OAuthCredentialProvider {
    providerArn: string;
    scopes: string[];
    customParameters?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    grantType?: OAuthGrantType | undefined;
    defaultReturnUrl?: string | undefined;
}
export type HarnessGatewayOutboundAuth = {
    awsIam: Record<string, never>;
    none?: undefined;
    oauth?: undefined;
} | {
    awsIam?: undefined;
    none: Record<string, never>;
    oauth?: undefined;
} | {
    awsIam?: undefined;
    none?: undefined;
    oauth: OAuthCredentialProvider;
};
export interface HarnessAgentCoreGatewayConfig {
    gatewayArn: string;
    outboundAuth?: HarnessGatewayOutboundAuth | undefined;
}
export type HarnessInlineFunctionDescription = string | redacted.Redacted<string>;
export interface HarnessInlineFunctionConfig {
    description: string | redacted.Redacted<string>;
    inputSchema: any;
}
export type HarnessCodeInterpreterArn = string;
export interface HarnessAgentCoreCodeInterpreterConfig {
    codeInterpreterArn?: string | undefined;
}
export type HarnessToolConfiguration = {
    remoteMcp: HarnessRemoteMcpConfig;
    agentCoreBrowser?: undefined;
    agentCoreGateway?: undefined;
    inlineFunction?: undefined;
    agentCoreCodeInterpreter?: undefined;
} | {
    remoteMcp?: undefined;
    agentCoreBrowser: HarnessAgentCoreBrowserConfig;
    agentCoreGateway?: undefined;
    inlineFunction?: undefined;
    agentCoreCodeInterpreter?: undefined;
} | {
    remoteMcp?: undefined;
    agentCoreBrowser?: undefined;
    agentCoreGateway: HarnessAgentCoreGatewayConfig;
    inlineFunction?: undefined;
    agentCoreCodeInterpreter?: undefined;
} | {
    remoteMcp?: undefined;
    agentCoreBrowser?: undefined;
    agentCoreGateway?: undefined;
    inlineFunction: HarnessInlineFunctionConfig;
    agentCoreCodeInterpreter?: undefined;
} | {
    remoteMcp?: undefined;
    agentCoreBrowser?: undefined;
    agentCoreGateway?: undefined;
    inlineFunction?: undefined;
    agentCoreCodeInterpreter: HarnessAgentCoreCodeInterpreterConfig;
};
export interface HarnessTool {
    type: HarnessToolType;
    name?: string | undefined;
    config?: HarnessToolConfiguration | undefined;
}
export type HarnessTools = HarnessTool[];
export type HarnessSkillPath = string;
export type HarnessSkillS3Uri = string;
export interface HarnessSkillS3Source {
    uri: string;
}
export type HarnessSkillGitUrl = string;
export interface HarnessSkillGitAuth {
    credentialArn: string;
    username?: string | undefined;
}
export interface HarnessSkillGitSource {
    url: string;
    path?: string | undefined;
    auth?: HarnessSkillGitAuth | undefined;
}
export type HarnessAwsSkillPath = string;
export type HarnessAwsSkillPaths = string[];
export interface HarnessSkillAwsSkillsSource {
    paths?: string[] | undefined;
}
export type HarnessSkill = {
    path: string;
    s3?: undefined;
    git?: undefined;
    awsSkills?: undefined;
} | {
    path?: undefined;
    s3: HarnessSkillS3Source;
    git?: undefined;
    awsSkills?: undefined;
} | {
    path?: undefined;
    s3?: undefined;
    git: HarnessSkillGitSource;
    awsSkills?: undefined;
} | {
    path?: undefined;
    s3?: undefined;
    git?: undefined;
    awsSkills: HarnessSkillAwsSkillsSource;
};
export type HarnessSkills = HarnessSkill[];
export type HarnessAllowedTool = string;
export type HarnessAllowedTools = string[];
export interface InvokeHarnessRequest {
    harnessArn: string;
    qualifier?: string | undefined;
    runtimeSessionId: string;
    runtimeUserId?: string | undefined;
    traceParent?: string | undefined;
    traceState?: string | undefined;
    traceId?: string | undefined;
    baggage?: string | undefined;
    messages: HarnessMessage[];
    model?: HarnessModelConfiguration | undefined;
    systemPrompt?: HarnessSystemContentBlock[] | undefined;
    tools?: HarnessTool[] | undefined;
    skills?: HarnessSkill[] | undefined;
    allowedTools?: string[] | undefined;
    maxIterations?: number | undefined;
    maxTokens?: number | undefined;
    timeoutSeconds?: number | undefined;
    actorId?: string | undefined;
}
export interface HarnessMessageStartEvent {
    role: HarnessConversationRole;
}
export interface HarnessToolUseBlockStart {
    toolUseId: string;
    name: string;
    type?: HarnessToolUseType | undefined;
    serverName?: string | undefined;
}
export interface HarnessToolResultBlockStart {
    toolUseId: string;
    status?: HarnessToolUseStatus | undefined;
}
export type HarnessContentBlockStart = {
    toolUse: HarnessToolUseBlockStart;
    toolResult?: undefined;
} | {
    toolUse?: undefined;
    toolResult: HarnessToolResultBlockStart;
};
export interface HarnessContentBlockStartEvent {
    contentBlockIndex: number;
    start: HarnessContentBlockStart;
}
export interface HarnessToolUseBlockDelta {
    input: string | redacted.Redacted<string>;
}
export type HarnessToolResultBlockDelta = {
    text: string | redacted.Redacted<string>;
    json?: undefined;
} | {
    text?: undefined;
    json: any;
};
export type HarnessToolResultBlocksDelta = HarnessToolResultBlockDelta[];
export type HarnessReasoningContentBlockDelta = {
    text: string;
    redactedContent?: undefined;
    signature?: undefined;
} | {
    text?: undefined;
    redactedContent: Uint8Array | redacted.Redacted<Uint8Array>;
    signature?: undefined;
} | {
    text?: undefined;
    redactedContent?: undefined;
    signature: string;
};
export interface HarnessToolResultMetadataBlockDelta {
    metadata: string | redacted.Redacted<string>;
}
export type HarnessContentBlockDelta = {
    text: string | redacted.Redacted<string>;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
    toolResultMetadata?: undefined;
} | {
    text?: undefined;
    toolUse: HarnessToolUseBlockDelta;
    toolResult?: undefined;
    reasoningContent?: undefined;
    toolResultMetadata?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult: HarnessToolResultBlockDelta[];
    reasoningContent?: undefined;
    toolResultMetadata?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent: HarnessReasoningContentBlockDelta;
    toolResultMetadata?: undefined;
} | {
    text?: undefined;
    toolUse?: undefined;
    toolResult?: undefined;
    reasoningContent?: undefined;
    toolResultMetadata: HarnessToolResultMetadataBlockDelta;
};
export interface HarnessContentBlockDeltaEvent {
    contentBlockIndex: number;
    delta: HarnessContentBlockDelta;
}
export interface HarnessContentBlockStopEvent {
    contentBlockIndex: number;
}
export type HarnessStopReason = "end_turn" | "tool_use" | "tool_result" | "max_tokens" | "stop_sequence" | "content_filtered" | "malformed_model_output" | "malformed_tool_use" | "interrupted" | "partial_turn" | "model_context_window_exceeded" | "max_iterations_exceeded" | "max_output_tokens_exceeded" | "timeout_exceeded" | "hook_stopped" | (string & {});
export interface HarnessMessageStopEvent {
    stopReason: HarnessStopReason;
}
export interface HarnessTokenUsage {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cacheReadInputTokens?: number | undefined;
    cacheWriteInputTokens?: number | undefined;
}
export interface HarnessStreamMetrics {
    latencyMs: number;
}
export interface HarnessMetadataEvent {
    usage: HarnessTokenUsage;
    metrics: HarnessStreamMetrics;
}
export type HarnessHookEventId = string;
export type HarnessHookName = string;
export type HarnessHookEventType = "before_tool_call" | "after_tool_call" | "before_invocation" | "after_invocation" | (string & {});
export type HarnessHookDecision = "allow" | "deny" | (string & {});
export interface HarnessHookEvent {
    hookEventId: string;
    name: string;
    type: HarnessHookEventType;
    decision?: HarnessHookDecision | undefined;
    reason?: string | undefined;
}
export type InvokeHarnessStreamOutput = {
    messageStart: HarnessMessageStartEvent;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart: HarnessContentBlockStartEvent;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta: HarnessContentBlockDeltaEvent;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop: HarnessContentBlockStopEvent;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop: HarnessMessageStopEvent;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata: HarnessMetadataEvent;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    runtimeClientError?: undefined;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError: RuntimeClientError;
    hookEvent?: undefined;
} | {
    messageStart?: undefined;
    contentBlockStart?: undefined;
    contentBlockDelta?: undefined;
    contentBlockStop?: undefined;
    messageStop?: undefined;
    metadata?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    runtimeClientError?: undefined;
    hookEvent: HarnessHookEvent;
};
export interface InvokeHarnessResponse {
    stream: stream.Stream<InvokeHarnessStreamOutput, Error, never>;
}
export type WebSearchId = string;
export type DomainName = string;
export type DomainList = string[];
export interface DomainFilter {
    include?: string[] | undefined;
    exclude?: string[] | undefined;
}
export interface PublishedDateFilter {
    publishedAfter?: Date | undefined;
    publishedBefore?: Date | undefined;
}
export interface WebSearchFilters {
    domainFilter?: DomainFilter | undefined;
    publishedDateFilter?: PublishedDateFilter | undefined;
}
export interface InvokeWebSearchInput {
    webSearchId: string;
    searchQuery: string;
    maxResults?: number | undefined;
    filters?: WebSearchFilters | undefined;
}
export interface WebSearchResult {
    title?: string | undefined;
    url?: string | undefined;
    text: string;
    publishedAt?: Date | undefined;
}
export type WebSearchResultList = WebSearchResult[];
export interface InvokeWebSearchOutput {
    results: WebSearchResult[];
}
export interface ListABTestsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ABTestSummary {
    abTestId: string;
    abTestArn: string;
    name: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    description?: string | undefined;
    gatewayArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type ABTestSummaryList = ABTestSummary[];
export interface ListABTestsResponse {
    abTests: ABTestSummary[];
    nextToken?: string | undefined;
}
export type MaxResults = number;
export type PaginationToken = string;
export interface ListActorsInput {
    memoryId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ActorSummary {
    actorId: string;
}
export type ActorSummaryList = ActorSummary[];
export interface ListActorsOutput {
    actorSummaries: ActorSummary[];
    nextToken?: string | undefined;
}
export interface ListBatchEvaluationsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface BatchEvaluationSummary {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    status: BatchEvaluationStatus;
    createdAt: Date;
    description?: string | undefined;
    evaluators?: Evaluator[] | undefined;
    insights?: Insight[] | undefined;
    evaluationResults?: EvaluationJobResults | undefined;
    errorDetails?: string[] | undefined;
    kmsKeyArn?: string | undefined;
    updatedAt?: Date | undefined;
}
export type BatchEvaluationSummaryList = BatchEvaluationSummary[];
export interface ListBatchEvaluationsResponse {
    batchEvaluations: BatchEvaluationSummary[];
    nextToken?: string | undefined;
}
export type NextToken = string;
export interface ListBrowserSessionsRequest {
    browserIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    status?: BrowserSessionStatus | undefined;
}
export interface BrowserSessionSummary {
    browserIdentifier: string;
    sessionId: string;
    name?: string | undefined;
    status: BrowserSessionStatus;
    createdAt: Date;
    lastUpdatedAt?: Date | undefined;
}
export type BrowserSessionSummaries = BrowserSessionSummary[];
export interface ListBrowserSessionsResponse {
    items: BrowserSessionSummary[];
    nextToken?: string | undefined;
}
export interface ListCodeInterpreterSessionsRequest {
    codeInterpreterIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    status?: CodeInterpreterSessionStatus | undefined;
}
export interface CodeInterpreterSessionSummary {
    codeInterpreterIdentifier: string;
    sessionId: string;
    name?: string | undefined;
    status: CodeInterpreterSessionStatus;
    createdAt: Date;
    lastUpdatedAt?: Date | undefined;
}
export type CodeInterpreterSessionSummaries = CodeInterpreterSessionSummary[];
export interface ListCodeInterpreterSessionsResponse {
    items: CodeInterpreterSessionSummary[];
    nextToken?: string | undefined;
}
export interface BranchFilter {
    name: string;
    includeParentBranches?: boolean | undefined;
}
export type LeftExpression = {
    metadataKey: string;
};
export type OperatorType = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | (string & {});
export type RightExpression = {
    metadataValue: MetadataValue;
};
export interface EventMetadataFilterExpression {
    left: LeftExpression;
    operator: OperatorType;
    right?: RightExpression | undefined;
}
export type EventMetadataFilterList = EventMetadataFilterExpression[];
export interface FilterInput {
    branch?: BranchFilter | undefined;
    eventMetadata?: EventMetadataFilterExpression[] | undefined;
}
export interface ListEventsInput {
    memoryId: string;
    sessionId: string;
    actorId: string;
    includePayloads?: boolean | undefined;
    filter?: FilterInput | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type EventList = Event[];
export interface ListEventsOutput {
    events: Event[];
    nextToken?: string | undefined;
}
export type ExtractionJobStatus = "FAILED" | (string & {});
export interface ExtractionJobFilterInput {
    strategyId?: string | undefined;
    sessionId?: string | undefined;
    actorId?: string | undefined;
    status?: ExtractionJobStatus | undefined;
}
export interface ListMemoryExtractionJobsInput {
    memoryId: string;
    maxResults?: number | undefined;
    filter?: ExtractionJobFilterInput | undefined;
    nextToken?: string | undefined;
}
export interface MessageMetadata {
    eventId: string;
    messageIndex: number;
}
export type MessagesList = MessageMetadata[];
export type ExtractionJobMessages = {
    messagesList: MessageMetadata[];
};
export interface ExtractionJobMetadata {
    jobID: string;
    messages: ExtractionJobMessages;
    status?: ExtractionJobStatus | undefined;
    failureReason?: string | undefined;
    strategyId?: string | undefined;
    sessionId?: string | undefined;
    actorId?: string | undefined;
}
export type ExtractionJobMetadataList = ExtractionJobMetadata[];
export interface ListMemoryExtractionJobsOutput {
    jobs: ExtractionJobMetadata[];
    nextToken?: string | undefined;
}
export type MemoryRecordLeftExpression = {
    metadataKey: string;
};
export type MemoryRecordOperatorType = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | "BEFORE" | "AFTER" | "CONTAINS" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | (string & {});
export type MemoryRecordRightExpression = {
    metadataValue: MemoryRecordMetadataValue;
};
export interface MemoryMetadataFilterExpression {
    left: MemoryRecordLeftExpression;
    operator: MemoryRecordOperatorType;
    right?: MemoryRecordRightExpression | undefined;
}
export type MemoryMetadataFilterList = MemoryMetadataFilterExpression[];
export interface ListMemoryRecordsInput {
    memoryId: string;
    namespace?: string | undefined;
    namespacePath?: string | undefined;
    memoryStrategyId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    metadataFilters?: MemoryMetadataFilterExpression[] | undefined;
}
export interface MemoryRecordSummary {
    memoryRecordId: string;
    content: MemoryContent;
    memoryStrategyId?: string | undefined;
    namespaces: string[];
    createdAt: Date;
    score?: number | undefined;
    timestamp?: Date | undefined;
    metadata?: {
        [key: string]: MemoryRecordMetadataValue | undefined;
    } | undefined;
}
export type MemoryRecordSummaryList = MemoryRecordSummary[];
export interface ListMemoryRecordsOutput {
    memoryRecordSummaries: MemoryRecordSummary[];
    nextToken?: string | undefined;
}
export interface ListPaymentInstrumentsRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentConnectorId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PaymentInstrumentSummary {
    paymentInstrumentId: string;
    paymentManagerArn: string;
    paymentConnectorId: string;
    userId: string;
    paymentInstrumentType: PaymentInstrumentType;
    status: PaymentInstrumentStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type PaymentInstrumentSummaryList = PaymentInstrumentSummary[];
export interface ListPaymentInstrumentsResponse {
    paymentInstruments: PaymentInstrumentSummary[];
    nextToken?: string | undefined;
}
export interface ListPaymentSessionsRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PaymentSessionSummary {
    paymentSessionId: string;
    paymentManagerArn: string;
    userId: string;
    expiryTimeInMinutes: number;
    createdAt: Date;
    updatedAt: Date;
}
export type PaymentSessionSummaryList = PaymentSessionSummary[];
export interface ListPaymentSessionsResponse {
    paymentSessions: PaymentSessionSummary[];
    nextToken?: string | undefined;
}
export interface ListRecommendationsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    statusFilter?: RecommendationStatus | undefined;
}
export interface RecommendationSummary {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string | undefined;
    type: RecommendationType;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type RecommendationSummaryList = RecommendationSummary[];
export interface ListRecommendationsResponse {
    recommendationSummaries: RecommendationSummary[];
    nextToken?: string | undefined;
}
export type EventFilterCondition = "HAS_EVENTS" | (string & {});
export interface SessionFilter {
    eventFilter?: EventFilterCondition | undefined;
}
export interface ListSessionsInput {
    memoryId: string;
    actorId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filter?: SessionFilter | undefined;
}
export interface SessionSummary {
    sessionId: string;
    actorId: string;
    createdAt: Date;
}
export type SessionSummaryList = SessionSummary[];
export interface ListSessionsOutput {
    sessionSummaries: SessionSummary[];
    nextToken?: string | undefined;
}
export type PaymentType = "CRYPTO_X402" | "MPP" | (string & {});
export type PaymentDocument = unknown;
export type Permit2AllowanceLimit = string;
export interface CryptoX402PaymentInput {
    version: string;
    payload: any;
    permit2AllowanceLimit?: string | undefined;
}
export type Version = string;
export type WwwAuthenticateHeader = string;
export type WwwAuthenticateHeaderList = string[];
export interface MppPaymentInput {
    version: string;
    wwwAuthenticateHeaders: string[];
    buyerPaysGasFees?: boolean | undefined;
}
export type PaymentInput = {
    cryptoX402: CryptoX402PaymentInput;
    mpp?: undefined;
} | {
    cryptoX402?: undefined;
    mpp: MppPaymentInput;
};
export interface ProcessPaymentRequest {
    userId?: string | undefined;
    agentName?: string | undefined;
    paymentManagerArn: string;
    paymentSessionId: string;
    paymentInstrumentId: string;
    paymentType: PaymentType;
    paymentInput: PaymentInput;
    clientToken?: string | undefined;
}
export type ProcessPaymentId = string;
export type PaymentStatus = "PROOF_GENERATED" | (string & {});
export interface CryptoX402PaymentOutput {
    version: string;
    payload: any;
}
export type MppPaymentCredential = string | redacted.Redacted<string>;
export interface MppPaymentOutput {
    version: string;
    selectedPaymentId: string;
    paymentCredential: string | redacted.Redacted<string>;
}
export type PaymentOutput = {
    cryptoX402: CryptoX402PaymentOutput;
    mpp?: undefined;
} | {
    cryptoX402?: undefined;
    mpp: MppPaymentOutput;
};
export interface ProcessPaymentResponse {
    processPaymentId: string;
    paymentManagerArn: string;
    paymentSessionId: string;
    paymentInstrumentId: string;
    paymentType: PaymentType;
    status: PaymentStatus;
    paymentOutput: PaymentOutput;
    createdAt: Date;
    updatedAt: Date;
}
export interface SearchCriteria {
    searchQuery: string | redacted.Redacted<string>;
    memoryStrategyId?: string | undefined;
    topK?: number | undefined;
    metadataFilters?: MemoryMetadataFilterExpression[] | undefined;
}
export interface RetrieveMemoryRecordsInput {
    memoryId: string;
    namespace?: string | undefined;
    namespacePath?: string | undefined;
    searchCriteria: SearchCriteria;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RetrieveMemoryRecordsOutput {
    memoryRecordSummaries: MemoryRecordSummary[];
    nextToken?: string | undefined;
}
export interface SaveBrowserSessionProfileRequest {
    traceId?: string | undefined;
    traceParent?: string | undefined;
    profileIdentifier: string;
    browserIdentifier: string;
    sessionId: string;
    clientToken?: string | undefined;
}
export interface SaveBrowserSessionProfileResponse {
    profileIdentifier: string;
    browserIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export type RegistryIdentifier = string;
export type RegistryIdList = string[];
export type MetadataFilterExpression = unknown;
export interface SearchRegistryRecordsRequest {
    searchQuery: string;
    registryIds: string[];
    maxResults?: number | undefined;
    filters?: any | undefined;
}
export type RegistryArn = string;
export type RegistryRecordArn = string;
export type RegistryRecordId = string;
export type RegistryRecordName = string;
export type Description = string | redacted.Redacted<string>;
export type DescriptorType = "MCP" | "A2A" | "CUSTOM" | "AGENT_SKILLS" | (string & {});
export type SchemaVersion = string;
export type InlineContent = string;
export interface ServerDefinition {
    schemaVersion?: string | undefined;
    inlineContent?: string | undefined;
}
export interface ToolsDefinition {
    protocolVersion?: string | undefined;
    inlineContent?: string | undefined;
}
export interface McpDescriptor {
    server: ServerDefinition;
    tools: ToolsDefinition;
}
export interface AgentCardDefinition {
    schemaVersion?: string | undefined;
    inlineContent?: string | undefined;
}
export interface A2aDescriptor {
    agentCard: AgentCardDefinition;
}
export interface CustomDescriptor {
    inlineContent?: string | undefined;
}
export interface SkillMdDefinition {
    inlineContent?: string | undefined;
}
export interface SkillDefinition {
    schemaVersion?: string | undefined;
    inlineContent?: string | undefined;
}
export interface AgentSkillsDescriptor {
    skillMd: SkillMdDefinition;
    skillDefinition?: SkillDefinition | undefined;
}
export interface Descriptors {
    mcp?: McpDescriptor | undefined;
    a2a?: A2aDescriptor | undefined;
    custom?: CustomDescriptor | undefined;
    agentSkills?: AgentSkillsDescriptor | undefined;
}
export type RegistryRecordVersion = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | (string & {});
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    description?: string | redacted.Redacted<string> | undefined;
    descriptorType: DescriptorType;
    descriptors: Descriptors;
    version: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export interface SearchRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
}
export type GroundTruthTurnInput = {
    prompt: string;
};
export interface GroundTruthTurn {
    input?: GroundTruthTurnInput | undefined;
    expectedResponse?: EvaluationContent | undefined;
}
export type GroundTruthTurnList = GroundTruthTurn[];
export interface InlineGroundTruth {
    assertions?: EvaluationContent[] | undefined;
    expectedTrajectory?: EvaluationExpectedTrajectory | undefined;
    turns?: GroundTruthTurn[] | undefined;
}
export type GroundTruthSource = {
    inline: InlineGroundTruth;
};
export type StringMap = {
    [key: string]: string | undefined;
};
export interface SessionMetadataShape {
    sessionId: string;
    testScenarioId?: string | undefined;
    groundTruth?: GroundTruthSource | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SessionMetadataList = SessionMetadataShape[];
export type EvaluationMetadata = {
    sessionMetadata: SessionMetadataShape[];
};
export interface StartBatchEvaluationRequest {
    batchEvaluationName: string;
    evaluators?: Evaluator[] | undefined;
    insights?: Insight[] | undefined;
    dataSourceConfig: DataSourceConfig;
    clientToken?: string | undefined;
    evaluationMetadata?: EvaluationMetadata | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
    description?: string | undefined;
    outputConfig?: OutputConfig | undefined;
}
export interface StartBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    batchEvaluationName: string;
    evaluators?: Evaluator[] | undefined;
    insights?: Insight[] | undefined;
    status: BatchEvaluationStatus;
    createdAt: Date;
    outputConfig?: OutputConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
    description?: string | undefined;
}
export interface StartBrowserSessionRequest {
    traceId?: string | undefined;
    traceParent?: string | undefined;
    browserIdentifier: string;
    name?: string | undefined;
    sessionTimeoutSeconds?: number | undefined;
    viewPort?: ViewPort | undefined;
    extensions?: BrowserExtension[] | undefined;
    profileConfiguration?: BrowserProfileConfiguration | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    enterprisePolicies?: BrowserEnterprisePolicy[] | undefined;
    certificates?: Certificate[] | undefined;
    filesystemConfigurations?: ToolsFileSystemConfiguration[] | undefined;
    clientToken?: string | undefined;
}
export interface StartBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    createdAt: Date;
    streams?: BrowserSessionStream | undefined;
}
export interface StartCodeInterpreterSessionRequest {
    traceId?: string | undefined;
    traceParent?: string | undefined;
    codeInterpreterIdentifier: string;
    name?: string | undefined;
    sessionTimeoutSeconds?: number | undefined;
    certificates?: Certificate[] | undefined;
    filesystemConfigurations?: ToolsFileSystemConfiguration[] | undefined;
    clientToken?: string | undefined;
}
export interface StartCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    createdAt: Date;
}
export interface ExtractionJob {
    jobId: string;
}
export interface StartMemoryExtractionJobInput {
    memoryId: string;
    extractionJob: ExtractionJob;
    clientToken?: string | undefined;
}
export interface StartMemoryExtractionJobOutput {
    jobId: string;
}
export interface StartRecommendationRequest {
    name: string;
    description?: string | undefined;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    kmsKeyArn?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartRecommendationResponse {
    recommendationId: string;
    recommendationArn: string;
    name: string;
    description?: string | undefined;
    type: RecommendationType;
    recommendationConfig: RecommendationConfig;
    status: RecommendationStatus;
    createdAt: Date;
    updatedAt: Date;
}
export interface StopBatchEvaluationRequest {
    batchEvaluationId: string;
}
export interface StopBatchEvaluationResponse {
    batchEvaluationId: string;
    batchEvaluationArn: string;
    status: BatchEvaluationStatus;
    description?: string | undefined;
}
export interface StopBrowserSessionRequest {
    traceId?: string | undefined;
    traceParent?: string | undefined;
    browserIdentifier: string;
    sessionId: string;
    clientToken?: string | undefined;
}
export interface StopBrowserSessionResponse {
    browserIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export interface StopCodeInterpreterSessionRequest {
    traceId?: string | undefined;
    traceParent?: string | undefined;
    codeInterpreterIdentifier: string;
    sessionId: string;
    clientToken?: string | undefined;
}
export interface StopCodeInterpreterSessionResponse {
    codeInterpreterIdentifier: string;
    sessionId: string;
    lastUpdatedAt: Date;
}
export interface StopRuntimeSessionRequest {
    runtimeSessionId: string;
    agentRuntimeArn: string;
    qualifier?: string | undefined;
    clientToken?: string | undefined;
}
export interface StopRuntimeSessionResponse {
    runtimeSessionId?: string | undefined;
    statusCode?: number | undefined;
}
export interface UpdateABTestRequest {
    abTestId: string;
    clientToken?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    variants?: Variant[] | undefined;
    gatewayFilter?: GatewayFilter | undefined;
    evaluationConfig?: ABTestEvaluationConfig | undefined;
    roleArn?: string | undefined;
    executionStatus?: ABTestExecutionStatus | undefined;
}
export interface UpdateABTestResponse {
    abTestId: string;
    abTestArn: string;
    status: ABTestStatus;
    executionStatus: ABTestExecutionStatus;
    updatedAt: Date;
}
export interface AutomationStreamUpdate {
    streamStatus?: AutomationStreamStatus | undefined;
}
export type StreamUpdate = {
    automationStreamUpdate: AutomationStreamUpdate;
};
export interface UpdateBrowserStreamRequest {
    browserIdentifier: string;
    sessionId: string;
    streamUpdate: StreamUpdate;
    clientToken?: string | undefined;
}
export interface UpdateBrowserStreamResponse {
    browserIdentifier: string;
    sessionId: string;
    streams: BrowserSessionStream;
    updatedAt: Date;
}
export type BatchCreateMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Creates multiple memory records in a single batch operation for the specified memory with custom content.
 */
export declare const batchCreateMemoryRecords: API.OperationMethod<BatchCreateMemoryRecordsInput & RegionInput, BatchCreateMemoryRecordsOutput, BatchCreateMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes multiple memory records in a single batch operation from the specified memory.
 */
export declare const batchDeleteMemoryRecords: API.OperationMethod<BatchDeleteMemoryRecordsInput & RegionInput, BatchDeleteMemoryRecordsOutput, BatchDeleteMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateMemoryRecordsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Updates multiple memory records with custom content in a single batch operation within the specified memory.
 */
export declare const batchUpdateMemoryRecords: API.OperationMethod<BatchUpdateMemoryRecordsInput & RegionInput, BatchUpdateMemoryRecordsOutput, BatchUpdateMemoryRecordsError, Credentials | HttpClient.HttpClient>;
export type CompleteResourceTokenAuthError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Confirms the user authentication session for obtaining OAuth2.0 tokens for a resource.
 */
export declare const completeResourceTokenAuth: API.OperationMethod<CompleteResourceTokenAuthRequest & RegionInput, CompleteResourceTokenAuthResponse, CompleteResourceTokenAuthError, Credentials | HttpClient.HttpClient>;
export type CreateABTestError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Creates an A/B test for comparing agent configurations. A/B tests split traffic between a control variant and a treatment variant through a gateway, then evaluate performance using online evaluation configurations to determine which variant performs better.
 */
export declare const createABTest: API.OperationMethod<CreateABTestRequest & RegionInput, CreateABTestResponse, CreateABTestError, Credentials | HttpClient.HttpClient>;
export type CreateEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | RetryableConflictException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Creates an event in an AgentCore Memory resource. Events represent interactions or activities that occur within a session and are associated with specific actors.
 *
 * To use this operation, you must have the `bedrock-agentcore:CreateEvent` permission.
 *
 * This operation is subject to request rate limiting.
 */
export declare const createEvent: API.OperationMethod<CreateEventInput & RegionInput, CreateEventOutput, CreateEventError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentInstrumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new payment instrument for a connector.
 */
export declare const createPaymentInstrument: API.OperationMethod<CreatePaymentInstrumentRequest & RegionInput, CreatePaymentInstrumentResponse, CreatePaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type CreatePaymentSessionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new payment session.
 */
export declare const createPaymentSession: API.OperationMethod<CreatePaymentSessionRequest & RegionInput, CreatePaymentSessionResponse, CreatePaymentSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteABTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes an A/B test and its associated gateway rules.
 */
export declare const deleteABTest: API.OperationMethod<DeleteABTestRequest & RegionInput, DeleteABTestResponse, DeleteABTestError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Deletes a batch evaluation and its associated results.
 */
export declare const deleteBatchEvaluation: API.OperationMethod<DeleteBatchEvaluationRequest & RegionInput, DeleteBatchEvaluationResponse, DeleteBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a session associated with a capacity provider in Amazon Bedrock AgentCore and makes the session unavailable for further use. To delete a capacity provider session, specify both the capacity provider identifier and the session ID. After you delete a session, you cannot restart it.
 */
export declare const deleteCapacityProviderSession: API.OperationMethod<DeleteCapacityProviderSessionRequest & RegionInput, DeleteCapacityProviderSessionResponse, DeleteCapacityProviderSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes an event from an AgentCore Memory resource. When you delete an event, it is permanently removed.
 *
 * To use this operation, you must have the `bedrock-agentcore:DeleteEvent` permission.
 */
export declare const deleteEvent: API.OperationMethod<DeleteEventInput & RegionInput, DeleteEventOutput, DeleteEventError, Credentials | HttpClient.HttpClient>;
export type DeleteMemoryRecordError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Deletes a memory record from an AgentCore Memory resource. When you delete a memory record, it is permanently removed.
 *
 * To use this operation, you must have the `bedrock-agentcore:DeleteMemoryRecord` permission.
 */
export declare const deleteMemoryRecord: API.OperationMethod<DeleteMemoryRecordInput & RegionInput, DeleteMemoryRecordOutput, DeleteMemoryRecordError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentInstrumentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a payment instrument. This is a soft delete operation that preserves the record for audit and compliance purposes.
 */
export declare const deletePaymentInstrument: API.OperationMethod<DeletePaymentInstrumentRequest & RegionInput, DeletePaymentInstrumentResponse, DeletePaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type DeletePaymentSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a payment session. This permanently removes the payment session record.
 */
export declare const deletePaymentSession: API.OperationMethod<DeletePaymentSessionRequest & RegionInput, DeletePaymentSessionResponse, DeletePaymentSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a recommendation and its associated results.
 */
export declare const deleteRecommendation: API.OperationMethod<DeleteRecommendationRequest & RegionInput, DeleteRecommendationResponse, DeleteRecommendationError, Credentials | HttpClient.HttpClient>;
export type EvaluateError = AccessDeniedException | ConflictException | DuplicateIdException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Performs on-demand evaluation of agent traces using a specified evaluator. This synchronous API accepts traces in OpenTelemetry format and returns immediate scoring results with detailed explanations.
 */
export declare const evaluate: API.OperationMethod<EvaluateRequest & RegionInput, EvaluateResponse, EvaluateError, Credentials | HttpClient.HttpClient>;
export type GetABTestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an A/B test, including its configuration, status, and statistical results.
 */
export declare const getABTest: API.OperationMethod<GetABTestRequest & RegionInput, GetABTestResponse, GetABTestError, Credentials | HttpClient.HttpClient>;
export type GetAgentCardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the A2A agent card associated with an AgentCore Runtime agent.
 */
export declare const getAgentCard: API.OperationMethod<GetAgentCardRequest & RegionInput, GetAgentCardResponse, GetAgentCardError, Credentials | HttpClient.HttpClient>;
export type GetBatchEvaluationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a batch evaluation, including its status, configuration, results, and any error details.
 */
export declare const getBatchEvaluation: API.OperationMethod<GetBatchEvaluationRequest & RegionInput, GetBatchEvaluationResponse, GetBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type GetBrowserSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific browser session in Amazon Bedrock AgentCore. This operation returns the session's configuration, current status, associated streams, and metadata.
 *
 * To get a browser session, you must specify both the browser identifier and the session ID. The response includes information about the session's viewport configuration, timeout settings, and stream endpoints.
 *
 * The following operations are related to `GetBrowserSession`:
 *
 * - StartBrowserSession
 *
 * - ListBrowserSessions
 *
 * - StopBrowserSession
 */
export declare const getBrowserSession: API.OperationMethod<GetBrowserSessionRequest & RegionInput, GetBrowserSessionResponse, GetBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type GetCodeInterpreterSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific code interpreter session in Amazon Bedrock AgentCore. This operation returns the session's configuration, current status, and metadata.
 *
 * To get a code interpreter session, you must specify both the code interpreter identifier and the session ID. The response includes information about the session's timeout settings and current status.
 *
 * The following operations are related to `GetCodeInterpreterSession`:
 *
 * - StartCodeInterpreterSession
 *
 * - ListCodeInterpreterSessions
 *
 * - StopCodeInterpreterSession
 */
export declare const getCodeInterpreterSession: API.OperationMethod<GetCodeInterpreterSessionRequest & RegionInput, GetCodeInterpreterSessionResponse, GetCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type GetEventError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific event in an AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:GetEvent` permission.
 */
export declare const getEvent: API.OperationMethod<GetEventInput & RegionInput, GetEventOutput, GetEventError, Credentials | HttpClient.HttpClient>;
export type GetMemoryRecordError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Retrieves a specific memory record from an AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:GetMemoryRecord` permission.
 */
export declare const getMemoryRecord: API.OperationMethod<GetMemoryRecordInput & RegionInput, GetMemoryRecordOutput, GetMemoryRecordError, Credentials | HttpClient.HttpClient>;
export type GetPaymentInstrumentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a payment instrument by ID.
 */
export declare const getPaymentInstrument: API.OperationMethod<GetPaymentInstrumentRequest & RegionInput, GetPaymentInstrumentResponse, GetPaymentInstrumentError, Credentials | HttpClient.HttpClient>;
export type GetPaymentInstrumentBalanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the balance of a payment instrument.
 */
export declare const getPaymentInstrumentBalance: API.OperationMethod<GetPaymentInstrumentBalanceRequest & RegionInput, GetPaymentInstrumentBalanceResponse, GetPaymentInstrumentBalanceError, Credentials | HttpClient.HttpClient>;
export type GetPaymentSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a payment session.
 */
export declare const getPaymentSession: API.OperationMethod<GetPaymentSessionRequest & RegionInput, GetPaymentSessionResponse, GetPaymentSessionError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a recommendation, including its configuration, status, and results.
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest & RegionInput, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type GetResourceApiKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Retrieves the API key associated with an API key credential provider.
 */
export declare const getResourceApiKey: API.OperationMethod<GetResourceApiKeyRequest & RegionInput, GetResourceApiKeyResponse, GetResourceApiKeyError, Credentials | HttpClient.HttpClient>;
export type GetResourceOauth2TokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Returns the OAuth 2.0 token of the provided resource.
 */
export declare const getResourceOauth2Token: API.OperationMethod<GetResourceOauth2TokenRequest & RegionInput, GetResourceOauth2TokenResponse, GetResourceOauth2TokenError, Credentials | HttpClient.HttpClient>;
export type GetResourcePaymentTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Generates authentication tokens for payment providers that use vendor-specific authentication mechanisms.
 */
export declare const getResourcePaymentToken: API.OperationMethod<GetResourcePaymentTokenRequest & RegionInput, GetResourcePaymentTokenResponse, GetResourcePaymentTokenError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads not acting on behalf of a user.
 */
export declare const getWorkloadAccessToken: API.OperationMethod<GetWorkloadAccessTokenRequest & RegionInput, GetWorkloadAccessTokenResponse, GetWorkloadAccessTokenError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenForJWTError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads acting on behalf of a user, using a JWT token.
 */
export declare const getWorkloadAccessTokenForJWT: API.OperationMethod<GetWorkloadAccessTokenForJWTRequest & RegionInput, GetWorkloadAccessTokenForJWTResponse, GetWorkloadAccessTokenForJWTError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadAccessTokenForUserIdError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Obtains a workload access token for agentic workloads acting on behalf of a user, using the user's ID.
 */
export declare const getWorkloadAccessTokenForUserId: API.OperationMethod<GetWorkloadAccessTokenForUserIdRequest & RegionInput, GetWorkloadAccessTokenForUserIdResponse, GetWorkloadAccessTokenForUserIdError, Credentials | HttpClient.HttpClient>;
export type IngestDataError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Submits content directly for ingestion to generate long-term memory records in a AgentCore Memory resource.
 *
 * To use this operation, you must have the `bedrock-agentcore:IngestData` permission.
 */
export declare const ingestData: API.OperationMethod<IngestDataInput & RegionInput, IngestDataOutput, IngestDataError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentRuntimeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a request to an agent or tool hosted in an Amazon Bedrock AgentCore Runtime and receives responses in real-time.
 *
 * To invoke an agent, you can specify either the AgentCore Runtime ARN or the agent ID with an account ID, and provide a payload containing your request. When you use the agent ID instead of the full ARN, you don't need to URL-encode the identifier. You can optionally specify a qualifier to target a specific endpoint of the agent.
 *
 * This operation supports streaming responses, allowing you to receive partial responses as they become available. We recommend using pagination to ensure that the operation returns quickly and successfully when processing large responses.
 *
 * For example code, see Invoke an AgentCore Runtime agent.
 *
 * If you're integrating your agent with OAuth, you can't use the Amazon Web Services SDK to call `InvokeAgentRuntime`. Instead, make a HTTPS request to `InvokeAgentRuntime`. For an example, see Authenticate and authorize with Inbound Auth and Outbound Auth.
 *
 * To use this operation, you must have the `bedrock-agentcore:InvokeAgentRuntime` permission. If you are making a call to `InvokeAgentRuntime` on behalf of a user ID with the `X-Amzn-Bedrock-AgentCore-Runtime-User-Id` header, You require permissions to both actions (`bedrock-agentcore:InvokeAgentRuntime` and `bedrock-agentcore:InvokeAgentRuntimeForUser`).
 */
export declare const invokeAgentRuntime: API.OperationMethod<InvokeAgentRuntimeRequest & RegionInput, InvokeAgentRuntimeResponse, InvokeAgentRuntimeError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentRuntimeCommandError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes a command in a runtime session container and streams the output back to the caller. This operation allows you to run shell commands within the agent runtime environment and receive real-time streaming responses including standard output and standard error.
 *
 * To invoke a command, you must specify the agent runtime ARN and a runtime session ID. The command execution supports streaming responses, allowing you to receive output as it becomes available through `contentStart`, `contentDelta`, and `contentStop` events.
 *
 * To use this operation, you must have the `bedrock-agentcore:InvokeAgentRuntimeCommand` permission.
 */
export declare const invokeAgentRuntimeCommand: API.OperationMethod<InvokeAgentRuntimeCommandRequest & RegionInput, InvokeAgentRuntimeCommandResponse, InvokeAgentRuntimeCommandError, Credentials | HttpClient.HttpClient>;
export type InvokeBrowserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an operating system-level action on a browser session in Amazon Bedrock AgentCore. This operation provides direct OS-level control over browser sessions, enabling mouse actions, keyboard input, and screenshots that the WebSocket-based Chrome DevTools Protocol (CDP) cannot handle -- such as interacting with print dialogs, context menus, and JavaScript alerts.
 *
 * You send a request with exactly one action in the `BrowserAction` union, and receive a corresponding result in the `BrowserActionResult` union.
 *
 * The following operations are related to `InvokeBrowser`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 *
 * - StopBrowserSession
 */
export declare const invokeBrowser: API.OperationMethod<InvokeBrowserRequest & RegionInput, InvokeBrowserResponse, InvokeBrowserError, Credentials | HttpClient.HttpClient>;
export type InvokeCodeInterpreterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes code within an active code interpreter session in Amazon Bedrock AgentCore. This operation processes the provided code, runs it in a secure environment, and returns the execution results including output, errors, and generated visualizations.
 *
 * To execute code, you must specify the code interpreter identifier, session ID, and the code to run in the arguments parameter. The operation returns a stream containing the execution results, which can include text output, error messages, and data visualizations.
 *
 * This operation is subject to request rate limiting based on your account's service quotas.
 *
 * The following operations are related to `InvokeCodeInterpreter`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const invokeCodeInterpreter: API.OperationMethod<InvokeCodeInterpreterRequest & RegionInput, InvokeCodeInterpreterResponse, InvokeCodeInterpreterError, Credentials | HttpClient.HttpClient>;
export type InvokeHarnessError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Operation to invoke a Harness.
 */
export declare const invokeHarness: API.OperationMethod<InvokeHarnessRequest & RegionInput, InvokeHarnessResponse, InvokeHarnessError, Credentials | HttpClient.HttpClient>;
export type InvokeWebSearchError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches the web and returns a ranked list of results. Each result includes a text extract from the page.
 *
 * You can filter the results by domain and by publication date.
 *
 * To use this operation, you must have the `bedrock-agentcore:InvokeWebSearch` permission on the resource `arn:${Partition}:bedrock-agentcore:${Region}:aws:tool/web-search.v1`.
 */
export declare const invokeWebSearch: API.OperationMethod<InvokeWebSearchInput & RegionInput, InvokeWebSearchOutput, InvokeWebSearchError, Credentials | HttpClient.HttpClient>;
export type ListABTestsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all A/B tests in the account.
 */
export declare const listABTests: API.PaginatedOperationMethod<ListABTestsRequest & RegionInput, ListABTestsResponse, ListABTestsError, Credentials | HttpClient.HttpClient, ABTestSummary>;
export type ListActorsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists all actors in an AgentCore Memory resource. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListActors` permission.
 */
export declare const listActors: API.PaginatedOperationMethod<ListActorsInput & RegionInput, ListActorsOutput, ListActorsError, Credentials | HttpClient.HttpClient, ActorSummary>;
export type ListBatchEvaluationsError = AccessDeniedException | InternalServerException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Lists all batch evaluations in the account, providing summary information about each evaluation's status and configuration.
 */
export declare const listBatchEvaluations: API.PaginatedOperationMethod<ListBatchEvaluationsRequest & RegionInput, ListBatchEvaluationsResponse, ListBatchEvaluationsError, Credentials | HttpClient.HttpClient, BatchEvaluationSummary>;
export type ListBrowserSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of browser sessions in Amazon Bedrock AgentCore that match the specified criteria. This operation returns summary information about each session, including identifiers, status, and timestamps.
 *
 * You can filter the results by browser identifier and session status. The operation supports pagination to handle large result sets efficiently.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully when retrieving large numbers of sessions.
 *
 * The following operations are related to `ListBrowserSessions`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const listBrowserSessions: API.OperationMethod<ListBrowserSessionsRequest & RegionInput, ListBrowserSessionsResponse, ListBrowserSessionsError, Credentials | HttpClient.HttpClient>;
export type ListCodeInterpreterSessionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of code interpreter sessions in Amazon Bedrock AgentCore that match the specified criteria. This operation returns summary information about each session, including identifiers, status, and timestamps.
 *
 * You can filter the results by code interpreter identifier and session status. The operation supports pagination to handle large result sets efficiently.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully when retrieving large numbers of sessions.
 *
 * The following operations are related to `ListCodeInterpreterSessions`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const listCodeInterpreterSessions: API.OperationMethod<ListCodeInterpreterSessionsRequest & RegionInput, ListCodeInterpreterSessionsResponse, ListCodeInterpreterSessionsError, Credentials | HttpClient.HttpClient>;
export type ListEventsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists events in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListEvents` permission.
 */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsInput & RegionInput, ListEventsOutput, ListEventsError, Credentials | HttpClient.HttpClient, Event>;
export type ListMemoryExtractionJobsError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists all long-term memory extraction jobs that are eligible to be started with optional filtering.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListMemoryExtractionJobs` permission.
 */
export declare const listMemoryExtractionJobs: API.PaginatedOperationMethod<ListMemoryExtractionJobsInput & RegionInput, ListMemoryExtractionJobsOutput, ListMemoryExtractionJobsError, Credentials | HttpClient.HttpClient, ExtractionJobMetadata>;
export type ListMemoryRecordsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists memory records in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListMemoryRecords` permission.
 */
export declare const listMemoryRecords: API.PaginatedOperationMethod<ListMemoryRecordsInput & RegionInput, ListMemoryRecordsOutput, ListMemoryRecordsError, Credentials | HttpClient.HttpClient, MemoryRecordSummary>;
export type ListPaymentInstrumentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List payment instruments for a manager.
 */
export declare const listPaymentInstruments: API.PaginatedOperationMethod<ListPaymentInstrumentsRequest & RegionInput, ListPaymentInstrumentsResponse, ListPaymentInstrumentsError, Credentials | HttpClient.HttpClient, PaymentInstrumentSummary>;
export type ListPaymentSessionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List payment sessions.
 */
export declare const listPaymentSessions: API.PaginatedOperationMethod<ListPaymentSessionsRequest & RegionInput, ListPaymentSessionsResponse, ListPaymentSessionsError, Credentials | HttpClient.HttpClient, PaymentSessionSummary>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all recommendations in the account, with optional filtering by status.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest & RegionInput, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type ListSessionsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Lists sessions in an AgentCore Memory resource based on specified criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * Empty sessions are automatically deleted after one day.
 *
 * To use this operation, you must have the `bedrock-agentcore:ListSessions` permission.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsInput & RegionInput, ListSessionsOutput, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ProcessPaymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | SubscriptionRequiredException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Processes a payment using a payment instrument within a payment session.
 */
export declare const processPayment: API.OperationMethod<ProcessPaymentRequest & RegionInput, ProcessPaymentResponse, ProcessPaymentError, Credentials | HttpClient.HttpClient>;
export type RetrieveMemoryRecordsError = AccessDeniedException | InvalidInputException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Searches for and retrieves memory records from an AgentCore Memory resource based on specified search criteria. We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * To use this operation, you must have the `bedrock-agentcore:RetrieveMemoryRecords` permission.
 */
export declare const retrieveMemoryRecords: API.PaginatedOperationMethod<RetrieveMemoryRecordsInput & RegionInput, RetrieveMemoryRecordsOutput, RetrieveMemoryRecordsError, Credentials | HttpClient.HttpClient, MemoryRecordSummary>;
export type SaveBrowserSessionProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Saves the current state of a browser session as a reusable profile in Amazon Bedrock AgentCore. A browser profile captures persistent browser data such as cookies and local storage from an active session, enabling you to reuse this data in future browser sessions.
 *
 * To save a browser session profile, you must specify the profile identifier, browser identifier, and session ID. The session must be active when saving the profile. Once saved, the profile can be used with the `StartBrowserSession` operation to initialize new sessions with the stored browser state.
 *
 * Browser profiles are useful for scenarios that require persistent authentication, maintaining user preferences across sessions, or continuing tasks that depend on previously stored browser data.
 *
 * The following operations are related to `SaveBrowserSessionProfile`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const saveBrowserSessionProfile: API.OperationMethod<SaveBrowserSessionProfileRequest & RegionInput, SaveBrowserSessionProfileResponse, SaveBrowserSessionProfileError, Credentials | HttpClient.HttpClient>;
export type SearchRegistryRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Searches for registry records using semantic, lexical, or hybrid queries. Returns metadata for matching records ordered by relevance within the specified registry.
 */
export declare const searchRegistryRecords: API.OperationMethod<SearchRegistryRecordsRequest & RegionInput, SearchRegistryRecordsResponse, SearchRegistryRecordsError, Credentials | HttpClient.HttpClient>;
export type StartBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Starts a batch evaluation job that evaluates agent performance across multiple sessions. Batch evaluations pull agent traces from CloudWatch Logs or an existing online evaluation configuration and run specified evaluators and insights against them.
 */
export declare const startBatchEvaluation: API.OperationMethod<StartBatchEvaluationRequest & RegionInput, StartBatchEvaluationResponse, StartBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type StartBrowserSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and initializes a browser session in Amazon Bedrock AgentCore. The session enables agents to navigate and interact with web content, extract information from websites, and perform web-based tasks as part of their response generation.
 *
 * To create a session, you must specify a browser identifier and a name. You can also configure the viewport dimensions to control the visible area of web content. The session remains active until it times out or you explicitly stop it using the `StopBrowserSession` operation.
 *
 * The following operations are related to `StartBrowserSession`:
 *
 * - GetBrowserSession
 *
 * - UpdateBrowserStream
 *
 * - SaveBrowserSessionProfile
 *
 * - StopBrowserSession
 *
 * - InvokeBrowser
 */
export declare const startBrowserSession: API.OperationMethod<StartBrowserSessionRequest & RegionInput, StartBrowserSessionResponse, StartBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type StartCodeInterpreterSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and initializes a code interpreter session in Amazon Bedrock AgentCore. The session enables agents to execute code as part of their response generation, supporting programming languages such as Python for data analysis, visualization, and computation tasks.
 *
 * To create a session, you must specify a code interpreter identifier and a name. The session remains active until it times out or you explicitly stop it using the `StopCodeInterpreterSession` operation.
 *
 * The following operations are related to `StartCodeInterpreterSession`:
 *
 * - InvokeCodeInterpreter
 *
 * - GetCodeInterpreterSession
 *
 * - StopCodeInterpreterSession
 */
export declare const startCodeInterpreterSession: API.OperationMethod<StartCodeInterpreterSessionRequest & RegionInput, StartCodeInterpreterSessionResponse, StartCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type StartMemoryExtractionJobError = AccessDeniedException | ResourceNotFoundException | ServiceException | ServiceQuotaExceededException | ThrottledException | ValidationException | CommonErrors;
/**
 * Starts a memory extraction job that processes events that failed extraction previously in an AgentCore Memory resource and produces structured memory records. When earlier extraction attempts have left events unprocessed, this job will pick up and extract those as well.
 *
 * To use this operation, you must have the `bedrock-agentcore:StartMemoryExtractionJob` permission.
 */
export declare const startMemoryExtractionJob: API.OperationMethod<StartMemoryExtractionJobInput & RegionInput, StartMemoryExtractionJobOutput, StartMemoryExtractionJobError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a recommendation job that analyzes agent traces and generates optimization suggestions for system prompts or tool descriptions to improve agent performance.
 */
export declare const startRecommendation: API.OperationMethod<StartRecommendationRequest & RegionInput, StartRecommendationResponse, StartRecommendationError, Credentials | HttpClient.HttpClient>;
export type StopBatchEvaluationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Stops a running batch evaluation. Sessions that have already been evaluated retain their results.
 */
export declare const stopBatchEvaluation: API.OperationMethod<StopBatchEvaluationRequest & RegionInput, StopBatchEvaluationResponse, StopBatchEvaluationError, Credentials | HttpClient.HttpClient>;
export type StopBrowserSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates an active browser session in Amazon Bedrock AgentCore. This operation stops the session, releases associated resources, and makes the session unavailable for further use.
 *
 * To stop a browser session, you must specify both the browser identifier and the session ID. Once stopped, a session cannot be restarted; you must create a new session using `StartBrowserSession`.
 *
 * The following operations are related to `StopBrowserSession`:
 *
 * - StartBrowserSession
 *
 * - GetBrowserSession
 */
export declare const stopBrowserSession: API.OperationMethod<StopBrowserSessionRequest & RegionInput, StopBrowserSessionResponse, StopBrowserSessionError, Credentials | HttpClient.HttpClient>;
export type StopCodeInterpreterSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Terminates an active code interpreter session in Amazon Bedrock AgentCore. This operation stops the session, releases associated resources, and makes the session unavailable for further use.
 *
 * To stop a code interpreter session, you must specify both the code interpreter identifier and the session ID. Once stopped, a session cannot be restarted; you must create a new session using `StartCodeInterpreterSession`.
 *
 * The following operations are related to `StopCodeInterpreterSession`:
 *
 * - StartCodeInterpreterSession
 *
 * - GetCodeInterpreterSession
 */
export declare const stopCodeInterpreterSession: API.OperationMethod<StopCodeInterpreterSessionRequest & RegionInput, StopCodeInterpreterSessionResponse, StopCodeInterpreterSessionError, Credentials | HttpClient.HttpClient>;
export type StopRuntimeSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | RetryableConflictException | RuntimeClientError | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Stops a session that is running in an running AgentCore Runtime agent.
 */
export declare const stopRuntimeSession: API.OperationMethod<StopRuntimeSessionRequest & RegionInput, StopRuntimeSessionResponse, StopRuntimeSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateABTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnauthorizedException | ValidationException | CommonErrors;
/**
 * Updates an A/B test's configuration, including variants, traffic allocation, evaluation settings, or execution status.
 */
export declare const updateABTest: API.OperationMethod<UpdateABTestRequest & RegionInput, UpdateABTestResponse, UpdateABTestError, Credentials | HttpClient.HttpClient>;
export type UpdateBrowserStreamError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a browser stream. To use this operation, you must have permissions to perform the bedrock:UpdateBrowserStream action.
 */
export declare const updateBrowserStream: API.OperationMethod<UpdateBrowserStreamRequest & RegionInput, UpdateBrowserStreamResponse, UpdateBrowserStreamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agentcore.d.ts.map