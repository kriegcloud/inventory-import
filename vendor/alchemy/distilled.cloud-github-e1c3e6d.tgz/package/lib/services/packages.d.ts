import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export type DeletePackageForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export interface DeletePackageForAuthenticatedUserResponse {
}
export type DeletePackageForOrgRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageForOrgRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export interface DeletePackageForOrgResponse {
}
export type DeletePackageForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export interface DeletePackageForUserResponse {
}
export type DeletePackageVersionForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageVersionForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageVersionForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface DeletePackageVersionForAuthenticatedUserResponse {
}
export type DeletePackageVersionForOrgRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageVersionForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageVersionForOrgRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface DeletePackageVersionForOrgResponse {
}
export type DeletePackageVersionForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface DeletePackageVersionForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: DeletePackageVersionForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface DeletePackageVersionForUserResponse {
}
export type GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequestState = "active" | "deleted";
export interface GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The state of the package, either active or deleted. */
    state?: GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequestState | (string & {}) | undefined;
}
export type PackageVersionMetadataPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type PackageVersionMetadataContainerTagsList = Array<string>;
export interface PackageVersionMetadataContainer {
    tags: PackageVersionMetadataContainerTagsList;
}
export type PackageVersionMetadataDockerTagList = Array<string>;
export interface PackageVersionMetadataDocker {
    tag?: PackageVersionMetadataDockerTagList | undefined;
}
export interface PackageVersionMetadata {
    package_type: PackageVersionMetadataPackageType;
    container?: PackageVersionMetadataContainer | undefined;
    docker?: PackageVersionMetadataDocker | undefined;
}
/** A version of a software package */
export interface PackageVersion {
    /** Unique identifier of the package version. */
    id: number;
    /** The name of the package version. */
    name: string;
    url: string;
    package_html_url: string;
    html_url?: string | undefined;
    license?: string | undefined;
    description?: string | undefined;
    created_at: string;
    updated_at: string;
    deleted_at?: string | undefined;
    metadata?: PackageVersionMetadata | undefined;
}
export type GetAllPackageVersionsForPackageOwnedByAuthenticatedUserResponseBodyList = Array<PackageVersion>;
export type GetAllPackageVersionsForPackageOwnedByAuthenticatedUserResponse = GetAllPackageVersionsForPackageOwnedByAuthenticatedUserResponseBodyList;
export type GetAllPackageVersionsForPackageOwnedByOrgRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type GetAllPackageVersionsForPackageOwnedByOrgRequestState = "active" | "deleted";
export interface GetAllPackageVersionsForPackageOwnedByOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetAllPackageVersionsForPackageOwnedByOrgRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The state of the package, either active or deleted. */
    state?: GetAllPackageVersionsForPackageOwnedByOrgRequestState | (string & {}) | undefined;
}
export type GetAllPackageVersionsForPackageOwnedByOrgResponseBodyList = Array<PackageVersion>;
export type GetAllPackageVersionsForPackageOwnedByOrgResponse = GetAllPackageVersionsForPackageOwnedByOrgResponseBodyList;
export type GetAllPackageVersionsForPackageOwnedByUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetAllPackageVersionsForPackageOwnedByUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetAllPackageVersionsForPackageOwnedByUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export type GetAllPackageVersionsForPackageOwnedByUserResponseBodyList = Array<PackageVersion>;
export type GetAllPackageVersionsForPackageOwnedByUserResponse = GetAllPackageVersionsForPackageOwnedByUserResponseBodyList;
export type GetPackageForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export type PackagePackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type PackageVisibility = "private" | "public";
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export type NullableMinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type NullableMinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface NullableMinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface NullableMinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type NullableMinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface NullableMinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: NullableSimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: NullableMinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: NullableMinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: NullableMinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: NullableMinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: NullableMinimalRepositoryCustomPropertiesMap | undefined;
}
/** A software package */
export interface Package {
    /** Unique identifier of the package. */
    id: number;
    /** The name of the package. */
    name: string;
    package_type: PackagePackageType;
    url: string;
    html_url: string;
    /** The number of versions of the package. */
    version_count: number;
    visibility: PackageVisibility;
    owner?: NullableSimpleUser | null | undefined;
    repository?: NullableMinimalRepository | null | undefined;
    created_at: string;
    updated_at: string;
}
export type GetPackageForOrganizationRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageForOrganizationRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export type GetPackageForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
}
export type GetPackageVersionForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageVersionForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageVersionForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export type GetPackageVersionForOrganizationRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageVersionForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageVersionForOrganizationRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export type GetPackageVersionForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface GetPackageVersionForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: GetPackageVersionForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface ListDockerMigrationConflictingPackagesForAuthenticatedUserRequest {
}
export type ListDockerMigrationConflictingPackagesForAuthenticatedUserResponseBodyList = Array<Package>;
export type ListDockerMigrationConflictingPackagesForAuthenticatedUserResponse = ListDockerMigrationConflictingPackagesForAuthenticatedUserResponseBodyList;
export interface ListDockerMigrationConflictingPackagesForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type ListDockerMigrationConflictingPackagesForOrganizationResponseBodyList = Array<Package>;
export type ListDockerMigrationConflictingPackagesForOrganizationResponse = ListDockerMigrationConflictingPackagesForOrganizationResponseBodyList;
export interface ListDockerMigrationConflictingPackagesForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export type ListDockerMigrationConflictingPackagesForUserResponseBodyList = Array<Package>;
export type ListDockerMigrationConflictingPackagesForUserResponse = ListDockerMigrationConflictingPackagesForUserResponseBodyList;
export type ListPackagesForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type ListPackagesForAuthenticatedUserRequestVisibility = "public" | "private" | "internal";
export interface ListPackagesForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: ListPackagesForAuthenticatedUserRequestPackageType | (string & {});
    /** The selected visibility of the packages. This parameter is optional and only filters an existing result set. The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`. For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." */
    visibility?: ListPackagesForAuthenticatedUserRequestVisibility | (string & {}) | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListPackagesForAuthenticatedUserResponseBodyList = Array<Package>;
export type ListPackagesForAuthenticatedUserResponse = ListPackagesForAuthenticatedUserResponseBodyList;
export type ListPackagesForOrganizationRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type ListPackagesForOrganizationRequestVisibility = "public" | "private" | "internal";
export interface ListPackagesForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: ListPackagesForOrganizationRequestPackageType | (string & {});
    /** The selected visibility of the packages. This parameter is optional and only filters an existing result set. The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`. For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." */
    visibility?: ListPackagesForOrganizationRequestVisibility | (string & {}) | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListPackagesForOrganizationResponseBodyList = Array<Package>;
export type ListPackagesForOrganizationResponse = ListPackagesForOrganizationResponseBodyList;
export type ListPackagesForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export type ListPackagesForUserRequestVisibility = "public" | "private" | "internal";
export interface ListPackagesForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: ListPackagesForUserRequestPackageType | (string & {});
    /** The selected visibility of the packages. This parameter is optional and only filters an existing result set. The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`. For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." */
    visibility?: ListPackagesForUserRequestVisibility | (string & {}) | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListPackagesForUserResponseBodyList = Array<Package>;
export type ListPackagesForUserResponse = ListPackagesForUserResponseBodyList;
export type RestorePackageForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** package token */
    token?: string | undefined;
}
export interface RestorePackageForAuthenticatedUserResponse {
}
export type RestorePackageForOrgRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageForOrgRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** package token */
    token?: string | undefined;
}
export interface RestorePackageForOrgResponse {
}
export type RestorePackageForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** package token */
    token?: string | undefined;
}
export interface RestorePackageForUserResponse {
}
export type RestorePackageVersionForAuthenticatedUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageVersionForAuthenticatedUserRequest {
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageVersionForAuthenticatedUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface RestorePackageVersionForAuthenticatedUserResponse {
}
export type RestorePackageVersionForOrgRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageVersionForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageVersionForOrgRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface RestorePackageVersionForOrgResponse {
}
export type RestorePackageVersionForUserRequestPackageType = "npm" | "maven" | "rubygems" | "docker" | "nuget" | "container";
export interface RestorePackageVersionForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. */
    package_type: RestorePackageVersionForUserRequestPackageType | (string & {});
    /** The name of the package. */
    package_name: string;
    /** Unique identifier of the package version. */
    package_version_id: number;
}
export interface RestorePackageVersionForUserResponse {
}
export type DeletePackageForAuthenticatedUserError = GithubOpError;
/** Delete a package for the authenticated user Deletes a package owned by the authenticated user. You cannot delete a public package if any version of the package has more than 5,000 downloads. In this scenario, contact GitHub support for further assistance. OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageForAuthenticatedUser: API.OperationMethod<DeletePackageForAuthenticatedUserRequest, DeletePackageForAuthenticatedUserResponse, DeletePackageForAuthenticatedUserError, GithubOpContext>;
export type DeletePackageForOrgError = GithubOpError;
/** Delete a package for an organization Deletes an entire package in an organization. You cannot delete a public package if any version of the package has more than 5,000 downloads. In this scenario, contact GitHub support for further assistance. The authenticated user must have admin permissions in the organization to use this endpoint. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must also have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageForOrg: API.OperationMethod<DeletePackageForOrgRequest, DeletePackageForOrgResponse, DeletePackageForOrgError, GithubOpContext>;
export type DeletePackageForUserError = GithubOpError;
/** Delete a package for a user Deletes an entire package for a user. You cannot delete a public package if any version of the package has more than 5,000 downloads. In this scenario, contact GitHub support for further assistance. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageForUser: API.OperationMethod<DeletePackageForUserRequest, DeletePackageForUserResponse, DeletePackageForUserError, GithubOpContext>;
export type DeletePackageVersionForAuthenticatedUserError = GithubOpError;
/** Delete a package version for the authenticated user Deletes a specific package version for a package owned by the authenticated user. If the package is public and the package version has more than 5,000 downloads, you cannot delete the package version. In this scenario, contact GitHub support for further assistance. The authenticated user must have admin permissions in the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageVersionForAuthenticatedUser: API.OperationMethod<DeletePackageVersionForAuthenticatedUserRequest, DeletePackageVersionForAuthenticatedUserResponse, DeletePackageVersionForAuthenticatedUserError, GithubOpContext>;
export type DeletePackageVersionForOrgError = GithubOpError;
/** Delete package version for an organization Deletes a specific package version in an organization. If the package is public and the package version has more than 5,000 downloads, you cannot delete the package version. In this scenario, contact GitHub support for further assistance. The authenticated user must have admin permissions in the organization to use this endpoint. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must also have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageVersionForOrg: API.OperationMethod<DeletePackageVersionForOrgRequest, DeletePackageVersionForOrgResponse, DeletePackageVersionForOrgError, GithubOpContext>;
export type DeletePackageVersionForUserError = GithubOpError;
/** Delete package version for a user Deletes a specific package version for a user. If the package is public and the package version has more than 5,000 downloads, you cannot delete the package version. In this scenario, contact GitHub support for further assistance. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `delete:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const deletePackageVersionForUser: API.OperationMethod<DeletePackageVersionForUserRequest, DeletePackageVersionForUserResponse, DeletePackageVersionForUserError, GithubOpContext>;
export type GetAllPackageVersionsForPackageOwnedByAuthenticatedUserError = GithubOpError;
/** List package versions for a package owned by the authenticated user Lists package versions for a package owned by the authenticated user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getAllPackageVersionsForPackageOwnedByAuthenticatedUser: API.PaginatedOperationMethod<GetAllPackageVersionsForPackageOwnedByAuthenticatedUserRequest, GetAllPackageVersionsForPackageOwnedByAuthenticatedUserResponse, GetAllPackageVersionsForPackageOwnedByAuthenticatedUserError, GithubOpContext, PackageVersion>;
export type GetAllPackageVersionsForPackageOwnedByOrgError = GithubOpError;
/** List package versions for a package owned by an organization Lists package versions for a package owned by an organization. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getAllPackageVersionsForPackageOwnedByOrg: API.PaginatedOperationMethod<GetAllPackageVersionsForPackageOwnedByOrgRequest, GetAllPackageVersionsForPackageOwnedByOrgResponse, GetAllPackageVersionsForPackageOwnedByOrgError, GithubOpContext, PackageVersion>;
export type GetAllPackageVersionsForPackageOwnedByUserError = GithubOpError;
/** List package versions for a package owned by a user Lists package versions for a public package owned by a specified user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getAllPackageVersionsForPackageOwnedByUser: API.OperationMethod<GetAllPackageVersionsForPackageOwnedByUserRequest, GetAllPackageVersionsForPackageOwnedByUserResponse, GetAllPackageVersionsForPackageOwnedByUserError, GithubOpContext>;
export type GetPackageForAuthenticatedUserError = GithubOpError;
/** Get a package for the authenticated user Gets a specific package for a package owned by the authenticated user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageForAuthenticatedUser: API.OperationMethod<GetPackageForAuthenticatedUserRequest, Package, GetPackageForAuthenticatedUserError, GithubOpContext>;
export type GetPackageForOrganizationError = GithubOpError;
/** Get a package for an organization Gets a specific package in an organization. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageForOrganization: API.OperationMethod<GetPackageForOrganizationRequest, Package, GetPackageForOrganizationError, GithubOpContext>;
export type GetPackageForUserError = GithubOpError;
/** Get a package for a user Gets a specific package metadata for a public package owned by a user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageForUser: API.OperationMethod<GetPackageForUserRequest, Package, GetPackageForUserError, GithubOpContext>;
export type GetPackageVersionForAuthenticatedUserError = GithubOpError;
/** Get a package version for the authenticated user Gets a specific package version for a package owned by the authenticated user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageVersionForAuthenticatedUser: API.OperationMethod<GetPackageVersionForAuthenticatedUserRequest, PackageVersion, GetPackageVersionForAuthenticatedUserError, GithubOpContext>;
export type GetPackageVersionForOrganizationError = GithubOpError;
/** Get a package version for an organization Gets a specific package version in an organization. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageVersionForOrganization: API.OperationMethod<GetPackageVersionForOrganizationRequest, PackageVersion, GetPackageVersionForOrganizationError, GithubOpContext>;
export type GetPackageVersionForUserError = GithubOpError;
/** Get a package version for a user Gets a specific package version for a public package owned by a specified user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const getPackageVersionForUser: API.OperationMethod<GetPackageVersionForUserRequest, PackageVersion, GetPackageVersionForUserError, GithubOpContext>;
export type ListDockerMigrationConflictingPackagesForAuthenticatedUserError = GithubOpError;
/** Get list of conflicting packages during Docker migration for authenticated-user Lists all packages that are owned by the authenticated user within the user's namespace, and that encountered a conflict during a Docker migration. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. */
export declare const listDockerMigrationConflictingPackagesForAuthenticatedUser: API.OperationMethod<ListDockerMigrationConflictingPackagesForAuthenticatedUserRequest, ListDockerMigrationConflictingPackagesForAuthenticatedUserResponse, ListDockerMigrationConflictingPackagesForAuthenticatedUserError, GithubOpContext>;
export type ListDockerMigrationConflictingPackagesForOrganizationError = GithubOpError;
/** Get list of conflicting packages during Docker migration for organization Lists all packages that are in a specific organization, are readable by the requesting user, and that encountered a conflict during a Docker migration. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. */
export declare const listDockerMigrationConflictingPackagesForOrganization: API.OperationMethod<ListDockerMigrationConflictingPackagesForOrganizationRequest, ListDockerMigrationConflictingPackagesForOrganizationResponse, ListDockerMigrationConflictingPackagesForOrganizationError, GithubOpContext>;
export type ListDockerMigrationConflictingPackagesForUserError = GithubOpError;
/** Get list of conflicting packages during Docker migration for user Lists all packages that are in a specific user's namespace, that the requesting user has access to, and that encountered a conflict during Docker migration. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. */
export declare const listDockerMigrationConflictingPackagesForUser: API.OperationMethod<ListDockerMigrationConflictingPackagesForUserRequest, ListDockerMigrationConflictingPackagesForUserResponse, ListDockerMigrationConflictingPackagesForUserError, GithubOpContext>;
export type ListPackagesForAuthenticatedUserError = GithubOpError;
/** List packages for the authenticated user's namespace Lists packages owned by the authenticated user within the user's namespace. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const listPackagesForAuthenticatedUser: API.PaginatedOperationMethod<ListPackagesForAuthenticatedUserRequest, ListPackagesForAuthenticatedUserResponse, ListPackagesForAuthenticatedUserError, GithubOpContext, Package>;
export type ListPackagesForOrganizationError = GithubOpError;
/** List packages for an organization Lists packages in an organization readable by the user. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const listPackagesForOrganization: API.PaginatedOperationMethod<ListPackagesForOrganizationRequest, ListPackagesForOrganizationResponse, ListPackagesForOrganizationError, GithubOpContext, Package>;
export type ListPackagesForUserError = GithubOpError;
/** List packages for a user Lists all packages in a user's namespace for which the requesting user has access. OAuth app tokens and personal access tokens (classic) need the `read:packages` scope to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const listPackagesForUser: API.PaginatedOperationMethod<ListPackagesForUserRequest, ListPackagesForUserResponse, ListPackagesForUserError, GithubOpContext, Package>;
export type RestorePackageForAuthenticatedUserError = GithubOpError;
/** Restore a package for the authenticated user Restores a package owned by the authenticated user. You can restore a deleted package under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageForAuthenticatedUser: API.OperationMethod<RestorePackageForAuthenticatedUserRequest, RestorePackageForAuthenticatedUserResponse, RestorePackageForAuthenticatedUserError, GithubOpContext>;
export type RestorePackageForOrgError = GithubOpError;
/** Restore a package for an organization Restores an entire package in an organization. You can restore a deleted package under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. The authenticated user must have admin permissions in the organization to use this endpoint. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must also have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageForOrg: API.OperationMethod<RestorePackageForOrgRequest, RestorePackageForOrgResponse, RestorePackageForOrgError, GithubOpContext>;
export type RestorePackageForUserError = GithubOpError;
/** Restore a package for a user Restores an entire package for a user. You can restore a deleted package under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageForUser: API.OperationMethod<RestorePackageForUserRequest, RestorePackageForUserResponse, RestorePackageForUserError, GithubOpContext>;
export type RestorePackageVersionForAuthenticatedUserError = GithubOpError;
/** Restore a package version for the authenticated user Restores a package version owned by the authenticated user. You can restore a deleted package version under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageVersionForAuthenticatedUser: API.OperationMethod<RestorePackageVersionForAuthenticatedUserRequest, RestorePackageVersionForAuthenticatedUserResponse, RestorePackageVersionForAuthenticatedUserError, GithubOpContext>;
export type RestorePackageVersionForOrgError = GithubOpError;
/** Restore package version for an organization Restores a specific package version in an organization. You can restore a deleted package under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. The authenticated user must have admin permissions in the organization to use this endpoint. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must also have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageVersionForOrg: API.OperationMethod<RestorePackageVersionForOrgRequest, RestorePackageVersionForOrgResponse, RestorePackageVersionForOrgError, GithubOpContext>;
export type RestorePackageVersionForUserError = GithubOpError;
/** Restore package version for a user Restores a specific package version for a user. You can restore a deleted package under the following conditions: - The package was deleted within the last 30 days. - The same package namespace and version is still available and not reused for a new package. If the same package namespace is not available, you will not be able to restore your package. In this scenario, to restore the deleted package, you must delete the new package that uses the deleted package's namespace first. If the `package_type` belongs to a GitHub Packages registry that supports granular permissions, the authenticated user must have admin permissions to the package. For the list of these registries, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." OAuth app tokens and personal access tokens (classic) need the `read:packages` and `write:packages` scopes to use this endpoint. For more information, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#permissions-for-repository-scoped-packages)." */
export declare const restorePackageVersionForUser: API.OperationMethod<RestorePackageVersionForUserRequest, RestorePackageVersionForUserResponse, RestorePackageVersionForUserError, GithubOpContext>;
//# sourceMappingURL=packages.d.ts.map