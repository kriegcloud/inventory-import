import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidArgsException_base: S.TaggedErrorClass<"InvalidArgsException", {
    readonly message: any;
}>;
export declare class InvalidArgsException extends /*@__PURE__*/ InvalidArgsException_base {
}
declare const InvalidArnException_base: S.TaggedErrorClass<"InvalidArnException", {
    readonly message: any;
}>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidDomainValidationOptionsException_base: S.TaggedErrorClass<"InvalidDomainValidationOptionsException", {
    readonly message: any;
}>;
export declare class InvalidDomainValidationOptionsException extends /*@__PURE__*/ InvalidDomainValidationOptionsException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const RequestInProgressException_base: S.TaggedErrorClass<"RequestInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestInProgressException extends /*@__PURE__*/ RequestInProgressException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}>;
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagPolicyException_base: S.TaggedErrorClass<"TagPolicyException", {
    readonly message: any;
}>;
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsToCertificateRequest {
    CertificateArn: string;
    Tags: Tag[];
}
export interface AddTagsToCertificateResponse {
}
export type AcmeEndpointArn = string;
export type DomainName = string;
export type DomainScopeOption = "ENABLED" | "DISABLED" | (string & {});
export interface DomainScope {
    ExactDomain?: DomainScopeOption | undefined;
    Subdomains?: DomainScopeOption | undefined;
    Wildcards?: DomainScopeOption | undefined;
}
export type HostedZoneId = string;
export interface DnsPrevalidationOptions {
    DomainScope?: DomainScope | undefined;
    HostedZoneId?: string | undefined;
}
export type PrevalidationOptions = {
    DnsPrevalidation: DnsPrevalidationOptions;
};
export interface CreateAcmeDomainValidationRequest {
    IdempotencyToken?: string | undefined;
    AcmeEndpointArn: string;
    DomainName: string;
    PrevalidationOptions: PrevalidationOptions;
    Tags?: Tag[] | undefined;
}
export type AcmeDomainValidationArn = string;
export interface CreateAcmeDomainValidationResponse {
    AcmeDomainValidationArn: string;
}
export type AcmeAuthorizationBehavior = "PRE_APPROVED" | (string & {});
export type AcmeContact = "REQUIRED" | "NOT_REQUIRED" | (string & {});
export type PublicKeyAlgorithm = "RSA_2048" | "EC_prime256v1" | "EC_secp384r1" | (string & {});
export type PublicKeyAlgorithmList = PublicKeyAlgorithm[];
export interface PublicCertificateAuthority {
    AllowedKeyAlgorithms?: PublicKeyAlgorithm[] | undefined;
}
export type CertificateAuthority = {
    PublicCertificateAuthority: PublicCertificateAuthority;
};
export interface CreateAcmeEndpointRequest {
    IdempotencyToken?: string | undefined;
    AuthorizationBehavior: AcmeAuthorizationBehavior;
    Contact?: AcmeContact | undefined;
    CertificateAuthority: CertificateAuthority;
    Tags?: Tag[] | undefined;
    CertificateTags?: Tag[] | undefined;
}
export interface CreateAcmeEndpointResponse {
    AcmeEndpointArn?: string | undefined;
}
export type RoleArn = string;
export type TimeType = "MINUTES" | "HOURS" | "DAYS" | (string & {});
export interface Expiration {
    Value: number;
    Type: TimeType;
}
export interface CreateAcmeExternalAccountBindingRequest {
    IdempotencyToken?: string | undefined;
    AcmeEndpointArn: string;
    RoleArn: string;
    Expiration?: Expiration | undefined;
    Tags?: Tag[] | undefined;
}
export type AcmeExternalAccountBindingArn = string;
export interface AcmeExternalAccountBinding {
    AcmeExternalAccountBindingArn?: string | undefined;
    AcmeEndpointArn?: string | undefined;
    RoleArn?: string | undefined;
    ExpiresAt?: Date | undefined;
    RevokedAt?: Date | undefined;
    LastUsedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface CreateAcmeExternalAccountBindingResponse {
    ExternalAccountBinding?: AcmeExternalAccountBinding | undefined;
}
export interface DeleteAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
}
export interface DeleteAcmeDomainValidationResponse {
}
export interface DeleteAcmeEndpointRequest {
    AcmeEndpointArn: string;
}
export interface DeleteAcmeEndpointResponse {
}
export interface DeleteAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export interface DeleteAcmeExternalAccountBindingResponse {
}
export interface DeleteCertificateRequest {
    CertificateArn: string;
}
export interface DeleteCertificateResponse {
}
export interface DescribeAcmeAccountRequest {
    AcmeEndpointArn: string;
    AccountUrl: string;
}
export type AcmeAccountStatus = "VALID" | "DEACTIVATED" | "REVOKED" | (string & {});
export type ContactList = string[];
export interface AcmeAccount {
    AccountUrl?: string | undefined;
    PublicKeyThumbprint?: string | undefined;
    Status?: AcmeAccountStatus | undefined;
    CreatedAt?: Date | undefined;
    AcmeExternalAccountBindingArn?: string | undefined;
    Contacts?: string[] | undefined;
}
export interface DescribeAcmeAccountResponse {
    AcmeAccount?: AcmeAccount | undefined;
}
export interface DescribeAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
}
export type PrevalidationType = "DNS_PREVALIDATION" | (string & {});
export type RecordType = "CNAME" | (string & {});
export interface ResourceRecord {
    Name: string;
    Type: RecordType;
    Value: string;
}
export interface DnsPrevalidationDetails {
    DomainScope?: DomainScope | undefined;
    HostedZoneId?: string | undefined;
    ResourceRecord?: ResourceRecord | undefined;
}
export type PrevalidationDetails = {
    DnsPrevalidation: DnsPrevalidationDetails;
};
export type AcmeDomainValidationStatus = "VALIDATING" | "VALID" | "INVALID" | "DELETING" | (string & {});
export type AcmeDomainValidationFailureReason = "ACCESS_DENIED" | "DOMAIN_MISMATCH" | "DOMAIN_NOT_ALLOWED" | "ENDPOINT_NOT_ACTIVE" | "HOSTED_ZONE_NOT_FOUND" | "INTERNAL_FAILURE" | "INVALID_CHANGE_BATCH" | "INVALID_PUBLIC_DOMAIN" | "TIMED_OUT" | (string & {});
export interface FailureDetails {
    Reason?: AcmeDomainValidationFailureReason | undefined;
    Message?: string | undefined;
}
export interface AcmeDomainValidation {
    AcmeDomainValidationArn?: string | undefined;
    AcmeEndpointArn?: string | undefined;
    DomainName?: string | undefined;
    PrevalidationType?: PrevalidationType | undefined;
    PrevalidationDetails?: PrevalidationDetails | undefined;
    Status?: AcmeDomainValidationStatus | undefined;
    FailureDetails?: FailureDetails | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface DescribeAcmeDomainValidationResponse {
    AcmeDomainValidation?: AcmeDomainValidation | undefined;
}
export interface DescribeAcmeEndpointRequest {
    AcmeEndpointArn: string;
}
export type AcmeEndpointStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export interface AcmeEndpoint {
    AcmeEndpointArn?: string | undefined;
    EndpointUrl?: string | undefined;
    Status?: AcmeEndpointStatus | undefined;
    FailureReason?: string | undefined;
    AuthorizationBehavior?: AcmeAuthorizationBehavior | undefined;
    Contact?: AcmeContact | undefined;
    CertificateAuthority?: CertificateAuthority | undefined;
    CertificateTags?: Tag[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface DescribeAcmeEndpointResponse {
    AcmeEndpoint?: AcmeEndpoint | undefined;
}
export interface DescribeAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export interface DescribeAcmeExternalAccountBindingResponse {
    ExternalAccountBinding?: AcmeExternalAccountBinding | undefined;
}
export interface DescribeCertificateRequest {
    CertificateArn: string;
}
export type DomainNameString = string;
export type DomainList = string[];
export type CertificateManagedBy = "CLOUDFRONT" | (string & {});
export type ValidationEmailList = string[];
export type DomainStatus = "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export interface HttpRedirect {
    RedirectFrom?: string | undefined;
    RedirectTo?: string | undefined;
}
export type ValidationMethod = "EMAIL" | "DNS" | "HTTP" | (string & {});
export interface DomainValidation {
    DomainName: string;
    ValidationEmails?: string[] | undefined;
    ValidationDomain?: string | undefined;
    ValidationStatus?: DomainStatus | undefined;
    ResourceRecord?: ResourceRecord | undefined;
    HttpRedirect?: HttpRedirect | undefined;
    ValidationMethod?: ValidationMethod | undefined;
}
export type DomainValidationList = DomainValidation[];
export type CertificateStatus = "PENDING_VALIDATION" | "ISSUED" | "INACTIVE" | "EXPIRED" | "VALIDATION_TIMED_OUT" | "REVOKED" | "FAILED" | (string & {});
export type RevocationReason = "UNSPECIFIED" | "KEY_COMPROMISE" | "CA_COMPROMISE" | "AFFILIATION_CHANGED" | "SUPERCEDED" | "SUPERSEDED" | "CESSATION_OF_OPERATION" | "CERTIFICATE_HOLD" | "REMOVE_FROM_CRL" | "PRIVILEGE_WITHDRAWN" | "A_A_COMPROMISE" | (string & {});
export type KeyAlgorithm = "RSA_1024" | "RSA_2048" | "RSA_3072" | "RSA_4096" | "EC_prime256v1" | "EC_secp384r1" | "EC_secp521r1" | (string & {});
export type InUseList = string[];
export type FailureReason = "NO_AVAILABLE_CONTACTS" | "ADDITIONAL_VERIFICATION_REQUIRED" | "DOMAIN_NOT_ALLOWED" | "INVALID_PUBLIC_DOMAIN" | "DOMAIN_VALIDATION_DENIED" | "CAA_ERROR" | "PCA_LIMIT_EXCEEDED" | "PCA_INVALID_ARN" | "PCA_INVALID_STATE" | "PCA_REQUEST_FAILED" | "PCA_NAME_CONSTRAINTS_VALIDATION" | "PCA_RESOURCE_NOT_FOUND" | "PCA_INVALID_ARGS" | "PCA_INVALID_DURATION" | "PCA_ACCESS_DENIED" | "SLR_NOT_FOUND" | "OTHER" | (string & {});
export type CertificateType = "IMPORTED" | "AMAZON_ISSUED" | "PRIVATE" | (string & {});
export type RenewalStatus = "PENDING_AUTO_RENEWAL" | "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export interface RenewalSummary {
    RenewalStatus: RenewalStatus;
    DomainValidationOptions: DomainValidation[];
    RenewalStatusReason?: FailureReason | undefined;
    UpdatedAt: Date;
}
export type KeyUsageName = "DIGITAL_SIGNATURE" | "NON_REPUDIATION" | "KEY_ENCIPHERMENT" | "DATA_ENCIPHERMENT" | "KEY_AGREEMENT" | "CERTIFICATE_SIGNING" | "CRL_SIGNING" | "ENCIPHER_ONLY" | "DECIPHER_ONLY" | "ANY" | "CUSTOM" | (string & {});
export interface KeyUsage {
    Name?: KeyUsageName | undefined;
}
export type KeyUsageList = KeyUsage[];
export type ExtendedKeyUsageName = "TLS_WEB_SERVER_AUTHENTICATION" | "TLS_WEB_CLIENT_AUTHENTICATION" | "CODE_SIGNING" | "EMAIL_PROTECTION" | "TIME_STAMPING" | "OCSP_SIGNING" | "IPSEC_END_SYSTEM" | "IPSEC_TUNNEL" | "IPSEC_USER" | "ANY" | "NONE" | "CUSTOM" | (string & {});
export interface ExtendedKeyUsage {
    Name?: ExtendedKeyUsageName | undefined;
    OID?: string | undefined;
}
export type ExtendedKeyUsageList = ExtendedKeyUsage[];
export type RenewalEligibility = "ELIGIBLE" | "INELIGIBLE" | (string & {});
export type CertificateTransparencyLoggingPreference = "ENABLED" | "DISABLED" | (string & {});
export type CertificateExport = "ENABLED" | "DISABLED" | (string & {});
export interface CertificateOptions {
    CertificateTransparencyLoggingPreference?: CertificateTransparencyLoggingPreference | undefined;
    Export?: CertificateExport | undefined;
    ValidationMethod?: ValidationMethod | undefined;
}
export type UpdateStatus = "PENDING_DOMAIN_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export type UpdateType = "DOMAIN_VALIDATION_METHOD" | (string & {});
export interface DomainValidationMethodUpdateSummary {
    From?: ValidationMethod | undefined;
    To?: ValidationMethod | undefined;
}
export interface UpdateSummary {
    Status?: UpdateStatus | undefined;
    Type?: UpdateType | undefined;
    DomainValidationMethodUpdateSummary?: DomainValidationMethodUpdateSummary | undefined;
    RequestedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type CertificateKeyPairOrigin = "AWS_MANAGED" | "ACME" | "CUSTOMER_PROVIDED" | (string & {});
export type AcmeAccountId = string;
export interface CertificateDetail {
    CertificateArn?: string | undefined;
    DomainName?: string | undefined;
    SubjectAlternativeNames?: string[] | undefined;
    ManagedBy?: CertificateManagedBy | undefined;
    DomainValidationOptions?: DomainValidation[] | undefined;
    Serial?: string | undefined;
    Subject?: string | undefined;
    Issuer?: string | undefined;
    CreatedAt?: Date | undefined;
    IssuedAt?: Date | undefined;
    ImportedAt?: Date | undefined;
    Status?: CertificateStatus | undefined;
    RevokedAt?: Date | undefined;
    RevocationReason?: RevocationReason | undefined;
    NotBefore?: Date | undefined;
    NotAfter?: Date | undefined;
    KeyAlgorithm?: KeyAlgorithm | undefined;
    SignatureAlgorithm?: string | undefined;
    InUseBy?: string[] | undefined;
    FailureReason?: FailureReason | undefined;
    Type?: CertificateType | undefined;
    RenewalSummary?: RenewalSummary | undefined;
    KeyUsages?: KeyUsage[] | undefined;
    ExtendedKeyUsages?: ExtendedKeyUsage[] | undefined;
    CertificateAuthorityArn?: string | undefined;
    RenewalEligibility?: RenewalEligibility | undefined;
    Options?: CertificateOptions | undefined;
    UpdateSummary?: UpdateSummary | undefined;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin | undefined;
    AcmeEndpointArn?: string | undefined;
    AcmeAccountId?: string | undefined;
}
export interface DescribeCertificateResponse {
    Certificate?: CertificateDetail | undefined;
}
export type PassphraseBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ExportCertificateRequest {
    CertificateArn: string;
    Passphrase: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type CertificateBody = string;
export type CertificateChain = string;
export type PrivateKey = string | redacted.Redacted<string>;
export interface ExportCertificateResponse {
    Certificate?: string | undefined;
    CertificateChain?: string | undefined;
    PrivateKey?: string | redacted.Redacted<string> | undefined;
}
export interface GetAccountConfigurationRequest {
}
export type PositiveInteger = number;
export interface ExpiryEventsConfiguration {
    DaysBeforeExpiry?: number | undefined;
}
export interface GetAccountConfigurationResponse {
    ExpiryEvents?: ExpiryEventsConfiguration | undefined;
}
export interface GetAcmeExternalAccountBindingCredentialsRequest {
    AcmeExternalAccountBindingArn: string;
}
export type MacKey = string | redacted.Redacted<string>;
export interface GetAcmeExternalAccountBindingCredentialsResponse {
    KeyId?: string | undefined;
    MacKey?: string | redacted.Redacted<string> | undefined;
}
export interface GetCertificateRequest {
    CertificateArn: string;
}
export interface GetCertificateResponse {
    Certificate?: string | undefined;
    CertificateChain?: string | undefined;
}
export type CertificateBodyBlob = Uint8Array;
export type PrivateKeyBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export type CertificateChainBlob = Uint8Array;
export interface ImportCertificateRequest {
    CertificateArn?: string | undefined;
    Certificate: Uint8Array;
    PrivateKey: Uint8Array | redacted.Redacted<Uint8Array>;
    CertificateChain?: Uint8Array | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportCertificateResponse {
    CertificateArn?: string | undefined;
}
export interface ListAcmeAccountsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AcmeEndpointArn: string;
}
export interface AcmeAccountSummary {
    AccountUrl?: string | undefined;
    PublicKeyThumbprint?: string | undefined;
    Status?: AcmeAccountStatus | undefined;
    CreatedAt?: Date | undefined;
    AcmeExternalAccountBindingArn?: string | undefined;
    Contacts?: string[] | undefined;
}
export type AcmeAccountList = AcmeAccountSummary[];
export interface ListAcmeAccountsResponse {
    AcmeAccounts?: AcmeAccountSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAcmeDomainValidationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AcmeEndpointArn: string;
}
export interface AcmeDomainValidationSummary {
    AcmeDomainValidationArn?: string | undefined;
    AcmeEndpointArn?: string | undefined;
    DomainName?: string | undefined;
    PrevalidationType?: PrevalidationType | undefined;
    PrevalidationDetails?: PrevalidationDetails | undefined;
    Status?: AcmeDomainValidationStatus | undefined;
    FailureDetails?: FailureDetails | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type AcmeDomainValidationList = AcmeDomainValidationSummary[];
export interface ListAcmeDomainValidationsResponse {
    AcmeDomainValidations?: AcmeDomainValidationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAcmeEndpointsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AcmeEndpointSummary {
    AcmeEndpointArn?: string | undefined;
    EndpointUrl?: string | undefined;
    Status?: AcmeEndpointStatus | undefined;
    FailureReason?: string | undefined;
    AuthorizationBehavior?: AcmeAuthorizationBehavior | undefined;
    Contact?: AcmeContact | undefined;
    CertificateAuthority?: CertificateAuthority | undefined;
    CertificateTags?: Tag[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type AcmeEndpointList = AcmeEndpointSummary[];
export interface ListAcmeEndpointsResponse {
    AcmeEndpoints?: AcmeEndpointSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAcmeExternalAccountBindingsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AcmeEndpointArn: string;
}
export interface AcmeExternalAccountBindingSummary {
    AcmeExternalAccountBindingArn?: string | undefined;
    AcmeEndpointArn?: string | undefined;
    RoleArn?: string | undefined;
    ExpiresAt?: Date | undefined;
    RevokedAt?: Date | undefined;
    LastUsedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type AcmeExternalAccountBindingList = AcmeExternalAccountBindingSummary[];
export interface ListAcmeExternalAccountBindingsResponse {
    ExternalAccountBindings?: AcmeExternalAccountBindingSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CertificateArn = string;
export type NextToken = string;
export type MaxItems = number;
export interface ListCertificateDomainValidationsRequest {
    CertificateArn: string;
    NextToken?: string | undefined;
    MaxItems?: number | undefined;
}
export interface EmailValidationChallenge {
    ValidationEmails?: string[] | undefined;
    ValidationDomain?: string | undefined;
}
export interface DnsValidationChallenge {
    ResourceRecord?: ResourceRecord | undefined;
}
export type ValidationChallenge = {
    EmailValidationChallenge: EmailValidationChallenge;
    DnsValidationChallenge?: undefined;
} | {
    EmailValidationChallenge?: undefined;
    DnsValidationChallenge: DnsValidationChallenge;
};
export interface ValidationConfiguration {
    ValidationMethod?: ValidationMethod | undefined;
    ValidationChallenge?: ValidationChallenge | undefined;
    ValidationStatus?: DomainStatus | undefined;
}
export interface DomainValidationSummary {
    DomainName: string;
    ActiveValidationConfiguration?: ValidationConfiguration | undefined;
    RequestedValidationConfiguration?: ValidationConfiguration | undefined;
}
export type DomainValidationSummaryList = DomainValidationSummary[];
export interface ListCertificateDomainValidationsResponse {
    DomainValidationSummaryList?: DomainValidationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CertificateStatuses = CertificateStatus[];
export type CertificateKeyPairOrigins = CertificateKeyPairOrigin[];
export type ExtendedKeyUsageFilterList = ExtendedKeyUsageName[];
export type KeyUsageFilterList = KeyUsageName[];
export type KeyAlgorithmList = KeyAlgorithm[];
export interface Filters {
    extendedKeyUsage?: ExtendedKeyUsageName[] | undefined;
    keyUsage?: KeyUsageName[] | undefined;
    keyTypes?: KeyAlgorithm[] | undefined;
    exportOption?: CertificateExport | undefined;
    managedBy?: CertificateManagedBy | undefined;
}
export type SortBy = "CREATED_AT" | (string & {});
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListCertificatesRequest {
    CertificateStatuses?: CertificateStatus[] | undefined;
    CertificateKeyPairOrigins?: CertificateKeyPairOrigin[] | undefined;
    Includes?: Filters | undefined;
    NextToken?: string | undefined;
    MaxItems?: number | undefined;
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type KeyUsageNames = KeyUsageName[];
export type ExtendedKeyUsageNames = ExtendedKeyUsageName[];
export interface CertificateSummary {
    CertificateArn?: string | undefined;
    DomainName?: string | undefined;
    SubjectAlternativeNameSummaries?: string[] | undefined;
    HasAdditionalSubjectAlternativeNames?: boolean | undefined;
    Status?: CertificateStatus | undefined;
    Type?: CertificateType | undefined;
    KeyAlgorithm?: KeyAlgorithm | undefined;
    KeyUsages?: KeyUsageName[] | undefined;
    ExtendedKeyUsages?: ExtendedKeyUsageName[] | undefined;
    ExportOption?: CertificateExport | undefined;
    InUse?: boolean | undefined;
    Exported?: boolean | undefined;
    RenewalEligibility?: RenewalEligibility | undefined;
    NotBefore?: Date | undefined;
    NotAfter?: Date | undefined;
    CreatedAt?: Date | undefined;
    IssuedAt?: Date | undefined;
    ImportedAt?: Date | undefined;
    RevokedAt?: Date | undefined;
    ManagedBy?: CertificateManagedBy | undefined;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin | undefined;
}
export type CertificateSummaryList = CertificateSummary[];
export interface ListCertificatesResponse {
    NextToken?: string | undefined;
    CertificateSummaryList?: CertificateSummary[] | undefined;
}
export interface ListTagsForCertificateRequest {
    CertificateArn: string;
}
export interface ListTagsForCertificateResponse {
    Tags?: Tag[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type IdempotencyToken = string;
export interface PutAccountConfigurationRequest {
    ExpiryEvents?: ExpiryEventsConfiguration | undefined;
    IdempotencyToken: string;
}
export interface PutAccountConfigurationResponse {
}
export interface RemoveTagsFromCertificateRequest {
    CertificateArn: string;
    Tags: Tag[];
}
export interface RemoveTagsFromCertificateResponse {
}
export interface RenewCertificateRequest {
    CertificateArn: string;
}
export interface RenewCertificateResponse {
}
export interface DomainValidationOption {
    DomainName: string;
    ValidationDomain: string;
}
export type DomainValidationOptionList = DomainValidationOption[];
export type PcaArn = string;
export interface RequestCertificateRequest {
    DomainName: string;
    ValidationMethod?: ValidationMethod | undefined;
    SubjectAlternativeNames?: string[] | undefined;
    IdempotencyToken?: string | undefined;
    DomainValidationOptions?: DomainValidationOption[] | undefined;
    Options?: CertificateOptions | undefined;
    CertificateAuthorityArn?: string | undefined;
    Tags?: Tag[] | undefined;
    KeyAlgorithm?: KeyAlgorithm | undefined;
    ManagedBy?: CertificateManagedBy | undefined;
}
export interface RequestCertificateResponse {
    CertificateArn?: string | undefined;
}
export interface ResendValidationEmailRequest {
    CertificateArn: string;
    Domain: string;
    ValidationDomain: string;
}
export interface ResendValidationEmailResponse {
}
export interface RevokeAcmeAccountRequest {
    AcmeEndpointArn: string;
    AccountUrl: string;
}
export interface RevokeAcmeAccountResponse {
}
export interface RevokeAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export interface RevokeAcmeExternalAccountBindingResponse {
}
export interface RevokeCertificateRequest {
    CertificateArn: string;
    RevocationReason: RevocationReason;
}
export interface RevokeCertificateResponse {
    CertificateArn?: string | undefined;
}
export type CertificateFilterStatementList = CertificateFilterStatement[];
export type FilterString = string;
export type ComparisonOperator = "CONTAINS" | "EQUALS" | (string & {});
export interface CommonNameFilter {
    Value: string;
    ComparisonOperator: ComparisonOperator;
}
export type SubjectFilter = {
    CommonName: CommonNameFilter;
};
export interface DnsNameFilter {
    Value: string;
    ComparisonOperator: ComparisonOperator;
}
export type SubjectAlternativeNameFilter = {
    DnsName: DnsNameFilter;
};
export type SerialNumber = string;
export interface TimestampRange {
    Start?: Date | undefined;
    End?: Date | undefined;
}
export type X509AttributeFilter = {
    Subject: SubjectFilter;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName: SubjectAlternativeNameFilter;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage: ExtendedKeyUsageName;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage: KeyUsageName;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm: KeyAlgorithm;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber: string;
    NotAfter?: undefined;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter: TimestampRange;
    NotBefore?: undefined;
} | {
    Subject?: undefined;
    SubjectAlternativeName?: undefined;
    ExtendedKeyUsage?: undefined;
    KeyUsage?: undefined;
    KeyAlgorithm?: undefined;
    SerialNumber?: undefined;
    NotAfter?: undefined;
    NotBefore: TimestampRange;
};
export type AcmCertificateMetadataFilter = {
    Status: CertificateStatus;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus: RenewalStatus;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type: CertificateType;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse: boolean;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported: boolean;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption: CertificateExport;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy: CertificateManagedBy;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod: ValidationMethod;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin: CertificateKeyPairOrigin;
    AcmeEndpointArn?: undefined;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn: string;
    AcmeAccountId?: undefined;
} | {
    Status?: undefined;
    RenewalStatus?: undefined;
    Type?: undefined;
    InUse?: undefined;
    Exported?: undefined;
    ExportOption?: undefined;
    ManagedBy?: undefined;
    ValidationMethod?: undefined;
    CertificateKeyPairOrigin?: undefined;
    AcmeEndpointArn?: undefined;
    AcmeAccountId: string;
};
export type CertificateFilter = {
    CertificateArn: string;
    X509AttributeFilter?: undefined;
    AcmCertificateMetadataFilter?: undefined;
} | {
    CertificateArn?: undefined;
    X509AttributeFilter: X509AttributeFilter;
    AcmCertificateMetadataFilter?: undefined;
} | {
    CertificateArn?: undefined;
    X509AttributeFilter?: undefined;
    AcmCertificateMetadataFilter: AcmCertificateMetadataFilter;
};
export type CertificateFilterStatement = {
    And: CertificateFilterStatement[];
    Or?: undefined;
    Not?: undefined;
    Filter?: undefined;
} | {
    And?: undefined;
    Or: CertificateFilterStatement[];
    Not?: undefined;
    Filter?: undefined;
} | {
    And?: undefined;
    Or?: undefined;
    Not: CertificateFilterStatement;
    Filter?: undefined;
} | {
    And?: undefined;
    Or?: undefined;
    Not?: undefined;
    Filter: CertificateFilter;
};
export type SearchMaxResults = number;
export type SearchCertificatesSortBy = "CREATED_AT" | "NOT_AFTER" | "STATUS" | "RENEWAL_STATUS" | "EXPORTED" | "IN_USE" | "NOT_BEFORE" | "KEY_ALGORITHM" | "TYPE" | "CERTIFICATE_ARN" | "COMMON_NAME" | "REVOKED_AT" | "RENEWAL_ELIGIBILITY" | "ISSUED_AT" | "MANAGED_BY" | "EXPORT_OPTION" | "VALIDATION_METHOD" | "IMPORTED_AT" | "ACME_ENDPOINT_ARN" | "ACME_ACCOUNT_ID" | "CERTIFICATE_KEY_PAIR_ORIGIN" | (string & {});
export type SearchCertificatesSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface SearchCertificatesRequest {
    FilterStatement?: CertificateFilterStatement | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    SortBy?: SearchCertificatesSortBy | undefined;
    SortOrder?: SearchCertificatesSortOrder | undefined;
}
export type DomainComponentList = string[];
export interface CustomAttribute {
    ObjectIdentifier?: string | undefined;
    Value?: string | undefined;
}
export type CustomAttributeList = CustomAttribute[];
export interface DistinguishedName {
    CommonName?: string | undefined;
    DomainComponents?: string[] | undefined;
    Country?: string | undefined;
    CustomAttributes?: CustomAttribute[] | undefined;
    DistinguishedNameQualifier?: string | undefined;
    GenerationQualifier?: string | undefined;
    GivenName?: string | undefined;
    Initials?: string | undefined;
    Locality?: string | undefined;
    Organization?: string | undefined;
    OrganizationalUnit?: string | undefined;
    Pseudonym?: string | undefined;
    SerialNumber?: string | undefined;
    State?: string | undefined;
    Surname?: string | undefined;
    Title?: string | undefined;
}
export interface OtherName {
    ObjectIdentifier?: string | undefined;
    Value?: string | undefined;
}
export type GeneralName = {
    DirectoryName: DistinguishedName;
    DnsName?: undefined;
    IpAddress?: undefined;
    OtherName?: undefined;
    RegisteredId?: undefined;
    Rfc822Name?: undefined;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName: string;
    IpAddress?: undefined;
    OtherName?: undefined;
    RegisteredId?: undefined;
    Rfc822Name?: undefined;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName?: undefined;
    IpAddress: string;
    OtherName?: undefined;
    RegisteredId?: undefined;
    Rfc822Name?: undefined;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName?: undefined;
    IpAddress?: undefined;
    OtherName: OtherName;
    RegisteredId?: undefined;
    Rfc822Name?: undefined;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName?: undefined;
    IpAddress?: undefined;
    OtherName?: undefined;
    RegisteredId: string;
    Rfc822Name?: undefined;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName?: undefined;
    IpAddress?: undefined;
    OtherName?: undefined;
    RegisteredId?: undefined;
    Rfc822Name: string;
    UniformResourceIdentifier?: undefined;
} | {
    DirectoryName?: undefined;
    DnsName?: undefined;
    IpAddress?: undefined;
    OtherName?: undefined;
    RegisteredId?: undefined;
    Rfc822Name?: undefined;
    UniformResourceIdentifier: string;
};
export type GeneralNameList = GeneralName[];
export interface X509Attributes {
    Issuer?: DistinguishedName | undefined;
    Subject?: DistinguishedName | undefined;
    SubjectAlternativeNames?: GeneralName[] | undefined;
    ExtendedKeyUsages?: ExtendedKeyUsageName[] | undefined;
    KeyAlgorithm?: KeyAlgorithm | undefined;
    KeyUsages?: KeyUsageName[] | undefined;
    SerialNumber?: string | undefined;
    NotAfter?: Date | undefined;
    NotBefore?: Date | undefined;
}
export interface AcmCertificateMetadata {
    CreatedAt?: Date | undefined;
    Exported?: boolean | undefined;
    ImportedAt?: Date | undefined;
    InUse?: boolean | undefined;
    IssuedAt?: Date | undefined;
    RenewalEligibility?: RenewalEligibility | undefined;
    RevokedAt?: Date | undefined;
    Status?: CertificateStatus | undefined;
    RenewalStatus?: RenewalStatus | undefined;
    Type?: CertificateType | undefined;
    ExportOption?: CertificateExport | undefined;
    ManagedBy?: CertificateManagedBy | undefined;
    ValidationMethod?: ValidationMethod | undefined;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin | undefined;
    AcmeEndpointArn?: string | undefined;
    AcmeAccountId?: string | undefined;
}
export type CertificateMetadata = {
    AcmCertificateMetadata: AcmCertificateMetadata;
};
export interface CertificateSearchResult {
    CertificateArn?: string | undefined;
    X509Attributes?: X509Attributes | undefined;
    CertificateMetadata?: CertificateMetadata | undefined;
}
export type CertificateSearchResultList = CertificateSearchResult[];
export interface SearchCertificatesResponse {
    Results?: CertificateSearchResult[] | undefined;
    NextToken?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
    PrevalidationOptions?: PrevalidationOptions | undefined;
}
export interface UpdateAcmeDomainValidationResponse {
}
export interface UpdateAcmeEndpointRequest {
    AcmeEndpointArn: string;
    AuthorizationBehavior?: AcmeAuthorizationBehavior | undefined;
    Contact?: AcmeContact | undefined;
    CertificateAuthority?: CertificateAuthority | undefined;
}
export interface UpdateAcmeEndpointResponse {
}
export interface UpdateCertificateOptionsRequest {
    CertificateArn: string;
    Options: CertificateOptions;
}
export interface UpdateCertificateOptionsResponse {
}
export type AvailabilityErrorMessage = string;
export type CoralAvailabilityThrottlingReason = string;
export type CoralAvailabilityThrottledResource = string;
export interface ThrottlingReason {
    reason?: string | undefined;
    resource?: string | undefined;
}
export type ThrottlingReasonList = ThrottlingReason[];
export type ValidationExceptionMessage = string;
export type ServiceErrorMessage = string;
export type AddTagsToCertificateError = InvalidArnException | InvalidParameterException | InvalidTagException | ResourceNotFoundException | TagPolicyException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to an ACM certificate. Tags are labels that you can use to identify and organize your Amazon Web Services resources. Each tag consists of a `key` and an optional `value`. You specify the certificate on input by its Amazon Resource Name (ARN). You specify the tag by using a key-value pair.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use TagResource instead.
 *
 * You can apply a tag to just one certificate if you want to identify a specific characteristic of that certificate, or you can apply the same tag to multiple certificates if you want to filter for a common relationship among those certificates. Similarly, you can apply the same tag to multiple resources if you want to specify a relationship among those resources. For example, you can add the same tag to an ACM certificate and an Elastic Load Balancing load balancer to indicate that they are both used by the same website. For more information, see Tagging ACM certificates.
 *
 * To remove one or more tags, use the RemoveTagsFromCertificate action. To view all of the tags that have been applied to the certificate, use the ListTagsForCertificate action.
 */
export declare const addTagsToCertificate: API.OperationMethod<AddTagsToCertificateRequest & RegionInput, AddTagsToCertificateResponse, AddTagsToCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain validation for an ACME endpoint. Domain validations authorize the endpoint to issue certificates for specified domain names. You configure prevalidation to prove domain ownership.
 */
export declare const createAcmeDomainValidation: API.OperationMethod<CreateAcmeDomainValidationRequest & RegionInput, CreateAcmeDomainValidationResponse, CreateAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ACME endpoint, which is a managed ACME server with a unique endpoint URL. After creation, ACME clients can use the endpoint URL to automate certificate issuance using the ACME protocol.
 */
export declare const createAcmeEndpoint: API.OperationMethod<CreateAcmeEndpointRequest & RegionInput, CreateAcmeEndpointResponse, CreateAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeExternalAccountBindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an external account binding (EAB) for an ACME endpoint. An EAB provides credentials that authorize an ACME client to register an account with the endpoint. Each EAB is associated with an IAM role that controls what certificate operations the ACME client can perform.
 */
export declare const createAcmeExternalAccountBinding: API.OperationMethod<CreateAcmeExternalAccountBindingRequest & RegionInput, CreateAcmeExternalAccountBindingResponse, CreateAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a domain validation. After deletion, the ACME endpoint can no longer issue certificates for the associated domain.
 */
export declare const deleteAcmeDomainValidation: API.OperationMethod<DeleteAcmeDomainValidationRequest & RegionInput, DeleteAcmeDomainValidationResponse, DeleteAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ACME endpoint. After deletion, the endpoint URL is no longer accessible and ACME clients cannot issue certificates through it. Any existing external account bindings and domain validations associated with the endpoint are also deleted.
 */
export declare const deleteAcmeEndpoint: API.OperationMethod<DeleteAcmeEndpointRequest & RegionInput, DeleteAcmeEndpointResponse, DeleteAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeExternalAccountBindingError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an external account binding. Previously fetched credentials for this binding will no longer be usable for account registration. A deleted binding cannot be recovered.
 */
export declare const deleteAcmeExternalAccountBinding: API.OperationMethod<DeleteAcmeExternalAccountBindingRequest & RegionInput, DeleteAcmeExternalAccountBindingResponse, DeleteAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = AccessDeniedException | ConflictException | InvalidArnException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a certificate and its associated private key. If this action succeeds, the certificate is not available for use by Amazon Web Services services integrated with ACM. Deleting a certificate is eventually consistent. The may be a short delay before the certificate no longer appears in the list that can be displayed by calling the ListCertificates action or be retrieved by calling the GetCertificate action.
 *
 * You cannot delete an ACM certificate that is being used by another Amazon Web Services service. To delete a certificate that is in use, you must first remove the certificate association using the console or the CLI for the associated service.
 *
 * Deleting a certificate issued by a private certificate authority (CA) has no effect on the CA. You will continue to be charged for the CA until it is deleted. For more information, see Deleting Your Private CA in the *Private Certificate Authority User Guide*.
 *
 * You cannot delete a certificate with a `CertificateKeyPairOrigin` of `ACME`. ACM automatically deletes these certificates 1 year after they expire.
 *
 * Deleting a certificate issued by a private certificate authority (CA) has no effect on the CA. You will continue to be charged for the CA until it is deleted. For more information, see Deleting your private CA in the *Amazon Web Services Private Certificate Authority User Guide*.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateRequest & RegionInput, DeleteCertificateResponse, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeAccountError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACME account, including its status, public key thumbprint, and associated external account binding.
 */
export declare const describeAcmeAccount: API.OperationMethod<DescribeAcmeAccountRequest & RegionInput, DescribeAcmeAccountResponse, DescribeAcmeAccountError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeDomainValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified domain validation, including its status, domain scope, and DNS resource records required for validation.
 */
export declare const describeAcmeDomainValidation: API.OperationMethod<DescribeAcmeDomainValidationRequest & RegionInput, DescribeAcmeDomainValidationResponse, DescribeAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACME endpoint, including its status, URL, authorization behavior, and certificate authority configuration.
 */
export declare const describeAcmeEndpoint: API.OperationMethod<DescribeAcmeEndpointRequest & RegionInput, DescribeAcmeEndpointResponse, DescribeAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeExternalAccountBindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified external account binding, including the associated IAM role, expiration time, and usage history.
 */
export declare const describeAcmeExternalAccountBinding: API.OperationMethod<DescribeAcmeExternalAccountBindingRequest & RegionInput, DescribeAcmeExternalAccountBindingResponse, DescribeAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateError = InvalidArnException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACM certificate.
 *
 * If you have just created a certificate using the `RequestCertificate` action, there is a delay of several seconds before you can retrieve information about it.
 */
export declare const describeCertificate: API.OperationMethod<DescribeCertificateRequest & RegionInput, DescribeCertificateResponse, DescribeCertificateError, Credentials | HttpClient.HttpClient>;
export type ExportCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports a private certificate issued by a private certificate authority (CA) or a public certificate for use anywhere. The exported file contains the certificate, the certificate chain, and the encrypted private key associated with the public key that is embedded in the certificate. For security, you must assign a passphrase for the private key when exporting it.
 *
 * For information about exporting and formatting a certificate using the ACM console or CLI, see Export a private certificate and Export a public certificate.
 *
 * ACM public certificates created prior to June 17, 2025 cannot be exported.
 */
export declare const exportCertificate: API.OperationMethod<ExportCertificateRequest & RegionInput, ExportCertificateResponse, ExportCertificateError, Credentials | HttpClient.HttpClient>;
export type GetAccountConfigurationError = AccessDeniedException | ThrottlingException | CommonErrors;
/**
 * Returns the account configuration options associated with an Amazon Web Services account.
 */
export declare const getAccountConfiguration: API.OperationMethod<GetAccountConfigurationRequest & RegionInput, GetAccountConfigurationResponse, GetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAcmeExternalAccountBindingCredentialsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the key ID and MAC key credentials for an external account binding. These credentials are used by ACME clients during account registration to bind to the endpoint.
 */
export declare const getAcmeExternalAccountBindingCredentials: API.OperationMethod<GetAcmeExternalAccountBindingCredentialsRequest & RegionInput, GetAcmeExternalAccountBindingCredentialsResponse, GetAcmeExternalAccountBindingCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a certificate and its certificate chain. The certificate may be either a public or private certificate issued using the ACM `RequestCertificate` action, or a certificate imported into ACM using the `ImportCertificate` action. The chain consists of the certificate of the issuing CA and the intermediate certificates of any other subordinate CAs. All of the certificates are base64 encoded. You can use OpenSSL to decode the certificates and inspect individual fields.
 */
export declare const getCertificate: API.OperationMethod<GetCertificateRequest & RegionInput, GetCertificateResponse, GetCertificateError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateError = ConflictException | InvalidArnException | InvalidParameterException | InvalidTagException | LimitExceededException | ResourceNotFoundException | TagPolicyException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Imports a certificate into Certificate Manager (ACM) to use with services that are integrated with ACM. Note that integrated services allow only certificate types and keys they support to be associated with their resources. Further, their support differs depending on whether the certificate is imported into IAM or into ACM. For more information, see the documentation for each service. For more information about importing certificates into ACM, see Importing Certificates in the *Certificate Manager User Guide*.
 *
 * ACM does not provide managed renewal for certificates that you import.
 *
 * Note the following guidelines when importing third party certificates:
 *
 * - You must enter the private key that matches the certificate you are importing.
 *
 * - The private key must be unencrypted. You cannot import a private key that is protected by a password or a passphrase.
 *
 * - The private key must be no larger than 5 KB (5,120 bytes).
 *
 * - The certificate, private key, and certificate chain must be PEM-encoded.
 *
 * - The current time must be between the `Not Before` and `Not After` certificate fields.
 *
 * - The `Issuer` field must not be empty.
 *
 * - The OCSP authority URL, if present, must not exceed 1000 characters.
 *
 * - To import a new certificate, omit the `CertificateArn` argument. Include this argument only when you want to replace a previously imported certificate.
 *
 * - When you import a certificate by using the CLI, you must specify the certificate, the certificate chain, and the private key by their file names preceded by `fileb://`. For example, you can specify a certificate saved in the `C:\temp` folder as `fileb://C:\temp\certificate_to_import.pem`. If you are making an HTTP or HTTPS Query request, include these arguments as BLOBs.
 *
 * - When you import a certificate by using an SDK, you must specify the certificate, the certificate chain, and the private key files in the manner required by the programming language you're using.
 *
 * - The cryptographic algorithm of an imported certificate must match the algorithm of the signing CA. For example, if the signing CA key type is RSA, then the certificate key type must also be RSA.
 *
 * This operation returns the Amazon Resource Name (ARN) of the imported certificate.
 */
export declare const importCertificate: API.OperationMethod<ImportCertificateRequest & RegionInput, ImportCertificateResponse, ImportCertificateError, Credentials | HttpClient.HttpClient>;
export type ListAcmeAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of ACME accounts registered with the specified ACME endpoint. ACME accounts are created when clients use external account binding credentials to register.
 */
export declare const listAcmeAccounts: API.PaginatedOperationMethod<ListAcmeAccountsRequest & RegionInput, ListAcmeAccountsResponse, ListAcmeAccountsError, Credentials | HttpClient.HttpClient, AcmeAccountSummary>;
export type ListAcmeDomainValidationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of domain validations for the specified ACME endpoint.
 */
export declare const listAcmeDomainValidations: API.PaginatedOperationMethod<ListAcmeDomainValidationsRequest & RegionInput, ListAcmeDomainValidationsResponse, ListAcmeDomainValidationsError, Credentials | HttpClient.HttpClient, AcmeDomainValidationSummary>;
export type ListAcmeEndpointsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of ACME endpoints in your account. Use this operation to view all configured ACME endpoints and their current status.
 */
export declare const listAcmeEndpoints: API.PaginatedOperationMethod<ListAcmeEndpointsRequest & RegionInput, ListAcmeEndpointsResponse, ListAcmeEndpointsError, Credentials | HttpClient.HttpClient, AcmeEndpointSummary>;
export type ListAcmeExternalAccountBindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of external account bindings for the specified ACME endpoint.
 */
export declare const listAcmeExternalAccountBindings: API.PaginatedOperationMethod<ListAcmeExternalAccountBindingsRequest & RegionInput, ListAcmeExternalAccountBindingsResponse, ListAcmeExternalAccountBindingsError, Credentials | HttpClient.HttpClient, AcmeExternalAccountBindingSummary>;
export type ListCertificateDomainValidationsError = AccessDeniedException | InvalidArgsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns per-domain validation summaries for an ACM certificate. Each summary includes the domain name, the active validation configuration, and the requested validation configuration when a validation method migration is in progress. You can use the results to monitor the progress of an email-to-DNS validation migration and to retrieve the CNAME records required for DNS validation.
 */
export declare const listCertificateDomainValidations: API.PaginatedOperationMethod<ListCertificateDomainValidationsRequest & RegionInput, ListCertificateDomainValidationsResponse, ListCertificateDomainValidationsError, Credentials | HttpClient.HttpClient, DomainValidationSummary>;
export type ListCertificatesError = InvalidArgsException | ValidationException | CommonErrors;
/**
 * Retrieves a list of certificate ARNs and domain names. You can request that only certificates that match a specific status be listed. You can also filter by specific attributes of the certificate. Default filtering returns only `RSA_2048` certificates. For more information, see Filters.
 *
 * By default, this action does not return certificates with a `CertificateKeyPairOrigin` of `ACME`. To include ACME certificates, specify `ACME` in the `CertificateKeyPairOrigins` filter.
 */
export declare const listCertificates: API.PaginatedOperationMethod<ListCertificatesRequest & RegionInput, ListCertificatesResponse, ListCertificatesError, Credentials | HttpClient.HttpClient, CertificateSummary>;
export type ListTagsForCertificateError = InvalidArnException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags that have been applied to the ACM certificate. Use the certificate's Amazon Resource Name (ARN) to specify the certificate. To add a tag to an ACM certificate, use the AddTagsToCertificate action. To delete a tag, use the RemoveTagsFromCertificate action.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use ListTagsForResource instead.
 */
export declare const listTagsForCertificate: API.OperationMethod<ListTagsForCertificateRequest & RegionInput, ListTagsForCertificateResponse, ListTagsForCertificateError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with an ACM resource.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use ListTagsForCertificate instead.
 *
 * To add one or more tags, use the TagResource action. To remove one or more tags, use the UntagResource action.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountConfigurationError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or modifies account-level configurations in ACM.
 *
 * The supported configuration option is `DaysBeforeExpiry`. This option specifies the number of days prior to certificate expiration when ACM starts generating `EventBridge` events. ACM sends one event per day per certificate until the certificate expires. By default, accounts receive events starting 45 days before certificate expiration.
 */
export declare const putAccountConfiguration: API.OperationMethod<PutAccountConfigurationRequest & RegionInput, PutAccountConfigurationResponse, PutAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromCertificateError = InvalidArnException | InvalidParameterException | InvalidTagException | ResourceNotFoundException | TagPolicyException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove one or more tags from an ACM certificate. A tag consists of a key-value pair. If you do not specify the value portion of the tag when calling this function, the tag will be removed regardless of value. If you specify a value, the tag is removed only if it is associated with the specified value.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use UntagResource instead.
 *
 * To add tags to a certificate, use the AddTagsToCertificate action. To view all of the tags that have been applied to a specific ACM certificate, use the ListTagsForCertificate action.
 */
export declare const removeTagsFromCertificate: API.OperationMethod<RemoveTagsFromCertificateRequest & RegionInput, RemoveTagsFromCertificateResponse, RemoveTagsFromCertificateError, Credentials | HttpClient.HttpClient>;
export type RenewCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Renews an eligible ACM certificate. In order to renew your Amazon Web Services Private CA certificates with ACM, you must first grant the ACM service principal permission to do so. For more information, see Testing Managed Renewal in the ACM User Guide.
 */
export declare const renewCertificate: API.OperationMethod<RenewCertificateRequest & RegionInput, RenewCertificateResponse, RenewCertificateError, Credentials | HttpClient.HttpClient>;
export type RequestCertificateError = InvalidArnException | InvalidDomainValidationOptionsException | InvalidParameterException | InvalidTagException | LimitExceededException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Requests an ACM certificate for use with other Amazon Web Services services. To request an ACM certificate, you must specify a fully qualified domain name (FQDN) in the `DomainName` parameter. You can also specify additional FQDNs in the `SubjectAlternativeNames` parameter.
 *
 * If you are requesting a private certificate, domain validation is not required. If you are requesting a public certificate, each domain name that you specify must be validated to verify that you own or control the domain. You can use DNS validation or email validation. We recommend that you use DNS validation.
 *
 * ACM behavior differs from the RFC 6125 specification of the certificate validation process. ACM first checks for a Subject Alternative Name, and, if it finds one, ignores the common name (CN).
 *
 * After successful completion of the `RequestCertificate` action, there is a delay of several seconds before you can retrieve information about the new certificate.
 */
export declare const requestCertificate: API.OperationMethod<RequestCertificateRequest & RegionInput, RequestCertificateResponse, RequestCertificateError, Credentials | HttpClient.HttpClient>;
export type ResendValidationEmailError = InvalidArnException | InvalidDomainValidationOptionsException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resends the email that requests domain ownership validation. The domain owner or an authorized representative must approve the ACM certificate before it can be issued. The certificate can be approved by clicking a link in the mail to navigate to the Amazon certificate approval website and then clicking **I Approve**. However, the validation email can be blocked by spam filters. Therefore, if you do not receive the original mail, you can request that the mail be resent within 72 hours of requesting the ACM certificate. If more than 72 hours have elapsed since your original request or since your last attempt to resend validation mail, you must request a new certificate. For more information about setting up your contact email addresses, see Configure Email for your Domain.
 */
export declare const resendValidationEmail: API.OperationMethod<ResendValidationEmailRequest & RegionInput, ResendValidationEmailResponse, ResendValidationEmailError, Credentials | HttpClient.HttpClient>;
export type RevokeAcmeAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes an ACME account, preventing it from requesting or revoking certificates. This operation is irreversible.
 */
export declare const revokeAcmeAccount: API.OperationMethod<RevokeAcmeAccountRequest & RegionInput, RevokeAcmeAccountResponse, RevokeAcmeAccountError, Credentials | HttpClient.HttpClient>;
export type RevokeAcmeExternalAccountBindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes an external account binding, preventing new ACME accounts from being registered using this binding. Existing ACME accounts that were previously registered using the binding are not affected and must be revoked separately.
 */
export declare const revokeAcmeExternalAccountBinding: API.OperationMethod<RevokeAcmeExternalAccountBindingRequest & RegionInput, RevokeAcmeExternalAccountBindingResponse, RevokeAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type RevokeCertificateError = AccessDeniedException | ConflictException | InvalidArnException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes a public ACM certificate. You can only revoke certificates that have been previously exported.
 *
 * Once a certificate is revoked, you cannot reuse the certificate. Revoking a certificate is permanent.
 */
export declare const revokeCertificate: API.OperationMethod<RevokeCertificateRequest & RegionInput, RevokeCertificateResponse, RevokeCertificateError, Credentials | HttpClient.HttpClient>;
export type SearchCertificatesError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of certificates matching search criteria. You can filter certificates by X.509 attributes and ACM specific properties like certificate status, type and renewal eligibility. This operation provides more flexible filtering than ListCertificates by supporting complex filter statements.
 */
export declare const searchCertificates: API.PaginatedOperationMethod<SearchCertificatesRequest & RegionInput, SearchCertificatesResponse, SearchCertificatesError, Credentials | HttpClient.HttpClient, CertificateSearchResult>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to an ACM resource. Tags are labels that you can use to identify and organize your Amazon Web Services resources. Each tag consists of a `key` and an optional `value`.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use AddTagsToCertificate instead.
 *
 * To remove one or more tags, use the UntagResource action. To view all of the tags that have been applied to a resource, use the ListTagsForResource action.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from an ACM resource.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use RemoveTagsFromCertificate instead.
 *
 * To add one or more tags, use the TagResource action. To view all of the tags that have been applied to a resource, use the ListTagsForResource action.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the prevalidation configuration of an existing domain validation.
 */
export declare const updateAcmeDomainValidation: API.OperationMethod<UpdateAcmeDomainValidationRequest & RegionInput, UpdateAcmeDomainValidationResponse, UpdateAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type UpdateAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing ACME endpoint. You can change the authorization behavior, contact requirement, or certificate authority settings.
 */
export declare const updateAcmeEndpoint: API.OperationMethod<UpdateAcmeEndpointRequest & RegionInput, UpdateAcmeEndpointResponse, UpdateAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateCertificateOptionsError = ConflictException | InvalidArnException | InvalidStateException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates certificate options. You can use this operation to change the domain validation method or specify whether to export your certificate. For more information, see Migrate from email to DNS validation and Certificate Manager Exportable Managed Certificates.
 */
export declare const updateCertificateOptions: API.OperationMethod<UpdateCertificateOptionsRequest & RegionInput, UpdateCertificateOptionsResponse, UpdateCertificateOptionsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=acm.d.ts.map