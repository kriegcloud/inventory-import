import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Scope from "effect/Scope";
import { AlchemyContext } from "./AlchemyContext.ts";
import { type StackEffect } from "./Stack.ts";
import { Stage } from "./Stage.ts";
export declare const evalStack: <S extends {
    services: Context.Context<any>;
}, B, StackErr, Err, Req>(effect: StackEffect<S, StackErr, Stage | AlchemyContext>, fn: (stack: S) => Effect.Effect<B, Err, Req>, options: {
    stage: string;
    dev?: boolean;
    /**
     * Optional caller-supplied scope. When provided, scoped resources
     * (e.g. the dev sidecar process) live until the caller closes this
     * scope instead of being torn down when `evalStack` resolves. Used
     * by the test harness so the sidecar survives across `beforeAll`,
     * tests, and `afterAll`. When omitted, behaves as before with a
     * private scope closed on completion. The state store never outlives
     * the call.
     */
    scope?: Scope.Scope;
}) => Effect.Effect<B, Err | StackErr | import("effect/PlatformError").PlatformError, import("./Artifacts.ts").ArtifactStore | import("./index.ts").AuthProviders | import("./Interaction.ts").Interaction | import("./State/State.ts").State>;
//# sourceMappingURL=EvalStack.d.ts.map