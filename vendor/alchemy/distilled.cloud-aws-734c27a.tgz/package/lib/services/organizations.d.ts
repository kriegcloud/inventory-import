import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AccessDeniedForDependencyException_base: S.TaggedErrorClass<"AccessDeniedForDependencyException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedForDependencyException extends /*@__PURE__*/ AccessDeniedForDependencyException_base {
}
declare const AccountAlreadyClosedException_base: S.TaggedErrorClass<"AccountAlreadyClosedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AccountAlreadyClosedException extends /*@__PURE__*/ AccountAlreadyClosedException_base {
}
declare const AccountAlreadyRegisteredException_base: S.TaggedErrorClass<"AccountAlreadyRegisteredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AccountAlreadyRegisteredException extends /*@__PURE__*/ AccountAlreadyRegisteredException_base {
}
declare const AccountNotFoundException_base: S.TaggedErrorClass<"AccountNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotFoundException extends /*@__PURE__*/ AccountNotFoundException_base {
}
declare const AccountNotRegisteredException_base: S.TaggedErrorClass<"AccountNotRegisteredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AccountNotRegisteredException extends /*@__PURE__*/ AccountNotRegisteredException_base {
}
declare const AccountOwnerNotVerifiedException_base: S.TaggedErrorClass<"AccountOwnerNotVerifiedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccountOwnerNotVerifiedException extends /*@__PURE__*/ AccountOwnerNotVerifiedException_base {
}
declare const AlreadyInOrganizationException_base: S.TaggedErrorClass<"AlreadyInOrganizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AlreadyInOrganizationException extends /*@__PURE__*/ AlreadyInOrganizationException_base {
}
declare const AWSOrganizationsNotInUseException_base: S.TaggedErrorClass<"AWSOrganizationsNotInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AWSOrganizationsNotInUseException extends /*@__PURE__*/ AWSOrganizationsNotInUseException_base {
}
declare const ChildNotFoundException_base: S.TaggedErrorClass<"ChildNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChildNotFoundException extends /*@__PURE__*/ ChildNotFoundException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ConstraintViolationException_base: S.TaggedErrorClass<"ConstraintViolationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConstraintViolationException extends /*@__PURE__*/ ConstraintViolationException_base {
}
declare const CreateAccountStatusNotFoundException_base: S.TaggedErrorClass<"CreateAccountStatusNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CreateAccountStatusNotFoundException extends /*@__PURE__*/ CreateAccountStatusNotFoundException_base {
}
declare const DestinationParentNotFoundException_base: S.TaggedErrorClass<"DestinationParentNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DestinationParentNotFoundException extends /*@__PURE__*/ DestinationParentNotFoundException_base {
}
declare const DuplicateAccountException_base: S.TaggedErrorClass<"DuplicateAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateAccountException extends /*@__PURE__*/ DuplicateAccountException_base {
}
declare const DuplicateHandshakeException_base: S.TaggedErrorClass<"DuplicateHandshakeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateHandshakeException extends /*@__PURE__*/ DuplicateHandshakeException_base {
}
declare const DuplicateOrganizationalUnitException_base: S.TaggedErrorClass<"DuplicateOrganizationalUnitException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateOrganizationalUnitException extends /*@__PURE__*/ DuplicateOrganizationalUnitException_base {
}
declare const DuplicatePolicyAttachmentException_base: S.TaggedErrorClass<"DuplicatePolicyAttachmentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicatePolicyAttachmentException extends /*@__PURE__*/ DuplicatePolicyAttachmentException_base {
}
declare const DuplicatePolicyException_base: S.TaggedErrorClass<"DuplicatePolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicatePolicyException extends /*@__PURE__*/ DuplicatePolicyException_base {
}
declare const EffectivePolicyNotFoundException_base: S.TaggedErrorClass<"EffectivePolicyNotFoundException", {
    readonly message: any;
}>;
export declare class EffectivePolicyNotFoundException extends /*@__PURE__*/ EffectivePolicyNotFoundException_base {
}
declare const FinalizingOrganizationException_base: S.TaggedErrorClass<"FinalizingOrganizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class FinalizingOrganizationException extends /*@__PURE__*/ FinalizingOrganizationException_base {
}
declare const HandshakeAlreadyInStateException_base: S.TaggedErrorClass<"HandshakeAlreadyInStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class HandshakeAlreadyInStateException extends /*@__PURE__*/ HandshakeAlreadyInStateException_base {
}
declare const HandshakeConstraintViolationException_base: S.TaggedErrorClass<"HandshakeConstraintViolationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class HandshakeConstraintViolationException extends /*@__PURE__*/ HandshakeConstraintViolationException_base {
}
declare const HandshakeNotFoundException_base: S.TaggedErrorClass<"HandshakeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HandshakeNotFoundException extends /*@__PURE__*/ HandshakeNotFoundException_base {
}
declare const InvalidHandshakeTransitionException_base: S.TaggedErrorClass<"InvalidHandshakeTransitionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidHandshakeTransitionException extends /*@__PURE__*/ InvalidHandshakeTransitionException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidResponsibilityTransferTransitionException_base: S.TaggedErrorClass<"InvalidResponsibilityTransferTransitionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidResponsibilityTransferTransitionException extends /*@__PURE__*/ InvalidResponsibilityTransferTransitionException_base {
}
declare const MalformedPolicyDocumentException_base: S.TaggedErrorClass<"MalformedPolicyDocumentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedPolicyDocumentException extends /*@__PURE__*/ MalformedPolicyDocumentException_base {
}
declare const MasterCannotLeaveOrganizationException_base: S.TaggedErrorClass<"MasterCannotLeaveOrganizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class MasterCannotLeaveOrganizationException extends /*@__PURE__*/ MasterCannotLeaveOrganizationException_base {
}
declare const OrganizationalUnitNotEmptyException_base: S.TaggedErrorClass<"OrganizationalUnitNotEmptyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class OrganizationalUnitNotEmptyException extends /*@__PURE__*/ OrganizationalUnitNotEmptyException_base {
}
declare const OrganizationalUnitNotFoundException_base: S.TaggedErrorClass<"OrganizationalUnitNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationalUnitNotFoundException extends /*@__PURE__*/ OrganizationalUnitNotFoundException_base {
}
declare const OrganizationNotEmptyException_base: S.TaggedErrorClass<"OrganizationNotEmptyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class OrganizationNotEmptyException extends /*@__PURE__*/ OrganizationNotEmptyException_base {
}
declare const ParentNotFoundException_base: S.TaggedErrorClass<"ParentNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParentNotFoundException extends /*@__PURE__*/ ParentNotFoundException_base {
}
declare const PolicyChangesInProgressException_base: S.TaggedErrorClass<"PolicyChangesInProgressException", {
    readonly message: any;
}>;
export declare class PolicyChangesInProgressException extends /*@__PURE__*/ PolicyChangesInProgressException_base {
}
declare const PolicyInUseException_base: S.TaggedErrorClass<"PolicyInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PolicyInUseException extends /*@__PURE__*/ PolicyInUseException_base {
}
declare const PolicyNotAttachedException_base: S.TaggedErrorClass<"PolicyNotAttachedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PolicyNotAttachedException extends /*@__PURE__*/ PolicyNotAttachedException_base {
}
declare const PolicyNotFoundException_base: S.TaggedErrorClass<"PolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyNotFoundException extends /*@__PURE__*/ PolicyNotFoundException_base {
}
declare const PolicyTypeAlreadyEnabledException_base: S.TaggedErrorClass<"PolicyTypeAlreadyEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PolicyTypeAlreadyEnabledException extends /*@__PURE__*/ PolicyTypeAlreadyEnabledException_base {
}
declare const PolicyTypeNotAvailableForOrganizationException_base: S.TaggedErrorClass<"PolicyTypeNotAvailableForOrganizationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PolicyTypeNotAvailableForOrganizationException extends /*@__PURE__*/ PolicyTypeNotAvailableForOrganizationException_base {
}
declare const PolicyTypeNotEnabledException_base: S.TaggedErrorClass<"PolicyTypeNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class PolicyTypeNotEnabledException extends /*@__PURE__*/ PolicyTypeNotEnabledException_base {
}
declare const ResourcePolicyNotFoundException_base: S.TaggedErrorClass<"ResourcePolicyNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourcePolicyNotFoundException extends /*@__PURE__*/ ResourcePolicyNotFoundException_base {
}
declare const ResponsibilityTransferAlreadyInStatusException_base: S.TaggedErrorClass<"ResponsibilityTransferAlreadyInStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResponsibilityTransferAlreadyInStatusException extends /*@__PURE__*/ ResponsibilityTransferAlreadyInStatusException_base {
}
declare const ResponsibilityTransferNotFoundException_base: S.TaggedErrorClass<"ResponsibilityTransferNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResponsibilityTransferNotFoundException extends /*@__PURE__*/ ResponsibilityTransferNotFoundException_base {
}
declare const RootNotFoundException_base: S.TaggedErrorClass<"RootNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RootNotFoundException extends /*@__PURE__*/ RootNotFoundException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const SourceParentNotFoundException_base: S.TaggedErrorClass<"SourceParentNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceParentNotFoundException extends /*@__PURE__*/ SourceParentNotFoundException_base {
}
declare const TargetNotFoundException_base: S.TaggedErrorClass<"TargetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TargetNotFoundException extends /*@__PURE__*/ TargetNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedAPIEndpointException_base: S.TaggedErrorClass<"UnsupportedAPIEndpointException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnsupportedAPIEndpointException extends /*@__PURE__*/ UnsupportedAPIEndpointException_base {
}
export type HandshakeId = string;
export interface AcceptHandshakeRequest {
    HandshakeId: string;
}
export type HandshakeArn = string;
export type HandshakePartyId = string | redacted.Redacted<string>;
export type HandshakePartyType = "ACCOUNT" | "ORGANIZATION" | "EMAIL" | (string & {});
export interface HandshakeParty {
    Id: string | redacted.Redacted<string>;
    Type: HandshakePartyType;
}
export type HandshakeParties = HandshakeParty[];
export type HandshakeState = "REQUESTED" | "OPEN" | "CANCELED" | "ACCEPTED" | "DECLINED" | "EXPIRED" | (string & {});
export type ActionType = "INVITE" | "ENABLE_ALL_FEATURES" | "APPROVE_ALL_FEATURES" | "ADD_ORGANIZATIONS_SERVICE_LINKED_ROLE" | "TRANSFER_RESPONSIBILITY" | (string & {});
export type HandshakeResourceValue = string | redacted.Redacted<string>;
export type HandshakeResourceType = "ACCOUNT" | "ORGANIZATION" | "ORGANIZATION_FEATURE_SET" | "EMAIL" | "MASTER_EMAIL" | "MASTER_NAME" | "NOTES" | "PARENT_HANDSHAKE" | "RESPONSIBILITY_TRANSFER" | "TRANSFER_START_TIMESTAMP" | "TRANSFER_TYPE" | "MANAGEMENT_ACCOUNT" | "MANAGEMENT_EMAIL" | "MANAGEMENT_NAME" | (string & {});
export interface HandshakeResource {
    Value?: string | redacted.Redacted<string> | undefined;
    Type?: HandshakeResourceType | undefined;
    Resources?: HandshakeResource[] | undefined;
}
export type HandshakeResources = HandshakeResource[];
export interface Handshake {
    Id?: string | undefined;
    Arn?: string | undefined;
    Parties?: HandshakeParty[] | undefined;
    State?: HandshakeState | undefined;
    RequestedTimestamp?: Date | undefined;
    ExpirationTimestamp?: Date | undefined;
    Action?: ActionType | undefined;
    Resources?: HandshakeResource[] | undefined;
}
export interface AcceptHandshakeResponse {
    Handshake?: Handshake | undefined;
}
export type PolicyId = string;
export type PolicyTargetId = string;
export interface AttachPolicyRequest {
    PolicyId: string;
    TargetId: string;
}
export interface AttachPolicyResponse {
}
export interface CancelHandshakeRequest {
    HandshakeId: string;
}
export interface CancelHandshakeResponse {
    Handshake?: Handshake | undefined;
}
export type AccountId = string;
export interface CloseAccountRequest {
    AccountId: string;
}
export interface CloseAccountResponse {
}
export type Email = string | redacted.Redacted<string>;
export type CreateAccountName = string | redacted.Redacted<string>;
export type RoleName = string;
export type IAMUserAccessToBilling = "ALLOW" | "DENY" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export interface CreateAccountRequest {
    Email: string | redacted.Redacted<string>;
    AccountName: string | redacted.Redacted<string>;
    RoleName?: string | undefined;
    IamUserAccessToBilling?: IAMUserAccessToBilling | undefined;
    Tags?: Tag[] | undefined;
}
export type CreateAccountRequestId = string;
export type CreateAccountState = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type CreateAccountFailureReason = "ACCOUNT_LIMIT_EXCEEDED" | "EMAIL_ALREADY_EXISTS" | "INVALID_ADDRESS" | "INVALID_EMAIL" | "CONCURRENT_ACCOUNT_MODIFICATION" | "INTERNAL_FAILURE" | "GOVCLOUD_ACCOUNT_ALREADY_EXISTS" | "MISSING_BUSINESS_VALIDATION" | "FAILED_BUSINESS_VALIDATION" | "PENDING_BUSINESS_VALIDATION" | "INVALID_IDENTITY_FOR_BUSINESS_VALIDATION" | "UNKNOWN_BUSINESS_VALIDATION" | "MISSING_PAYMENT_INSTRUMENT" | "INVALID_PAYMENT_INSTRUMENT" | "UPDATE_EXISTING_RESOURCE_POLICY_WITH_TAGS_NOT_SUPPORTED" | (string & {});
export interface CreateAccountStatus {
    Id?: string | undefined;
    AccountName?: string | redacted.Redacted<string> | undefined;
    State?: CreateAccountState | undefined;
    RequestedTimestamp?: Date | undefined;
    CompletedTimestamp?: Date | undefined;
    AccountId?: string | undefined;
    GovCloudAccountId?: string | undefined;
    FailureReason?: CreateAccountFailureReason | undefined;
}
export interface CreateAccountResponse {
    CreateAccountStatus?: CreateAccountStatus | undefined;
}
export interface CreateGovCloudAccountRequest {
    Email: string | redacted.Redacted<string>;
    AccountName: string | redacted.Redacted<string>;
    RoleName?: string | undefined;
    IamUserAccessToBilling?: IAMUserAccessToBilling | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateGovCloudAccountResponse {
    CreateAccountStatus?: CreateAccountStatus | undefined;
}
export type OrganizationFeatureSet = "ALL" | "CONSOLIDATED_BILLING" | (string & {});
export interface CreateOrganizationRequest {
    FeatureSet?: OrganizationFeatureSet | undefined;
}
export type OrganizationId = string;
export type OrganizationArn = string;
export type AccountArn = string;
export type PolicyType = "SERVICE_CONTROL_POLICY" | "RESOURCE_CONTROL_POLICY" | "TAG_POLICY" | "BACKUP_POLICY" | "AISERVICES_OPT_OUT_POLICY" | "CHATBOT_POLICY" | "DECLARATIVE_POLICY_EC2" | "SECURITYHUB_POLICY" | "SECURITYHUB_CSPM_POLICY" | "INSPECTOR_POLICY" | "UPGRADE_ROLLOUT_POLICY" | "BEDROCK_POLICY" | "S3_POLICY" | "NETWORK_SECURITY_DIRECTOR_POLICY" | "GUARDDUTY_POLICY" | (string & {});
export type PolicyTypeStatus = "ENABLED" | "PENDING_ENABLE" | "PENDING_DISABLE" | (string & {});
export interface PolicyTypeSummary {
    Type?: PolicyType | undefined;
    Status?: PolicyTypeStatus | undefined;
}
export type PolicyTypes = PolicyTypeSummary[];
export interface Organization {
    Id?: string | undefined;
    Arn?: string | undefined;
    FeatureSet?: OrganizationFeatureSet | undefined;
    MasterAccountArn?: string | undefined;
    MasterAccountId?: string | undefined;
    MasterAccountEmail?: string | redacted.Redacted<string> | undefined;
    AvailablePolicyTypes?: PolicyTypeSummary[] | undefined;
}
export interface CreateOrganizationResponse {
    Organization?: Organization | undefined;
}
export type ParentId = string;
export type OrganizationalUnitName = string;
export interface CreateOrganizationalUnitRequest {
    ParentId: string;
    Name: string;
    Tags?: Tag[] | undefined;
}
export type OrganizationalUnitId = string;
export type OrganizationalUnitArn = string;
export type Path = string;
export interface OrganizationalUnit {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Path?: string | undefined;
}
export interface CreateOrganizationalUnitResponse {
    OrganizationalUnit?: OrganizationalUnit | undefined;
}
export type PolicyContent = string;
export type PolicyDescription = string;
export type PolicyName = string;
export interface CreatePolicyRequest {
    Content: string;
    Description: string;
    Name: string;
    Type: PolicyType;
    Tags?: Tag[] | undefined;
}
export type PolicyArn = string;
export type AwsManagedPolicy = boolean;
export interface PolicySummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Type?: PolicyType | undefined;
    AwsManaged?: boolean | undefined;
}
export interface Policy {
    PolicySummary?: PolicySummary | undefined;
    Content?: string | undefined;
}
export interface CreatePolicyResponse {
    Policy?: Policy | undefined;
}
export interface DeclineHandshakeRequest {
    HandshakeId: string;
}
export interface DeclineHandshakeResponse {
    Handshake?: Handshake | undefined;
}
export interface DeleteOrganizationRequest {
}
export interface DeleteOrganizationResponse {
}
export interface DeleteOrganizationalUnitRequest {
    OrganizationalUnitId: string;
}
export interface DeleteOrganizationalUnitResponse {
}
export interface DeletePolicyRequest {
    PolicyId: string;
}
export interface DeletePolicyResponse {
}
export interface DeleteResourcePolicyRequest {
}
export interface DeleteResourcePolicyResponse {
}
export type ServicePrincipal = string;
export interface DeregisterDelegatedAdministratorRequest {
    AccountId: string;
    ServicePrincipal: string;
}
export interface DeregisterDelegatedAdministratorResponse {
}
export interface DescribeAccountRequest {
    AccountId: string;
}
export type AccountName = string | redacted.Redacted<string>;
export type AccountStatus = "ACTIVE" | "SUSPENDED" | "PENDING_CLOSURE" | (string & {});
export type AccountState = "PENDING_ACTIVATION" | "ACTIVE" | "SUSPENDED" | "PENDING_CLOSURE" | "CLOSED" | (string & {});
export type Paths = string[];
export type AccountJoinedMethod = "INVITED" | "CREATED" | (string & {});
export interface Account {
    Id?: string | undefined;
    Arn?: string | undefined;
    Email?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Status?: AccountStatus | undefined;
    State?: AccountState | undefined;
    Paths?: string[] | undefined;
    JoinedMethod?: AccountJoinedMethod | undefined;
    JoinedTimestamp?: Date | undefined;
}
export interface DescribeAccountResponse {
    Account?: Account | undefined;
}
export interface DescribeCreateAccountStatusRequest {
    CreateAccountRequestId: string;
}
export interface DescribeCreateAccountStatusResponse {
    CreateAccountStatus?: CreateAccountStatus | undefined;
}
export type EffectivePolicyType = "TAG_POLICY" | "BACKUP_POLICY" | "AISERVICES_OPT_OUT_POLICY" | "CHATBOT_POLICY" | "DECLARATIVE_POLICY_EC2" | "SECURITYHUB_POLICY" | "SECURITYHUB_CSPM_POLICY" | "INSPECTOR_POLICY" | "UPGRADE_ROLLOUT_POLICY" | "BEDROCK_POLICY" | "S3_POLICY" | "NETWORK_SECURITY_DIRECTOR_POLICY" | "GUARDDUTY_POLICY" | (string & {});
export interface DescribeEffectivePolicyRequest {
    PolicyType: EffectivePolicyType;
    TargetId?: string | undefined;
}
export interface EffectivePolicy {
    PolicyContent?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    TargetId?: string | undefined;
    PolicyType?: EffectivePolicyType | undefined;
}
export interface DescribeEffectivePolicyResponse {
    EffectivePolicy?: EffectivePolicy | undefined;
}
export interface DescribeHandshakeRequest {
    HandshakeId: string;
}
export interface DescribeHandshakeResponse {
    Handshake?: Handshake | undefined;
}
export interface DescribeOrganizationRequest {
}
export interface DescribeOrganizationResponse {
    Organization?: Organization | undefined;
}
export interface DescribeOrganizationalUnitRequest {
    OrganizationalUnitId: string;
}
export interface DescribeOrganizationalUnitResponse {
    OrganizationalUnit?: OrganizationalUnit | undefined;
}
export interface DescribePolicyRequest {
    PolicyId: string;
}
export interface DescribePolicyResponse {
    Policy?: Policy | undefined;
}
export interface DescribeResourcePolicyRequest {
}
export type ResourcePolicyId = string;
export type ResourcePolicyArn = string;
export interface ResourcePolicySummary {
    Id?: string | undefined;
    Arn?: string | undefined;
}
export type ResourcePolicyContent = string;
export interface ResourcePolicy {
    ResourcePolicySummary?: ResourcePolicySummary | undefined;
    Content?: string | undefined;
}
export interface DescribeResourcePolicyResponse {
    ResourcePolicy?: ResourcePolicy | undefined;
}
export type ResponsibilityTransferId = string;
export interface DescribeResponsibilityTransferRequest {
    Id: string;
}
export type ResponsibilityTransferArn = string;
export type ResponsibilityTransferName = string | redacted.Redacted<string>;
export type ResponsibilityTransferType = "BILLING" | (string & {});
export type ResponsibilityTransferStatus = "REQUESTED" | "DECLINED" | "CANCELED" | "EXPIRED" | "ACCEPTED" | "WITHDRAWN" | (string & {});
export interface TransferParticipant {
    ManagementAccountId?: string | undefined;
    ManagementAccountEmail?: string | redacted.Redacted<string> | undefined;
}
export interface ResponsibilityTransfer {
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Id?: string | undefined;
    Type?: ResponsibilityTransferType | undefined;
    Status?: ResponsibilityTransferStatus | undefined;
    Source?: TransferParticipant | undefined;
    Target?: TransferParticipant | undefined;
    StartTimestamp?: Date | undefined;
    EndTimestamp?: Date | undefined;
    ActiveHandshakeId?: string | undefined;
}
export interface DescribeResponsibilityTransferResponse {
    ResponsibilityTransfer?: ResponsibilityTransfer | undefined;
}
export interface DetachPolicyRequest {
    PolicyId: string;
    TargetId: string;
}
export interface DetachPolicyResponse {
}
export interface DisableAWSServiceAccessRequest {
    ServicePrincipal: string;
}
export interface DisableAWSServiceAccessResponse {
}
export type RootId = string;
export interface DisablePolicyTypeRequest {
    RootId: string;
    PolicyType: PolicyType;
}
export type RootArn = string;
export type RootName = string;
export interface Root {
    Id?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    PolicyTypes?: PolicyTypeSummary[] | undefined;
}
export interface DisablePolicyTypeResponse {
    Root?: Root | undefined;
}
export interface EnableAllFeaturesRequest {
}
export interface EnableAllFeaturesResponse {
    Handshake?: Handshake | undefined;
}
export interface EnableAWSServiceAccessRequest {
    ServicePrincipal: string;
}
export interface EnableAWSServiceAccessResponse {
}
export interface EnablePolicyTypeRequest {
    RootId: string;
    PolicyType: PolicyType;
}
export interface EnablePolicyTypeResponse {
    Root?: Root | undefined;
}
export type HandshakeNotes = string | redacted.Redacted<string>;
export interface InviteAccountToOrganizationRequest {
    Target: HandshakeParty;
    Notes?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export interface InviteAccountToOrganizationResponse {
    Handshake?: Handshake | undefined;
}
export interface InviteOrganizationToTransferResponsibilityRequest {
    Type: ResponsibilityTransferType;
    Target: HandshakeParty;
    Notes?: string | redacted.Redacted<string> | undefined;
    StartTimestamp: Date;
    SourceName: string | redacted.Redacted<string>;
    Tags?: Tag[] | undefined;
}
export interface InviteOrganizationToTransferResponsibilityResponse {
    Handshake?: Handshake | undefined;
}
export interface LeaveOrganizationRequest {
}
export interface LeaveOrganizationResponse {
}
export type NextToken = string;
export type MaxResults = number;
export interface ListAccountsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Accounts = Account[];
export interface ListAccountsResponse {
    Accounts?: Account[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAccountsForParentRequest {
    ParentId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListAccountsForParentResponse {
    Accounts?: Account[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAccountsWithInvalidEffectivePolicyRequest {
    PolicyType: EffectivePolicyType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListAccountsWithInvalidEffectivePolicyResponse {
    Accounts?: Account[] | undefined;
    PolicyType?: EffectivePolicyType | undefined;
    NextToken?: string | undefined;
}
export interface ListAWSServiceAccessForOrganizationRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EnabledServicePrincipal {
    ServicePrincipal?: string | undefined;
    DateEnabled?: Date | undefined;
}
export type EnabledServicePrincipals = EnabledServicePrincipal[];
export interface ListAWSServiceAccessForOrganizationResponse {
    EnabledServicePrincipals?: EnabledServicePrincipal[] | undefined;
    NextToken?: string | undefined;
}
export type ChildType = "ACCOUNT" | "ORGANIZATIONAL_UNIT" | (string & {});
export interface ListChildrenRequest {
    ParentId: string;
    ChildType: ChildType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ChildId = string;
export interface Child {
    Id?: string | undefined;
    Type?: ChildType | undefined;
}
export type Children = Child[];
export interface ListChildrenResponse {
    Children?: Child[] | undefined;
    NextToken?: string | undefined;
}
export type CreateAccountStates = CreateAccountState[];
export interface ListCreateAccountStatusRequest {
    States?: CreateAccountState[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type CreateAccountStatuses = CreateAccountStatus[];
export interface ListCreateAccountStatusResponse {
    CreateAccountStatuses?: CreateAccountStatus[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDelegatedAdministratorsRequest {
    ServicePrincipal?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DelegatedAdministrator {
    Id?: string | undefined;
    Arn?: string | undefined;
    Email?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Status?: AccountStatus | undefined;
    State?: AccountState | undefined;
    JoinedMethod?: AccountJoinedMethod | undefined;
    JoinedTimestamp?: Date | undefined;
    DelegationEnabledDate?: Date | undefined;
}
export type DelegatedAdministrators = DelegatedAdministrator[];
export interface ListDelegatedAdministratorsResponse {
    DelegatedAdministrators?: DelegatedAdministrator[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDelegatedServicesForAccountRequest {
    AccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DelegatedService {
    ServicePrincipal?: string | undefined;
    DelegationEnabledDate?: Date | undefined;
}
export type DelegatedServices = DelegatedService[];
export interface ListDelegatedServicesForAccountResponse {
    DelegatedServices?: DelegatedService[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEffectivePolicyValidationErrorsRequest {
    AccountId: string;
    PolicyType: EffectivePolicyType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ErrorCode = string;
export type ErrorMessage = string;
export type PathToError = string;
export type PolicyIds = string[];
export interface EffectivePolicyValidationError {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
    PathToError?: string | undefined;
    ContributingPolicies?: string[] | undefined;
}
export type EffectivePolicyValidationErrors = EffectivePolicyValidationError[];
export interface ListEffectivePolicyValidationErrorsResponse {
    AccountId?: string | undefined;
    PolicyType?: EffectivePolicyType | undefined;
    Path?: string | undefined;
    EvaluationTimestamp?: Date | undefined;
    NextToken?: string | undefined;
    EffectivePolicyValidationErrors?: EffectivePolicyValidationError[] | undefined;
}
export interface HandshakeFilter {
    ActionType?: ActionType | undefined;
    ParentHandshakeId?: string | undefined;
}
export interface ListHandshakesForAccountRequest {
    Filter?: HandshakeFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Handshakes = Handshake[];
export interface ListHandshakesForAccountResponse {
    Handshakes?: Handshake[] | undefined;
    NextToken?: string | undefined;
}
export interface ListHandshakesForOrganizationRequest {
    Filter?: HandshakeFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListHandshakesForOrganizationResponse {
    Handshakes?: Handshake[] | undefined;
    NextToken?: string | undefined;
}
export interface ListInboundResponsibilityTransfersRequest {
    Type: ResponsibilityTransferType;
    Id?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ResponsibilityTransfers = ResponsibilityTransfer[];
export interface ListInboundResponsibilityTransfersResponse {
    ResponsibilityTransfers?: ResponsibilityTransfer[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOrganizationalUnitsForParentRequest {
    ParentId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type OrganizationalUnits = OrganizationalUnit[];
export interface ListOrganizationalUnitsForParentResponse {
    OrganizationalUnits?: OrganizationalUnit[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOutboundResponsibilityTransfersRequest {
    Type: ResponsibilityTransferType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListOutboundResponsibilityTransfersResponse {
    ResponsibilityTransfers?: ResponsibilityTransfer[] | undefined;
    NextToken?: string | undefined;
}
export interface ListParentsRequest {
    ChildId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ParentType = "ROOT" | "ORGANIZATIONAL_UNIT" | (string & {});
export interface Parent {
    Id?: string | undefined;
    Type?: ParentType | undefined;
}
export type Parents = Parent[];
export interface ListParentsResponse {
    Parents?: Parent[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPoliciesRequest {
    Filter: PolicyType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Policies = PolicySummary[];
export interface ListPoliciesResponse {
    Policies?: PolicySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPoliciesForTargetRequest {
    TargetId: string;
    Filter: PolicyType;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListPoliciesForTargetResponse {
    Policies?: PolicySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRootsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Roots = Root[];
export interface ListRootsResponse {
    Roots?: Root[] | undefined;
    NextToken?: string | undefined;
}
export type TaggableResourceId = string;
export interface ListTagsForResourceRequest {
    ResourceId: string;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTargetsForPolicyRequest {
    PolicyId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type GenericArn = string;
export type TargetName = string;
export type TargetType = "ACCOUNT" | "ORGANIZATIONAL_UNIT" | "ROOT" | (string & {});
export interface PolicyTargetSummary {
    TargetId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Type?: TargetType | undefined;
}
export type PolicyTargets = PolicyTargetSummary[];
export interface ListTargetsForPolicyResponse {
    Targets?: PolicyTargetSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface MoveAccountRequest {
    AccountId: string;
    SourceParentId: string;
    DestinationParentId: string;
}
export interface MoveAccountResponse {
}
export interface PutResourcePolicyRequest {
    Content: string;
    Tags?: Tag[] | undefined;
}
export interface PutResourcePolicyResponse {
    ResourcePolicy?: ResourcePolicy | undefined;
}
export interface RegisterDelegatedAdministratorRequest {
    AccountId: string;
    ServicePrincipal: string;
}
export interface RegisterDelegatedAdministratorResponse {
}
export interface RemoveAccountFromOrganizationRequest {
    AccountId: string;
}
export interface RemoveAccountFromOrganizationResponse {
}
export interface TagResourceRequest {
    ResourceId: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface TerminateResponsibilityTransferRequest {
    Id: string;
    EndTimestamp?: Date | undefined;
}
export interface TerminateResponsibilityTransferResponse {
    ResponsibilityTransfer?: ResponsibilityTransfer | undefined;
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceId: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateOrganizationalUnitRequest {
    OrganizationalUnitId: string;
    Name?: string | undefined;
}
export interface UpdateOrganizationalUnitResponse {
    OrganizationalUnit?: OrganizationalUnit | undefined;
}
export interface UpdatePolicyRequest {
    PolicyId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Content?: string | undefined;
}
export interface UpdatePolicyResponse {
    Policy?: Policy | undefined;
}
export interface UpdateResponsibilityTransferRequest {
    Id: string;
    Name: string | redacted.Redacted<string>;
}
export interface UpdateResponsibilityTransferResponse {
    ResponsibilityTransfer?: ResponsibilityTransfer | undefined;
}
export type ExceptionMessage = string;
export type AccessDeniedForDependencyExceptionReason = "ACCESS_DENIED_DURING_CREATE_SERVICE_LINKED_ROLE" | (string & {});
export type ConstraintViolationExceptionReason = "ACCOUNT_NUMBER_LIMIT_EXCEEDED" | "HANDSHAKE_RATE_LIMIT_EXCEEDED" | "OU_NUMBER_LIMIT_EXCEEDED" | "OU_DEPTH_LIMIT_EXCEEDED" | "POLICY_NUMBER_LIMIT_EXCEEDED" | "POLICY_CONTENT_LIMIT_EXCEEDED" | "MAX_POLICY_TYPE_ATTACHMENT_LIMIT_EXCEEDED" | "MIN_POLICY_TYPE_ATTACHMENT_LIMIT_EXCEEDED" | "ACCOUNT_CANNOT_LEAVE_ORGANIZATION" | "ACCOUNT_CANNOT_LEAVE_WITHOUT_EULA" | "ACCOUNT_CANNOT_LEAVE_WITHOUT_PHONE_VERIFICATION" | "MASTER_ACCOUNT_PAYMENT_INSTRUMENT_REQUIRED" | "MEMBER_ACCOUNT_PAYMENT_INSTRUMENT_REQUIRED" | "ACCOUNT_CREATION_RATE_LIMIT_EXCEEDED" | "MASTER_ACCOUNT_ADDRESS_DOES_NOT_MATCH_MARKETPLACE" | "MASTER_ACCOUNT_MISSING_CONTACT_INFO" | "MASTER_ACCOUNT_NOT_GOVCLOUD_ENABLED" | "ORGANIZATION_NOT_IN_ALL_FEATURES_MODE" | "CREATE_ORGANIZATION_IN_BILLING_MODE_UNSUPPORTED_REGION" | "EMAIL_VERIFICATION_CODE_EXPIRED" | "WAIT_PERIOD_ACTIVE" | "MAX_TAG_LIMIT_EXCEEDED" | "TAG_POLICY_VIOLATION" | "MAX_DELEGATED_ADMINISTRATORS_FOR_SERVICE_LIMIT_EXCEEDED" | "CANNOT_REGISTER_MASTER_AS_DELEGATED_ADMINISTRATOR" | "CANNOT_REMOVE_DELEGATED_ADMINISTRATOR_FROM_ORG" | "DELEGATED_ADMINISTRATOR_EXISTS_FOR_THIS_SERVICE" | "POLICY_TYPE_ENABLED_FOR_THIS_SERVICE" | "MASTER_ACCOUNT_MISSING_BUSINESS_LICENSE" | "CANNOT_CLOSE_MANAGEMENT_ACCOUNT" | "CLOSE_ACCOUNT_QUOTA_EXCEEDED" | "CLOSE_ACCOUNT_REQUESTS_LIMIT_EXCEEDED" | "SERVICE_ACCESS_NOT_ENABLED" | "INVALID_PAYMENT_INSTRUMENT" | "ACCOUNT_CREATION_NOT_COMPLETE" | "CANNOT_REGISTER_SUSPENDED_ACCOUNT_AS_DELEGATED_ADMINISTRATOR" | "ALL_FEATURES_MIGRATION_ORGANIZATION_SIZE_LIMIT_EXCEEDED" | "RESPONSIBILITY_TRANSFER_MAX_LEVEL_VIOLATION" | "RESPONSIBILITY_TRANSFER_MAX_INBOUND_QUOTA_VIOLATION" | "RESPONSIBILITY_TRANSFER_MAX_OUTBOUND_QUOTA_VIOLATION" | "RESPONSIBILITY_TRANSFER_MAX_TRANSFERS_QUOTA_VIOLATION" | "ACTIVE_RESPONSIBILITY_TRANSFER_PROCESS" | "TRANSFER_RESPONSIBILITY_TARGET_DELETION_IN_PROGRESS" | "TRANSFER_RESPONSIBILITY_SOURCE_DELETION_IN_PROGRESS" | "UNSUPPORTED_PRICING" | "UNMET_BILLING_PREREQUISITE" | "ACCOUNT_NOT_ACTIVE_FOR_TRANSFER_RESPONSIBILITY" | "TRANSFER_RESPONSIBILITY_UPDATE_NOT_ALLOWED" | (string & {});
export type HandshakeConstraintViolationExceptionReason = "ACCOUNT_NUMBER_LIMIT_EXCEEDED" | "HANDSHAKE_RATE_LIMIT_EXCEEDED" | "ALREADY_IN_AN_ORGANIZATION" | "ORGANIZATION_ALREADY_HAS_ALL_FEATURES" | "ORGANIZATION_IS_ALREADY_PENDING_ALL_FEATURES_MIGRATION" | "INVITE_DISABLED_DURING_ENABLE_ALL_FEATURES" | "PAYMENT_INSTRUMENT_REQUIRED" | "ORGANIZATION_FROM_DIFFERENT_SELLER_OF_RECORD" | "ORGANIZATION_MEMBERSHIP_CHANGE_RATE_LIMIT_EXCEEDED" | "MANAGEMENT_ACCOUNT_EMAIL_NOT_VERIFIED" | "RESPONSIBILITY_TRANSFER_ALREADY_EXISTS" | "SOURCE_AND_TARGET_CANNOT_MATCH" | "UNUSED_PREPAYMENT_BALANCE" | "LEGACY_PERMISSIONS_STILL_IN_USE" | "PAST_DUE_INVOICE" | "TARGET_ACCOUNT_VALIDATION_FAILURE" | (string & {});
export type InvalidInputExceptionReason = "INVALID_PARTY_TYPE_TARGET" | "INVALID_SYNTAX_ORGANIZATION_ARN" | "INVALID_SYNTAX_POLICY_ID" | "INVALID_ENUM" | "INVALID_ENUM_POLICY_TYPE" | "INVALID_LIST_MEMBER" | "MAX_LENGTH_EXCEEDED" | "MAX_VALUE_EXCEEDED" | "MIN_LENGTH_EXCEEDED" | "MIN_VALUE_EXCEEDED" | "IMMUTABLE_POLICY" | "INVALID_PATTERN" | "INVALID_PATTERN_TARGET_ID" | "INPUT_REQUIRED" | "INVALID_NEXT_TOKEN" | "MAX_LIMIT_EXCEEDED_FILTER" | "MOVING_ACCOUNT_BETWEEN_DIFFERENT_ROOTS" | "INVALID_FULL_NAME_TARGET" | "UNRECOGNIZED_SERVICE_PRINCIPAL" | "INVALID_ROLE_NAME" | "INVALID_SYSTEM_TAGS_PARAMETER" | "DUPLICATE_TAG_KEY" | "TARGET_NOT_SUPPORTED" | "INVALID_EMAIL_ADDRESS_TARGET" | "INVALID_RESOURCE_POLICY_JSON" | "INVALID_PRINCIPAL" | "UNSUPPORTED_ACTION_IN_RESOURCE_POLICY" | "UNSUPPORTED_POLICY_TYPE_IN_RESOURCE_POLICY" | "UNSUPPORTED_RESOURCE_IN_RESOURCE_POLICY" | "NON_DETACHABLE_POLICY" | "CALLER_REQUIRED_FIELD_MISSING" | "UNSUPPORTED_ACTION_IN_RESPONSIBILITY_TRANSFER" | "START_DATE_NOT_BEGINNING_OF_MONTH" | "START_DATE_NOT_BEGINNING_OF_DAY" | "START_DATE_TOO_EARLY" | "START_DATE_TOO_LATE" | "INVALID_START_DATE" | "END_DATE_NOT_END_OF_MONTH" | "END_DATE_TOO_EARLY" | "END_DATE_TOO_LATE" | "INVALID_END_DATE" | (string & {});
export type ExceptionType = string;
export type AcceptHandshakeError = AccessDeniedException | AccessDeniedForDependencyException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | HandshakeAlreadyInStateException | HandshakeConstraintViolationException | HandshakeNotFoundException | InvalidHandshakeTransitionException | InvalidInputException | MasterCannotLeaveOrganizationException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Accepts a handshake by sending an `ACCEPTED` response to the sender. You
 * can view accepted handshakes in API responses for 30 days before they are
 * deleted.
 *
 * Only the management account can accept the following
 * handshakes:
 *
 * - Enable all features final confirmation
 * (`APPROVE_ALL_FEATURES`)
 *
 * - Billing transfer (`TRANSFER_RESPONSIBILITY`)
 *
 * For more information, see Enabling all features and Responding to a billing transfer invitation in the
 * *Organizations User Guide*.
 *
 * Only a member account can accept the following
 * handshakes:
 *
 * - Invitation to join (`INVITE`)
 *
 * - Approve all features request (`ENABLE_ALL_FEATURES`)
 *
 * For more information, see Responding to invitations and Enabling all features in the *Organizations User Guide*.
 *
 * When a handshake is accepted, Organizations logs membership events in CloudTrail, available
 * only in the management account's event history. If the account was standalone and joined
 * a new organization, an `AccountJoinedOrganization` event is logged with
 * `joinedMethod:INVITED` and `joinedTime` fields. If the account
 * departed one organization and joined another, both an
 * `AccountDepartedOrganization` event with `departureMethod:LEFT`
 * and `departureTime` and an `AccountJoinedOrganization` event with
 * `joinedMethod:INVITED` and `joinedTime` are logged in their
 * respective management accounts.
 *
 * When a billing transfer (`TRANSFER_RESPONSIBILITY`) handshake is accepted,
 * Organizations publishes a `ResponsibilityTransferAccepted` service event to CloudTrail.
 * Each affected account receives this event, including upstream participants such as
 * distributors in a chained transfer. For an example log entry, see Example log entries: AcceptResponsibilityTransfer in the
 * *Organizations User Guide*.
 */
export declare const acceptHandshake: API.OperationMethod<AcceptHandshakeRequest & RegionInput, AcceptHandshakeResponse, AcceptHandshakeError, Credentials | HttpClient.HttpClient>;
export type AttachPolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicatePolicyAttachmentException | InvalidInputException | PolicyChangesInProgressException | PolicyNotFoundException | PolicyTypeNotEnabledException | ServiceException | TargetNotFoundException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Attaches a policy to a root, an organizational unit (OU), or an individual account.
 * How the policy affects accounts depends on the type of policy. Refer to the
 * *Organizations User Guide* for information about each policy type:
 *
 * - SERVICE_CONTROL_POLICY
 *
 * - RESOURCE_CONTROL_POLICY
 *
 * - DECLARATIVE_POLICY_EC2
 *
 * - BACKUP_POLICY
 *
 * - TAG_POLICY
 *
 * - CHATBOT_POLICY
 *
 * - AISERVICES_OPT_OUT_POLICY
 *
 * - SECURITYHUB_POLICY
 *
 * - UPGRADE_ROLLOUT_POLICY
 *
 * - INSPECTOR_POLICY
 *
 * - BEDROCK_POLICY
 *
 * - S3_POLICY
 *
 * - NETWORK_SECURITY_DIRECTOR_POLICY
 *
 * - GUARDDUTY_POLICY
 *
 * - SECURITYHUB_CSPM_POLICY
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const attachPolicy: API.OperationMethod<AttachPolicyRequest & RegionInput, AttachPolicyResponse, AttachPolicyError, Credentials | HttpClient.HttpClient>;
export type CancelHandshakeError = AccessDeniedException | ConcurrentModificationException | HandshakeAlreadyInStateException | HandshakeNotFoundException | InvalidHandshakeTransitionException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Cancels a Handshake.
 *
 * Only the account that sent a handshake can call this operation. The recipient of the handshake can't cancel it, but can use DeclineHandshake to decline. After a handshake is canceled, the
 * recipient can no longer respond to the handshake.
 *
 * You can view canceled handshakes in API responses for 30 days before they are
 * deleted.
 */
export declare const cancelHandshake: API.OperationMethod<CancelHandshakeRequest & RegionInput, CancelHandshakeResponse, CancelHandshakeError, Credentials | HttpClient.HttpClient>;
export type CloseAccountError = AccessDeniedException | AccountAlreadyClosedException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConflictException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Closes an Amazon Web Services member account within an organization. You can close an account when
 * all
 * features are enabled . You can't close the management account with this API.
 * This is an asynchronous request that Amazon Web Services performs in the background. Because
 * `CloseAccount` operates asynchronously, it can return a successful
 * completion message even though account closure might still be in progress. You need to
 * wait a few minutes before the account is fully closed. To check the status of the
 * request, do one of the following:
 *
 * - Use the `AccountId` that you sent in the `CloseAccount`
 * request to provide as a parameter to the DescribeAccount
 * operation.
 *
 * While the close account request is in progress, Account status will indicate
 * PENDING_CLOSURE. When the close account request completes, the status will
 * change to SUSPENDED.
 *
 * - Check the CloudTrail log for the `CloseAccountResult` event that gets
 * published after the account closes successfully. For information on using CloudTrail
 * with Organizations, see Logging and monitoring in Organizations in the
 * *Organizations User Guide*.
 *
 * - Resources remaining within the account after closing will be automatically deleted after 90 days. During this 90-day period,
 * the resources won't be available unless you contact Amazon Web Services Support to reopen the account. After 90 days, you can't reopen an account.
 * You might still receive a bill after account closure.
 *
 * - Within a rolling 30 day period you can close the higher of either 250 or 20% of the member accounts in your organization,
 * up to a maximum of 1,000. This quota is not bound by a calendar month, but
 * starts when you close an account. After you reach this limit, you can't
 * close additional accounts. For more information, see Closing a member
 * account in your organization and Quotas for
 * Organizations in the *Organizations User Guide*.
 *
 * - To reinstate a closed account, contact Amazon Web Services Support within the 90-day
 * grace period while the account is in SUSPENDED status.
 *
 * - If the Amazon Web Services account you attempt to close is linked to an Amazon Web Services GovCloud
 * (US) account, the `CloseAccount` request will close both
 * accounts. To learn important pre-closure details, see
 * Closing an Amazon Web Services GovCloud (US) account in the
 * Amazon Web Services GovCloud User Guide.
 *
 * After the permanent termination of the account after the 90-day waiting period,
 * Organizations logs a membership event in CloudTrail. The event is an
 * `AccountDepartedOrganization` event with
 * `departureMethod:CLEANED` and `departureTime`. This event is
 * available only in the management account's event history.
 */
export declare const closeAccount: API.OperationMethod<CloseAccountRequest & RegionInput, CloseAccountResponse, CloseAccountError, Credentials | HttpClient.HttpClient>;
export type CreateAccountError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | FinalizingOrganizationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Creates an Amazon Web Services account that is automatically a member of the organization whose
 * credentials made the request. This is an asynchronous request that Amazon Web Services performs in the
 * background. Because `CreateAccount` operates asynchronously, it can return a
 * successful completion message even though account initialization might still be in
 * progress. You might need to wait a few minutes before you can successfully access the
 * account. To check the status of the request, do one of the following:
 *
 * - Use the `Id` value of the `CreateAccountStatus` response
 * element from this operation to provide as a parameter to the DescribeCreateAccountStatus operation.
 *
 * - Check the CloudTrail log for the `CreateAccountResult` event. For
 * information on using CloudTrail with Organizations, see Logging and monitoring in Organizations in the
 * *Organizations User Guide*.
 *
 * Additionally, the `AccountJoinedOrganization` event is logged in CloudTrail and
 * is available only in the management account's event history. This event includes
 * `joinedMethod:Created` and `joinedTime` fields to provide context
 * on how and when the account joined the organization.
 *
 * The user who calls the API to create an account must have the
 * `organizations:CreateAccount` permission. If you enabled all features in
 * the organization, Organizations creates the required service-linked role named
 * `AWSServiceRoleForOrganizations`. For more information, see Organizations and service-linked roles in the
 * *Organizations User Guide*.
 *
 * If the request includes tags, then the requester must have the
 * `organizations:TagResource` permission.
 *
 * Organizations preconfigures the new member account with a role (named
 * `OrganizationAccountAccessRole` by default) that grants users in the
 * management account administrator permissions in the new member account. Principals in
 * the management account can assume the role. Organizations clones the company name and address
 * information for the new account from the organization's management account.
 *
 * You can only call this operation from the management account.
 *
 * For more information about creating accounts, see Creating
 * a member account in your organization in the
 * *Organizations User Guide*.
 *
 * - When you create an account in an organization using the Organizations console,
 * API, or CLI commands, the information required for the account to operate
 * as a standalone account, such as a payment method is
 * *not* automatically collected. If you must remove an
 * account from your organization later, you can do so only after you provide
 * the missing information. For more information, see Considerations before removing an account from an organization
 * in the *Organizations User Guide*.
 *
 * - If you get an exception that indicates that you exceeded your account
 * limits for the organization, contact Amazon Web Services Support.
 *
 * - If you get an exception that indicates that the operation failed because
 * your organization is still initializing, wait one hour and then try again.
 * If the error persists, contact Amazon Web Services Support.
 *
 * - It isn't recommended to use `CreateAccount` to create multiple
 * temporary accounts, and using the `CreateAccount` API to close
 * accounts is subject to a 30-day usage quota. For information on the
 * requirements and process for closing an account, see Closing a member
 * account in your organization in the
 * *Organizations User Guide*.
 *
 * When you create a member account with this operation, you can choose whether to
 * create the account with the IAM User and Role Access to
 * Billing Information switch enabled. If you enable it, IAM users and
 * roles that have appropriate permissions can view billing information for the
 * account. If you disable it, only the account root user can access billing
 * information. For information about how to disable this switch for an account, see
 * Granting access to
 * your billing information and tools.
 */
export declare const createAccount: API.OperationMethod<CreateAccountRequest & RegionInput, CreateAccountResponse, CreateAccountError, Credentials | HttpClient.HttpClient>;
export type CreateGovCloudAccountError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | FinalizingOrganizationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * This action is available if all of the following are true:
 *
 * - You're authorized to create accounts in the Amazon Web Services GovCloud (US) Region. For
 * more information on the Amazon Web Services GovCloud (US) Region, see the
 * *Amazon Web Services GovCloud User Guide*.
 *
 * - You already have an account in the Amazon Web Services GovCloud (US) Region that is paired
 * with a management account of an organization in the commercial Region.
 *
 * - You call this action from the management account of your organization in the
 * commercial Region.
 *
 * - You have the `organizations:CreateGovCloudAccount` permission.
 *
 * Organizations automatically creates the required service-linked role named
 * `AWSServiceRoleForOrganizations`. For more information, see Organizations and service-linked roles in the
 * *Organizations User Guide*.
 *
 * Amazon Web Services automatically enables CloudTrail for Amazon Web Services GovCloud (US) accounts, but you should also
 * do the following:
 *
 * - Verify that CloudTrail is enabled to store logs.
 *
 * - Create an Amazon S3 bucket for CloudTrail log storage.
 *
 * For more information, see Verifying CloudTrail Is
 * Enabled in the *Amazon Web Services GovCloud User Guide*.
 *
 * If the request includes tags, then the requester must have the
 * `organizations:TagResource` permission. The tags are attached to the
 * commercial account associated with the GovCloud account, rather than the GovCloud
 * account itself. To add tags to the GovCloud account, call the TagResource operation in the GovCloud Region after the new GovCloud
 * account exists.
 *
 * You call this action from the management account of your organization in the
 * commercial Region to create a standalone Amazon Web Services account in the Amazon Web Services GovCloud (US)
 * Region. After the account is created, the management account of an organization in the
 * Amazon Web Services GovCloud (US) Region can invite it to that organization. For more information on
 * inviting standalone accounts in the Amazon Web Services GovCloud (US) to join an organization, see
 * Organizations in the
 * *Amazon Web Services GovCloud User Guide*.
 *
 * Calling `CreateGovCloudAccount` is an asynchronous request that Amazon Web Services
 * performs in the background. Because `CreateGovCloudAccount` operates
 * asynchronously, it can return a successful completion message even though account
 * initialization might still be in progress. You might need to wait a few minutes before
 * you can successfully access the account. To check the status of the request, do one of
 * the following:
 *
 * - Use the `Id` response element from this operation to
 * provide as a parameter to the DescribeCreateAccountStatus
 * operation.
 *
 * - Check the CloudTrail log for the `CreateAccountResult` event. For
 * information on using CloudTrail with Organizations, see Logging and
 * monitoring in Organizations in the
 * *Organizations User Guide*.
 *
 * Additionally, the `AccountJoinedOrganization` event is logged in CloudTrail and
 * is available only in the management account's event history only for the linked
 * commercial account. This event includes `joinedMethod:Created` and
 * `joinedTime` fields to provide context on how and when the account joined
 * the organization.
 *
 * When you call the `CreateGovCloudAccount` action, you create two accounts:
 * a standalone account in the Amazon Web Services GovCloud (US) Region and an associated account in the
 * commercial Region for billing and support purposes. The account in the commercial Region
 * is automatically a member of the organization whose credentials made the request. Both
 * accounts are associated with the same email address.
 *
 * A role is created in the new account in the commercial Region that allows the
 * management account in the organization in the commercial Region to assume it. An Amazon Web Services
 * GovCloud (US) account is then created and associated with the commercial account that
 * you just created. A role is also created in the new Amazon Web Services GovCloud (US) account that can
 * be assumed by the Amazon Web Services GovCloud (US) account that is associated with the management
 * account of the commercial organization. For more information and to view a diagram that
 * explains how account access works, see Organizations in the
 * *Amazon Web Services GovCloud User Guide*.
 *
 * For more information about creating accounts, see Creating
 * a member account in your organization in the
 * *Organizations User Guide*.
 *
 * - When you create an account in an organization using the Organizations console,
 * API, or CLI commands, the information required for the account to operate as
 * a standalone account is *not* automatically collected.
 * This includes a payment method and signing the end user license agreement
 * (EULA). If you must remove an account from your organization later, you can
 * do so only after you provide the missing information. For more information,
 * see Considerations before removing an account from an organization
 * in the *Organizations User Guide*.
 *
 * - If you get an exception that indicates that you exceeded your account
 * limits for the organization, contact Amazon Web Services Support.
 *
 * - If you get an exception that indicates that the operation failed because
 * your organization is still initializing, wait one hour and then try again.
 * If the error persists, contact Amazon Web Services Support.
 *
 * - Using `CreateGovCloudAccount` to create multiple temporary
 * accounts isn't recommended. You can only close an account from the Amazon Web Services
 * Billing and Cost Management console, and you must be signed in as the root user. For information on
 * the requirements and process for closing an account, see Closing a member
 * account in your organization in the
 * *Organizations User Guide*.
 *
 * When you create a member account with this operation, you can choose whether to
 * create the account with the IAM User and Role Access to
 * Billing Information switch enabled. If you enable it, IAM users and
 * roles that have appropriate permissions can view billing information for the
 * account. If you disable it, only the account root user can access billing
 * information. For information about how to disable this switch for an account, see
 * Granting
 * access to your billing information and tools.
 */
export declare const createGovCloudAccount: API.OperationMethod<CreateGovCloudAccountRequest & RegionInput, CreateGovCloudAccountResponse, CreateGovCloudAccountError, Credentials | HttpClient.HttpClient>;
export type CreateOrganizationError = AccessDeniedException | AccessDeniedForDependencyException | AlreadyInOrganizationException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Creates an Amazon Web Services organization. The account whose user is calling the
 * `CreateOrganization` operation automatically becomes the management account of the new organization.
 *
 * This operation must be called using credentials from the account that is to become the
 * new organization's management account. The principal must also have the relevant IAM
 * permissions.
 *
 * By default (or if you set the `FeatureSet` parameter to `ALL`),
 * the new organization is created with all features enabled and service control policies
 * automatically enabled in the root. If you instead choose to create the organization
 * supporting only the consolidated billing features by setting the `FeatureSet`
 * parameter to `CONSOLIDATED_BILLING`, no policy types are enabled by default
 * and you can't use organization policies.
 *
 * The `AccountJoinedOrganization` event is logged in CloudTrail and
 * is available only in the management account's event history. This event includes
 * `joinedMethod:INVITED` and `joinedTime` fields to provide
 * context on how and when the account joined the organization.
 */
export declare const createOrganization: API.OperationMethod<CreateOrganizationRequest & RegionInput, CreateOrganizationResponse, CreateOrganizationError, Credentials | HttpClient.HttpClient>;
export type CreateOrganizationalUnitError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicateOrganizationalUnitException | InvalidInputException | ParentNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Creates an organizational unit (OU) within a root or parent OU. An OU is a container
 * for accounts that enables you to organize your accounts to apply policies according to
 * your business requirements. The number of levels deep that you can nest OUs is dependent
 * upon the policy types enabled for that root. For service control policies, the limit is
 * five.
 *
 * For more information about OUs, see Managing organizational units (OUs) in the
 * *Organizations User Guide*.
 *
 * If the request includes tags, then the requester must have the
 * `organizations:TagResource` permission.
 *
 * You can only call this operation from the management account.
 */
export declare const createOrganizationalUnit: API.OperationMethod<CreateOrganizationalUnitRequest & RegionInput, CreateOrganizationalUnitResponse, CreateOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicatePolicyException | InvalidInputException | MalformedPolicyDocumentException | PolicyTypeNotAvailableForOrganizationException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Creates a policy of a specified type that you can attach to a root, an organizational
 * unit (OU), or an individual Amazon Web Services account.
 *
 * For more information about policies and their use, see Managing
 * Organizations policies.
 *
 * If the request includes tags, then the requester must have the
 * `organizations:TagResource` permission.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest & RegionInput, CreatePolicyResponse, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type DeclineHandshakeError = AccessDeniedException | ConcurrentModificationException | HandshakeAlreadyInStateException | HandshakeNotFoundException | InvalidHandshakeTransitionException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Declines a Handshake.
 *
 * Only the account that receives a handshake can call this operation. The sender of the handshake can use CancelHandshake to
 * cancel if the handshake hasn't yet been responded to.
 *
 * You can view canceled handshakes in API responses for 30 days before they are
 * deleted.
 */
export declare const declineHandshake: API.OperationMethod<DeclineHandshakeRequest & RegionInput, DeclineHandshakeResponse, DeclineHandshakeError, Credentials | HttpClient.HttpClient>;
export type DeleteOrganizationError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | OrganizationNotEmptyException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the organization. You can delete an organization only by using credentials
 * from the management account. The organization must be empty of member accounts.
 *
 * When an organization is deleted, Organizations logs a membership event in CloudTrail. The
 * event is an `AccountDepartedOrganization` event with
 * `departureMethod:LEFT` and `departureTime`. This event is available
 * only in the management account's event history.
 */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest & RegionInput, DeleteOrganizationResponse, DeleteOrganizationError, Credentials | HttpClient.HttpClient>;
export type DeleteOrganizationalUnitError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | InvalidInputException | OrganizationalUnitNotEmptyException | OrganizationalUnitNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an organizational unit (OU) from a root or another OU. You must first remove
 * all accounts and child OUs from the OU that you want to delete.
 *
 * You can only call this operation from the management account.
 */
export declare const deleteOrganizationalUnit: API.OperationMethod<DeleteOrganizationalUnitRequest & RegionInput, DeleteOrganizationalUnitResponse, DeleteOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | InvalidInputException | PolicyInUseException | PolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Deletes the specified policy from your organization. Before you perform this
 * operation, you must first detach the policy from all organizational units (OUs), roots,
 * and accounts.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest & RegionInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | ResourcePolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Deletes the resource policy from your organization.
 *
 * You can only call this operation from the management account.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterDelegatedAdministratorError = AccessDeniedException | AccountNotFoundException | AccountNotRegisteredException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Removes the specified member Amazon Web Services account as a delegated administrator for the
 * specified Amazon Web Services service.
 *
 * Deregistering a delegated administrator can have unintended impacts on the
 * functionality of the enabled Amazon Web Services service. See the documentation for the enabled
 * service before you deregister a delegated administrator so that you understand any
 * potential impacts.
 *
 * You can run this action only for Amazon Web Services services that support this
 * feature. For a current list of services that support it, see the column Supports
 * Delegated Administrator in the table at Amazon Web Services Services that you can use with
 * Organizations in the *Organizations User Guide.*
 *
 * You can only call this operation from the management account.
 */
export declare const deregisterDelegatedAdministrator: API.OperationMethod<DeregisterDelegatedAdministratorRequest & RegionInput, DeregisterDelegatedAdministratorResponse, DeregisterDelegatedAdministratorError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountError = AccessDeniedException | AccountNotFoundException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves Organizations-related information about the specified account.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const describeAccount: API.OperationMethod<DescribeAccountRequest & RegionInput, DescribeAccountResponse, DescribeAccountError, Credentials | HttpClient.HttpClient>;
export type DescribeCreateAccountStatusError = AccessDeniedException | AWSOrganizationsNotInUseException | CreateAccountStatusNotFoundException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Retrieves the current status of an asynchronous request to create an account.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const describeCreateAccountStatus: API.OperationMethod<DescribeCreateAccountStatusRequest & RegionInput, DescribeCreateAccountStatusResponse, DescribeCreateAccountStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeEffectivePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | EffectivePolicyNotFoundException | InvalidInputException | ServiceException | TargetNotFoundException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Returns the contents of the effective policy for specified policy type and account.
 * The effective policy is the aggregation of any policies of the specified type that the
 * account inherits, plus any policy of that type that is directly attached to the
 * account.
 *
 * This operation applies only to management policies. It does not apply to authorization
 * policies: service control policies (SCPs) and resource control policies (RCPs).
 *
 * For more information about policy inheritance, see Understanding
 * management policy inheritance in the
 * *Organizations User Guide*.
 *
 * You can call this operation from any account in a organization.
 */
export declare const describeEffectivePolicy: API.OperationMethod<DescribeEffectivePolicyRequest & RegionInput, DescribeEffectivePolicyResponse, DescribeEffectivePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeHandshakeError = AccessDeniedException | ConcurrentModificationException | HandshakeNotFoundException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns details for a handshake. A handshake is the secure exchange of information
 * between two Amazon Web Services accounts: a sender and a recipient.
 *
 * You can view `ACCEPTED`, `DECLINED`, or `CANCELED`
 * handshakes in API Responses for 30 days before they are deleted.
 *
 * You can call this operation from any account in a organization.
 */
export declare const describeHandshake: API.OperationMethod<DescribeHandshakeRequest & RegionInput, DescribeHandshakeResponse, DescribeHandshakeError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about the organization that the user's account belongs
 * to.
 *
 * You can call this operation from any account in a organization.
 *
 * Even if a policy type is shown as available in the organization, you can disable
 * it separately at the root level with DisablePolicyType. Use ListRoots to see the status of policy types for a specified
 * root.
 */
export declare const describeOrganization: API.OperationMethod<DescribeOrganizationRequest & RegionInput, DescribeOrganizationResponse, DescribeOrganizationError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationalUnitError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | OrganizationalUnitNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about an organizational unit (OU).
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const describeOrganizationalUnit: API.OperationMethod<DescribeOrganizationalUnitRequest & RegionInput, DescribeOrganizationalUnitResponse, DescribeOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type DescribePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | PolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Retrieves information about a policy.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const describePolicy: API.OperationMethod<DescribePolicyRequest & RegionInput, DescribePolicyResponse, DescribePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | ResourcePolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Retrieves information about a resource policy.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeResponsibilityTransferError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ResponsibilityTransferNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Returns details for a transfer. A *transfer* is an arrangement
 * between two management accounts where one account designates the other with specified
 * responsibilities for their organization.
 */
export declare const describeResponsibilityTransfer: API.OperationMethod<DescribeResponsibilityTransferRequest & RegionInput, DescribeResponsibilityTransferResponse, DescribeResponsibilityTransferError, Credentials | HttpClient.HttpClient>;
export type DetachPolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | PolicyChangesInProgressException | PolicyNotAttachedException | PolicyNotFoundException | ServiceException | TargetNotFoundException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Detaches a policy from a target root, organizational unit (OU), or account.
 *
 * If the policy being detached is a service control policy (SCP), the changes to
 * permissions for Identity and Access Management (IAM) users and roles in affected accounts are
 * immediate.
 *
 * Every root, OU, and account must have at least one SCP attached. If you want to
 * replace the default `FullAWSAccess` policy with an SCP that limits the
 * permissions that can be delegated, you must attach the replacement SCP before you can
 * remove the default SCP. This is the authorization strategy of an "allow list". If you instead attach a second SCP and
 * leave the `FullAWSAccess` SCP still attached, and specify "Effect":
 * "Deny" in the second SCP to override the `"Effect": "Allow"` in
 * the `FullAWSAccess` policy (or any other attached SCP), you're using the
 * authorization strategy of a "deny list".
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const detachPolicy: API.OperationMethod<DetachPolicyRequest & RegionInput, DetachPolicyResponse, DetachPolicyError, Credentials | HttpClient.HttpClient>;
export type DisableAWSServiceAccessError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Disables the integration of an Amazon Web Services service (the service that is specified by
 * `ServicePrincipal`) with Organizations. When you disable integration, the
 * specified service no longer can create a service-linked role in
 * *new* accounts in your organization. This means the service can't
 * perform operations on your behalf on any new accounts in your organization. The service
 * can still perform operations in older accounts until the service completes its clean-up
 * from Organizations.
 *
 * We
 * *strongly recommend*
 * that
 * you don't use this command to disable integration between Organizations and the specified
 * Amazon Web Services service. Instead, use the console or commands that are provided by the
 * specified service. This lets the trusted service perform any required initialization
 * when enabling trusted access, such as creating any required resources and any
 * required clean up of resources when disabling trusted access.
 *
 * For information about how to disable trusted service access to your organization
 * using the trusted service, see the **Learn more** link
 * under the **Supports Trusted Access** column at Amazon Web Services services that you can use with Organizations. on this page.
 *
 * If you disable access by using this command, it causes the following actions to
 * occur:
 *
 * - The service can no longer create a service-linked role in the accounts in
 * your organization. This means that the service can't perform operations on
 * your behalf on any new accounts in your organization. The service can still
 * perform operations in older accounts until the service completes its
 * clean-up from Organizations.
 *
 * - The service can no longer perform tasks in the member accounts in the
 * organization, unless those operations are explicitly permitted by the IAM
 * policies that are attached to your roles. This includes any data aggregation
 * from the member accounts to the management account, or to a delegated
 * administrator account, where relevant.
 *
 * - Some services detect this and clean up any remaining data or resources
 * related to the integration, while other services stop accessing the
 * organization but leave any historical data and configuration in place to
 * support a possible re-enabling of the integration.
 *
 * Using the other service's console or commands to disable the integration ensures
 * that the other service is aware that it can clean up any resources that are required
 * only for the integration. How the service cleans up its resources in the
 * organization's accounts depends on that service. For more information, see the
 * documentation for the other Amazon Web Services service.
 *
 * After you perform the `DisableAWSServiceAccess` operation, the specified
 * service can no longer perform operations in your organization's accounts
 *
 * For more information about integrating other services with Organizations, including the
 * list of services that work with Organizations, see Using Organizations with other Amazon Web Services
 * services in the *Organizations User Guide*.
 *
 * You can only call this operation from the management account.
 */
export declare const disableAWSServiceAccess: API.OperationMethod<DisableAWSServiceAccessRequest & RegionInput, DisableAWSServiceAccessResponse, DisableAWSServiceAccessError, Credentials | HttpClient.HttpClient>;
export type DisablePolicyTypeError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | PolicyChangesInProgressException | PolicyTypeNotEnabledException | RootNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Disables an organizational policy type in a root. A policy of a certain type can be
 * attached to entities in a root only if that type is enabled in the root. After you
 * perform this operation, you no longer can attach policies of the specified type to that
 * root or to any organizational unit (OU) or account in that root. You can undo this by
 * using the EnablePolicyType operation.
 *
 * This is an asynchronous request that Amazon Web Services performs in the background. If you disable
 * a policy type for a root, it still appears enabled for the organization if all features are enabled for the organization. Amazon Web Services recommends that you
 * first use ListRoots to see the status of policy types for a specified
 * root, and then use this operation.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 *
 * To view the status of available policy types in the organization, use ListRoots.
 */
export declare const disablePolicyType: API.OperationMethod<DisablePolicyTypeRequest & RegionInput, DisablePolicyTypeResponse, DisablePolicyTypeError, Credentials | HttpClient.HttpClient>;
export type EnableAllFeaturesError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | HandshakeConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Enables all features in an organization. This enables the use of organization policies
 * that can restrict the services and actions that can be called in each account. Until you
 * enable all features, you have access only to consolidated billing, and you can't use any
 * of the advanced account administration features that Organizations supports. For more
 * information, see Enabling all features in your organization in the
 * *Organizations User Guide*.
 *
 * This operation is required only for organizations that were created explicitly
 * with only the consolidated billing features enabled. Calling this operation sends a
 * handshake to every invited account in the organization. The feature set change can
 * be finalized and the additional features enabled only after all administrators in
 * the invited accounts approve the change by accepting the handshake.
 *
 * After you enable all features, you can separately enable or disable individual policy
 * types in a root using EnablePolicyType and DisablePolicyType. To see the status of policy types in a root, use
 * ListRoots.
 *
 * After all invited member accounts accept the handshake, you finalize the feature set
 * change by accepting the handshake that contains "Action":
 * "ENABLE_ALL_FEATURES". This completes the change.
 *
 * After you enable all features in your organization, the management account in the
 * organization can apply policies on all member accounts. These policies can restrict what
 * users and even administrators in those accounts can do. The management account can apply
 * policies that prevent accounts from leaving the organization. Ensure that your account
 * administrators are aware of this.
 *
 * You can only call this operation from the management account.
 */
export declare const enableAllFeatures: API.OperationMethod<EnableAllFeaturesRequest & RegionInput, EnableAllFeaturesResponse, EnableAllFeaturesError, Credentials | HttpClient.HttpClient>;
export type EnableAWSServiceAccessError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Provides an Amazon Web Services service (the service that is specified by
 * `ServicePrincipal`) with permissions to view the structure of an
 * organization, create a service-linked role in
 * all the accounts in the organization, and allow the service to perform operations on
 * behalf of the organization and its accounts. Establishing these permissions can be a
 * first step in enabling the integration of an Amazon Web Services service with Organizations.
 *
 * We recommend that you enable integration between Organizations and the specified Amazon Web Services
 * service by using the console or commands that are provided by the specified service.
 * Doing so ensures that the service is aware that it can create the resources that are
 * required for the integration. How the service creates those resources in the
 * organization's accounts depends on that service. For more information, see the
 * documentation for the other Amazon Web Services service.
 *
 * For more information about enabling services to integrate with Organizations, see Using
 * Organizations with other Amazon Web Services services in the
 * *Organizations User Guide*.
 *
 * You can only call this operation from the management account.
 */
export declare const enableAWSServiceAccess: API.OperationMethod<EnableAWSServiceAccessRequest & RegionInput, EnableAWSServiceAccessResponse, EnableAWSServiceAccessError, Credentials | HttpClient.HttpClient>;
export type EnablePolicyTypeError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | PolicyChangesInProgressException | PolicyTypeAlreadyEnabledException | PolicyTypeNotAvailableForOrganizationException | RootNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Enables a policy type in a root. After you enable a policy type in a root, you can
 * attach policies of that type to the root, any organizational unit (OU), or account in
 * that root. You can undo this by using the DisablePolicyType
 * operation.
 *
 * This is an asynchronous request that Amazon Web Services performs in the background. Amazon Web Services
 * recommends that you first use ListRoots to see the status of policy
 * types for a specified root, and then use this operation.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 *
 * You can enable a policy type in a root only if that policy type is available in the
 * organization. To view the status of available policy types in the organization, use
 * ListRoots.
 */
export declare const enablePolicyType: API.OperationMethod<EnablePolicyTypeRequest & RegionInput, EnablePolicyTypeResponse, EnablePolicyTypeError, Credentials | HttpClient.HttpClient>;
export type InviteAccountToOrganizationError = AccessDeniedException | AccountOwnerNotVerifiedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicateHandshakeException | FinalizingOrganizationException | HandshakeConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sends an invitation to another account to join your organization as a member account.
 * Organizations sends email on your behalf to the email address that is associated with the
 * other account's owner. The invitation is implemented as a Handshake
 * whose details are in the response.
 *
 * If you receive an exception that indicates that you exceeded your account limits
 * for the organization or that the operation failed because your organization is still
 * initializing, wait one hour and then try again. If the error persists after an hour,
 * contact Amazon Web Services
 * Support.
 *
 * If the request includes tags, then the requester must have the
 * `organizations:TagResource` permission.
 *
 * You can only call this operation from the management account.
 */
export declare const inviteAccountToOrganization: API.OperationMethod<InviteAccountToOrganizationRequest & RegionInput, InviteAccountToOrganizationResponse, InviteAccountToOrganizationError, Credentials | HttpClient.HttpClient>;
export type InviteOrganizationToTransferResponsibilityError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicateHandshakeException | HandshakeConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Sends an invitation to another organization's management account to designate your
 * account with the specified responsibilities for their organization. The invitation is
 * implemented as a Handshake whose details are in the response.
 *
 * You can only call this operation from the management account.
 */
export declare const inviteOrganizationToTransferResponsibility: API.OperationMethod<InviteOrganizationToTransferResponsibilityRequest & RegionInput, InviteOrganizationToTransferResponsibilityResponse, InviteOrganizationToTransferResponsibilityError, Credentials | HttpClient.HttpClient>;
export type LeaveOrganizationError = AccessDeniedException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | MasterCannotLeaveOrganizationException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Removes a member account from its parent organization. This version of the operation
 * is performed by the account that wants to leave. To remove a member account as a user in
 * the management account, use RemoveAccountFromOrganization
 * instead.
 *
 * You can only call from operation from a member account.
 *
 * When an account leaves an organization, Organizations logs a membership event in
 * CloudTrail. The event is an `AccountDepartedOrganization` event with
 * `departureMethod:LEFT` and `departureTime`. This event is available
 * only in the management account's event history.
 *
 * - The management account in an organization with all features enabled can
 * set service control policies (SCPs) that can restrict what administrators of
 * member accounts can do. This includes preventing them from successfully
 * calling `LeaveOrganization` and leaving the organization.
 *
 * - You can leave an organization as a member account only if the account is
 * configured with the information required to operate as a standalone account.
 * When you create an account in an organization using the Organizations console,
 * API, or CLI commands, the information required of standalone accounts is
 * *not* automatically collected. For each account that
 * you want to make standalone, you must perform the following steps. If any of
 * the steps are already completed for this account, that step doesn't
 * appear.
 *
 * - Choose a support plan
 *
 * - Provide and verify the required contact information
 *
 * - Provide a current payment method
 *
 * Amazon Web Services uses the payment method to charge for any billable (not free tier)
 * Amazon Web Services activity that occurs while the account isn't attached to an
 * organization. For more information, see Considerations before removing an account from an organization
 * in the *Organizations User Guide*.
 *
 * - The account that you want to leave must not be a delegated administrator
 * account for any Amazon Web Services service enabled for your organization. If the account
 * is a delegated administrator, you must first change the delegated
 * administrator account to another account that is remaining in the
 * organization.
 *
 * - After the account leaves the organization, all tags that were attached to
 * the account object in the organization are deleted. Amazon Web Services accounts outside
 * of an organization do not support tags.
 *
 * - A newly created account has a waiting period before it can be removed from
 * its organization. You must wait until at least four days after the account
 * was created. Invited accounts aren't subject to this waiting period.
 *
 * - If you are using an organization principal to call
 * `LeaveOrganization` across multiple accounts, you can only do
 * this up to 5 accounts per second in a single organization.
 */
export declare const leaveOrganization: API.OperationMethod<LeaveOrganizationRequest & RegionInput, LeaveOrganizationResponse, LeaveOrganizationError, Credentials | HttpClient.HttpClient>;
export type ListAccountsError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists all the accounts in the organization. To request only the accounts in a
 * specified root or organizational unit (OU), use the ListAccountsForParent operation instead.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest & RegionInput, ListAccountsResponse, ListAccountsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAccountsForParentError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ParentNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the accounts in an organization that are contained by the specified target root
 * or organizational unit (OU). If you specify the root, you get a list of all the accounts
 * that aren't in any OU. If you specify an OU, you get a list of all the accounts in only
 * that OU and not in any child OUs. To get a list of all accounts in the organization, use
 * the ListAccounts operation.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listAccountsForParent: API.PaginatedOperationMethod<ListAccountsForParentRequest & RegionInput, ListAccountsForParentResponse, ListAccountsForParentError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAccountsWithInvalidEffectivePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | EffectivePolicyNotFoundException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists all the accounts in an organization that have invalid effective policies. An
 * *invalid effective policy* is an effective
 * policy that fails validation checks, resulting in the effective policy not
 * being fully enforced on all the intended accounts within an organization.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listAccountsWithInvalidEffectivePolicy: API.PaginatedOperationMethod<ListAccountsWithInvalidEffectivePolicyRequest & RegionInput, ListAccountsWithInvalidEffectivePolicyResponse, ListAccountsWithInvalidEffectivePolicyError, Credentials | HttpClient.HttpClient, Account>;
export type ListAWSServiceAccessForOrganizationError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Returns a list of the Amazon Web Services services that you enabled to integrate with your
 * organization. After a service on this list creates the resources that it requires for
 * the integration, it can perform operations on your organization and its accounts.
 *
 * For more information about integrating other services with Organizations, including the
 * list of services that currently work with Organizations, see Using Organizations with other Amazon Web Services
 * services in the *Organizations User Guide*.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listAWSServiceAccessForOrganization: API.PaginatedOperationMethod<ListAWSServiceAccessForOrganizationRequest & RegionInput, ListAWSServiceAccessForOrganizationResponse, ListAWSServiceAccessForOrganizationError, Credentials | HttpClient.HttpClient, unknown>;
export type ListChildrenError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ParentNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the organizational units (OUs) or accounts that are contained in the
 * specified parent OU or root. This operation, along with ListParents
 * enables you to traverse the tree structure that makes up this root.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listChildren: API.PaginatedOperationMethod<ListChildrenRequest & RegionInput, ListChildrenResponse, ListChildrenError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCreateAccountStatusError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists the account creation requests that match the specified status that is currently
 * being tracked for the organization.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listCreateAccountStatus: API.PaginatedOperationMethod<ListCreateAccountStatusRequest & RegionInput, ListCreateAccountStatusResponse, ListCreateAccountStatusError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDelegatedAdministratorsError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists the Amazon Web Services accounts that are designated as delegated administrators in this
 * organization.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listDelegatedAdministrators: API.PaginatedOperationMethod<ListDelegatedAdministratorsRequest & RegionInput, ListDelegatedAdministratorsResponse, ListDelegatedAdministratorsError, Credentials | HttpClient.HttpClient, DelegatedAdministrator>;
export type ListDelegatedServicesForAccountError = AccessDeniedException | AccountNotFoundException | AccountNotRegisteredException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * List the Amazon Web Services services for which the specified account is a delegated
 * administrator.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listDelegatedServicesForAccount: API.PaginatedOperationMethod<ListDelegatedServicesForAccountRequest & RegionInput, ListDelegatedServicesForAccountResponse, ListDelegatedServicesForAccountError, Credentials | HttpClient.HttpClient, DelegatedService>;
export type ListEffectivePolicyValidationErrorsError = AccessDeniedException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConstraintViolationException | EffectivePolicyNotFoundException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists all the validation errors on an effective
 * policy for a specified account and policy type.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listEffectivePolicyValidationErrors: API.PaginatedOperationMethod<ListEffectivePolicyValidationErrorsRequest & RegionInput, ListEffectivePolicyValidationErrorsResponse, ListEffectivePolicyValidationErrorsError, Credentials | HttpClient.HttpClient, EffectivePolicyValidationError>;
export type ListHandshakesForAccountError = AccessDeniedException | ConcurrentModificationException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the recent handshakes that you have received.
 *
 * You can view `CANCELED`, `ACCEPTED`, `DECLINED`, or
 * `EXPIRED` handshakes in API responses for 30 days before they are
 * deleted.
 *
 * You can call this operation from any account in a organization.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 */
export declare const listHandshakesForAccount: API.PaginatedOperationMethod<ListHandshakesForAccountRequest & RegionInput, ListHandshakesForAccountResponse, ListHandshakesForAccountError, Credentials | HttpClient.HttpClient, unknown>;
export type ListHandshakesForOrganizationError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the recent handshakes that you have sent.
 *
 * You can view `CANCELED`, `ACCEPTED`, `DECLINED`, or
 * `EXPIRED` handshakes in API responses for 30 days before they are
 * deleted.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 */
export declare const listHandshakesForOrganization: API.PaginatedOperationMethod<ListHandshakesForOrganizationRequest & RegionInput, ListHandshakesForOrganizationResponse, ListHandshakesForOrganizationError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInboundResponsibilityTransfersError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ResponsibilityTransferNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists transfers that allow you to manage the specified responsibilities for another
 * organization. This operation returns both transfer invitations and transfers.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 */
export declare const listInboundResponsibilityTransfers: API.OperationMethod<ListInboundResponsibilityTransfersRequest & RegionInput, ListInboundResponsibilityTransfersResponse, ListInboundResponsibilityTransfersError, Credentials | HttpClient.HttpClient>;
export type ListOrganizationalUnitsForParentError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ParentNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the organizational units (OUs) in a parent organizational unit or root.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listOrganizationalUnitsForParent: API.PaginatedOperationMethod<ListOrganizationalUnitsForParentRequest & RegionInput, ListOrganizationalUnitsForParentResponse, ListOrganizationalUnitsForParentError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOutboundResponsibilityTransfersError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists transfers that allow an account outside your organization to manage the
 * specified responsibilities for your organization. This operation returns both transfer
 * invitations and transfers.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 */
export declare const listOutboundResponsibilityTransfers: API.OperationMethod<ListOutboundResponsibilityTransfersRequest & RegionInput, ListOutboundResponsibilityTransfersResponse, ListOutboundResponsibilityTransfersError, Credentials | HttpClient.HttpClient>;
export type ListParentsError = AccessDeniedException | AWSOrganizationsNotInUseException | ChildNotFoundException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the root or organizational units (OUs) that serve as the immediate parent of the
 * specified child OU or account. This operation, along with ListChildren
 * enables you to traverse the tree structure that makes up this root.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 *
 * In the current release, a child can have only a single parent.
 */
export declare const listParents: API.PaginatedOperationMethod<ListParentsRequest & RegionInput, ListParentsResponse, ListParentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPoliciesError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Retrieves the list of all policies in an organization of a specified type.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest & RegionInput, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPoliciesForTargetError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TargetNotFoundException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists the policies that are directly attached to the specified target root,
 * organizational unit (OU), or account. You must specify the policy type that you want
 * included in the returned list.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listPoliciesForTarget: API.PaginatedOperationMethod<ListPoliciesForTargetRequest & RegionInput, ListPoliciesForTargetResponse, ListPoliciesForTargetError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRootsError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists the roots that are defined in the current organization.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 *
 * Policy types can be enabled and disabled in roots. This is distinct from whether
 * they're available in the organization. When you enable all features, you make policy
 * types available for use in that organization. Individual policy types can then be
 * enabled and disabled in a root. To see the availability of a policy type in an
 * organization, use DescribeOrganization.
 */
export declare const listRoots: API.PaginatedOperationMethod<ListRootsRequest & RegionInput, ListRootsResponse, ListRootsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | ServiceException | TargetNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists tags that are attached to the specified resource.
 *
 * You can attach tags to the following resources in Organizations.
 *
 * - Amazon Web Services account
 *
 * - Organization root
 *
 * - Organizational unit (OU)
 *
 * - Policy (any type)
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTargetsForPolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | InvalidInputException | PolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Lists all the roots, organizational units (OUs), and accounts that the specified
 * policy is attached to.
 *
 * When calling List* operations, always check the `NextToken` response parameter value, even if you receive an empty result set.
 * These operations can occasionally return an empty set of results even when more results are available.
 * Continue making requests until `NextToken` returns null. A null `NextToken` value indicates that you have retrieved all available results.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const listTargetsForPolicy: API.PaginatedOperationMethod<ListTargetsForPolicyRequest & RegionInput, ListTargetsForPolicyResponse, ListTargetsForPolicyError, Credentials | HttpClient.HttpClient, unknown>;
export type MoveAccountError = AccessDeniedException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConcurrentModificationException | DestinationParentNotFoundException | DuplicateAccountException | InvalidInputException | ServiceException | SourceParentNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Moves an account from its current source parent root or organizational unit (OU) to
 * the specified destination parent root or OU.
 *
 * You can only call this operation from the management account.
 */
export declare const moveAccount: API.OperationMethod<MoveAccountRequest & RegionInput, MoveAccountResponse, MoveAccountError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Creates or updates a resource policy.
 *
 * You can only call this operation from the management account..
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterDelegatedAdministratorError = AccessDeniedException | AccountAlreadyRegisteredException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Enables the specified member account to administer the Organizations features of the specified
 * Amazon Web Services service. It grants read-only access to Organizations service data. The account still
 * requires IAM permissions to access and administer the Amazon Web Services service.
 *
 * You can run this action only for Amazon Web Services services that support this
 * feature. For a current list of services that support it, see the column Supports
 * Delegated Administrator in the table at Amazon Web Services Services that you can use with
 * Organizations in the *Organizations User Guide.*
 *
 * You can only call this operation from the management account.
 */
export declare const registerDelegatedAdministrator: API.OperationMethod<RegisterDelegatedAdministratorRequest & RegionInput, RegisterDelegatedAdministratorResponse, RegisterDelegatedAdministratorError, Credentials | HttpClient.HttpClient>;
export type RemoveAccountFromOrganizationError = AccessDeniedException | AccountNotFoundException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | MasterCannotLeaveOrganizationException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Removes the specified account from the organization.
 *
 * The removed account becomes a standalone account that isn't a member of any
 * organization. It's no longer subject to any policies and is responsible for its own bill
 * payments. The organization's management account is no longer charged for any expenses
 * accrued by the member account after it's removed from the organization.
 *
 * You can only call this operation from the management account. Member accounts can remove themselves with LeaveOrganization instead.
 *
 * When an account is removed from an organization, Organizations logs a membership
 * event in CloudTrail. The event is an
 * `AccountDepartedOrganization` event with
 * `departureMethod:REMOVED` and `departureTime`. This event is
 * available only in the management account's event history.
 *
 * - You can remove an account from your organization only if the account is
 * configured with the information required to operate as a standalone account.
 * When you create an account in an organization using the Organizations console,
 * API, or CLI commands, the information required of standalone accounts is
 * *not* automatically collected. For more information,
 * see Considerations before removing an account from an organization
 * in the *Organizations User Guide*.
 *
 * - The account that you want to leave must not be a delegated administrator
 * account for any Amazon Web Services service enabled for your organization. If the account
 * is a delegated administrator, you must first change the delegated
 * administrator account to another account that is remaining in the
 * organization.
 *
 * - After the account leaves the organization, all tags that were attached to
 * the account object in the organization are deleted. Amazon Web Services accounts outside
 * of an organization do not support tags.
 */
export declare const removeAccountFromOrganization: API.OperationMethod<RemoveAccountFromOrganizationRequest & RegionInput, RemoveAccountFromOrganizationResponse, RemoveAccountFromOrganizationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TargetNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds one or more tags to the specified resource.
 *
 * Currently, you can attach tags to the following resources in Organizations.
 *
 * - Amazon Web Services account
 *
 * - Organization root
 *
 * - Organizational unit (OU)
 *
 * - Policy (any type)
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateResponsibilityTransferError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | InvalidResponsibilityTransferTransitionException | ResponsibilityTransferAlreadyInStatusException | ResponsibilityTransferNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Ends a transfer. A *transfer* is an arrangement between two
 * management accounts where one account designates the other with specified
 * responsibilities for their organization.
 *
 * When a transfer ends, Organizations publishes a
 * `ResponsibilityTransferTerminated` service event to CloudTrail. Each affected
 * account receives this event, including upstream participants such as distributors in a
 * chained transfer. For an example log entry, see Example log entries: TerminateResponsibilityTransfer in the
 * *Organizations User Guide*.
 */
export declare const terminateResponsibilityTransfer: API.OperationMethod<TerminateResponsibilityTransferRequest & RegionInput, TerminateResponsibilityTransferResponse, TerminateResponsibilityTransferError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | InvalidInputException | ServiceException | TargetNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes any tags with the specified keys from the specified resource.
 *
 * You can attach tags to the following resources in Organizations.
 *
 * - Amazon Web Services account
 *
 * - Organization root
 *
 * - Organizational unit (OU)
 *
 * - Policy (any type)
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationalUnitError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | DuplicateOrganizationalUnitException | InvalidInputException | OrganizationalUnitNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Renames the specified organizational unit (OU). The ID and ARN don't change. The child
 * OUs and accounts remain in place, and any attached policies of the OU remain
 * attached.
 *
 * You can only call this operation from the management account.
 */
export declare const updateOrganizationalUnit: API.OperationMethod<UpdateOrganizationalUnitRequest & RegionInput, UpdateOrganizationalUnitResponse, UpdateOrganizationalUnitError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = AccessDeniedException | AWSOrganizationsNotInUseException | ConcurrentModificationException | ConstraintViolationException | DuplicatePolicyException | InvalidInputException | MalformedPolicyDocumentException | PolicyChangesInProgressException | PolicyNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Updates an existing policy with a new name, description, or content. If you don't
 * supply any parameter, that value remains unchanged. You can't change a policy's
 * type.
 *
 * You can only call this operation from the management account or a member account that is a delegated administrator.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest & RegionInput, UpdatePolicyResponse, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateResponsibilityTransferError = AccessDeniedException | AWSOrganizationsNotInUseException | ConstraintViolationException | InvalidInputException | ResponsibilityTransferNotFoundException | ServiceException | TooManyRequestsException | UnsupportedAPIEndpointException | CommonErrors;
/**
 * Updates a transfer. A *transfer* is the arrangement between two
 * management accounts where one account designates the other with specified
 * responsibilities for their organization.
 *
 * You can update the name assigned to a transfer.
 */
export declare const updateResponsibilityTransfer: API.OperationMethod<UpdateResponsibilityTransferRequest & RegionInput, UpdateResponsibilityTransferResponse, UpdateResponsibilityTransferError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=organizations.d.ts.map