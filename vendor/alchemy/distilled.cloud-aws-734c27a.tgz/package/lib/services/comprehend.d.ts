import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BatchSizeLimitExceededException_base: S.TaggedErrorClass<"BatchSizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchSizeLimitExceededException extends /*@__PURE__*/ BatchSizeLimitExceededException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidFilterException_base: S.TaggedErrorClass<"InvalidFilterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFilterException extends /*@__PURE__*/ InvalidFilterException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly Reason: any;
    readonly Detail: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const JobNotFoundException_base: S.TaggedErrorClass<"JobNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class JobNotFoundException extends /*@__PURE__*/ JobNotFoundException_base {
}
declare const KmsKeyValidationException_base: S.TaggedErrorClass<"KmsKeyValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyValidationException extends /*@__PURE__*/ KmsKeyValidationException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const TextSizeLimitExceededException_base: S.TaggedErrorClass<"TextSizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextSizeLimitExceededException extends /*@__PURE__*/ TextSizeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TooManyTagKeysException_base: S.TaggedErrorClass<"TooManyTagKeysException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagKeysException extends /*@__PURE__*/ TooManyTagKeysException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedLanguageException_base: S.TaggedErrorClass<"UnsupportedLanguageException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedLanguageException extends /*@__PURE__*/ UnsupportedLanguageException_base {
}
export type CustomerInputString = string | redacted.Redacted<string>;
export type CustomerInputStringList = (string | redacted.Redacted<string>)[];
export interface BatchDetectDominantLanguageRequest {
    TextList: (string | redacted.Redacted<string>)[];
}
export interface DominantLanguage {
    LanguageCode?: string | undefined;
    Score?: number | undefined;
}
export type ListOfDominantLanguages = DominantLanguage[];
export interface BatchDetectDominantLanguageItemResult {
    Index?: number | undefined;
    Languages?: DominantLanguage[] | undefined;
}
export type ListOfDetectDominantLanguageResult = BatchDetectDominantLanguageItemResult[];
export interface BatchItemError {
    Index?: number | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchItemErrorList = BatchItemError[];
export interface BatchDetectDominantLanguageResponse {
    ResultList: BatchDetectDominantLanguageItemResult[];
    ErrorList: BatchItemError[];
}
export type LanguageCode = "en" | "es" | "fr" | "de" | "it" | "pt" | "ar" | "hi" | "ja" | "ko" | "zh" | "zh-TW" | (string & {});
export interface BatchDetectEntitiesRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export type EntityType = "PERSON" | "LOCATION" | "ORGANIZATION" | "COMMERCIAL_ITEM" | "EVENT" | "DATE" | "QUANTITY" | "TITLE" | "OTHER" | (string & {});
export interface ChildBlock {
    ChildBlockId?: string | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
}
export type ListOfChildBlocks = ChildBlock[];
export interface BlockReference {
    BlockId?: string | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    ChildBlocks?: ChildBlock[] | undefined;
}
export type ListOfBlockReferences = BlockReference[];
export interface Entity {
    Score?: number | undefined;
    Type?: EntityType | undefined;
    Text?: string | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    BlockReferences?: BlockReference[] | undefined;
}
export type ListOfEntities = Entity[];
export interface BatchDetectEntitiesItemResult {
    Index?: number | undefined;
    Entities?: Entity[] | undefined;
}
export type ListOfDetectEntitiesResult = BatchDetectEntitiesItemResult[];
export interface BatchDetectEntitiesResponse {
    ResultList: BatchDetectEntitiesItemResult[];
    ErrorList: BatchItemError[];
}
export interface BatchDetectKeyPhrasesRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export interface KeyPhrase {
    Score?: number | undefined;
    Text?: string | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
}
export type ListOfKeyPhrases = KeyPhrase[];
export interface BatchDetectKeyPhrasesItemResult {
    Index?: number | undefined;
    KeyPhrases?: KeyPhrase[] | undefined;
}
export type ListOfDetectKeyPhrasesResult = BatchDetectKeyPhrasesItemResult[];
export interface BatchDetectKeyPhrasesResponse {
    ResultList: BatchDetectKeyPhrasesItemResult[];
    ErrorList: BatchItemError[];
}
export interface BatchDetectSentimentRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export type SentimentType = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | "MIXED" | (string & {});
export interface SentimentScore {
    Positive?: number | undefined;
    Negative?: number | undefined;
    Neutral?: number | undefined;
    Mixed?: number | undefined;
}
export interface BatchDetectSentimentItemResult {
    Index?: number | undefined;
    Sentiment?: SentimentType | undefined;
    SentimentScore?: SentimentScore | undefined;
}
export type ListOfDetectSentimentResult = BatchDetectSentimentItemResult[];
export interface BatchDetectSentimentResponse {
    ResultList: BatchDetectSentimentItemResult[];
    ErrorList: BatchItemError[];
}
export type SyntaxLanguageCode = "en" | "es" | "fr" | "de" | "it" | "pt" | (string & {});
export interface BatchDetectSyntaxRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: SyntaxLanguageCode;
}
export type PartOfSpeechTagType = "ADJ" | "ADP" | "ADV" | "AUX" | "CONJ" | "CCONJ" | "DET" | "INTJ" | "NOUN" | "NUM" | "O" | "PART" | "PRON" | "PROPN" | "PUNCT" | "SCONJ" | "SYM" | "VERB" | (string & {});
export interface PartOfSpeechTag {
    Tag?: PartOfSpeechTagType | undefined;
    Score?: number | undefined;
}
export interface SyntaxToken {
    TokenId?: number | undefined;
    Text?: string | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    PartOfSpeech?: PartOfSpeechTag | undefined;
}
export type ListOfSyntaxTokens = SyntaxToken[];
export interface BatchDetectSyntaxItemResult {
    Index?: number | undefined;
    SyntaxTokens?: SyntaxToken[] | undefined;
}
export type ListOfDetectSyntaxResult = BatchDetectSyntaxItemResult[];
export interface BatchDetectSyntaxResponse {
    ResultList: BatchDetectSyntaxItemResult[];
    ErrorList: BatchItemError[];
}
export interface BatchDetectTargetedSentimentRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export type ListOfDescriptiveMentionIndices = number[];
export type TargetedSentimentEntityType = "PERSON" | "LOCATION" | "ORGANIZATION" | "FACILITY" | "BRAND" | "COMMERCIAL_ITEM" | "MOVIE" | "MUSIC" | "BOOK" | "SOFTWARE" | "GAME" | "PERSONAL_TITLE" | "EVENT" | "DATE" | "QUANTITY" | "ATTRIBUTE" | "OTHER" | (string & {});
export interface MentionSentiment {
    Sentiment?: SentimentType | undefined;
    SentimentScore?: SentimentScore | undefined;
}
export interface TargetedSentimentMention {
    Score?: number | undefined;
    GroupScore?: number | undefined;
    Text?: string | undefined;
    Type?: TargetedSentimentEntityType | undefined;
    MentionSentiment?: MentionSentiment | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
}
export type ListOfMentions = TargetedSentimentMention[];
export interface TargetedSentimentEntity {
    DescriptiveMentionIndex?: number[] | undefined;
    Mentions?: TargetedSentimentMention[] | undefined;
}
export type ListOfTargetedSentimentEntities = TargetedSentimentEntity[];
export interface BatchDetectTargetedSentimentItemResult {
    Index?: number | undefined;
    Entities?: TargetedSentimentEntity[] | undefined;
}
export type ListOfDetectTargetedSentimentResult = BatchDetectTargetedSentimentItemResult[];
export interface BatchDetectTargetedSentimentResponse {
    ResultList: BatchDetectTargetedSentimentItemResult[];
    ErrorList: BatchItemError[];
}
export type DocumentClassifierEndpointArn = string;
export type SemiStructuredDocumentBlob = Uint8Array;
export type DocumentReadAction = "TEXTRACT_DETECT_DOCUMENT_TEXT" | "TEXTRACT_ANALYZE_DOCUMENT" | (string & {});
export type DocumentReadMode = "SERVICE_DEFAULT" | "FORCE_DOCUMENT_READ_ACTION" | (string & {});
export type DocumentReadFeatureTypes = "TABLES" | "FORMS" | (string & {});
export type ListOfDocumentReadFeatureTypes = DocumentReadFeatureTypes[];
export interface DocumentReaderConfig {
    DocumentReadAction: DocumentReadAction;
    DocumentReadMode?: DocumentReadMode | undefined;
    FeatureTypes?: DocumentReadFeatureTypes[] | undefined;
}
export interface ClassifyDocumentRequest {
    Text?: string | redacted.Redacted<string> | undefined;
    EndpointArn: string;
    Bytes?: Uint8Array | undefined;
    DocumentReaderConfig?: DocumentReaderConfig | undefined;
}
export interface DocumentClass {
    Name?: string | undefined;
    Score?: number | undefined;
    Page?: number | undefined;
}
export type ListOfClasses = DocumentClass[];
export interface DocumentLabel {
    Name?: string | undefined;
    Score?: number | undefined;
    Page?: number | undefined;
}
export type ListOfLabels = DocumentLabel[];
export interface ExtractedCharactersListItem {
    Page?: number | undefined;
    Count?: number | undefined;
}
export type ListOfExtractedCharacters = ExtractedCharactersListItem[];
export interface DocumentMetadata {
    Pages?: number | undefined;
    ExtractedCharacters?: ExtractedCharactersListItem[] | undefined;
}
export type DocumentType = "NATIVE_PDF" | "SCANNED_PDF" | "MS_WORD" | "IMAGE" | "PLAIN_TEXT" | "TEXTRACT_DETECT_DOCUMENT_TEXT_JSON" | "TEXTRACT_ANALYZE_DOCUMENT_JSON" | (string & {});
export interface DocumentTypeListItem {
    Page?: number | undefined;
    Type?: DocumentType | undefined;
}
export type ListOfDocumentType = DocumentTypeListItem[];
export type PageBasedErrorCode = "TEXTRACT_BAD_PAGE" | "TEXTRACT_PROVISIONED_THROUGHPUT_EXCEEDED" | "PAGE_CHARACTERS_EXCEEDED" | "PAGE_SIZE_EXCEEDED" | "INTERNAL_SERVER_ERROR" | (string & {});
export interface ErrorsListItem {
    Page?: number | undefined;
    ErrorCode?: PageBasedErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type ListOfErrors = ErrorsListItem[];
export type PageBasedWarningCode = "INFERENCING_PLAINTEXT_WITH_NATIVE_TRAINED_MODEL" | "INFERENCING_NATIVE_DOCUMENT_WITH_PLAINTEXT_TRAINED_MODEL" | (string & {});
export interface WarningsListItem {
    Page?: number | undefined;
    WarnCode?: PageBasedWarningCode | undefined;
    WarnMessage?: string | undefined;
}
export type ListOfWarnings = WarningsListItem[];
export interface ClassifyDocumentResponse {
    Classes?: DocumentClass[] | undefined;
    Labels?: DocumentLabel[] | undefined;
    DocumentMetadata?: DocumentMetadata | undefined;
    DocumentType?: DocumentTypeListItem[] | undefined;
    Errors?: ErrorsListItem[] | undefined;
    Warnings?: WarningsListItem[] | undefined;
}
export interface ContainsPiiEntitiesRequest {
    Text: string;
    LanguageCode: LanguageCode;
}
export type PiiEntityType = "BANK_ACCOUNT_NUMBER" | "BANK_ROUTING" | "CREDIT_DEBIT_NUMBER" | "CREDIT_DEBIT_CVV" | "CREDIT_DEBIT_EXPIRY" | "PIN" | "EMAIL" | "ADDRESS" | "NAME" | "PHONE" | "SSN" | "DATE_TIME" | "PASSPORT_NUMBER" | "DRIVER_ID" | "URL" | "AGE" | "USERNAME" | "PASSWORD" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "IP_ADDRESS" | "MAC_ADDRESS" | "ALL" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "IN_PERMANENT_ACCOUNT_NUMBER" | "IN_NREGA" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "CA_HEALTH_NUMBER" | "IN_AADHAAR" | "IN_VOTER_NUMBER" | (string & {});
export interface EntityLabel {
    Name?: PiiEntityType | undefined;
    Score?: number | undefined;
}
export type ListOfEntityLabels = EntityLabel[];
export interface ContainsPiiEntitiesResponse {
    Labels?: EntityLabel[] | undefined;
}
export type ComprehendFlywheelArn = string;
export type ComprehendArnName = string;
export type DatasetType = "TRAIN" | "TEST" | (string & {});
export type Description = string;
export type AttributeNamesListItem = string;
export type AttributeNamesList = string[];
export type S3Uri = string;
export type AugmentedManifestsDocumentTypeFormat = "PLAIN_TEXT_DOCUMENT" | "SEMI_STRUCTURED_DOCUMENT" | (string & {});
export interface DatasetAugmentedManifestsListItem {
    AttributeNames: string[];
    S3Uri: string;
    AnnotationDataS3Uri?: string | undefined;
    SourceDocumentsS3Uri?: string | undefined;
    DocumentType?: AugmentedManifestsDocumentTypeFormat | undefined;
}
export type DatasetAugmentedManifestsList = DatasetAugmentedManifestsListItem[];
export type DatasetDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export type LabelDelimiter = string;
export interface DatasetDocumentClassifierInputDataConfig {
    S3Uri: string;
    LabelDelimiter?: string | undefined;
}
export interface DatasetEntityRecognizerAnnotations {
    S3Uri: string;
}
export type InputFormat = "ONE_DOC_PER_FILE" | "ONE_DOC_PER_LINE" | (string & {});
export interface DatasetEntityRecognizerDocuments {
    S3Uri: string;
    InputFormat?: InputFormat | undefined;
}
export interface DatasetEntityRecognizerEntityList {
    S3Uri: string;
}
export interface DatasetEntityRecognizerInputDataConfig {
    Annotations?: DatasetEntityRecognizerAnnotations | undefined;
    Documents: DatasetEntityRecognizerDocuments;
    EntityList?: DatasetEntityRecognizerEntityList | undefined;
}
export interface DatasetInputDataConfig {
    AugmentedManifests?: DatasetAugmentedManifestsListItem[] | undefined;
    DataFormat?: DatasetDataFormat | undefined;
    DocumentClassifierInputDataConfig?: DatasetDocumentClassifierInputDataConfig | undefined;
    EntityRecognizerInputDataConfig?: DatasetEntityRecognizerInputDataConfig | undefined;
}
export type ClientRequestTokenString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface CreateDatasetRequest {
    FlywheelArn: string;
    DatasetName: string;
    DatasetType?: DatasetType | undefined;
    Description?: string | undefined;
    InputDataConfig: DatasetInputDataConfig;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ComprehendDatasetArn = string;
export interface CreateDatasetResponse {
    DatasetArn?: string | undefined;
}
export type VersionName = string;
export type IamRoleArn = string;
export type DocumentClassifierDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export type Split = "TRAIN" | "TEST" | (string & {});
export interface AugmentedManifestsListItem {
    S3Uri: string;
    Split?: Split | undefined;
    AttributeNames: string[];
    AnnotationDataS3Uri?: string | undefined;
    SourceDocumentsS3Uri?: string | undefined;
    DocumentType?: AugmentedManifestsDocumentTypeFormat | undefined;
}
export type DocumentClassifierAugmentedManifestsList = AugmentedManifestsListItem[];
export type DocumentClassifierDocumentTypeFormat = "PLAIN_TEXT_DOCUMENT" | "SEMI_STRUCTURED_DOCUMENT" | (string & {});
export interface DocumentClassifierDocuments {
    S3Uri: string;
    TestS3Uri?: string | undefined;
}
export interface DocumentClassifierInputDataConfig {
    DataFormat?: DocumentClassifierDataFormat | undefined;
    S3Uri?: string | undefined;
    TestS3Uri?: string | undefined;
    LabelDelimiter?: string | undefined;
    AugmentedManifests?: AugmentedManifestsListItem[] | undefined;
    DocumentType?: DocumentClassifierDocumentTypeFormat | undefined;
    Documents?: DocumentClassifierDocuments | undefined;
    DocumentReaderConfig?: DocumentReaderConfig | undefined;
}
export type KmsKeyId = string;
export interface DocumentClassifierOutputDataConfig {
    S3Uri?: string | undefined;
    KmsKeyId?: string | undefined;
    FlywheelStatsS3Prefix?: string | undefined;
}
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type SubnetId = string;
export type Subnets = string[];
export interface VpcConfig {
    SecurityGroupIds: string[];
    Subnets: string[];
}
export type DocumentClassifierMode = "MULTI_CLASS" | "MULTI_LABEL" | (string & {});
export type Policy = string;
export interface CreateDocumentClassifierRequest {
    DocumentClassifierName: string;
    VersionName?: string | undefined;
    DataAccessRoleArn: string;
    Tags?: Tag[] | undefined;
    InputDataConfig: DocumentClassifierInputDataConfig;
    OutputDataConfig?: DocumentClassifierOutputDataConfig | undefined;
    ClientRequestToken?: string | undefined;
    LanguageCode: LanguageCode;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Mode?: DocumentClassifierMode | undefined;
    ModelKmsKeyId?: string | undefined;
    ModelPolicy?: string | undefined;
}
export type DocumentClassifierArn = string;
export interface CreateDocumentClassifierResponse {
    DocumentClassifierArn?: string | undefined;
}
export type ComprehendEndpointName = string;
export type ComprehendModelArn = string;
export type InferenceUnitsInteger = number;
export interface CreateEndpointRequest {
    EndpointName: string;
    ModelArn?: string | undefined;
    DesiredInferenceUnits: number;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
    DataAccessRoleArn?: string | undefined;
    FlywheelArn?: string | undefined;
}
export type ComprehendEndpointArn = string;
export interface CreateEndpointResponse {
    EndpointArn?: string | undefined;
    ModelArn?: string | undefined;
}
export type EntityRecognizerDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export type EntityTypeName = string;
export interface EntityTypesListItem {
    Type: string;
}
export type EntityTypesList = EntityTypesListItem[];
export interface EntityRecognizerDocuments {
    S3Uri: string;
    TestS3Uri?: string | undefined;
    InputFormat?: InputFormat | undefined;
}
export interface EntityRecognizerAnnotations {
    S3Uri: string;
    TestS3Uri?: string | undefined;
}
export interface EntityRecognizerEntityList {
    S3Uri: string;
}
export type EntityRecognizerAugmentedManifestsList = AugmentedManifestsListItem[];
export interface EntityRecognizerInputDataConfig {
    DataFormat?: EntityRecognizerDataFormat | undefined;
    EntityTypes: EntityTypesListItem[];
    Documents?: EntityRecognizerDocuments | undefined;
    Annotations?: EntityRecognizerAnnotations | undefined;
    EntityList?: EntityRecognizerEntityList | undefined;
    AugmentedManifests?: AugmentedManifestsListItem[] | undefined;
}
export interface CreateEntityRecognizerRequest {
    RecognizerName: string;
    VersionName?: string | undefined;
    DataAccessRoleArn: string;
    Tags?: Tag[] | undefined;
    InputDataConfig: EntityRecognizerInputDataConfig;
    ClientRequestToken?: string | undefined;
    LanguageCode: LanguageCode;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    ModelKmsKeyId?: string | undefined;
    ModelPolicy?: string | undefined;
}
export type EntityRecognizerArn = string;
export interface CreateEntityRecognizerResponse {
    EntityRecognizerArn?: string | undefined;
}
export type LabelListItem = string;
export type LabelsList = string[];
export interface DocumentClassificationConfig {
    Mode: DocumentClassifierMode;
    Labels?: string[] | undefined;
}
export interface EntityRecognitionConfig {
    EntityTypes: EntityTypesListItem[];
}
export interface TaskConfig {
    LanguageCode: LanguageCode;
    DocumentClassificationConfig?: DocumentClassificationConfig | undefined;
    EntityRecognitionConfig?: EntityRecognitionConfig | undefined;
}
export type ModelType = "DOCUMENT_CLASSIFIER" | "ENTITY_RECOGNIZER" | (string & {});
export type FlywheelS3Uri = string;
export interface DataSecurityConfig {
    ModelKmsKeyId?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    DataLakeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface CreateFlywheelRequest {
    FlywheelName: string;
    ActiveModelArn?: string | undefined;
    DataAccessRoleArn: string;
    TaskConfig?: TaskConfig | undefined;
    ModelType?: ModelType | undefined;
    DataLakeS3Uri: string;
    DataSecurityConfig?: DataSecurityConfig | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateFlywheelResponse {
    FlywheelArn?: string | undefined;
    ActiveModelArn?: string | undefined;
}
export interface DeleteDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export interface DeleteDocumentClassifierResponse {
}
export interface DeleteEndpointRequest {
    EndpointArn: string;
}
export interface DeleteEndpointResponse {
}
export interface DeleteEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export interface DeleteEntityRecognizerResponse {
}
export interface DeleteFlywheelRequest {
    FlywheelArn: string;
}
export interface DeleteFlywheelResponse {
}
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
    PolicyRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface DescribeDatasetRequest {
    DatasetArn: string;
}
export type DatasetStatus = "CREATING" | "COMPLETED" | "FAILED" | (string & {});
export type AnyLengthString = string;
export type NumberOfDocuments = number;
export interface DatasetProperties {
    DatasetArn?: string | undefined;
    DatasetName?: string | undefined;
    DatasetType?: DatasetType | undefined;
    DatasetS3Uri?: string | undefined;
    Description?: string | undefined;
    Status?: DatasetStatus | undefined;
    Message?: string | undefined;
    NumberOfDocuments?: number | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface DescribeDatasetResponse {
    DatasetProperties?: DatasetProperties | undefined;
}
export type JobId = string;
export interface DescribeDocumentClassificationJobRequest {
    JobId: string;
}
export type ComprehendArn = string;
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export interface InputDataConfig {
    S3Uri: string;
    InputFormat?: InputFormat | undefined;
    DocumentReaderConfig?: DocumentReaderConfig | undefined;
}
export interface OutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string | undefined;
}
export interface DocumentClassificationJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    DocumentClassifierArn?: string | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    FlywheelArn?: string | undefined;
}
export interface DescribeDocumentClassificationJobResponse {
    DocumentClassificationJobProperties?: DocumentClassificationJobProperties | undefined;
}
export interface DescribeDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export type ModelStatus = "SUBMITTED" | "TRAINING" | "DELETING" | "STOP_REQUESTED" | "STOPPED" | "IN_ERROR" | "TRAINED" | "TRAINED_WITH_WARNING" | (string & {});
export interface ClassifierEvaluationMetrics {
    Accuracy?: number | undefined;
    Precision?: number | undefined;
    Recall?: number | undefined;
    F1Score?: number | undefined;
    MicroPrecision?: number | undefined;
    MicroRecall?: number | undefined;
    MicroF1Score?: number | undefined;
    HammingLoss?: number | undefined;
}
export interface ClassifierMetadata {
    NumberOfLabels?: number | undefined;
    NumberOfTrainedDocuments?: number | undefined;
    NumberOfTestDocuments?: number | undefined;
    EvaluationMetrics?: ClassifierEvaluationMetrics | undefined;
}
export interface DocumentClassifierProperties {
    DocumentClassifierArn?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    Status?: ModelStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    TrainingStartTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    InputDataConfig?: DocumentClassifierInputDataConfig | undefined;
    OutputDataConfig?: DocumentClassifierOutputDataConfig | undefined;
    ClassifierMetadata?: ClassifierMetadata | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Mode?: DocumentClassifierMode | undefined;
    ModelKmsKeyId?: string | undefined;
    VersionName?: string | undefined;
    SourceModelArn?: string | undefined;
    FlywheelArn?: string | undefined;
}
export interface DescribeDocumentClassifierResponse {
    DocumentClassifierProperties?: DocumentClassifierProperties | undefined;
}
export interface DescribeDominantLanguageDetectionJobRequest {
    JobId: string;
}
export interface DominantLanguageDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface DescribeDominantLanguageDetectionJobResponse {
    DominantLanguageDetectionJobProperties?: DominantLanguageDetectionJobProperties | undefined;
}
export interface DescribeEndpointRequest {
    EndpointArn: string;
}
export type EndpointStatus = "CREATING" | "DELETING" | "FAILED" | "IN_SERVICE" | "UPDATING" | (string & {});
export interface EndpointProperties {
    EndpointArn?: string | undefined;
    Status?: EndpointStatus | undefined;
    Message?: string | undefined;
    ModelArn?: string | undefined;
    DesiredModelArn?: string | undefined;
    DesiredInferenceUnits?: number | undefined;
    CurrentInferenceUnits?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    DataAccessRoleArn?: string | undefined;
    DesiredDataAccessRoleArn?: string | undefined;
    FlywheelArn?: string | undefined;
}
export interface DescribeEndpointResponse {
    EndpointProperties?: EndpointProperties | undefined;
}
export interface DescribeEntitiesDetectionJobRequest {
    JobId: string;
}
export interface EntitiesDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    EntityRecognizerArn?: string | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    FlywheelArn?: string | undefined;
}
export interface DescribeEntitiesDetectionJobResponse {
    EntitiesDetectionJobProperties?: EntitiesDetectionJobProperties | undefined;
}
export interface DescribeEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export interface EntityRecognizerEvaluationMetrics {
    Precision?: number | undefined;
    Recall?: number | undefined;
    F1Score?: number | undefined;
}
export interface EntityTypesEvaluationMetrics {
    Precision?: number | undefined;
    Recall?: number | undefined;
    F1Score?: number | undefined;
}
export interface EntityRecognizerMetadataEntityTypesListItem {
    Type?: string | undefined;
    EvaluationMetrics?: EntityTypesEvaluationMetrics | undefined;
    NumberOfTrainMentions?: number | undefined;
}
export type EntityRecognizerMetadataEntityTypesList = EntityRecognizerMetadataEntityTypesListItem[];
export interface EntityRecognizerMetadata {
    NumberOfTrainedDocuments?: number | undefined;
    NumberOfTestDocuments?: number | undefined;
    EvaluationMetrics?: EntityRecognizerEvaluationMetrics | undefined;
    EntityTypes?: EntityRecognizerMetadataEntityTypesListItem[] | undefined;
}
export interface EntityRecognizerOutputDataConfig {
    FlywheelStatsS3Prefix?: string | undefined;
}
export interface EntityRecognizerProperties {
    EntityRecognizerArn?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    Status?: ModelStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    TrainingStartTime?: Date | undefined;
    TrainingEndTime?: Date | undefined;
    InputDataConfig?: EntityRecognizerInputDataConfig | undefined;
    RecognizerMetadata?: EntityRecognizerMetadata | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    ModelKmsKeyId?: string | undefined;
    VersionName?: string | undefined;
    SourceModelArn?: string | undefined;
    FlywheelArn?: string | undefined;
    OutputDataConfig?: EntityRecognizerOutputDataConfig | undefined;
}
export interface DescribeEntityRecognizerResponse {
    EntityRecognizerProperties?: EntityRecognizerProperties | undefined;
}
export interface DescribeEventsDetectionJobRequest {
    JobId: string;
}
export type EventTypeString = string;
export type TargetEventTypes = string[];
export interface EventsDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    TargetEventTypes?: string[] | undefined;
}
export interface DescribeEventsDetectionJobResponse {
    EventsDetectionJobProperties?: EventsDetectionJobProperties | undefined;
}
export interface DescribeFlywheelRequest {
    FlywheelArn: string;
}
export type FlywheelStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type FlywheelIterationId = string;
export interface FlywheelProperties {
    FlywheelArn?: string | undefined;
    ActiveModelArn?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    TaskConfig?: TaskConfig | undefined;
    DataLakeS3Uri?: string | undefined;
    DataSecurityConfig?: DataSecurityConfig | undefined;
    Status?: FlywheelStatus | undefined;
    ModelType?: ModelType | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LatestFlywheelIteration?: string | undefined;
}
export interface DescribeFlywheelResponse {
    FlywheelProperties?: FlywheelProperties | undefined;
}
export interface DescribeFlywheelIterationRequest {
    FlywheelArn: string;
    FlywheelIterationId: string;
}
export type FlywheelIterationStatus = "TRAINING" | "EVALUATING" | "COMPLETED" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export interface FlywheelModelEvaluationMetrics {
    AverageF1Score?: number | undefined;
    AveragePrecision?: number | undefined;
    AverageRecall?: number | undefined;
    AverageAccuracy?: number | undefined;
}
export interface FlywheelIterationProperties {
    FlywheelArn?: string | undefined;
    FlywheelIterationId?: string | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
    Status?: FlywheelIterationStatus | undefined;
    Message?: string | undefined;
    EvaluatedModelArn?: string | undefined;
    EvaluatedModelMetrics?: FlywheelModelEvaluationMetrics | undefined;
    TrainedModelArn?: string | undefined;
    TrainedModelMetrics?: FlywheelModelEvaluationMetrics | undefined;
    EvaluationManifestS3Prefix?: string | undefined;
}
export interface DescribeFlywheelIterationResponse {
    FlywheelIterationProperties?: FlywheelIterationProperties | undefined;
}
export interface DescribeKeyPhrasesDetectionJobRequest {
    JobId: string;
}
export interface KeyPhrasesDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface DescribeKeyPhrasesDetectionJobResponse {
    KeyPhrasesDetectionJobProperties?: KeyPhrasesDetectionJobProperties | undefined;
}
export interface DescribePiiEntitiesDetectionJobRequest {
    JobId: string;
}
export interface PiiOutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string | undefined;
}
export type ListOfPiiEntityTypes = PiiEntityType[];
export type PiiEntitiesDetectionMaskMode = "MASK" | "REPLACE_WITH_PII_ENTITY_TYPE" | (string & {});
export type MaskCharacter = string;
export interface RedactionConfig {
    PiiEntityTypes?: PiiEntityType[] | undefined;
    MaskMode?: PiiEntitiesDetectionMaskMode | undefined;
    MaskCharacter?: string | undefined;
}
export type PiiEntitiesDetectionMode = "ONLY_REDACTION" | "ONLY_OFFSETS" | (string & {});
export interface PiiEntitiesDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: PiiOutputDataConfig | undefined;
    RedactionConfig?: RedactionConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    Mode?: PiiEntitiesDetectionMode | undefined;
}
export interface DescribePiiEntitiesDetectionJobResponse {
    PiiEntitiesDetectionJobProperties?: PiiEntitiesDetectionJobProperties | undefined;
}
export interface DescribeResourcePolicyRequest {
    ResourceArn: string;
}
export interface DescribeResourcePolicyResponse {
    ResourcePolicy?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    PolicyRevisionId?: string | undefined;
}
export interface DescribeSentimentDetectionJobRequest {
    JobId: string;
}
export interface SentimentDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface DescribeSentimentDetectionJobResponse {
    SentimentDetectionJobProperties?: SentimentDetectionJobProperties | undefined;
}
export interface DescribeTargetedSentimentDetectionJobRequest {
    JobId: string;
}
export interface TargetedSentimentDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface DescribeTargetedSentimentDetectionJobResponse {
    TargetedSentimentDetectionJobProperties?: TargetedSentimentDetectionJobProperties | undefined;
}
export interface DescribeTopicsDetectionJobRequest {
    JobId: string;
}
export interface TopicsDetectionJobProperties {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    NumberOfTopics?: number | undefined;
    DataAccessRoleArn?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface DescribeTopicsDetectionJobResponse {
    TopicsDetectionJobProperties?: TopicsDetectionJobProperties | undefined;
}
export interface DetectDominantLanguageRequest {
    Text: string | redacted.Redacted<string>;
}
export interface DetectDominantLanguageResponse {
    Languages?: DominantLanguage[] | undefined;
}
export type EntityRecognizerEndpointArn = string;
export interface DetectEntitiesRequest {
    Text?: string | redacted.Redacted<string> | undefined;
    LanguageCode?: LanguageCode | undefined;
    EndpointArn?: string | undefined;
    Bytes?: Uint8Array | undefined;
    DocumentReaderConfig?: DocumentReaderConfig | undefined;
}
export type BlockType = "LINE" | "WORD" | (string & {});
export interface BoundingBox {
    Height?: number | undefined;
    Left?: number | undefined;
    Top?: number | undefined;
    Width?: number | undefined;
}
export interface Point {
    X?: number | undefined;
    Y?: number | undefined;
}
export type Polygon = Point[];
export interface Geometry {
    BoundingBox?: BoundingBox | undefined;
    Polygon?: Point[] | undefined;
}
export type StringList = string[];
export type RelationshipType = "CHILD" | (string & {});
export interface RelationshipsListItem {
    Ids?: string[] | undefined;
    Type?: RelationshipType | undefined;
}
export type ListOfRelationships = RelationshipsListItem[];
export interface Block {
    Id?: string | undefined;
    BlockType?: BlockType | undefined;
    Text?: string | undefined;
    Page?: number | undefined;
    Geometry?: Geometry | undefined;
    Relationships?: RelationshipsListItem[] | undefined;
}
export type ListOfBlocks = Block[];
export interface DetectEntitiesResponse {
    Entities?: Entity[] | undefined;
    DocumentMetadata?: DocumentMetadata | undefined;
    DocumentType?: DocumentTypeListItem[] | undefined;
    Blocks?: Block[] | undefined;
    Errors?: ErrorsListItem[] | undefined;
}
export interface DetectKeyPhrasesRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export interface DetectKeyPhrasesResponse {
    KeyPhrases?: KeyPhrase[] | undefined;
}
export interface DetectPiiEntitiesRequest {
    Text: string;
    LanguageCode: LanguageCode;
}
export interface PiiEntity {
    Score?: number | undefined;
    Type?: PiiEntityType | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
}
export type ListOfPiiEntities = PiiEntity[];
export interface DetectPiiEntitiesResponse {
    Entities?: PiiEntity[] | undefined;
}
export interface DetectSentimentRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export interface DetectSentimentResponse {
    Sentiment?: SentimentType | undefined;
    SentimentScore?: SentimentScore | undefined;
}
export interface DetectSyntaxRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: SyntaxLanguageCode;
}
export interface DetectSyntaxResponse {
    SyntaxTokens?: SyntaxToken[] | undefined;
}
export interface DetectTargetedSentimentRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export interface DetectTargetedSentimentResponse {
    Entities?: TargetedSentimentEntity[] | undefined;
}
export interface TextSegment {
    Text: string | redacted.Redacted<string>;
}
export type ListOfTextSegments = TextSegment[];
export interface DetectToxicContentRequest {
    TextSegments: TextSegment[];
    LanguageCode: LanguageCode;
}
export type ToxicContentType = "GRAPHIC" | "HARASSMENT_OR_ABUSE" | "HATE_SPEECH" | "INSULT" | "PROFANITY" | "SEXUAL" | "VIOLENCE_OR_THREAT" | (string & {});
export interface ToxicContent {
    Name?: ToxicContentType | undefined;
    Score?: number | undefined;
}
export type ListOfToxicContent = ToxicContent[];
export interface ToxicLabels {
    Labels?: ToxicContent[] | undefined;
    Toxicity?: number | undefined;
}
export type ListOfToxicLabels = ToxicLabels[];
export interface DetectToxicContentResponse {
    ResultList?: ToxicLabels[] | undefined;
}
export interface ImportModelRequest {
    SourceModelArn: string;
    ModelName?: string | undefined;
    VersionName?: string | undefined;
    ModelKmsKeyId?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportModelResponse {
    ModelArn?: string | undefined;
}
export interface DatasetFilter {
    Status?: DatasetStatus | undefined;
    DatasetType?: DatasetType | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
}
export type MaxResultsInteger = number;
export interface ListDatasetsRequest {
    FlywheelArn?: string | undefined;
    Filter?: DatasetFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DatasetPropertiesList = DatasetProperties[];
export interface ListDatasetsResponse {
    DatasetPropertiesList?: DatasetProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface DocumentClassificationJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListDocumentClassificationJobsRequest {
    Filter?: DocumentClassificationJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DocumentClassificationJobPropertiesList = DocumentClassificationJobProperties[];
export interface ListDocumentClassificationJobsResponse {
    DocumentClassificationJobPropertiesList?: DocumentClassificationJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface DocumentClassifierFilter {
    Status?: ModelStatus | undefined;
    DocumentClassifierName?: string | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListDocumentClassifiersRequest {
    Filter?: DocumentClassifierFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DocumentClassifierPropertiesList = DocumentClassifierProperties[];
export interface ListDocumentClassifiersResponse {
    DocumentClassifierPropertiesList?: DocumentClassifierProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDocumentClassifierSummariesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DocumentClassifierSummary {
    DocumentClassifierName?: string | undefined;
    NumberOfVersions?: number | undefined;
    LatestVersionCreatedAt?: Date | undefined;
    LatestVersionName?: string | undefined;
    LatestVersionStatus?: ModelStatus | undefined;
}
export type DocumentClassifierSummariesList = DocumentClassifierSummary[];
export interface ListDocumentClassifierSummariesResponse {
    DocumentClassifierSummariesList?: DocumentClassifierSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface DominantLanguageDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListDominantLanguageDetectionJobsRequest {
    Filter?: DominantLanguageDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DominantLanguageDetectionJobPropertiesList = DominantLanguageDetectionJobProperties[];
export interface ListDominantLanguageDetectionJobsResponse {
    DominantLanguageDetectionJobPropertiesList?: DominantLanguageDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface EndpointFilter {
    ModelArn?: string | undefined;
    Status?: EndpointStatus | undefined;
    CreationTimeBefore?: Date | undefined;
    CreationTimeAfter?: Date | undefined;
}
export interface ListEndpointsRequest {
    Filter?: EndpointFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EndpointPropertiesList = EndpointProperties[];
export interface ListEndpointsResponse {
    EndpointPropertiesList?: EndpointProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface EntitiesDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListEntitiesDetectionJobsRequest {
    Filter?: EntitiesDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EntitiesDetectionJobPropertiesList = EntitiesDetectionJobProperties[];
export interface ListEntitiesDetectionJobsResponse {
    EntitiesDetectionJobPropertiesList?: EntitiesDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface EntityRecognizerFilter {
    Status?: ModelStatus | undefined;
    RecognizerName?: string | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListEntityRecognizersRequest {
    Filter?: EntityRecognizerFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EntityRecognizerPropertiesList = EntityRecognizerProperties[];
export interface ListEntityRecognizersResponse {
    EntityRecognizerPropertiesList?: EntityRecognizerProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEntityRecognizerSummariesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EntityRecognizerSummary {
    RecognizerName?: string | undefined;
    NumberOfVersions?: number | undefined;
    LatestVersionCreatedAt?: Date | undefined;
    LatestVersionName?: string | undefined;
    LatestVersionStatus?: ModelStatus | undefined;
}
export type EntityRecognizerSummariesList = EntityRecognizerSummary[];
export interface ListEntityRecognizerSummariesResponse {
    EntityRecognizerSummariesList?: EntityRecognizerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface EventsDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListEventsDetectionJobsRequest {
    Filter?: EventsDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EventsDetectionJobPropertiesList = EventsDetectionJobProperties[];
export interface ListEventsDetectionJobsResponse {
    EventsDetectionJobPropertiesList?: EventsDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface FlywheelIterationFilter {
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
}
export interface ListFlywheelIterationHistoryRequest {
    FlywheelArn: string;
    Filter?: FlywheelIterationFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type FlywheelIterationPropertiesList = FlywheelIterationProperties[];
export interface ListFlywheelIterationHistoryResponse {
    FlywheelIterationPropertiesList?: FlywheelIterationProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface FlywheelFilter {
    Status?: FlywheelStatus | undefined;
    CreationTimeAfter?: Date | undefined;
    CreationTimeBefore?: Date | undefined;
}
export interface ListFlywheelsRequest {
    Filter?: FlywheelFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FlywheelSummary {
    FlywheelArn?: string | undefined;
    ActiveModelArn?: string | undefined;
    DataLakeS3Uri?: string | undefined;
    Status?: FlywheelStatus | undefined;
    ModelType?: ModelType | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LatestFlywheelIteration?: string | undefined;
}
export type FlywheelSummaryList = FlywheelSummary[];
export interface ListFlywheelsResponse {
    FlywheelSummaryList?: FlywheelSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface KeyPhrasesDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListKeyPhrasesDetectionJobsRequest {
    Filter?: KeyPhrasesDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type KeyPhrasesDetectionJobPropertiesList = KeyPhrasesDetectionJobProperties[];
export interface ListKeyPhrasesDetectionJobsResponse {
    KeyPhrasesDetectionJobPropertiesList?: KeyPhrasesDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface PiiEntitiesDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListPiiEntitiesDetectionJobsRequest {
    Filter?: PiiEntitiesDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PiiEntitiesDetectionJobPropertiesList = PiiEntitiesDetectionJobProperties[];
export interface ListPiiEntitiesDetectionJobsResponse {
    PiiEntitiesDetectionJobPropertiesList?: PiiEntitiesDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface SentimentDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListSentimentDetectionJobsRequest {
    Filter?: SentimentDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SentimentDetectionJobPropertiesList = SentimentDetectionJobProperties[];
export interface ListSentimentDetectionJobsResponse {
    SentimentDetectionJobPropertiesList?: SentimentDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TargetedSentimentDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListTargetedSentimentDetectionJobsRequest {
    Filter?: TargetedSentimentDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TargetedSentimentDetectionJobPropertiesList = TargetedSentimentDetectionJobProperties[];
export interface ListTargetedSentimentDetectionJobsResponse {
    TargetedSentimentDetectionJobPropertiesList?: TargetedSentimentDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface TopicsDetectionJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export interface ListTopicsDetectionJobsRequest {
    Filter?: TopicsDetectionJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TopicsDetectionJobPropertiesList = TopicsDetectionJobProperties[];
export interface ListTopicsDetectionJobsResponse {
    TopicsDetectionJobPropertiesList?: TopicsDetectionJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    ResourcePolicy: string;
    PolicyRevisionId?: string | undefined;
}
export interface PutResourcePolicyResponse {
    PolicyRevisionId?: string | undefined;
}
export interface StartDocumentClassificationJobRequest {
    JobName?: string | undefined;
    DocumentClassifierArn?: string | undefined;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
    FlywheelArn?: string | undefined;
}
export interface StartDocumentClassificationJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
    DocumentClassifierArn?: string | undefined;
}
export interface StartDominantLanguageDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartDominantLanguageDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StartEntitiesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    EntityRecognizerArn?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
    FlywheelArn?: string | undefined;
}
export interface StartEntitiesDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
    EntityRecognizerArn?: string | undefined;
}
export interface StartEventsDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    TargetEventTypes: string[];
    Tags?: Tag[] | undefined;
}
export interface StartEventsDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StartFlywheelIterationRequest {
    FlywheelArn: string;
    ClientRequestToken?: string | undefined;
}
export interface StartFlywheelIterationResponse {
    FlywheelArn?: string | undefined;
    FlywheelIterationId?: string | undefined;
}
export interface StartKeyPhrasesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartKeyPhrasesDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StartPiiEntitiesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    Mode: PiiEntitiesDetectionMode;
    RedactionConfig?: RedactionConfig | undefined;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartPiiEntitiesDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StartSentimentDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartSentimentDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StartTargetedSentimentDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartTargetedSentimentDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export type NumberOfTopicsInteger = number;
export interface StartTopicsDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    NumberOfTopics?: number | undefined;
    ClientRequestToken?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartTopicsDetectionJobResponse {
    JobId?: string | undefined;
    JobArn?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopDominantLanguageDetectionJobRequest {
    JobId: string;
}
export interface StopDominantLanguageDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopEntitiesDetectionJobRequest {
    JobId: string;
}
export interface StopEntitiesDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopEventsDetectionJobRequest {
    JobId: string;
}
export interface StopEventsDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopKeyPhrasesDetectionJobRequest {
    JobId: string;
}
export interface StopKeyPhrasesDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopPiiEntitiesDetectionJobRequest {
    JobId: string;
}
export interface StopPiiEntitiesDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopSentimentDetectionJobRequest {
    JobId: string;
}
export interface StopSentimentDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopTargetedSentimentDetectionJobRequest {
    JobId: string;
}
export interface StopTargetedSentimentDetectionJobResponse {
    JobId?: string | undefined;
    JobStatus?: JobStatus | undefined;
}
export interface StopTrainingDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export interface StopTrainingDocumentClassifierResponse {
}
export interface StopTrainingEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export interface StopTrainingEntityRecognizerResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateEndpointRequest {
    EndpointArn: string;
    DesiredModelArn?: string | undefined;
    DesiredInferenceUnits?: number | undefined;
    DesiredDataAccessRoleArn?: string | undefined;
    FlywheelArn?: string | undefined;
}
export interface UpdateEndpointResponse {
    DesiredModelArn?: string | undefined;
}
export interface UpdateDataSecurityConfig {
    ModelKmsKeyId?: string | undefined;
    VolumeKmsKeyId?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
}
export interface UpdateFlywheelRequest {
    FlywheelArn: string;
    ActiveModelArn?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    DataSecurityConfig?: UpdateDataSecurityConfig | undefined;
}
export interface UpdateFlywheelResponse {
    FlywheelProperties?: FlywheelProperties | undefined;
}
export type InvalidRequestReason = "INVALID_DOCUMENT" | (string & {});
export type InvalidRequestDetailReason = "DOCUMENT_SIZE_EXCEEDED" | "UNSUPPORTED_DOC_TYPE" | "PAGE_LIMIT_EXCEEDED" | "TEXTRACT_ACCESS_DENIED" | (string & {});
export interface InvalidRequestDetail {
    Reason?: InvalidRequestDetailReason | undefined;
}
export type BatchDetectDominantLanguageError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | CommonErrors;
/**
 * Determines the dominant language of the input text for a batch of documents. For a list
 * of languages that Amazon Comprehend can detect, see Amazon Comprehend Supported Languages.
 */
export declare const batchDetectDominantLanguage: API.OperationMethod<BatchDetectDominantLanguageRequest & RegionInput, BatchDetectDominantLanguageResponse, BatchDetectDominantLanguageError, Credentials | HttpClient.HttpClient>;
export type BatchDetectEntitiesError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the text of a batch of documents for named entities and returns information
 * about them. For more information about named entities, see
 * Entities in the Comprehend Developer Guide.
 */
export declare const batchDetectEntities: API.OperationMethod<BatchDetectEntitiesRequest & RegionInput, BatchDetectEntitiesResponse, BatchDetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type BatchDetectKeyPhrasesError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects the key noun phrases found in a batch of documents.
 */
export declare const batchDetectKeyPhrases: API.OperationMethod<BatchDetectKeyPhrasesRequest & RegionInput, BatchDetectKeyPhrasesResponse, BatchDetectKeyPhrasesError, Credentials | HttpClient.HttpClient>;
export type BatchDetectSentimentError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects a batch of documents and returns an inference of the prevailing sentiment,
 * `POSITIVE`, `NEUTRAL`, `MIXED`, or `NEGATIVE`,
 * in each one.
 */
export declare const batchDetectSentiment: API.OperationMethod<BatchDetectSentimentRequest & RegionInput, BatchDetectSentimentResponse, BatchDetectSentimentError, Credentials | HttpClient.HttpClient>;
export type BatchDetectSyntaxError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the text of a batch of documents for the syntax and part of speech of the words
 * in the document and returns information about them. For more information, see
 * Syntax in the Comprehend Developer Guide.
 */
export declare const batchDetectSyntax: API.OperationMethod<BatchDetectSyntaxRequest & RegionInput, BatchDetectSyntaxResponse, BatchDetectSyntaxError, Credentials | HttpClient.HttpClient>;
export type BatchDetectTargetedSentimentError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects a batch of documents and returns a sentiment analysis
 * for each entity identified in the documents.
 *
 * For more information about targeted sentiment, see Targeted sentiment in the *Amazon Comprehend Developer Guide*.
 */
export declare const batchDetectTargetedSentiment: API.OperationMethod<BatchDetectTargetedSentimentRequest & RegionInput, BatchDetectTargetedSentimentResponse, BatchDetectTargetedSentimentError, Credentials | HttpClient.HttpClient>;
export type ClassifyDocumentError = InternalServerException | InvalidRequestException | ResourceUnavailableException | TextSizeLimitExceededException | NotAuthorizedException | CommonErrors;
/**
 * Creates a classification request to analyze a single document in real-time. `ClassifyDocument`
 * supports the following model types:
 *
 * - Custom classifier - a custom model that you have created and trained.
 * For input, you can provide plain text, a single-page document (PDF, Word, or image), or
 * Amazon Textract API output. For more information, see Custom classification in the *Amazon Comprehend Developer Guide*.
 *
 * - Prompt safety classifier - Amazon Comprehend provides a pre-trained model for classifying
 * input prompts for generative AI applications.
 * For input, you provide English plain text input.
 * For prompt safety classification, the response includes only the `Classes` field.
 * For more information about prompt safety classifiers, see Prompt safety classification in the *Amazon Comprehend Developer Guide*.
 *
 * If the system detects errors while processing a page in the input document,
 * the API response includes an `Errors` field that describes the errors.
 *
 * If the system detects a document-level error in your input document, the API returns an
 * `InvalidRequestException` error response.
 * For details about this exception, see
 *
 * Errors in semi-structured documents in the Comprehend Developer Guide.
 */
export declare const classifyDocument: API.OperationMethod<ClassifyDocumentRequest & RegionInput, ClassifyDocumentResponse, ClassifyDocumentError, Credentials | HttpClient.HttpClient>;
export type ContainsPiiEntitiesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Analyzes input text for the presence of personally identifiable information (PII) and
 * returns the labels of identified PII entity types such as name, address, bank account number,
 * or phone number.
 */
export declare const containsPiiEntities: API.OperationMethod<ContainsPiiEntitiesRequest & RegionInput, ContainsPiiEntitiesResponse, ContainsPiiEntitiesError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a dataset to upload training or test data for a model associated with a flywheel.
 * For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest & RegionInput, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentClassifierError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * Creates a new document classifier that you can use to categorize documents. To create a
 * classifier, you provide a set of training documents that are labeled with the categories that you
 * want to use. For more information, see
 * Training classifier models
 * in the Comprehend Developer Guide.
 */
export declare const createDocumentClassifier: API.OperationMethod<CreateDocumentClassifierRequest & RegionInput, CreateDocumentClassifierResponse, CreateDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a model-specific endpoint for synchronous inference for a previously trained
 * custom model
 * For information about endpoints, see Managing endpoints.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointRequest & RegionInput, CreateEndpointResponse, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEntityRecognizerError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * Creates an entity recognizer using submitted files. After your
 * `CreateEntityRecognizer` request is submitted, you can check job status using the
 * `DescribeEntityRecognizer` API.
 */
export declare const createEntityRecognizer: API.OperationMethod<CreateEntityRecognizerRequest & RegionInput, CreateEntityRecognizerResponse, CreateEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type CreateFlywheelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * A flywheel is an Amazon Web Services resource that orchestrates the ongoing training of a model for custom classification
 * or custom entity recognition. You can create a flywheel to start with an existing trained model, or
 * Comprehend can create and train a new model.
 *
 * When you create the flywheel, Comprehend creates a data lake in your account. The data lake holds the training
 * data and test data for all versions of the model.
 *
 * To use a flywheel with an existing trained model, you specify the active model version. Comprehend copies the model's
 * training data and test data into the flywheel's data lake.
 *
 * To use the flywheel with a new model, you need to provide a dataset for training data (and optional test data)
 * when you create the flywheel.
 *
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const createFlywheel: API.OperationMethod<CreateFlywheelRequest & RegionInput, CreateFlywheelResponse, CreateFlywheelError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a previously created document classifier
 *
 * Only those classifiers that are in terminated states (IN_ERROR, TRAINED) will be deleted.
 * If an active inference job is using the model, a `ResourceInUseException` will be
 * returned.
 *
 * This is an asynchronous action that puts the classifier into a DELETING state, and it is
 * then removed by a background job. Once removed, the classifier disappears from your account
 * and is no longer available for use.
 */
export declare const deleteDocumentClassifier: API.OperationMethod<DeleteDocumentClassifierRequest & RegionInput, DeleteDocumentClassifierResponse, DeleteDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a model-specific endpoint for a previously-trained custom model. All endpoints
 * must be deleted in order for the model to be deleted.
 * For information about endpoints, see Managing endpoints.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest & RegionInput, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an entity recognizer.
 *
 * Only those recognizers that are in terminated states (IN_ERROR, TRAINED) will be deleted.
 * If an active inference job is using the model, a `ResourceInUseException` will be
 * returned.
 *
 * This is an asynchronous action that puts the recognizer into a DELETING state, and it is
 * then removed by a background job. Once removed, the recognizer disappears from your account
 * and is no longer available for use.
 */
export declare const deleteEntityRecognizer: API.OperationMethod<DeleteEntityRecognizerRequest & RegionInput, DeleteEntityRecognizerResponse, DeleteEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type DeleteFlywheelError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a flywheel. When you delete the flywheel, Amazon Comprehend
 * does not delete the data lake or the model associated with the flywheel.
 *
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const deleteFlywheel: API.OperationMethod<DeleteFlywheelRequest & RegionInput, DeleteFlywheelResponse, DeleteFlywheelError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a resource-based policy that is attached to a custom model.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the dataset that you specify.
 * For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest & RegionInput, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDocumentClassificationJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a document classification job. Use this operation to
 * get the status of a classification job.
 */
export declare const describeDocumentClassificationJob: API.OperationMethod<DescribeDocumentClassificationJobRequest & RegionInput, DescribeDocumentClassificationJobResponse, DescribeDocumentClassificationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a document classifier.
 */
export declare const describeDocumentClassifier: API.OperationMethod<DescribeDocumentClassifierRequest & RegionInput, DescribeDocumentClassifierResponse, DescribeDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type DescribeDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a dominant language detection job. Use this operation
 * to get the status of a detection job.
 */
export declare const describeDominantLanguageDetectionJob: API.OperationMethod<DescribeDominantLanguageDetectionJobRequest & RegionInput, DescribeDominantLanguageDetectionJobResponse, DescribeDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a specific endpoint. Use this operation to get the
 * status of an endpoint.
 * For information about endpoints, see Managing endpoints.
 */
export declare const describeEndpoint: API.OperationMethod<DescribeEndpointRequest & RegionInput, DescribeEndpointResponse, DescribeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an entities detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeEntitiesDetectionJob: API.OperationMethod<DescribeEntitiesDetectionJobRequest & RegionInput, DescribeEntitiesDetectionJobResponse, DescribeEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides details about an entity recognizer including status, S3 buckets containing
 * training data, recognizer metadata, metrics, and so on.
 */
export declare const describeEntityRecognizer: API.OperationMethod<DescribeEntityRecognizerRequest & RegionInput, DescribeEntityRecognizerResponse, DescribeEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | NotAuthorizedException | CommonErrors;
/**
 * Gets the status and details of an events detection job.
 */
export declare const describeEventsDetectionJob: API.OperationMethod<DescribeEventsDetectionJobRequest & RegionInput, DescribeEventsDetectionJobResponse, DescribeEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFlywheelError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides configuration information about the flywheel. For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeFlywheel: API.OperationMethod<DescribeFlywheelRequest & RegionInput, DescribeFlywheelResponse, DescribeFlywheelError, Credentials | HttpClient.HttpClient>;
export type DescribeFlywheelIterationError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the configuration properties of a flywheel iteration.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeFlywheelIteration: API.OperationMethod<DescribeFlywheelIterationRequest & RegionInput, DescribeFlywheelIterationResponse, DescribeFlywheelIterationError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a key phrases detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeKeyPhrasesDetectionJob: API.OperationMethod<DescribeKeyPhrasesDetectionJobRequest & RegionInput, DescribeKeyPhrasesDetectionJobResponse, DescribeKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribePiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a PII entities detection job. For example, you can use
 * this operation to get the job status.
 */
export declare const describePiiEntitiesDetectionJob: API.OperationMethod<DescribePiiEntitiesDetectionJobRequest & RegionInput, DescribePiiEntitiesDetectionJobResponse, DescribePiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the details of a resource-based policy that is attached to a custom model, including
 * the JSON body of the policy.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a sentiment detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeSentimentDetectionJob: API.OperationMethod<DescribeSentimentDetectionJobRequest & RegionInput, DescribeSentimentDetectionJobResponse, DescribeSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a targeted sentiment detection job. Use this operation
 * to get the status of the job.
 */
export declare const describeTargetedSentimentDetectionJob: API.OperationMethod<DescribeTargetedSentimentDetectionJobRequest & RegionInput, DescribeTargetedSentimentDetectionJobResponse, DescribeTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a topic detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeTopicsDetectionJob: API.OperationMethod<DescribeTopicsDetectionJobRequest & RegionInput, DescribeTopicsDetectionJobResponse, DescribeTopicsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DetectDominantLanguageError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | CommonErrors;
/**
 * Determines the dominant language of the input text. For a list of languages that Amazon
 * Comprehend can detect, see Amazon Comprehend Supported Languages.
 */
export declare const detectDominantLanguage: API.OperationMethod<DetectDominantLanguageRequest & RegionInput, DetectDominantLanguageResponse, DetectDominantLanguageError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesError = InternalServerException | InvalidRequestException | ResourceUnavailableException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects named entities in input text when you use the pre-trained model.
 * Detects custom entities if you have a custom entity recognition model.
 *
 * When detecting named entities using the pre-trained model, use plain text as the input.
 * For more information about named entities, see
 * Entities in the Comprehend Developer Guide.
 *
 * When you use a custom entity recognition model,
 * you can input plain text or you can upload a single-page input document (text, PDF, Word, or image).
 *
 * If the system detects errors while processing a page in the input document, the API response
 * includes an entry in `Errors` for each error.
 *
 * If the system detects a document-level error in your input document, the API returns an
 * `InvalidRequestException` error response.
 * For details about this exception, see
 *
 * Errors in semi-structured documents in the Comprehend Developer Guide.
 */
export declare const detectEntities: API.OperationMethod<DetectEntitiesRequest & RegionInput, DetectEntitiesResponse, DetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectKeyPhrasesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects the key noun phrases found in the text.
 */
export declare const detectKeyPhrases: API.OperationMethod<DetectKeyPhrasesRequest & RegionInput, DetectKeyPhrasesResponse, DetectKeyPhrasesError, Credentials | HttpClient.HttpClient>;
export type DetectPiiEntitiesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the input text for entities that contain personally identifiable information
 * (PII) and returns information about them.
 */
export declare const detectPiiEntities: API.OperationMethod<DetectPiiEntitiesRequest & RegionInput, DetectPiiEntitiesResponse, DetectPiiEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectSentimentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects text and returns an inference of the prevailing sentiment
 * (`POSITIVE`, `NEUTRAL`, `MIXED`, or `NEGATIVE`).
 */
export declare const detectSentiment: API.OperationMethod<DetectSentimentRequest & RegionInput, DetectSentimentResponse, DetectSentimentError, Credentials | HttpClient.HttpClient>;
export type DetectSyntaxError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects text for syntax and the part of speech of words in the document. For more
 * information, see
 * Syntax in the Comprehend Developer Guide.
 */
export declare const detectSyntax: API.OperationMethod<DetectSyntaxRequest & RegionInput, DetectSyntaxResponse, DetectSyntaxError, Credentials | HttpClient.HttpClient>;
export type DetectTargetedSentimentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the input text and returns a sentiment analysis for each entity identified in the text.
 *
 * For more information about targeted sentiment, see Targeted sentiment in the *Amazon Comprehend Developer Guide*.
 */
export declare const detectTargetedSentiment: API.OperationMethod<DetectTargetedSentimentRequest & RegionInput, DetectTargetedSentimentResponse, DetectTargetedSentimentError, Credentials | HttpClient.HttpClient>;
export type DetectToxicContentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Performs toxicity analysis on the list of text strings that you provide as input.
 * The API response contains a results list that matches the size of the input list.
 * For more information about toxicity detection, see Toxicity detection in the *Amazon Comprehend Developer Guide*.
 */
export declare const detectToxicContent: API.OperationMethod<DetectToxicContentRequest & RegionInput, DetectToxicContentResponse, DetectToxicContentError, Credentials | HttpClient.HttpClient>;
export type ImportModelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a new custom model that replicates a source custom model that you import. The
 * source model can be in your Amazon Web Services account or another one.
 *
 * If the source model is in another Amazon Web Services account, then it must have a resource-based policy
 * that authorizes you to import it.
 *
 * The source model must be in the same Amazon Web Services Region that you're using when you import. You
 * can't import a model that's in a different Region.
 */
export declare const importModel: API.OperationMethod<ImportModelRequest & RegionInput, ImportModelResponse, ImportModelError, Credentials | HttpClient.HttpClient>;
export type ListDatasetsError = InternalServerException | InvalidFilterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the datasets that you have configured in this Region. For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest & RegionInput, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassificationJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the documentation classification jobs that you have submitted.
 */
export declare const listDocumentClassificationJobs: API.PaginatedOperationMethod<ListDocumentClassificationJobsRequest & RegionInput, ListDocumentClassificationJobsResponse, ListDocumentClassificationJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassifiersError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the document classifiers that you have created.
 */
export declare const listDocumentClassifiers: API.PaginatedOperationMethod<ListDocumentClassifiersRequest & RegionInput, ListDocumentClassifiersResponse, ListDocumentClassifiersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassifierSummariesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of summaries of the document classifiers that you have created
 */
export declare const listDocumentClassifierSummaries: API.PaginatedOperationMethod<ListDocumentClassifierSummariesRequest & RegionInput, ListDocumentClassifierSummariesResponse, ListDocumentClassifierSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDominantLanguageDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the dominant language detection jobs that you have submitted.
 */
export declare const listDominantLanguageDetectionJobs: API.PaginatedOperationMethod<ListDominantLanguageDetectionJobsRequest & RegionInput, ListDominantLanguageDetectionJobsResponse, ListDominantLanguageDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEndpointsError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of all existing endpoints that you've created.
 * For information about endpoints, see Managing endpoints.
 */
export declare const listEndpoints: API.PaginatedOperationMethod<ListEndpointsRequest & RegionInput, ListEndpointsResponse, ListEndpointsError, Credentials | HttpClient.HttpClient, EndpointProperties>;
export type ListEntitiesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the entity detection jobs that you have submitted.
 */
export declare const listEntitiesDetectionJobs: API.PaginatedOperationMethod<ListEntitiesDetectionJobsRequest & RegionInput, ListEntitiesDetectionJobsResponse, ListEntitiesDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityRecognizersError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the properties of all entity recognizers that you created, including
 * recognizers currently in training. Allows you to filter the list of recognizers based on
 * criteria such as status and submission time. This call returns up to 500 entity recognizers in
 * the list, with a default number of 100 recognizers in the list.
 *
 * The results of this list are not in any particular order. Please get the list and sort
 * locally if needed.
 */
export declare const listEntityRecognizers: API.PaginatedOperationMethod<ListEntityRecognizersRequest & RegionInput, ListEntityRecognizersResponse, ListEntityRecognizersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityRecognizerSummariesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of summaries for the entity recognizers that you have created.
 */
export declare const listEntityRecognizerSummaries: API.PaginatedOperationMethod<ListEntityRecognizerSummariesRequest & RegionInput, ListEntityRecognizerSummariesResponse, ListEntityRecognizerSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventsDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | NotAuthorizedException | CommonErrors;
/**
 * Gets a list of the events detection jobs that you have submitted.
 */
export declare const listEventsDetectionJobs: API.PaginatedOperationMethod<ListEventsDetectionJobsRequest & RegionInput, ListEventsDetectionJobsResponse, ListEventsDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlywheelIterationHistoryError = InternalServerException | InvalidFilterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Information about the history of a flywheel iteration.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const listFlywheelIterationHistory: API.PaginatedOperationMethod<ListFlywheelIterationHistoryRequest & RegionInput, ListFlywheelIterationHistoryResponse, ListFlywheelIterationHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlywheelsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the flywheels that you have created.
 */
export declare const listFlywheels: API.PaginatedOperationMethod<ListFlywheelsRequest & RegionInput, ListFlywheelsResponse, ListFlywheelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKeyPhrasesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Get a list of key phrase detection jobs that you have submitted.
 */
export declare const listKeyPhrasesDetectionJobs: API.PaginatedOperationMethod<ListKeyPhrasesDetectionJobsRequest & RegionInput, ListKeyPhrasesDetectionJobsResponse, ListKeyPhrasesDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPiiEntitiesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the PII entity detection jobs that you have submitted.
 */
export declare const listPiiEntitiesDetectionJobs: API.PaginatedOperationMethod<ListPiiEntitiesDetectionJobsRequest & RegionInput, ListPiiEntitiesDetectionJobsResponse, ListPiiEntitiesDetectionJobsError, Credentials | HttpClient.HttpClient, PiiEntitiesDetectionJobProperties>;
export type ListSentimentDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of sentiment detection jobs that you have submitted.
 */
export declare const listSentimentDetectionJobs: API.PaginatedOperationMethod<ListSentimentDetectionJobsRequest & RegionInput, ListSentimentDetectionJobsResponse, ListSentimentDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a given Amazon Comprehend resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetedSentimentDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of targeted sentiment detection jobs that you have submitted.
 */
export declare const listTargetedSentimentDetectionJobs: API.PaginatedOperationMethod<ListTargetedSentimentDetectionJobsRequest & RegionInput, ListTargetedSentimentDetectionJobsResponse, ListTargetedSentimentDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTopicsDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the topic detection jobs that you have submitted.
 */
export declare const listTopicsDetectionJobs: API.PaginatedOperationMethod<ListTopicsDetectionJobsRequest & RegionInput, ListTopicsDetectionJobsResponse, ListTopicsDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based policy to a custom model. You can use this policy to authorize
 * an entity in another Amazon Web Services account to import the custom model, which replicates it in Amazon
 * Comprehend in their account.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartDocumentClassificationJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous document classification job using a custom classification model. Use the
 * `DescribeDocumentClassificationJob`
 * operation to track the progress of the job.
 */
export declare const startDocumentClassificationJob: API.OperationMethod<StartDocumentClassificationJobRequest & RegionInput, StartDocumentClassificationJobResponse, StartDocumentClassificationJobError, Credentials | HttpClient.HttpClient>;
export type StartDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous dominant language detection job for a collection of documents. Use
 * the operation to track the status
 * of a job.
 */
export declare const startDominantLanguageDetectionJob: API.OperationMethod<StartDominantLanguageDetectionJobRequest & RegionInput, StartDominantLanguageDetectionJobResponse, StartDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartEntitiesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous entity detection job for a collection of documents. Use the operation to track the status of a job.
 *
 * This API can be used for either standard entity detection or custom entity recognition. In
 * order to be used for custom entity recognition, the optional `EntityRecognizerArn`
 * must be used in order to provide access to the recognizer being used to detect the custom
 * entity.
 */
export declare const startEntitiesDetectionJob: API.OperationMethod<StartEntitiesDetectionJobRequest & RegionInput, StartEntitiesDetectionJobResponse, StartEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartEventsDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | NotAuthorizedException | CommonErrors;
/**
 * Starts an asynchronous event detection job for a collection of documents.
 */
export declare const startEventsDetectionJob: API.OperationMethod<StartEventsDetectionJobRequest & RegionInput, StartEventsDetectionJobResponse, StartEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartFlywheelIterationError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Start the flywheel iteration.This operation uses any new datasets to train a new model version.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const startFlywheelIteration: API.OperationMethod<StartFlywheelIterationRequest & RegionInput, StartFlywheelIterationResponse, StartFlywheelIterationError, Credentials | HttpClient.HttpClient>;
export type StartKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous key phrase detection job for a collection of documents. Use the
 * operation to track the status of a
 * job.
 */
export declare const startKeyPhrasesDetectionJob: API.OperationMethod<StartKeyPhrasesDetectionJobRequest & RegionInput, StartKeyPhrasesDetectionJobResponse, StartKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartPiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous PII entity detection job for a collection of documents.
 */
export declare const startPiiEntitiesDetectionJob: API.OperationMethod<StartPiiEntitiesDetectionJobRequest & RegionInput, StartPiiEntitiesDetectionJobResponse, StartPiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartSentimentDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous sentiment detection job for a collection of documents. Use the
 * operation to track the status of a
 * job.
 */
export declare const startSentimentDetectionJob: API.OperationMethod<StartSentimentDetectionJobRequest & RegionInput, StartSentimentDetectionJobResponse, StartSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous targeted sentiment detection job for a collection of documents. Use the
 * `DescribeTargetedSentimentDetectionJob` operation to track the status of a
 * job.
 */
export declare const startTargetedSentimentDetectionJob: API.OperationMethod<StartTargetedSentimentDetectionJobRequest & RegionInput, StartTargetedSentimentDetectionJobResponse, StartTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartTopicsDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous topic detection job. Use the
 * `DescribeTopicDetectionJob` operation to track the status of a job.
 */
export declare const startTopicsDetectionJob: API.OperationMethod<StartTopicsDetectionJobRequest & RegionInput, StartTopicsDetectionJobResponse, StartTopicsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a dominant language detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopDominantLanguageDetectionJob: API.OperationMethod<StopDominantLanguageDetectionJobRequest & RegionInput, StopDominantLanguageDetectionJobResponse, StopDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops an entities detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopEntitiesDetectionJob: API.OperationMethod<StopEntitiesDetectionJobRequest & RegionInput, StopEntitiesDetectionJobResponse, StopEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopEventsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | NotAuthorizedException | CommonErrors;
/**
 * Stops an events detection job in progress.
 */
export declare const stopEventsDetectionJob: API.OperationMethod<StopEventsDetectionJobRequest & RegionInput, StopEventsDetectionJobResponse, StopEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a key phrases detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopKeyPhrasesDetectionJob: API.OperationMethod<StopKeyPhrasesDetectionJobRequest & RegionInput, StopKeyPhrasesDetectionJobResponse, StopKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopPiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a PII entities detection job in progress.
 */
export declare const stopPiiEntitiesDetectionJob: API.OperationMethod<StopPiiEntitiesDetectionJobRequest & RegionInput, StopPiiEntitiesDetectionJobResponse, StopPiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a sentiment detection job in progress.
 *
 * If the job state is `IN_PROGRESS`, the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is be stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopSentimentDetectionJob: API.OperationMethod<StopSentimentDetectionJobRequest & RegionInput, StopSentimentDetectionJobResponse, StopSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a targeted sentiment detection job in progress.
 *
 * If the job state is `IN_PROGRESS`, the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is be stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopTargetedSentimentDetectionJob: API.OperationMethod<StopTargetedSentimentDetectionJobRequest & RegionInput, StopTargetedSentimentDetectionJobResponse, StopTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopTrainingDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a document classifier training job while in progress.
 *
 * If the training job state is `TRAINING`, the job is marked for termination and
 * put into the `STOP_REQUESTED` state. If the training job completes before it can be
 * stopped, it is put into the `TRAINED`; otherwise the training job is stopped and
 * put into the `STOPPED` state and the service sends back an HTTP 200 response with
 * an empty HTTP body.
 */
export declare const stopTrainingDocumentClassifier: API.OperationMethod<StopTrainingDocumentClassifierRequest & RegionInput, StopTrainingDocumentClassifierResponse, StopTrainingDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type StopTrainingEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops an entity recognizer training job while in progress.
 *
 * If the training job state is `TRAINING`, the job is marked for termination and
 * put into the `STOP_REQUESTED` state. If the training job completes before it can be
 * stopped, it is put into the `TRAINED`; otherwise the training job is stopped and
 * putted into the `STOPPED` state and the service sends back an HTTP 200 response
 * with an empty HTTP body.
 */
export declare const stopTrainingEntityRecognizer: API.OperationMethod<StopTrainingEntityRecognizerRequest & RegionInput, StopTrainingEntityRecognizerResponse, StopTrainingEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Associates a specific tag with an Amazon Comprehend resource. A tag is a key-value pair
 * that adds as a metadata to a resource used by Amazon Comprehend. For example, a tag with
 * "Sales" as the key might be added to a resource to indicate its use by the sales department.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyTagKeysException | CommonErrors;
/**
 * Removes a specific tag associated with an Amazon Comprehend resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates information about the specified endpoint.
 * For information about endpoints, see Managing endpoints.
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointRequest & RegionInput, UpdateEndpointResponse, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateFlywheelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update the configuration information for an existing flywheel.
 */
export declare const updateFlywheel: API.OperationMethod<UpdateFlywheelRequest & RegionInput, UpdateFlywheelResponse, UpdateFlywheelError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=comprehend.d.ts.map