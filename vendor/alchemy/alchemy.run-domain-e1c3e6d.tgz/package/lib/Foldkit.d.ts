import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import { Command, type Subscription } from "foldkit";
import { type MessageUnion } from "foldkit/message";
import type * as Aggregate from "./Aggregate.ts";
import type * as Api from "./Api.ts";
import type * as DomainCommand from "./Command.ts";
import type * as Middleware from "./Middleware.ts";
import type * as Query from "./Query.ts";
import * as Read from "./Read.ts";
import type * as DomainStream from "./Stream.ts";
import * as View from "./View.ts";
declare const CommandHeaders_base: Context.ServiceClass<CommandHeaders, "@alchemy.run/domain/Foldkit/CommandHeaders", {
    readonly get: (command: string) => Effect.Effect<Headers.Input>;
}>;
/** Per-call headers, resolved at execution time and excluded from replayable args. */
export declare class CommandHeaders extends CommandHeaders_base {
}
/** Page-local command id state. Give each page load a fresh session in Flags. */
export declare const CommandIds: Schema.Struct<{
    readonly session: Schema.String;
    readonly sent: Schema.Number;
}>;
/** Page-local command id state. */
export type CommandIds = typeof CommandIds.Type;
/** Allocate an id without reading time or changing the supplied state. */
export declare const next: (ids: CommandIds) => {
    commandId: string;
    commandIds: {
        readonly session: string;
        readonly sent: number;
    };
};
type Input<C extends DomainCommand.Any> = Omit<C["Type"], "_tag">;
type Reply<C extends DomainCommand.Any> = C["reply"] extends Schema.Top ? C["reply"]["Type"] : void;
type Rejection<C extends DomainCommand.Any> = C["rejects"][number]["Type"];
type Denial<C extends DomainCommand.Any> = C["middleware"][number]["error"]["Type"];
/** A refusal is final; an unknown outcome can be retried with the same id. */
export type Failure<C extends DomainCommand.Any> = Readonly<{
    _tag: "Rejected";
    rejection: Rejection<C>;
}> | Readonly<{
    _tag: "Denied";
    error: Denial<C>;
}> | Readonly<{
    _tag: "Unknown";
}>;
type QueryRejection<Q extends Query.Any> = Aggregate.InstanceOf<NonNullable<Q["definition"]["rejects"]>[number]>;
type QueryRefusal<Q extends Query.Any> = Readonly<{
    _tag: "Rejected";
    rejection: QueryRejection<Q>;
}> | Readonly<{
    _tag: "Denied";
    error: Middleware.Errors<Q["middleware"]>;
}> | Readonly<{
    _tag: "Unknown";
}>;
/**
 * A query refusal (`Rejected`, `Denied`) is final. `TimedOut` (only for a query with
 * `waitsFor`) means its projections did not reach `atLeast` in time; `Unknown` is transport or a defect.
 * Both can be asked again.
 */
export type QueryFailure<Q extends Query.Any> = NonNullable<Q["definition"]["waitsFor"]> extends readonly [] ? QueryRefusal<Q> : QueryRefusal<Q> | Readonly<{
    _tag: "TimedOut";
}>;
type QueryCases<A extends Api.Any> = {
    readonly [Q in Api.QueriesOf<A> as `Succeeded${Q["queryName"]}`]: {
        requestId: typeof Schema.String;
        result: Schema.Schema<Query.ResultOf<Q>>;
    };
} & {
    readonly [Q in Api.QueriesOf<A> as `Failed${Q["queryName"]}`]: {
        requestId: typeof Schema.String;
        failure: Schema.Schema<QueryFailure<Q>>;
    };
};
type Cases<A extends Api.Any> = QueryCases<A> & {
    readonly [C in Api.CommandsOf<A> as `Succeeded${C["tag"]}`]: {
        commandId: typeof Schema.String;
        reply: Schema.Schema<Reply<C>>;
        /** The first stream it committed to: what a read takes as `atLeast`. */
        receipt: typeof Receipt;
        /** Every stream it committed to: more than one for a command a decision implements. */
        commits: Schema.$Array<typeof Receipt>;
    };
} & {
    readonly [C in Api.CommandsOf<A> as `Failed${C["tag"]}`]: {
        commandId: typeof Schema.String;
        failure: Schema.Schema<Failure<C>>;
    };
};
type Args<C extends DomainCommand.Any> = {
    input: Schema.Schema<Input<C>>;
    commandId: typeof Schema.String;
};
type Result<A extends Api.Any, C extends DomainCommand.Any> = Extract<MessageUnion<Cases<A>>["Type"], {
    readonly _tag: `Succeeded${C["tag"]}` | `Failed${C["tag"]}`;
}>;
type QueryArgs<Q extends Query.Any> = {
    input: Schema.Schema<Query.InputOf<Q>>;
    requestId: typeof Schema.String;
    atLeast: Schema.optional<typeof Receipts>;
    after: Schema.optional<typeof Schema.String>;
    take: Schema.optional<typeof Schema.Number>;
};
type QueryResult<A extends Api.Any, Q extends Query.Any> = Extract<MessageUnion<Cases<A>>["Type"], {
    readonly _tag: `Succeeded${Q["queryName"]}` | `Failed${Q["queryName"]}`;
}>;
/** Typed Command definitions and their result Message union, derived from an Api. */
type CommandDefinitions<A extends Api.Any> = {
    readonly [Q in Api.QueriesOf<A> as Q["queryName"]]: Command.CommandDefinitionWithArgs<Q["queryName"], QueryArgs<Q>, Effect.Effect<QueryResult<A, Q>, never, A["Client"]["Identifier"]>>;
} & {
    readonly [C in Api.CommandsOf<A> as C["tag"]]: Command.CommandDefinitionWithArgs<C["tag"], Args<C>, Effect.Effect<Result<A, C>, never, A["Client"]["Identifier"] | Effect.Services<ReturnType<Api.CommandClient<C>>>>>;
} & {
    readonly Message: MessageUnion<Cases<A>>;
};
declare const Receipt: Schema.Struct<{
    readonly stream: Schema.String;
    readonly version: Schema.Number;
}>;
/** A query's `atLeast`: one receipt, or one per command. */
declare const Receipts: Schema.Union<readonly [Schema.Struct<{
    readonly stream: Schema.String;
    readonly version: Schema.Number;
}>, Schema.$Array<Schema.Struct<{
    readonly stream: Schema.String;
    readonly version: Schema.Number;
}>>]>;
type ReadEntry = View.Any | DomainStream.Any;
type Reads<A extends Api.Any> = Extract<A["serves"][number], ReadEntry>;
type ReadName<V extends ReadEntry> = V extends View.Any ? V["viewName"] : V extends DomainStream.Any ? V["streamName"] : never;
type ReadClient<V extends ReadEntry> = V extends View.Any ? Api.ViewClient<V> : V extends DomainStream.Any ? Api.StreamClient<V> : never;
type ReadKey<V extends ReadEntry> = Parameters<ReadClient<V>["watch"]>[0];
type StateOf<V extends ReadEntry> = Stream.Success<ReturnType<ReadClient<V>["watch"]>>["state"];
type EntryOf<V extends ReadEntry> = Exclude<Stream.Success<ReturnType<ReadClient<V>["events"]>>, Read.CaughtUp>;
type ErrorOf<V extends ReadEntry> = Stream.Error<ReturnType<ReadClient<V>["watch"]>>;
type ViewStateSchema<V extends View.Any> = [NonNullable<V["definition"]["state"]>] extends [never] ? typeof Schema.Never : Extract<NonNullable<V["definition"]["state"]>, Schema.Top>;
type ViewFlags<V extends View.Any> = ReturnType<typeof snapshotFlags<ViewStateSchema<V>>>;
/** A read namespace with Foldkit Subscription entries, bound to one Api entry. */
export interface ReadClientOf<A extends Api.Any, V extends ReadEntry> {
    readonly watch: <Model, Message>(options: WatchOptions<Model, Message, V>) => Subscription.EntryWithoutKeepAlive<Model, Message, {
        key: ReadKey<V>;
        isEnabled: boolean;
    }, A["Client"]["Identifier"]>;
    readonly events: <Model, Message>(options: EventsOptions<Model, Message, V>) => EventsSubscription<A, Model, Message, V>;
}
/** Commands and read namespaces computed from the Api's entries. Message is reserved. */
export type ClientOf<A extends Api.Any> = CommandDefinitions<A> & {
    readonly [V in Reads<A> as ReadName<V>]: ReadClientOf<A, V> & (V extends View.Any ? {
        readonly SnapshotFlags: ViewFlags<V>;
        readonly decodeSnapshotFlags: (flags: unknown) => Option.Option<ViewFlags<V>["Type"]>;
    } : {});
};
/** Build the Foldkit Commands and Subscriptions for an Api. The app provides api.layerClient in its runtime resources. */
export declare function make<A extends Api.Any>(api: A & ("Message" extends keyof Api.ClientOf<A> ? never : unknown)): ClientOf<A>;
/** A watch Snapshot with explicit absence for Foldkit Models. */
export type Snapshot<State> = Readonly<{
    state: Option.Option<NonNullable<State>>;
    cursor: number;
}>;
/** Callbacks for live read state. Cursor changes do not restart the watch. */
export interface WatchOptions<Model, Message, V extends ReadEntry> {
    readonly key: (model: Model) => ReadKey<V>;
    readonly isEnabled?: (model: Model) => boolean;
    /** The snapshot, and the key it is of: a Model that keeps several keys files it under this one. */
    readonly toMessage: (snapshot: Snapshot<StateOf<V>>, key: ReadKey<V>) => Message;
    readonly onFailure: (error: ErrorOf<V>) => Message;
    /** Handle unexpected read defects. Interruption does not call this callback. */
    readonly onDefect: (cause: Cause.Cause<unknown>) => Message;
}
/** Callbacks for a resumable event feed. The app stores the cursor after applying each entry. */
export interface EventsOptions<Model, Message, V extends ReadEntry> {
    readonly key: (model: Model) => ReadKey<V>;
    readonly cursor: (model: Model) => Option.Option<number>;
    readonly isEnabled?: (model: Model) => boolean;
    readonly restartKey?: (model: Model) => number;
    readonly onEntry: (entry: EntryOf<V>) => Message;
    /** Every stored entry of `key` has been delivered: what follows is live. */
    readonly onCaughtUp: (cursor: number, key: ReadKey<V>) => Message;
    readonly onFailure: (error: ErrorOf<V>) => Message;
    /** Handle unexpected read defects. Interruption does not call this callback. */
    readonly onDefect: (cause: Cause.Cause<unknown>) => Message;
}
/** Follow event entries after the Model's cursor, without counting sequence gaps. */
type EventsSubscription<A extends Api.Any, Model, Message, V extends ReadEntry> = {
    readonly dependenciesSchema: Schema.Struct<{
        key: Schema.Schema<ReadKey<V>>;
        cursor: Schema.Schema<Option.Option<number>>;
        restartKey: Schema.optional<typeof Schema.Number>;
        isEnabled: typeof Schema.Boolean;
    }>;
    readonly modelToDependencies: (model: Model) => {
        key: ReadKey<V>;
        cursor: Option.Option<number>;
        restartKey?: number;
        isEnabled: boolean;
    };
    readonly keepAliveEquivalence: (left: {
        key: ReadKey<V>;
        cursor: Option.Option<number>;
        restartKey?: number;
        isEnabled: boolean;
    }, right: {
        key: ReadKey<V>;
        cursor: Option.Option<number>;
        restartKey?: number;
        isEnabled: boolean;
    }) => boolean;
    readonly dependenciesToStream: (dependencies: {
        key: ReadKey<V>;
        cursor: Option.Option<number>;
        restartKey?: number;
        isEnabled: boolean;
    }, readDependencies: () => {
        key: ReadKey<V>;
        cursor: Option.Option<number>;
        restartKey?: number;
        isEnabled: boolean;
    }) => Stream.Stream<Message, never, A["Client"]["Identifier"]>;
};
/** Decode snapshot wire data in Flags, converting null state to Option.none. */
declare const snapshotFlags: <State extends Schema.Top>(state: State) => Schema.Struct<{
    readonly state: Schema.OptionFromNullOr<State>;
    readonly cursor: Schema.Number;
}>;
export {};
//# sourceMappingURL=Foldkit.d.ts.map