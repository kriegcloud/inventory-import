import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
export interface Resolver {
    /** The file a relative specifier names, from the file that imports it. */
    readonly relative: (from: string, specifier: string) => Effect.Effect<string>;
    /**
     * The file a package specifier names, from the file that imports it, as
     * Node finds it: in the nearest `node_modules` that has the package,
     * through its `exports`. `undefined` when nothing is found.
     */
    readonly bare: (from: string, specifier: string) => Effect.Effect<string | undefined>;
}
/** The package a specifier names, and the path inside it: `@acme/rules/Ticket` is `./Ticket` of `@acme/rules`. */
export declare const packageOf: (specifier: string) => {
    readonly name: string;
    readonly subpath: string;
} | undefined;
/** Finds the files that imports name, the way the runtime that runs the code does. */
export declare const make: Effect.Effect<Resolver, never, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=Resolve.d.ts.map