import * as Repos from "@distilled.cloud/github/repos";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface BranchProtectionProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Name of the branch to protect (e.g. `main`). The branch is the rule's
     * identity — changing it replaces the protection. The branch must exist.
     */
    branch: string;
    /**
     * Require status checks to pass before merging. Omit to disable.
     */
    requiredStatusChecks?: {
        /**
         * Require branches to be up to date with the base branch before merging.
         * @default false
         */
        strict?: boolean;
        /**
         * Status check contexts that must pass. Prefer `checks` for control over
         * which GitHub App must report the check.
         */
        contexts?: string[];
        /**
         * Status checks that must pass, optionally pinned to the GitHub App that
         * must report them. When this is set, the update sends `checks` and
         * omits `contexts`. GitHub rejects a request that includes both.
         */
        checks?: {
            /**
             * Name of the required check.
             */
            context: string;
            /**
             * ID of the GitHub App that must provide this check. Omit to accept the
             * app that most recently reported it; pass `-1` to accept any app.
             */
            appId?: number;
        }[];
    };
    /**
     * Require pull request reviews before merging. Omit to disable.
     */
    requiredPullRequestReviews?: {
        /**
         * Dismiss approving reviews when a new commit is pushed.
         * @default false
         */
        dismissStaleReviews?: boolean;
        /**
         * Block merging until code owners have reviewed.
         * @default false
         */
        requireCodeOwnerReviews?: boolean;
        /**
         * Number of approving reviews required (0–6).
         * @default 0
         */
        requiredApprovingReviewCount?: number;
        /**
         * Require the most recent push to be approved by someone other than the
         * pusher.
         * @default false
         */
        requireLastPushApproval?: boolean;
        /**
         * Who may dismiss pull request reviews. Only available on
         * organization-owned repositories; omit for personal repositories.
         */
        dismissalRestrictions?: {
            /**
             * User logins with dismissal access.
             */
            users?: string[];
            /**
             * Team slugs with dismissal access.
             */
            teams?: string[];
            /**
             * App slugs with dismissal access.
             */
            apps?: string[];
        };
        /**
         * Who may bypass pull request requirements.
         */
        bypassPullRequestAllowances?: {
            /**
             * User logins allowed to bypass.
             */
            users?: string[];
            /**
             * Team slugs allowed to bypass.
             */
            teams?: string[];
            /**
             * App slugs allowed to bypass.
             */
            apps?: string[];
        };
    };
    /**
     * Restrict who can push to the branch. Only available on
     * organization-owned repositories. Omit to disable.
     */
    restrictions?: {
        /**
         * User logins with push access.
         */
        users?: string[];
        /**
         * Team slugs with push access.
         */
        teams?: string[];
        /**
         * App slugs with push access.
         */
        apps?: string[];
    };
    /**
     * Enforce all configured restrictions for repository administrators.
     * @default false
     */
    enforceAdmins?: boolean;
    /**
     * Require signed commits on the branch.
     * @default false
     */
    requiredSignatures?: boolean;
    /**
     * Require a linear commit history (no merge commits). The repository must
     * allow squash or rebase merging.
     * @default false
     */
    requiredLinearHistory?: boolean;
    /**
     * Permit force pushes by anyone with write access.
     * @default false
     */
    allowForcePushes?: boolean;
    /**
     * Permit deletion of the branch by anyone with write access.
     * @default false
     */
    allowDeletions?: boolean;
    /**
     * When `restrictions` is set, also block pushes that create new branches
     * unless the pusher is allowed by the restrictions.
     * @default false
     */
    blockCreations?: boolean;
    /**
     * Require all pull request conversations to be resolved before merging.
     * @default false
     */
    requiredConversationResolution?: boolean;
    /**
     * Make the branch read-only.
     * @default false
     */
    lockBranch?: boolean;
    /**
     * Allow fork syncing (pulling upstream changes) while the branch is locked.
     * @default false
     */
    allowForkSyncing?: boolean;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same branch on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface BranchProtection extends Resource<"GitHub.BranchProtection", BranchProtectionProps, {
    /**
     * API URL of the branch protection rule.
     */
    url: string;
    /**
     * The protected branch name.
     */
    branch: string;
    /**
     * Whether restrictions are enforced for administrators.
     */
    enforceAdmins: boolean;
    /**
     * Whether signed commits are required.
     */
    requiredSignatures: boolean;
    /**
     * Whether a linear history is required.
     */
    requiredLinearHistory: boolean;
    /**
     * Whether force pushes are allowed.
     */
    allowForcePushes: boolean;
    /**
     * Whether branch deletion is allowed.
     */
    allowDeletions: boolean;
    /**
     * Whether conversation resolution is required before merging.
     */
    requiredConversationResolution: boolean;
    /**
     * Whether the branch is locked (read-only).
     */
    lockBranch: boolean;
}, never, GitHub.Providers> {
}
/**
 * A GitHub branch protection rule.
 *
 * `BranchProtection` manages the classic branch protection settings on a
 * single branch: required status checks, required pull request reviews,
 * push restrictions, admin enforcement, signed commits, linear history, and
 * the force-push / deletion / lock toggles. Pair it with `GitHub.Repository`
 * to protect the default branch of a repository provisioned in the same
 * stack.
 *
 * Branch protection is available on public repositories on every plan;
 * private repositories require GitHub Pro, Team, or Enterprise. Push
 * restrictions and dismissal restrictions are only available on
 * organization-owned repositories.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied
 * by `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token
 * needs `repo` scope and admin access to the repository.
 *
 * ### Protecting a Branch
 * **Example:** Require Pull Request Reviews
 * ```typescript
 * yield* GitHub.BranchProtection("main", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   branch: "main",
 *   requiredPullRequestReviews: {
 *     requiredApprovingReviewCount: 1,
 *     dismissStaleReviews: true,
 *   },
 * });
 * ```
 *
 * **Example:** Require Status Checks and a Linear History
 * ```typescript
 * yield* GitHub.BranchProtection("main", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   branch: "main",
 *   requiredStatusChecks: {
 *     strict: true,
 *     checks: [{ context: "ci" }],
 *   },
 *   requiredLinearHistory: true,
 *   requiredConversationResolution: true,
 *   enforceAdmins: true,
 * });
 * ```
 *
 * ### Protecting a Repository's Default Branch
 * **Example:** Protect the Default Branch of a New Repository
 * ```typescript
 * import * as Output from "alchemy/Output";
 *
 * const repo = yield* GitHub.Repository("repo", {
 *   owner: "my-org",
 *   name: "my-repo",
 *   autoInit: true,
 * });
 *
 * yield* GitHub.BranchProtection("main", {
 *   owner: "my-org",
 *   repository: Output.map(repo.fullName, (fullName) => fullName.split("/")[1]!),
 *   branch: repo.defaultBranch,
 *   requiredPullRequestReviews: { requiredApprovingReviewCount: 1 },
 *   allowForcePushes: false,
 *   allowDeletions: false,
 * });
 * ```
 *
 * ### Restricting Pushes
 * **Example:** Only a Team May Push
 * ```typescript
 * yield* GitHub.BranchProtection("release", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   branch: "release",
 *   restrictions: { teams: ["release-managers"] },
 *   blockCreations: true,
 *   requiredSignatures: true,
 * });
 * ```
 *
 * @resource
 * @product Repository
 */
export declare const BranchProtection: import("alchemy/Resource").ResourceClass<BranchProtection>;
export declare const BranchProtectionProvider: () => import("effect/Layer").Layer<Provider.Provider<BranchProtection>, never, Repos.GithubOpContext>;
//# sourceMappingURL=BranchProtection.d.ts.map