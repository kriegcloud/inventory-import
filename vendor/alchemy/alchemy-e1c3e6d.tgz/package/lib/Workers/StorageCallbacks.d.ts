import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { Callbacks } from "../Callback.ts";
/** The key-value storage jobs are kept in, as a Durable Object's. */
export interface CallbackStorage {
    get<T>(key: string): Effect.Effect<T | undefined>;
    put<T>(key: string, value: T): Effect.Effect<void>;
    delete(key: string): Effect.Effect<boolean>;
    list<T>(options: {
        readonly prefix: string;
    }): Effect.Effect<Map<string, T>>;
}
/** One alarm per instance, as Durable Objects have: setting it replaces it. */
export interface Alarm {
    readonly set: (at: number) => Effect.Effect<void>;
    readonly get: Effect.Effect<number | null>;
}
/**
 * Durable callbacks (`alchemy/Callback`) over an instance's key-value storage
 * and one wake-up, for hosts without a callbacks implementation of their own
 * (Rivet, Effect Cluster, Domain's Durable Object hosts). Jobs are rows in the instance's storage; the alarm
 * is set for the soonest, and `fire` (the instance's alarm handler) runs the
 * due ones. A job whose handler dies is redelivered from 2 seconds doubling,
 * then hourly, and never dropped. Delivery is at least once.
 *
 * Handlers run in Node processes here, not workerd, so `fire` keeps an
 * in-memory flag to run one pass at a time.
 */
export declare const storageCallbacks: (storage: CallbackStorage, alarm: Alarm) => {
    callbacks: Layer.Layer<Callbacks, never, never>;
    fire: Effect.Effect<void, never, never>;
};
//# sourceMappingURL=StorageCallbacks.d.ts.map