import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const RealtimeKitPresetExists_base: S.TaggedErrorClass<"RealtimeKitPresetExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RealtimeKitPresetExists extends /*@__PURE__*/ RealtimeKitPresetExists_base {
}
declare const RealtimeKitPresetNotFound_base: S.TaggedErrorClass<"RealtimeKitPresetNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RealtimeKitPresetNotFound extends /*@__PURE__*/ RealtimeKitPresetNotFound_base {
}
declare const RealtimeKitWebhookExists_base: S.TaggedErrorClass<"RealtimeKitWebhookExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RealtimeKitWebhookExists extends /*@__PURE__*/ RealtimeKitWebhookExists_base {
}
declare const RealtimeKitWebhookNotFound_base: S.TaggedErrorClass<"RealtimeKitWebhookNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RealtimeKitWebhookNotFound extends /*@__PURE__*/ RealtimeKitWebhookNotFound_base {
}
export interface ActiveSessionMuteAllParticipantsRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** if false, participants won't be able to unmute themselves after they are muted */
    allowUnmute?: boolean | undefined;
}
export interface ActiveSessionMuteAllParticipantsResponseData {
    action?: string | null | undefined;
    mutedParticipantsCount?: number | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ActiveSessionMuteAllParticipantsResponse {
    data?: ActiveSessionMuteAllParticipantsResponseData | null | undefined;
}
export type ActiveSessionMuteParticipantsRequestCustomParticipantIdsList = Array<string>;
export type ActiveSessionMuteParticipantsRequestParticipantIdsList = Array<string>;
export interface ActiveSessionMuteParticipantsRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    customParticipantIds?: ActiveSessionMuteParticipantsRequestCustomParticipantIdsList | undefined;
    participantIds?: ActiveSessionMuteParticipantsRequestParticipantIdsList | undefined;
}
export interface ActiveSessionMuteParticipantsResponseDataParticipantsItem {
    /** ID of the session participant */
    id: string;
    createdAt: string;
    updatedAt: string;
    /** Email of the session participant. */
    email?: string | null | undefined;
    /** Name of the session participant. */
    name?: string | null | undefined;
    /** A URL pointing to a picture of the participant. */
    picture?: string | null | undefined;
}
export type ActiveSessionMuteParticipantsResponseDataParticipantsList = Array<ActiveSessionMuteParticipantsResponseDataParticipantsItem>;
export interface ActiveSessionMuteParticipantsResponseData {
    action?: string | null | undefined;
    participants?: ActiveSessionMuteParticipantsResponseDataParticipantsList | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ActiveSessionMuteParticipantsResponse {
    data?: ActiveSessionMuteParticipantsResponseData | null | undefined;
}
export interface MeetingsAddParticipantRequestToken {
    /** RFC 3339 timestamp with a timezone at or after which the token cannot be used. Must be in the future. Defaults to not_before plus 100 days. */
    expiresOn?: string | undefined;
    /** RFC 3339 timestamp with a timezone before which the token cannot be used. Defaults to the current time. May be in the past. */
    notBefore?: string | undefined;
}
export interface AddParticipantMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** A unique participant ID. You must specify a unique ID for the participant, for example, UUID, email address, and so on. */
    customParticipantId: string;
    /** Name of the preset to apply to this participant. */
    presetName: string;
    /** Validity window of the participant authentication token. The window is [not_before, expires_on) and cannot be longer than 100 days. Defaults to a token valid from now for 100 days. */
    token?: MeetingsAddParticipantRequestToken | undefined;
    /** (Optional) Name of the participant. */
    name?: string | undefined;
    /** (Optional) A URL to a picture to be used for the participant. */
    picture?: string | undefined;
}
export interface MeetingsAddParticipantResponseData {
    /** ID of the participant. */
    id: string;
    /** The participant's auth token that can be used for joining a meeting from the client side. */
    token: string;
    /** When this object was created. The time is returned in ISO format. */
    createdAt: string;
    /** A unique participant ID generated by the client. */
    customParticipantId: string;
    /** Preset applied to the participant. */
    presetName: string;
    /** When this object was updated. The time is returned in ISO format. */
    updatedAt: string;
    /** Time at which the token stops being valid, in UTC. Returned when adding a participant. */
    expiresOn?: string | null | undefined;
    /** Name of the participant. */
    name?: string | null | undefined;
    /** Time from which the token is valid, in UTC. Returned when adding a participant. */
    notBefore?: string | null | undefined;
    /** URL to a picture of the participant. */
    picture?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface AddParticipantMeetingResponse {
    /** Represents a participant. */
    data?: MeetingsAddParticipantResponseData | null | undefined;
}
export interface CreateIndependentLivestreamLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** Name of the livestream */
    name?: string | undefined;
}
export type LivestreamsCreateIndependentLivestreamResponseDataStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED";
export interface LivestreamsCreateIndependentLivestreamResponseData {
    /** The livestream ID. */
    id?: string | null | undefined;
    /** Specifies if the livestream was disabled. */
    disabled?: boolean | null | undefined;
    /** The server URL to which the RTMP encoder should send the video and audio data. */
    ingestServer?: string | null | undefined;
    meetingId?: string | null | undefined;
    name?: string | null | undefined;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl?: string | null | undefined;
    status?: LivestreamsCreateIndependentLivestreamResponseDataStatus | null | undefined;
    /** Unique key for accessing each livestream. */
    streamKey?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateIndependentLivestreamLivestreamResponse {
    data?: LivestreamsCreateIndependentLivestreamResponseData | null | undefined;
}
export type MeetingsCreateRequestAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsCreateRequestAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsCreateRequestAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsCreateRequestAiConfigSummarizationSummaryType | (string & {}) | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsCreateRequestAiConfigSummarizationTextFormat | (string & {}) | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | undefined;
}
export type MeetingsCreateRequestAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsCreateRequestAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsCreateRequestAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsCreateRequestAiConfigTranscriptionKeywordsList | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsCreateRequestAiConfigTranscriptionLanguage | (string & {}) | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | undefined;
}
export interface MeetingsCreateRequestAiConfig {
    /** Summary Config */
    summarization?: MeetingsCreateRequestAiConfigSummarization | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsCreateRequestAiConfigTranscription | undefined;
}
export type MeetingsCreateRequestRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsCreateRequestRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsCreateRequestRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsCreateRequestRecordingConfigAudioConfigChannel | (string & {}) | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsCreateRequestRecordingConfigAudioConfigCodec | (string & {}) | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | undefined;
}
export interface MeetingsCreateRequestRecordingConfigLiveStreamingConfig {
    /** RTMP URL to stream to */
    rtmpUrl?: string | undefined;
}
export interface MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig {
    /** Controls whether recordings are uploaded to RealtimeKit's bucket. If set to false, `download_url`, `audio_download_url`, `download_url_expiry` won't be generated for a recording. */
    enabled: boolean;
}
export type MeetingsCreateRequestRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsCreateRequestRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsCreateRequestRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsCreateRequestRecordingConfigStorageConfigCase0AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsCreateRequestRecordingConfigStorageConfigCase0Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsCreateRequestRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsCreateRequestRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsCreateRequestRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsCreateRequestRecordingConfigStorageConfigCase1AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsCreateRequestRecordingConfigStorageConfigCase1Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsCreateRequestRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsCreateRequestRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsCreateRequestRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsCreateRequestRecordingConfigStorageConfigCase2AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsCreateRequestRecordingConfigStorageConfigCase2Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsCreateRequestRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsCreateRequestRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsCreateRequestRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsCreateRequestRecordingConfigStorageConfigCase3AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsCreateRequestRecordingConfigStorageConfigCase3Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsCreateRequestRecordingConfigStorageConfig = MeetingsCreateRequestRecordingConfigStorageConfigCase0 | MeetingsCreateRequestRecordingConfigStorageConfigCase1 | MeetingsCreateRequestRecordingConfigStorageConfigCase2 | MeetingsCreateRequestRecordingConfigStorageConfigCase3;
export type MeetingsCreateRequestRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsCreateRequestRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export interface MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize {
    /** Height of the watermark in px */
    height?: number | undefined;
    /** Width of the watermark in px */
    width?: number | undefined;
}
export interface MeetingsCreateRequestRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsCreateRequestRecordingConfigVideoConfigWatermarkPosition | (string & {}) | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize | undefined;
    /** URL of the watermark image */
    url?: string | undefined;
}
export interface MeetingsCreateRequestRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsCreateRequestRecordingConfigVideoConfigCodec | (string & {}) | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | undefined;
    /** Height of the recording video in pixels */
    height?: number | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsCreateRequestRecordingConfigVideoConfigWatermark | undefined;
    /** Width of the recording video in pixels */
    width?: number | undefined;
}
export interface MeetingsCreateRequestRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsCreateRequestRecordingConfigAudioConfig | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | undefined;
    liveStreamingConfig?: MeetingsCreateRequestRecordingConfigLiveStreamingConfig | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | undefined;
    storageConfig?: MeetingsCreateRequestRecordingConfigStorageConfig | undefined;
    videoConfig?: MeetingsCreateRequestRecordingConfigVideoConfig | undefined;
}
export interface CreateMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsCreateRequestAiConfig | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | undefined;
    /** If a meeting is set to persist_chat, meeting chat would remain for a week within the meeting space. */
    persistChat?: boolean | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsCreateRequestRecordingConfig | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | undefined;
    /** Title of the meeting */
    title?: string | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | undefined;
}
export type MeetingsCreateResponseDataAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsCreateResponseDataAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsCreateResponseDataAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsCreateResponseDataAiConfigSummarizationSummaryType | null | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsCreateResponseDataAiConfigSummarizationTextFormat | null | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | null | undefined;
}
export type MeetingsCreateResponseDataAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsCreateResponseDataAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsCreateResponseDataAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsCreateResponseDataAiConfigTranscriptionKeywordsList | null | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsCreateResponseDataAiConfigTranscriptionLanguage | null | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | null | undefined;
}
export interface MeetingsCreateResponseDataAiConfig {
    /** Summary Config */
    summarization?: MeetingsCreateResponseDataAiConfigSummarization | null | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsCreateResponseDataAiConfigTranscription | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsCreateResponseDataRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsCreateResponseDataRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsCreateResponseDataRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsCreateResponseDataRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export interface MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig {
    /** RTMP URL to stream to */
    rtmpUrl?: string | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsCreateResponseDataRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsCreateResponseDataRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsCreateResponseDataRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsCreateResponseDataRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsCreateResponseDataRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsCreateResponseDataRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsCreateResponseDataRecordingConfigStorageConfig = MeetingsCreateResponseDataRecordingConfigStorageConfigCase0 | MeetingsCreateResponseDataRecordingConfigStorageConfigCase1 | MeetingsCreateResponseDataRecordingConfigStorageConfigCase2 | MeetingsCreateResponseDataRecordingConfigStorageConfigCase3;
export type MeetingsCreateResponseDataRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export interface MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize {
    /** Height of the watermark in px */
    height?: number | null | undefined;
    /** Width of the watermark in px */
    width?: number | null | undefined;
}
export interface MeetingsCreateResponseDataRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface MeetingsCreateResponseDataRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsCreateResponseDataRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface MeetingsCreateResponseDataRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsCreateResponseDataRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: MeetingsCreateResponseDataRecordingConfigStorageConfig | null | undefined;
    videoConfig?: MeetingsCreateResponseDataRecordingConfigVideoConfig | null | undefined;
}
export type MeetingsCreateResponseDataStatus = "ACTIVE" | "INACTIVE";
export interface MeetingsCreateResponseData {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsCreateResponseDataAiConfig | null | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsCreateResponseDataRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsCreateResponseDataStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateMeetingResponse {
    /** Data returned by the operation */
    data?: MeetingsCreateResponseData | null | undefined;
}
export type ActiveSessionCreatePollRequestOptionsList = Array<string>;
export interface CreatePollActiveSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** Different options for the question */
    options: ActiveSessionCreatePollRequestOptionsList;
    /** Question of the poll */
    question: string;
    /** if voters on a poll are anonymous */
    anonymous?: boolean | undefined;
    /** if votes on an option are visible before a person votes */
    hideVotes?: boolean | undefined;
}
export interface ActiveSessionCreatePollResponseDataPollOptionsItemVotesItem {
    id: string;
    name: string;
}
export type ActiveSessionCreatePollResponseDataPollOptionsItemVotesList = Array<ActiveSessionCreatePollResponseDataPollOptionsItemVotesItem>;
export interface ActiveSessionCreatePollResponseDataPollOptionsItem {
    count: number;
    /** Text of the answer option */
    text: string;
    votes: ActiveSessionCreatePollResponseDataPollOptionsItemVotesList;
}
export type ActiveSessionCreatePollResponseDataPollOptionsList = Array<ActiveSessionCreatePollResponseDataPollOptionsItem>;
export type ActiveSessionCreatePollResponseDataPollVotedList = Array<string>;
export interface ActiveSessionCreatePollResponseDataPoll {
    /** ID of the poll */
    id: string;
    /** Answer options */
    options: ActiveSessionCreatePollResponseDataPollOptionsList;
    /** Question asked by the poll */
    question: string;
    anonymous?: boolean | null | undefined;
    createdBy?: string | null | undefined;
    hideVotes?: boolean | null | undefined;
    voted?: ActiveSessionCreatePollResponseDataPollVotedList | null | undefined;
}
export interface ActiveSessionCreatePollResponseData {
    action?: string | null | undefined;
    poll?: ActiveSessionCreatePollResponseDataPoll | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreatePollActiveSessionResponse {
    data?: ActiveSessionCreatePollResponseData | null | undefined;
}
export interface PresetsCreateRequestConfigMaxVideoStreams {
    /** Maximum number of video streams visible on desktop devices */
    desktop: number;
    /** Maximum number of streams visible on mobile devices */
    mobile: number;
}
export type PresetsCreateRequestConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsCreateRequestConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: PresetsCreateRequestConfigMediaScreenshareQuality | (string & {});
}
export type PresetsCreateRequestConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsCreateRequestConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: PresetsCreateRequestConfigMediaVideoQuality | (string & {});
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | undefined;
}
export interface PresetsCreateRequestConfigMediaAudio {
    /** Enable High Quality Audio for your meetings */
    enableHighBitrate?: boolean | undefined;
    /** Enable Stereo for your meetings */
    enableStereo?: boolean | undefined;
}
export interface PresetsCreateRequestConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: PresetsCreateRequestConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: PresetsCreateRequestConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateRequestConfigMediaAudio | undefined;
}
export type PresetsCreateRequestConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type PresetsCreateRequestConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsCreateRequestConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: PresetsCreateRequestConfigMedia;
    /** Type of the meeting */
    viewType: PresetsCreateRequestConfigViewType | (string & {});
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsCreateRequestConfigLivestreamViewerQualitiesList | undefined;
}
export interface PresetsCreateRequestPermissionsChatPrivate {
    canReceive: boolean;
    canSend: boolean;
    files: boolean;
    text: boolean;
}
export interface PresetsCreateRequestPermissionsChatPublic {
    /** Can send messages in general */
    canSend: boolean;
    /** Can send file messages */
    files: boolean;
    /** Can send text messages */
    text: boolean;
}
export interface PresetsCreateRequestPermissionsChat {
    private: PresetsCreateRequestPermissionsChatPrivate;
    public: PresetsCreateRequestPermissionsChatPublic;
}
export interface PresetsCreateRequestPermissionsConnectedMeetings {
    canAlterConnectedMeetings: boolean;
    canSwitchConnectedMeetings: boolean;
    canSwitchToParentMeeting: boolean;
}
export type PresetsCreateRequestPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateRequestPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: PresetsCreateRequestPermissionsMediaAudioCanProduce | (string & {});
}
export type PresetsCreateRequestPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateRequestPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: PresetsCreateRequestPermissionsMediaScreenshareCanProduce | (string & {});
}
export type PresetsCreateRequestPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateRequestPermissionsMediaVideo {
    /** Can produce video */
    canProduce: PresetsCreateRequestPermissionsMediaVideoCanProduce | (string & {});
}
export interface PresetsCreateRequestPermissionsMedia {
    /** Audio permissions */
    audio: PresetsCreateRequestPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: PresetsCreateRequestPermissionsMediaScreenshare;
    /** Video permissions */
    video: PresetsCreateRequestPermissionsMediaVideo;
}
export interface PresetsCreateRequestPermissionsPlugins {
    /** Can close plugins that are already open */
    canClose: boolean;
    /** Can edit plugin config */
    canEditConfig: boolean;
    /** Can start plugins */
    canStart: boolean;
    /** Plugin configuration keyed by plugin UUID. */
    config: unknown;
}
export interface PresetsCreateRequestPermissionsPolls {
    /** Can create polls */
    canCreate: boolean;
    /** Can view polls */
    canView: boolean;
    /** Can vote on polls */
    canVote: boolean;
}
export type PresetsCreateRequestPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsCreateRequestPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type PresetsCreateRequestPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateRequestPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: PresetsCreateRequestPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: PresetsCreateRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: PresetsCreateRequestPermissionsRecorderType | (string & {});
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: PresetsCreateRequestPermissionsWaitingRoomType | (string & {});
    acceptStageRequests?: boolean | undefined;
    isRecorder?: boolean | undefined;
    stageAccess?: PresetsCreateRequestPermissionsStageAccess | (string & {}) | undefined;
    stageEnabled?: boolean | undefined;
    transcriptionEnabled?: boolean | undefined;
}
export type PresetsCreateRequestUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsCreateRequestUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export interface PresetsCreateRequestUiDesignTokensColorsBackground {
    "1000": string;
    "600": string;
    "700": string;
    "800": string;
    "900": string;
}
export interface PresetsCreateRequestUiDesignTokensColorsBrand {
    "300": string;
    "400": string;
    "500": string;
    "600": string;
    "700": string;
}
export interface PresetsCreateRequestUiDesignTokensColors {
    background: PresetsCreateRequestUiDesignTokensColorsBackground;
    brand: PresetsCreateRequestUiDesignTokensColorsBrand;
    danger: string;
    success: string;
    text: string;
    textOnBrand: string;
    videoBg: string;
    warning: string;
}
export type PresetsCreateRequestUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsCreateRequestUiDesignTokens {
    borderRadius: PresetsCreateRequestUiDesignTokensBorderRadius | (string & {});
    borderWidth: PresetsCreateRequestUiDesignTokensBorderWidth | (string & {});
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: PresetsCreateRequestUiDesignTokensTheme | (string & {});
    fontFamily?: string | undefined;
    googleFont?: string | undefined;
    logo?: string | undefined;
}
export interface PresetsCreateRequestUi {
    designTokens: PresetsCreateRequestUiDesignTokens;
}
export interface CreatePresetRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    config: PresetsCreateRequestConfig;
    /** Name of the preset */
    name: string;
    permissions: PresetsCreateRequestPermissions;
    ui: PresetsCreateRequestUi;
}
export type PresetsCreateResponseDataConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type PresetsCreateResponseDataConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsCreateResponseDataConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: PresetsCreateResponseDataConfigMediaScreenshareQuality;
}
export type PresetsCreateResponseDataConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsCreateResponseDataConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: PresetsCreateResponseDataConfigMediaVideoQuality;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | null | undefined;
}
export interface PresetsCreateResponseDataConfigMediaAudio {
    /** Enable High Quality Audio for your meetings */
    enableHighBitrate?: boolean | null | undefined;
    /** Enable Stereo for your meetings */
    enableStereo?: boolean | null | undefined;
}
export interface PresetsCreateResponseDataConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: PresetsCreateResponseDataConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: PresetsCreateResponseDataConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateResponseDataConfigMediaAudio | null | undefined;
}
export type PresetsCreateResponseDataConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type PresetsCreateResponseDataConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsCreateResponseDataConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: PresetsCreateResponseDataConfigMedia;
    /** Type of the meeting */
    viewType: PresetsCreateResponseDataConfigViewType;
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsCreateResponseDataConfigLivestreamViewerQualitiesList | null | undefined;
}
export type PresetsCreateResponseDataPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type PresetsCreateResponseDataPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type PresetsCreateResponseDataPermissionsChat = PresetsCreateRequestPermissionsChat;
export type PresetsCreateResponseDataPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type PresetsCreateResponseDataPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateResponseDataPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: PresetsCreateResponseDataPermissionsMediaAudioCanProduce;
}
export type PresetsCreateResponseDataPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateResponseDataPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: PresetsCreateResponseDataPermissionsMediaScreenshareCanProduce;
}
export type PresetsCreateResponseDataPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateResponseDataPermissionsMediaVideo {
    /** Can produce video */
    canProduce: PresetsCreateResponseDataPermissionsMediaVideoCanProduce;
}
export interface PresetsCreateResponseDataPermissionsMedia {
    /** Audio permissions */
    audio: PresetsCreateResponseDataPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: PresetsCreateResponseDataPermissionsMediaScreenshare;
    /** Video permissions */
    video: PresetsCreateResponseDataPermissionsMediaVideo;
}
export type PresetsCreateResponseDataPermissionsPlugins = PresetsCreateRequestPermissionsPlugins;
export type PresetsCreateResponseDataPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type PresetsCreateResponseDataPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsCreateResponseDataPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type PresetsCreateResponseDataPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsCreateResponseDataPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: PresetsCreateResponseDataPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: PresetsCreateRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: PresetsCreateResponseDataPermissionsRecorderType;
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: PresetsCreateResponseDataPermissionsWaitingRoomType;
    acceptStageRequests?: boolean | null | undefined;
    isRecorder?: boolean | null | undefined;
    stageAccess?: PresetsCreateResponseDataPermissionsStageAccess | null | undefined;
    stageEnabled?: boolean | null | undefined;
    transcriptionEnabled?: boolean | null | undefined;
}
export type PresetsCreateResponseDataUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsCreateResponseDataUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type PresetsCreateResponseDataUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type PresetsCreateResponseDataUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type PresetsCreateResponseDataUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type PresetsCreateResponseDataUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsCreateResponseDataUiDesignTokens {
    borderRadius: PresetsCreateResponseDataUiDesignTokensBorderRadius;
    borderWidth: PresetsCreateResponseDataUiDesignTokensBorderWidth;
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: PresetsCreateResponseDataUiDesignTokensTheme;
    fontFamily?: string | null | undefined;
    googleFont?: string | null | undefined;
    logo?: string | null | undefined;
}
export interface PresetsCreateResponseDataUi {
    designTokens: PresetsCreateResponseDataUiDesignTokens;
}
export interface PresetsCreateResponseData {
    /** ID of the preset */
    id: string;
    config: PresetsCreateResponseDataConfig;
    /** Timestamp this preset was created at */
    createdAt: string;
    /** Name of the preset */
    name: string;
    permissions: PresetsCreateResponseDataPermissions;
    ui: PresetsCreateResponseDataUi;
    /** Timestamp this preset was last updated */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreatePresetResponse {
    /** Data returned by the operation */
    data: PresetsCreateResponseData;
}
export type WebhooksCreateWebhookRequestEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksCreateWebhookRequestEventsList = Array<WebhooksCreateWebhookRequestEventsItem | (string & {})>;
export interface CreateWebhookWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** Events that this webhook will get triggered by */
    events: WebhooksCreateWebhookRequestEventsList;
    /** Name of the webhook */
    name: string;
    /** URL this webhook will send events to */
    url: string;
    /** Set whether or not the webhook should be active when created */
    enabled?: boolean | undefined;
}
export type WebhooksCreateWebhookResponseDataEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksCreateWebhookResponseDataEventsList = Array<WebhooksCreateWebhookResponseDataEventsItem>;
export interface WebhooksCreateWebhookResponseData {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksCreateWebhookResponseDataEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateWebhookWebhookResponse {
    data: WebhooksCreateWebhookResponseData;
}
export interface DeleteMeetingParticipantMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
}
export interface MeetingsDeleteMeetingParticipantResponseData {
    /** Timestamp this object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** A unique participant ID generated by the client. */
    customParticipantId: string;
    /** ID of the preset applied to this participant. */
    presetId: string;
    /** Timestamp this object was updated at. The time is returned in ISO format. */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteMeetingParticipantMeetingResponse {
    /** Data returned by the operation */
    data?: MeetingsDeleteMeetingParticipantResponseData | null | undefined;
}
export interface DeletePresetRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    presetId: string;
}
export type PresetsDeleteResponseDataConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type PresetsDeleteResponseDataConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsDeleteResponseDataConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: PresetsDeleteResponseDataConfigMediaScreenshareQuality;
}
export type PresetsDeleteResponseDataConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsDeleteResponseDataConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: PresetsDeleteResponseDataConfigMediaVideoQuality;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | null | undefined;
}
export type PresetsDeleteResponseDataConfigMediaAudio = PresetsCreateResponseDataConfigMediaAudio;
export interface PresetsDeleteResponseDataConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: PresetsDeleteResponseDataConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: PresetsDeleteResponseDataConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateResponseDataConfigMediaAudio | null | undefined;
}
export type PresetsDeleteResponseDataConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type PresetsDeleteResponseDataConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsDeleteResponseDataConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: PresetsDeleteResponseDataConfigMedia;
    /** Type of the meeting */
    viewType: PresetsDeleteResponseDataConfigViewType;
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsDeleteResponseDataConfigLivestreamViewerQualitiesList | null | undefined;
}
export type PresetsDeleteResponseDataPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type PresetsDeleteResponseDataPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type PresetsDeleteResponseDataPermissionsChat = PresetsCreateRequestPermissionsChat;
export type PresetsDeleteResponseDataPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type PresetsDeleteResponseDataPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsDeleteResponseDataPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: PresetsDeleteResponseDataPermissionsMediaAudioCanProduce;
}
export type PresetsDeleteResponseDataPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsDeleteResponseDataPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: PresetsDeleteResponseDataPermissionsMediaScreenshareCanProduce;
}
export type PresetsDeleteResponseDataPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsDeleteResponseDataPermissionsMediaVideo {
    /** Can produce video */
    canProduce: PresetsDeleteResponseDataPermissionsMediaVideoCanProduce;
}
export interface PresetsDeleteResponseDataPermissionsMedia {
    /** Audio permissions */
    audio: PresetsDeleteResponseDataPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: PresetsDeleteResponseDataPermissionsMediaScreenshare;
    /** Video permissions */
    video: PresetsDeleteResponseDataPermissionsMediaVideo;
}
export type PresetsDeleteResponseDataPermissionsPlugins = PresetsCreateRequestPermissionsPlugins;
export type PresetsDeleteResponseDataPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type PresetsDeleteResponseDataPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsDeleteResponseDataPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type PresetsDeleteResponseDataPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsDeleteResponseDataPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: PresetsDeleteResponseDataPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: PresetsCreateRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: PresetsDeleteResponseDataPermissionsRecorderType;
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: PresetsDeleteResponseDataPermissionsWaitingRoomType;
    acceptStageRequests?: boolean | null | undefined;
    isRecorder?: boolean | null | undefined;
    stageAccess?: PresetsDeleteResponseDataPermissionsStageAccess | null | undefined;
    stageEnabled?: boolean | null | undefined;
    transcriptionEnabled?: boolean | null | undefined;
}
export type PresetsDeleteResponseDataUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsDeleteResponseDataUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type PresetsDeleteResponseDataUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type PresetsDeleteResponseDataUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type PresetsDeleteResponseDataUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type PresetsDeleteResponseDataUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsDeleteResponseDataUiDesignTokens {
    borderRadius: PresetsDeleteResponseDataUiDesignTokensBorderRadius;
    borderWidth: PresetsDeleteResponseDataUiDesignTokensBorderWidth;
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: PresetsDeleteResponseDataUiDesignTokensTheme;
    fontFamily?: string | null | undefined;
    googleFont?: string | null | undefined;
    logo?: string | null | undefined;
}
export interface PresetsDeleteResponseDataUi {
    designTokens: PresetsDeleteResponseDataUiDesignTokens;
}
export interface PresetsDeleteResponseData {
    /** ID of the preset */
    id: string;
    config: PresetsDeleteResponseDataConfig;
    /** Timestamp this preset was created at */
    createdAt: string;
    /** Name of the preset */
    name: string;
    permissions: PresetsDeleteResponseDataPermissions;
    ui: PresetsDeleteResponseDataUi;
    /** Timestamp this preset was last updated */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeletePresetResponse {
    /** Data returned by the operation */
    data: PresetsDeleteResponseData;
}
export interface DeleteWebhookWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    webhookId: string;
}
export type WebhooksDeleteWebhookResponseDataEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksDeleteWebhookResponseDataEventsList = Array<WebhooksDeleteWebhookResponseDataEventsItem>;
export interface WebhooksDeleteWebhookResponseData {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksDeleteWebhookResponseDataEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteWebhookWebhookResponse {
    data: WebhooksDeleteWebhookResponseData;
}
export interface EditParticipantMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
    /** (Optional) Name of the participant. */
    name?: string | undefined;
    /** (Optional) A URL to a picture to be used for the participant. */
    picture?: string | undefined;
    /** (Optional) Name of the preset to apply to this participant. */
    presetName?: string | undefined;
}
export type MeetingsEditParticipantResponseData = MeetingsAddParticipantResponseData;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface EditParticipantMeetingResponse {
    /** Represents a participant. */
    data?: MeetingsAddParticipantResponseData | null | undefined;
}
export type WebhooksEditWebhookRequestEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.chatSynced" | "meeting.transcript" | "meeting.summary";
export type WebhooksEditWebhookRequestEventsList = Array<WebhooksEditWebhookRequestEventsItem | (string & {})>;
export interface EditWebhookWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    webhookId: string;
    enabled?: boolean | undefined;
    /** Events that the webhook will get triggered by */
    events?: WebhooksEditWebhookRequestEventsList | undefined;
    /** Name of the webhook */
    name?: string | undefined;
    /** URL the webhook will send events to */
    url?: string | undefined;
}
export type WebhooksEditWebhookResponseDataEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksEditWebhookResponseDataEventsList = Array<WebhooksEditWebhookResponseDataEventsItem>;
export interface WebhooksEditWebhookResponseData {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksEditWebhookResponseDataEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface EditWebhookWebhookResponse {
    data: WebhooksEditWebhookResponseData;
}
export interface GenerateSummaryOfTranscriptsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
}
export interface SessionsGenerateSummaryOfTranscriptsResponseData {
    sessionId?: string | null | undefined;
    status?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GenerateSummaryOfTranscriptsSessionResponse {
    data?: SessionsGenerateSummaryOfTranscriptsResponseData | null | undefined;
}
export interface GetActiveLivestreamsForLivestreamIdLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    livestreamId: string;
}
export type LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataLivestreamStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataLivestream {
    /** ID of the livestream. */
    id: string;
    /** Timestamp the livestream was created at, in ISO format. */
    createdAt: string;
    /** Specifies if the livestream is disabled. */
    disabled: boolean;
    /** ID of the underlying Cloudflare Stream live input. */
    externalId: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** Specifies if the livestream is ingested manually by an RTMP encoder. */
    manualIngest: boolean;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataLivestreamStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
    /** Timestamp the livestream was last updated at, in ISO format. */
    updatedAt: string;
}
export interface LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession {
    /** ID of the livestream session. */
    id: string;
    /** Timestamp the livestream session was created at, in ISO format. */
    createdAt: string;
    /** Error message, if the livestream session failed. */
    errMessage: string;
    /** The time duration for which the input was given or the meeting was streamed. */
    ingestSeconds: number;
    /** Timestamp the livestream session was invoked at, in ISO format. */
    invokedTime: string;
    /** ID of the livestream. */
    livestreamId: string;
    /** Timestamp the livestream session started at, in ISO format. */
    startedTime: string;
    /** Timestamp the livestream session stopped at, in ISO format. */
    stoppedTime: string;
    /** Timestamp the livestream session was last updated at, in ISO format. */
    updatedAt: string;
    /** The total view time for which the viewers watched the stream. */
    viewerSeconds: number;
}
export interface LivestreamsGetActiveLivestreamsForLivestreamIdResponseData {
    livestream: LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataLivestream;
    session: LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetActiveLivestreamsForLivestreamIdLivestreamResponse {
    data: LivestreamsGetActiveLivestreamsForLivestreamIdResponseData;
}
export interface GetActiveRecordingsRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
}
export type RecordingsGetActiveRecordingsResponseDataStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export interface RecordingsGetActiveRecordingsResponseData {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsGetActiveRecordingsResponseDataStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetActiveRecordingsRecordingResponse {
    /** Data returned by the operation */
    data: RecordingsGetActiveRecordingsResponseData;
}
export interface GetActiveSessionActiveSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
}
export type ActiveSessionGetActiveSessionResponseDataStatus = "LIVE" | "ENDED";
export type ActiveSessionGetActiveSessionResponseDataType = "meeting" | "livestream" | "participant";
export type ActiveSessionGetActiveSessionResponseDataBreakoutRoomsList = Array<unknown>;
export interface ActiveSessionGetActiveSessionResponseData {
    /** ID of the session */
    id: string;
    /** ID of the meeting this session is associated with. In the case of V2 meetings, it is always a UUID. In V1 meetings, it is a room name of the form `abcdef-ghijkl` */
    associatedId: string;
    /** timestamp when session created */
    createdAt: string;
    /** number of participants currently in the session */
    liveParticipants: number;
    /** number of maximum participants that were in the session */
    maxConcurrentParticipants: number;
    /** Title of the meeting this session belongs to */
    meetingDisplayName: string;
    /** number of minutes consumed since the session started */
    minutesConsumed: number;
    /** App id that hosted this session */
    organizationId: string;
    /** timestamp when session started */
    startedAt: string;
    /** current status of session */
    status: ActiveSessionGetActiveSessionResponseDataStatus;
    /** type of session */
    type: ActiveSessionGetActiveSessionResponseDataType;
    /** timestamp when session was last updated */
    updatedAt: string;
    breakoutRooms?: ActiveSessionGetActiveSessionResponseDataBreakoutRoomsList | null | undefined;
    /** timestamp when session ended */
    endedAt?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetActiveSessionActiveSessionResponse {
    data?: ActiveSessionGetActiveSessionResponseData | null | undefined;
}
export type LivestreamsGetAllLivestreamsRequestSortOrder = "ASC" | "DSC";
export type LivestreamsGetAllLivestreamsRequestStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED";
export interface GetAllLivestreamsLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** Specify the end time range in ISO format to access the live stream. */
    endTime?: string | undefined;
    /** Exclude the RealtimeKit meetings that are livestreamed. */
    excludeMeetings?: boolean | undefined;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Specifies the sorting order for the results. */
    sortOrder?: LivestreamsGetAllLivestreamsRequestSortOrder | (string & {}) | undefined;
    /** Specify the start time range in ISO format to access the live stream. */
    startTime?: string | undefined;
    /** Specifies the status of the operation. */
    status?: LivestreamsGetAllLivestreamsRequestStatus | (string & {}) | undefined;
}
export type LivestreamsGetAllLivestreamsResponseDataItemStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface LivestreamsGetAllLivestreamsResponseDataItem {
    /** ID of the livestream. */
    id: string;
    /** Timestamp the livestream was created at, in ISO format. */
    createdAt: string;
    /** Specifies if the livestream is disabled. */
    disabled: boolean;
    /** ID of the underlying Cloudflare Stream live input. */
    externalId: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** Specifies if the livestream is ingested manually by an RTMP encoder. */
    manualIngest: boolean;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: LivestreamsGetAllLivestreamsResponseDataItemStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
    /** Timestamp the livestream was last updated at, in ISO format. */
    updatedAt: string;
}
export type LivestreamsGetAllLivestreamsResponseDataList = Array<LivestreamsGetAllLivestreamsResponseDataItem>;
export interface LivestreamsGetAllLivestreamsResponsePaging {
    endOffset: number;
    startOffset: number;
    totalCount: number;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAllLivestreamsLivestreamResponse {
    data: LivestreamsGetAllLivestreamsResponseDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export type AppsGetRequestSortOrder = "ASC" | "DESC";
export interface GetAppRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** Search string that matches apps by name. */
    search?: string | undefined;
    /** Sort order for apps by creation time. */
    sortOrder?: AppsGetRequestSortOrder | (string & {}) | undefined;
}
export interface AppsGetResponseDataItem {
    id?: string | null | undefined;
    createdAt?: string | null | undefined;
    name?: string | null | undefined;
}
export type AppsGetResponseDataList = Array<AppsGetResponseDataItem>;
export interface AppsGetResponsePaging {
    endOffset?: number | null | undefined;
    startOffset?: number | null | undefined;
    totalCount?: number | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAppResponse {
    data?: AppsGetResponseDataList | null | undefined;
    paging?: AppsGetResponsePaging | null | undefined;
}
export interface GetAppByIdRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
}
export type GetAppByIdResponseData = AppsGetResponseDataItem;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetAppByIdResponse {
    data?: AppsGetResponseDataItem | null | undefined;
}
export interface GetLivestreamAnalyticsCompleteLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** Specify the end time as a Unix timestamp in seconds to access the livestream analytics. */
    endTime?: number | undefined;
    /** Optional filters for livestream analytics. */
    filters?: string | undefined;
    /** Specify the start time as a Unix timestamp in seconds to access the livestream analytics. */
    startTime?: number | undefined;
}
export interface LivestreamsGetLivestreamAnalyticsCompleteResponseData {
    /** Count of total livestreams. */
    count?: number | null | undefined;
    /** Total time duration for which the input was given or the meeting was streamed. */
    totalIngestSeconds?: number | null | undefined;
    /** Total view time for which the viewers watched the stream. */
    totalViewerSeconds?: number | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamAnalyticsCompleteLivestreamResponse {
    data?: LivestreamsGetLivestreamAnalyticsCompleteResponseData | null | undefined;
}
export interface GetLivestreamAnalyticsDaywiseLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** Specify the end time as a Unix timestamp in seconds to access the livestream analytics. */
    endTime?: number | undefined;
    /** Optional filters for livestream analytics. */
    filters?: string | undefined;
    /** Specify the start time as a Unix timestamp in seconds to access the livestream analytics. */
    startTime?: number | undefined;
}
export interface LivestreamsGetLivestreamAnalyticsDaywiseResponseDataItem {
    /** Count of total livestream sessions. */
    count?: number | null | undefined;
    /** Analytics date. */
    date?: string | null | undefined;
    /** Total time duration for which the input was given or the meeting was streamed. */
    totalIngestSeconds?: number | null | undefined;
    /** Total view time for which the viewers watched the stream. */
    totalViewerSeconds?: number | null | undefined;
}
export type LivestreamsGetLivestreamAnalyticsDaywiseResponseDataList = Array<LivestreamsGetLivestreamAnalyticsDaywiseResponseDataItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamAnalyticsDaywiseLivestreamResponse {
    data?: LivestreamsGetLivestreamAnalyticsDaywiseResponseDataList | null | undefined;
}
export interface GetLivestreamSessionDetailsForMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
}
export type GetLivestreamSessionDetailsForMeetingResponseDataDataLivestreamStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface GetLivestreamSessionDetailsForMeetingResponseDataDataLivestream {
    /** ID of the livestream. */
    id: string;
    /** Timestamp the livestream was created at, in ISO format. */
    createdAt: string;
    /** Specifies if the livestream is disabled. */
    disabled: boolean;
    /** ID of the underlying Cloudflare Stream live input. */
    externalId: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** Specifies if the livestream is ingested manually by an RTMP encoder. */
    manualIngest: boolean;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: GetLivestreamSessionDetailsForMeetingResponseDataDataLivestreamStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
    /** Timestamp the livestream was last updated at, in ISO format. */
    updatedAt: string;
}
export type GetLivestreamSessionDetailsForMeetingResponseDataDataSessionsItem = LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
export type GetLivestreamSessionDetailsForMeetingResponseDataDataSessionsList = Array<LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession>;
export interface GetLivestreamSessionDetailsForMeetingResponseDataData {
    livestream: GetLivestreamSessionDetailsForMeetingResponseDataDataLivestream;
    sessions: GetLivestreamSessionDetailsForMeetingResponseDataDataSessionsList;
}
export type GetLivestreamSessionDetailsForMeetingResponseDataPaging = LivestreamsGetAllLivestreamsResponsePaging;
export interface GetLivestreamSessionDetailsForMeetingResponseData {
    data: GetLivestreamSessionDetailsForMeetingResponseDataData;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamSessionDetailsForMeetingResponse {
    data: GetLivestreamSessionDetailsForMeetingResponseData;
}
export interface GetLivestreamSessionDetailsForSessionIdLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    livestreamSessionId: string;
}
export type LivestreamsGetLivestreamSessionDetailsForSessionIdResponseData = LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamSessionDetailsForSessionIdLivestreamResponse {
    data: LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
}
export interface GetLivestreamSessionForLivestreamIdLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    livestreamId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
}
export type LivestreamsGetLivestreamSessionForLivestreamIdResponseDataLivestreamStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface LivestreamsGetLivestreamSessionForLivestreamIdResponseDataLivestream {
    /** ID of the livestream. */
    id: string;
    /** Timestamp the livestream was created at, in ISO format. */
    createdAt: string;
    /** Specifies if the livestream is disabled. */
    disabled: boolean;
    /** ID of the underlying Cloudflare Stream live input. */
    externalId: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** Specifies if the livestream is ingested manually by an RTMP encoder. */
    manualIngest: boolean;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: LivestreamsGetLivestreamSessionForLivestreamIdResponseDataLivestreamStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
    /** Timestamp the livestream was last updated at, in ISO format. */
    updatedAt: string;
}
export type LivestreamsGetLivestreamSessionForLivestreamIdResponseDataSessionsItem = LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
export type LivestreamsGetLivestreamSessionForLivestreamIdResponseDataSessionsList = Array<LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession>;
export interface LivestreamsGetLivestreamSessionForLivestreamIdResponseData {
    livestream: LivestreamsGetLivestreamSessionForLivestreamIdResponseDataLivestream;
    sessions: LivestreamsGetLivestreamSessionForLivestreamIdResponseDataSessionsList;
}
export type LivestreamsGetLivestreamSessionForLivestreamIdResponsePaging = LivestreamsGetAllLivestreamsResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamSessionForLivestreamIdLivestreamResponse {
    data: LivestreamsGetLivestreamSessionForLivestreamIdResponseData;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export interface GetLivestreamSessionsForSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
}
export type GetLivestreamSessionsForSessionResponseDataDataItem = LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession;
export type GetLivestreamSessionsForSessionResponseDataDataList = Array<LivestreamsGetActiveLivestreamsForLivestreamIdResponseDataSession>;
export type GetLivestreamSessionsForSessionResponseDataPaging = LivestreamsGetAllLivestreamsResponsePaging;
export interface GetLivestreamSessionsForSessionResponseData {
    data: GetLivestreamSessionsForSessionResponseDataDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLivestreamSessionsForSessionResponse {
    data: GetLivestreamSessionsForSessionResponseData;
}
export type MeetingsGetRequestStatus = "ACTIVE" | "INACTIVE";
export interface GetMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** The end time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    endTime?: string | undefined;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page */
    perPage?: number | undefined;
    /** The search query string. You can search using the meeting ID or title. */
    search?: string | undefined;
    /** The start time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    startTime?: string | undefined;
    /** Filter meetings by status. */
    status?: MeetingsGetRequestStatus | (string & {}) | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsGetResponseDataItemRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsGetResponseDataItemRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsGetResponseDataItemRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsGetResponseDataItemRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigLiveStreamingConfig = MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig;
export type MeetingsGetResponseDataItemRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetResponseDataItemRecordingConfigStorageConfig = MeetingsGetResponseDataItemRecordingConfigStorageConfigCase0 | MeetingsGetResponseDataItemRecordingConfigStorageConfigCase1 | MeetingsGetResponseDataItemRecordingConfigStorageConfigCase2 | MeetingsGetResponseDataItemRecordingConfigStorageConfigCase3;
export type MeetingsGetResponseDataItemRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsGetResponseDataItemRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsGetResponseDataItemRecordingConfigVideoConfigWatermarkSize = MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsGetResponseDataItemRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsGetResponseDataItemRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface MeetingsGetResponseDataItemRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsGetResponseDataItemRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsGetResponseDataItemRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface MeetingsGetResponseDataItemRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsGetResponseDataItemRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: MeetingsGetResponseDataItemRecordingConfigStorageConfig | null | undefined;
    videoConfig?: MeetingsGetResponseDataItemRecordingConfigVideoConfig | null | undefined;
}
export type MeetingsGetResponseDataItemStatus = "ACTIVE" | "INACTIVE";
export interface MeetingsGetResponseDataItem {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsGetResponseDataItemRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsGetResponseDataItemStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
export type MeetingsGetResponseDataList = Array<MeetingsGetResponseDataItem>;
export type MeetingsGetResponsePaging = LivestreamsGetAllLivestreamsResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMeetingResponse {
    data: MeetingsGetResponseDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export interface GetMeetingActiveLivestreamsLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
}
export type LivestreamsGetMeetingActiveLivestreamsResponseDataStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface LivestreamsGetMeetingActiveLivestreamsResponseData {
    /** ID of the livestream. */
    id: string;
    /** Timestamp the livestream was created at, in ISO format. */
    createdAt: string;
    /** Specifies if the livestream is disabled. */
    disabled: boolean;
    /** ID of the underlying Cloudflare Stream live input. */
    externalId: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** Specifies if the livestream is ingested manually by an RTMP encoder. */
    manualIngest: boolean;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: LivestreamsGetMeetingActiveLivestreamsResponseDataStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
    /** Timestamp the livestream was last updated at, in ISO format. */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMeetingActiveLivestreamsLivestreamResponse {
    data: LivestreamsGetMeetingActiveLivestreamsResponseData;
}
export interface GetMeetingByIdMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    name?: string | undefined;
}
export type MeetingsGetMeetingByIdResponseDataAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsGetMeetingByIdResponseDataAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsGetMeetingByIdResponseDataAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsGetMeetingByIdResponseDataAiConfigSummarizationSummaryType | null | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsGetMeetingByIdResponseDataAiConfigSummarizationTextFormat | null | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsGetMeetingByIdResponseDataAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsGetMeetingByIdResponseDataAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsGetMeetingByIdResponseDataAiConfigTranscriptionKeywordsList | null | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsGetMeetingByIdResponseDataAiConfigTranscriptionLanguage | null | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | null | undefined;
}
export interface MeetingsGetMeetingByIdResponseDataAiConfig {
    /** Summary Config */
    summarization?: MeetingsGetMeetingByIdResponseDataAiConfigSummarization | null | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsGetMeetingByIdResponseDataAiConfigTranscription | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigLiveStreamingConfig = MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig;
export type MeetingsGetMeetingByIdResponseDataRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfig = MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase0 | MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase1 | MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase2 | MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfigCase3;
export type MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkSize = MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface MeetingsGetMeetingByIdResponseDataRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsGetMeetingByIdResponseDataRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: MeetingsGetMeetingByIdResponseDataRecordingConfigStorageConfig | null | undefined;
    videoConfig?: MeetingsGetMeetingByIdResponseDataRecordingConfigVideoConfig | null | undefined;
}
export type MeetingsGetMeetingByIdResponseDataStatus = "ACTIVE" | "INACTIVE";
export interface MeetingsGetMeetingByIdResponseData {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsGetMeetingByIdResponseDataAiConfig | null | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsGetMeetingByIdResponseDataRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsGetMeetingByIdResponseDataStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMeetingByIdMeetingResponse {
    /** Data returned by the operation */
    data?: MeetingsGetMeetingByIdResponseData | null | undefined;
}
export interface GetMeetingParticipantMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
}
export interface MeetingsGetMeetingParticipantResponseData {
    /** ID of the participant. */
    id: string;
    /** When this object was created. The time is returned in ISO format. */
    createdAt: string;
    /** A unique participant ID generated by the client. */
    customParticipantId: string;
    /** Preset applied to the participant. */
    presetName: string;
    /** When this object was updated. The time is returned in ISO format. */
    updatedAt: string;
    /** Name of the participant. */
    name?: string | null | undefined;
    /** URL to a picture of the participant. */
    picture?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMeetingParticipantMeetingResponse {
    /** Data returned by the operation */
    data: MeetingsGetMeetingParticipantResponseData;
}
export interface GetMeetingParticipantsMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page */
    perPage?: number | undefined;
}
export type MeetingsGetMeetingParticipantsResponseDataItem = MeetingsGetMeetingParticipantResponseData;
export type MeetingsGetMeetingParticipantsResponseDataList = Array<MeetingsGetMeetingParticipantResponseData>;
export type MeetingsGetMeetingParticipantsResponsePaging = LivestreamsGetAllLivestreamsResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMeetingParticipantsMeetingResponse {
    data: MeetingsGetMeetingParticipantsResponseDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export interface GetOneRecordingRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    recordingId: string;
}
export type RecordingsGetOneRecordingResponseDataStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export type RecordingsGetOneRecordingResponseDataStartReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsGetOneRecordingResponseDataStartReasonCaller {
    /** Name of the user who started the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsGetOneRecordingResponseDataStartReasonCallerType | null | undefined;
    /** The user ID of the person who started the recording. */
    userId?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStartReasonReason = "API_CALL" | "RECORD_ON_START";
export interface RecordingsGetOneRecordingResponseDataStartReason {
    caller?: RecordingsGetOneRecordingResponseDataStartReasonCaller | null | undefined;
    /** Specifies if the recording was started using the "Start a Recording"API or using the parameter RECORD_ON_START in the "Create a meeting" API. */
    reason?: RecordingsGetOneRecordingResponseDataStartReasonReason | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStopReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsGetOneRecordingResponseDataStopReasonCaller {
    /** Name of the user who stopped the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsGetOneRecordingResponseDataStopReasonCallerType | null | undefined;
    /** The user ID of the person who stopped the recording. */
    userId?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStopReasonReason = "API_CALL" | "INTERNAL_ERROR" | "ALL_PEERS_LEFT";
export interface RecordingsGetOneRecordingResponseDataStopReason {
    caller?: RecordingsGetOneRecordingResponseDataStopReasonCaller | null | undefined;
    /** Specifies the reason why the recording stopped. */
    reason?: RecordingsGetOneRecordingResponseDataStopReasonReason | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetOneRecordingResponseDataStorageConfigCase0Type = "gcs";
export interface RecordingsGetOneRecordingResponseDataStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetOneRecordingResponseDataStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetOneRecordingResponseDataStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetOneRecordingResponseDataStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsGetOneRecordingResponseDataStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetOneRecordingResponseDataStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetOneRecordingResponseDataStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStorageConfigCase2AuthMethod = "KEY";
export type RecordingsGetOneRecordingResponseDataStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetOneRecordingResponseDataStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetOneRecordingResponseDataStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetOneRecordingResponseDataStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsGetOneRecordingResponseDataStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetOneRecordingResponseDataStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetOneRecordingResponseDataStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetOneRecordingResponseDataStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetOneRecordingResponseDataStorageConfig = RecordingsGetOneRecordingResponseDataStorageConfigCase0 | RecordingsGetOneRecordingResponseDataStorageConfigCase1 | RecordingsGetOneRecordingResponseDataStorageConfigCase2 | RecordingsGetOneRecordingResponseDataStorageConfigCase3;
export interface RecordingsGetOneRecordingResponseData {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsGetOneRecordingResponseDataStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
    startReason?: RecordingsGetOneRecordingResponseDataStartReason | null | undefined;
    stopReason?: RecordingsGetOneRecordingResponseDataStopReason | null | undefined;
    storageConfig?: RecordingsGetOneRecordingResponseDataStorageConfig | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetOneRecordingRecordingResponse {
    /** Data returned by the operation */
    data?: RecordingsGetOneRecordingResponseData | null | undefined;
}
export interface GetOrgAnalyticsAnalyticRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** end date in YYYY-MM-DD format */
    endDate?: string | undefined;
    /** start date in YYYY-MM-DD format */
    startDate?: string | undefined;
}
export interface AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsItem {
    day?: string | null | undefined;
    /** Total recording minutes for a specific day */
    totalRecordingMinutes?: number | null | undefined;
    /** Total number of recordings for a specific day */
    totalRecordings?: number | null | undefined;
}
export type AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsList = Array<AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsItem>;
export interface AnalyticsGetOrgAnalyticsResponseDataRecordingStats {
    /** Day wise recording stats */
    dayStats?: AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsList | null | undefined;
    /** Total number of recordings during the range specified */
    recordingCount?: number | null | undefined;
    /** Total recording minutes during the range specified */
    recordingMinutesConsumed?: number | null | undefined;
}
export interface AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsItem {
    day?: string | null | undefined;
    /** Total session minutes for a specific day */
    totalSessionMinutes?: number | null | undefined;
    /** Total number of sessions for a specific day */
    totalSessions?: number | null | undefined;
}
export type AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsList = Array<AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsItem>;
export interface AnalyticsGetOrgAnalyticsResponseDataSessionStats {
    /** Day wise session stats */
    dayStats?: AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsList | null | undefined;
    /** Total number of sessions during the range specified */
    sessionsCount?: number | null | undefined;
    /** Total session minutes during the range specified */
    sessionsMinutesConsumed?: number | null | undefined;
}
export interface AnalyticsGetOrgAnalyticsResponseData {
    /** Recording statistics of an App during the range specified */
    recordingStats?: AnalyticsGetOrgAnalyticsResponseDataRecordingStats | null | undefined;
    /** Session statistics of an App during the range specified */
    sessionStats?: AnalyticsGetOrgAnalyticsResponseDataSessionStats | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetOrgAnalyticsAnalyticResponse {
    data?: AnalyticsGetOrgAnalyticsResponseData | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdRequestFilters = "device_info" | "ip_information" | "precall_network_information" | "events" | "quality_stats";
export interface GetParticipantDataFromPeerIdSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    peerId: string;
    /** Filter to apply to the peer report. */
    filters?: SessionsGetParticipantDataFromPeerIdRequestFilters | (string & {}) | undefined;
    /** if true, response includes all the peer events of participant. */
    includePeerEvents?: boolean | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItemEventName = "PEER_CREATED" | "PEER_JOINING" | "PEER_LEAVING";
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItemPresetViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM" | "CHAT";
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItem {
    /** ID of the peer event. */
    id?: string | null | undefined;
    /** Timestamp when this peer event was created. */
    createdAt?: string | null | undefined;
    /** Name of the peer event. */
    eventName?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItemEventName | null | undefined;
    /** Minutes consumed attributed to this event. */
    minutesConsumed?: number | null | undefined;
    /** ID of the participant this event belongs to. */
    participantId?: string | null | undefined;
    /** Peer ID this event belongs to. */
    peerId?: string | null | undefined;
    /** View type of the preset associated with the peer. */
    presetViewType?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItemPresetViewType | null | undefined;
    /** ID of the session this event belongs to. */
    sessionId?: string | null | undefined;
    /** ID of the socket session associated with this event. */
    socketSessionId?: string | null | undefined;
    /** Timestamp when this peer event was last updated. */
    updatedAt?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem {
    /** ID of the device. */
    deviceId?: string | null | undefined;
    /** Kind of device, for example audioinput or videoinput. */
    kind?: string | null | undefined;
    /** Human-readable label of the device. */
    label?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemRemovedItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemRemovedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItem {
    /** Devices that became available. */
    added?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedList | null | undefined;
    /** Devices that became unavailable. */
    removed?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemRemovedList | null | undefined;
    /** Timestamp of the device update. */
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataBrowserMetadata {
    browser?: string | null | undefined;
    browserVersion?: string | null | undefined;
    engine?: string | null | undefined;
    userAgent?: string | null | undefined;
    webglSupport?: boolean | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportItem {
    availableIncomingBitrate?: number | null | undefined;
    availableOutgoingBitrate?: number | null | undefined;
    bytesDiscardedOnSend?: number | null | undefined;
    bytesReceived?: number | null | undefined;
    bytesSent?: number | null | undefined;
    currentRoundTripTime?: number | null | undefined;
    /** Epoch milliseconds when the last packet was received. */
    lastPacketReceivedTimestamp?: number | null | undefined;
    /** Epoch milliseconds when the last packet was sent. */
    lastPacketSentTimestamp?: number | null | undefined;
    localCandidateAddress?: string | null | undefined;
    localCandidateId?: string | null | undefined;
    localCandidateNetworkType?: string | null | undefined;
    localCandidatePort?: number | null | undefined;
    localCandidateProtocol?: string | null | undefined;
    localCandidateRelatedAddress?: string | null | undefined;
    localCandidateRelatedPort?: number | null | undefined;
    localCandidateType?: string | null | undefined;
    localCandidateUrl?: string | null | undefined;
    nominated?: boolean | null | undefined;
    packetsDiscardedOnSend?: number | null | undefined;
    packetsReceived?: number | null | undefined;
    packetsSent?: number | null | undefined;
    remoteCandidateAddress?: string | null | undefined;
    remoteCandidateId?: string | null | undefined;
    remoteCandidatePort?: number | null | undefined;
    remoteCandidateProtocol?: string | null | undefined;
    remoteCandidateType?: string | null | undefined;
    remoteCandidateUrl?: string | null | undefined;
    totalRoundTripTime?: number | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsProducingTransportItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsProducingTransportList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairs {
    consumingTransport?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsConsumingTransportList | null | undefined;
    producingTransport?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairsProducingTransportList | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataDeviceInfo {
    cpus?: number | null | undefined;
    isMobile?: boolean | null | undefined;
    os?: string | null | undefined;
    osVersion?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItemMetadataValue = string | number | boolean;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItemMetadataMap = {
    [key: string]: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItemMetadataValue | undefined;
};
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItem {
    /** Event-specific metadata. Keys vary per event; values are primitive scalars (string, number, boolean, or null). */
    metadata?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItemMetadataMap | null | undefined;
    /** Name of the event. */
    name?: string | null | undefined;
    /** Timestamp when the event occurred. */
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataIpInformationAsn {
    asn?: string | null | undefined;
    domain?: string | null | undefined;
    name?: string | null | undefined;
    route?: string | null | undefined;
    type?: string | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataIpInformation {
    asn?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataIpInformationAsn | null | undefined;
    city?: string | null | undefined;
    country?: string | null | undefined;
    ipv4?: string | null | undefined;
    org?: string | null | undefined;
    region?: string | null | undefined;
    timezone?: string | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataNativeMetadata {
    audioEncoder?: string | null | undefined;
    videoEncoder?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataItemSdpList = Array<string>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataItem {
    effectiveNetworkType?: string | null | undefined;
    reflexiveConnectivity?: boolean | null | undefined;
    relayConnectivity?: boolean | null | undefined;
    sdp?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataItemSdpList | null | undefined;
    timestamp?: string | null | undefined;
    turnConnectivity?: boolean | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSelectedDeviceUpdatesItemDevice = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSelectedDeviceUpdatesItem {
    /** A media device (camera, microphone, or speaker). */
    device?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSelectedDeviceUpdatesList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSelectedDeviceUpdatesItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemAddedItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemAddedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemRemovedItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemRemovedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItem {
    /** Devices that became available. */
    added?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemAddedList | null | undefined;
    /** Devices that became unavailable. */
    removed?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItemRemovedList | null | undefined;
    /** Timestamp of the device update. */
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemAddedItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemAddedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemRemovedItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemRemovedList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesItemAddedItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItem {
    /** Devices that became available. */
    added?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemAddedList | null | undefined;
    /** Devices that became unavailable. */
    removed?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItemRemovedList | null | undefined;
    /** Timestamp of the device update. */
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadata {
    audioDevicesUpdates?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataAudioDevicesUpdatesList | null | undefined;
    browserMetadata?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataBrowserMetadata | null | undefined;
    candidatePairs?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataCandidatePairs | null | undefined;
    deviceInfo?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataDeviceInfo | null | undefined;
    events?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataEventsList | null | undefined;
    ipInformation?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataIpInformation | null | undefined;
    nativeMetadata?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataNativeMetadata | null | undefined;
    pcMetadata?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataPcMetadataList | null | undefined;
    roomViewType?: string | null | undefined;
    sdkName?: string | null | undefined;
    sdkType?: string | null | undefined;
    sdkVersion?: string | null | undefined;
    selectedDeviceUpdates?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSelectedDeviceUpdatesList | null | undefined;
    speakerDevicesUpdates?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataSpeakerDevicesUpdatesList | null | undefined;
    videoDevicesUpdates?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadataVideoDevicesUpdatesList | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerItem {
    bytesReceived?: number | null | undefined;
    concealmentEvents?: number | null | undefined;
    consumerId?: string | null | undefined;
    jitter?: number | null | undefined;
    jitterBufferDelay?: number | null | undefined;
    jitterBufferEmittedCount?: number | null | undefined;
    mid?: string | null | undefined;
    mosQuality?: number | null | undefined;
    packetsLost?: number | null | undefined;
    packetsReceived?: number | null | undefined;
    peerId?: string | null | undefined;
    producerId?: string | null | undefined;
    ssrc?: number | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerItem>;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay {
    "100msOrGreaterEventFraction"?: number | null | undefined;
    "250msOrGreaterEventFraction"?: number | null | undefined;
    "500msOrGreaterEventFraction"?: number | null | undefined;
    avg?: number | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss {
    "10OrGreaterEventFraction"?: number | null | undefined;
    "25OrGreaterEventFraction"?: number | null | undefined;
    "5OrGreaterEventFraction"?: number | null | undefined;
    "50OrGreaterEventFraction"?: number | null | undefined;
    avg?: number | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos {
    avg?: number | null | undefined;
    p50?: number | null | undefined;
    p75?: number | null | undefined;
    p90?: number | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulative {
    /** Cumulative latency distribution (milliseconds-based thresholds). */
    jitterBufferDelay?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay | null | undefined;
    /** Cumulative packet loss distribution. */
    packetLoss?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss | null | undefined;
    /** Distribution summary with average and percentiles. */
    qualityMos?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerItem {
    bytesSent?: number | null | undefined;
    jitter?: number | null | undefined;
    mid?: string | null | undefined;
    mosQuality?: number | null | undefined;
    packetsLost?: number | null | undefined;
    packetsSent?: number | null | undefined;
    producerId?: string | null | undefined;
    rtt?: number | null | undefined;
    ssrc?: number | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulativeRtt = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulative {
    /** Cumulative packet loss distribution. */
    packetLoss?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss | null | undefined;
    /** Distribution summary with average and percentiles. */
    qualityMos?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    /** Cumulative latency distribution (milliseconds-based thresholds). */
    rtt?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerCumulativeJitterBufferDelay = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerCumulative = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulative;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerCumulativeRtt = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerCumulative = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulative;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerItem {
    bytesReceived?: number | null | undefined;
    consumerId?: string | null | undefined;
    firCount?: number | null | undefined;
    frameHeight?: number | null | undefined;
    frameWidth?: number | null | undefined;
    framesDecoded?: number | null | undefined;
    framesDropped?: number | null | undefined;
    framesPerSecond?: number | null | undefined;
    jitter?: number | null | undefined;
    jitterBufferDelay?: number | null | undefined;
    jitterBufferEmittedCount?: number | null | undefined;
    keyFramesDecoded?: number | null | undefined;
    mid?: string | null | undefined;
    mosQuality?: number | null | undefined;
    packetsLost?: number | null | undefined;
    packetsReceived?: number | null | undefined;
    peerId?: string | null | undefined;
    producerId?: string | null | undefined;
    ssrc?: number | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeFramePerSecond = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeFrameWidth = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeIssues {
    lagFraction?: number | null | undefined;
    noVideoFraction?: number | null | undefined;
    poorResolutionFraction?: number | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeJitterBufferDelay = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulative {
    /** Distribution summary with average and percentiles. */
    framePerSecond?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    /** Distribution summary with average and percentiles. */
    frameWidth?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    issues?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeIssues | null | undefined;
    /** Cumulative latency distribution (milliseconds-based thresholds). */
    jitterBufferDelay?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay | null | undefined;
    keyFramesDecodedFraction?: number | null | undefined;
    /** Cumulative packet loss distribution. */
    packetLoss?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss | null | undefined;
    /** Distribution summary with average and percentiles. */
    qualityMos?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationDurations {
    bandwidth?: number | null | undefined;
    cpu?: number | null | undefined;
    none?: number | null | undefined;
    other?: number | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationReason = "cpu" | "bandwidth" | "none" | "other";
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItem {
    bytesSent?: number | null | undefined;
    firCount?: number | null | undefined;
    frameHeight?: number | null | undefined;
    frameWidth?: number | null | undefined;
    framesEncoded?: number | null | undefined;
    framesPerSecond?: number | null | undefined;
    jitter?: number | null | undefined;
    keyFramesEncoded?: number | null | undefined;
    mid?: string | null | undefined;
    mosQuality?: number | null | undefined;
    packetsLost?: number | null | undefined;
    packetsSent?: number | null | undefined;
    pliCount?: number | null | undefined;
    producerId?: string | null | undefined;
    qualityLimitationDurations?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationDurations | null | undefined;
    qualityLimitationReason?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationReason | null | undefined;
    qualityLimitationResolutionChanges?: number | null | undefined;
    rtt?: number | null | undefined;
    ssrc?: number | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeFramePerSecond = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeFrameWidth = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeIssues {
    bandwidthQualityLimitationFraction?: number | null | undefined;
    cpuQualityLimitationFraction?: number | null | undefined;
    noVideoFraction?: number | null | undefined;
    poorResolutionFraction?: number | null | undefined;
    qualityLimitationFraction?: number | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeRtt = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulative {
    /** Distribution summary with average and percentiles. */
    framePerSecond?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    /** Distribution summary with average and percentiles. */
    frameWidth?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    highNegativeFeedbackFraction?: number | null | undefined;
    issues?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeIssues | null | undefined;
    keyFramesEncodedFraction?: number | null | undefined;
    /** Cumulative packet loss distribution. */
    packetLoss?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss | null | undefined;
    /** Distribution summary with average and percentiles. */
    qualityMos?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos | null | undefined;
    /** Cumulative latency distribution (milliseconds-based thresholds). */
    rtt?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerItem = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerItem;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativeFramePerSecond = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativeFrameWidth = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativeIssues = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulativeIssues;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativeJitterBufferDelay = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerCumulative = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulative;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerItemQualityLimitationDurations = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationDurations;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerItemQualityLimitationReason = "cpu" | "bandwidth" | "none" | "other";
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerItem {
    bytesSent?: number | null | undefined;
    firCount?: number | null | undefined;
    frameHeight?: number | null | undefined;
    frameWidth?: number | null | undefined;
    framesEncoded?: number | null | undefined;
    framesPerSecond?: number | null | undefined;
    jitter?: number | null | undefined;
    keyFramesEncoded?: number | null | undefined;
    mid?: string | null | undefined;
    mosQuality?: number | null | undefined;
    packetsLost?: number | null | undefined;
    packetsSent?: number | null | undefined;
    pliCount?: number | null | undefined;
    producerId?: string | null | undefined;
    qualityLimitationDurations?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerItemQualityLimitationDurations | null | undefined;
    qualityLimitationReason?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerItemQualityLimitationReason | null | undefined;
    qualityLimitationResolutionChanges?: number | null | undefined;
    rtt?: number | null | undefined;
    ssrc?: number | null | undefined;
    timestamp?: string | null | undefined;
}
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerList = Array<SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerItem>;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativeFramePerSecond = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativeFrameWidth = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativeIssues = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulativeIssues;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativePacketLoss = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativePacketLoss;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativeQualityMos = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeQualityMos;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulativeRtt = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulativeJitterBufferDelay;
export type SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerCumulative = SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulative;
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQuality {
    audioConsumer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerList | null | undefined;
    /** Aggregated inbound (consumer) audio statistics for the session. */
    audioConsumerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulative | null | undefined;
    audioProducer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerList | null | undefined;
    /** Aggregated outbound (producer) audio statistics for the session. */
    audioProducerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulative | null | undefined;
    screenshareAudioConsumer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioConsumerList | null | undefined;
    /** Aggregated inbound (consumer) audio statistics for the session. */
    screenshareAudioConsumerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioConsumerCumulative | null | undefined;
    screenshareAudioProducer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareAudioProducerList | null | undefined;
    /** Aggregated outbound (producer) audio statistics for the session. */
    screenshareAudioProducerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityAudioProducerCumulative | null | undefined;
    screenshareVideoConsumer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerList | null | undefined;
    /** Aggregated inbound (consumer) video statistics for the session. */
    screenshareVideoConsumerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulative | null | undefined;
    screenshareVideoProducer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerList | null | undefined;
    /** Aggregated outbound (producer) video statistics for the session. */
    screenshareVideoProducerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulative | null | undefined;
    videoConsumer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoConsumerList | null | undefined;
    /** Aggregated inbound (consumer) video statistics for the session. */
    videoConsumerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoConsumerCumulative | null | undefined;
    videoProducer?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityVideoProducerList | null | undefined;
    /** Aggregated outbound (producer) video statistics for the session. */
    videoProducerCumulative?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQualityScreenshareVideoProducerCumulative | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReport {
    /** Connection and device metadata for the participant. */
    metadata?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportMetadata | null | undefined;
    /** Media quality statistics for the participant. */
    quality?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReportQuality | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseDataParticipant {
    /** ID of the participant. */
    id?: string | null | undefined;
    /** timestamp when this participant was created. */
    createdAt?: string | null | undefined;
    /** ID passed by client to create this participant. */
    customParticipantId?: string | null | undefined;
    /** Display name of participant when joining the session. */
    displayName?: string | null | undefined;
    /** number of minutes for which the participant was in the session. */
    duration?: number | null | undefined;
    /** timestamp at which participant joined the session. */
    joinedAt?: string | null | undefined;
    /** timestamp at which participant left the session. */
    leftAt?: string | null | undefined;
    /** Connection lifecycle events for the participant's peer. */
    peerEvents?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerEventsList | null | undefined;
    /** Peer call statistics report. */
    peerReport?: SessionsGetParticipantDataFromPeerIdResponseDataParticipantPeerReport | null | undefined;
    /** Name of the preset associated with the participant. */
    role?: string | null | undefined;
    sessionId?: string | null | undefined;
    /** timestamp when this participant's data was last updated. */
    updatedAt?: string | null | undefined;
    /** User id for this participant. */
    userId?: string | null | undefined;
}
export interface SessionsGetParticipantDataFromPeerIdResponseData {
    participant?: SessionsGetParticipantDataFromPeerIdResponseDataParticipant | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetParticipantDataFromPeerIdSessionResponse {
    data?: SessionsGetParticipantDataFromPeerIdResponseData | null | undefined;
}
export interface GetPresetRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page */
    perPage?: number | undefined;
    /** Search presets by name. */
    search?: string | undefined;
}
export interface PresetsGetResponseDataItem {
    /** ID of the preset */
    id?: string | null | undefined;
    /** Timestamp this preset was created at */
    createdAt?: string | null | undefined;
    /** Name of the preset */
    name?: string | null | undefined;
    /** Timestamp this preset was last updated */
    updatedAt?: string | null | undefined;
}
export type PresetsGetResponseDataList = Array<PresetsGetResponseDataItem>;
export type PresetsGetResponsePaging = LivestreamsGetAllLivestreamsResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetPresetResponse {
    data: PresetsGetResponseDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export interface GetPresetByIdPresetRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    presetId: string;
}
export type PresetsGetPresetByIdResponseDataConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type PresetsGetPresetByIdResponseDataConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsGetPresetByIdResponseDataConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: PresetsGetPresetByIdResponseDataConfigMediaScreenshareQuality;
}
export type PresetsGetPresetByIdResponseDataConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsGetPresetByIdResponseDataConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: PresetsGetPresetByIdResponseDataConfigMediaVideoQuality;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | null | undefined;
}
export type PresetsGetPresetByIdResponseDataConfigMediaAudio = PresetsCreateResponseDataConfigMediaAudio;
export interface PresetsGetPresetByIdResponseDataConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: PresetsGetPresetByIdResponseDataConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: PresetsGetPresetByIdResponseDataConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateResponseDataConfigMediaAudio | null | undefined;
}
export type PresetsGetPresetByIdResponseDataConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type PresetsGetPresetByIdResponseDataConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsGetPresetByIdResponseDataConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: PresetsGetPresetByIdResponseDataConfigMedia;
    /** Type of the meeting */
    viewType: PresetsGetPresetByIdResponseDataConfigViewType;
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsGetPresetByIdResponseDataConfigLivestreamViewerQualitiesList | null | undefined;
}
export type PresetsGetPresetByIdResponseDataPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type PresetsGetPresetByIdResponseDataPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type PresetsGetPresetByIdResponseDataPermissionsChat = PresetsCreateRequestPermissionsChat;
export type PresetsGetPresetByIdResponseDataPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type PresetsGetPresetByIdResponseDataPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsGetPresetByIdResponseDataPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: PresetsGetPresetByIdResponseDataPermissionsMediaAudioCanProduce;
}
export type PresetsGetPresetByIdResponseDataPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsGetPresetByIdResponseDataPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: PresetsGetPresetByIdResponseDataPermissionsMediaScreenshareCanProduce;
}
export type PresetsGetPresetByIdResponseDataPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsGetPresetByIdResponseDataPermissionsMediaVideo {
    /** Can produce video */
    canProduce: PresetsGetPresetByIdResponseDataPermissionsMediaVideoCanProduce;
}
export interface PresetsGetPresetByIdResponseDataPermissionsMedia {
    /** Audio permissions */
    audio: PresetsGetPresetByIdResponseDataPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: PresetsGetPresetByIdResponseDataPermissionsMediaScreenshare;
    /** Video permissions */
    video: PresetsGetPresetByIdResponseDataPermissionsMediaVideo;
}
export type PresetsGetPresetByIdResponseDataPermissionsPlugins = PresetsCreateRequestPermissionsPlugins;
export type PresetsGetPresetByIdResponseDataPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type PresetsGetPresetByIdResponseDataPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsGetPresetByIdResponseDataPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type PresetsGetPresetByIdResponseDataPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsGetPresetByIdResponseDataPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: PresetsGetPresetByIdResponseDataPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: PresetsCreateRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: PresetsGetPresetByIdResponseDataPermissionsRecorderType;
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: PresetsGetPresetByIdResponseDataPermissionsWaitingRoomType;
    acceptStageRequests?: boolean | null | undefined;
    isRecorder?: boolean | null | undefined;
    stageAccess?: PresetsGetPresetByIdResponseDataPermissionsStageAccess | null | undefined;
    stageEnabled?: boolean | null | undefined;
    transcriptionEnabled?: boolean | null | undefined;
}
export type PresetsGetPresetByIdResponseDataUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsGetPresetByIdResponseDataUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type PresetsGetPresetByIdResponseDataUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type PresetsGetPresetByIdResponseDataUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type PresetsGetPresetByIdResponseDataUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type PresetsGetPresetByIdResponseDataUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsGetPresetByIdResponseDataUiDesignTokens {
    borderRadius: PresetsGetPresetByIdResponseDataUiDesignTokensBorderRadius;
    borderWidth: PresetsGetPresetByIdResponseDataUiDesignTokensBorderWidth;
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: PresetsGetPresetByIdResponseDataUiDesignTokensTheme;
    fontFamily?: string | null | undefined;
    googleFont?: string | null | undefined;
    logo?: string | null | undefined;
}
export interface PresetsGetPresetByIdResponseDataUi {
    designTokens: PresetsGetPresetByIdResponseDataUiDesignTokens;
    /** Difference between the preset's UI config and the defaults. */
    configDiff?: unknown | null | undefined;
}
export interface PresetsGetPresetByIdResponseData {
    /** ID of the preset */
    id: string;
    config: PresetsGetPresetByIdResponseDataConfig;
    /** Timestamp this preset was created at */
    createdAt: string;
    /** Name of the preset */
    name: string;
    permissions: PresetsGetPresetByIdResponseDataPermissions;
    ui: PresetsGetPresetByIdResponseDataUi;
    /** Timestamp this preset was last updated */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetPresetByIdPresetResponse {
    /** Data returned by the operation */
    data: PresetsGetPresetByIdResponseData;
}
export type RecordingsGetRecordingsRequestSortBy = "invokedTime";
export type RecordingsGetRecordingsRequestSortOrder = "ASC" | "DESC";
export type RecordingsGetRecordingsRequestStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export type RecordingsGetRecordingsRequestStatusList = Array<RecordingsGetRecordingsRequestStatus | (string & {})>;
export interface GetRecordingsRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** The end time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    endTime?: string | undefined;
    /** If passed, only shows expired/non-expired recordings on RealtimeKit's bucket */
    expired?: boolean | undefined;
    /** ID of a meeting. Optional. Will limit results to only this meeting if passed. */
    meetingId?: string | undefined;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page */
    perPage?: number | undefined;
    /** The search query string. You can search using the meeting ID or title. */
    search?: string | undefined;
    sortBy?: RecordingsGetRecordingsRequestSortBy | (string & {}) | undefined;
    sortOrder?: RecordingsGetRecordingsRequestSortOrder | (string & {}) | undefined;
    /** The start time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    startTime?: string | undefined;
    /** Filter by one or more recording status */
    status?: RecordingsGetRecordingsRequestStatusList | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigLiveStreamingConfig = MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig;
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0Type = "gcs";
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfig = RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase0 | RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase1 | RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase2 | RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfigCase3;
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigWatermarkSize = MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize;
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface RecordingsGetRecordingsResponseDataItemMeetingRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigStorageConfig | null | undefined;
    videoConfig?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfigVideoConfig | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemMeetingStatus = "ACTIVE" | "INACTIVE";
export interface RecordingsGetRecordingsResponseDataItemMeeting {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: RecordingsGetRecordingsResponseDataItemMeetingRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: RecordingsGetRecordingsResponseDataItemMeetingStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase0Type = "gcs";
export interface RecordingsGetRecordingsResponseDataItemStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetRecordingsResponseDataItemStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetRecordingsResponseDataItemStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsGetRecordingsResponseDataItemStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsGetRecordingsResponseDataItemStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsGetRecordingsResponseDataItemStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase2AuthMethod = "KEY";
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetRecordingsResponseDataItemStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetRecordingsResponseDataItemStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetRecordingsResponseDataItemStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsGetRecordingsResponseDataItemStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsGetRecordingsResponseDataItemStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsGetRecordingsResponseDataItemStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsGetRecordingsResponseDataItemStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsGetRecordingsResponseDataItemStorageConfig = RecordingsGetRecordingsResponseDataItemStorageConfigCase0 | RecordingsGetRecordingsResponseDataItemStorageConfigCase1 | RecordingsGetRecordingsResponseDataItemStorageConfigCase2 | RecordingsGetRecordingsResponseDataItemStorageConfigCase3;
export interface RecordingsGetRecordingsResponseDataItem {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsGetRecordingsResponseDataItemStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    meeting?: RecordingsGetRecordingsResponseDataItemMeeting | null | undefined;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
    storageConfig?: RecordingsGetRecordingsResponseDataItemStorageConfig | null | undefined;
}
export type RecordingsGetRecordingsResponseDataList = Array<RecordingsGetRecordingsResponseDataItem>;
export type RecordingsGetRecordingsResponsePaging = LivestreamsGetAllLivestreamsResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetRecordingsRecordingResponse {
    data: RecordingsGetRecordingsResponseDataList;
    paging: LivestreamsGetAllLivestreamsResponsePaging;
}
export interface GetSessionChatSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
}
export interface SessionsGetSessionChatResponseData {
    /** URL where the chat logs can be downloaded */
    chatDownloadUrl: string;
    /** Time when the download URL will expire */
    chatDownloadUrlExpiry: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionChatSessionResponse {
    data?: SessionsGetSessionChatResponseData | null | undefined;
}
export interface GetSessionDetailsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
    /** List all breakout rooms */
    includeBreakoutRooms?: boolean | undefined;
}
export type SessionsGetSessionDetailsResponseDataStatus = "LIVE" | "ENDED";
export type SessionsGetSessionDetailsResponseDataType = "meeting" | "livestream" | "participant";
export type SessionsGetSessionDetailsResponseDataBreakoutRoomsList = Array<unknown>;
export interface SessionsGetSessionDetailsResponseData {
    /** ID of the session */
    id: string;
    /** ID of the meeting this session is associated with. In the case of V2 meetings, it is always a UUID. In V1 meetings, it is a room name of the form `abcdef-ghijkl` */
    associatedId: string;
    /** timestamp when session created */
    createdAt: string;
    /** number of participants currently in the session */
    liveParticipants: number;
    /** number of maximum participants that were in the session */
    maxConcurrentParticipants: number;
    /** Title of the meeting this session belongs to */
    meetingDisplayName: string;
    /** number of minutes consumed since the session started */
    minutesConsumed: number;
    /** App id that hosted this session */
    organizationId: string;
    /** timestamp when session started */
    startedAt: string;
    /** current status of session */
    status: SessionsGetSessionDetailsResponseDataStatus;
    /** type of session */
    type: SessionsGetSessionDetailsResponseDataType;
    /** timestamp when session was last updated */
    updatedAt: string;
    breakoutRooms?: SessionsGetSessionDetailsResponseDataBreakoutRoomsList | null | undefined;
    /** timestamp when session ended */
    endedAt?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionDetailsSessionResponse {
    data?: SessionsGetSessionDetailsResponseData | null | undefined;
}
export interface GetSessionParticipantDetailsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
    participantId: string;
    /** if true, response includes all the peer events of participant. */
    includePeerEvents?: boolean | undefined;
}
export type SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItemEventName = "PEER_CREATED" | "PEER_JOINING" | "PEER_LEAVING";
export type SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItemPresetViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM" | "CHAT";
export interface SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItem {
    /** ID of the peer event. */
    id?: string | null | undefined;
    /** Timestamp when this peer event was created. */
    createdAt?: string | null | undefined;
    /** Name of the peer event. */
    eventName?: SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItemEventName | null | undefined;
    /** Minutes consumed attributed to this event. */
    minutesConsumed?: number | null | undefined;
    /** ID of the participant this event belongs to. */
    participantId?: string | null | undefined;
    /** Peer ID this event belongs to. */
    peerId?: string | null | undefined;
    /** View type of the preset associated with the peer. */
    presetViewType?: SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItemPresetViewType | null | undefined;
    /** ID of the session this event belongs to. */
    sessionId?: string | null | undefined;
    /** ID of the socket session associated with this event. */
    socketSessionId?: string | null | undefined;
    /** Timestamp when this peer event was last updated. */
    updatedAt?: string | null | undefined;
}
export type SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsList = Array<SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsItem>;
export interface SessionsGetSessionParticipantDetailsResponseDataParticipant {
    /** Participant ID. This maps to the corresponding peerId. */
    id?: string | null | undefined;
    /** timestamp when this participant was created. */
    createdAt?: string | null | undefined;
    /** ID passed by client to create this participant. */
    customParticipantId?: string | null | undefined;
    /** Display name of participant when joining the session. */
    displayName?: string | null | undefined;
    /** number of minutes for which the participant was in the session. */
    duration?: number | null | undefined;
    /** timestamp at which participant joined the session. */
    joinedAt?: string | null | undefined;
    /** timestamp at which participant left the session. */
    leftAt?: string | null | undefined;
    /** Connection lifecycle events for the participant's peer. Only included when `include_peer_events` is true. */
    peerEvents?: SessionsGetSessionParticipantDetailsResponseDataParticipantPeerEventsList | null | undefined;
    /** Name of the preset associated with the participant. */
    presetName?: string | null | undefined;
    /** timestamp when this participant's data was last updated. */
    updatedAt?: string | null | undefined;
    /** User id for this participant. */
    userId?: string | null | undefined;
}
export interface SessionsGetSessionParticipantDetailsResponseData {
    participant?: SessionsGetSessionParticipantDetailsResponseDataParticipant | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionParticipantDetailsSessionResponse {
    data?: SessionsGetSessionParticipantDetailsResponseData | null | undefined;
}
export type SessionsGetSessionParticipantsRequestSortBy = "joinedAt" | "duration";
export type SessionsGetSessionParticipantsRequestSortOrder = "ASC" | "DESC";
export type SessionsGetSessionParticipantsRequestView = "raw" | "consolidated";
export interface GetSessionParticipantsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
    /** if true, response includes all the peer events of participants. */
    includePeerEvents?: boolean | undefined;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    /** Number of results per page. */
    perPage?: number | undefined;
    /** The search query string. You can search using participant ID, custom participant ID, or display name. */
    search?: string | undefined;
    sortBy?: SessionsGetSessionParticipantsRequestSortBy | (string & {}) | undefined;
    sortOrder?: SessionsGetSessionParticipantsRequestSortOrder | (string & {}) | undefined;
    /** In breakout room sessions, the view parameter can be set to `raw` for session specific duration for participants or `consolidated` to accumulate breakout room durations. */
    view?: SessionsGetSessionParticipantsRequestView | (string & {}) | undefined;
}
export type SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItemEventName = "PEER_CREATED" | "PEER_JOINING" | "PEER_LEAVING";
export type SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItemPresetViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM" | "CHAT";
export interface SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItem {
    /** ID of the peer event. */
    id?: string | null | undefined;
    /** Timestamp when this peer event was created. */
    createdAt?: string | null | undefined;
    /** Name of the peer event. */
    eventName?: SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItemEventName | null | undefined;
    /** Minutes consumed attributed to this event. */
    minutesConsumed?: number | null | undefined;
    /** ID of the participant this event belongs to. */
    participantId?: string | null | undefined;
    /** Peer ID this event belongs to. */
    peerId?: string | null | undefined;
    /** View type of the preset associated with the peer. */
    presetViewType?: SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItemPresetViewType | null | undefined;
    /** ID of the session this event belongs to. */
    sessionId?: string | null | undefined;
    /** ID of the socket session associated with this event. */
    socketSessionId?: string | null | undefined;
    /** Timestamp when this peer event was last updated. */
    updatedAt?: string | null | undefined;
}
export type SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsList = Array<SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsItem>;
export interface SessionsGetSessionParticipantsResponseDataParticipantsItem {
    /** Participant ID. This maps to the corresponding peerId. */
    id?: string | null | undefined;
    /** timestamp when this participant was created. */
    createdAt?: string | null | undefined;
    /** ID passed by client to create this participant. */
    customParticipantId?: string | null | undefined;
    /** Display name of participant when joining the session. */
    displayName?: string | null | undefined;
    /** number of minutes for which the participant was in the session. */
    duration?: number | null | undefined;
    /** timestamp at which participant joined the session. */
    joinedAt?: string | null | undefined;
    /** timestamp at which participant left the session. */
    leftAt?: string | null | undefined;
    /** Connection lifecycle events for the participant's peer. Only included when `include_peer_events` is true. */
    peerEvents?: SessionsGetSessionParticipantsResponseDataParticipantsItemPeerEventsList | null | undefined;
    /** Name of the preset associated with the participant. */
    presetName?: string | null | undefined;
    /** timestamp when this participant's data was last updated. */
    updatedAt?: string | null | undefined;
    /** User id for this participant. */
    userId?: string | null | undefined;
}
export type SessionsGetSessionParticipantsResponseDataParticipantsList = Array<SessionsGetSessionParticipantsResponseDataParticipantsItem>;
export interface SessionsGetSessionParticipantsResponseData {
    participants?: SessionsGetSessionParticipantsResponseDataParticipantsList | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionParticipantsSessionResponse {
    data?: SessionsGetSessionParticipantsResponseData | null | undefined;
}
export type SessionsGetSessionsRequestSortBy = "minutesConsumed" | "createdAt";
export type SessionsGetSessionsRequestSortOrder = "ASC" | "DESC";
export type SessionsGetSessionsRequestStatus = "LIVE" | "ENDED";
export interface GetSessionsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** ID of the meeting that sessions should be associated with */
    associatedId?: string | undefined;
    /** The end time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    endTime?: string | undefined;
    /** The page number from which you want your page search results to be displayed. */
    pageNo?: number | undefined;
    participants?: string | undefined;
    /** Number of results per page */
    perPage?: number | undefined;
    /** Search string that matches sessions based on meeting title, meeting ID, and session ID */
    search?: string | undefined;
    sortBy?: SessionsGetSessionsRequestSortBy | (string & {}) | undefined;
    sortOrder?: SessionsGetSessionsRequestSortOrder | (string & {}) | undefined;
    /** The start time range for which you want to retrieve the meetings. The time must be specified in ISO format. */
    startTime?: string | undefined;
    status?: SessionsGetSessionsRequestStatus | (string & {}) | undefined;
}
export type SessionsGetSessionsResponseDataSessionsItemStatus = "LIVE" | "ENDED";
export type SessionsGetSessionsResponseDataSessionsItemType = "meeting" | "livestream" | "participant";
export type SessionsGetSessionsResponseDataSessionsItemBreakoutRoomsList = Array<unknown>;
export interface SessionsGetSessionsResponseDataSessionsItem {
    /** ID of the session */
    id: string;
    /** ID of the meeting this session is associated with. In the case of V2 meetings, it is always a UUID. In V1 meetings, it is a room name of the form `abcdef-ghijkl` */
    associatedId: string;
    /** timestamp when session created */
    createdAt: string;
    /** number of participants currently in the session */
    liveParticipants: number;
    /** number of maximum participants that were in the session */
    maxConcurrentParticipants: number;
    /** Title of the meeting this session belongs to */
    meetingDisplayName: string;
    /** number of minutes consumed since the session started */
    minutesConsumed: number;
    /** App id that hosted this session */
    organizationId: string;
    /** timestamp when session started */
    startedAt: string;
    /** current status of session */
    status: SessionsGetSessionsResponseDataSessionsItemStatus;
    /** type of session */
    type: SessionsGetSessionsResponseDataSessionsItemType;
    /** timestamp when session was last updated */
    updatedAt: string;
    breakoutRooms?: SessionsGetSessionsResponseDataSessionsItemBreakoutRoomsList | null | undefined;
    /** timestamp when session ended */
    endedAt?: string | null | undefined;
}
export type SessionsGetSessionsResponseDataSessionsList = Array<SessionsGetSessionsResponseDataSessionsItem>;
export interface SessionsGetSessionsResponseData {
    sessions?: SessionsGetSessionsResponseDataSessionsList | null | undefined;
}
export type SessionsGetSessionsResponsePaging = AppsGetResponsePaging;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionsSessionResponse {
    data?: SessionsGetSessionsResponseData | null | undefined;
    paging?: AppsGetResponsePaging | null | undefined;
}
export interface GetSessionSummarySessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
}
export interface SessionsGetSessionSummaryResponseData {
    sessionId: string;
    /** URL where the summary of transcripts can be downloaded */
    summaryDownloadUrl: string;
    /** Time of Expiry before when you need to download the csv file. */
    summaryDownloadUrlExpiry: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionSummarySessionResponse {
    data?: SessionsGetSessionSummaryResponseData | null | undefined;
}
export type SessionsGetSessionTranscriptsRequestFormat = "SRT" | "VTT" | "JSON" | "CSV";
export interface GetSessionTranscriptsSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    sessionId: string;
    /** Transcript file format to fetch. */
    format?: SessionsGetSessionTranscriptsRequestFormat | (string & {}) | undefined;
}
export interface SessionsGetSessionTranscriptsResponseData {
    sessionId: string;
    /** URL where the transcript can be downloaded */
    transcriptDownloadUrl: string;
    /** Time when the download URL will expire */
    transcriptDownloadUrlExpiry: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSessionTranscriptsSessionResponse {
    data?: SessionsGetSessionTranscriptsResponseData | null | undefined;
}
export interface GetWebhookByIdWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    webhookId: string;
}
export type WebhooksGetWebhookByIdResponseDataEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksGetWebhookByIdResponseDataEventsList = Array<WebhooksGetWebhookByIdResponseDataEventsItem>;
export interface WebhooksGetWebhookByIdResponseData {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksGetWebhookByIdResponseDataEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetWebhookByIdWebhookResponse {
    data: WebhooksGetWebhookByIdResponseData;
}
export interface GetWebhooksWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
}
export type WebhooksGetWebhooksResponseDataItemEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksGetWebhooksResponseDataItemEventsList = Array<WebhooksGetWebhooksResponseDataItemEventsItem>;
export interface WebhooksGetWebhooksResponseDataItem {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksGetWebhooksResponseDataItemEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
export type WebhooksGetWebhooksResponseDataList = Array<WebhooksGetWebhooksResponseDataItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetWebhooksWebhookResponse {
    data: WebhooksGetWebhooksResponseDataList;
}
export interface KickAllParticipantsActiveSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
}
export interface ActiveSessionKickAllParticipantsResponseData {
    action?: string | null | undefined;
    kickedParticipantsCount?: number | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface KickAllParticipantsActiveSessionResponse {
    data?: ActiveSessionKickAllParticipantsResponseData | null | undefined;
}
export type ActiveSessionKickParticipantsRequestCustomParticipantIdsList = Array<string>;
export type ActiveSessionKickParticipantsRequestParticipantIdsList = Array<string>;
export interface KickParticipantsActiveSessionRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    customParticipantIds?: ActiveSessionKickParticipantsRequestCustomParticipantIdsList | undefined;
    participantIds?: ActiveSessionKickParticipantsRequestParticipantIdsList | undefined;
}
export type ActiveSessionKickParticipantsResponseDataParticipantsItem = ActiveSessionMuteParticipantsResponseDataParticipantsItem;
export type ActiveSessionKickParticipantsResponseDataParticipantsList = Array<ActiveSessionMuteParticipantsResponseDataParticipantsItem>;
export interface ActiveSessionKickParticipantsResponseData {
    action?: string | null | undefined;
    participants?: ActiveSessionKickParticipantsResponseDataParticipantsList | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface KickParticipantsActiveSessionResponse {
    data?: ActiveSessionKickParticipantsResponseData | null | undefined;
}
export interface LivestreamsGetOrgAnalyticsRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** end date in YYYY-MM-DD format */
    endDate?: string | undefined;
    /** start date in YYYY-MM-DD format */
    startDate?: string | undefined;
}
export type LivestreamsGetOrgAnalyticsResponseDataRecordingStatsDayStatsItem = AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsItem;
export type LivestreamsGetOrgAnalyticsResponseDataRecordingStatsDayStatsList = Array<AnalyticsGetOrgAnalyticsResponseDataRecordingStatsDayStatsItem>;
export interface LivestreamsGetOrgAnalyticsResponseDataRecordingStats {
    /** Day wise recording stats */
    dayStats?: LivestreamsGetOrgAnalyticsResponseDataRecordingStatsDayStatsList | null | undefined;
    /** Total number of recordings during the range specified */
    recordingCount?: number | null | undefined;
    /** Total recording minutes during the range specified */
    recordingMinutesConsumed?: number | null | undefined;
}
export type LivestreamsGetOrgAnalyticsResponseDataSessionStatsDayStatsItem = AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsItem;
export type LivestreamsGetOrgAnalyticsResponseDataSessionStatsDayStatsList = Array<AnalyticsGetOrgAnalyticsResponseDataSessionStatsDayStatsItem>;
export interface LivestreamsGetOrgAnalyticsResponseDataSessionStats {
    /** Day wise session stats */
    dayStats?: LivestreamsGetOrgAnalyticsResponseDataSessionStatsDayStatsList | null | undefined;
    /** Total number of sessions during the range specified */
    sessionsCount?: number | null | undefined;
    /** Total session minutes during the range specified */
    sessionsMinutesConsumed?: number | null | undefined;
}
export interface LivestreamsGetOrgAnalyticsResponseData {
    /** Recording statistics of an App during the range specified */
    recordingStats?: LivestreamsGetOrgAnalyticsResponseDataRecordingStats | null | undefined;
    /** Session statistics of an App during the range specified */
    sessionStats?: LivestreamsGetOrgAnalyticsResponseDataSessionStats | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface LivestreamsGetOrgAnalyticsResponse {
    data?: LivestreamsGetOrgAnalyticsResponseData | null | undefined;
}
export interface MeetingsReplaceParticipantRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
    /** Unique participant ID accepted by the replace participant API. */
    customParticipantId: string;
    /** Name of the preset to apply to this participant. */
    presetName: string;
    /** (Optional) Name of the participant. */
    name?: string | undefined;
    /** (Optional) A URL to a picture to be used for the participant. */
    picture?: string | undefined;
}
export type MeetingsReplaceParticipantResponseData = MeetingsAddParticipantResponseData;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface MeetingsReplaceParticipantResponse {
    /** Represents a participant. */
    data?: MeetingsAddParticipantResponseData | null | undefined;
}
export interface MeetingsRevokeParticipantTokenRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
}
export interface MeetingsRevokeParticipantTokenResponseData {
    /** The revoked participant authentication token. */
    token: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface MeetingsRevokeParticipantTokenResponse {
    /** Data returned by the operation */
    data: MeetingsRevokeParticipantTokenResponseData;
}
export type PresetsUpdateRequestConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsUpdateRequestConfigMaxVideoStreams {
    /** Maximum number of video streams visible on desktop devices */
    desktop?: number | undefined;
    /** Maximum number of streams visible on mobile devices */
    mobile?: number | undefined;
}
export type PresetsUpdateRequestConfigMediaAudio = PresetsCreateRequestConfigMediaAudio;
export type PresetsUpdateRequestConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsUpdateRequestConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate?: number | undefined;
    /** Quality of screen share */
    quality?: PresetsUpdateRequestConfigMediaScreenshareQuality | (string & {}) | undefined;
}
export type PresetsUpdateRequestConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsUpdateRequestConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate?: number | undefined;
    /** Video quality of participants */
    quality?: PresetsUpdateRequestConfigMediaVideoQuality | (string & {}) | undefined;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | undefined;
}
export interface PresetsUpdateRequestConfigMedia {
    /** Control options for Audio quality. */
    audio?: PresetsCreateRequestConfigMediaAudio | undefined;
    /** Configuration options for participant screen shares */
    screenshare?: PresetsUpdateRequestConfigMediaScreenshare | undefined;
    /** Configuration options for participant videos */
    video?: PresetsUpdateRequestConfigMediaVideo | undefined;
}
export type PresetsUpdateRequestConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export interface PresetsUpdateRequestConfig {
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsUpdateRequestConfigLivestreamViewerQualitiesList | undefined;
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount?: number | undefined;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams?: PresetsUpdateRequestConfigMaxVideoStreams | undefined;
    /** Media configuration options. eg: Video quality */
    media?: PresetsUpdateRequestConfigMedia | undefined;
    /** Type of the meeting */
    viewType?: PresetsUpdateRequestConfigViewType | (string & {}) | undefined;
}
export interface PresetsUpdateRequestPermissionsChatPrivate {
    canReceive?: boolean | undefined;
    canSend?: boolean | undefined;
    files?: boolean | undefined;
    text?: boolean | undefined;
}
export interface PresetsUpdateRequestPermissionsChatPublic {
    /** Can send messages in general */
    canSend?: boolean | undefined;
    /** Can send file messages */
    files?: boolean | undefined;
    /** Can send text messages */
    text?: boolean | undefined;
}
export interface PresetsUpdateRequestPermissionsChat {
    private?: PresetsUpdateRequestPermissionsChatPrivate | undefined;
    public?: PresetsUpdateRequestPermissionsChatPublic | undefined;
}
export interface PresetsUpdateRequestPermissionsConnectedMeetings {
    canAlterConnectedMeetings?: boolean | undefined;
    canSwitchConnectedMeetings?: boolean | undefined;
    canSwitchToParentMeeting?: boolean | undefined;
}
export type PresetsUpdateRequestPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateRequestPermissionsMediaAudio {
    /** Can produce audio */
    canProduce?: PresetsUpdateRequestPermissionsMediaAudioCanProduce | (string & {}) | undefined;
}
export type PresetsUpdateRequestPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateRequestPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce?: PresetsUpdateRequestPermissionsMediaScreenshareCanProduce | (string & {}) | undefined;
}
export type PresetsUpdateRequestPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateRequestPermissionsMediaVideo {
    /** Can produce video */
    canProduce?: PresetsUpdateRequestPermissionsMediaVideoCanProduce | (string & {}) | undefined;
}
export interface PresetsUpdateRequestPermissionsMedia {
    /** Audio permissions */
    audio?: PresetsUpdateRequestPermissionsMediaAudio | undefined;
    /** Screenshare permissions */
    screenshare?: PresetsUpdateRequestPermissionsMediaScreenshare | undefined;
    /** Video permissions */
    video?: PresetsUpdateRequestPermissionsMediaVideo | undefined;
}
export interface PresetsUpdateRequestPermissionsPlugins {
    /** Can close plugins that are already open */
    canClose?: boolean | undefined;
    /** Can edit plugin config */
    canEditConfig?: boolean | undefined;
    /** Can start plugins */
    canStart?: boolean | undefined;
    /** Plugin configuration keyed by plugin UUID. */
    config?: unknown | undefined;
}
export interface PresetsUpdateRequestPermissionsPolls {
    /** Can create polls */
    canCreate?: boolean | undefined;
    /** Can view polls */
    canView?: boolean | undefined;
    /** Can vote on polls */
    canVote?: boolean | undefined;
}
export type PresetsUpdateRequestPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsUpdateRequestPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export type PresetsUpdateRequestPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export interface PresetsUpdateRequestPermissions {
    acceptStageRequests?: boolean | undefined;
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests?: boolean | undefined;
    canAcceptProductionRequests?: boolean | undefined;
    canChangeParticipantPermissions?: boolean | undefined;
    canEditDisplayName?: boolean | undefined;
    canLivestream?: boolean | undefined;
    canRecord?: boolean | undefined;
    canSpotlight?: boolean | undefined;
    chat?: PresetsUpdateRequestPermissionsChat | undefined;
    connectedMeetings?: PresetsUpdateRequestPermissionsConnectedMeetings | undefined;
    disableParticipantAudio?: boolean | undefined;
    disableParticipantScreensharing?: boolean | undefined;
    disableParticipantVideo?: boolean | undefined;
    /** Whether this participant is visible to others or not */
    hiddenParticipant?: boolean | undefined;
    isRecorder?: boolean | undefined;
    kickParticipant?: boolean | undefined;
    /** Media permissions */
    media?: PresetsUpdateRequestPermissionsMedia | undefined;
    pinParticipant?: boolean | undefined;
    /** Plugin permissions */
    plugins?: PresetsUpdateRequestPermissionsPlugins | undefined;
    /** Poll permissions */
    polls?: PresetsUpdateRequestPermissionsPolls | undefined;
    /** Type of the recording peer */
    recorderType?: PresetsUpdateRequestPermissionsRecorderType | (string & {}) | undefined;
    showParticipantList?: boolean | undefined;
    stageAccess?: PresetsUpdateRequestPermissionsStageAccess | (string & {}) | undefined;
    stageEnabled?: boolean | undefined;
    transcriptionEnabled?: boolean | undefined;
    /** Waiting room type */
    waitingRoomType?: PresetsUpdateRequestPermissionsWaitingRoomType | (string & {}) | undefined;
}
export type PresetsUpdateRequestUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsUpdateRequestUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export interface PresetsUpdateRequestUiDesignTokensColorsBackground {
    "1000"?: string | undefined;
    "600"?: string | undefined;
    "700"?: string | undefined;
    "800"?: string | undefined;
    "900"?: string | undefined;
}
export interface PresetsUpdateRequestUiDesignTokensColorsBrand {
    "300"?: string | undefined;
    "400"?: string | undefined;
    "500"?: string | undefined;
    "600"?: string | undefined;
    "700"?: string | undefined;
}
export interface PresetsUpdateRequestUiDesignTokensColors {
    background?: PresetsUpdateRequestUiDesignTokensColorsBackground | undefined;
    brand?: PresetsUpdateRequestUiDesignTokensColorsBrand | undefined;
    danger?: string | undefined;
    success?: string | undefined;
    text?: string | undefined;
    textOnBrand?: string | undefined;
    videoBg?: string | undefined;
    warning?: string | undefined;
}
export type PresetsUpdateRequestUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsUpdateRequestUiDesignTokens {
    borderRadius?: PresetsUpdateRequestUiDesignTokensBorderRadius | (string & {}) | undefined;
    borderWidth?: PresetsUpdateRequestUiDesignTokensBorderWidth | (string & {}) | undefined;
    colors?: PresetsUpdateRequestUiDesignTokensColors | undefined;
    fontFamily?: string | undefined;
    googleFont?: string | undefined;
    logo?: string | undefined;
    spacingBase?: number | undefined;
    theme?: PresetsUpdateRequestUiDesignTokensTheme | (string & {}) | undefined;
}
export interface PresetsUpdateRequestUi {
    designTokens?: PresetsUpdateRequestUiDesignTokens | undefined;
}
export interface PatchPresetRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    presetId: string;
    config?: PresetsUpdateRequestConfig | undefined;
    /** Name of the preset */
    name?: string | undefined;
    permissions?: PresetsUpdateRequestPermissions | undefined;
    ui?: PresetsUpdateRequestUi | undefined;
}
export type PresetsUpdateResponseDataConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type PresetsUpdateResponseDataConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsUpdateResponseDataConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: PresetsUpdateResponseDataConfigMediaScreenshareQuality;
}
export type PresetsUpdateResponseDataConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface PresetsUpdateResponseDataConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: PresetsUpdateResponseDataConfigMediaVideoQuality;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | null | undefined;
}
export type PresetsUpdateResponseDataConfigMediaAudio = PresetsCreateResponseDataConfigMediaAudio;
export interface PresetsUpdateResponseDataConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: PresetsUpdateResponseDataConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: PresetsUpdateResponseDataConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateResponseDataConfigMediaAudio | null | undefined;
}
export type PresetsUpdateResponseDataConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type PresetsUpdateResponseDataConfigLivestreamViewerQualitiesList = Array<number>;
export interface PresetsUpdateResponseDataConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: PresetsUpdateResponseDataConfigMedia;
    /** Type of the meeting */
    viewType: PresetsUpdateResponseDataConfigViewType;
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: PresetsUpdateResponseDataConfigLivestreamViewerQualitiesList | null | undefined;
}
export type PresetsUpdateResponseDataPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type PresetsUpdateResponseDataPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type PresetsUpdateResponseDataPermissionsChat = PresetsCreateRequestPermissionsChat;
export type PresetsUpdateResponseDataPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type PresetsUpdateResponseDataPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateResponseDataPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: PresetsUpdateResponseDataPermissionsMediaAudioCanProduce;
}
export type PresetsUpdateResponseDataPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateResponseDataPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: PresetsUpdateResponseDataPermissionsMediaScreenshareCanProduce;
}
export type PresetsUpdateResponseDataPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateResponseDataPermissionsMediaVideo {
    /** Can produce video */
    canProduce: PresetsUpdateResponseDataPermissionsMediaVideoCanProduce;
}
export interface PresetsUpdateResponseDataPermissionsMedia {
    /** Audio permissions */
    audio: PresetsUpdateResponseDataPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: PresetsUpdateResponseDataPermissionsMediaScreenshare;
    /** Video permissions */
    video: PresetsUpdateResponseDataPermissionsMediaVideo;
}
export type PresetsUpdateResponseDataPermissionsPlugins = PresetsCreateRequestPermissionsPlugins;
export type PresetsUpdateResponseDataPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type PresetsUpdateResponseDataPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type PresetsUpdateResponseDataPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type PresetsUpdateResponseDataPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface PresetsUpdateResponseDataPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: PresetsUpdateResponseDataPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: PresetsCreateRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: PresetsUpdateResponseDataPermissionsRecorderType;
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: PresetsUpdateResponseDataPermissionsWaitingRoomType;
    acceptStageRequests?: boolean | null | undefined;
    isRecorder?: boolean | null | undefined;
    stageAccess?: PresetsUpdateResponseDataPermissionsStageAccess | null | undefined;
    stageEnabled?: boolean | null | undefined;
    transcriptionEnabled?: boolean | null | undefined;
}
export type PresetsUpdateResponseDataUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type PresetsUpdateResponseDataUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type PresetsUpdateResponseDataUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type PresetsUpdateResponseDataUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type PresetsUpdateResponseDataUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type PresetsUpdateResponseDataUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface PresetsUpdateResponseDataUiDesignTokens {
    borderRadius: PresetsUpdateResponseDataUiDesignTokensBorderRadius;
    borderWidth: PresetsUpdateResponseDataUiDesignTokensBorderWidth;
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: PresetsUpdateResponseDataUiDesignTokensTheme;
    fontFamily?: string | null | undefined;
    googleFont?: string | null | undefined;
    logo?: string | null | undefined;
}
export interface PresetsUpdateResponseDataUi {
    designTokens: PresetsUpdateResponseDataUiDesignTokens;
}
export interface PresetsUpdateResponseData {
    /** ID of the preset */
    id: string;
    config: PresetsUpdateResponseDataConfig;
    /** Timestamp this preset was created at */
    createdAt: string;
    /** Name of the preset */
    name: string;
    permissions: PresetsUpdateResponseDataPermissions;
    ui: PresetsUpdateResponseDataUi;
    /** Timestamp this preset was last updated */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PatchPresetResponse {
    /** Data returned by the operation */
    data: PresetsUpdateResponseData;
}
export type RecordingsPauseResumeStopRecordingRequestAction = "stop" | "pause" | "resume";
export interface PauseResumeStopRecordingRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    recordingId: string;
    action: RecordingsPauseResumeStopRecordingRequestAction | (string & {});
}
export type RecordingsPauseResumeStopRecordingResponseDataStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export type RecordingsPauseResumeStopRecordingResponseDataStartReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsPauseResumeStopRecordingResponseDataStartReasonCaller {
    /** Name of the user who started the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsPauseResumeStopRecordingResponseDataStartReasonCallerType | null | undefined;
    /** The user ID of the person who started the recording. */
    userId?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStartReasonReason = "API_CALL" | "RECORD_ON_START";
export interface RecordingsPauseResumeStopRecordingResponseDataStartReason {
    caller?: RecordingsPauseResumeStopRecordingResponseDataStartReasonCaller | null | undefined;
    /** Specifies if the recording was started using the "Start a Recording"API or using the parameter RECORD_ON_START in the "Create a meeting" API. */
    reason?: RecordingsPauseResumeStopRecordingResponseDataStartReasonReason | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStopReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsPauseResumeStopRecordingResponseDataStopReasonCaller {
    /** Name of the user who stopped the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsPauseResumeStopRecordingResponseDataStopReasonCallerType | null | undefined;
    /** The user ID of the person who stopped the recording. */
    userId?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStopReasonReason = "API_CALL" | "INTERNAL_ERROR" | "ALL_PEERS_LEFT";
export interface RecordingsPauseResumeStopRecordingResponseDataStopReason {
    caller?: RecordingsPauseResumeStopRecordingResponseDataStopReasonCaller | null | undefined;
    /** Specifies the reason why the recording stopped. */
    reason?: RecordingsPauseResumeStopRecordingResponseDataStopReasonReason | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0Type = "gcs";
export interface RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2AuthMethod = "KEY";
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsPauseResumeStopRecordingResponseDataStorageConfig = RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase0 | RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase1 | RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase2 | RecordingsPauseResumeStopRecordingResponseDataStorageConfigCase3;
export interface RecordingsPauseResumeStopRecordingResponseData {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsPauseResumeStopRecordingResponseDataStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
    startReason?: RecordingsPauseResumeStopRecordingResponseDataStartReason | null | undefined;
    stopReason?: RecordingsPauseResumeStopRecordingResponseDataStopReason | null | undefined;
    storageConfig?: RecordingsPauseResumeStopRecordingResponseDataStorageConfig | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PauseResumeStopRecordingRecordingResponse {
    /** Data returned by the operation */
    data?: RecordingsPauseResumeStopRecordingResponseData | null | undefined;
}
export interface PostAppRequest {
    /** The account identifier tag. */
    accountId: string;
    name: string;
}
export type AppsPostResponseDataApp = AppsGetResponseDataItem;
export interface AppsPostResponseData {
    app?: AppsGetResponseDataItem | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PostAppResponse {
    data?: AppsPostResponseData | null | undefined;
}
export interface RefreshParticipantTokenMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    participantId: string;
    /** RFC 3339 timestamp with a timezone at or after which the token cannot be used. Must be in the future. Defaults to not_before plus 100 days. */
    expiresOn?: string | undefined;
    /** RFC 3339 timestamp with a timezone before which the token cannot be used. Defaults to the current time. May be in the past. */
    notBefore?: string | undefined;
}
export interface MeetingsRefreshParticipantTokenResponseData {
    /** Regenerated participant's authentication token. */
    token: string;
    /** Time at which the token stops being valid, in UTC. */
    expiresOn: string;
    /** Time from which the token is valid, in UTC. */
    notBefore: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface RefreshParticipantTokenMeetingResponse {
    /** Data returned by the operation */
    data: MeetingsRefreshParticipantTokenResponseData;
}
export type MeetingsReplaceMeetingByIdRequestAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsReplaceMeetingByIdRequestAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsReplaceMeetingByIdRequestAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsReplaceMeetingByIdRequestAiConfigSummarizationSummaryType | (string & {}) | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsReplaceMeetingByIdRequestAiConfigSummarizationTextFormat | (string & {}) | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | undefined;
}
export type MeetingsReplaceMeetingByIdRequestAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsReplaceMeetingByIdRequestAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsReplaceMeetingByIdRequestAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsReplaceMeetingByIdRequestAiConfigTranscriptionKeywordsList | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsReplaceMeetingByIdRequestAiConfigTranscriptionLanguage | (string & {}) | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | undefined;
}
export interface MeetingsReplaceMeetingByIdRequestAiConfig {
    /** Summary Config */
    summarization?: MeetingsReplaceMeetingByIdRequestAiConfigSummarization | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsReplaceMeetingByIdRequestAiConfigTranscription | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfigChannel | (string & {}) | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfigCodec | (string & {}) | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigLiveStreamingConfig = MeetingsCreateRequestRecordingConfigLiveStreamingConfig;
export type MeetingsReplaceMeetingByIdRequestRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfig = MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase0 | MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase1 | MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase2 | MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfigCase3;
export type MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigWatermarkSize = MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigWatermarkPosition | (string & {}) | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize | undefined;
    /** URL of the watermark image */
    url?: string | undefined;
}
export interface MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigCodec | (string & {}) | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | undefined;
    /** Height of the recording video in pixels */
    height?: number | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfigWatermark | undefined;
    /** Width of the recording video in pixels */
    width?: number | undefined;
}
export interface MeetingsReplaceMeetingByIdRequestRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsReplaceMeetingByIdRequestRecordingConfigAudioConfig | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | undefined;
    liveStreamingConfig?: MeetingsCreateRequestRecordingConfigLiveStreamingConfig | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | undefined;
    storageConfig?: MeetingsReplaceMeetingByIdRequestRecordingConfigStorageConfig | undefined;
    videoConfig?: MeetingsReplaceMeetingByIdRequestRecordingConfigVideoConfig | undefined;
}
export interface ReplaceMeetingByIdMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsReplaceMeetingByIdRequestAiConfig | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | undefined;
    /** If a meeting is set to persist_chat, meeting chat would remain for a week within the meeting space. */
    persistChat?: boolean | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsReplaceMeetingByIdRequestRecordingConfig | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | undefined;
    /** Title of the meeting */
    title?: string | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsReplaceMeetingByIdResponseDataAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsReplaceMeetingByIdResponseDataAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsReplaceMeetingByIdResponseDataAiConfigSummarizationSummaryType | null | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsReplaceMeetingByIdResponseDataAiConfigSummarizationTextFormat | null | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsReplaceMeetingByIdResponseDataAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsReplaceMeetingByIdResponseDataAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsReplaceMeetingByIdResponseDataAiConfigTranscriptionKeywordsList | null | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsReplaceMeetingByIdResponseDataAiConfigTranscriptionLanguage | null | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | null | undefined;
}
export interface MeetingsReplaceMeetingByIdResponseDataAiConfig {
    /** Summary Config */
    summarization?: MeetingsReplaceMeetingByIdResponseDataAiConfigSummarization | null | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsReplaceMeetingByIdResponseDataAiConfigTranscription | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigLiveStreamingConfig = MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig;
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfig = MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase0 | MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase1 | MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase2 | MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfigCase3;
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkSize = MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface MeetingsReplaceMeetingByIdResponseDataRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigStorageConfig | null | undefined;
    videoConfig?: MeetingsReplaceMeetingByIdResponseDataRecordingConfigVideoConfig | null | undefined;
}
export type MeetingsReplaceMeetingByIdResponseDataStatus = "ACTIVE" | "INACTIVE";
export interface MeetingsReplaceMeetingByIdResponseData {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsReplaceMeetingByIdResponseDataAiConfig | null | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsReplaceMeetingByIdResponseDataRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsReplaceMeetingByIdResponseDataStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ReplaceMeetingByIdMeetingResponse {
    /** Data returned by the operation */
    data?: MeetingsReplaceMeetingByIdResponseData | null | undefined;
}
export type ReplacePresetByIdRequestConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type ReplacePresetByIdRequestConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface ReplacePresetByIdRequestConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: ReplacePresetByIdRequestConfigMediaScreenshareQuality | (string & {});
}
export type ReplacePresetByIdRequestConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface ReplacePresetByIdRequestConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: ReplacePresetByIdRequestConfigMediaVideoQuality | (string & {});
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | undefined;
}
export type ReplacePresetByIdRequestConfigMediaAudio = PresetsCreateRequestConfigMediaAudio;
export interface ReplacePresetByIdRequestConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: ReplacePresetByIdRequestConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: ReplacePresetByIdRequestConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateRequestConfigMediaAudio | undefined;
}
export type ReplacePresetByIdRequestConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type ReplacePresetByIdRequestConfigLivestreamViewerQualitiesList = Array<number>;
export interface ReplacePresetByIdRequestConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: ReplacePresetByIdRequestConfigMedia;
    /** Type of the meeting */
    viewType: ReplacePresetByIdRequestConfigViewType | (string & {});
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: ReplacePresetByIdRequestConfigLivestreamViewerQualitiesList | undefined;
}
export type ReplacePresetByIdRequestPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type ReplacePresetByIdRequestPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type ReplacePresetByIdRequestPermissionsChat = PresetsCreateRequestPermissionsChat;
export type ReplacePresetByIdRequestPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type ReplacePresetByIdRequestPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdRequestPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: ReplacePresetByIdRequestPermissionsMediaAudioCanProduce | (string & {});
}
export type ReplacePresetByIdRequestPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdRequestPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: ReplacePresetByIdRequestPermissionsMediaScreenshareCanProduce | (string & {});
}
export type ReplacePresetByIdRequestPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdRequestPermissionsMediaVideo {
    /** Can produce video */
    canProduce: ReplacePresetByIdRequestPermissionsMediaVideoCanProduce | (string & {});
}
export interface ReplacePresetByIdRequestPermissionsMedia {
    /** Audio permissions */
    audio: ReplacePresetByIdRequestPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: ReplacePresetByIdRequestPermissionsMediaScreenshare;
    /** Video permissions */
    video: ReplacePresetByIdRequestPermissionsMediaVideo;
}
export type ReplacePresetByIdRequestPermissionsPluginsConfigValueAccessControl = "FULL_ACCESS" | "VIEW_ONLY";
export interface ReplacePresetByIdRequestPermissionsPluginsConfigValue {
    accessControl?: ReplacePresetByIdRequestPermissionsPluginsConfigValueAccessControl | (string & {}) | undefined;
    handlesViewOnly?: boolean | undefined;
}
export type ReplacePresetByIdRequestPermissionsPluginsConfigMap = {
    [key: string]: ReplacePresetByIdRequestPermissionsPluginsConfigValue | undefined;
};
export interface ReplacePresetByIdRequestPermissionsPlugins {
    /** Can close plugins that are already open */
    canClose: boolean;
    /** Can edit plugin config */
    canEditConfig: boolean;
    /** Can start plugins */
    canStart: boolean;
    /** Plugin configuration keyed by plugin UUID. */
    config: ReplacePresetByIdRequestPermissionsPluginsConfigMap;
}
export type ReplacePresetByIdRequestPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type ReplacePresetByIdRequestPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type ReplacePresetByIdRequestPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type ReplacePresetByIdRequestPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdRequestPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: ReplacePresetByIdRequestPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: ReplacePresetByIdRequestPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: ReplacePresetByIdRequestPermissionsRecorderType | (string & {});
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: ReplacePresetByIdRequestPermissionsWaitingRoomType | (string & {});
    acceptStageRequests?: boolean | undefined;
    isRecorder?: boolean | undefined;
    stageAccess?: ReplacePresetByIdRequestPermissionsStageAccess | (string & {}) | undefined;
    stageEnabled?: boolean | undefined;
    transcriptionEnabled?: boolean | undefined;
}
export type ReplacePresetByIdRequestUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type ReplacePresetByIdRequestUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type ReplacePresetByIdRequestUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type ReplacePresetByIdRequestUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type ReplacePresetByIdRequestUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type ReplacePresetByIdRequestUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface ReplacePresetByIdRequestUiDesignTokens {
    borderRadius: ReplacePresetByIdRequestUiDesignTokensBorderRadius | (string & {});
    borderWidth: ReplacePresetByIdRequestUiDesignTokensBorderWidth | (string & {});
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: ReplacePresetByIdRequestUiDesignTokensTheme | (string & {});
    fontFamily?: string | undefined;
    googleFont?: string | undefined;
    logo?: string | undefined;
}
export interface ReplacePresetByIdRequestUi {
    designTokens: ReplacePresetByIdRequestUiDesignTokens;
}
export interface ReplacePresetByIdRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    presetId: string;
    config: ReplacePresetByIdRequestConfig;
    /** Name of the preset */
    name: string;
    permissions: ReplacePresetByIdRequestPermissions;
    ui: ReplacePresetByIdRequestUi;
}
export type ReplacePresetByIdResponseDataConfigMaxVideoStreams = PresetsCreateRequestConfigMaxVideoStreams;
export type ReplacePresetByIdResponseDataConfigMediaScreenshareQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface ReplacePresetByIdResponseDataConfigMediaScreenshare {
    /** Frame rate of screen share */
    frameRate: number;
    /** Quality of screen share */
    quality: ReplacePresetByIdResponseDataConfigMediaScreenshareQuality;
}
export type ReplacePresetByIdResponseDataConfigMediaVideoQuality = "hd" | "vga" | "qvga" | "fhd" | "uhd";
export interface ReplacePresetByIdResponseDataConfigMediaVideo {
    /** Frame rate of participants' video */
    frameRate: number;
    /** Video quality of participants */
    quality: ReplacePresetByIdResponseDataConfigMediaVideoQuality;
    /** Enable simulcast for participant videos. */
    simulcast?: boolean | null | undefined;
}
export type ReplacePresetByIdResponseDataConfigMediaAudio = PresetsCreateResponseDataConfigMediaAudio;
export interface ReplacePresetByIdResponseDataConfigMedia {
    /** Configuration options for participant screen shares */
    screenshare: ReplacePresetByIdResponseDataConfigMediaScreenshare;
    /** Configuration options for participant videos */
    video: ReplacePresetByIdResponseDataConfigMediaVideo;
    /** Control options for Audio quality. */
    audio?: PresetsCreateResponseDataConfigMediaAudio | null | undefined;
}
export type ReplacePresetByIdResponseDataConfigViewType = "GROUP_CALL" | "WEBINAR" | "AUDIO_ROOM" | "LIVESTREAM";
export type ReplacePresetByIdResponseDataConfigLivestreamViewerQualitiesList = Array<number>;
export interface ReplacePresetByIdResponseDataConfig {
    /** Maximum number of screen shares that can be active at a given time */
    maxScreenshareCount: number;
    /** Maximum number of streams that are visible on a device */
    maxVideoStreams: PresetsCreateRequestConfigMaxVideoStreams;
    /** Media configuration options. eg: Video quality */
    media: ReplacePresetByIdResponseDataConfigMedia;
    /** Type of the meeting */
    viewType: ReplacePresetByIdResponseDataConfigViewType;
    /** Livestream viewer quality levels. */
    livestreamViewerQualities?: ReplacePresetByIdResponseDataConfigLivestreamViewerQualitiesList | null | undefined;
}
export type ReplacePresetByIdResponseDataPermissionsChatPrivate = PresetsCreateRequestPermissionsChatPrivate;
export type ReplacePresetByIdResponseDataPermissionsChatPublic = PresetsCreateRequestPermissionsChatPublic;
export type ReplacePresetByIdResponseDataPermissionsChat = PresetsCreateRequestPermissionsChat;
export type ReplacePresetByIdResponseDataPermissionsConnectedMeetings = PresetsCreateRequestPermissionsConnectedMeetings;
export type ReplacePresetByIdResponseDataPermissionsMediaAudioCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdResponseDataPermissionsMediaAudio {
    /** Can produce audio */
    canProduce: ReplacePresetByIdResponseDataPermissionsMediaAudioCanProduce;
}
export type ReplacePresetByIdResponseDataPermissionsMediaScreenshareCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdResponseDataPermissionsMediaScreenshare {
    /** Can produce screen share video */
    canProduce: ReplacePresetByIdResponseDataPermissionsMediaScreenshareCanProduce;
}
export type ReplacePresetByIdResponseDataPermissionsMediaVideoCanProduce = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdResponseDataPermissionsMediaVideo {
    /** Can produce video */
    canProduce: ReplacePresetByIdResponseDataPermissionsMediaVideoCanProduce;
}
export interface ReplacePresetByIdResponseDataPermissionsMedia {
    /** Audio permissions */
    audio: ReplacePresetByIdResponseDataPermissionsMediaAudio;
    /** Screenshare permissions */
    screenshare: ReplacePresetByIdResponseDataPermissionsMediaScreenshare;
    /** Video permissions */
    video: ReplacePresetByIdResponseDataPermissionsMediaVideo;
}
export type ReplacePresetByIdResponseDataPermissionsPluginsConfigValueAccessControl = "FULL_ACCESS" | "VIEW_ONLY";
export interface ReplacePresetByIdResponseDataPermissionsPluginsConfigValue {
    accessControl?: ReplacePresetByIdResponseDataPermissionsPluginsConfigValueAccessControl | null | undefined;
    handlesViewOnly?: boolean | null | undefined;
}
export type ReplacePresetByIdResponseDataPermissionsPluginsConfigMap = {
    [key: string]: ReplacePresetByIdResponseDataPermissionsPluginsConfigValue | undefined;
};
export interface ReplacePresetByIdResponseDataPermissionsPlugins {
    /** Can close plugins that are already open */
    canClose: boolean;
    /** Can edit plugin config */
    canEditConfig: boolean;
    /** Can start plugins */
    canStart: boolean;
    /** Plugin configuration keyed by plugin UUID. */
    config: ReplacePresetByIdResponseDataPermissionsPluginsConfigMap;
}
export type ReplacePresetByIdResponseDataPermissionsPolls = PresetsCreateRequestPermissionsPolls;
export type ReplacePresetByIdResponseDataPermissionsRecorderType = "RECORDER" | "LIVESTREAMER" | "NONE";
export type ReplacePresetByIdResponseDataPermissionsWaitingRoomType = "SKIP" | "ON_PRIVILEGED_USER_ENTRY" | "SKIP_ON_ACCEPT";
export type ReplacePresetByIdResponseDataPermissionsStageAccess = "ALLOWED" | "NOT_ALLOWED" | "CAN_REQUEST";
export interface ReplacePresetByIdResponseDataPermissions {
    /** Whether this participant can accept waiting requests */
    acceptWaitingRequests: boolean;
    canAcceptProductionRequests: boolean;
    canChangeParticipantPermissions: boolean;
    canEditDisplayName: boolean;
    canLivestream: boolean;
    canRecord: boolean;
    canSpotlight: boolean;
    chat: PresetsCreateRequestPermissionsChat;
    connectedMeetings: PresetsCreateRequestPermissionsConnectedMeetings;
    disableParticipantAudio: boolean;
    disableParticipantScreensharing: boolean;
    disableParticipantVideo: boolean;
    /** Whether this participant is visible to others or not */
    hiddenParticipant: boolean;
    kickParticipant: boolean;
    /** Media permissions */
    media: ReplacePresetByIdResponseDataPermissionsMedia;
    pinParticipant: boolean;
    /** Plugin permissions */
    plugins: ReplacePresetByIdResponseDataPermissionsPlugins;
    /** Poll permissions */
    polls: PresetsCreateRequestPermissionsPolls;
    /** Type of the recording peer */
    recorderType: ReplacePresetByIdResponseDataPermissionsRecorderType;
    showParticipantList: boolean;
    /** Waiting room type */
    waitingRoomType: ReplacePresetByIdResponseDataPermissionsWaitingRoomType;
    acceptStageRequests?: boolean | null | undefined;
    isRecorder?: boolean | null | undefined;
    stageAccess?: ReplacePresetByIdResponseDataPermissionsStageAccess | null | undefined;
    stageEnabled?: boolean | null | undefined;
    transcriptionEnabled?: boolean | null | undefined;
}
export type ReplacePresetByIdResponseDataUiDesignTokensBorderRadius = "sharp" | "rounded" | "extra-rounded" | "circular";
export type ReplacePresetByIdResponseDataUiDesignTokensBorderWidth = "none" | "thin" | "fat";
export type ReplacePresetByIdResponseDataUiDesignTokensColorsBackground = PresetsCreateRequestUiDesignTokensColorsBackground;
export type ReplacePresetByIdResponseDataUiDesignTokensColorsBrand = PresetsCreateRequestUiDesignTokensColorsBrand;
export type ReplacePresetByIdResponseDataUiDesignTokensColors = PresetsCreateRequestUiDesignTokensColors;
export type ReplacePresetByIdResponseDataUiDesignTokensTheme = "darkest" | "dark" | "light";
export interface ReplacePresetByIdResponseDataUiDesignTokens {
    borderRadius: ReplacePresetByIdResponseDataUiDesignTokensBorderRadius;
    borderWidth: ReplacePresetByIdResponseDataUiDesignTokensBorderWidth;
    colors: PresetsCreateRequestUiDesignTokensColors;
    spacingBase: number;
    theme: ReplacePresetByIdResponseDataUiDesignTokensTheme;
    fontFamily?: string | null | undefined;
    googleFont?: string | null | undefined;
    logo?: string | null | undefined;
}
export interface ReplacePresetByIdResponseDataUi {
    designTokens: ReplacePresetByIdResponseDataUiDesignTokens;
}
export interface ReplacePresetByIdResponseData {
    /** ID of the preset */
    id: string;
    config: ReplacePresetByIdResponseDataConfig;
    /** Timestamp this preset was created at */
    createdAt: string;
    /** Name of the preset */
    name: string;
    permissions: ReplacePresetByIdResponseDataPermissions;
    ui: ReplacePresetByIdResponseDataUi;
    /** Timestamp this preset was last updated */
    updatedAt: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ReplacePresetByIdResponse {
    /** Data returned by the operation */
    data: ReplacePresetByIdResponseData;
}
export type WebhooksReplaceWebhookRequestEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksReplaceWebhookRequestEventsList = Array<WebhooksReplaceWebhookRequestEventsItem | (string & {})>;
export interface ReplaceWebhookWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    webhookId: string;
    /** Events that this webhook will get triggered by */
    events: WebhooksReplaceWebhookRequestEventsList;
    /** Name of the webhook */
    name: string;
    /** URL this webhook will send events to */
    url: string;
    /** Set whether or not the webhook should be active when created */
    enabled?: boolean | undefined;
}
export type WebhooksReplaceWebhookResponseDataEventsItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksReplaceWebhookResponseDataEventsList = Array<WebhooksReplaceWebhookResponseDataEventsItem>;
export interface WebhooksReplaceWebhookResponseData {
    /** ID of the webhook */
    id: string;
    /** Timestamp when this webhook was created */
    createdAt: string;
    /** Set to true if the webhook is active */
    enabled: boolean;
    /** Events this webhook will send updates for */
    events: WebhooksReplaceWebhookResponseDataEventsList;
    /** Name of the webhook */
    name: string;
    /** Timestamp when this webhook was updated */
    updatedAt: string;
    /** URL the webhook will send events to */
    url: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ReplaceWebhookWebhookResponse {
    data: WebhooksReplaceWebhookResponseData;
}
export interface LivestreamsStartLivestreamingAMeetingRequestVideoConfig {
    /** Height of the livestreaming video in pixels */
    height?: number | undefined;
    /** Width of the livestreaming video in pixels */
    width?: number | undefined;
}
export interface StartLivestreamingAMeetingLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    name?: string | undefined;
    videoConfig?: LivestreamsStartLivestreamingAMeetingRequestVideoConfig | undefined;
}
export type LivestreamsStartLivestreamingAMeetingResponseDataStatus = "LIVE" | "IDLE" | "ERRORED" | "INVOKED" | "METRICS_READY";
export interface LivestreamsStartLivestreamingAMeetingResponseData {
    /** ID of the livestream. */
    id: string;
    /** The server URL to which the RTMP encoder sends the video and audio data. */
    ingestServer: string;
    /** ID of the meeting being livestreamed, if any. */
    meetingId: string;
    /** Name of the livestream. */
    name: string;
    /** The web address that viewers can use to watch the livestream. */
    playbackUrl: string;
    /** Status of the livestream. */
    status: LivestreamsStartLivestreamingAMeetingResponseDataStatus;
    /** Unique key for accessing each livestream. Empty if the livestream is disabled. */
    streamKey: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StartLivestreamingAMeetingLivestreamResponse {
    data: LivestreamsStartLivestreamingAMeetingResponseData;
}
export type RecordingsStartRecordingsRequestAudioConfigChannel = "mono" | "stereo";
export type RecordingsStartRecordingsRequestAudioConfigCodec = "MP3" | "AAC";
export interface RecordingsStartRecordingsRequestAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: RecordingsStartRecordingsRequestAudioConfigChannel | (string & {}) | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: RecordingsStartRecordingsRequestAudioConfigCodec | (string & {}) | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | undefined;
}
export type RecordingsStartRecordingsRequestInteractiveConfigType = "ID3";
export interface RecordingsStartRecordingsRequestInteractiveConfig {
    /** The metadata is presented in the form of ID3 tags. */
    type?: RecordingsStartRecordingsRequestInteractiveConfigType | (string & {}) | undefined;
}
export type RecordingsStartRecordingsRequestRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type RecordingsStartRecordingsRequestRtmpOutConfig = MeetingsCreateRequestRecordingConfigLiveStreamingConfig;
export type RecordingsStartRecordingsRequestStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsStartRecordingsRequestStorageConfigCase0Type = "gcs";
export interface RecordingsStartRecordingsRequestStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsStartRecordingsRequestStorageConfigCase0AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: RecordingsStartRecordingsRequestStorageConfigCase0Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type RecordingsStartRecordingsRequestStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsStartRecordingsRequestStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsStartRecordingsRequestStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsStartRecordingsRequestStorageConfigCase1AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: RecordingsStartRecordingsRequestStorageConfigCase1Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type RecordingsStartRecordingsRequestStorageConfigCase2AuthMethod = "KEY";
export type RecordingsStartRecordingsRequestStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsStartRecordingsRequestStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: RecordingsStartRecordingsRequestStorageConfigCase2AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: RecordingsStartRecordingsRequestStorageConfigCase2Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type RecordingsStartRecordingsRequestStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsStartRecordingsRequestStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsStartRecordingsRequestStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: RecordingsStartRecordingsRequestStorageConfigCase3AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: RecordingsStartRecordingsRequestStorageConfigCase3Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type RecordingsStartRecordingsRequestStorageConfig = RecordingsStartRecordingsRequestStorageConfigCase0 | RecordingsStartRecordingsRequestStorageConfigCase1 | RecordingsStartRecordingsRequestStorageConfigCase2 | RecordingsStartRecordingsRequestStorageConfigCase3;
export type RecordingsStartRecordingsRequestVideoConfigCodec = "H264" | "VP8" | "VP9";
export type RecordingsStartRecordingsRequestVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type RecordingsStartRecordingsRequestVideoConfigWatermarkSize = MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize;
export interface RecordingsStartRecordingsRequestVideoConfigWatermark {
    /** Position of the watermark */
    position?: RecordingsStartRecordingsRequestVideoConfigWatermarkPosition | (string & {}) | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize | undefined;
    /** URL of the watermark image */
    url?: string | undefined;
}
export interface RecordingsStartRecordingsRequestVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: RecordingsStartRecordingsRequestVideoConfigCodec | (string & {}) | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | undefined;
    /** Height of the recording video in pixels */
    height?: number | undefined;
    /** Watermark to be added to the recording */
    watermark?: RecordingsStartRecordingsRequestVideoConfigWatermark | undefined;
    /** Width of the recording video in pixels */
    width?: number | undefined;
}
export interface StartRecordingsRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** ID of the meeting to record. */
    meetingId: string;
    /** By default, a meeting allows only one recording to run at a time. Enabling the `allow_multiple_recordings` parameter to true allows you to initiate multiple recordings concurrently in the same meeting. This allows you to record separate videos of the same meeting with different configurations, such as portrait mode or landscape mode. */
    allowMultipleRecordings?: boolean | undefined;
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: RecordingsStartRecordingsRequestAudioConfig | undefined;
    /** Update the recording file name. */
    fileNamePrefix?: string | undefined;
    /** Allows you to add timed metadata to your recordings, which are digital markers inserted into a video file to provide contextual information at specific points in the content range. The ID3 tags containing this information are available to clients on the playback timeline in HLS format. The output files are generated in a compressed .tar format. */
    interactiveConfig?: RecordingsStartRecordingsRequestInteractiveConfig | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | undefined;
    rtmpOutConfig?: MeetingsCreateRequestRecordingConfigLiveStreamingConfig | undefined;
    storageConfig?: RecordingsStartRecordingsRequestStorageConfig | undefined;
    /** Pass a custom url to record arbitary screen */
    url?: string | undefined;
    videoConfig?: RecordingsStartRecordingsRequestVideoConfig | undefined;
}
export type RecordingsStartRecordingsResponseDataStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export type RecordingsStartRecordingsResponseDataStartReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsStartRecordingsResponseDataStartReasonCaller {
    /** Name of the user who started the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsStartRecordingsResponseDataStartReasonCallerType | null | undefined;
    /** The user ID of the person who started the recording. */
    userId?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStartReasonReason = "API_CALL" | "RECORD_ON_START";
export interface RecordingsStartRecordingsResponseDataStartReason {
    caller?: RecordingsStartRecordingsResponseDataStartReasonCaller | null | undefined;
    /** Specifies if the recording was started using the "Start a Recording"API or using the parameter RECORD_ON_START in the "Create a meeting" API. */
    reason?: RecordingsStartRecordingsResponseDataStartReasonReason | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStopReasonCallerType = "ORGANIZATION" | "USER";
export interface RecordingsStartRecordingsResponseDataStopReasonCaller {
    /** Name of the user who stopped the recording. */
    name?: string | null | undefined;
    /** The type can be an App or a user. If the type is `user`, then only the `user_Id` and `name` are returned. */
    type?: RecordingsStartRecordingsResponseDataStopReasonCallerType | null | undefined;
    /** The user ID of the person who stopped the recording. */
    userId?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStopReasonReason = "API_CALL" | "INTERNAL_ERROR" | "ALL_PEERS_LEFT";
export interface RecordingsStartRecordingsResponseDataStopReason {
    caller?: RecordingsStartRecordingsResponseDataStopReasonCaller | null | undefined;
    /** Specifies the reason why the recording stopped. */
    reason?: RecordingsStartRecordingsResponseDataStopReasonReason | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type RecordingsStartRecordingsResponseDataStorageConfigCase0Type = "gcs";
export interface RecordingsStartRecordingsResponseDataStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsStartRecordingsResponseDataStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsStartRecordingsResponseDataStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type RecordingsStartRecordingsResponseDataStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface RecordingsStartRecordingsResponseDataStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: RecordingsStartRecordingsResponseDataStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: RecordingsStartRecordingsResponseDataStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStorageConfigCase2AuthMethod = "KEY";
export type RecordingsStartRecordingsResponseDataStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsStartRecordingsResponseDataStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsStartRecordingsResponseDataStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsStartRecordingsResponseDataStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStorageConfigCase3AuthMethod = "PASSWORD";
export type RecordingsStartRecordingsResponseDataStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface RecordingsStartRecordingsResponseDataStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: RecordingsStartRecordingsResponseDataStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: RecordingsStartRecordingsResponseDataStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type RecordingsStartRecordingsResponseDataStorageConfig = RecordingsStartRecordingsResponseDataStorageConfigCase0 | RecordingsStartRecordingsResponseDataStorageConfigCase1 | RecordingsStartRecordingsResponseDataStorageConfigCase2 | RecordingsStartRecordingsResponseDataStorageConfigCase3;
export interface RecordingsStartRecordingsResponseData {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsStartRecordingsResponseDataStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
    startReason?: RecordingsStartRecordingsResponseDataStartReason | null | undefined;
    stopReason?: RecordingsStartRecordingsResponseDataStopReason | null | undefined;
    storageConfig?: RecordingsStartRecordingsResponseDataStorageConfig | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StartRecordingsRecordingResponse {
    /** Data returned by the operation */
    data?: RecordingsStartRecordingsResponseData | null | undefined;
}
export type RecordingsStartTrackRecordingRequestLayersValueMediaKind = "audio";
export interface RecordingsStartTrackRecordingRequestLayersValue {
    /** A file name prefix to apply for files generated from this layer */
    fileNamePrefix?: string | undefined;
    /** Media kind to record. Track recording currently supports audio only. */
    mediaKind?: RecordingsStartTrackRecordingRequestLayersValueMediaKind | (string & {}) | undefined;
}
export type RecordingsStartTrackRecordingRequestLayersMap = {
    [key: string]: RecordingsStartTrackRecordingRequestLayersValue | undefined;
};
export type RecordingsStartTrackRecordingRequestUserIdsList = Array<string>;
export interface StartTrackRecordingRecordingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    /** ID of the meeting to record. */
    meetingId: string;
    /** Optional audio layer configuration. If omitted, RealtimeKit records all participant audio using the default file name prefix. */
    layers?: RecordingsStartTrackRecordingRequestLayersMap | undefined;
    /** Optional list of participant user IDs to record. Selective track recording (`user_ids`) is in early beta contact support to use this feature. */
    userIds?: RecordingsStartTrackRecordingRequestUserIdsList | undefined;
}
export type RecordingsStartTrackRecordingResponseDataRecordingStatus = "INVOKED" | "RECORDING" | "UPLOADING" | "UPLOADED" | "ERRORED" | "PAUSED";
export interface RecordingsStartTrackRecordingResponseDataRecording {
    /** ID of the recording */
    id: string;
    /** If the audio_config is passed, the URL for downloading the audio recording is returned. */
    audioDownloadUrl: string;
    /** URL where the recording can be downloaded. */
    downloadUrl: string;
    /** Timestamp when the download URL expires. */
    downloadUrlExpiry: string;
    /** File size of the recording, in bytes. */
    fileSize: number;
    /** Timestamp when this recording was invoked. */
    invokedTime: string;
    /** File name of the recording. */
    outputFileName: string;
    /** ID of the meeting session this recording is for. */
    sessionId: string;
    /** Timestamp when this recording actually started after being invoked. Usually a few seconds after `invoked_time`. */
    startedTime: string;
    /** Current status of the recording. */
    status: RecordingsStartTrackRecordingResponseDataRecordingStatus;
    /** Timestamp when this recording was stopped. Optional; is present only when the recording has actually been stopped. */
    stoppedTime: string;
    /** Total recording time in seconds. */
    recordingDuration?: number | null | undefined;
}
export interface RecordingsStartTrackRecordingResponseData {
    recording: RecordingsStartTrackRecordingResponseDataRecording;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StartTrackRecordingRecordingResponse {
    /** Data returned by the operation */
    data?: RecordingsStartTrackRecordingResponseData | null | undefined;
}
export interface StopLivestreamingAMeetingLivestreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
}
export interface LivestreamsStopLivestreamingAMeetingResponseData {
    message?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StopLivestreamingAMeetingLivestreamResponse {
    data?: LivestreamsStopLivestreamingAMeetingResponseData | null | undefined;
}
export interface UpdateAppByIdRequest {
    /** The account identifier tag. */
    accountId: string;
    appId: string;
    /** The app name. Leading and trailing whitespace is removed, and the name must contain at least one non-whitespace character. */
    name: string;
}
export interface UpdateAppByIdResponseData {
    id?: string | null | undefined;
    cfAccountTag?: string | null | undefined;
    createdAt?: string | null | undefined;
    isOrgOnKv?: boolean | null | undefined;
    name?: string | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface UpdateAppByIdResponse {
    data: UpdateAppByIdResponseData;
}
export type MeetingsUpdateMeetingByIdRequestAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsUpdateMeetingByIdRequestAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsUpdateMeetingByIdRequestAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsUpdateMeetingByIdRequestAiConfigSummarizationSummaryType | (string & {}) | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsUpdateMeetingByIdRequestAiConfigSummarizationTextFormat | (string & {}) | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | undefined;
}
export type MeetingsUpdateMeetingByIdRequestAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsUpdateMeetingByIdRequestAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsUpdateMeetingByIdRequestAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsUpdateMeetingByIdRequestAiConfigTranscriptionKeywordsList | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsUpdateMeetingByIdRequestAiConfigTranscriptionLanguage | (string & {}) | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | undefined;
}
export interface MeetingsUpdateMeetingByIdRequestAiConfig {
    /** Summary Config */
    summarization?: MeetingsUpdateMeetingByIdRequestAiConfigSummarization | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsUpdateMeetingByIdRequestAiConfigTranscription | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfigChannel | (string & {}) | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfigCodec | (string & {}) | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigLiveStreamingConfig = MeetingsCreateRequestRecordingConfigLiveStreamingConfig;
export type MeetingsUpdateMeetingByIdRequestRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    type?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | undefined;
    authMethod?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3AuthMethod | (string & {}) | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | undefined;
    /** Region of the storage medium. */
    region?: string | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | undefined;
    /** Type of storage media. */
    type?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3Type | (string & {}) | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | undefined;
}
export type MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfig = MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase0 | MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase1 | MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase2 | MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfigCase3;
export type MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigWatermarkSize = MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigWatermarkPosition | (string & {}) | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateRequestRecordingConfigVideoConfigWatermarkSize | undefined;
    /** URL of the watermark image */
    url?: string | undefined;
}
export interface MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigCodec | (string & {}) | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | undefined;
    /** Height of the recording video in pixels */
    height?: number | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfigWatermark | undefined;
    /** Width of the recording video in pixels */
    width?: number | undefined;
}
export interface MeetingsUpdateMeetingByIdRequestRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsUpdateMeetingByIdRequestRecordingConfigAudioConfig | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | undefined;
    liveStreamingConfig?: MeetingsCreateRequestRecordingConfigLiveStreamingConfig | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | undefined;
    storageConfig?: MeetingsUpdateMeetingByIdRequestRecordingConfigStorageConfig | undefined;
    videoConfig?: MeetingsUpdateMeetingByIdRequestRecordingConfigVideoConfig | undefined;
}
export type MeetingsUpdateMeetingByIdRequestStatus = "ACTIVE" | "INACTIVE";
export interface UpdateMeetingByIdMeetingRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
    meetingId: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsUpdateMeetingByIdRequestAiConfig | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | undefined;
    /** If a meeting is updated to persist_chat, meeting chat would remain for a week within the meeting space. */
    persistChat?: boolean | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsUpdateMeetingByIdRequestRecordingConfig | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsUpdateMeetingByIdRequestStatus | (string & {}) | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | undefined;
    /** Title of the meeting */
    title?: string | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataAiConfigSummarizationSummaryType = "general" | "team_meeting" | "sales_call" | "client_check_in" | "interview" | "daily_standup" | "one_on_one_meeting" | "lecture" | "code_review";
export type MeetingsUpdateMeetingByIdResponseDataAiConfigSummarizationTextFormat = "plain_text" | "markdown";
export interface MeetingsUpdateMeetingByIdResponseDataAiConfigSummarization {
    /** Defines the style of the summary, such as general, team meeting, or sales call. */
    summaryType?: MeetingsUpdateMeetingByIdResponseDataAiConfigSummarizationSummaryType | null | undefined;
    /** Determines the text format of the summary, such as plain text or markdown. */
    textFormat?: MeetingsUpdateMeetingByIdResponseDataAiConfigSummarizationTextFormat | null | undefined;
    /** Sets the maximum number of words in the meeting summary. */
    wordLimit?: number | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataAiConfigTranscriptionKeywordsList = Array<string>;
export type MeetingsUpdateMeetingByIdResponseDataAiConfigTranscriptionLanguage = "en-US" | "en-IN" | "de" | "hi" | "sv" | "ru" | "pl" | "el" | "fr" | "nl";
export interface MeetingsUpdateMeetingByIdResponseDataAiConfigTranscription {
    /** Adds specific terms to improve accurate detection during transcription. */
    keywords?: MeetingsUpdateMeetingByIdResponseDataAiConfigTranscriptionKeywordsList | null | undefined;
    /** Specifies the language code for transcription to ensure accurate results. If omitted, the language is auto-detected for post-meeting (Whisper) transcription. */
    language?: MeetingsUpdateMeetingByIdResponseDataAiConfigTranscriptionLanguage | null | undefined;
    /** Control the inclusion of offensive language in transcriptions. */
    profanityFilter?: boolean | null | undefined;
}
export interface MeetingsUpdateMeetingByIdResponseDataAiConfig {
    /** Summary Config */
    summarization?: MeetingsUpdateMeetingByIdResponseDataAiConfigSummarization | null | undefined;
    /** Transcription Configurations */
    transcription?: MeetingsUpdateMeetingByIdResponseDataAiConfigTranscription | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfigChannel = "mono" | "stereo";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfigCodec = "MP3" | "AAC";
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfig {
    /** Audio signal pathway within an audio file that carries a specific sound source. */
    channel?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfigChannel | null | undefined;
    /** Codec using which the recording will be encoded. If VP8/VP9 is selected for videoConfig, changing audioConfig is not allowed. In this case, the codec in the audioConfig is automatically set to vorbis. */
    codec?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfigCodec | null | undefined;
    /** Controls whether to export audio file seperately */
    exportFile?: boolean | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigLiveStreamingConfig = MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig;
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigRealtimekitBucketConfig = MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig;
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod = "KEY" | "PASSWORD";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type = "gcs";
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0 {
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod = "KEY" | "PASSWORD";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type = "aws" | "azure" | "digitalocean";
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1 {
    accessKey: unknown;
    region: unknown;
    /** Authentication method used for "sftp" type storage medium */
    authMethod?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    type?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod = "KEY";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2 {
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod = "PASSWORD";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type = "aws" | "azure" | "digitalocean" | "gcs" | "sftp";
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3 {
    /** SSH destination server password for SFTP type storage medium when auth_method is "PASSWORD". If auth_method is "KEY", this specifies the password for the ssh private key. */
    password: string;
    /** Access key of the storage medium. Access key is not required for the `gcs` storage media type. */
    accessKey?: string | null | undefined;
    authMethod?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3AuthMethod | null | undefined;
    /** Name of the storage medium's bucket. */
    bucket?: string | null | undefined;
    /** SSH destination server host for SFTP type storage medium */
    host?: string | null | undefined;
    /** Path relative to the bucket root at which the recording will be placed. */
    path?: string | null | undefined;
    /** SSH destination server port for SFTP type storage medium */
    port?: number | null | undefined;
    /** Private key used to login to destination SSH server for SFTP type storage medium, when auth_method used is "KEY" */
    privateKey?: string | null | undefined;
    /** Region of the storage medium. */
    region?: string | null | undefined;
    /** Secret key of the storage medium. Similar to `access_key`, it is only writeable by clients, not readable. */
    secret?: string | null | undefined;
    /** Type of storage media. */
    type?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3Type | null | undefined;
    /** SSH destination server username for SFTP type storage medium */
    username?: string | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfig = MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase0 | MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase1 | MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase2 | MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfigCase3;
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigCodec = "H264" | "VP8" | "VP9";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition = "left top" | "right top" | "left bottom" | "right bottom";
export type MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkSize = MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize;
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigWatermark {
    /** Position of the watermark */
    position?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigWatermarkPosition | null | undefined;
    /** Size of the watermark */
    size?: MeetingsCreateResponseDataRecordingConfigVideoConfigWatermarkSize | null | undefined;
    /** URL of the watermark image */
    url?: string | null | undefined;
}
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfig {
    /** Codec using which the recording will be encoded. */
    codec?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigCodec | null | undefined;
    /** Controls whether to export video file seperately */
    exportFile?: boolean | null | undefined;
    /** Height of the recording video in pixels */
    height?: number | null | undefined;
    /** Watermark to be added to the recording */
    watermark?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfigWatermark | null | undefined;
    /** Width of the recording video in pixels */
    width?: number | null | undefined;
}
export interface MeetingsUpdateMeetingByIdResponseDataRecordingConfig {
    /** Object containing configuration regarding the audio that is being recorded. */
    audioConfig?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigAudioConfig | null | undefined;
    /** Adds a prefix to the beginning of the file name of the recording. */
    fileNamePrefix?: string | null | undefined;
    liveStreamingConfig?: MeetingsCreateResponseDataRecordingConfigLiveStreamingConfig | null | undefined;
    /** Specifies the maximum duration for recording in seconds, ranging from a minimum of 60 seconds to a maximum of 24 hours. */
    maxSeconds?: number | null | undefined;
    realtimekitBucketConfig?: MeetingsCreateRequestRecordingConfigRealtimekitBucketConfig | null | undefined;
    storageConfig?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigStorageConfig | null | undefined;
    videoConfig?: MeetingsUpdateMeetingByIdResponseDataRecordingConfigVideoConfig | null | undefined;
}
export type MeetingsUpdateMeetingByIdResponseDataStatus = "ACTIVE" | "INACTIVE";
export interface MeetingsUpdateMeetingByIdResponseData {
    /** ID of the meeting. */
    id: string;
    /** Timestamp the object was created at. The time is returned in ISO format. */
    createdAt: string;
    /** Timestamp the object was updated at. The time is returned in ISO format. */
    updatedAt: string;
    /** The AI Config allows you to customize the behavior of meeting transcriptions and summaries */
    aiConfig?: MeetingsUpdateMeetingByIdResponseDataAiConfig | null | undefined;
    /** Specifies if the meeting should start getting livestreamed on start. */
    liveStreamOnStart?: boolean | null | undefined;
    /** Specifies if Chat within a meeting should persist for a week. */
    persistChat?: boolean | null | undefined;
    /** Specifies if the meeting should start getting recorded as soon as someone joins the meeting. */
    recordOnStart?: boolean | null | undefined;
    /** Recording Configurations to be used for this meeting. This level of configs takes higher preference over App level configs on the RealtimeKit developer portal. */
    recordingConfig?: MeetingsUpdateMeetingByIdResponseDataRecordingConfig | null | undefined;
    /** Time in seconds, for which a session remains active, after the last participant has left the meeting. */
    sessionKeepAliveTimeInSecs?: number | null | undefined;
    /** Whether the meeting is `ACTIVE` or `INACTIVE`. Users will not be able to join an `INACTIVE` meeting. */
    status?: MeetingsUpdateMeetingByIdResponseDataStatus | null | undefined;
    /** Automatically generate summary of meetings using transcripts. Requires Transcriptions to be enabled, and can be retrieved via Webhooks or summary API. */
    summarizeOnEnd?: boolean | null | undefined;
    /** Title of the meeting. */
    title?: string | null | undefined;
    /** Automatically generate transcripts when the meeting ends. */
    transcribeOnEnd?: boolean | null | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface UpdateMeetingByIdMeetingResponse {
    /** Data returned by the operation */
    data?: MeetingsUpdateMeetingByIdResponseData | null | undefined;
}
export interface WebhooksGetAllWebhooksRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The app identifier tag. */
    appId: string;
}
export type WebhooksGetAllWebhooksResponseDataItem = "meeting.started" | "meeting.ended" | "meeting.participantJoined" | "meeting.participantLeft" | "meeting.chatSynced" | "recording.statusUpdate" | "livestreaming.statusUpdate" | "meeting.transcript" | "meeting.summary";
export type WebhooksGetAllWebhooksResponseDataList = Array<WebhooksGetAllWebhooksResponseDataItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface WebhooksGetAllWebhooksResponse {
    data: WebhooksGetAllWebhooksResponseDataList;
}
export type ActiveSessionMuteAllParticipantsError = CloudflareOpError;
/** Mutes all participants of an active session for the given meeting ID. */
export declare const activeSessionMuteAllParticipants: API.OperationMethod<ActiveSessionMuteAllParticipantsRequest, ActiveSessionMuteAllParticipantsResponse, ActiveSessionMuteAllParticipantsError, CloudflareOpContext>;
export type ActiveSessionMuteParticipantsError = CloudflareOpError;
/** Mutes one or more participants from an active session using user ID or custom participant ID. */
export declare const activeSessionMuteParticipants: API.OperationMethod<ActiveSessionMuteParticipantsRequest, ActiveSessionMuteParticipantsResponse, ActiveSessionMuteParticipantsError, CloudflareOpContext>;
export type AddParticipantMeetingError = CloudflareOpError;
/** Adds a participant to the given meeting ID. */
export declare const addParticipantMeeting: API.OperationMethod<AddParticipantMeetingRequest, AddParticipantMeetingResponse, AddParticipantMeetingError, CloudflareOpContext>;
export type CreateIndependentLivestreamLivestreamError = CloudflareOpError;
/** Creates a livestream for the given App ID and returns ingest server, stream key, and playback URL. You can pass custom input to the ingest server and stream key, and freely distribute the content using the playback URL on any player that supports HLS/LHLS. */
export declare const createIndependentLivestreamLivestream: API.OperationMethod<CreateIndependentLivestreamLivestreamRequest, CreateIndependentLivestreamLivestreamResponse, CreateIndependentLivestreamLivestreamError, CloudflareOpContext>;
export type CreateMeetingError = CloudflareOpError;
/** Create a meeting for the given App ID. */
export declare const createMeeting: API.OperationMethod<CreateMeetingRequest, CreateMeetingResponse, CreateMeetingError, CloudflareOpContext>;
export type CreatePollActiveSessionError = CloudflareOpError;
/** Creates a new poll in an active session for the given meeting ID. */
export declare const createPollActiveSession: API.OperationMethod<CreatePollActiveSessionRequest, CreatePollActiveSessionResponse, CreatePollActiveSessionError, CloudflareOpContext>;
export type CreatePresetError = RealtimeKitPresetExists | Forbidden | CloudflareOpError;
/** Creates a preset belonging to the current App */
export declare const createPreset: API.OperationMethod<CreatePresetRequest, CreatePresetResponse, CreatePresetError, CloudflareOpContext>;
export type CreateWebhookWebhookError = RealtimeKitWebhookExists | Forbidden | CloudflareOpError;
/** Adds a new webhook to an App. */
export declare const createWebhookWebhook: API.OperationMethod<CreateWebhookWebhookRequest, CreateWebhookWebhookResponse, CreateWebhookWebhookError, CloudflareOpContext>;
export type DeleteMeetingParticipantMeetingError = CloudflareOpError;
/** Deletes a participant for the given meeting and participant ID. */
export declare const deleteMeetingParticipantMeeting: API.OperationMethod<DeleteMeetingParticipantMeetingRequest, DeleteMeetingParticipantMeetingResponse, DeleteMeetingParticipantMeetingError, CloudflareOpContext>;
export type DeletePresetError = RealtimeKitPresetNotFound | Forbidden | CloudflareOpError;
/** Deletes a preset using the provided preset ID */
export declare const deletePreset: API.OperationMethod<DeletePresetRequest, DeletePresetResponse, DeletePresetError, CloudflareOpContext>;
export type DeleteWebhookWebhookError = RealtimeKitWebhookNotFound | Forbidden | CloudflareOpError;
/** Removes a webhook for the given webhook ID. */
export declare const deleteWebhookWebhook: API.OperationMethod<DeleteWebhookWebhookRequest, DeleteWebhookWebhookResponse, DeleteWebhookWebhookError, CloudflareOpContext>;
export type EditParticipantMeetingError = CloudflareOpError;
/** Updates a participant's details for the given meeting and participant ID. */
export declare const editParticipantMeeting: API.OperationMethod<EditParticipantMeetingRequest, EditParticipantMeetingResponse, EditParticipantMeetingError, CloudflareOpContext>;
export type EditWebhookWebhookError = CloudflareOpError;
/** Edits the webhook details for the given webhook ID. */
export declare const editWebhookWebhook: API.OperationMethod<EditWebhookWebhookRequest, EditWebhookWebhookResponse, EditWebhookWebhookError, CloudflareOpContext>;
export type GenerateSummaryOfTranscriptsSessionError = CloudflareOpError;
/** Trigger Summary generation of Transcripts for the session ID. */
export declare const generateSummaryOfTranscriptsSession: API.OperationMethod<GenerateSummaryOfTranscriptsSessionRequest, GenerateSummaryOfTranscriptsSessionResponse, GenerateSummaryOfTranscriptsSessionError, CloudflareOpContext>;
export type GetActiveLivestreamsForLivestreamIdLivestreamError = CloudflareOpError;
/** Returns details of all active livestreams for the given livestream ID. Retreive the livestream ID using the `Start livestreaming a meeting` API. */
export declare const getActiveLivestreamsForLivestreamIdLivestream: API.OperationMethod<GetActiveLivestreamsForLivestreamIdLivestreamRequest, GetActiveLivestreamsForLivestreamIdLivestreamResponse, GetActiveLivestreamsForLivestreamIdLivestreamError, CloudflareOpContext>;
export type GetActiveRecordingsRecordingError = CloudflareOpError;
/** Returns the active recording details for the given meeting ID. */
export declare const getActiveRecordingsRecording: API.OperationMethod<GetActiveRecordingsRecordingRequest, GetActiveRecordingsRecordingResponse, GetActiveRecordingsRecordingError, CloudflareOpContext>;
export type GetActiveSessionActiveSessionError = CloudflareOpError;
/** Returns details of an ongoing active session for the given meeting ID. */
export declare const getActiveSessionActiveSession: API.OperationMethod<GetActiveSessionActiveSessionRequest, GetActiveSessionActiveSessionResponse, GetActiveSessionActiveSessionError, CloudflareOpContext>;
export type GetAllLivestreamsLivestreamError = CloudflareOpError;
/** Returns details of livestreams associated with the given App ID. It includes livestreams created by your App and RealtimeKit meetings that are livestreamed by your App. If you only want details of livestreams created by your App and not RealtimeKit meetings, you can use the `exclude_meetings` query parameter. */
export declare const getAllLivestreamsLivestream: API.OperationMethod<GetAllLivestreamsLivestreamRequest, GetAllLivestreamsLivestreamResponse, GetAllLivestreamsLivestreamError, CloudflareOpContext>;
export type GetAppError = Forbidden | CloudflareOpError;
/** Fetch all apps for your account */
export declare const getApp: API.OperationMethod<GetAppRequest, GetAppResponse, GetAppError, CloudflareOpContext>;
export type GetAppByIdError = CloudflareOpError;
/** Fetch details for an app in your account. */
export declare const getAppById: API.OperationMethod<GetAppByIdRequest, GetAppByIdResponse, GetAppByIdError, CloudflareOpContext>;
export type GetLivestreamAnalyticsCompleteLivestreamError = CloudflareOpError;
/** Returns livestream analytics for the specified time range. */
export declare const getLivestreamAnalyticsCompleteLivestream: API.OperationMethod<GetLivestreamAnalyticsCompleteLivestreamRequest, GetLivestreamAnalyticsCompleteLivestreamResponse, GetLivestreamAnalyticsCompleteLivestreamError, CloudflareOpContext>;
export type GetLivestreamAnalyticsDaywiseLivestreamError = CloudflareOpError;
/** Returns day-wise livestream analytics for the specified time range. */
export declare const getLivestreamAnalyticsDaywiseLivestream: API.OperationMethod<GetLivestreamAnalyticsDaywiseLivestreamRequest, GetLivestreamAnalyticsDaywiseLivestreamResponse, GetLivestreamAnalyticsDaywiseLivestreamError, CloudflareOpContext>;
export type GetLivestreamSessionDetailsForMeetingError = CloudflareOpError;
/** Returns livestream session details for the given meeting ID. Retreive the meeting ID using the `Create a meeting` API. */
export declare const getLivestreamSessionDetailsForMeeting: API.OperationMethod<GetLivestreamSessionDetailsForMeetingRequest, GetLivestreamSessionDetailsForMeetingResponse, GetLivestreamSessionDetailsForMeetingError, CloudflareOpContext>;
export type GetLivestreamSessionDetailsForSessionIdLivestreamError = CloudflareOpError;
/** Returns livestream session details for the given livestream session ID. Retrieve the `livestream_session_id`using the `Fetch livestream session details using a session ID` API. */
export declare const getLivestreamSessionDetailsForSessionIdLivestream: API.OperationMethod<GetLivestreamSessionDetailsForSessionIdLivestreamRequest, GetLivestreamSessionDetailsForSessionIdLivestreamResponse, GetLivestreamSessionDetailsForSessionIdLivestreamError, CloudflareOpContext>;
export type GetLivestreamSessionForLivestreamIdLivestreamError = CloudflareOpError;
/** Returns details of a livestream with sessions for the given livestream ID. Retreive the livestream ID using the `Start livestreaming a meeting` API. */
export declare const getLivestreamSessionForLivestreamIdLivestream: API.OperationMethod<GetLivestreamSessionForLivestreamIdLivestreamRequest, GetLivestreamSessionForLivestreamIdLivestreamResponse, GetLivestreamSessionForLivestreamIdLivestreamError, CloudflareOpContext>;
export type GetLivestreamSessionsForSessionError = CloudflareOpError;
/** Returns livestream session details for the given session ID. Retreive the session ID using the `Fetch all sessions of an App` API. */
export declare const getLivestreamSessionsForSession: API.OperationMethod<GetLivestreamSessionsForSessionRequest, GetLivestreamSessionsForSessionResponse, GetLivestreamSessionsForSessionError, CloudflareOpContext>;
export type GetMeetingError = CloudflareOpError;
/** Returns all meetings for the given App ID. */
export declare const getMeeting: API.OperationMethod<GetMeetingRequest, GetMeetingResponse, GetMeetingError, CloudflareOpContext>;
export type GetMeetingActiveLivestreamsLivestreamError = CloudflareOpError;
/** Returns details of all active livestreams for the given meeting ID. */
export declare const getMeetingActiveLivestreamsLivestream: API.OperationMethod<GetMeetingActiveLivestreamsLivestreamRequest, GetMeetingActiveLivestreamsLivestreamResponse, GetMeetingActiveLivestreamsLivestreamError, CloudflareOpContext>;
export type GetMeetingByIdMeetingError = CloudflareOpError;
/** Returns a meeting details in an App for the given meeting ID. */
export declare const getMeetingByIdMeeting: API.OperationMethod<GetMeetingByIdMeetingRequest, GetMeetingByIdMeetingResponse, GetMeetingByIdMeetingError, CloudflareOpContext>;
export type GetMeetingParticipantMeetingError = CloudflareOpError;
/** Returns a participant details for the given meeting and participant ID. */
export declare const getMeetingParticipantMeeting: API.OperationMethod<GetMeetingParticipantMeetingRequest, GetMeetingParticipantMeetingResponse, GetMeetingParticipantMeetingError, CloudflareOpContext>;
export type GetMeetingParticipantsMeetingError = CloudflareOpError;
/** Returns all participants detail for the given meeting ID. */
export declare const getMeetingParticipantsMeeting: API.OperationMethod<GetMeetingParticipantsMeetingRequest, GetMeetingParticipantsMeetingResponse, GetMeetingParticipantsMeetingError, CloudflareOpContext>;
export type GetOneRecordingRecordingError = CloudflareOpError;
/** Returns details of a recording for the given recording ID. */
export declare const getOneRecordingRecording: API.OperationMethod<GetOneRecordingRecordingRequest, GetOneRecordingRecordingResponse, GetOneRecordingRecordingError, CloudflareOpContext>;
export type GetOrgAnalyticsAnalyticError = CloudflareOpError;
/** Returns day-wise session and recording analytics data of an App for the specified time range start_date to end_date. If start_date and end_date are not provided, the default time range is set from 30 days ago to the current date. */
export declare const getOrgAnalyticsAnalytic: API.OperationMethod<GetOrgAnalyticsAnalyticRequest, GetOrgAnalyticsAnalyticResponse, GetOrgAnalyticsAnalyticError, CloudflareOpContext>;
export type GetParticipantDataFromPeerIdSessionError = CloudflareOpError;
/** Returns participant details for the given peer ID along with call statistics. */
export declare const getParticipantDataFromPeerIdSession: API.OperationMethod<GetParticipantDataFromPeerIdSessionRequest, GetParticipantDataFromPeerIdSessionResponse, GetParticipantDataFromPeerIdSessionError, CloudflareOpContext>;
export type GetPresetError = Forbidden | CloudflareOpError;
/** Fetches all the presets belonging to an App. */
export declare const getPreset: API.OperationMethod<GetPresetRequest, GetPresetResponse, GetPresetError, CloudflareOpContext>;
export type GetPresetByIdPresetError = RealtimeKitPresetNotFound | Forbidden | CloudflareOpError;
/** Fetches details of a preset using the provided preset ID */
export declare const getPresetByIdPreset: API.OperationMethod<GetPresetByIdPresetRequest, GetPresetByIdPresetResponse, GetPresetByIdPresetError, CloudflareOpContext>;
export type GetRecordingsRecordingError = CloudflareOpError;
/** Returns all recordings for an App. If the `meeting_id` parameter is passed, returns all recordings for the given meeting ID. */
export declare const getRecordingsRecording: API.OperationMethod<GetRecordingsRecordingRequest, GetRecordingsRecordingResponse, GetRecordingsRecordingError, CloudflareOpContext>;
export type GetSessionChatSessionError = CloudflareOpError;
/** Returns a URL to download all chat messages of the session ID in CSV format. */
export declare const getSessionChatSession: API.OperationMethod<GetSessionChatSessionRequest, GetSessionChatSessionResponse, GetSessionChatSessionError, CloudflareOpContext>;
export type GetSessionDetailsSessionError = CloudflareOpError;
/** Returns data of the given session ID including recording details. */
export declare const getSessionDetailsSession: API.OperationMethod<GetSessionDetailsSessionRequest, GetSessionDetailsSessionResponse, GetSessionDetailsSessionError, CloudflareOpContext>;
export type GetSessionParticipantDetailsSessionError = CloudflareOpError;
/** Returns details of the given participant ID for the given session ID. Use the peer report endpoint to retrieve call statistics. */
export declare const getSessionParticipantDetailsSession: API.OperationMethod<GetSessionParticipantDetailsSessionRequest, GetSessionParticipantDetailsSessionResponse, GetSessionParticipantDetailsSessionError, CloudflareOpContext>;
export type GetSessionParticipantsSessionError = CloudflareOpError;
/** Returns a list of participants for the given session ID. */
export declare const getSessionParticipantsSession: API.OperationMethod<GetSessionParticipantsSessionRequest, GetSessionParticipantsSessionResponse, GetSessionParticipantsSessionError, CloudflareOpContext>;
export type GetSessionsSessionError = CloudflareOpError;
/** Returns details of all sessions of an App. */
export declare const getSessionsSession: API.OperationMethod<GetSessionsSessionRequest, GetSessionsSessionResponse, GetSessionsSessionError, CloudflareOpContext>;
export type GetSessionSummarySessionError = CloudflareOpError;
/** Returns a Summary URL to download the Summary of Transcripts for the session ID as plain text. */
export declare const getSessionSummarySession: API.OperationMethod<GetSessionSummarySessionRequest, GetSessionSummarySessionResponse, GetSessionSummarySessionError, CloudflareOpContext>;
export type GetSessionTranscriptsSessionError = CloudflareOpError;
/** Returns a URL to download the transcript for the session ID in CSV format. */
export declare const getSessionTranscriptsSession: API.OperationMethod<GetSessionTranscriptsSessionRequest, GetSessionTranscriptsSessionResponse, GetSessionTranscriptsSessionError, CloudflareOpContext>;
export type GetWebhookByIdWebhookError = RealtimeKitWebhookNotFound | Forbidden | CloudflareOpError;
/** Returns webhook details for the given webhook ID. */
export declare const getWebhookByIdWebhook: API.OperationMethod<GetWebhookByIdWebhookRequest, GetWebhookByIdWebhookResponse, GetWebhookByIdWebhookError, CloudflareOpContext>;
export type GetWebhooksWebhookError = RealtimeKitWebhookNotFound | Forbidden | CloudflareOpError;
/** Returns details of all webhooks for an App. */
export declare const getWebhooksWebhook: API.OperationMethod<GetWebhooksWebhookRequest, GetWebhooksWebhookResponse, GetWebhooksWebhookError, CloudflareOpContext>;
export type KickAllParticipantsActiveSessionError = CloudflareOpError;
/** Kicks all participants from an active session for the given meeting ID. */
export declare const kickAllParticipantsActiveSession: API.OperationMethod<KickAllParticipantsActiveSessionRequest, KickAllParticipantsActiveSessionResponse, KickAllParticipantsActiveSessionError, CloudflareOpContext>;
export type KickParticipantsActiveSessionError = CloudflareOpError;
/** Kicks one or more participants from an active session using user ID or custom participant ID. */
export declare const kickParticipantsActiveSession: API.OperationMethod<KickParticipantsActiveSessionRequest, KickParticipantsActiveSessionResponse, KickParticipantsActiveSessionError, CloudflareOpContext>;
export type LivestreamsGetOrgAnalyticsError = CloudflareOpError;
/** Returns day-wise session and recording analytics data of an App for the specified time range start_date to end_date. If start_date and end_date are not provided, the default time range is set from 30 days ago to the current date. */
export declare const livestreamsGetOrgAnalytics: API.OperationMethod<LivestreamsGetOrgAnalyticsRequest, LivestreamsGetOrgAnalyticsResponse, LivestreamsGetOrgAnalyticsError, CloudflareOpContext>;
export type MeetingsReplaceParticipantError = CloudflareOpError;
/** Replaces a participant's details for the given meeting and participant ID. */
export declare const meetingsReplaceParticipant: API.OperationMethod<MeetingsReplaceParticipantRequest, MeetingsReplaceParticipantResponse, MeetingsReplaceParticipantError, CloudflareOpContext>;
export type MeetingsRevokeParticipantTokenError = CloudflareOpError;
/** Revokes a previously issued participant authentication token without deleting the participant. Other tokens issued to the participant remain valid. */
export declare const meetingsRevokeParticipantToken: API.OperationMethod<MeetingsRevokeParticipantTokenRequest, MeetingsRevokeParticipantTokenResponse, MeetingsRevokeParticipantTokenError, CloudflareOpContext>;
export type PatchPresetError = RealtimeKitPresetNotFound | Forbidden | CloudflareOpError;
/** Update a preset by the provided preset ID */
export declare const patchPreset: API.OperationMethod<PatchPresetRequest, PatchPresetResponse, PatchPresetError, CloudflareOpContext>;
export type PauseResumeStopRecordingRecordingError = CloudflareOpError;
/** Pause/Resume/Stop a given recording ID. */
export declare const pauseResumeStopRecordingRecording: API.OperationMethod<PauseResumeStopRecordingRecordingRequest, PauseResumeStopRecordingRecordingResponse, PauseResumeStopRecordingRecordingError, CloudflareOpContext>;
export type PostAppError = Forbidden | CloudflareOpError;
/** Create new app for your account */
export declare const postApp: API.OperationMethod<PostAppRequest, PostAppResponse, PostAppError, CloudflareOpContext>;
export type RefreshParticipantTokenMeetingError = CloudflareOpError;
/** Regenerates participant's authentication token for the given meeting and participant ID. */
export declare const refreshParticipantTokenMeeting: API.OperationMethod<RefreshParticipantTokenMeetingRequest, RefreshParticipantTokenMeetingResponse, RefreshParticipantTokenMeetingError, CloudflareOpContext>;
export type ReplaceMeetingByIdMeetingError = CloudflareOpError;
/** Replaces all the details for the given meeting ID. */
export declare const replaceMeetingByIdMeeting: API.OperationMethod<ReplaceMeetingByIdMeetingRequest, ReplaceMeetingByIdMeetingResponse, ReplaceMeetingByIdMeetingError, CloudflareOpContext>;
export type ReplacePresetByIdError = CloudflareOpError;
/** Replace all details for the preset using the provided preset ID. */
export declare const replacePresetById: API.OperationMethod<ReplacePresetByIdRequest, ReplacePresetByIdResponse, ReplacePresetByIdError, CloudflareOpContext>;
export type ReplaceWebhookWebhookError = RealtimeKitWebhookNotFound | Forbidden | CloudflareOpError;
/** Replace all details for the given webhook ID. */
export declare const replaceWebhookWebhook: API.OperationMethod<ReplaceWebhookWebhookRequest, ReplaceWebhookWebhookResponse, ReplaceWebhookWebhookError, CloudflareOpContext>;
export type StartLivestreamingAMeetingLivestreamError = CloudflareOpError;
/** Starts livestream of a meeting associated with the given meeting ID. Retreive the meeting ID using the `Create a meeting` API. */
export declare const startLivestreamingAMeetingLivestream: API.OperationMethod<StartLivestreamingAMeetingLivestreamRequest, StartLivestreamingAMeetingLivestreamResponse, StartLivestreamingAMeetingLivestreamError, CloudflareOpContext>;
export type StartRecordingsRecordingError = CloudflareOpError;
/** Starts recording a meeting. The meeting can be started by an App admin directly, or a participant with permissions to start a recording, based on the type of authorization used. */
export declare const startRecordingsRecording: API.OperationMethod<StartRecordingsRecordingRequest, StartRecordingsRecordingResponse, StartRecordingsRecordingError, CloudflareOpContext>;
export type StartTrackRecordingRecordingError = CloudflareOpError;
/** Starts track recording for a meeting. Track recording currently records separate participant audio tracks as WebM files in the RealtimeKit bucket. Video track recording is in development. For more information, refer to [Track recording](https://developers.cloudflare.com/realtime/realtimekit/recording-guide/track-recording/). */
export declare const startTrackRecordingRecording: API.OperationMethod<StartTrackRecordingRecordingRequest, StartTrackRecordingRecordingResponse, StartTrackRecordingRecordingError, CloudflareOpContext>;
export type StopLivestreamingAMeetingLivestreamError = CloudflareOpError;
/** Stops the active livestream of a meeting associated with the given meeting ID. Retreive the meeting ID using the `Create a meeting` API. */
export declare const stopLivestreamingAMeetingLivestream: API.OperationMethod<StopLivestreamingAMeetingLivestreamRequest, StopLivestreamingAMeetingLivestreamResponse, StopLivestreamingAMeetingLivestreamError, CloudflareOpContext>;
export type UpdateAppByIdError = CloudflareOpError;
/** Update the name of an app in your account. */
export declare const updateAppById: API.OperationMethod<UpdateAppByIdRequest, UpdateAppByIdResponse, UpdateAppByIdError, CloudflareOpContext>;
export type UpdateMeetingByIdMeetingError = CloudflareOpError;
/** Updates a meeting in an App for the given meeting ID. */
export declare const updateMeetingByIdMeeting: API.OperationMethod<UpdateMeetingByIdMeetingRequest, UpdateMeetingByIdMeetingResponse, UpdateMeetingByIdMeetingError, CloudflareOpContext>;
export type WebhooksGetAllWebhooksError = CloudflareOpError;
/** Returns the list of webhook event names supported by RealtimeKit. */
export declare const webhooksGetAllWebhooks: API.OperationMethod<WebhooksGetAllWebhooksRequest, WebhooksGetAllWebhooksResponse, WebhooksGetAllWebhooksError, CloudflareOpContext>;
export declare const getOrgAnalyticsLivestream: API.OperationMethod<GetOrgAnalyticsAnalyticRequest, GetOrgAnalyticsAnalyticResponse, CloudflareOpError, CloudflareOpContext>;
export type GetOrgAnalyticsLivestreamRequest = GetOrgAnalyticsAnalyticRequest;
export type GetOrgAnalyticsLivestreamResponse = GetOrgAnalyticsAnalyticResponse;
export type GetOrgAnalyticsLivestreamError = GetOrgAnalyticsAnalyticError;
//# sourceMappingURL=realtime_kit.d.ts.map