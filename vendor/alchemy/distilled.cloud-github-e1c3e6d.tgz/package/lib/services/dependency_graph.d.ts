import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CreateRepositorySnapshotRequestJob {
    /** The external ID of the job. */
    id: string;
    /** Correlator provides a key that is used to group snapshots submitted over time. Only the "latest" submitted snapshot for a given combination of `job.correlator` and `detector.name` will be considered when calculating a repository's current dependencies. Correlator should be as unique as it takes to distinguish all detection runs for a given "wave" of CI workflow you run. If you're using GitHub Actions, a good default value for this could be the environment variables GITHUB_WORKFLOW and GITHUB_JOB concatenated together. If you're using a build matrix, then you'll also need to add additional key(s) to distinguish between each submission inside a matrix variation. */
    correlator: string;
    /** The url for the job. */
    html_url?: string | undefined;
}
/** A description of the detector used. */
export interface CreateRepositorySnapshotRequestDetector {
    /** The name of the detector used. */
    name: string;
    /** The version of the detector used. */
    version: string;
    /** The url of the detector used. */
    url: string;
}
export type MetadataValue = string | number | boolean;
/** User-defined metadata to store domain-specific information limited to 8 keys with scalar values. */
export type Metadata = {
    [key: string]: MetadataValue | null | undefined;
};
export interface ManifestFile {
    /** The path of the manifest file relative to the root of the Git repository. */
    source_location?: string | undefined;
}
/** A notation of whether a dependency is requested directly by this manifest or is a dependency of another dependency. */
export type DependencyRelationship = "direct" | "indirect";
/** A notation of whether the dependency is required for the primary build artifact (runtime) or is only used for development. Future versions of this specification may allow for more granular scopes. */
export type DependencyScope = "runtime" | "development";
/** Array of package-url (PURLs) of direct child dependencies. */
export type DependencyDependenciesList = Array<string>;
export interface Dependency {
    /** Package-url (PURL) of dependency. See https://github.com/package-url/purl-spec for more details. */
    package_url?: string | undefined;
    metadata?: Metadata | undefined;
    /** A notation of whether a dependency is requested directly by this manifest or is a dependency of another dependency. */
    relationship?: DependencyRelationship | (string & {}) | undefined;
    /** A notation of whether the dependency is required for the primary build artifact (runtime) or is only used for development. Future versions of this specification may allow for more granular scopes. */
    scope?: DependencyScope | (string & {}) | undefined;
    /** Array of package-url (PURLs) of direct child dependencies. */
    dependencies?: DependencyDependenciesList | undefined;
}
/** A collection of resolved package dependencies. */
export type ManifestResolvedMap = {
    [key: string]: Dependency | undefined;
};
export interface Manifest {
    /** The name of the manifest. */
    name: string;
    file?: ManifestFile | undefined;
    metadata?: Metadata | undefined;
    /** A collection of resolved package dependencies. */
    resolved?: ManifestResolvedMap | undefined;
}
/** A collection of package manifests, which are a collection of related dependencies declared in a file or representing a logical group of dependencies. */
export type CreateRepositorySnapshotRequestManifestsMap = {
    [key: string]: Manifest | undefined;
};
export interface CreateRepositorySnapshotRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The version of the repository snapshot submission. */
    version: number;
    job: CreateRepositorySnapshotRequestJob;
    /** The commit SHA associated with this dependency snapshot. Maximum length: 64 characters. */
    sha: string;
    /** The repository branch that triggered this snapshot. */
    ref: string;
    /** A description of the detector used. */
    detector: CreateRepositorySnapshotRequestDetector;
    metadata?: Metadata | undefined;
    /** A collection of package manifests, which are a collection of related dependencies declared in a file or representing a logical group of dependencies. */
    manifests?: CreateRepositorySnapshotRequestManifestsMap | undefined;
    /** The time at which the snapshot was scanned. */
    scanned: string;
}
export interface CreateRepositorySnapshotResponse {
    /** ID of the created snapshot. */
    id: number;
    /** The time at which the snapshot was created. */
    created_at: string;
    /** Either "SUCCESS", "ACCEPTED", or "INVALID". "SUCCESS" indicates that the snapshot was successfully created and the repository's dependencies were updated. "ACCEPTED" indicates that the snapshot was successfully created, but the repository's dependencies were not updated. "INVALID" indicates that the snapshot was malformed. */
    result: string;
    /** A message providing further details about the result, such as why the dependencies were not updated. */
    message: string;
}
export interface DiffRangeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The base and head Git revisions to compare. The Git revisions will be resolved to commit SHAs. Named revisions will be resolved to their corresponding HEAD commits, and an appropriate merge base will be determined. This parameter expects the format `{base}...{head}`. */
    basehead: string;
    /** The full path, relative to the repository root, of the dependency manifest file. */
    name?: string | undefined;
}
export type DependencyGraphDiffItemChangeType = "added" | "removed";
export interface DependencyGraphDiffItemVulnerabilitiesItem {
    severity: string;
    advisory_ghsa_id: string;
    advisory_summary: string;
    advisory_url: string;
}
export type DependencyGraphDiffItemVulnerabilitiesList = Array<DependencyGraphDiffItemVulnerabilitiesItem>;
/** Where the dependency is utilized. `development` means that the dependency is only utilized in the development environment. `runtime` means that the dependency is utilized at runtime and in the development environment. */
export type DependencyGraphDiffItemScope = "unknown" | "runtime" | "development";
export interface DependencyGraphDiffItem {
    change_type: DependencyGraphDiffItemChangeType;
    manifest: string;
    ecosystem: string;
    name: string;
    version: string;
    package_url: string | null;
    license: string | null;
    source_repository_url: string | null;
    vulnerabilities: DependencyGraphDiffItemVulnerabilitiesList;
    /** Where the dependency is utilized. `development` means that the dependency is only utilized in the development environment. `runtime` means that the dependency is utilized at runtime and in the development environment. */
    scope: DependencyGraphDiffItemScope;
}
/** A diff of the dependencies between two commits. */
export type DependencyGraphDiff = Array<DependencyGraphDiffItem>;
export type DiffRangeResponse = DependencyGraphDiff;
export interface FetchSbomReportRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the SBOM export. */
    sbom_uuid: string;
}
export interface FetchSbomReportResponse {
}
export interface GenerateSbomReportRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GenerateSbomReportResponse {
    /** URL to poll for the SBOM export result. */
    sbom_url?: string | undefined;
}
export type CreateRepositorySnapshotError = GithubOpError;
/** Create a snapshot of dependencies for a repository Create a new snapshot of a repository's dependencies. The authenticated user must have access to the repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRepositorySnapshot: API.OperationMethod<CreateRepositorySnapshotRequest, CreateRepositorySnapshotResponse, CreateRepositorySnapshotError, GithubOpContext>;
export type DiffRangeError = GithubOpError;
/** Get a diff of the dependencies between commits Gets the diff of the dependency changes between two commits of a repository, based on the changes to the dependency manifests made in those commits. */
export declare const diffRange: API.OperationMethod<DiffRangeRequest, DiffRangeResponse, DiffRangeError, GithubOpContext>;
export type FetchSbomReportError = GithubOpError;
/** Fetch a software bill of materials (SBOM) for a repository. Fetches a previously generated software bill of materials (SBOM) for a repository. When the SBOM is ready, the response is a 302 redirect to a temporary download URL for the SBOM in SPDX JSON format. The generated SBOM report may be retained for up to one week from the original request. The temporary download URL returned by this endpoint expires separately, and its expiry is set when the fetch request is made. */
export declare const fetchSbomReport: API.OperationMethod<FetchSbomReportRequest, FetchSbomReportResponse, FetchSbomReportError, GithubOpContext>;
export type GenerateSbomReportError = GithubOpError;
/** Request generation of a software bill of materials (SBOM) for a repository. Triggers a job to generate a software bill of materials (SBOM) for a repository in SPDX JSON format. */
export declare const generateSbomReport: API.OperationMethod<GenerateSbomReportRequest, GenerateSbomReportResponse, GenerateSbomReportError, GithubOpContext>;
//# sourceMappingURL=dependency_graph.d.ts.map