import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as Redacted from "effect/Redacted";
import { Credentials } from "./Credentials.ts";
import type * as GitHub from "./Providers.ts";
export interface PersonalAccessTokenProps {
    /**
     * The token to capture. Defaults to the provider's credential (the token
     * `alchemy login` or `GITHUB_TOKEN` resolves).
     */
    token?: Redacted.Redacted<string>;
}
export interface PersonalAccessToken extends Resource<"GitHub.PersonalAccessToken", PersonalAccessTokenProps, {
    /** The token value. Yield it inside a host to bind it into the host's environment. */
    value: Redacted.Redacted<string>;
    /** REST API base URL the token authenticates against. */
    apiUrl: string;
    /** The login the token authenticates as. */
    login: string;
}, never, GitHub.Providers> {
}
/**
 * A GitHub token captured as a resource, so a Worker or Function can
 * authenticate with it at runtime.
 *
 * GitHub has no API to mint personal access tokens, so this resource does not
 * create one. It captures a token (the `token` prop, or the provider's
 * credential by default), validates it, and stores it in state. The `GitHub.*Http`
 * binding layers capture one per host and bind its `value` into the host.
 * Deleting the resource only forgets the token; revoking it stays a manual step.
 *
 * ### Capturing a Token
 * **Example:** The provider's credential
 * ```typescript
 * const token = yield* GitHub.PersonalAccessToken("BotToken");
 * ```
 *
 * **Example:** An explicit token
 * ```typescript
 * const token = yield* GitHub.PersonalAccessToken("BotToken", {
 *   token: Redacted.make(process.env.BOT_GITHUB_TOKEN!),
 * });
 * ```
 *
 * @resource
 * @product Repository
 */
export declare const PersonalAccessToken: import("alchemy/Resource").ResourceClass<PersonalAccessToken>;
export declare const PersonalAccessTokenProvider: () => import("effect/Layer").Layer<Provider.Provider<PersonalAccessToken>, never, Credentials | import("effect/http/HttpClient").HttpClient>;
//# sourceMappingURL=PersonalAccessToken.d.ts.map