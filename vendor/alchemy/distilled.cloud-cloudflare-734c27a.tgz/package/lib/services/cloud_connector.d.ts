import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CloudConnectorRulesNotFound_base: S.TaggedErrorClass<"CloudConnectorRulesNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class CloudConnectorRulesNotFound extends /*@__PURE__*/ CloudConnectorRulesNotFound_base {
}
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
}
export interface RulesListResultItemParameters {
    /** Host to perform Cloud Connection to */
    host?: string | null | undefined;
}
export type RulesListResultItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage" | "oci_storage";
export interface RulesListResultItem {
    id?: string | null | undefined;
    description?: string | null | undefined;
    enabled?: boolean | null | undefined;
    expression?: string | null | undefined;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesListResultItemParameters | null | undefined;
    /** Cloud Provider type */
    provider?: RulesListResultItemProvider | null | undefined;
}
export type RulesListResultList = Array<RulesListResultItem>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface RulesUpdateRequestRulesItemParameters {
    /** Host to perform Cloud Connection to */
    host?: string | undefined;
}
export type RulesUpdateRequestRulesItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage" | "oci_storage";
export interface RulesUpdateRequestRulesItem {
    id?: string | undefined;
    description?: string | undefined;
    enabled?: boolean | undefined;
    expression?: string | undefined;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesUpdateRequestRulesItemParameters | undefined;
    /** Cloud Provider type */
    provider?: RulesUpdateRequestRulesItemProvider | (string & {}) | undefined;
}
export type RulesUpdateRequestRulesList = Array<RulesUpdateRequestRulesItem>;
export interface PutRuleRequest {
    /** Identifier. */
    zoneId: string;
    rules?: RulesUpdateRequestRulesList | undefined;
}
export type RulesUpdateResultItemParameters = RulesListResultItemParameters;
export type RulesUpdateResultItemProvider = "aws_s3" | "cloudflare_r2" | "gcp_storage" | "azure_storage" | "oci_storage";
export interface RulesUpdateResultItem {
    id?: string | null | undefined;
    description?: string | null | undefined;
    enabled?: boolean | null | undefined;
    expression?: string | null | undefined;
    /** Parameters of Cloud Connector Rule */
    parameters?: RulesListResultItemParameters | null | undefined;
    /** Cloud Provider type */
    provider?: RulesUpdateResultItemProvider | null | undefined;
}
export type RulesUpdateResultList = Array<RulesUpdateResultItem>;
export interface PutRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type ListRulesError = Forbidden | CloudConnectorRulesNotFound | CloudflareOpError;
/** Retrieves the Cloud Connector rules configured for a zone. Rules define how traffic is routed to cloud services. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type PutRuleError = Forbidden | CloudflareOpError;
/** Updates Cloud Connector rules for a zone, replacing the existing rule configuration. */
export declare const putRule: API.PaginatedOperationMethod<PutRuleRequest, PutRuleResponse, PutRuleError, CloudflareOpContext, RulesUpdateResultItem>;
//# sourceMappingURL=cloud_connector.d.ts.map