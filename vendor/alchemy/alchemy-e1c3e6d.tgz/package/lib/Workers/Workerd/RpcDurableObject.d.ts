/**
 * The server half of `RpcDurableObject`, shared by every engine whose
 * objects follow the Workers API (Cloudflare today).
 *
 * @internal
 */
import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type { RpcGroup } from "effect/rpc";
import * as RpcWebSocket from "./RpcWebSocket.ts";
/**
 * Wrap an `RpcDurableObject` implementation: an inner Effect returning a
 * handlers Layer becomes the object's RPC server — HTTP for plain requests,
 * the hibernatable WebSocket transport for upgrades. Any other value is
 * served as the object's `fetch`.
 */
export declare const wrapRpcDurableObjectImpl: <I>(State: Context.Key<I, RpcWebSocket.RpcWebSocketState>, impl: Effect.Effect<Effect.Effect<any>>, schema: RpcGroup.RpcGroup<any>) => Effect.Effect<Effect.Effect<any>>;
//# sourceMappingURL=RpcDurableObject.d.ts.map