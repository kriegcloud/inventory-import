import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetRequest {
    license: string;
}
export type LicensePermissionsList = Array<string>;
export type LicenseConditionsList = Array<string>;
export type LicenseLimitationsList = Array<string>;
/** License */
export interface License {
    key: string;
    name: string;
    spdx_id: string | null;
    url: string | null;
    node_id: string;
    html_url: string;
    description: string;
    implementation: string;
    permissions: LicensePermissionsList;
    conditions: LicenseConditionsList;
    limitations: LicenseLimitationsList;
    body: string;
    featured: boolean;
}
export interface GetAllCommonlyUsedRequest {
    featured?: boolean | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** License Simple */
export interface LicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export type GetAllCommonlyUsedResponseBodyList = Array<LicenseSimple>;
export type GetAllCommonlyUsedResponse = GetAllCommonlyUsedResponseBodyList;
export interface GetForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
}
export interface LicenseContentLinks {
    git: string | null;
    html: string | null;
    self: string;
}
/** License Simple */
export type NullableLicenseSimple = LicenseSimple;
/** License Content */
export interface LicenseContent {
    name: string;
    path: string;
    sha: string;
    size: number;
    url: string;
    html_url: string | null;
    git_url: string | null;
    download_url: string | null;
    type: string;
    content: string;
    encoding: string;
    _links: LicenseContentLinks;
    license: LicenseSimple | null;
}
export type GetError = GithubOpError;
/** Get a license Gets information about a specific license. For more information, see "[Licensing a repository ](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)." */
export declare const get: API.OperationMethod<GetRequest, License, GetError, GithubOpContext>;
export type GetAllCommonlyUsedError = GithubOpError;
/** Get all commonly used licenses Lists the most commonly used licenses on GitHub. For more information, see "[Licensing a repository ](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)." */
export declare const getAllCommonlyUsed: API.PaginatedOperationMethod<GetAllCommonlyUsedRequest, GetAllCommonlyUsedResponse, GetAllCommonlyUsedError, GithubOpContext, LicenseSimple>;
export type GetForRepoError = GithubOpError;
/** Get the license for a repository This method returns the contents of the repository's license file, if one is detected. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw contents of the license. - **`application/vnd.github.html+json`**: Returns the license contents in HTML. Markup languages are rendered to HTML using GitHub's open-source [Markup library](https://github.com/github/markup). */
export declare const getForRepo: API.OperationMethod<GetForRepoRequest, LicenseContent, GetForRepoError, GithubOpContext>;
//# sourceMappingURL=licenses.d.ts.map