/**
 * The `com.distilled.telemetry#service` trait's `hosts`: facts for requests
 * to S3-compatible hosts such as Cloudflare R2. Generated code imports this
 * only where a trait has one (S3). See
 * `packages/dev/src/codegen/telemetry-traits.md`.
 */
import type { RequestHook } from "./telemetry.ts";
/** Facts for requests to a host ending in `suffix`. */
export interface HostRule {
    /** Host suffix, with its leading dot (`.r2.cloudflarestorage.com`). */
    readonly suffix: string;
    readonly attributes?: Readonly<Record<string, string | number | boolean>>;
    /** Attribute that gets the host label just before the suffix (the account id). */
    readonly hostLabel?: string;
    /** Attribute values copied under a second name: `{ "aws.s3.bucket": "cloudflare.r2.bucket" }`. */
    readonly copy?: Readonly<Record<string, string>>;
}
/**
 * Facts recorded when a request goes to a matching host: an S3-compatible
 * service such as Cloudflare R2 reached through the S3 SDK.
 */
export declare const hostRules: (rules: ReadonlyArray<HostRule>) => RequestHook;
//# sourceMappingURL=telemetry-host-rules.d.ts.map