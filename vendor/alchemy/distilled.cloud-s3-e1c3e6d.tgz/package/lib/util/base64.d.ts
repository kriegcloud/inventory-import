/** Base64-encode bytes without blowing the stack on large payloads. */
export declare const toBase64: (bytes: Uint8Array) => string;
/** The bytes of a base64 string. */
export declare const fromBase64: (base64: string) => Uint8Array;
//# sourceMappingURL=base64.d.ts.map