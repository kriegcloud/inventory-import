/**
 * An endpoint override: the base URL every operation is sent to, in place of
 * the one the endpoint rules resolve (`https://<account>.r2.cloudflarestorage.com`
 * for Cloudflare R2, `http://localhost:9000` for MinIO).
 */
import * as Context from "effect/Context";
import type * as Effect from "effect/Effect";
import type { ProviderError } from "./credentials.ts";
declare const EndpointService: Context.ServiceClass<Endpoint, "AWS::Endpoint", Effect.Effect<string | undefined, ProviderError>>;
export declare class Endpoint extends EndpointService {
}
export {};
//# sourceMappingURL=endpoint.d.ts.map