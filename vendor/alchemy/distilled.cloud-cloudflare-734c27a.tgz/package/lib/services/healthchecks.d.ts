import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HealthcheckAlreadyExists_base: S.TaggedErrorClass<"HealthcheckAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class HealthcheckAlreadyExists extends /*@__PURE__*/ HealthcheckAlreadyExists_base {
}
declare const HealthcheckNotFound_base: S.TaggedErrorClass<"HealthcheckNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class HealthcheckNotFound extends /*@__PURE__*/ HealthcheckNotFound_base {
}
export type CreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateRequestCheckRegionsList = Array<CreateRequestCheckRegionsItem | (string & {})>;
export type CreateRequestHttpConfigExpectedCodesList = Array<string>;
export type CreateRequestHttpConfigHeaderValueList = Array<string>;
export type CreateRequestHttpConfigHeaderMap = {
    [key: string]: CreateRequestHttpConfigHeaderValueList | undefined;
};
export type CreateRequestHttpConfigMethod = "GET" | "HEAD";
export interface CreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: CreateRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type CreateRequestTcpConfigMethod = "connection_established";
export interface CreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface CreateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type CreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateResponseCheckRegionsList = Array<CreateResponseCheckRegionsItem>;
export type CreateResponseHttpConfigExpectedCodesList = Array<string>;
export type CreateResponseHttpConfigHeaderValueList = Array<string>;
export type CreateResponseHttpConfigHeaderMap = {
    [key: string]: CreateResponseHttpConfigHeaderValueList | undefined;
};
export type CreateResponseHttpConfigMethod = "GET" | "HEAD";
export interface CreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: CreateResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type CreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type CreateResponseTcpConfigMethod = "connection_established";
export interface CreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateHealthcheckResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: CreateResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type PreviewsCreateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsCreateRequestCheckRegionsList = Array<PreviewsCreateRequestCheckRegionsItem | (string & {})>;
export type PreviewsCreateRequestHttpConfigExpectedCodesList = Array<string>;
export type PreviewsCreateRequestHttpConfigHeaderValueList = Array<string>;
export type PreviewsCreateRequestHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateRequestHttpConfigHeaderValueList | undefined;
};
export type PreviewsCreateRequestHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsCreateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type PreviewsCreateRequestTcpConfigMethod = "connection_established";
export interface PreviewsCreateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface CreatePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type PreviewsCreateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsCreateResponseCheckRegionsList = Array<PreviewsCreateResponseCheckRegionsItem>;
export type PreviewsCreateResponseHttpConfigExpectedCodesList = Array<string>;
export type PreviewsCreateResponseHttpConfigHeaderValueList = Array<string>;
export type PreviewsCreateResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsCreateResponseHttpConfigHeaderValueList | undefined;
};
export type PreviewsCreateResponseHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsCreateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsCreateResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsCreateResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: PreviewsCreateResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type PreviewsCreateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type PreviewsCreateResponseTcpConfigMethod = "connection_established";
export interface PreviewsCreateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsCreateResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePreviewResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsCreateResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsCreateResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsCreateResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsCreateResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export interface DeleteHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteHealthcheckResponse {
    /** Identifier */
    id?: string | null | undefined;
}
export interface DeletePreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePreviewResponse {
    /** Identifier */
    id?: string | null | undefined;
}
export interface GetHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export type GetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type GetResponseCheckRegionsList = Array<GetResponseCheckRegionsItem>;
export type GetResponseHttpConfigExpectedCodesList = Array<string>;
export type GetResponseHttpConfigHeaderValueList = Array<string>;
export type GetResponseHttpConfigHeaderMap = {
    [key: string]: GetResponseHttpConfigHeaderValueList | undefined;
};
export type GetResponseHttpConfigMethod = "GET" | "HEAD";
export interface GetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: GetResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type GetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type GetResponseTcpConfigMethod = "connection_established";
export interface GetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetHealthcheckResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: GetResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export interface GetPreviewRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
}
export type PreviewsGetResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type PreviewsGetResponseCheckRegionsList = Array<PreviewsGetResponseCheckRegionsItem>;
export type PreviewsGetResponseHttpConfigExpectedCodesList = Array<string>;
export type PreviewsGetResponseHttpConfigHeaderValueList = Array<string>;
export type PreviewsGetResponseHttpConfigHeaderMap = {
    [key: string]: PreviewsGetResponseHttpConfigHeaderValueList | undefined;
};
export type PreviewsGetResponseHttpConfigMethod = "GET" | "HEAD";
export interface PreviewsGetResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: PreviewsGetResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: PreviewsGetResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: PreviewsGetResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type PreviewsGetResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type PreviewsGetResponseTcpConfigMethod = "connection_established";
export interface PreviewsGetResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: PreviewsGetResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPreviewResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: PreviewsGetResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: PreviewsGetResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: PreviewsGetResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: PreviewsGetResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export interface ListHealthchecksRequest {
    /** Identifier */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number | undefined;
}
export type ListResultItemCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type ListResultItemCheckRegionsList = Array<ListResultItemCheckRegionsItem>;
export type ListResultItemHttpConfigExpectedCodesList = Array<string>;
export type ListResultItemHttpConfigHeaderValueList = Array<string>;
export type ListResultItemHttpConfigHeaderMap = {
    [key: string]: ListResultItemHttpConfigHeaderValueList | undefined;
};
export type ListResultItemHttpConfigMethod = "GET" | "HEAD";
export interface ListResultItemHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: ListResultItemHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: ListResultItemHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: ListResultItemHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type ListResultItemStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type ListResultItemTcpConfigMethod = "connection_established";
export interface ListResultItemTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: ListResultItemTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
export interface ListResultItem {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: ListResultItemCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: ListResultItemHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: ListResultItemStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: ListResultItemTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListHealthchecksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type EditRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditRequestCheckRegionsList = Array<EditRequestCheckRegionsItem | (string & {})>;
export type EditRequestHttpConfigExpectedCodesList = Array<string>;
export type EditRequestHttpConfigHeaderValueList = Array<string>;
export type EditRequestHttpConfigHeaderMap = {
    [key: string]: EditRequestHttpConfigHeaderValueList | undefined;
};
export type EditRequestHttpConfigMethod = "GET" | "HEAD";
export interface EditRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: EditRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type EditRequestTcpConfigMethod = "connection_established";
export interface EditRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface PatchHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type EditResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditResponseCheckRegionsList = Array<EditResponseCheckRegionsItem>;
export type EditResponseHttpConfigExpectedCodesList = Array<string>;
export type EditResponseHttpConfigHeaderValueList = Array<string>;
export type EditResponseHttpConfigHeaderMap = {
    [key: string]: EditResponseHttpConfigHeaderValueList | undefined;
};
export type EditResponseHttpConfigMethod = "GET" | "HEAD";
export interface EditResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: EditResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type EditResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type EditResponseTcpConfigMethod = "connection_established";
export interface EditResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchHealthcheckResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: EditResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type UpdateRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateRequestCheckRegionsList = Array<UpdateRequestCheckRegionsItem | (string & {})>;
export type UpdateRequestHttpConfigExpectedCodesList = Array<string>;
export type UpdateRequestHttpConfigHeaderValueList = Array<string>;
export type UpdateRequestHttpConfigHeaderMap = {
    [key: string]: UpdateRequestHttpConfigHeaderValueList | undefined;
};
export type UpdateRequestHttpConfigMethod = "GET" | "HEAD";
export interface UpdateRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: UpdateRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type UpdateRequestTcpConfigMethod = "connection_established";
export interface UpdateRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface UpdateHealthcheckRequest {
    /** Identifier */
    zoneId: string;
    /** Identifier */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type UpdateResponseCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateResponseCheckRegionsList = Array<UpdateResponseCheckRegionsItem>;
export type UpdateResponseHttpConfigExpectedCodesList = Array<string>;
export type UpdateResponseHttpConfigHeaderValueList = Array<string>;
export type UpdateResponseHttpConfigHeaderMap = {
    [key: string]: UpdateResponseHttpConfigHeaderValueList | undefined;
};
export type UpdateResponseHttpConfigMethod = "GET" | "HEAD";
export interface UpdateResponseHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateResponseHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateResponseHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: UpdateResponseHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type UpdateResponseStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateResponseTcpConfigMethod = "connection_established";
export interface UpdateResponseTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateResponseTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateHealthcheckResponse {
    /** Identifier */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateResponseCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateResponseHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: UpdateResponseStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateResponseTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type CreateHealthcheckError = HealthcheckAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new health check. */
export declare const createHealthcheck: API.OperationMethod<CreateHealthcheckRequest, CreateHealthcheckResponse, CreateHealthcheckError, CloudflareOpContext>;
export type CreatePreviewError = CloudflareOpError;
/** Create a new preview health check. */
export declare const createPreview: API.OperationMethod<CreatePreviewRequest, CreatePreviewResponse, CreatePreviewError, CloudflareOpContext>;
export type DeleteHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthcheck: API.OperationMethod<DeleteHealthcheckRequest, DeleteHealthcheckResponse, DeleteHealthcheckError, CloudflareOpContext>;
export type DeletePreviewError = CloudflareOpError;
/** Delete a health check. */
export declare const deletePreview: API.OperationMethod<DeletePreviewRequest, DeletePreviewResponse, DeletePreviewError, CloudflareOpContext>;
export type GetHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthcheck: API.OperationMethod<GetHealthcheckRequest, GetHealthcheckResponse, GetHealthcheckError, CloudflareOpContext>;
export type GetPreviewError = CloudflareOpError;
/** Fetch a single configured health check preview. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, GetPreviewResponse, GetPreviewError, CloudflareOpContext>;
export type ListHealthchecksError = Forbidden | CloudflareOpError;
/** List configured health checks. */
export declare const listHealthchecks: API.PaginatedOperationMethod<ListHealthchecksRequest, ListHealthchecksResponse, ListHealthchecksError, CloudflareOpContext, ListResultItem>;
export type PatchHealthcheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const patchHealthcheck: API.OperationMethod<PatchHealthcheckRequest, PatchHealthcheckResponse, PatchHealthcheckError, CloudflareOpContext>;
export type UpdateHealthcheckError = HealthcheckNotFound | Forbidden | CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthcheck: API.OperationMethod<UpdateHealthcheckRequest, UpdateHealthcheckResponse, UpdateHealthcheckError, CloudflareOpContext>;
//# sourceMappingURL=healthchecks.d.ts.map