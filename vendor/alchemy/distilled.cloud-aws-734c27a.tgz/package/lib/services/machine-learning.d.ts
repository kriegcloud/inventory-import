import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PredictorNotMountedException_base: S.TaggedErrorClass<"PredictorNotMountedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PredictorNotMountedException extends /*@__PURE__*/ PredictorNotMountedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TagLimitExceededException_base: S.TaggedErrorClass<"TagLimitExceededException", {
    readonly message: any;
}>;
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export type EntityId = string;
export type TaggableResourceType = "BatchPrediction" | "DataSource" | "Evaluation" | "MLModel" | (string & {});
export interface AddTagsInput {
    Tags: Tag[];
    ResourceId: string;
    ResourceType: TaggableResourceType;
}
export interface AddTagsOutput {
    ResourceId?: string | undefined;
    ResourceType?: TaggableResourceType | undefined;
}
export type EntityName = string;
export type S3Url = string;
export interface CreateBatchPredictionInput {
    BatchPredictionId: string;
    BatchPredictionName?: string | undefined;
    MLModelId: string;
    BatchPredictionDataSourceId: string;
    OutputUri: string;
}
export interface CreateBatchPredictionOutput {
    BatchPredictionId?: string | undefined;
}
export type RDSInstanceIdentifier = string;
export type RDSDatabaseName = string;
export interface RDSDatabase {
    InstanceIdentifier: string;
    DatabaseName: string;
}
export type RDSSelectSqlQuery = string;
export type RDSDatabaseUsername = string;
export type RDSDatabasePassword = string | redacted.Redacted<string>;
export interface RDSDatabaseCredentials {
    Username: string;
    Password: string | redacted.Redacted<string>;
}
export type DataRearrangement = string;
export type DataSchema = string;
export type EDPResourceRole = string;
export type EDPServiceRole = string;
export type EDPSubnetId = string;
export type EDPSecurityGroupId = string;
export type EDPSecurityGroupIds = string[];
export interface RDSDataSpec {
    DatabaseInformation: RDSDatabase;
    SelectSqlQuery: string;
    DatabaseCredentials: RDSDatabaseCredentials;
    S3StagingLocation: string;
    DataRearrangement?: string | undefined;
    DataSchema?: string | undefined;
    DataSchemaUri?: string | undefined;
    ResourceRole: string;
    ServiceRole: string;
    SubnetId: string;
    SecurityGroupIds: string[];
}
export type RoleARN = string;
export type ComputeStatistics = boolean;
export interface CreateDataSourceFromRDSInput {
    DataSourceId: string;
    DataSourceName?: string | undefined;
    RDSData: RDSDataSpec;
    RoleARN: string;
    ComputeStatistics?: boolean | undefined;
}
export interface CreateDataSourceFromRDSOutput {
    DataSourceId?: string | undefined;
}
export type RedshiftDatabaseName = string;
export type RedshiftClusterIdentifier = string;
export interface RedshiftDatabase {
    DatabaseName: string;
    ClusterIdentifier: string;
}
export type RedshiftSelectSqlQuery = string;
export type RedshiftDatabaseUsername = string;
export type RedshiftDatabasePassword = string | redacted.Redacted<string>;
export interface RedshiftDatabaseCredentials {
    Username: string;
    Password: string | redacted.Redacted<string>;
}
export interface RedshiftDataSpec {
    DatabaseInformation: RedshiftDatabase;
    SelectSqlQuery: string;
    DatabaseCredentials: RedshiftDatabaseCredentials;
    S3StagingLocation: string;
    DataRearrangement?: string | undefined;
    DataSchema?: string | undefined;
    DataSchemaUri?: string | undefined;
}
export interface CreateDataSourceFromRedshiftInput {
    DataSourceId: string;
    DataSourceName?: string | undefined;
    DataSpec: RedshiftDataSpec;
    RoleARN: string;
    ComputeStatistics?: boolean | undefined;
}
export interface CreateDataSourceFromRedshiftOutput {
    DataSourceId?: string | undefined;
}
export interface S3DataSpec {
    DataLocationS3: string;
    DataRearrangement?: string | undefined;
    DataSchema?: string | undefined;
    DataSchemaLocationS3?: string | undefined;
}
export interface CreateDataSourceFromS3Input {
    DataSourceId: string;
    DataSourceName?: string | undefined;
    DataSpec: S3DataSpec;
    ComputeStatistics?: boolean | undefined;
}
export interface CreateDataSourceFromS3Output {
    DataSourceId?: string | undefined;
}
export interface CreateEvaluationInput {
    EvaluationId: string;
    EvaluationName?: string | undefined;
    MLModelId: string;
    EvaluationDataSourceId: string;
}
export interface CreateEvaluationOutput {
    EvaluationId?: string | undefined;
}
export type MLModelType = "REGRESSION" | "BINARY" | "MULTICLASS" | (string & {});
export type StringType = string;
export type TrainingParameters = {
    [key: string]: string | undefined;
};
export type Recipe = string;
export interface CreateMLModelInput {
    MLModelId: string;
    MLModelName?: string | undefined;
    MLModelType: MLModelType;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    TrainingDataSourceId: string;
    Recipe?: string | undefined;
    RecipeUri?: string | undefined;
}
export interface CreateMLModelOutput {
    MLModelId?: string | undefined;
}
export interface CreateRealtimeEndpointInput {
    MLModelId: string;
}
export type IntegerType = number;
export type EpochTime = Date;
export type VipURL = string;
export type RealtimeEndpointStatus = "NONE" | "READY" | "UPDATING" | "FAILED" | (string & {});
export interface RealtimeEndpointInfo {
    PeakRequestsPerSecond?: number | undefined;
    CreatedAt?: Date | undefined;
    EndpointUrl?: string | undefined;
    EndpointStatus?: RealtimeEndpointStatus | undefined;
}
export interface CreateRealtimeEndpointOutput {
    MLModelId?: string | undefined;
    RealtimeEndpointInfo?: RealtimeEndpointInfo | undefined;
}
export interface DeleteBatchPredictionInput {
    BatchPredictionId: string;
}
export interface DeleteBatchPredictionOutput {
    BatchPredictionId?: string | undefined;
}
export interface DeleteDataSourceInput {
    DataSourceId: string;
}
export interface DeleteDataSourceOutput {
    DataSourceId?: string | undefined;
}
export interface DeleteEvaluationInput {
    EvaluationId: string;
}
export interface DeleteEvaluationOutput {
    EvaluationId?: string | undefined;
}
export interface DeleteMLModelInput {
    MLModelId: string;
}
export interface DeleteMLModelOutput {
    MLModelId?: string | undefined;
}
export interface DeleteRealtimeEndpointInput {
    MLModelId: string;
}
export interface DeleteRealtimeEndpointOutput {
    MLModelId?: string | undefined;
    RealtimeEndpointInfo?: RealtimeEndpointInfo | undefined;
}
export type TagKeyList = string[];
export interface DeleteTagsInput {
    TagKeys: string[];
    ResourceId: string;
    ResourceType: TaggableResourceType;
}
export interface DeleteTagsOutput {
    ResourceId?: string | undefined;
    ResourceType?: TaggableResourceType | undefined;
}
export type BatchPredictionFilterVariable = "CreatedAt" | "LastUpdatedAt" | "Status" | "Name" | "IAMUser" | "MLModelId" | "DataSourceId" | "DataURI" | (string & {});
export type ComparatorValue = string;
export type SortOrder = "asc" | "dsc" | (string & {});
export type PageLimit = number;
export interface DescribeBatchPredictionsInput {
    FilterVariable?: BatchPredictionFilterVariable | undefined;
    EQ?: string | undefined;
    GT?: string | undefined;
    LT?: string | undefined;
    GE?: string | undefined;
    LE?: string | undefined;
    NE?: string | undefined;
    Prefix?: string | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type AwsUserArn = string;
export type EntityStatus = "PENDING" | "INPROGRESS" | "FAILED" | "COMPLETED" | "DELETED" | (string & {});
export type Message = string;
export type LongType = number;
export interface BatchPrediction {
    BatchPredictionId?: string | undefined;
    MLModelId?: string | undefined;
    BatchPredictionDataSourceId?: string | undefined;
    InputDataLocationS3?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    OutputUri?: string | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    TotalRecordCount?: number | undefined;
    InvalidRecordCount?: number | undefined;
}
export type BatchPredictions = BatchPrediction[];
export interface DescribeBatchPredictionsOutput {
    Results?: BatchPrediction[] | undefined;
    NextToken?: string | undefined;
}
export type DataSourceFilterVariable = "CreatedAt" | "LastUpdatedAt" | "Status" | "Name" | "DataLocationS3" | "IAMUser" | (string & {});
export interface DescribeDataSourcesInput {
    FilterVariable?: DataSourceFilterVariable | undefined;
    EQ?: string | undefined;
    GT?: string | undefined;
    LT?: string | undefined;
    GE?: string | undefined;
    LE?: string | undefined;
    NE?: string | undefined;
    Prefix?: string | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface RedshiftMetadata {
    RedshiftDatabase?: RedshiftDatabase | undefined;
    DatabaseUserName?: string | undefined;
    SelectSqlQuery?: string | undefined;
}
export type EDPPipelineId = string;
export interface RDSMetadata {
    Database?: RDSDatabase | undefined;
    DatabaseUserName?: string | undefined;
    SelectSqlQuery?: string | undefined;
    ResourceRole?: string | undefined;
    ServiceRole?: string | undefined;
    DataPipelineId?: string | undefined;
}
export interface DataSource {
    DataSourceId?: string | undefined;
    DataLocationS3?: string | undefined;
    DataRearrangement?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    DataSizeInBytes?: number | undefined;
    NumberOfFiles?: number | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    Message?: string | undefined;
    RedshiftMetadata?: RedshiftMetadata | undefined;
    RDSMetadata?: RDSMetadata | undefined;
    RoleARN?: string | undefined;
    ComputeStatistics?: boolean | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
}
export type DataSources = DataSource[];
export interface DescribeDataSourcesOutput {
    Results?: DataSource[] | undefined;
    NextToken?: string | undefined;
}
export type EvaluationFilterVariable = "CreatedAt" | "LastUpdatedAt" | "Status" | "Name" | "IAMUser" | "MLModelId" | "DataSourceId" | "DataURI" | (string & {});
export interface DescribeEvaluationsInput {
    FilterVariable?: EvaluationFilterVariable | undefined;
    EQ?: string | undefined;
    GT?: string | undefined;
    LT?: string | undefined;
    GE?: string | undefined;
    LE?: string | undefined;
    NE?: string | undefined;
    Prefix?: string | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type PerformanceMetricsPropertyKey = string;
export type PerformanceMetricsPropertyValue = string;
export type PerformanceMetricsProperties = {
    [key: string]: string | undefined;
};
export interface PerformanceMetrics {
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Evaluation {
    EvaluationId?: string | undefined;
    MLModelId?: string | undefined;
    EvaluationDataSourceId?: string | undefined;
    InputDataLocationS3?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    PerformanceMetrics?: PerformanceMetrics | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
}
export type Evaluations = Evaluation[];
export interface DescribeEvaluationsOutput {
    Results?: Evaluation[] | undefined;
    NextToken?: string | undefined;
}
export type MLModelFilterVariable = "CreatedAt" | "LastUpdatedAt" | "Status" | "Name" | "IAMUser" | "TrainingDataSourceId" | "RealtimeEndpointStatus" | "MLModelType" | "Algorithm" | "TrainingDataURI" | (string & {});
export interface DescribeMLModelsInput {
    FilterVariable?: MLModelFilterVariable | undefined;
    EQ?: string | undefined;
    GT?: string | undefined;
    LT?: string | undefined;
    GE?: string | undefined;
    LE?: string | undefined;
    NE?: string | undefined;
    Prefix?: string | undefined;
    SortOrder?: SortOrder | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type MLModelName = string;
export type Algorithm = "sgd" | (string & {});
export type ScoreThreshold = number;
export interface MLModel {
    MLModelId?: string | undefined;
    TrainingDataSourceId?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    SizeInBytes?: number | undefined;
    EndpointInfo?: RealtimeEndpointInfo | undefined;
    TrainingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    InputDataLocationS3?: string | undefined;
    Algorithm?: Algorithm | undefined;
    MLModelType?: MLModelType | undefined;
    ScoreThreshold?: number | undefined;
    ScoreThresholdLastUpdatedAt?: Date | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
}
export type MLModels = MLModel[];
export interface DescribeMLModelsOutput {
    Results?: MLModel[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeTagsInput {
    ResourceId: string;
    ResourceType: TaggableResourceType;
}
export interface DescribeTagsOutput {
    ResourceId?: string | undefined;
    ResourceType?: TaggableResourceType | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetBatchPredictionInput {
    BatchPredictionId: string;
}
export type PresignedS3Url = string;
export interface GetBatchPredictionOutput {
    BatchPredictionId?: string | undefined;
    MLModelId?: string | undefined;
    BatchPredictionDataSourceId?: string | undefined;
    InputDataLocationS3?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    OutputUri?: string | undefined;
    LogUri?: string | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    TotalRecordCount?: number | undefined;
    InvalidRecordCount?: number | undefined;
}
export type Verbose = boolean;
export interface GetDataSourceInput {
    DataSourceId: string;
    Verbose?: boolean | undefined;
}
export interface GetDataSourceOutput {
    DataSourceId?: string | undefined;
    DataLocationS3?: string | undefined;
    DataRearrangement?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    DataSizeInBytes?: number | undefined;
    NumberOfFiles?: number | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    LogUri?: string | undefined;
    Message?: string | undefined;
    RedshiftMetadata?: RedshiftMetadata | undefined;
    RDSMetadata?: RDSMetadata | undefined;
    RoleARN?: string | undefined;
    ComputeStatistics?: boolean | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    DataSourceSchema?: string | undefined;
}
export interface GetEvaluationInput {
    EvaluationId: string;
}
export interface GetEvaluationOutput {
    EvaluationId?: string | undefined;
    MLModelId?: string | undefined;
    EvaluationDataSourceId?: string | undefined;
    InputDataLocationS3?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    PerformanceMetrics?: PerformanceMetrics | undefined;
    LogUri?: string | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
}
export interface GetMLModelInput {
    MLModelId: string;
    Verbose?: boolean | undefined;
}
export interface GetMLModelOutput {
    MLModelId?: string | undefined;
    TrainingDataSourceId?: string | undefined;
    CreatedByIamUser?: string | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    Name?: string | undefined;
    Status?: EntityStatus | undefined;
    SizeInBytes?: number | undefined;
    EndpointInfo?: RealtimeEndpointInfo | undefined;
    TrainingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    InputDataLocationS3?: string | undefined;
    MLModelType?: MLModelType | undefined;
    ScoreThreshold?: number | undefined;
    ScoreThresholdLastUpdatedAt?: Date | undefined;
    LogUri?: string | undefined;
    Message?: string | undefined;
    ComputeTime?: number | undefined;
    FinishedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    Recipe?: string | undefined;
    Schema?: string | undefined;
}
export type VariableName = string;
export type VariableValue = string;
export type Record = {
    [key: string]: string | undefined;
};
export interface PredictInput {
    MLModelId: string;
    Record: {
        [key: string]: string | undefined;
    };
    PredictEndpoint: string;
}
export type Label = string;
export type FloatLabel = number;
export type ScoreValue = number;
export type ScoreValuePerLabelMap = {
    [key: string]: number | undefined;
};
export type DetailsAttributes = "PredictiveModelType" | "Algorithm" | (string & {});
export type DetailsValue = string;
export type DetailsMap = {
    [key in DetailsAttributes]?: string | undefined;
};
export interface Prediction {
    predictedLabel?: string | undefined;
    predictedValue?: number | undefined;
    predictedScores?: {
        [key: string]: number | undefined;
    } | undefined;
    details?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PredictOutput {
    Prediction?: Prediction | undefined;
}
export interface UpdateBatchPredictionInput {
    BatchPredictionId: string;
    BatchPredictionName: string;
}
export interface UpdateBatchPredictionOutput {
    BatchPredictionId?: string | undefined;
}
export interface UpdateDataSourceInput {
    DataSourceId: string;
    DataSourceName: string;
}
export interface UpdateDataSourceOutput {
    DataSourceId?: string | undefined;
}
export interface UpdateEvaluationInput {
    EvaluationId: string;
    EvaluationName: string;
}
export interface UpdateEvaluationOutput {
    EvaluationId?: string | undefined;
}
export interface UpdateMLModelInput {
    MLModelId: string;
    MLModelName?: string | undefined;
    ScoreThreshold?: number | undefined;
}
export interface UpdateMLModelOutput {
    MLModelId?: string | undefined;
}
export type ErrorMessage = string;
export type ErrorCode = number;
export type AddTagsError = InternalServerException | InvalidInputException | InvalidTagException | ResourceNotFoundException | TagLimitExceededException | CommonErrors;
/**
 * Adds one or more tags to an object, up to a limit of 10. Each tag consists of a key
 * and an optional value. If you add a tag using a key that is already associated with the ML object,
 * `AddTags` updates the tag's value.
 */
export declare const addTags: API.OperationMethod<AddTagsInput & RegionInput, AddTagsOutput, AddTagsError, Credentials | HttpClient.HttpClient>;
export type CreateBatchPredictionError = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Generates predictions for a group of observations. The observations to process exist in one or more data files referenced
 * by a `DataSource`. This operation creates a new `BatchPrediction`, and uses an `MLModel` and the data
 * files referenced by the `DataSource` as information sources.
 *
 * `CreateBatchPrediction` is an asynchronous operation. In response to `CreateBatchPrediction`,
 * Amazon Machine Learning (Amazon ML) immediately returns and sets the `BatchPrediction` status to `PENDING`.
 * After the `BatchPrediction` completes, Amazon ML sets the status to `COMPLETED`.
 *
 * You can poll for status updates by using the GetBatchPrediction operation and checking the `Status` parameter of the result. After the `COMPLETED` status appears,
 * the results are available in the location specified by the `OutputUri` parameter.
 */
export declare const createBatchPrediction: API.OperationMethod<CreateBatchPredictionInput & RegionInput, CreateBatchPredictionOutput, CreateBatchPredictionError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceFromRDSError = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Creates a `DataSource` object from an Amazon Relational Database Service (Amazon RDS). A `DataSource` references data that can be used to perform `CreateMLModel`, `CreateEvaluation`, or `CreateBatchPrediction` operations.
 *
 * `CreateDataSourceFromRDS` is an asynchronous operation. In response to `CreateDataSourceFromRDS`,
 * Amazon Machine Learning (Amazon ML) immediately returns and sets the `DataSource` status to `PENDING`.
 * After the `DataSource` is created and ready for use, Amazon ML sets the `Status` parameter to `COMPLETED`.
 * `DataSource` in the `COMPLETED` or `PENDING` state can
 * be used only to perform `>CreateMLModel`>, `CreateEvaluation`, or `CreateBatchPrediction` operations.
 *
 * If Amazon ML cannot accept the input source, it sets the `Status` parameter to `FAILED` and includes an error message in the `Message` attribute of the `GetDataSource` operation response.
 */
export declare const createDataSourceFromRDS: API.OperationMethod<CreateDataSourceFromRDSInput & RegionInput, CreateDataSourceFromRDSOutput, CreateDataSourceFromRDSError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceFromRedshiftError = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Creates a `DataSource` from a database hosted on an Amazon Redshift cluster. A
 * `DataSource` references data that can be used to perform either `CreateMLModel`, `CreateEvaluation`, or `CreateBatchPrediction`
 * operations.
 *
 * `CreateDataSourceFromRedshift` is an asynchronous operation. In response to `CreateDataSourceFromRedshift`, Amazon Machine Learning (Amazon ML) immediately returns and sets the `DataSource` status to `PENDING`.
 * After the `DataSource` is created and ready for use, Amazon ML sets the `Status` parameter to `COMPLETED`.
 * `DataSource` in `COMPLETED` or `PENDING` states can be
 * used to perform only `CreateMLModel`, `CreateEvaluation`, or `CreateBatchPrediction` operations.
 *
 * If Amazon ML can't accept the input source, it sets the `Status` parameter to `FAILED` and includes an error message in the `Message`
 * attribute of the `GetDataSource` operation response.
 *
 * The observations should be contained in the database hosted on an Amazon Redshift cluster
 * and should be specified by a `SelectSqlQuery` query. Amazon ML executes an
 * `Unload` command in Amazon Redshift to transfer the result set of
 * the `SelectSqlQuery` query to `S3StagingLocation`.
 *
 * After the `DataSource` has been created, it's ready for use in evaluations and
 * batch predictions. If you plan to use the `DataSource` to train an
 * `MLModel`, the `DataSource` also requires a recipe. A recipe
 * describes how each input variable will be used in training an `MLModel`. Will
 * the variable be included or excluded from training? Will the variable be manipulated;
 * for example, will it be combined with another variable or will it be split apart into
 * word combinations? The recipe provides answers to these questions.
 *
 * You can't change an existing datasource, but you can copy and modify the settings from an
 * existing Amazon Redshift datasource to create a new datasource. To do so, call
 * `GetDataSource` for an existing datasource and copy the values to a
 * `CreateDataSource` call. Change the settings that you want to change and
 * make sure that all required fields have the appropriate values.
 */
export declare const createDataSourceFromRedshift: API.OperationMethod<CreateDataSourceFromRedshiftInput & RegionInput, CreateDataSourceFromRedshiftOutput, CreateDataSourceFromRedshiftError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceFromS3Error = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Creates a `DataSource` object. A `DataSource` references data that
 * can be used to perform `CreateMLModel`, `CreateEvaluation`, or
 * `CreateBatchPrediction` operations.
 *
 * `CreateDataSourceFromS3` is an asynchronous operation. In response to
 * `CreateDataSourceFromS3`, Amazon Machine Learning (Amazon ML) immediately
 * returns and sets the `DataSource` status to `PENDING`. After the
 * `DataSource` has been created and is ready for use, Amazon ML sets the
 * `Status` parameter to `COMPLETED`. `DataSource` in
 * the `COMPLETED` or `PENDING` state can be used to perform only
 * `CreateMLModel`, `CreateEvaluation` or
 * `CreateBatchPrediction` operations.
 *
 * If Amazon ML can't accept the input source, it sets the `Status` parameter to
 * `FAILED` and includes an error message in the `Message`
 * attribute of the `GetDataSource` operation response.
 *
 * The observation data used in a `DataSource` should be ready to use; that is,
 * it should have a consistent structure, and missing data values should be kept to a
 * minimum. The observation data must reside in one or more .csv files in an Amazon Simple
 * Storage Service (Amazon S3) location, along with a schema that describes the data items
 * by name and type. The same schema must be used for all of the data files referenced by
 * the `DataSource`.
 *
 * After the `DataSource` has been created, it's ready to use in evaluations and
 * batch predictions. If you plan to use the `DataSource` to train an
 * `MLModel`, the `DataSource` also needs a recipe. A recipe
 * describes how each input variable will be used in training an `MLModel`. Will
 * the variable be included or excluded from training? Will the variable be manipulated;
 * for example, will it be combined with another variable or will it be split apart into
 * word combinations? The recipe provides answers to these questions.
 */
export declare const createDataSourceFromS3: API.OperationMethod<CreateDataSourceFromS3Input & RegionInput, CreateDataSourceFromS3Output, CreateDataSourceFromS3Error, Credentials | HttpClient.HttpClient>;
export type CreateEvaluationError = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Creates a new `Evaluation` of an `MLModel`. An `MLModel` is evaluated on a set of observations associated to a `DataSource`. Like a `DataSource`
 * for an `MLModel`, the `DataSource` for an `Evaluation` contains values for the `Target Variable`. The `Evaluation` compares the predicted result for each observation to the actual outcome and provides a
 * summary so that you know how effective the `MLModel` functions on the test
 * data. Evaluation generates a relevant performance metric, such as BinaryAUC, RegressionRMSE or MulticlassAvgFScore based on the corresponding `MLModelType`: `BINARY`, `REGRESSION` or `MULTICLASS`.
 *
 * `CreateEvaluation` is an asynchronous operation. In response to `CreateEvaluation`, Amazon Machine Learning (Amazon ML) immediately
 * returns and sets the evaluation status to `PENDING`. After the `Evaluation` is created and ready for use,
 * Amazon ML sets the status to `COMPLETED`.
 *
 * You can use the `GetEvaluation` operation to check progress of the evaluation during the creation operation.
 */
export declare const createEvaluation: API.OperationMethod<CreateEvaluationInput & RegionInput, CreateEvaluationOutput, CreateEvaluationError, Credentials | HttpClient.HttpClient>;
export type CreateMLModelError = IdempotentParameterMismatchException | InternalServerException | InvalidInputException | CommonErrors;
/**
 * Creates a new `MLModel` using the `DataSource` and the recipe as
 * information sources.
 *
 * An `MLModel` is nearly immutable. Users can update only the
 * `MLModelName` and the `ScoreThreshold` in an
 * `MLModel` without creating a new `MLModel`.
 *
 * `CreateMLModel` is an asynchronous operation. In response to
 * `CreateMLModel`, Amazon Machine Learning (Amazon ML) immediately returns
 * and sets the `MLModel` status to `PENDING`. After the
 * `MLModel` has been created and ready is for use, Amazon ML sets the
 * status to `COMPLETED`.
 *
 * You can use the `GetMLModel` operation to check the progress of the
 * `MLModel` during the creation operation.
 *
 * `CreateMLModel` requires a `DataSource` with computed statistics,
 * which can be created by setting `ComputeStatistics` to `true` in
 * `CreateDataSourceFromRDS`, `CreateDataSourceFromS3`, or
 * `CreateDataSourceFromRedshift` operations.
 */
export declare const createMLModel: API.OperationMethod<CreateMLModelInput & RegionInput, CreateMLModelOutput, CreateMLModelError, Credentials | HttpClient.HttpClient>;
export type CreateRealtimeEndpointError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a real-time endpoint for the `MLModel`. The endpoint contains the URI of the `MLModel`; that is, the location to send real-time prediction requests for the specified `MLModel`.
 */
export declare const createRealtimeEndpoint: API.OperationMethod<CreateRealtimeEndpointInput & RegionInput, CreateRealtimeEndpointOutput, CreateRealtimeEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchPredictionError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns the DELETED status to a `BatchPrediction`, rendering it unusable.
 *
 * After using the `DeleteBatchPrediction` operation, you can use the GetBatchPrediction
 * operation to verify that the status of the `BatchPrediction` changed to DELETED.
 *
 * **Caution:** The result of the `DeleteBatchPrediction` operation is irreversible.
 */
export declare const deleteBatchPrediction: API.OperationMethod<DeleteBatchPredictionInput & RegionInput, DeleteBatchPredictionOutput, DeleteBatchPredictionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns the DELETED status to a `DataSource`, rendering it unusable.
 *
 * After using the `DeleteDataSource` operation, you can use the GetDataSource operation to verify that the status of the `DataSource` changed to DELETED.
 *
 * **Caution:** The results of the `DeleteDataSource` operation are irreversible.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceInput & RegionInput, DeleteDataSourceOutput, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteEvaluationError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns the `DELETED` status to an `Evaluation`, rendering it unusable.
 *
 * After invoking the `DeleteEvaluation` operation, you can use the
 * `GetEvaluation` operation to verify that the status of the `Evaluation` changed to `DELETED`.
 *
 * **Caution:** The results of the `DeleteEvaluation` operation are irreversible.
 */
export declare const deleteEvaluation: API.OperationMethod<DeleteEvaluationInput & RegionInput, DeleteEvaluationOutput, DeleteEvaluationError, Credentials | HttpClient.HttpClient>;
export type DeleteMLModelError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns the `DELETED` status to an `MLModel`, rendering it unusable.
 *
 * After using the `DeleteMLModel` operation, you can use the
 * `GetMLModel` operation to verify that the status of the `MLModel` changed to DELETED.
 *
 * **Caution:** The result of the `DeleteMLModel` operation is irreversible.
 */
export declare const deleteMLModel: API.OperationMethod<DeleteMLModelInput & RegionInput, DeleteMLModelOutput, DeleteMLModelError, Credentials | HttpClient.HttpClient>;
export type DeleteRealtimeEndpointError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a real time endpoint of an `MLModel`.
 */
export declare const deleteRealtimeEndpoint: API.OperationMethod<DeleteRealtimeEndpointInput & RegionInput, DeleteRealtimeEndpointOutput, DeleteRealtimeEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = InternalServerException | InvalidInputException | InvalidTagException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified tags associated with an ML object. After this operation is complete, you can't recover deleted tags.
 *
 * If you specify a tag that doesn't exist, Amazon ML ignores it.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsInput & RegionInput, DeleteTagsOutput, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeBatchPredictionsError = InternalServerException | InvalidInputException | CommonErrors;
/**
 * Returns a list of `BatchPrediction` operations that match the search criteria in the request.
 */
export declare const describeBatchPredictions: API.PaginatedOperationMethod<DescribeBatchPredictionsInput & RegionInput, DescribeBatchPredictionsOutput, DescribeBatchPredictionsError, Credentials | HttpClient.HttpClient, BatchPrediction>;
export type DescribeDataSourcesError = InternalServerException | InvalidInputException | CommonErrors;
/**
 * Returns a list of `DataSource` that match the search criteria in the request.
 */
export declare const describeDataSources: API.PaginatedOperationMethod<DescribeDataSourcesInput & RegionInput, DescribeDataSourcesOutput, DescribeDataSourcesError, Credentials | HttpClient.HttpClient, DataSource>;
export type DescribeEvaluationsError = InternalServerException | InvalidInputException | CommonErrors;
/**
 * Returns a list of `DescribeEvaluations` that match the search criteria in the request.
 */
export declare const describeEvaluations: API.PaginatedOperationMethod<DescribeEvaluationsInput & RegionInput, DescribeEvaluationsOutput, DescribeEvaluationsError, Credentials | HttpClient.HttpClient, Evaluation>;
export type DescribeMLModelsError = InternalServerException | InvalidInputException | CommonErrors;
/**
 * Returns a list of `MLModel` that match the search criteria in the request.
 */
export declare const describeMLModels: API.PaginatedOperationMethod<DescribeMLModelsInput & RegionInput, DescribeMLModelsOutput, DescribeMLModelsError, Credentials | HttpClient.HttpClient, MLModel>;
export type DescribeTagsError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes one or more of the tags for your Amazon ML object.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsInput & RegionInput, DescribeTagsOutput, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type GetBatchPredictionError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `BatchPrediction` that includes detailed metadata, status, and data file information for a
 * `Batch Prediction` request.
 */
export declare const getBatchPrediction: API.OperationMethod<GetBatchPredictionInput & RegionInput, GetBatchPredictionOutput, GetBatchPredictionError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a `DataSource` that includes metadata and data file information, as well as the current status of the `DataSource`.
 *
 * `GetDataSource` provides results in normal or verbose format. The verbose format
 * adds the schema description and the list of files pointed to by the DataSource to the normal format.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceInput & RegionInput, GetDataSourceOutput, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetEvaluationError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an `Evaluation` that includes metadata as well as the current status of the `Evaluation`.
 */
export declare const getEvaluation: API.OperationMethod<GetEvaluationInput & RegionInput, GetEvaluationOutput, GetEvaluationError, Credentials | HttpClient.HttpClient>;
export type GetMLModelError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an `MLModel` that includes detailed metadata, data source information, and the current status of the `MLModel`.
 *
 * `GetMLModel` provides results in normal or verbose format.
 */
export declare const getMLModel: API.OperationMethod<GetMLModelInput & RegionInput, GetMLModelOutput, GetMLModelError, Credentials | HttpClient.HttpClient>;
export type PredictError = InternalServerException | InvalidInputException | LimitExceededException | PredictorNotMountedException | ResourceNotFoundException | CommonErrors;
/**
 * Generates a prediction for the observation using the specified `ML Model`.
 *
 * **Note:** Not all response parameters will be populated. Whether a
 * response parameter is populated depends on the type of model requested.
 */
export declare const predict: API.OperationMethod<PredictInput & RegionInput, PredictOutput, PredictError, Credentials | HttpClient.HttpClient>;
export type UpdateBatchPredictionError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `BatchPredictionName` of a `BatchPrediction`.
 *
 * You can use the `GetBatchPrediction` operation to view the contents of the updated data element.
 */
export declare const updateBatchPrediction: API.OperationMethod<UpdateBatchPredictionInput & RegionInput, UpdateBatchPredictionOutput, UpdateBatchPredictionError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `DataSourceName` of a `DataSource`.
 *
 * You can use the `GetDataSource` operation to view the contents of the updated data element.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceInput & RegionInput, UpdateDataSourceOutput, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEvaluationError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `EvaluationName` of an `Evaluation`.
 *
 * You can use the `GetEvaluation` operation to view the contents of the updated data element.
 */
export declare const updateEvaluation: API.OperationMethod<UpdateEvaluationInput & RegionInput, UpdateEvaluationOutput, UpdateEvaluationError, Credentials | HttpClient.HttpClient>;
export type UpdateMLModelError = InternalServerException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `MLModelName` and the `ScoreThreshold` of an `MLModel`.
 *
 * You can use the `GetMLModel` operation to view the contents of the updated data element.
 */
export declare const updateMLModel: API.OperationMethod<UpdateMLModelInput & RegionInput, UpdateMLModelOutput, UpdateMLModelError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=machine-learning.d.ts.map