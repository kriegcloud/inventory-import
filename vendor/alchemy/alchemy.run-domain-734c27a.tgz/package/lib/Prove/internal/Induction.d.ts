import * as Effect from "effect/Effect";
import type * as Aggregate from "../../Aggregate.ts";
import type * as Decision from "../../Decision.ts";
import type { Verdict } from "./Check.ts";
import type { Interpreter } from "./Interpreter.ts";
import * as Paths from "./Paths.ts";
import type * as Smt from "./Smt.ts";
import * as Value from "./Value.ts";
/** What one command does to every invariant, from any state the schema allows. */
export interface Row {
    readonly command: string;
    /** The paths through the command that were checked. */
    readonly paths: number;
    readonly verdicts: ReadonlyMap<string, Verdict>;
    /**
     * Whether every state the command leaves is one the state's schema allows.
     * The proofs assume it of the state a command meets, so they follow one
     * another only when every command keeps it.
     */
    readonly fits: Verdict;
    /**
     * Whether some state the invariants allow lets the command record an event:
     * `false` when none does, so the proofs say nothing about it, and
     * `undefined` when the prover could not tell.
     */
    readonly accepted: boolean | undefined;
    /**
     * What the command writes to a part of the state whose schema has a check
     * the prover does not read: the new value is not proved to pass it.
     */
    readonly unkept: ReadonlyArray<string>;
    /**
     * The paths on which inputs were picked and run on the real `decide` and
     * `evolve`, and each one where the real code did not do what the prover read.
     */
    readonly compared: number;
    /** The paths inputs take that could not be run: a value the prover cannot build, or one a schema it does not read refuses. */
    readonly uncompared: number;
    readonly differs: ReadonlyArray<string>;
}
/** The most paths of one command that are run on the real code. */
export declare const MAX_COMPARED = 256;
/** The checks of the state's schema no proof covers, as lines of a report. */
export declare const unkept: (rows: ReadonlyArray<Row>) => ReadonlyArray<string>;
/** Whether every command keeps the state in its schema, so that the proofs follow one another. */
export declare const closed: (rows: ReadonlyArray<Row>) => boolean;
/**
 * What a proof on one path is worth: where the path gave a list only a few
 * items, it says nothing of a longer one.
 */
export declare const within: (verdict: Verdict, run: Value.Run) => Verdict;
export declare const worse: (a: Verdict, b: Verdict) => Verdict;
export declare const notRead: (error: Value.NotTranslated) => Verdict;
export declare const MAX_PATHS = 4096;
/**
 * Take each command from any state that satisfies every invariant, along
 * every path through its code, and say whether each invariant still holds.
 */
export declare const rows: (solver: Smt.Solver, interpreter: Interpreter, aggregate: Aggregate.Any, definition: Paths.Definition) => Effect.Effect<Row[], Smt.SolverError, never>;
/** A decision the prover reads: its definition, and each aggregate it reads with its own. */
export interface DecisionImpl {
    readonly cls: Decision.Any;
    readonly definition: Paths.DecisionDefinition;
    readonly command: Paths.CommandClass;
    readonly reads: Readonly<Record<string, {
        readonly cls: Aggregate.Any;
        readonly definition: Paths.Definition;
    }>>;
}
/** The name a report gives an aggregate's rule that a decision must keep. */
export declare const ruleOf: (aggregate: string, name: string) => string;
/**
 * What one decision does to every rule of every aggregate it reads, and to
 * its own, from any states the schemas allow.
 */
export interface DecisionRow extends Row {
    /** The decision's own transitions, by name: the other verdicts are named `Aggregate.Rule`. */
    readonly own: ReadonlyArray<string>;
}
/**
 * The instances a decision reads on one path, each given any state its
 * aggregate's rules allow the first time `keyOf` names it. Two names of one
 * aggregate are the same instance on one path and two on another.
 */
export declare const reader: (interpreter: Interpreter, impl: DecisionImpl, run: Value.Run) => {
    read: {
        readonly cls: Aggregate.Any;
        readonly slot: Paths.Slot;
    }[];
    slotOf: (name: string, id: Value.V) => Effect.Effect<{
        index: number;
        slot: Paths.Slot;
    }, Value.Stop, never>;
};
/**
 * Take a decision from any states that satisfy every invariant of the
 * aggregates it reads, along every path through its code, and say whether
 * each of their rules, and each of its own, still holds. Two names that can
 * stand for one instance are tried both ways: as two instances, and as one.
 */
export declare const decisionRow: (solver: Smt.Solver, interpreter: Interpreter, impl: DecisionImpl) => Effect.Effect<DecisionRow, Smt.SolverError, never>;
/** Find a decision's definition, and each aggregate's it reads, among files that were read. */
export declare const locate: (interpreter: Interpreter, modules: readonly Value.Module[], decision: Decision.Any) => Effect.Effect<string | DecisionImpl, never, never>;
//# sourceMappingURL=Induction.d.ts.map