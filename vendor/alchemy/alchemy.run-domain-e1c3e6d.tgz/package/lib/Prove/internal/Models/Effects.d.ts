import type { Kit, Models } from "../Kit.ts";
import type { V } from "../Value.ts";
/** What `Effect.fromOption` and the like fail with when there is nothing. */
export declare const noSuchElement: V;
/**
 * `Effect`: what a handler written as an effect is made of. An effect here
 * succeeds, fails with an error the code can handle, or dies; nothing runs at
 * the same time as anything else, so the options that say how many do are
 * left as they are.
 */
export declare const make: (kit: Kit) => {
    readonly models: Models;
    readonly values: Record<string, V>;
};
//# sourceMappingURL=Effects.d.ts.map