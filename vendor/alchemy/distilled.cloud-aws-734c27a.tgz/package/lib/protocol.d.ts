export * from "@distilled.cloud/s3/Protocol";
//# sourceMappingURL=protocol.d.ts.map