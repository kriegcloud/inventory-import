import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadGatewayException_base: S.TaggedErrorClass<"BadGatewayException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class BadGatewayException extends /*@__PURE__*/ BadGatewayException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DependencyFailedException_base: S.TaggedErrorClass<"DependencyFailedException", {
    readonly message: any;
    readonly resourceName: any;
}>;
export declare class DependencyFailedException extends /*@__PURE__*/ DependencyFailedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ModelNotReadyException_base: S.TaggedErrorClass<"ModelNotReadyException", {
    readonly message: any;
}>;
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AgenticRetrieveMessageContent {
    text?: string | undefined;
}
export type ConversationRole = "user" | "assistant" | (string & {});
export interface AgenticRetrieveMessage {
    content: AgenticRetrieveMessageContent;
    role: ConversationRole;
}
export type AgenticRetrieveMessages = AgenticRetrieveMessage[];
export type KnowledgeBaseId = string;
export type FilterKey = string;
export type FilterValue = unknown;
export interface FilterAttribute {
    key: string;
    value: any;
}
export type RetrievalFilterList = RetrievalFilter[];
export type RetrievalFilter = {
    equals: FilterAttribute;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals: FilterAttribute;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan: FilterAttribute;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals: FilterAttribute;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan: FilterAttribute;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals: FilterAttribute;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in: FilterAttribute;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn: FilterAttribute;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith: FilterAttribute;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains: FilterAttribute;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains: FilterAttribute;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll: RetrievalFilter[];
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll: RetrievalFilter[];
};
export interface RetrievalOverrides {
    filter?: RetrievalFilter | undefined;
    maxNumberOfResults?: number | undefined;
}
export interface KnowledgeBaseRetrieverConfiguration {
    knowledgeBaseId: string;
    retrievalOverrides?: RetrievalOverrides | undefined;
}
export type RetrieverConfiguration = {
    knowledgeBase: KnowledgeBaseRetrieverConfiguration;
};
export interface AgenticRetriever {
    description?: string | undefined;
    configuration: RetrieverConfiguration;
}
export type AgenticRetrievers = AgenticRetriever[];
export type FoundationModelType = "CUSTOM" | "MANAGED" | (string & {});
export type FoundationModelConfigurationType = "BEDROCK_FOUNDATION_MODEL" | "MANTLE_FOUNDATION_MODEL" | (string & {});
export type BedrockModelArn = string;
export interface BedrockFoundationModelModelConfiguration {
    modelArn: string;
}
export interface BedrockFoundationModelConfiguration {
    modelConfiguration: BedrockFoundationModelModelConfiguration;
}
export type MantleProjectId = string;
export interface MantleFoundationModelModelConfiguration {
    modelArn: string;
    projectId?: string | undefined;
}
export interface MantleFoundationModelConfiguration {
    modelConfiguration: MantleFoundationModelModelConfiguration;
}
export interface FoundationModelConfiguration {
    type: FoundationModelConfigurationType;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelConfiguration | undefined;
    mantleFoundationModelConfiguration?: MantleFoundationModelConfiguration | undefined;
}
export type AgenticRetrieveRerankingModelType = "CUSTOM" | "MANAGED" | "NONE" | (string & {});
export type AgenticRetrieveRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export interface AgenticRetrieveBedrockRerankingModelConfiguration {
    modelArn: string;
}
export interface AgenticRetrieveBedrockRerankingConfiguration {
    modelConfiguration: AgenticRetrieveBedrockRerankingModelConfiguration;
}
export interface AgenticRetrieveRerankingConfiguration {
    type: AgenticRetrieveRerankingConfigurationType;
    bedrockRerankingConfiguration?: AgenticRetrieveBedrockRerankingConfiguration | undefined;
}
export interface AgenticRetrieveConfiguration {
    foundationModelType?: FoundationModelType | undefined;
    foundationModelConfiguration?: FoundationModelConfiguration | undefined;
    rerankingModelType?: AgenticRetrieveRerankingModelType | undefined;
    rerankingConfiguration?: AgenticRetrieveRerankingConfiguration | undefined;
    maxAgentIteration?: number | undefined;
}
export interface AgenticRetrieveBedrockGuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export interface AgenticRetrievePolicyConfiguration {
    bedrockGuardrailConfiguration?: AgenticRetrieveBedrockGuardrailConfiguration | undefined;
}
export type NextToken = string;
export interface UserContext {
    userId: string;
}
export type AgentCoreMemoryId = string;
export type AgentCoreMemoryActorId = string;
export type AgentCoreMemorySessionId = string;
export interface AgenticRetrieveMemorySessionBinding {
    actorId: string;
    sessionId: string;
}
export type MemoryNamespace = string;
export type MemoryStrategyId = string;
export type AgenticRetrieveMemoryMetadataKey = string;
export type AgenticRetrieveMemoryMetadataFilterLeft = {
    metadataKey: string;
};
export type AgenticRetrieveMemoryMetadataFilterOperator = "EQUALS_TO" | "EXISTS" | "NOT_EXISTS" | "BEFORE" | "AFTER" | "CONTAINS" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | (string & {});
export type AgenticRetrieveMemoryMetadataStringValue = string;
export type AgenticRetrieveMemoryMetadataStringListItem = string;
export type AgenticRetrieveMemoryMetadataStringList = string[];
export type AgenticRetrieveMemoryMetadataValue = {
    stringValue: string;
    numberValue?: undefined;
    stringListValue?: undefined;
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    numberValue: number;
    stringListValue?: undefined;
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    numberValue?: undefined;
    stringListValue: string[];
    dateTimeValue?: undefined;
} | {
    stringValue?: undefined;
    numberValue?: undefined;
    stringListValue?: undefined;
    dateTimeValue: Date;
};
export type AgenticRetrieveMemoryMetadataFilterRight = {
    metadataValue: AgenticRetrieveMemoryMetadataValue;
};
export interface AgenticRetrieveMemoryMetadataFilter {
    left: AgenticRetrieveMemoryMetadataFilterLeft;
    operator: AgenticRetrieveMemoryMetadataFilterOperator;
    right?: AgenticRetrieveMemoryMetadataFilterRight | undefined;
}
export type AgenticRetrieveMemoryMetadataFilterList = AgenticRetrieveMemoryMetadataFilter[];
export interface AgenticRetrieveMemoryRetrievalConfig {
    namespace?: string | undefined;
    namespacePath?: string | undefined;
    strategyId?: string | undefined;
    metadataFilters?: AgenticRetrieveMemoryMetadataFilter[] | undefined;
}
export type AgenticRetrieveMemoryRetrievalConfigList = AgenticRetrieveMemoryRetrievalConfig[];
export type AgenticRetrieveMemoryPersistenceMode = "DEFAULT" | "NONE" | (string & {});
export interface AgenticRetrieveMemoryConfiguration {
    memoryId: string;
    sessionBinding?: AgenticRetrieveMemorySessionBinding | undefined;
    retrievalConfigs?: AgenticRetrieveMemoryRetrievalConfig[] | undefined;
    persistenceMode?: AgenticRetrieveMemoryPersistenceMode | undefined;
}
export type RetrievalInstructionId = string;
export type RetrievalInstructionVersion = string;
export interface AgenticRetrieveInstructionConfiguration {
    retrievalInstructionId: string;
    version?: string | undefined;
}
export interface AgenticRetrieveStreamRequest {
    messages: AgenticRetrieveMessage[];
    retrievers: AgenticRetriever[];
    agenticRetrieveConfiguration: AgenticRetrieveConfiguration;
    policyConfiguration?: AgenticRetrievePolicyConfiguration | undefined;
    nextToken?: string | undefined;
    userContext?: UserContext | undefined;
    memoryConfiguration?: AgenticRetrieveMemoryConfiguration | undefined;
    retrievalInstructionConfiguration?: AgenticRetrieveInstructionConfiguration | undefined;
    generateResponse?: boolean | undefined;
}
export type MimeType = string;
export interface RetrievalContent {
    byteContent?: Uint8Array | undefined;
    text?: string | undefined;
    mimeType: string;
}
export type AgenticRetrieveMetadata = {
    [key: string]: any | undefined;
};
export interface AgenticRetrieveSourceRetriever {
    identifier: string;
}
export interface AgenticRetrieveResultItem {
    content: RetrievalContent;
    metadata?: {
        [key: string]: any | undefined;
    } | undefined;
    sourceRetriever: AgenticRetrieveSourceRetriever;
}
export type AgenticRetrieveResults = AgenticRetrieveResultItem[];
export interface AgenticRetrieveCitationReference {
    resultIndex: number;
}
export type AgenticRetrieveCitationReferenceList = AgenticRetrieveCitationReference[];
export interface AgenticRetrieveCitation {
    startIndex: number;
    endIndex: number;
    references: AgenticRetrieveCitationReference[];
}
export type AgenticRetrieveCitationList = AgenticRetrieveCitation[];
export interface AgenticRetrieveGeneratedResponse {
    answer: string;
    citations?: AgenticRetrieveCitation[] | undefined;
}
export interface AgenticRetrieveResultEvent {
    results: AgenticRetrieveResultItem[];
    generatedResponse?: AgenticRetrieveGeneratedResponse | undefined;
    nextToken?: string | undefined;
}
export type AgenticRetrieveStep = "Planning" | "Retrieval" | "SpeculativeRetrieval" | "FullDocumentExpansion" | "SessionHistoryLoad" | "CodeExecution" | (string & {});
export type AgenticRetrieveStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type AgenticRetrieveSourceRetrieverList = AgenticRetrieveSourceRetriever[];
export interface AgenticRetrieveActionDetails {
    inputQuery: AgenticRetrieveMessageContent;
    sourceRetrievers: AgenticRetrieveSourceRetriever[];
}
export interface AgenticRetrieveFullDocExpansionDetails {
    documentId?: string | undefined;
    sourceRetriever?: AgenticRetrieveSourceRetriever | undefined;
}
export interface AgenticRetrieveMemoryRetrieveDetails {
    inputQuery: AgenticRetrieveMessageContent;
    memoryId: string;
    namespace?: string | undefined;
    namespacePath?: string | undefined;
    strategyId?: string | undefined;
}
export interface AgenticRetrieveCodeExecutionDocument {
    documentId?: string | undefined;
    sourceRetriever?: AgenticRetrieveSourceRetriever | undefined;
}
export type AgenticRetrieveCodeExecutionDocumentList = AgenticRetrieveCodeExecutionDocument[];
export interface AgenticRetrieveCodeExecutionDetails {
    documents?: AgenticRetrieveCodeExecutionDocument[] | undefined;
}
export interface AgenticRetrieveAction {
    retrieve?: AgenticRetrieveActionDetails | undefined;
    fullDocumentExpansion?: AgenticRetrieveFullDocExpansionDetails | undefined;
    memoryRetrieve?: AgenticRetrieveMemoryRetrieveDetails | undefined;
    codeExecution?: AgenticRetrieveCodeExecutionDetails | undefined;
}
export type AgenticRetrieveActions = AgenticRetrieveAction[];
export interface AgenticRetrieveWarningMessage {
    message: string;
}
export type GuardrailAction = "INTERVENED" | "NONE" | (string & {});
export interface AgenticRetrieveGuardrailWarning {
    id: string;
    version: string;
    action: GuardrailAction;
    message?: string | undefined;
}
export type AgenticRetrieveWarning = {
    message: AgenticRetrieveWarningMessage;
    guardrail?: undefined;
} | {
    message?: undefined;
    guardrail: AgenticRetrieveGuardrailWarning;
};
export type AgenticRetrieveWarnings = AgenticRetrieveWarning[];
export interface AgenticRetrieveFailure {
    message: string;
}
export type AgenticRetrieveFailures = AgenticRetrieveFailure[];
export type AgenticRetrieveType = "BedrockKnowledgeBase" | "BedrockAgentCoreMemory" | (string & {});
export interface AgenticRetrieveSourceMetadata {
    identifier?: string | undefined;
    retrievalType?: AgenticRetrieveType | undefined;
}
export type AgenticRetrieveSourceMetadataList = AgenticRetrieveSourceMetadata[];
export interface AgenticRetrieveTraceResultItem {
    content?: RetrievalContent | undefined;
    metadata?: {
        [key: string]: any | undefined;
    } | undefined;
    sourceRetriever?: AgenticRetrieveSourceRetriever | undefined;
}
export type AgenticRetrieveTraceResults = AgenticRetrieveTraceResultItem[];
export interface AgenticRetrieveAppliedInstruction {
    id: string;
    version?: string | undefined;
}
export interface AgenticRetrieveTraceEventAttributes {
    step: AgenticRetrieveStep;
    status: AgenticRetrieveStatus;
    message: string;
    actions?: AgenticRetrieveAction[] | undefined;
    warnings?: AgenticRetrieveWarning[] | undefined;
    failures?: AgenticRetrieveFailure[] | undefined;
    retrievalMetadata?: AgenticRetrieveSourceMetadata[] | undefined;
    retrievalResponse?: AgenticRetrieveTraceResultItem[] | undefined;
    appliedInstruction?: AgenticRetrieveAppliedInstruction | undefined;
}
export interface AgenticRetrieveTraceEvent {
    id: string;
    timestamp: number;
    attributes: AgenticRetrieveTraceEventAttributes;
}
export interface AgenticRetrieveResponseEvent {
    text: string;
}
export type NonBlankString = string;
export type AgenticRetrieveStreamResponseOutput = {
    result: AgenticRetrieveResultEvent;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent: AgenticRetrieveTraceEvent;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent: AgenticRetrieveResponseEvent;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: undefined;
} | {
    result?: undefined;
    traceEvent?: undefined;
    responseEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException: BadGatewayException;
};
export interface AgenticRetrieveStreamResponse {
    stream: stream.Stream<AgenticRetrieveStreamResponseOutput, Error, never>;
}
export type KnowledgeBaseIdentifier = string;
export type DataSourceId = string;
export type DocumentId = string;
export interface CheckIngestedDocumentAclRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
    userContext: UserContext;
}
export interface CheckIngestedDocumentAclResponse {
    hasAccess: boolean;
}
export type Uuid = string;
export type InvocationDescription = string;
export type SessionIdentifier = string;
export interface CreateInvocationRequest {
    invocationId?: string | undefined;
    description?: string | undefined;
    sessionIdentifier: string;
}
export interface CreateInvocationResponse {
    sessionId: string;
    invocationId: string;
    createdAt: Date;
}
export type SessionMetadataKey = string;
export type SessionMetadataValue = string;
export type SessionMetadataMap = {
    [key: string]: string | undefined;
};
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateSessionRequest {
    sessionMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    encryptionKeyArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SessionArn = string;
export type SessionStatus = "ACTIVE" | "EXPIRED" | "ENDED" | (string & {});
export interface CreateSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
}
export type AgentId = string;
export type AgentAliasId = string;
export type MemoryId = string;
export type SessionId = string;
export interface DeleteAgentMemoryRequest {
    agentId: string;
    agentAliasId: string;
    memoryId?: string | undefined;
    sessionId?: string | undefined;
}
export interface DeleteAgentMemoryResponse {
}
export interface DeleteSessionRequest {
    sessionIdentifier: string;
}
export interface DeleteSessionResponse {
}
export interface EndSessionRequest {
    sessionIdentifier: string;
}
export interface EndSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
}
export type InputQueryType = "TEXT" | (string & {});
export interface QueryGenerationInput {
    type: InputQueryType;
    text: string;
}
export type QueryTransformationMode = "TEXT_TO_SQL" | (string & {});
export type TextToSqlConfigurationType = "KNOWLEDGE_BASE" | (string & {});
export type KnowledgeBaseArn = string;
export interface TextToSqlKnowledgeBaseConfiguration {
    knowledgeBaseArn: string;
}
export interface TextToSqlConfiguration {
    type: TextToSqlConfigurationType;
    knowledgeBaseConfiguration?: TextToSqlKnowledgeBaseConfiguration | undefined;
}
export interface TransformationConfiguration {
    mode: QueryTransformationMode;
    textToSqlConfiguration?: TextToSqlConfiguration | undefined;
}
export interface GenerateQueryRequest {
    queryGenerationInput: QueryGenerationInput;
    transformationConfiguration: TransformationConfiguration;
}
export type GeneratedQueryType = "REDSHIFT_SQL" | (string & {});
export interface GeneratedQuery {
    type?: GeneratedQueryType | undefined;
    sql?: string | undefined;
}
export type GeneratedQueries = GeneratedQuery[];
export interface GenerateQueryResponse {
    queries?: GeneratedQuery[] | undefined;
}
export type MaxResults = number;
export type MemoryType = "SESSION_SUMMARY" | (string & {});
export interface GetAgentMemoryRequest {
    nextToken?: string | undefined;
    maxItems?: number | undefined;
    agentId: string;
    agentAliasId: string;
    memoryType: MemoryType;
    memoryId: string;
}
export type SummaryText = string;
export interface MemorySessionSummary {
    memoryId?: string | undefined;
    sessionId?: string | undefined;
    sessionStartTime?: Date | undefined;
    sessionExpiryTime?: Date | undefined;
    summaryText?: string | undefined;
}
export type Memory = {
    sessionSummary: MemorySessionSummary;
};
export type Memories = Memory[];
export interface GetAgentMemoryResponse {
    nextToken?: string | undefined;
    memoryContents?: Memory[] | undefined;
}
export type MediaId = string;
export type DocumentOutputFormat = "RAW" | "EXTRACTED" | (string & {});
export interface GetDocumentContentRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
    mediaId?: string | undefined;
    outputFormat?: DocumentOutputFormat | undefined;
    userContext?: UserContext | undefined;
}
export type PresignedUrl = string | redacted.Redacted<string>;
export interface GetDocumentContentResponse {
    mimeType: string;
    presignedUrl: string | redacted.Redacted<string>;
    documentContentLength?: number | undefined;
}
export type FlowIdentifier = string;
export type FlowAliasIdentifier = string;
export type FlowExecutionIdentifier = string;
export interface GetExecutionFlowSnapshotRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export type Version = string;
export type FlowExecutionRoleArn = string;
export interface GetExecutionFlowSnapshotResponse {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    flowVersion: string;
    executionRoleArn: string;
    definition: string;
    customerEncryptionKeyArn?: string | undefined;
}
export interface GetFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export type FlowExecutionStatus = "Running" | "Succeeded" | "Failed" | "TimedOut" | "Aborted" | (string & {});
export type NodeName = string;
export type FlowExecutionErrorType = "ExecutionTimedOut" | (string & {});
export interface FlowExecutionError {
    nodeName?: string | undefined;
    error?: FlowExecutionErrorType | undefined;
    message?: string | undefined;
}
export type FlowExecutionErrors = FlowExecutionError[];
export interface GetFlowExecutionResponse {
    executionArn: string;
    status: FlowExecutionStatus;
    startedAt: Date;
    endedAt?: Date | undefined;
    errors?: FlowExecutionError[] | undefined;
    flowAliasIdentifier: string;
    flowIdentifier: string;
    flowVersion: string;
}
export interface GetIngestedDocumentAclRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentId: string;
}
export type DocumentAclMemberRelation = "AND" | "OR" | (string & {});
export type DocumentAclMembershipType = "KNOWLEDGE_BASE" | "DATA_SOURCE" | (string & {});
export interface DocumentAclUser {
    id: string;
    type: DocumentAclMembershipType;
}
export type DocumentAclUserList = DocumentAclUser[];
export interface DocumentAclGroup {
    id: string;
    type: DocumentAclMembershipType;
}
export type DocumentAclGroupList = DocumentAclGroup[];
export interface DocumentAclCondition {
    conditionOperator?: DocumentAclMemberRelation | undefined;
    users?: DocumentAclUser[] | undefined;
    groups?: DocumentAclGroup[] | undefined;
}
export type DocumentAclConditionList = DocumentAclCondition[];
export interface DocumentAclMembership {
    memberRelation?: DocumentAclMemberRelation | undefined;
    conditions?: DocumentAclCondition[] | undefined;
}
export interface DocumentAcl {
    allowList?: DocumentAclMembership | undefined;
    denyList?: DocumentAclMembership | undefined;
}
export interface GetIngestedDocumentAclResponse {
    documentAcl: DocumentAcl;
}
export type InvocationIdentifier = string;
export interface GetInvocationStepRequest {
    invocationIdentifier: string;
    invocationStepId: string;
    sessionIdentifier: string;
}
export type ImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export type S3Uri = string;
export interface S3Location {
    uri: string;
}
export type ImageSource = {
    bytes: Uint8Array;
    s3Location?: undefined;
} | {
    bytes?: undefined;
    s3Location: S3Location;
};
export interface ImageBlock {
    format: ImageFormat;
    source: ImageSource;
}
export type BedrockSessionContentBlock = {
    text: string;
    image?: undefined;
} | {
    text?: undefined;
    image: ImageBlock;
};
export type BedrockSessionContentBlocks = BedrockSessionContentBlock[];
export type InvocationStepPayload = {
    contentBlocks: BedrockSessionContentBlock[];
};
export interface InvocationStep {
    sessionId: string;
    invocationId: string;
    invocationStepId: string;
    invocationStepTime: Date;
    payload: InvocationStepPayload;
}
export interface GetInvocationStepResponse {
    invocationStep: InvocationStep;
}
export interface GetSessionRequest {
    sessionIdentifier: string;
}
export interface GetSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
    sessionMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    encryptionKeyArn?: string | undefined;
}
export type SessionAttributesMap = {
    [key: string]: string | undefined;
};
export type PromptSessionAttributesMap = {
    [key: string]: string | undefined;
};
export type ApiPath = string | redacted.Redacted<string>;
export type ConfirmationState = "CONFIRM" | "DENY" | (string & {});
export type ResponseState = "FAILURE" | "REPROMPT" | (string & {});
export type ImageInputFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export type ImageInputSource = {
    bytes: Uint8Array;
};
export interface ImageInput {
    format: ImageInputFormat;
    source: ImageInputSource;
}
export type ImageInputs = ImageInput[];
export interface ContentBody {
    body?: string | undefined;
    images?: ImageInput[] | undefined;
}
export type ResponseBody = {
    [key: string]: ContentBody | undefined;
};
export interface ApiResult {
    actionGroup: string;
    httpMethod?: string | undefined;
    apiPath?: string | redacted.Redacted<string> | undefined;
    confirmationState?: ConfirmationState | undefined;
    responseState?: ResponseState | undefined;
    httpStatusCode?: number | undefined;
    responseBody?: {
        [key: string]: ContentBody | undefined;
    } | undefined;
    agentId?: string | undefined;
}
export interface FunctionResult {
    actionGroup: string;
    confirmationState?: ConfirmationState | undefined;
    function?: string | undefined;
    responseBody?: {
        [key: string]: ContentBody | undefined;
    } | undefined;
    responseState?: ResponseState | undefined;
    agentId?: string | undefined;
}
export type InvocationResultMember = {
    apiResult: ApiResult;
    functionResult?: undefined;
} | {
    apiResult?: undefined;
    functionResult: FunctionResult;
};
export type ReturnControlInvocationResults = InvocationResultMember[];
export type FileSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export interface S3ObjectFile {
    uri: string;
}
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentFile {
    mediaType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface FileSource {
    sourceType: FileSourceType;
    s3Location?: S3ObjectFile | undefined;
    byteContent?: ByteContentFile | undefined;
}
export type FileUseCase = "CODE_INTERPRETER" | "CHAT" | (string & {});
export interface InputFile {
    name: string;
    source: FileSource;
    useCase: FileUseCase;
}
export type InputFiles = InputFile[];
export type SearchType = "HYBRID" | "SEMANTIC" | (string & {});
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export type BedrockRerankingModelArn = string;
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export interface FieldForReranking {
    fieldName: string;
}
export type FieldsForReranking = FieldForReranking[];
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: undefined;
} | {
    fieldsToInclude?: undefined;
    fieldsToExclude: FieldForReranking[];
};
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration | undefined;
}
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number | undefined;
    metadataConfiguration?: MetadataConfigurationForReranking | undefined;
}
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration | undefined;
}
export type AttributeType = "STRING" | "NUMBER" | "BOOLEAN" | "STRING_LIST" | (string & {});
export interface MetadataAttributeSchema {
    key: string;
    type: AttributeType;
    description: string;
}
export type MetadataAttributeSchemaList = MetadataAttributeSchema[];
export interface ImplicitFilterConfiguration {
    metadataAttributes: MetadataAttributeSchema[];
    modelArn: string;
}
export interface KnowledgeBaseVectorSearchConfiguration {
    numberOfResults?: number | undefined;
    overrideSearchType?: SearchType | undefined;
    filter?: RetrievalFilter | undefined;
    rerankingConfiguration?: VectorSearchRerankingConfiguration | undefined;
    implicitFilterConfiguration?: ImplicitFilterConfiguration | undefined;
}
export type RerankingModelType = "CUSTOM" | "MANAGED" | "NONE" | (string & {});
export type ManagedSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export interface ManagedSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export interface ManagedSearchBedrockRerankingConfiguration {
    modelConfiguration: ManagedSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number | undefined;
    metadataConfiguration?: MetadataConfigurationForReranking | undefined;
}
export interface ManagedSearchRerankingConfiguration {
    type: ManagedSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: ManagedSearchBedrockRerankingConfiguration | undefined;
}
export interface ManagedSearchConfiguration {
    numberOfResults?: number | undefined;
    filter?: RetrievalFilter | undefined;
    rerankingModelType?: RerankingModelType | undefined;
    rerankingConfiguration?: ManagedSearchRerankingConfiguration | undefined;
}
export interface KnowledgeBaseRetrievalConfiguration {
    vectorSearchConfiguration?: KnowledgeBaseVectorSearchConfiguration | undefined;
    managedSearchConfiguration?: ManagedSearchConfiguration | undefined;
}
export interface KnowledgeBaseConfiguration {
    knowledgeBaseId: string;
    retrievalConfiguration: KnowledgeBaseRetrievalConfiguration;
}
export type KnowledgeBaseConfigurations = KnowledgeBaseConfiguration[];
export type ContentBlock = {
    text: string;
};
export type ContentBlocks = ContentBlock[];
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export type Messages = Message[];
export interface ConversationHistory {
    messages?: Message[] | undefined;
}
export interface SessionState {
    sessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    promptSessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    returnControlInvocationResults?: InvocationResultMember[] | undefined;
    invocationId?: string | undefined;
    files?: InputFile[] | undefined;
    knowledgeBaseConfigurations?: KnowledgeBaseConfiguration[] | undefined;
    conversationHistory?: ConversationHistory | undefined;
}
export type InputText = string | redacted.Redacted<string>;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency | undefined;
}
export interface BedrockModelConfigurations {
    performanceConfig?: PerformanceConfiguration | undefined;
}
export interface StreamingConfigurations {
    streamFinalResponse?: boolean | undefined;
    applyGuardrailInterval?: number | undefined;
}
export interface PromptCreationConfigurations {
    previousConversationTurnsToInclude?: number | undefined;
    excludePreviousThinkingSteps?: boolean | undefined;
}
export type AWSResourceARN = string;
export interface InvokeAgentRequest {
    sessionState?: SessionState | undefined;
    agentId: string;
    agentAliasId: string;
    sessionId: string;
    endSession?: boolean | undefined;
    enableTrace?: boolean | undefined;
    inputText?: string | redacted.Redacted<string> | undefined;
    memoryId?: string | undefined;
    bedrockModelConfigurations?: BedrockModelConfigurations | undefined;
    streamingConfigurations?: StreamingConfigurations | undefined;
    promptCreationConfigurations?: PromptCreationConfigurations | undefined;
    sourceArn?: string | undefined;
}
export type PartBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface Span {
    start?: number | undefined;
    end?: number | undefined;
}
export interface TextResponsePart {
    text?: string | undefined;
    span?: Span | undefined;
}
export interface GeneratedResponsePart {
    textResponsePart?: TextResponsePart | undefined;
}
export type RetrievalResultContentType = "TEXT" | "IMAGE" | "ROW" | "AUDIO" | "VIDEO" | (string & {});
export interface VideoSegment {
    s3Uri: string;
    summary?: string | undefined;
}
export interface AudioSegment {
    s3Uri: string;
    transcription?: string | undefined;
}
export type RetrievalResultContentColumnType = "BLOB" | "BOOLEAN" | "DOUBLE" | "NULL" | "LONG" | "STRING" | (string & {});
export interface RetrievalResultContentColumn {
    columnName?: string | undefined;
    columnValue?: string | undefined;
    type?: RetrievalResultContentColumnType | undefined;
}
export type RetrievalResultContentRow = RetrievalResultContentColumn[];
export interface RetrievalResultContent {
    type?: RetrievalResultContentType | undefined;
    text?: string | undefined;
    byteContent?: string | undefined;
    video?: VideoSegment | undefined;
    audio?: AudioSegment | undefined;
    row?: RetrievalResultContentColumn[] | undefined;
}
export type RetrievalResultLocationType = "S3" | "WEB" | "CONFLUENCE" | "SALESFORCE" | "SHAREPOINT" | "CUSTOM" | "KENDRA" | "SQL" | "ONEDRIVE" | "GOOGLEDRIVE" | (string & {});
export interface RetrievalResultS3Location {
    uri?: string | undefined;
}
export interface RetrievalResultWebLocation {
    url?: string | undefined;
}
export interface RetrievalResultConfluenceLocation {
    url?: string | undefined;
}
export interface RetrievalResultSalesforceLocation {
    url?: string | undefined;
}
export interface RetrievalResultSharePointLocation {
    url?: string | undefined;
}
export interface RetrievalResultCustomDocumentLocation {
    id?: string | undefined;
}
export interface RetrievalResultKendraDocumentLocation {
    uri?: string | undefined;
}
export interface RetrievalResultSqlLocation {
    query?: string | undefined;
}
export interface RetrievalResultOneDriveLocation {
    url?: string | undefined;
}
export interface RetrievalResultGoogleDriveLocation {
    url?: string | undefined;
}
export interface RetrievalResultLocation {
    type: RetrievalResultLocationType;
    s3Location?: RetrievalResultS3Location | undefined;
    webLocation?: RetrievalResultWebLocation | undefined;
    confluenceLocation?: RetrievalResultConfluenceLocation | undefined;
    salesforceLocation?: RetrievalResultSalesforceLocation | undefined;
    sharePointLocation?: RetrievalResultSharePointLocation | undefined;
    customDocumentLocation?: RetrievalResultCustomDocumentLocation | undefined;
    kendraDocumentLocation?: RetrievalResultKendraDocumentLocation | undefined;
    sqlLocation?: RetrievalResultSqlLocation | undefined;
    oneDriveLocation?: RetrievalResultOneDriveLocation | undefined;
    googleDriveLocation?: RetrievalResultGoogleDriveLocation | undefined;
}
export type RetrievalResultMetadataKey = string;
export type RetrievalResultMetadataValue = unknown;
export type RetrievalResultMetadata = {
    [key: string]: any | undefined;
};
export interface RetrievedReference {
    content?: RetrievalResultContent | undefined;
    location?: RetrievalResultLocation | undefined;
    metadata?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type RetrievedReferences = RetrievedReference[];
export interface Citation {
    generatedResponsePart?: GeneratedResponsePart | undefined;
    retrievedReferences?: RetrievedReference[] | undefined;
}
export type Citations = Citation[];
export interface Attribution {
    citations?: Citation[] | undefined;
}
export interface PayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    attribution?: Attribution | undefined;
}
export type TraceId = string;
export type GuardrailTopicType = "DENY" | (string & {});
export type GuardrailTopicPolicyAction = "BLOCKED" | (string & {});
export interface GuardrailTopic {
    name?: string | undefined;
    type?: GuardrailTopicType | undefined;
    action?: GuardrailTopicPolicyAction | undefined;
}
export type GuardrailTopicList = GuardrailTopic[];
export interface GuardrailTopicPolicyAssessment {
    topics?: GuardrailTopic[] | undefined;
}
export type GuardrailContentFilterType = "INSULTS" | "HATE" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export type GuardrailContentFilterConfidence = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailContentPolicyAction = "BLOCKED" | (string & {});
export interface GuardrailContentFilter {
    type?: GuardrailContentFilterType | undefined;
    confidence?: GuardrailContentFilterConfidence | undefined;
    action?: GuardrailContentPolicyAction | undefined;
}
export type GuardrailContentFilterList = GuardrailContentFilter[];
export interface GuardrailContentPolicyAssessment {
    filters?: GuardrailContentFilter[] | undefined;
}
export type GuardrailWordPolicyAction = "BLOCKED" | (string & {});
export interface GuardrailCustomWord {
    match?: string | undefined;
    action?: GuardrailWordPolicyAction | undefined;
}
export type GuardrailCustomWordList = GuardrailCustomWord[];
export type GuardrailManagedWordType = "PROFANITY" | (string & {});
export interface GuardrailManagedWord {
    match?: string | undefined;
    type?: GuardrailManagedWordType | undefined;
    action?: GuardrailWordPolicyAction | undefined;
}
export type GuardrailManagedWordList = GuardrailManagedWord[];
export interface GuardrailWordPolicyAssessment {
    customWords?: GuardrailCustomWord[] | undefined;
    managedWordLists?: GuardrailManagedWord[] | undefined;
}
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export type GuardrailSensitiveInformationPolicyAction = "BLOCKED" | "ANONYMIZED" | (string & {});
export interface GuardrailPiiEntityFilter {
    type?: GuardrailPiiEntityType | undefined;
    match?: string | undefined;
    action?: GuardrailSensitiveInformationPolicyAction | undefined;
}
export type GuardrailPiiEntityFilterList = GuardrailPiiEntityFilter[];
export interface GuardrailRegexFilter {
    name?: string | undefined;
    regex?: string | undefined;
    match?: string | undefined;
    action?: GuardrailSensitiveInformationPolicyAction | undefined;
}
export type GuardrailRegexFilterList = GuardrailRegexFilter[];
export interface GuardrailSensitiveInformationPolicyAssessment {
    piiEntities?: GuardrailPiiEntityFilter[] | undefined;
    regexes?: GuardrailRegexFilter[] | undefined;
}
export interface GuardrailAssessment {
    topicPolicy?: GuardrailTopicPolicyAssessment | undefined;
    contentPolicy?: GuardrailContentPolicyAssessment | undefined;
    wordPolicy?: GuardrailWordPolicyAssessment | undefined;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicyAssessment | undefined;
}
export type GuardrailAssessmentList = GuardrailAssessment[];
export interface Usage {
    inputTokens?: number | undefined;
    outputTokens?: number | undefined;
}
export interface Metadata {
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    totalTimeMs?: number | undefined;
    operationTotalTimeMs?: number | undefined;
    clientRequestId?: string | undefined;
    usage?: Usage | undefined;
}
export interface GuardrailTrace {
    action?: GuardrailAction | undefined;
    traceId?: string | undefined;
    inputAssessments?: GuardrailAssessment[] | undefined;
    outputAssessments?: GuardrailAssessment[] | undefined;
    metadata?: Metadata | undefined;
}
export type PromptText = string | redacted.Redacted<string>;
export type PromptType = "PRE_PROCESSING" | "ORCHESTRATION" | "KNOWLEDGE_BASE_RESPONSE_GENERATION" | "POST_PROCESSING" | "ROUTING_CLASSIFIER" | (string & {});
export type LambdaArn = string;
export type CreationMode = "DEFAULT" | "OVERRIDDEN" | (string & {});
export type Temperature = number;
export type TopP = number;
export type TopK = number;
export type MaximumLength = number;
export type StopSequences = string[];
export interface InferenceConfiguration {
    temperature?: number | undefined;
    topP?: number | undefined;
    topK?: number | undefined;
    maximumLength?: number | undefined;
    stopSequences?: string[] | undefined;
}
export type ModelIdentifier = string;
export interface ModelInvocationInput {
    traceId?: string | undefined;
    text?: string | redacted.Redacted<string> | undefined;
    type?: PromptType | undefined;
    overrideLambda?: string | undefined;
    promptCreationMode?: CreationMode | undefined;
    inferenceConfiguration?: InferenceConfiguration | undefined;
    parserMode?: CreationMode | undefined;
    foundationModel?: string | undefined;
}
export type RationaleString = string | redacted.Redacted<string>;
export interface PreProcessingParsedResponse {
    rationale?: string | redacted.Redacted<string> | undefined;
    isValid?: boolean | undefined;
}
export interface RawResponse {
    content?: string | undefined;
}
export interface ReasoningTextBlock {
    text: string;
    signature?: string | undefined;
}
export type ReasoningContentBlock = {
    reasoningText: ReasoningTextBlock;
    redactedContent?: undefined;
} | {
    reasoningText?: undefined;
    redactedContent: Uint8Array;
};
export interface PreProcessingModelInvocationOutput {
    traceId?: string | undefined;
    parsedResponse?: PreProcessingParsedResponse | undefined;
    rawResponse?: RawResponse | undefined;
    metadata?: Metadata | undefined;
    reasoningContent?: ReasoningContentBlock | undefined;
}
export type PreProcessingTrace = {
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: undefined;
} | {
    modelInvocationInput?: undefined;
    modelInvocationOutput: PreProcessingModelInvocationOutput;
};
export interface Rationale {
    traceId?: string | undefined;
    text?: string | redacted.Redacted<string> | undefined;
}
export type InvocationType = "ACTION_GROUP" | "KNOWLEDGE_BASE" | "FINISH" | "ACTION_GROUP_CODE_INTERPRETER" | "AGENT_COLLABORATOR" | (string & {});
export type ActionGroupName = string | redacted.Redacted<string>;
export type Verb = string | redacted.Redacted<string>;
export interface Parameter {
    name?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
}
export type Parameters = Parameter[];
export type ContentMap = {
    [key: string]: Parameter[] | undefined;
};
export interface RequestBody {
    content?: {
        [key: string]: Parameter[] | undefined;
    } | undefined;
}
export type ExecutionType = "LAMBDA" | "RETURN_CONTROL" | (string & {});
export interface ActionGroupInvocationInput {
    actionGroupName?: string | redacted.Redacted<string> | undefined;
    verb?: string | redacted.Redacted<string> | undefined;
    apiPath?: string | redacted.Redacted<string> | undefined;
    parameters?: Parameter[] | undefined;
    requestBody?: RequestBody | undefined;
    function?: string | redacted.Redacted<string> | undefined;
    executionType?: ExecutionType | undefined;
    invocationId?: string | undefined;
}
export type KnowledgeBaseLookupInputString = string | redacted.Redacted<string>;
export type TraceKnowledgeBaseId = string | redacted.Redacted<string>;
export interface KnowledgeBaseLookupInput {
    text?: string | redacted.Redacted<string> | undefined;
    knowledgeBaseId?: string | redacted.Redacted<string> | undefined;
}
export type Files = string[];
export interface CodeInterpreterInvocationInput {
    code?: string | undefined;
    files?: string[] | undefined;
}
export type AgentAliasArn = string;
export type PayloadType = "TEXT" | "RETURN_CONTROL" | (string & {});
export type AgentCollaboratorPayloadString = string | redacted.Redacted<string>;
export interface ReturnControlResults {
    invocationId?: string | undefined;
    returnControlInvocationResults?: InvocationResultMember[] | undefined;
}
export interface AgentCollaboratorInputPayload {
    type?: PayloadType | undefined;
    text?: string | redacted.Redacted<string> | undefined;
    returnControlResults?: ReturnControlResults | undefined;
}
export interface AgentCollaboratorInvocationInput {
    agentCollaboratorName?: string | undefined;
    agentCollaboratorAliasArn?: string | undefined;
    input?: AgentCollaboratorInputPayload | undefined;
}
export interface InvocationInput {
    traceId?: string | undefined;
    invocationType?: InvocationType | undefined;
    actionGroupInvocationInput?: ActionGroupInvocationInput | undefined;
    knowledgeBaseLookupInput?: KnowledgeBaseLookupInput | undefined;
    codeInterpreterInvocationInput?: CodeInterpreterInvocationInput | undefined;
    agentCollaboratorInvocationInput?: AgentCollaboratorInvocationInput | undefined;
}
export type Type = "ACTION_GROUP" | "AGENT_COLLABORATOR" | "KNOWLEDGE_BASE" | "FINISH" | "ASK_USER" | "REPROMPT" | (string & {});
export type ActionGroupOutputString = string | redacted.Redacted<string>;
export interface ActionGroupInvocationOutput {
    text?: string | redacted.Redacted<string> | undefined;
    metadata?: Metadata | undefined;
}
export interface ApiParameter {
    name?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
}
export type ApiParameters = ApiParameter[];
export type ParameterList = Parameter[];
export interface PropertyParameters {
    properties?: Parameter[] | undefined;
}
export type ApiContentMap = {
    [key: string]: PropertyParameters | undefined;
};
export interface ApiRequestBody {
    content?: {
        [key: string]: PropertyParameters | undefined;
    } | undefined;
}
export type ActionInvocationType = "RESULT" | "USER_CONFIRMATION" | "USER_CONFIRMATION_AND_RESULT" | (string & {});
export type Name = string | redacted.Redacted<string>;
export interface ApiInvocationInput {
    actionGroup: string;
    httpMethod?: string | undefined;
    apiPath?: string | redacted.Redacted<string> | undefined;
    parameters?: ApiParameter[] | undefined;
    requestBody?: ApiRequestBody | undefined;
    actionInvocationType?: ActionInvocationType | undefined;
    agentId?: string | undefined;
    collaboratorName?: string | redacted.Redacted<string> | undefined;
}
export interface FunctionParameter {
    name?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
}
export type FunctionParameters = FunctionParameter[];
export interface FunctionInvocationInput {
    actionGroup: string;
    parameters?: FunctionParameter[] | undefined;
    function?: string | undefined;
    actionInvocationType?: ActionInvocationType | undefined;
    agentId?: string | undefined;
    collaboratorName?: string | redacted.Redacted<string> | undefined;
}
export type InvocationInputMember = {
    apiInvocationInput: ApiInvocationInput;
    functionInvocationInput?: undefined;
} | {
    apiInvocationInput?: undefined;
    functionInvocationInput: FunctionInvocationInput;
};
export type InvocationInputs = InvocationInputMember[];
export interface ReturnControlPayload {
    invocationInputs?: InvocationInputMember[] | undefined;
    invocationId?: string | undefined;
}
export interface AgentCollaboratorOutputPayload {
    type?: PayloadType | undefined;
    text?: string | redacted.Redacted<string> | undefined;
    returnControlPayload?: ReturnControlPayload | undefined;
}
export interface AgentCollaboratorInvocationOutput {
    agentCollaboratorName?: string | undefined;
    agentCollaboratorAliasArn?: string | undefined;
    output?: AgentCollaboratorOutputPayload | undefined;
    metadata?: Metadata | undefined;
}
export interface KnowledgeBaseLookupOutput {
    retrievedReferences?: RetrievedReference[] | undefined;
    metadata?: Metadata | undefined;
}
export type FinalResponseString = string | redacted.Redacted<string>;
export interface FinalResponse {
    text?: string | redacted.Redacted<string> | undefined;
    metadata?: Metadata | undefined;
}
export type Source = "ACTION_GROUP" | "KNOWLEDGE_BASE" | "PARSER" | (string & {});
export interface RepromptResponse {
    text?: string | undefined;
    source?: Source | undefined;
}
export interface CodeInterpreterInvocationOutput {
    executionOutput?: string | undefined;
    executionError?: string | undefined;
    files?: string[] | undefined;
    executionTimeout?: boolean | undefined;
    metadata?: Metadata | undefined;
}
export interface Observation {
    traceId?: string | undefined;
    type?: Type | undefined;
    actionGroupInvocationOutput?: ActionGroupInvocationOutput | undefined;
    agentCollaboratorInvocationOutput?: AgentCollaboratorInvocationOutput | undefined;
    knowledgeBaseLookupOutput?: KnowledgeBaseLookupOutput | undefined;
    finalResponse?: FinalResponse | undefined;
    repromptResponse?: RepromptResponse | undefined;
    codeInterpreterInvocationOutput?: CodeInterpreterInvocationOutput | undefined;
}
export interface OrchestrationModelInvocationOutput {
    traceId?: string | undefined;
    rawResponse?: RawResponse | undefined;
    metadata?: Metadata | undefined;
    reasoningContent?: ReasoningContentBlock | undefined;
}
export type OrchestrationTrace = {
    rationale: Rationale;
    invocationInput?: undefined;
    observation?: undefined;
    modelInvocationInput?: undefined;
    modelInvocationOutput?: undefined;
} | {
    rationale?: undefined;
    invocationInput: InvocationInput;
    observation?: undefined;
    modelInvocationInput?: undefined;
    modelInvocationOutput?: undefined;
} | {
    rationale?: undefined;
    invocationInput?: undefined;
    observation: Observation;
    modelInvocationInput?: undefined;
    modelInvocationOutput?: undefined;
} | {
    rationale?: undefined;
    invocationInput?: undefined;
    observation?: undefined;
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: undefined;
} | {
    rationale?: undefined;
    invocationInput?: undefined;
    observation?: undefined;
    modelInvocationInput?: undefined;
    modelInvocationOutput: OrchestrationModelInvocationOutput;
};
export type OutputString = string | redacted.Redacted<string>;
export interface PostProcessingParsedResponse {
    text?: string | redacted.Redacted<string> | undefined;
}
export interface PostProcessingModelInvocationOutput {
    traceId?: string | undefined;
    parsedResponse?: PostProcessingParsedResponse | undefined;
    rawResponse?: RawResponse | undefined;
    metadata?: Metadata | undefined;
    reasoningContent?: ReasoningContentBlock | undefined;
}
export type PostProcessingTrace = {
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: undefined;
} | {
    modelInvocationInput?: undefined;
    modelInvocationOutput: PostProcessingModelInvocationOutput;
};
export interface RoutingClassifierModelInvocationOutput {
    traceId?: string | undefined;
    rawResponse?: RawResponse | undefined;
    metadata?: Metadata | undefined;
}
export type RoutingClassifierTrace = {
    invocationInput: InvocationInput;
    observation?: undefined;
    modelInvocationInput?: undefined;
    modelInvocationOutput?: undefined;
} | {
    invocationInput?: undefined;
    observation: Observation;
    modelInvocationInput?: undefined;
    modelInvocationOutput?: undefined;
} | {
    invocationInput?: undefined;
    observation?: undefined;
    modelInvocationInput: ModelInvocationInput;
    modelInvocationOutput?: undefined;
} | {
    invocationInput?: undefined;
    observation?: undefined;
    modelInvocationInput?: undefined;
    modelInvocationOutput: RoutingClassifierModelInvocationOutput;
};
export type FailureReasonString = string | redacted.Redacted<string>;
export interface FailureTrace {
    traceId?: string | undefined;
    failureReason?: string | redacted.Redacted<string> | undefined;
    failureCode?: number | undefined;
    metadata?: Metadata | undefined;
}
export interface CustomOrchestrationTraceEvent {
    text?: string | undefined;
}
export interface CustomOrchestrationTrace {
    traceId?: string | undefined;
    event?: CustomOrchestrationTraceEvent | undefined;
}
export type Trace = {
    guardrailTrace: GuardrailTrace;
    preProcessingTrace?: undefined;
    orchestrationTrace?: undefined;
    postProcessingTrace?: undefined;
    routingClassifierTrace?: undefined;
    failureTrace?: undefined;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace: PreProcessingTrace;
    orchestrationTrace?: undefined;
    postProcessingTrace?: undefined;
    routingClassifierTrace?: undefined;
    failureTrace?: undefined;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace?: undefined;
    orchestrationTrace: OrchestrationTrace;
    postProcessingTrace?: undefined;
    routingClassifierTrace?: undefined;
    failureTrace?: undefined;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace?: undefined;
    orchestrationTrace?: undefined;
    postProcessingTrace: PostProcessingTrace;
    routingClassifierTrace?: undefined;
    failureTrace?: undefined;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace?: undefined;
    orchestrationTrace?: undefined;
    postProcessingTrace?: undefined;
    routingClassifierTrace: RoutingClassifierTrace;
    failureTrace?: undefined;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace?: undefined;
    orchestrationTrace?: undefined;
    postProcessingTrace?: undefined;
    routingClassifierTrace?: undefined;
    failureTrace: FailureTrace;
    customOrchestrationTrace?: undefined;
} | {
    guardrailTrace?: undefined;
    preProcessingTrace?: undefined;
    orchestrationTrace?: undefined;
    postProcessingTrace?: undefined;
    routingClassifierTrace?: undefined;
    failureTrace?: undefined;
    customOrchestrationTrace: CustomOrchestrationTrace;
};
export type Caller = {
    agentAliasArn: string;
};
export type CallerChain = Caller[];
export type AgentVersion = string;
export interface TracePart {
    sessionId?: string | undefined;
    trace?: Trace | undefined;
    callerChain?: Caller[] | undefined;
    eventTime?: Date | undefined;
    collaboratorName?: string | redacted.Redacted<string> | undefined;
    agentId?: string | undefined;
    agentAliasId?: string | undefined;
    agentVersion?: string | undefined;
}
export type FileBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface OutputFile {
    name?: string | undefined;
    type?: string | undefined;
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export type OutputFiles = OutputFile[];
export interface FilePart {
    files?: OutputFile[] | undefined;
}
export type ResponseStream = {
    chunk: PayloadPart;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace: TracePart;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl: ReturnControlPayload;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException: BadGatewayException;
    modelNotReadyException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException: ModelNotReadyException;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    modelNotReadyException?: undefined;
    files: FilePart;
};
export interface InvokeAgentResponse {
    completion: stream.Stream<ResponseStream, Error, never>;
    contentType: string;
    sessionId: string;
    memoryId?: string | undefined;
}
export type NodeOutputName = string;
export type FlowInputContent = {
    document: any;
};
export type NodeInputName = string;
export interface FlowInput {
    nodeName: string;
    nodeOutputName?: string | undefined;
    content: FlowInputContent;
    nodeInputName?: string | undefined;
}
export type FlowInputs = FlowInput[];
export interface ModelPerformanceConfiguration {
    performanceConfig?: PerformanceConfiguration | undefined;
}
export type FlowExecutionId = string;
export interface InvokeFlowRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    inputs: FlowInput[];
    enableTrace?: boolean | undefined;
    modelPerformanceConfiguration?: ModelPerformanceConfiguration | undefined;
    executionId?: string | undefined;
}
export type NodeType = "FlowInputNode" | "FlowOutputNode" | "LambdaFunctionNode" | "KnowledgeBaseNode" | "PromptNode" | "ConditionNode" | "LexNode" | (string & {});
export type FlowOutputContent = {
    document: any;
};
export interface FlowOutputEvent {
    nodeName: string;
    nodeType: NodeType;
    content: FlowOutputContent;
}
export type FlowCompletionReason = "SUCCESS" | "INPUT_REQUIRED" | (string & {});
export interface FlowCompletionEvent {
    completionReason: FlowCompletionReason;
}
export type FlowTraceNodeInputContent = {
    document: any;
};
export type FlowNodeOutputName = string;
export type FlowNodeInputExpression = string | redacted.Redacted<string>;
export interface FlowTraceNodeInputSource {
    nodeName: string;
    outputFieldName: string;
    expression: string | redacted.Redacted<string>;
}
export type FlowNodeIODataType = "String" | "Number" | "Boolean" | "Object" | "Array" | (string & {});
export type FlowNodeInputCategory = "LoopCondition" | "ReturnValueToLoopStart" | "ExitLoop" | (string & {});
export type FlowControlNodeType = "Iterator" | "Loop" | (string & {});
export interface FlowTraceNodeInputExecutionChainItem {
    nodeName: string;
    index?: number | undefined;
    type: FlowControlNodeType;
}
export type FlowTraceNodeInputExecutionChain = FlowTraceNodeInputExecutionChainItem[];
export interface FlowTraceNodeInputField {
    nodeInputName: string;
    content: FlowTraceNodeInputContent;
    source?: FlowTraceNodeInputSource | undefined;
    type?: FlowNodeIODataType | undefined;
    category?: FlowNodeInputCategory | undefined;
    executionChain?: FlowTraceNodeInputExecutionChainItem[] | undefined;
}
export type FlowTraceNodeInputFields = FlowTraceNodeInputField[];
export interface FlowTraceNodeInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowTraceNodeInputField[];
}
export type FlowTraceNodeOutputContent = {
    document: any;
};
export type FlowNodeInputName = string;
export interface FlowTraceNodeOutputNext {
    nodeName: string;
    inputFieldName: string;
}
export type FlowTraceNodeOutputNextList = FlowTraceNodeOutputNext[];
export interface FlowTraceNodeOutputField {
    nodeOutputName: string;
    content: FlowTraceNodeOutputContent;
    next?: FlowTraceNodeOutputNext[] | undefined;
    type?: FlowNodeIODataType | undefined;
}
export type FlowTraceNodeOutputFields = FlowTraceNodeOutputField[];
export interface FlowTraceNodeOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowTraceNodeOutputField[];
}
export interface FlowTraceCondition {
    conditionName: string;
}
export type FlowTraceConditions = FlowTraceCondition[];
export interface FlowTraceConditionNodeResultEvent {
    nodeName: string;
    timestamp: Date;
    satisfiedConditions: FlowTraceCondition[];
}
export interface FlowTraceNodeActionEvent {
    nodeName: string;
    timestamp: Date;
    requestId: string;
    serviceName: string;
    operationName: string;
    operationRequest?: any | undefined;
    operationResponse?: any | undefined;
}
export type AgentTraces = TracePart[];
export type TraceElements = {
    agentTraces: TracePart[];
};
export interface FlowTraceDependencyEvent {
    nodeName: string;
    timestamp: Date;
    traceElements: TraceElements;
}
export type FlowTrace = {
    nodeInputTrace: FlowTraceNodeInputEvent;
    nodeOutputTrace?: undefined;
    conditionNodeResultTrace?: undefined;
    nodeActionTrace?: undefined;
    nodeDependencyTrace?: undefined;
} | {
    nodeInputTrace?: undefined;
    nodeOutputTrace: FlowTraceNodeOutputEvent;
    conditionNodeResultTrace?: undefined;
    nodeActionTrace?: undefined;
    nodeDependencyTrace?: undefined;
} | {
    nodeInputTrace?: undefined;
    nodeOutputTrace?: undefined;
    conditionNodeResultTrace: FlowTraceConditionNodeResultEvent;
    nodeActionTrace?: undefined;
    nodeDependencyTrace?: undefined;
} | {
    nodeInputTrace?: undefined;
    nodeOutputTrace?: undefined;
    conditionNodeResultTrace?: undefined;
    nodeActionTrace: FlowTraceNodeActionEvent;
    nodeDependencyTrace?: undefined;
} | {
    nodeInputTrace?: undefined;
    nodeOutputTrace?: undefined;
    conditionNodeResultTrace?: undefined;
    nodeActionTrace?: undefined;
    nodeDependencyTrace: FlowTraceDependencyEvent;
};
export interface FlowTraceEvent {
    trace: FlowTrace;
}
export type FlowMultiTurnInputContent = {
    document: any;
};
export interface FlowMultiTurnInputRequestEvent {
    nodeName: string;
    nodeType: NodeType;
    content: FlowMultiTurnInputContent;
}
export type FlowResponseStream = {
    flowOutputEvent: FlowOutputEvent;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent: FlowCompletionEvent;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent: FlowTraceEvent;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException: BadGatewayException;
    flowMultiTurnInputRequestEvent?: undefined;
} | {
    flowOutputEvent?: undefined;
    flowCompletionEvent?: undefined;
    flowTraceEvent?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    flowMultiTurnInputRequestEvent: FlowMultiTurnInputRequestEvent;
};
export interface InvokeFlowResponse {
    responseStream: stream.Stream<FlowResponseStream, Error, never>;
    executionId?: string | undefined;
}
export type Instruction = string | redacted.Redacted<string>;
export type SessionTTL = number;
export type ResourceName = string | redacted.Redacted<string>;
export type ResourceDescription = string | redacted.Redacted<string>;
export type ActionGroupSignature = "AMAZON.UserInput" | "AMAZON.CodeInterpreter" | "ANTHROPIC.Computer" | "ANTHROPIC.Bash" | "ANTHROPIC.TextEditor" | (string & {});
export type LambdaResourceArn = string;
export type CustomControlMethod = "RETURN_CONTROL" | (string & {});
export type ActionGroupExecutor = {
    lambda: string;
    customControl?: undefined;
} | {
    lambda?: undefined;
    customControl: CustomControlMethod;
};
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Identifier {
    s3BucketName?: string | undefined;
    s3ObjectKey?: string | undefined;
}
export type Payload = string | redacted.Redacted<string>;
export type APISchema = {
    s3: S3Identifier;
    payload?: undefined;
} | {
    s3?: undefined;
    payload: string | redacted.Redacted<string>;
};
export type FunctionDescription = string;
export type ParameterName = string;
export type ParameterDescription = string;
export type ParameterType = "string" | "number" | "integer" | "boolean" | "array" | (string & {});
export interface ParameterDetail {
    description?: string | undefined;
    type: ParameterType;
    required?: boolean | undefined;
}
export type ParameterMap = {
    [key: string]: ParameterDetail | undefined;
};
export type RequireConfirmation = "ENABLED" | "DISABLED" | (string & {});
export interface FunctionDefinition {
    name: string | redacted.Redacted<string>;
    description?: string | undefined;
    parameters?: {
        [key: string]: ParameterDetail | undefined;
    } | undefined;
    requireConfirmation?: RequireConfirmation | undefined;
}
export type Functions = FunctionDefinition[];
export type FunctionSchema = {
    functions: FunctionDefinition[];
};
export type ActionGroupSignatureParams = {
    [key: string]: string | undefined;
};
export interface AgentActionGroup {
    actionGroupName: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    parentActionGroupSignature?: ActionGroupSignature | undefined;
    actionGroupExecutor?: ActionGroupExecutor | undefined;
    apiSchema?: APISchema | undefined;
    functionSchema?: FunctionSchema | undefined;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AgentActionGroups = AgentActionGroup[];
export interface KnowledgeBase {
    knowledgeBaseId: string;
    description: string | redacted.Redacted<string>;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration | undefined;
}
export type KnowledgeBases = KnowledgeBase[];
export type GuardrailIdentifierWithArn = string;
export type GuardrailVersion = string;
export interface GuardrailConfigurationWithArn {
    guardrailIdentifier: string;
    guardrailVersion: string;
}
export type PromptState = "ENABLED" | "DISABLED" | (string & {});
export type BasePromptTemplate = string | redacted.Redacted<string>;
export interface PromptConfiguration {
    promptType?: PromptType | undefined;
    promptCreationMode?: CreationMode | undefined;
    promptState?: PromptState | undefined;
    basePromptTemplate?: string | redacted.Redacted<string> | undefined;
    inferenceConfiguration?: InferenceConfiguration | undefined;
    parserMode?: CreationMode | undefined;
    foundationModel?: string | undefined;
    additionalModelRequestFields?: any | undefined;
}
export type PromptConfigurations = PromptConfiguration[];
export interface PromptOverrideConfiguration {
    promptConfigurations: PromptConfiguration[];
    overrideLambda?: string | undefined;
}
export type AgentCollaboration = "SUPERVISOR" | "SUPERVISOR_ROUTER" | "DISABLED" | (string & {});
export type CollaborationInstruction = string | redacted.Redacted<string>;
export type RelayConversationHistory = "TO_COLLABORATOR" | "DISABLED" | (string & {});
export interface CollaboratorConfiguration {
    collaboratorName: string | redacted.Redacted<string>;
    collaboratorInstruction: string | redacted.Redacted<string>;
    agentAliasArn?: string | undefined;
    relayConversationHistory?: RelayConversationHistory | undefined;
}
export type CollaboratorConfigurations = CollaboratorConfiguration[];
export interface InlineSessionState {
    sessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    promptSessionAttributes?: {
        [key: string]: string | undefined;
    } | undefined;
    returnControlInvocationResults?: InvocationResultMember[] | undefined;
    invocationId?: string | undefined;
    files?: InputFile[] | undefined;
    conversationHistory?: ConversationHistory | undefined;
}
export interface Collaborator {
    customerEncryptionKeyArn?: string | undefined;
    foundationModel: string;
    instruction: string | redacted.Redacted<string>;
    idleSessionTTLInSeconds?: number | undefined;
    actionGroups?: AgentActionGroup[] | undefined;
    knowledgeBases?: KnowledgeBase[] | undefined;
    guardrailConfiguration?: GuardrailConfigurationWithArn | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
    collaboratorConfigurations?: CollaboratorConfiguration[] | undefined;
    agentName?: string | redacted.Redacted<string> | undefined;
}
export type Collaborators = Collaborator[];
export interface InlineBedrockModelConfigurations {
    performanceConfig?: PerformanceConfiguration | undefined;
}
export type OrchestrationType = "DEFAULT" | "CUSTOM_ORCHESTRATION" | (string & {});
export type OrchestrationExecutor = {
    lambda: string;
};
export interface CustomOrchestration {
    executor?: OrchestrationExecutor | undefined;
}
export interface InvokeInlineAgentRequest {
    customerEncryptionKeyArn?: string | undefined;
    foundationModel: string;
    instruction: string | redacted.Redacted<string>;
    idleSessionTTLInSeconds?: number | undefined;
    actionGroups?: AgentActionGroup[] | undefined;
    knowledgeBases?: KnowledgeBase[] | undefined;
    guardrailConfiguration?: GuardrailConfigurationWithArn | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
    collaboratorConfigurations?: CollaboratorConfiguration[] | undefined;
    agentName?: string | redacted.Redacted<string> | undefined;
    sessionId: string;
    endSession?: boolean | undefined;
    enableTrace?: boolean | undefined;
    inputText?: string | redacted.Redacted<string> | undefined;
    streamingConfigurations?: StreamingConfigurations | undefined;
    promptCreationConfigurations?: PromptCreationConfigurations | undefined;
    inlineSessionState?: InlineSessionState | undefined;
    collaborators?: Collaborator[] | undefined;
    bedrockModelConfigurations?: InlineBedrockModelConfigurations | undefined;
    orchestrationType?: OrchestrationType | undefined;
    customOrchestration?: CustomOrchestration | undefined;
}
export interface InlineAgentPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    attribution?: Attribution | undefined;
}
export interface InlineAgentTracePart {
    sessionId?: string | undefined;
    trace?: Trace | undefined;
    callerChain?: Caller[] | undefined;
    eventTime?: Date | undefined;
    collaboratorName?: string | redacted.Redacted<string> | undefined;
}
export interface InlineAgentReturnControlPayload {
    invocationInputs?: InvocationInputMember[] | undefined;
    invocationId?: string | undefined;
}
export interface InlineAgentFilePart {
    files?: OutputFile[] | undefined;
}
export type InlineAgentResponseStream = {
    chunk: InlineAgentPayloadPart;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace: InlineAgentTracePart;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl: InlineAgentReturnControlPayload;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: undefined;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException: BadGatewayException;
    files?: undefined;
} | {
    chunk?: undefined;
    trace?: undefined;
    returnControl?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
    files: InlineAgentFilePart;
};
export interface InvokeInlineAgentResponse {
    completion: stream.Stream<InlineAgentResponseStream, Error, never>;
    contentType: string;
    sessionId: string;
}
export type FlowExecutionEventType = "Node" | "Flow" | (string & {});
export interface ListFlowExecutionEventsRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    eventType: FlowExecutionEventType;
}
export type FlowExecutionContent = {
    document: any;
};
export interface FlowInputField {
    name: string;
    content: FlowExecutionContent;
}
export type FlowInputFields = FlowInputField[];
export interface FlowExecutionInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowInputField[];
}
export interface FlowOutputField {
    name: string;
    content: FlowExecutionContent;
}
export type FlowOutputFields = FlowOutputField[];
export interface FlowExecutionOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: FlowOutputField[];
}
export type NodeExecutionContent = {
    document: any;
};
export interface NodeInputSource {
    nodeName: string;
    outputFieldName: string;
    expression: string | redacted.Redacted<string>;
}
export interface NodeInputExecutionChainItem {
    nodeName: string;
    index?: number | undefined;
    type: FlowControlNodeType;
}
export type NodeInputExecutionChain = NodeInputExecutionChainItem[];
export interface NodeInputField {
    name: string;
    content: NodeExecutionContent;
    source?: NodeInputSource | undefined;
    type?: FlowNodeIODataType | undefined;
    category?: FlowNodeInputCategory | undefined;
    executionChain?: NodeInputExecutionChainItem[] | undefined;
}
export type NodeInputFields = NodeInputField[];
export interface NodeInputEvent {
    nodeName: string;
    timestamp: Date;
    fields: NodeInputField[];
}
export interface NodeOutputNext {
    nodeName: string;
    inputFieldName: string;
}
export type NodeOutputNextList = NodeOutputNext[];
export interface NodeOutputField {
    name: string;
    content: NodeExecutionContent;
    next?: NodeOutputNext[] | undefined;
    type?: FlowNodeIODataType | undefined;
}
export type NodeOutputFields = NodeOutputField[];
export interface NodeOutputEvent {
    nodeName: string;
    timestamp: Date;
    fields: NodeOutputField[];
}
export interface SatisfiedCondition {
    conditionName: string;
}
export type SatisfiedConditions = SatisfiedCondition[];
export interface ConditionResultEvent {
    nodeName: string;
    timestamp: Date;
    satisfiedConditions: SatisfiedCondition[];
}
export type NodeErrorCode = "VALIDATION" | "DEPENDENCY_FAILED" | "BAD_GATEWAY" | "INTERNAL_SERVER" | (string & {});
export interface NodeFailureEvent {
    nodeName: string;
    timestamp: Date;
    errorCode: NodeErrorCode;
    errorMessage: string;
}
export type FlowErrorCode = "VALIDATION" | "INTERNAL_SERVER" | "NODE_EXECUTION_FAILED" | (string & {});
export interface FlowFailureEvent {
    timestamp: Date;
    errorCode: FlowErrorCode;
    errorMessage: string;
}
export interface NodeActionEvent {
    nodeName: string;
    timestamp: Date;
    requestId: string;
    serviceName: string;
    operationName: string;
    operationRequest?: any | undefined;
    operationResponse?: any | undefined;
}
export type NodeTraceElements = {
    agentTraces: TracePart[];
};
export interface NodeDependencyEvent {
    nodeName: string;
    timestamp: Date;
    traceElements: NodeTraceElements;
}
export type FlowExecutionEvent = {
    flowInputEvent: FlowExecutionInputEvent;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent: FlowExecutionOutputEvent;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent: NodeInputEvent;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent: NodeOutputEvent;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent: ConditionResultEvent;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent: NodeFailureEvent;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent: FlowFailureEvent;
    nodeActionEvent?: undefined;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent: NodeActionEvent;
    nodeDependencyEvent?: undefined;
} | {
    flowInputEvent?: undefined;
    flowOutputEvent?: undefined;
    nodeInputEvent?: undefined;
    nodeOutputEvent?: undefined;
    conditionResultEvent?: undefined;
    nodeFailureEvent?: undefined;
    flowFailureEvent?: undefined;
    nodeActionEvent?: undefined;
    nodeDependencyEvent: NodeDependencyEvent;
};
export type FlowExecutionEvents = FlowExecutionEvent[];
export interface ListFlowExecutionEventsResponse {
    flowExecutionEvents: FlowExecutionEvent[];
    nextToken?: string | undefined;
}
export interface ListFlowExecutionsRequest {
    flowIdentifier: string;
    flowAliasIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FlowExecutionSummary {
    executionArn: string;
    flowAliasIdentifier: string;
    flowIdentifier: string;
    flowVersion: string;
    status: FlowExecutionStatus;
    createdAt: Date;
    endedAt?: Date | undefined;
}
export type FlowExecutionSummaries = FlowExecutionSummary[];
export interface ListFlowExecutionsResponse {
    flowExecutionSummaries: FlowExecutionSummary[];
    nextToken?: string | undefined;
}
export interface ListInvocationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sessionIdentifier: string;
}
export interface InvocationSummary {
    sessionId: string;
    invocationId: string;
    createdAt: Date;
}
export type InvocationSummaries = InvocationSummary[];
export interface ListInvocationsResponse {
    invocationSummaries: InvocationSummary[];
    nextToken?: string | undefined;
}
export interface ListInvocationStepsRequest {
    invocationIdentifier?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sessionIdentifier: string;
}
export interface InvocationStepSummary {
    sessionId: string;
    invocationId: string;
    invocationStepId: string;
    invocationStepTime: Date;
}
export type InvocationStepSummaries = InvocationStepSummary[];
export interface ListInvocationStepsResponse {
    invocationStepSummaries: InvocationStepSummary[];
    nextToken?: string | undefined;
}
export interface ListSessionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SessionSummary {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type SessionSummaries = SessionSummary[];
export interface ListSessionsResponse {
    sessionSummaries: SessionSummary[];
    nextToken?: string | undefined;
}
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TextPrompt {
    text: string;
}
export type InputPrompt = {
    textPrompt: TextPrompt;
};
export interface OptimizePromptRequest {
    input: InputPrompt;
    targetModelId: string;
}
export type OptimizedPrompt = {
    textPrompt: TextPrompt;
};
export interface OptimizedPromptEvent {
    optimizedPrompt?: OptimizedPrompt | undefined;
}
export interface AnalyzePromptEvent {
    message?: string | undefined;
}
export type OptimizedPromptStream = {
    optimizedPromptEvent: OptimizedPromptEvent;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent: AnalyzePromptEvent;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException: InternalServerException;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException: ThrottlingException;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException: ValidationException;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException: DependencyFailedException;
    accessDeniedException?: undefined;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException: AccessDeniedException;
    badGatewayException?: undefined;
} | {
    optimizedPromptEvent?: undefined;
    analyzePromptEvent?: undefined;
    internalServerException?: undefined;
    throttlingException?: undefined;
    validationException?: undefined;
    dependencyFailedException?: undefined;
    accessDeniedException?: undefined;
    badGatewayException: BadGatewayException;
};
export interface OptimizePromptResponse {
    optimizedPrompt: stream.Stream<OptimizedPromptStream, Error, never>;
}
export interface PutInvocationStepRequest {
    sessionIdentifier: string;
    invocationIdentifier: string;
    invocationStepTime: Date;
    payload: InvocationStepPayload;
    invocationStepId?: string | undefined;
}
export interface PutInvocationStepResponse {
    invocationStepId: string;
}
export type RerankQueryContentType = "TEXT" | (string & {});
export interface RerankTextDocument {
    text?: string | undefined;
}
export interface RerankQuery {
    type: RerankQueryContentType;
    textQuery: RerankTextDocument;
}
export type RerankQueriesList = RerankQuery[];
export type RerankSourceType = "INLINE" | (string & {});
export type RerankDocumentType = "TEXT" | "JSON" | (string & {});
export interface RerankDocument {
    type: RerankDocumentType;
    textDocument?: RerankTextDocument | undefined;
    jsonDocument?: any | undefined;
}
export interface RerankSource {
    type: RerankSourceType;
    inlineDocumentSource: RerankDocument;
}
export type RerankSourcesList = RerankSource[];
export type RerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export interface BedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export interface BedrockRerankingConfiguration {
    numberOfResults?: number | undefined;
    modelConfiguration: BedrockRerankingModelConfiguration;
}
export interface RerankingConfiguration {
    type: RerankingConfigurationType;
    bedrockRerankingConfiguration: BedrockRerankingConfiguration;
}
export interface RerankRequest {
    queries: RerankQuery[];
    sources: RerankSource[];
    rerankingConfiguration: RerankingConfiguration;
    nextToken?: string | undefined;
}
export interface RerankResult {
    index: number;
    relevanceScore: number;
    document?: RerankDocument | undefined;
}
export type RerankResultsList = RerankResult[];
export interface RerankResponse {
    results: RerankResult[];
    nextToken?: string | undefined;
}
export type KnowledgeBaseQueryType = "TEXT" | "IMAGE" | (string & {});
export type InputImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export interface InputImage {
    format: InputImageFormat;
    inlineContent: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface KnowledgeBaseQuery {
    type?: KnowledgeBaseQueryType | undefined;
    text?: string | undefined;
    image?: InputImage | undefined;
}
export interface GuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export interface RetrieveRequest {
    knowledgeBaseId: string;
    retrievalQuery: KnowledgeBaseQuery;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    nextToken?: string | undefined;
    userContext?: UserContext | undefined;
}
export interface KnowledgeBaseRetrievalResult {
    content: RetrievalResultContent;
    location?: RetrievalResultLocation | undefined;
    score?: number | undefined;
    metadata?: {
        [key: string]: any | undefined;
    } | undefined;
    documentId?: string | undefined;
}
export type KnowledgeBaseRetrievalResults = KnowledgeBaseRetrievalResult[];
export type GuadrailAction = "INTERVENED" | "NONE" | (string & {});
export interface RetrieveResponse {
    retrievalResults: KnowledgeBaseRetrievalResult[];
    guardrailAction?: GuadrailAction | undefined;
    nextToken?: string | undefined;
}
export interface RetrieveAndGenerateInput {
    text: string;
}
export type RetrieveAndGenerateType = "KNOWLEDGE_BASE" | "EXTERNAL_SOURCES" | (string & {});
export type TextPromptTemplate = string | redacted.Redacted<string>;
export interface PromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string> | undefined;
}
export type MaxTokens = number;
export type RAGStopSequences = string[];
export interface TextInferenceConfig {
    temperature?: number | undefined;
    topP?: number | undefined;
    maxTokens?: number | undefined;
    stopSequences?: string[] | undefined;
}
export interface InferenceConfig {
    textInferenceConfig?: TextInferenceConfig | undefined;
}
export interface GenerationConfiguration {
    promptTemplate?: PromptTemplate | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    inferenceConfig?: InferenceConfig | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
}
export type QueryTransformationType = "QUERY_DECOMPOSITION" | (string & {});
export interface QueryTransformationConfiguration {
    type: QueryTransformationType;
}
export interface OrchestrationConfiguration {
    promptTemplate?: PromptTemplate | undefined;
    inferenceConfig?: InferenceConfig | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
    queryTransformationConfiguration?: QueryTransformationConfiguration | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
}
export interface KnowledgeBaseRetrieveAndGenerateConfiguration {
    knowledgeBaseId: string;
    modelArn: string;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration | undefined;
    generationConfiguration?: GenerationConfiguration | undefined;
    orchestrationConfiguration?: OrchestrationConfiguration | undefined;
}
export type ExternalSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export interface S3ObjectDoc {
    uri: string;
}
export type Identifier = string | redacted.Redacted<string>;
export type ContentType = string;
export interface ByteContentDoc {
    identifier: string | redacted.Redacted<string>;
    contentType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface ExternalSource {
    sourceType: ExternalSourceType;
    s3Location?: S3ObjectDoc | undefined;
    byteContent?: ByteContentDoc | undefined;
}
export type ExternalSources = ExternalSource[];
export interface ExternalSourcesGenerationConfiguration {
    promptTemplate?: PromptTemplate | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    inferenceConfig?: InferenceConfig | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
}
export interface ExternalSourcesRetrieveAndGenerateConfiguration {
    modelArn: string;
    sources: ExternalSource[];
    generationConfiguration?: ExternalSourcesGenerationConfiguration | undefined;
}
export interface RetrieveAndGenerateConfiguration {
    type: RetrieveAndGenerateType;
    knowledgeBaseConfiguration?: KnowledgeBaseRetrieveAndGenerateConfiguration | undefined;
    externalSourcesConfiguration?: ExternalSourcesRetrieveAndGenerateConfiguration | undefined;
}
export interface RetrieveAndGenerateSessionConfiguration {
    kmsKeyArn: string;
}
export interface RetrieveAndGenerateRequest {
    sessionId?: string | undefined;
    input: RetrieveAndGenerateInput;
    retrieveAndGenerateConfiguration?: RetrieveAndGenerateConfiguration | undefined;
    sessionConfiguration?: RetrieveAndGenerateSessionConfiguration | undefined;
    userContext?: UserContext | undefined;
}
export interface RetrieveAndGenerateOutput {
    text: string;
}
export interface RetrieveAndGenerateResponse {
    sessionId: string;
    output: RetrieveAndGenerateOutput;
    citations?: Citation[] | undefined;
    guardrailAction?: GuadrailAction | undefined;
}
export interface RetrieveAndGenerateStreamRequest {
    sessionId?: string | undefined;
    input: RetrieveAndGenerateInput;
    retrieveAndGenerateConfiguration?: RetrieveAndGenerateConfiguration | undefined;
    sessionConfiguration?: RetrieveAndGenerateSessionConfiguration | undefined;
    userContext?: UserContext | undefined;
}
export interface RetrieveAndGenerateOutputEvent {
    text: string;
}
export interface CitationEvent {
    citation?: Citation | undefined;
    generatedResponsePart?: GeneratedResponsePart | undefined;
    retrievedReferences?: RetrievedReference[] | undefined;
}
export interface GuardrailEvent {
    action?: GuadrailAction | undefined;
}
export type RetrieveAndGenerateStreamResponseOutput = {
    output: RetrieveAndGenerateOutputEvent;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation: CitationEvent;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail: GuardrailEvent;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException: InternalServerException;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException: ValidationException;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException: ResourceNotFoundException;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException: ServiceQuotaExceededException;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException: ThrottlingException;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException: AccessDeniedException;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException: ConflictException;
    dependencyFailedException?: undefined;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException: DependencyFailedException;
    badGatewayException?: undefined;
} | {
    output?: undefined;
    citation?: undefined;
    guardrail?: undefined;
    internalServerException?: undefined;
    validationException?: undefined;
    resourceNotFoundException?: undefined;
    serviceQuotaExceededException?: undefined;
    throttlingException?: undefined;
    accessDeniedException?: undefined;
    conflictException?: undefined;
    dependencyFailedException?: undefined;
    badGatewayException: BadGatewayException;
};
export interface RetrieveAndGenerateStreamResponse {
    stream: stream.Stream<RetrieveAndGenerateStreamResponseOutput, Error, never>;
    sessionId: string;
}
export type FlowExecutionName = string;
export interface StartFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    flowExecutionName?: string | undefined;
    inputs: FlowInput[];
    modelPerformanceConfiguration?: ModelPerformanceConfiguration | undefined;
}
export interface StartFlowExecutionResponse {
    executionArn?: string | undefined;
}
export interface StopFlowExecutionRequest {
    flowIdentifier: string;
    flowAliasIdentifier: string;
    executionIdentifier: string;
}
export interface StopFlowExecutionResponse {
    executionArn?: string | undefined;
    status: FlowExecutionStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateSessionRequest {
    sessionMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    sessionIdentifier: string;
}
export interface UpdateSessionResponse {
    sessionId: string;
    sessionArn: string;
    sessionStatus: SessionStatus;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type AgenticRetrieveStreamError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information from one or more knowledge bases using an agentic approach. Agentic retrieval uses a foundation model to intelligently decompose complex queries into sub-queries and iteratively retrieve relevant information from your knowledge bases. This approach improves retrieval accuracy for complex, multi-step questions that a single retrieval pass might not fully address.
 *
 * The operation returns results through a stream that includes retrieval results, trace events for visibility into the process, and a generated response synthesized from the results by default, which can be turned off.
 */
export declare const agenticRetrieveStream: API.OperationMethod<AgenticRetrieveStreamRequest & RegionInput, AgenticRetrieveStreamResponse, AgenticRetrieveStreamError, Credentials | HttpClient.HttpClient>;
export type CheckIngestedDocumentAclError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks whether a user has access to a specific document by verifying against the ingested access control list (ACL) in a knowledge base. Use this operation to validate that document-level access control is working as expected after ingestion. To use this operation, you must have the `bedrock:CheckIngestedDocumentAcl` permission.
 */
export declare const checkIngestedDocumentAcl: API.OperationMethod<CheckIngestedDocumentAclRequest & RegionInput, CheckIngestedDocumentAclResponse, CheckIngestedDocumentAclError, Credentials | HttpClient.HttpClient>;
export type CreateInvocationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new invocation within a session. An invocation groups the related invocation steps that store the content from a conversation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * Related APIs
 *
 * - ListInvocations
 *
 * - ListSessions
 *
 * - GetSession
 */
export declare const createInvocation: API.OperationMethod<CreateInvocationRequest & RegionInput, CreateInvocationResponse, CreateInvocationError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a session to temporarily store conversations for generative AI (GenAI) applications built with open-source frameworks such as LangGraph and LlamaIndex. Sessions enable you to save the state of conversations at checkpoints, with the added security and infrastructure of Amazon Web Services. For more information, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * By default, Amazon Bedrock uses Amazon Web Services-managed keys for session encryption, including session metadata, or you can use your own KMS key. For more information, see Amazon Bedrock session encryption.
 *
 * You use a session to store state and conversation history for generative AI applications built with open-source frameworks. For Amazon Bedrock Agents, the service automatically manages conversation context and associates them with the agent-specific sessionId you specify in the InvokeAgent API operation.
 *
 * Related APIs:
 *
 * - ListSessions
 *
 * - GetSession
 *
 * - EndSession
 *
 * - DeleteSession
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest & RegionInput, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentMemoryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes memory from the specified memory identifier.
 */
export declare const deleteAgentMemory: API.OperationMethod<DeleteAgentMemoryRequest & RegionInput, DeleteAgentMemoryResponse, DeleteAgentMemoryError, Credentials | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a session that you ended. You can't delete a session with an `ACTIVE` status. To delete an active session, you must first end it with the EndSession API operation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest & RegionInput, DeleteSessionResponse, DeleteSessionError, Credentials | HttpClient.HttpClient>;
export type EndSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ends the session. After you end a session, you can still access its content but you can't add to it. To delete the session and it's content, you use the DeleteSession API operation. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const endSession: API.OperationMethod<EndSessionRequest & RegionInput, EndSessionResponse, EndSessionError, Credentials | HttpClient.HttpClient>;
export type GenerateQueryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates an SQL query from a natural language query. For more information, see Generate a query for structured data in the Amazon Bedrock User Guide.
 */
export declare const generateQuery: API.OperationMethod<GenerateQueryRequest & RegionInput, GenerateQueryResponse, GenerateQueryError, Credentials | HttpClient.HttpClient>;
export type GetAgentMemoryError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the sessions stored in the memory of the agent.
 */
export declare const getAgentMemory: API.PaginatedOperationMethod<GetAgentMemoryRequest & RegionInput, GetAgentMemoryResponse, GetAgentMemoryError, Credentials | HttpClient.HttpClient, Memory>;
export type GetDocumentContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the content of an ingested document from a knowledge base, or of an image embedded in the document. Returns a pre-signed URL for downloading the content. Use this operation to display the source of a `Retrieve` result.
 */
export declare const getDocumentContent: API.OperationMethod<GetDocumentContentRequest & RegionInput, GetDocumentContentResponse, GetDocumentContentError, Credentials | HttpClient.HttpClient>;
export type GetExecutionFlowSnapshotError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the flow definition snapshot used for a flow execution. The snapshot represents the flow metadata and definition as it existed at the time the execution was started. Note that even if the flow is edited after an execution starts, the snapshot connected to the execution remains unchanged.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const getExecutionFlowSnapshot: API.OperationMethod<GetExecutionFlowSnapshotRequest & RegionInput, GetExecutionFlowSnapshotResponse, GetExecutionFlowSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetFlowExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific flow execution, including its status, start and end times, and any errors that occurred during execution.
 */
export declare const getFlowExecution: API.OperationMethod<GetFlowExecutionRequest & RegionInput, GetFlowExecutionResponse, GetFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type GetIngestedDocumentAclError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the ingested access control list (ACL) for a specific document in a knowledge base. Use this operation to inspect the allow and deny lists that were ingested for a document to troubleshoot access control issues. To use this operation, you must have the `bedrock:GetIngestedDocumentAcl` permission.
 */
export declare const getIngestedDocumentAcl: API.OperationMethod<GetIngestedDocumentAclRequest & RegionInput, GetIngestedDocumentAclResponse, GetIngestedDocumentAclError, Credentials | HttpClient.HttpClient>;
export type GetInvocationStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific invocation step within an invocation in a session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const getInvocationStep: API.OperationMethod<GetInvocationStepRequest & RegionInput, GetInvocationStepResponse, GetInvocationStepError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest & RegionInput, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type InvokeAgentError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ModelNotReadyException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Bedrock Agents (now Amazon Bedrock Agents Classic) is no longer open to new customers. For capabilities similar to Bedrock Agents Classic, explore Amazon Bedrock AgentCore. Existing customers can continue to use the service as normal. For more information, see Amazon Bedrock Agents Classic availability change.
 *
 * Sends a prompt for the agent to process and respond to. Note the following fields for the request:
 *
 * - To continue the same conversation with an agent, use the same `sessionId` value in the request.
 *
 * - To activate trace enablement, turn `enableTrace` to `true`. Trace enablement helps you follow the agent's reasoning process that led it to the information it processed, the actions it took, and the final result it yielded. For more information, see Trace enablement.
 *
 * - End a conversation by setting `endSession` to `true`.
 *
 * - In the `sessionState` object, you can include attributes for the session or prompt or, if you configured an action group to return control, results from invocation of the action group.
 *
 * The response contains both **chunk** and **trace** attributes.
 *
 * The final response is returned in the `bytes` field of the `chunk` object. The `InvokeAgent` returns one chunk for the entire interaction.
 *
 * - The `attribution` object contains citations for parts of the response.
 *
 * - If you set `enableTrace` to `true` in the request, you can trace the agent's steps and reasoning process that led it to the response.
 *
 * - If the action predicted was configured to return control, the response returns parameters for the action, elicited from the user, in the `returnControl` field.
 *
 * - Errors are also surfaced in the response.
 */
export declare const invokeAgent: API.OperationMethod<InvokeAgentRequest & RegionInput, InvokeAgentResponse, InvokeAgentError, Credentials | HttpClient.HttpClient>;
export type InvokeFlowError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an alias of a flow to run the inputs that you specify and return the output of each node as a stream. If there's an error, the error is returned. For more information, see Test a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeFlow`.
 */
export declare const invokeFlow: API.OperationMethod<InvokeFlowRequest & RegionInput, InvokeFlowResponse, InvokeFlowError, Credentials | HttpClient.HttpClient>;
export type InvokeInlineAgentError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes an inline Amazon Bedrock agent using the configurations you provide with the request.
 *
 * - Specify the following fields for security purposes.
 *
 * - (Optional) `customerEncryptionKeyArn` - The Amazon Resource Name (ARN) of a KMS key to encrypt the creation of the agent.
 *
 * - (Optional) `idleSessionTTLinSeconds` - Specify the number of seconds for which the agent should maintain session information. After this time expires, the subsequent `InvokeInlineAgent` request begins a new session.
 *
 * - To override the default prompt behavior for agent orchestration and to use advanced prompts, include a `promptOverrideConfiguration` object. For more information, see Advanced prompts.
 *
 * - The agent instructions will not be honored if your agent has only one knowledge base, uses default prompts, has no action group, and user input is disabled.
 */
export declare const invokeInlineAgent: API.OperationMethod<InvokeInlineAgentRequest & RegionInput, InvokeInlineAgentResponse, InvokeInlineAgentError, Credentials | HttpClient.HttpClient>;
export type ListFlowExecutionEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists events that occurred during a flow execution. Events provide detailed information about the execution progress, including node inputs and outputs, flow inputs and outputs, condition results, and failure events.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const listFlowExecutionEvents: API.PaginatedOperationMethod<ListFlowExecutionEventsRequest & RegionInput, ListFlowExecutionEventsResponse, ListFlowExecutionEventsError, Credentials | HttpClient.HttpClient, FlowExecutionEvent>;
export type ListFlowExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all executions of a flow. Results can be paginated and include summary information about each execution, such as status, start and end times, and the execution's Amazon Resource Name (ARN).
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const listFlowExecutions: API.PaginatedOperationMethod<ListFlowExecutionsRequest & RegionInput, ListFlowExecutionsResponse, ListFlowExecutionsError, Credentials | HttpClient.HttpClient, FlowExecutionSummary>;
export type ListInvocationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all invocations associated with a specific session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listInvocations: API.PaginatedOperationMethod<ListInvocationsRequest & RegionInput, ListInvocationsResponse, ListInvocationsError, Credentials | HttpClient.HttpClient, InvocationSummary>;
export type ListInvocationStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all invocation steps associated with a session and optionally, an invocation within the session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listInvocationSteps: API.PaginatedOperationMethod<ListInvocationStepsRequest & RegionInput, ListInvocationStepsResponse, ListInvocationStepsError, Credentials | HttpClient.HttpClient, InvocationStepSummary>;
export type ListSessionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all sessions in your Amazon Web Services account. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest & RegionInput, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all the tags for the resource you specify.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type OptimizePromptError = AccessDeniedException | BadGatewayException | DependencyFailedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Optimizes a prompt for the task that you specify. For more information, see Optimize a prompt in the Amazon Bedrock User Guide.
 */
export declare const optimizePrompt: API.OperationMethod<OptimizePromptRequest & RegionInput, OptimizePromptResponse, OptimizePromptError, Credentials | HttpClient.HttpClient>;
export type PutInvocationStepError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Add an invocation step to an invocation in a session. An invocation step stores fine-grained state checkpoints, including text and images, for each interaction. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 *
 * Related APIs:
 *
 * - GetInvocationStep
 *
 * - ListInvocationSteps
 *
 * - ListInvocations
 *
 * - ListSessions
 */
export declare const putInvocationStep: API.OperationMethod<PutInvocationStepRequest & RegionInput, PutInvocationStepResponse, PutInvocationStepError, Credentials | HttpClient.HttpClient>;
export type RerankError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reranks the relevance of sources based on queries. For more information, see Improve the relevance of query responses with a reranker model.
 */
export declare const rerank: API.PaginatedOperationMethod<RerankRequest & RegionInput, RerankResponse, RerankError, Credentials | HttpClient.HttpClient, RerankResult>;
export type RetrieveError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and retrieves information from it.
 */
export declare const retrieve: API.PaginatedOperationMethod<RetrieveRequest & RegionInput, RetrieveResponse, RetrieveError, Credentials | HttpClient.HttpClient, KnowledgeBaseRetrievalResult>;
export type RetrieveAndGenerateError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and generates responses based on the retrieved results and using the specified foundation model or inference profile. The response only cites sources that are relevant to the query.
 *
 * This API cannot be used with managed knowledge bases. Use AgenticRetrieveStream or Retrieve with managed knowledge bases.
 */
export declare const retrieveAndGenerate: API.OperationMethod<RetrieveAndGenerateRequest & RegionInput, RetrieveAndGenerateResponse, RetrieveAndGenerateError, Credentials | HttpClient.HttpClient>;
export type RetrieveAndGenerateStreamError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Queries a knowledge base and generates responses based on the retrieved results, with output in streaming format.
 *
 * This API cannot be used with managed knowledge bases. Use AgenticRetrieveStream or Retrieve with managed knowledge bases.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeModelWithResponseStream`.
 *
 * This operation requires permission for the ` bedrock:RetrieveAndGenerate` action.
 */
export declare const retrieveAndGenerateStream: API.OperationMethod<RetrieveAndGenerateStreamRequest & RegionInput, RetrieveAndGenerateStreamResponse, RetrieveAndGenerateStreamError, Credentials | HttpClient.HttpClient>;
export type StartFlowExecutionError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an execution of an Amazon Bedrock flow. Unlike flows that run until completion or time out after five minutes, flow executions let you run flows asynchronously for longer durations. Flow executions also yield control so that your application can perform other tasks.
 *
 * This operation returns an Amazon Resource Name (ARN) that you can use to track and manage your flow execution.
 *
 * Flow executions is in preview release for Amazon Bedrock and is subject to change.
 */
export declare const startFlowExecution: API.OperationMethod<StartFlowExecutionRequest & RegionInput, StartFlowExecutionResponse, StartFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type StopFlowExecutionError = AccessDeniedException | BadGatewayException | ConflictException | DependencyFailedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an Amazon Bedrock flow's execution. This operation prevents further processing of the flow and changes the execution status to `Aborted`.
 */
export declare const stopFlowExecution: API.OperationMethod<StopFlowExecutionRequest & RegionInput, StopFlowExecutionResponse, StopFlowExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the metadata or encryption settings of a session. For more information about sessions, see Store and retrieve conversation history and context with Amazon Bedrock sessions.
 */
export declare const updateSession: API.OperationMethod<UpdateSessionRequest & RegionInput, UpdateSessionResponse, UpdateSessionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agent-runtime.d.ts.map