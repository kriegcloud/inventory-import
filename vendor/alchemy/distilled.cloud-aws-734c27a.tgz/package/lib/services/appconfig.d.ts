import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly Reason: any;
    readonly Details: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PayloadTooLargeException_base: S.TaggedErrorClass<"PayloadTooLargeException", {
    readonly message: any;
    readonly Measure: any;
    readonly Limit: any;
    readonly Size: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type Name = string;
export type Description = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateApplicationRequest {
    Name: string;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Id = string;
export interface Application {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type LongName = string;
export type Uri = string;
export type RoleArn = string;
export type ValidatorType = "JSON_SCHEMA" | "LAMBDA" | (string & {});
export type StringWithLengthBetween0And32768 = string | redacted.Redacted<string>;
export interface Validator {
    Type: ValidatorType;
    Content: string | redacted.Redacted<string>;
}
export type ValidatorList = Validator[];
export type ConfigurationProfileType = string;
export type KmsKeyIdentifier = string;
export interface CreateConfigurationProfileRequest {
    ApplicationId: string;
    Name: string;
    Description?: string | undefined;
    LocationUri: string;
    RetrievalRoleArn?: string | undefined;
    Validators?: Validator[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: string | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export type Arn = string;
export interface ConfigurationProfile {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    LocationUri?: string | undefined;
    RetrievalRoleArn?: string | undefined;
    Validators?: Validator[] | undefined;
    Type?: string | undefined;
    KmsKeyArn?: string | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export type MinutesBetween0And24Hours = number;
export type GrowthFactor = number;
export type GrowthType = "LINEAR" | "EXPONENTIAL" | (string & {});
export type ReplicateTo = "NONE" | "SSM_DOCUMENT" | (string & {});
export interface CreateDeploymentStrategyRequest {
    Name: string;
    Description?: string | undefined;
    DeploymentDurationInMinutes: number;
    FinalBakeTimeInMinutes?: number | undefined;
    GrowthFactor: number;
    GrowthType?: GrowthType | undefined;
    ReplicateTo?: ReplicateTo | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Percentage = number;
export interface DeploymentStrategy {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    DeploymentDurationInMinutes?: number | undefined;
    GrowthType?: GrowthType | undefined;
    GrowthFactor?: number | undefined;
    FinalBakeTimeInMinutes?: number | undefined;
    ReplicateTo?: ReplicateTo | undefined;
}
export type StringWithLengthBetween1And2048 = string;
export interface Monitor {
    AlarmArn: string;
    AlarmRoleArn?: string | undefined;
}
export type MonitorList = Monitor[];
export interface CreateEnvironmentRequest {
    ApplicationId: string;
    Name: string;
    Description?: string | undefined;
    Monitors?: Monitor[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EnvironmentState = "READY_FOR_DEPLOYMENT" | "DEPLOYING" | "ROLLING_BACK" | "ROLLED_BACK" | "REVERTED" | (string & {});
export interface Environment {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    State?: EnvironmentState | undefined;
    Monitors?: Monitor[] | undefined;
}
export type Identifier = string;
export type NameWithReservedAwsPrefix = string;
export type FlagKey = string;
export type Weight = number;
export type AttributeKey = string;
export type AttributeString = string;
export type StringList = string[];
export type NumberList = number[];
export type AttributeValue = {
    StringValue: string;
    NumberValue?: undefined;
    BooleanValue?: undefined;
    StringArray?: undefined;
    NumberArray?: undefined;
} | {
    StringValue?: undefined;
    NumberValue: number;
    BooleanValue?: undefined;
    StringArray?: undefined;
    NumberArray?: undefined;
} | {
    StringValue?: undefined;
    NumberValue?: undefined;
    BooleanValue: boolean;
    StringArray?: undefined;
    NumberArray?: undefined;
} | {
    StringValue?: undefined;
    NumberValue?: undefined;
    BooleanValue?: undefined;
    StringArray: string[];
    NumberArray?: undefined;
} | {
    StringValue?: undefined;
    NumberValue?: undefined;
    BooleanValue?: undefined;
    StringArray?: undefined;
    NumberArray: number[];
};
export type AttributeValueMap = {
    [key: string]: AttributeValue | undefined;
};
export interface FlagValue {
    Enabled: boolean;
    AttributeValues?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface TreatmentInput {
    Weight: number;
    Description?: string | undefined;
    FlagValue: FlagValue;
}
export type TreatmentInputList = TreatmentInput[];
export type Rule = string;
export interface CreateExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    Name: string;
    ConfigurationProfileIdentifier: string;
    EnvironmentIdentifier: string;
    FlagKey: string;
    Treatments: TreatmentInput[];
    Control: TreatmentInput;
    AudienceRule: string;
    Hypothesis?: string | undefined;
    AudienceDescription?: string | undefined;
    LaunchCriteria?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExperimentDefinitionStatus = "ACTIVE" | "IDLE" | "ARCHIVED" | (string & {});
export type TreatmentKey = string;
export interface Treatment {
    Key?: string | undefined;
    Weight: number;
    Description?: string | undefined;
    FlagValue: FlagValue;
}
export type TreatmentList = Treatment[];
export type Iso8601DateTime = Date;
export interface ExperimentDefinition {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Hypothesis?: string | undefined;
    Status?: ExperimentDefinitionStatus | undefined;
    ConfigurationProfileId?: string | undefined;
    EnvironmentId?: string | undefined;
    FlagKey?: string | undefined;
    AudienceRule?: string | undefined;
    AudienceDescription?: string | undefined;
    LaunchCriteria?: string | undefined;
    Treatments?: Treatment[] | undefined;
    Control?: Treatment | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export type ExtensionOrParameterName = string;
export type ActionPoint = "PRE_CREATE_HOSTED_CONFIGURATION_VERSION" | "PRE_START_DEPLOYMENT" | "AT_DEPLOYMENT_TICK" | "ON_DEPLOYMENT_START" | "ON_DEPLOYMENT_STEP" | "ON_DEPLOYMENT_BAKING" | "ON_DEPLOYMENT_COMPLETE" | "ON_DEPLOYMENT_ROLLED_BACK" | (string & {});
export interface Action {
    Name?: string | undefined;
    Description?: string | undefined;
    Uri?: string | undefined;
    RoleArn?: string | undefined;
}
export type ActionList = Action[];
export type ActionsMap = {
    [key in ActionPoint]?: Action[] | undefined;
};
export interface Parameter {
    Description?: string | undefined;
    Required?: boolean | undefined;
    Dynamic?: boolean | undefined;
}
export type ParameterMap = {
    [key: string]: Parameter | undefined;
};
export interface CreateExtensionRequest {
    Name: string;
    Description?: string | undefined;
    Actions: {
        [key: string]: Action[] | undefined;
    };
    Parameters?: {
        [key: string]: Parameter | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    LatestVersionNumber?: number | undefined;
}
export interface Extension {
    Id?: string | undefined;
    Name?: string | undefined;
    VersionNumber?: number | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
    Actions?: {
        [key: string]: Action[] | undefined;
    } | undefined;
    Parameters?: {
        [key: string]: Parameter | undefined;
    } | undefined;
}
export type ParameterValueMap = {
    [key: string]: string | undefined;
};
export interface CreateExtensionAssociationRequest {
    ExtensionIdentifier: string;
    ExtensionVersionNumber?: number | undefined;
    ResourceIdentifier: string;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ExtensionAssociation {
    Id?: string | undefined;
    ExtensionArn?: string | undefined;
    ResourceArn?: string | undefined;
    Arn?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ExtensionVersionNumber?: number | undefined;
}
export type StringWithLengthBetween1And255 = string;
export type VersionLabel = string;
export interface CreateHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    Description?: string | undefined;
    Content: T.StreamingInputBody;
    ContentType: string;
    LatestVersionNumber?: number | undefined;
    VersionLabel?: string | undefined;
}
export interface HostedConfigurationVersion {
    ApplicationId?: string | undefined;
    ConfigurationProfileId?: string | undefined;
    VersionNumber?: number | undefined;
    Description?: string | undefined;
    Content?: T.StreamingOutputBody | undefined;
    ContentType?: string | undefined;
    VersionLabel?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export interface DeleteApplicationRequest {
    ApplicationId: string;
}
export interface DeleteApplicationResponse {
}
export type DeletionProtectionCheck = "ACCOUNT_DEFAULT" | "APPLY" | "BYPASS" | (string & {});
export interface DeleteConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    DeletionProtectionCheck?: DeletionProtectionCheck | undefined;
}
export interface DeleteConfigurationProfileResponse {
}
export type DeploymentStrategyId = string;
export interface DeleteDeploymentStrategyRequest {
    DeploymentStrategyId: string;
}
export interface DeleteDeploymentStrategyResponse {
}
export interface DeleteEnvironmentRequest {
    EnvironmentId: string;
    ApplicationId: string;
    DeletionProtectionCheck?: DeletionProtectionCheck | undefined;
}
export interface DeleteEnvironmentResponse {
}
export type DeleteType = "ARCHIVE" | "DESTROY" | (string & {});
export interface DeleteExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    DeleteType?: DeleteType | undefined;
}
export interface DeleteExperimentDefinitionResponse {
}
export interface DeleteExtensionRequest {
    ExtensionIdentifier: string;
    VersionNumber?: number | undefined;
}
export interface DeleteExtensionResponse {
}
export interface DeleteExtensionAssociationRequest {
    ExtensionAssociationId: string;
}
export interface DeleteExtensionAssociationResponse {
}
export interface DeleteHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    VersionNumber: number;
}
export interface DeleteHostedConfigurationVersionResponse {
}
export interface GetAccountSettingsRequest {
}
export type DeletionProtectionDuration = number;
export interface DeletionProtectionSettings {
    Enabled?: boolean | undefined;
    ProtectionPeriodInMinutes?: number | undefined;
}
export interface VendedMetricsSettings {
    Enabled?: boolean | undefined;
}
export interface AccountSettings {
    DeletionProtection?: DeletionProtectionSettings | undefined;
    VendedMetrics?: VendedMetricsSettings | undefined;
}
export interface GetApplicationRequest {
    ApplicationId: string;
}
export type StringWithLengthBetween1And64 = string;
export type Version = string;
export interface GetConfigurationRequest {
    Application: string;
    Environment: string;
    Configuration: string;
    ClientId: string;
    ClientConfigurationVersion?: string | undefined;
}
export interface Configuration {
    Content?: T.StreamingOutputBody | undefined;
    ConfigurationVersion?: string | undefined;
    ContentType?: string | undefined;
}
export interface GetConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
}
export interface GetDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentNumber: number;
}
export type DeploymentState = "BAKING" | "VALIDATING" | "DEPLOYING" | "COMPLETE" | "ROLLING_BACK" | "ROLLED_BACK" | "REVERTED" | (string & {});
export type DeploymentEventType = "PERCENTAGE_UPDATED" | "ROLLBACK_STARTED" | "ROLLBACK_COMPLETED" | "BAKE_TIME_STARTED" | "DEPLOYMENT_STARTED" | "DEPLOYMENT_COMPLETED" | "REVERT_COMPLETED" | (string & {});
export type TriggeredBy = "USER" | "APPCONFIG" | "CLOUDWATCH_ALARM" | "INTERNAL_ERROR" | (string & {});
export interface ActionInvocation {
    ExtensionIdentifier?: string | undefined;
    ActionName?: string | undefined;
    Uri?: string | undefined;
    RoleArn?: string | undefined;
    ErrorMessage?: string | undefined;
    ErrorCode?: string | undefined;
    InvocationId?: string | undefined;
}
export type ActionInvocations = ActionInvocation[];
export interface DeploymentEvent {
    EventType?: DeploymentEventType | undefined;
    TriggeredBy?: TriggeredBy | undefined;
    Description?: string | undefined;
    ActionInvocations?: ActionInvocation[] | undefined;
    OccurredAt?: Date | undefined;
}
export type DeploymentEvents = DeploymentEvent[];
export interface AppliedExtension {
    ExtensionId?: string | undefined;
    ExtensionAssociationId?: string | undefined;
    VersionNumber?: number | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AppliedExtensions = AppliedExtension[];
export interface Deployment {
    ApplicationId?: string | undefined;
    EnvironmentId?: string | undefined;
    DeploymentStrategyId?: string | undefined;
    ConfigurationProfileId?: string | undefined;
    DeploymentNumber?: number | undefined;
    ConfigurationName?: string | undefined;
    ConfigurationLocationUri?: string | undefined;
    ConfigurationVersion?: string | undefined;
    Description?: string | undefined;
    DeploymentDurationInMinutes?: number | undefined;
    GrowthType?: GrowthType | undefined;
    GrowthFactor?: number | undefined;
    FinalBakeTimeInMinutes?: number | undefined;
    State?: DeploymentState | undefined;
    EventLog?: DeploymentEvent[] | undefined;
    PercentageComplete?: number | undefined;
    StartedAt?: Date | undefined;
    CompletedAt?: Date | undefined;
    AppliedExtensions?: AppliedExtension[] | undefined;
    KmsKeyArn?: string | undefined;
    KmsKeyIdentifier?: string | undefined;
    VersionLabel?: string | undefined;
}
export interface GetDeploymentStrategyRequest {
    DeploymentStrategyId: string;
}
export interface GetEnvironmentRequest {
    ApplicationId: string;
    EnvironmentId: string;
}
export interface GetExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
}
export type PositiveInteger = number;
export interface GetExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
}
export type ExperimentRunStatus = "RUNNING" | "DONE" | (string & {});
export type NullablePercentage = number;
export type EntityId = string;
export type TreatmentOverrideMap = {
    [key: string]: string | undefined;
};
export type TreatmentOverrides = {
    Inline: {
        [key: string]: string | undefined;
    };
};
export interface ExperimentRunResult {
    ExecutiveSummary?: string | undefined;
    ReasonsToLaunch?: string | undefined;
    ReasonsNotToLaunch?: string | undefined;
}
export interface ExperimentDefinitionSnapshot {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Hypothesis?: string | undefined;
    ConfigurationProfileId?: string | undefined;
    EnvironmentId?: string | undefined;
    FlagKey?: string | undefined;
    AudienceRule?: string | undefined;
    AudienceDescription?: string | undefined;
    LaunchCriteria?: string | undefined;
    Treatments?: Treatment[] | undefined;
    Control?: Treatment | undefined;
}
export interface ExperimentRun {
    ApplicationId?: string | undefined;
    ExperimentDefinitionId?: string | undefined;
    Run?: number | undefined;
    Description?: string | undefined;
    Status?: ExperimentRunStatus | undefined;
    ExposurePercentage?: number | undefined;
    TreatmentOverrides?: TreatmentOverrides | undefined;
    Result?: ExperimentRunResult | undefined;
    StartedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    ExperimentDefinitionSnapshot?: ExperimentDefinitionSnapshot | undefined;
}
export interface GetExtensionRequest {
    ExtensionIdentifier: string;
    VersionNumber?: number | undefined;
}
export interface GetExtensionAssociationRequest {
    ExtensionAssociationId: string;
}
export interface GetHostedConfigurationVersionRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    VersionNumber: number;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListApplicationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ApplicationList = Application[];
export interface Applications {
    Items?: Application[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationProfilesRequest {
    ApplicationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Type?: string | undefined;
}
export type ValidatorTypeList = ValidatorType[];
export interface ConfigurationProfileSummary {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    LocationUri?: string | undefined;
    ValidatorTypes?: ValidatorType[] | undefined;
    Type?: string | undefined;
}
export type ConfigurationProfileSummaryList = ConfigurationProfileSummary[];
export interface ConfigurationProfiles {
    Items?: ConfigurationProfileSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeploymentsRequest {
    ApplicationId: string;
    EnvironmentId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DeploymentType = "USER" | "MANAGED" | (string & {});
export interface DeploymentSummary {
    DeploymentNumber?: number | undefined;
    ConfigurationProfileId?: string | undefined;
    ConfigurationName?: string | undefined;
    ConfigurationVersion?: string | undefined;
    DeploymentDurationInMinutes?: number | undefined;
    GrowthType?: GrowthType | undefined;
    GrowthFactor?: number | undefined;
    FinalBakeTimeInMinutes?: number | undefined;
    State?: DeploymentState | undefined;
    PercentageComplete?: number | undefined;
    StartedAt?: Date | undefined;
    CompletedAt?: Date | undefined;
    VersionLabel?: string | undefined;
    Type?: DeploymentType | undefined;
}
export type DeploymentList = DeploymentSummary[];
export interface Deployments {
    Items?: DeploymentSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeploymentStrategiesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DeploymentStrategyList = DeploymentStrategy[];
export interface DeploymentStrategies {
    Items?: DeploymentStrategy[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEnvironmentsRequest {
    ApplicationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type EnvironmentList = Environment[];
export interface Environments {
    Items?: Environment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExperimentDefinitionsRequest {
    ApplicationIdentifier?: string | undefined;
    ConfigurationProfileIdentifier?: string | undefined;
    EnvironmentIdentifier?: string | undefined;
    Status?: ExperimentDefinitionStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ExperimentDefinitionSummary {
    ApplicationId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Hypothesis?: string | undefined;
    Status?: ExperimentDefinitionStatus | undefined;
    ConfigurationProfileId?: string | undefined;
    EnvironmentId?: string | undefined;
    FlagKey?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type ExperimentDefinitionList = ExperimentDefinitionSummary[];
export interface ExperimentDefinitions {
    Items?: ExperimentDefinitionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExperimentRunEventsRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ExperimentRunEventType = "RUN_STARTED" | "EXPOSURE_UPDATED" | "OVERRIDES_UPDATED" | "RUN_STOPPED" | (string & {});
export interface ExperimentRunEvent {
    Description?: string | undefined;
    AssociatedDeployment?: string | undefined;
    EventType?: ExperimentRunEventType | undefined;
    OccurredAt?: Date | undefined;
    TriggeredBy?: TriggeredBy | undefined;
    ExposurePercentage?: number | undefined;
    TreatmentOverrides?: TreatmentOverrides | undefined;
}
export type ExperimentRunEventList = ExperimentRunEvent[];
export interface ExperimentRunEvents {
    Items?: ExperimentRunEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExperimentRunsRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Status?: ExperimentRunStatus | undefined;
}
export interface ExperimentRunSummary {
    ExperimentDefinitionId?: string | undefined;
    Run?: number | undefined;
    Description?: string | undefined;
    Status?: ExperimentRunStatus | undefined;
    StartedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
}
export type ExperimentRunSummaryList = ExperimentRunSummary[];
export interface ExperimentRuns {
    Items?: ExperimentRunSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExtensionAssociationsRequest {
    ResourceIdentifier?: string | undefined;
    ExtensionIdentifier?: string | undefined;
    ExtensionVersionNumber?: number | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ExtensionAssociationSummary {
    Id?: string | undefined;
    ExtensionArn?: string | undefined;
    ResourceArn?: string | undefined;
}
export type ExtensionAssociationSummaries = ExtensionAssociationSummary[];
export interface ExtensionAssociations {
    Items?: ExtensionAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type QueryName = string;
export interface ListExtensionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Name?: string | undefined;
}
export interface ExtensionSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    VersionNumber?: number | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
}
export type ExtensionSummaries = ExtensionSummary[];
export interface Extensions {
    Items?: ExtensionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListHostedConfigurationVersionsRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    VersionLabel?: string | undefined;
}
export interface HostedConfigurationVersionSummary {
    ApplicationId?: string | undefined;
    ConfigurationProfileId?: string | undefined;
    VersionNumber?: number | undefined;
    Description?: string | undefined;
    ContentType?: string | undefined;
    VersionLabel?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export type HostedConfigurationVersionSummaryList = HostedConfigurationVersionSummary[];
export interface HostedConfigurationVersions {
    Items?: HostedConfigurationVersionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ResourceTags {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DynamicParameterKey = string;
export type DynamicParameterMap = {
    [key: string]: string | undefined;
};
export interface StartDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentStrategyId: string;
    ConfigurationProfileId: string;
    ConfigurationVersion: string;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    KmsKeyIdentifier?: string | undefined;
    DynamicExtensionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    LatestDeploymentNumber?: number | undefined;
}
export interface DeploymentParameters {
    DynamicExtensionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Description?: string | undefined;
    ExposurePercentage?: number | undefined;
    TreatmentOverrides?: TreatmentOverrides | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    DeploymentParameters?: DeploymentParameters | undefined;
}
export interface StopDeploymentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    DeploymentNumber: number;
    AllowRevert?: boolean | undefined;
}
export interface StopExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    Result?: ExperimentRunResult | undefined;
    DeploymentParameters?: DeploymentParameters | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccountSettingsRequest {
    DeletionProtection?: DeletionProtectionSettings | undefined;
    VendedMetrics?: VendedMetricsSettings | undefined;
}
export interface UpdateApplicationRequest {
    ApplicationId: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type KmsKeyIdentifierOrEmpty = string;
export interface UpdateConfigurationProfileRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    RetrievalRoleArn?: string | undefined;
    Validators?: Validator[] | undefined;
    KmsKeyIdentifier?: string | undefined;
}
export interface UpdateDeploymentStrategyRequest {
    DeploymentStrategyId: string;
    Description?: string | undefined;
    DeploymentDurationInMinutes?: number | undefined;
    FinalBakeTimeInMinutes?: number | undefined;
    GrowthFactor?: number | undefined;
    GrowthType?: GrowthType | undefined;
}
export interface UpdateEnvironmentRequest {
    ApplicationId: string;
    EnvironmentId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Monitors?: Monitor[] | undefined;
}
export interface UpdateExperimentDefinitionRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Treatments?: TreatmentInput[] | undefined;
    Control?: TreatmentInput | undefined;
    Hypothesis?: string | undefined;
    AudienceRule?: string | undefined;
    AudienceDescription?: string | undefined;
    LaunchCriteria?: string | undefined;
}
export interface UpdateExperimentRunRequest {
    ApplicationIdentifier: string;
    ExperimentDefinitionIdentifier: string;
    Run: number;
    Description?: string | undefined;
    ExposurePercentage?: number | undefined;
    TreatmentOverrides?: TreatmentOverrides | undefined;
    DeploymentParameters?: DeploymentParameters | undefined;
}
export interface UpdateExtensionRequest {
    ExtensionIdentifier: string;
    Description?: string | undefined;
    Actions?: {
        [key: string]: Action[] | undefined;
    } | undefined;
    Parameters?: {
        [key: string]: Parameter | undefined;
    } | undefined;
    VersionNumber?: number | undefined;
}
export interface UpdateExtensionAssociationRequest {
    ExtensionAssociationId: string;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ValidateConfigurationRequest {
    ApplicationId: string;
    ConfigurationProfileId: string;
    ConfigurationVersion: string;
}
export interface ValidateConfigurationResponse {
}
export type BadRequestReason = "InvalidConfiguration" | (string & {});
export interface InvalidConfigurationDetail {
    Constraint?: string | undefined;
    Location?: string | undefined;
    Reason?: string | undefined;
    Type?: string | undefined;
    Value?: string | undefined;
}
export type InvalidConfigurationDetailList = InvalidConfigurationDetail[];
export type BadRequestDetails = {
    InvalidConfiguration: InvalidConfigurationDetail[];
};
export type BytesMeasure = "KILOBYTES" | (string & {});
export type CreateApplicationError = BadRequestException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an application. In AppConfig, an application is simply an
 * organizational construct like a folder. This organizational construct has a relationship
 * with some unit of executable code. For example, you could create an application called
 * MyMobileApp to organize and manage configuration data for a mobile application installed by
 * your users.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, Application, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a configuration profile, which is information that enables AppConfig
 * to access the configuration source. Valid configuration sources include the
 * following:
 *
 * - Configuration data in YAML, JSON, and other formats stored in the AppConfig hosted configuration store
 *
 * - Configuration data stored as objects in an Amazon Simple Storage Service (Amazon S3)
 * bucket
 *
 * - Pipelines stored in CodePipeline
 *
 * - Secrets stored in Secrets Manager
 *
 * - Standard and secure string parameters stored in Amazon Web Services Systems Manager Parameter Store
 *
 * - Configuration data in SSM documents stored in the Systems Manager document store
 *
 * A configuration profile includes the following information:
 *
 * - The URI location of the configuration data.
 *
 * - The Identity and Access Management (IAM) role that provides access to the configuration data.
 *
 * - A validator for the configuration data. Available validators include either a JSON
 * Schema or an Amazon Web Services Lambda function.
 *
 * For more information, see Create a
 * Configuration and a Configuration Profile in the AppConfig
 * User Guide.
 */
export declare const createConfigurationProfile: API.OperationMethod<CreateConfigurationProfileRequest & RegionInput, ConfigurationProfile, CreateConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentStrategyError = BadRequestException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a deployment strategy that defines important criteria for rolling out your
 * configuration to the designated targets. A deployment strategy includes the overall
 * duration required, a percentage of targets to receive the deployment during each interval,
 * an algorithm that defines how percentage grows, and bake time.
 */
export declare const createDeploymentStrategy: API.OperationMethod<CreateDeploymentStrategyRequest & RegionInput, DeploymentStrategy, CreateDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an environment. For each application, you define one or more environments. An
 * environment is a deployment group of AppConfig targets, such as applications in a
 * `Beta` or `Production` environment. You can also define
 * environments for application subcomponents such as the `Web`,
 * `Mobile` and `Back-end` components for your application. You can
 * configure Amazon CloudWatch alarms for each environment. The system monitors alarms during a
 * configuration deployment. If an alarm is triggered, the system rolls back the
 * configuration.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest & RegionInput, Environment, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an experiment definition in AppConfig. An experiment definition describes the purpose, scope, and operational configuration of an experiment, including the target audience, feature flag, and treatment configurations.
 */
export declare const createExperimentDefinition: API.OperationMethod<CreateExperimentDefinitionRequest & RegionInput, ExperimentDefinition, CreateExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateExtensionError = BadRequestException | ConflictException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates an AppConfig extension. An extension augments your ability to inject
 * logic or behavior at different points during the AppConfig workflow of creating
 * or deploying a configuration.
 *
 * You can create your own extensions or use the Amazon Web Services authored extensions provided by
 * AppConfig. For an AppConfig extension that uses Lambda, you must create a Lambda function to perform any computation and processing
 * defined in the extension. If you plan to create custom versions of the Amazon Web Services
 * authored notification extensions, you only need to specify an Amazon Resource Name (ARN) in
 * the `Uri` field for the new extension version.
 *
 * - For a custom EventBridge notification extension, enter the ARN of the EventBridge
 * default events in the `Uri` field.
 *
 * - For a custom Amazon SNS notification extension, enter the ARN of an Amazon SNS
 * topic in the `Uri` field.
 *
 * - For a custom Amazon SQS notification extension, enter the ARN of an Amazon SQS
 * message queue in the `Uri` field.
 *
 * For more information about extensions, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const createExtension: API.OperationMethod<CreateExtensionRequest & RegionInput, Extension, CreateExtensionError, Credentials | HttpClient.HttpClient>;
export type CreateExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * When you create an extension or configure an Amazon Web Services authored extension, you
 * associate the extension with an AppConfig application, environment, or
 * configuration profile. For example, you can choose to run the AppConfig
 * deployment events to Amazon SNS
 * Amazon Web Services authored extension and receive notifications on an Amazon SNS
 * topic anytime a configuration deployment is started for a specific application. Defining
 * which extension to associate with an AppConfig resource is called an
 * *extension association*. An extension association is a specified
 * relationship between an extension and an AppConfig resource, such as an
 * application or a configuration profile. For more information about extensions and
 * associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const createExtensionAssociation: API.OperationMethod<CreateExtensionAssociationRequest & RegionInput, ExtensionAssociation, CreateExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateHostedConfigurationVersionError = BadRequestException | ConflictException | InternalServerException | PayloadTooLargeException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new configuration in the AppConfig hosted configuration store. If
 * you're creating a feature flag, we recommend you familiarize yourself with the JSON schema
 * for feature flag data. For more information, see Type reference for AWS.AppConfig.FeatureFlags in the
 * *AppConfig User Guide*.
 */
export declare const createHostedConfigurationVersion: API.OperationMethod<CreateHostedConfigurationVersionRequest & RegionInput, HostedConfigurationVersion, CreateHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationProfileError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a configuration profile.
 *
 * To prevent users from unintentionally deleting actively-used configuration profiles,
 * enable deletion
 * protection.
 */
export declare const deleteConfigurationProfile: API.OperationMethod<DeleteConfigurationProfileRequest & RegionInput, DeleteConfigurationProfileResponse, DeleteConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a deployment strategy.
 */
export declare const deleteDeploymentStrategy: API.OperationMethod<DeleteDeploymentStrategyRequest & RegionInput, DeleteDeploymentStrategyResponse, DeleteDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an environment.
 *
 * To prevent users from unintentionally deleting actively-used environments, enable deletion
 * protection.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an experiment definition. You can archive the definition to hide it from the active list while preserving it for future reference, or permanently delete it along with all associated run history.
 */
export declare const deleteExperimentDefinition: API.OperationMethod<DeleteExperimentDefinitionRequest & RegionInput, DeleteExperimentDefinitionResponse, DeleteExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteExtensionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an AppConfig extension. You must delete all associations to an
 * extension before you delete the extension.
 */
export declare const deleteExtension: API.OperationMethod<DeleteExtensionRequest & RegionInput, DeleteExtensionResponse, DeleteExtensionError, Credentials | HttpClient.HttpClient>;
export type DeleteExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an extension association. This action doesn't delete extensions defined in the
 * association.
 */
export declare const deleteExtensionAssociation: API.OperationMethod<DeleteExtensionAssociationRequest & RegionInput, DeleteExtensionAssociationResponse, DeleteExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteHostedConfigurationVersionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a version of a configuration from the AppConfig hosted configuration
 * store.
 */
export declare const deleteHostedConfigurationVersion: API.OperationMethod<DeleteHostedConfigurationVersionRequest & RegionInput, DeleteHostedConfigurationVersionResponse, DeleteHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Returns information about the status of the `DeletionProtection`
 * parameter.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest & RegionInput, AccountSettings, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, Application, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * (Deprecated) Retrieves the latest deployed configuration.
 *
 * Note the following important information.
 *
 * - This API action is deprecated. Calls to receive configuration data should use
 * the StartConfigurationSession and GetLatestConfiguration APIs instead.
 *
 * - GetConfiguration is a priced call. For more information, see
 * Pricing.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest & RegionInput, Configuration, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a configuration profile.
 */
export declare const getConfigurationProfile: API.OperationMethod<GetConfigurationProfileRequest & RegionInput, ConfigurationProfile, GetConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a configuration deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest & RegionInput, Deployment, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a deployment strategy. A deployment strategy defines
 * important criteria for rolling out your configuration to the designated targets. A
 * deployment strategy includes the overall duration required, a percentage of targets to
 * receive the deployment during each interval, an algorithm that defines how percentage
 * grows, and bake time.
 */
export declare const getDeploymentStrategy: API.OperationMethod<GetDeploymentStrategyRequest & RegionInput, DeploymentStrategy, GetDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an environment. An environment is a deployment group of
 * AppConfig applications, such as applications in a `Production`
 * environment or in an `EU_Region` environment. Each configuration deployment
 * targets an environment. You can enable one or more Amazon CloudWatch alarms for an environment. If
 * an alarm is triggered during a deployment, AppConfig roles back the
 * configuration.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest & RegionInput, Environment, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetExperimentDefinitionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an experiment definition.
 */
export declare const getExperimentDefinition: API.OperationMethod<GetExperimentDefinitionRequest & RegionInput, ExperimentDefinition, GetExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetExperimentRunError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an experiment run, including its status, start time, and exposure settings.
 */
export declare const getExperimentRun: API.OperationMethod<GetExperimentRunRequest & RegionInput, ExperimentRun, GetExperimentRunError, Credentials | HttpClient.HttpClient>;
export type GetExtensionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about an AppConfig extension.
 */
export declare const getExtension: API.OperationMethod<GetExtensionRequest & RegionInput, Extension, GetExtensionError, Credentials | HttpClient.HttpClient>;
export type GetExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about an AppConfig extension association. For more
 * information about extensions and associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const getExtensionAssociation: API.OperationMethod<GetExtensionAssociationRequest & RegionInput, ExtensionAssociation, GetExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type GetHostedConfigurationVersionError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a specific configuration version.
 */
export declare const getHostedConfigurationVersion: API.OperationMethod<GetHostedConfigurationVersionRequest & RegionInput, HostedConfigurationVersion, GetHostedConfigurationVersionError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all applications in your Amazon Web Services account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, Applications, ListApplicationsError, Credentials | HttpClient.HttpClient, Application>;
export type ListConfigurationProfilesError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the configuration profiles for an application.
 */
export declare const listConfigurationProfiles: API.PaginatedOperationMethod<ListConfigurationProfilesRequest & RegionInput, ConfigurationProfiles, ListConfigurationProfilesError, Credentials | HttpClient.HttpClient, ConfigurationProfileSummary>;
export type ListDeploymentsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the deployments for an environment in descending deployment number order.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest & RegionInput, Deployments, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentSummary>;
export type ListDeploymentStrategiesError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists deployment strategies.
 */
export declare const listDeploymentStrategies: API.PaginatedOperationMethod<ListDeploymentStrategiesRequest & RegionInput, DeploymentStrategies, ListDeploymentStrategiesError, Credentials | HttpClient.HttpClient, DeploymentStrategy>;
export type ListEnvironmentsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the environments for an application.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest & RegionInput, Environments, ListEnvironmentsError, Credentials | HttpClient.HttpClient, Environment>;
export type ListExperimentDefinitionsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the experiment definitions for an account. You can filter results by application, configuration profile, environment, or status.
 */
export declare const listExperimentDefinitions: API.PaginatedOperationMethod<ListExperimentDefinitionsRequest & RegionInput, ExperimentDefinitions, ListExperimentDefinitionsError, Credentials | HttpClient.HttpClient, ExperimentDefinitionSummary>;
export type ListExperimentRunEventsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the events for a specified experiment run. Events provide a timeline of actions and state changes that occurred during the run.
 */
export declare const listExperimentRunEvents: API.PaginatedOperationMethod<ListExperimentRunEventsRequest & RegionInput, ExperimentRunEvents, ListExperimentRunEventsError, Credentials | HttpClient.HttpClient, ExperimentRunEvent>;
export type ListExperimentRunsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the experiment runs for a specified experiment definition. You can filter by status.
 */
export declare const listExperimentRuns: API.PaginatedOperationMethod<ListExperimentRunsRequest & RegionInput, ExperimentRuns, ListExperimentRunsError, Credentials | HttpClient.HttpClient, ExperimentRunSummary>;
export type ListExtensionAssociationsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all AppConfig extension associations in the account. For more
 * information about extensions and associations, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const listExtensionAssociations: API.PaginatedOperationMethod<ListExtensionAssociationsRequest & RegionInput, ExtensionAssociations, ListExtensionAssociationsError, Credentials | HttpClient.HttpClient, ExtensionAssociationSummary>;
export type ListExtensionsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Lists all custom and Amazon Web Services authored AppConfig extensions in the
 * account. For more information about extensions, see Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const listExtensions: API.PaginatedOperationMethod<ListExtensionsRequest & RegionInput, Extensions, ListExtensionsError, Credentials | HttpClient.HttpClient, ExtensionSummary>;
export type ListHostedConfigurationVersionsError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists configurations stored in the AppConfig hosted configuration store by
 * version.
 */
export declare const listHostedConfigurationVersions: API.PaginatedOperationMethod<ListHostedConfigurationVersionsRequest & RegionInput, HostedConfigurationVersions, ListHostedConfigurationVersionsError, Credentials | HttpClient.HttpClient, HostedConfigurationVersionSummary>;
export type ListTagsForResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of key-value tags assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ResourceTags, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a deployment.
 *
 * AppConfig Agent supports deploying feature flag or free-form configuration data to specific segments or individual users during a gradual rollout. Entity-based gradual deployments ensure that once a user or segment receives a configuration version, they continue to receive that same version throughout the deployment period, regardless of which compute resource serves their requests. For more information, see Using AppConfig Agent for user-based or entity-based gradual deployments
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest & RegionInput, Deployment, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Starts an experiment run for the specified experiment definition. An experiment run delivers treatments to the target audience and collects metrics. You can start multiple experiment runs from the same experiment definition.
 *
 * Billing for this experiment begins when you call this operation and continues until the experiment is stopped. For pricing details, see AppConfig pricing.
 */
export declare const startExperimentRun: API.OperationMethod<StartExperimentRunRequest & RegionInput, ExperimentRun, StartExperimentRunError, Credentials | HttpClient.HttpClient>;
export type StopDeploymentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a deployment. This API action works only on deployments that have a status of
 * `DEPLOYING`, unless an `AllowRevert` parameter is supplied. If the
 * `AllowRevert` parameter is supplied, the status of an in-progress deployment
 * will be `ROLLED_BACK`. The status of a completed deployment will be
 * `REVERTED`. AppConfig only allows a revert within 72 hours of
 * deployment completion.
 */
export declare const stopDeployment: API.OperationMethod<StopDeploymentRequest & RegionInput, Deployment, StopDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a running experiment. Stopping an experiment run ends audience exposure and returns users to the currently deployed feature flag configuration.
 */
export declare const stopExperimentRun: API.OperationMethod<StopExperimentRunRequest & RegionInput, ExperimentRun, StopExperimentRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns metadata to an AppConfig resource. Tags help organize and categorize
 * your AppConfig resources. Each tag consists of a key and an optional value, both
 * of which you define. You can specify a maximum of 50 tags for a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a tag key and value from an AppConfig resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = BadRequestException | InternalServerException | CommonErrors;
/**
 * Updates the value of the `DeletionProtection` parameter.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest & RegionInput, AccountSettings, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, Application, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationProfileError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a configuration profile.
 */
export declare const updateConfigurationProfile: API.OperationMethod<UpdateConfigurationProfileRequest & RegionInput, ConfigurationProfile, UpdateConfigurationProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentStrategyError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a deployment strategy.
 */
export declare const updateDeploymentStrategy: API.OperationMethod<UpdateDeploymentStrategyRequest & RegionInput, DeploymentStrategy, UpdateDeploymentStrategyError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest & RegionInput, Environment, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentDefinitionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an experiment definition. You can update treatments, the control, audience rules, and other properties. You cannot update an experiment definition while an experiment run is active.
 */
export declare const updateExperimentDefinition: API.OperationMethod<UpdateExperimentDefinitionRequest & RegionInput, ExperimentDefinition, UpdateExperimentDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateExperimentRunError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a running experiment. Use this operation to increase audience exposure, modify treatment assignment overrides, or update the description of an active experiment run. Audience exposure can only be increased, not decreased.
 */
export declare const updateExperimentRun: API.OperationMethod<UpdateExperimentRunRequest & RegionInput, ExperimentRun, UpdateExperimentRunError, Credentials | HttpClient.HttpClient>;
export type UpdateExtensionError = BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an AppConfig extension. For more information about extensions, see
 * Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const updateExtension: API.OperationMethod<UpdateExtensionRequest & RegionInput, Extension, UpdateExtensionError, Credentials | HttpClient.HttpClient>;
export type UpdateExtensionAssociationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an association. For more information about extensions and associations, see
 * Extending
 * workflows in the *AppConfig User Guide*.
 */
export declare const updateExtensionAssociation: API.OperationMethod<UpdateExtensionAssociationRequest & RegionInput, ExtensionAssociation, UpdateExtensionAssociationError, Credentials | HttpClient.HttpClient>;
export type ValidateConfigurationError = BadRequestException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Uses the validators in a configuration profile to validate a configuration.
 */
export declare const validateConfiguration: API.OperationMethod<ValidateConfigurationRequest & RegionInput, ValidateConfigurationResponse, ValidateConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appconfig.d.ts.map