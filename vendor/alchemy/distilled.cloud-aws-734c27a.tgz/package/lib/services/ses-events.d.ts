export interface AdvisorRecommendationStatusOpen {
    data: string;
    version: string;
}
export type AdvisorRecommendationStatusOpenEventResourcesList = Array<string>;
export interface AdvisorRecommendationStatusOpenEvent {
    detail: AdvisorRecommendationStatusOpen;
    account: string;
    "detail-type": string;
    id: string;
    region: string;
    resources: AdvisorRecommendationStatusOpenEventResourcesList;
    source: string;
    time: string;
    version: string;
}
export type AdvisorRecommendationStatusResolved = AdvisorRecommendationStatusOpen;
export type AdvisorRecommendationStatusResolvedEventResourcesList = Array<string>;
export interface AdvisorRecommendationStatusResolvedEvent {
    detail: AdvisorRecommendationStatusOpen;
    account: string;
    "detail-type": string;
    id: string;
    region: string;
    resources: AdvisorRecommendationStatusResolvedEventResourcesList;
    source: string;
    time: string;
    version: string;
}
export interface AWSAPICallviaCloudTrailResourcesItem {
    accountId?: string | undefined;
    ARN?: string | undefined;
    ARNPrefix?: string | undefined;
    type?: string | undefined;
}
export type AWSAPICallviaCloudTrailResourcesList = Array<AWSAPICallviaCloudTrailResourcesItem>;
export interface AWSAPICallviaCloudTrailTlsDetails {
    cipherSuite?: string | undefined;
    clientProvidedHostHeader?: string | undefined;
    keyExchange?: string | undefined;
    tlsVersion?: string | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentityOnBehalfOf {
    identityStoreArn?: string | undefined;
    userId?: string | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes {
    creationDate?: string | undefined;
    mfaAuthenticated?: string | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer {
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
    type?: string | undefined;
    userName?: string | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData {
    attributes?: unknown | undefined;
    federatedProvider?: string | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentitySessionContext {
    assumedRoot?: string | undefined;
    attributes?: AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes | undefined;
    ec2IssuedInVPC?: string | undefined;
    ec2RoleDelivery?: string | undefined;
    sessionIssuer?: AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer | undefined;
    sourceIdentity?: string | undefined;
    webIdFederationData?: AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData | undefined;
}
export interface AWSAPICallviaCloudTrailUserIdentity {
    accessKeyId?: string | undefined;
    accountId?: string | undefined;
    arn?: string | undefined;
    credentialId?: string | undefined;
    identityProvider?: string | undefined;
    inScopeOf?: unknown | undefined;
    invokedBy?: string | undefined;
    invokedByDelegate?: unknown | undefined;
    onBehalfOf?: AWSAPICallviaCloudTrailUserIdentityOnBehalfOf | undefined;
    principalId?: string | undefined;
    sessionContext?: AWSAPICallviaCloudTrailUserIdentitySessionContext | undefined;
    type?: string | undefined;
    username?: string | undefined;
}
export interface AWSAPICallviaCloudTrail {
    addendum?: unknown | null | undefined;
    additionalEventData?: unknown | null | undefined;
    annotation?: string | undefined;
    apiVersion?: string | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    eventCategory?: string | undefined;
    eventContext?: unknown | undefined;
    eventID?: string | undefined;
    eventName?: string | undefined;
    eventSource?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    managementEvent?: boolean | undefined;
    readOnly?: boolean | undefined;
    recipientAccountId?: string | undefined;
    requestID?: string | undefined;
    requestParameters?: unknown | null | undefined;
    resources?: AWSAPICallviaCloudTrailResourcesList | undefined;
    responseElements?: unknown | null | undefined;
    sessionCredentialFromConsole?: string | undefined;
    sharedEventID?: string | undefined;
    sourceIPAddress?: string | undefined;
    tlsDetails?: AWSAPICallviaCloudTrailTlsDetails | undefined;
    userAgent?: string | undefined;
    userIdentity?: AWSAPICallviaCloudTrailUserIdentity | undefined;
    vpcEndpointAccountId?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export type AWSAPICallviaCloudTrailEventResourcesList = Array<string>;
export interface AWSAPICallviaCloudTrailEvent {
    detail: AWSAPICallviaCloudTrail;
    "detail-type": string;
    resources: AWSAPICallviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type AWSConsoleActionviaCloudTrailResourcesItem = AWSAPICallviaCloudTrailResourcesItem;
export type AWSConsoleActionviaCloudTrailResourcesList = Array<AWSAPICallviaCloudTrailResourcesItem>;
export type AWSConsoleActionviaCloudTrailTlsDetails = AWSAPICallviaCloudTrailTlsDetails;
export type AWSConsoleActionviaCloudTrailUserIdentityOnBehalfOf = AWSAPICallviaCloudTrailUserIdentityOnBehalfOf;
export type AWSConsoleActionviaCloudTrailUserIdentitySessionContextAttributes = AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes;
export type AWSConsoleActionviaCloudTrailUserIdentitySessionContextSessionIssuer = AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer;
export type AWSConsoleActionviaCloudTrailUserIdentitySessionContextWebIdFederationData = AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData;
export type AWSConsoleActionviaCloudTrailUserIdentitySessionContext = AWSAPICallviaCloudTrailUserIdentitySessionContext;
export type AWSConsoleActionviaCloudTrailUserIdentity = AWSAPICallviaCloudTrailUserIdentity;
export interface AWSConsoleActionviaCloudTrail {
    addendum?: unknown | null | undefined;
    additionalEventData?: unknown | null | undefined;
    annotation?: string | undefined;
    apiVersion?: string | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    eventCategory?: string | undefined;
    eventID?: string | undefined;
    eventName?: string | undefined;
    eventSource?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    managementEvent?: boolean | undefined;
    readOnly?: boolean | undefined;
    recipientAccountId?: string | undefined;
    requestID?: string | undefined;
    requestParameters?: unknown | null | undefined;
    resources?: AWSConsoleActionviaCloudTrailResourcesList | undefined;
    responseElements?: unknown | null | undefined;
    sessionCredentialFromConsole?: string | undefined;
    sharedEventID?: string | undefined;
    sourceIPAddress?: string | undefined;
    tlsDetails?: AWSAPICallviaCloudTrailTlsDetails | undefined;
    userAgent?: string | undefined;
    userIdentity?: AWSAPICallviaCloudTrailUserIdentity | undefined;
    vpcEndpointAccountId?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export type AWSConsoleActionviaCloudTrailEventResourcesList = Array<string>;
export interface AWSConsoleActionviaCloudTrailEvent {
    detail: AWSConsoleActionviaCloudTrail;
    "detail-type": string;
    resources: AWSConsoleActionviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type AWSConsoleSignInviaCloudTrailResourcesItem = AWSAPICallviaCloudTrailResourcesItem;
export type AWSConsoleSignInviaCloudTrailResourcesList = Array<AWSAPICallviaCloudTrailResourcesItem>;
export type AWSConsoleSignInviaCloudTrailTlsDetails = AWSAPICallviaCloudTrailTlsDetails;
export type AWSConsoleSignInviaCloudTrailUserIdentityOnBehalfOf = AWSAPICallviaCloudTrailUserIdentityOnBehalfOf;
export type AWSConsoleSignInviaCloudTrailUserIdentitySessionContextAttributes = AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes;
export type AWSConsoleSignInviaCloudTrailUserIdentitySessionContextSessionIssuer = AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer;
export type AWSConsoleSignInviaCloudTrailUserIdentitySessionContextWebIdFederationData = AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData;
export type AWSConsoleSignInviaCloudTrailUserIdentitySessionContext = AWSAPICallviaCloudTrailUserIdentitySessionContext;
export type AWSConsoleSignInviaCloudTrailUserIdentity = AWSAPICallviaCloudTrailUserIdentity;
export interface AWSConsoleSignInviaCloudTrail {
    addendum?: unknown | null | undefined;
    additionalEventData?: unknown | null | undefined;
    annotation?: string | undefined;
    apiVersion?: string | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    eventCategory?: string | undefined;
    eventID?: string | undefined;
    eventName?: string | undefined;
    eventSource?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    managementEvent?: boolean | undefined;
    readOnly?: boolean | undefined;
    recipientAccountId?: string | undefined;
    requestID?: string | undefined;
    requestParameters?: unknown | null | undefined;
    resources?: AWSConsoleSignInviaCloudTrailResourcesList | undefined;
    responseElements?: unknown | null | undefined;
    sessionCredentialFromConsole?: string | undefined;
    sharedEventID?: string | undefined;
    sourceIPAddress?: string | undefined;
    tlsDetails?: AWSAPICallviaCloudTrailTlsDetails | undefined;
    userAgent?: string | undefined;
    userIdentity?: AWSAPICallviaCloudTrailUserIdentity | undefined;
    vpcEndpointAccountId?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export type AWSConsoleSignInviaCloudTrailEventResourcesList = Array<string>;
export interface AWSConsoleSignInviaCloudTrailEvent {
    detail: AWSConsoleSignInviaCloudTrail;
    "detail-type": string;
    resources: AWSConsoleSignInviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export interface AWSInsightviaCloudTrail {
    addendum?: unknown | null | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    eventCategory?: string | undefined;
    eventID?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    insightDetails?: unknown | null | undefined;
    recipientAccountId?: string | undefined;
    sharedEventID?: string | undefined;
}
export type AWSInsightviaCloudTrailEventResourcesList = Array<string>;
export interface AWSInsightviaCloudTrailEvent {
    detail: AWSInsightviaCloudTrail;
    "detail-type": string;
    resources: AWSInsightviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type AWSMcpEventviaCloudTrailEventResourcesList = Array<string>;
export interface AWSMcpEventviaCloudTrailEvent {
    detail: unknown;
    "detail-type": string;
    resources: AWSMcpEventviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type AWSNetworkActivityEventviaCloudTrailResourcesItem = AWSAPICallviaCloudTrailResourcesItem;
export type AWSNetworkActivityEventviaCloudTrailResourcesList = Array<AWSAPICallviaCloudTrailResourcesItem>;
export type AWSNetworkActivityEventviaCloudTrailUserIdentityOnBehalfOf = AWSAPICallviaCloudTrailUserIdentityOnBehalfOf;
export type AWSNetworkActivityEventviaCloudTrailUserIdentitySessionContextAttributes = AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes;
export type AWSNetworkActivityEventviaCloudTrailUserIdentitySessionContextSessionIssuer = AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer;
export type AWSNetworkActivityEventviaCloudTrailUserIdentitySessionContextWebIdFederationData = AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData;
export type AWSNetworkActivityEventviaCloudTrailUserIdentitySessionContext = AWSAPICallviaCloudTrailUserIdentitySessionContext;
export type AWSNetworkActivityEventviaCloudTrailUserIdentity = AWSAPICallviaCloudTrailUserIdentity;
export interface AWSNetworkActivityEventviaCloudTrail {
    addendum?: unknown | null | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    eventCategory?: string | undefined;
    eventChecksum?: string | undefined;
    eventID?: string | undefined;
    eventName?: string | undefined;
    eventSource?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    recipientAccountId?: string | undefined;
    requestID?: string | undefined;
    resources?: AWSNetworkActivityEventviaCloudTrailResourcesList | undefined;
    sessionCredentialFromConsole?: string | undefined;
    sharedEventID?: string | undefined;
    sourceIPAddress?: string | undefined;
    userIdentity?: AWSAPICallviaCloudTrailUserIdentity | undefined;
    vpcEndpointAccountId?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export type AWSNetworkActivityEventviaCloudTrailEventResourcesList = Array<string>;
export interface AWSNetworkActivityEventviaCloudTrailEvent {
    detail: AWSNetworkActivityEventviaCloudTrail;
    "detail-type": string;
    resources: AWSNetworkActivityEventviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type AWSServiceEventviaCloudTrailResourcesItem = AWSAPICallviaCloudTrailResourcesItem;
export type AWSServiceEventviaCloudTrailResourcesList = Array<AWSAPICallviaCloudTrailResourcesItem>;
export type AWSServiceEventviaCloudTrailTlsDetails = AWSAPICallviaCloudTrailTlsDetails;
export type AWSServiceEventviaCloudTrailUserIdentityOnBehalfOf = AWSAPICallviaCloudTrailUserIdentityOnBehalfOf;
export type AWSServiceEventviaCloudTrailUserIdentitySessionContextAttributes = AWSAPICallviaCloudTrailUserIdentitySessionContextAttributes;
export type AWSServiceEventviaCloudTrailUserIdentitySessionContextSessionIssuer = AWSAPICallviaCloudTrailUserIdentitySessionContextSessionIssuer;
export type AWSServiceEventviaCloudTrailUserIdentitySessionContextWebIdFederationData = AWSAPICallviaCloudTrailUserIdentitySessionContextWebIdFederationData;
export type AWSServiceEventviaCloudTrailUserIdentitySessionContext = AWSAPICallviaCloudTrailUserIdentitySessionContext;
export type AWSServiceEventviaCloudTrailUserIdentity = AWSAPICallviaCloudTrailUserIdentity;
export interface AWSServiceEventviaCloudTrail {
    addendum?: unknown | null | undefined;
    additionalEventData?: unknown | null | undefined;
    annotation?: string | undefined;
    apiVersion?: string | undefined;
    awsRegion?: string | undefined;
    edgeDeviceDetails?: unknown | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    eventCategory?: string | undefined;
    eventContext?: unknown | undefined;
    eventID?: string | undefined;
    eventName?: string | undefined;
    eventSource?: string | undefined;
    eventTime?: string | undefined;
    eventType?: string | undefined;
    eventVersion?: string | undefined;
    managementEvent?: boolean | undefined;
    readOnly?: boolean | undefined;
    recipientAccountId?: string | undefined;
    requestID?: string | undefined;
    requestParameters?: unknown | null | undefined;
    resources?: AWSServiceEventviaCloudTrailResourcesList | undefined;
    responseElements?: unknown | null | undefined;
    serviceEventDetails?: unknown | undefined;
    sharedEventID?: string | undefined;
    sourceIPAddress?: string | undefined;
    tlsDetails?: AWSAPICallviaCloudTrailTlsDetails | undefined;
    userAgent?: string | undefined;
    userIdentity?: AWSAPICallviaCloudTrailUserIdentity | undefined;
    vpcEndpointAccountId?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export type AWSServiceEventviaCloudTrailEventResourcesList = Array<string>;
export interface AWSServiceEventviaCloudTrailEvent {
    detail: AWSServiceEventviaCloudTrail;
    "detail-type": string;
    resources: AWSServiceEventviaCloudTrailEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Bounce event. */
export type BounceEventType = "Bounce";
export type StringList = Array<string>;
/** One of the email's original headers. */
export interface MailHeader {
    /** The header name. */
    name: string;
    /** The header value. */
    value: string;
}
export type MailHeaderList = Array<MailHeader>;
/** The email's original, commonly used headers. Its messageId is the one Amazon SES assigned. */
export interface CommonHeaders {
    /** The From header. */
    from?: StringList | undefined;
    /** The To header. */
    to?: StringList | undefined;
    /** The Cc header. */
    cc?: StringList | undefined;
    /** The Bcc header. */
    bcc?: StringList | undefined;
    /** The Sender header. */
    sender?: StringList | undefined;
    /** The Reply-To header. */
    replyTo?: StringList | undefined;
    /** The Return-Path header. */
    returnPath?: string | undefined;
    /** The message ID Amazon SES assigned to the message. */
    messageId?: string | undefined;
    /** The Date header. */
    date?: string | undefined;
    /** The Subject header. */
    subject?: string | undefined;
}
export type MailTags = {
    [key: string]: StringList | undefined;
};
/** The original email that produced the event. */
export interface Mail {
    /** When the message was sent, in ISO 8601 format. */
    timestamp: string;
    /** The unique ID Amazon SES assigned to the message. */
    messageId: string;
    /** The envelope MAIL FROM address the message was sent from. */
    source: string;
    /** The ARN of the identity used to send the email. */
    sourceArn?: string | undefined;
    /** The AWS account ID of the account that sent the email. */
    sendingAccountId: string;
    /** The recipients of the original mail. */
    destination: StringList;
    /** Whether the headers are truncated, which happens above 10 KB. */
    headersTruncated?: boolean | undefined;
    /** The email's original headers. */
    headers?: MailHeaderList | undefined;
    /** The email's original, commonly used headers. */
    commonHeaders?: CommonHeaders | undefined;
    /** The tags associated with the email. */
    tags?: MailTags | undefined;
}
/** The type of bounce, as determined by Amazon SES. */
export type BounceType = "Undetermined" | "Permanent" | "Transient";
/** The subtype of the bounce, as determined by Amazon SES. */
export type BounceSubType = "Undetermined" | "General" | "NoEmail" | "Suppressed" | "OnAccountSuppressionList" | "EmailValidationSuppressed" | "OnTenantSuppressionList" | "MailboxFull" | "MessageTooLarge" | "CustomTimeoutExceeded" | "ContentRejected" | "AttachmentRejected";
/** A recipient whose address produced a bounce. */
export interface BouncedRecipient {
    /** The recipient's address; the DSN's Final-Recipient field when a DSN is attached. */
    emailAddress: string;
    /** The DSN's Action field. */
    action?: string | undefined;
    /** The DSN's Status field, e.g. `5.1.1`. */
    status?: string | undefined;
    /** The DSN's Diagnostic-Code field. */
    diagnosticCode?: string | undefined;
}
export type BouncedRecipientList = Array<BouncedRecipient>;
/** A hard bounce, or a soft bounce Amazon SES no longer retries. */
export interface Bounce {
    /** The type of bounce. */
    bounceType: BounceType;
    /** The subtype of the bounce. */
    bounceSubType: BounceSubType;
    /** The recipients that bounced. */
    bouncedRecipients: BouncedRecipientList;
    /** When the ISP sent the bounce notification, in ISO 8601 format. */
    timestamp: string;
    /** A unique ID for the bounce. */
    feedbackId: string;
    /** The DSN's Reporting-MTA field, present only when a DSN is attached. */
    reportingMTA?: string | undefined;
}
/** The `detail` of an SES Bounce event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailBounced {
    /** The type of event. */
    eventType: BounceEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Bounce event. */
    bounce: Bounce;
}
export type EmailBouncedEventResourcesList = Array<string>;
export interface EmailBouncedEvent {
    detail: EmailBounced;
    "detail-type": string;
    resources: EmailBouncedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Click event. */
export type ClickEventType = "Click";
/** How likely the event came from an automated system rather than a human. */
export type IsBotEvent = "Likely" | "Unlikely";
/** The recipient clicked a link in the email. */
export interface Click {
    /** The recipient's IP address. */
    ipAddress: string;
    /** When the click occurred, in ISO 8601 format. */
    timestamp: string;
    /** The user agent of the client that clicked. */
    userAgent: string;
    /** The URL of the link that was clicked. */
    link: string;
    /** The tags added to the link with the `ses:tags` attribute. */
    linkTags?: MailTags | undefined;
    /** How likely the click came from a bot. */
    isBotEvent?: IsBotEvent | undefined;
}
/** The `detail` of an SES Click event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailClicked {
    /** The type of event. */
    eventType: ClickEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Click event. */
    click: Click;
}
export type EmailClickedEventResourcesList = Array<string>;
export interface EmailClickedEvent {
    detail: EmailClicked;
    "detail-type": string;
    resources: EmailClickedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Complaint event. */
export type ComplaintEventType = "Complaint";
/** A recipient that may have submitted the complaint. */
export interface ComplainedRecipient {
    /** The recipient's address. */
    emailAddress: string;
}
export type ComplainedRecipientList = Array<ComplainedRecipient>;
/** The Feedback-Type of the ISP's feedback report (IANA MARF feedback types). */
export type ComplaintFeedbackType = "abuse" | "auth-failure" | "fraud" | "not-spam" | "other" | "virus";
/** A complaint a recipient's ISP reported. */
export interface Complaint {
    /** The recipients that may have submitted the complaint. */
    complainedRecipients: ComplainedRecipientList;
    /** When the ISP sent the complaint notification, in ISO 8601 format. */
    timestamp: string;
    /** A unique ID for the complaint. */
    feedbackId: string;
    /** Null, or `OnAccountSuppressionList` / `OnTenantSuppressionList` when Amazon SES accepted but did not send the message. */
    complaintSubType?: string | null | undefined;
    /** The feedback report's User-Agent field. */
    userAgent?: string | undefined;
    /** The feedback report's Feedback-Type field. */
    complaintFeedbackType?: ComplaintFeedbackType | undefined;
    /** The feedback report's Arrival-Date or Received-Date, in ISO 8601 format. */
    arrivalDate?: string | undefined;
}
/** The `detail` of an SES Complaint event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailComplaintReceived {
    /** The type of event. */
    eventType: ComplaintEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Complaint event. */
    complaint: Complaint;
}
export type EmailComplaintReceivedEventResourcesList = Array<string>;
export interface EmailComplaintReceivedEvent {
    detail: EmailComplaintReceived;
    "detail-type": string;
    resources: EmailComplaintReceivedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Delivery event. */
export type DeliveryEventType = "Delivery";
/** Amazon SES delivered the email to the recipient's mail server. */
export interface Delivery {
    /** When Amazon SES delivered the email, in ISO 8601 format. */
    timestamp: string;
    /** Milliseconds from accepting the request to passing the message on. */
    processingTimeMillis: number;
    /** The recipients the delivery applies to. */
    recipients: StringList;
    /** The SMTP response of the remote ISP that accepted the email. */
    smtpResponse: string;
    /** The host name of the Amazon SES mail server that sent the mail. */
    reportingMTA: string;
    /** The IP address of the MTA Amazon SES delivered the email to. */
    remoteMtaIp?: string | undefined;
}
/** The `detail` of an SES Delivery event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailDelivered {
    /** The type of event. */
    eventType: DeliveryEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Delivery event. */
    delivery: Delivery;
}
export type EmailDeliveredEventResourcesList = Array<string>;
export interface EmailDeliveredEvent {
    detail: EmailDelivered;
    "detail-type": string;
    resources: EmailDeliveredEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a DeliveryDelay event. */
export type DeliveryDelayEventType = "DeliveryDelay";
/** The type of delivery delay. */
export type DelayType = "InternalFailure" | "General" | "MailboxFull" | "SpamDetected" | "RecipientServerError" | "IPFailure" | "TransientCommunicationFailure" | "BYOIPHostNameLookupUnavailable" | "Undetermined" | "SendingDeferral";
/** A recipient whose delivery is delayed. */
export interface DelayedRecipient {
    /** The address whose delivery is delayed. */
    emailAddress: string;
    /** The SMTP status code of the delay. */
    status?: string | undefined;
    /** The diagnostic code from the receiving MTA. */
    diagnosticCode?: string | undefined;
}
export type DelayedRecipientList = Array<DelayedRecipient>;
/** The email could not be delivered yet; Amazon SES keeps trying. */
export interface DeliveryDelay {
    /** The type of delay. */
    delayType: DelayType;
    /** The recipients that are delayed. */
    delayedRecipients: DelayedRecipientList;
    /** When Amazon SES stops trying to deliver, in ISO 8601 format. */
    expirationTime: string;
    /** The IP address of the MTA that reported the delay. */
    reportingMTA?: string | undefined;
    /** When the delay occurred, in ISO 8601 format. */
    timestamp: string;
}
/** The `detail` of an SES DeliveryDelay event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailDeliveryDelayed {
    /** The type of event. */
    eventType: DeliveryDelayEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The DeliveryDelay event. */
    deliveryDelay: DeliveryDelay;
}
export type EmailDeliveryDelayedEventResourcesList = Array<string>;
export interface EmailDeliveryDelayedEvent {
    detail: EmailDeliveryDelayed;
    "detail-type": string;
    resources: EmailDeliveryDelayedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Open event. */
export type OpenEventType = "Open";
/** The recipient opened the email. */
export interface Open {
    /** The recipient's IP address. */
    ipAddress: string;
    /** When the open occurred, in ISO 8601 format. */
    timestamp: string;
    /** The user agent of the client that opened the email. */
    userAgent: string;
    /** How likely the open came from a bot. */
    isBotEvent?: IsBotEvent | undefined;
}
/** The `detail` of an SES Open event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailOpened {
    /** The type of event. */
    eventType: OpenEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Open event. */
    open: Open;
}
export type EmailOpenedEventResourcesList = Array<string>;
export interface EmailOpenedEvent {
    detail: EmailOpened;
    "detail-type": string;
    resources: EmailOpenedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Reject event. */
export type RejectEventType = "Reject";
/** Amazon SES rejected the email and did not attempt delivery. */
export interface Reject {
    /** Why the email was rejected. The only value is `Bad content`. */
    reason: string;
}
/** The `detail` of an SES Reject event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailRejected {
    /** The type of event. */
    eventType: RejectEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Reject event. */
    reject: Reject;
}
export type EmailRejectedEventResourcesList = Array<string>;
export interface EmailRejectedEvent {
    detail: EmailRejected;
    "detail-type": string;
    resources: EmailRejectedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Rendering Failure event. */
export type RenderingFailureEventType = "Rendering Failure";
/** The email was not sent because of a template rendering problem. */
export interface RenderingFailure {
    /** The name of the template used to send the email. */
    templateName: string;
    /** More information about the rendering failure. */
    errorMessage: string;
}
/** The `detail` of an SES Rendering Failure event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailRenderingFailed {
    /** The type of event. */
    eventType: RenderingFailureEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Rendering Failure event. */
    failure: RenderingFailure;
}
export type EmailRenderingFailedEventResourcesList = Array<string>;
export interface EmailRenderingFailedEvent {
    detail: EmailRenderingFailed;
    "detail-type": string;
    resources: EmailRenderingFailedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Send event. */
export type SendEventType = "Send";
/** The send request succeeded. Always empty. */
export interface Send {
}
/** The `detail` of an SES Send event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailSent {
    /** The type of event. */
    eventType: SendEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Send event. */
    send: Send;
}
export type EmailSentEventResourcesList = Array<string>;
export interface EmailSentEvent {
    detail: EmailSent;
    "detail-type": string;
    resources: EmailSentEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** The `eventType` of a Subscription event. */
export type SubscriptionEventType = "Subscription";
/** A topic subscription status. */
export type SubscriptionStatus = "OptIn" | "OptOut";
/** The subscription status of one topic in the contact list. */
export interface TopicSubscriptionStatus {
    /** The topic. */
    topicName: string;
    /** Whether the contact is subscribed. */
    subscriptionStatus: SubscriptionStatus;
}
export type TopicSubscriptionStatusList = Array<TopicSubscriptionStatus>;
/** The contact's subscription status for every topic in the contact list. */
export interface TopicPreferences {
    /** Whether the contact unsubscribed from all topics. */
    unsubscribeAll: boolean;
    /** The subscription status of each topic. */
    topicSubscriptionStatus?: TopicSubscriptionStatusList | undefined;
    /** The default subscription status of each topic. */
    topicDefaultSubscriptionStatus?: TopicSubscriptionStatusList | undefined;
}
/** The contact changed its subscription preferences. */
export interface Subscription {
    /** The name of the contact list. */
    contactList: string;
    /** When the change happened, in ISO 8601 format. */
    timestamp: string;
    /** How the change was made, e.g. `UnsubscribeHeader`. */
    source: string;
    /** The preferences after the change. */
    newTopicPreferences: TopicPreferences;
    /** The preferences before the change. */
    oldTopicPreferences: TopicPreferences;
}
/** The `detail` of an SES Subscription event: the event record SES publishes to EventBridge, SNS and Firehose. */
export interface EmailSubscribed {
    /** The type of event. */
    eventType: SubscriptionEventType;
    /** The original email that produced the event. */
    mail: Mail;
    /** The Subscription event. */
    subscription: Subscription;
}
export type EmailSubscribedEventResourcesList = Array<string>;
export interface EmailSubscribedEvent {
    detail: EmailSubscribed;
    "detail-type": string;
    resources: EmailSubscribedEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type SendingStatusDisabledEventResourcesList = Array<string>;
export interface SendingStatusDisabledEvent {
    detail: unknown;
    "detail-type": string;
    resources: SendingStatusDisabledEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
export type SendingStatusEnabledEventResourcesList = Array<string>;
export interface SendingStatusEnabledEvent {
    detail: unknown;
    "detail-type": string;
    resources: SendingStatusEnabledEventResourcesList;
    id: string;
    source: string;
    time: string;
    region: string;
    version: string;
    account: string;
}
/** Every event this service sends to EventBridge, keyed by its `detail-type`. */
export interface Events {
    "Advisor Recommendation Status Open": AdvisorRecommendationStatusOpenEvent;
    "Advisor Recommendation Status Resolved": AdvisorRecommendationStatusResolvedEvent;
    "AWS API Call via CloudTrail": AWSAPICallviaCloudTrailEvent;
    "AWS Console Action via CloudTrail": AWSConsoleActionviaCloudTrailEvent;
    "AWS Console Sign In via CloudTrail": AWSConsoleSignInviaCloudTrailEvent;
    "AWS Insight via CloudTrail": AWSInsightviaCloudTrailEvent;
    "AWS Mcp Event via CloudTrail": AWSMcpEventviaCloudTrailEvent;
    "AWS Network Activity Event via CloudTrail": AWSNetworkActivityEventviaCloudTrailEvent;
    "AWS Service Event via CloudTrail": AWSServiceEventviaCloudTrailEvent;
    "Email Bounced": EmailBouncedEvent;
    "Email Clicked": EmailClickedEvent;
    "Email Complaint Received": EmailComplaintReceivedEvent;
    "Email Delivered": EmailDeliveredEvent;
    "Email Delivery Delayed": EmailDeliveryDelayedEvent;
    "Email Opened": EmailOpenedEvent;
    "Email Rejected": EmailRejectedEvent;
    "Email Rendering Failed": EmailRenderingFailedEvent;
    "Email Sent": EmailSentEvent;
    "Email Subscribed": EmailSubscribedEvent;
    "Sending Status Disabled": SendingStatusDisabledEvent;
    "Sending Status Enabled": SendingStatusEnabledEvent;
}
/** An event's `detail-type`. */
export type DetailType = keyof Events;
/** Any event this service sends, narrowed by its `detail-type`. */
export type Event = {
    [K in DetailType]: Events[K] & {
        "detail-type": K;
    };
}[DetailType];
//# sourceMappingURL=ses-events.d.ts.map