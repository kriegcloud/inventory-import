import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly errors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly code: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly quotaValue: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UninitializedAccountException_base: S.TaggedErrorClass<"UninitializedAccountException", {
    readonly message: any;
    readonly code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UninitializedAccountException extends /*@__PURE__*/ UninitializedAccountException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly code: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationID = string;
export type AccountID = string;
export interface ArchiveApplicationRequest {
    applicationID: string;
    accountID?: string | undefined;
}
export type ARN = string;
export type ApplicationName = string;
export type ApplicationDescription = string;
export type ISO8601DatetimeString = string;
export type ApplicationHealthStatus = string;
export type ApplicationProgressStatus = string;
export type PositiveInteger = number;
export interface ApplicationAggregatedStatus {
    lastUpdateDateTime?: string | undefined;
    healthStatus?: string | undefined;
    progressStatus?: string | undefined;
    totalSourceServers?: number | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type WaveID = string;
export interface Application {
    applicationID?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    isArchived?: boolean | undefined;
    applicationAggregatedStatus?: ApplicationAggregatedStatus | undefined;
    creationDateTime?: string | undefined;
    lastModifiedDateTime?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    waveID?: string | undefined;
}
export interface ArchiveWaveRequest {
    waveID: string;
    accountID?: string | undefined;
}
export type WaveName = string;
export type WaveDescription = string;
export type WaveHealthStatus = string;
export type WaveProgressStatus = string;
export interface WaveAggregatedStatus {
    lastUpdateDateTime?: string | undefined;
    replicationStartedDateTime?: string | undefined;
    healthStatus?: string | undefined;
    progressStatus?: string | undefined;
    totalApplications?: number | undefined;
}
export interface Wave {
    waveID?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    isArchived?: boolean | undefined;
    waveAggregatedStatus?: WaveAggregatedStatus | undefined;
    creationDateTime?: string | undefined;
    lastModifiedDateTime?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ApplicationIDs = string[];
export interface AssociateApplicationsRequest {
    waveID: string;
    applicationIDs: string[];
    accountID?: string | undefined;
}
export interface AssociateApplicationsResponse {
}
export type SourceServerID = string;
export type AssociateSourceServersRequestSourceServerIDs = string[];
export interface AssociateSourceServersRequest {
    applicationID: string;
    sourceServerIDs: string[];
    accountID?: string | undefined;
}
export interface AssociateSourceServersResponse {
}
export type ChangeServerLifeCycleStateSourceServerLifecycleState = string;
export interface ChangeServerLifeCycleStateSourceServerLifecycle {
    state: string;
}
export interface ChangeServerLifeCycleStateRequest {
    sourceServerID: string;
    lifeCycle: ChangeServerLifeCycleStateSourceServerLifecycle;
    accountID?: string | undefined;
}
export type EC2InstanceID = string;
export type JobID = string;
export type FirstBoot = string;
export type LastKnownCheckType = string;
export type BoundedString = string;
export type LastKnownCheckStatus = string;
export interface LastKnownCheck {
    type?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    error?: string | undefined;
    checkedAt?: Date | undefined;
}
export type LastKnownChecksList = LastKnownCheck[];
export interface LaunchedInstance {
    ec2InstanceID?: string | undefined;
    jobID?: string | undefined;
    firstBoot?: string | undefined;
    lastKnownChecks?: LastKnownCheck[] | undefined;
    lastKnownFsxChecksStatus?: string | undefined;
}
export type ISO8601DurationString = string;
export interface DataReplicationInfoReplicatedDisk {
    deviceName?: string | undefined;
    totalStorageBytes?: number | undefined;
    replicatedStorageBytes?: number | undefined;
    rescannedStorageBytes?: number | undefined;
    backloggedStorageBytes?: number | undefined;
}
export type DataReplicationInfoReplicatedDisks = DataReplicationInfoReplicatedDisk[];
export type DataReplicationState = string;
export type DataReplicationInitiationStepName = string;
export type DataReplicationInitiationStepStatus = string;
export interface DataReplicationInitiationStep {
    name?: string | undefined;
    status?: string | undefined;
}
export type DataReplicationInitiationSteps = DataReplicationInitiationStep[];
export interface DataReplicationInitiation {
    startDateTime?: string | undefined;
    nextAttemptDateTime?: string | undefined;
    steps?: DataReplicationInitiationStep[] | undefined;
}
export type DataReplicationErrorString = string;
export type LargeBoundedString = string;
export interface DataReplicationError {
    error?: string | undefined;
    rawError?: string | undefined;
}
export type ReplicatorID = string;
export interface DataReplicationInfo {
    lagDuration?: string | undefined;
    etaDateTime?: string | undefined;
    replicatedDisks?: DataReplicationInfoReplicatedDisk[] | undefined;
    dataReplicationState?: string | undefined;
    dataReplicationInitiation?: DataReplicationInitiation | undefined;
    dataReplicationError?: DataReplicationError | undefined;
    lastSnapshotDateTime?: string | undefined;
    replicatorId?: string | undefined;
}
export interface LifeCycleLastTestInitiated {
    apiCallDateTime?: string | undefined;
    jobID?: string | undefined;
}
export interface LifeCycleLastTestReverted {
    apiCallDateTime?: string | undefined;
}
export interface LifeCycleLastTestFinalized {
    apiCallDateTime?: string | undefined;
}
export interface LifeCycleLastTest {
    initiated?: LifeCycleLastTestInitiated | undefined;
    reverted?: LifeCycleLastTestReverted | undefined;
    finalized?: LifeCycleLastTestFinalized | undefined;
}
export interface LifeCycleLastCutoverInitiated {
    apiCallDateTime?: string | undefined;
    jobID?: string | undefined;
}
export interface LifeCycleLastCutoverReverted {
    apiCallDateTime?: string | undefined;
}
export interface LifeCycleLastCutoverFinalized {
    apiCallDateTime?: string | undefined;
}
export interface LifeCycleLastCutover {
    initiated?: LifeCycleLastCutoverInitiated | undefined;
    reverted?: LifeCycleLastCutoverReverted | undefined;
    finalized?: LifeCycleLastCutoverFinalized | undefined;
}
export type LifeCycleState = string;
export interface LifeCycle {
    addedToServiceDateTime?: string | undefined;
    firstByteDateTime?: string | undefined;
    elapsedReplicationDuration?: string | undefined;
    lastSeenByServiceDateTime?: string | undefined;
    lastTest?: LifeCycleLastTest | undefined;
    lastCutover?: LifeCycleLastCutover | undefined;
    state?: string | undefined;
}
export type EC2InstanceType = string;
export interface IdentificationHints {
    fqdn?: string | undefined;
    hostname?: string | undefined;
    vmWareUuid?: string | undefined;
    awsInstanceID?: string | undefined;
    vmPath?: string | undefined;
}
export type IPsList = string[];
export interface NetworkInterface {
    macAddress?: string | undefined;
    ips?: string[] | undefined;
    isPrimary?: boolean | undefined;
}
export type NetworkInterfaces = NetworkInterface[];
export interface Disk {
    deviceName?: string | undefined;
    bytes?: number | undefined;
}
export type Disks = Disk[];
export interface CPU {
    cores?: number | undefined;
    modelName?: string | undefined;
}
export type Cpus = CPU[];
export interface OS {
    fullString?: string | undefined;
}
export interface SourceProperties {
    lastUpdatedDateTime?: string | undefined;
    recommendedInstanceType?: string | undefined;
    identificationHints?: IdentificationHints | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
    disks?: Disk[] | undefined;
    cpus?: CPU[] | undefined;
    ramBytes?: number | undefined;
    os?: OS | undefined;
}
export type ReplicationType = string;
export type VcenterClientID = string;
export type UserProvidedId = string;
export type SecretArn = string;
export type ConnectorArn = string;
export interface SourceServerConnectorAction {
    credentialsSecretArn?: string | undefined;
    connectorArn?: string | undefined;
}
export interface SourceServer {
    sourceServerID?: string | undefined;
    arn?: string | undefined;
    isArchived?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    launchedInstance?: LaunchedInstance | undefined;
    dataReplicationInfo?: DataReplicationInfo | undefined;
    lifeCycle?: LifeCycle | undefined;
    sourceProperties?: SourceProperties | undefined;
    replicationType?: string | undefined;
    vcenterClientID?: string | undefined;
    applicationID?: string | undefined;
    userProvidedID?: string | undefined;
    fqdnForActionFramework?: string | undefined;
    connectorAction?: SourceServerConnectorAction | undefined;
}
export interface CreateApplicationRequest {
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountID?: string | undefined;
}
export type ConnectorName = string;
export type SsmInstanceID = string;
export type S3BucketName = string;
export type CloudWatchLogGroupName = string;
export interface ConnectorSsmCommandConfig {
    s3OutputEnabled: boolean;
    outputS3BucketName?: string | undefined;
    cloudWatchOutputEnabled: boolean;
    cloudWatchLogGroupName?: string | undefined;
}
export interface CreateConnectorRequest {
    name: string;
    ssmInstanceID: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ssmCommandConfig?: ConnectorSsmCommandConfig | undefined;
}
export type ConnectorID = string;
export interface Connector {
    connectorID?: string | undefined;
    name?: string | undefined;
    ssmInstanceID?: string | undefined;
    arn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ssmCommandConfig?: ConnectorSsmCommandConfig | undefined;
}
export type PostLaunchActionsDeploymentType = string;
export type S3LogBucketName = string;
export type SsmDocumentName = string;
export type StrictlyPositiveInteger = number;
export type SsmDocumentParameterName = string;
export type SsmParameterStoreParameterType = string;
export type SsmParameterStoreParameterName = string;
export interface SsmParameterStoreParameter {
    parameterType: string;
    parameterName: string;
}
export type SsmParameterStoreParameters = SsmParameterStoreParameter[];
export type SsmDocumentParameters = {
    [key: string]: SsmParameterStoreParameter[] | undefined;
};
export type JmesPathString = string;
export type SsmExternalParameter = {
    dynamicPath: string;
};
export type SsmDocumentExternalParameters = {
    [key: string]: SsmExternalParameter | undefined;
};
export interface SsmDocument {
    actionName: string;
    ssmDocumentName: string;
    timeoutSeconds?: number | undefined;
    mustSucceedForCutover?: boolean | undefined;
    parameters?: {
        [key: string]: SsmParameterStoreParameter[] | undefined;
    } | undefined;
    externalParameters?: {
        [key: string]: SsmExternalParameter | undefined;
    } | undefined;
}
export type SsmDocuments = SsmDocument[];
export interface PostLaunchActions {
    deployment?: string | undefined;
    s3LogBucket?: string | undefined;
    s3OutputKeyPrefix?: string | undefined;
    cloudWatchLogGroupName?: string | undefined;
    ssmDocuments?: SsmDocument[] | undefined;
}
export type LaunchDisposition = string;
export type TargetInstanceTypeRightSizingMethod = string;
export interface Licensing {
    osByol?: boolean | undefined;
}
export type BootMode = string;
export type VolumeType = string;
export type Iops = number;
export type Throughput = number;
export type VolumeInitializationRate = number;
export interface LaunchTemplateDiskConf {
    volumeType?: string | undefined;
    iops?: number | undefined;
    throughput?: number | undefined;
    volumeInitializationRate?: number | undefined;
    deleteOnTermination?: boolean | undefined;
}
export type KmsKeyArn = string;
export interface CreateLaunchConfigurationTemplateRequest {
    postLaunchActions?: PostLaunchActions | undefined;
    enableMapAutoTagging?: boolean | undefined;
    mapAutoTaggingMpeID?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    launchDisposition?: string | undefined;
    targetInstanceTypeRightSizingMethod?: string | undefined;
    copyPrivateIp?: boolean | undefined;
    associatePublicIpAddress?: boolean | undefined;
    copyTags?: boolean | undefined;
    licensing?: Licensing | undefined;
    bootMode?: string | undefined;
    smallVolumeMaxSize?: number | undefined;
    smallVolumeConf?: LaunchTemplateDiskConf | undefined;
    largeVolumeConf?: LaunchTemplateDiskConf | undefined;
    enableParametersEncryption?: boolean | undefined;
    parametersEncryptionKey?: string | undefined;
}
export type LaunchConfigurationTemplateID = string;
export type EC2LaunchConfigurationTemplateID = string;
export interface LaunchConfigurationTemplate {
    launchConfigurationTemplateID: string;
    arn?: string | undefined;
    postLaunchActions?: PostLaunchActions | undefined;
    enableMapAutoTagging?: boolean | undefined;
    mapAutoTaggingMpeID?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ec2LaunchTemplateID?: string | undefined;
    launchDisposition?: string | undefined;
    targetInstanceTypeRightSizingMethod?: string | undefined;
    copyPrivateIp?: boolean | undefined;
    associatePublicIpAddress?: boolean | undefined;
    copyTags?: boolean | undefined;
    licensing?: Licensing | undefined;
    bootMode?: string | undefined;
    smallVolumeMaxSize?: number | undefined;
    smallVolumeConf?: LaunchTemplateDiskConf | undefined;
    largeVolumeConf?: LaunchTemplateDiskConf | undefined;
    enableParametersEncryption?: boolean | undefined;
    parametersEncryptionKey?: string | undefined;
}
export type ClientIdempotencyToken = string;
export type NetworkMigrationDefinitionName = string;
export type NetworkMigrationDefinitionDescription = string;
export type SourceEnvironment = string;
export type S3KeyName = string;
export interface SourceS3Configuration {
    s3Bucket: string;
    s3BucketOwner: string;
    s3Key: string;
}
export interface SourceConfiguration {
    sourceEnvironment: string;
    sourceS3Configuration: SourceS3Configuration;
}
export type SourceConfigurationList = SourceConfiguration[];
export interface TargetS3Configuration {
    s3Bucket: string;
    s3BucketOwner: string;
}
export type TargetNetworkTopology = string;
export type Cidr = string;
export interface TargetNetwork {
    topology: string;
    inboundCidr?: string | undefined;
    outboundCidr?: string | undefined;
    inspectionCidr?: string | undefined;
}
export type TargetDeployment = string;
export type VpcProvisioningStrategy = string;
export interface CidrMapping {
    originalCidr: string;
    updatedCidr: string;
}
export type CidrMappingsList = CidrMapping[];
export type ScopeTagKey = string;
export type ScopeTagValue = string;
export type ScopeTagsMap = {
    [key: string]: string | undefined;
};
export interface CreateNetworkMigrationDefinitionRequest {
    clientToken?: string | undefined;
    name: string;
    description?: string | undefined;
    sourceConfigurations?: SourceConfiguration[] | undefined;
    targetS3Configuration: TargetS3Configuration;
    targetNetwork: TargetNetwork;
    targetDeployment?: string | undefined;
    vpcProvisioningStrategy?: string | undefined;
    cidrMappings?: CidrMapping[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkMigrationDefinitionID = string;
export interface NetworkMigrationDefinition {
    arn?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    sourceConfigurations?: SourceConfiguration[] | undefined;
    targetS3Configuration?: TargetS3Configuration | undefined;
    targetNetwork?: TargetNetwork | undefined;
    targetDeployment?: string | undefined;
    vpcProvisioningStrategy?: string | undefined;
    cidrMappings?: CidrMapping[] | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SubnetID = string;
export type SecurityGroupID = string;
export type ReplicationServersSecurityGroupsIDs = string[];
export type ReplicationConfigurationDefaultLargeStagingDiskType = string;
export type ReplicationConfigurationEbsEncryption = string;
export type BandwidthThrottling = number;
export type ReplicationConfigurationDataPlaneRouting = string;
export type InternetProtocol = string;
export type StorageType = string;
export type StorageVirtualMachineId = string;
export interface FsxOntapConfiguration {
    storageVirtualMachineId: string;
    credentialsSecretArn: string;
}
export interface StorageConfiguration {
    storageType: string;
    fsxOntapConfiguration?: FsxOntapConfiguration | undefined;
}
export interface CreateReplicationConfigurationTemplateRequest {
    stagingAreaSubnetId: string;
    associateDefaultSecurityGroup: boolean;
    replicationServersSecurityGroupsIDs: string[];
    replicationServerInstanceType: string;
    useDedicatedReplicationServer: boolean;
    defaultLargeStagingDiskType: string;
    ebsEncryption: string;
    ebsEncryptionKeyArn?: string | undefined;
    bandwidthThrottling: number;
    dataPlaneRouting: string;
    createPublicIP: boolean;
    stagingAreaTags: {
        [key: string]: string | undefined;
    };
    useFipsEndpoint?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    internetProtocol?: string | undefined;
    storeSnapshotOnLocalZone?: boolean | undefined;
    storageConfiguration?: StorageConfiguration | undefined;
}
export type ReplicationConfigurationTemplateID = string;
export interface ReplicationConfigurationTemplate {
    replicationConfigurationTemplateID: string;
    arn?: string | undefined;
    stagingAreaSubnetId?: string | undefined;
    associateDefaultSecurityGroup?: boolean | undefined;
    replicationServersSecurityGroupsIDs?: string[] | undefined;
    replicationServerInstanceType?: string | undefined;
    useDedicatedReplicationServer?: boolean | undefined;
    defaultLargeStagingDiskType?: string | undefined;
    ebsEncryption?: string | undefined;
    ebsEncryptionKeyArn?: string | undefined;
    bandwidthThrottling?: number | undefined;
    dataPlaneRouting?: string | undefined;
    createPublicIP?: boolean | undefined;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    } | undefined;
    useFipsEndpoint?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    internetProtocol?: string | undefined;
    storeSnapshotOnLocalZone?: boolean | undefined;
    storageConfiguration?: StorageConfiguration | undefined;
}
export interface CreateWaveRequest {
    name: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountID?: string | undefined;
}
export interface DeleteApplicationRequest {
    applicationID: string;
    accountID?: string | undefined;
}
export interface DeleteApplicationResponse {
}
export interface DeleteConnectorRequest {
    connectorID: string;
}
export interface DeleteConnectorResponse {
}
export interface DeleteJobRequest {
    jobID: string;
    accountID?: string | undefined;
}
export interface DeleteJobResponse {
}
export interface DeleteLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
}
export interface DeleteLaunchConfigurationTemplateResponse {
}
export interface DeleteNetworkMigrationDefinitionRequest {
    networkMigrationDefinitionID: string;
}
export interface DeleteNetworkMigrationDefinitionResponse {
}
export interface DeleteReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
}
export interface DeleteReplicationConfigurationTemplateResponse {
}
export interface DeleteSourceServerRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface DeleteSourceServerResponse {
}
export interface DeleteVcenterClientRequest {
    vcenterClientID: string;
}
export interface DeleteVcenterClientResponse {
}
export interface DeleteWaveRequest {
    waveID: string;
    accountID?: string | undefined;
}
export interface DeleteWaveResponse {
}
export type MaxResultsType = number;
export type PaginationToken = string;
export interface DescribeJobLogItemsRequest {
    jobID: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type JobLogEvent = string;
export interface JobLogEventData {
    sourceServerID?: string | undefined;
    conversionServerID?: string | undefined;
    targetInstanceID?: string | undefined;
    rawError?: string | undefined;
    attemptCount?: number | undefined;
    maxAttemptsCount?: number | undefined;
}
export interface JobLog {
    logDateTime?: string | undefined;
    event?: string | undefined;
    eventData?: JobLogEventData | undefined;
}
export type JobLogs = JobLog[];
export interface DescribeJobLogItemsResponse {
    items?: JobLog[] | undefined;
    nextToken?: string | undefined;
}
export type DescribeJobsRequestFiltersJobIDs = string[];
export interface DescribeJobsRequestFilters {
    jobIDs?: string[] | undefined;
    fromDate?: string | undefined;
    toDate?: string | undefined;
}
export interface DescribeJobsRequest {
    filters?: DescribeJobsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type JobType = string;
export type InitiatedBy = string;
export type JobStatus = string;
export type LaunchStatus = string;
export type SsmDocumentType = string;
export type PostLaunchActionExecutionStatus = string;
export interface JobPostLaunchActionsLaunchStatus {
    ssmDocument?: SsmDocument | undefined;
    ssmDocumentType?: string | undefined;
    executionID?: string | undefined;
    executionStatus?: string | undefined;
    failureReason?: string | undefined;
}
export type PostLaunchActionsLaunchStatusList = JobPostLaunchActionsLaunchStatus[];
export interface PostLaunchActionsStatus {
    ssmAgentDiscoveryDatetime?: string | undefined;
    postLaunchActionsLaunchStatusList?: JobPostLaunchActionsLaunchStatus[] | undefined;
}
export interface ParticipatingServer {
    sourceServerID: string;
    launchStatus?: string | undefined;
    launchedEc2InstanceID?: string | undefined;
    postLaunchActionsStatus?: PostLaunchActionsStatus | undefined;
}
export type ParticipatingServers = ParticipatingServer[];
export interface Job {
    jobID: string;
    arn?: string | undefined;
    type?: string | undefined;
    initiatedBy?: string | undefined;
    creationDateTime?: string | undefined;
    endDateTime?: string | undefined;
    status?: string | undefined;
    participatingServers?: ParticipatingServer[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type JobsList = Job[];
export interface DescribeJobsResponse {
    items?: Job[] | undefined;
    nextToken?: string | undefined;
}
export type LaunchConfigurationTemplateIDs = string[];
export interface DescribeLaunchConfigurationTemplatesRequest {
    launchConfigurationTemplateIDs?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type LaunchConfigurationTemplates = LaunchConfigurationTemplate[];
export interface DescribeLaunchConfigurationTemplatesResponse {
    items?: LaunchConfigurationTemplate[] | undefined;
    nextToken?: string | undefined;
}
export type ReplicationConfigurationTemplateIDs = string[];
export interface DescribeReplicationConfigurationTemplatesRequest {
    replicationConfigurationTemplateIDs?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ReplicationConfigurationTemplates = ReplicationConfigurationTemplate[];
export interface DescribeReplicationConfigurationTemplatesResponse {
    items?: ReplicationConfigurationTemplate[] | undefined;
    nextToken?: string | undefined;
}
export type DescribeSourceServersRequestFiltersIDs = string[];
export type ReplicationTypes = string[];
export type LifeCycleStates = string[];
export type DescribeSourceServersRequestApplicationIDs = string[];
export interface DescribeSourceServersRequestFilters {
    sourceServerIDs?: string[] | undefined;
    isArchived?: boolean | undefined;
    replicationTypes?: string[] | undefined;
    lifeCycleStates?: string[] | undefined;
    applicationIDs?: string[] | undefined;
}
export interface DescribeSourceServersRequest {
    filters?: DescribeSourceServersRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type SourceServersList = SourceServer[];
export interface DescribeSourceServersResponse {
    items?: SourceServer[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeVcenterClientsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface VcenterClient {
    vcenterClientID?: string | undefined;
    arn?: string | undefined;
    hostname?: string | undefined;
    vcenterUUID?: string | undefined;
    datacenterName?: string | undefined;
    lastSeenDatetime?: string | undefined;
    sourceServerTags?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VcenterClientList = VcenterClient[];
export interface DescribeVcenterClientsResponse {
    items?: VcenterClient[] | undefined;
    nextToken?: string | undefined;
}
export interface DisassociateApplicationsRequest {
    waveID: string;
    applicationIDs: string[];
    accountID?: string | undefined;
}
export interface DisassociateApplicationsResponse {
}
export type DisassociateSourceServersRequestSourceServerIDs = string[];
export interface DisassociateSourceServersRequest {
    applicationID: string;
    sourceServerIDs: string[];
    accountID?: string | undefined;
}
export interface DisassociateSourceServersResponse {
}
export interface DisconnectFromServiceRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface FinalizeCutoverRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface GetLaunchConfigurationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export type SmallBoundedString = string;
export interface LaunchConfiguration {
    sourceServerID?: string | undefined;
    name?: string | undefined;
    ec2LaunchTemplateID?: string | undefined;
    launchDisposition?: string | undefined;
    targetInstanceTypeRightSizingMethod?: string | undefined;
    copyPrivateIp?: boolean | undefined;
    copyTags?: boolean | undefined;
    licensing?: Licensing | undefined;
    bootMode?: string | undefined;
    postLaunchActions?: PostLaunchActions | undefined;
    enableMapAutoTagging?: boolean | undefined;
    mapAutoTaggingMpeID?: string | undefined;
}
export interface GetNetworkMigrationDefinitionRequest {
    networkMigrationDefinitionID: string;
}
export type NetworkMigrationExecutionID = string;
export type SegmentID = string;
export type ConstructID = string;
export interface GetNetworkMigrationMapperSegmentConstructRequest {
    networkMigrationDefinitionID: string;
    networkMigrationExecutionID: string;
    segmentID: string;
    constructID: string;
}
export type NetworkMigrationMapperSegmentConstructType = string;
export type SegmentConstructName = string;
export type SegmentConstructDescription = string;
export type LogicalID = string;
export type ConstructPropertyKey = string;
export type MarshalledResourceDefinition = string;
export type ConstructProperties = {
    [key: string]: string | undefined;
};
export interface NetworkMigrationMapperSegmentConstruct {
    constructID?: string | undefined;
    constructType?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    logicalID?: string | undefined;
    excluded?: boolean | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetNetworkMigrationMapperSegmentConstructResponse {
    construct?: NetworkMigrationMapperSegmentConstruct | undefined;
}
export interface GetReplicationConfigurationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export type ReplicationConfigurationReplicatedDiskStagingDiskType = string;
export interface ReplicationConfigurationReplicatedDisk {
    deviceName?: string | undefined;
    isBootDisk?: boolean | undefined;
    stagingDiskType?: string | undefined;
    iops?: number | undefined;
    throughput?: number | undefined;
}
export type ReplicationConfigurationReplicatedDisks = ReplicationConfigurationReplicatedDisk[];
export interface ReplicationConfiguration {
    sourceServerID?: string | undefined;
    name?: string | undefined;
    stagingAreaSubnetId?: string | undefined;
    associateDefaultSecurityGroup?: boolean | undefined;
    replicationServersSecurityGroupsIDs?: string[] | undefined;
    replicationServerInstanceType?: string | undefined;
    useDedicatedReplicationServer?: boolean | undefined;
    defaultLargeStagingDiskType?: string | undefined;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[] | undefined;
    ebsEncryption?: string | undefined;
    ebsEncryptionKeyArn?: string | undefined;
    bandwidthThrottling?: number | undefined;
    dataPlaneRouting?: string | undefined;
    createPublicIP?: boolean | undefined;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    } | undefined;
    useFipsEndpoint?: boolean | undefined;
    internetProtocol?: string | undefined;
    storeSnapshotOnLocalZone?: boolean | undefined;
    storageConfiguration?: StorageConfiguration | undefined;
}
export interface InitializeServiceRequest {
}
export interface InitializeServiceResponse {
}
export type ApplicationIDsFilter = string[];
export type WaveIDsFilter = string[];
export interface ListApplicationsRequestFilters {
    applicationIDs?: string[] | undefined;
    isArchived?: boolean | undefined;
    waveIDs?: string[] | undefined;
}
export interface ListApplicationsRequest {
    filters?: ListApplicationsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type ApplicationsList = Application[];
export interface ListApplicationsResponse {
    items?: Application[] | undefined;
    nextToken?: string | undefined;
}
export type ConnectorIDsFilter = string[];
export interface ListConnectorsRequestFilters {
    connectorIDs?: string[] | undefined;
}
export interface ListConnectorsRequest {
    filters?: ListConnectorsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ConnectorsList = Connector[];
export interface ListConnectorsResponse {
    items?: Connector[] | undefined;
    nextToken?: string | undefined;
}
export type ExportID = string;
export interface ListExportErrorsRequest {
    exportID: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ExportErrorData {
    rawError?: string | undefined;
}
export interface ExportTaskError {
    errorDateTime?: string | undefined;
    errorData?: ExportErrorData | undefined;
}
export type ExportErrors = ExportTaskError[];
export interface ListExportErrorsResponse {
    items?: ExportTaskError[] | undefined;
    nextToken?: string | undefined;
}
export type ListExportsRequestFiltersExportIDs = string[];
export interface ListExportsRequestFilters {
    exportIDs?: string[] | undefined;
}
export interface ListExportsRequest {
    filters?: ListExportsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type S3Key = string;
export type ExportStatus = string;
export interface ExportTaskSummary {
    serversCount?: number | undefined;
    applicationsCount?: number | undefined;
    wavesCount?: number | undefined;
}
export interface ExportTask {
    exportID?: string | undefined;
    arn?: string | undefined;
    s3Bucket?: string | undefined;
    s3Key?: string | undefined;
    s3BucketOwner?: string | undefined;
    creationDateTime?: string | undefined;
    endDateTime?: string | undefined;
    status?: string | undefined;
    progressPercentage?: number | undefined;
    summary?: ExportTaskSummary | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ExportsList = ExportTask[];
export interface ListExportsResponse {
    items?: ExportTask[] | undefined;
    nextToken?: string | undefined;
}
export type ImportID = string;
export interface ListImportErrorsRequest {
    importID: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ImportErrorType = string;
export interface ImportErrorData {
    sourceServerID?: string | undefined;
    applicationID?: string | undefined;
    waveID?: string | undefined;
    ec2LaunchTemplateID?: string | undefined;
    rowNumber?: number | undefined;
    rawError?: string | undefined;
    accountID?: string | undefined;
}
export interface ImportTaskError {
    errorDateTime?: string | undefined;
    errorType?: string | undefined;
    errorData?: ImportErrorData | undefined;
}
export type ImportErrors = ImportTaskError[];
export interface ListImportErrorsResponse {
    items?: ImportTaskError[] | undefined;
    nextToken?: string | undefined;
}
export type ImportFileEnrichmentJobID = string;
export type ImportFileEnrichmentsIDsFilter = string[];
export interface ListImportFileEnrichmentsFilters {
    jobIDs?: string[] | undefined;
}
export interface ListImportFileEnrichmentsRequest {
    filters?: ListImportFileEnrichmentsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ImportFileEnrichmentStatus = string;
export type EncryptionAlgorithm = string;
export type Hash = string;
export interface Checksum {
    encryptionAlgorithm?: string | undefined;
    hash?: string | undefined;
}
export interface EnrichmentTargetS3Configuration {
    s3Bucket: string;
    s3BucketOwner: string;
    s3Key: string;
}
export interface ImportFileEnrichment {
    jobID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
    checksum?: Checksum | undefined;
    s3BucketTarget?: EnrichmentTargetS3Configuration | undefined;
}
export type ImportFileEnrichmentsList = ImportFileEnrichment[];
export interface ListImportFileEnrichmentsResponse {
    items?: ImportFileEnrichment[] | undefined;
    nextToken?: string | undefined;
}
export type ImportIDsFilter = string[];
export interface ListImportsRequestFilters {
    importIDs?: string[] | undefined;
}
export interface ListImportsRequest {
    filters?: ListImportsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface S3BucketSource {
    s3Bucket: string;
    s3Key: string;
    s3BucketOwner?: string | undefined;
}
export type ImportStatus = string;
export interface ImportTaskSummaryWaves {
    createdCount?: number | undefined;
    modifiedCount?: number | undefined;
}
export interface ImportTaskSummaryApplications {
    createdCount?: number | undefined;
    modifiedCount?: number | undefined;
}
export interface ImportTaskSummaryServers {
    createdCount?: number | undefined;
    modifiedCount?: number | undefined;
}
export interface ImportTaskSummary {
    waves?: ImportTaskSummaryWaves | undefined;
    applications?: ImportTaskSummaryApplications | undefined;
    servers?: ImportTaskSummaryServers | undefined;
}
export interface ImportTask {
    importID?: string | undefined;
    arn?: string | undefined;
    s3BucketSource?: S3BucketSource | undefined;
    creationDateTime?: string | undefined;
    endDateTime?: string | undefined;
    status?: string | undefined;
    progressPercentage?: number | undefined;
    summary?: ImportTaskSummary | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ImportList = ImportTask[];
export interface ListImportsResponse {
    items?: ImportTask[] | undefined;
    nextToken?: string | undefined;
}
export interface ListManagedAccountsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ManagedAccount {
    accountId?: string | undefined;
}
export type ManagedAccounts = ManagedAccount[];
export interface ListManagedAccountsResponse {
    items: ManagedAccount[];
    nextToken?: string | undefined;
}
export type NetworkMigrationJobID = string;
export type ListNetworkMigrationAnalysesIDsFilter = string[];
export interface ListNetworkMigrationAnalysesFilters {
    jobIDs?: string[] | undefined;
}
export interface ListNetworkMigrationAnalysesRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationAnalysesFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationJobStatus = string;
export interface NetworkMigrationAnalysisJobDetails {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
}
export type NetworkMigrationAnalysesList = NetworkMigrationAnalysisJobDetails[];
export interface ListNetworkMigrationAnalysesResponse {
    items?: NetworkMigrationAnalysisJobDetails[] | undefined;
    nextToken?: string | undefined;
}
export type VpcID = string;
export type VpcIDsFilter = string[];
export interface ListNetworkMigrationAnalysisResultsFilters {
    vpcIDs?: string[] | undefined;
}
export interface ListNetworkMigrationAnalysisResultsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationAnalysisResultsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AnalyzerType = string;
export interface NetworkMigrationAnalysisResultSource {
    vpcID?: string | undefined;
    subnetID?: string | undefined;
}
export interface NetworkMigrationAnalysisResultTarget {
    vpcID?: string | undefined;
    subnetID?: string | undefined;
}
export type NetworkMigrationAnalysisResultStatus = string;
export interface NetworkMigrationAnalysisResult {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    analyzerType?: string | undefined;
    source?: NetworkMigrationAnalysisResultSource | undefined;
    target?: NetworkMigrationAnalysisResultTarget | undefined;
    status?: string | undefined;
    analysisResult?: string | undefined;
}
export type NetworkMigrationAnalysisResultsList = NetworkMigrationAnalysisResult[];
export interface ListNetworkMigrationAnalysisResultsResponse {
    items?: NetworkMigrationAnalysisResult[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationCodeGenerationsIDsFilter = string[];
export interface ListNetworkMigrationCodeGenerationsFilters {
    jobIDs?: string[] | undefined;
}
export interface ListNetworkMigrationCodeGenerationsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationCodeGenerationsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type CodeGenerationOutputFormatType = string;
export type CodeGenerationOutputFormatStatus = string;
export interface CodeGenerationOutputFormatStatusDetails {
    status?: string | undefined;
    statusDetailList?: string | undefined;
}
export type CodeGenerationOutputFormatStatusDetailsMap = {
    [key: string]: CodeGenerationOutputFormatStatusDetails | undefined;
};
export interface NetworkMigrationCodeGenerationJobDetails {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
    codeGenerationOutputFormatStatusDetailsMap?: {
        [key: string]: CodeGenerationOutputFormatStatusDetails | undefined;
    } | undefined;
}
export type NetworkMigrationCodeGenerationsList = NetworkMigrationCodeGenerationJobDetails[];
export interface ListNetworkMigrationCodeGenerationsResponse {
    items?: NetworkMigrationCodeGenerationJobDetails[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationCodeGenerationSegmentsIDsFilter = string[];
export interface ListNetworkMigrationCodeGenerationSegmentsFilters {
    segmentIDs?: string[] | undefined;
}
export interface ListNetworkMigrationCodeGenerationSegmentsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationCodeGenerationSegmentsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationCodeGenerationSegmentType = string;
export type NetworkMigrationCodeGenerationArtifactID = string;
export type NetworkMigrationCodeGenerationArtifactType = string;
export type NetworkMigrationCodeGenerationArtifactSubType = string;
export interface S3Configuration {
    s3Bucket?: string | undefined;
    s3BucketOwner?: string | undefined;
    s3Key?: string | undefined;
}
export interface NetworkMigrationCodeGenerationArtifact {
    artifactID?: string | undefined;
    artifactType?: string | undefined;
    artifactSubType?: string | undefined;
    logicalID?: string | undefined;
    outputS3Configuration?: S3Configuration | undefined;
    checksum?: Checksum | undefined;
    createdAt?: Date | undefined;
}
export type NetworkMigrationCodeGenerationArtifacts = NetworkMigrationCodeGenerationArtifact[];
export type ReferencedSegmentsList = string[];
export interface NetworkMigrationCodeGenerationSegment {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    segmentID?: string | undefined;
    segmentType?: string | undefined;
    logicalID?: string | undefined;
    mapperSegmentID?: string | undefined;
    artifacts?: NetworkMigrationCodeGenerationArtifact[] | undefined;
    referencedSegments?: string[] | undefined;
    createdAt?: Date | undefined;
}
export type NetworkMigrationCodeGenerationSegmentsList = NetworkMigrationCodeGenerationSegment[];
export interface ListNetworkMigrationCodeGenerationSegmentsResponse {
    items?: NetworkMigrationCodeGenerationSegment[] | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationDefintionsIDsFilter = string[];
export interface ListNetworkMigrationDefinitionsRequestFilters {
    networkMigrationDefinitionIDs?: string[] | undefined;
}
export interface ListNetworkMigrationDefinitionsRequest {
    filters?: ListNetworkMigrationDefinitionsRequestFilters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface NetworkMigrationDefinitionSummary {
    networkMigrationDefinitionID?: string | undefined;
    name?: string | undefined;
    sourceEnvironment?: string | undefined;
    arn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkMigrationDefinitionSummariesList = NetworkMigrationDefinitionSummary[];
export interface ListNetworkMigrationDefinitionsResponse {
    items?: NetworkMigrationDefinitionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListNetworkMigrationDeployedStacksRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationDeployedStackStatus = string;
export type PhysicalID = string;
export type NetworkMigrationFailedResourceStatus = string;
export interface NetworkMigrationFailedResourceDetails {
    logicalID?: string | undefined;
    status?: string | undefined;
    statusReason?: string | undefined;
}
export type NetworkMigrationFailedResourcesList = NetworkMigrationFailedResourceDetails[];
export interface NetworkMigrationDeployedStackDetails {
    status?: string | undefined;
    stackPhysicalID?: string | undefined;
    stackLogicalID?: string | undefined;
    segmentID?: string | undefined;
    targetAccount?: string | undefined;
    failedResources?: NetworkMigrationFailedResourceDetails[] | undefined;
}
export type NetworkMigrationDeployedStacksList = NetworkMigrationDeployedStackDetails[];
export interface ListNetworkMigrationDeployedStacksResponse {
    items?: NetworkMigrationDeployedStackDetails[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationDeployerJobIDsFilters = string[];
export interface ListNetworkMigrationDeployerJobFilters {
    jobIDs?: string[] | undefined;
}
export interface ListNetworkMigrationDeploymentsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationDeployerJobFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface NetworkMigrationDeployerJobDetails {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
}
export type NetworkMigrationDeployerJobList = NetworkMigrationDeployerJobDetails[];
export interface ListNetworkMigrationDeployerJobResponse {
    items?: NetworkMigrationDeployerJobDetails[] | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationExecutionIDsFilter = string[];
export type ExecutionStatus = string;
export type NetworkMigrationExecutionStatusesFilter = string[];
export interface ListNetworkMigrationExecutionRequestFilters {
    networkMigrationExecutionIDs?: string[] | undefined;
    networkMigrationExecutionStatuses?: string[] | undefined;
}
export interface ListNetworkMigrationExecutionsRequest {
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationExecutionRequestFilters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ExecutionStage = string;
export type ExecutionStageActivity = string;
export interface NetworkMigrationExecution {
    networkMigrationDefinitionID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    status?: string | undefined;
    stage?: string | undefined;
    activity?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkMigrationExecutionsList = NetworkMigrationExecution[];
export interface ListNetworkMigrationExecutionsResponse {
    items?: NetworkMigrationExecution[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationMapperSegmentConstructsIDsFilter = string[];
export type ListNetworkMigrationMapperSegmentConstructTypesFilter = string[];
export interface ListNetworkMigrationMapperSegmentConstructsFilters {
    constructIDs?: string[] | undefined;
    constructTypes?: string[] | undefined;
}
export interface ListNetworkMigrationMapperSegmentConstructsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    segmentID: string;
    filters?: ListNetworkMigrationMapperSegmentConstructsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationMapperSegmentConstructs = NetworkMigrationMapperSegmentConstruct[];
export interface ListNetworkMigrationMapperSegmentConstructsResponse {
    items?: NetworkMigrationMapperSegmentConstruct[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationMapperSegmentsIDsFilter = string[];
export interface ListNetworkMigrationMapperSegmentsFilters {
    segmentIDs?: string[] | undefined;
}
export interface ListNetworkMigrationMapperSegmentsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationMapperSegmentsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type NetworkMigrationMapperSegmentType = string;
export type SegmentName = string;
export type SegmentDescription = string;
export interface NetworkMigrationMapperSegment {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    segmentID?: string | undefined;
    segmentType?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    logicalID?: string | undefined;
    checksum?: Checksum | undefined;
    outputS3Configuration?: S3Configuration | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
    targetAccount?: string | undefined;
    referencedSegments?: string[] | undefined;
}
export type NetworkMigrationMapperSegmentsList = NetworkMigrationMapperSegment[];
export interface ListNetworkMigrationMapperSegmentsResponse {
    items?: NetworkMigrationMapperSegment[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationMappingsIDsFilter = string[];
export interface ListNetworkMigrationMappingsFilters {
    jobIDs?: string[] | undefined;
}
export interface ListNetworkMigrationMappingsRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationMappingsFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface NetworkMigrationMappingJobDetails {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
}
export type NetworkMigrationMappingsList = NetworkMigrationMappingJobDetails[];
export interface ListNetworkMigrationMappingsResponse {
    items?: NetworkMigrationMappingJobDetails[] | undefined;
    nextToken?: string | undefined;
}
export type ListNetworkMigrationMappingUpdatesIDsFilter = string[];
export interface ListNetworkMigrationMappingUpdatesFilters {
    jobIDs?: string[] | undefined;
}
export interface ListNetworkMigrationMappingUpdatesRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    filters?: ListNetworkMigrationMappingUpdatesFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface NetworkMigrationMappingUpdateJobDetails {
    jobID?: string | undefined;
    networkMigrationExecutionID?: string | undefined;
    networkMigrationDefinitionID?: string | undefined;
    createdAt?: Date | undefined;
    endedAt?: Date | undefined;
    status?: string | undefined;
    statusDetails?: string | undefined;
}
export type NetworkMigrationMappingUpdatesList = NetworkMigrationMappingUpdateJobDetails[];
export interface ListNetworkMigrationMappingUpdatesResponse {
    items?: NetworkMigrationMappingUpdateJobDetails[] | undefined;
    nextToken?: string | undefined;
}
export type ActionID = string;
export type ActionIDs = string[];
export interface SourceServerActionsRequestFilters {
    actionIDs?: string[] | undefined;
}
export interface ListSourceServerActionsRequest {
    sourceServerID: string;
    filters?: SourceServerActionsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type ActionName = string;
export type OrderType = number;
export type DocumentVersion = string;
export type ActionDescription = string;
export type ActionCategory = string;
export interface SourceServerActionDocument {
    actionID?: string | undefined;
    actionName?: string | undefined;
    documentIdentifier?: string | undefined;
    order?: number | undefined;
    documentVersion?: string | undefined;
    active?: boolean | undefined;
    timeoutSeconds?: number | undefined;
    mustSucceedForCutover?: boolean | undefined;
    parameters?: {
        [key: string]: SsmParameterStoreParameter[] | undefined;
    } | undefined;
    externalParameters?: {
        [key: string]: SsmExternalParameter | undefined;
    } | undefined;
    description?: string | undefined;
    category?: string | undefined;
}
export type SourceServerActionDocuments = SourceServerActionDocument[];
export interface ListSourceServerActionsResponse {
    items?: SourceServerActionDocument[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TemplateActionsRequestFilters {
    actionIDs?: string[] | undefined;
}
export interface ListTemplateActionsRequest {
    launchConfigurationTemplateID: string;
    filters?: TemplateActionsRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type OperatingSystemString = string;
export interface TemplateActionDocument {
    actionID?: string | undefined;
    actionName?: string | undefined;
    documentIdentifier?: string | undefined;
    order?: number | undefined;
    documentVersion?: string | undefined;
    active?: boolean | undefined;
    timeoutSeconds?: number | undefined;
    mustSucceedForCutover?: boolean | undefined;
    parameters?: {
        [key: string]: SsmParameterStoreParameter[] | undefined;
    } | undefined;
    operatingSystem?: string | undefined;
    externalParameters?: {
        [key: string]: SsmExternalParameter | undefined;
    } | undefined;
    description?: string | undefined;
    category?: string | undefined;
}
export type TemplateActionDocuments = TemplateActionDocument[];
export interface ListTemplateActionsResponse {
    items?: TemplateActionDocument[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWavesRequestFilters {
    waveIDs?: string[] | undefined;
    isArchived?: boolean | undefined;
}
export interface ListWavesRequest {
    filters?: ListWavesRequestFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountID?: string | undefined;
}
export type WavesList = Wave[];
export interface ListWavesResponse {
    items?: Wave[] | undefined;
    nextToken?: string | undefined;
}
export interface MarkAsArchivedRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface PauseReplicationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface PutSourceServerActionRequest {
    sourceServerID: string;
    actionName: string;
    documentIdentifier: string;
    order: number;
    actionID: string;
    documentVersion?: string | undefined;
    active?: boolean | undefined;
    timeoutSeconds?: number | undefined;
    mustSucceedForCutover?: boolean | undefined;
    parameters?: {
        [key: string]: SsmParameterStoreParameter[] | undefined;
    } | undefined;
    externalParameters?: {
        [key: string]: SsmExternalParameter | undefined;
    } | undefined;
    description?: string | undefined;
    category?: string | undefined;
    accountID?: string | undefined;
}
export interface PutTemplateActionRequest {
    launchConfigurationTemplateID: string;
    actionName: string;
    documentIdentifier: string;
    order: number;
    actionID: string;
    documentVersion?: string | undefined;
    active?: boolean | undefined;
    timeoutSeconds?: number | undefined;
    mustSucceedForCutover?: boolean | undefined;
    parameters?: {
        [key: string]: SsmParameterStoreParameter[] | undefined;
    } | undefined;
    operatingSystem?: string | undefined;
    externalParameters?: {
        [key: string]: SsmExternalParameter | undefined;
    } | undefined;
    description?: string | undefined;
    category?: string | undefined;
}
export interface RemoveSourceServerActionRequest {
    sourceServerID: string;
    actionID: string;
    accountID?: string | undefined;
}
export interface RemoveSourceServerActionResponse {
}
export interface RemoveTemplateActionRequest {
    launchConfigurationTemplateID: string;
    actionID: string;
}
export interface RemoveTemplateActionResponse {
}
export interface ResumeReplicationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface RetryDataReplicationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export type StartCutoverRequestSourceServerIDs = string[];
export interface StartCutoverRequest {
    sourceServerIDs: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountID?: string | undefined;
}
export interface StartCutoverResponse {
    job?: Job | undefined;
}
export interface StartExportRequest {
    s3Bucket: string;
    s3Key: string;
    s3BucketOwner?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartExportResponse {
    exportTask?: ExportTask | undefined;
}
export interface StartImportRequest {
    clientToken?: string | undefined;
    s3BucketSource: S3BucketSource;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartImportResponse {
    importTask?: ImportTask | undefined;
}
export interface EnrichmentSourceS3Configuration {
    s3Bucket: string;
    s3BucketOwner: string;
    s3Key: string;
}
export type IpAssignmentStrategy = string;
export interface StartImportFileEnrichmentRequest {
    clientToken?: string | undefined;
    s3BucketSource: EnrichmentSourceS3Configuration;
    s3BucketTarget: EnrichmentTargetS3Configuration;
    ipAssignmentStrategy?: string | undefined;
}
export interface StartImportFileEnrichmentResponse {
    jobID?: string | undefined;
}
export interface StartNetworkMigrationAnalysisRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
}
export interface StartNetworkMigrationAnalysisResponse {
    jobID?: string | undefined;
}
export type CodeGenerationOutputFormatTypes = string[];
export interface StartNetworkMigrationCodeGenerationRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    codeGenerationOutputFormatTypes?: string[] | undefined;
}
export interface StartNetworkMigrationCodeGenerationResponse {
    jobID?: string | undefined;
}
export interface StartNetworkMigrationDeploymentRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
}
export interface StartNetworkMigrationDeployerJobResponse {
    jobID?: string | undefined;
}
export type SecurityGroupMappingStrategy = string;
export interface StartNetworkMigrationMappingRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    securityGroupMappingStrategy?: string | undefined;
}
export interface StartNetworkMigrationMappingResponse {
    jobID?: string | undefined;
}
export interface MergeConstruct {
    segmentID?: string | undefined;
    constructID?: string | undefined;
}
export type MergeConstructs = MergeConstruct[];
export interface MergeOperation {
    mergeConstructs?: MergeConstruct[] | undefined;
}
export type CidrBlock = string;
export interface SplitConstruct {
    cidrBlock?: string | undefined;
}
export type SplitConstructs = SplitConstruct[];
export interface SplitOperation {
    splitConstructs?: SplitConstruct[] | undefined;
}
export interface DeleteOperation {
}
export interface UpdateOperation {
    name?: string | undefined;
    excluded?: boolean | undefined;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type OperationUnion = {
    merge: MergeOperation;
    split?: undefined;
    delete?: undefined;
    update?: undefined;
} | {
    merge?: undefined;
    split: SplitOperation;
    delete?: undefined;
    update?: undefined;
} | {
    merge?: undefined;
    split?: undefined;
    delete: DeleteOperation;
    update?: undefined;
} | {
    merge?: undefined;
    split?: undefined;
    delete?: undefined;
    update: UpdateOperation;
};
export interface StartNetworkMigrationMappingUpdateConstruct {
    segmentID: string;
    constructID: string;
    constructType: string;
    operation?: OperationUnion | undefined;
}
export type StartNetworkMigrationMappingUpdateConstructs = StartNetworkMigrationMappingUpdateConstruct[];
export interface StartNetworkMigrationMappingUpdateSegment {
    segmentID: string;
    targetAccount?: string | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StartNetworkMigrationMappingUpdateSegments = StartNetworkMigrationMappingUpdateSegment[];
export interface StartNetworkMigrationMappingUpdateRequest {
    networkMigrationExecutionID: string;
    networkMigrationDefinitionID: string;
    constructs?: StartNetworkMigrationMappingUpdateConstruct[] | undefined;
    segments?: StartNetworkMigrationMappingUpdateSegment[] | undefined;
}
export interface StartNetworkMigrationMappingUpdateResponse {
    jobID?: string | undefined;
}
export interface StartReplicationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export type StartTestRequestSourceServerIDs = string[];
export interface StartTestRequest {
    sourceServerIDs: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountID?: string | undefined;
}
export interface StartTestResponse {
    job?: Job | undefined;
}
export interface StopReplicationRequest {
    sourceServerID: string;
    accountID?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TerminateTargetInstancesRequestSourceServerIDs = string[];
export interface TerminateTargetInstancesRequest {
    sourceServerIDs: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountID?: string | undefined;
}
export interface TerminateTargetInstancesResponse {
    job?: Job | undefined;
}
export interface UnarchiveApplicationRequest {
    applicationID: string;
    accountID?: string | undefined;
}
export interface UnarchiveWaveRequest {
    waveID: string;
    accountID?: string | undefined;
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    applicationID: string;
    name?: string | undefined;
    description?: string | undefined;
    accountID?: string | undefined;
}
export interface UpdateConnectorRequest {
    connectorID: string;
    name?: string | undefined;
    ssmCommandConfig?: ConnectorSsmCommandConfig | undefined;
}
export interface UpdateLaunchConfigurationRequest {
    sourceServerID: string;
    name?: string | undefined;
    launchDisposition?: string | undefined;
    targetInstanceTypeRightSizingMethod?: string | undefined;
    copyPrivateIp?: boolean | undefined;
    copyTags?: boolean | undefined;
    licensing?: Licensing | undefined;
    bootMode?: string | undefined;
    postLaunchActions?: PostLaunchActions | undefined;
    enableMapAutoTagging?: boolean | undefined;
    mapAutoTaggingMpeID?: string | undefined;
    accountID?: string | undefined;
}
export interface UpdateLaunchConfigurationTemplateRequest {
    launchConfigurationTemplateID: string;
    postLaunchActions?: PostLaunchActions | undefined;
    enableMapAutoTagging?: boolean | undefined;
    mapAutoTaggingMpeID?: string | undefined;
    launchDisposition?: string | undefined;
    targetInstanceTypeRightSizingMethod?: string | undefined;
    copyPrivateIp?: boolean | undefined;
    associatePublicIpAddress?: boolean | undefined;
    copyTags?: boolean | undefined;
    licensing?: Licensing | undefined;
    bootMode?: string | undefined;
    smallVolumeMaxSize?: number | undefined;
    smallVolumeConf?: LaunchTemplateDiskConf | undefined;
    largeVolumeConf?: LaunchTemplateDiskConf | undefined;
    enableParametersEncryption?: boolean | undefined;
    parametersEncryptionKey?: string | undefined;
}
export interface TargetS3ConfigurationUpdate {
    s3Bucket?: string | undefined;
    s3BucketOwner?: string | undefined;
}
export interface TargetNetworkUpdate {
    topology?: string | undefined;
    inboundCidr?: string | undefined;
    outboundCidr?: string | undefined;
    inspectionCidr?: string | undefined;
}
export interface UpdateNetworkMigrationDefinitionRequest {
    networkMigrationDefinitionID: string;
    name?: string | undefined;
    description?: string | undefined;
    sourceConfigurations?: SourceConfiguration[] | undefined;
    targetS3Configuration?: TargetS3ConfigurationUpdate | undefined;
    targetNetwork?: TargetNetworkUpdate | undefined;
    targetDeployment?: string | undefined;
    vpcProvisioningStrategy?: string | undefined;
    cidrMappings?: CidrMapping[] | undefined;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateNetworkMigrationMapperSegmentRequest {
    networkMigrationDefinitionID: string;
    networkMigrationExecutionID: string;
    segmentID: string;
    scopeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateReplicationConfigurationRequest {
    sourceServerID: string;
    name?: string | undefined;
    stagingAreaSubnetId?: string | undefined;
    associateDefaultSecurityGroup?: boolean | undefined;
    replicationServersSecurityGroupsIDs?: string[] | undefined;
    replicationServerInstanceType?: string | undefined;
    useDedicatedReplicationServer?: boolean | undefined;
    defaultLargeStagingDiskType?: string | undefined;
    replicatedDisks?: ReplicationConfigurationReplicatedDisk[] | undefined;
    ebsEncryption?: string | undefined;
    ebsEncryptionKeyArn?: string | undefined;
    bandwidthThrottling?: number | undefined;
    dataPlaneRouting?: string | undefined;
    createPublicIP?: boolean | undefined;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    } | undefined;
    useFipsEndpoint?: boolean | undefined;
    accountID?: string | undefined;
    internetProtocol?: string | undefined;
    storeSnapshotOnLocalZone?: boolean | undefined;
    storageConfiguration?: StorageConfiguration | undefined;
}
export interface UpdateReplicationConfigurationTemplateRequest {
    replicationConfigurationTemplateID: string;
    arn?: string | undefined;
    stagingAreaSubnetId?: string | undefined;
    associateDefaultSecurityGroup?: boolean | undefined;
    replicationServersSecurityGroupsIDs?: string[] | undefined;
    replicationServerInstanceType?: string | undefined;
    useDedicatedReplicationServer?: boolean | undefined;
    defaultLargeStagingDiskType?: string | undefined;
    ebsEncryption?: string | undefined;
    ebsEncryptionKeyArn?: string | undefined;
    bandwidthThrottling?: number | undefined;
    dataPlaneRouting?: string | undefined;
    createPublicIP?: boolean | undefined;
    stagingAreaTags?: {
        [key: string]: string | undefined;
    } | undefined;
    useFipsEndpoint?: boolean | undefined;
    internetProtocol?: string | undefined;
    storeSnapshotOnLocalZone?: boolean | undefined;
    storageConfiguration?: StorageConfiguration | undefined;
}
export type FqdnForActionFramework = string;
export interface UpdateSourceServerRequest {
    accountID?: string | undefined;
    sourceServerID: string;
    connectorAction?: SourceServerConnectorAction | undefined;
    userProvidedID?: string | undefined;
    fqdnForActionFramework?: string | undefined;
    platform?: string | undefined;
}
export interface UpdateSourceServerReplicationTypeRequest {
    sourceServerID: string;
    replicationType: string;
    accountID?: string | undefined;
}
export interface UpdateWaveRequest {
    waveID: string;
    name?: string | undefined;
    description?: string | undefined;
    accountID?: string | undefined;
}
export interface ErrorDetails {
    message?: string | undefined;
    code?: string | undefined;
    resourceId?: string | undefined;
    resourceType?: string | undefined;
}
export type ConflictExceptionErrors = ErrorDetails[];
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name?: string | undefined;
    message?: string | undefined;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ArchiveApplicationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Archive application.
 */
export declare const archiveApplication: API.OperationMethod<ArchiveApplicationRequest & RegionInput, Application, ArchiveApplicationError, Credentials | HttpClient.HttpClient>;
export type ArchiveWaveError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Archive wave.
 */
export declare const archiveWave: API.OperationMethod<ArchiveWaveRequest & RegionInput, Wave, ArchiveWaveError, Credentials | HttpClient.HttpClient>;
export type AssociateApplicationsError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Associate applications to wave.
 */
export declare const associateApplications: API.OperationMethod<AssociateApplicationsRequest & RegionInput, AssociateApplicationsResponse, AssociateApplicationsError, Credentials | HttpClient.HttpClient>;
export type AssociateSourceServersError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Associate source servers to application.
 */
export declare const associateSourceServers: API.OperationMethod<AssociateSourceServersRequest & RegionInput, AssociateSourceServersResponse, AssociateSourceServersError, Credentials | HttpClient.HttpClient>;
export type ChangeServerLifeCycleStateError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Allows the user to set the SourceServer.LifeCycle.state property for specific Source Server IDs to one of the following: READY_FOR_TEST or READY_FOR_CUTOVER. This command only works if the Source Server is already launchable (dataReplicationInfo.lagDuration is not null.)
 */
export declare const changeServerLifeCycleState: API.OperationMethod<ChangeServerLifeCycleStateRequest & RegionInput, SourceServer, ChangeServerLifeCycleStateError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConflictException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Create application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, Application, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Create Connector.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest & RegionInput, Connector, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateLaunchConfigurationTemplateError = AccessDeniedException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new Launch Configuration Template.
 */
export declare const createLaunchConfigurationTemplate: API.OperationMethod<CreateLaunchConfigurationTemplateRequest & RegionInput, LaunchConfigurationTemplate, CreateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkMigrationDefinitionError = ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new network migration definition that specifies the source and target network configuration for a migration.
 */
export declare const createNetworkMigrationDefinition: API.OperationMethod<CreateNetworkMigrationDefinitionRequest & RegionInput, NetworkMigrationDefinition, CreateNetworkMigrationDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationConfigurationTemplateError = AccessDeniedException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Creates a new ReplicationConfigurationTemplate.
 */
export declare const createReplicationConfigurationTemplate: API.OperationMethod<CreateReplicationConfigurationTemplateRequest & RegionInput, ReplicationConfigurationTemplate, CreateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateWaveError = ConflictException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Create wave.
 */
export declare const createWave: API.OperationMethod<CreateWaveRequest & RegionInput, Wave, CreateWaveError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Delete application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Delete Connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest & RegionInput, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Job by ID.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest & RegionInput, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteLaunchConfigurationTemplateError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Launch Configuration Template by ID.
 */
export declare const deleteLaunchConfigurationTemplate: API.OperationMethod<DeleteLaunchConfigurationTemplateRequest & RegionInput, DeleteLaunchConfigurationTemplateResponse, DeleteLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkMigrationDefinitionError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a network migration definition. This operation removes the migration definition and all associated metadata.
 */
export declare const deleteNetworkMigrationDefinition: API.OperationMethod<DeleteNetworkMigrationDefinitionRequest & RegionInput, DeleteNetworkMigrationDefinitionResponse, DeleteNetworkMigrationDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationConfigurationTemplateError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single Replication Configuration Template by ID
 */
export declare const deleteReplicationConfigurationTemplate: API.OperationMethod<DeleteReplicationConfigurationTemplateRequest & RegionInput, DeleteReplicationConfigurationTemplateResponse, DeleteReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceServerError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Deletes a single source server by ID.
 */
export declare const deleteSourceServer: API.OperationMethod<DeleteSourceServerRequest & RegionInput, DeleteSourceServerResponse, DeleteSourceServerError, Credentials | HttpClient.HttpClient>;
export type DeleteVcenterClientError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Deletes a given vCenter client by ID.
 */
export declare const deleteVcenterClient: API.OperationMethod<DeleteVcenterClientRequest & RegionInput, DeleteVcenterClientResponse, DeleteVcenterClientError, Credentials | HttpClient.HttpClient>;
export type DeleteWaveError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Delete wave.
 */
export declare const deleteWave: API.OperationMethod<DeleteWaveRequest & RegionInput, DeleteWaveResponse, DeleteWaveError, Credentials | HttpClient.HttpClient>;
export type DescribeJobLogItemsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retrieves detailed job log items with paging.
 */
export declare const describeJobLogItems: API.PaginatedOperationMethod<DescribeJobLogItemsRequest & RegionInput, DescribeJobLogItemsResponse, DescribeJobLogItemsError, Credentials | HttpClient.HttpClient, JobLog>;
export type DescribeJobsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of Jobs. Use the jobIDs and fromDate and toDate filters to limit which jobs are returned. The response is sorted by creationDateTime - latest date first. Jobs are normally created by the StartTest, StartCutover, and TerminateTargetInstances APIs. Jobs are also created by DiagnosticLaunch and TerminateDiagnosticInstances, which are APIs available only to *Support* and only used in response to relevant support tickets.
 */
export declare const describeJobs: API.PaginatedOperationMethod<DescribeJobsRequest & RegionInput, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient, Job>;
export type DescribeLaunchConfigurationTemplatesError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all Launch Configuration Templates, filtered by Launch Configuration Template IDs
 */
export declare const describeLaunchConfigurationTemplates: API.PaginatedOperationMethod<DescribeLaunchConfigurationTemplatesRequest & RegionInput, DescribeLaunchConfigurationTemplatesResponse, DescribeLaunchConfigurationTemplatesError, Credentials | HttpClient.HttpClient, LaunchConfigurationTemplate>;
export type DescribeReplicationConfigurationTemplatesError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Lists all ReplicationConfigurationTemplates, filtered by replication configuration template IDs.
 */
export declare const describeReplicationConfigurationTemplates: API.PaginatedOperationMethod<DescribeReplicationConfigurationTemplatesRequest & RegionInput, DescribeReplicationConfigurationTemplatesResponse, DescribeReplicationConfigurationTemplatesError, Credentials | HttpClient.HttpClient, ReplicationConfigurationTemplate>;
export type DescribeSourceServersError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Retrieves all SourceServers or multiple SourceServers by ID.
 */
export declare const describeSourceServers: API.PaginatedOperationMethod<DescribeSourceServersRequest & RegionInput, DescribeSourceServersResponse, DescribeSourceServersError, Credentials | HttpClient.HttpClient, SourceServer>;
export type DescribeVcenterClientsError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Returns a list of the installed vCenter clients.
 */
export declare const describeVcenterClients: API.PaginatedOperationMethod<DescribeVcenterClientsRequest & RegionInput, DescribeVcenterClientsResponse, DescribeVcenterClientsError, Credentials | HttpClient.HttpClient, VcenterClient>;
export type DisassociateApplicationsError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Disassociate applications from wave.
 */
export declare const disassociateApplications: API.OperationMethod<DisassociateApplicationsRequest & RegionInput, DisassociateApplicationsResponse, DisassociateApplicationsError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceServersError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Disassociate source servers from application.
 */
export declare const disassociateSourceServers: API.OperationMethod<DisassociateSourceServersRequest & RegionInput, DisassociateSourceServersResponse, DisassociateSourceServersError, Credentials | HttpClient.HttpClient>;
export type DisconnectFromServiceError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Disconnects specific Source Servers from Application Migration Service. Data replication is stopped immediately. All AWS resources created by Application Migration Service for enabling the replication of these source servers will be terminated / deleted within 90 minutes. Launched Test or Cutover instances will NOT be terminated. If the agent on the source server has not been prevented from communicating with Application Migration Service, then it will receive a command to uninstall itself (within approximately 10 minutes). The following properties of the SourceServer will be changed immediately: dataReplicationInfo.dataReplicationState will be set to DISCONNECTED; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.etaDateTime will be nullified.
 */
export declare const disconnectFromService: API.OperationMethod<DisconnectFromServiceRequest & RegionInput, SourceServer, DisconnectFromServiceError, Credentials | HttpClient.HttpClient>;
export type FinalizeCutoverError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Finalizes the cutover immediately for specific Source Servers. All AWS resources created by Application Migration Service for enabling the replication of these source servers will be terminated / deleted within 90 minutes. Launched Test or Cutover instances will NOT be terminated. The AWS Replication Agent will receive a command to uninstall itself (within 10 minutes). The following properties of the SourceServer will be changed immediately: dataReplicationInfo.dataReplicationState will be changed to DISCONNECTED; The SourceServer.lifeCycle.state will be changed to CUTOVER; The totalStorageBytes property for each of dataReplicationInfo.replicatedDisks will be set to zero; dataReplicationInfo.lagDuration and dataReplicationInfo.etaDateTime will be nullified.
 */
export declare const finalizeCutover: API.OperationMethod<FinalizeCutoverRequest & RegionInput, SourceServer, FinalizeCutoverError, Credentials | HttpClient.HttpClient>;
export type GetLaunchConfigurationError = ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Lists all LaunchConfigurations available, filtered by Source Server IDs.
 */
export declare const getLaunchConfiguration: API.OperationMethod<GetLaunchConfigurationRequest & RegionInput, LaunchConfiguration, GetLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetNetworkMigrationDefinitionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the details of a network migration definition including source and target configurations.
 */
export declare const getNetworkMigrationDefinition: API.OperationMethod<GetNetworkMigrationDefinitionRequest & RegionInput, NetworkMigrationDefinition, GetNetworkMigrationDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetNetworkMigrationMapperSegmentConstructError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific construct within a mapper segment, including its properties and configuration data.
 */
export declare const getNetworkMigrationMapperSegmentConstruct: API.OperationMethod<GetNetworkMigrationMapperSegmentConstructRequest & RegionInput, GetNetworkMigrationMapperSegmentConstructResponse, GetNetworkMigrationMapperSegmentConstructError, Credentials | HttpClient.HttpClient>;
export type GetReplicationConfigurationError = ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Lists all ReplicationConfigurations, filtered by Source Server ID.
 */
export declare const getReplicationConfiguration: API.OperationMethod<GetReplicationConfigurationRequest & RegionInput, ReplicationConfiguration, GetReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type InitializeServiceError = AccessDeniedException | ValidationException | CommonErrors;
/**
 * Initialize Application Migration Service.
 */
export declare const initializeService: API.OperationMethod<InitializeServiceRequest & RegionInput, InitializeServiceResponse, InitializeServiceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = UninitializedAccountException | CommonErrors;
/**
 * Retrieves all applications or multiple applications by ID.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, Application>;
export type ListConnectorsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * List Connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, Connector>;
export type ListExportErrorsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * List export errors.
 */
export declare const listExportErrors: API.PaginatedOperationMethod<ListExportErrorsRequest & RegionInput, ListExportErrorsResponse, ListExportErrorsError, Credentials | HttpClient.HttpClient, ExportTaskError>;
export type ListExportsError = UninitializedAccountException | CommonErrors;
/**
 * List exports.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsRequest & RegionInput, ListExportsResponse, ListExportsError, Credentials | HttpClient.HttpClient, ExportTask>;
export type ListImportErrorsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * List import errors.
 */
export declare const listImportErrors: API.PaginatedOperationMethod<ListImportErrorsRequest & RegionInput, ListImportErrorsResponse, ListImportErrorsError, Credentials | HttpClient.HttpClient, ImportTaskError>;
export type ListImportFileEnrichmentsError = ValidationException | CommonErrors;
/**
 * Lists import file enrichment jobs with optional filtering by job IDs.
 */
export declare const listImportFileEnrichments: API.PaginatedOperationMethod<ListImportFileEnrichmentsRequest & RegionInput, ListImportFileEnrichmentsResponse, ListImportFileEnrichmentsError, Credentials | HttpClient.HttpClient, ImportFileEnrichment>;
export type ListImportsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * List imports.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsRequest & RegionInput, ListImportsResponse, ListImportsError, Credentials | HttpClient.HttpClient, ImportTask>;
export type ListManagedAccountsError = UninitializedAccountException | ValidationException | CommonErrors;
/**
 * List Managed Accounts.
 */
export declare const listManagedAccounts: API.PaginatedOperationMethod<ListManagedAccountsRequest & RegionInput, ListManagedAccountsResponse, ListManagedAccountsError, Credentials | HttpClient.HttpClient, ManagedAccount>;
export type ListNetworkMigrationAnalysesError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network migration analysis jobs for a specified execution. Returns information about analysis job status and results.
 */
export declare const listNetworkMigrationAnalyses: API.PaginatedOperationMethod<ListNetworkMigrationAnalysesRequest & RegionInput, ListNetworkMigrationAnalysesResponse, ListNetworkMigrationAnalysesError, Credentials | HttpClient.HttpClient, NetworkMigrationAnalysisJobDetails>;
export type ListNetworkMigrationAnalysisResultsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the results of network migration analyses, showing connectivity and compatibility findings for migrated resources.
 */
export declare const listNetworkMigrationAnalysisResults: API.PaginatedOperationMethod<ListNetworkMigrationAnalysisResultsRequest & RegionInput, ListNetworkMigrationAnalysisResultsResponse, ListNetworkMigrationAnalysisResultsError, Credentials | HttpClient.HttpClient, NetworkMigrationAnalysisResult>;
export type ListNetworkMigrationCodeGenerationsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network migration code generation jobs, which convert network mappings into infrastructure-as-code templates.
 */
export declare const listNetworkMigrationCodeGenerations: API.PaginatedOperationMethod<ListNetworkMigrationCodeGenerationsRequest & RegionInput, ListNetworkMigrationCodeGenerationsResponse, ListNetworkMigrationCodeGenerationsError, Credentials | HttpClient.HttpClient, NetworkMigrationCodeGenerationJobDetails>;
export type ListNetworkMigrationCodeGenerationSegmentsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists code generation segments, which represent individual infrastructure components generated as code templates.
 */
export declare const listNetworkMigrationCodeGenerationSegments: API.PaginatedOperationMethod<ListNetworkMigrationCodeGenerationSegmentsRequest & RegionInput, ListNetworkMigrationCodeGenerationSegmentsResponse, ListNetworkMigrationCodeGenerationSegmentsError, Credentials | HttpClient.HttpClient, NetworkMigrationCodeGenerationSegment>;
export type ListNetworkMigrationDefinitionsError = AccessDeniedException | CommonErrors;
/**
 * Lists all network migration definitions in the account, with optional filtering.
 */
export declare const listNetworkMigrationDefinitions: API.PaginatedOperationMethod<ListNetworkMigrationDefinitionsRequest & RegionInput, ListNetworkMigrationDefinitionsResponse, ListNetworkMigrationDefinitionsError, Credentials | HttpClient.HttpClient, NetworkMigrationDefinitionSummary>;
export type ListNetworkMigrationDeployedStacksError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists CloudFormation stacks that have been deployed as part of the network migration.
 */
export declare const listNetworkMigrationDeployedStacks: API.PaginatedOperationMethod<ListNetworkMigrationDeployedStacksRequest & RegionInput, ListNetworkMigrationDeployedStacksResponse, ListNetworkMigrationDeployedStacksError, Credentials | HttpClient.HttpClient, NetworkMigrationDeployedStackDetails>;
export type ListNetworkMigrationDeploymentsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network migration deployment jobs and their current status.
 */
export declare const listNetworkMigrationDeployments: API.PaginatedOperationMethod<ListNetworkMigrationDeploymentsRequest & RegionInput, ListNetworkMigrationDeployerJobResponse, ListNetworkMigrationDeploymentsError, Credentials | HttpClient.HttpClient, NetworkMigrationDeployerJobDetails>;
export type ListNetworkMigrationExecutionsError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists network migration execution instances for a given definition, showing the status and progress of each execution.
 */
export declare const listNetworkMigrationExecutions: API.PaginatedOperationMethod<ListNetworkMigrationExecutionsRequest & RegionInput, ListNetworkMigrationExecutionsResponse, ListNetworkMigrationExecutionsError, Credentials | HttpClient.HttpClient, NetworkMigrationExecution>;
export type ListNetworkMigrationMapperSegmentConstructsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists constructs within a mapper segment, representing individual infrastructure components like VPCs, subnets, or security groups.
 */
export declare const listNetworkMigrationMapperSegmentConstructs: API.PaginatedOperationMethod<ListNetworkMigrationMapperSegmentConstructsRequest & RegionInput, ListNetworkMigrationMapperSegmentConstructsResponse, ListNetworkMigrationMapperSegmentConstructsError, Credentials | HttpClient.HttpClient, NetworkMigrationMapperSegmentConstruct>;
export type ListNetworkMigrationMapperSegmentsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists mapper segments, which represent logical groupings of network resources to be migrated together.
 */
export declare const listNetworkMigrationMapperSegments: API.PaginatedOperationMethod<ListNetworkMigrationMapperSegmentsRequest & RegionInput, ListNetworkMigrationMapperSegmentsResponse, ListNetworkMigrationMapperSegmentsError, Credentials | HttpClient.HttpClient, NetworkMigrationMapperSegment>;
export type ListNetworkMigrationMappingsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists network migration mapping jobs, which analyze and create relationships between source and target network resources.
 */
export declare const listNetworkMigrationMappings: API.PaginatedOperationMethod<ListNetworkMigrationMappingsRequest & RegionInput, ListNetworkMigrationMappingsResponse, ListNetworkMigrationMappingsError, Credentials | HttpClient.HttpClient, NetworkMigrationMappingJobDetails>;
export type ListNetworkMigrationMappingUpdatesError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists mapping update jobs, which apply customer modifications to the generated network mappings.
 */
export declare const listNetworkMigrationMappingUpdates: API.PaginatedOperationMethod<ListNetworkMigrationMappingUpdatesRequest & RegionInput, ListNetworkMigrationMappingUpdatesResponse, ListNetworkMigrationMappingUpdatesError, Credentials | HttpClient.HttpClient, NetworkMigrationMappingUpdateJobDetails>;
export type ListSourceServerActionsError = ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * List source server post migration custom actions.
 */
export declare const listSourceServerActions: API.PaginatedOperationMethod<ListSourceServerActionsRequest & RegionInput, ListSourceServerActionsResponse, ListSourceServerActionsError, Credentials | HttpClient.HttpClient, SourceServerActionDocument>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all tags for your Application Migration Service resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplateActionsError = ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * List template post migration custom actions.
 */
export declare const listTemplateActions: API.PaginatedOperationMethod<ListTemplateActionsRequest & RegionInput, ListTemplateActionsResponse, ListTemplateActionsError, Credentials | HttpClient.HttpClient, TemplateActionDocument>;
export type ListWavesError = UninitializedAccountException | CommonErrors;
/**
 * Retrieves all waves or multiple waves by ID.
 */
export declare const listWaves: API.PaginatedOperationMethod<ListWavesRequest & RegionInput, ListWavesResponse, ListWavesError, Credentials | HttpClient.HttpClient, Wave>;
export type MarkAsArchivedError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Archives specific Source Servers by setting the SourceServer.isArchived property to true for specified SourceServers by ID. This command only works for SourceServers with a lifecycle state that equals DISCONNECTED or CUTOVER.
 */
export declare const markAsArchived: API.OperationMethod<MarkAsArchivedRequest & RegionInput, SourceServer, MarkAsArchivedError, Credentials | HttpClient.HttpClient>;
export type PauseReplicationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Pause Replication.
 */
export declare const pauseReplication: API.OperationMethod<PauseReplicationRequest & RegionInput, SourceServer, PauseReplicationError, Credentials | HttpClient.HttpClient>;
export type PutSourceServerActionError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Put source server post migration custom action.
 */
export declare const putSourceServerAction: API.OperationMethod<PutSourceServerActionRequest & RegionInput, SourceServerActionDocument, PutSourceServerActionError, Credentials | HttpClient.HttpClient>;
export type PutTemplateActionError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Put template post migration custom action.
 */
export declare const putTemplateAction: API.OperationMethod<PutTemplateActionRequest & RegionInput, TemplateActionDocument, PutTemplateActionError, Credentials | HttpClient.HttpClient>;
export type RemoveSourceServerActionError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Remove source server post migration custom action.
 */
export declare const removeSourceServerAction: API.OperationMethod<RemoveSourceServerActionRequest & RegionInput, RemoveSourceServerActionResponse, RemoveSourceServerActionError, Credentials | HttpClient.HttpClient>;
export type RemoveTemplateActionError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Remove template post migration custom action.
 */
export declare const removeTemplateAction: API.OperationMethod<RemoveTemplateActionRequest & RegionInput, RemoveTemplateActionResponse, RemoveTemplateActionError, Credentials | HttpClient.HttpClient>;
export type ResumeReplicationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Resume Replication.
 */
export declare const resumeReplication: API.OperationMethod<ResumeReplicationRequest & RegionInput, SourceServer, ResumeReplicationError, Credentials | HttpClient.HttpClient>;
export type RetryDataReplicationError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Causes the data replication initiation sequence to begin immediately upon next Handshake for specified SourceServer IDs, regardless of when the previous initiation started. This command will not work if the SourceServer is not stalled or is in a DISCONNECTED or STOPPED state.
 */
export declare const retryDataReplication: API.OperationMethod<RetryDataReplicationRequest & RegionInput, SourceServer, RetryDataReplicationError, Credentials | HttpClient.HttpClient>;
export type StartCutoverError = ConflictException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Launches a Cutover Instance for specific Source Servers. This command starts a LAUNCH job whose initiatedBy property is StartCutover and changes the SourceServer.lifeCycle.state property to CUTTING_OVER.
 */
export declare const startCutover: API.OperationMethod<StartCutoverRequest & RegionInput, StartCutoverResponse, StartCutoverError, Credentials | HttpClient.HttpClient>;
export type StartExportError = ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Start export.
 */
export declare const startExport: API.OperationMethod<StartExportRequest & RegionInput, StartExportResponse, StartExportError, Credentials | HttpClient.HttpClient>;
export type StartImportError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Start import.
 */
export declare const startImport: API.OperationMethod<StartImportRequest & RegionInput, StartImportResponse, StartImportError, Credentials | HttpClient.HttpClient>;
export type StartImportFileEnrichmentError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an import file enrichment job to process and enrich network migration import files with additional metadata and IP assignment strategies.
 */
export declare const startImportFileEnrichment: API.OperationMethod<StartImportFileEnrichmentRequest & RegionInput, StartImportFileEnrichmentResponse, StartImportFileEnrichmentError, Credentials | HttpClient.HttpClient>;
export type StartNetworkMigrationAnalysisError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a network migration analysis job to evaluate connectivity and compatibility of the migration mappings.
 */
export declare const startNetworkMigrationAnalysis: API.OperationMethod<StartNetworkMigrationAnalysisRequest & RegionInput, StartNetworkMigrationAnalysisResponse, StartNetworkMigrationAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartNetworkMigrationCodeGenerationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a code generation job to convert network migration mappings into infrastructure-as-code templates.
 */
export declare const startNetworkMigrationCodeGeneration: API.OperationMethod<StartNetworkMigrationCodeGenerationRequest & RegionInput, StartNetworkMigrationCodeGenerationResponse, StartNetworkMigrationCodeGenerationError, Credentials | HttpClient.HttpClient>;
export type StartNetworkMigrationDeploymentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a deployment job to create the target network infrastructure based on the generated code templates.
 */
export declare const startNetworkMigrationDeployment: API.OperationMethod<StartNetworkMigrationDeploymentRequest & RegionInput, StartNetworkMigrationDeployerJobResponse, StartNetworkMigrationDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartNetworkMigrationMappingError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the network migration mapping process for a given network migration execution.
 */
export declare const startNetworkMigrationMapping: API.OperationMethod<StartNetworkMigrationMappingRequest & RegionInput, StartNetworkMigrationMappingResponse, StartNetworkMigrationMappingError, Credentials | HttpClient.HttpClient>;
export type StartNetworkMigrationMappingUpdateError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a job to apply customer modifications to network migration mappings, such as changing properties.
 */
export declare const startNetworkMigrationMappingUpdate: API.OperationMethod<StartNetworkMigrationMappingUpdateRequest & RegionInput, StartNetworkMigrationMappingUpdateResponse, StartNetworkMigrationMappingUpdateError, Credentials | HttpClient.HttpClient>;
export type StartReplicationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Start replication for source server irrespective of its replication type.
 */
export declare const startReplication: API.OperationMethod<StartReplicationRequest & RegionInput, SourceServer, StartReplicationError, Credentials | HttpClient.HttpClient>;
export type StartTestError = ConflictException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Launches a Test Instance for specific Source Servers. This command starts a LAUNCH job whose initiatedBy property is StartTest and changes the SourceServer.lifeCycle.state property to TESTING.
 */
export declare const startTest: API.OperationMethod<StartTestRequest & RegionInput, StartTestResponse, StartTestError, Credentials | HttpClient.HttpClient>;
export type StopReplicationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Stop Replication.
 */
export declare const stopReplication: API.OperationMethod<StopReplicationRequest & RegionInput, SourceServer, StopReplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or overwrites only the specified tags for the specified Application Migration Service resource or resources. When you specify an existing tag key, the value is overwritten with the new value. Each resource can have a maximum of 50 tags. Each tag consists of a key and optional value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateTargetInstancesError = ConflictException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Starts a job that terminates specific launched EC2 Test and Cutover instances. This command will not work for any Source Server with a lifecycle.state of TESTING, CUTTING_OVER, or CUTOVER.
 */
export declare const terminateTargetInstances: API.OperationMethod<TerminateTargetInstancesRequest & RegionInput, TerminateTargetInstancesResponse, TerminateTargetInstancesError, Credentials | HttpClient.HttpClient>;
export type UnarchiveApplicationError = ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Unarchive application.
 */
export declare const unarchiveApplication: API.OperationMethod<UnarchiveApplicationRequest & RegionInput, Application, UnarchiveApplicationError, Credentials | HttpClient.HttpClient>;
export type UnarchiveWaveError = ResourceNotFoundException | ServiceQuotaExceededException | UninitializedAccountException | CommonErrors;
/**
 * Unarchive wave.
 */
export declare const unarchiveWave: API.OperationMethod<UnarchiveWaveRequest & RegionInput, Wave, UnarchiveWaveError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified set of tags from the specified set of Application Migration Service resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Update application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, Application, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Update Connector.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest & RegionInput, Connector, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates multiple LaunchConfigurations by Source Server ID.
 *
 * bootMode valid values are `LEGACY_BIOS | UEFI | USE_SOURCE`
 */
export declare const updateLaunchConfiguration: API.OperationMethod<UpdateLaunchConfigurationRequest & RegionInput, LaunchConfiguration, UpdateLaunchConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLaunchConfigurationTemplateError = AccessDeniedException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates an existing Launch Configuration Template by ID.
 */
export declare const updateLaunchConfigurationTemplate: API.OperationMethod<UpdateLaunchConfigurationTemplateRequest & RegionInput, LaunchConfigurationTemplate, UpdateLaunchConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkMigrationDefinitionError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing network migration definition with new source or target configurations.
 */
export declare const updateNetworkMigrationDefinition: API.OperationMethod<UpdateNetworkMigrationDefinitionRequest & RegionInput, NetworkMigrationDefinition, UpdateNetworkMigrationDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkMigrationMapperSegmentError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a mapper segment's configuration, such as changing its scope tags.
 */
export declare const updateNetworkMigrationMapperSegment: API.OperationMethod<UpdateNetworkMigrationMapperSegmentRequest & RegionInput, NetworkMigrationMapperSegment, UpdateNetworkMigrationMapperSegmentError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationError = AccessDeniedException | ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Allows you to update multiple ReplicationConfigurations by Source Server ID.
 */
export declare const updateReplicationConfiguration: API.OperationMethod<UpdateReplicationConfigurationRequest & RegionInput, ReplicationConfiguration, UpdateReplicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationConfigurationTemplateError = AccessDeniedException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Updates a ReplicationConfigurationTemplate by ID.
 */
export declare const updateReplicationConfigurationTemplate: API.OperationMethod<UpdateReplicationConfigurationTemplateRequest & RegionInput, ReplicationConfigurationTemplate, UpdateReplicationConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceServerError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Update Source Server.
 */
export declare const updateSourceServer: API.OperationMethod<UpdateSourceServerRequest & RegionInput, SourceServer, UpdateSourceServerError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceServerReplicationTypeError = ConflictException | ResourceNotFoundException | UninitializedAccountException | ValidationException | CommonErrors;
/**
 * Allows you to change between the AGENT_BASED replication type and the SNAPSHOT_SHIPPING replication type.
 *
 * SNAPSHOT_SHIPPING should be used for agentless replication.
 */
export declare const updateSourceServerReplicationType: API.OperationMethod<UpdateSourceServerReplicationTypeRequest & RegionInput, SourceServer, UpdateSourceServerReplicationTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateWaveError = ConflictException | ResourceNotFoundException | UninitializedAccountException | CommonErrors;
/**
 * Update wave.
 */
export declare const updateWave: API.OperationMethod<UpdateWaveRequest & RegionInput, Wave, UpdateWaveError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mgn.d.ts.map