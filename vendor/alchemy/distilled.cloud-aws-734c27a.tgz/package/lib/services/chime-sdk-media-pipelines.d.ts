import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.TaggedErrorClass<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
export type MediaPipelineSourceType = "ChimeSdkMeeting" | (string & {});
export type Arn = string | redacted.Redacted<string>;
export type MediaPipelineSinkType = "S3Bucket" | (string & {});
export type ClientRequestToken = string | redacted.Redacted<string>;
export type GuidString = string;
export type AttendeeIdList = string[];
export type ExternalUserIdType = string | redacted.Redacted<string>;
export type ExternalUserIdList = (string | redacted.Redacted<string>)[];
export interface SelectedVideoStreams {
    AttendeeIds?: string[] | undefined;
    ExternalUserIds?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface SourceConfiguration {
    SelectedVideoStreams?: SelectedVideoStreams | undefined;
}
export type AudioMuxType = "AudioOnly" | "AudioWithActiveSpeakerVideo" | "AudioWithCompositedVideo" | (string & {});
export interface AudioArtifactsConfiguration {
    MuxType: AudioMuxType;
}
export type ArtifactsState = "Enabled" | "Disabled" | (string & {});
export type VideoMuxType = "VideoOnly" | (string & {});
export interface VideoArtifactsConfiguration {
    State: ArtifactsState;
    MuxType?: VideoMuxType | undefined;
}
export type ContentMuxType = "ContentOnly" | (string & {});
export interface ContentArtifactsConfiguration {
    State: ArtifactsState;
    MuxType?: ContentMuxType | undefined;
}
export type LayoutOption = "GridView" | (string & {});
export type ResolutionOption = "HD" | "FHD" | (string & {});
export type ContentShareLayoutOption = "PresenterOnly" | "Horizontal" | "Vertical" | "ActiveSpeakerOnly" | (string & {});
export type PresenterPosition = "TopLeft" | "TopRight" | "BottomLeft" | "BottomRight" | (string & {});
export interface PresenterOnlyConfiguration {
    PresenterPosition?: PresenterPosition | undefined;
}
export type ActiveSpeakerPosition = "TopLeft" | "TopRight" | "BottomLeft" | "BottomRight" | (string & {});
export interface ActiveSpeakerOnlyConfiguration {
    ActiveSpeakerPosition?: ActiveSpeakerPosition | undefined;
}
export type TileOrder = "JoinSequence" | "SpeakerSequence" | (string & {});
export type HorizontalTilePosition = "Top" | "Bottom" | (string & {});
export type TileCount = number;
export type TileAspectRatio = string;
export interface HorizontalLayoutConfiguration {
    TileOrder?: TileOrder | undefined;
    TilePosition?: HorizontalTilePosition | undefined;
    TileCount?: number | undefined;
    TileAspectRatio?: string | undefined;
}
export type VerticalTilePosition = "Left" | "Right" | (string & {});
export interface VerticalLayoutConfiguration {
    TileOrder?: TileOrder | undefined;
    TilePosition?: VerticalTilePosition | undefined;
    TileCount?: number | undefined;
    TileAspectRatio?: string | undefined;
}
export type CornerRadius = number;
export type BorderColor = "Black" | "Blue" | "Red" | "Green" | "White" | "Yellow" | (string & {});
export type HighlightColor = "Black" | "Blue" | "Red" | "Green" | "White" | "Yellow" | (string & {});
export type BorderThickness = number;
export interface VideoAttribute {
    CornerRadius?: number | undefined;
    BorderColor?: BorderColor | undefined;
    HighlightColor?: HighlightColor | undefined;
    BorderThickness?: number | undefined;
}
export type CanvasOrientation = "Landscape" | "Portrait" | (string & {});
export interface GridViewConfiguration {
    ContentShareLayout: ContentShareLayoutOption;
    PresenterOnlyConfiguration?: PresenterOnlyConfiguration | undefined;
    ActiveSpeakerOnlyConfiguration?: ActiveSpeakerOnlyConfiguration | undefined;
    HorizontalLayoutConfiguration?: HorizontalLayoutConfiguration | undefined;
    VerticalLayoutConfiguration?: VerticalLayoutConfiguration | undefined;
    VideoAttribute?: VideoAttribute | undefined;
    CanvasOrientation?: CanvasOrientation | undefined;
}
export interface CompositedVideoArtifactsConfiguration {
    Layout?: LayoutOption | undefined;
    Resolution?: ResolutionOption | undefined;
    GridViewConfiguration: GridViewConfiguration;
}
export interface ArtifactsConfiguration {
    Audio: AudioArtifactsConfiguration;
    Video: VideoArtifactsConfiguration;
    Content: ContentArtifactsConfiguration;
    CompositedVideo?: CompositedVideoArtifactsConfiguration | undefined;
}
export interface ChimeSdkMeetingConfiguration {
    SourceConfiguration?: SourceConfiguration | undefined;
    ArtifactsConfiguration?: ArtifactsConfiguration | undefined;
}
export interface SseAwsKeyManagementParams {
    AwsKmsKeyId: string;
    AwsKmsEncryptionContext?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateMediaCapturePipelineRequest {
    SourceType: MediaPipelineSourceType;
    SourceArn: string | redacted.Redacted<string>;
    SinkType: MediaPipelineSinkType;
    SinkArn: string | redacted.Redacted<string>;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
    ChimeSdkMeetingConfiguration?: ChimeSdkMeetingConfiguration | undefined;
    SseAwsKeyManagementParams?: SseAwsKeyManagementParams | undefined;
    SinkIamRoleArn?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export type AmazonResourceName = string;
export type MediaPipelineStatus = "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | "Paused" | "NotStarted" | (string & {});
export type Iso8601Timestamp = Date;
export interface MediaCapturePipeline {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
    SourceType?: MediaPipelineSourceType | undefined;
    SourceArn?: string | redacted.Redacted<string> | undefined;
    Status?: MediaPipelineStatus | undefined;
    SinkType?: MediaPipelineSinkType | undefined;
    SinkArn?: string | redacted.Redacted<string> | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    ChimeSdkMeetingConfiguration?: ChimeSdkMeetingConfiguration | undefined;
    SseAwsKeyManagementParams?: SseAwsKeyManagementParams | undefined;
    SinkIamRoleArn?: string | redacted.Redacted<string> | undefined;
}
export interface CreateMediaCapturePipelineResponse {
    MediaCapturePipeline?: MediaCapturePipeline | undefined;
}
export type ConcatenationSourceType = "MediaCapturePipeline" | (string & {});
export type AudioArtifactsConcatenationState = "Enabled" | (string & {});
export interface AudioConcatenationConfiguration {
    State: AudioArtifactsConcatenationState;
}
export type ArtifactsConcatenationState = "Enabled" | "Disabled" | (string & {});
export interface VideoConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface ContentConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface DataChannelConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface TranscriptionMessagesConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface MeetingEventsConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface CompositedVideoConcatenationConfiguration {
    State: ArtifactsConcatenationState;
}
export interface ArtifactsConcatenationConfiguration {
    Audio: AudioConcatenationConfiguration;
    Video: VideoConcatenationConfiguration;
    Content: ContentConcatenationConfiguration;
    DataChannel: DataChannelConcatenationConfiguration;
    TranscriptionMessages: TranscriptionMessagesConcatenationConfiguration;
    MeetingEvents: MeetingEventsConcatenationConfiguration;
    CompositedVideo: CompositedVideoConcatenationConfiguration;
}
export interface ChimeSdkMeetingConcatenationConfiguration {
    ArtifactsConfiguration: ArtifactsConcatenationConfiguration;
}
export interface MediaCapturePipelineSourceConfiguration {
    MediaPipelineArn: string | redacted.Redacted<string>;
    ChimeSdkMeetingConfiguration: ChimeSdkMeetingConcatenationConfiguration;
}
export interface ConcatenationSource {
    Type: ConcatenationSourceType;
    MediaCapturePipelineSourceConfiguration: MediaCapturePipelineSourceConfiguration;
}
export type ConcatenationSourceList = ConcatenationSource[];
export type ConcatenationSinkType = "S3Bucket" | (string & {});
export interface S3BucketSinkConfiguration {
    Destination: string | redacted.Redacted<string>;
}
export interface ConcatenationSink {
    Type: ConcatenationSinkType;
    S3BucketSinkConfiguration: S3BucketSinkConfiguration;
}
export type ConcatenationSinkList = ConcatenationSink[];
export interface CreateMediaConcatenationPipelineRequest {
    Sources: ConcatenationSource[];
    Sinks: ConcatenationSink[];
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export interface MediaConcatenationPipeline {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
    Sources?: ConcatenationSource[] | undefined;
    Sinks?: ConcatenationSink[] | undefined;
    Status?: MediaPipelineStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateMediaConcatenationPipelineResponse {
    MediaConcatenationPipeline?: MediaConcatenationPipeline | undefined;
}
export type KinesisVideoStreamArn = string;
export type FragmentNumberString = string;
export type NumberOfChannels = number;
export type ChannelId = number;
export type ParticipantRole = "AGENT" | "CUSTOMER" | (string & {});
export interface ChannelDefinition {
    ChannelId: number;
    ParticipantRole?: ParticipantRole | undefined;
}
export type ChannelDefinitions = ChannelDefinition[];
export interface StreamChannelDefinition {
    NumberOfChannels: number;
    ChannelDefinitions?: ChannelDefinition[] | undefined;
}
export interface StreamConfiguration {
    StreamArn: string;
    FragmentNumber?: string | undefined;
    StreamChannelDefinition: StreamChannelDefinition;
}
export type Streams = StreamConfiguration[];
export type MediaEncoding = "pcm" | (string & {});
export type MediaSampleRateHertz = number;
export interface KinesisVideoStreamSourceRuntimeConfiguration {
    Streams: StreamConfiguration[];
    MediaEncoding: MediaEncoding;
    MediaSampleRate: number;
}
export type NonEmptyString = string;
export type MediaInsightsRuntimeMetadata = {
    [key: string]: string | undefined;
};
export interface RecordingStreamConfiguration {
    StreamArn?: string | undefined;
}
export type RecordingStreamList = RecordingStreamConfiguration[];
export type FragmentSelectorType = "ProducerTimestamp" | "ServerTimestamp" | (string & {});
export interface TimestampRange {
    StartTimestamp: Date;
    EndTimestamp: Date;
}
export interface FragmentSelector {
    FragmentSelectorType: FragmentSelectorType;
    TimestampRange: TimestampRange;
}
export interface KinesisVideoStreamRecordingSourceRuntimeConfiguration {
    Streams: RecordingStreamConfiguration[];
    FragmentSelector: FragmentSelector;
}
export type RecordingFileFormat = "Wav" | "Opus" | (string & {});
export interface S3RecordingSinkRuntimeConfiguration {
    Destination: string | redacted.Redacted<string>;
    RecordingFileFormat: RecordingFileFormat;
}
export interface CreateMediaInsightsPipelineRequest {
    MediaInsightsPipelineConfigurationArn: string | redacted.Redacted<string>;
    KinesisVideoStreamSourceRuntimeConfiguration?: KinesisVideoStreamSourceRuntimeConfiguration | undefined;
    MediaInsightsRuntimeMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    KinesisVideoStreamRecordingSourceRuntimeConfiguration?: KinesisVideoStreamRecordingSourceRuntimeConfiguration | undefined;
    S3RecordingSinkRuntimeConfiguration?: S3RecordingSinkRuntimeConfiguration | undefined;
    Tags?: Tag[] | undefined;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
}
export type MediaInsightsPipelineConfigurationElementType = "AmazonTranscribeCallAnalyticsProcessor" | "VoiceAnalyticsProcessor" | "AmazonTranscribeProcessor" | "KinesisDataStreamSink" | "LambdaFunctionSink" | "SqsQueueSink" | "SnsTopicSink" | "S3RecordingSink" | "VoiceEnhancementSink" | (string & {});
export type MediaPipelineElementStatus = "NotStarted" | "NotSupported" | "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | "Paused" | (string & {});
export interface MediaInsightsPipelineElementStatus {
    Type?: MediaInsightsPipelineConfigurationElementType | undefined;
    Status?: MediaPipelineElementStatus | undefined;
}
export type MediaInsightsPipelineElementStatuses = MediaInsightsPipelineElementStatus[];
export interface MediaInsightsPipeline {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | redacted.Redacted<string> | undefined;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string> | undefined;
    Status?: MediaPipelineStatus | undefined;
    KinesisVideoStreamSourceRuntimeConfiguration?: KinesisVideoStreamSourceRuntimeConfiguration | undefined;
    MediaInsightsRuntimeMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    KinesisVideoStreamRecordingSourceRuntimeConfiguration?: KinesisVideoStreamRecordingSourceRuntimeConfiguration | undefined;
    S3RecordingSinkRuntimeConfiguration?: S3RecordingSinkRuntimeConfiguration | undefined;
    CreatedTimestamp?: Date | undefined;
    ElementStatuses?: MediaInsightsPipelineElementStatus[] | undefined;
}
export interface CreateMediaInsightsPipelineResponse {
    MediaInsightsPipeline: MediaInsightsPipeline;
}
export type MediaInsightsPipelineConfigurationNameString = string;
export type RealTimeAlertRuleType = "KeywordMatch" | "Sentiment" | "IssueDetection" | (string & {});
export type RuleName = string;
export type Keyword = string;
export type KeywordMatchWordList = string[];
export interface KeywordMatchConfiguration {
    RuleName: string;
    Keywords: string[];
    Negate?: boolean | undefined;
}
export type SentimentType = "NEGATIVE" | (string & {});
export type SentimentTimePeriodInSeconds = number;
export interface SentimentConfiguration {
    RuleName: string;
    SentimentType: SentimentType;
    TimePeriod: number;
}
export interface IssueDetectionConfiguration {
    RuleName: string;
}
export interface RealTimeAlertRule {
    Type: RealTimeAlertRuleType;
    KeywordMatchConfiguration?: KeywordMatchConfiguration | undefined;
    SentimentConfiguration?: SentimentConfiguration | undefined;
    IssueDetectionConfiguration?: IssueDetectionConfiguration | undefined;
}
export type RealTimeAlertRuleList = RealTimeAlertRule[];
export interface RealTimeAlertConfiguration {
    Disabled?: boolean | undefined;
    Rules?: RealTimeAlertRule[] | undefined;
}
export type CallAnalyticsLanguageCode = "en-US" | "en-GB" | "es-US" | "fr-CA" | "fr-FR" | "en-AU" | "it-IT" | "de-DE" | "pt-BR" | (string & {});
export type VocabularyName = string;
export type VocabularyFilterName = string;
export type VocabularyFilterMethod = "remove" | "mask" | "tag" | (string & {});
export type ModelName = string;
export type PartialResultsStability = "high" | "medium" | "low" | (string & {});
export type ContentType = "PII" | (string & {});
export type PiiEntityTypes = string;
export type ContentRedactionOutput = "redacted" | "redacted_and_unredacted" | (string & {});
export interface PostCallAnalyticsSettings {
    OutputLocation: string;
    DataAccessRoleArn: string;
    ContentRedactionOutput?: ContentRedactionOutput | undefined;
    OutputEncryptionKMSKeyId?: string | undefined;
}
export type CategoryName = string;
export type CategoryNameList = string[];
export interface AmazonTranscribeCallAnalyticsProcessorConfiguration {
    LanguageCode: CallAnalyticsLanguageCode;
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    LanguageModelName?: string | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentType | undefined;
    ContentRedactionType?: ContentType | undefined;
    PiiEntityTypes?: string | undefined;
    FilterPartialResults?: boolean | undefined;
    PostCallAnalyticsSettings?: PostCallAnalyticsSettings | undefined;
    CallAnalyticsStreamCategories?: string[] | undefined;
}
export type LanguageOptions = string;
export type VocabularyNames = string;
export type VocabularyFilterNames = string;
export interface AmazonTranscribeProcessorConfiguration {
    LanguageCode?: CallAnalyticsLanguageCode | undefined;
    VocabularyName?: string | undefined;
    VocabularyFilterName?: string | undefined;
    VocabularyFilterMethod?: VocabularyFilterMethod | undefined;
    ShowSpeakerLabel?: boolean | undefined;
    EnablePartialResultsStabilization?: boolean | undefined;
    PartialResultsStability?: PartialResultsStability | undefined;
    ContentIdentificationType?: ContentType | undefined;
    ContentRedactionType?: ContentType | undefined;
    PiiEntityTypes?: string | undefined;
    LanguageModelName?: string | undefined;
    FilterPartialResults?: boolean | undefined;
    IdentifyLanguage?: boolean | undefined;
    IdentifyMultipleLanguages?: boolean | undefined;
    LanguageOptions?: string | undefined;
    PreferredLanguage?: CallAnalyticsLanguageCode | undefined;
    VocabularyNames?: string | undefined;
    VocabularyFilterNames?: string | undefined;
}
export interface KinesisDataStreamSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string> | undefined;
}
export interface S3RecordingSinkConfiguration {
    Destination?: string | redacted.Redacted<string> | undefined;
    RecordingFileFormat?: RecordingFileFormat | undefined;
}
export type VoiceAnalyticsConfigurationStatus = "Enabled" | "Disabled" | (string & {});
export interface VoiceAnalyticsProcessorConfiguration {
    SpeakerSearchStatus?: VoiceAnalyticsConfigurationStatus | undefined;
    VoiceToneAnalysisStatus?: VoiceAnalyticsConfigurationStatus | undefined;
}
export interface LambdaFunctionSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string> | undefined;
}
export interface SqsQueueSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string> | undefined;
}
export interface SnsTopicSinkConfiguration {
    InsightsTarget?: string | redacted.Redacted<string> | undefined;
}
export interface VoiceEnhancementSinkConfiguration {
    Disabled?: boolean | undefined;
}
export interface MediaInsightsPipelineConfigurationElement {
    Type: MediaInsightsPipelineConfigurationElementType;
    AmazonTranscribeCallAnalyticsProcessorConfiguration?: AmazonTranscribeCallAnalyticsProcessorConfiguration | undefined;
    AmazonTranscribeProcessorConfiguration?: AmazonTranscribeProcessorConfiguration | undefined;
    KinesisDataStreamSinkConfiguration?: KinesisDataStreamSinkConfiguration | undefined;
    S3RecordingSinkConfiguration?: S3RecordingSinkConfiguration | undefined;
    VoiceAnalyticsProcessorConfiguration?: VoiceAnalyticsProcessorConfiguration | undefined;
    LambdaFunctionSinkConfiguration?: LambdaFunctionSinkConfiguration | undefined;
    SqsQueueSinkConfiguration?: SqsQueueSinkConfiguration | undefined;
    SnsTopicSinkConfiguration?: SnsTopicSinkConfiguration | undefined;
    VoiceEnhancementSinkConfiguration?: VoiceEnhancementSinkConfiguration | undefined;
}
export type MediaInsightsPipelineConfigurationElements = MediaInsightsPipelineConfigurationElement[];
export interface CreateMediaInsightsPipelineConfigurationRequest {
    MediaInsightsPipelineConfigurationName: string;
    ResourceAccessRoleArn: string | redacted.Redacted<string>;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration | undefined;
    Elements: MediaInsightsPipelineConfigurationElement[];
    Tags?: Tag[] | undefined;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
}
export interface MediaInsightsPipelineConfiguration {
    MediaInsightsPipelineConfigurationName?: string | undefined;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string> | undefined;
    ResourceAccessRoleArn?: string | redacted.Redacted<string> | undefined;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration | undefined;
    Elements?: MediaInsightsPipelineConfigurationElement[] | undefined;
    MediaInsightsPipelineConfigurationId?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration | undefined;
}
export type LiveConnectorSourceType = "ChimeSdkMeeting" | (string & {});
export type LiveConnectorMuxType = "AudioWithCompositedVideo" | "AudioWithActiveSpeakerVideo" | (string & {});
export interface ChimeSdkMeetingLiveConnectorConfiguration {
    Arn: string | redacted.Redacted<string>;
    MuxType: LiveConnectorMuxType;
    CompositedVideo?: CompositedVideoArtifactsConfiguration | undefined;
    SourceConfiguration?: SourceConfiguration | undefined;
}
export interface LiveConnectorSourceConfiguration {
    SourceType: LiveConnectorSourceType;
    ChimeSdkMeetingLiveConnectorConfiguration: ChimeSdkMeetingLiveConnectorConfiguration;
}
export type LiveConnectorSourceList = LiveConnectorSourceConfiguration[];
export type LiveConnectorSinkType = "RTMP" | (string & {});
export type SensitiveString = string | redacted.Redacted<string>;
export type AudioChannelsOption = "Stereo" | "Mono" | (string & {});
export type AudioSampleRateOption = string;
export interface LiveConnectorRTMPConfiguration {
    Url: string | redacted.Redacted<string>;
    AudioChannels?: AudioChannelsOption | undefined;
    AudioSampleRate?: string | undefined;
}
export interface LiveConnectorSinkConfiguration {
    SinkType: LiveConnectorSinkType;
    RTMPConfiguration: LiveConnectorRTMPConfiguration;
}
export type LiveConnectorSinkList = LiveConnectorSinkConfiguration[];
export interface CreateMediaLiveConnectorPipelineRequest {
    Sources: LiveConnectorSourceConfiguration[];
    Sinks: LiveConnectorSinkConfiguration[];
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export interface MediaLiveConnectorPipeline {
    Sources?: LiveConnectorSourceConfiguration[] | undefined;
    Sinks?: LiveConnectorSinkConfiguration[] | undefined;
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
    Status?: MediaPipelineStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateMediaLiveConnectorPipelineResponse {
    MediaLiveConnectorPipeline?: MediaLiveConnectorPipeline | undefined;
}
export type AwsRegion = string;
export type DataRetentionInHours = number;
export interface KinesisVideoStreamConfiguration {
    Region: string;
    DataRetentionInHours?: number | undefined;
}
export type KinesisVideoStreamPoolName = string;
export interface CreateMediaPipelineKinesisVideoStreamPoolRequest {
    StreamConfiguration: KinesisVideoStreamConfiguration;
    PoolName: string;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export type KinesisVideoStreamPoolId = string;
export type KinesisVideoStreamPoolStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type KinesisVideoStreamPoolSize = number;
export interface KinesisVideoStreamPoolConfiguration {
    PoolArn?: string | redacted.Redacted<string> | undefined;
    PoolName?: string | undefined;
    PoolId?: string | undefined;
    PoolStatus?: KinesisVideoStreamPoolStatus | undefined;
    PoolSize?: number | undefined;
    StreamConfiguration?: KinesisVideoStreamConfiguration | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration | undefined;
}
export interface MediaStreamSource {
    SourceType: MediaPipelineSourceType;
    SourceArn: string | redacted.Redacted<string>;
}
export type MediaStreamSourceList = MediaStreamSource[];
export type MediaStreamPipelineSinkType = "KinesisVideoStreamPool" | (string & {});
export type ReservedStreamCapacity = number;
export type MediaStreamType = "MixedAudio" | "IndividualAudio" | (string & {});
export interface MediaStreamSink {
    SinkArn: string | redacted.Redacted<string>;
    SinkType: MediaStreamPipelineSinkType;
    ReservedStreamCapacity: number;
    MediaStreamType: MediaStreamType;
}
export type MediaStreamSinkList = MediaStreamSink[];
export interface CreateMediaStreamPipelineRequest {
    Sources: MediaStreamSource[];
    Sinks: MediaStreamSink[];
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
}
export interface MediaStreamPipeline {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    Status?: MediaPipelineStatus | undefined;
    Sources?: MediaStreamSource[] | undefined;
    Sinks?: MediaStreamSink[] | undefined;
}
export interface CreateMediaStreamPipelineResponse {
    MediaStreamPipeline?: MediaStreamPipeline | undefined;
}
export interface DeleteMediaCapturePipelineRequest {
    MediaPipelineId: string;
}
export interface DeleteMediaCapturePipelineResponse {
}
export interface DeleteMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
}
export interface DeleteMediaInsightsPipelineConfigurationResponse {
}
export interface DeleteMediaPipelineRequest {
    MediaPipelineId: string;
}
export interface DeleteMediaPipelineResponse {
}
export interface DeleteMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
}
export interface DeleteMediaPipelineKinesisVideoStreamPoolResponse {
}
export interface GetMediaCapturePipelineRequest {
    MediaPipelineId: string;
}
export interface GetMediaCapturePipelineResponse {
    MediaCapturePipeline?: MediaCapturePipeline | undefined;
}
export interface GetMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
}
export interface GetMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration | undefined;
}
export interface GetMediaPipelineRequest {
    MediaPipelineId: string;
}
export interface MediaPipeline {
    MediaCapturePipeline?: MediaCapturePipeline | undefined;
    MediaLiveConnectorPipeline?: MediaLiveConnectorPipeline | undefined;
    MediaConcatenationPipeline?: MediaConcatenationPipeline | undefined;
    MediaInsightsPipeline?: MediaInsightsPipeline | undefined;
    MediaStreamPipeline?: MediaStreamPipeline | undefined;
}
export interface GetMediaPipelineResponse {
    MediaPipeline?: MediaPipeline | undefined;
}
export interface GetMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
}
export interface GetMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration | undefined;
}
export interface GetSpeakerSearchTaskRequest {
    Identifier: string;
    SpeakerSearchTaskId: string;
}
export type MediaPipelineTaskStatus = "NotStarted" | "Initializing" | "InProgress" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface SpeakerSearchTask {
    SpeakerSearchTaskId?: string | undefined;
    SpeakerSearchTaskStatus?: MediaPipelineTaskStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface GetSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask | undefined;
}
export interface GetVoiceToneAnalysisTaskRequest {
    Identifier: string;
    VoiceToneAnalysisTaskId: string;
}
export interface VoiceToneAnalysisTask {
    VoiceToneAnalysisTaskId?: string | undefined;
    VoiceToneAnalysisTaskStatus?: MediaPipelineTaskStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface GetVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask | undefined;
}
export type ResultMax = number;
export interface ListMediaCapturePipelinesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MediaCapturePipelineSummary {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
}
export type MediaCapturePipelineSummaryList = MediaCapturePipelineSummary[];
export interface ListMediaCapturePipelinesResponse {
    MediaCapturePipelines?: MediaCapturePipelineSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMediaInsightsPipelineConfigurationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MediaInsightsPipelineConfigurationSummary {
    MediaInsightsPipelineConfigurationName?: string | undefined;
    MediaInsightsPipelineConfigurationId?: string | undefined;
    MediaInsightsPipelineConfigurationArn?: string | redacted.Redacted<string> | undefined;
}
export type MediaInsightsPipelineConfigurationSummaryList = MediaInsightsPipelineConfigurationSummary[];
export interface ListMediaInsightsPipelineConfigurationsResponse {
    MediaInsightsPipelineConfigurations?: MediaInsightsPipelineConfigurationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMediaPipelineKinesisVideoStreamPoolsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface KinesisVideoStreamPoolSummary {
    PoolName?: string | undefined;
    PoolId?: string | undefined;
    PoolArn?: string | redacted.Redacted<string> | undefined;
}
export type KinesisVideoStreamPoolSummaryList = KinesisVideoStreamPoolSummary[];
export interface ListMediaPipelineKinesisVideoStreamPoolsResponse {
    KinesisVideoStreamPools?: KinesisVideoStreamPoolSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMediaPipelinesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MediaPipelineSummary {
    MediaPipelineId?: string | undefined;
    MediaPipelineArn?: string | undefined;
}
export type MediaPipelineList = MediaPipelineSummary[];
export interface ListMediaPipelinesResponse {
    MediaPipelines?: MediaPipelineSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface KinesisVideoStreamSourceTaskConfiguration {
    StreamArn: string;
    ChannelId: number;
    FragmentNumber?: string | undefined;
}
export interface StartSpeakerSearchTaskRequest {
    Identifier: string;
    VoiceProfileDomainArn: string | redacted.Redacted<string>;
    KinesisVideoStreamSourceTaskConfiguration?: KinesisVideoStreamSourceTaskConfiguration | undefined;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
}
export interface StartSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask | undefined;
}
export type VoiceAnalyticsLanguageCode = "en-US" | (string & {});
export interface StartVoiceToneAnalysisTaskRequest {
    Identifier: string;
    LanguageCode: VoiceAnalyticsLanguageCode;
    KinesisVideoStreamSourceTaskConfiguration?: KinesisVideoStreamSourceTaskConfiguration | undefined;
    ClientRequestToken?: string | redacted.Redacted<string> | undefined;
}
export interface StartVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask | undefined;
}
export interface StopSpeakerSearchTaskRequest {
    Identifier: string;
    SpeakerSearchTaskId: string;
}
export interface StopSpeakerSearchTaskResponse {
}
export interface StopVoiceToneAnalysisTaskRequest {
    Identifier: string;
    VoiceToneAnalysisTaskId: string;
}
export interface StopVoiceToneAnalysisTaskResponse {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateMediaInsightsPipelineConfigurationRequest {
    Identifier: string;
    ResourceAccessRoleArn: string | redacted.Redacted<string>;
    RealTimeAlertConfiguration?: RealTimeAlertConfiguration | undefined;
    Elements: MediaInsightsPipelineConfigurationElement[];
}
export interface UpdateMediaInsightsPipelineConfigurationResponse {
    MediaInsightsPipelineConfiguration?: MediaInsightsPipelineConfiguration | undefined;
}
export type MediaPipelineStatusUpdate = "Pause" | "Resume" | (string & {});
export interface UpdateMediaInsightsPipelineStatusRequest {
    Identifier: string;
    UpdateStatus: MediaPipelineStatusUpdate;
}
export interface UpdateMediaInsightsPipelineStatusResponse {
}
export type DataRetentionChangeInHours = number;
export interface KinesisVideoStreamConfigurationUpdate {
    DataRetentionInHours?: number | undefined;
}
export interface UpdateMediaPipelineKinesisVideoStreamPoolRequest {
    Identifier: string;
    StreamConfiguration?: KinesisVideoStreamConfigurationUpdate | undefined;
}
export interface UpdateMediaPipelineKinesisVideoStreamPoolResponse {
    KinesisVideoStreamPoolConfiguration?: KinesisVideoStreamPoolConfiguration | undefined;
}
export type ErrorCode = "BadRequest" | "Forbidden" | "NotFound" | "ResourceLimitExceeded" | "ServiceFailure" | "ServiceUnavailable" | "Throttling" | (string & {});
export type CreateMediaCapturePipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media pipeline.
 */
export declare const createMediaCapturePipeline: API.OperationMethod<CreateMediaCapturePipelineRequest & RegionInput, CreateMediaCapturePipelineResponse, CreateMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaConcatenationPipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media concatenation pipeline.
 */
export declare const createMediaConcatenationPipeline: API.OperationMethod<CreateMediaConcatenationPipelineRequest & RegionInput, CreateMediaConcatenationPipelineResponse, CreateMediaConcatenationPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaInsightsPipelineError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media insights pipeline.
 */
export declare const createMediaInsightsPipeline: API.OperationMethod<CreateMediaInsightsPipelineRequest & RegionInput, CreateMediaInsightsPipelineResponse, CreateMediaInsightsPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaInsightsPipelineConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * A structure that contains the static configurations for a media insights
 * pipeline.
 */
export declare const createMediaInsightsPipelineConfiguration: API.OperationMethod<CreateMediaInsightsPipelineConfigurationRequest & RegionInput, CreateMediaInsightsPipelineConfigurationResponse, CreateMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateMediaLiveConnectorPipelineError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a media live connector pipeline in an Amazon Chime SDK meeting.
 */
export declare const createMediaLiveConnectorPipeline: API.OperationMethod<CreateMediaLiveConnectorPipelineRequest & RegionInput, CreateMediaLiveConnectorPipelineResponse, CreateMediaLiveConnectorPipelineError, Credentials | HttpClient.HttpClient>;
export type CreateMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Kinesis Video Stream pool for use with media stream
 * pipelines.
 *
 * If a meeting uses an opt-in Region as its
 * MediaRegion,
 * the KVS stream must be in that same Region. For example, if a meeting uses the `af-south-1` Region, the KVS stream must also be in `af-south-1`. However, if the meeting uses a
 * Region that AWS turns on by default, the KVS stream can be in any available Region, including an opt-in Region. For example, if the meeting uses `ca-central-1`, the KVS stream can be in
 * `eu-west-2`, `us-east-1`, `af-south-1`, or any other Region that the Amazon Chime SDK supports.
 *
 * To learn which AWS Region a meeting uses, call the GetMeeting API and
 * use the MediaRegion
 * parameter from the response.
 *
 * For more information about opt-in Regions, refer to Available Regions in the
 * *Amazon Chime SDK Developer Guide*, and
 * Specify which AWS Regions your account can use,
 * in the *AWS Account Management Reference Guide*.
 */
export declare const createMediaPipelineKinesisVideoStreamPool: API.OperationMethod<CreateMediaPipelineKinesisVideoStreamPoolRequest & RegionInput, CreateMediaPipelineKinesisVideoStreamPoolResponse, CreateMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type CreateMediaStreamPipelineError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a streaming media pipeline.
 */
export declare const createMediaStreamPipeline: API.OperationMethod<CreateMediaStreamPipelineRequest & RegionInput, CreateMediaStreamPipelineResponse, CreateMediaStreamPipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaCapturePipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the media pipeline.
 */
export declare const deleteMediaCapturePipeline: API.OperationMethod<DeleteMediaCapturePipelineRequest & RegionInput, DeleteMediaCapturePipelineResponse, DeleteMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaInsightsPipelineConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified configuration settings.
 */
export declare const deleteMediaInsightsPipelineConfiguration: API.OperationMethod<DeleteMediaInsightsPipelineConfigurationRequest & RegionInput, DeleteMediaInsightsPipelineConfigurationResponse, DeleteMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaPipelineError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the media pipeline.
 */
export declare const deleteMediaPipeline: API.OperationMethod<DeleteMediaPipelineRequest & RegionInput, DeleteMediaPipelineResponse, DeleteMediaPipelineError, Credentials | HttpClient.HttpClient>;
export type DeleteMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Kinesis Video Stream pool.
 */
export declare const deleteMediaPipelineKinesisVideoStreamPool: API.OperationMethod<DeleteMediaPipelineKinesisVideoStreamPoolRequest & RegionInput, DeleteMediaPipelineKinesisVideoStreamPoolResponse, DeleteMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type GetMediaCapturePipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an existing media pipeline.
 */
export declare const getMediaCapturePipeline: API.OperationMethod<GetMediaCapturePipelineRequest & RegionInput, GetMediaCapturePipelineResponse, GetMediaCapturePipelineError, Credentials | HttpClient.HttpClient>;
export type GetMediaInsightsPipelineConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the configuration settings for a media insights pipeline.
 */
export declare const getMediaInsightsPipelineConfiguration: API.OperationMethod<GetMediaInsightsPipelineConfigurationRequest & RegionInput, GetMediaInsightsPipelineConfigurationResponse, GetMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetMediaPipelineError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an existing media pipeline.
 */
export declare const getMediaPipeline: API.OperationMethod<GetMediaPipelineRequest & RegionInput, GetMediaPipelineResponse, GetMediaPipelineError, Credentials | HttpClient.HttpClient>;
export type GetMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets an Kinesis video stream pool.
 */
export declare const getMediaPipelineKinesisVideoStreamPool: API.OperationMethod<GetMediaPipelineKinesisVideoStreamPoolRequest & RegionInput, GetMediaPipelineKinesisVideoStreamPoolResponse, GetMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export type GetSpeakerSearchTaskError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified speaker search task.
 */
export declare const getSpeakerSearchTask: API.OperationMethod<GetSpeakerSearchTaskRequest & RegionInput, GetSpeakerSearchTaskResponse, GetSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type GetVoiceToneAnalysisTaskError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a voice tone analysis task.
 */
export declare const getVoiceToneAnalysisTask: API.OperationMethod<GetVoiceToneAnalysisTaskRequest & RegionInput, GetVoiceToneAnalysisTaskResponse, GetVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type ListMediaCapturePipelinesError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of media pipelines.
 */
export declare const listMediaCapturePipelines: API.PaginatedOperationMethod<ListMediaCapturePipelinesRequest & RegionInput, ListMediaCapturePipelinesResponse, ListMediaCapturePipelinesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaInsightsPipelineConfigurationsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the available media insights pipeline configurations.
 */
export declare const listMediaInsightsPipelineConfigurations: API.PaginatedOperationMethod<ListMediaInsightsPipelineConfigurationsRequest & RegionInput, ListMediaInsightsPipelineConfigurationsResponse, ListMediaInsightsPipelineConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaPipelineKinesisVideoStreamPoolsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the video stream pools in the media pipeline.
 */
export declare const listMediaPipelineKinesisVideoStreamPools: API.PaginatedOperationMethod<ListMediaPipelineKinesisVideoStreamPoolsRequest & RegionInput, ListMediaPipelineKinesisVideoStreamPoolsResponse, ListMediaPipelineKinesisVideoStreamPoolsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMediaPipelinesError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of media pipelines.
 */
export declare const listMediaPipelines: API.PaginatedOperationMethod<ListMediaPipelinesRequest & RegionInput, ListMediaPipelinesResponse, ListMediaPipelinesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the tags available for a media pipeline.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSpeakerSearchTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Starts a speaker search task.
 *
 * Before starting any speaker search tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startSpeakerSearchTask: API.OperationMethod<StartSpeakerSearchTaskRequest & RegionInput, StartSpeakerSearchTaskResponse, StartSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StartVoiceToneAnalysisTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Starts a voice tone analysis task. For more information about voice tone analysis, see
 * Using Amazon Chime SDK voice analytics
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * Before starting any voice tone analysis tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startVoiceToneAnalysisTask: API.OperationMethod<StartVoiceToneAnalysisTaskRequest & RegionInput, StartVoiceToneAnalysisTaskResponse, StartVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type StopSpeakerSearchTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Stops a speaker search task.
 */
export declare const stopSpeakerSearchTask: API.OperationMethod<StopSpeakerSearchTaskRequest & RegionInput, StopSpeakerSearchTaskResponse, StopSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StopVoiceToneAnalysisTaskError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Stops a voice tone analysis task.
 */
export declare const stopVoiceToneAnalysisTask: API.OperationMethod<StopVoiceToneAnalysisTaskRequest & RegionInput, StopVoiceToneAnalysisTaskResponse, StopVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * The ARN of the media pipeline that you want to tag. Consists of the pipeline's endpoint region, resource ID, and pipeline ID.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes any tags from a media pipeline.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaInsightsPipelineConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the media insights pipeline's configuration settings.
 */
export declare const updateMediaInsightsPipelineConfiguration: API.OperationMethod<UpdateMediaInsightsPipelineConfigurationRequest & RegionInput, UpdateMediaInsightsPipelineConfigurationResponse, UpdateMediaInsightsPipelineConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaInsightsPipelineStatusError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the status of a media insights pipeline.
 */
export declare const updateMediaInsightsPipelineStatus: API.OperationMethod<UpdateMediaInsightsPipelineStatusRequest & RegionInput, UpdateMediaInsightsPipelineStatusResponse, UpdateMediaInsightsPipelineStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateMediaPipelineKinesisVideoStreamPoolError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates an Amazon Kinesis Video Stream pool in a media pipeline.
 */
export declare const updateMediaPipelineKinesisVideoStreamPool: API.OperationMethod<UpdateMediaPipelineKinesisVideoStreamPoolRequest & RegionInput, UpdateMediaPipelineKinesisVideoStreamPoolResponse, UpdateMediaPipelineKinesisVideoStreamPoolError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-media-pipelines.d.ts.map