import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** Array of user login names who will receive alerts. Rejected for user-scope as alerting is always disabled for them. */
export type CreateOrganizationBudgetRequestBudgetAlertingAlertRecipientsList = Array<string>;
export interface CreateOrganizationBudgetRequestBudgetAlerting {
    /** Whether alerts are enabled for this budget. Rejected for user-scope as alerting is always disabled for them. */
    will_alert?: boolean | undefined;
    /** Array of user login names who will receive alerts. Rejected for user-scope as alerting is always disabled for them. */
    alert_recipients?: CreateOrganizationBudgetRequestBudgetAlertingAlertRecipientsList | undefined;
}
/** The scope of the budget for this organization. - `organization`: Apply the budget to the organization. - `repository`: Apply the budget to a specific repository in the organization. - `multi_user_customer`: Apply a universal budget to all users in the organization. - `user`: Apply the budget to a single user in the organization. `user` and `multi_user_customer` scopes are only supported when `budget_product_sku` is `ai_credits` or `premium_requests`. */
export type CreateOrganizationBudgetRequestBudgetScope = "organization" | "repository" | "multi_user_customer" | "user";
export type CreateOrganizationBudgetRequestBudgetTypeCase0 = "BundlePricing";
export type CreateOrganizationBudgetRequestBudgetTypeCase1 = "ProductPricing";
export type CreateOrganizationBudgetRequestBudgetTypeCase2 = "SkuPricing";
/** The type of pricing model used by the budget. Determines how `budget_product_sku` is interpreted. - `BundlePricing`: Covers all AI credit SKUs. Set `budget_product_sku` to `ai_credits`. - `ProductPricing`: Covers all SKUs that belong to a product. Set `budget_product_sku` to a product such as `actions` or `packages`. - `SkuPricing`: Covers a single, specific SKU. Set `budget_product_sku` to a SKU such as `actions_linux`. */
export type CreateOrganizationBudgetRequestBudgetType = CreateOrganizationBudgetRequestBudgetTypeCase0 | CreateOrganizationBudgetRequestBudgetTypeCase1 | CreateOrganizationBudgetRequestBudgetTypeCase2;
export interface CreateOrganizationBudgetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The budget amount in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount?: number | undefined;
    /** Whether to prevent additional spending once the budget is exceeded. For `user` and `multi_user_customer` scopes, this must be `true`. */
    prevent_further_usage?: boolean | undefined;
    budget_alerting?: CreateOrganizationBudgetRequestBudgetAlerting | undefined;
    /** The scope of the budget for this organization. - `organization`: Apply the budget to the organization. - `repository`: Apply the budget to a specific repository in the organization. - `multi_user_customer`: Apply a universal budget to all users in the organization. - `user`: Apply the budget to a single user in the organization. `user` and `multi_user_customer` scopes are only supported when `budget_product_sku` is `ai_credits` or `premium_requests`. */
    budget_scope?: CreateOrganizationBudgetRequestBudgetScope | (string & {}) | undefined;
    /** The entity to apply the budget to. The expected value depends on `budget_scope`. - `repository`: The repository name, or `owner/repo`. - `organization`, `multi_user_customer`, and `user`: Not used. For `user`, set the `user` field instead. */
    budget_entity_name?: string | undefined;
    /** The type of pricing model used by the budget. Determines how `budget_product_sku` is interpreted. - `BundlePricing`: Covers all AI credit SKUs. Set `budget_product_sku` to `ai_credits`. - `ProductPricing`: Covers all SKUs that belong to a product. Set `budget_product_sku` to a product such as `actions` or `packages`. - `SkuPricing`: Covers a single, specific SKU. Set `budget_product_sku` to a SKU such as `actions_linux`. */
    budget_type?: CreateOrganizationBudgetRequestBudgetType | undefined;
    /** A single product or SKU that will be covered in the budget */
    budget_product_sku?: string | undefined;
    /** The username of the user for `user` scope budgets. This field is required when `budget_scope` is `user`. */
    user?: string | undefined;
    /** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not provided, the budget will not expire. Only supported for budgets with `budget_scope` of `user` */
    expires_at?: string | undefined;
}
/** The type of scope for the budget */
export type CreateBudgetBudgetBudgetScope = "enterprise" | "organization" | "repository" | "cost_center" | "multi_user_customer" | "multi_user_cost_center" | "user";
export type CreateBudgetBudgetBudgetTypeCase0 = "ProductPricing";
export type CreateBudgetBudgetBudgetTypeCase1 = "SkuPricing";
/** The type of pricing for the budget */
export type CreateBudgetBudgetBudgetType = CreateBudgetBudgetBudgetTypeCase0 | CreateBudgetBudgetBudgetTypeCase1;
/** Array of user login names who will receive alerts. Rejected for user-scope as alerting is always disabled for them. */
export type CreateBudgetBudgetBudgetAlertingAlertRecipientsList = Array<string>;
export interface CreateBudgetBudgetBudgetAlerting {
    /** Whether alerts are enabled for this budget. Rejected for user-scope as alerting is always disabled for them. */
    will_alert?: boolean | undefined;
    /** Array of user login names who will receive alerts. Rejected for user-scope as alerting is always disabled for them. */
    alert_recipients?: CreateBudgetBudgetBudgetAlertingAlertRecipientsList | undefined;
}
export interface CreateBudgetBudget {
    /** ID of the budget. */
    id?: string | undefined;
    /** The type of scope for the budget */
    budget_scope?: CreateBudgetBudgetBudgetScope | undefined;
    /** The name of the entity to apply the budget to */
    budget_entity_name?: string | undefined;
    /** The budget amount in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount?: number | undefined;
    /** Whether to prevent additional spending once the budget is exceeded */
    prevent_further_usage?: boolean | undefined;
    /** A single product or sku to apply the budget to. */
    budget_product_sku?: string | undefined;
    /** The type of pricing for the budget */
    budget_type?: CreateBudgetBudgetBudgetType | undefined;
    budget_alerting?: CreateBudgetBudgetBudgetAlerting | undefined;
    /** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not provided, the budget will not expire. Only supported for budgets with `budget_scope` of `user` */
    expires_at?: string | undefined;
}
export interface CreateBudget {
    /** A message indicating the result of the create operation */
    message: string;
    budget: CreateBudgetBudget;
}
export interface DeleteBudgetOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID corresponding to the budget. */
    budget_id: string;
}
export interface DeleteBudget {
    /** A message indicating the result of the deletion operation */
    message: string;
    /** The ID of the deleted budget */
    id: string;
}
export type GetAllBudgetsOrgRequestScope = "enterprise" | "organization" | "repository" | "cost_center" | "multi_user_customer" | "user";
export interface GetAllBudgetsOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The page number of the results to fetch. */
    page?: number | undefined;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** Filter budgets by scope type. - `organization`: Budgets scoped to the organization. - `repository`: Budgets scoped to a repository. - `multi_user_customer`: Universal budgets that apply to all users in the organization. - `user`: Budgets scoped to an individual user. */
    scope?: GetAllBudgetsOrgRequestScope | (string & {}) | undefined;
    /** Filter consumed amount details for budgets by the specified user login. */
    user?: string | undefined;
}
export type BudgetBudgetTypeCase0 = "SkuPricing";
export type BudgetBudgetTypeCase1 = "ProductPricing";
/** The type of pricing for the budget */
export type BudgetBudgetType = BudgetBudgetTypeCase0 | BudgetBudgetTypeCase1;
/** The scope of the budget */
export type BudgetBudgetScope = "enterprise" | "organization" | "repository" | "cost_center" | "multi_user_customer" | "multi_user_cost_center" | "user";
/** Array of user login names who will receive alerts. Ignored for user-scope as alerting is disabled for them. */
export type BudgetBudgetAlertingAlertRecipientsList = Array<string>;
export interface BudgetBudgetAlerting {
    /** Whether alerts are enabled for this budget. Ignored for user-scope as alerting is disabled for them. */
    will_alert: boolean;
    /** Array of user login names who will receive alerts. Ignored for user-scope as alerting is disabled for them. */
    alert_recipients: BudgetBudgetAlertingAlertRecipientsList;
}
export interface Budget {
    /** The unique identifier for the budget */
    id: string;
    /** The type of pricing for the budget */
    budget_type: BudgetBudgetType;
    /** The budget amount limit in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount: number;
    /** The type of limit enforcement for the budget */
    prevent_further_usage: boolean;
    /** The scope of the budget */
    budget_scope: BudgetBudgetScope;
    /** The name of the entity for the budget (enterprise does not require a name). */
    budget_entity_name?: string | undefined;
    /** The user login when the budget is scoped to a single user (`user` scope). */
    user?: string | undefined;
    /** The amount consumed for a user-scoped budget, or for a multi-user budget when filtering by user. */
    consumed_amount?: number | undefined;
    /** A single product or sku to apply the budget to. */
    budget_product_sku: string;
    budget_alerting: BudgetBudgetAlerting;
    /** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not provided, the budget will not expire. Only supported for budgets with `budget_scope` of `user` */
    expires_at?: string | undefined;
}
/** Array of budget objects for the enterprise */
export type GetAllBudgetsBudgetsList = Array<Budget>;
/** Effective user-level budget details returned when the response is scoped with the `user` query parameter. */
export interface GetAllBudgetsEffectiveBudget {
    /** The unique identifier of the effective budget. */
    id: string;
    /** The budget amount for the effective budget. */
    budget_amount: number;
    /** The consumed amount for the specified user within the effective budget. */
    consumed_amount: number;
}
export interface GetAllBudgets {
    /** Array of budget objects for the enterprise */
    budgets: GetAllBudgetsBudgetsList;
    /** User login included when the response is scoped with the `user` query parameter. */
    user?: string | undefined;
    /** Effective user-level budget details returned when the response is scoped with the `user` query parameter. */
    effective_budget?: GetAllBudgetsEffectiveBudget | undefined;
    /** Indicates if there are more pages of results available */
    has_next_page?: boolean | undefined;
    /** Total number of budgets matching the query */
    total_count?: number | undefined;
}
export interface GetBudgetOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID corresponding to the budget. */
    budget_id: string;
}
/** The type of scope for the budget */
export type GetBudgetBudgetScope = "enterprise" | "organization" | "repository" | "cost_center" | "multi_user_customer" | "multi_user_cost_center" | "user";
export type GetBudgetBudgetTypeCase0 = "ProductPricing";
export type GetBudgetBudgetTypeCase1 = "SkuPricing";
/** The type of pricing for the budget */
export type GetBudgetBudgetType = GetBudgetBudgetTypeCase0 | GetBudgetBudgetTypeCase1;
/** Array of user login names who will receive alerts. Present but not applicable for user-scope as alerting is always disabled for them. */
export type GetBudgetBudgetAlertingAlertRecipientsList = Array<string>;
export interface GetBudgetBudgetAlerting {
    /** Whether alerts are enabled for this budget. Present but not applicable for user-scope as alerting is always disabled for them. */
    will_alert?: boolean | undefined;
    /** Array of user login names who will receive alerts. Present but not applicable for user-scope as alerting is always disabled for them. */
    alert_recipients?: GetBudgetBudgetAlertingAlertRecipientsList | undefined;
}
export interface GetBudget {
    /** ID of the budget. */
    id: string;
    /** The type of scope for the budget */
    budget_scope: GetBudgetBudgetScope;
    /** The name of the entity to apply the budget to */
    budget_entity_name: string;
    /** The user login when the budget is scoped to a single user (`user` scope). */
    user?: string | undefined;
    /** The budget amount in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount: number;
    /** Whether to prevent additional spending once the budget is exceeded */
    prevent_further_usage: boolean;
    /** A single product or sku to apply the budget to. */
    budget_product_sku: string;
    /** The type of pricing for the budget */
    budget_type: GetBudgetBudgetType;
    budget_alerting: GetBudgetBudgetAlerting;
    /** The current usage amount counted toward the budget. How usage is calculated may vary by budget type. */
    consumed_amount?: number | undefined;
}
export interface GetGithubBillingAiCreditUsageReportOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The user name to query usage for. The name is not case sensitive. */
    user?: string | undefined;
    /** The model name to query usage for. The name is not case sensitive. */
    model?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
}
export interface BillingAiCreditUsageReportOrgTimePeriod {
    /** The year for the usage report. */
    year: number;
    /** The month for the usage report. */
    month?: number | undefined;
    /** The day for the usage report. */
    day?: number | undefined;
}
export interface BillingAiCreditUsageReportOrgUsageItemsItem {
    /** Product name. */
    product: string;
    /** SKU name. */
    sku: string;
    /** Model name. */
    model: string;
    /** Unit type of the usage line item. */
    unitType: string;
    /** Price per unit of the usage line item. */
    pricePerUnit: number;
    /** Gross quantity of the usage line item. */
    grossQuantity: number;
    /** Gross amount of the usage line item. */
    grossAmount: number;
    /** Discount quantity of the usage line item. */
    discountQuantity: number;
    /** Discount amount of the usage line item. */
    discountAmount: number;
    /** Net quantity of the usage line item. */
    netQuantity: number;
    /** Net amount of the usage line item. */
    netAmount: number;
}
export type BillingAiCreditUsageReportOrgUsageItemsList = Array<BillingAiCreditUsageReportOrgUsageItemsItem>;
export interface BillingAiCreditUsageReportOrg {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the organization. */
    organization: string;
    /** The name of the user for the usage report. */
    user?: string | undefined;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The model for the usage report. */
    model?: string | undefined;
    usageItems: BillingAiCreditUsageReportOrgUsageItemsList;
}
export interface GetGithubBillingAiCreditUsageReportUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The model name to query usage for. The name is not case sensitive. */
    model?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
}
export type BillingAiCreditUsageReportUserTimePeriod = BillingAiCreditUsageReportOrgTimePeriod;
export type BillingAiCreditUsageReportUserUsageItemsItem = BillingAiCreditUsageReportOrgUsageItemsItem;
export type BillingAiCreditUsageReportUserUsageItemsList = Array<BillingAiCreditUsageReportOrgUsageItemsItem>;
export interface BillingAiCreditUsageReportUser {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the user. */
    user: string;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The model for the usage report. */
    model?: string | undefined;
    usageItems: BillingAiCreditUsageReportUserUsageItemsList;
}
export interface GetGithubBillingPremiumRequestUsageReportOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The user name to query usage for. The name is not case sensitive. */
    user?: string | undefined;
    /** The model name to query usage for. The name is not case sensitive. */
    model?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
}
export type BillingPremiumRequestUsageReportOrgTimePeriod = BillingAiCreditUsageReportOrgTimePeriod;
export type BillingPremiumRequestUsageReportOrgUsageItemsItem = BillingAiCreditUsageReportOrgUsageItemsItem;
export type BillingPremiumRequestUsageReportOrgUsageItemsList = Array<BillingAiCreditUsageReportOrgUsageItemsItem>;
export interface BillingPremiumRequestUsageReportOrg {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the organization. */
    organization: string;
    /** The name of the user for the usage report. */
    user?: string | undefined;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The model for the usage report. */
    model?: string | undefined;
    usageItems: BillingPremiumRequestUsageReportOrgUsageItemsList;
}
export interface GetGithubBillingPremiumRequestUsageReportUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The model name to query usage for. The name is not case sensitive. */
    model?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
}
export type BillingPremiumRequestUsageReportUserTimePeriod = BillingAiCreditUsageReportOrgTimePeriod;
export type BillingPremiumRequestUsageReportUserUsageItemsItem = BillingAiCreditUsageReportOrgUsageItemsItem;
export type BillingPremiumRequestUsageReportUserUsageItemsList = Array<BillingAiCreditUsageReportOrgUsageItemsItem>;
export interface BillingPremiumRequestUsageReportUser {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the user. */
    user: string;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The model for the usage report. */
    model?: string | undefined;
    usageItems: BillingPremiumRequestUsageReportUserUsageItemsList;
}
export interface GetGithubBillingUsageReportOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
}
export interface BillingUsageReportUsageItemsItem {
    /** Date of the usage line item. */
    date: string;
    /** Product name. */
    product: string;
    /** SKU name. */
    sku: string;
    /** Quantity of the usage line item. */
    quantity: number;
    /** Unit type of the usage line item. */
    unitType: string;
    /** Price per unit of the usage line item. */
    pricePerUnit: number;
    /** Gross amount of the usage line item. */
    grossAmount: number;
    /** Discount amount of the usage line item. */
    discountAmount: number;
    /** Net amount of the usage line item. */
    netAmount: number;
    /** Name of the organization. */
    organizationName: string;
    /** Name of the repository. */
    repositoryName?: string | undefined;
}
export type BillingUsageReportUsageItemsList = Array<BillingUsageReportUsageItemsItem>;
export interface BillingUsageReport {
    usageItems?: BillingUsageReportUsageItemsList | undefined;
}
export interface GetGithubBillingUsageReportUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
}
export interface BillingUsageReportUserUsageItemsItem {
    /** Date of the usage line item. */
    date: string;
    /** Product name. */
    product: string;
    /** SKU name. */
    sku: string;
    /** Quantity of the usage line item. */
    quantity: number;
    /** Unit type of the usage line item. */
    unitType: string;
    /** Price per unit of the usage line item. */
    pricePerUnit: number;
    /** Gross amount of the usage line item. */
    grossAmount: number;
    /** Discount amount of the usage line item. */
    discountAmount: number;
    /** Net amount of the usage line item. */
    netAmount: number;
    /** Name of the repository. */
    repositoryName?: string | undefined;
}
export type BillingUsageReportUserUsageItemsList = Array<BillingUsageReportUserUsageItemsItem>;
export interface BillingUsageReportUser {
    usageItems?: BillingUsageReportUserUsageItemsList | undefined;
}
export interface GetGithubBillingUsageSummaryReportOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The repository name to query for usage in the format owner/repository. */
    repository?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
    /** The SKU to query for usage. */
    sku?: string | undefined;
}
export type BillingUsageSummaryReportOrgTimePeriod = BillingAiCreditUsageReportOrgTimePeriod;
export interface BillingUsageSummaryReportOrgUsageItemsItem {
    /** Product name. */
    product: string;
    /** SKU name. */
    sku: string;
    /** Unit type of the usage line item. */
    unitType: string;
    /** Price per unit of the usage line item. */
    pricePerUnit: number;
    /** Gross quantity of the usage line item. */
    grossQuantity: number;
    /** Gross amount of the usage line item. */
    grossAmount: number;
    /** Discount quantity of the usage line item. */
    discountQuantity: number;
    /** Discount amount of the usage line item. */
    discountAmount: number;
    /** Net quantity of the usage line item. */
    netQuantity: number;
    /** Net amount of the usage line item. */
    netAmount: number;
}
export type BillingUsageSummaryReportOrgUsageItemsList = Array<BillingUsageSummaryReportOrgUsageItemsItem>;
export interface BillingUsageSummaryReportOrg {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the organization. */
    organization: string;
    /** The name of the repository for the usage report. */
    repository?: string | undefined;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The SKU for the usage report. */
    sku?: string | undefined;
    usageItems: BillingUsageSummaryReportOrgUsageItemsList;
}
export interface GetGithubBillingUsageSummaryReportUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year. */
    year?: number | undefined;
    /** If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used. */
    month?: number | undefined;
    /** If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used. */
    day?: number | undefined;
    /** The repository name to query for usage in the format owner/repository. */
    repository?: string | undefined;
    /** The product name to query usage for. The name is not case sensitive. */
    product?: string | undefined;
    /** The SKU to query for usage. */
    sku?: string | undefined;
}
export type BillingUsageSummaryReportUserTimePeriod = BillingAiCreditUsageReportOrgTimePeriod;
export type BillingUsageSummaryReportUserUsageItemsItem = BillingUsageSummaryReportOrgUsageItemsItem;
export type BillingUsageSummaryReportUserUsageItemsList = Array<BillingUsageSummaryReportOrgUsageItemsItem>;
export interface BillingUsageSummaryReportUser {
    timePeriod: BillingAiCreditUsageReportOrgTimePeriod;
    /** The unique identifier of the user. */
    user: string;
    /** The name of the repository for the usage report. */
    repository?: string | undefined;
    /** The product for the usage report. */
    product?: string | undefined;
    /** The SKU for the usage report. */
    sku?: string | undefined;
    usageItems: BillingUsageSummaryReportUserUsageItemsList;
}
/** Array of user login names who will receive alerts. Ignored for user-scopes as alerting is always disabled for them. */
export type UpdateBudgetOrgRequestBudgetAlertingAlertRecipientsList = Array<string>;
export interface UpdateBudgetOrgRequestBudgetAlerting {
    /** Whether alerts are enabled for this budget. Ignored for user-scopes as alerting is always disabled for them. */
    will_alert?: boolean | undefined;
    /** Array of user login names who will receive alerts. Ignored for user-scopes as alerting is always disabled for them. */
    alert_recipients?: UpdateBudgetOrgRequestBudgetAlertingAlertRecipientsList | undefined;
}
export type UpdateBudgetOrgRequestExpiresAtCase1 = 0;
/** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not set, the budget will not expire. Setting to `null` or `0` will remove the expiration date from a budget if set. Only supported for existing user-scoped budgets. */
export type UpdateBudgetOrgRequestExpiresAt = string | UpdateBudgetOrgRequestExpiresAtCase1;
export interface UpdateBudgetOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID corresponding to the budget. */
    budget_id: string;
    /** The budget amount in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount?: number | undefined;
    /** Whether to prevent additional spending once the budget is exceeded. For budgets with `user` or `multi_user_customer` scope, this must remain `true`. */
    prevent_further_usage?: boolean | undefined;
    budget_alerting?: UpdateBudgetOrgRequestBudgetAlerting | undefined;
    /** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not set, the budget will not expire. Setting to `null` or `0` will remove the expiration date from a budget if set. Only supported for existing user-scoped budgets. */
    expires_at?: UpdateBudgetOrgRequestExpiresAt | undefined;
}
/** The type of scope for the budget */
export type UpdateBudgetBudgetBudgetScope = "enterprise" | "organization" | "repository" | "cost_center" | "multi_user_customer" | "multi_user_cost_center" | "user";
export type UpdateBudgetBudgetBudgetTypeCase0 = "ProductPricing";
export type UpdateBudgetBudgetBudgetTypeCase1 = "SkuPricing";
/** The type of pricing for the budget */
export type UpdateBudgetBudgetBudgetType = UpdateBudgetBudgetBudgetTypeCase0 | UpdateBudgetBudgetBudgetTypeCase1;
/** Array of user login names who will receive alerts. Ignored for user-scope as alerting is always disabled for them. */
export type UpdateBudgetBudgetBudgetAlertingAlertRecipientsList = Array<string>;
export interface UpdateBudgetBudgetBudgetAlerting {
    /** Whether alerts are enabled for this budget. Ignored for user-scope as alerting is always disabled for them. */
    will_alert?: boolean | undefined;
    /** Array of user login names who will receive alerts. Ignored for user-scope as alerting is always disabled for them. */
    alert_recipients?: UpdateBudgetBudgetBudgetAlertingAlertRecipientsList | undefined;
}
export interface UpdateBudgetBudget {
    /** ID of the budget. */
    id?: string | undefined;
    /** The type of scope for the budget */
    budget_scope?: UpdateBudgetBudgetBudgetScope | undefined;
    /** The name of the entity to apply the budget to */
    budget_entity_name?: string | undefined;
    /** The user login when the budget is scoped to a single user (`user` scope). */
    user?: string | undefined;
    /** The consumed amount for the specified user within the budget. Only included for `user`-scoped budgets. */
    consumed_amount?: number | undefined;
    /** The budget amount in whole dollars. For license-based products, this represents the number of licenses. */
    budget_amount?: number | undefined;
    /** Whether to prevent additional spending once the budget is exceeded */
    prevent_further_usage?: boolean | undefined;
    /** A single product or sku to apply the budget to. */
    budget_product_sku?: string | undefined;
    /** The type of pricing for the budget */
    budget_type?: UpdateBudgetBudgetBudgetType | undefined;
    budget_alerting?: UpdateBudgetBudgetBudgetAlerting | undefined;
    /** The date the budget will expire in `YYYY-MM-DD` format. Only dates in the future are accepted. If not provided, the budget will not expire. Only supported for budgets with `budget_scope` of `user` */
    expires_at?: string | undefined;
}
export interface UpdateBudget {
    /** A message indicating the result of the update operation */
    message: string;
    budget: UpdateBudgetBudget;
}
export type CreateOrganizationBudgetError = GithubOpError;
/** Create a budget for an organization Creates a new budget for an organization. The authenticated user must be an organization admin or billing manager. */
export declare const createOrganizationBudget: API.OperationMethod<CreateOrganizationBudgetRequest, CreateBudget, CreateOrganizationBudgetError, GithubOpContext>;
export type DeleteBudgetOrgError = GithubOpError;
/** Delete a budget for an organization Deletes a budget by ID for an organization. The authenticated user must be an organization admin or billing manager. */
export declare const deleteBudgetOrg: API.OperationMethod<DeleteBudgetOrgRequest, DeleteBudget, DeleteBudgetOrgError, GithubOpContext>;
export type GetAllBudgetsOrgError = GithubOpError;
/** Get all budgets for an organization Gets all budgets for an organization. The authenticated user must be an organization admin or billing manager. Each page returns up to 100 budgets. */
export declare const getAllBudgetsOrg: API.PaginatedOperationMethod<GetAllBudgetsOrgRequest, GetAllBudgets, GetAllBudgetsOrgError, GithubOpContext, Budget>;
export type GetBudgetOrgError = GithubOpError;
/** Get a budget by ID for an organization Gets a budget by ID. The authenticated user must be an organization admin or billing manager. */
export declare const getBudgetOrg: API.OperationMethod<GetBudgetOrgRequest, GetBudget, GetBudgetOrgError, GithubOpContext>;
export type GetGithubBillingAiCreditUsageReportOrgError = GithubOpError;
/** Get billing AI credit usage report for an organization Gets a report of AI credit usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingAiCreditUsageReportOrg: API.OperationMethod<GetGithubBillingAiCreditUsageReportOrgRequest, BillingAiCreditUsageReportOrg, GetGithubBillingAiCreditUsageReportOrgError, GithubOpContext>;
export type GetGithubBillingAiCreditUsageReportUserError = GithubOpError;
/** Get billing AI credit usage report for a user Gets a report of AI credit usage for a user. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingAiCreditUsageReportUser: API.OperationMethod<GetGithubBillingAiCreditUsageReportUserRequest, BillingAiCreditUsageReportUser, GetGithubBillingAiCreditUsageReportUserError, GithubOpContext>;
export type GetGithubBillingPremiumRequestUsageReportOrgError = GithubOpError;
/** Get billing premium request usage report for an organization Gets a report of premium request usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingPremiumRequestUsageReportOrg: API.OperationMethod<GetGithubBillingPremiumRequestUsageReportOrgRequest, BillingPremiumRequestUsageReportOrg, GetGithubBillingPremiumRequestUsageReportOrgError, GithubOpContext>;
export type GetGithubBillingPremiumRequestUsageReportUserError = GithubOpError;
/** Get billing premium request usage report for a user Gets a report of premium request usage for a user. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingPremiumRequestUsageReportUser: API.OperationMethod<GetGithubBillingPremiumRequestUsageReportUserRequest, BillingPremiumRequestUsageReportUser, GetGithubBillingPremiumRequestUsageReportUserError, GithubOpContext>;
export type GetGithubBillingUsageReportOrgError = GithubOpError;
/** Get billing usage report for an organization Gets a report of the total usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account. **Note:** This endpoint is only available to organizations with access to the enhanced billing platform. For more information, see "[About the enhanced billing platform](https://docs.github.com/billing/using-the-new-billing-platform)." */
export declare const getGithubBillingUsageReportOrg: API.OperationMethod<GetGithubBillingUsageReportOrgRequest, BillingUsageReport, GetGithubBillingUsageReportOrgError, GithubOpContext>;
export type GetGithubBillingUsageReportUserError = GithubOpError;
/** Get billing usage report for a user Gets a report of the total usage for a user. **Note:** This endpoint is only available to users with access to the enhanced billing platform. */
export declare const getGithubBillingUsageReportUser: API.OperationMethod<GetGithubBillingUsageReportUserRequest, BillingUsageReportUser, GetGithubBillingUsageReportUserError, GithubOpContext>;
export type GetGithubBillingUsageSummaryReportOrgError = GithubOpError;
/** Get billing usage summary for an organization > [!NOTE] > This endpoint is in public preview and is subject to change. Gets a summary report of usage for an organization. To use this endpoint, you must be an administrator of an organization within an enterprise or an organization account. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingUsageSummaryReportOrg: API.OperationMethod<GetGithubBillingUsageSummaryReportOrgRequest, BillingUsageSummaryReportOrg, GetGithubBillingUsageSummaryReportOrgError, GithubOpContext>;
export type GetGithubBillingUsageSummaryReportUserError = GithubOpError;
/** Get billing usage summary for a user > [!NOTE] > This endpoint is in public preview and is subject to change. Gets a summary report of usage for a user. **Note:** Only data from the past 24 months is accessible via this endpoint. */
export declare const getGithubBillingUsageSummaryReportUser: API.OperationMethod<GetGithubBillingUsageSummaryReportUserRequest, BillingUsageSummaryReportUser, GetGithubBillingUsageSummaryReportUserError, GithubOpContext>;
export type UpdateBudgetOrgError = GithubOpError;
/** Update a budget for an organization Updates an existing budget for an organization. The authenticated user must be an organization admin or billing manager. */
export declare const updateBudgetOrg: API.OperationMethod<UpdateBudgetOrgRequest, UpdateBudget, UpdateBudgetOrgError, GithubOpContext>;
//# sourceMappingURL=billing.d.ts.map