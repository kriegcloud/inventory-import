import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TrainingSessionName = string;
export type IntegerList = number[];
export type EncodedTextChunkType = "encoded_text" | (string & {});
export interface EncodedTextChunk {
    tokens: number[];
    type: EncodedTextChunkType;
}
export type EncodedTextChunkList = EncodedTextChunk[];
export interface ModelInput {
    chunks: EncodedTextChunk[];
}
export type StopSequenceList = string[];
export interface SamplingParams {
    maxTokens: number;
    temperature?: number | undefined;
    topK?: number | undefined;
    topP?: number | undefined;
    seed?: number | undefined;
    stop?: string[] | undefined;
}
export interface SampleConfig {
    prompt: ModelInput;
    numSamples: number;
    samplingParams: SamplingParams;
    includePromptLogprobs?: boolean | undefined;
    topkPromptLogprobs?: number | undefined;
    modelPackageArn?: string | undefined;
}
export interface ComputeLogprobsConfig {
    prompt: ModelInput;
    modelPackageArn?: string | undefined;
}
export interface LoadWeightsForSamplingConfig {
    modelPackageArn: string;
}
export type SampleOperationConfig = {
    sample: SampleConfig;
    computeLogprobs?: undefined;
    loadWeightsForSampling?: undefined;
} | {
    sample?: undefined;
    computeLogprobs: ComputeLogprobsConfig;
    loadWeightsForSampling?: undefined;
} | {
    sample?: undefined;
    computeLogprobs?: undefined;
    loadWeightsForSampling: LoadWeightsForSamplingConfig;
};
export interface ExecuteSamplingOperationInput {
    trainingSessionName: string;
    operationConfig: SampleOperationConfig;
}
export type OperationId = string;
export interface ExecuteSamplingOperationOutput {
    operationId: string;
}
export type SequenceNumber = number;
export type ClientToken = string;
export type LossFnName = "cross_entropy" | "importance_sampling" | "ppo" | "cispo" | (string & {});
export interface TensorData {
    data: any;
    dtype: string;
    shape?: number[] | undefined;
}
export type TensorDataMap = {
    [key: string]: TensorData | undefined;
};
export interface Datum {
    modelInput: ModelInput;
    lossFnInputs?: {
        [key: string]: TensorData | undefined;
    } | undefined;
}
export type DatumList = Datum[];
export interface ForwardConfig {
    lossFnName: LossFnName;
    datumList: Datum[];
    lossFnConfig?: any | undefined;
}
export interface ForwardBackwardConfig {
    lossFnName: LossFnName;
    datumList: Datum[];
    lossFnConfig?: any | undefined;
}
export interface AdamParamsConfig {
    learningRate: number;
    beta1?: number | undefined;
    beta2?: number | undefined;
    eps?: number | undefined;
    weightDecay?: number | undefined;
    gradClipNorm?: number | undefined;
    loraPlusLrRatio?: number | undefined;
}
export interface OptimizerStepConfig {
    adamParamsConfig: AdamParamsConfig;
}
export interface SaveWeightsConfig {
    mergeWeights?: boolean | undefined;
    description?: string | undefined;
}
export interface SaveStateConfig {
    description?: string | undefined;
}
export interface LoadStateConfig {
    modelPackageArn: string;
    loadOptimizer: boolean;
}
export type OperationConfig = {
    forward: ForwardConfig;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward: ForwardBackwardConfig;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep: OptimizerStepConfig;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights: SaveWeightsConfig;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState: SaveStateConfig;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState: LoadStateConfig;
};
export interface ExecuteTrainingOperationInput {
    trainingSessionName: string;
    sequenceNumber: number;
    clientToken?: string | undefined;
    operationConfig: OperationConfig;
}
export interface ExecuteTrainingOperationOutput {
    operationId: string;
}
export interface GetSamplingOperationResultInput {
    trainingSessionName: string;
    operationId: string;
}
export type RequestStatus = "Pending" | "InProgress" | "Completed" | "Failed" | "Skipped" | (string & {});
export type StopReason = "stop" | "length" | (string & {});
export type DoubleList = number[];
export interface SampleTokenUsage {
    prefill: number;
    decode: number;
}
export interface SampledSequence {
    stopReason: StopReason;
    tokens: number[];
    logprobs?: number[] | undefined;
    tokenUsage?: SampleTokenUsage | undefined;
}
export type SampledSequenceList = SampledSequence[];
export interface TokenLogprob {
    tokenId: number;
    logprob: number;
}
export type TokenLogprobList = TokenLogprob[];
export type TopkPromptLogprobsList = TokenLogprob[][];
export interface SampleResponse {
    sequences: SampledSequence[];
    promptLogprobs?: number[] | undefined;
    topkPromptLogprobs?: TokenLogprob[][] | undefined;
}
export interface ComputeLogprobsResult {
    logprobs: number[];
}
export interface LoadWeightsForSamplingResult {
}
export type SampleOperationResult = {
    sample: SampleResponse;
    computeLogprobs?: undefined;
    loadWeightsForSampling?: undefined;
} | {
    sample?: undefined;
    computeLogprobs: ComputeLogprobsResult;
    loadWeightsForSampling?: undefined;
} | {
    sample?: undefined;
    computeLogprobs?: undefined;
    loadWeightsForSampling: LoadWeightsForSamplingResult;
};
export interface GetSamplingOperationResultOutput {
    status: RequestStatus;
    operationResult?: SampleOperationResult | undefined;
    errorDetails?: string | undefined;
}
export interface GetTrainingOperationResultInput {
    trainingSessionName: string;
    operationId: string;
}
export type TensorDataMapList = {
    [key: string]: TensorData | undefined;
}[];
export type MetricsMap = {
    [key: string]: number | undefined;
};
export interface TrainingTokenUsage {
    trainingTokens?: number | undefined;
}
export interface ForwardResult {
    lossFnOutputType?: string | undefined;
    lossFnOutputs?: {
        [key: string]: TensorData | undefined;
    }[] | undefined;
    metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    tokenUsage?: TrainingTokenUsage | undefined;
}
export interface ForwardBackwardResult {
    lossFnOutputType?: string | undefined;
    lossFnOutputs?: {
        [key: string]: TensorData | undefined;
    }[] | undefined;
    metrics?: {
        [key: string]: number | undefined;
    } | undefined;
    tokenUsage?: TrainingTokenUsage | undefined;
}
export interface OptimizerStepResult {
    metrics?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface SaveWeightsResult {
    modelPackageArn?: string | undefined;
}
export interface SaveStateResult {
    modelPackageArn: string;
}
export interface LoadStateResult {
}
export type OperationResult = {
    forward: ForwardResult;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward: ForwardBackwardResult;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep: OptimizerStepResult;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights: SaveWeightsResult;
    saveState?: undefined;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState: SaveStateResult;
    loadState?: undefined;
} | {
    forward?: undefined;
    forwardBackward?: undefined;
    optimizerStep?: undefined;
    saveWeights?: undefined;
    saveState?: undefined;
    loadState: LoadStateResult;
};
export interface GetTrainingOperationResultOutput {
    status: RequestStatus;
    operationResult?: OperationResult | undefined;
    errorDetails?: string | undefined;
    tokenUsage?: TrainingTokenUsage | undefined;
}
export interface SampleTrainingSessionInput {
    trainingSessionName: string;
    contentType?: string | undefined;
    accept?: string | undefined;
    modelPackageArn?: string | undefined;
    body?: T.StreamingInputBody | undefined;
}
export interface SampleTrainingSessionOutput {
    contentType?: string | undefined;
    body: T.StreamingOutputBody;
}
export interface SampleTrainingSessionWithResponseStreamInput {
    trainingSessionName: string;
    contentType?: string | undefined;
    accept?: string | undefined;
    modelPackageArn?: string | undefined;
    body?: T.StreamingInputBody | undefined;
}
export interface SampleTrainingSessionWithResponseStreamOutput {
    contentType?: string | undefined;
    body: T.StreamingOutputBody;
}
export type ExecuteSamplingOperationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits an asynchronous sampling operation to generate text or compute log-probabilities from the model associated with the specified training session. The session must be in `Running` or `Blocked` state. Use `GetSamplingOperationResult` to poll for the result.
 */
export declare const executeSamplingOperation: API.OperationMethod<ExecuteSamplingOperationInput & RegionInput, ExecuteSamplingOperationOutput, ExecuteSamplingOperationError, Credentials | HttpClient.HttpClient>;
export type ExecuteTrainingOperationError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits an asynchronous training operation to the specified training session. The service executes operations in sequence number order. The session must be in `Running` or `Blocked` state. Use `GetTrainingOperationResult` to poll for the result. Supported operation types: `forward`, `forwardBackward`, `optimizerStep`, `saveWeights`, `saveState`, and `loadState`.
 */
export declare const executeTrainingOperation: API.OperationMethod<ExecuteTrainingOperationInput & RegionInput, ExecuteTrainingOperationOutput, ExecuteTrainingOperationError, Credentials | HttpClient.HttpClient>;
export type GetSamplingOperationResultError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current status and result of a previously submitted sampling operation. Poll this operation until the status reaches a terminal state (Completed or Failed).
 */
export declare const getSamplingOperationResult: API.OperationMethod<GetSamplingOperationResultInput & RegionInput, GetSamplingOperationResultOutput, GetSamplingOperationResultError, Credentials | HttpClient.HttpClient>;
export type GetTrainingOperationResultError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current status and result of a previously submitted training operation. Poll this operation until the status reaches a terminal state (Completed, Failed, or Skipped).
 */
export declare const getTrainingOperationResult: API.OperationMethod<GetTrainingOperationResultInput & RegionInput, GetTrainingOperationResultOutput, GetTrainingOperationResultError, Credentials | HttpClient.HttpClient>;
export type SampleTrainingSessionError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an inference request to the model associated with the specified training session and returns the response synchronously. The service passes the request and response bodies to and from the model without modification.
 */
export declare const sampleTrainingSession: API.OperationMethod<SampleTrainingSessionInput & RegionInput, SampleTrainingSessionOutput, SampleTrainingSessionError, Credentials | HttpClient.HttpClient>;
export type SampleTrainingSessionWithResponseStreamError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Streams inference responses from the model associated with the specified training session. Use this operation for real-time token-by-token generation. The service passes the request body to the model without modification.
 */
export declare const sampleTrainingSessionWithResponseStream: API.OperationMethod<SampleTrainingSessionWithResponseStreamInput & RegionInput, SampleTrainingSessionWithResponseStreamOutput, SampleTrainingSessionWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemakertrainingsessionruntime.d.ts.map