import type * as rolldown from "rolldown";
/**
 * Packages whose namespace imports are rewritten by default. Their root
 * modules re-export every service (`export * as Lambda from "./Lambda/index.ts"`),
 * and every one of them declares `"sideEffects": false`.
 */
export declare const DEFAULT_NAMESPACE_IMPORT_PACKAGES: ReadonlyArray<string>;
/**
 * Options for {@link namespaceImportPlugin}.
 */
export interface NamespaceImportPluginOptions {
    /**
     * Extra package names or globs whose namespace imports are rewritten, in
     * addition to {@link DEFAULT_NAMESPACE_IMPORT_PACKAGES}. Matched with
     * picomatch against the package name of the import specifier. Only list
     * packages that declare `"sideEffects": false`.
     */
    readonly packages?: ReadonlyArray<string>;
}
/**
 * Rolldown plugin that rewrites namespace imports of barrel packages into
 * named imports, so `experimental.lazyBarrel` only compiles the re-exports
 * a module actually uses.
 *
 * ```ts
 * import * as AWS from "@alchemy.run/aws";
 * AWS.Lambda.Function;
 * // becomes
 * import { Lambda as AWS$Lambda } from "@alchemy.run/aws";
 * AWS$Lambda.Function;
 * ```
 *
 * Rolldown loads every export of a barrel imported with `import * as ns`,
 * even when only `ns.X` is read, so without this rewrite one
 * `import * as AWS from "@alchemy.run/aws"` parses every AWS service.
 *
 * A namespace is only rewritten when every reference to its name is a
 * static member access (`ns.X`, or `ns.X` in a type). Anything else —
 * passing the namespace around, computed access, a shadowing binding,
 * JSX — leaves the import untouched.
 */
export declare const namespaceImportPlugin: (options?: NamespaceImportPluginOptions) => rolldown.Plugin;
/** A source replacement over `[start, end)`. */
export interface NamespaceImportEdit {
    readonly start: number;
    readonly end: number;
    readonly text: string;
}
/**
 * Returns the edits that rewrite each eligible namespace import in `code`
 * (see {@link namespaceImportPlugin}), or an empty array when nothing is
 * rewritten.
 */
export declare function collectNamespaceImportEdits(code: string, filename: string, matchesSpecifier: (specifier: string) => boolean): Promise<NamespaceImportEdit[]>;
//# sourceMappingURL=NamespaceImportPlugin.d.ts.map