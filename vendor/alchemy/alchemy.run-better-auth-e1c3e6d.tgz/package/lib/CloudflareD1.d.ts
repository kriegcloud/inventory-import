import * as Cloudflare from "@alchemy.run/cloudflare";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as Scope from "effect/Scope";
import { Database } from "./Database.ts";
/**
 * Cloudflare D1 database layer for Better Auth.
 *
 * At runtime the Worker reaches the database through its native D1 binding
 * (the layer bakes in `QueryDatabaseBinding`). At deploy time, schema
 * migrations run over the D1 HTTP query API — which also transparently
 * targets the local D1 simulator under `alchemy dev`.
 *
 *
 * ### Using D1 as the auth database
 * Provide the layer on the Worker impl effect that yields `BetterAuth`.
 * The database resource can be referenced from module scope — the layer
 * accepts the resource or its Effect.
 * **Example:** Worker with a D1-backed BetterAuth
 * ```typescript
 * import { BetterAuth } from "@alchemy.run/better-auth";
 * import { CloudflareD1 } from "@alchemy.run/better-auth/CloudflareD1";
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 *
 * export const AuthDb = Cloudflare.D1.Database("AuthDb");
 *
 * export default class Api extends Cloudflare.Worker<Api>()(
 *   "Api",
 *   { main: import.meta.url, compatibility: { flags: ["nodejs_compat"] } },
 *   Effect.gen(function* () {
 *     const auth = yield* BetterAuth({
 *       basePath: "/auth",
 *       emailAndPassword: { enabled: true },
 *     });
 *     return {
 *       fetch: Effect.gen(function* () {
 *         const request = yield* HttpServerRequest;
 *         if (request.url.startsWith("/auth")) {
 *           return yield* auth.fetch;
 *         }
 *         const session = yield* auth.getSession();
 *         return yield* HttpServerResponse.json({ user: session?.user ?? null });
 *       }),
 *     };
 *   }).pipe(Effect.provide(CloudflareD1(AuthDb))),
 * ) {}
 * ```
 *
 * ### Migrations
 * The schema migration Action connects over the D1 HTTP API at deploy
 * time — the Worker's native binding is never used outside the deployed
 * runtime, and no migration code ships in the Worker bundle.
 * **Example:** Opting out of automatic migrations
 * ```typescript
 * const auth = yield* BetterAuth({
 *   migrate: false, // manage the schema yourself
 *   emailAndPassword: { enabled: true },
 * });
 * ```
 *
 * @layer
 * @provides BetterAuth.Database
 * @product D1
 */
export declare const CloudflareD1: <R = never>(database: Cloudflare.D1.Database | Effect.Effect<Cloudflare.D1.Database, never, R>) => Layer.Layer<Database, never, Cloudflare.WorkerEnvironment | Exclude<Exclude<R, Scope.Scope>, Cloudflare.D1.QueryDatabase> | Cloudflare.Worker<any>>;
//# sourceMappingURL=CloudflareD1.d.ts.map