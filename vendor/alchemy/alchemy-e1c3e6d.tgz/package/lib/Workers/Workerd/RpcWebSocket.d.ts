import * as Effect from "effect/Effect";
import * as RpcSerialization from "effect/rpc/RpcSerialization";
import * as RpcServer from "effect/rpc/RpcServer";
import type { HttpEffect } from "../../Http.ts";
import { RuntimeContext } from "../../RuntimeContext.ts";
import type { WorkerdDurableObjectState } from "./DurableObjectState.ts";
import { type WebSocket } from "./WebSocket.ts";
export interface Transport {
    readonly protocol: RpcServer.Protocol["Service"];
    readonly fetch: HttpEffect;
    readonly webSocketMessage: (socket: WebSocket, message: string | ArrayBuffer) => Effect.Effect<void>;
    readonly webSocketClose: (socket: WebSocket) => Effect.Effect<void>;
    readonly webSocketError: (socket: WebSocket, error: unknown) => Effect.Effect<void>;
}
/**
 * Internal, per-activation transport. Provide `protocol` to `RpcServer.layer`
 * in an instance-owned scope, not the first fetch or WebSocket event's scope.
 * This transport exclusively owns the object's WebSocket auto-response pair.
 * Binary serializers use waking Ping/Pong messages instead of auto-response.
 * Serializers must emit each response immediately; buffered output fails closed.
 */
/** The Durable Object state members the transport needs. */
export type RpcWebSocketState = Pick<WorkerdDurableObjectState, "abort" | "acceptWebSocket" | "getWebSocketAutoResponse" | "getWebSockets" | "setWebSocketAutoResponse" | "waitUntil">;
export declare const make: (state: RpcWebSocketState) => Effect.Effect<Transport, never, RuntimeContext | RpcSerialization.RpcSerialization>;
//# sourceMappingURL=RpcWebSocket.d.ts.map