import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CreateForkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
}
export interface CreateForkResponse {
}
/** The package's language or package management ecosystem. */
export type SecurityAdvisoryEcosystems = "rubygems" | "npm" | "pip" | "maven" | "nuget" | "composer" | "go" | "rust" | "erlang" | "actions" | "pub" | "other" | "swift";
/** The name of the package affected by the vulnerability. */
export interface CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage {
    ecosystem: SecurityAdvisoryEcosystems | (string & {});
    /** The unique package name within its ecosystem. */
    name?: string | null | undefined;
}
/** The functions in the package that are affected. */
export type CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemVulnerableFunctionsList = Array<string>;
export interface CreatePrivateVulnerabilityReportRequestVulnerabilitiesItem {
    /** The name of the package affected by the vulnerability. */
    package: CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage;
    /** The range of the package versions affected by the vulnerability. */
    vulnerable_version_range?: string | null | undefined;
    /** The package version(s) that resolve the vulnerability. */
    patched_versions?: string | null | undefined;
    /** The functions in the package that are affected. */
    vulnerable_functions?: CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemVulnerableFunctionsList | null | undefined;
}
/** An array of products affected by the vulnerability detailed in a repository security advisory. */
export type CreatePrivateVulnerabilityReportRequestVulnerabilitiesList = Array<CreatePrivateVulnerabilityReportRequestVulnerabilitiesItem>;
/** A list of Common Weakness Enumeration (CWE) IDs. */
export type CreatePrivateVulnerabilityReportRequestCweIdsList = Array<string>;
/** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
export type CreatePrivateVulnerabilityReportRequestSeverity = "critical" | "high" | "medium" | "low";
export interface CreatePrivateVulnerabilityReportRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A short summary of the advisory. */
    summary: string;
    /** A detailed description of what the advisory impacts. */
    description: string;
    /** An array of products affected by the vulnerability detailed in a repository security advisory. */
    vulnerabilities?: CreatePrivateVulnerabilityReportRequestVulnerabilitiesList | null | undefined;
    /** A list of Common Weakness Enumeration (CWE) IDs. */
    cwe_ids?: CreatePrivateVulnerabilityReportRequestCweIdsList | null | undefined;
    /** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
    severity?: CreatePrivateVulnerabilityReportRequestSeverity | (string & {}) | null | undefined;
    /** The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`. */
    cvss_vector_string?: string | null | undefined;
    /** Whether to create a temporary private fork of the repository to collaborate on a fix. The fork is created only if you are permitted to create one; otherwise, this parameter is ignored and the report is still created. */
    start_private_fork?: boolean | undefined;
}
/** The severity of the advisory. */
export type RepositoryAdvisorySeverity = "critical" | "high" | "medium" | "low";
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The type of identifier. */
export type RepositoryAdvisoryIdentifiersItemType = "CVE" | "GHSA";
export interface RepositoryAdvisoryIdentifiersItem {
    /** The type of identifier. */
    type: RepositoryAdvisoryIdentifiersItemType;
    /** The identifier value. */
    value: string;
}
export type RepositoryAdvisoryIdentifiersList = Array<RepositoryAdvisoryIdentifiersItem>;
/** The state of the advisory. */
export type RepositoryAdvisoryState = "published" | "closed" | "withdrawn" | "draft" | "triage";
export interface RepositoryAdvisorySubmission {
    /** Whether a private vulnerability report was accepted by the repository's administrators. */
    accepted: boolean;
}
/** The name of the package affected by the vulnerability. */
export interface RepositoryAdvisoryVulnerabilityPackage {
    ecosystem: SecurityAdvisoryEcosystems;
    /** The unique package name within its ecosystem. */
    name: string | null;
}
/** The functions in the package that are affected. */
export type RepositoryAdvisoryVulnerabilityVulnerableFunctionsList = Array<string>;
/** A product affected by the vulnerability detailed in a repository security advisory. */
export interface RepositoryAdvisoryVulnerability {
    /** The name of the package affected by the vulnerability. */
    package: RepositoryAdvisoryVulnerabilityPackage | null;
    /** The range of the package versions affected by the vulnerability. */
    vulnerable_version_range: string | null;
    /** The package version(s) that resolve the vulnerability. */
    patched_versions: string | null;
    /** The functions in the package that are affected. */
    vulnerable_functions: RepositoryAdvisoryVulnerabilityVulnerableFunctionsList | null;
}
export type RepositoryAdvisoryVulnerabilitiesList = Array<RepositoryAdvisoryVulnerability>;
export interface RepositoryAdvisoryCvss {
    /** The CVSS vector. */
    vector_string: string | null;
    /** The CVSS score. */
    score: number | null;
}
export interface CvssSeveritiesCvssV3 {
    /** The CVSS 3 vector string. */
    vector_string: string | null;
    /** The CVSS 3 score. */
    score: number | null;
}
export interface CvssSeveritiesCvssV4 {
    /** The CVSS 4 vector string. */
    vector_string: string | null;
    /** The CVSS 4 score. */
    score: number | null;
}
export interface CvssSeverities {
    cvss_v3?: CvssSeveritiesCvssV3 | null | undefined;
    cvss_v4?: CvssSeveritiesCvssV4 | null | undefined;
}
export interface RepositoryAdvisoryCwesItem {
    /** The Common Weakness Enumeration (CWE) identifier. */
    cwe_id: string;
    /** The name of the CWE. */
    name: string;
}
export type RepositoryAdvisoryCwesList = Array<RepositoryAdvisoryCwesItem>;
/** A list of only the CWE IDs. */
export type RepositoryAdvisoryCweIdsList = Array<string>;
/** The type of credit the user is receiving. */
export type SecurityAdvisoryCreditTypes = "analyst" | "finder" | "reporter" | "coordinator" | "remediation_developer" | "remediation_reviewer" | "remediation_verifier" | "tool" | "sponsor" | "other";
export interface RepositoryAdvisoryCreditsItem {
    /** The username of the user credited. */
    login?: string | undefined;
    type?: SecurityAdvisoryCreditTypes | undefined;
}
export type RepositoryAdvisoryCreditsList = Array<RepositoryAdvisoryCreditsItem>;
/** The state of the user's acceptance of the credit. */
export type RepositoryAdvisoryCreditState = "accepted" | "declined" | "pending";
/** A credit given to a user for a repository security advisory. */
export interface RepositoryAdvisoryCredit {
    user: SimpleUser;
    type: SecurityAdvisoryCreditTypes;
    /** The state of the user's acceptance of the credit. */
    state: RepositoryAdvisoryCreditState;
}
export type RepositoryAdvisoryCreditsDetailedList = Array<RepositoryAdvisoryCredit>;
/** A list of users that collaborate on the advisory. */
export type RepositoryAdvisoryCollaboratingUsersList = Array<SimpleUser>;
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
/** A list of teams that collaborate on the advisory. */
export type RepositoryAdvisoryCollaboratingTeamsList = Array<Team>;
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: SimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
/** A repository security advisory. */
export interface RepositoryAdvisory {
    /** The GitHub Security Advisory ID. */
    ghsa_id: string;
    /** The Common Vulnerabilities and Exposures (CVE) ID. */
    cve_id: string | null;
    /** The API URL for the advisory. */
    url: string;
    /** The URL for the advisory. */
    html_url: string;
    /** A short summary of the advisory. */
    summary: string;
    /** A detailed description of what the advisory entails. */
    description: string | null;
    /** The severity of the advisory. */
    severity: RepositoryAdvisorySeverity | null;
    /** The author of the advisory. */
    author: SimpleUser | null;
    /** The publisher of the advisory. */
    publisher: SimpleUser | null;
    identifiers: RepositoryAdvisoryIdentifiersList;
    /** The state of the advisory. */
    state: RepositoryAdvisoryState;
    /** The date and time of when the advisory was created, in ISO 8601 format. */
    created_at: string | null;
    /** The date and time of when the advisory was last updated, in ISO 8601 format. */
    updated_at: string | null;
    /** The date and time of when the advisory was published, in ISO 8601 format. */
    published_at: string | null;
    /** The date and time of when the advisory was closed, in ISO 8601 format. */
    closed_at: string | null;
    /** The date and time of when the advisory was withdrawn, in ISO 8601 format. */
    withdrawn_at: string | null;
    submission: RepositoryAdvisorySubmission | null;
    vulnerabilities: RepositoryAdvisoryVulnerabilitiesList | null;
    cvss: RepositoryAdvisoryCvss | null;
    cvss_severities?: CvssSeverities | null | undefined;
    cwes: RepositoryAdvisoryCwesList | null;
    /** A list of only the CWE IDs. */
    cwe_ids: RepositoryAdvisoryCweIdsList | null;
    credits: RepositoryAdvisoryCreditsList | null;
    credits_detailed: RepositoryAdvisoryCreditsDetailedList | null;
    /** A list of users that collaborate on the advisory. */
    collaborating_users: RepositoryAdvisoryCollaboratingUsersList | null;
    /** A list of teams that collaborate on the advisory. */
    collaborating_teams: RepositoryAdvisoryCollaboratingTeamsList | null;
    /** A temporary private fork of the advisory's repository for collaborating on a fix. */
    private_fork: SimpleRepository | null;
}
/** The name of the package affected by the vulnerability. */
export type CreateRepositoryAdvisoryRequestVulnerabilitiesItemPackage = CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage;
/** The functions in the package that are affected. */
export type CreateRepositoryAdvisoryRequestVulnerabilitiesItemVulnerableFunctionsList = Array<string>;
export interface CreateRepositoryAdvisoryRequestVulnerabilitiesItem {
    /** The name of the package affected by the vulnerability. */
    package: CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage;
    /** The range of the package versions affected by the vulnerability. */
    vulnerable_version_range?: string | null | undefined;
    /** The package version(s) that resolve the vulnerability. */
    patched_versions?: string | null | undefined;
    /** The functions in the package that are affected. */
    vulnerable_functions?: CreateRepositoryAdvisoryRequestVulnerabilitiesItemVulnerableFunctionsList | null | undefined;
}
/** A product affected by the vulnerability detailed in a repository security advisory. */
export type CreateRepositoryAdvisoryRequestVulnerabilitiesList = Array<CreateRepositoryAdvisoryRequestVulnerabilitiesItem>;
/** A list of Common Weakness Enumeration (CWE) IDs. */
export type CreateRepositoryAdvisoryRequestCweIdsList = Array<string>;
export interface CreateRepositoryAdvisoryRequestCreditsItem {
    /** The username of the user credited. */
    login: string;
    type: SecurityAdvisoryCreditTypes | (string & {});
}
/** A list of users receiving credit for their participation in the security advisory. */
export type CreateRepositoryAdvisoryRequestCreditsList = Array<CreateRepositoryAdvisoryRequestCreditsItem>;
/** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
export type CreateRepositoryAdvisoryRequestSeverity = "critical" | "high" | "medium" | "low";
export interface CreateRepositoryAdvisoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A short summary of the advisory. */
    summary: string;
    /** A detailed description of what the advisory impacts. */
    description: string;
    /** The Common Vulnerabilities and Exposures (CVE) ID. */
    cve_id?: string | null | undefined;
    /** A product affected by the vulnerability detailed in a repository security advisory. */
    vulnerabilities: CreateRepositoryAdvisoryRequestVulnerabilitiesList;
    /** A list of Common Weakness Enumeration (CWE) IDs. */
    cwe_ids?: CreateRepositoryAdvisoryRequestCweIdsList | null | undefined;
    /** A list of users receiving credit for their participation in the security advisory. */
    credits?: CreateRepositoryAdvisoryRequestCreditsList | null | undefined;
    /** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
    severity?: CreateRepositoryAdvisoryRequestSeverity | (string & {}) | null | undefined;
    /** The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`. */
    cvss_vector_string?: string | null | undefined;
    /** Whether to create a temporary private fork of the repository to collaborate on a fix. */
    start_private_fork?: boolean | undefined;
}
export interface CreateRepositoryAdvisoryCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
    /** The contents of the comment. */
    body: string;
}
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** A comment on a repository security advisory. */
export interface RepositoryAdvisoryComment {
    /** Unique identifier of the advisory comment. */
    id: number;
    node_id: string;
    /** API URL for the advisory comment. */
    url: string;
    /** Web URL for the advisory comment. */
    html_url: string;
    /** Contents of the advisory comment. */
    body: string;
    user: SimpleUser | null;
    created_at: string;
    updated_at: string;
    advisory_url: string;
    author_association: AuthorAssociation;
}
export interface CreateRepositoryAdvisoryCveRequestRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
}
export interface CreateRepositoryAdvisoryCveRequestResponse {
}
export interface GetGlobalAdvisoryRequest {
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
}
/** The type of advisory. */
export type GlobalAdvisoryType = "reviewed" | "unreviewed" | "malware";
/** The severity of the advisory. */
export type GlobalAdvisorySeverity = "critical" | "high" | "medium" | "low" | "unknown";
/** The type of identifier. */
export type GlobalAdvisoryIdentifiersItemType = "CVE" | "GHSA";
export interface GlobalAdvisoryIdentifiersItem {
    /** The type of identifier. */
    type: GlobalAdvisoryIdentifiersItemType;
    /** The identifier value. */
    value: string;
}
export type GlobalAdvisoryIdentifiersList = Array<GlobalAdvisoryIdentifiersItem>;
export type GlobalAdvisoryReferencesList = Array<string>;
/** The name of the package affected by the vulnerability. */
export type VulnerabilityPackage = RepositoryAdvisoryVulnerabilityPackage;
/** The functions in the package that are affected by the vulnerability. */
export type VulnerabilityVulnerableFunctionsList = Array<string>;
/** A vulnerability describing the product and its affected versions within a GitHub Security Advisory. */
export interface Vulnerability {
    /** The name of the package affected by the vulnerability. */
    package: RepositoryAdvisoryVulnerabilityPackage | null;
    /** The range of the package versions affected by the vulnerability. */
    vulnerable_version_range: string | null;
    /** The package version that resolves the vulnerability. */
    first_patched_version: string | null;
    /** The functions in the package that are affected by the vulnerability. */
    vulnerable_functions: VulnerabilityVulnerableFunctionsList | null;
}
/** The products and respective version ranges affected by the advisory. */
export type GlobalAdvisoryVulnerabilitiesList = Array<Vulnerability>;
export type GlobalAdvisoryCvss = RepositoryAdvisoryCvss;
/** The EPSS scores as calculated by the [Exploit Prediction Scoring System](https://www.first.org/epss). */
export interface SecurityAdvisoryEpss {
    percentage?: number | undefined;
    percentile?: number | undefined;
}
export type GlobalAdvisoryCwesItem = RepositoryAdvisoryCwesItem;
export type GlobalAdvisoryCwesList = Array<RepositoryAdvisoryCwesItem>;
export interface GlobalAdvisoryCreditsItem {
    user: SimpleUser;
    type: SecurityAdvisoryCreditTypes;
}
/** The users who contributed to the advisory. */
export type GlobalAdvisoryCreditsList = Array<GlobalAdvisoryCreditsItem>;
/** A GitHub Security Advisory. */
export interface GlobalAdvisory {
    /** The GitHub Security Advisory ID. */
    ghsa_id: string;
    /** The Common Vulnerabilities and Exposures (CVE) ID. */
    cve_id: string | null;
    /** The API URL for the advisory. */
    url: string;
    /** The URL for the advisory. */
    html_url: string;
    /** The API URL for the repository advisory. */
    repository_advisory_url: string | null;
    /** A short summary of the advisory. */
    summary: string;
    /** A detailed description of what the advisory entails. */
    description: string | null;
    /** The type of advisory. */
    type: GlobalAdvisoryType;
    /** The severity of the advisory. */
    severity: GlobalAdvisorySeverity;
    /** The URL of the advisory's source code. */
    source_code_location: string | null;
    identifiers: GlobalAdvisoryIdentifiersList | null;
    references: GlobalAdvisoryReferencesList | null;
    /** The date and time of when the advisory was published, in ISO 8601 format. */
    published_at: string;
    /** The date and time of when the advisory was last updated, in ISO 8601 format. */
    updated_at: string;
    /** The date and time of when the advisory was reviewed by GitHub, in ISO 8601 format. */
    github_reviewed_at: string | null;
    /** The date and time when the advisory was published in the National Vulnerability Database, in ISO 8601 format. This field is only populated when the advisory is imported from the National Vulnerability Database. */
    nvd_published_at: string | null;
    /** The date and time of when the advisory was withdrawn, in ISO 8601 format. */
    withdrawn_at: string | null;
    /** The products and respective version ranges affected by the advisory. */
    vulnerabilities: GlobalAdvisoryVulnerabilitiesList | null;
    cvss: RepositoryAdvisoryCvss | null;
    cvss_severities?: CvssSeverities | null | undefined;
    epss?: SecurityAdvisoryEpss | null | undefined;
    cwes: GlobalAdvisoryCwesList | null;
    /** The users who contributed to the advisory. */
    credits: GlobalAdvisoryCreditsList | null;
}
export interface GetRepositoryAdvisoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
}
export interface GetRepositoryAdvisoryCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export type ListGlobalAdvisoriesRequestType = "reviewed" | "malware" | "unreviewed";
export type ListGlobalAdvisoriesRequestSeverity = "unknown" | "low" | "medium" | "high" | "critical";
export type ListGlobalAdvisoriesRequestCwesCase1List = Array<string>;
export type ListGlobalAdvisoriesRequestCwes = string | ListGlobalAdvisoriesRequestCwesCase1List;
export type ListGlobalAdvisoriesRequestAffectsCase1List = Array<string>;
export type ListGlobalAdvisoriesRequestAffects = string | ListGlobalAdvisoriesRequestAffectsCase1List;
export type ListGlobalAdvisoriesRequestDirection = "asc" | "desc";
export type ListGlobalAdvisoriesRequestSort = "updated" | "published" | "epss_percentage" | "epss_percentile";
export interface ListGlobalAdvisoriesRequest {
    /** If specified, only advisories with this GHSA (GitHub Security Advisory) identifier will be returned. */
    ghsa_id?: string | undefined;
    /** If specified, only advisories of this type will be returned. By default, a request with no other parameters defined will only return reviewed advisories that are not malware. */
    type?: ListGlobalAdvisoriesRequestType | (string & {}) | undefined;
    /** If specified, only advisories with this CVE (Common Vulnerabilities and Exposures) identifier will be returned. */
    cve_id?: string | undefined;
    /** If specified, only advisories for these ecosystems will be returned. */
    ecosystem?: SecurityAdvisoryEcosystems | (string & {}) | undefined;
    /** If specified, only advisories with these severities will be returned. */
    severity?: ListGlobalAdvisoriesRequestSeverity | (string & {}) | undefined;
    /** If specified, only advisories with these Common Weakness Enumerations (CWEs) will be returned. Example: `cwes=79,284,22` or `cwes[]=79&cwes[]=284&cwes[]=22` */
    cwes?: ListGlobalAdvisoriesRequestCwes | undefined;
    /** Whether to only return advisories that have been withdrawn. */
    is_withdrawn?: boolean | undefined;
    /** If specified, only return advisories that affect any of `package` or `package@version`. A maximum of 1000 packages can be specified. If the query parameter causes the URL to exceed the maximum URL length supported by your client, you must specify fewer packages. Example: `affects=package1,package2@1.0.0,package3@2.0.0` or `affects[]=package1&affects[]=package2@1.0.0` */
    affects?: ListGlobalAdvisoriesRequestAffects | undefined;
    /** If specified, only return advisories that were published on a date or date range. For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)." */
    published?: string | undefined;
    /** If specified, only return advisories that were updated on a date or date range. For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)." */
    updated?: string | undefined;
    /** If specified, only show advisories that were updated or published on a date or date range. For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)." */
    modified?: string | undefined;
    /** If specified, only return advisories that have an EPSS percentage score that matches the provided value. The EPSS percentage represents the likelihood of a CVE being exploited. */
    epss_percentage?: string | undefined;
    /** If specified, only return advisories that have an EPSS percentile score that matches the provided value. The EPSS percentile represents the relative rank of the CVE's likelihood of being exploited compared to other CVEs. */
    epss_percentile?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The direction to sort the results by. */
    direction?: ListGlobalAdvisoriesRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The property to sort the results by. */
    sort?: ListGlobalAdvisoriesRequestSort | (string & {}) | undefined;
}
export type ListGlobalAdvisoriesResponseBodyList = Array<GlobalAdvisory>;
export type ListGlobalAdvisoriesResponse = ListGlobalAdvisoriesResponseBodyList;
export type ListOrgRepositoryAdvisoriesRequestDirection = "asc" | "desc";
export type ListOrgRepositoryAdvisoriesRequestSort = "created" | "updated" | "published";
export type ListOrgRepositoryAdvisoriesRequestState = "triage" | "draft" | "published" | "closed";
export interface ListOrgRepositoryAdvisoriesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The direction to sort the results by. */
    direction?: ListOrgRepositoryAdvisoriesRequestDirection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListOrgRepositoryAdvisoriesRequestSort | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of advisories to return per page. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Filter by the state of the repository advisories. Only advisories of this state will be returned. */
    state?: ListOrgRepositoryAdvisoriesRequestState | (string & {}) | undefined;
}
export type ListOrgRepositoryAdvisoriesResponseBodyList = Array<RepositoryAdvisory>;
export type ListOrgRepositoryAdvisoriesResponse = ListOrgRepositoryAdvisoriesResponseBodyList;
export type ListRepositoryAdvisoriesRequestDirection = "asc" | "desc";
export type ListRepositoryAdvisoriesRequestSort = "created" | "updated" | "published";
export type ListRepositoryAdvisoriesRequestState = "triage" | "draft" | "published" | "closed";
export interface ListRepositoryAdvisoriesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The direction to sort the results by. */
    direction?: ListRepositoryAdvisoriesRequestDirection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListRepositoryAdvisoriesRequestSort | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The number of advisories to return per page. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Filter by state of the repository advisories. Only advisories of this state will be returned. */
    state?: ListRepositoryAdvisoriesRequestState | (string & {}) | undefined;
}
export type ListRepositoryAdvisoriesResponseBodyList = Array<RepositoryAdvisory>;
export type ListRepositoryAdvisoriesResponse = ListRepositoryAdvisoriesResponseBodyList;
export interface ListRepositoryAdvisoryCommentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepositoryAdvisoryCommentsResponseBodyList = Array<RepositoryAdvisoryComment>;
export type ListRepositoryAdvisoryCommentsResponse = ListRepositoryAdvisoryCommentsResponseBodyList;
/** The name of the package affected by the vulnerability. */
export type UpdateRepositoryAdvisoryRequestVulnerabilitiesItemPackage = CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage;
/** The functions in the package that are affected. */
export type UpdateRepositoryAdvisoryRequestVulnerabilitiesItemVulnerableFunctionsList = Array<string>;
export interface UpdateRepositoryAdvisoryRequestVulnerabilitiesItem {
    /** The name of the package affected by the vulnerability. */
    package: CreatePrivateVulnerabilityReportRequestVulnerabilitiesItemPackage;
    /** The range of the package versions affected by the vulnerability. */
    vulnerable_version_range?: string | null | undefined;
    /** The package version(s) that resolve the vulnerability. */
    patched_versions?: string | null | undefined;
    /** The functions in the package that are affected. */
    vulnerable_functions?: UpdateRepositoryAdvisoryRequestVulnerabilitiesItemVulnerableFunctionsList | null | undefined;
}
/** A product affected by the vulnerability detailed in a repository security advisory. */
export type UpdateRepositoryAdvisoryRequestVulnerabilitiesList = Array<UpdateRepositoryAdvisoryRequestVulnerabilitiesItem>;
/** A list of Common Weakness Enumeration (CWE) IDs. */
export type UpdateRepositoryAdvisoryRequestCweIdsList = Array<string>;
export type UpdateRepositoryAdvisoryRequestCreditsItem = CreateRepositoryAdvisoryRequestCreditsItem;
/** A list of users receiving credit for their participation in the security advisory. */
export type UpdateRepositoryAdvisoryRequestCreditsList = Array<CreateRepositoryAdvisoryRequestCreditsItem>;
/** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
export type UpdateRepositoryAdvisoryRequestSeverity = "critical" | "high" | "medium" | "low";
/** The state of the advisory. */
export type UpdateRepositoryAdvisoryRequestState = "published" | "closed" | "draft";
/** A list of usernames who have been granted write access to the advisory. */
export type UpdateRepositoryAdvisoryRequestCollaboratingUsersList = Array<string>;
/** A list of team slugs which have been granted write access to the advisory. */
export type UpdateRepositoryAdvisoryRequestCollaboratingTeamsList = Array<string>;
export interface UpdateRepositoryAdvisoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
    /** A short summary of the advisory. */
    summary?: string | undefined;
    /** A detailed description of what the advisory impacts. */
    description?: string | undefined;
    /** The Common Vulnerabilities and Exposures (CVE) ID. */
    cve_id?: string | null | undefined;
    /** A product affected by the vulnerability detailed in a repository security advisory. */
    vulnerabilities?: UpdateRepositoryAdvisoryRequestVulnerabilitiesList | undefined;
    /** A list of Common Weakness Enumeration (CWE) IDs. */
    cwe_ids?: UpdateRepositoryAdvisoryRequestCweIdsList | null | undefined;
    /** A list of users receiving credit for their participation in the security advisory. */
    credits?: UpdateRepositoryAdvisoryRequestCreditsList | null | undefined;
    /** The severity of the advisory. You must choose between setting this field or `cvss_vector_string`. */
    severity?: UpdateRepositoryAdvisoryRequestSeverity | (string & {}) | null | undefined;
    /** The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`. */
    cvss_vector_string?: string | null | undefined;
    /** The state of the advisory. */
    state?: UpdateRepositoryAdvisoryRequestState | (string & {}) | undefined;
    /** A list of usernames who have been granted write access to the advisory. */
    collaborating_users?: UpdateRepositoryAdvisoryRequestCollaboratingUsersList | null | undefined;
    /** A list of team slugs which have been granted write access to the advisory. */
    collaborating_teams?: UpdateRepositoryAdvisoryRequestCollaboratingTeamsList | null | undefined;
}
export interface UpdateRepositoryAdvisoryCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The GHSA (GitHub Security Advisory) identifier of the advisory. */
    ghsa_id: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The contents of the comment. */
    body: string;
}
export type CreateForkError = GithubOpError;
/** Create a temporary private fork Create a temporary private fork to collaborate on fixing a security vulnerability in a repository. Repository administrators, organization owners, and security managers can create a temporary private fork. The original reporter of a privately reported vulnerability can also create one while they remain a collaborator on the security advisory. > [!NOTE] > Forking a repository happens asynchronously. You may have to wait up to 5 minutes before you can access the fork. */
export declare const createFork: API.OperationMethod<CreateForkRequest, CreateForkResponse, CreateForkError, GithubOpContext>;
export type CreatePrivateVulnerabilityReportError = GithubOpError;
/** Privately report a security vulnerability Report a security vulnerability to the maintainers of the repository. See "[Privately reporting a security vulnerability](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability)" for more information about private vulnerability reporting. */
export declare const createPrivateVulnerabilityReport: API.OperationMethod<CreatePrivateVulnerabilityReportRequest, RepositoryAdvisory, CreatePrivateVulnerabilityReportError, GithubOpContext>;
export type CreateRepositoryAdvisoryError = GithubOpError;
/** Create a repository security advisory Creates a new repository security advisory. In order to create a draft repository security advisory, the authenticated user must be a security manager or administrator of that repository. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:write` scope to use this endpoint. */
export declare const createRepositoryAdvisory: API.OperationMethod<CreateRepositoryAdvisoryRequest, RepositoryAdvisory, CreateRepositoryAdvisoryError, GithubOpContext>;
export type CreateRepositoryAdvisoryCommentError = GithubOpError;
/** Create a repository advisory comment Creates a comment on a repository security advisory. In order to create a comment, the authenticated user must be an advisory collaborator, security manager, or repository administrator. */
export declare const createRepositoryAdvisoryComment: API.OperationMethod<CreateRepositoryAdvisoryCommentRequest, RepositoryAdvisoryComment, CreateRepositoryAdvisoryCommentError, GithubOpContext>;
export type CreateRepositoryAdvisoryCveRequestError = GithubOpError;
/** Request a CVE for a repository security advisory If you want a CVE identification number for the security vulnerability in your project, and don't already have one, you can request a CVE identification number from GitHub. For more information see "[Requesting a CVE identification number](https://docs.github.com/code-security/security-advisories/repository-security-advisories/publishing-a-repository-security-advisory#requesting-a-cve-identification-number-optional)." You may request a CVE for public repositories, but cannot do so for private repositories. In order to request a CVE for a repository security advisory, the authenticated user must be a security manager or administrator of that repository. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:write` scope to use this endpoint. */
export declare const createRepositoryAdvisoryCveRequest: API.OperationMethod<CreateRepositoryAdvisoryCveRequestRequest, CreateRepositoryAdvisoryCveRequestResponse, CreateRepositoryAdvisoryCveRequestError, GithubOpContext>;
export type GetGlobalAdvisoryError = GithubOpError;
/** Get a global security advisory Gets a global security advisory using its GitHub Security Advisory (GHSA) identifier. */
export declare const getGlobalAdvisory: API.OperationMethod<GetGlobalAdvisoryRequest, GlobalAdvisory, GetGlobalAdvisoryError, GithubOpContext>;
export type GetRepositoryAdvisoryError = GithubOpError;
/** Get a repository security advisory Get a repository security advisory using its GitHub Security Advisory (GHSA) identifier. Anyone can access any published security advisory on a public repository. The authenticated user can access an unpublished security advisory from a repository if they are a security manager or administrator of that repository, or if they are a collaborator on the security advisory. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:read` scope to to get a published security advisory in a private repository, or any unpublished security advisory that the authenticated user has access to. */
export declare const getRepositoryAdvisory: API.OperationMethod<GetRepositoryAdvisoryRequest, RepositoryAdvisory, GetRepositoryAdvisoryError, GithubOpContext>;
export type GetRepositoryAdvisoryCommentError = GithubOpError;
/** Get a repository advisory comment Get a comment on a repository security advisory using the comment's ID. Advisory collaborators can view all non-confidential comments on advisories they have access to. Other users can only view comments that are not considered internal. GitHub Apps and fine-grained personal access tokens with the `repository_advisories: read` permission can view all non-confidential comments, including internal comments. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:read` scope to get a comment on a security advisory in a private repository, or any unpublished security advisory that the authenticated user has access to. */
export declare const getRepositoryAdvisoryComment: API.OperationMethod<GetRepositoryAdvisoryCommentRequest, RepositoryAdvisoryComment, GetRepositoryAdvisoryCommentError, GithubOpContext>;
export type ListGlobalAdvisoriesError = GithubOpError;
/** List global security advisories Lists all global security advisories that match the specified parameters. If no other parameters are defined, the request will return only GitHub-reviewed advisories that are not malware. By default, all responses will exclude advisories for malware, because malware are not standard vulnerabilities. To list advisories for malware, you must include the `type` parameter in your request, with the value `malware`. For more information about the different types of security advisories, see "[About the GitHub Advisory database](https://docs.github.com/code-security/security-advisories/global-security-advisories/about-the-github-advisory-database#about-types-of-security-advisories)." */
export declare const listGlobalAdvisories: API.OperationMethod<ListGlobalAdvisoriesRequest, ListGlobalAdvisoriesResponse, ListGlobalAdvisoriesError, GithubOpContext>;
export type ListOrgRepositoryAdvisoriesError = GithubOpError;
/** List repository security advisories for an organization Lists repository security advisories for an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:write` scope to use this endpoint. */
export declare const listOrgRepositoryAdvisories: API.OperationMethod<ListOrgRepositoryAdvisoriesRequest, ListOrgRepositoryAdvisoriesResponse, ListOrgRepositoryAdvisoriesError, GithubOpContext>;
export type ListRepositoryAdvisoriesError = GithubOpError;
/** List repository security advisories Lists security advisories in a repository. The authenticated user can access unpublished security advisories from a repository if they are a security manager or administrator of that repository, or if they are a collaborator on any security advisory. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:read` scope to to get a published security advisory in a private repository, or any unpublished security advisory that the authenticated user has access to. */
export declare const listRepositoryAdvisories: API.OperationMethod<ListRepositoryAdvisoriesRequest, ListRepositoryAdvisoriesResponse, ListRepositoryAdvisoriesError, GithubOpContext>;
export type ListRepositoryAdvisoryCommentsError = GithubOpError;
/** List repository security advisory comments Lists comments on a repository security advisory. Accessing internal comments requires write access to the advisory. Callers with read-only access to the advisory receive only eligible post-publication comments. For unpublished advisories, these callers receive an empty list. */
export declare const listRepositoryAdvisoryComments: API.PaginatedOperationMethod<ListRepositoryAdvisoryCommentsRequest, ListRepositoryAdvisoryCommentsResponse, ListRepositoryAdvisoryCommentsError, GithubOpContext, RepositoryAdvisoryComment>;
export type UpdateRepositoryAdvisoryError = GithubOpError;
/** Update a repository security advisory Update a repository security advisory using its GitHub Security Advisory (GHSA) identifier. In order to update any security advisory, the authenticated user must be a security manager or administrator of that repository, or a collaborator on the repository security advisory. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:write` scope to use this endpoint. */
export declare const updateRepositoryAdvisory: API.OperationMethod<UpdateRepositoryAdvisoryRequest, RepositoryAdvisory, UpdateRepositoryAdvisoryError, GithubOpContext>;
export type UpdateRepositoryAdvisoryCommentError = GithubOpError;
/** Update a repository advisory comment Update the body of a comment on a repository security advisory using the comment's ID. In order to update a comment, the authenticated user must be the author of the comment, or a security manager or administrator of the repository. OAuth app tokens and personal access tokens (classic) need the `repo` or `repository_advisories:write` scope to use this endpoint. */
export declare const updateRepositoryAdvisoryComment: API.OperationMethod<UpdateRepositoryAdvisoryCommentRequest, RepositoryAdvisoryComment, UpdateRepositoryAdvisoryCommentError, GithubOpContext>;
//# sourceMappingURL=security_advisories.d.ts.map