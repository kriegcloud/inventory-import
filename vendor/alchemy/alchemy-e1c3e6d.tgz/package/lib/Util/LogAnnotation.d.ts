/**
 * Annotation keys alchemy reads. `fqn` is an ordinary attribute (the
 * resource a record is about, when there is one); the rest map onto
 * envelope fields instead of `attributes`.
 */
export declare const LogAnnotation: {
    readonly fqn: "fqn";
    readonly stream: "alchemy.stream";
    readonly process: "alchemy.process";
    /** Set by `emit`: the record's message is a typed event. */
    readonly event: "alchemy.event";
    /** `"global"`: account-level work, filed in the global run log. */
    readonly scope: "alchemy.scope";
    /** Set on replay: what the original record carried. */
    readonly time: "alchemy.time";
    readonly cause: "alchemy.cause";
    readonly trace: "alchemy.trace";
};
//# sourceMappingURL=LogAnnotation.d.ts.map