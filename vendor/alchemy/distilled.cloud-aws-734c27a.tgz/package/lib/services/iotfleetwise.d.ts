import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resource: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DecoderManifestValidationException_base: S.TaggedErrorClass<"DecoderManifestValidationException", {
    readonly invalidSignals: any;
    readonly invalidNetworkInterfaces: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DecoderManifestValidationException extends /*@__PURE__*/ DecoderManifestValidationException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidNodeException_base: S.TaggedErrorClass<"InvalidNodeException", {
    readonly invalidNodes: any;
    readonly reason: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNodeException extends /*@__PURE__*/ InvalidNodeException_base {
}
declare const InvalidSignalsException_base: S.TaggedErrorClass<"InvalidSignalsException", {
    readonly message: any;
    readonly invalidSignals: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSignalsException extends /*@__PURE__*/ InvalidSignalsException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type VehicleName = string;
export type FleetId = string;
export interface AssociateVehicleFleetRequest {
    vehicleName: string;
    fleetId: string;
}
export interface AssociateVehicleFleetResponse {
}
export type Arn = string;
export type AttributeName = string;
export type AttributeValue = string;
export type AttributesMap = {
    [key: string]: string | undefined;
};
export type VehicleAssociationBehavior = "CreateIotThing" | "ValidateIotThingExists" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type ResourceIdentifier = string;
export type TimeUnit = "MILLISECOND" | "SECOND" | "MINUTE" | "HOUR" | (string & {});
export type PositiveInteger = number;
export interface TimePeriod {
    unit: TimeUnit;
    value: number;
}
export interface PeriodicStateTemplateUpdateStrategy {
    stateTemplateUpdateRate: TimePeriod;
}
export interface OnChangeStateTemplateUpdateStrategy {
}
export type StateTemplateUpdateStrategy = {
    periodic: PeriodicStateTemplateUpdateStrategy;
    onChange?: undefined;
} | {
    periodic?: undefined;
    onChange: OnChangeStateTemplateUpdateStrategy;
};
export interface StateTemplateAssociation {
    identifier: string;
    stateTemplateUpdateStrategy: StateTemplateUpdateStrategy;
}
export type StateTemplateAssociations = StateTemplateAssociation[];
export interface CreateVehicleRequestItem {
    vehicleName: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    associationBehavior?: VehicleAssociationBehavior | undefined;
    tags?: Tag[] | undefined;
    stateTemplates?: StateTemplateAssociation[] | undefined;
}
export type CreateVehicleRequestItems = CreateVehicleRequestItem[];
export interface BatchCreateVehicleRequest {
    vehicles: CreateVehicleRequestItem[];
}
export interface CreateVehicleResponseItem {
    vehicleName?: string | undefined;
    arn?: string | undefined;
    thingArn?: string | undefined;
}
export type CreateVehicleResponses = CreateVehicleResponseItem[];
export interface CreateVehicleError_ {
    vehicleName?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type CreateVehicleErrors = CreateVehicleError_[];
export interface BatchCreateVehicleResponse {
    vehicles?: CreateVehicleResponseItem[] | undefined;
    errors?: CreateVehicleError_[] | undefined;
}
export type UpdateMode = "Overwrite" | "Merge" | (string & {});
export type StateTemplateAssociationIdentifiers = string[];
export interface UpdateVehicleRequestItem {
    vehicleName: string;
    modelManifestArn?: string | undefined;
    decoderManifestArn?: string | undefined;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    attributeUpdateMode?: UpdateMode | undefined;
    stateTemplatesToAdd?: StateTemplateAssociation[] | undefined;
    stateTemplatesToRemove?: string[] | undefined;
    stateTemplatesToUpdate?: StateTemplateAssociation[] | undefined;
}
export type UpdateVehicleRequestItems = UpdateVehicleRequestItem[];
export interface BatchUpdateVehicleRequest {
    vehicles: UpdateVehicleRequestItem[];
}
export interface UpdateVehicleResponseItem {
    vehicleName?: string | undefined;
    arn?: string | undefined;
}
export type UpdateVehicleResponseItems = UpdateVehicleResponseItem[];
export interface UpdateVehicleError_ {
    vehicleName?: string | undefined;
    code?: number | undefined;
    message?: string | undefined;
}
export type UpdateVehicleErrors = UpdateVehicleError_[];
export interface BatchUpdateVehicleResponse {
    vehicles?: UpdateVehicleResponseItem[] | undefined;
    errors?: UpdateVehicleError_[] | undefined;
}
export type CampaignName = string;
export type Description = string;
export type Uint32 = number;
export type DiagnosticsMode = "OFF" | "SEND_ACTIVE_DTCS" | (string & {});
export type SpoolingMode = "OFF" | "TO_DISK" | (string & {});
export type Compression = "OFF" | "SNAPPY" | (string & {});
export type Priority = number;
export type WildcardSignalName = string;
export type MaxSampleCount = number;
export type DataPartitionId = string;
export interface SignalInformation {
    name: string;
    maxSampleCount?: number | undefined;
    minimumSamplingIntervalMs?: number | undefined;
    dataPartitionId?: string | undefined;
}
export type SignalInformationList = SignalInformation[];
export type CollectionPeriodMs = number;
export interface TimeBasedCollectionScheme {
    periodMs: number;
}
export type EventExpression = string | redacted.Redacted<string>;
export type TriggerMode = "ALWAYS" | "RISING_EDGE" | (string & {});
export type LanguageVersion = number;
export interface ConditionBasedCollectionScheme {
    expression: string | redacted.Redacted<string>;
    minimumTriggerIntervalMs?: number | undefined;
    triggerMode?: TriggerMode | undefined;
    conditionLanguageVersion?: number | undefined;
}
export type CollectionScheme = {
    timeBasedCollectionScheme: TimeBasedCollectionScheme;
    conditionBasedCollectionScheme?: undefined;
} | {
    timeBasedCollectionScheme?: undefined;
    conditionBasedCollectionScheme: ConditionBasedCollectionScheme;
};
export type NodePath = string;
export type DataExtraDimensionNodePathList = string[];
export type S3BucketArn = string;
export type DataFormat = "JSON" | "PARQUET" | (string & {});
export type StorageCompressionFormat = "NONE" | "GZIP" | (string & {});
export type Prefix = string;
export interface S3Config {
    bucketArn: string;
    dataFormat?: DataFormat | undefined;
    storageCompressionFormat?: StorageCompressionFormat | undefined;
    prefix?: string | undefined;
}
export type TimestreamTableArn = string;
export type IAMRoleArn = string;
export interface TimestreamConfig {
    timestreamTableArn: string;
    executionRoleArn: string;
}
export type MqttTopicArn = string;
export interface MqttTopicConfig {
    mqttTopicArn: string;
    executionRoleArn: string;
}
export type DataDestinationConfig = {
    s3Config: S3Config;
    timestreamConfig?: undefined;
    mqttTopicConfig?: undefined;
} | {
    s3Config?: undefined;
    timestreamConfig: TimestreamConfig;
    mqttTopicConfig?: undefined;
} | {
    s3Config?: undefined;
    timestreamConfig?: undefined;
    mqttTopicConfig: MqttTopicConfig;
};
export type DataDestinationConfigs = DataDestinationConfig[];
export type StorageMaximumSizeUnit = "MB" | "GB" | "TB" | (string & {});
export type StorageMaximumSizeValue = number;
export interface StorageMaximumSize {
    unit: StorageMaximumSizeUnit;
    value: number;
}
export type StorageLocation = string | redacted.Redacted<string>;
export type StorageMinimumTimeToLiveUnit = "HOURS" | "DAYS" | "WEEKS" | (string & {});
export type StorageMinimumTimeToLiveValue = number;
export interface StorageMinimumTimeToLive {
    unit: StorageMinimumTimeToLiveUnit;
    value: number;
}
export interface DataPartitionStorageOptions {
    maximumSize: StorageMaximumSize;
    storageLocation: string | redacted.Redacted<string>;
    minimumTimeToLive: StorageMinimumTimeToLive;
}
export interface DataPartitionUploadOptions {
    expression: string | redacted.Redacted<string>;
    conditionLanguageVersion?: number | undefined;
}
export interface DataPartition {
    id: string;
    storageOptions: DataPartitionStorageOptions;
    uploadOptions?: DataPartitionUploadOptions | undefined;
}
export type DataPartitions = DataPartition[];
export type PositiveLong = number;
export interface TimeBasedSignalFetchConfig {
    executionFrequencyMs: number;
}
export type FetchConfigEventExpression = string | redacted.Redacted<string>;
export interface ConditionBasedSignalFetchConfig {
    conditionExpression: string | redacted.Redacted<string>;
    triggerMode: TriggerMode;
}
export type SignalFetchConfig = {
    timeBased: TimeBasedSignalFetchConfig;
    conditionBased?: undefined;
} | {
    timeBased?: undefined;
    conditionBased: ConditionBasedSignalFetchConfig;
};
export type ActionEventExpression = string | redacted.Redacted<string>;
export type EventExpressionList = (string | redacted.Redacted<string>)[];
export interface SignalFetchInformation {
    fullyQualifiedName: string;
    signalFetchConfig: SignalFetchConfig;
    conditionLanguageVersion?: number | undefined;
    actions: (string | redacted.Redacted<string>)[];
}
export type SignalFetchInformationList = SignalFetchInformation[];
export interface CreateCampaignRequest {
    name: string;
    description?: string | undefined;
    signalCatalogArn: string;
    targetArn: string;
    startTime?: Date | undefined;
    expiryTime?: Date | undefined;
    postTriggerCollectionDuration?: number | undefined;
    diagnosticsMode?: DiagnosticsMode | undefined;
    spoolingMode?: SpoolingMode | undefined;
    compression?: Compression | undefined;
    priority?: number | undefined;
    signalsToCollect?: SignalInformation[] | undefined;
    collectionScheme: CollectionScheme;
    dataExtraDimensions?: string[] | undefined;
    tags?: Tag[] | undefined;
    dataDestinationConfigs?: DataDestinationConfig[] | undefined;
    dataPartitions?: DataPartition[] | undefined;
    signalsToFetch?: SignalFetchInformation[] | undefined;
}
export type CampaignArn = string;
export interface CreateCampaignResponse {
    name?: string | undefined;
    arn?: string | undefined;
}
export type ResourceName = string;
export type FullyQualifiedName = string;
export type SignalDecoderType = "CAN_SIGNAL" | "OBD_SIGNAL" | "MESSAGE_SIGNAL" | "CUSTOM_DECODING_SIGNAL" | (string & {});
export type InterfaceId = string;
export type NonNegativeInteger = number;
export type CanSignalName = string;
export type SignalValueType = "INTEGER" | "FLOATING_POINT" | (string & {});
export interface CanSignal {
    messageId: number;
    isBigEndian: boolean;
    isSigned: boolean;
    startBit: number;
    offset: number;
    factor: number;
    length: number;
    name?: string | undefined;
    signalValueType?: SignalValueType | undefined;
}
export type ObdByteLength = number;
export type ObdBitmaskLength = number;
export interface ObdSignal {
    pidResponseLength: number;
    serviceMode: number;
    pid: number;
    scaling: number;
    offset: number;
    startByte: number;
    byteLength: number;
    bitRightShift?: number | undefined;
    bitMaskLength?: number | undefined;
    isSigned?: boolean | undefined;
    signalValueType?: SignalValueType | undefined;
}
export type TopicName = string;
export type ROS2PrimitiveType = "BOOL" | "BYTE" | "CHAR" | "FLOAT32" | "FLOAT64" | "INT8" | "UINT8" | "INT16" | "UINT16" | "INT32" | "UINT32" | "INT64" | "UINT64" | "STRING" | "WSTRING" | (string & {});
export type MaxStringSize = number;
export interface ROS2PrimitiveMessageDefinition {
    primitiveType: ROS2PrimitiveType;
    offset?: number | undefined;
    scaling?: number | undefined;
    upperBound?: number | undefined;
}
export type PrimitiveMessageDefinition = {
    ros2PrimitiveMessageDefinition: ROS2PrimitiveMessageDefinition;
};
export type StructureMessageName = string;
export type StructuredMessageListType = "FIXED_CAPACITY" | "DYNAMIC_UNBOUNDED_CAPACITY" | "DYNAMIC_BOUNDED_CAPACITY" | (string & {});
export interface StructuredMessageListDefinition {
    name: string;
    memberType: StructuredMessage;
    listType: StructuredMessageListType;
    capacity?: number | undefined;
}
export interface StructuredMessageFieldNameAndDataTypePair {
    fieldName: string;
    dataType: StructuredMessage;
}
export type StructuredMessageDefinition = StructuredMessageFieldNameAndDataTypePair[];
export type StructuredMessage = {
    primitiveMessageDefinition: PrimitiveMessageDefinition;
    structuredMessageListDefinition?: undefined;
    structuredMessageDefinition?: undefined;
} | {
    primitiveMessageDefinition?: undefined;
    structuredMessageListDefinition: StructuredMessageListDefinition;
    structuredMessageDefinition?: undefined;
} | {
    primitiveMessageDefinition?: undefined;
    structuredMessageListDefinition?: undefined;
    structuredMessageDefinition: StructuredMessageFieldNameAndDataTypePair[];
};
export interface MessageSignal {
    topicName: string;
    structuredMessage: StructuredMessage;
}
export type CustomDecodingId = string;
export interface CustomDecodingSignal {
    id: string;
}
export interface SignalDecoder {
    fullyQualifiedName: string;
    type: SignalDecoderType;
    interfaceId: string;
    canSignal?: CanSignal | undefined;
    obdSignal?: ObdSignal | undefined;
    messageSignal?: MessageSignal | undefined;
    customDecodingSignal?: CustomDecodingSignal | undefined;
}
export type SignalDecoders = SignalDecoder[];
export type NetworkInterfaceType = "CAN_INTERFACE" | "OBD_INTERFACE" | "VEHICLE_MIDDLEWARE" | "CUSTOM_DECODING_INTERFACE" | (string & {});
export type CanInterfaceName = string;
export type ProtocolName = string;
export type ProtocolVersion = string;
export interface CanInterface {
    name: string;
    protocolName?: string | undefined;
    protocolVersion?: string | undefined;
}
export type ObdInterfaceName = string;
export type ObdStandard = string;
export interface ObdInterface {
    name: string;
    requestMessageId: number;
    obdStandard?: string | undefined;
    pidRequestIntervalSeconds?: number | undefined;
    dtcRequestIntervalSeconds?: number | undefined;
    useExtendedIds?: boolean | undefined;
    hasTransmissionEcu?: boolean | undefined;
}
export type VehicleMiddlewareName = string;
export type VehicleMiddlewareProtocol = "ROS_2" | (string & {});
export interface VehicleMiddleware {
    name: string;
    protocolName: VehicleMiddlewareProtocol;
}
export type CustomDecodingSignalInterfaceName = string;
export interface CustomDecodingInterface {
    name: string;
}
export interface NetworkInterface {
    interfaceId: string;
    type: NetworkInterfaceType;
    canInterface?: CanInterface | undefined;
    obdInterface?: ObdInterface | undefined;
    vehicleMiddleware?: VehicleMiddleware | undefined;
    customDecodingInterface?: CustomDecodingInterface | undefined;
}
export type NetworkInterfaces = NetworkInterface[];
export type DefaultForUnmappedSignalsType = "CUSTOM_DECODING" | (string & {});
export interface CreateDecoderManifestRequest {
    name: string;
    description?: string | undefined;
    modelManifestArn: string;
    signalDecoders?: SignalDecoder[] | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
    defaultForUnmappedSignals?: DefaultForUnmappedSignalsType | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateDecoderManifestResponse {
    name: string;
    arn: string;
}
export interface CreateFleetRequest {
    fleetId: string;
    description?: string | undefined;
    signalCatalogArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateFleetResponse {
    id: string;
    arn: string;
}
export type ListOfStrings = string[];
export interface CreateModelManifestRequest {
    name: string;
    description?: string | undefined;
    nodes: string[];
    signalCatalogArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateModelManifestResponse {
    name: string;
    arn: string;
}
export type Message = string;
export interface Branch {
    fullyQualifiedName: string;
    description?: string | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
}
export type NodeDataType = "INT8" | "UINT8" | "INT16" | "UINT16" | "INT32" | "UINT32" | "INT64" | "UINT64" | "BOOLEAN" | "FLOAT" | "DOUBLE" | "STRING" | "UNIX_TIMESTAMP" | "INT8_ARRAY" | "UINT8_ARRAY" | "INT16_ARRAY" | "UINT16_ARRAY" | "INT32_ARRAY" | "UINT32_ARRAY" | "INT64_ARRAY" | "UINT64_ARRAY" | "BOOLEAN_ARRAY" | "FLOAT_ARRAY" | "DOUBLE_ARRAY" | "STRING_ARRAY" | "UNIX_TIMESTAMP_ARRAY" | "UNKNOWN" | "STRUCT" | "STRUCT_ARRAY" | (string & {});
export interface Sensor {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string | undefined;
    unit?: string | undefined;
    allowedValues?: string[] | undefined;
    min?: number | undefined;
    max?: number | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
    structFullyQualifiedName?: string | undefined;
}
export interface Actuator {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string | undefined;
    unit?: string | undefined;
    allowedValues?: string[] | undefined;
    min?: number | undefined;
    max?: number | undefined;
    assignedValue?: string | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
    structFullyQualifiedName?: string | undefined;
}
export interface Attribute {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string | undefined;
    unit?: string | undefined;
    allowedValues?: string[] | undefined;
    min?: number | undefined;
    max?: number | undefined;
    assignedValue?: string | undefined;
    defaultValue?: string | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
}
export interface CustomStruct {
    fullyQualifiedName: string;
    description?: string | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
}
export type NodeDataEncoding = "BINARY" | "TYPED" | (string & {});
export interface CustomProperty {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    dataEncoding?: NodeDataEncoding | undefined;
    description?: string | undefined;
    deprecationMessage?: string | undefined;
    comment?: string | undefined;
    structFullyQualifiedName?: string | undefined;
}
export type Node = {
    branch: Branch;
    sensor?: undefined;
    actuator?: undefined;
    attribute?: undefined;
    struct?: undefined;
    property?: undefined;
} | {
    branch?: undefined;
    sensor: Sensor;
    actuator?: undefined;
    attribute?: undefined;
    struct?: undefined;
    property?: undefined;
} | {
    branch?: undefined;
    sensor?: undefined;
    actuator: Actuator;
    attribute?: undefined;
    struct?: undefined;
    property?: undefined;
} | {
    branch?: undefined;
    sensor?: undefined;
    actuator?: undefined;
    attribute: Attribute;
    struct?: undefined;
    property?: undefined;
} | {
    branch?: undefined;
    sensor?: undefined;
    actuator?: undefined;
    attribute?: undefined;
    struct: CustomStruct;
    property?: undefined;
} | {
    branch?: undefined;
    sensor?: undefined;
    actuator?: undefined;
    attribute?: undefined;
    struct?: undefined;
    property: CustomProperty;
};
export type Nodes = Node[];
export interface CreateSignalCatalogRequest {
    name: string;
    description?: string | undefined;
    nodes?: Node[] | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateSignalCatalogResponse {
    name: string;
    arn: string;
}
export type StateTemplateProperties = string[];
export type StateTemplateDataExtraDimensionNodePathList = string[];
export type StateTemplateMetadataExtraDimensionNodePathList = string[];
export interface CreateStateTemplateRequest {
    name: string;
    description?: string | undefined;
    signalCatalogArn: string;
    stateTemplateProperties: string[];
    dataExtraDimensions?: string[] | undefined;
    metadataExtraDimensions?: string[] | undefined;
    tags?: Tag[] | undefined;
}
export type ResourceUniqueId = string;
export interface CreateStateTemplateResponse {
    name?: string | undefined;
    arn?: string | undefined;
    id?: string | undefined;
}
export interface CreateVehicleRequest {
    vehicleName: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    associationBehavior?: VehicleAssociationBehavior | undefined;
    tags?: Tag[] | undefined;
    stateTemplates?: StateTemplateAssociation[] | undefined;
}
export interface CreateVehicleResponse {
    vehicleName?: string | undefined;
    arn?: string | undefined;
    thingArn?: string | undefined;
}
export interface DeleteCampaignRequest {
    name: string;
}
export interface DeleteCampaignResponse {
    name?: string | undefined;
    arn?: string | undefined;
}
export interface DeleteDecoderManifestRequest {
    name: string;
}
export interface DeleteDecoderManifestResponse {
    name: string;
    arn: string;
}
export interface DeleteFleetRequest {
    fleetId: string;
}
export interface DeleteFleetResponse {
    id?: string | undefined;
    arn?: string | undefined;
}
export interface DeleteModelManifestRequest {
    name: string;
}
export interface DeleteModelManifestResponse {
    name: string;
    arn: string;
}
export interface DeleteSignalCatalogRequest {
    name: string;
}
export interface DeleteSignalCatalogResponse {
    name: string;
    arn: string;
}
export interface DeleteStateTemplateRequest {
    identifier: string;
}
export interface DeleteStateTemplateResponse {
    name?: string | undefined;
    arn?: string | undefined;
    id?: string | undefined;
}
export interface DeleteVehicleRequest {
    vehicleName: string;
}
export interface DeleteVehicleResponse {
    vehicleName: string;
    arn: string;
}
export interface DisassociateVehicleFleetRequest {
    vehicleName: string;
    fleetId: string;
}
export interface DisassociateVehicleFleetResponse {
}
export interface GetCampaignRequest {
    name: string;
}
export type CampaignStatus = "CREATING" | "WAITING_FOR_APPROVAL" | "RUNNING" | "SUSPENDED" | (string & {});
export interface GetCampaignResponse {
    name?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    signalCatalogArn?: string | undefined;
    targetArn?: string | undefined;
    status?: CampaignStatus | undefined;
    startTime?: Date | undefined;
    expiryTime?: Date | undefined;
    postTriggerCollectionDuration?: number | undefined;
    diagnosticsMode?: DiagnosticsMode | undefined;
    spoolingMode?: SpoolingMode | undefined;
    compression?: Compression | undefined;
    priority?: number | undefined;
    signalsToCollect?: SignalInformation[] | undefined;
    collectionScheme?: CollectionScheme | undefined;
    dataExtraDimensions?: string[] | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
    dataDestinationConfigs?: DataDestinationConfig[] | undefined;
    dataPartitions?: DataPartition[] | undefined;
    signalsToFetch?: SignalFetchInformation[] | undefined;
}
export interface GetDecoderManifestRequest {
    name: string;
}
export type ManifestStatus = "ACTIVE" | "DRAFT" | "INVALID" | "VALIDATING" | (string & {});
export interface GetDecoderManifestResponse {
    name: string;
    arn: string;
    description?: string | undefined;
    modelManifestArn?: string | undefined;
    status?: ManifestStatus | undefined;
    creationTime: Date;
    lastModificationTime: Date;
    message?: string | undefined;
}
export interface GetEncryptionConfigurationRequest {
}
export type EncryptionStatus = "PENDING" | "SUCCESS" | "FAILURE" | (string & {});
export type EncryptionType = "KMS_BASED_ENCRYPTION" | "FLEETWISE_DEFAULT_ENCRYPTION" | (string & {});
export type ErrorMessage = string;
export interface GetEncryptionConfigurationResponse {
    kmsKeyId?: string | undefined;
    encryptionStatus: EncryptionStatus;
    encryptionType: EncryptionType;
    errorMessage?: string | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
}
export interface GetFleetRequest {
    fleetId: string;
}
export interface GetFleetResponse {
    id: string;
    arn: string;
    description?: string | undefined;
    signalCatalogArn: string;
    creationTime: Date;
    lastModificationTime: Date;
}
export interface GetLoggingOptionsRequest {
}
export type LogType = "OFF" | "ERROR" | (string & {});
export type CloudWatchLogGroupName = string;
export interface CloudWatchLogDeliveryOptions {
    logType: LogType;
    logGroupName?: string | undefined;
}
export interface GetLoggingOptionsResponse {
    cloudWatchLogDelivery: CloudWatchLogDeliveryOptions;
}
export interface GetModelManifestRequest {
    name: string;
}
export interface GetModelManifestResponse {
    name: string;
    arn: string;
    description?: string | undefined;
    signalCatalogArn?: string | undefined;
    status?: ManifestStatus | undefined;
    creationTime: Date;
    lastModificationTime: Date;
}
export interface GetRegisterAccountStatusRequest {
}
export type CustomerAccountId = string;
export type RegistrationStatus = "REGISTRATION_PENDING" | "REGISTRATION_SUCCESS" | "REGISTRATION_FAILURE" | (string & {});
export type TimestreamDatabaseName = string;
export type TimestreamTableName = string;
export interface TimestreamRegistrationResponse {
    timestreamDatabaseName: string;
    timestreamTableName: string;
    timestreamDatabaseArn?: string | undefined;
    timestreamTableArn?: string | undefined;
    registrationStatus: RegistrationStatus;
    errorMessage?: string | undefined;
}
export interface IamRegistrationResponse {
    roleArn: string;
    registrationStatus: RegistrationStatus;
    errorMessage?: string | undefined;
}
export interface GetRegisterAccountStatusResponse {
    customerAccountId: string;
    accountStatus: RegistrationStatus;
    timestreamRegistrationResponse?: TimestreamRegistrationResponse | undefined;
    iamRegistrationResponse: IamRegistrationResponse;
    creationTime: Date;
    lastModificationTime: Date;
}
export interface GetSignalCatalogRequest {
    name: string;
}
export interface NodeCounts {
    totalNodes?: number | undefined;
    totalBranches?: number | undefined;
    totalSensors?: number | undefined;
    totalAttributes?: number | undefined;
    totalActuators?: number | undefined;
    totalStructs?: number | undefined;
    totalProperties?: number | undefined;
}
export interface GetSignalCatalogResponse {
    name: string;
    arn: string;
    description?: string | undefined;
    nodeCounts?: NodeCounts | undefined;
    creationTime: Date;
    lastModificationTime: Date;
}
export interface GetStateTemplateRequest {
    identifier: string;
}
export interface GetStateTemplateResponse {
    name?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    signalCatalogArn?: string | undefined;
    stateTemplateProperties?: string[] | undefined;
    dataExtraDimensions?: string[] | undefined;
    metadataExtraDimensions?: string[] | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
    id?: string | undefined;
}
export interface GetVehicleRequest {
    vehicleName: string;
}
export interface GetVehicleResponse {
    vehicleName?: string | undefined;
    arn?: string | undefined;
    modelManifestArn?: string | undefined;
    decoderManifestArn?: string | undefined;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    stateTemplates?: StateTemplateAssociation[] | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface GetVehicleStatusRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    vehicleName: string;
}
export type VehicleState = "CREATED" | "READY" | "HEALTHY" | "SUSPENDED" | "DELETING" | "READY_FOR_CHECKIN" | (string & {});
export interface VehicleStatus {
    campaignName?: string | undefined;
    vehicleName?: string | undefined;
    status?: VehicleState | undefined;
}
export type VehicleStatusList = VehicleStatus[];
export interface GetVehicleStatusResponse {
    campaigns?: VehicleStatus[] | undefined;
    nextToken?: string | undefined;
}
export type NetworkFileBlob = Uint8Array;
export type NetworkFilesList = Uint8Array[];
export type ModelSignalsMap = {
    [key: string]: string | undefined;
};
export interface CanDbcDefinition {
    networkInterface: string;
    canDbcFiles: Uint8Array[];
    signalsMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkFileDefinition = {
    canDbc: CanDbcDefinition;
};
export type NetworkFileDefinitions = NetworkFileDefinition[];
export interface ImportDecoderManifestRequest {
    name: string;
    networkFileDefinitions: NetworkFileDefinition[];
}
export interface ImportDecoderManifestResponse {
    name: string;
    arn: string;
}
export type FormattedVss = {
    vssJson: string;
};
export interface ImportSignalCatalogRequest {
    name: string;
    description?: string | undefined;
    vss?: FormattedVss | undefined;
    tags?: Tag[] | undefined;
}
export interface ImportSignalCatalogResponse {
    name: string;
    arn: string;
}
export type StatusStr = string;
export type ListResponseScope = "METADATA_ONLY" | (string & {});
export interface ListCampaignsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    status?: string | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface CampaignSummary {
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    signalCatalogArn?: string | undefined;
    targetArn?: string | undefined;
    status?: CampaignStatus | undefined;
    creationTime: Date;
    lastModificationTime: Date;
}
export type CampaignSummaries = CampaignSummary[];
export interface ListCampaignsResponse {
    campaignSummaries?: CampaignSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDecoderManifestNetworkInterfacesRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListDecoderManifestNetworkInterfacesResponse {
    networkInterfaces?: NetworkInterface[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDecoderManifestsRequest {
    modelManifestArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface DecoderManifestSummary {
    name?: string | undefined;
    arn?: string | undefined;
    modelManifestArn?: string | undefined;
    description?: string | undefined;
    status?: ManifestStatus | undefined;
    creationTime: Date;
    lastModificationTime: Date;
    message?: string | undefined;
}
export type DecoderManifestSummaries = DecoderManifestSummary[];
export interface ListDecoderManifestsResponse {
    summaries?: DecoderManifestSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDecoderManifestSignalsRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListDecoderManifestSignalsResponse {
    signalDecoders?: SignalDecoder[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFleetsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface FleetSummary {
    id: string;
    arn: string;
    description?: string | undefined;
    signalCatalogArn: string;
    creationTime: Date;
    lastModificationTime?: Date | undefined;
}
export type FleetSummaries = FleetSummary[];
export interface ListFleetsResponse {
    fleetSummaries?: FleetSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFleetsForVehicleRequest {
    vehicleName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Fleets = string[];
export interface ListFleetsForVehicleResponse {
    fleets?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListModelManifestNodesRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListModelManifestNodesResponse {
    nodes?: Node[] | undefined;
    nextToken?: string | undefined;
}
export interface ListModelManifestsRequest {
    signalCatalogArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface ModelManifestSummary {
    name?: string | undefined;
    arn?: string | undefined;
    signalCatalogArn?: string | undefined;
    description?: string | undefined;
    status?: ManifestStatus | undefined;
    creationTime: Date;
    lastModificationTime: Date;
}
export type ModelManifestSummaries = ModelManifestSummary[];
export interface ListModelManifestsResponse {
    summaries?: ModelManifestSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SignalNodeType = "SENSOR" | "ACTUATOR" | "ATTRIBUTE" | "BRANCH" | "CUSTOM_STRUCT" | "CUSTOM_PROPERTY" | (string & {});
export interface ListSignalCatalogNodesRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    signalNodeType?: SignalNodeType | undefined;
}
export interface ListSignalCatalogNodesResponse {
    nodes?: Node[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSignalCatalogsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SignalCatalogSummary {
    name?: string | undefined;
    arn?: string | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
}
export type SignalCatalogSummaries = SignalCatalogSummary[];
export interface ListSignalCatalogsResponse {
    summaries?: SignalCatalogSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListStateTemplatesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface StateTemplateSummary {
    name?: string | undefined;
    arn?: string | undefined;
    signalCatalogArn?: string | undefined;
    description?: string | undefined;
    creationTime?: Date | undefined;
    lastModificationTime?: Date | undefined;
    id?: string | undefined;
}
export type StateTemplateSummaries = StateTemplateSummary[];
export interface ListStateTemplatesResponse {
    summaries?: StateTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type AttributeNamesList = string[];
export type AttributeValuesList = string[];
export type ListVehiclesMaxResults = number;
export interface ListVehiclesRequest {
    modelManifestArn?: string | undefined;
    attributeNames?: string[] | undefined;
    attributeValues?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    listResponseScope?: ListResponseScope | undefined;
}
export interface VehicleSummary {
    vehicleName: string;
    arn: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    creationTime: Date;
    lastModificationTime: Date;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VehicleSummaries = VehicleSummary[];
export interface ListVehiclesResponse {
    vehicleSummaries?: VehicleSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListVehiclesInFleetRequest {
    fleetId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Vehicles = string[];
export interface ListVehiclesInFleetResponse {
    vehicles?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface PutEncryptionConfigurationRequest {
    kmsKeyId?: string | undefined;
    encryptionType: EncryptionType;
}
export interface PutEncryptionConfigurationResponse {
    kmsKeyId?: string | undefined;
    encryptionStatus: EncryptionStatus;
    encryptionType: EncryptionType;
}
export interface PutLoggingOptionsRequest {
    cloudWatchLogDelivery: CloudWatchLogDeliveryOptions;
}
export interface PutLoggingOptionsResponse {
}
export interface TimestreamResources {
    timestreamDatabaseName: string;
    timestreamTableName: string;
}
export interface IamResources {
    roleArn: string;
}
export interface RegisterAccountRequest {
    timestreamResources?: TimestreamResources | undefined;
    iamResources?: IamResources | undefined;
}
export interface RegisterAccountResponse {
    registerAccountStatus: RegistrationStatus;
    timestreamResources?: TimestreamResources | undefined;
    iamResources: IamResources;
    creationTime: Date;
    lastModificationTime: Date;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type UpdateCampaignAction = "APPROVE" | "SUSPEND" | "RESUME" | "UPDATE" | (string & {});
export interface UpdateCampaignRequest {
    name: string;
    description?: string | undefined;
    dataExtraDimensions?: string[] | undefined;
    action: UpdateCampaignAction;
}
export interface UpdateCampaignResponse {
    arn?: string | undefined;
    name?: string | undefined;
    status?: CampaignStatus | undefined;
}
export type Fqns = string[];
export type InterfaceIds = string[];
export interface UpdateDecoderManifestRequest {
    name: string;
    description?: string | undefined;
    signalDecodersToAdd?: SignalDecoder[] | undefined;
    signalDecodersToUpdate?: SignalDecoder[] | undefined;
    signalDecodersToRemove?: string[] | undefined;
    networkInterfacesToAdd?: NetworkInterface[] | undefined;
    networkInterfacesToUpdate?: NetworkInterface[] | undefined;
    networkInterfacesToRemove?: string[] | undefined;
    status?: ManifestStatus | undefined;
    defaultForUnmappedSignals?: DefaultForUnmappedSignalsType | undefined;
}
export interface UpdateDecoderManifestResponse {
    name: string;
    arn: string;
}
export interface UpdateFleetRequest {
    fleetId: string;
    description?: string | undefined;
}
export interface UpdateFleetResponse {
    id?: string | undefined;
    arn?: string | undefined;
}
export type NodePaths = string[];
export interface UpdateModelManifestRequest {
    name: string;
    description?: string | undefined;
    nodesToAdd?: string[] | undefined;
    nodesToRemove?: string[] | undefined;
    status?: ManifestStatus | undefined;
}
export interface UpdateModelManifestResponse {
    name: string;
    arn: string;
}
export interface UpdateSignalCatalogRequest {
    name: string;
    description?: string | undefined;
    nodesToAdd?: Node[] | undefined;
    nodesToUpdate?: Node[] | undefined;
    nodesToRemove?: string[] | undefined;
}
export interface UpdateSignalCatalogResponse {
    name: string;
    arn: string;
}
export interface UpdateStateTemplateRequest {
    identifier: string;
    description?: string | undefined;
    stateTemplatePropertiesToAdd?: string[] | undefined;
    stateTemplatePropertiesToRemove?: string[] | undefined;
    dataExtraDimensions?: string[] | undefined;
    metadataExtraDimensions?: string[] | undefined;
}
export interface UpdateStateTemplateResponse {
    name?: string | undefined;
    arn?: string | undefined;
    id?: string | undefined;
}
export interface UpdateVehicleRequest {
    vehicleName: string;
    modelManifestArn?: string | undefined;
    decoderManifestArn?: string | undefined;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    attributeUpdateMode?: UpdateMode | undefined;
    stateTemplatesToAdd?: StateTemplateAssociation[] | undefined;
    stateTemplatesToRemove?: string[] | undefined;
    stateTemplatesToUpdate?: StateTemplateAssociation[] | undefined;
}
export interface UpdateVehicleResponse {
    vehicleName?: string | undefined;
    arn?: string | undefined;
}
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type SignalDecoderFailureReason = "DUPLICATE_SIGNAL" | "CONFLICTING_SIGNAL" | "SIGNAL_TO_ADD_ALREADY_EXISTS" | "SIGNAL_NOT_ASSOCIATED_WITH_NETWORK_INTERFACE" | "NETWORK_INTERFACE_TYPE_INCOMPATIBLE_WITH_SIGNAL_DECODER_TYPE" | "SIGNAL_NOT_IN_MODEL" | "CAN_SIGNAL_INFO_IS_NULL" | "OBD_SIGNAL_INFO_IS_NULL" | "NO_DECODER_INFO_FOR_SIGNAL_IN_MODEL" | "MESSAGE_SIGNAL_INFO_IS_NULL" | "SIGNAL_DECODER_TYPE_INCOMPATIBLE_WITH_MESSAGE_SIGNAL_TYPE" | "STRUCT_SIZE_MISMATCH" | "NO_SIGNAL_IN_CATALOG_FOR_DECODER_SIGNAL" | "SIGNAL_DECODER_INCOMPATIBLE_WITH_SIGNAL_CATALOG" | "EMPTY_MESSAGE_SIGNAL" | "CUSTOM_DECODING_SIGNAL_INFO_IS_NULL" | (string & {});
export interface InvalidSignalDecoder {
    name?: string | undefined;
    reason?: SignalDecoderFailureReason | undefined;
    hint?: string | undefined;
}
export type InvalidSignalDecoders = InvalidSignalDecoder[];
export type NetworkInterfaceFailureReason = "DUPLICATE_NETWORK_INTERFACE" | "CONFLICTING_NETWORK_INTERFACE" | "NETWORK_INTERFACE_TO_ADD_ALREADY_EXISTS" | "CAN_NETWORK_INTERFACE_INFO_IS_NULL" | "OBD_NETWORK_INTERFACE_INFO_IS_NULL" | "NETWORK_INTERFACE_TO_REMOVE_ASSOCIATED_WITH_SIGNALS" | "VEHICLE_MIDDLEWARE_NETWORK_INTERFACE_INFO_IS_NULL" | "CUSTOM_DECODING_SIGNAL_NETWORK_INTERFACE_INFO_IS_NULL" | (string & {});
export interface InvalidNetworkInterface {
    interfaceId?: string | undefined;
    reason?: NetworkInterfaceFailureReason | undefined;
}
export type InvalidNetworkInterfaces = InvalidNetworkInterface[];
export interface InvalidSignal {
    name?: string | undefined;
    reason?: string | undefined;
}
export type InvalidSignals = InvalidSignal[];
export type AssociateVehicleFleetError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds, or associates, a vehicle with a fleet.
 */
export declare const associateVehicleFleet: API.OperationMethod<AssociateVehicleFleetRequest & RegionInput, AssociateVehicleFleetResponse, AssociateVehicleFleetError, Credentials | HttpClient.HttpClient>;
export type BatchCreateVehicleError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a group, or batch, of vehicles.
 *
 * You must specify a decoder manifest and a vehicle model (model manifest) for each
 * vehicle.
 *
 * For more information, see Create multiple
 * vehicles (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const batchCreateVehicle: API.OperationMethod<BatchCreateVehicleRequest & RegionInput, BatchCreateVehicleResponse, BatchCreateVehicleError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateVehicleError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a group, or batch, of vehicles.
 *
 * You must specify a decoder manifest and a vehicle model (model manifest) for each
 * vehicle.
 *
 * For more information, see Update multiple
 * vehicles (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const batchUpdateVehicle: API.OperationMethod<BatchUpdateVehicleRequest & RegionInput, BatchUpdateVehicleResponse, BatchUpdateVehicleError, Credentials | HttpClient.HttpClient>;
export type CreateCampaignError = AccessDeniedException | ConflictException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates an orchestration of data collection rules. The Amazon Web Services IoT FleetWise Edge Agent software
 * running in vehicles uses campaigns to decide how to collect and transfer data to the
 * cloud. You create campaigns in the cloud. After you or your team approve campaigns,
 * Amazon Web Services IoT FleetWise automatically deploys them to vehicles.
 *
 * For more information, see Collect and transfer data
 * with campaigns in the *Amazon Web Services IoT FleetWise Developer Guide*.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest & RegionInput, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type CreateDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates the decoder manifest associated with a model manifest. To create a decoder
 * manifest, the following must be true:
 *
 * - Every signal decoder has a unique name.
 *
 * - Each signal decoder is associated with a network interface.
 *
 * - Each network interface has a unique ID.
 *
 * - The signal decoders are specified in the model manifest.
 */
export declare const createDecoderManifest: API.OperationMethod<CreateDecoderManifestRequest & RegionInput, CreateDecoderManifestResponse, CreateDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type CreateFleetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a fleet that represents a group of vehicles.
 *
 * You must create both a signal catalog and vehicles before you can create a fleet.
 *
 * For more information, see Fleets in the
 * *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createFleet: API.OperationMethod<CreateFleetRequest & RegionInput, CreateFleetResponse, CreateFleetError, Credentials | HttpClient.HttpClient>;
export type CreateModelManifestError = AccessDeniedException | ConflictException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates a vehicle model (model manifest) that specifies signals (attributes,
 * branches, sensors, and actuators).
 *
 * For more information, see Vehicle models
 * in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createModelManifest: API.OperationMethod<CreateModelManifestRequest & RegionInput, CreateModelManifestResponse, CreateModelManifestError, Credentials | HttpClient.HttpClient>;
export type CreateSignalCatalogError = AccessDeniedException | ConflictException | InvalidNodeException | InvalidSignalsException | LimitExceededException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates a collection of standardized signals that can be reused to create vehicle
 * models.
 */
export declare const createSignalCatalog: API.OperationMethod<CreateSignalCatalogRequest & RegionInput, CreateSignalCatalogResponse, CreateSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateStateTemplateError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a state template. State templates contain state properties, which are signals that belong to a signal catalog that is synchronized between the Amazon Web Services IoT FleetWise Edge and the Amazon Web Services Cloud.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createStateTemplate: API.OperationMethod<CreateStateTemplateRequest & RegionInput, CreateStateTemplateResponse, CreateStateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateVehicleError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a vehicle, which is an instance of a vehicle model (model manifest). Vehicles
 * created from the same vehicle model consist of the same signals inherited from the
 * vehicle model.
 *
 * If you have an existing Amazon Web Services IoT thing, you can use Amazon Web Services IoT FleetWise to create a
 * vehicle and collect data from your thing.
 *
 * For more information, see Create a vehicle
 * (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createVehicle: API.OperationMethod<CreateVehicleRequest & RegionInput, CreateVehicleResponse, CreateVehicleError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Deletes a data collection campaign. Deleting a campaign suspends all data collection
 * and removes it from any vehicles.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest & RegionInput, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteDecoderManifestError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a decoder manifest. You can't delete a decoder manifest if it has vehicles
 * associated with it.
 */
export declare const deleteDecoderManifest: API.OperationMethod<DeleteDecoderManifestRequest & RegionInput, DeleteDecoderManifestResponse, DeleteDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a fleet. Before you delete a fleet, all vehicles must be
 * dissociated from the fleet. For more information, see Delete a fleet (AWS
 * CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const deleteFleet: API.OperationMethod<DeleteFleetRequest & RegionInput, DeleteFleetResponse, DeleteFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteModelManifestError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a vehicle model (model manifest).
 */
export declare const deleteModelManifest: API.OperationMethod<DeleteModelManifestRequest & RegionInput, DeleteModelManifestResponse, DeleteModelManifestError, Credentials | HttpClient.HttpClient>;
export type DeleteSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a signal catalog.
 */
export declare const deleteSignalCatalog: API.OperationMethod<DeleteSignalCatalogRequest & RegionInput, DeleteSignalCatalogResponse, DeleteSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteStateTemplateError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a state template.
 */
export declare const deleteStateTemplate: API.OperationMethod<DeleteStateTemplateRequest & RegionInput, DeleteStateTemplateResponse, DeleteStateTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteVehicleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a vehicle and removes it from any campaigns.
 */
export declare const deleteVehicle: API.OperationMethod<DeleteVehicleRequest & RegionInput, DeleteVehicleResponse, DeleteVehicleError, Credentials | HttpClient.HttpClient>;
export type DisassociateVehicleFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes, or disassociates, a vehicle from a fleet. Disassociating a vehicle from a
 * fleet doesn't delete the vehicle.
 */
export declare const disassociateVehicleFleet: API.OperationMethod<DisassociateVehicleFleetRequest & RegionInput, DisassociateVehicleFleetResponse, DisassociateVehicleFleetError, Credentials | HttpClient.HttpClient>;
export type GetCampaignError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Retrieves information about a campaign.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const getCampaign: API.OperationMethod<GetCampaignRequest & RegionInput, GetCampaignResponse, GetCampaignError, Credentials | HttpClient.HttpClient>;
export type GetDecoderManifestError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Retrieves information about a created decoder manifest.
 */
export declare const getDecoderManifest: API.OperationMethod<GetDecoderManifestRequest & RegionInput, GetDecoderManifestResponse, GetDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type GetEncryptionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the encryption configuration for resources and data in Amazon Web Services IoT FleetWise.
 */
export declare const getEncryptionConfiguration: API.OperationMethod<GetEncryptionConfigurationRequest & RegionInput, GetEncryptionConfigurationResponse, GetEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a fleet.
 */
export declare const getFleet: API.OperationMethod<GetFleetRequest & RegionInput, GetFleetResponse, GetFleetError, Credentials | HttpClient.HttpClient>;
export type GetLoggingOptionsError = AccessDeniedException | ThrottlingException | InternalServerException | CommonErrors;
/**
 * Retrieves the logging options.
 */
export declare const getLoggingOptions: API.OperationMethod<GetLoggingOptionsRequest & RegionInput, GetLoggingOptionsResponse, GetLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type GetModelManifestError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Retrieves information about a vehicle model (model manifest).
 */
export declare const getModelManifest: API.OperationMethod<GetModelManifestRequest & RegionInput, GetModelManifestResponse, GetModelManifestError, Credentials | HttpClient.HttpClient>;
export type GetRegisterAccountStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the status of registering your Amazon Web Services account, IAM, and
 * Amazon Timestream resources so that Amazon Web Services IoT FleetWise can transfer your vehicle data to the Amazon Web Services
 * Cloud.
 *
 * For more information, including step-by-step procedures, see Setting up Amazon Web Services IoT FleetWise.
 *
 * This API operation doesn't require input parameters.
 */
export declare const getRegisterAccountStatus: API.OperationMethod<GetRegisterAccountStatusRequest & RegionInput, GetRegisterAccountStatusResponse, GetRegisterAccountStatusError, Credentials | HttpClient.HttpClient>;
export type GetSignalCatalogError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Retrieves information about a signal catalog.
 */
export declare const getSignalCatalog: API.OperationMethod<GetSignalCatalogRequest & RegionInput, GetSignalCatalogResponse, GetSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type GetStateTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a state template.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const getStateTemplate: API.OperationMethod<GetStateTemplateRequest & RegionInput, GetStateTemplateResponse, GetStateTemplateError, Credentials | HttpClient.HttpClient>;
export type GetVehicleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a vehicle.
 */
export declare const getVehicle: API.OperationMethod<GetVehicleRequest & RegionInput, GetVehicleResponse, GetVehicleError, Credentials | HttpClient.HttpClient>;
export type GetVehicleStatusError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Retrieves information about the status of campaigns, decoder manifests, or state templates
 * associated with a vehicle.
 */
export declare const getVehicleStatus: API.PaginatedOperationMethod<GetVehicleStatusRequest & RegionInput, GetVehicleStatusResponse, GetVehicleStatusError, Credentials | HttpClient.HttpClient, VehicleStatus>;
export type ImportDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | InvalidSignalsException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates a decoder manifest using your existing CAN DBC file from your local device.
 *
 * The CAN signal name must be unique and not repeated across CAN message definitions in a .dbc file.
 */
export declare const importDecoderManifest: API.OperationMethod<ImportDecoderManifestRequest & RegionInput, ImportDecoderManifestResponse, ImportDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type ImportSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a signal catalog using your existing VSS formatted content from your local
 * device.
 */
export declare const importSignalCatalog: API.OperationMethod<ImportSignalCatalogRequest & RegionInput, ImportSignalCatalogResponse, ImportSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Lists information about created campaigns.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest & RegionInput, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListDecoderManifestNetworkInterfacesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the network interfaces specified in a decoder manifest.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifestNetworkInterfaces: API.PaginatedOperationMethod<ListDecoderManifestNetworkInterfacesRequest & RegionInput, ListDecoderManifestNetworkInterfacesResponse, ListDecoderManifestNetworkInterfacesError, Credentials | HttpClient.HttpClient, NetworkInterface>;
export type ListDecoderManifestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists decoder manifests.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifests: API.PaginatedOperationMethod<ListDecoderManifestsRequest & RegionInput, ListDecoderManifestsResponse, ListDecoderManifestsError, Credentials | HttpClient.HttpClient, DecoderManifestSummary>;
export type ListDecoderManifestSignalsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A list of information about signal decoders specified in a decoder manifest.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifestSignals: API.PaginatedOperationMethod<ListDecoderManifestSignalsRequest & RegionInput, ListDecoderManifestSignalsResponse, ListDecoderManifestSignalsError, Credentials | HttpClient.HttpClient, SignalDecoder>;
export type ListFleetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information for each created fleet in an Amazon Web Services account.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listFleets: API.PaginatedOperationMethod<ListFleetsRequest & RegionInput, ListFleetsResponse, ListFleetsError, Credentials | HttpClient.HttpClient, FleetSummary>;
export type ListFleetsForVehicleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of IDs for all fleets that the vehicle is associated with.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listFleetsForVehicle: API.PaginatedOperationMethod<ListFleetsForVehicleRequest & RegionInput, ListFleetsForVehicleResponse, ListFleetsForVehicleError, Credentials | HttpClient.HttpClient, FleetId>;
export type ListModelManifestNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about nodes specified in a vehicle model (model manifest).
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listModelManifestNodes: API.PaginatedOperationMethod<ListModelManifestNodesRequest & RegionInput, ListModelManifestNodesResponse, ListModelManifestNodesError, Credentials | HttpClient.HttpClient, Node>;
export type ListModelManifestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of vehicle models (model manifests).
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listModelManifests: API.PaginatedOperationMethod<ListModelManifestsRequest & RegionInput, ListModelManifestsResponse, ListModelManifestsError, Credentials | HttpClient.HttpClient, ModelManifestSummary>;
export type ListSignalCatalogNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists of information about the signals (nodes) specified in a signal catalog.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listSignalCatalogNodes: API.PaginatedOperationMethod<ListSignalCatalogNodesRequest & RegionInput, ListSignalCatalogNodesResponse, ListSignalCatalogNodesError, Credentials | HttpClient.HttpClient, Node>;
export type ListSignalCatalogsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the created signal catalogs in an Amazon Web Services account.
 *
 * You can use to list information about
 * each signal (node) specified in a signal catalog.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listSignalCatalogs: API.PaginatedOperationMethod<ListSignalCatalogsRequest & RegionInput, ListSignalCatalogsResponse, ListSignalCatalogsError, Credentials | HttpClient.HttpClient, SignalCatalogSummary>;
export type ListStateTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about created state templates.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const listStateTemplates: API.PaginatedOperationMethod<ListStateTemplatesRequest & RegionInput, ListStateTemplatesResponse, ListStateTemplatesError, Credentials | HttpClient.HttpClient, StateTemplateSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags (metadata) you have assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVehiclesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of summaries of created vehicles.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listVehicles: API.PaginatedOperationMethod<ListVehiclesRequest & RegionInput, ListVehiclesResponse, ListVehiclesError, Credentials | HttpClient.HttpClient, VehicleSummary>;
export type ListVehiclesInFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of summaries of all vehicles associated with a fleet.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listVehiclesInFleet: API.PaginatedOperationMethod<ListVehiclesInFleetRequest & RegionInput, ListVehiclesInFleetResponse, ListVehiclesInFleetError, Credentials | HttpClient.HttpClient, VehicleName>;
export type PutEncryptionConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the encryption configuration. Amazon Web Services IoT FleetWise can encrypt your data and
 * resources using an Amazon Web Services managed key. Or, you can use a KMS key that you own and
 * manage. For more information, see Data
 * encryption in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const putEncryptionConfiguration: API.OperationMethod<PutEncryptionConfigurationRequest & RegionInput, PutEncryptionConfigurationResponse, PutEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Creates or updates the logging option.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest & RegionInput, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type RegisterAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API operation contains deprecated parameters. Register your account again
 * without the Timestream resources parameter so that Amazon Web Services IoT FleetWise can remove the Timestream
 * metadata stored. You should then pass the data destination into the CreateCampaign API operation.
 *
 * You must delete any existing campaigns that include an empty data destination
 * before you register your account again. For more information, see the DeleteCampaign API operation.
 *
 * If you want to delete the Timestream inline policy from the service-linked role, such
 * as to mitigate an overly permissive policy, you must first delete any existing
 * campaigns. Then delete the service-linked role and register your account again to
 * enable CloudWatch metrics. For more information, see DeleteServiceLinkedRole in the Identity and Access Management API
 * Reference.
 *
 * Registers your Amazon Web Services account, IAM, and Amazon Timestream resources so Amazon Web Services IoT FleetWise can
 * transfer your vehicle data to the Amazon Web Services Cloud. For more information, including
 * step-by-step procedures, see Setting up
 * Amazon Web Services IoT FleetWise.
 *
 * An Amazon Web Services account is **not** the same thing as a
 * "user." An Amazon Web Services user is an identity that you create using Identity and Access Management (IAM) and
 * takes the form of either an IAM user or an IAM role, both
 * with credentials. A single Amazon Web Services account can, and typically does,
 * contain many users and roles.
 */
export declare const registerAccount: API.OperationMethod<RegisterAccountRequest & RegionInput, RegisterAccountResponse, RegisterAccountError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata which can be
 * used to manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the given tags (metadata) from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Updates a campaign.
 */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest & RegionInput, UpdateCampaignResponse, UpdateCampaignError, Credentials | HttpClient.HttpClient>;
export type UpdateDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | InternalServerException | CommonErrors;
/**
 * Updates a decoder manifest.
 *
 * A decoder manifest can only be updated when the status is `DRAFT`. Only
 * `ACTIVE` decoder manifests can be associated with vehicles.
 */
export declare const updateDecoderManifest: API.OperationMethod<UpdateDecoderManifestRequest & RegionInput, UpdateDecoderManifestResponse, UpdateDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type UpdateFleetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description of an existing fleet.
 */
export declare const updateFleet: API.OperationMethod<UpdateFleetRequest & RegionInput, UpdateFleetResponse, UpdateFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateModelManifestError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a vehicle model (model manifest). If created vehicles are associated with a
 * vehicle model, it can't be updated.
 */
export declare const updateModelManifest: API.OperationMethod<UpdateModelManifestRequest & RegionInput, UpdateModelManifestResponse, UpdateModelManifestError, Credentials | HttpClient.HttpClient>;
export type UpdateSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | InvalidNodeException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a signal catalog.
 */
export declare const updateSignalCatalog: API.OperationMethod<UpdateSignalCatalogRequest & RegionInput, UpdateSignalCatalogResponse, UpdateSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateStateTemplateError = AccessDeniedException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a state template.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const updateStateTemplate: API.OperationMethod<UpdateStateTemplateRequest & RegionInput, UpdateStateTemplateResponse, UpdateStateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateVehicleError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a vehicle.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const updateVehicle: API.OperationMethod<UpdateVehicleRequest & RegionInput, UpdateVehicleResponse, UpdateVehicleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotfleetwise.d.ts.map