/**
 * Buffers arbitrary text chunks and emits complete lines. `\r\n`, `\n` and a
 * bare `\r` all end a line; `\r` ends it immediately, so a `\n` that opens the
 * next chunk is skipped as the rest of a split `\r\n`. Call `flush` when the
 * source closes to emit a trailing partial line.
 */
export declare const makeLineBuffer: (onLine: (line: string) => void) => {
    push(chunk: string): void;
    flush(): void;
};
//# sourceMappingURL=LineBuffer.d.ts.map