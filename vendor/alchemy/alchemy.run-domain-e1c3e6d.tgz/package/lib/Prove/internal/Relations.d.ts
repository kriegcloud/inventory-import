import * as Effect from "effect/Effect";
import type * as Aggregate from "../../Aggregate.ts";
import type { Verdict } from "./Check.ts";
import * as Induction from "./Induction.ts";
import type { Interpreter } from "./Interpreter.ts";
import * as Paths from "./Paths.ts";
import type * as Smt from "./Smt.ts";
import * as Value from "./Value.ts";
type V = Value.V;
/** An aggregate a relation is over, with where it is written and the state a new instance has. */
export interface Over {
    readonly cls: Aggregate.Any;
    readonly definition: Paths.Definition;
    readonly initial: V;
}
/** A relation the prover reads: the aggregate behind each of its names, and the real function. */
export interface Relation {
    readonly name: string;
    readonly over: Readonly<Record<string, Over>>;
    readonly real: (on: Readonly<Record<string, Real>>) => boolean;
}
/** One real instance a relation is given. */
export interface Real {
    readonly id: unknown;
    readonly state: unknown;
}
/** A model's relations, and everything that can change what they are about. */
export interface Subject {
    /** The model's definition, where its relations are written. */
    readonly model: Paths.Definition;
    readonly relations: ReadonlyArray<Relation>;
    readonly decisions: ReadonlyArray<Induction.DecisionImpl>;
}
/** How far one relation is proved, and what the proof fails on when it does. */
export interface Row {
    readonly name: string;
    readonly verdict: Verdict;
    /** What breaks it, or what the prover could not read: a command, a decision, or a new model. */
    readonly by: string | undefined;
    /** The relations the proof takes to hold before each step: itself and the others still standing. */
    readonly assumes: ReadonlyArray<string>;
}
/**
 * How far each of a model's relations is proved. A proof of one takes every
 * relation to hold before each step, so they are proved together: one that
 * fails is taken out, and the rest are proved again without it, until those
 * left all stand.
 */
export declare const rows: (solver: Smt.Solver, interpreter: Interpreter, subject: Subject) => Effect.Effect<Row[], Smt.SolverError, never>;
export {};
//# sourceMappingURL=Relations.d.ts.map