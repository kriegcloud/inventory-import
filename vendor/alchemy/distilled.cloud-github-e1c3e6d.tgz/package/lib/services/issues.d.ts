import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The confidence level for this assignee choice. */
export type AddAssigneesRequestAssigneesItemCase1Confidence = "low" | "medium" | "high";
export interface AddAssigneesRequestAssigneesItemCase1 {
    /** The login of the user to assign. */
    login: string;
    /** Optional reasoning for adding this assignee. */
    rationale?: string | undefined;
    /** If `true`, the assignee is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this assignee choice. */
    confidence?: AddAssigneesRequestAssigneesItemCase1Confidence | (string & {}) | undefined;
}
export type AddAssigneesRequestAssigneesItem = string | AddAssigneesRequestAssigneesItemCase1;
/** Usernames of people to assign this issue to. _NOTE: Only users with push access can add assignees to an issue. Assignees are silently ignored otherwise._ */
export type AddAssigneesRequestAssigneesList = Array<AddAssigneesRequestAssigneesItem>;
export interface AddAssigneesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** Usernames of people to assign this issue to. _NOTE: Only users with push access can add assignees to an issue. Assignees are silently ignored otherwise._ */
    assignees?: AddAssigneesRequestAssigneesList | undefined;
}
/** The reason for the current state */
export type IssueStateReason = "completed" | "reopened" | "not_planned" | "duplicate";
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export interface IssueLabelsItemCase1 {
    id?: number | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    color?: string | null | undefined;
    default?: boolean | undefined;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by?: NullableSimpleUser | null | undefined;
}
export type IssueLabelsItem = string | IssueLabelsItemCase1;
/** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
export type IssueLabelsList = Array<IssueLabelsItem>;
export type IssueAssigneesList = Array<NullableSimpleUser>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: NullableSimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export interface IssuePullRequest {
    merged_at?: string | null | undefined;
    diff_url: string | null;
    html_url: string | null;
    patch_url: string | null;
    url: string | null;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = NullableSimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
export interface SubIssuesSummary {
    total: number;
    completed: number;
    percent_completed: number;
}
/** Context around who pinned an issue comment and when it was pinned. */
export interface NullablePinnedIssueComment {
    pinned_at: string;
    pinned_by: NullableSimpleUser | null;
}
/** Details about why an issue comment was minimized. */
export interface NullableIssueCommentMinimized {
    /** The reason the comment was minimized. */
    reason: string | null;
}
/** Comments provide a way for people to collaborate on an issue. */
export interface NullableIssueComment {
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: NullableSimpleUser | null;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association?: AuthorAssociation | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
export interface IssueDependenciesSummary {
    blocked_by: number;
    blocking: number;
    total_blocked_by: number;
    total_blocking: number;
}
/** The data type of the issue field */
export type IssueFieldValueDataType = "text" | "single_select" | "multi_select" | "number" | "date";
/** The value of the issue field */
export type IssueFieldValueValue = string | number | number;
/** Details about the selected option (only present for single_select fields) */
export interface IssueFieldValueSingleSelectOption {
    /** Unique identifier for the option. */
    id: number;
    /** The name of the option */
    name: string;
    /** The color of the option */
    color: string;
}
export type IssueFieldValueMultiSelectOptionsItem = IssueFieldValueSingleSelectOption;
/** Details about the selected options */
export type IssueFieldValueMultiSelectOptionsList = Array<IssueFieldValueSingleSelectOption>;
/** A value assigned to an issue field */
export interface IssueFieldValue {
    /** Unique identifier for the issue field. */
    issue_field_id: number;
    /** The human-readable name of the issue field. */
    issue_field_name?: string | undefined;
    node_id: string;
    /** The data type of the issue field */
    data_type: IssueFieldValueDataType;
    /** The value of the issue field */
    value: IssueFieldValueValue | null;
    /** Details about the selected option (only present for single_select fields) */
    single_select_option?: IssueFieldValueSingleSelectOption | null | undefined;
    /** Details about the selected options */
    multi_select_options?: IssueFieldValueMultiSelectOptionsList | null | undefined;
}
export type IssueIssueFieldValuesList = Array<IssueFieldValue>;
/** Issues are a great way to keep track of tasks, enhancements, and bugs for your projects. */
export interface Issue {
    id: number;
    node_id: string;
    /** URL for the issue */
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    /** Number uniquely identifying the issue within its repository */
    number: number;
    /** State of the issue; either 'open' or 'closed' */
    state: string;
    /** The reason for the current state */
    state_reason?: IssueStateReason | null | undefined;
    /** Title of the issue */
    title: string;
    /** Contents of the issue */
    body?: string | null | undefined;
    user: NullableSimpleUser | null;
    /** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
    labels: IssueLabelsList;
    assignee: NullableSimpleUser | null;
    assignees?: IssueAssigneesList | undefined;
    milestone: NullableMilestone | null;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    comments: number;
    pull_request?: IssuePullRequest | undefined;
    closed_at: string | null;
    created_at: string;
    updated_at: string;
    draft?: boolean | undefined;
    closed_by?: NullableSimpleUser | null | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    repository?: Repository | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    author_association?: AuthorAssociation | undefined;
    reactions?: ReactionRollup | undefined;
    sub_issues_summary?: SubIssuesSummary | undefined;
    /** URL to get the parent issue of this issue, if it is a sub-issue */
    parent_issue_url?: string | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: IssueIssueFieldValuesList | undefined;
}
export interface AddBlockedByDependencyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the issue that blocks the current issue */
    issue_id: number;
}
/** The value to set for multi_select fields (array of option names) */
export type AddIssueFieldValuesRequestIssueFieldValuesItemValueCase2List = Array<string>;
/** The value to set for the field. The type depends on the field's data type: - For text fields: provide a string value - For single_select fields: provide the option name as a string (must match an existing option) - For number fields: provide a numeric value - For multi_select fields: provide an array of option names (must match existing options) - For date fields: provide an ISO 8601 date string */
export type AddIssueFieldValuesRequestIssueFieldValuesItemValue = string | number | AddIssueFieldValuesRequestIssueFieldValuesItemValueCase2List;
export interface AddIssueFieldValuesRequestIssueFieldValuesItem {
    /** The ID of the issue field to set */
    field_id: number;
    /** The value to set for the field. The type depends on the field's data type: - For text fields: provide a string value - For single_select fields: provide the option name as a string (must match an existing option) - For number fields: provide a numeric value - For multi_select fields: provide an array of option names (must match existing options) - For date fields: provide an ISO 8601 date string */
    value: AddIssueFieldValuesRequestIssueFieldValuesItemValue;
}
/** An array of issue field values to add to this issue. Each field value must include the field ID and the value to set. */
export type AddIssueFieldValuesRequestIssueFieldValuesList = Array<AddIssueFieldValuesRequestIssueFieldValuesItem>;
export interface AddIssueFieldValuesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** An array of issue field values to add to this issue. Each field value must include the field ID and the value to set. */
    issue_field_values?: AddIssueFieldValuesRequestIssueFieldValuesList | undefined;
}
/** The current issue field values for this issue after adding the new values */
export type AddIssueFieldValuesResponseBodyList = Array<IssueFieldValue>;
export type AddIssueFieldValuesResponse = AddIssueFieldValuesResponseBodyList;
/** The confidence level for this label choice. */
export type AddLabelsRequestBodyCase0LabelsItemCase1Confidence = "low" | "medium" | "high";
export interface AddLabelsRequestBodyCase0LabelsItemCase1 {
    /** The name of the label to add. */
    name: string;
    /** Optional reasoning for adding this label. */
    rationale?: string | undefined;
    /** If `true`, the label is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this label choice. */
    confidence?: AddLabelsRequestBodyCase0LabelsItemCase1Confidence | (string & {}) | undefined;
}
export type AddLabelsRequestBodyCase0LabelsItem = string | AddLabelsRequestBodyCase0LabelsItemCase1;
/** The labels to add to the issue's existing labels. You can also pass an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. To replace all of the labels for an issue, use "[Set labels for an issue](https://docs.github.com/rest/issues/labels#set-labels-for-an-issue)." */
export type AddLabelsRequestBodyCase0LabelsList = Array<AddLabelsRequestBodyCase0LabelsItem>;
export interface AddLabelsRequestBodyCase0 {
    /** The labels to add to the issue's existing labels. You can also pass an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. To replace all of the labels for an issue, use "[Set labels for an issue](https://docs.github.com/rest/issues/labels#set-labels-for-an-issue)." */
    labels?: AddLabelsRequestBodyCase0LabelsList | undefined;
}
export type AddLabelsRequestBodyCase1List = Array<string>;
/** The confidence level for this label choice. */
export type AddLabelsRequestBodyCase2ItemConfidence = "low" | "medium" | "high";
export interface AddLabelsRequestBodyCase2Item {
    name: string;
    /** Optional reasoning for adding this label. */
    rationale?: string | undefined;
    /** If `true`, the label is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this label choice. */
    confidence?: AddLabelsRequestBodyCase2ItemConfidence | (string & {}) | undefined;
}
export type AddLabelsRequestBodyCase2List = Array<AddLabelsRequestBodyCase2Item>;
export type AddLabelsRequestBody = AddLabelsRequestBodyCase0 | AddLabelsRequestBodyCase1List | AddLabelsRequestBodyCase2List;
export interface AddLabelsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    body?: AddLabelsRequestBody | undefined;
}
/** Color-coded labels help you categorize and filter your issues (just like labels in Gmail). */
export interface Label {
    /** Unique identifier for the label. */
    id: number;
    node_id: string;
    /** URL for the label */
    url: string;
    /** The name of the label. */
    name: string;
    /** Optional description of the label, such as its purpose. */
    description: string | null;
    /** 6-character hex code, without the leading #, identifying the color */
    color: string;
    /** Whether this label comes by default in a new repository. */
    default: boolean;
    /** Timestamp indicating when the label was archived, or `null` if it has not been archived. */
    archived_at: string | null;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: NullableSimpleUser | null;
}
export type AddLabelsResponseBodyList = Array<Label>;
export type AddLabelsResponse = AddLabelsResponseBodyList;
export interface AddRelatesToRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the issue to mark as related to the current issue */
    issue_id: number;
}
export interface AddSubIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the sub-issue to add. The sub-issue must belong to the same repository owner as the parent issue */
    sub_issue_id: number;
    /** Option that, when true, instructs the operation to replace the sub-issues current parent issue */
    replace_parent?: boolean | undefined;
}
export interface ApproveSuggestionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The unique identifier of the suggestion. */
    suggestion_id: number;
}
/** The kind of change proposed. */
export type IssueSuggestionAction = "set_type" | "add_label" | "add_field" | "add_assignee" | "close_issue";
/** The suggestion's lifecycle state. */
export type IssueSuggestionState = "pending" | "applied" | "approved" | "dismissed" | "replaced" | "invalidated";
export type IssueSuggestionTargetValueCase3List = Array<string>;
/** The proposed value, when applicable. An array for multi-select field suggestions. */
export type IssueSuggestionTargetValue = string | number | boolean | IssueSuggestionTargetValueCase3List;
/** The actor's confidence level in the suggestion. */
export type IssueSuggestionConfidence = "LOW" | "MEDIUM" | "HIGH";
/** An agent-proposed change to an issue that a maintainer can approve or dismiss. */
export interface IssueSuggestion {
    /** The unique identifier of the suggestion. */
    id: number;
    /** The unique identifier of the issue the suggestion applies to. */
    issue_id: number;
    /** The kind of change proposed. */
    action: IssueSuggestionAction;
    /** The suggestion's lifecycle state. */
    state: IssueSuggestionState;
    /** The identifier of the target the change applies to (issue type, label, field, assignee, or duplicate issue), when applicable. */
    target_id: number | null;
    /** The proposed value, when applicable. An array for multi-select field suggestions. */
    target_value: IssueSuggestionTargetValue | null;
    /** The rationale the actor provided for the suggestion. */
    rationale: string | null;
    /** The actor's confidence level in the suggestion. */
    confidence: IssueSuggestionConfidence | null;
    /** The unique identifier of the actor that proposed the suggestion. */
    actor_id: number | null;
    /** The identifier of the timeline event created when the suggestion was approved, when applicable. */
    issue_event_id: number | null;
    /** The unique identifier of the user who approved or dismissed the suggestion. */
    resolved_by: number | null;
    /** The time the suggestion was created. */
    created_at: string;
    /** The time the suggestion was last updated. */
    updated_at: string;
}
export interface CheckUserCanBeAssignedRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    assignee: string;
}
export interface CheckUserCanBeAssignedResponse {
}
export interface CheckUserCanBeAssignedToIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    assignee: string;
}
export interface CheckUserCanBeAssignedToIssueResponse {
}
/** The title of the issue. */
export type CreateRequestTitle = string | number;
export type CreateRequestMilestone = string | number;
export interface CreateRequestLabelsItemCase1 {
    id?: number | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    color?: string | null | undefined;
}
export type CreateRequestLabelsItem = string | CreateRequestLabelsItemCase1;
/** Labels to associate with this issue. _NOTE: Only users with push access can set labels for new issues. Labels are silently dropped otherwise._ */
export type CreateRequestLabelsList = Array<CreateRequestLabelsItem>;
/** Logins for Users to assign to this issue. _NOTE: Only users with push access can set assignees for new issues. Assignees are silently dropped otherwise._ */
export type CreateRequestAssigneesList = Array<string>;
export type CreateRequestIssueFieldValuesItemValueCase2List = Array<string>;
/** The value to set for the field. For multi-select fields, provide an array of option names. */
export type CreateRequestIssueFieldValuesItemValue = string | number | CreateRequestIssueFieldValuesItemValueCase2List;
export interface CreateRequestIssueFieldValuesItem {
    /** The ID of the issue field to set */
    field_id: number;
    /** The value to set for the field. For multi-select fields, provide an array of option names. */
    value: CreateRequestIssueFieldValuesItemValue;
}
/** An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Issue fields are only available for organization-owned repositories with the feature enabled. Field values are silently dropped otherwise. */
export type CreateRequestIssueFieldValuesList = Array<CreateRequestIssueFieldValuesItem>;
export interface CreateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The title of the issue. */
    title: CreateRequestTitle;
    /** The contents of the issue. */
    body?: string | undefined;
    /** Login for the user that this issue should be assigned to. _NOTE: Only users with push access can set the assignee for new issues. The assignee is silently dropped otherwise. **This field is closing down.**_ */
    assignee?: string | null | undefined;
    milestone?: CreateRequestMilestone | null | undefined;
    /** Labels to associate with this issue. _NOTE: Only users with push access can set labels for new issues. Labels are silently dropped otherwise._ */
    labels?: CreateRequestLabelsList | undefined;
    /** Logins for Users to assign to this issue. _NOTE: Only users with push access can set assignees for new issues. Assignees are silently dropped otherwise._ */
    assignees?: CreateRequestAssigneesList | undefined;
    /** An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Issue fields are only available for organization-owned repositories with the feature enabled. Field values are silently dropped otherwise. */
    issue_field_values?: CreateRequestIssueFieldValuesList | undefined;
    /** The name of the issue type to associate with this issue. _NOTE: Only users with push access can set the type for new issues. The type is silently dropped otherwise._ */
    type?: string | null | undefined;
    /** The id of the parent issue to add this issue to as a sub-issue. _NOTE: Only users with triage access to both the parent issue's repository and this repository can set the parent issue._ */
    parent_issue_id?: number | undefined;
}
export interface CreateCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The contents of the comment. */
    body: string;
}
/** Comments provide a way for people to collaborate on an issue. */
export interface IssueComment {
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: NullableSimpleUser | null;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association?: AuthorAssociation | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
/** The artifact type. */
export type CreateIssueArtifactRequestType = "generic" | "link" | "plan" | "embedded_html";
export interface CreateIssueArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The artifact type. */
    type?: CreateIssueArtifactRequestType | (string & {}) | undefined;
    /** The human-readable name of the artifact. */
    name: string;
    /** The artifact content. For `embedded_html` artifacts, provide the HTML source. */
    body: string;
}
/** The user or integration that created the artifact. */
export interface IssueArtifactCreator {
    login: string;
    id: number;
}
/** The user or integration that most recently updated the artifact. */
export type IssueArtifactUpdatedByActor = IssueArtifactCreator;
/** Issue artifacts are named, typed pieces of content attached to an issue. They give people and agents a durable place to preserve context and supporting material alongside the work. Each artifact has a number unique within the issue. */
export interface IssueArtifact {
    /** The globally unique identifier of the artifact. */
    id: number;
    /** The canonical browser URL for the artifact in its issue context. */
    html_url?: string | undefined;
    /** The artifact number within the issue. */
    number: number;
    /** The artifact type. The types supported for external creation and filtering are: - `generic` is a general-purpose Markdown document. - `link` represents a named link. - `plan` is a Markdown plan. - `embedded_html` is a self-contained HTML document. Its `body` contains the HTML source. */
    type: string;
    /** The human-readable name of the artifact. */
    name: string;
    /** The artifact content. For `embedded_html` artifacts, this is the HTML source. */
    body: string;
    /** The artifact content rendered as HTML, or `null` if rendering times out or is skipped to protect the response's time budget. The raw content remains available in `body`. */
    body_html: string | null;
    /** A short, generated summary of the artifact. */
    description: string;
    /** The user or integration that created the artifact. */
    creator: IssueArtifactCreator | null;
    /** The user or integration that most recently updated the artifact. */
    updated_by_actor: IssueArtifactCreator | null;
    /** The time the artifact was created. */
    created_at: string | null;
    /** The time the artifact was last updated. */
    updated_at: string | null;
}
export interface CreateLabelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png ":strawberry:"). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)." */
    name: string;
    /** The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`. */
    color?: string | undefined;
    /** A short description of the label. Must be 100 characters or fewer. */
    description?: string | undefined;
}
/** The state of the milestone. Either `open` or `closed`. */
export type CreateMilestoneRequestState = "open" | "closed";
export interface CreateMilestoneRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The title of the milestone. */
    title: string;
    /** The state of the milestone. Either `open` or `closed`. */
    state?: CreateMilestoneRequestState | (string & {}) | undefined;
    /** A description of the milestone. */
    description?: string | undefined;
    /** The milestone due date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    due_on?: string | undefined;
}
/** The state of the milestone. */
export type MilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface Milestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: MilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: NullableSimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export interface DeleteCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface DeleteCommentResponse {
}
export interface DeleteIssueArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The artifact number within the issue. */
    artifact_number: number;
}
export interface DeleteIssueArtifactResponse {
}
export interface DeleteIssueFieldValueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The unique identifier of the issue field. */
    issue_field_id: number;
}
export interface DeleteIssueFieldValueResponse {
}
export interface DeleteLabelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    name: string;
}
export interface DeleteLabelResponse {
}
export interface DeleteMilestoneRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the milestone. */
    milestone_number: number;
}
export interface DeleteMilestoneResponse {
}
export interface DismissSuggestionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The unique identifier of the suggestion. */
    suggestion_id: number;
}
export interface GetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
}
export interface GetCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface GetEventRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    event_id: number;
}
/** The reason for the current state */
export type NullableIssueStateReason = "completed" | "reopened" | "not_planned" | "duplicate";
export type NullableIssueLabelsItemCase1 = IssueLabelsItemCase1;
export type NullableIssueLabelsItem = string | IssueLabelsItemCase1;
/** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
export type NullableIssueLabelsList = Array<NullableIssueLabelsItem>;
export type NullableIssueAssigneesList = Array<NullableSimpleUser>;
export type NullableIssuePullRequest = IssuePullRequest;
export type NullableIssueIssueFieldValuesList = Array<IssueFieldValue>;
/** Issues are a great way to keep track of tasks, enhancements, and bugs for your projects. */
export interface NullableIssue {
    id: number;
    node_id: string;
    /** URL for the issue */
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    /** Number uniquely identifying the issue within its repository */
    number: number;
    /** State of the issue; either 'open' or 'closed' */
    state: string;
    /** The reason for the current state */
    state_reason?: NullableIssueStateReason | null | undefined;
    /** Title of the issue */
    title: string;
    /** Contents of the issue */
    body?: string | null | undefined;
    user: NullableSimpleUser | null;
    /** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
    labels: NullableIssueLabelsList;
    assignee: NullableSimpleUser | null;
    assignees?: NullableIssueAssigneesList | undefined;
    milestone: NullableMilestone | null;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    comments: number;
    pull_request?: IssuePullRequest | undefined;
    closed_at: string | null;
    created_at: string;
    updated_at: string;
    draft?: boolean | undefined;
    closed_by?: NullableSimpleUser | null | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    repository?: Repository | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    author_association?: AuthorAssociation | undefined;
    reactions?: ReactionRollup | undefined;
    sub_issues_summary?: SubIssuesSummary | undefined;
    /** URL to get the parent issue of this issue, if it is a sub-issue */
    parent_issue_url?: string | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: NullableIssueIssueFieldValuesList | undefined;
}
/** Issue Event Label */
export interface IssueEventLabel {
    name: string | null;
    color: string | null;
}
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export interface IssueEventDismissedReview {
    state: string;
    review_id: number;
    dismissal_message: string | null;
    dismissal_commit_id?: string | null | undefined;
}
/** Issue Event Milestone */
export interface IssueEventMilestone {
    title: string;
}
/** Issue Event Project Card */
export interface IssueEventProjectCard {
    url: string;
    id: number;
    project_url: string;
    project_id: number;
    column_name: string;
    previous_column_name?: string | undefined;
}
/** Issue Event Rename */
export interface IssueEventRename {
    from: string;
    to: string;
}
/** The color of the issue type. */
export type IssueTypeWebhookColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type of issue. */
export interface IssueTypeWebhook {
    /** The unique identifier of the issue type. */
    id: number;
    /** The name of the issue type. */
    name: string;
    /** The color of the issue type. */
    color?: IssueTypeWebhookColor | null | undefined;
}
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: NullableSimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
/** The type of the referenced issue. */
export interface NullableIssueReferenceIssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The color of the issue type. */
    color?: string | null | undefined;
}
/** A minimal reference to an issue linked from a timeline event (e.g. sub-issue, parent-issue, or dependency events). */
export interface NullableIssueReference {
    /** The number of the referenced issue. */
    number: number;
    /** The title of the referenced issue. */
    title: string;
    /** The state of the referenced issue. */
    state: string;
    /** The reason for the referenced issue's state. */
    state_reason?: string | null | undefined;
    repository: SimpleRepository;
    /** The type of the referenced issue. */
    issue_type: NullableIssueReferenceIssueType | null;
}
/** The confidence level the agent had when performing this action. */
export type NullableIssueEventIntentConfidence = "LOW" | "MEDIUM" | "HIGH";
/** The intent behind an agent's action on an issue, including the rationale and confidence. Present (and `null` when the event carried no agent intent) on supported event types while the issue suggestions feature is enabled for the repository; the property is omitted entirely when the feature is disabled or the event type does not support intent. */
export interface NullableIssueEventIntent {
    /** The reasoning the agent provided for the change. */
    rationale?: string | null | undefined;
    /** The confidence level the agent had when performing this action. */
    confidence?: NullableIssueEventIntentConfidence | null | undefined;
}
/** Issue Event */
export interface IssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser | null;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    issue?: NullableIssue | null | undefined;
    label?: IssueEventLabel | undefined;
    assignee?: NullableSimpleUser | null | undefined;
    assigner?: NullableSimpleUser | null | undefined;
    review_requester?: NullableSimpleUser | null | undefined;
    requested_reviewer?: NullableSimpleUser | null | undefined;
    requested_team?: Team | undefined;
    dismissed_review?: IssueEventDismissedReview | undefined;
    milestone?: IssueEventMilestone | undefined;
    project_card?: IssueEventProjectCard | undefined;
    rename?: IssueEventRename | undefined;
    issue_type?: IssueTypeWebhook | null | undefined;
    prev_issue_type?: IssueTypeWebhook | null | undefined;
    sub_issue?: NullableIssueReference | null | undefined;
    parent_issue?: NullableIssueReference | null | undefined;
    blocked_by?: NullableIssueReference | null | undefined;
    blocking?: NullableIssueReference | null | undefined;
    intent?: NullableIssueEventIntent | null | undefined;
    author_association?: AuthorAssociation | undefined;
    lock_reason?: string | null | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
}
export interface GetIssueArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The artifact number within the issue. */
    artifact_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The user or integration that created this version. */
export type GetIssueArtifactResponseBodyCase1VersionsItemActor = IssueArtifactCreator;
export interface GetIssueArtifactResponseBodyCase1VersionsItem {
    /** The sequential version number. */
    version: number;
    /** The artifact name at this version. */
    name: string;
    /** The artifact content at this version. */
    body: string;
    /** The artifact content at this version rendered as HTML, or `null` if rendering times out or is skipped to protect the response's time budget. The raw content remains available in `body`. */
    body_html: string | null;
    /** The time this version was created. */
    created_at: string | null;
    /** The user or integration that created this version. */
    actor: IssueArtifactCreator | null;
}
/** The artifact version history, ordered from newest to oldest. */
export type GetIssueArtifactResponseBodyCase1VersionsList = Array<GetIssueArtifactResponseBodyCase1VersionsItem>;
export interface GetIssueArtifactResponseBodyCase1 {
    artifact: IssueArtifact;
    /** Whether another page of retained versions is available. */
    has_next_page: boolean;
    /** The number of retained artifact versions. */
    total_count: number;
    /** The artifact version history, ordered from newest to oldest. */
    versions: GetIssueArtifactResponseBodyCase1VersionsList;
}
export type GetIssueArtifactResponseBody = IssueArtifact | GetIssueArtifactResponseBodyCase1;
export type GetIssueArtifactResponse = GetIssueArtifactResponseBody;
export interface GetLabelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    name: string;
}
export interface GetMilestoneRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the milestone. */
    milestone_number: number;
}
export interface GetParentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
}
export type ListRequestFilter = "assigned" | "created" | "mentioned" | "subscribed" | "repos" | "all";
export type ListRequestState = "open" | "closed" | "all";
export type ListRequestSort = "created" | "updated" | "comments";
export type ListRequestDirection = "asc" | "desc";
export interface ListRequest {
    /** Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. */
    filter?: ListRequestFilter | (string & {}) | undefined;
    /** Indicates the state of the issues to return. */
    state?: ListRequestState | (string & {}) | undefined;
    /** A list of comma separated label names. Example: `bug,ui,@high` */
    labels?: string | undefined;
    /** What to sort results by. */
    sort?: ListRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    collab?: boolean | undefined;
    orgs?: boolean | undefined;
    owned?: boolean | undefined;
    pulls?: boolean | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListResponseBodyList = Array<Issue>;
export type ListResponse = ListResponseBodyList;
export interface ListAssigneesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListAssigneesResponseBodyList = Array<NullableSimpleUser>;
export type ListAssigneesResponse = ListAssigneesResponseBodyList;
export interface ListCommentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommentsResponseBodyList = Array<IssueComment>;
export type ListCommentsResponse = ListCommentsResponseBodyList;
export type ListCommentsForRepoRequestSort = "created" | "updated";
export type ListCommentsForRepoRequestDirection = "asc" | "desc";
export interface ListCommentsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The property to sort the results by. */
    sort?: ListCommentsForRepoRequestSort | (string & {}) | undefined;
    /** Either `asc` or `desc`. Ignored without the `sort` parameter. */
    direction?: ListCommentsForRepoRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommentsForRepoResponseBodyList = Array<IssueComment>;
export type ListCommentsForRepoResponse = ListCommentsForRepoResponseBodyList;
export interface ListDependenciesBlockedByRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDependenciesBlockedByResponseBodyList = Array<Issue>;
export type ListDependenciesBlockedByResponse = ListDependenciesBlockedByResponseBodyList;
export interface ListDependenciesBlockingRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDependenciesBlockingResponseBodyList = Array<Issue>;
export type ListDependenciesBlockingResponse = ListDependenciesBlockingResponseBodyList;
export interface ListEventsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface LabeledIssueEventLabel {
    name: string;
    color: string;
}
/** Labeled Issue Event */
export interface LabeledIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    label: LabeledIssueEventLabel;
    intent?: NullableIssueEventIntent | null | undefined;
}
export type UnlabeledIssueEventLabel = LabeledIssueEventLabel;
/** Unlabeled Issue Event */
export type UnlabeledIssueEvent = LabeledIssueEvent;
export type IntegrationOwner = NullableSimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export type IntegrationPermissions = NullableIntegrationPermissions;
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type IntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface Integration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: IntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: IntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** Assigned Issue Event */
export interface AssignedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: Integration | null;
    assignee: NullableSimpleUser;
    assigner: NullableSimpleUser;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Unassigned Issue Event */
export interface UnassignedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    assignee: NullableSimpleUser;
    assigner: NullableSimpleUser;
}
export type MilestonedIssueEventMilestone = IssueEventMilestone;
/** Milestoned Issue Event */
export interface MilestonedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    milestone: IssueEventMilestone;
}
export type DemilestonedIssueEventMilestone = IssueEventMilestone;
/** Demilestoned Issue Event */
export type DemilestonedIssueEvent = MilestonedIssueEvent;
export type RenamedIssueEventRename = IssueEventRename;
/** Renamed Issue Event */
export interface RenamedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    rename: IssueEventRename;
}
/** Review Requested Issue Event */
export interface ReviewRequestedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    review_requester: NullableSimpleUser;
    requested_team?: Team | undefined;
    requested_reviewer?: NullableSimpleUser | undefined;
}
/** Review Request Removed Issue Event */
export type ReviewRequestRemovedIssueEvent = ReviewRequestedIssueEvent;
export interface ReviewDismissedIssueEventDismissedReview {
    state: string;
    review_id: number;
    dismissal_message: string | null;
    dismissal_commit_id?: string | undefined;
}
/** Review Dismissed Issue Event */
export interface ReviewDismissedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    dismissed_review: ReviewDismissedIssueEventDismissedReview;
}
/** Locked Issue Event */
export interface LockedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    lock_reason: string | null;
}
export interface AddedToProjectIssueEventProjectCard {
    id: number;
    url: string;
    project_id: number;
    project_url: string;
    column_name: string;
    previous_column_name?: string | undefined;
}
/** Added to Project Issue Event */
export interface AddedToProjectIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    project_card?: AddedToProjectIssueEventProjectCard | undefined;
}
export type MovedColumnInProjectIssueEventProjectCard = AddedToProjectIssueEventProjectCard;
/** Moved Column in Project Issue Event */
export type MovedColumnInProjectIssueEvent = AddedToProjectIssueEvent;
export type RemovedFromProjectIssueEventProjectCard = AddedToProjectIssueEventProjectCard;
/** Removed from Project Issue Event */
export type RemovedFromProjectIssueEvent = AddedToProjectIssueEvent;
export type ConvertedNoteToIssueIssueEventProjectCard = AddedToProjectIssueEventProjectCard;
/** Converted Note to Issue Issue Event */
export interface ConvertedNoteToIssueIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: Integration | null;
    project_card?: AddedToProjectIssueEventProjectCard | undefined;
}
/** Issue Type Added Issue Event */
export interface IssueTypeAddedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    issue_type: IssueTypeWebhook | null;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Issue Type Removed Issue Event */
export interface IssueTypeRemovedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    prev_issue_type: IssueTypeWebhook | null;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Issue Type Changed Issue Event */
export interface IssueTypeChangedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    issue_type: IssueTypeWebhook | null;
    prev_issue_type: IssueTypeWebhook | null;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Sub-issue Added Issue Event */
export interface SubIssueAddedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    sub_issue: NullableIssueReference | null;
}
/** Sub-issue Removed Issue Event */
export type SubIssueRemovedIssueEvent = SubIssueAddedIssueEvent;
/** Parent-issue Added Issue Event */
export interface ParentIssueAddedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    parent_issue: NullableIssueReference | null;
}
/** Parent-issue Removed Issue Event */
export type ParentIssueRemovedIssueEvent = ParentIssueAddedIssueEvent;
/** Blocked-by Added Issue Event */
export interface BlockedByAddedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    blocked_by: NullableIssueReference | null;
}
/** Blocked-by Removed Issue Event */
export type BlockedByRemovedIssueEvent = BlockedByAddedIssueEvent;
/** Blocking Added Issue Event */
export interface BlockingAddedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    blocking: NullableIssueReference | null;
}
/** Blocking Removed Issue Event */
export type BlockingRemovedIssueEvent = BlockingAddedIssueEvent;
/** Issue Event for Issue */
export type IssueEventForIssue = LabeledIssueEvent | LabeledIssueEvent | AssignedIssueEvent | UnassignedIssueEvent | MilestonedIssueEvent | MilestonedIssueEvent | RenamedIssueEvent | ReviewRequestedIssueEvent | ReviewRequestedIssueEvent | ReviewDismissedIssueEvent | LockedIssueEvent | AddedToProjectIssueEvent | AddedToProjectIssueEvent | AddedToProjectIssueEvent | ConvertedNoteToIssueIssueEvent | IssueTypeAddedIssueEvent | IssueTypeRemovedIssueEvent | IssueTypeChangedIssueEvent | SubIssueAddedIssueEvent | SubIssueAddedIssueEvent | ParentIssueAddedIssueEvent | ParentIssueAddedIssueEvent | BlockedByAddedIssueEvent | BlockedByAddedIssueEvent | BlockingAddedIssueEvent | BlockingAddedIssueEvent;
export type ListEventsResponseBodyList = Array<IssueEventForIssue>;
export type ListEventsResponse = ListEventsResponseBodyList;
export interface ListEventsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListEventsForRepoResponseBodyList = Array<IssueEvent>;
export type ListEventsForRepoResponse = ListEventsForRepoResponseBodyList;
export interface ListEventsForTimelineRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** A comma-separated list of timeline event names to exclude from the response. */
    exclude?: string | undefined;
}
/** Timeline Comment Event */
export interface TimelineCommentEvent {
    event: string;
    actor: NullableSimpleUser;
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: NullableSimpleUser;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association: AuthorAssociation;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
export interface TimelineCrossReferencedEventSource {
    type?: string | undefined;
    issue?: Issue | undefined;
}
/** Timeline Cross Referenced Event */
export interface TimelineCrossReferencedEvent {
    event: string;
    actor?: NullableSimpleUser | undefined;
    created_at: string;
    updated_at: string;
    source: TimelineCrossReferencedEventSource;
}
/** Identifying information for the git-user */
export interface TimelineCommittedEventAuthor {
    /** Timestamp of the commit */
    date: string;
    /** Git email address of the user */
    email: string;
    /** Name of the git user */
    name: string;
}
/** Identifying information for the git-user */
export type TimelineCommittedEventCommitter = TimelineCommittedEventAuthor;
export interface TimelineCommittedEventTree {
    /** SHA for the commit */
    sha: string;
    url: string;
}
export interface TimelineCommittedEventParentsItem {
    /** SHA for the commit */
    sha: string;
    url: string;
    html_url: string;
}
export type TimelineCommittedEventParentsList = Array<TimelineCommittedEventParentsItem>;
export interface TimelineCommittedEventVerification {
    verified: boolean;
    reason: string;
    signature: string | null;
    payload: string | null;
    verified_at: string | null;
}
/** Timeline Committed Event */
export interface TimelineCommittedEvent {
    event?: string | undefined;
    /** SHA for the commit */
    sha: string;
    node_id: string;
    url: string;
    /** Identifying information for the git-user */
    author: TimelineCommittedEventAuthor;
    /** Identifying information for the git-user */
    committer: TimelineCommittedEventAuthor;
    /** Message describing the purpose of the commit */
    message: string;
    tree: TimelineCommittedEventTree;
    parents: TimelineCommittedEventParentsList;
    verification: TimelineCommittedEventVerification;
    html_url: string;
}
export interface TimelineReviewedEventLinksHtml {
    href: string;
}
export type TimelineReviewedEventLinksPullRequest = TimelineReviewedEventLinksHtml;
export interface TimelineReviewedEventLinks {
    html: TimelineReviewedEventLinksHtml;
    pull_request: TimelineReviewedEventLinksHtml;
}
/** Timeline Reviewed Event */
export interface TimelineReviewedEvent {
    event: string;
    /** Unique identifier of the review */
    id: number;
    node_id: string;
    user: NullableSimpleUser;
    /** The text of the review. */
    body: string | null;
    state: string;
    html_url: string;
    pull_request_url: string;
    _links: TimelineReviewedEventLinks;
    submitted_at?: string | undefined;
    updated_at?: string | null | undefined;
    /** A commit SHA for the review. */
    commit_id: string;
    body_html?: string | undefined;
    body_text?: string | undefined;
    author_association: AuthorAssociation;
}
/** The kind of contributing source. */
export type PullRequestReviewCommentCopilotCodeReviewSourcesItemKind = "SKILL" | "MCP" | "CUSTOM_INSTRUCTIONS";
export interface PullRequestReviewCommentCopilotCodeReviewSourcesItem {
    /** The kind of contributing source. */
    kind: PullRequestReviewCommentCopilotCodeReviewSourcesItemKind;
    /** The reported source name, or "custom instructions" for CUSTOM_INSTRUCTIONS. */
    name: string;
    /** The validated repository-relative source path, if available. Commit OIDs are not exposed. */
    path?: string | undefined;
}
/** Sources reported as contributing to this comment; may be incomplete. Not returned for issue timeline events. */
export type PullRequestReviewCommentCopilotCodeReviewSourcesList = Array<PullRequestReviewCommentCopilotCodeReviewSourcesItem>;
export type PullRequestReviewCommentLinksSelf = TimelineReviewedEventLinksHtml;
export type PullRequestReviewCommentLinksHtml = TimelineReviewedEventLinksHtml;
export type PullRequestReviewCommentLinksPullRequest = TimelineReviewedEventLinksHtml;
export interface PullRequestReviewCommentLinks {
    self: TimelineReviewedEventLinksHtml;
    html: TimelineReviewedEventLinksHtml;
    pull_request: TimelineReviewedEventLinksHtml;
}
/** The side of the first line of the range for a multi-line comment. */
export type PullRequestReviewCommentStartSide = "LEFT" | "RIGHT";
/** The side of the diff to which the comment applies. The side of the last line of the range for a multi-line comment */
export type PullRequestReviewCommentSide = "LEFT" | "RIGHT";
/** The level at which the comment is targeted, can be a diff line or a file. */
export type PullRequestReviewCommentSubjectType = "line" | "file";
/** Pull Request Review Comments are comments on a portion of the Pull Request's diff. */
export interface PullRequestReviewComment {
    /** Whether this comment was produced by Copilot code review. Not returned for issue timeline events. */
    is_copilot_code_review?: boolean | undefined;
    /** Sources reported as contributing to this comment; may be incomplete. Not returned for issue timeline events. */
    copilot_code_review_sources?: PullRequestReviewCommentCopilotCodeReviewSourcesList | undefined;
    /** URL for the pull request review comment */
    url: string;
    /** The ID of the pull request review to which the comment belongs. */
    pull_request_review_id: number | null;
    /** The ID of the pull request review comment. */
    id: number;
    /** The node ID of the pull request review comment. */
    node_id: string;
    /** The diff of the line that the comment refers to. */
    diff_hunk: string;
    /** The relative path of the file to which the comment applies. */
    path: string;
    /** The line index in the diff to which the comment applies. This field is closing down; use `line` instead. */
    position?: number | undefined;
    /** The index of the original line in the diff to which the comment applies. This field is closing down; use `original_line` instead. */
    original_position?: number | undefined;
    /** The SHA of the commit to which the comment applies. */
    commit_id: string;
    /** The SHA of the original commit to which the comment applies. */
    original_commit_id: string;
    /** The comment ID to reply to. */
    in_reply_to_id?: number | undefined;
    user: NullableSimpleUser | null;
    /** The text of the comment. */
    body: string;
    created_at: string;
    updated_at: string;
    /** HTML URL for the pull request review comment. */
    html_url: string;
    /** URL for the pull request that the review comment belongs to. */
    pull_request_url: string;
    author_association: AuthorAssociation;
    _links: PullRequestReviewCommentLinks;
    /** The first line of the range for a multi-line comment. */
    start_line?: number | null | undefined;
    /** The first line of the range for a multi-line comment. */
    original_start_line?: number | null | undefined;
    /** The side of the first line of the range for a multi-line comment. */
    start_side?: PullRequestReviewCommentStartSide | null | undefined;
    /** The line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    line?: number | undefined;
    /** The line of the blob to which the comment applies. The last line of the range for a multi-line comment */
    original_line?: number | undefined;
    /** The side of the diff to which the comment applies. The side of the last line of the range for a multi-line comment */
    side?: PullRequestReviewCommentSide | undefined;
    /** The level at which the comment is targeted, can be a diff line or a file. */
    subject_type?: PullRequestReviewCommentSubjectType | undefined;
    reactions?: ReactionRollup | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
}
export type TimelineLineCommentedEventCommentsList = Array<PullRequestReviewComment>;
/** Timeline Line Commented Event */
export interface TimelineLineCommentedEvent {
    event?: string | undefined;
    node_id?: string | undefined;
    comments?: TimelineLineCommentedEventCommentsList | undefined;
}
/** Commit Comment */
export interface CommitComment {
    html_url: string;
    url: string;
    id: number;
    node_id: string;
    body: string;
    path: string | null;
    position: number | null;
    line: number | null;
    commit_id: string;
    user: NullableSimpleUser | null;
    created_at: string;
    updated_at: string;
    author_association: AuthorAssociation;
    reactions?: ReactionRollup | undefined;
}
export type TimelineCommitCommentedEventCommentsList = Array<CommitComment>;
/** Timeline Commit Commented Event */
export interface TimelineCommitCommentedEvent {
    event?: string | undefined;
    node_id?: string | undefined;
    commit_id?: string | undefined;
    comments?: TimelineCommitCommentedEventCommentsList | undefined;
}
/** Timeline Assigned Issue Event */
export interface TimelineAssignedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    assignee: NullableSimpleUser;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Timeline Unassigned Issue Event */
export interface TimelineUnassignedIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    assignee: NullableSimpleUser;
}
/** State Change Issue Event */
export interface StateChangeIssueEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
    state_reason?: string | null | undefined;
    intent?: NullableIssueEventIntent | null | undefined;
}
/** Timeline Connected Event */
export interface TimelineConnectedEvent {
    id: number;
    node_id: string;
    url: string;
    actor: NullableSimpleUser;
    event: string;
    commit_id: string | null;
    commit_url: string | null;
    created_at: string;
    performed_via_github_app: NullableIntegration | null;
}
/** Timeline Disconnected Event */
export type TimelineDisconnectedEvent = TimelineConnectedEvent;
/** Timeline Event */
export type TimelineIssueEvents = LabeledIssueEvent | LabeledIssueEvent | MilestonedIssueEvent | MilestonedIssueEvent | RenamedIssueEvent | ReviewRequestedIssueEvent | ReviewRequestedIssueEvent | ReviewDismissedIssueEvent | LockedIssueEvent | AddedToProjectIssueEvent | AddedToProjectIssueEvent | AddedToProjectIssueEvent | ConvertedNoteToIssueIssueEvent | TimelineCommentEvent | TimelineCrossReferencedEvent | TimelineCommittedEvent | TimelineReviewedEvent | TimelineLineCommentedEvent | TimelineCommitCommentedEvent | TimelineAssignedIssueEvent | TimelineUnassignedIssueEvent | StateChangeIssueEvent | IssueTypeAddedIssueEvent | IssueTypeRemovedIssueEvent | IssueTypeChangedIssueEvent | SubIssueAddedIssueEvent | SubIssueAddedIssueEvent | ParentIssueAddedIssueEvent | ParentIssueAddedIssueEvent | BlockedByAddedIssueEvent | BlockedByAddedIssueEvent | BlockingAddedIssueEvent | BlockingAddedIssueEvent | TimelineConnectedEvent | TimelineConnectedEvent;
export type ListEventsForTimelineResponseBodyList = Array<TimelineIssueEvents>;
export type ListEventsForTimelineResponse = ListEventsForTimelineResponseBodyList;
export type ListForAuthenticatedUserRequestFilter = "assigned" | "created" | "mentioned" | "subscribed" | "repos" | "all";
export type ListForAuthenticatedUserRequestState = "open" | "closed" | "all";
export type ListForAuthenticatedUserRequestSort = "created" | "updated" | "comments";
export type ListForAuthenticatedUserRequestDirection = "asc" | "desc";
export interface ListForAuthenticatedUserRequest {
    /** Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. */
    filter?: ListForAuthenticatedUserRequestFilter | (string & {}) | undefined;
    /** Indicates the state of the issues to return. */
    state?: ListForAuthenticatedUserRequestState | (string & {}) | undefined;
    /** A list of comma separated label names. Example: `bug,ui,@high` */
    labels?: string | undefined;
    /** What to sort results by. */
    sort?: ListForAuthenticatedUserRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListForAuthenticatedUserRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForAuthenticatedUserResponseBodyList = Array<Issue>;
export type ListForAuthenticatedUserResponse = ListForAuthenticatedUserResponseBodyList;
export type ListForOrgRequestFilter = "assigned" | "created" | "mentioned" | "subscribed" | "repos" | "all";
export type ListForOrgRequestState = "open" | "closed" | "all";
export type ListForOrgRequestSort = "created" | "updated" | "comments";
export type ListForOrgRequestDirection = "asc" | "desc";
export interface ListForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. */
    filter?: ListForOrgRequestFilter | (string & {}) | undefined;
    /** Indicates the state of the issues to return. */
    state?: ListForOrgRequestState | (string & {}) | undefined;
    /** A list of comma separated label names. Example: `bug,ui,@high` */
    labels?: string | undefined;
    /** Can be the name of an issue type. */
    type?: string | undefined;
    /** What to sort results by. */
    sort?: ListForOrgRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListForOrgRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForOrgResponseBodyList = Array<Issue>;
export type ListForOrgResponse = ListForOrgResponseBodyList;
export type ListForRepoRequestState = "open" | "closed" | "all";
export type ListForRepoRequestSort = "created" | "updated" | "comments";
export type ListForRepoRequestDirection = "asc" | "desc";
export interface ListForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** If an `integer` is passed, it should refer to a milestone by its `number` field. If the string `*` is passed, issues with any milestone are accepted. If the string `none` is passed, issues without milestones are returned. */
    milestone?: string | undefined;
    /** Indicates the state of the issues to return. */
    state?: ListForRepoRequestState | (string & {}) | undefined;
    /** Can be the name of a user. Pass in `none` for issues with no assigned user, and `*` for issues assigned to any user. */
    assignee?: string | undefined;
    /** Can be the name of an issue type. If the string `*` is passed, issues with any type are accepted. If the string `none` is passed, issues without type are returned. */
    type?: string | undefined;
    /** The user that created the issue. */
    creator?: string | undefined;
    /** A user that's mentioned in the issue. */
    mentioned?: string | undefined;
    /** A comma-separated list of issue field filters in `field_slug:value` format. Only issues matching all specified field values are returned. Requires issue fields to be enabled for the repository. Issue fields are not available for user-owned repositories, and field availability for organization-owned public repositories depends on the organization's visibility settings. For example, `priority:Urgent,severity:High` filters issues where the `priority` field is `Urgent` AND the `severity` field is `High`. */
    issue_field_values?: string | undefined;
    /** A list of comma separated label names. Example: `bug,ui,@high` */
    labels?: string | undefined;
    /** What to sort results by. */
    sort?: ListForRepoRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListForRepoRequestDirection | (string & {}) | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForRepoResponseBodyList = Array<Issue>;
export type ListForRepoResponse = ListForRepoResponseBodyList;
export type ListIssueArtifactsRequestType = "generic" | "link" | "plan" | "embedded_html";
export interface ListIssueArtifactsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The artifact type to return. */
    type?: ListIssueArtifactsRequestType | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListIssueArtifactsResponseBodyList = Array<IssueArtifact>;
export type ListIssueArtifactsResponse = ListIssueArtifactsResponseBodyList;
export interface ListIssueFieldValuesForIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListIssueFieldValuesForIssueResponseBodyList = Array<IssueFieldValue>;
export type ListIssueFieldValuesForIssueResponse = ListIssueFieldValuesForIssueResponseBodyList;
export interface ListLabelsForMilestoneRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the milestone. */
    milestone_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListLabelsForMilestoneResponseBodyList = Array<Label>;
export type ListLabelsForMilestoneResponse = ListLabelsForMilestoneResponseBodyList;
export interface ListLabelsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListLabelsForRepoResponseBodyList = Array<Label>;
export type ListLabelsForRepoResponse = ListLabelsForRepoResponseBodyList;
export interface ListLabelsOnIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListLabelsOnIssueResponseBodyList = Array<Label>;
export type ListLabelsOnIssueResponse = ListLabelsOnIssueResponseBodyList;
export type ListMilestonesRequestState = "open" | "closed" | "all";
export type ListMilestonesRequestSort = "due_on" | "completeness";
export type ListMilestonesRequestDirection = "asc" | "desc";
export interface ListMilestonesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The state of the milestone. Either `open`, `closed`, or `all`. */
    state?: ListMilestonesRequestState | (string & {}) | undefined;
    /** What to sort results by. Either `due_on` or `completeness`. */
    sort?: ListMilestonesRequestSort | (string & {}) | undefined;
    /** The direction of the sort. Either `asc` or `desc`. */
    direction?: ListMilestonesRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListMilestonesResponseBodyList = Array<Milestone>;
export type ListMilestonesResponse = ListMilestonesResponseBodyList;
export interface ListRelatesToRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRelatesToResponseBodyList = Array<Issue>;
export type ListRelatesToResponse = ListRelatesToResponseBodyList;
export interface ListSubIssuesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSubIssuesResponseBodyList = Array<Issue>;
export type ListSubIssuesResponse = ListSubIssuesResponseBodyList;
export type ListSuggestionsRequestState = "pending" | "applied" | "approved" | "dismissed" | "replaced" | "invalidated" | "all";
export type ListSuggestionsRequestAction = "set_type" | "add_label" | "add_field" | "add_assignee" | "close_issue";
export interface ListSuggestionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** Filter suggestions by their state. */
    state?: ListSuggestionsRequestState | (string & {}) | undefined;
    /** Filter suggestions by the change they propose. */
    action?: ListSuggestionsRequestAction | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSuggestionsResponseBodyList = Array<IssueSuggestion>;
export type ListSuggestionsResponse = ListSuggestionsResponseBodyList;
/** The reason for locking the issue or pull request conversation. Lock will fail if you don't use one of these reasons: * `off-topic` * `too heated` * `resolved` * `spam` */
export type LockRequestLockReason = "off-topic" | "too heated" | "resolved" | "spam";
export interface LockRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The reason for locking the issue or pull request conversation. Lock will fail if you don't use one of these reasons: * `off-topic` * `too heated` * `resolved` * `spam` */
    lock_reason?: LockRequestLockReason | (string & {}) | undefined;
}
export interface LockResponse {
}
export interface PinCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface RemoveAllLabelsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
}
export interface RemoveAllLabelsResponse {
}
/** Usernames of assignees to remove from an issue. _NOTE: Only users with push access can remove assignees from an issue. Assignees are silently ignored otherwise._ */
export type RemoveAssigneesRequestAssigneesList = Array<string>;
export interface RemoveAssigneesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** Usernames of assignees to remove from an issue. _NOTE: Only users with push access can remove assignees from an issue. Assignees are silently ignored otherwise._ */
    assignees?: RemoveAssigneesRequestAssigneesList | undefined;
}
export interface RemoveDependencyBlockedByRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the blocking issue to remove as a dependency */
    issue_id: number;
}
export interface RemoveLabelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    name: string;
}
export type RemoveLabelResponseBodyList = Array<Label>;
export type RemoveLabelResponse = RemoveLabelResponseBodyList;
export interface RemoveRelatesToRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the related issue to remove */
    issue_id: number;
}
export interface RemoveSubIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the sub-issue to remove */
    sub_issue_id: number;
}
export interface ReprioritizeSubIssueRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The id of the sub-issue to reprioritize */
    sub_issue_id: number;
    /** The id of the sub-issue to be prioritized after (either positional argument after OR before should be specified). */
    after_id?: number | undefined;
    /** The id of the sub-issue to be prioritized before (either positional argument after OR before should be specified). */
    before_id?: number | undefined;
}
/** The value to set for the field. The type depends on the field's data type: - For text fields: provide a string value - For single_select fields: provide the option name as a string (must match an existing option) - For number fields: provide a numeric value - For date fields: provide an ISO 8601 date string */
export type SetIssueFieldValuesRequestIssueFieldValuesItemValue = string | number;
export interface SetIssueFieldValuesRequestIssueFieldValuesItem {
    /** The ID of the issue field to set */
    field_id: number;
    /** The value to set for the field. The type depends on the field's data type: - For text fields: provide a string value - For single_select fields: provide the option name as a string (must match an existing option) - For number fields: provide a numeric value - For date fields: provide an ISO 8601 date string */
    value: SetIssueFieldValuesRequestIssueFieldValuesItemValue;
}
/** An array of issue field values to set for this issue. Each field value must include the field ID and the value to set. All existing field values will be replaced. */
export type SetIssueFieldValuesRequestIssueFieldValuesList = Array<SetIssueFieldValuesRequestIssueFieldValuesItem>;
export interface SetIssueFieldValuesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** An array of issue field values to set for this issue. Each field value must include the field ID and the value to set. All existing field values will be replaced. */
    issue_field_values?: SetIssueFieldValuesRequestIssueFieldValuesList | undefined;
}
/** The current issue field values for this issue after setting the new values */
export type SetIssueFieldValuesResponseBodyList = Array<IssueFieldValue>;
export type SetIssueFieldValuesResponse = SetIssueFieldValuesResponseBodyList;
/** The names of the labels to set for the issue. The labels you set replace any existing labels. You can pass an empty array to remove all labels. Alternatively, you can pass a single label as a `string` or an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. You can also add labels to the existing labels for an issue. For more information, see "[Add labels to an issue](https://docs.github.com/rest/issues/labels#add-labels-to-an-issue)." */
export type SetLabelsRequestBodyCase0LabelsList = Array<string>;
export interface SetLabelsRequestBodyCase0 {
    /** The names of the labels to set for the issue. The labels you set replace any existing labels. You can pass an empty array to remove all labels. Alternatively, you can pass a single label as a `string` or an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. You can also add labels to the existing labels for an issue. For more information, see "[Add labels to an issue](https://docs.github.com/rest/issues/labels#add-labels-to-an-issue)." */
    labels?: SetLabelsRequestBodyCase0LabelsList | undefined;
}
export type SetLabelsRequestBodyCase1List = Array<string>;
export interface SetLabelsRequestBodyCase2LabelsItem {
    name: string;
}
export type SetLabelsRequestBodyCase2LabelsList = Array<SetLabelsRequestBodyCase2LabelsItem>;
export interface SetLabelsRequestBodyCase2 {
    labels?: SetLabelsRequestBodyCase2LabelsList | undefined;
}
export type SetLabelsRequestBodyCase3Item = SetLabelsRequestBodyCase2LabelsItem;
export type SetLabelsRequestBodyCase3List = Array<SetLabelsRequestBodyCase2LabelsItem>;
export type SetLabelsRequestBody = SetLabelsRequestBodyCase0 | SetLabelsRequestBodyCase1List | SetLabelsRequestBodyCase2 | SetLabelsRequestBodyCase3List | string;
export interface SetLabelsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    body?: SetLabelsRequestBody | undefined;
}
export type SetLabelsResponseBodyList = Array<Label>;
export type SetLabelsResponse = SetLabelsResponseBodyList;
export interface UnlockRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
}
export interface UnlockResponse {
}
export interface UnpinCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface UnpinCommentResponse {
}
/** The title of the issue. */
export type UpdateRequestTitle = string | number;
/** The open or closed state of the issue. */
export type UpdateRequestState = "open" | "closed";
/** The reason for the state change. Ignored unless `state` is changed. */
export type UpdateRequestStateReason = "completed" | "not_planned" | "duplicate" | "reopened";
export type UpdateRequestMilestone = string | number;
/** The confidence level for this label choice. */
export type UpdateRequestLabelsItemCase1Confidence = "low" | "medium" | "high";
export interface UpdateRequestLabelsItemCase1 {
    id?: number | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    color?: string | null | undefined;
    /** Optional reasoning for selecting this label. */
    rationale?: string | undefined;
    /** If `true`, the change is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this label choice. */
    confidence?: UpdateRequestLabelsItemCase1Confidence | (string & {}) | undefined;
}
export type UpdateRequestLabelsItem = string | UpdateRequestLabelsItemCase1;
/** Labels to associate with this issue. Pass one or more labels to _replace_ the set of labels on this issue. Send an empty array (`[]`) to clear all labels from the issue. Only users with push access can set labels for issues. Without push access to the repository, label changes are silently dropped. */
export type UpdateRequestLabelsList = Array<UpdateRequestLabelsItem>;
/** The confidence level for this assignee choice. */
export type UpdateRequestAssigneesItemCase1Confidence = "low" | "medium" | "high";
export interface UpdateRequestAssigneesItemCase1 {
    login?: string | undefined;
    /** Optional reasoning for selecting this assignee. */
    rationale?: string | undefined;
    /** If `true`, the change is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this assignee choice. */
    confidence?: UpdateRequestAssigneesItemCase1Confidence | (string & {}) | undefined;
}
export type UpdateRequestAssigneesItem = string | UpdateRequestAssigneesItemCase1;
/** Usernames to assign to this issue. Pass one or more user logins to _replace_ the set of assignees on this issue. Send an empty array (`[]`) to clear all assignees from the issue. Only users with push access can set assignees for new issues. Without push access to the repository, assignee changes are silently dropped. */
export type UpdateRequestAssigneesList = Array<UpdateRequestAssigneesItem>;
export type UpdateRequestIssueFieldValuesItemValueCase2List = Array<string>;
/** The value to set for the field. For multi-select fields, provide an array of option names. */
export type UpdateRequestIssueFieldValuesItemValue = string | number | UpdateRequestIssueFieldValuesItemValueCase2List;
/** The confidence level for this field value choice. */
export type UpdateRequestIssueFieldValuesItemConfidence = "low" | "medium" | "high";
export interface UpdateRequestIssueFieldValuesItem {
    /** The ID of the issue field to set */
    field_id: number;
    /** The value to set for the field. For multi-select fields, provide an array of option names. */
    value: UpdateRequestIssueFieldValuesItemValue;
    /** Optional reasoning for setting this field value. */
    rationale?: string | undefined;
    /** If `true`, the change is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this field value choice. */
    confidence?: UpdateRequestIssueFieldValuesItemConfidence | (string & {}) | undefined;
}
/** An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Only users with push access can set field values for issues */
export type UpdateRequestIssueFieldValuesList = Array<UpdateRequestIssueFieldValuesItem>;
/** The confidence level for this type choice. */
export type UpdateRequestTypeCase1Confidence = "low" | "medium" | "high";
/** The issue type with optional metadata. */
export interface UpdateRequestTypeCase1 {
    /** The name of the issue type to associate with this issue, or `null` to remove the current issue type. */
    value?: string | null | undefined;
    /** Optional reasoning for selecting this type. */
    rationale?: string | undefined;
    /** If `true`, the change is stored as a pending suggestion for human review rather than applied directly. */
    suggest?: boolean | undefined;
    /** The confidence level for this type choice. */
    confidence?: UpdateRequestTypeCase1Confidence | (string & {}) | undefined;
}
/** The issue type to associate with this issue. Only users with push access can set the type for issues. Without push access to the repository, type changes are silently dropped. */
export type UpdateRequestType = string | UpdateRequestTypeCase1;
export interface UpdateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The title of the issue. */
    title?: UpdateRequestTitle | null | undefined;
    /** The contents of the issue. */
    body?: string | null | undefined;
    /** Username to assign to this issue. **This field is closing down.** */
    assignee?: string | null | undefined;
    /** The open or closed state of the issue. */
    state?: UpdateRequestState | (string & {}) | undefined;
    /** The reason for the state change. Ignored unless `state` is changed. */
    state_reason?: UpdateRequestStateReason | (string & {}) | null | undefined;
    /** The ID of the issue that this issue duplicates, used when marking this issue as a duplicate with `status: Duplicate` or `state_reason: duplicate`. The issue must exist and be accessible to the authenticated user. */
    duplicate_issue_id?: number | undefined;
    milestone?: UpdateRequestMilestone | null | undefined;
    /** Labels to associate with this issue. Pass one or more labels to _replace_ the set of labels on this issue. Send an empty array (`[]`) to clear all labels from the issue. Only users with push access can set labels for issues. Without push access to the repository, label changes are silently dropped. */
    labels?: UpdateRequestLabelsList | undefined;
    /** Usernames to assign to this issue. Pass one or more user logins to _replace_ the set of assignees on this issue. Send an empty array (`[]`) to clear all assignees from the issue. Only users with push access can set assignees for new issues. Without push access to the repository, assignee changes are silently dropped. */
    assignees?: UpdateRequestAssigneesList | undefined;
    /** An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Only users with push access can set field values for issues */
    issue_field_values?: UpdateRequestIssueFieldValuesList | undefined;
    /** The issue type to associate with this issue. Only users with push access can set the type for issues. Without push access to the repository, type changes are silently dropped. */
    type?: UpdateRequestType | null | undefined;
}
/** The reason for the current state */
export type UpdateResponseStateReason = "completed" | "reopened" | "not_planned" | "duplicate";
export type UpdateResponseLabelsItemCase1 = IssueLabelsItemCase1;
export type UpdateResponseLabelsItem = string | IssueLabelsItemCase1;
/** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
export type UpdateResponseLabelsList = Array<UpdateResponseLabelsItem>;
export type UpdateResponseAssigneesList = Array<NullableSimpleUser>;
export type UpdateResponsePullRequest = IssuePullRequest;
export type UpdateResponseIssueFieldValuesList = Array<IssueFieldValue>;
export type UpdateResponseSuggestionsTypeItemConfidence = "low" | "medium" | "high";
export type UpdateResponseSuggestionsTypeItemIgnoredReason = "already_applied" | "issue_already_closed";
export interface UpdateResponseSuggestionsTypeItem {
    value?: string | undefined;
    rationale?: string | undefined;
    suggest?: boolean | undefined;
    confidence?: UpdateResponseSuggestionsTypeItemConfidence | undefined;
    ignored?: boolean | undefined;
    ignored_reason?: UpdateResponseSuggestionsTypeItemIgnoredReason | undefined;
}
export type UpdateResponseSuggestionsTypeList = Array<UpdateResponseSuggestionsTypeItem>;
export type UpdateResponseSuggestionsIssueFieldValuesItemValueCase2List = Array<string>;
export type UpdateResponseSuggestionsIssueFieldValuesItemValue = string | number | UpdateResponseSuggestionsIssueFieldValuesItemValueCase2List;
export type UpdateResponseSuggestionsIssueFieldValuesItemConfidence = "low" | "medium" | "high";
export type UpdateResponseSuggestionsIssueFieldValuesItemIgnoredReason = "already_applied" | "issue_already_closed";
export interface UpdateResponseSuggestionsIssueFieldValuesItem {
    field_id?: number | undefined;
    value?: UpdateResponseSuggestionsIssueFieldValuesItemValue | undefined;
    rationale?: string | undefined;
    suggest?: boolean | undefined;
    confidence?: UpdateResponseSuggestionsIssueFieldValuesItemConfidence | undefined;
    ignored?: boolean | undefined;
    ignored_reason?: UpdateResponseSuggestionsIssueFieldValuesItemIgnoredReason | undefined;
}
export type UpdateResponseSuggestionsIssueFieldValuesList = Array<UpdateResponseSuggestionsIssueFieldValuesItem>;
export type UpdateResponseSuggestionsLabelsItemConfidence = "low" | "medium" | "high";
export type UpdateResponseSuggestionsLabelsItemIgnoredReason = "already_applied" | "issue_already_closed";
export interface UpdateResponseSuggestionsLabelsItem {
    name?: string | undefined;
    rationale?: string | undefined;
    suggest?: boolean | undefined;
    confidence?: UpdateResponseSuggestionsLabelsItemConfidence | undefined;
    ignored?: boolean | undefined;
    ignored_reason?: UpdateResponseSuggestionsLabelsItemIgnoredReason | undefined;
}
export type UpdateResponseSuggestionsLabelsList = Array<UpdateResponseSuggestionsLabelsItem>;
export type UpdateResponseSuggestionsAssigneesItemConfidence = "low" | "medium" | "high";
export type UpdateResponseSuggestionsAssigneesItemIgnoredReason = "already_applied" | "issue_already_closed";
export interface UpdateResponseSuggestionsAssigneesItem {
    login?: string | undefined;
    rationale?: string | undefined;
    suggest?: boolean | undefined;
    confidence?: UpdateResponseSuggestionsAssigneesItemConfidence | undefined;
    ignored?: boolean | undefined;
    ignored_reason?: UpdateResponseSuggestionsAssigneesItemIgnoredReason | undefined;
}
export type UpdateResponseSuggestionsAssigneesList = Array<UpdateResponseSuggestionsAssigneesItem>;
export type UpdateResponseSuggestionsStateItemConfidence = "low" | "medium" | "high";
export type UpdateResponseSuggestionsStateItemIgnoredReason = "already_applied" | "issue_already_closed";
export interface UpdateResponseSuggestionsStateItem {
    value?: string | undefined;
    state_reason?: string | undefined;
    duplicate_issue_id?: number | undefined;
    rationale?: string | undefined;
    suggest?: boolean | undefined;
    confidence?: UpdateResponseSuggestionsStateItemConfidence | undefined;
    ignored?: boolean | undefined;
    ignored_reason?: UpdateResponseSuggestionsStateItemIgnoredReason | undefined;
}
export type UpdateResponseSuggestionsStateList = Array<UpdateResponseSuggestionsStateItem>;
/** Pending suggestions for each suggestible field (`type`, `issue_field_values`, `labels`, `assignees`, `state`) the request touched. Omitted for fields not in the request or with no pending or ignored suggestions. Items tagged `ignored` are echoes of the current request's inputs that were not persisted as pending suggestions. */
export interface UpdateResponseSuggestions {
    type?: UpdateResponseSuggestionsTypeList | undefined;
    issue_field_values?: UpdateResponseSuggestionsIssueFieldValuesList | undefined;
    labels?: UpdateResponseSuggestionsLabelsList | undefined;
    assignees?: UpdateResponseSuggestionsAssigneesList | undefined;
    state?: UpdateResponseSuggestionsStateList | undefined;
}
export interface UpdateResponse {
    id: number;
    node_id: string;
    /** URL for the issue */
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    /** Number uniquely identifying the issue within its repository */
    number: number;
    /** State of the issue; either 'open' or 'closed' */
    state: string;
    /** The reason for the current state */
    state_reason?: UpdateResponseStateReason | null | undefined;
    /** Title of the issue */
    title: string;
    /** Contents of the issue */
    body?: string | null | undefined;
    user: NullableSimpleUser | null;
    /** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
    labels: UpdateResponseLabelsList;
    assignee: NullableSimpleUser | null;
    assignees?: UpdateResponseAssigneesList | undefined;
    milestone: NullableMilestone | null;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    comments: number;
    pull_request?: IssuePullRequest | undefined;
    closed_at: string | null;
    created_at: string;
    updated_at: string;
    draft?: boolean | undefined;
    closed_by?: NullableSimpleUser | null | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    repository?: Repository | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    author_association?: AuthorAssociation | undefined;
    reactions?: ReactionRollup | undefined;
    sub_issues_summary?: SubIssuesSummary | undefined;
    /** URL to get the parent issue of this issue, if it is a sub-issue */
    parent_issue_url?: string | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: UpdateResponseIssueFieldValuesList | undefined;
    /** Pending suggestions for each suggestible field (`type`, `issue_field_values`, `labels`, `assignees`, `state`) the request touched. Omitted for fields not in the request or with no pending or ignored suggestions. Items tagged `ignored` are echoes of the current request's inputs that were not persisted as pending suggestions. */
    suggestions?: UpdateResponseSuggestions | undefined;
}
export interface UpdateCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The contents of the comment. */
    body: string;
}
export interface UpdateIssueArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the issue. */
    issue_number: number;
    /** The artifact number within the issue. */
    artifact_number: number;
    /** The new human-readable name of the artifact. */
    name?: string | undefined;
    /** The new artifact content. */
    body?: string | undefined;
}
export interface UpdateLabelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    name: string;
    /** The new name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png ":strawberry:"). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)." */
    new_name?: string | undefined;
    /** The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`. */
    color?: string | undefined;
    /** A short description of the label. Must be 100 characters or fewer. */
    description?: string | undefined;
    /** Whether to archive or unarchive the label. Archived labels cannot be added to issues or pull requests. For more information, see "[Archiving labels](https://docs.github.com/issues/organizing-your-work-with-labels/managing-labels)." */
    archived?: boolean | undefined;
}
/** The state of the milestone. Either `open` or `closed`. */
export type UpdateMilestoneRequestState = "open" | "closed";
export interface UpdateMilestoneRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies the milestone. */
    milestone_number: number;
    /** The title of the milestone. */
    title?: string | undefined;
    /** The state of the milestone. Either `open` or `closed`. */
    state?: UpdateMilestoneRequestState | (string & {}) | undefined;
    /** A description of the milestone. */
    description?: string | undefined;
    /** The milestone due date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    due_on?: string | null | undefined;
}
export type AddAssigneesError = GithubOpError;
/** Add assignees to an issue Adds up to 10 assignees to an issue. Users already assigned to an issue are not replaced. */
export declare const addAssignees: API.OperationMethod<AddAssigneesRequest, Issue, AddAssigneesError, GithubOpContext>;
export type AddBlockedByDependencyError = GithubOpError;
/** Add a dependency an issue is blocked by You can use the REST API to add a 'blocked by' relationship to an issue. Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see [Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits) and [Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api). This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const addBlockedByDependency: API.OperationMethod<AddBlockedByDependencyRequest, Issue, AddBlockedByDependencyError, GithubOpContext>;
export type AddIssueFieldValuesError = GithubOpError;
/** Add issue field values to an issue Add custom field values to an issue. You can set values for organization-level issue fields that have been defined for the repository's organization. Adding an empty array will clear all existing field values for the issue. This endpoint supports the following field data types: - **`text`**: String values for text fields - **`single_select`**: Option names for single-select fields (must match an existing option name) - **`number`**: Numeric values for number fields - **`date`**: ISO 8601 date strings for date fields Only users with push access to the repository can add issue field values. If you don't have the proper permissions, you'll receive a `403 Forbidden` response. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const addIssueFieldValues: API.OperationMethod<AddIssueFieldValuesRequest, AddIssueFieldValuesResponse, AddIssueFieldValuesError, GithubOpContext>;
export type AddLabelsError = GithubOpError;
/** Add labels to an issue Adds labels to an issue. */
export declare const addLabels: API.OperationMethod<AddLabelsRequest, AddLabelsResponse, AddLabelsError, GithubOpContext>;
export type AddRelatesToError = GithubOpError;
/** Add a related issue You can use the REST API to mark an issue as related to another issue. Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see [Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits) and [Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api). This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const addRelatesTo: API.OperationMethod<AddRelatesToRequest, Issue, AddRelatesToError, GithubOpContext>;
export type AddSubIssueError = GithubOpError;
/** Add sub-issue You can use the REST API to add sub-issues to issues. Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const addSubIssue: API.OperationMethod<AddSubIssueRequest, Issue, AddSubIssueError, GithubOpContext>;
export type ApproveSuggestionError = GithubOpError;
/** Approve an issue suggestion Approves a pending suggestion on an issue. Applies the proposed change (creating the corresponding timeline event), transitions the suggestion to `approved`, and dismisses any competing pending suggestions for the same change. Requires triage access to the repository. Approving a suggestion also requires permission to perform the change it applies (for example, setting the issue type, adding a label or assignee, or closing the issue); this only affects fine-grained access tokens and GitHub Apps whose permissions are narrower than the triage role. This endpoint only supports issues, not pull requests. */
export declare const approveSuggestion: API.OperationMethod<ApproveSuggestionRequest, IssueSuggestion, ApproveSuggestionError, GithubOpContext>;
export type CheckUserCanBeAssignedError = GithubOpError;
/** Check if a user can be assigned Checks if a user has permission to be assigned to an issue in this repository. If the `assignee` can be assigned to issues in the repository, a `204` header with no content is returned. Otherwise a `404` status code is returned. */
export declare const checkUserCanBeAssigned: API.OperationMethod<CheckUserCanBeAssignedRequest, CheckUserCanBeAssignedResponse, CheckUserCanBeAssignedError, GithubOpContext>;
export type CheckUserCanBeAssignedToIssueError = GithubOpError;
/** Check if a user can be assigned to a issue Checks if a user has permission to be assigned to a specific issue. If the `assignee` can be assigned to this issue, a `204` status code with no content is returned. Otherwise a `404` status code is returned. */
export declare const checkUserCanBeAssignedToIssue: API.OperationMethod<CheckUserCanBeAssignedToIssueRequest, CheckUserCanBeAssignedToIssueResponse, CheckUserCanBeAssignedToIssueError, GithubOpContext>;
export type CreateError = GithubOpError;
/** Create an issue Any user with pull access to a repository can create an issue. If [issues are disabled in the repository](https://docs.github.com/articles/disabling-issues/), the API returns a `410 Gone` status. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const create: API.OperationMethod<CreateRequest, Issue, CreateError, GithubOpContext>;
export type CreateCommentError = GithubOpError;
/** Create an issue comment You can use the REST API to create comments on issues and pull requests. Every pull request is an issue, but not every issue is a pull request. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const createComment: API.OperationMethod<CreateCommentRequest, IssueComment, CreateCommentError, GithubOpContext>;
export type CreateIssueArtifactError = GithubOpError;
/** Create an issue artifact Creates an artifact attached to an issue. The artifact type defaults to `generic` when omitted. Creating an artifact requires permission to update the issue. The request can return `403` if the repository is read-only or locked, or a GitHub App installation has only `issues: read` permission. To create an HTML artifact, set `type` to `embedded_html` and provide the HTML source in `body`. Open the returned `html_url` to inspect the source, then select **Preview** to view the rendered artifact. Select **Show source** to return to the HTML source. */
export declare const createIssueArtifact: API.OperationMethod<CreateIssueArtifactRequest, IssueArtifact, CreateIssueArtifactError, GithubOpContext>;
export type CreateLabelError = GithubOpError;
/** Create a label Creates a label for the specified repository with the given name and color. The name and color parameters are required. The color must be a valid [hexadecimal color code](http://www.color-hex.com/). */
export declare const createLabel: API.OperationMethod<CreateLabelRequest, Label, CreateLabelError, GithubOpContext>;
export type CreateMilestoneError = GithubOpError;
/** Create a milestone Creates a milestone. */
export declare const createMilestone: API.OperationMethod<CreateMilestoneRequest, Milestone, CreateMilestoneError, GithubOpContext>;
export type DeleteCommentError = GithubOpError;
/** Delete an issue comment You can use the REST API to delete comments on issues and pull requests. Every pull request is an issue, but not every issue is a pull request. */
export declare const deleteComment: API.OperationMethod<DeleteCommentRequest, DeleteCommentResponse, DeleteCommentError, GithubOpContext>;
export type DeleteIssueArtifactError = GithubOpError;
/** Delete an issue artifact Permanently deletes an artifact attached to an issue. Deleting an artifact requires permission to update the issue. The request can return `403` if the repository is read-only or locked, or a GitHub App installation has only `issues: read` permission. */
export declare const deleteIssueArtifact: API.OperationMethod<DeleteIssueArtifactRequest, DeleteIssueArtifactResponse, DeleteIssueArtifactError, GithubOpContext>;
export type DeleteIssueFieldValueError = GithubOpError;
/** Delete an issue field value from an issue Remove a specific custom field value from an issue. Only users with push access to the repository can delete issue field values. If you don't have the proper permissions, you'll receive a `403 Forbidden` response. If the specified field does not have a value set on the issue, this operation will return a `404` error. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const deleteIssueFieldValue: API.OperationMethod<DeleteIssueFieldValueRequest, DeleteIssueFieldValueResponse, DeleteIssueFieldValueError, GithubOpContext>;
export type DeleteLabelError = GithubOpError;
/** Delete a label Deletes a label using the given label name. */
export declare const deleteLabel: API.OperationMethod<DeleteLabelRequest, DeleteLabelResponse, DeleteLabelError, GithubOpContext>;
export type DeleteMilestoneError = GithubOpError;
/** Delete a milestone Deletes a milestone using the given milestone number. */
export declare const deleteMilestone: API.OperationMethod<DeleteMilestoneRequest, DeleteMilestoneResponse, DeleteMilestoneError, GithubOpContext>;
export type DismissSuggestionError = GithubOpError;
/** Dismiss an issue suggestion Dismisses a pending suggestion on an issue. Transitions the suggestion to `dismissed` without applying any change or creating a timeline event. Requires triage access to the repository. This endpoint only supports issues, not pull requests. */
export declare const dismissSuggestion: API.OperationMethod<DismissSuggestionRequest, IssueSuggestion, DismissSuggestionError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get an issue The API returns a [`301 Moved Permanently` status](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api#follow-redirects) if the issue was [transferred](https://docs.github.com/articles/transferring-an-issue-to-another-repository/) to another repository. If the issue was transferred to or deleted from a repository where the authenticated user lacks read access, the API returns a `404 Not Found` status. If the issue was deleted from a repository where the authenticated user has read access, the API returns a `410 Gone` status. To receive webhook events for transferred and deleted issues, subscribe to the [`issues`](https://docs.github.com/webhooks/event-payloads/#issues) webhook. > [!NOTE] > GitHub's REST API considers every pull request an issue, but not every issue is a pull request. For this reason, "Issues" endpoints may return both issues and pull requests in the response. You can identify pull requests by the `pull_request` key. Be aware that the `id` of a pull request returned from "Issues" endpoints will be an _issue id_. To find out the pull request id, use the "[List pull requests](https://docs.github.com/rest/pulls/pulls#list-pull-requests)" endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const get: API.OperationMethod<GetRequest, Issue, GetError, GithubOpContext>;
export type GetCommentError = GithubOpError;
/** Get an issue comment You can use the REST API to get comments on issues and pull requests. Every pull request is an issue, but not every issue is a pull request. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const getComment: API.OperationMethod<GetCommentRequest, IssueComment, GetCommentError, GithubOpContext>;
export type GetEventError = GithubOpError;
/** Get an issue event Gets a single event by the event id. */
export declare const getEvent: API.OperationMethod<GetEventRequest, IssueEvent, GetEventError, GithubOpContext>;
export type GetIssueArtifactError = GithubOpError;
/** Get an issue artifact Returns an artifact attached to an issue by its per-issue artifact number, along with its version history ordered from newest to oldest. */
export declare const getIssueArtifact: API.OperationMethod<GetIssueArtifactRequest, GetIssueArtifactResponse, GetIssueArtifactError, GithubOpContext>;
export type GetLabelError = GithubOpError;
/** Get a label Gets a label using the given name. */
export declare const getLabel: API.OperationMethod<GetLabelRequest, Label, GetLabelError, GithubOpContext>;
export type GetMilestoneError = GithubOpError;
/** Get a milestone Gets a milestone using the given milestone number. */
export declare const getMilestone: API.OperationMethod<GetMilestoneRequest, Milestone, GetMilestoneError, GithubOpContext>;
export type GetParentError = GithubOpError;
/** Get parent issue You can use the REST API to get the parent issue of a sub-issue. This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const getParent: API.OperationMethod<GetParentRequest, Issue, GetParentError, GithubOpContext>;
export type ListError = GithubOpError;
/** List issues assigned to the authenticated user List issues assigned to the authenticated user across all visible repositories including owned repositories, member repositories, and organization repositories. You can use the `filter` query parameter to fetch issues that are not necessarily assigned to you. > [!NOTE] > GitHub's REST API considers every pull request an issue, but not every issue is a pull request. For this reason, "Issues" endpoints may return both issues and pull requests in the response. You can identify pull requests by the `pull_request` key. Be aware that the `id` of a pull request returned from "Issues" endpoints will be an _issue id_. To find out the pull request id, use the "[List pull requests](https://docs.github.com/rest/pulls/pulls#list-pull-requests)" endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const list: API.PaginatedOperationMethod<ListRequest, ListResponse, ListError, GithubOpContext, Issue>;
export type ListAssigneesError = GithubOpError;
/** List assignees Lists the [available assignees](https://docs.github.com/articles/assigning-issues-and-pull-requests-to-other-github-users/) for issues in a repository. */
export declare const listAssignees: API.PaginatedOperationMethod<ListAssigneesRequest, ListAssigneesResponse, ListAssigneesError, GithubOpContext, NullableSimpleUser>;
export type ListCommentsError = GithubOpError;
/** List issue comments You can use the REST API to list comments on issues and pull requests. Every pull request is an issue, but not every issue is a pull request. Issue comments are ordered by ascending ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listComments: API.PaginatedOperationMethod<ListCommentsRequest, ListCommentsResponse, ListCommentsError, GithubOpContext, IssueComment>;
export type ListCommentsForRepoError = GithubOpError;
/** List issue comments for a repository You can use the REST API to list comments on issues and pull requests for a repository. Every pull request is an issue, but not every issue is a pull request. By default, issue comments are ordered by ascending ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listCommentsForRepo: API.PaginatedOperationMethod<ListCommentsForRepoRequest, ListCommentsForRepoResponse, ListCommentsForRepoError, GithubOpContext, IssueComment>;
export type ListDependenciesBlockedByError = GithubOpError;
/** List dependencies an issue is blocked by You can use the REST API to list the dependencies an issue is blocked by. This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listDependenciesBlockedBy: API.PaginatedOperationMethod<ListDependenciesBlockedByRequest, ListDependenciesBlockedByResponse, ListDependenciesBlockedByError, GithubOpContext, Issue>;
export type ListDependenciesBlockingError = GithubOpError;
/** List dependencies an issue is blocking You can use the REST API to list the dependencies an issue is blocking. This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listDependenciesBlocking: API.PaginatedOperationMethod<ListDependenciesBlockingRequest, ListDependenciesBlockingResponse, ListDependenciesBlockingError, GithubOpContext, Issue>;
export type ListEventsError = GithubOpError;
/** List issue events Lists all events for an issue. */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsRequest, ListEventsResponse, ListEventsError, GithubOpContext, IssueEventForIssue>;
export type ListEventsForRepoError = GithubOpError;
/** List issue events for a repository Lists events for a repository. */
export declare const listEventsForRepo: API.PaginatedOperationMethod<ListEventsForRepoRequest, ListEventsForRepoResponse, ListEventsForRepoError, GithubOpContext, IssueEvent>;
export type ListEventsForTimelineError = GithubOpError;
/** List timeline events for an issue List all timeline events for an issue. */
export declare const listEventsForTimeline: API.PaginatedOperationMethod<ListEventsForTimelineRequest, ListEventsForTimelineResponse, ListEventsForTimelineError, GithubOpContext, TimelineIssueEvents>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List user account issues assigned to the authenticated user List issues across owned and member repositories assigned to the authenticated user. > [!NOTE] > GitHub's REST API considers every pull request an issue, but not every issue is a pull request. For this reason, "Issues" endpoints may return both issues and pull requests in the response. You can identify pull requests by the `pull_request` key. Be aware that the `id` of a pull request returned from "Issues" endpoints will be an _issue id_. To find out the pull request id, use the "[List pull requests](https://docs.github.com/rest/pulls/pulls#list-pull-requests)" endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, Issue>;
export type ListForOrgError = GithubOpError;
/** List organization issues assigned to the authenticated user List issues in an organization assigned to the authenticated user. > [!NOTE] > GitHub's REST API considers every pull request an issue, but not every issue is a pull request. For this reason, "Issues" endpoints may return both issues and pull requests in the response. You can identify pull requests by the `pull_request` key. Be aware that the `id` of a pull request returned from "Issues" endpoints will be an _issue id_. To find out the pull request id, use the "[List pull requests](https://docs.github.com/rest/pulls/pulls#list-pull-requests)" endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listForOrg: API.PaginatedOperationMethod<ListForOrgRequest, ListForOrgResponse, ListForOrgError, GithubOpContext, Issue>;
export type ListForRepoError = GithubOpError;
/** List repository issues List issues in a repository. Only open issues will be listed. > [!NOTE] > GitHub's REST API considers every pull request an issue, but not every issue is a pull request. For this reason, "Issues" endpoints may return both issues and pull requests in the response. You can identify pull requests by the `pull_request` key. Be aware that the `id` of a pull request returned from "Issues" endpoints will be an _issue id_. To find out the pull request id, use the "[List pull requests](https://docs.github.com/rest/pulls/pulls#list-pull-requests)" endpoint. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listForRepo: API.PaginatedOperationMethod<ListForRepoRequest, ListForRepoResponse, ListForRepoError, GithubOpContext, Issue>;
export type ListIssueArtifactsError = GithubOpError;
/** List issue artifacts Lists artifacts attached to an issue. Results are ordered by artifact number. The `type` parameter filters the response to artifacts of one type. Results can be requested by page. The page defaults to `1`; the page size defaults to `30` and can be set from `1` to `100`. The response is a bare array and does not include pagination metadata such as a `Link` header, a total count, or the service's `has_next_page` signal. */
export declare const listIssueArtifacts: API.PaginatedOperationMethod<ListIssueArtifactsRequest, ListIssueArtifactsResponse, ListIssueArtifactsError, GithubOpContext, IssueArtifact>;
export type ListIssueFieldValuesForIssueError = GithubOpError;
/** List issue field values for an issue Lists all issue field values for an issue. */
export declare const listIssueFieldValuesForIssue: API.PaginatedOperationMethod<ListIssueFieldValuesForIssueRequest, ListIssueFieldValuesForIssueResponse, ListIssueFieldValuesForIssueError, GithubOpContext, IssueFieldValue>;
export type ListLabelsForMilestoneError = GithubOpError;
/** List labels for issues in a milestone Lists labels for issues in a milestone. */
export declare const listLabelsForMilestone: API.PaginatedOperationMethod<ListLabelsForMilestoneRequest, ListLabelsForMilestoneResponse, ListLabelsForMilestoneError, GithubOpContext, Label>;
export type ListLabelsForRepoError = GithubOpError;
/** List labels for a repository Lists all labels for a repository. */
export declare const listLabelsForRepo: API.PaginatedOperationMethod<ListLabelsForRepoRequest, ListLabelsForRepoResponse, ListLabelsForRepoError, GithubOpContext, Label>;
export type ListLabelsOnIssueError = GithubOpError;
/** List labels for an issue Lists all labels for an issue. */
export declare const listLabelsOnIssue: API.PaginatedOperationMethod<ListLabelsOnIssueRequest, ListLabelsOnIssueResponse, ListLabelsOnIssueError, GithubOpContext, Label>;
export type ListMilestonesError = GithubOpError;
/** List milestones Lists milestones for a repository. */
export declare const listMilestones: API.PaginatedOperationMethod<ListMilestonesRequest, ListMilestonesResponse, ListMilestonesError, GithubOpContext, Milestone>;
export type ListRelatesToError = GithubOpError;
/** List issues related to an issue You can use the REST API to list the issues that are related to an issue. This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listRelatesTo: API.PaginatedOperationMethod<ListRelatesToRequest, ListRelatesToResponse, ListRelatesToError, GithubOpContext, Issue>;
export type ListSubIssuesError = GithubOpError;
/** List sub-issues You can use the REST API to list the sub-issues on an issue. This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listSubIssues: API.PaginatedOperationMethod<ListSubIssuesRequest, ListSubIssuesResponse, ListSubIssuesError, GithubOpContext, Issue>;
export type ListSuggestionsError = GithubOpError;
/** List issue suggestions Lists the suggestions on an issue. A suggestion is an agent-proposed change to an issue's type, labels, fields, assignees, or closed state that a maintainer can approve or dismiss. By default only pending suggestions are returned. Use `state=all` to return suggestions in every state, or `state=<state>` to filter to a single state. Use `action=<action>` to return only suggestions for a specific change. This endpoint is only available while the issue suggestions feature is enabled for the repository, and only supports issues, not pull requests. Requires triage access to the repository. */
export declare const listSuggestions: API.PaginatedOperationMethod<ListSuggestionsRequest, ListSuggestionsResponse, ListSuggestionsError, GithubOpContext, IssueSuggestion>;
export type LockError = GithubOpError;
/** Lock an issue Users with push access can lock an issue or pull request's conversation. Note that, if you choose not to pass any parameters, you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." */
export declare const lock: API.OperationMethod<LockRequest, LockResponse, LockError, GithubOpContext>;
export type PinCommentError = GithubOpError;
/** Pin an issue comment You can use the REST API to pin comments on issues. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const pinComment: API.OperationMethod<PinCommentRequest, IssueComment, PinCommentError, GithubOpContext>;
export type RemoveAllLabelsError = GithubOpError;
/** Remove all labels from an issue Removes all labels from an issue. */
export declare const removeAllLabels: API.OperationMethod<RemoveAllLabelsRequest, RemoveAllLabelsResponse, RemoveAllLabelsError, GithubOpContext>;
export type RemoveAssigneesError = GithubOpError;
/** Remove assignees from an issue Removes one or more assignees from an issue. */
export declare const removeAssignees: API.OperationMethod<RemoveAssigneesRequest, Issue, RemoveAssigneesError, GithubOpContext>;
export type RemoveDependencyBlockedByError = GithubOpError;
/** Remove dependency an issue is blocked by You can use the REST API to remove a dependency that an issue is blocked by. Removing content too quickly using this endpoint may result in secondary rate limiting. For more information, see [Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits) and [Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api). This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass a specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const removeDependencyBlockedBy: API.OperationMethod<RemoveDependencyBlockedByRequest, Issue, RemoveDependencyBlockedByError, GithubOpContext>;
export type RemoveLabelError = GithubOpError;
/** Remove a label from an issue Removes the specified label from the issue, and returns the remaining labels on the issue. This endpoint returns a `404 Not Found` status if the label does not exist. */
export declare const removeLabel: API.OperationMethod<RemoveLabelRequest, RemoveLabelResponse, RemoveLabelError, GithubOpContext>;
export type RemoveRelatesToError = GithubOpError;
/** Remove a related issue You can use the REST API to remove a 'relates to' relationship between two issues. Removing content too quickly using this endpoint may result in secondary rate limiting. For more information, see [Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits) and [Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api). This endpoint supports the following custom media types. For more information, see [Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). - **`application/vnd.github.raw+json`**: Returns the raw Markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the Markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's Markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const removeRelatesTo: API.OperationMethod<RemoveRelatesToRequest, Issue, RemoveRelatesToError, GithubOpContext>;
export type RemoveSubIssueError = GithubOpError;
/** Remove sub-issue You can use the REST API to remove a sub-issue from an issue. Removing content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass a specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const removeSubIssue: API.OperationMethod<RemoveSubIssueRequest, Issue, RemoveSubIssueError, GithubOpContext>;
export type ReprioritizeSubIssueError = GithubOpError;
/** Reprioritize sub-issue You can use the REST API to reprioritize a sub-issue to a different position in the parent list. */
export declare const reprioritizeSubIssue: API.OperationMethod<ReprioritizeSubIssueRequest, Issue, ReprioritizeSubIssueError, GithubOpContext>;
export type SetIssueFieldValuesError = GithubOpError;
/** Set issue field values for an issue Set custom field values for an issue, replacing any existing values. You can set values for organization-level issue fields that have been defined for the repository's organization. This endpoint supports the following field data types: - **`text`**: String values for text fields - **`single_select`**: Option names for single-select fields (must match an existing option name) - **`number`**: Numeric values for number fields - **`date`**: ISO 8601 date strings for date fields This operation will replace all existing field values with the provided ones. If you want to add field values without replacing existing ones, use the `POST` endpoint instead. Only users with push access to the repository can set issue field values. If you don't have the proper permissions, you'll receive a `403 Forbidden` response. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const setIssueFieldValues: API.OperationMethod<SetIssueFieldValuesRequest, SetIssueFieldValuesResponse, SetIssueFieldValuesError, GithubOpContext>;
export type SetLabelsError = GithubOpError;
/** Set labels for an issue Removes any previous labels and sets the new labels for an issue. */
export declare const setLabels: API.OperationMethod<SetLabelsRequest, SetLabelsResponse, SetLabelsError, GithubOpContext>;
export type UnlockError = GithubOpError;
/** Unlock an issue Users with push access can unlock an issue's conversation. */
export declare const unlock: API.OperationMethod<UnlockRequest, UnlockResponse, UnlockError, GithubOpContext>;
export type UnpinCommentError = GithubOpError;
/** Unpin an issue comment You can use the REST API to unpin comments on issues. */
export declare const unpinComment: API.OperationMethod<UnpinCommentRequest, UnpinCommentResponse, UnpinCommentError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update an issue Issue owners and users with push access or Triage role can edit an issue. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, GithubOpContext>;
export type UpdateCommentError = GithubOpError;
/** Update an issue comment You can use the REST API to update comments on issues and pull requests. Every pull request is an issue, but not every issue is a pull request. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const updateComment: API.OperationMethod<UpdateCommentRequest, IssueComment, UpdateCommentError, GithubOpContext>;
export type UpdateIssueArtifactError = GithubOpError;
/** Update an issue artifact Updates the name, body, or both for an artifact attached to an issue. Updating an artifact requires permission to update the issue. The request can return `403` if the repository is read-only or locked, or a GitHub App installation has only `issues: read` permission. */
export declare const updateIssueArtifact: API.OperationMethod<UpdateIssueArtifactRequest, IssueArtifact, UpdateIssueArtifactError, GithubOpContext>;
export type UpdateLabelError = GithubOpError;
/** Update a label Updates a label using the given label name. */
export declare const updateLabel: API.OperationMethod<UpdateLabelRequest, Label, UpdateLabelError, GithubOpContext>;
export type UpdateMilestoneError = GithubOpError;
/** Update a milestone */
export declare const updateMilestone: API.OperationMethod<UpdateMilestoneRequest, Milestone, UpdateMilestoneError, GithubOpContext>;
//# sourceMappingURL=issues.d.ts.map