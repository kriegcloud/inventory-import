import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AttributeLimitExceededException_base: S.TaggedErrorClass<"AttributeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class AttributeLimitExceededException extends /*@__PURE__*/ AttributeLimitExceededException_base {
}
declare const BlockedException_base: S.TaggedErrorClass<"BlockedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BlockedException extends /*@__PURE__*/ BlockedException_base {
}
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const ClusterContainsCapacityProviderException_base: S.TaggedErrorClass<"ClusterContainsCapacityProviderException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsCapacityProviderException extends /*@__PURE__*/ ClusterContainsCapacityProviderException_base {
}
declare const ClusterContainsContainerInstancesException_base: S.TaggedErrorClass<"ClusterContainsContainerInstancesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsContainerInstancesException extends /*@__PURE__*/ ClusterContainsContainerInstancesException_base {
}
declare const ClusterContainsServicesException_base: S.TaggedErrorClass<"ClusterContainsServicesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsServicesException extends /*@__PURE__*/ ClusterContainsServicesException_base {
}
declare const ClusterContainsTasksException_base: S.TaggedErrorClass<"ClusterContainsTasksException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ClusterContainsTasksException extends /*@__PURE__*/ ClusterContainsTasksException_base {
}
declare const ClusterNotFoundException_base: S.TaggedErrorClass<"ClusterNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ClusterNotFoundException extends /*@__PURE__*/ ClusterNotFoundException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly resourceIds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DaemonNotActiveException_base: S.TaggedErrorClass<"DaemonNotActiveException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DaemonNotActiveException extends /*@__PURE__*/ DaemonNotActiveException_base {
}
declare const DaemonNotFoundException_base: S.TaggedErrorClass<"DaemonNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class DaemonNotFoundException extends /*@__PURE__*/ DaemonNotFoundException_base {
}
declare const GatewayNotFoundException_base: S.TaggedErrorClass<"GatewayNotFoundException", {
    readonly message: any;
}>;
export declare class GatewayNotFoundException extends /*@__PURE__*/ GatewayNotFoundException_base {
}
declare const InfrastructureRoleAccessDenied_base: S.TaggedErrorClass<"InfrastructureRoleAccessDenied", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InfrastructureRoleAccessDenied extends /*@__PURE__*/ InfrastructureRoleAccessDenied_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MissingVersionException_base: S.TaggedErrorClass<"MissingVersionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingVersionException extends /*@__PURE__*/ MissingVersionException_base {
}
declare const NamespaceNotFoundException_base: S.TaggedErrorClass<"NamespaceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class NamespaceNotFoundException extends /*@__PURE__*/ NamespaceNotFoundException_base {
}
declare const NoUpdateAvailableException_base: S.TaggedErrorClass<"NoUpdateAvailableException", {
    readonly message: any;
}>;
export declare class NoUpdateAvailableException extends /*@__PURE__*/ NoUpdateAvailableException_base {
}
declare const PlatformTaskDefinitionIncompatibilityException_base: S.TaggedErrorClass<"PlatformTaskDefinitionIncompatibilityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformTaskDefinitionIncompatibilityException extends /*@__PURE__*/ PlatformTaskDefinitionIncompatibilityException_base {
}
declare const PlatformUnknownException_base: S.TaggedErrorClass<"PlatformUnknownException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformUnknownException extends /*@__PURE__*/ PlatformUnknownException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerException_base: S.TaggedErrorClass<"ServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const ServiceDeploymentNotFoundException_base: S.TaggedErrorClass<"ServiceDeploymentNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ServiceDeploymentNotFoundException extends /*@__PURE__*/ ServiceDeploymentNotFoundException_base {
}
declare const ServiceLinkedRoleNotAssumable_base: S.TaggedErrorClass<"ServiceLinkedRoleNotAssumable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceLinkedRoleNotAssumable extends /*@__PURE__*/ ServiceLinkedRoleNotAssumable_base {
}
declare const ServiceNotActiveException_base: S.TaggedErrorClass<"ServiceNotActiveException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ServiceNotActiveException extends /*@__PURE__*/ ServiceNotActiveException_base {
}
declare const ServiceNotFoundException_base: S.TaggedErrorClass<"ServiceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ServiceNotFoundException extends /*@__PURE__*/ ServiceNotFoundException_base {
}
declare const ServiceRoleNotAssumable_base: S.TaggedErrorClass<"ServiceRoleNotAssumable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceRoleNotAssumable extends /*@__PURE__*/ ServiceRoleNotAssumable_base {
}
declare const TargetNotConnectedException_base: S.TaggedErrorClass<"TargetNotConnectedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TargetNotConnectedException extends /*@__PURE__*/ TargetNotConnectedException_base {
}
declare const TargetNotFoundException_base: S.TaggedErrorClass<"TargetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TargetNotFoundException extends /*@__PURE__*/ TargetNotFoundException_base {
}
declare const TaskSetNotFoundException_base: S.TaggedErrorClass<"TaskSetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TaskSetNotFoundException extends /*@__PURE__*/ TaskSetNotFoundException_base {
}
declare const UnsupportedFeatureException_base: S.TaggedErrorClass<"UnsupportedFeatureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedFeatureException extends /*@__PURE__*/ UnsupportedFeatureException_base {
}
declare const UpdateInProgressException_base: S.TaggedErrorClass<"UpdateInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class UpdateInProgressException extends /*@__PURE__*/ UpdateInProgressException_base {
}
export interface AssociateGatewayWithClusterRequest {
    gateway: string;
    cluster: string;
}
export type GatewayClusterAssociationStatus = "ACTIVE" | "DISASSOCIATING" | "INACTIVE" | (string & {});
export interface AssociateGatewayWithClusterResponse {
    gatewayArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: GatewayClusterAssociationStatus | undefined;
}
export type DeploymentLifecycleHookAction = "ROLLBACK" | "CONTINUE" | (string & {});
export interface ContinueServiceDeploymentRequest {
    serviceDeploymentArn: string;
    hookId: string;
    action?: DeploymentLifecycleHookAction | undefined;
}
export interface ContinueServiceDeploymentResponse {
    serviceDeploymentArn?: string | undefined;
}
export type ManagedScalingStatus = "ENABLED" | "DISABLED" | (string & {});
export type ManagedScalingTargetCapacity = number;
export type ManagedScalingStepSize = number;
export type ManagedScalingInstanceWarmupPeriod = number;
export interface ManagedScaling {
    status?: ManagedScalingStatus | undefined;
    targetCapacity?: number | undefined;
    minimumScalingStepSize?: number | undefined;
    maximumScalingStepSize?: number | undefined;
    instanceWarmupPeriod?: number | undefined;
}
export type ManagedTerminationProtection = "ENABLED" | "DISABLED" | (string & {});
export type ManagedDraining = "ENABLED" | "DISABLED" | (string & {});
export interface AutoScalingGroupProvider {
    autoScalingGroupArn: string;
    managedScaling?: ManagedScaling | undefined;
    managedTerminationProtection?: ManagedTerminationProtection | undefined;
    managedDraining?: ManagedDraining | undefined;
}
export type StringList = string[];
export interface ManagedInstancesNetworkConfiguration {
    subnets?: string[] | undefined;
    securityGroups?: string[] | undefined;
}
export type TaskVolumeStorageGiB = number;
export interface ManagedInstancesStorageConfiguration {
    storageSizeGiB?: number | undefined;
}
export interface ManagedInstancesLocalStorageConfiguration {
    useLocalStorage?: boolean | undefined;
}
export type ManagedInstancesMonitoringOptions = "BASIC" | "DETAILED" | (string & {});
export type CapacityOptionType = "ON_DEMAND" | "SPOT" | "RESERVED" | (string & {});
export type BoxedBoolean = boolean;
export type BoxedInteger = number;
export interface VCpuCountRangeRequest {
    min: number;
    max?: number | undefined;
}
export interface MemoryMiBRequest {
    min: number;
    max?: number | undefined;
}
export type CpuManufacturer = "intel" | "amd" | "amazon-web-services" | (string & {});
export type CpuManufacturerSet = CpuManufacturer[];
export type BoxedDouble = number;
export interface MemoryGiBPerVCpuRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export type ExcludedInstanceType = string;
export type ExcludedInstanceTypeSet = string[];
export type InstanceGeneration = "current" | "previous" | (string & {});
export type InstanceGenerationSet = InstanceGeneration[];
export type BareMetal = "included" | "required" | "excluded" | (string & {});
export type BurstablePerformance = "included" | "required" | "excluded" | (string & {});
export interface NetworkInterfaceCountRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export type LocalStorage = "included" | "required" | "excluded" | (string & {});
export type LocalStorageType = "hdd" | "ssd" | (string & {});
export type LocalStorageTypeSet = LocalStorageType[];
export interface TotalLocalStorageGBRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export interface BaselineEbsBandwidthMbpsRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export type AcceleratorType = "gpu" | "fpga" | "inference" | (string & {});
export type AcceleratorTypeSet = AcceleratorType[];
export interface AcceleratorCountRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export type AcceleratorManufacturer = "amazon-web-services" | "amd" | "nvidia" | "xilinx" | "habana" | (string & {});
export type AcceleratorManufacturerSet = AcceleratorManufacturer[];
export type AcceleratorName = "a100" | "inferentia" | "k520" | "k80" | "m60" | "radeon-pro-v520" | "t4" | "vu9p" | "v100" | "a10g" | "h100" | "t4g" | "l40s" | "l4" | (string & {});
export type AcceleratorNameSet = AcceleratorName[];
export interface AcceleratorTotalMemoryMiBRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export interface NetworkBandwidthGbpsRequest {
    min?: number | undefined;
    max?: number | undefined;
}
export type AllowedInstanceType = string;
export type AllowedInstanceTypeSet = string[];
export interface InstanceRequirementsRequest {
    vCpuCount: VCpuCountRangeRequest;
    memoryMiB: MemoryMiBRequest;
    cpuManufacturers?: CpuManufacturer[] | undefined;
    memoryGiBPerVCpu?: MemoryGiBPerVCpuRequest | undefined;
    excludedInstanceTypes?: string[] | undefined;
    instanceGenerations?: InstanceGeneration[] | undefined;
    spotMaxPricePercentageOverLowestPrice?: number | undefined;
    onDemandMaxPricePercentageOverLowestPrice?: number | undefined;
    bareMetal?: BareMetal | undefined;
    burstablePerformance?: BurstablePerformance | undefined;
    requireHibernateSupport?: boolean | undefined;
    networkInterfaceCount?: NetworkInterfaceCountRequest | undefined;
    localStorage?: LocalStorage | undefined;
    localStorageTypes?: LocalStorageType[] | undefined;
    totalLocalStorageGB?: TotalLocalStorageGBRequest | undefined;
    baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsRequest | undefined;
    acceleratorTypes?: AcceleratorType[] | undefined;
    acceleratorCount?: AcceleratorCountRequest | undefined;
    acceleratorManufacturers?: AcceleratorManufacturer[] | undefined;
    acceleratorNames?: AcceleratorName[] | undefined;
    acceleratorTotalMemoryMiB?: AcceleratorTotalMemoryMiBRequest | undefined;
    networkBandwidthGbps?: NetworkBandwidthGbpsRequest | undefined;
    allowedInstanceTypes?: string[] | undefined;
    maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number | undefined;
}
export type CapacityReservationPreference = "RESERVATIONS_ONLY" | "RESERVATIONS_FIRST" | "RESERVATIONS_EXCLUDED" | (string & {});
export interface CapacityReservationRequest {
    reservationGroupArn?: string | undefined;
    reservationPreference?: CapacityReservationPreference | undefined;
}
export interface InstanceLaunchTemplate {
    ec2InstanceProfileArn: string;
    networkConfiguration: ManagedInstancesNetworkConfiguration;
    storageConfiguration?: ManagedInstancesStorageConfiguration | undefined;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration | undefined;
    monitoring?: ManagedInstancesMonitoringOptions | undefined;
    capacityOptionType?: CapacityOptionType | undefined;
    instanceMetadataTagsPropagation?: boolean | undefined;
    instanceRequirements?: InstanceRequirementsRequest | undefined;
    fipsEnabled?: boolean | undefined;
    capacityReservations?: CapacityReservationRequest | undefined;
    nitroEnclavesEnabled?: boolean | undefined;
}
export type PropagateMITags = "CAPACITY_PROVIDER" | "NONE" | (string & {});
export interface InfrastructureOptimization {
    scaleInAfter?: number | undefined;
}
export type AutoRepairActionsStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AutoRepairConfiguration {
    actionsStatus?: AutoRepairActionsStatus | undefined;
}
export interface CreateManagedInstancesProviderConfiguration {
    infrastructureRoleArn: string;
    instanceLaunchTemplate: InstanceLaunchTemplate;
    propagateTags?: PropagateMITags | undefined;
    infrastructureOptimization?: InfrastructureOptimization | undefined;
    autoRepairConfiguration?: AutoRepairConfiguration | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type Tags = Tag[];
export interface CreateCapacityProviderRequest {
    name: string;
    cluster?: string | undefined;
    autoScalingGroupProvider?: AutoScalingGroupProvider | undefined;
    managedInstancesProvider?: CreateManagedInstancesProviderConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export type CapacityProviderStatus = "PROVISIONING" | "ACTIVE" | "DEPROVISIONING" | "INACTIVE" | (string & {});
export interface ManagedInstancesProvider {
    infrastructureRoleArn?: string | undefined;
    instanceLaunchTemplate?: InstanceLaunchTemplate | undefined;
    propagateTags?: PropagateMITags | undefined;
    infrastructureOptimization?: InfrastructureOptimization | undefined;
    autoRepairConfiguration?: AutoRepairConfiguration | undefined;
}
export type CapacityProviderUpdateStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export type CapacityProviderType = "EC2_AUTOSCALING" | "MANAGED_INSTANCES" | "FARGATE" | "FARGATE_SPOT" | (string & {});
export interface CapacityProvider {
    capacityProviderArn?: string | undefined;
    name?: string | undefined;
    cluster?: string | undefined;
    status?: CapacityProviderStatus | undefined;
    autoScalingGroupProvider?: AutoScalingGroupProvider | undefined;
    managedInstancesProvider?: ManagedInstancesProvider | undefined;
    updateStatus?: CapacityProviderUpdateStatus | undefined;
    updateStatusReason?: string | undefined;
    tags?: Tag[] | undefined;
    type?: CapacityProviderType | undefined;
}
export interface CreateCapacityProviderResponse {
    capacityProvider?: CapacityProvider | undefined;
}
export type ClusterSettingName = "containerInsights" | (string & {});
export interface ClusterSetting {
    name?: ClusterSettingName | undefined;
    value?: string | undefined;
}
export type ClusterSettings = ClusterSetting[];
export type ExecuteCommandLogging = "NONE" | "DEFAULT" | "OVERRIDE" | (string & {});
export interface ExecuteCommandLogConfiguration {
    cloudWatchLogGroupName?: string | undefined;
    cloudWatchEncryptionEnabled?: boolean | undefined;
    s3BucketName?: string | undefined;
    s3EncryptionEnabled?: boolean | undefined;
    s3KeyPrefix?: string | undefined;
}
export interface ExecuteCommandConfiguration {
    kmsKeyId?: string | undefined;
    logging?: ExecuteCommandLogging | undefined;
    logConfiguration?: ExecuteCommandLogConfiguration | undefined;
}
export interface ManagedStorageConfiguration {
    kmsKeyId?: string | undefined;
    fargateEphemeralStorageKmsKeyId?: string | undefined;
}
export interface ClusterConfiguration {
    executeCommandConfiguration?: ExecuteCommandConfiguration | undefined;
    managedStorageConfiguration?: ManagedStorageConfiguration | undefined;
}
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string;
    weight?: number | undefined;
    base?: number | undefined;
}
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export interface ClusterServiceConnectDefaultsRequest {
    namespace: string;
}
export interface CreateClusterRequest {
    clusterName?: string | undefined;
    tags?: Tag[] | undefined;
    settings?: ClusterSetting[] | undefined;
    configuration?: ClusterConfiguration | undefined;
    capacityProviders?: string[] | undefined;
    defaultCapacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    serviceConnectDefaults?: ClusterServiceConnectDefaultsRequest | undefined;
}
export interface KeyValuePair {
    name?: string | undefined;
    value?: string | undefined;
}
export type Statistics = KeyValuePair[];
export type AttachmentDetails = KeyValuePair[];
export interface Attachment {
    id?: string | undefined;
    type?: string | undefined;
    status?: string | undefined;
    details?: KeyValuePair[] | undefined;
}
export type Attachments = Attachment[];
export interface ClusterServiceConnectDefaults {
    namespace?: string | undefined;
}
export interface Cluster {
    clusterArn?: string | undefined;
    clusterName?: string | undefined;
    configuration?: ClusterConfiguration | undefined;
    status?: string | undefined;
    registeredContainerInstancesCount?: number | undefined;
    runningTasksCount?: number | undefined;
    pendingTasksCount?: number | undefined;
    activeServicesCount?: number | undefined;
    statistics?: KeyValuePair[] | undefined;
    tags?: Tag[] | undefined;
    settings?: ClusterSetting[] | undefined;
    capacityProviders?: string[] | undefined;
    defaultCapacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    attachments?: Attachment[] | undefined;
    attachmentsStatus?: string | undefined;
    serviceConnectDefaults?: ClusterServiceConnectDefaults | undefined;
}
export interface CreateClusterResponse {
    cluster?: Cluster | undefined;
}
export type DaemonDrainPercent = number;
export interface DaemonAlarmConfiguration {
    alarmNames?: string[] | undefined;
    enable?: boolean | undefined;
}
export interface DaemonDeploymentConfiguration {
    drainPercent?: number | undefined;
    alarms?: DaemonAlarmConfiguration | undefined;
    bakeTimeInMinutes?: number | undefined;
}
export type DaemonPropagateTags = "DAEMON" | "NONE" | (string & {});
export interface CreateDaemonRequest {
    daemonName: string;
    clusterArn?: string | undefined;
    daemonTaskDefinitionArn: string;
    capacityProviderArns: string[];
    deploymentConfiguration?: DaemonDeploymentConfiguration | undefined;
    tags?: Tag[] | undefined;
    propagateTags?: DaemonPropagateTags | undefined;
    enableECSManagedTags?: boolean | undefined;
    enableExecuteCommand?: boolean | undefined;
    clientToken?: string | undefined;
    critical?: boolean | undefined;
}
export type DaemonStatus = "ACTIVE" | "DELETE_IN_PROGRESS" | (string & {});
export interface CreateDaemonResponse {
    daemonArn?: string | undefined;
    status?: DaemonStatus | undefined;
    createdAt?: Date | undefined;
    deploymentArn?: string | undefined;
}
export interface ExpressGatewayServiceAwsLogsConfiguration {
    logGroup: string;
    logStreamPrefix: string;
}
export interface ExpressGatewayRepositoryCredentials {
    credentialsParameter?: string | undefined;
}
export type EnvironmentVariables = KeyValuePair[];
export interface Secret {
    name: string;
    valueFrom: string;
}
export type SecretList = Secret[];
export interface ExpressGatewayContainer {
    image: string;
    containerPort?: number | undefined;
    awsLogsConfiguration?: ExpressGatewayServiceAwsLogsConfiguration | undefined;
    repositoryCredentials?: ExpressGatewayRepositoryCredentials | undefined;
    command?: string[] | undefined;
    environment?: KeyValuePair[] | undefined;
    secrets?: Secret[] | undefined;
}
export interface ExpressGatewayServiceNetworkConfiguration {
    securityGroups?: string[] | undefined;
    subnets?: string[] | undefined;
}
export type ExpressCpuArchitecture = "X86_64" | "ARM64" | (string & {});
export type ExpressGatewayServiceScalingMetric = "AVERAGE_CPU" | "AVERAGE_MEMORY" | "REQUEST_COUNT_PER_TARGET" | (string & {});
export interface ExpressGatewayScalingTarget {
    minTaskCount?: number | undefined;
    maxTaskCount?: number | undefined;
    autoScalingMetric?: ExpressGatewayServiceScalingMetric | undefined;
    autoScalingTargetValue?: number | undefined;
}
export interface CreateExpressGatewayServiceRequest {
    executionRoleArn?: string | undefined;
    infrastructureRoleArn: string;
    serviceName?: string | undefined;
    cluster?: string | undefined;
    healthCheckPath?: string | undefined;
    primaryContainer?: ExpressGatewayContainer | undefined;
    taskRoleArn?: string | undefined;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    cpuArchitecture?: ExpressCpuArchitecture | undefined;
    scalingTarget?: ExpressGatewayScalingTarget | undefined;
    tags?: Tag[] | undefined;
    taskDefinitionArn?: string | undefined;
}
export type ExpressGatewayServiceStatusCode = "ACTIVE" | "DRAINING" | "INACTIVE" | (string & {});
export interface ExpressGatewayServiceStatus {
    statusCode?: ExpressGatewayServiceStatusCode | undefined;
    statusReason?: string | undefined;
}
export type AccessType = "PUBLIC" | "PRIVATE" | (string & {});
export interface IngressPathSummary {
    accessType: AccessType;
    endpoint: string;
}
export type IngressPathSummaries = IngressPathSummary[];
export interface ExpressGatewayServiceConfiguration {
    serviceRevisionArn?: string | undefined;
    executionRoleArn?: string | undefined;
    taskRoleArn?: string | undefined;
    taskDefinitionArn?: string | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    cpuArchitecture?: ExpressCpuArchitecture | undefined;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration | undefined;
    healthCheckPath?: string | undefined;
    primaryContainer?: ExpressGatewayContainer | undefined;
    scalingTarget?: ExpressGatewayScalingTarget | undefined;
    ingressPaths?: IngressPathSummary[] | undefined;
    createdAt?: Date | undefined;
}
export type ExpressGatewayServiceConfigurations = ExpressGatewayServiceConfiguration[];
export interface ECSExpressGatewayService {
    cluster?: string | undefined;
    serviceName?: string | undefined;
    serviceArn?: string | undefined;
    infrastructureRoleArn?: string | undefined;
    status?: ExpressGatewayServiceStatus | undefined;
    currentDeployment?: string | undefined;
    activeConfigurations?: ExpressGatewayServiceConfiguration[] | undefined;
    tags?: Tag[] | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService | undefined;
}
export type GatewayElbIpAddressType = "ipv4" | "dualstack" | "dualstack-without-public-ipv4" | (string & {});
export interface GatewayElbNetworkConfiguration {
    inboundSecurityGroup?: string | undefined;
    subnets?: string[] | undefined;
    ipAddressType?: GatewayElbIpAddressType | undefined;
}
export type GatewayElbScheme = "internet-facing" | "internal" | (string & {});
export interface GatewayElbAccessLogS3Destination {
    bucket: string;
    prefix?: string | undefined;
}
export type GatewayElbAccessLogDestination = {
    s3: GatewayElbAccessLogS3Destination;
};
export interface GatewayElbAccessLogConfiguration {
    destination?: GatewayElbAccessLogDestination | undefined;
}
export type GatewayAlbProtocol = "HTTP" | "HTTPS" | (string & {});
export type GatewayAlbDesyncMitigationMode = "monitor" | "defensive" | "strictest" | (string & {});
export interface GatewayTestTrafficHeader {
    name: string;
    values: string[];
}
export interface GatewayAlbTestTrafficRules {
    header?: GatewayTestTrafficHeader | undefined;
}
export interface HostSharedAlbConfiguration {
    networkConfiguration?: GatewayElbNetworkConfiguration | undefined;
    scheme?: GatewayElbScheme | undefined;
    webACLArn?: string | undefined;
    accessLogs?: GatewayElbAccessLogConfiguration | undefined;
    port?: number | undefined;
    protocol?: GatewayAlbProtocol | undefined;
    maxAlbCount?: number | undefined;
    httpDesync?: GatewayAlbDesyncMitigationMode | undefined;
    testTrafficRules?: GatewayAlbTestTrafficRules | undefined;
}
export type GatewayConfiguration = {
    hostSharedAlb: HostSharedAlbConfiguration;
};
export type PropagateGatewayTags = "NONE" | "GATEWAY" | (string & {});
export interface CreateGatewayRequest {
    name: string;
    infrastructureRoleArn: string;
    clientToken?: string | undefined;
    deletionProtection?: boolean | undefined;
    configuration: GatewayConfiguration;
    tags?: Tag[] | undefined;
    propagateTags?: PropagateGatewayTags | undefined;
}
export type GatewayStatus = "ACTIVE" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | "DELETED" | (string & {});
export interface CreateGatewayResponse {
    gatewayArn?: string | undefined;
    name?: string | undefined;
    status?: GatewayStatus | undefined;
}
export type AvailabilityZoneRebalancing = "ENABLED" | "DISABLED" | (string & {});
export interface AdvancedConfiguration {
    alternateTargetGroupArn?: string | undefined;
    productionListenerRule?: string | undefined;
    testListenerRule?: string | undefined;
    roleArn?: string | undefined;
}
export interface LoadBalancer {
    targetGroupArn?: string | undefined;
    loadBalancerName?: string | undefined;
    containerName?: string | undefined;
    containerPort?: number | undefined;
    advancedConfiguration?: AdvancedConfiguration | undefined;
}
export type LoadBalancers = LoadBalancer[];
export interface ServiceRegistry {
    registryArn?: string | undefined;
    port?: number | undefined;
    containerName?: string | undefined;
    containerPort?: number | undefined;
}
export type ServiceRegistries = ServiceRegistry[];
export type LaunchType = "EC2" | "FARGATE" | "EXTERNAL" | "MANAGED_INSTANCES" | (string & {});
export type ThresholdType = "COUNT" | "BOUNDED_PERCENT" | "UNBOUNDED_PERCENT" | (string & {});
export interface ThresholdConfiguration {
    type: ThresholdType;
    value: number;
}
export interface DeploymentCircuitBreaker {
    enable: boolean;
    rollback: boolean;
    resetOnHealthyTask?: boolean | undefined;
    thresholdConfiguration?: ThresholdConfiguration | undefined;
}
export interface DeploymentAlarms {
    alarmNames: string[];
    rollback: boolean;
    enable: boolean;
}
export type DeploymentStrategy = "ROLLING" | "BLUE_GREEN" | "LINEAR" | "CANARY" | (string & {});
export type DeploymentLifecycleHookTargetType = "AWS_LAMBDA" | "PAUSE" | (string & {});
export type IAMRoleArn = string;
export type DeploymentLifecycleHookStage = "RECONCILE_SERVICE" | "PRE_SCALE_UP" | "POST_SCALE_UP" | "TEST_TRAFFIC_SHIFT" | "POST_TEST_TRAFFIC_SHIFT" | "PRE_PRODUCTION_TRAFFIC_SHIFT" | "PRODUCTION_TRAFFIC_SHIFT" | "POST_PRODUCTION_TRAFFIC_SHIFT" | (string & {});
export type DeploymentLifecycleHookStageList = DeploymentLifecycleHookStage[];
export type HookDetails = unknown;
export type DeploymentLifecycleHookDuration = number;
export interface DeploymentLifecycleHookTimeoutConfiguration {
    timeoutInMinutes?: number | undefined;
    action?: DeploymentLifecycleHookAction | undefined;
}
export interface DeploymentLifecycleHook {
    targetType?: DeploymentLifecycleHookTargetType | undefined;
    hookTargetArn?: string | undefined;
    roleArn?: string | undefined;
    lifecycleStages?: DeploymentLifecycleHookStage[] | undefined;
    hookDetails?: any | undefined;
    timeoutConfiguration?: DeploymentLifecycleHookTimeoutConfiguration | undefined;
}
export type DeploymentLifecycleHookList = DeploymentLifecycleHook[];
export interface LinearConfiguration {
    stepPercent?: number | undefined;
    stepBakeTimeInMinutes?: number | undefined;
}
export interface CanaryConfiguration {
    canaryPercent?: number | undefined;
    canaryBakeTimeInMinutes?: number | undefined;
}
export type HealthyPercentInteger = number;
export type ServiceRevisionCleanup = "BLOCKING" | "DEFERRED" | (string & {});
export interface DeploymentEarlySuccessCriteria {
    enable: boolean;
    healthyPercent?: number | undefined;
    sourceServiceRevisionCleanup?: ServiceRevisionCleanup | undefined;
}
export interface DeploymentConfiguration {
    deploymentCircuitBreaker?: DeploymentCircuitBreaker | undefined;
    maximumPercent?: number | undefined;
    minimumHealthyPercent?: number | undefined;
    alarms?: DeploymentAlarms | undefined;
    strategy?: DeploymentStrategy | undefined;
    bakeTimeInMinutes?: number | undefined;
    lifecycleHooks?: DeploymentLifecycleHook[] | undefined;
    linearConfiguration?: LinearConfiguration | undefined;
    canaryConfiguration?: CanaryConfiguration | undefined;
    earlySuccessCriteria?: DeploymentEarlySuccessCriteria | undefined;
}
export type PlacementConstraintType = "distinctInstance" | "memberOf" | (string & {});
export interface PlacementConstraint {
    type?: PlacementConstraintType | undefined;
    expression?: string | undefined;
}
export type PlacementConstraints = PlacementConstraint[];
export type PlacementStrategyType = "random" | "spread" | "binpack" | (string & {});
export interface PlacementStrategy {
    type?: PlacementStrategyType | undefined;
    field?: string | undefined;
}
export type PlacementStrategies = PlacementStrategy[];
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export interface AwsVpcConfiguration {
    subnets: string[];
    securityGroups?: string[] | undefined;
    assignPublicIp?: AssignPublicIp | undefined;
}
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration | undefined;
}
export type SchedulingStrategy = "REPLICA" | "DAEMON" | (string & {});
export type DeploymentControllerType = "ECS" | "CODE_DEPLOY" | "EXTERNAL" | (string & {});
export interface DeploymentController {
    type: DeploymentControllerType;
}
export type PropagateTags = "TASK_DEFINITION" | "SERVICE" | "NONE" | (string & {});
export type PortNumber = number;
export interface ServiceConnectTestTrafficHeaderMatchRules {
    exact: string;
}
export interface ServiceConnectTestTrafficHeaderRules {
    name: string;
    value?: ServiceConnectTestTrafficHeaderMatchRules | undefined;
}
export interface ServiceConnectTestTrafficRules {
    header: ServiceConnectTestTrafficHeaderRules;
}
export interface ServiceConnectClientAlias {
    port: number;
    dnsName?: string | undefined;
    testTrafficRules?: ServiceConnectTestTrafficRules | undefined;
}
export type ServiceConnectClientAliasList = ServiceConnectClientAlias[];
export type Duration = number;
export interface TimeoutConfiguration {
    idleTimeoutSeconds?: number | undefined;
    perRequestTimeoutSeconds?: number | undefined;
}
export interface ServiceConnectTlsCertificateAuthority {
    awsPcaAuthorityArn?: string | undefined;
}
export interface ServiceConnectTlsConfiguration {
    issuerCertificateAuthority: ServiceConnectTlsCertificateAuthority;
    kmsKey?: string | undefined;
    roleArn?: string | undefined;
}
export interface ServiceConnectService {
    portName: string;
    discoveryName?: string | undefined;
    clientAliases?: ServiceConnectClientAlias[] | undefined;
    ingressPortOverride?: number | undefined;
    timeout?: TimeoutConfiguration | undefined;
    tls?: ServiceConnectTlsConfiguration | undefined;
}
export type ServiceConnectServiceList = ServiceConnectService[];
export type LogDriver = "json-file" | "syslog" | "journald" | "gelf" | "fluentd" | "awslogs" | "splunk" | "awsfirelens" | (string & {});
export type LogConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface LogConfiguration {
    logDriver: LogDriver;
    options?: {
        [key: string]: string | undefined;
    } | undefined;
    secretOptions?: Secret[] | undefined;
}
export type ServiceConnectAccessLoggingFormat = "TEXT" | "JSON" | (string & {});
export type ServiceConnectIncludeQueryParameters = "DISABLED" | "ENABLED" | (string & {});
export interface ServiceConnectAccessLogConfiguration {
    format: ServiceConnectAccessLoggingFormat;
    includeQueryParameters?: ServiceConnectIncludeQueryParameters | undefined;
}
export type ServiceConnectContainerLogLevel = "debug" | "info" | (string & {});
export type ServiceConnectContainerConfiguration = {
    logLevel: ServiceConnectContainerLogLevel;
};
export type ServiceConnectContainerConfigurations = ServiceConnectContainerConfiguration[];
export interface ServiceConnectConfiguration {
    enabled: boolean;
    namespace?: string | undefined;
    services?: ServiceConnectService[] | undefined;
    logConfiguration?: LogConfiguration | undefined;
    accessLogConfiguration?: ServiceConnectAccessLogConfiguration | undefined;
    containerConfigurations?: ServiceConnectContainerConfiguration[] | undefined;
}
export type ECSVolumeName = string;
export type EBSKMSKeyId = string;
export type EBSVolumeType = string;
export type EBSSnapshotId = string;
export type EBSResourceType = "volume" | (string & {});
export interface EBSTagSpecification {
    resourceType: EBSResourceType;
    tags?: Tag[] | undefined;
    propagateTags?: PropagateTags | undefined;
}
export type EBSTagSpecifications = EBSTagSpecification[];
export type TaskFilesystemType = "ext3" | "ext4" | "xfs" | "ntfs" | (string & {});
export interface ServiceManagedEBSVolumeConfiguration {
    encrypted?: boolean | undefined;
    kmsKeyId?: string | undefined;
    volumeType?: string | undefined;
    sizeInGiB?: number | undefined;
    snapshotId?: string | undefined;
    volumeInitializationRate?: number | undefined;
    iops?: number | undefined;
    throughput?: number | undefined;
    tagSpecifications?: EBSTagSpecification[] | undefined;
    roleArn: string;
    filesystemType?: TaskFilesystemType | undefined;
}
export interface ServiceVolumeConfiguration {
    name: string;
    managedEBSVolume?: ServiceManagedEBSVolumeConfiguration | undefined;
}
export type ServiceVolumeConfigurations = ServiceVolumeConfiguration[];
export interface VpcLatticeAdvancedConfiguration {
    alternateTargetGroupArn?: string | undefined;
    productionListenerRule?: string | undefined;
    testListenerRule?: string | undefined;
}
export interface VpcLatticeConfiguration {
    roleArn: string;
    targetGroupArn: string;
    portName: string;
    advancedConfiguration?: VpcLatticeAdvancedConfiguration | undefined;
}
export type VpcLatticeConfigurations = VpcLatticeConfiguration[];
export type GatewayConnectorHealthCheckProtocol = "HTTP" | "HTTPS" | (string & {});
export interface GatewayConnectorHealthCheckMatcher {
    httpCode?: string | undefined;
    grpcCode?: string | undefined;
}
export interface GatewayConnectorHealthCheck {
    healthCheckProtocol?: GatewayConnectorHealthCheckProtocol | undefined;
    healthCheckPort?: number | undefined;
    healthCheckPath?: string | undefined;
    healthCheckTimeoutSeconds?: number | undefined;
    healthCheckIntervalSeconds?: number | undefined;
    healthyThresholdCount?: number | undefined;
    unhealthyThresholdCount?: number | undefined;
    matcher?: GatewayConnectorHealthCheckMatcher | undefined;
}
export type AccessTypeList = AccessType[];
export interface GatewayConnectorFilters {
    accessTypes?: AccessType[] | undefined;
}
export interface GatewayConnector {
    portName: string;
    healthCheck?: GatewayConnectorHealthCheck | undefined;
    filters?: GatewayConnectorFilters | undefined;
}
export type GatewayConnectorList = GatewayConnector[];
export type MetricName = string;
export type MetricNamesList = string[];
export type MetricResolutionSeconds = number;
export interface MetricConfiguration {
    metricNames: string[];
    resolutionSeconds: number;
}
export type MetricConfigurationList = MetricConfiguration[];
export interface MonitoringConfiguration {
    metricConfigurations?: MetricConfiguration[] | undefined;
}
export interface CreateServiceRequest {
    cluster?: string | undefined;
    serviceName: string;
    taskDefinition?: string | undefined;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    desiredCount?: number | undefined;
    clientToken?: string | undefined;
    launchType?: LaunchType | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    platformVersion?: string | undefined;
    role?: string | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    placementConstraints?: PlacementConstraint[] | undefined;
    placementStrategy?: PlacementStrategy[] | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    healthCheckGracePeriodSeconds?: number | undefined;
    schedulingStrategy?: SchedulingStrategy | undefined;
    deploymentController?: DeploymentController | undefined;
    tags?: Tag[] | undefined;
    enableECSManagedTags?: boolean | undefined;
    propagateTags?: PropagateTags | undefined;
    enableExecuteCommand?: boolean | undefined;
    serviceConnectConfiguration?: ServiceConnectConfiguration | undefined;
    volumeConfigurations?: ServiceVolumeConfiguration[] | undefined;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[] | undefined;
    gatewayConnectors?: GatewayConnector[] | undefined;
    monitoring?: MonitoringConfiguration | undefined;
}
export type ScaleUnit = "PERCENT" | (string & {});
export interface Scale {
    value?: number | undefined;
    unit?: ScaleUnit | undefined;
}
export type StabilityStatus = "STEADY_STATE" | "STABILIZING" | (string & {});
export interface DeploymentEphemeralStorage {
    kmsKeyId?: string | undefined;
}
export interface TaskSet {
    id?: string | undefined;
    taskSetArn?: string | undefined;
    serviceArn?: string | undefined;
    clusterArn?: string | undefined;
    startedBy?: string | undefined;
    externalId?: string | undefined;
    status?: string | undefined;
    taskDefinition?: string | undefined;
    computedDesiredCount?: number | undefined;
    pendingCount?: number | undefined;
    runningCount?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    launchType?: LaunchType | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    platformVersion?: string | undefined;
    platformFamily?: string | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    scale?: Scale | undefined;
    stabilityStatus?: StabilityStatus | undefined;
    stabilityStatusAt?: Date | undefined;
    tags?: Tag[] | undefined;
    fargateEphemeralStorage?: DeploymentEphemeralStorage | undefined;
}
export type TaskSets = TaskSet[];
export type DeploymentRolloutState = "COMPLETED" | "FAILED" | "IN_PROGRESS" | (string & {});
export interface ServiceConnectServiceResource {
    discoveryName?: string | undefined;
    discoveryArn?: string | undefined;
}
export type ServiceConnectServiceResourceList = ServiceConnectServiceResource[];
export interface Deployment {
    id?: string | undefined;
    status?: string | undefined;
    taskDefinition?: string | undefined;
    desiredCount?: number | undefined;
    pendingCount?: number | undefined;
    runningCount?: number | undefined;
    failedTasks?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    launchType?: LaunchType | undefined;
    platformVersion?: string | undefined;
    platformFamily?: string | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    rolloutState?: DeploymentRolloutState | undefined;
    rolloutStateReason?: string | undefined;
    serviceConnectConfiguration?: ServiceConnectConfiguration | undefined;
    serviceConnectResources?: ServiceConnectServiceResource[] | undefined;
    volumeConfigurations?: ServiceVolumeConfiguration[] | undefined;
    fargateEphemeralStorage?: DeploymentEphemeralStorage | undefined;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[] | undefined;
}
export type Deployments = Deployment[];
export interface ServiceEvent {
    id?: string | undefined;
    createdAt?: Date | undefined;
    message?: string | undefined;
}
export type ServiceEvents = ServiceEvent[];
export interface ServiceCurrentRevisionSummary {
    arn?: string | undefined;
    requestedTaskCount?: number | undefined;
    runningTaskCount?: number | undefined;
    pendingTaskCount?: number | undefined;
}
export type ServiceCurrentRevisionSummaryList = ServiceCurrentRevisionSummary[];
export type ResourceManagementType = "CUSTOMER" | "ECS" | (string & {});
export interface Service {
    serviceArn?: string | undefined;
    serviceName?: string | undefined;
    clusterArn?: string | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    status?: string | undefined;
    desiredCount?: number | undefined;
    runningCount?: number | undefined;
    pendingCount?: number | undefined;
    launchType?: LaunchType | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    platformVersion?: string | undefined;
    platformFamily?: string | undefined;
    taskDefinition?: string | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    taskSets?: TaskSet[] | undefined;
    deployments?: Deployment[] | undefined;
    roleArn?: string | undefined;
    events?: ServiceEvent[] | undefined;
    createdAt?: Date | undefined;
    currentServiceDeployment?: string | undefined;
    currentServiceRevisions?: ServiceCurrentRevisionSummary[] | undefined;
    placementConstraints?: PlacementConstraint[] | undefined;
    placementStrategy?: PlacementStrategy[] | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    healthCheckGracePeriodSeconds?: number | undefined;
    schedulingStrategy?: SchedulingStrategy | undefined;
    deploymentController?: DeploymentController | undefined;
    tags?: Tag[] | undefined;
    createdBy?: string | undefined;
    enableECSManagedTags?: boolean | undefined;
    propagateTags?: PropagateTags | undefined;
    enableExecuteCommand?: boolean | undefined;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing | undefined;
    resourceManagementType?: ResourceManagementType | undefined;
}
export interface CreateServiceResponse {
    service?: Service | undefined;
}
export interface CreateTaskSetRequest {
    service: string;
    cluster: string;
    externalId?: string | undefined;
    taskDefinition: string;
    networkConfiguration?: NetworkConfiguration | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    launchType?: LaunchType | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    platformVersion?: string | undefined;
    scale?: Scale | undefined;
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateTaskSetResponse {
    taskSet?: TaskSet | undefined;
}
export type SettingName = "serviceLongArnFormat" | "taskLongArnFormat" | "containerInstanceLongArnFormat" | "awsvpcTrunking" | "containerInsights" | "fargateFIPSMode" | "tagResourceAuthorization" | "fargateTaskRetirementWaitPeriod" | "guardDutyActivate" | "defaultLogDriverMode" | "fargateEventWindows" | (string & {});
export interface DeleteAccountSettingRequest {
    name: SettingName;
    principalArn?: string | undefined;
}
export type SettingType = "user" | "aws_managed" | (string & {});
export interface Setting {
    name?: SettingName | undefined;
    value?: string | undefined;
    principalArn?: string | undefined;
    type?: SettingType | undefined;
}
export interface DeleteAccountSettingResponse {
    setting?: Setting | undefined;
}
export type TargetType = "container-instance" | (string & {});
export interface Attribute {
    name: string;
    value?: string | undefined;
    targetType?: TargetType | undefined;
    targetId?: string | undefined;
}
export type Attributes = Attribute[];
export interface DeleteAttributesRequest {
    cluster?: string | undefined;
    attributes: Attribute[];
}
export interface DeleteAttributesResponse {
    attributes?: Attribute[] | undefined;
}
export interface DeleteCapacityProviderRequest {
    capacityProvider: string;
    cluster?: string | undefined;
}
export interface DeleteCapacityProviderResponse {
    capacityProvider?: CapacityProvider | undefined;
}
export interface DeleteClusterRequest {
    cluster: string;
}
export interface DeleteClusterResponse {
    cluster?: Cluster | undefined;
}
export interface DeleteDaemonRequest {
    daemonArn: string;
}
export interface DeleteDaemonResponse {
    daemonArn?: string | undefined;
    status?: DaemonStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deploymentArn?: string | undefined;
}
export interface DeleteDaemonTaskDefinitionRequest {
    daemonTaskDefinition: string;
}
export interface DeleteDaemonTaskDefinitionResponse {
    daemonTaskDefinitionArn?: string | undefined;
}
export interface DeleteExpressGatewayServiceRequest {
    serviceArn: string;
}
export interface DeleteExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService | undefined;
}
export interface DeleteGatewayRequest {
    gateway: string;
}
export interface DeleteGatewayResponse {
    gatewayArn?: string | undefined;
    name?: string | undefined;
    status?: GatewayStatus | undefined;
}
export interface DeleteServiceRequest {
    cluster?: string | undefined;
    service: string;
    force?: boolean | undefined;
}
export interface DeleteServiceResponse {
    service?: Service | undefined;
}
export interface DeleteTaskDefinitionsRequest {
    taskDefinitions: string[];
}
export interface RepositoryCredentials {
    credentialsParameter: string;
}
export type TransportProtocol = "tcp" | "udp" | (string & {});
export type ApplicationProtocol = "http" | "http2" | "grpc" | (string & {});
export interface PortMapping {
    containerPort?: number | undefined;
    hostPort?: number | undefined;
    protocol?: TransportProtocol | undefined;
    name?: string | undefined;
    appProtocol?: ApplicationProtocol | undefined;
    containerPortRange?: string | undefined;
}
export type PortMappingList = PortMapping[];
export type IntegerList = number[];
export interface ContainerRestartPolicy {
    enabled: boolean;
    ignoredExitCodes?: number[] | undefined;
    restartAttemptPeriod?: number | undefined;
}
export type EnvironmentFileType = "s3" | (string & {});
export interface EnvironmentFile {
    value: string;
    type: EnvironmentFileType;
}
export type EnvironmentFiles = EnvironmentFile[];
export interface MountPoint {
    sourceVolume?: string | undefined;
    containerPath?: string | undefined;
    readOnly?: boolean | undefined;
}
export type MountPointList = MountPoint[];
export interface VolumeFrom {
    sourceContainer?: string | undefined;
    readOnly?: boolean | undefined;
}
export type VolumeFromList = VolumeFrom[];
export interface KernelCapabilities {
    add?: string[] | undefined;
    drop?: string[] | undefined;
}
export type DeviceCgroupPermission = "read" | "write" | "mknod" | (string & {});
export type DeviceCgroupPermissions = DeviceCgroupPermission[];
export interface Device {
    hostPath: string;
    containerPath?: string | undefined;
    permissions?: DeviceCgroupPermission[] | undefined;
}
export type DevicesList = Device[];
export interface Tmpfs {
    containerPath: string;
    size: number;
    mountOptions?: string[] | undefined;
}
export type TmpfsList = Tmpfs[];
export interface LinuxParameters {
    capabilities?: KernelCapabilities | undefined;
    devices?: Device[] | undefined;
    initProcessEnabled?: boolean | undefined;
    sharedMemorySize?: number | undefined;
    tmpfs?: Tmpfs[] | undefined;
    maxSwap?: number | undefined;
    swappiness?: number | undefined;
}
export type ContainerCondition = "START" | "COMPLETE" | "SUCCESS" | "HEALTHY" | (string & {});
export interface ContainerDependency {
    containerName: string;
    condition: ContainerCondition;
}
export type ContainerDependencies = ContainerDependency[];
export type VersionConsistency = "enabled" | "disabled" | (string & {});
export interface HostEntry {
    hostname: string;
    ipAddress: string;
}
export type HostEntryList = HostEntry[];
export type DockerLabelsMap = {
    [key: string]: string | undefined;
};
export type UlimitName = "core" | "cpu" | "data" | "fsize" | "locks" | "memlock" | "msgqueue" | "nice" | "nofile" | "nproc" | "rss" | "rtprio" | "rttime" | "sigpending" | "stack" | (string & {});
export interface Ulimit {
    name: UlimitName;
    softLimit: number;
    hardLimit: number;
}
export type UlimitList = Ulimit[];
export interface HealthCheck {
    command: string[];
    interval?: number | undefined;
    timeout?: number | undefined;
    retries?: number | undefined;
    startPeriod?: number | undefined;
}
export interface SystemControl {
    namespace?: string | undefined;
    value?: string | undefined;
}
export type SystemControls = SystemControl[];
export type ResourceType = "GPU" | "InferenceAccelerator" | "NeuronDevice" | (string & {});
export interface NvidiaMpsAllocation {
    memory: number;
    maxComputePercent?: number | undefined;
}
export type SharingStrategy = {
    nvidiaMps: NvidiaMpsAllocation;
};
export interface ResourceRequirement {
    value?: string | undefined;
    type: ResourceType;
    sharingStrategy?: SharingStrategy | undefined;
}
export type ResourceRequirements = ResourceRequirement[];
export type FirelensConfigurationType = "fluentd" | "fluentbit" | (string & {});
export type FirelensConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface FirelensConfiguration {
    type: FirelensConfigurationType;
    options?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ContainerDefinition {
    name?: string | undefined;
    image?: string | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
    cpu?: number | undefined;
    memory?: number | undefined;
    memoryReservation?: number | undefined;
    links?: string[] | undefined;
    portMappings?: PortMapping[] | undefined;
    essential?: boolean | undefined;
    restartPolicy?: ContainerRestartPolicy | undefined;
    entryPoint?: string[] | undefined;
    command?: string[] | undefined;
    environment?: KeyValuePair[] | undefined;
    environmentFiles?: EnvironmentFile[] | undefined;
    mountPoints?: MountPoint[] | undefined;
    volumesFrom?: VolumeFrom[] | undefined;
    linuxParameters?: LinuxParameters | undefined;
    secrets?: Secret[] | undefined;
    dependsOn?: ContainerDependency[] | undefined;
    startTimeout?: number | undefined;
    stopTimeout?: number | undefined;
    versionConsistency?: VersionConsistency | undefined;
    hostname?: string | undefined;
    user?: string | undefined;
    workingDirectory?: string | undefined;
    disableNetworking?: boolean | undefined;
    privileged?: boolean | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    dnsServers?: string[] | undefined;
    dnsSearchDomains?: string[] | undefined;
    extraHosts?: HostEntry[] | undefined;
    dockerSecurityOptions?: string[] | undefined;
    interactive?: boolean | undefined;
    pseudoTerminal?: boolean | undefined;
    dockerLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    ulimits?: Ulimit[] | undefined;
    logConfiguration?: LogConfiguration | undefined;
    healthCheck?: HealthCheck | undefined;
    systemControls?: SystemControl[] | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
    firelensConfiguration?: FirelensConfiguration | undefined;
    credentialSpecs?: string[] | undefined;
}
export type ContainerDefinitions = ContainerDefinition[];
export type NetworkMode = "bridge" | "host" | "awsvpc" | "none" | (string & {});
export interface HostVolumeProperties {
    sourcePath?: string | undefined;
}
export type Scope = "task" | "shared" | (string & {});
export type StringMap = {
    [key: string]: string | undefined;
};
export interface DockerVolumeConfiguration {
    scope?: Scope | undefined;
    autoprovision?: boolean | undefined;
    driver?: string | undefined;
    driverOpts?: {
        [key: string]: string | undefined;
    } | undefined;
    labels?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EFSTransitEncryption = "ENABLED" | "DISABLED" | (string & {});
export type EFSAuthorizationConfigIAM = "ENABLED" | "DISABLED" | (string & {});
export interface EFSAuthorizationConfig {
    accessPointId?: string | undefined;
    iam?: EFSAuthorizationConfigIAM | undefined;
}
export interface EFSVolumeConfiguration {
    fileSystemId: string;
    rootDirectory?: string | undefined;
    transitEncryption?: EFSTransitEncryption | undefined;
    transitEncryptionPort?: number | undefined;
    authorizationConfig?: EFSAuthorizationConfig | undefined;
}
export interface S3FilesVolumeConfiguration {
    fileSystemArn: string;
    rootDirectory?: string | undefined;
    transitEncryptionPort?: number | undefined;
    accessPointArn?: string | undefined;
}
export interface FSxWindowsFileServerAuthorizationConfig {
    credentialsParameter: string;
    domain: string;
}
export interface FSxWindowsFileServerVolumeConfiguration {
    fileSystemId: string;
    rootDirectory: string;
    authorizationConfig: FSxWindowsFileServerAuthorizationConfig;
}
export interface Volume {
    name?: string | undefined;
    host?: HostVolumeProperties | undefined;
    dockerVolumeConfiguration?: DockerVolumeConfiguration | undefined;
    efsVolumeConfiguration?: EFSVolumeConfiguration | undefined;
    s3filesVolumeConfiguration?: S3FilesVolumeConfiguration | undefined;
    fsxWindowsFileServerVolumeConfiguration?: FSxWindowsFileServerVolumeConfiguration | undefined;
    configuredAtLaunch?: boolean | undefined;
}
export type VolumeList = Volume[];
export type TaskDefinitionStatus = "ACTIVE" | "INACTIVE" | "DELETE_IN_PROGRESS" | (string & {});
export type RequiresAttributes = Attribute[];
export type TaskDefinitionPlacementConstraintType = "memberOf" | (string & {});
export interface TaskDefinitionPlacementConstraint {
    type?: TaskDefinitionPlacementConstraintType | undefined;
    expression?: string | undefined;
}
export type TaskDefinitionPlacementConstraints = TaskDefinitionPlacementConstraint[];
export type Compatibility = "EC2" | "FARGATE" | "EXTERNAL" | "MANAGED_INSTANCES" | (string & {});
export type CompatibilityList = Compatibility[];
export type CPUArchitecture = "X86_64" | "ARM64" | (string & {});
export type OSFamily = "WINDOWS_SERVER_2019_FULL" | "WINDOWS_SERVER_2019_CORE" | "WINDOWS_SERVER_2016_FULL" | "WINDOWS_SERVER_2004_CORE" | "WINDOWS_SERVER_2022_CORE" | "WINDOWS_SERVER_2022_FULL" | "WINDOWS_SERVER_2025_CORE" | "WINDOWS_SERVER_2025_FULL" | "WINDOWS_SERVER_20H2_CORE" | "LINUX" | (string & {});
export interface RuntimePlatform {
    cpuArchitecture?: CPUArchitecture | undefined;
    operatingSystemFamily?: OSFamily | undefined;
}
export interface InferenceAccelerator {
    deviceName: string;
    deviceType: string;
}
export type InferenceAccelerators = InferenceAccelerator[];
export type PidMode = "host" | "task" | (string & {});
export type IpcMode = "host" | "task" | "none" | (string & {});
export type ProxyConfigurationType = "APPMESH" | (string & {});
export type ProxyConfigurationProperties = KeyValuePair[];
export interface ProxyConfiguration {
    type?: ProxyConfigurationType | undefined;
    containerName: string;
    properties?: KeyValuePair[] | undefined;
}
export interface EphemeralStorage {
    sizeInGiB: number;
}
export type IsolationMode = "SHARED" | "ISOLATED_SANDBOX" | "CONFIDENTIAL_SANDBOX" | (string & {});
export interface TrustedExecutionConfiguration {
    isolationMode: IsolationMode;
    attestationPolicy?: string | undefined;
}
export interface TaskDefinition {
    taskDefinitionArn?: string | undefined;
    containerDefinitions?: ContainerDefinition[] | undefined;
    family?: string | undefined;
    taskRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    networkMode?: NetworkMode | undefined;
    revision?: number | undefined;
    volumes?: Volume[] | undefined;
    status?: TaskDefinitionStatus | undefined;
    requiresAttributes?: Attribute[] | undefined;
    placementConstraints?: TaskDefinitionPlacementConstraint[] | undefined;
    compatibilities?: Compatibility[] | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    requiresCompatibilities?: Compatibility[] | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    inferenceAccelerators?: InferenceAccelerator[] | undefined;
    pidMode?: PidMode | undefined;
    ipcMode?: IpcMode | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    registeredAt?: Date | undefined;
    deregisteredAt?: Date | undefined;
    deleteRequestedAt?: Date | undefined;
    registeredBy?: string | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    enableFaultInjection?: boolean | undefined;
    trustedExecutionConfiguration?: TrustedExecutionConfiguration | undefined;
}
export type TaskDefinitionList = TaskDefinition[];
export interface Failure {
    arn?: string | undefined;
    reason?: string | undefined;
    detail?: string | undefined;
}
export type Failures = Failure[];
export interface DeleteTaskDefinitionsResponse {
    taskDefinitions?: TaskDefinition[] | undefined;
    failures?: Failure[] | undefined;
}
export interface DeleteTaskSetRequest {
    cluster: string;
    service: string;
    taskSet: string;
    force?: boolean | undefined;
}
export interface DeleteTaskSetResponse {
    taskSet?: TaskSet | undefined;
}
export interface DeregisterContainerInstanceRequest {
    cluster?: string | undefined;
    containerInstance: string;
    force?: boolean | undefined;
}
export interface VersionInfo {
    agentVersion?: string | undefined;
    agentHash?: string | undefined;
    dockerVersion?: string | undefined;
}
export interface Resource {
    name?: string | undefined;
    type?: string | undefined;
    doubleValue?: number | undefined;
    longValue?: number | undefined;
    integerValue?: number | undefined;
    stringSetValue?: string[] | undefined;
}
export type Resources = Resource[];
export type AgentUpdateStatus = "PENDING" | "STAGING" | "STAGED" | "UPDATING" | "UPDATED" | "FAILED" | (string & {});
export type InstanceHealthCheckState = "OK" | "IMPAIRED" | "INSUFFICIENT_DATA" | "INITIALIZING" | (string & {});
export type InstanceHealthCheckType = "CONTAINER_RUNTIME" | "ACCELERATED_COMPUTE" | "DAEMON" | "AGENT_CONNECTIVITY" | (string & {});
export interface InstanceHealthCheckResult {
    type?: InstanceHealthCheckType | undefined;
    status?: InstanceHealthCheckState | undefined;
    statusReason?: string | undefined;
    lastUpdated?: Date | undefined;
    lastStatusChange?: Date | undefined;
}
export type InstanceHealthCheckResultList = InstanceHealthCheckResult[];
export interface ContainerInstanceHealthStatus {
    overallStatus?: InstanceHealthCheckState | undefined;
    details?: InstanceHealthCheckResult[] | undefined;
}
export type GpuSharingMode = "IDLE" | "NVIDIA_MPS" | "DEDICATED" | (string & {});
export interface GpuDevice {
    gpuId?: string | undefined;
    sharingMode?: GpuSharingMode | undefined;
    totalMemoryInMiB?: number | undefined;
    remainingMemoryInMiB?: number | undefined;
    containerCount?: number | undefined;
}
export type GpuDevices = GpuDevice[];
export interface ContainerInstance {
    containerInstanceArn?: string | undefined;
    ec2InstanceId?: string | undefined;
    capacityProviderName?: string | undefined;
    version?: number | undefined;
    versionInfo?: VersionInfo | undefined;
    remainingResources?: Resource[] | undefined;
    registeredResources?: Resource[] | undefined;
    status?: string | undefined;
    statusReason?: string | undefined;
    agentConnected?: boolean | undefined;
    runningTasksCount?: number | undefined;
    pendingTasksCount?: number | undefined;
    agentUpdateStatus?: AgentUpdateStatus | undefined;
    attributes?: Attribute[] | undefined;
    registeredAt?: Date | undefined;
    attachments?: Attachment[] | undefined;
    tags?: Tag[] | undefined;
    healthStatus?: ContainerInstanceHealthStatus | undefined;
    gpuDevices?: GpuDevice[] | undefined;
}
export interface DeregisterContainerInstanceResponse {
    containerInstance?: ContainerInstance | undefined;
}
export interface DeregisterTaskDefinitionRequest {
    taskDefinition: string;
}
export interface DeregisterTaskDefinitionResponse {
    taskDefinition?: TaskDefinition | undefined;
}
export type CapacityProviderField = "TAGS" | (string & {});
export type CapacityProviderFieldList = CapacityProviderField[];
export interface DescribeCapacityProvidersRequest {
    capacityProviders?: string[] | undefined;
    cluster?: string | undefined;
    include?: CapacityProviderField[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type CapacityProviders = CapacityProvider[];
export interface DescribeCapacityProvidersResponse {
    capacityProviders?: CapacityProvider[] | undefined;
    failures?: Failure[] | undefined;
    nextToken?: string | undefined;
}
export type ClusterField = "ATTACHMENTS" | "CONFIGURATIONS" | "SETTINGS" | "STATISTICS" | "TAGS" | (string & {});
export type ClusterFieldList = ClusterField[];
export interface DescribeClustersRequest {
    clusters?: string[] | undefined;
    include?: ClusterField[] | undefined;
}
export type Clusters = Cluster[];
export interface DescribeClustersResponse {
    clusters?: Cluster[] | undefined;
    failures?: Failure[] | undefined;
}
export type ContainerInstanceField = "TAGS" | "CONTAINER_INSTANCE_HEALTH" | (string & {});
export type ContainerInstanceFieldList = ContainerInstanceField[];
export interface DescribeContainerInstancesRequest {
    cluster?: string | undefined;
    containerInstances: string[];
    include?: ContainerInstanceField[] | undefined;
}
export type ContainerInstances = ContainerInstance[];
export interface DescribeContainerInstancesResponse {
    containerInstances?: ContainerInstance[] | undefined;
    failures?: Failure[] | undefined;
}
export interface DescribeDaemonRequest {
    daemonArn: string;
}
export interface DaemonCapacityProvider {
    arn?: string | undefined;
    runningCount?: number | undefined;
    withoutDaemonCount?: number | undefined;
}
export type DaemonCapacityProviderList = DaemonCapacityProvider[];
export interface DaemonRevisionDetail {
    arn?: string | undefined;
    capacityProviders?: DaemonCapacityProvider[] | undefined;
    totalRunningCount?: number | undefined;
    totalWithoutDaemonCount?: number | undefined;
}
export type DaemonRevisionDetailList = DaemonRevisionDetail[];
export interface DaemonDetail {
    daemonArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: DaemonStatus | undefined;
    currentRevisions?: DaemonRevisionDetail[] | undefined;
    deploymentArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface DescribeDaemonResponse {
    daemon?: DaemonDetail | undefined;
}
export interface DescribeDaemonDeploymentsRequest {
    daemonDeploymentArns: string[];
}
export type DaemonDeploymentStatus = "PENDING" | "SUCCESSFUL" | "STOPPED" | "STOP_REQUESTED" | "IN_PROGRESS" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_SUCCESSFUL" | "ROLLBACK_FAILED" | (string & {});
export interface DaemonDeploymentCapacityProvider {
    arn?: string | undefined;
    runningInstanceCount?: number | undefined;
    withoutDaemonInstanceCount?: number | undefined;
    drainingInstanceCount?: number | undefined;
}
export type DaemonDeploymentCapacityProviderList = DaemonDeploymentCapacityProvider[];
export interface DaemonDeploymentRevisionDetail {
    arn?: string | undefined;
    capacityProviders?: DaemonDeploymentCapacityProvider[] | undefined;
    totalRunningInstanceCount?: number | undefined;
    totalWithoutDaemonInstanceCount?: number | undefined;
    totalDrainingInstanceCount?: number | undefined;
}
export type DaemonDeploymentRevisionDetailList = DaemonDeploymentRevisionDetail[];
export type DaemonDeploymentRollbackMonitorsStatus = "TRIGGERED" | "MONITORING" | "MONITORING_COMPLETE" | "DISABLED" | (string & {});
export interface DaemonCircuitBreaker {
    failureCount?: number | undefined;
    status?: DaemonDeploymentRollbackMonitorsStatus | undefined;
    threshold?: number | undefined;
}
export interface DaemonDeploymentAlarms {
    status?: DaemonDeploymentRollbackMonitorsStatus | undefined;
    alarmNames?: string[] | undefined;
    triggeredAlarmNames?: string[] | undefined;
}
export interface DaemonRollback {
    reason?: string | undefined;
    startedAt?: Date | undefined;
    rollbackTargetDaemonRevisionArn?: string | undefined;
    rollbackCapacityProviders?: string[] | undefined;
}
export interface DaemonDeployment {
    daemonDeploymentArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: DaemonDeploymentStatus | undefined;
    statusReason?: string | undefined;
    targetDaemonRevision?: DaemonDeploymentRevisionDetail | undefined;
    sourceDaemonRevisions?: DaemonDeploymentRevisionDetail[] | undefined;
    circuitBreaker?: DaemonCircuitBreaker | undefined;
    alarms?: DaemonDeploymentAlarms | undefined;
    rollback?: DaemonRollback | undefined;
    deploymentConfiguration?: DaemonDeploymentConfiguration | undefined;
    createdAt?: Date | undefined;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
    finishedAt?: Date | undefined;
}
export type DaemonDeploymentList = DaemonDeployment[];
export interface DescribeDaemonDeploymentsResponse {
    failures?: Failure[] | undefined;
    daemonDeployments?: DaemonDeployment[] | undefined;
}
export interface DescribeDaemonRevisionsRequest {
    daemonRevisionArns: string[];
}
export interface DaemonContainerImage {
    containerName?: string | undefined;
    imageDigest?: string | undefined;
    image?: string | undefined;
}
export type DaemonContainerImages = DaemonContainerImage[];
export interface DaemonRevision {
    daemonRevisionArn?: string | undefined;
    clusterArn?: string | undefined;
    daemonArn?: string | undefined;
    daemonTaskDefinitionArn?: string | undefined;
    createdAt?: Date | undefined;
    containerImages?: DaemonContainerImage[] | undefined;
    propagateTags?: DaemonPropagateTags | undefined;
    enableECSManagedTags?: boolean | undefined;
    enableExecuteCommand?: boolean | undefined;
    critical?: boolean | undefined;
}
export type DaemonRevisions = DaemonRevision[];
export interface DescribeDaemonRevisionsResponse {
    daemonRevisions?: DaemonRevision[] | undefined;
    failures?: Failure[] | undefined;
}
export interface DescribeDaemonTaskDefinitionRequest {
    daemonTaskDefinition: string;
}
export interface DaemonLinuxParameters {
    capabilities?: KernelCapabilities | undefined;
    devices?: Device[] | undefined;
    initProcessEnabled?: boolean | undefined;
    tmpfs?: Tmpfs[] | undefined;
}
export interface DaemonContainerDefinition {
    name?: string | undefined;
    image: string;
    memory?: number | undefined;
    memoryReservation?: number | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
    healthCheck?: HealthCheck | undefined;
    cpu?: number | undefined;
    essential?: boolean | undefined;
    entryPoint?: string[] | undefined;
    command?: string[] | undefined;
    workingDirectory?: string | undefined;
    environmentFiles?: EnvironmentFile[] | undefined;
    environment?: KeyValuePair[] | undefined;
    secrets?: Secret[] | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    mountPoints?: MountPoint[] | undefined;
    logConfiguration?: LogConfiguration | undefined;
    firelensConfiguration?: FirelensConfiguration | undefined;
    privileged?: boolean | undefined;
    user?: string | undefined;
    ulimits?: Ulimit[] | undefined;
    linuxParameters?: DaemonLinuxParameters | undefined;
    dependsOn?: ContainerDependency[] | undefined;
    startTimeout?: number | undefined;
    stopTimeout?: number | undefined;
    systemControls?: SystemControl[] | undefined;
    interactive?: boolean | undefined;
    pseudoTerminal?: boolean | undefined;
    restartPolicy?: ContainerRestartPolicy | undefined;
}
export type DaemonContainerDefinitionList = DaemonContainerDefinition[];
export interface LogDriverVolumeConfiguration {
    driver: LogDriver;
}
export interface DaemonVolume {
    name?: string | undefined;
    host?: HostVolumeProperties | undefined;
    logDriverVolumeConfiguration?: LogDriverVolumeConfiguration | undefined;
}
export type DaemonVolumeList = DaemonVolume[];
export type DaemonTaskDefinitionStatus = "ACTIVE" | "DELETE_IN_PROGRESS" | "DELETED" | (string & {});
export type DaemonPidMode = "none" | "shared" | (string & {});
export type DaemonIpcMode = "none" | "shared" | (string & {});
export interface DaemonTaskDefinition {
    daemonTaskDefinitionArn?: string | undefined;
    family?: string | undefined;
    revision?: number | undefined;
    taskRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    containerDefinitions?: DaemonContainerDefinition[] | undefined;
    volumes?: DaemonVolume[] | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    status?: DaemonTaskDefinitionStatus | undefined;
    registeredAt?: Date | undefined;
    deleteRequestedAt?: Date | undefined;
    registeredBy?: string | undefined;
    pidMode?: DaemonPidMode | undefined;
    ipcMode?: DaemonIpcMode | undefined;
}
export interface DescribeDaemonTaskDefinitionResponse {
    daemonTaskDefinition?: DaemonTaskDefinition | undefined;
}
export type ExpressGatewayServiceInclude = "TAGS" | (string & {});
export type ExpressGatewayServiceIncludeList = ExpressGatewayServiceInclude[];
export interface DescribeExpressGatewayServiceRequest {
    serviceArn: string;
    include?: ExpressGatewayServiceInclude[] | undefined;
}
export interface DescribeExpressGatewayServiceResponse {
    service?: ECSExpressGatewayService | undefined;
}
export interface DescribeGatewayRequest {
    gateway: string;
}
export interface GatewayOperationError {
    operation?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type GatewayOperationErrorList = GatewayOperationError[];
export interface GatewayResourceFailure {
    arn?: string | undefined;
    errors?: GatewayOperationError[] | undefined;
}
export type GatewayResourceFailureList = GatewayResourceFailure[];
export interface DescribeGatewayAlbConfiguration {
    networkConfiguration?: GatewayElbNetworkConfiguration | undefined;
    scheme?: GatewayElbScheme | undefined;
    accessLogs?: GatewayElbAccessLogConfiguration | undefined;
    webACLArn?: string | undefined;
    port?: number | undefined;
    protocol?: GatewayAlbProtocol | undefined;
    maxAlbCount?: number | undefined;
    currentAlbCount?: number | undefined;
    httpDesync?: GatewayAlbDesyncMitigationMode | undefined;
    testTrafficRules?: GatewayAlbTestTrafficRules | undefined;
}
export type DescribeGatewayConfiguration = {
    hostSharedAlb: DescribeGatewayAlbConfiguration;
};
export interface Gateway {
    gatewayArn?: string | undefined;
    name?: string | undefined;
    status?: GatewayStatus | undefined;
    statusReason?: string | undefined;
    failures?: GatewayResourceFailure[] | undefined;
    infrastructureRoleArn?: string | undefined;
    deletionProtection?: boolean | undefined;
    configuration?: DescribeGatewayConfiguration | undefined;
    accessType?: AccessType | undefined;
    propagateTags?: PropagateGatewayTags | undefined;
    tags?: Tag[] | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface DescribeGatewayResponse {
    gateway?: Gateway | undefined;
}
export interface DescribeGatewayResourcesRequest {
    gateway: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ElbGatewayResources {
    loadBalancerArn?: string | undefined;
    listenerArn?: string | undefined;
    securityGroup?: string | undefined;
    gatewayRouteArns?: string[] | undefined;
}
export type ElbGatewayResourcesList = ElbGatewayResources[];
export type GatewayInfrastructureResources = {
    hostSharedAlb: ElbGatewayResources[];
};
export interface GatewayResources {
    gatewayArn?: string | undefined;
    resources?: GatewayInfrastructureResources | undefined;
}
export interface DescribeGatewayResourcesResponse {
    gatewayResources?: GatewayResources | undefined;
    nextToken?: string | undefined;
}
export interface DescribeGatewayRouteRequest {
    gatewayRouteArn: string;
}
export type GatewayRouteStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export interface GatewayRouteLoadBalancerSecurityGroup {
    arn?: string | undefined;
    ruleArns?: string[] | undefined;
}
export type GatewayRouteLoadBalancerSecurityGroupList = GatewayRouteLoadBalancerSecurityGroup[];
export interface GatewayRouteAlbResources {
    acmCertificateArn?: string | undefined;
    loadBalancerArn?: string | undefined;
    listenerArn?: string | undefined;
    listenerRuleArn?: string | undefined;
    testListenerRuleArns?: string[] | undefined;
    loadBalancerSecurityGroups?: GatewayRouteLoadBalancerSecurityGroup[] | undefined;
    serviceSecurityGroupArn?: string | undefined;
}
export type GatewayRouteAlbResourcesList = GatewayRouteAlbResources[];
export type GatewayRouteResources = {
    hostSharedAlb: GatewayRouteAlbResources[];
};
export interface GatewayRoute {
    gatewayRouteArn?: string | undefined;
    serviceArn?: string | undefined;
    serviceContainerPortName?: string | undefined;
    status?: GatewayRouteStatus | undefined;
    serviceUrl?: string | undefined;
    resources?: GatewayRouteResources | undefined;
}
export interface DescribeGatewayRouteResponse {
    gatewayRoute?: GatewayRoute | undefined;
}
export interface DescribeServiceDeploymentsRequest {
    serviceDeploymentArns: string[];
}
export interface ServiceRevisionSummary {
    arn?: string | undefined;
    requestedTaskCount?: number | undefined;
    runningTaskCount?: number | undefined;
    pendingTaskCount?: number | undefined;
    requestedTestTrafficWeight?: number | undefined;
    requestedProductionTrafficWeight?: number | undefined;
}
export type ServiceRevisionsSummaryList = ServiceRevisionSummary[];
export type ServiceDeploymentStatus = "PENDING" | "SUCCESSFUL" | "STOPPED" | "STOP_REQUESTED" | "IN_PROGRESS" | "ROLLBACK_REQUESTED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_SUCCESSFUL" | "ROLLBACK_FAILED" | (string & {});
export type ServiceDeploymentLifecycleStage = "RECONCILE_SERVICE" | "PRE_SCALE_UP" | "SCALE_UP" | "POST_SCALE_UP" | "TEST_TRAFFIC_SHIFT" | "POST_TEST_TRAFFIC_SHIFT" | "PRODUCTION_TRAFFIC_SHIFT" | "POST_PRODUCTION_TRAFFIC_SHIFT" | "BAKE_TIME" | "CLEAN_UP" | (string & {});
export type DeploymentLifecycleHookStatus = "AWAITING_ACTION" | "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | (string & {});
export interface DeploymentLifecycleHookDetail {
    hookId?: string | undefined;
    targetType?: DeploymentLifecycleHookTargetType | undefined;
    targetArn?: string | undefined;
    status?: DeploymentLifecycleHookStatus | undefined;
    expiresAt?: Date | undefined;
    timeoutAction?: DeploymentLifecycleHookAction | undefined;
}
export type DeploymentLifecycleHookDetailList = DeploymentLifecycleHookDetail[];
export interface Rollback {
    reason?: string | undefined;
    startedAt?: Date | undefined;
    serviceRevisionArn?: string | undefined;
}
export type ServiceDeploymentRollbackMonitorsStatus = "TRIGGERED" | "MONITORING" | "MONITORING_COMPLETE" | "DISABLED" | (string & {});
export interface ServiceDeploymentCircuitBreaker {
    status?: ServiceDeploymentRollbackMonitorsStatus | undefined;
    failureCount?: number | undefined;
    threshold?: number | undefined;
}
export interface ServiceDeploymentAlarms {
    status?: ServiceDeploymentRollbackMonitorsStatus | undefined;
    alarmNames?: string[] | undefined;
    triggeredAlarmNames?: string[] | undefined;
}
export interface ServiceDeployment {
    serviceDeploymentArn?: string | undefined;
    serviceArn?: string | undefined;
    clusterArn?: string | undefined;
    createdAt?: Date | undefined;
    startedAt?: Date | undefined;
    finishedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
    updatedAt?: Date | undefined;
    sourceServiceRevisions?: ServiceRevisionSummary[] | undefined;
    targetServiceRevision?: ServiceRevisionSummary | undefined;
    status?: ServiceDeploymentStatus | undefined;
    statusReason?: string | undefined;
    lifecycleStage?: ServiceDeploymentLifecycleStage | undefined;
    lifecycleHookDetails?: DeploymentLifecycleHookDetail[] | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    rollback?: Rollback | undefined;
    deploymentCircuitBreaker?: ServiceDeploymentCircuitBreaker | undefined;
    alarms?: ServiceDeploymentAlarms | undefined;
}
export type ServiceDeployments = ServiceDeployment[];
export interface DescribeServiceDeploymentsResponse {
    serviceDeployments?: ServiceDeployment[] | undefined;
    failures?: Failure[] | undefined;
}
export interface DescribeServiceRevisionsRequest {
    serviceRevisionArns: string[];
}
export interface ContainerImage {
    containerName?: string | undefined;
    imageDigest?: string | undefined;
    image?: string | undefined;
}
export type ContainerImages = ContainerImage[];
export interface ServiceRevisionLoadBalancer {
    targetGroupArn?: string | undefined;
    productionListenerRule?: string | undefined;
}
export type ServiceRevisionLoadBalancers = ServiceRevisionLoadBalancer[];
export interface ServiceRevisionVpcLatticeConfiguration {
    targetGroupArn?: string | undefined;
    productionListenerRule?: string | undefined;
}
export type ServiceRevisionVpcLatticeConfigurations = ServiceRevisionVpcLatticeConfiguration[];
export interface ResolvedConfiguration {
    loadBalancers?: ServiceRevisionLoadBalancer[] | undefined;
    vpcLatticeConfigurations?: ServiceRevisionVpcLatticeConfiguration[] | undefined;
}
export type ManagedResourceStatus = "PROVISIONING" | "ACTIVE" | "DEPROVISIONING" | "DELETED" | "FAILED" | (string & {});
export interface ManagedLoadBalancer {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    scheme: string;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
}
export interface ManagedSecurityGroup {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
}
export type ManagedSecurityGroups = ManagedSecurityGroup[];
export interface ManagedCertificate {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    domainName: string;
}
export interface ManagedListener {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
}
export interface ManagedListenerRule {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
}
export interface ManagedTargetGroup {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    healthCheckPath: string;
    healthCheckPort: number;
    port: number;
}
export type ManagedTargetGroups = ManagedTargetGroup[];
export interface ManagedIngressPath {
    accessType: AccessType;
    endpoint: string;
    loadBalancer?: ManagedLoadBalancer | undefined;
    loadBalancerSecurityGroups?: ManagedSecurityGroup[] | undefined;
    certificate?: ManagedCertificate | undefined;
    listener?: ManagedListener | undefined;
    rule?: ManagedListenerRule | undefined;
    targetGroups?: ManagedTargetGroup[] | undefined;
}
export type ManagedIngressPaths = ManagedIngressPath[];
export interface ManagedScalableTarget {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    minCapacity: number;
    maxCapacity: number;
}
export interface ManagedApplicationAutoScalingPolicy {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    policyType: string;
    targetValue: number;
    metric: string;
}
export type ManagedApplicationAutoScalingPolicies = ManagedApplicationAutoScalingPolicy[];
export interface ManagedAutoScaling {
    scalableTarget?: ManagedScalableTarget | undefined;
    applicationAutoScalingPolicies?: ManagedApplicationAutoScalingPolicy[] | undefined;
}
export interface ManagedMetricAlarm {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
}
export type ManagedMetricAlarms = ManagedMetricAlarm[];
export interface ManagedLogGroup {
    arn?: string | undefined;
    status: ManagedResourceStatus;
    statusReason?: string | undefined;
    updatedAt: Date;
    logGroupName: string;
}
export type ManagedLogGroups = ManagedLogGroup[];
export interface GatewayConnectionAlbResources {
    acmCertificateArn?: string | undefined;
    loadBalancerArn?: string | undefined;
    loadBalancerSecurityGroupArns?: string[] | undefined;
    listenerArn?: string | undefined;
    listenerRuleArn?: string | undefined;
    testListenerRuleArn?: string | undefined;
    targetGroupArn?: string | undefined;
    alternateTargetGroupArn?: string | undefined;
}
export type GatewayConnectionAlbResourcesList = GatewayConnectionAlbResources[];
export type GatewayConnectionResources = {
    hostSharedAlb: GatewayConnectionAlbResources[];
};
export interface GatewayConnection {
    gatewayArn?: string | undefined;
    gatewayRouteArn?: string | undefined;
    portName?: string | undefined;
    serviceUrl?: string | undefined;
    accessType?: AccessType | undefined;
    status?: GatewayRouteStatus | undefined;
    resources?: GatewayConnectionResources | undefined;
}
export type GatewayConnectionList = GatewayConnection[];
export interface ECSManagedResources {
    ingressPaths?: ManagedIngressPath[] | undefined;
    autoScaling?: ManagedAutoScaling | undefined;
    metricAlarms?: ManagedMetricAlarm[] | undefined;
    serviceSecurityGroups?: ManagedSecurityGroup[] | undefined;
    logGroups?: ManagedLogGroup[] | undefined;
    gatewayConnections?: GatewayConnection[] | undefined;
}
export interface RuntimePlatformOverride {
    cpuArchitecture?: string | undefined;
}
export interface ServiceRevisionOverrides {
    runtimePlatform?: RuntimePlatformOverride | undefined;
}
export interface ServiceRevision {
    serviceRevisionArn?: string | undefined;
    serviceArn?: string | undefined;
    clusterArn?: string | undefined;
    taskDefinition?: string | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    launchType?: LaunchType | undefined;
    platformVersion?: string | undefined;
    platformFamily?: string | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    containerImages?: ContainerImage[] | undefined;
    guardDutyEnabled?: boolean | undefined;
    serviceConnectConfiguration?: ServiceConnectConfiguration | undefined;
    volumeConfigurations?: ServiceVolumeConfiguration[] | undefined;
    fargateEphemeralStorage?: DeploymentEphemeralStorage | undefined;
    createdAt?: Date | undefined;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[] | undefined;
    resolvedConfiguration?: ResolvedConfiguration | undefined;
    ecsManagedResources?: ECSManagedResources | undefined;
    overrides?: ServiceRevisionOverrides | undefined;
    gatewayConnectors?: GatewayConnector[] | undefined;
    monitoring?: MonitoringConfiguration | undefined;
}
export type ServiceRevisions = ServiceRevision[];
export interface DescribeServiceRevisionsResponse {
    serviceRevisions?: ServiceRevision[] | undefined;
    failures?: Failure[] | undefined;
}
export type ServiceField = "TAGS" | (string & {});
export type ServiceFieldList = ServiceField[];
export interface DescribeServicesRequest {
    cluster?: string | undefined;
    services: string[];
    include?: ServiceField[] | undefined;
}
export type Services = Service[];
export interface DescribeServicesResponse {
    services?: Service[] | undefined;
    failures?: Failure[] | undefined;
}
export type TaskDefinitionField = "TAGS" | (string & {});
export type TaskDefinitionFieldList = TaskDefinitionField[];
export interface DescribeTaskDefinitionRequest {
    taskDefinition: string;
    include?: TaskDefinitionField[] | undefined;
}
export interface DescribeTaskDefinitionResponse {
    taskDefinition?: TaskDefinition | undefined;
    tags?: Tag[] | undefined;
}
export type TaskField = "TAGS" | (string & {});
export type TaskFieldList = TaskField[];
export interface DescribeTasksRequest {
    cluster?: string | undefined;
    tasks: string[];
    include?: TaskField[] | undefined;
}
export type Connectivity = "CONNECTED" | "DISCONNECTED" | (string & {});
export interface NetworkBinding {
    bindIP?: string | undefined;
    containerPort?: number | undefined;
    hostPort?: number | undefined;
    protocol?: TransportProtocol | undefined;
    containerPortRange?: string | undefined;
    hostPortRange?: string | undefined;
}
export type NetworkBindings = NetworkBinding[];
export interface NetworkInterface {
    attachmentId?: string | undefined;
    privateIpv4Address?: string | undefined;
    ipv6Address?: string | undefined;
}
export type NetworkInterfaces = NetworkInterface[];
export type HealthStatus = "HEALTHY" | "UNHEALTHY" | "UNKNOWN" | (string & {});
export type ManagedAgentName = "ExecuteCommandAgent" | (string & {});
export interface ManagedAgent {
    lastStartedAt?: Date | undefined;
    name?: ManagedAgentName | undefined;
    reason?: string | undefined;
    lastStatus?: string | undefined;
}
export type ManagedAgents = ManagedAgent[];
export type GpuIds = string[];
export type NeuronDeviceIds = string[];
export interface Container {
    containerArn?: string | undefined;
    taskArn?: string | undefined;
    name?: string | undefined;
    image?: string | undefined;
    imageDigest?: string | undefined;
    runtimeId?: string | undefined;
    lastStatus?: string | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    networkBindings?: NetworkBinding[] | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
    healthStatus?: HealthStatus | undefined;
    managedAgents?: ManagedAgent[] | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    memoryReservation?: string | undefined;
    gpuIds?: string[] | undefined;
    neuronDeviceIds?: string[] | undefined;
    gpuSharingStrategy?: SharingStrategy | undefined;
}
export type Containers = Container[];
export interface ContainerOverride {
    name?: string | undefined;
    command?: string[] | undefined;
    environment?: KeyValuePair[] | undefined;
    environmentFiles?: EnvironmentFile[] | undefined;
    cpu?: number | undefined;
    memory?: number | undefined;
    memoryReservation?: number | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
}
export type ContainerOverrides = ContainerOverride[];
export interface InferenceAcceleratorOverride {
    deviceName?: string | undefined;
    deviceType?: string | undefined;
}
export type InferenceAcceleratorOverrides = InferenceAcceleratorOverride[];
export interface TaskOverride {
    containerOverrides?: ContainerOverride[] | undefined;
    cpu?: string | undefined;
    inferenceAcceleratorOverrides?: InferenceAcceleratorOverride[] | undefined;
    executionRoleArn?: string | undefined;
    memory?: string | undefined;
    taskRoleArn?: string | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
}
export type TaskStopCode = "TaskFailedToStart" | "EssentialContainerExited" | "UserInitiated" | "ServiceSchedulerInitiated" | "SpotInterruption" | "TerminationNotice" | "InfrastructureHealth" | (string & {});
export interface TaskEphemeralStorage {
    sizeInGiB?: number | undefined;
    kmsKeyId?: string | undefined;
}
export type AttestationPolicyStatus = "CONFIGURED" | (string & {});
export interface TrustedExecutionSummary {
    isolationMode: IsolationMode;
    attestationPolicyStatus?: AttestationPolicyStatus | undefined;
}
export interface Task {
    attachments?: Attachment[] | undefined;
    attributes?: Attribute[] | undefined;
    availabilityZone?: string | undefined;
    capacityProviderName?: string | undefined;
    clusterArn?: string | undefined;
    connectivity?: Connectivity | undefined;
    connectivityAt?: Date | undefined;
    containerInstanceArn?: string | undefined;
    containers?: Container[] | undefined;
    cpu?: string | undefined;
    createdAt?: Date | undefined;
    desiredStatus?: string | undefined;
    enableExecuteCommand?: boolean | undefined;
    executionStoppedAt?: Date | undefined;
    group?: string | undefined;
    healthStatus?: HealthStatus | undefined;
    inferenceAccelerators?: InferenceAccelerator[] | undefined;
    lastStatus?: string | undefined;
    launchType?: LaunchType | undefined;
    memory?: string | undefined;
    overrides?: TaskOverride | undefined;
    platformVersion?: string | undefined;
    platformFamily?: string | undefined;
    pullStartedAt?: Date | undefined;
    pullStoppedAt?: Date | undefined;
    startedAt?: Date | undefined;
    startedBy?: string | undefined;
    stopCode?: TaskStopCode | undefined;
    stoppedAt?: Date | undefined;
    stoppedReason?: string | undefined;
    stoppingAt?: Date | undefined;
    tags?: Tag[] | undefined;
    taskArn?: string | undefined;
    taskDefinitionArn?: string | undefined;
    version?: number | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    fargateEphemeralStorage?: TaskEphemeralStorage | undefined;
    trustedExecutionSummary?: TrustedExecutionSummary | undefined;
}
export type Tasks = Task[];
export interface DescribeTasksResponse {
    tasks?: Task[] | undefined;
    failures?: Failure[] | undefined;
}
export type TaskSetField = "TAGS" | (string & {});
export type TaskSetFieldList = TaskSetField[];
export interface DescribeTaskSetsRequest {
    cluster: string;
    service: string;
    taskSets?: string[] | undefined;
    include?: TaskSetField[] | undefined;
}
export interface DescribeTaskSetsResponse {
    taskSets?: TaskSet[] | undefined;
    failures?: Failure[] | undefined;
}
export interface DisassociateGatewayFromClusterRequest {
    gateway: string;
    cluster: string;
}
export interface DisassociateGatewayFromClusterResponse {
    gatewayArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: GatewayClusterAssociationStatus | undefined;
}
export interface DiscoverPollEndpointRequest {
    containerInstance?: string | undefined;
    cluster?: string | undefined;
}
export interface DiscoverPollEndpointResponse {
    endpoint?: string | undefined;
    telemetryEndpoint?: string | undefined;
    serviceConnectEndpoint?: string | undefined;
}
export interface ExecuteCommandRequest {
    cluster?: string | undefined;
    container?: string | undefined;
    command: string;
    interactive: boolean;
    task: string;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface Session {
    sessionId?: string | undefined;
    streamUrl?: string | undefined;
    tokenValue?: string | redacted.Redacted<string> | undefined;
}
export interface ExecuteCommandResponse {
    clusterArn?: string | undefined;
    containerArn?: string | undefined;
    containerName?: string | undefined;
    interactive?: boolean | undefined;
    session?: Session | undefined;
    taskArn?: string | undefined;
}
export interface GetTaskProtectionRequest {
    cluster: string;
    tasks?: string[] | undefined;
}
export interface ProtectedTask {
    taskArn?: string | undefined;
    protectionEnabled?: boolean | undefined;
    expirationDate?: Date | undefined;
}
export type ProtectedTasks = ProtectedTask[];
export interface GetTaskProtectionResponse {
    protectedTasks?: ProtectedTask[] | undefined;
    failures?: Failure[] | undefined;
}
export interface ListAccountSettingsRequest {
    name?: SettingName | undefined;
    value?: string | undefined;
    principalArn?: string | undefined;
    effectiveSettings?: boolean | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Settings = Setting[];
export interface ListAccountSettingsResponse {
    settings?: Setting[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAttributesRequest {
    cluster?: string | undefined;
    targetType: TargetType;
    attributeName?: string | undefined;
    attributeValue?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListAttributesResponse {
    attributes?: Attribute[] | undefined;
    nextToken?: string | undefined;
}
export interface ListClustersRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListClustersResponse {
    clusterArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export type ContainerInstanceStatus = "ACTIVE" | "DRAINING" | "REGISTERING" | "DEREGISTERING" | "REGISTRATION_FAILED" | (string & {});
export interface ListContainerInstancesRequest {
    cluster?: string | undefined;
    filter?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    status?: ContainerInstanceStatus | undefined;
}
export interface ListContainerInstancesResponse {
    containerInstanceArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export type DaemonDeploymentStatusList = DaemonDeploymentStatus[];
export interface CreatedAt {
    before?: Date | undefined;
    after?: Date | undefined;
}
export interface ListDaemonDeploymentsRequest {
    daemonArn: string;
    status?: DaemonDeploymentStatus[] | undefined;
    createdAt?: CreatedAt | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DaemonDeploymentSummary {
    daemonDeploymentArn?: string | undefined;
    daemonArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: DaemonDeploymentStatus | undefined;
    statusReason?: string | undefined;
    targetDaemonRevisionArn?: string | undefined;
    createdAt?: Date | undefined;
    startedAt?: Date | undefined;
    stoppedAt?: Date | undefined;
    finishedAt?: Date | undefined;
}
export type DaemonDeploymentSummaryList = DaemonDeploymentSummary[];
export interface ListDaemonDeploymentsResponse {
    nextToken?: string | undefined;
    daemonDeployments?: DaemonDeploymentSummary[] | undefined;
}
export interface ListDaemonsRequest {
    clusterArn?: string | undefined;
    capacityProviderArns?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DaemonSummary {
    daemonArn?: string | undefined;
    status?: DaemonStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DaemonSummariesList = DaemonSummary[];
export interface ListDaemonsResponse {
    daemonSummariesList?: DaemonSummary[] | undefined;
    nextToken?: string | undefined;
}
export type DaemonTaskDefinitionRevisionFilter = "LAST_REGISTERED" | (string & {});
export type DaemonTaskDefinitionStatusFilter = "ACTIVE" | "DELETE_IN_PROGRESS" | "ALL" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface ListDaemonTaskDefinitionsRequest {
    familyPrefix?: string | undefined;
    family?: string | undefined;
    revision?: DaemonTaskDefinitionRevisionFilter | undefined;
    status?: DaemonTaskDefinitionStatusFilter | undefined;
    sort?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DaemonTaskDefinitionSummary {
    arn?: string | undefined;
    registeredAt?: Date | undefined;
    registeredBy?: string | undefined;
    deleteRequestedAt?: Date | undefined;
    status?: DaemonTaskDefinitionStatus | undefined;
}
export type DaemonTaskDefinitionSummaries = DaemonTaskDefinitionSummary[];
export interface ListDaemonTaskDefinitionsResponse {
    daemonTaskDefinitions?: DaemonTaskDefinitionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type GatewayClusterAssociationStatusList = GatewayClusterAssociationStatus[];
export interface ListGatewayClusterAssociationsRequest {
    gateway?: string | undefined;
    cluster?: string | undefined;
    status?: GatewayClusterAssociationStatus[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GatewayClusterAssociationSummary {
    gatewayArn?: string | undefined;
    clusterArn?: string | undefined;
    status?: GatewayClusterAssociationStatus | undefined;
}
export type GatewayClusterAssociationSummaryList = GatewayClusterAssociationSummary[];
export interface ListGatewayClusterAssociationsResponse {
    gatewayClusterAssociations?: GatewayClusterAssociationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type GatewayRouteStatusList = GatewayRouteStatus[];
export interface ListGatewayRoutesRequest {
    gateway?: string | undefined;
    cluster?: string | undefined;
    service?: string | undefined;
    serviceContainerPortName?: string | undefined;
    status?: GatewayRouteStatus[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GatewayRouteSummary {
    gatewayRouteArn?: string | undefined;
    gatewayArn?: string | undefined;
    clusterArn?: string | undefined;
    serviceArn?: string | undefined;
    serviceContainerPortName?: string | undefined;
    status?: GatewayRouteStatus | undefined;
}
export type GatewayRouteSummaryList = GatewayRouteSummary[];
export interface ListGatewayRoutesResponse {
    gatewayRoutes?: GatewayRouteSummary[] | undefined;
    nextToken?: string | undefined;
}
export type GatewayStatusList = GatewayStatus[];
export interface ListGatewaysRequest {
    names?: string[] | undefined;
    status?: GatewayStatus[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GatewaySummary {
    gatewayArn?: string | undefined;
    name?: string | undefined;
    status?: GatewayStatus | undefined;
    createdAt?: Date | undefined;
}
export type GatewaySummaryList = GatewaySummary[];
export interface ListGatewaysResponse {
    gateways?: GatewaySummary[] | undefined;
    nextToken?: string | undefined;
}
export type ServiceDeploymentStatusList = ServiceDeploymentStatus[];
export interface ListServiceDeploymentsRequest {
    service: string;
    cluster?: string | undefined;
    status?: ServiceDeploymentStatus[] | undefined;
    createdAt?: CreatedAt | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ServiceDeploymentBrief {
    serviceDeploymentArn?: string | undefined;
    serviceArn?: string | undefined;
    clusterArn?: string | undefined;
    startedAt?: Date | undefined;
    createdAt?: Date | undefined;
    finishedAt?: Date | undefined;
    targetServiceRevisionArn?: string | undefined;
    status?: ServiceDeploymentStatus | undefined;
    statusReason?: string | undefined;
}
export type ServiceDeploymentsBrief = ServiceDeploymentBrief[];
export interface ListServiceDeploymentsResponse {
    serviceDeployments?: ServiceDeploymentBrief[] | undefined;
    nextToken?: string | undefined;
}
export interface ListServicesRequest {
    cluster?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    launchType?: LaunchType | undefined;
    schedulingStrategy?: SchedulingStrategy | undefined;
    resourceManagementType?: ResourceManagementType | undefined;
}
export interface ListServicesResponse {
    serviceArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListServicesByNamespaceRequest {
    namespace: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListServicesByNamespaceResponse {
    serviceArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export type TaskDefinitionFamilyStatus = "ACTIVE" | "INACTIVE" | "ALL" | (string & {});
export interface ListTaskDefinitionFamiliesRequest {
    familyPrefix?: string | undefined;
    status?: TaskDefinitionFamilyStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTaskDefinitionFamiliesResponse {
    families?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTaskDefinitionsRequest {
    familyPrefix?: string | undefined;
    status?: TaskDefinitionStatus | undefined;
    sort?: SortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTaskDefinitionsResponse {
    taskDefinitionArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export type DesiredStatus = "RUNNING" | "PENDING" | "STOPPED" | (string & {});
export interface ListTasksRequest {
    cluster?: string | undefined;
    containerInstance?: string | undefined;
    family?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    startedBy?: string | undefined;
    serviceName?: string | undefined;
    desiredStatus?: DesiredStatus | undefined;
    launchType?: LaunchType | undefined;
    daemonName?: string | undefined;
}
export interface ListTasksResponse {
    taskArns?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface PutAccountSettingRequest {
    name: SettingName;
    value: string;
    principalArn?: string | undefined;
}
export interface PutAccountSettingResponse {
    setting?: Setting | undefined;
}
export interface PutAccountSettingDefaultRequest {
    name: SettingName;
    value: string;
}
export interface PutAccountSettingDefaultResponse {
    setting?: Setting | undefined;
}
export interface PutAttributesRequest {
    cluster?: string | undefined;
    attributes: Attribute[];
}
export interface PutAttributesResponse {
    attributes?: Attribute[] | undefined;
}
export interface PutClusterCapacityProvidersRequest {
    cluster: string;
    capacityProviders: string[];
    defaultCapacityProviderStrategy: CapacityProviderStrategyItem[];
}
export interface PutClusterCapacityProvidersResponse {
    cluster?: Cluster | undefined;
}
export type PlatformDeviceType = "GPU" | "NEURON_DEVICE" | (string & {});
export interface PlatformDevice {
    id: string;
    type: PlatformDeviceType;
}
export type PlatformDevices = PlatformDevice[];
export interface RegisterContainerInstanceRequest {
    cluster?: string | undefined;
    instanceIdentityDocument?: string | undefined;
    instanceIdentityDocumentSignature?: string | undefined;
    totalResources?: Resource[] | undefined;
    versionInfo?: VersionInfo | undefined;
    containerInstanceArn?: string | undefined;
    attributes?: Attribute[] | undefined;
    platformDevices?: PlatformDevice[] | undefined;
    tags?: Tag[] | undefined;
}
export interface RegisterContainerInstanceResponse {
    containerInstance?: ContainerInstance | undefined;
}
export interface RegisterDaemonTaskDefinitionRequest {
    family: string;
    taskRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    containerDefinitions: DaemonContainerDefinition[];
    cpu?: string | undefined;
    memory?: string | undefined;
    volumes?: DaemonVolume[] | undefined;
    tags?: Tag[] | undefined;
    pidMode?: DaemonPidMode | undefined;
    ipcMode?: DaemonIpcMode | undefined;
}
export interface RegisterDaemonTaskDefinitionResponse {
    daemonTaskDefinitionArn?: string | undefined;
}
export interface RegisterTaskDefinitionRequest {
    family: string;
    taskRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    networkMode?: NetworkMode | undefined;
    containerDefinitions: ContainerDefinition[];
    volumes?: Volume[] | undefined;
    placementConstraints?: TaskDefinitionPlacementConstraint[] | undefined;
    requiresCompatibilities?: Compatibility[] | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    tags?: Tag[] | undefined;
    pidMode?: PidMode | undefined;
    ipcMode?: IpcMode | undefined;
    proxyConfiguration?: ProxyConfiguration | undefined;
    inferenceAccelerators?: InferenceAccelerator[] | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    enableFaultInjection?: boolean | undefined;
    trustedExecutionConfiguration?: TrustedExecutionConfiguration | undefined;
}
export interface RegisterTaskDefinitionResponse {
    taskDefinition?: TaskDefinition | undefined;
    tags?: Tag[] | undefined;
}
export interface TaskManagedEBSVolumeTerminationPolicy {
    deleteOnTermination: boolean;
}
export interface TaskManagedEBSVolumeConfiguration {
    encrypted?: boolean | undefined;
    kmsKeyId?: string | undefined;
    volumeType?: string | undefined;
    sizeInGiB?: number | undefined;
    snapshotId?: string | undefined;
    volumeInitializationRate?: number | undefined;
    iops?: number | undefined;
    throughput?: number | undefined;
    tagSpecifications?: EBSTagSpecification[] | undefined;
    roleArn: string;
    terminationPolicy?: TaskManagedEBSVolumeTerminationPolicy | undefined;
    filesystemType?: TaskFilesystemType | undefined;
}
export interface TaskVolumeConfiguration {
    name: string;
    managedEBSVolume?: TaskManagedEBSVolumeConfiguration | undefined;
}
export type TaskVolumeConfigurations = TaskVolumeConfiguration[];
export interface RunTaskRequest {
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    cluster?: string | undefined;
    count?: number | undefined;
    enableECSManagedTags?: boolean | undefined;
    enableExecuteCommand?: boolean | undefined;
    group?: string | undefined;
    launchType?: LaunchType | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    overrides?: TaskOverride | undefined;
    placementConstraints?: PlacementConstraint[] | undefined;
    placementStrategy?: PlacementStrategy[] | undefined;
    platformVersion?: string | undefined;
    propagateTags?: PropagateTags | undefined;
    referenceId?: string | undefined;
    startedBy?: string | undefined;
    tags?: Tag[] | undefined;
    taskDefinition: string;
    clientToken?: string | undefined;
    volumeConfigurations?: TaskVolumeConfiguration[] | undefined;
}
export interface RunTaskResponse {
    tasks?: Task[] | undefined;
    failures?: Failure[] | undefined;
}
export interface StartTaskRequest {
    cluster?: string | undefined;
    containerInstances: string[];
    enableECSManagedTags?: boolean | undefined;
    enableExecuteCommand?: boolean | undefined;
    group?: string | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    overrides?: TaskOverride | undefined;
    propagateTags?: PropagateTags | undefined;
    referenceId?: string | undefined;
    startedBy?: string | undefined;
    tags?: Tag[] | undefined;
    taskDefinition: string;
    volumeConfigurations?: TaskVolumeConfiguration[] | undefined;
}
export interface StartTaskResponse {
    tasks?: Task[] | undefined;
    failures?: Failure[] | undefined;
}
export type StopServiceDeploymentStopType = "ABORT" | "ROLLBACK" | (string & {});
export interface StopServiceDeploymentRequest {
    serviceDeploymentArn: string;
    stopType?: StopServiceDeploymentStopType | undefined;
}
export interface StopServiceDeploymentResponse {
    serviceDeploymentArn?: string | undefined;
}
export interface StopTaskRequest {
    cluster?: string | undefined;
    task: string;
    reason?: string | undefined;
}
export interface StopTaskResponse {
    task?: Task | undefined;
}
export interface AttachmentStateChange {
    attachmentArn: string;
    status: string;
}
export type AttachmentStateChanges = AttachmentStateChange[];
export interface SubmitAttachmentStateChangesRequest {
    cluster?: string | undefined;
    attachments: AttachmentStateChange[];
}
export interface SubmitAttachmentStateChangesResponse {
    acknowledgment?: string | undefined;
}
export interface SubmitContainerStateChangeRequest {
    cluster?: string | undefined;
    task?: string | undefined;
    containerName?: string | undefined;
    runtimeId?: string | undefined;
    status?: string | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    networkBindings?: NetworkBinding[] | undefined;
}
export interface SubmitContainerStateChangeResponse {
    acknowledgment?: string | undefined;
}
export interface ContainerStateChange {
    containerName?: string | undefined;
    imageDigest?: string | undefined;
    runtimeId?: string | undefined;
    exitCode?: number | undefined;
    networkBindings?: NetworkBinding[] | undefined;
    reason?: string | undefined;
    status?: string | undefined;
}
export type ContainerStateChanges = ContainerStateChange[];
export interface ManagedAgentStateChange {
    containerName: string;
    managedAgentName: ManagedAgentName;
    status: string;
    reason?: string | undefined;
}
export type ManagedAgentStateChanges = ManagedAgentStateChange[];
export interface SubmitTaskStateChangeRequest {
    cluster?: string | undefined;
    task?: string | undefined;
    status?: string | undefined;
    reason?: string | undefined;
    containers?: ContainerStateChange[] | undefined;
    attachments?: AttachmentStateChange[] | undefined;
    managedAgents?: ManagedAgentStateChange[] | undefined;
    pullStartedAt?: Date | undefined;
    pullStoppedAt?: Date | undefined;
    executionStoppedAt?: Date | undefined;
}
export interface SubmitTaskStateChangeResponse {
    acknowledgment?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface AutoScalingGroupProviderUpdate {
    managedScaling?: ManagedScaling | undefined;
    managedTerminationProtection?: ManagedTerminationProtection | undefined;
    managedDraining?: ManagedDraining | undefined;
}
export interface InstanceLaunchTemplateUpdate {
    ec2InstanceProfileArn?: string | undefined;
    networkConfiguration?: ManagedInstancesNetworkConfiguration | undefined;
    storageConfiguration?: ManagedInstancesStorageConfiguration | undefined;
    instanceMetadataTagsPropagation?: boolean | undefined;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration | undefined;
    monitoring?: ManagedInstancesMonitoringOptions | undefined;
    instanceRequirements?: InstanceRequirementsRequest | undefined;
    capacityReservations?: CapacityReservationRequest | undefined;
}
export interface UpdateManagedInstancesProviderConfiguration {
    infrastructureRoleArn: string;
    instanceLaunchTemplate: InstanceLaunchTemplateUpdate;
    propagateTags?: PropagateMITags | undefined;
    infrastructureOptimization?: InfrastructureOptimization | undefined;
    autoRepairConfiguration?: AutoRepairConfiguration | undefined;
}
export interface UpdateCapacityProviderRequest {
    name: string;
    cluster?: string | undefined;
    autoScalingGroupProvider?: AutoScalingGroupProviderUpdate | undefined;
    managedInstancesProvider?: UpdateManagedInstancesProviderConfiguration | undefined;
}
export interface UpdateCapacityProviderResponse {
    capacityProvider?: CapacityProvider | undefined;
}
export interface UpdateClusterRequest {
    cluster: string;
    settings?: ClusterSetting[] | undefined;
    configuration?: ClusterConfiguration | undefined;
    serviceConnectDefaults?: ClusterServiceConnectDefaultsRequest | undefined;
}
export interface UpdateClusterResponse {
    cluster?: Cluster | undefined;
}
export interface UpdateClusterSettingsRequest {
    cluster: string;
    settings: ClusterSetting[];
}
export interface UpdateClusterSettingsResponse {
    cluster?: Cluster | undefined;
}
export interface UpdateContainerAgentRequest {
    cluster?: string | undefined;
    containerInstance: string;
}
export interface UpdateContainerAgentResponse {
    containerInstance?: ContainerInstance | undefined;
}
export interface UpdateContainerInstancesStateRequest {
    cluster?: string | undefined;
    containerInstances: string[];
    status: ContainerInstanceStatus;
}
export interface UpdateContainerInstancesStateResponse {
    containerInstances?: ContainerInstance[] | undefined;
    failures?: Failure[] | undefined;
}
export interface UpdateDaemonRequest {
    daemonArn: string;
    daemonTaskDefinitionArn: string;
    capacityProviderArns: string[];
    deploymentConfiguration?: DaemonDeploymentConfiguration | undefined;
    propagateTags?: DaemonPropagateTags | undefined;
    enableECSManagedTags?: boolean | undefined;
    enableExecuteCommand?: boolean | undefined;
    critical?: boolean | undefined;
}
export interface UpdateDaemonResponse {
    daemonArn?: string | undefined;
    status?: DaemonStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deploymentArn?: string | undefined;
}
export interface UpdateExpressGatewayServiceRequest {
    serviceArn: string;
    executionRoleArn?: string | undefined;
    healthCheckPath?: string | undefined;
    primaryContainer?: ExpressGatewayContainer | undefined;
    taskRoleArn?: string | undefined;
    networkConfiguration?: ExpressGatewayServiceNetworkConfiguration | undefined;
    cpu?: string | undefined;
    memory?: string | undefined;
    cpuArchitecture?: ExpressCpuArchitecture | undefined;
    scalingTarget?: ExpressGatewayScalingTarget | undefined;
    taskDefinitionArn?: string | undefined;
}
export interface UpdatedExpressGatewayService {
    serviceArn?: string | undefined;
    cluster?: string | undefined;
    serviceName?: string | undefined;
    status?: ExpressGatewayServiceStatus | undefined;
    targetConfiguration?: ExpressGatewayServiceConfiguration | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface UpdateExpressGatewayServiceResponse {
    service?: UpdatedExpressGatewayService | undefined;
}
export interface UpdateGatewayNetworkConfiguration {
    inboundSecurityGroup?: string | undefined;
}
export interface UpdateGatewayAlbConfiguration {
    networkConfiguration?: UpdateGatewayNetworkConfiguration | undefined;
    maxAlbCount?: number | undefined;
    webACLArn?: string | undefined;
    accessLogs?: GatewayElbAccessLogConfiguration | undefined;
    httpDesync?: GatewayAlbDesyncMitigationMode | undefined;
    testTrafficRules?: GatewayAlbTestTrafficRules | undefined;
}
export type UpdateGatewayConfiguration = {
    hostSharedAlb: UpdateGatewayAlbConfiguration;
};
export interface UpdateGatewayRequest {
    gateway: string;
    infrastructureRoleArn?: string | undefined;
    deletionProtection?: boolean | undefined;
    configuration?: UpdateGatewayConfiguration | undefined;
    propagateTags?: PropagateGatewayTags | undefined;
}
export interface UpdateGatewayResponse {
    gatewayArn?: string | undefined;
    name?: string | undefined;
    status?: GatewayStatus | undefined;
}
export interface UpdateServiceRequest {
    cluster?: string | undefined;
    service: string;
    desiredCount?: number | undefined;
    taskDefinition?: string | undefined;
    capacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    availabilityZoneRebalancing?: AvailabilityZoneRebalancing | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    placementConstraints?: PlacementConstraint[] | undefined;
    placementStrategy?: PlacementStrategy[] | undefined;
    platformVersion?: string | undefined;
    forceNewDeployment?: boolean | undefined;
    healthCheckGracePeriodSeconds?: number | undefined;
    deploymentController?: DeploymentController | undefined;
    enableExecuteCommand?: boolean | undefined;
    enableECSManagedTags?: boolean | undefined;
    loadBalancers?: LoadBalancer[] | undefined;
    propagateTags?: PropagateTags | undefined;
    serviceRegistries?: ServiceRegistry[] | undefined;
    serviceConnectConfiguration?: ServiceConnectConfiguration | undefined;
    volumeConfigurations?: ServiceVolumeConfiguration[] | undefined;
    vpcLatticeConfigurations?: VpcLatticeConfiguration[] | undefined;
    gatewayConnectors?: GatewayConnector[] | undefined;
    monitoring?: MonitoringConfiguration | undefined;
}
export interface UpdateServiceResponse {
    service?: Service | undefined;
}
export interface UpdateServicePrimaryTaskSetRequest {
    cluster: string;
    service: string;
    primaryTaskSet: string;
}
export interface UpdateServicePrimaryTaskSetResponse {
    taskSet?: TaskSet | undefined;
}
export interface UpdateTaskProtectionRequest {
    cluster: string;
    tasks: string[];
    protectionEnabled: boolean;
    expiresInMinutes?: number | undefined;
}
export interface UpdateTaskProtectionResponse {
    protectedTasks?: ProtectedTask[] | undefined;
    failures?: Failure[] | undefined;
}
export interface UpdateTaskSetRequest {
    cluster: string;
    service: string;
    taskSet: string;
    scale: Scale;
}
export interface UpdateTaskSetResponse {
    taskSet?: TaskSet | undefined;
}
export type ResourceIds = string[];
export type AssociateGatewayWithClusterError = AccessDeniedException | ClientException | ClusterNotFoundException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Associates a gateway with an Amazon ECS cluster. After a cluster is associated with a gateway, services in that cluster can use the gateway for ingress. No changes take effect until you update a service in the cluster to use the gateway. A single cluster can be associated with up to 5 gateways.
 */
export declare const associateGatewayWithCluster: API.OperationMethod<AssociateGatewayWithClusterRequest & RegionInput, AssociateGatewayWithClusterResponse, AssociateGatewayWithClusterError, Credentials | HttpClient.HttpClient>;
export type ContinueServiceDeploymentError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | ServiceDeploymentNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Continues or rolls back an Amazon ECS service deployment that is paused at a lifecycle hook.
 *
 * When a service deployment reaches a lifecycle stage that has a `PAUSE` hook configured, the deployment pauses and waits for an explicit action. Use this API to either continue the deployment to the next stage or roll back to the previous service revision.
 *
 * To find the `hookId` of the paused hook, call DescribeServiceDeployments and inspect the `lifecycleHookDetails` field.
 *
 * For more information, see Continuing Amazon ECS service deployments in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const continueServiceDeployment: API.OperationMethod<ContinueServiceDeploymentRequest & RegionInput, ContinueServiceDeploymentResponse, ContinueServiceDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | UnsupportedFeatureException | UpdateInProgressException | InfrastructureRoleAccessDenied | CommonErrors;
/**
 * Creates a capacity provider. Capacity providers are associated with a cluster and are used in capacity provider strategies to facilitate cluster auto scaling. You can create capacity providers for Amazon ECS Managed Instances and EC2 instances. Fargate has the predefined `FARGATE` and `FARGATE_SPOT` capacity providers.
 */
export declare const createCapacityProvider: API.OperationMethod<CreateCapacityProviderRequest & RegionInput, CreateCapacityProviderResponse, CreateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = AccessDeniedException | ClientException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * Creates a new Amazon ECS cluster. By default, your account receives a `default` cluster when you launch your first container instance. However, you can create your own cluster with a unique name.
 *
 * When you call the CreateCluster API operation, Amazon ECS attempts to create the Amazon ECS service-linked role for your account. This is so that it can manage required resources in other Amazon Web Services services on your behalf. However, if the user that makes the call doesn't have permissions to create the service-linked role, it isn't created. For more information, see Using service-linked roles for Amazon ECS in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Creates a new daemon in the specified cluster and capacity providers. A daemon deploys cross-cutting software agents such as security monitoring, telemetry, and logging independently across your Amazon ECS infrastructure.
 *
 * Amazon ECS deploys exactly one daemon task on each container instance of the specified capacity providers. When a container instance registers with the cluster, Amazon ECS automatically starts daemon tasks. Amazon ECS starts a daemon task before scheduling other tasks.
 *
 * Daemons are essential for instance health - if a daemon task stops, Amazon ECS automatically drains and replaces that container instance.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const createDaemon: API.OperationMethod<CreateDaemonRequest & RegionInput, CreateDaemonResponse, CreateDaemonError, Credentials | HttpClient.HttpClient>;
export type CreateExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Creates an Express service that simplifies deploying containerized web applications on Amazon ECS with managed Amazon Web Services infrastructure. This operation provisions and configures Application Load Balancers, target groups, security groups, and auto-scaling policies automatically.
 *
 * Specify a primary container configuration with your application image and basic settings. Amazon ECS creates the necessary Amazon Web Services resources for traffic distribution, health monitoring, network access control, and capacity management.
 *
 * Provide an execution role for task operations and an infrastructure role for managing Amazon Web Services resources on your behalf.
 */
export declare const createExpressGatewayService: API.OperationMethod<CreateExpressGatewayServiceRequest & RegionInput, CreateExpressGatewayServiceResponse, CreateExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Creates a gateway. A gateway defines and dynamically manages ingress paths for your Amazon ECS services, handling traffic routing and infrastructure across multiple services while optimizing infrastructure usage. `CreateGateway` is a synchronous operation and the gateway is returned with a status of `ACTIVE`. The load balancers and other infrastructure that a gateway manages aren't created until a service in an associated cluster begins using the gateway.
 *
 * To use this operation, you must have the `iam:PassRole` permission for the infrastructure role that you specify in `infrastructureRoleArn`.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayRequest & RegionInput, CreateGatewayResponse, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | ServiceRoleNotAssumable | CommonErrors;
/**
 * Runs and maintains your desired number of tasks from a specified task definition. If the number of tasks running in a service drops below the `desiredCount`, Amazon ECS runs another copy of the task in the specified cluster. To update an existing service, use UpdateService.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * In addition to maintaining the desired count of tasks in your service, you can optionally run your service behind one or more load balancers. The load balancers distribute traffic across the tasks that are associated with the service. For more information, see Service load balancing in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. `volumeConfigurations` is only supported for REPLICA service and not DAEMON service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Tasks for services that don't use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * There are two service scheduler strategies available:
 *
 * - `REPLICA` - The replica scheduling strategy places and maintains your desired number of tasks across your cluster. By default, the service scheduler spreads tasks across Availability Zones. You can use task placement strategies and constraints to customize task placement decisions. For more information, see Service scheduler concepts in the *Amazon Elastic Container Service Developer Guide*.
 *
 * - `DAEMON` - The daemon scheduling strategy deploys exactly one task on each active container instance that meets all of the task placement constraints that you specify in your cluster. The service scheduler also evaluates the task placement constraints for running tasks. It also stops tasks that don't meet the placement constraints. When using this strategy, you don't need to specify a desired number of tasks, a task placement strategy, or use Service Auto Scaling policies. For more information, see Amazon ECS services in the *Amazon Elastic Container Service Developer Guide*.
 *
 * The deployment controller is the mechanism that determines how tasks are deployed for your service. The valid options are:
 *
 * - ECS
 *
 * When you create a service which uses the `ECS` deployment controller, you can choose between the following deployment strategies (which you can set in the "`strategy`" field in "`deploymentConfiguration`"): :
 *
 * - `ROLLING`: When you create a service which uses the *rolling update* (`ROLLING`) deployment strategy, the Amazon ECS service scheduler replaces the currently running tasks with new tasks. The number of tasks that Amazon ECS adds or removes from the service during a rolling update is controlled by the service deployment configuration. For more information, see Deploy Amazon ECS services by replacing tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Rolling update deployments are best suited for the following scenarios:
 *
 * - Gradual service updates: You need to update your service incrementally without taking the entire service offline at once.
 *
 * - Limited resource requirements: You want to avoid the additional resource costs of running two complete environments simultaneously (as required by blue/green deployments).
 *
 * - Acceptable deployment time: Your application can tolerate a longer deployment process, as rolling updates replace tasks one by one.
 *
 * - No need for instant roll back: Your service can tolerate a rollback process that takes minutes rather than seconds.
 *
 * - Simple deployment process: You prefer a straightforward deployment approach without the complexity of managing multiple environments, target groups, and listeners.
 *
 * - No load balancer requirement: Your service doesn't use or require a load balancer, Application Load Balancer, Network Load Balancer, or Service Connect (which are required for blue/green deployments).
 *
 * - Stateful applications: Your application maintains state that makes it difficult to run two parallel environments.
 *
 * - Cost sensitivity: You want to minimize deployment costs by not running duplicate environments during deployment.
 *
 * Rolling updates are the default deployment strategy for services and provide a balance between deployment safety and resource efficiency for many common application scenarios.
 *
 * - `BLUE_GREEN`: A *blue/green* deployment strategy (`BLUE_GREEN`) is a release methodology that reduces downtime and risk by running two identical production environments called blue and green. With Amazon ECS blue/green deployments, you can validate new service revisions before directing production traffic to them. This approach provides a safer way to deploy changes with the ability to quickly roll back if needed. For more information, see Amazon ECS blue/green deployments in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Amazon ECS blue/green deployments are best suited for the following scenarios:
 *
 * - Service validation: When you need to validate new service revisions before directing production traffic to them
 *
 * - Zero downtime: When your service requires zero-downtime deployments
 *
 * - Instant roll back: When you need the ability to quickly roll back if issues are detected
 *
 * - Load balancer requirement: When your service uses Application Load Balancer, Network Load Balancer, or Service Connect
 *
 * - `LINEAR`: A *linear* deployment strategy (`LINEAR`) gradually shifts traffic from the current production environment to a new environment in equal percentage increments. With Amazon ECS linear deployments, you can control the pace of traffic shifting and validate new service revisions with increasing amounts of production traffic.
 *
 * Linear deployments are best suited for the following scenarios:
 *
 * - Gradual validation: When you want to gradually validate your new service version with increasing traffic
 *
 * - Performance monitoring: When you need time to monitor metrics and performance during the deployment
 *
 * - Risk minimization: When you want to minimize risk by exposing the new version to production traffic incrementally
 *
 * - Load balancer requirement: When your service uses Application Load Balancer or Service Connect
 *
 * - `CANARY`: A *canary* deployment strategy (`CANARY`) shifts a small percentage of traffic to the new service revision first, then shifts the remaining traffic all at once after a specified time period. This allows you to test the new version with a subset of users before full deployment.
 *
 * Canary deployments are best suited for the following scenarios:
 *
 * - Feature testing: When you want to test new features with a small subset of users before full rollout
 *
 * - Production validation: When you need to validate performance and functionality with real production traffic
 *
 * - Blast radius control: When you want to minimize blast radius if issues are discovered in the new version
 *
 * - Load balancer requirement: When your service uses Application Load Balancer or Service Connect
 *
 * - External
 *
 * Use a third-party deployment controller.
 *
 * - Blue/green deployment (powered by CodeDeploy)
 *
 * CodeDeploy installs an updated version of the application as a new replacement task set and reroutes production traffic from the original application task set to the replacement task set. The original task set is terminated after a successful deployment. Use this deployment controller to verify a new deployment of a service before sending production traffic to it.
 *
 * When creating a service that uses the `EXTERNAL` deployment controller, you can specify only parameters that aren't controlled at the task set level. The only required parameter is the service name. You control your services using the CreateTaskSet. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 *
 * When the service scheduler launches new tasks, it determines task placement. For information about task placement and task placement strategies, see Amazon ECS task placement in the *Amazon Elastic Container Service Developer Guide*
 */
export declare const createService: API.OperationMethod<CreateServiceRequest & RegionInput, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Create a task set in the specified cluster and service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * For information about the maximum number of task sets and other quotas, see Amazon ECS service quotas in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const createTaskSet: API.OperationMethod<CreateTaskSetRequest & RegionInput, CreateTaskSetResponse, CreateTaskSetError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountSettingError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Disables an account setting for a specified user, role, or the root user for an account.
 */
export declare const deleteAccountSetting: API.OperationMethod<DeleteAccountSettingRequest & RegionInput, DeleteAccountSettingResponse, DeleteAccountSettingError, Credentials | HttpClient.HttpClient>;
export type DeleteAttributesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotFoundException | CommonErrors;
/**
 * Deletes one or more custom attributes from an Amazon ECS resource.
 */
export declare const deleteAttributes: API.OperationMethod<DeleteAttributesRequest & RegionInput, DeleteAttributesResponse, DeleteAttributesError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | UpdateInProgressException | CommonErrors;
/**
 * Deletes the specified capacity provider.
 *
 * The `FARGATE` and `FARGATE_SPOT` capacity providers are reserved and can't be deleted. You can disassociate them from a cluster using either PutClusterCapacityProviders or by deleting the cluster.
 *
 * Prior to a capacity provider being deleted, the capacity provider must be removed from the capacity provider strategy from all services. The UpdateService API can be used to remove a capacity provider from a service's capacity provider strategy. When updating a service, the `forceNewDeployment` option can be used to ensure that any tasks using the Amazon EC2 instance capacity provided by the capacity provider are transitioned to use the capacity from the remaining capacity providers. Only capacity providers that aren't associated with a cluster can be deleted. To remove a capacity provider from a cluster, you can either use PutClusterCapacityProviders or delete the cluster.
 */
export declare const deleteCapacityProvider: API.OperationMethod<DeleteCapacityProviderRequest & RegionInput, DeleteCapacityProviderResponse, DeleteCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = AccessDeniedException | ClientException | ClusterContainsCapacityProviderException | ClusterContainsContainerInstancesException | ClusterContainsServicesException | ClusterContainsTasksException | ClusterNotFoundException | InvalidParameterException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Deletes the specified cluster. The cluster transitions to the `INACTIVE` state. Clusters with an `INACTIVE` status might remain discoverable in your account for a period of time. However, this behavior is subject to change in the future. We don't recommend that you rely on `INACTIVE` clusters persisting.
 *
 * You must deregister all container instances from this cluster before you may delete it. You can list the container instances in a cluster with ListContainerInstances and deregister them with DeregisterContainerInstance.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest & RegionInput, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotActiveException | DaemonNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes the specified daemon. The daemon must be in an `ACTIVE` state to be deleted. Deleting a daemon stops all running daemon tasks on the associated container instances. Amazon ECS drains existing container instances and provisions new instances without the deleted daemon. Amazon ECS automatically launches replacement tasks for your Amazon ECS services.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const deleteDaemon: API.OperationMethod<DeleteDaemonRequest & RegionInput, DeleteDaemonResponse, DeleteDaemonError, Credentials | HttpClient.HttpClient>;
export type DeleteDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deletes the specified daemon task definition. After a daemon task definition is deleted, no new daemons can be created using this definition. Existing daemons that reference the deleted daemon task definition continue to run.
 *
 * A daemon task definition must be in an `ACTIVE` state to be deleted.
 */
export declare const deleteDaemonTaskDefinition: API.OperationMethod<DeleteDaemonTaskDefinitionRequest & RegionInput, DeleteDaemonTaskDefinitionResponse, DeleteDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes an Express service and removes all associated Amazon Web Services resources. This operation stops service tasks, removes the Application Load Balancer, target groups, security groups, auto-scaling policies, and other managed infrastructure components.
 *
 * The service enters a `DRAINING` state where existing tasks complete current requests without starting new tasks. After all tasks stop, the service and infrastructure are permanently removed.
 *
 * This operation cannot be reversed. Back up important data and verify the service is no longer needed before deletion.
 */
export declare const deleteExpressGatewayService: API.OperationMethod<DeleteExpressGatewayServiceRequest & RegionInput, DeleteExpressGatewayServiceResponse, DeleteExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = AccessDeniedException | ClientException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes a gateway. Before you can delete a gateway, deletion protection must be disabled and the gateway must not have any cluster associations that are in the `ACTIVE` or `DISASSOCIATING` state. If associations exist, the operation fails; disassociate all clusters first. `DeleteGateway` is a synchronous operation. After you delete a gateway, subsequent requests for it return a `GatewayNotFoundException`.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayRequest & RegionInput, DeleteGatewayResponse, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | CommonErrors;
/**
 * Deletes a specified service within a cluster. You can delete a service if you have no running tasks in it and the desired task count is zero. If the service is actively maintaining tasks, you can't delete it, and you must update the service to a desired task count of zero. For more information, see UpdateService.
 *
 * When you delete a service, if there are still running tasks that require cleanup, the service status moves from `ACTIVE` to `DRAINING`, and the service is no longer visible in the console or in the ListServices API operation. After all tasks have transitioned to either `STOPPING` or `STOPPED` status, the service status moves from `DRAINING` to `INACTIVE`. Services in the `DRAINING` or `INACTIVE` status can still be viewed with the DescribeServices API operation. However, in the future, `INACTIVE` services may be cleaned up and purged from Amazon ECS record keeping, and DescribeServices calls on those services return a `ServiceNotFoundException` error.
 *
 * If you attempt to create a new service with the same name as an existing service in either `ACTIVE` or `DRAINING` status, you receive an error.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest & RegionInput, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deletes one or more task definitions.
 *
 * You must deregister a task definition revision before you delete it. For more information, see DeregisterTaskDefinition.
 *
 * When you delete a task definition revision, it is immediately transitions from the `INACTIVE` to `DELETE_IN_PROGRESS`. Existing tasks and services that reference a `DELETE_IN_PROGRESS` task definition revision continue to run without disruption. Existing services that reference a `DELETE_IN_PROGRESS` task definition revision can still scale up or down by modifying the service's desired count.
 *
 * You can't use a `DELETE_IN_PROGRESS` task definition revision to run new tasks or create new services. You also can't update an existing service to reference a `DELETE_IN_PROGRESS` task definition revision.
 *
 * A task definition revision will stay in `DELETE_IN_PROGRESS` status until all the associated tasks and services have been terminated.
 *
 * When you delete all `INACTIVE` task definition revisions, the task definition name is not displayed in the console and not returned in the API. If a task definition revisions are in the `DELETE_IN_PROGRESS` state, the task definition name is displayed in the console and returned in the API. The task definition name is retained by Amazon ECS and the revision is incremented the next time you create a task definition with that name.
 */
export declare const deleteTaskDefinitions: API.OperationMethod<DeleteTaskDefinitionsRequest & RegionInput, DeleteTaskDefinitionsResponse, DeleteTaskDefinitionsError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Deletes a specified task set within a service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS deployment types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const deleteTaskSet: API.OperationMethod<DeleteTaskSetRequest & RegionInput, DeleteTaskSetResponse, DeleteTaskSetError, Credentials | HttpClient.HttpClient>;
export type DeregisterContainerInstanceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deregisters an Amazon ECS container instance from the specified cluster. This instance is no longer available to run tasks.
 *
 * If you intend to use the container instance for some other purpose after deregistration, we recommend that you stop all of the tasks running on the container instance before deregistration. That prevents any orphaned tasks from consuming resources.
 *
 * Deregistering a container instance removes the instance from a cluster, but it doesn't terminate the EC2 instance. If you are finished using the instance, be sure to terminate it in the Amazon EC2 console to stop billing.
 *
 * If you terminate a running container instance, Amazon ECS automatically deregisters the instance from your cluster (stopped container instances or instances with disconnected agents aren't automatically deregistered when terminated).
 */
export declare const deregisterContainerInstance: API.OperationMethod<DeregisterContainerInstanceRequest & RegionInput, DeregisterContainerInstanceResponse, DeregisterContainerInstanceError, Credentials | HttpClient.HttpClient>;
export type DeregisterTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Deregisters the specified task definition by family and revision. Upon deregistration, the task definition is marked as `INACTIVE`. Existing tasks and services that reference an `INACTIVE` task definition continue to run without disruption. Existing services that reference an `INACTIVE` task definition can still scale up or down by modifying the service's desired count. If you want to delete a task definition revision, you must first deregister the task definition revision.
 *
 * You can't use an `INACTIVE` task definition to run new tasks or create new services, and you can't update an existing service to reference an `INACTIVE` task definition. However, there may be up to a 10-minute window following deregistration where these restrictions have not yet taken effect.
 *
 * At this time, `INACTIVE` task definitions remain discoverable in your account indefinitely. However, this behavior is subject to change in the future. We don't recommend that you rely on `INACTIVE` task definitions persisting beyond the lifecycle of any associated tasks and services.
 *
 * You must deregister a task definition revision before you delete it. For more information, see DeleteTaskDefinitions.
 */
export declare const deregisterTaskDefinition: API.OperationMethod<DeregisterTaskDefinitionRequest & RegionInput, DeregisterTaskDefinitionResponse, DeregisterTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeCapacityProvidersError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your capacity providers.
 */
export declare const describeCapacityProviders: API.OperationMethod<DescribeCapacityProvidersRequest & RegionInput, DescribeCapacityProvidersResponse, DescribeCapacityProvidersError, Credentials | HttpClient.HttpClient>;
export type DescribeClustersError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes one or more of your clusters.
 *
 * For CLI examples, see describe-clusters.rst on GitHub.
 */
export declare const describeClusters: API.OperationMethod<DescribeClustersRequest & RegionInput, DescribeClustersResponse, DescribeClustersError, Credentials | HttpClient.HttpClient>;
export type DescribeContainerInstancesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes one or more container instances. Returns metadata about each container instance requested.
 */
export declare const describeContainerInstances: API.OperationMethod<DescribeContainerInstancesRequest & RegionInput, DescribeContainerInstancesResponse, DescribeContainerInstancesError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes the specified daemon.
 */
export declare const describeDaemon: API.OperationMethod<DescribeDaemonRequest & RegionInput, DescribeDaemonResponse, DescribeDaemonError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your daemon deployments.
 *
 * A daemon deployment orchestrates the progressive rollout of daemon task updates across container instances managed by the daemon's capacity providers. Each deployment includes circuit breaker and alarm-based rollback capabilities.
 */
export declare const describeDaemonDeployments: API.OperationMethod<DescribeDaemonDeploymentsRequest & RegionInput, DescribeDaemonDeploymentsResponse, DescribeDaemonDeploymentsError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonRevisionsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your daemon revisions.
 *
 * A daemon revision is a snapshot of a daemon's configuration at the time a deployment was initiated. It captures the daemon task definition, container images, tag propagation, and execute command settings. Daemon revisions are immutable.
 */
export declare const describeDaemonRevisions: API.OperationMethod<DescribeDaemonRevisionsRequest & RegionInput, DescribeDaemonRevisionsResponse, DescribeDaemonRevisionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a daemon task definition. You can specify a `family` and `revision` to find information about a specific daemon task definition, or you can simply specify the family to find the latest `ACTIVE` revision in that family.
 */
export declare const describeDaemonTaskDefinition: API.OperationMethod<DescribeDaemonTaskDefinitionRequest & RegionInput, DescribeDaemonTaskDefinitionResponse, DescribeDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Retrieves detailed information about an Express service, including current status, configuration, managed infrastructure, and service revisions.
 *
 * Returns comprehensive service details, active service revisions, ingress paths with endpoints, and managed Amazon Web Services resource status including load balancers and auto-scaling policies.
 *
 * Use the `include` parameter to retrieve additional information such as resource tags.
 */
export declare const describeExpressGatewayService: API.OperationMethod<DescribeExpressGatewayServiceRequest & RegionInput, DescribeExpressGatewayServiceResponse, DescribeExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayError = AccessDeniedException | ClientException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes a gateway, including its configuration, status, and the type-specific infrastructure settings that it uses.
 */
export declare const describeGateway: API.OperationMethod<DescribeGatewayRequest & RegionInput, DescribeGatewayResponse, DescribeGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayResourcesError = AccessDeniedException | ClientException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns the infrastructure that a gateway has created and manages, so that you can follow the traffic path from top-level shared resources, such as load balancers, to the service-specific resources represented as gateway routes. Responses include only the Amazon Resource Names (ARNs) of gateway-managed infrastructure. For the current state of a resource, describe it with the corresponding Amazon Web Services service (Elastic Load Balancing, Amazon EC2, or Amazon Web Services Certificate Manager). The results are paginated.
 */
export declare const describeGatewayResources: API.OperationMethod<DescribeGatewayResourcesRequest & RegionInput, DescribeGatewayResourcesResponse, DescribeGatewayResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayRouteError = AccessDeniedException | ClientException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes a gateway route, including its status, the service it routes traffic to, and the service-specific infrastructure, such as target groups and listener rules, that the gateway manages for it.
 */
export declare const describeGatewayRoute: API.OperationMethod<DescribeGatewayRouteRequest & RegionInput, DescribeGatewayRouteResponse, DescribeGatewayRouteError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more of your service deployments.
 *
 * A service deployment happens when you release a software update for the service. For more information, see View service history using Amazon ECS service deployments.
 */
export declare const describeServiceDeployments: API.OperationMethod<DescribeServiceDeploymentsRequest & RegionInput, DescribeServiceDeploymentsResponse, DescribeServiceDeploymentsError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceRevisionsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes one or more service revisions.
 *
 * A service revision is a version of the service that includes the values for the Amazon ECS resources (for example, task definition) and the environment resources (for example, load balancers, subnets, and security groups). For more information, see Amazon ECS service revisions.
 *
 * You can't describe a service revision that was created before October 25, 2024.
 */
export declare const describeServiceRevisions: API.OperationMethod<DescribeServiceRevisionsRequest & RegionInput, DescribeServiceRevisionsResponse, DescribeServiceRevisionsError, Credentials | HttpClient.HttpClient>;
export type DescribeServicesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes the specified services running in your cluster.
 */
export declare const describeServices: API.OperationMethod<DescribeServicesRequest & RegionInput, DescribeServicesResponse, DescribeServicesError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a task definition. You can specify a `family` and `revision` to find information about a specific task definition, or you can simply specify the family to find the latest `ACTIVE` revision in that family.
 *
 * You can only describe `INACTIVE` task definitions while an active task or service references them.
 */
export declare const describeTaskDefinition: API.OperationMethod<DescribeTaskDefinitionRequest & RegionInput, DescribeTaskDefinitionResponse, DescribeTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeTasksError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Describes a specified task or tasks.
 *
 * Currently, stopped tasks appear in the returned results for at least one hour.
 *
 * If you have tasks with tags, and then delete the cluster, the tagged tasks are returned in the response. If you create a new cluster with the same name as the deleted cluster, the tagged tasks are not included in the response.
 */
export declare const describeTasks: API.OperationMethod<DescribeTasksRequest & RegionInput, DescribeTasksResponse, DescribeTasksError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskSetsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Describes the task sets in the specified cluster and service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const describeTaskSets: API.OperationMethod<DescribeTaskSetsRequest & RegionInput, DescribeTaskSetsResponse, DescribeTaskSetsError, Credentials | HttpClient.HttpClient>;
export type DisassociateGatewayFromClusterError = AccessDeniedException | ClientException | ClusterNotFoundException | GatewayNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Removes the association between a gateway and an Amazon ECS cluster. The association remains in the `DISASSOCIATING` state until you remove all of the gateway routes for the cluster by updating the associated services. You can use `ListGatewayRoutes` with a cluster filter to determine which routes are preventing disassociation. No infrastructure changes are made until the affected services are updated.
 */
export declare const disassociateGatewayFromCluster: API.OperationMethod<DisassociateGatewayFromClusterRequest & RegionInput, DisassociateGatewayFromClusterResponse, DisassociateGatewayFromClusterError, Credentials | HttpClient.HttpClient>;
export type DiscoverPollEndpointError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Returns an endpoint for the Amazon ECS agent to poll for updates.
 */
export declare const discoverPollEndpoint: API.OperationMethod<DiscoverPollEndpointRequest & RegionInput, DiscoverPollEndpointResponse, DiscoverPollEndpointError, Credentials | HttpClient.HttpClient>;
export type ExecuteCommandError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotConnectedException | CommonErrors;
/**
 * Runs a command remotely on a container within a task.
 *
 * If you use a condition key in your IAM policy to refine the conditions for the policy statement, for example limit the actions to a specific cluster, you receive an `AccessDeniedException` when there is a mismatch between the condition key value and the corresponding parameter value.
 *
 * For information about required permissions and considerations, see Using Amazon ECS Exec for debugging in the *Amazon ECS Developer Guide*.
 */
export declare const executeCommand: API.OperationMethod<ExecuteCommandRequest & RegionInput, ExecuteCommandResponse, ExecuteCommandError, Credentials | HttpClient.HttpClient>;
export type GetTaskProtectionError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Retrieves the protection status of tasks in an Amazon ECS service.
 */
export declare const getTaskProtection: API.OperationMethod<GetTaskProtectionRequest & RegionInput, GetTaskProtectionResponse, GetTaskProtectionError, Credentials | HttpClient.HttpClient>;
export type ListAccountSettingsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Lists the account settings for a specified principal.
 */
export declare const listAccountSettings: API.PaginatedOperationMethod<ListAccountSettingsRequest & RegionInput, ListAccountSettingsResponse, ListAccountSettingsError, Credentials | HttpClient.HttpClient, Setting>;
export type ListAttributesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Lists the attributes for Amazon ECS resources within a specified target type and cluster. When you specify a target type and cluster, `ListAttributes` returns a list of attribute objects, one for each attribute on each resource. You can filter the list of results to a single attribute name to only return results that have that name. You can also filter the results by attribute name and value. You can do this, for example, to see which container instances in a cluster are running a Linux AMI (`ecs.os-type=linux`).
 */
export declare const listAttributes: API.PaginatedOperationMethod<ListAttributesRequest & RegionInput, ListAttributesResponse, ListAttributesError, Credentials | HttpClient.HttpClient, Attribute>;
export type ListClustersError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of existing clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, string>;
export type ListContainerInstancesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of container instances in a specified cluster. You can filter the results of a `ListContainerInstances` operation with cluster query language statements inside the `filter` parameter. For more information, see Cluster Query Language in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const listContainerInstances: API.PaginatedOperationMethod<ListContainerInstancesRequest & RegionInput, ListContainerInstancesResponse, ListContainerInstancesError, Credentials | HttpClient.HttpClient, string>;
export type ListDaemonDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of daemon deployments for a specified daemon. You can filter the results by status or creation time.
 */
export declare const listDaemonDeployments: API.OperationMethod<ListDaemonDeploymentsRequest & RegionInput, ListDaemonDeploymentsResponse, ListDaemonDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListDaemonsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of daemons. You can filter the results by cluster or capacity provider.
 */
export declare const listDaemons: API.OperationMethod<ListDaemonsRequest & RegionInput, ListDaemonsResponse, ListDaemonsError, Credentials | HttpClient.HttpClient>;
export type ListDaemonTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of daemon task definitions that are registered to your account. You can filter the results by family name, status, or both to find daemon task definitions that match your criteria.
 */
export declare const listDaemonTaskDefinitions: API.OperationMethod<ListDaemonTaskDefinitionsRequest & RegionInput, ListDaemonTaskDefinitionsResponse, ListDaemonTaskDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListGatewayClusterAssociationsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of the associations between gateways and clusters. You can filter the results by gateway, cluster, and status. The results are paginated. We recommend that you use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listGatewayClusterAssociations: API.PaginatedOperationMethod<ListGatewayClusterAssociationsRequest & RegionInput, ListGatewayClusterAssociationsResponse, ListGatewayClusterAssociationsError, Credentials | HttpClient.HttpClient, GatewayClusterAssociationSummary>;
export type ListGatewayRoutesError = AccessDeniedException | ClientException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of gateway routes. A gateway route represents the association between a service and a gateway and the service-specific infrastructure the gateway manages for it. You can filter the results by gateway, cluster, service, container port name, and status. The results are paginated. We recommend that you use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listGatewayRoutes: API.PaginatedOperationMethod<ListGatewayRoutesRequest & RegionInput, ListGatewayRoutesResponse, ListGatewayRoutesError, Credentials | HttpClient.HttpClient, GatewayRouteSummary>;
export type ListGatewaysError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Returns a list of gateways in your account. You can filter the results by gateway name and status. The results are paginated. We recommend that you use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysRequest & RegionInput, ListGatewaysResponse, ListGatewaysError, Credentials | HttpClient.HttpClient, GatewaySummary>;
export type ListServiceDeploymentsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * This operation lists all the service deployments that meet the specified filter criteria.
 *
 * A service deployment happens when you release a software update for the service. You route traffic from the running service revisions to the new service revison and control the number of running tasks.
 *
 * This API returns the values that you use for the request parameters in DescribeServiceRevisions.
 */
export declare const listServiceDeployments: API.OperationMethod<ListServiceDeploymentsRequest & RegionInput, ListServiceDeploymentsResponse, ListServiceDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListServicesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of services. You can filter the results by cluster, launch type, and scheduling strategy.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest & RegionInput, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, string>;
export type ListServicesByNamespaceError = AccessDeniedException | ClientException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * This operation lists all of the services that are associated with a Cloud Map namespace. This list might include services in different clusters. In contrast, `ListServices` can only list services in one cluster at a time. If you need to filter the list of services in a single cluster by various parameters, use `ListServices`. For more information, see Service Connect in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const listServicesByNamespace: API.PaginatedOperationMethod<ListServicesByNamespaceRequest & RegionInput, ListServicesByNamespaceResponse, ListServicesByNamespaceError, Credentials | HttpClient.HttpClient, string>;
export type ListTagsForResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * List the tags for an Amazon ECS resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTaskDefinitionFamiliesError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of task definition families that are registered to your account. This list includes task definition families that no longer have any `ACTIVE` task definition revisions.
 *
 * You can filter out task definition families that don't contain any `ACTIVE` task definition revisions by setting the `status` parameter to `ACTIVE`. You can also filter the results with the `familyPrefix` parameter.
 */
export declare const listTaskDefinitionFamilies: API.PaginatedOperationMethod<ListTaskDefinitionFamiliesRequest & RegionInput, ListTaskDefinitionFamiliesResponse, ListTaskDefinitionFamiliesError, Credentials | HttpClient.HttpClient, string>;
export type ListTaskDefinitionsError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Returns a list of task definitions that are registered to your account. You can filter the results by family name with the `familyPrefix` parameter or by status with the `status` parameter.
 */
export declare const listTaskDefinitions: API.PaginatedOperationMethod<ListTaskDefinitionsRequest & RegionInput, ListTaskDefinitionsResponse, ListTaskDefinitionsError, Credentials | HttpClient.HttpClient, string>;
export type ListTasksError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotFoundException | CommonErrors;
/**
 * Returns a list of tasks. You can filter the results by cluster, task definition family, container instance, launch type, what IAM principal started the task, or by the desired status of the task.
 *
 * Recently stopped tasks might appear in the returned results.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest & RegionInput, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, string>;
export type PutAccountSettingError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies an account setting. Account settings are set on a per-Region basis.
 *
 * If you change the root user account setting, the default settings are reset for users and roles that do not have specified individual account settings. For more information, see Account Settings in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest & RegionInput, PutAccountSettingResponse, PutAccountSettingError, Credentials | HttpClient.HttpClient>;
export type PutAccountSettingDefaultError = AccessDeniedException | ClientException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies an account setting for all users on an account for whom no individual account setting has been specified. Account settings are set on a per-Region basis.
 */
export declare const putAccountSettingDefault: API.OperationMethod<PutAccountSettingDefaultRequest & RegionInput, PutAccountSettingDefaultResponse, PutAccountSettingDefaultError, Credentials | HttpClient.HttpClient>;
export type PutAttributesError = AccessDeniedException | AttributeLimitExceededException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | TargetNotFoundException | CommonErrors;
/**
 * Create or update an attribute on an Amazon ECS resource. If the attribute doesn't exist, it's created. If the attribute exists, its value is replaced with the specified value. To delete an attribute, use DeleteAttributes. For more information, see Attributes in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const putAttributes: API.OperationMethod<PutAttributesRequest & RegionInput, PutAttributesResponse, PutAttributesError, Credentials | HttpClient.HttpClient>;
export type PutClusterCapacityProvidersError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceInUseException | ServerException | UpdateInProgressException | ServiceLinkedRoleNotAssumable | CommonErrors;
/**
 * Modifies the available capacity providers and the default capacity provider strategy for a cluster.
 *
 * You must specify both the available capacity providers and a default capacity provider strategy for the cluster. If the specified cluster has existing capacity providers associated with it, you must specify all existing capacity providers in addition to any new ones you want to add. Any existing capacity providers that are associated with a cluster that are omitted from a PutClusterCapacityProviders API call will be disassociated with the cluster. You can only disassociate an existing capacity provider from a cluster if it's not being used by any existing tasks.
 *
 * When creating a service or running a task on a cluster, if no capacity provider or launch type is specified, then the cluster's default capacity provider strategy is used. We recommend that you define a default capacity provider strategy for your cluster. However, you must specify an empty array (`[]`) to bypass defining a default strategy.
 *
 * Amazon ECS Managed Instances doesn't support this, because when you create a capacity provider with Amazon ECS Managed Instances, it becomes available only within the specified cluster.
 */
export declare const putClusterCapacityProviders: API.OperationMethod<PutClusterCapacityProvidersRequest & RegionInput, PutClusterCapacityProvidersResponse, PutClusterCapacityProvidersError, Credentials | HttpClient.HttpClient>;
export type RegisterContainerInstanceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Registers an EC2 instance into the specified cluster. This instance becomes available to place containers on.
 */
export declare const registerContainerInstance: API.OperationMethod<RegisterContainerInstanceRequest & RegionInput, RegisterContainerInstanceResponse, RegisterContainerInstanceError, Credentials | HttpClient.HttpClient>;
export type RegisterDaemonTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | LimitExceededException | ServerException | CommonErrors;
/**
 * Registers a new daemon task definition from the supplied `family` and `containerDefinitions`. Optionally, you can add data volumes to your containers with the `volumes` parameter. For more information, see Daemon task definitions in the *Amazon Elastic Container Service Developer Guide*.
 *
 * A daemon task definition is a template that describes the containers that form a daemon. Daemons deploy cross-cutting software agents such as security monitoring, telemetry, and logging across your Amazon ECS infrastructure.
 *
 * Each time you call `RegisterDaemonTaskDefinition`, a new revision of the daemon task definition is created. You can't modify a revision after you register it.
 */
export declare const registerDaemonTaskDefinition: API.OperationMethod<RegisterDaemonTaskDefinitionRequest & RegionInput, RegisterDaemonTaskDefinitionResponse, RegisterDaemonTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type RegisterTaskDefinitionError = AccessDeniedException | ClientException | InvalidParameterException | LimitExceededException | ServerException | CommonErrors;
/**
 * Registers a new task definition from the supplied `family` and `containerDefinitions`. Optionally, you can add data volumes to your containers with the `volumes` parameter. For more information about task definition parameters and defaults, see Amazon ECS Task Definitions in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can specify a role for your task with the `taskRoleArn` parameter. When you specify a role for a task, its containers can then use the latest versions of the CLI or SDKs to make API requests to the Amazon Web Services services that are specified in the policy that's associated with the role. For more information, see IAM Roles for Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can specify a Docker networking mode for the containers in your task definition with the `networkMode` parameter. If you specify the `awsvpc` network mode, the task is allocated an elastic network interface, and you must specify a NetworkConfiguration when you create a service or run a task with the task definition. For more information, see Task Networking in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const registerTaskDefinition: API.OperationMethod<RegisterTaskDefinitionRequest & RegionInput, RegisterTaskDefinitionResponse, RegisterTaskDefinitionError, Credentials | HttpClient.HttpClient>;
export type RunTaskError = AccessDeniedException | BlockedException | ClientException | ClusterNotFoundException | ConflictException | InvalidParameterException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Starts a new task using the specified task definition.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * You can allow Amazon ECS to place tasks for you, or you can customize how Amazon ECS places tasks using placement constraints and placement strategies. For more information, see Scheduling Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Alternatively, you can use `StartTask` to use your own scheduler or place tasks manually on specific container instances.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * The Amazon ECS API follows an eventual consistency model. This is because of the distributed nature of the system supporting the API. This means that the result of an API command you run that affects your Amazon ECS resources might not be immediately visible to all subsequent commands you run. Keep this in mind when you carry out an API command that immediately follows a previous API command.
 *
 * To manage eventual consistency, you can do the following:
 *
 * - Confirm the state of the resource before you run a command to modify it. Run the DescribeTasks command using an exponential backoff algorithm to ensure that you allow enough time for the previous command to propagate through the system. To do this, run the DescribeTasks command repeatedly, starting with a couple of seconds of wait time and increasing gradually up to five minutes of wait time.
 *
 * - Add wait time between subsequent commands, even if the DescribeTasks command returns an accurate response. Apply an exponential backoff algorithm starting with a couple of seconds of wait time, and increase gradually up to about five minutes of wait time.
 *
 * If you get a `ConflictException` error, the `RunTask` request could not be processed due to conflicts. The provided `clientToken` is already in use with a different `RunTask` request. The `resourceIds` are the existing task ARNs which are already associated with the `clientToken`.
 *
 * To fix this issue:
 *
 * - Run `RunTask` with a unique `clientToken`.
 *
 * - Run `RunTask` with the `clientToken` and the original set of parameters
 *
 * If you get a `ClientException`error, the `RunTask` could not be processed because you use managed scaling and there is a capacity error because the quota of tasks in the `PROVISIONING` per cluster has been reached. For information about the service quotas, see Amazon ECS service quotas.
 */
export declare const runTask: API.OperationMethod<RunTaskRequest & RegionInput, RunTaskResponse, RunTaskError, Credentials | HttpClient.HttpClient>;
export type StartTaskError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Starts a new task from the specified task definition on the specified container instance or instances.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * Amazon Elastic Inference (EI) is no longer available to customers.
 *
 * Alternatively, you can use`RunTask` to place tasks for you. For more information, see Scheduling Tasks in the *Amazon Elastic Container Service Developer Guide*.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const startTask: API.OperationMethod<StartTaskRequest & RegionInput, StartTaskResponse, StartTaskError, Credentials | HttpClient.HttpClient>;
export type StopServiceDeploymentError = AccessDeniedException | ClientException | ConflictException | InvalidParameterException | ServerException | ServiceDeploymentNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Stops an ongoing service deployment.
 *
 * The following stop types are avaiable:
 *
 * - ROLLBACK - This option rolls back the service deployment to the previous service revision.
 *
 * You can use this option even if you didn't configure the service deployment for the rollback option.
 *
 * For more information, see Stopping Amazon ECS service deployments in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const stopServiceDeployment: API.OperationMethod<StopServiceDeploymentRequest & RegionInput, StopServiceDeploymentResponse, StopServiceDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopTaskError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Stops a running task. Any tags associated with the task will be deleted.
 *
 * When you call `StopTask` on a task, the equivalent of `docker stop` is issued to the containers running in the task. This results in a stop signal value and a default 30-second timeout, after which the `SIGKILL` value is sent and the containers are forcibly stopped. This signal can be defined in your container image with the `STOPSIGNAL` instruction and will default to `SIGTERM`. If the container handles the `SIGTERM` value gracefully and exits within 30 seconds from receiving it, no `SIGKILL` value is sent.
 *
 * For Windows containers, POSIX signals do not work and runtime stops the container by sending a `CTRL_SHUTDOWN_EVENT`. For more information, see Unable to react to graceful shutdown of (Windows) container #25982 on GitHub.
 *
 * The default 30-second timeout can be configured on the Amazon ECS container agent with the `ECS_CONTAINER_STOP_TIMEOUT` variable. For more information, see Amazon ECS Container Agent Configuration in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const stopTask: API.OperationMethod<StopTaskRequest & RegionInput, StopTaskResponse, StopTaskError, Credentials | HttpClient.HttpClient>;
export type SubmitAttachmentStateChangesError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that an attachment changed states.
 */
export declare const submitAttachmentStateChanges: API.OperationMethod<SubmitAttachmentStateChangesRequest & RegionInput, SubmitAttachmentStateChangesResponse, SubmitAttachmentStateChangesError, Credentials | HttpClient.HttpClient>;
export type SubmitContainerStateChangeError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that a container changed states.
 */
export declare const submitContainerStateChange: API.OperationMethod<SubmitContainerStateChangeRequest & RegionInput, SubmitContainerStateChangeResponse, SubmitContainerStateChangeError, Credentials | HttpClient.HttpClient>;
export type SubmitTaskStateChangeError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * This action is only used by the Amazon ECS agent, and it is not intended for use outside of the agent.
 *
 * Sent to acknowledge that a task changed states.
 */
export declare const submitTaskStateChange: API.OperationMethod<SubmitTaskStateChangeRequest & RegionInput, SubmitTaskStateChangeResponse, SubmitTaskStateChangeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`. If existing tags on a resource aren't specified in the request parameters, they aren't changed. When a resource is deleted, the tags that are associated with that resource are deleted as well.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityProviderError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | InfrastructureRoleAccessDenied | CommonErrors;
/**
 * Modifies the parameters for a capacity provider.
 *
 * These changes only apply to new Amazon ECS Managed Instances, or EC2 instances, not existing ones.
 */
export declare const updateCapacityProvider: API.OperationMethod<UpdateCapacityProviderRequest & RegionInput, UpdateCapacityProviderResponse, UpdateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | ServerException | CommonErrors;
/**
 * Updates the cluster.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest & RegionInput, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterSettingsError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Modifies the settings to use for a cluster.
 */
export declare const updateClusterSettings: API.OperationMethod<UpdateClusterSettingsRequest & RegionInput, UpdateClusterSettingsResponse, UpdateClusterSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerAgentError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | MissingVersionException | NoUpdateAvailableException | ServerException | UpdateInProgressException | CommonErrors;
/**
 * Updates the Amazon ECS container agent on a specified container instance. Updating the Amazon ECS container agent doesn't interrupt running tasks or services on the container instance. The process for updating the agent differs depending on whether your container instance was launched with the Amazon ECS-optimized AMI or another operating system.
 *
 * The `UpdateContainerAgent` API isn't supported for container instances using the Amazon ECS-optimized Amazon Linux 2 (arm64) AMI. To update the container agent, you can update the `ecs-init` package. This updates the agent. For more information, see Updating the Amazon ECS container agent in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Agent updates with the `UpdateContainerAgent` API operation do not apply to Windows container instances. We recommend that you launch new container instances to update the agent version in your Windows clusters.
 *
 * The `UpdateContainerAgent` API requires an Amazon ECS-optimized AMI or Amazon Linux AMI with the `ecs-init` service installed and running. For help updating the Amazon ECS container agent on other operating systems, see Manually updating the Amazon ECS container agent in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateContainerAgent: API.OperationMethod<UpdateContainerAgentRequest & RegionInput, UpdateContainerAgentResponse, UpdateContainerAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerInstancesStateError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | CommonErrors;
/**
 * Modifies the status of an Amazon ECS container instance.
 *
 * Once a container instance has reached an `ACTIVE` state, you can change the status of a container instance to `DRAINING` to manually remove an instance from a cluster, for example to perform system updates, update the Docker daemon, or scale down the cluster size.
 *
 * A container instance can't be changed to `DRAINING` until it has reached an `ACTIVE` status. If the instance is in any other status, an error will be received.
 *
 * When you set a container instance to `DRAINING`, Amazon ECS prevents new tasks from being scheduled for placement on the container instance and replacement service tasks are started on other container instances in the cluster if the resources are available. Service tasks on the container instance that are in the `PENDING` state are stopped immediately.
 *
 * Service tasks on the container instance that are in the `RUNNING` state are stopped and replaced according to the service's deployment configuration parameters, `minimumHealthyPercent` and `maximumPercent`. You can change the deployment configuration of your service using UpdateService.
 *
 * - If `minimumHealthyPercent` is below 100%, the scheduler can ignore `desiredCount` temporarily during task replacement. For example, `desiredCount` is four tasks, a minimum of 50% allows the scheduler to stop two existing tasks before starting two new tasks. If the minimum is 100%, the service scheduler can't remove existing tasks until the replacement tasks are considered healthy. Tasks for services that do not use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * - The `maximumPercent` parameter represents an upper limit on the number of running tasks during task replacement. You can use this to define the replacement batch size. For example, if `desiredCount` is four tasks, a maximum of 200% starts four new tasks before stopping the four tasks to be drained, provided that the cluster resources required to do this are available. If the maximum is 100%, then replacement tasks can't start until the draining tasks have stopped.
 *
 * Any `PENDING` or `RUNNING` tasks that do not belong to a service aren't affected. You must wait for them to finish or stop them manually.
 *
 * A container instance has completed draining when it has no more `RUNNING` tasks. You can verify this using ListTasks.
 *
 * When a container instance has been drained, you can set a container instance to `ACTIVE` status and once it has reached that status the Amazon ECS scheduler can begin scheduling tasks on the instance again.
 */
export declare const updateContainerInstancesState: API.OperationMethod<UpdateContainerInstancesStateRequest & RegionInput, UpdateContainerInstancesStateResponse, UpdateContainerInstancesStateError, Credentials | HttpClient.HttpClient>;
export type UpdateDaemonError = AccessDeniedException | ClientException | ClusterNotFoundException | DaemonNotActiveException | DaemonNotFoundException | InvalidParameterException | PlatformUnknownException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates the specified daemon. When you update a daemon, a new deployment is triggered that progressively rolls out the changes to the container instances associated with the daemon's capacity providers. For more information, see Daemon deployments in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Amazon ECS drains existing container instances and provisions new instances with the updated daemon. Amazon ECS automatically launches replacement tasks for your services.
 *
 * Updating a daemon triggers a rolling deployment that drains and replaces container instances. Plan updates during maintenance windows to minimize impact on running services.
 *
 * ECS Managed Daemons is only supported for Amazon ECS Managed Instances Capacity Providers.
 */
export declare const updateDaemon: API.OperationMethod<UpdateDaemonRequest & RegionInput, UpdateDaemonResponse, UpdateDaemonError, Credentials | HttpClient.HttpClient>;
export type UpdateExpressGatewayServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates an existing Express service configuration. Modifies container settings, resource allocation, auto-scaling configuration, and other service parameters without recreating the service.
 *
 * Amazon ECS creates a new service revision with updated configuration and performs a rolling deployment to replace existing tasks. The service remains available during updates, ensuring zero-downtime deployments.
 *
 * Some parameters like the infrastructure role cannot be modified after service creation and require creating a new service.
 */
export declare const updateExpressGatewayService: API.OperationMethod<UpdateExpressGatewayServiceRequest & RegionInput, UpdateExpressGatewayServiceResponse, UpdateExpressGatewayServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayError = AccessDeniedException | ClientException | GatewayNotFoundException | InvalidParameterException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies the configuration of a gateway. You can change only the properties that can be applied without interrupting traffic, and the configuration variant that you provide must match the gateway's type. `UpdateGateway` is an asynchronous operation: the changes are applied to each load balancer the gateway manages, and the gateway reports a status of `UPDATE_IN_PROGRESS` until the update completes. If Amazon ECS can't update one or more resources, it makes a best effort to update the rest and the gateway status changes to `UPDATE_FAILED`. Use `DescribeGateway` to inspect the gateway's `statusReason` and failures list, which gives the ARN of each load balancer that was not updated and the operation, error code, and message for each failure.
 *
 * If you specify `infrastructureRoleArn`, you must have the `iam:PassRole` permission for that role.
 */
export declare const updateGateway: API.OperationMethod<UpdateGatewayRequest & RegionInput, UpdateGatewayResponse, UpdateGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | NamespaceNotFoundException | PlatformTaskDefinitionIncompatibilityException | PlatformUnknownException | ServerException | ServiceNotActiveException | ServiceNotFoundException | UnsupportedFeatureException | ServiceRoleNotAssumable | CommonErrors;
/**
 * Modifies the parameters of a service.
 *
 * On March 21, 2024, a change was made to resolve the task definition revision before authorization. When a task definition revision is not specified, authorization will occur using the latest revision of a task definition.
 *
 * For services using the rolling update (`ECS`) you can update the desired count, deployment configuration, network configuration, load balancers, service registries, enable ECS managed tags option, propagate tags option, task placement constraints and strategies, and task definition. When you update any of these parameters, Amazon ECS starts new tasks with the new configuration.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when starting or running a task, or when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*. You can update your volume configurations and trigger a new deployment. `volumeConfigurations` is only supported for REPLICA service and not DAEMON service. If you leave `volumeConfigurations` `null`, it doesn't trigger a new deployment. For more information on volumes, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * For services using the blue/green (`CODE_DEPLOY`) deployment controller, only the desired count, deployment configuration, health check grace period, task placement constraints and strategies, enable ECS managed tags option, and propagate tags can be updated using this API. If the network configuration, platform version, task definition, or load balancer need to be updated, create a new CodeDeploy deployment. For more information, see CreateDeployment in the *CodeDeploy API Reference*.
 *
 * For services using an external deployment controller, you can update only the desired count, task placement constraints and strategies, health check grace period, enable ECS managed tags option, and propagate tags option, using this API. If the launch type, load balancer, network configuration, platform version, or task definition need to be updated, create a new task set For more information, see CreateTaskSet.
 *
 * You can add to or subtract from the number of instantiations of a task definition in a service by specifying the cluster that the service is running in and a new `desiredCount` parameter.
 *
 * You can attach Amazon EBS volumes to Amazon ECS tasks by configuring the volume when starting or running a task, or when creating or updating a service. For more information, see Amazon EBS volumes in the *Amazon Elastic Container Service Developer Guide*.
 *
 * If you have updated the container image of your application, you can create a new task definition with that image and deploy it to your service. The service scheduler uses the minimum healthy percent and maximum percent parameters (in the service's deployment configuration) to determine the deployment strategy.
 *
 * If your updated Docker image uses the same tag as what is in the existing task definition for your service (for example, `my_image:latest`), you don't need to create a new revision of your task definition. You can update the service using the `forceNewDeployment` option. The new tasks launched by the deployment pull the current image/tag combination from your repository when they start.
 *
 * You can also update the deployment configuration of a service. When a deployment is triggered by updating the task definition of a service, the service scheduler uses the deployment configuration parameters, `minimumHealthyPercent` and `maximumPercent`, to determine the deployment strategy.
 *
 * - If `minimumHealthyPercent` is below 100%, the scheduler can ignore `desiredCount` temporarily during a deployment. For example, if `desiredCount` is four tasks, a minimum of 50% allows the scheduler to stop two existing tasks before starting two new tasks. Tasks for services that don't use a load balancer are considered healthy if they're in the `RUNNING` state. Tasks for services that use a load balancer are considered healthy if they're in the `RUNNING` state and are reported as healthy by the load balancer.
 *
 * - The `maximumPercent` parameter represents an upper limit on the number of running tasks during a deployment. You can use it to define the deployment batch size. For example, if `desiredCount` is four tasks, a maximum of 200% starts four new tasks before stopping the four older tasks (provided that the cluster resources required to do this are available).
 *
 * When UpdateService stops a task during a deployment, the equivalent of `docker stop` is issued to the containers running in the task. This results in a `SIGTERM` and a 30-second timeout. After this, `SIGKILL` is sent and the containers are forcibly stopped. If the container handles the `SIGTERM` gracefully and exits within 30 seconds from receiving it, no `SIGKILL` is sent.
 *
 * When the service scheduler launches new tasks, it determines task placement in your cluster with the following logic.
 *
 * - Determine which of the container instances in your cluster can support your service's task definition. For example, they have the required CPU, memory, ports, and container instance attributes.
 *
 * - By default, the service scheduler attempts to balance tasks across Availability Zones in this manner even though you can choose a different placement strategy.
 *
 * - Sort the valid container instances by the fewest number of running tasks for this service in the same Availability Zone as the instance. For example, if zone A has one running service task and zones B and C each have zero, valid container instances in either zone B or C are considered optimal for placement.
 *
 * - Place the new service task on a valid container instance in an optimal Availability Zone (based on the previous steps), favoring container instances with the fewest number of running tasks for this service.
 *
 * When the service scheduler stops running tasks, it attempts to maintain balance across the Availability Zones in your cluster using the following logic:
 *
 * - Sort the container instances by the largest number of running tasks for this service in the same Availability Zone as the instance. For example, if zone A has one running service task and zones B and C each have two, container instances in either zone B or C are considered optimal for termination.
 *
 * - Stop the task on a container instance in an optimal Availability Zone (based on the previous steps), favoring container instances with the largest number of running tasks for this service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest & RegionInput, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServicePrimaryTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies which task set in a service is the primary task set. Any parameters that are updated on the primary task set in a service will transition to the service. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateServicePrimaryTaskSet: API.OperationMethod<UpdateServicePrimaryTaskSetRequest & RegionInput, UpdateServicePrimaryTaskSetResponse, UpdateServicePrimaryTaskSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskProtectionError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | ResourceNotFoundException | ServerException | UnsupportedFeatureException | CommonErrors;
/**
 * Updates the protection status of a task. You can set `protectionEnabled` to `true` to protect your task from termination during scale-in events from Service Autoscaling or deployments.
 *
 * Task-protection, by default, expires after 2 hours at which point Amazon ECS clears the `protectionEnabled` property making the task eligible for termination by a subsequent scale-in event.
 *
 * You can specify a custom expiration period for task protection from 1 minute to up to 2,880 minutes (48 hours). To specify the custom expiration period, set the `expiresInMinutes` property. The `expiresInMinutes` property is always reset when you invoke this operation for a task that already has `protectionEnabled` set to `true`. You can keep extending the protection expiration period of a task by invoking this operation repeatedly.
 *
 * To learn more about Amazon ECS task protection, see Task scale-in protection in the * Amazon Elastic Container Service Developer Guide* .
 *
 * This operation is only supported for tasks belonging to an Amazon ECS service. Invoking this operation for a standalone task will result in an `TASK_NOT_VALID` failure. For more information, see API failure reasons.
 *
 * If you prefer to set task protection from within the container, we recommend using the Task scale-in protection endpoint.
 */
export declare const updateTaskProtection: API.OperationMethod<UpdateTaskProtectionRequest & RegionInput, UpdateTaskProtectionResponse, UpdateTaskProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskSetError = AccessDeniedException | ClientException | ClusterNotFoundException | InvalidParameterException | LimitExceededException | ServerException | ServiceNotActiveException | ServiceNotFoundException | TaskSetNotFoundException | UnsupportedFeatureException | CommonErrors;
/**
 * Modifies a task set. This is used when a service uses the `EXTERNAL` deployment controller type. For more information, see Amazon ECS Deployment Types in the *Amazon Elastic Container Service Developer Guide*.
 */
export declare const updateTaskSet: API.OperationMethod<UpdateTaskSetRequest & RegionInput, UpdateTaskSetResponse, UpdateTaskSetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ecs.d.ts.map