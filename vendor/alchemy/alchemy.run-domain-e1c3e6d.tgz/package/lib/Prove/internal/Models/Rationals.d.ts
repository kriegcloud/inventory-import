import type { Kit, Model } from "../Kit.ts";
import type { V } from "../Value.ts";
/**
 * `Rational`: one whole number over another, held exactly. The solver's real
 * numbers are those, so every operation is read on any fraction, a division
 * too.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
    values: Record<string, V>;
};
//# sourceMappingURL=Rationals.d.ts.map