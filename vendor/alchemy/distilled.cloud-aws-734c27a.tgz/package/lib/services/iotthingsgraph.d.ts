import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ThingName = string;
export type Urn = string;
export type Version = number;
export interface AssociateEntityToThingRequest {
    thingName: string;
    entityId: string;
    namespaceVersion?: number | undefined;
}
export interface AssociateEntityToThingResponse {
}
export type DefinitionLanguage = "GRAPHQL" | (string & {});
export type DefinitionText = string;
export interface DefinitionDocument {
    language: DefinitionLanguage;
    text: string;
}
export interface CreateFlowTemplateRequest {
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number | undefined;
}
export type Arn = string;
export interface FlowTemplateSummary {
    id?: string | undefined;
    arn?: string | undefined;
    revisionNumber?: number | undefined;
    createdAt?: Date | undefined;
}
export interface CreateFlowTemplateResponse {
    summary?: FlowTemplateSummary | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export type DeploymentTarget = "GREENGRASS" | "CLOUD" | (string & {});
export type GroupName = string;
export type S3BucketName = string;
export type Enabled = boolean;
export type RoleArn = string;
export interface MetricsConfiguration {
    cloudMetricEnabled?: boolean | undefined;
    metricRuleRoleArn?: string | undefined;
}
export interface CreateSystemInstanceRequest {
    tags?: Tag[] | undefined;
    definition: DefinitionDocument;
    target: DeploymentTarget;
    greengrassGroupName?: string | undefined;
    s3BucketName?: string | undefined;
    metricsConfiguration?: MetricsConfiguration | undefined;
    flowActionsRoleArn?: string | undefined;
}
export type SystemInstanceDeploymentStatus = "NOT_DEPLOYED" | "BOOTSTRAP" | "DEPLOY_IN_PROGRESS" | "DEPLOYED_IN_TARGET" | "UNDEPLOY_IN_PROGRESS" | "FAILED" | "PENDING_DELETE" | "DELETED_IN_TARGET" | (string & {});
export type GreengrassGroupId = string;
export type GreengrassGroupVersionId = string;
export interface SystemInstanceSummary {
    id?: string | undefined;
    arn?: string | undefined;
    status?: SystemInstanceDeploymentStatus | undefined;
    target?: DeploymentTarget | undefined;
    greengrassGroupName?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    greengrassGroupId?: string | undefined;
    greengrassGroupVersionId?: string | undefined;
}
export interface CreateSystemInstanceResponse {
    summary?: SystemInstanceSummary | undefined;
}
export interface CreateSystemTemplateRequest {
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number | undefined;
}
export interface SystemTemplateSummary {
    id?: string | undefined;
    arn?: string | undefined;
    revisionNumber?: number | undefined;
    createdAt?: Date | undefined;
}
export interface CreateSystemTemplateResponse {
    summary?: SystemTemplateSummary | undefined;
}
export interface DeleteFlowTemplateRequest {
    id: string;
}
export interface DeleteFlowTemplateResponse {
}
export interface DeleteNamespaceRequest {
}
export type NamespaceName = string;
export interface DeleteNamespaceResponse {
    namespaceArn?: string | undefined;
    namespaceName?: string | undefined;
}
export interface DeleteSystemInstanceRequest {
    id?: string | undefined;
}
export interface DeleteSystemInstanceResponse {
}
export interface DeleteSystemTemplateRequest {
    id: string;
}
export interface DeleteSystemTemplateResponse {
}
export interface DeploySystemInstanceRequest {
    id?: string | undefined;
}
export type GreengrassDeploymentId = string;
export interface DeploySystemInstanceResponse {
    summary: SystemInstanceSummary;
    greengrassDeploymentId?: string | undefined;
}
export interface DeprecateFlowTemplateRequest {
    id: string;
}
export interface DeprecateFlowTemplateResponse {
}
export interface DeprecateSystemTemplateRequest {
    id: string;
}
export interface DeprecateSystemTemplateResponse {
}
export interface DescribeNamespaceRequest {
    namespaceName?: string | undefined;
}
export interface DescribeNamespaceResponse {
    namespaceArn?: string | undefined;
    namespaceName?: string | undefined;
    trackingNamespaceName?: string | undefined;
    trackingNamespaceVersion?: number | undefined;
    namespaceVersion?: number | undefined;
}
export type EntityType = "DEVICE" | "SERVICE" | "DEVICE_MODEL" | "CAPABILITY" | "STATE" | "ACTION" | "EVENT" | "PROPERTY" | "MAPPING" | "ENUM" | (string & {});
export interface DissociateEntityFromThingRequest {
    thingName: string;
    entityType: EntityType;
}
export interface DissociateEntityFromThingResponse {
}
export type Urns = string[];
export interface GetEntitiesRequest {
    ids: string[];
    namespaceVersion?: number | undefined;
}
export interface EntityDescription {
    id?: string | undefined;
    arn?: string | undefined;
    type?: EntityType | undefined;
    createdAt?: Date | undefined;
    definition?: DefinitionDocument | undefined;
}
export type EntityDescriptions = EntityDescription[];
export interface GetEntitiesResponse {
    descriptions?: EntityDescription[] | undefined;
}
export interface GetFlowTemplateRequest {
    id: string;
    revisionNumber?: number | undefined;
}
export interface FlowTemplateDescription {
    summary?: FlowTemplateSummary | undefined;
    definition?: DefinitionDocument | undefined;
    validatedNamespaceVersion?: number | undefined;
}
export interface GetFlowTemplateResponse {
    description?: FlowTemplateDescription | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface GetFlowTemplateRevisionsRequest {
    id: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type FlowTemplateSummaries = FlowTemplateSummary[];
export interface GetFlowTemplateRevisionsResponse {
    summaries?: FlowTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface GetNamespaceDeletionStatusRequest {
}
export type NamespaceDeletionStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type NamespaceDeletionStatusErrorCodes = "VALIDATION_FAILED" | (string & {});
export interface GetNamespaceDeletionStatusResponse {
    namespaceArn?: string | undefined;
    namespaceName?: string | undefined;
    status?: NamespaceDeletionStatus | undefined;
    errorCode?: NamespaceDeletionStatusErrorCodes | undefined;
    errorMessage?: string | undefined;
}
export interface GetSystemInstanceRequest {
    id: string;
}
export interface DependencyRevision {
    id?: string | undefined;
    revisionNumber?: number | undefined;
}
export type DependencyRevisions = DependencyRevision[];
export interface SystemInstanceDescription {
    summary?: SystemInstanceSummary | undefined;
    definition?: DefinitionDocument | undefined;
    s3BucketName?: string | undefined;
    metricsConfiguration?: MetricsConfiguration | undefined;
    validatedNamespaceVersion?: number | undefined;
    validatedDependencyRevisions?: DependencyRevision[] | undefined;
    flowActionsRoleArn?: string | undefined;
}
export interface GetSystemInstanceResponse {
    description?: SystemInstanceDescription | undefined;
}
export interface GetSystemTemplateRequest {
    id: string;
    revisionNumber?: number | undefined;
}
export interface SystemTemplateDescription {
    summary?: SystemTemplateSummary | undefined;
    definition?: DefinitionDocument | undefined;
    validatedNamespaceVersion?: number | undefined;
}
export interface GetSystemTemplateResponse {
    description?: SystemTemplateDescription | undefined;
}
export interface GetSystemTemplateRevisionsRequest {
    id: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SystemTemplateSummaries = SystemTemplateSummary[];
export interface GetSystemTemplateRevisionsResponse {
    summaries?: SystemTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export type UploadId = string;
export interface GetUploadStatusRequest {
    uploadId: string;
}
export type UploadStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type StringList = string[];
export interface GetUploadStatusResponse {
    uploadId: string;
    uploadStatus: UploadStatus;
    namespaceArn?: string | undefined;
    namespaceName?: string | undefined;
    namespaceVersion?: number | undefined;
    failureReason?: string[] | undefined;
    createdDate: Date;
}
export type FlowExecutionId = string;
export interface ListFlowExecutionMessagesRequest {
    flowExecutionId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type FlowExecutionMessageId = string;
export type FlowExecutionEventType = "EXECUTION_STARTED" | "EXECUTION_FAILED" | "EXECUTION_ABORTED" | "EXECUTION_SUCCEEDED" | "STEP_STARTED" | "STEP_FAILED" | "STEP_SUCCEEDED" | "ACTIVITY_SCHEDULED" | "ACTIVITY_STARTED" | "ACTIVITY_FAILED" | "ACTIVITY_SUCCEEDED" | "START_FLOW_EXECUTION_TASK" | "SCHEDULE_NEXT_READY_STEPS_TASK" | "THING_ACTION_TASK" | "THING_ACTION_TASK_FAILED" | "THING_ACTION_TASK_SUCCEEDED" | "ACKNOWLEDGE_TASK_MESSAGE" | (string & {});
export type FlowExecutionMessagePayload = string;
export interface FlowExecutionMessage {
    messageId?: string | undefined;
    eventType?: FlowExecutionEventType | undefined;
    timestamp?: Date | undefined;
    payload?: string | undefined;
}
export type FlowExecutionMessages = FlowExecutionMessage[];
export interface ListFlowExecutionMessagesResponse {
    messages?: FlowExecutionMessage[] | undefined;
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    maxResults?: number | undefined;
    resourceArn: string;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
    nextToken?: string | undefined;
}
export type EntityTypes = EntityType[];
export type EntityFilterName = "NAME" | "NAMESPACE" | "SEMANTIC_TYPE_PATH" | "REFERENCED_ENTITY_ID" | (string & {});
export type EntityFilterValue = string;
export type EntityFilterValues = string[];
export interface EntityFilter {
    name?: EntityFilterName | undefined;
    value?: string[] | undefined;
}
export type EntityFilters = EntityFilter[];
export interface SearchEntitiesRequest {
    entityTypes: EntityType[];
    filters?: EntityFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    namespaceVersion?: number | undefined;
}
export interface SearchEntitiesResponse {
    descriptions?: EntityDescription[] | undefined;
    nextToken?: string | undefined;
}
export interface SearchFlowExecutionsRequest {
    systemInstanceId: string;
    flowExecutionId?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type FlowExecutionStatus = "RUNNING" | "ABORTED" | "SUCCEEDED" | "FAILED" | (string & {});
export interface FlowExecutionSummary {
    flowExecutionId?: string | undefined;
    status?: FlowExecutionStatus | undefined;
    systemInstanceId?: string | undefined;
    flowTemplateId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type FlowExecutionSummaries = FlowExecutionSummary[];
export interface SearchFlowExecutionsResponse {
    summaries?: FlowExecutionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type FlowTemplateFilterName = "DEVICE_MODEL_ID" | (string & {});
export type FlowTemplateFilterValue = string;
export type FlowTemplateFilterValues = string[];
export interface FlowTemplateFilter {
    name: FlowTemplateFilterName;
    value: string[];
}
export type FlowTemplateFilters = FlowTemplateFilter[];
export interface SearchFlowTemplatesRequest {
    filters?: FlowTemplateFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SearchFlowTemplatesResponse {
    summaries?: FlowTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SystemInstanceFilterName = "SYSTEM_TEMPLATE_ID" | "STATUS" | "GREENGRASS_GROUP_NAME" | (string & {});
export type SystemInstanceFilterValue = string;
export type SystemInstanceFilterValues = string[];
export interface SystemInstanceFilter {
    name?: SystemInstanceFilterName | undefined;
    value?: string[] | undefined;
}
export type SystemInstanceFilters = SystemInstanceFilter[];
export interface SearchSystemInstancesRequest {
    filters?: SystemInstanceFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SystemInstanceSummaries = SystemInstanceSummary[];
export interface SearchSystemInstancesResponse {
    summaries?: SystemInstanceSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SystemTemplateFilterName = "FLOW_TEMPLATE_ID" | (string & {});
export type SystemTemplateFilterValue = string;
export type SystemTemplateFilterValues = string[];
export interface SystemTemplateFilter {
    name: SystemTemplateFilterName;
    value: string[];
}
export type SystemTemplateFilters = SystemTemplateFilter[];
export interface SearchSystemTemplatesRequest {
    filters?: SystemTemplateFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SearchSystemTemplatesResponse {
    summaries?: SystemTemplateSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface SearchThingsRequest {
    entityId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    namespaceVersion?: number | undefined;
}
export type ThingArn = string;
export interface Thing {
    thingArn?: string | undefined;
    thingName?: string | undefined;
}
export type Things = Thing[];
export interface SearchThingsResponse {
    things?: Thing[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export interface UndeploySystemInstanceRequest {
    id?: string | undefined;
}
export interface UndeploySystemInstanceResponse {
    summary?: SystemInstanceSummary | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateFlowTemplateRequest {
    id: string;
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number | undefined;
}
export interface UpdateFlowTemplateResponse {
    summary?: FlowTemplateSummary | undefined;
}
export interface UpdateSystemTemplateRequest {
    id: string;
    definition: DefinitionDocument;
    compatibleNamespaceVersion?: number | undefined;
}
export interface UpdateSystemTemplateResponse {
    summary?: SystemTemplateSummary | undefined;
}
export type SyncWithPublicNamespace = boolean;
export type DeprecateExistingEntities = boolean;
export interface UploadEntityDefinitionsRequest {
    document?: DefinitionDocument | undefined;
    syncWithPublicNamespace?: boolean | undefined;
    deprecateExistingEntities?: boolean | undefined;
}
export interface UploadEntityDefinitionsResponse {
    uploadId: string;
}
export type ErrorMessage = string;
export type AssociateEntityToThingError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a device with a concrete thing that is in the user's registry.
 *
 * A thing can be associated with only one device at a time. If you associate a thing with a new device id, its previous association will be removed.
 */
export declare const associateEntityToThing: API.OperationMethod<AssociateEntityToThingRequest & RegionInput, AssociateEntityToThingResponse, AssociateEntityToThingError, Credentials | HttpClient.HttpClient>;
export type CreateFlowTemplateError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a workflow template. Workflows can be created only in the user's namespace. (The public namespace contains only
 * entities.) The workflow can contain only entities in the specified namespace. The workflow is validated against the entities in the
 * latest version of the user's namespace unless another namespace version is specified in the request.
 */
export declare const createFlowTemplate: API.OperationMethod<CreateFlowTemplateRequest & RegionInput, CreateFlowTemplateResponse, CreateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateSystemInstanceError = InternalFailureException | InvalidRequestException | LimitExceededException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a system instance.
 *
 * This action validates the system instance, prepares the deployment-related resources. For Greengrass deployments, it updates the Greengrass group that is
 * specified by the `greengrassGroupName` parameter. It also adds a file to the S3 bucket specified by the `s3BucketName` parameter. You need to
 * call `DeploySystemInstance` after running this action.
 *
 * For Greengrass deployments, since this action modifies and adds resources to a Greengrass group and an S3 bucket on the caller's behalf, the calling identity must have write permissions
 * to both the specified Greengrass group and S3 bucket. Otherwise, the call will fail with an authorization error.
 *
 * For cloud deployments, this action requires a `flowActionsRoleArn` value. This is an IAM role
 * that has permissions to access AWS services, such as AWS Lambda and AWS IoT, that the flow uses when it executes.
 *
 * If the definition document doesn't specify a version of the user's namespace, the latest version will be used by default.
 */
export declare const createSystemInstance: API.OperationMethod<CreateSystemInstanceRequest & RegionInput, CreateSystemInstanceResponse, CreateSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a system. The system is validated against the entities in the
 * latest version of the user's namespace unless another namespace version is specified in the request.
 */
export declare const createSystemTemplate: API.OperationMethod<CreateSystemTemplateRequest & RegionInput, CreateSystemTemplateResponse, CreateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a workflow. Any new system or deployment that contains this workflow will fail to update or deploy.
 * Existing deployments that contain the workflow will continue to run (since they use a snapshot of the workflow taken at the time of deployment).
 */
export declare const deleteFlowTemplate: API.OperationMethod<DeleteFlowTemplateRequest & RegionInput, DeleteFlowTemplateResponse, DeleteFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = InternalFailureException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified namespace. This action deletes all of the entities in the namespace. Delete the systems and flows that use entities in the namespace before performing this action. This action takes no
 * request parameters.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest & RegionInput, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a system instance.
 * Only system instances that have never been deployed, or that have been undeployed can be deleted.
 *
 * Users can create a new system instance that has the same ID as a deleted system instance.
 */
export declare const deleteSystemInstance: API.OperationMethod<DeleteSystemInstanceRequest & RegionInput, DeleteSystemInstanceResponse, DeleteSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a system. New deployments can't contain the system after its deletion.
 * Existing deployments that contain the system will continue to work because they use a snapshot of the system that is taken when it is deployed.
 */
export declare const deleteSystemTemplate: API.OperationMethod<DeleteSystemTemplateRequest & RegionInput, DeleteSystemTemplateResponse, DeleteSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DeploySystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * **Greengrass and Cloud Deployments**
 *
 * Deploys the system instance to the target specified in `CreateSystemInstance`.
 *
 * **Greengrass Deployments**
 *
 * If the system or any workflows and entities have been updated before this action is called, then the deployment will create a new Amazon Simple Storage Service
 * resource file and then deploy it.
 *
 * Since this action creates a Greengrass deployment on the caller's behalf, the calling identity must have write permissions
 * to the specified Greengrass group. Otherwise, the call will fail with an authorization error.
 *
 * For information about the artifacts that get added to your Greengrass core device when you use this API, see AWS IoT Things Graph and AWS IoT Greengrass.
 */
export declare const deploySystemInstance: API.OperationMethod<DeploySystemInstanceRequest & RegionInput, DeploySystemInstanceResponse, DeploySystemInstanceError, Credentials | HttpClient.HttpClient>;
export type DeprecateFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deprecates the specified workflow. This action marks the workflow for deletion. Deprecated flows can't be deployed, but existing deployments will continue to run.
 */
export declare const deprecateFlowTemplate: API.OperationMethod<DeprecateFlowTemplateRequest & RegionInput, DeprecateFlowTemplateResponse, DeprecateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type DeprecateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deprecates the specified system.
 */
export declare const deprecateSystemTemplate: API.OperationMethod<DeprecateSystemTemplateRequest & RegionInput, DeprecateSystemTemplateResponse, DeprecateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeNamespaceError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the latest version of the user's namespace and the public version that it is tracking.
 */
export declare const describeNamespace: API.OperationMethod<DescribeNamespaceRequest & RegionInput, DescribeNamespaceResponse, DescribeNamespaceError, Credentials | HttpClient.HttpClient>;
export type DissociateEntityFromThingError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Dissociates a device entity from a concrete thing. The action takes only the type of the entity that you need to dissociate because only
 * one entity of a particular type can be associated with a thing.
 */
export declare const dissociateEntityFromThing: API.OperationMethod<DissociateEntityFromThingRequest & RegionInput, DissociateEntityFromThingResponse, DissociateEntityFromThingError, Credentials | HttpClient.HttpClient>;
export type GetEntitiesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets definitions of the specified entities. Uses the latest version of the user's namespace by default. This API returns the
 * following TDM entities.
 *
 * - Properties
 *
 * - States
 *
 * - Events
 *
 * - Actions
 *
 * - Capabilities
 *
 * - Mappings
 *
 * - Devices
 *
 * - Device Models
 *
 * - Services
 *
 * This action doesn't return definitions for systems, flows, and deployments.
 */
export declare const getEntities: API.OperationMethod<GetEntitiesRequest & RegionInput, GetEntitiesResponse, GetEntitiesError, Credentials | HttpClient.HttpClient>;
export type GetFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the latest version of the `DefinitionDocument` and `FlowTemplateSummary` for the specified workflow.
 */
export declare const getFlowTemplate: API.OperationMethod<GetFlowTemplateRequest & RegionInput, GetFlowTemplateResponse, GetFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type GetFlowTemplateRevisionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets revisions of the specified workflow. Only the last 100 revisions are stored. If the workflow has been deprecated,
 * this action will return revisions that occurred before the deprecation. This action won't work for workflows that have been deleted.
 */
export declare const getFlowTemplateRevisions: API.PaginatedOperationMethod<GetFlowTemplateRevisionsRequest & RegionInput, GetFlowTemplateRevisionsResponse, GetFlowTemplateRevisionsError, Credentials | HttpClient.HttpClient, FlowTemplateSummary>;
export type GetNamespaceDeletionStatusError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Gets the status of a namespace deletion task.
 */
export declare const getNamespaceDeletionStatus: API.OperationMethod<GetNamespaceDeletionStatusRequest & RegionInput, GetNamespaceDeletionStatusResponse, GetNamespaceDeletionStatusError, Credentials | HttpClient.HttpClient>;
export type GetSystemInstanceError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets a system instance.
 */
export declare const getSystemInstance: API.OperationMethod<GetSystemInstanceRequest & RegionInput, GetSystemInstanceResponse, GetSystemInstanceError, Credentials | HttpClient.HttpClient>;
export type GetSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets a system.
 */
export declare const getSystemTemplate: API.OperationMethod<GetSystemTemplateRequest & RegionInput, GetSystemTemplateResponse, GetSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type GetSystemTemplateRevisionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets revisions made to the specified system template. Only the previous 100 revisions are stored. If the system has been deprecated, this action will return
 * the revisions that occurred before its deprecation. This action won't work with systems that have been deleted.
 */
export declare const getSystemTemplateRevisions: API.PaginatedOperationMethod<GetSystemTemplateRevisionsRequest & RegionInput, GetSystemTemplateRevisionsResponse, GetSystemTemplateRevisionsError, Credentials | HttpClient.HttpClient, SystemTemplateSummary>;
export type GetUploadStatusError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the status of the specified upload.
 */
export declare const getUploadStatus: API.OperationMethod<GetUploadStatusRequest & RegionInput, GetUploadStatusResponse, GetUploadStatusError, Credentials | HttpClient.HttpClient>;
export type ListFlowExecutionMessagesError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of objects that contain information about events in a flow execution.
 */
export declare const listFlowExecutionMessages: API.PaginatedOperationMethod<ListFlowExecutionMessagesRequest & RegionInput, ListFlowExecutionMessagesResponse, ListFlowExecutionMessagesError, Credentials | HttpClient.HttpClient, FlowExecutionMessage>;
export type ListTagsForResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Lists all tags on an AWS IoT Things Graph resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type SearchEntitiesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for entities of the specified type. You can search for entities in your namespace and the public namespace that you're tracking.
 */
export declare const searchEntities: API.PaginatedOperationMethod<SearchEntitiesRequest & RegionInput, SearchEntitiesResponse, SearchEntitiesError, Credentials | HttpClient.HttpClient, EntityDescription>;
export type SearchFlowExecutionsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for AWS IoT Things Graph workflow execution instances.
 */
export declare const searchFlowExecutions: API.PaginatedOperationMethod<SearchFlowExecutionsRequest & RegionInput, SearchFlowExecutionsResponse, SearchFlowExecutionsError, Credentials | HttpClient.HttpClient, FlowExecutionSummary>;
export type SearchFlowTemplatesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for summary information about workflows.
 */
export declare const searchFlowTemplates: API.PaginatedOperationMethod<SearchFlowTemplatesRequest & RegionInput, SearchFlowTemplatesResponse, SearchFlowTemplatesError, Credentials | HttpClient.HttpClient, FlowTemplateSummary>;
export type SearchSystemInstancesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for system instances in the user's account.
 */
export declare const searchSystemInstances: API.PaginatedOperationMethod<SearchSystemInstancesRequest & RegionInput, SearchSystemInstancesResponse, SearchSystemInstancesError, Credentials | HttpClient.HttpClient, SystemInstanceSummary>;
export type SearchSystemTemplatesError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for summary information about systems in the user's account. You can filter by the ID of a workflow to return only systems that use the specified workflow.
 */
export declare const searchSystemTemplates: API.PaginatedOperationMethod<SearchSystemTemplatesRequest & RegionInput, SearchSystemTemplatesResponse, SearchSystemTemplatesError, Credentials | HttpClient.HttpClient, SystemTemplateSummary>;
export type SearchThingsError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for things associated with the specified entity. You can search by both device and device model.
 *
 * For example, if two different devices, camera1 and camera2, implement the camera device model, the user can associate thing1 to camera1 and thing2 to camera2.
 * `SearchThings(camera2)` will return only thing2, but `SearchThings(camera)` will return both thing1 and thing2.
 *
 * This action searches for exact matches and doesn't perform partial text matching.
 */
export declare const searchThings: API.PaginatedOperationMethod<SearchThingsRequest & RegionInput, SearchThingsResponse, SearchThingsError, Credentials | HttpClient.HttpClient, Thing>;
export type TagResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a tag for the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UndeploySystemInstanceError = InternalFailureException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a system instance from its target (Cloud or Greengrass).
 */
export declare const undeploySystemInstance: API.OperationMethod<UndeploySystemInstanceRequest & RegionInput, UndeploySystemInstanceResponse, UndeploySystemInstanceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalFailureException | InvalidRequestException | ResourceAlreadyExistsException | ThrottlingException | CommonErrors;
/**
 * Removes a tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified workflow. All deployed systems and system instances that use the workflow will see the changes in the flow when it is redeployed. If you don't want this
 * behavior, copy the workflow (creating a new workflow with a different ID), and update the copy. The workflow can contain only entities in the specified namespace.
 */
export declare const updateFlowTemplate: API.OperationMethod<UpdateFlowTemplateRequest & RegionInput, UpdateFlowTemplateResponse, UpdateFlowTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateSystemTemplateError = InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified system. You don't need to run this action after updating a workflow. Any deployment that uses the system will see the changes in the system when it is redeployed.
 */
export declare const updateSystemTemplate: API.OperationMethod<UpdateSystemTemplateRequest & RegionInput, UpdateSystemTemplateResponse, UpdateSystemTemplateError, Credentials | HttpClient.HttpClient>;
export type UploadEntityDefinitionsError = InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Asynchronously uploads one or more entity definitions to the user's namespace. The `document` parameter is required if
 * `syncWithPublicNamespace` and `deleteExistingEntites` are false. If the `syncWithPublicNamespace` parameter is set to
 * `true`, the user's namespace will synchronize with the latest version of the public namespace. If `deprecateExistingEntities` is set to true,
 * all entities in the latest version will be deleted before the new `DefinitionDocument` is uploaded.
 *
 * When a user uploads entity definitions for the first time, the service creates a new namespace for the user. The new namespace tracks the public namespace. Currently users
 * can have only one namespace. The namespace version increments whenever a user uploads entity definitions that are backwards-incompatible and whenever a user sets the
 * `syncWithPublicNamespace` parameter or the `deprecateExistingEntities` parameter to `true`.
 *
 * The IDs for all of the entities should be in URN format. Each entity must be in the user's namespace. Users can't create entities in the public namespace, but entity definitions can refer to entities in the public namespace.
 *
 * Valid entities are `Device`, `DeviceModel`, `Service`, `Capability`, `State`, `Action`, `Event`, `Property`,
 * `Mapping`, `Enum`.
 */
export declare const uploadEntityDefinitions: API.OperationMethod<UploadEntityDefinitionsRequest & RegionInput, UploadEntityDefinitionsResponse, UploadEntityDefinitionsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotthingsgraph.d.ts.map