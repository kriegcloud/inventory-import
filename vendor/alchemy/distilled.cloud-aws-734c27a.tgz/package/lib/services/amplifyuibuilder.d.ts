import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type ComponentName = string;
export type ComponentType = string;
export interface ComponentPropertyBindingProperties {
    property: string;
    field?: string | undefined;
}
export interface FormBindingElement {
    element: string;
    property: string;
}
export type FormBindings = {
    [key: string]: FormBindingElement | undefined;
};
export type ComponentPropertyList = ComponentProperty[];
export interface ComponentConditionProperty {
    property?: string | undefined;
    field?: string | undefined;
    operator?: string | undefined;
    operand?: string | undefined;
    then?: ComponentProperty | undefined;
    else?: ComponentProperty | undefined;
    operandType?: string | undefined;
}
export interface ComponentProperty {
    value?: string | undefined;
    bindingProperties?: ComponentPropertyBindingProperties | undefined;
    collectionBindingProperties?: ComponentPropertyBindingProperties | undefined;
    defaultValue?: string | undefined;
    model?: string | undefined;
    bindings?: {
        [key: string]: FormBindingElement | undefined;
    } | undefined;
    event?: string | undefined;
    userAttribute?: string | undefined;
    concat?: ComponentProperty[] | undefined;
    condition?: ComponentConditionProperty | undefined;
    configured?: boolean | undefined;
    type?: string | undefined;
    importedValue?: string | undefined;
    componentName?: string | undefined;
    property?: string | undefined;
}
export type ComponentProperties = {
    [key: string]: ComponentProperty | undefined;
};
export interface MutationActionSetStateParameter {
    componentName: string;
    property: string;
    set: ComponentProperty;
}
export interface ActionParameters {
    type?: ComponentProperty | undefined;
    url?: ComponentProperty | undefined;
    anchor?: ComponentProperty | undefined;
    target?: ComponentProperty | undefined;
    global?: ComponentProperty | undefined;
    model?: string | undefined;
    id?: ComponentProperty | undefined;
    fields?: {
        [key: string]: ComponentProperty | undefined;
    } | undefined;
    state?: MutationActionSetStateParameter | undefined;
}
export interface ComponentEvent {
    action?: string | undefined;
    parameters?: ActionParameters | undefined;
    bindingEvent?: string | undefined;
}
export type ComponentEvents = {
    [key: string]: ComponentEvent | undefined;
};
export interface ComponentChild {
    componentType: string;
    name: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[] | undefined;
    events?: {
        [key: string]: ComponentEvent | undefined;
    } | undefined;
    sourceId?: string | undefined;
}
export type ComponentChildList = ComponentChild[];
export type ComponentVariantValues = {
    [key: string]: string | undefined;
};
export type ComponentOverridesValue = {
    [key: string]: string | undefined;
};
export type ComponentOverrides = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export interface ComponentVariant {
    variantValues?: {
        [key: string]: string | undefined;
    } | undefined;
    overrides?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
}
export type ComponentVariants = ComponentVariant[];
export type OperandType = string;
export interface Predicate {
    or?: Predicate[] | undefined;
    and?: Predicate[] | undefined;
    field?: string | undefined;
    operator?: string | undefined;
    operand?: string | undefined;
    operandType?: string | undefined;
}
export type PredicateList = Predicate[];
export interface ComponentBindingPropertiesValueProperties {
    model?: string | undefined;
    field?: string | undefined;
    predicates?: Predicate[] | undefined;
    userAttribute?: string | undefined;
    bucket?: string | undefined;
    key?: string | undefined;
    defaultValue?: string | undefined;
    slotName?: string | undefined;
}
export interface ComponentBindingPropertiesValue {
    type?: string | undefined;
    bindingProperties?: ComponentBindingPropertiesValueProperties | undefined;
    defaultValue?: string | undefined;
}
export type ComponentBindingProperties = {
    [key: string]: ComponentBindingPropertiesValue | undefined;
};
export type SortDirection = "ASC" | "DESC" | (string & {});
export interface SortProperty {
    field: string;
    direction: SortDirection;
}
export type SortPropertyList = SortProperty[];
export type IdentifierList = string[];
export interface ComponentDataConfiguration {
    model: string;
    sort?: SortProperty[] | undefined;
    predicate?: Predicate | undefined;
    identifiers?: string[] | undefined;
}
export type ComponentCollectionProperties = {
    [key: string]: ComponentDataConfiguration | undefined;
};
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateComponentData {
    name: string;
    sourceId?: string | undefined;
    componentType: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[] | undefined;
    variants: ComponentVariant[];
    overrides: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    bindingProperties: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    };
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    events?: {
        [key: string]: ComponentEvent | undefined;
    } | undefined;
    schemaVersion?: string | undefined;
}
export interface CreateComponentRequest {
    appId: string;
    environmentName: string;
    clientToken?: string | undefined;
    componentToCreate: CreateComponentData;
}
export type Uuid = string;
export interface Component {
    appId: string;
    environmentName: string;
    sourceId?: string | undefined;
    id: string;
    name: string;
    componentType: string;
    properties: {
        [key: string]: ComponentProperty | undefined;
    };
    children?: ComponentChild[] | undefined;
    variants: ComponentVariant[];
    overrides: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
    bindingProperties: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    };
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    } | undefined;
    createdAt: Date;
    modifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    events?: {
        [key: string]: ComponentEvent | undefined;
    } | undefined;
    schemaVersion?: string | undefined;
}
export interface CreateComponentResponse {
    entity?: Component | undefined;
}
export type FormName = string;
export type FormDataSourceType = string;
export interface FormDataTypeConfig {
    dataSourceType: string;
    dataTypeName: string;
}
export type FormActionType = "create" | "update" | (string & {});
export type FixedPosition = "first" | (string & {});
export type FieldPosition = {
    fixed: FixedPosition;
    rightOf?: undefined;
    below?: undefined;
} | {
    fixed?: undefined;
    rightOf: string;
    below?: undefined;
} | {
    fixed?: undefined;
    rightOf?: undefined;
    below: string;
};
export interface FormInputValuePropertyBindingProperties {
    property: string;
    field?: string | undefined;
}
export type FormInputValuePropertyList = FormInputValueProperty[];
export interface FormInputValueProperty {
    value?: string | undefined;
    bindingProperties?: FormInputValuePropertyBindingProperties | undefined;
    concat?: FormInputValueProperty[] | undefined;
}
export interface ValueMapping {
    displayValue?: FormInputValueProperty | undefined;
    value: FormInputValueProperty;
}
export type ValueMappingList = ValueMapping[];
export interface FormInputBindingPropertiesValueProperties {
    model?: string | undefined;
}
export interface FormInputBindingPropertiesValue {
    type?: string | undefined;
    bindingProperties?: FormInputBindingPropertiesValueProperties | undefined;
}
export type FormInputBindingProperties = {
    [key: string]: FormInputBindingPropertiesValue | undefined;
};
export interface ValueMappings {
    values: ValueMapping[];
    bindingProperties?: {
        [key: string]: FormInputBindingPropertiesValue | undefined;
    } | undefined;
}
export type StorageAccessLevel = "public" | "protected" | "private" | (string & {});
export type StrValues = string[];
export interface FileUploaderFieldConfig {
    accessLevel: StorageAccessLevel;
    acceptedFileTypes: string[];
    showThumbnails?: boolean | undefined;
    isResumable?: boolean | undefined;
    maxFileCount?: number | undefined;
    maxSize?: number | undefined;
}
export interface FieldInputConfig {
    type: string;
    required?: boolean | undefined;
    readOnly?: boolean | undefined;
    placeholder?: string | undefined;
    defaultValue?: string | undefined;
    descriptiveText?: string | undefined;
    defaultChecked?: boolean | undefined;
    defaultCountryCode?: string | undefined;
    valueMappings?: ValueMappings | undefined;
    name?: string | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
    step?: number | undefined;
    value?: string | undefined;
    isArray?: boolean | undefined;
    fileUploaderConfig?: FileUploaderFieldConfig | undefined;
}
export type NumValues = number[];
export interface FieldValidationConfiguration {
    type: string;
    strValues?: string[] | undefined;
    numValues?: number[] | undefined;
    validationMessage?: string | undefined;
}
export type ValidationsList = FieldValidationConfiguration[];
export interface FieldConfig {
    label?: string | undefined;
    position?: FieldPosition | undefined;
    excluded?: boolean | undefined;
    inputType?: FieldInputConfig | undefined;
    validations?: FieldValidationConfiguration[] | undefined;
}
export type FieldsMap = {
    [key: string]: FieldConfig | undefined;
};
export type FormStyleConfig = {
    tokenReference: string;
    value?: undefined;
} | {
    tokenReference?: undefined;
    value: string;
};
export interface FormStyle {
    horizontalGap?: FormStyleConfig | undefined;
    verticalGap?: FormStyleConfig | undefined;
    outerPadding?: FormStyleConfig | undefined;
}
export interface SectionalElement {
    type: string;
    position?: FieldPosition | undefined;
    text?: string | undefined;
    level?: number | undefined;
    orientation?: string | undefined;
    excluded?: boolean | undefined;
}
export type SectionalElementMap = {
    [key: string]: SectionalElement | undefined;
};
export type FormButtonsPosition = "top" | "bottom" | "top_and_bottom" | (string & {});
export interface FormButton {
    excluded?: boolean | undefined;
    children?: string | undefined;
    position?: FieldPosition | undefined;
}
export interface FormCTA {
    position?: FormButtonsPosition | undefined;
    clear?: FormButton | undefined;
    cancel?: FormButton | undefined;
    submit?: FormButton | undefined;
}
export type LabelDecorator = string;
export interface CreateFormData {
    name: string;
    dataType: FormDataTypeConfig;
    formActionType: FormActionType;
    fields: {
        [key: string]: FieldConfig | undefined;
    };
    style: FormStyle;
    sectionalElements: {
        [key: string]: SectionalElement | undefined;
    };
    schemaVersion: string;
    cta?: FormCTA | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    labelDecorator?: string | undefined;
}
export interface CreateFormRequest {
    appId: string;
    environmentName: string;
    clientToken?: string | undefined;
    formToCreate: CreateFormData;
}
export interface Form {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    formActionType: FormActionType;
    style: FormStyle;
    dataType: FormDataTypeConfig;
    fields: {
        [key: string]: FieldConfig | undefined;
    };
    sectionalElements: {
        [key: string]: SectionalElement | undefined;
    };
    schemaVersion: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    cta?: FormCTA | undefined;
    labelDecorator?: string | undefined;
}
export interface CreateFormResponse {
    entity?: Form | undefined;
}
export type ThemeName = string;
export interface ThemeValue {
    value?: string | undefined;
    children?: ThemeValues[] | undefined;
}
export interface ThemeValues {
    key?: string | undefined;
    value?: ThemeValue | undefined;
}
export type ThemeValuesList = ThemeValues[];
export interface CreateThemeData {
    name: string;
    values: ThemeValues[];
    overrides?: ThemeValues[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateThemeRequest {
    appId: string;
    environmentName: string;
    clientToken?: string | undefined;
    themeToCreate: CreateThemeData;
}
export interface Theme {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    createdAt: Date;
    modifiedAt?: Date | undefined;
    values: ThemeValues[];
    overrides?: ThemeValues[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateThemeResponse {
    entity?: Theme | undefined;
}
export interface DeleteComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface DeleteComponentResponse {
}
export interface DeleteFormRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface DeleteFormResponse {
}
export interface DeleteThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface DeleteThemeResponse {
}
export type TokenProviders = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface ExchangeCodeForTokenRequestBody {
    code: string | redacted.Redacted<string>;
    redirectUri: string;
    clientId?: string | redacted.Redacted<string> | undefined;
}
export interface ExchangeCodeForTokenRequest {
    provider: string;
    request: ExchangeCodeForTokenRequestBody;
}
export interface ExchangeCodeForTokenResponse {
    accessToken: string | redacted.Redacted<string>;
    expiresIn: number;
    refreshToken: string | redacted.Redacted<string>;
}
export interface ExportComponentsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
}
export type ComponentList = Component[];
export interface ExportComponentsResponse {
    entities: Component[];
    nextToken?: string | undefined;
}
export interface ExportFormsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
}
export type FormList = Form[];
export interface ExportFormsResponse {
    entities: Form[];
    nextToken?: string | undefined;
}
export interface ExportThemesRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
}
export type ThemeList = Theme[];
export interface ExportThemesResponse {
    entities: Theme[];
    nextToken?: string | undefined;
}
export type AppId = string;
export interface GetCodegenJobRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export type JSModule = "es2020" | "esnext" | (string & {});
export type JSTarget = "es2015" | "es2020" | (string & {});
export type JSScript = "jsx" | "tsx" | "js" | (string & {});
export interface GraphQLRenderConfig {
    typesFilePath: string;
    queriesFilePath: string;
    mutationsFilePath: string;
    subscriptionsFilePath: string;
    fragmentsFilePath: string;
}
export interface DataStoreRenderConfig {
}
export interface NoApiRenderConfig {
}
export type ApiConfiguration = {
    graphQLConfig: GraphQLRenderConfig;
    dataStoreConfig?: undefined;
    noApiConfig?: undefined;
} | {
    graphQLConfig?: undefined;
    dataStoreConfig: DataStoreRenderConfig;
    noApiConfig?: undefined;
} | {
    graphQLConfig?: undefined;
    dataStoreConfig?: undefined;
    noApiConfig: NoApiRenderConfig;
};
export type ReactCodegenDependencies = {
    [key: string]: string | undefined;
};
export interface ReactStartCodegenJobData {
    module?: JSModule | undefined;
    target?: JSTarget | undefined;
    script?: JSScript | undefined;
    renderTypeDeclarations?: boolean | undefined;
    inlineSourceMap?: boolean | undefined;
    apiConfiguration?: ApiConfiguration | undefined;
    dependencies?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CodegenJobRenderConfig = {
    react: ReactStartCodegenJobData;
};
export type CodegenJobGenericDataSourceType = "DataStore" | (string & {});
export type CodegenGenericDataFieldDataType = "ID" | "String" | "Int" | "Float" | "AWSDate" | "AWSTime" | "AWSDateTime" | "AWSTimestamp" | "AWSEmail" | "AWSURL" | "AWSIPAddress" | "Boolean" | "AWSJSON" | "AWSPhone" | "Enum" | "Model" | "NonModel" | (string & {});
export type GenericDataRelationshipType = "HAS_MANY" | "HAS_ONE" | "BELONGS_TO" | (string & {});
export type RelatedModelFieldsList = string[];
export type AssociatedFieldsList = string[];
export interface CodegenGenericDataRelationshipType {
    type: GenericDataRelationshipType;
    relatedModelName: string;
    relatedModelFields?: string[] | undefined;
    canUnlinkAssociatedModel?: boolean | undefined;
    relatedJoinFieldName?: string | undefined;
    relatedJoinTableName?: string | undefined;
    belongsToFieldOnRelatedModel?: string | undefined;
    associatedFields?: string[] | undefined;
    isHasManyIndex?: boolean | undefined;
}
export interface CodegenGenericDataField {
    dataType: CodegenGenericDataFieldDataType;
    dataTypeValue: string;
    required: boolean;
    readOnly: boolean;
    isArray: boolean;
    relationship?: CodegenGenericDataRelationshipType | undefined;
}
export type CodegenGenericDataFields = {
    [key: string]: CodegenGenericDataField | undefined;
};
export type CodegenPrimaryKeysList = string[];
export interface CodegenGenericDataModel {
    fields: {
        [key: string]: CodegenGenericDataField | undefined;
    };
    isJoinTable?: boolean | undefined;
    primaryKeys: string[];
}
export type CodegenGenericDataModels = {
    [key: string]: CodegenGenericDataModel | undefined;
};
export type CodegenGenericDataEnumValuesList = string[];
export interface CodegenGenericDataEnum {
    values: string[];
}
export type CodegenGenericDataEnums = {
    [key: string]: CodegenGenericDataEnum | undefined;
};
export type CodegenGenericDataNonModelFields = {
    [key: string]: CodegenGenericDataField | undefined;
};
export interface CodegenGenericDataNonModel {
    fields: {
        [key: string]: CodegenGenericDataField | undefined;
    };
}
export type CodegenGenericDataNonModels = {
    [key: string]: CodegenGenericDataNonModel | undefined;
};
export interface CodegenJobGenericDataSchema {
    dataSourceType: CodegenJobGenericDataSourceType;
    models: {
        [key: string]: CodegenGenericDataModel | undefined;
    };
    enums: {
        [key: string]: CodegenGenericDataEnum | undefined;
    };
    nonModels: {
        [key: string]: CodegenGenericDataNonModel | undefined;
    };
}
export interface CodegenFeatureFlags {
    isRelationshipSupported?: boolean | undefined;
    isNonModelSupported?: boolean | undefined;
}
export type CodegenJobStatus = "in_progress" | "failed" | "succeeded" | (string & {});
export interface CodegenJobAsset {
    downloadUrl?: string | undefined;
}
export interface CodegenDependency {
    name?: string | undefined;
    supportedVersion?: string | undefined;
    isSemVer?: boolean | undefined;
    reason?: string | undefined;
}
export type CodegenDependencies = CodegenDependency[];
export interface CodegenJob {
    id: string;
    appId: string;
    environmentName: string;
    renderConfig?: CodegenJobRenderConfig | undefined;
    genericDataSchema?: CodegenJobGenericDataSchema | undefined;
    autoGenerateForms?: boolean | undefined;
    features?: CodegenFeatureFlags | undefined;
    status?: CodegenJobStatus | undefined;
    statusMessage?: string | undefined;
    asset?: CodegenJobAsset | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    dependencies?: CodegenDependency[] | undefined;
}
export interface GetCodegenJobResponse {
    job?: CodegenJob | undefined;
}
export interface GetComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface GetComponentResponse {
    component?: Component | undefined;
}
export interface GetFormRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface GetFormResponse {
    form?: Form | undefined;
}
export interface GetMetadataRequest {
    appId: string;
    environmentName: string;
}
export type FeaturesMap = {
    [key: string]: string | undefined;
};
export interface GetMetadataResponse {
    features: {
        [key: string]: string | undefined;
    };
}
export interface GetThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
}
export interface GetThemeResponse {
    theme?: Theme | undefined;
}
export type ListCodegenJobsLimit = number;
export interface ListCodegenJobsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CodegenJobSummary {
    appId: string;
    environmentName: string;
    id: string;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
}
export type CodegenJobSummaryList = CodegenJobSummary[];
export interface ListCodegenJobsResponse {
    entities: CodegenJobSummary[];
    nextToken?: string | undefined;
}
export type ListEntityLimit = number;
export interface ListComponentsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ComponentSummary {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
    componentType: string;
}
export type ComponentSummaryList = ComponentSummary[];
export interface ListComponentsResponse {
    entities: ComponentSummary[];
    nextToken?: string | undefined;
}
export interface ListFormsRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface FormSummary {
    appId: string;
    dataType: FormDataTypeConfig;
    environmentName: string;
    formActionType: FormActionType;
    id: string;
    name: string;
}
export type FormSummaryList = FormSummary[];
export interface ListFormsResponse {
    entities: FormSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export interface ListThemesRequest {
    appId: string;
    environmentName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ThemeSummary {
    appId: string;
    environmentName: string;
    id: string;
    name: string;
}
export type ThemeSummaryList = ThemeSummary[];
export interface ListThemesResponse {
    entities: ThemeSummary[];
    nextToken?: string | undefined;
}
export interface PutMetadataFlagBody {
    newValue: string;
}
export interface PutMetadataFlagRequest {
    appId: string;
    environmentName: string;
    featureName: string;
    body: PutMetadataFlagBody;
}
export interface PutMetadataFlagResponse {
}
export interface RefreshTokenRequestBody {
    token: string | redacted.Redacted<string>;
    clientId?: string | redacted.Redacted<string> | undefined;
}
export interface RefreshTokenRequest {
    provider: string;
    refreshTokenBody: RefreshTokenRequestBody;
}
export interface RefreshTokenResponse {
    accessToken: string | redacted.Redacted<string>;
    expiresIn: number;
}
export interface StartCodegenJobData {
    renderConfig: CodegenJobRenderConfig;
    genericDataSchema?: CodegenJobGenericDataSchema | undefined;
    autoGenerateForms?: boolean | undefined;
    features?: CodegenFeatureFlags | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartCodegenJobRequest {
    appId: string;
    environmentName: string;
    clientToken?: string | undefined;
    codegenJobToCreate: StartCodegenJobData;
}
export interface StartCodegenJobResponse {
    entity?: CodegenJob | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateComponentData {
    id?: string | undefined;
    name?: string | undefined;
    sourceId?: string | undefined;
    componentType?: string | undefined;
    properties?: {
        [key: string]: ComponentProperty | undefined;
    } | undefined;
    children?: ComponentChild[] | undefined;
    variants?: ComponentVariant[] | undefined;
    overrides?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
    bindingProperties?: {
        [key: string]: ComponentBindingPropertiesValue | undefined;
    } | undefined;
    collectionProperties?: {
        [key: string]: ComponentDataConfiguration | undefined;
    } | undefined;
    events?: {
        [key: string]: ComponentEvent | undefined;
    } | undefined;
    schemaVersion?: string | undefined;
}
export interface UpdateComponentRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string | undefined;
    updatedComponent: UpdateComponentData;
}
export interface UpdateComponentResponse {
    entity?: Component | undefined;
}
export interface UpdateFormData {
    name?: string | undefined;
    dataType?: FormDataTypeConfig | undefined;
    formActionType?: FormActionType | undefined;
    fields?: {
        [key: string]: FieldConfig | undefined;
    } | undefined;
    style?: FormStyle | undefined;
    sectionalElements?: {
        [key: string]: SectionalElement | undefined;
    } | undefined;
    schemaVersion?: string | undefined;
    cta?: FormCTA | undefined;
    labelDecorator?: string | undefined;
}
export interface UpdateFormRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string | undefined;
    updatedForm: UpdateFormData;
}
export interface UpdateFormResponse {
    entity?: Form | undefined;
}
export interface UpdateThemeData {
    id?: string | undefined;
    name?: string | undefined;
    values: ThemeValues[];
    overrides?: ThemeValues[] | undefined;
}
export interface UpdateThemeRequest {
    appId: string;
    environmentName: string;
    id: string;
    clientToken?: string | undefined;
    updatedTheme: UpdateThemeData;
}
export interface UpdateThemeResponse {
    entity?: Theme | undefined;
}
export type CreateComponentError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new component for an Amplify app.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest & RegionInput, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateFormError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new form for an Amplify app.
 */
export declare const createForm: API.OperationMethod<CreateFormRequest & RegionInput, CreateFormResponse, CreateFormError, Credentials | HttpClient.HttpClient>;
export type CreateThemeError = InternalServerException | InvalidParameterException | ResourceConflictException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a theme to apply to the components in an Amplify app.
 */
export declare const createTheme: API.OperationMethod<CreateThemeRequest & RegionInput, CreateThemeResponse, CreateThemeError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a component from an Amplify app.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest & RegionInput, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteFormError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a form from an Amplify app.
 */
export declare const deleteForm: API.OperationMethod<DeleteFormRequest & RegionInput, DeleteFormResponse, DeleteFormError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a theme from an Amplify app.
 */
export declare const deleteTheme: API.OperationMethod<DeleteThemeRequest & RegionInput, DeleteThemeResponse, DeleteThemeError, Credentials | HttpClient.HttpClient>;
export type ExchangeCodeForTokenError = InvalidParameterException | CommonErrors;
/**
 * This is for internal use.
 *
 * Amplify uses this action to exchange an access code for a token.
 */
export declare const exchangeCodeForToken: API.OperationMethod<ExchangeCodeForTokenRequest & RegionInput, ExchangeCodeForTokenResponse, ExchangeCodeForTokenError, Credentials | HttpClient.HttpClient>;
export type ExportComponentsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports component configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportComponents: API.PaginatedOperationMethod<ExportComponentsRequest & RegionInput, ExportComponentsResponse, ExportComponentsError, Credentials | HttpClient.HttpClient, Component>;
export type ExportFormsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports form configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportForms: API.PaginatedOperationMethod<ExportFormsRequest & RegionInput, ExportFormsResponse, ExportFormsError, Credentials | HttpClient.HttpClient, Form>;
export type ExportThemesError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Exports theme configurations to code that is ready to integrate into an Amplify app.
 */
export declare const exportThemes: API.PaginatedOperationMethod<ExportThemesRequest & RegionInput, ExportThemesResponse, ExportThemesError, Credentials | HttpClient.HttpClient, Theme>;
export type GetCodegenJobError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns an existing code generation job.
 */
export declare const getCodegenJob: API.OperationMethod<GetCodegenJobRequest & RegionInput, GetCodegenJobResponse, GetCodegenJobError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing component for an Amplify app.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest & RegionInput, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetFormError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing form for an Amplify app.
 */
export declare const getForm: API.OperationMethod<GetFormRequest & RegionInput, GetFormResponse, GetFormError, Credentials | HttpClient.HttpClient>;
export type GetMetadataError = InvalidParameterException | UnauthorizedException | CommonErrors;
/**
 * Returns existing metadata for an Amplify app.
 */
export declare const getMetadata: API.OperationMethod<GetMetadataRequest & RegionInput, GetMetadataResponse, GetMetadataError, Credentials | HttpClient.HttpClient>;
export type GetThemeError = InternalServerException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns an existing theme for an Amplify app.
 */
export declare const getTheme: API.OperationMethod<GetThemeRequest & RegionInput, GetThemeResponse, GetThemeError, Credentials | HttpClient.HttpClient>;
export type ListCodegenJobsError = InternalServerException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Retrieves a list of code generation jobs for a specified Amplify app and backend environment.
 */
export declare const listCodegenJobs: API.PaginatedOperationMethod<ListCodegenJobsRequest & RegionInput, ListCodegenJobsResponse, ListCodegenJobsError, Credentials | HttpClient.HttpClient, CodegenJobSummary>;
export type ListComponentsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of components for a specified Amplify app and backend
 * environment.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest & RegionInput, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, ComponentSummary>;
export type ListFormsError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of forms for a specified Amplify app and backend environment.
 */
export declare const listForms: API.PaginatedOperationMethod<ListFormsRequest & RegionInput, ListFormsResponse, ListFormsError, Credentials | HttpClient.HttpClient, FormSummary>;
export type ListTagsForResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of tags for a specified Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListThemesError = InternalServerException | InvalidParameterException | CommonErrors;
/**
 * Retrieves a list of themes for a specified Amplify app and backend
 * environment.
 */
export declare const listThemes: API.PaginatedOperationMethod<ListThemesRequest & RegionInput, ListThemesResponse, ListThemesError, Credentials | HttpClient.HttpClient, ThemeSummary>;
export type PutMetadataFlagError = InvalidParameterException | UnauthorizedException | CommonErrors;
/**
 * Stores the metadata information about a feature on a form.
 */
export declare const putMetadataFlag: API.OperationMethod<PutMetadataFlagRequest & RegionInput, PutMetadataFlagResponse, PutMetadataFlagError, Credentials | HttpClient.HttpClient>;
export type RefreshTokenError = InvalidParameterException | CommonErrors;
/**
 * This is for internal use.
 *
 * Amplify uses this action to refresh a previously issued access token that might have expired.
 */
export declare const refreshToken: API.OperationMethod<RefreshTokenRequest & RegionInput, RefreshTokenResponse, RefreshTokenError, Credentials | HttpClient.HttpClient>;
export type StartCodegenJobError = InternalServerException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Starts a code generation job for a specified Amplify app and backend environment.
 */
export declare const startCodegenJob: API.OperationMethod<StartCodegenJobRequest & RegionInput, StartCodegenJobResponse, StartCodegenJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Tags the resource with a tag key and value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Untags a resource with a specified Amazon Resource Name (ARN).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing component.
 */
export declare const updateComponent: API.OperationMethod<UpdateComponentRequest & RegionInput, UpdateComponentResponse, UpdateComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateFormError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing form.
 */
export declare const updateForm: API.OperationMethod<UpdateFormRequest & RegionInput, UpdateFormResponse, UpdateFormError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeError = InternalServerException | InvalidParameterException | ResourceConflictException | CommonErrors;
/**
 * Updates an existing theme.
 */
export declare const updateTheme: API.OperationMethod<UpdateThemeRequest & RegionInput, UpdateThemeResponse, UpdateThemeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplifyuibuilder.d.ts.map