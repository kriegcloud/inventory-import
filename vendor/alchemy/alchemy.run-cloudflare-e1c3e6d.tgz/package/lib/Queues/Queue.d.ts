import * as queues from "@distilled.cloud/cloudflare/queues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { Stack } from "alchemy/Stack";
import * as Layer from "effect/Layer";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import { LocalRuntimeState } from "../LocalRuntime.ts";
import type { Providers } from "../Providers.ts";
export declare const isQueue: (value: unknown) => value is Queue;
/**
 * Where Cloudflare stores and processes a queue's messages.
 */
export type QueueJurisdiction = "eu" | "us" | "fedramp";
export type QueueProps = {
    /**
     * Name of the queue. If omitted, a unique name will be generated.
     * Queue names are unique per account across all jurisdictions.
     * @default ${app}-${stage}-${id}
     */
    name?: string;
    /**
     * Restrict where Cloudflare stores and processes the queue's messages.
     * Workers can still produce to and consume from it from any location.
     * Cloudflare only accepts it when the queue is created, so changing it
     * replaces the queue and drops the messages still in it. A dead-letter
     * queue must be in the same jurisdiction as its source queue.
     * @default undefined (global)
     */
    jurisdiction?: QueueJurisdiction;
    /**
     * Seconds an unconsumed message is kept before it is deleted. Cloudflare
     * allows 60 seconds to 14 days (1209600). Workers Free plans can't change it.
     * Removing it resets it to the default.
     * @default 345600 (4 days)
     */
    messageRetentionPeriod?: number;
    /**
     * Seconds to delay delivery of every message to consumers, from 0 to 86400 (24 hours).
     * Removing it resets it to the default.
     * @default 0
     */
    deliveryDelay?: number;
    /**
     * Pause delivery of messages to consumers. Producers can still send.
     * Removing it resets it to the default.
     * @default false
     */
    deliveryPaused?: boolean;
};
declare const QueueJurisdictionMismatch_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "QueueJurisdictionMismatch";
} & Readonly<A>;
/**
 * The queue found by name is in a different jurisdiction than the one
 * declared. Cloudflare can't move a queue between jurisdictions, so it is
 * not adopted.
 */
export declare class QueueJurisdictionMismatch extends QueueJurisdictionMismatch_base<{
    readonly message: string;
    readonly queueName: string;
    readonly expected: QueueJurisdiction | undefined;
    readonly actual: QueueJurisdiction | undefined;
}> {
}
export type Queue = Resource<"Cloudflare.Queues.Queue", QueueProps, {
    queueId: string;
    queueName: string;
    accountId: string;
    /** The queue's jurisdiction, or `undefined` for a global queue. */
    jurisdiction: QueueJurisdiction | undefined;
    /** Seconds an unconsumed message is kept before it is deleted. */
    messageRetentionPeriod: number;
    /** Seconds delivery of every message to consumers is delayed. */
    deliveryDelay: number;
    /** Whether delivery of messages to consumers is paused. */
    deliveryPaused: boolean;
}, never, Providers, QueueLookup>;
/**
 * Props for {@link Queue.lookup}: find a queue this stack doesn't manage, by
 * its id or its name.
 */
export type QueueLookup = {
    /**
     * The Cloudflare-assigned ID of the existing queue.
     */
    queueId: string;
} | {
    /**
     * The name of the existing queue.
     */
    name: string;
};
/**
 * A Cloudflare Queue for reliable message passing between Workers.
 *
 * Queues enable you to send and receive messages with guaranteed delivery.
 * Create a queue as a resource, then bind it to a Worker to send messages
 * at runtime. Register a consumer to process messages.
 * ### Creating a Queue
 * **Example:** Basic queue
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("MyQueue");
 * ```
 *
 * **Example:** Queue with explicit name
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("MyQueue", {
 *   name: "my-app-queue",
 * });
 * ```
 *
 * ### Configuring Settings
 * Durations are in seconds, matching the Cloudflare API. A setting you
 * never declare keeps whatever value the queue already has.
 *
 * **Example:** Dead-letter queue that keeps messages for 14 days
 * ```typescript
 * const deadLetters = yield* Cloudflare.Queues.Queue("DeadLetters", {
 *   messageRetentionPeriod: 14 * 24 * 60 * 60,
 * });
 * ```
 *
 * **Example:** Delay and pause delivery
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("MyQueue", {
 *   deliveryDelay: 30,
 *   deliveryPaused: true,
 * });
 * ```
 *
 * ### Data Residency
 * **Example:** Queue restricted to the EU
 * ```typescript
 * const queue = yield* Cloudflare.Queues.Queue("EuQueue", {
 *   jurisdiction: "eu",
 * });
 * const deadLetters = yield* Cloudflare.Queues.Queue("EuDeadLetters", {
 *   jurisdiction: "eu",
 * });
 * ```
 *
 * ### Binding to a Worker
 * In an Effect-style Worker, use `Cloudflare.Queues.WriteQueue` in
 * the init phase and provide `Cloudflare.Queues.WriteQueueBinding` in
 * the runtime layer. The returned `WriteQueueClient` exposes `send`
 * and `sendBatch`.
 *
 * **Example:** Sending messages from a Worker
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as Effect from "effect/Effect";
 * import { HttpServerRequest } from "effect/http/HttpServerRequest";
 * import * as HttpServerResponse from "effect/http/HttpServerResponse";
 *
 * export const Queue = Cloudflare.Queues.Queue("Queue");
 *
 * export default Cloudflare.Worker(
 *   "Worker",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const queue = yield* Cloudflare.Queues.WriteQueue(Queue);
 *
 *     return {
 *       fetch: Effect.gen(function* () {
 *         const request = yield* HttpServerRequest;
 *         if (request.url === "/queue/send" && request.method === "POST") {
 *           const text = yield* request.text;
 *           yield* queue.send({ text, sentAt: Date.now() }).pipe(Effect.orDie);
 *           return yield* HttpServerResponse.json(
 *             { sent: { text } },
 *             { status: 202 },
 *           );
 *         }
 *         return HttpServerResponse.text("Not Found", { status: 404 });
 *       }),
 *     };
 *   }).pipe(Effect.provide(Cloudflare.Queues.WriteQueueBinding)),
 * );
 * ```
 *
 * ### Looking up an existing queue
 * `Queue.lookup` binds a queue Alchemy doesn't manage (created in the
 * dashboard or by another stack), found by `queueId` or `name`. It is read
 * during plan/deploy and never created, updated or deleted.
 *
 * **Example:** By name
 * ```typescript
 * const jobs = yield* Cloudflare.Queues.WriteQueue(
 *   Cloudflare.Queues.Queue.lookup({ name: "jobs" }),
 * );
 * ```
 *
 * **Example:** By ID, in an async Worker's `env`
 * ```typescript
 * const worker = yield* Cloudflare.Worker("Worker", {
 *   main: "./src/worker.ts",
 *   env: {
 *     JOBS: Cloudflare.Queues.Queue.lookup({
 *       queueId: "023e105f4ecef8ad9ca31a8372d0c353",
 *     }),
 *   },
 * });
 * ```
 *
 * @resource
 * @product Queues
 * @category Storage & Databases
 */
export declare const Queue: import("alchemy").ResourceClass<Queue>;
export declare const ProviderLive: () => Layer.Layer<Provider.Provider<Queue>, never, CloudflareEnvironment | Stack | import("alchemy").Stage | queues.CloudflareOpContext>;
export declare const ProviderLocal: () => Layer.Layer<Provider.Provider<Queue>, never, import("alchemy").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | LocalRuntimeState | Stack | import("alchemy").Stage | queues.CloudflareOpContext>;
export declare const QueueProvider: () => Layer.Layer<Provider.Provider<Queue>, import("effect/Config").ConfigError | import("@alchemy.run/cloudflare-runtime/core").ConfigError | import("effect/PlatformError").PlatformError | import("@alchemy.run/cloudflare-runtime/core").SystemError, import("alchemy").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | CloudflareEnvironment | import("effect/FileSystem").FileSystem | import("effect/Path").Path | Stack | import("alchemy").Stage | queues.CloudflareOpContext>;
export {};
//# sourceMappingURL=Queue.d.ts.map