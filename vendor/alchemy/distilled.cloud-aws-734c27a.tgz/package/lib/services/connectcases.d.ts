import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type ContactArn = string;
export interface Contact {
    contactArn: string;
}
export type CommentBody = string;
export type CommentBodyTextType = string;
export interface CommentContent {
    body: string;
    contentType: string;
}
export type FileArn = string;
export interface FileContent {
    fileArn: string;
}
export type SlaName = string | redacted.Redacted<string>;
export type SlaType = string;
export type FieldId = string;
export interface EmptyFieldValue {
}
export type FieldValueUnion = {
    stringValue: string;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue: number;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue: boolean;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue: EmptyFieldValue;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue: string;
};
export type SlaFieldValueUnionList = FieldValueUnion[];
export type TargetSlaMinutes = number;
export interface SlaInputConfiguration {
    name: string | redacted.Redacted<string>;
    type: string;
    fieldId?: string | undefined;
    targetFieldValues?: FieldValueUnion[] | undefined;
    targetSlaMinutes: number;
}
export type SlaInputContent = {
    slaInputConfiguration: SlaInputConfiguration;
};
export type CaseId = string;
export interface ConnectCaseInputContent {
    caseId: string;
}
export interface FieldValue {
    id: string;
    value: FieldValueUnion;
}
export type FieldValueList = FieldValue[];
export interface CustomInputContent {
    fields: FieldValue[];
}
export type RelatedItemInputContent = {
    contact: Contact;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment: CommentContent;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file: FileContent;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla: SlaInputContent;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase: ConnectCaseInputContent;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom: CustomInputContent;
};
export type ReferenceId = string;
export type CaseIdentifierUnion = {
    caseId: string;
    referenceId?: undefined;
} | {
    caseId?: undefined;
    referenceId: string;
};
export interface BatchCreateRelatedItemIdentifier {
    caseIdentifier: CaseIdentifierUnion;
}
export type BatchCreateRelatedItemIdentifierList = BatchCreateRelatedItemIdentifier[];
export type UserArn = string;
export type CustomEntity = string | redacted.Redacted<string>;
export type UserUnion = {
    userArn: string;
    customEntity?: undefined;
} | {
    userArn?: undefined;
    customEntity: string | redacted.Redacted<string>;
};
export interface BatchCreateRelatedItemRequest {
    domainId: string;
    content: RelatedItemInputContent;
    cases: BatchCreateRelatedItemIdentifier[];
    performedBy?: UserUnion | undefined;
    clientToken?: string | undefined;
}
export type ReferenceNumber = string;
export interface CaseIdentifier {
    caseId?: string | undefined;
    referenceNumber?: string | undefined;
    referenceId?: string | undefined;
}
export type RelatedItemId = string;
export type RelatedItemArn = string;
export interface BatchCreateRelatedItemSuccessEntry {
    caseIdentifier: CaseIdentifier;
    relatedItemId: string;
    relatedItemArn: string;
}
export type BatchCreateRelatedItemSuccessEntryList = BatchCreateRelatedItemSuccessEntry[];
export interface BatchCreateRelatedItemErrorEntry {
    caseIdentifier: CaseIdentifier;
    errorCode: string;
    errorMessage: string;
}
export type BatchCreateRelatedItemErrorEntryList = BatchCreateRelatedItemErrorEntry[];
export interface BatchCreateRelatedItemResponse {
    successfulItems: BatchCreateRelatedItemSuccessEntry[];
    failedItems: BatchCreateRelatedItemErrorEntry[];
}
export type CaseRuleId = string;
export interface CaseRuleIdentifier {
    id: string;
}
export type CaseRuleIdentifierList = CaseRuleIdentifier[];
export interface BatchGetCaseRuleRequest {
    domainId: string;
    caseRules: CaseRuleIdentifier[];
}
export type CaseRuleName = string;
export type CaseRuleArn = string;
export type OperandOne = {
    fieldId: string;
};
export interface EmptyOperandValue {
}
export type OperandTwo = {
    stringValue: string;
    booleanValue?: undefined;
    doubleValue?: undefined;
    emptyValue?: undefined;
} | {
    stringValue?: undefined;
    booleanValue: boolean;
    doubleValue?: undefined;
    emptyValue?: undefined;
} | {
    stringValue?: undefined;
    booleanValue?: undefined;
    doubleValue: number;
    emptyValue?: undefined;
} | {
    stringValue?: undefined;
    booleanValue?: undefined;
    doubleValue?: undefined;
    emptyValue: EmptyOperandValue;
};
export interface BooleanOperands {
    operandOne: OperandOne;
    operandTwo: OperandTwo;
    result: boolean;
}
export interface CompoundCondition {
    conditions: BooleanCondition[];
}
export type BooleanCondition = {
    equalTo: BooleanOperands;
    notEqualTo?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo: BooleanOperands;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    andAll: CompoundCondition;
    orAll?: undefined;
} | {
    equalTo?: undefined;
    notEqualTo?: undefined;
    andAll?: undefined;
    orAll: CompoundCondition;
};
export type BooleanConditionList = BooleanCondition[];
export interface RequiredCaseRule {
    defaultValue: boolean;
    conditions: BooleanCondition[];
}
export type ParentChildFieldOptionValue = string;
export type ParentChildFieldOptionValueList = string[];
export interface ParentChildFieldOptionsMapping {
    parentFieldOptionValue: string;
    childFieldOptionValues: string[];
}
export type ParentChildFieldOptionsMappingList = ParentChildFieldOptionsMapping[];
export interface FieldOptionsCaseRule {
    parentFieldId?: string | undefined;
    childFieldId?: string | undefined;
    parentChildFieldOptionsMappings: ParentChildFieldOptionsMapping[];
}
export interface HiddenCaseRule {
    defaultValue: boolean;
    conditions: BooleanCondition[];
}
export type CaseRuleDetails = {
    required: RequiredCaseRule;
    fieldOptions?: undefined;
    hidden?: undefined;
} | {
    required?: undefined;
    fieldOptions: FieldOptionsCaseRule;
    hidden?: undefined;
} | {
    required?: undefined;
    fieldOptions?: undefined;
    hidden: HiddenCaseRule;
};
export type CaseRuleDescription = string;
export type Deleted = boolean;
export type CreatedTime = Date;
export type LastModifiedTime = Date;
export type Tags = {
    [key: string]: string | null | undefined;
};
export interface GetCaseRuleResponse {
    caseRuleId: string;
    name: string;
    caseRuleArn: string;
    rule: CaseRuleDetails;
    description?: string | undefined;
    deleted?: boolean | undefined;
    createdTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export type BatchGetCaseRuleList = GetCaseRuleResponse[];
export interface CaseRuleError {
    id: string;
    errorCode: string;
    message?: string | undefined;
}
export type BatchGetCaseRuleErrorList = CaseRuleError[];
export type BatchGetCaseRuleUnprocessedList = string[];
export interface BatchGetCaseRuleResponse {
    caseRules: GetCaseRuleResponse[];
    errors: CaseRuleError[];
    unprocessedCaseRules?: string[] | undefined;
}
export interface FieldIdentifier {
    id: string;
}
export type BatchGetFieldIdentifierList = FieldIdentifier[];
export interface BatchGetFieldRequest {
    domainId: string;
    fields: FieldIdentifier[];
}
export type FieldName = string;
export type FieldArn = string;
export type FieldDescription = string;
export type FieldType = string;
export type FieldNamespace = string;
export interface TextAttributes {
    isMultiline: boolean;
}
export type FieldAttributes = {
    text: TextAttributes;
};
export interface GetFieldResponse {
    fieldId: string;
    name: string;
    fieldArn: string;
    description?: string | undefined;
    type: string;
    namespace: string;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    deleted?: boolean | undefined;
    createdTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    attributes?: FieldAttributes | undefined;
}
export type BatchGetFieldList = GetFieldResponse[];
export interface FieldError {
    id: string;
    errorCode: string;
    message?: string | undefined;
}
export type BatchGetFieldErrorList = FieldError[];
export interface BatchGetFieldResponse {
    fields: GetFieldResponse[];
    errors: FieldError[];
}
export type FieldOptionName = string;
export type FieldOptionValue = string;
export interface FieldOption {
    name: string;
    value: string;
    active: boolean;
}
export type FieldOptionsList = FieldOption[];
export interface BatchPutFieldOptionsRequest {
    domainId: string;
    fieldId: string;
    options: FieldOption[];
}
export interface FieldOptionError {
    message: string;
    errorCode: string;
    value: string;
}
export type FieldOptionErrorList = FieldOptionError[];
export interface BatchPutFieldOptionsResponse {
    errors?: FieldOptionError[] | undefined;
}
export interface BatchUpdateCaseIdentifier {
    caseIdentifier: CaseIdentifierUnion;
}
export type BatchUpdateCaseIdentifierList = BatchUpdateCaseIdentifier[];
export type FieldIdentifierUnion = {
    id: string;
    name?: undefined;
} | {
    id?: undefined;
    name: string;
};
export interface FieldValueInput {
    fieldIdentifier: FieldIdentifierUnion;
    value: FieldValueUnion;
}
export type FieldValueInputList = FieldValueInput[];
export type CaseTitle = string | redacted.Redacted<string>;
export type CaseStatus = string;
export type CustomerProfileArn = string;
export interface BatchUpdateCaseRequest {
    domainId: string;
    cases: BatchUpdateCaseIdentifier[];
    fields: FieldValueInput[];
    performedBy?: UserUnion | undefined;
    title?: string | redacted.Redacted<string> | undefined;
    status?: string | undefined;
    customerId?: string | undefined;
    clientToken?: string | undefined;
}
export interface BatchUpdateCaseSuccessEntry {
    caseIdentifier: CaseIdentifier;
}
export type BatchUpdateCaseSuccessEntryList = BatchUpdateCaseSuccessEntry[];
export interface BatchUpdateCaseErrorEntry {
    caseIdentifier: CaseIdentifier;
    errorCode: string;
    errorMessage: string;
}
export type BatchUpdateCaseErrorEntryList = BatchUpdateCaseErrorEntry[];
export interface BatchUpdateCaseResponse {
    successfulCases: BatchUpdateCaseSuccessEntry[];
    failedCases: BatchUpdateCaseErrorEntry[];
}
export type TemplateId = string;
export type MutableTagKey = string;
export type TagValueString = string;
export type MutableTags = {
    [key: string]: string | undefined;
};
export interface CreateCaseRequest {
    domainId: string;
    templateId: string;
    fields: FieldValue[];
    clientToken?: string | undefined;
    performedBy?: UserUnion | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CaseArn = string;
export interface CreateCaseResponse {
    caseId: string;
    caseArn: string;
}
export interface CreateCaseRuleRequest {
    domainId: string;
    name: string;
    description?: string | undefined;
    rule: CaseRuleDetails;
}
export interface CreateCaseRuleResponse {
    caseRuleId: string;
    caseRuleArn: string;
}
export type DomainName = string;
export interface CreateDomainRequest {
    name: string;
}
export type DomainArn = string;
export type DomainStatus = string;
export interface CreateDomainResponse {
    domainId: string;
    domainArn: string;
    domainStatus: string;
}
export interface CreateFieldRequest {
    domainId: string;
    name: string;
    type: string;
    description?: string | undefined;
    attributes?: FieldAttributes | undefined;
}
export interface CreateFieldResponse {
    fieldId: string;
    fieldArn: string;
}
export type LayoutName = string;
export interface FieldItem {
    id: string;
}
export type FieldList = FieldItem[];
export interface FieldGroup {
    name?: string | undefined;
    fields: FieldItem[];
}
export type Section = {
    fieldGroup: FieldGroup;
};
export type SectionsList = Section[];
export interface LayoutSections {
    sections?: Section[] | undefined;
}
export interface BasicLayout {
    topPanel?: LayoutSections | undefined;
    moreInfo?: LayoutSections | undefined;
}
export type LayoutContent = {
    basic: BasicLayout;
};
export interface CreateLayoutRequest {
    domainId: string;
    name: string;
    content: LayoutContent;
}
export type LayoutId = string;
export type LayoutArn = string;
export interface CreateLayoutResponse {
    layoutId: string;
    layoutArn: string;
}
export type RelatedItemType = string;
export interface CreateRelatedItemRequest {
    domainId: string;
    caseId: string;
    type: string;
    content: RelatedItemInputContent;
    performedBy?: UserUnion | undefined;
}
export interface CreateRelatedItemResponse {
    relatedItemId: string;
    relatedItemArn: string;
}
export type TemplateName = string;
export type TemplateDescription = string;
export interface LayoutConfiguration {
    defaultLayout?: string | undefined;
}
export interface RequiredField {
    fieldId: string;
}
export type RequiredFieldList = RequiredField[];
export type TemplateStatus = string;
export interface TemplateRule {
    caseRuleId: string;
    fieldId?: string | undefined;
}
export type TemplateCaseRuleList = TemplateRule[];
export type TagPropagationResourceType = string;
export interface TagPropagationConfiguration {
    resourceType: string;
    tagMap: {
        [key: string]: string | undefined;
    };
}
export type TagPropagationConfigurationList = TagPropagationConfiguration[];
export interface CreateTemplateRequest {
    domainId: string;
    name: string;
    description?: string | undefined;
    layoutConfiguration?: LayoutConfiguration | undefined;
    requiredFields?: RequiredField[] | undefined;
    status?: string | undefined;
    rules?: TemplateRule[] | undefined;
    tagPropagationConfigurations?: TagPropagationConfiguration[] | undefined;
}
export type TemplateArn = string;
export interface CreateTemplateResponse {
    templateId: string;
    templateArn: string;
}
export interface DeleteCaseRequest {
    domainId: string;
    caseId: string;
}
export interface DeleteCaseResponse {
}
export interface DeleteCaseRuleRequest {
    domainId: string;
    caseRuleId: string;
}
export interface DeleteCaseRuleResponse {
}
export interface DeleteDomainRequest {
    domainId: string;
}
export interface DeleteDomainResponse {
}
export interface DeleteFieldRequest {
    domainId: string;
    fieldId: string;
}
export interface DeleteFieldResponse {
}
export interface DeleteLayoutRequest {
    domainId: string;
    layoutId: string;
}
export interface DeleteLayoutResponse {
}
export interface DeleteRelatedItemRequest {
    domainId: string;
    caseId: string;
    relatedItemId: string;
}
export interface DeleteRelatedItemResponse {
}
export interface DeleteTemplateRequest {
    domainId: string;
    templateId: string;
}
export interface DeleteTemplateResponse {
}
export type FieldIdentifierList = FieldIdentifier[];
export type NextToken = string;
export interface GetCaseRequest {
    caseId: string;
    domainId: string;
    fields: FieldIdentifier[];
    nextToken?: string | undefined;
}
export interface GetCaseResponse {
    fields: FieldValue[];
    templateId: string;
    nextToken?: string | undefined;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export interface GetCaseAuditEventsRequest {
    caseId: string;
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AuditEventId = string;
export type AuditEventType = string;
export type AuditEventDateTime = Date;
export type AuditEventFieldId = string;
export type AuditEventFieldValueUnion = {
    stringValue: string;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue: number;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue: boolean;
    emptyValue?: undefined;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue: EmptyFieldValue;
    userArnValue?: undefined;
} | {
    stringValue?: undefined;
    doubleValue?: undefined;
    booleanValue?: undefined;
    emptyValue?: undefined;
    userArnValue: string;
};
export interface AuditEventField {
    eventFieldId: string;
    oldValue?: AuditEventFieldValueUnion | undefined;
    newValue: AuditEventFieldValueUnion;
}
export type AuditEventFieldList = (AuditEventField | null)[];
export type IamPrincipalArn = string;
export interface AuditEventPerformedBy {
    user?: UserUnion | undefined;
    iamPrincipalArn: string;
}
export interface AuditMergeMetadata {
    mergeEventId: string;
    primaryCaseId: string;
    secondaryCaseId: string;
}
export interface AuditEvent {
    eventId: string;
    type: string;
    relatedItemType?: string | undefined;
    performedTime: Date;
    fields: (AuditEventField | null)[];
    performedBy?: AuditEventPerformedBy | undefined;
    mergeMetadata?: AuditMergeMetadata | undefined;
}
export type AuditEventsList = (AuditEvent | null)[];
export interface GetCaseAuditEventsResponse {
    nextToken?: string | undefined;
    auditEvents: (AuditEvent | null)[];
}
export interface GetCaseEventConfigurationRequest {
    domainId: string;
}
export interface CaseEventIncludedData {
    fields: FieldIdentifier[];
}
export interface RelatedItemEventIncludedData {
    includeContent: boolean;
}
export interface EventIncludedData {
    caseData?: CaseEventIncludedData | undefined;
    relatedItemData?: RelatedItemEventIncludedData | undefined;
}
export interface EventBridgeConfiguration {
    enabled: boolean;
    includedData?: EventIncludedData | undefined;
}
export interface GetCaseEventConfigurationResponse {
    eventBridge: EventBridgeConfiguration;
}
export interface GetDomainRequest {
    domainId: string;
}
export interface GetDomainResponse {
    domainId: string;
    domainArn: string;
    name: string;
    createdTime: Date;
    domainStatus: string;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export interface GetLayoutRequest {
    domainId: string;
    layoutId: string;
}
export interface GetLayoutResponse {
    layoutId: string;
    layoutArn: string;
    name: string;
    content: LayoutContent;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    deleted?: boolean | undefined;
    createdTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
}
export interface GetMergeCasesStatusRequest {
    domainId: string;
    caseId: string;
}
export type MergeStatus = string;
export type CaseIdList = string[];
export interface GetMergeCasesStatusResponse {
    status: string;
    primaryCaseId?: string | undefined;
    secondaryCaseIds?: string[] | undefined;
}
export interface GetTemplateRequest {
    domainId: string;
    templateId: string;
}
export interface GetTemplateResponse {
    templateId: string;
    templateArn: string;
    name: string;
    description?: string | undefined;
    layoutConfiguration?: LayoutConfiguration | undefined;
    requiredFields?: RequiredField[] | undefined;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    status: string;
    deleted?: boolean | undefined;
    createdTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    rules?: TemplateRule[] | undefined;
    tagPropagationConfigurations?: TagPropagationConfiguration[] | undefined;
}
export type MaxResults = number;
export interface ListCaseRulesRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type RuleType = string;
export interface CaseRuleSummary {
    caseRuleId: string;
    name: string;
    caseRuleArn: string;
    ruleType: string;
    description?: string | undefined;
}
export type CaseRuleSummaryList = CaseRuleSummary[];
export interface ListCaseRulesResponse {
    caseRules: CaseRuleSummary[];
    nextToken?: string | undefined;
}
export interface ListCasesForContactRequest {
    domainId: string;
    contactArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface CaseSummary {
    caseId: string;
    templateId: string;
}
export type CaseSummaryList = CaseSummary[];
export interface ListCasesForContactResponse {
    cases: CaseSummary[];
    nextToken?: string | undefined;
}
export interface ListDomainsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DomainSummary {
    domainId: string;
    domainArn: string;
    name: string;
}
export type DomainSummaryList = DomainSummary[];
export interface ListDomainsResponse {
    domains: DomainSummary[];
    nextToken?: string | undefined;
}
export type Value = string;
export type ValuesList = string[];
export interface ListFieldOptionsRequest {
    domainId: string;
    fieldId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    values?: string[] | undefined;
}
export interface ListFieldOptionsResponse {
    options: FieldOption[];
    nextToken?: string | undefined;
}
export interface ListFieldsRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FieldSummary {
    fieldId: string;
    fieldArn: string;
    name: string;
    type: string;
    namespace: string;
    attributes?: FieldAttributes | undefined;
}
export type FieldSummaryList = FieldSummary[];
export interface ListFieldsResponse {
    fields: FieldSummary[];
    nextToken?: string | undefined;
}
export interface ListLayoutsRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface LayoutSummary {
    layoutId: string;
    layoutArn: string;
    name: string;
}
export type LayoutSummaryList = LayoutSummary[];
export interface ListLayoutsResponse {
    layouts: LayoutSummary[];
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export type TemplateStatusFilters = string[];
export interface ListTemplatesRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    status?: string[] | undefined;
}
export interface TemplateSummary {
    templateId: string;
    templateArn: string;
    name: string;
    status: string;
    tagPropagationConfigurations?: TagPropagationConfiguration[] | undefined;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListTemplatesResponse {
    templates: TemplateSummary[];
    nextToken?: string | undefined;
}
export interface PutCaseEventConfigurationRequest {
    domainId: string;
    eventBridge: EventBridgeConfiguration;
}
export interface PutCaseEventConfigurationResponse {
}
export type Channel = string;
export type ChannelList = string[];
export interface ContactFilter {
    channel?: string[] | undefined;
    contactArn?: string | undefined;
}
export interface CommentFilter {
}
export interface FileFilter {
    fileArn?: string | undefined;
}
export type SlaStatus = string;
export interface SlaFilter {
    name?: string | redacted.Redacted<string> | undefined;
    status?: string | undefined;
}
export interface ConnectCaseFilter {
    caseId?: string | undefined;
}
export type FieldFilter = {
    equalTo: FieldValue;
    contains?: undefined;
    greaterThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThan?: undefined;
    lessThanOrEqualTo?: undefined;
} | {
    equalTo?: undefined;
    contains: FieldValue;
    greaterThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThan?: undefined;
    lessThanOrEqualTo?: undefined;
} | {
    equalTo?: undefined;
    contains?: undefined;
    greaterThan: FieldValue;
    greaterThanOrEqualTo?: undefined;
    lessThan?: undefined;
    lessThanOrEqualTo?: undefined;
} | {
    equalTo?: undefined;
    contains?: undefined;
    greaterThan?: undefined;
    greaterThanOrEqualTo: FieldValue;
    lessThan?: undefined;
    lessThanOrEqualTo?: undefined;
} | {
    equalTo?: undefined;
    contains?: undefined;
    greaterThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThan: FieldValue;
    lessThanOrEqualTo?: undefined;
} | {
    equalTo?: undefined;
    contains?: undefined;
    greaterThan?: undefined;
    greaterThanOrEqualTo?: undefined;
    lessThan?: undefined;
    lessThanOrEqualTo: FieldValue;
};
export type CustomFieldsFilterList = CustomFieldsFilter[];
export type CustomFieldsFilter = {
    field: FieldFilter;
    not?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    field?: undefined;
    not: CustomFieldsFilter;
    andAll?: undefined;
    orAll?: undefined;
} | {
    field?: undefined;
    not?: undefined;
    andAll: CustomFieldsFilter[];
    orAll?: undefined;
} | {
    field?: undefined;
    not?: undefined;
    andAll?: undefined;
    orAll: CustomFieldsFilter[];
};
export interface CustomFilter {
    fields?: CustomFieldsFilter | undefined;
}
export type RelatedItemTypeFilter = {
    contact: ContactFilter;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment: CommentFilter;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file: FileFilter;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla: SlaFilter;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase: ConnectCaseFilter;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom: CustomFilter;
};
export type RelatedItemFilterList = RelatedItemTypeFilter[];
export type SearchAllRelatedItemsSortProperty = string;
export type Order = string;
export interface SearchAllRelatedItemsSort {
    sortProperty: string;
    sortOrder: string;
}
export type SearchAllRelatedItemsSortList = SearchAllRelatedItemsSort[];
export interface SearchAllRelatedItemsRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: RelatedItemTypeFilter[] | undefined;
    sorts?: SearchAllRelatedItemsSort[] | undefined;
}
export type AssociationTime = Date;
export type ConnectedToSystemTime = Date;
export interface ContactContent {
    contactArn: string;
    channel: string;
    connectedToSystemTime: Date;
}
export type SlaTargetTime = Date;
export type SlaCompletionTime = Date;
export interface SlaConfiguration {
    name: string | redacted.Redacted<string>;
    type: string;
    status: string;
    fieldId?: string | undefined;
    targetFieldValues?: FieldValueUnion[] | undefined;
    targetTime: Date;
    completionTime?: Date | undefined;
}
export interface SlaContent {
    slaConfiguration: SlaConfiguration;
}
export interface ConnectCaseContent {
    caseId: string;
}
export interface CustomContent {
    fields: FieldValue[];
}
export type RelatedItemContent = {
    contact: ContactContent;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment: CommentContent;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file: FileContent;
    sla?: undefined;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla: SlaContent;
    connectCase?: undefined;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase: ConnectCaseContent;
    custom?: undefined;
} | {
    contact?: undefined;
    comment?: undefined;
    file?: undefined;
    sla?: undefined;
    connectCase?: undefined;
    custom: CustomContent;
};
export interface SearchAllRelatedItemsResponseItem {
    relatedItemId: string;
    caseId: string;
    type: string;
    associationTime: Date;
    content: RelatedItemContent;
    performedBy?: UserUnion | undefined;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export type SearchAllRelatedItemsResponseItemList = (SearchAllRelatedItemsResponseItem | null)[];
export interface SearchAllRelatedItemsResponse {
    nextToken?: string | undefined;
    relatedItems: (SearchAllRelatedItemsResponseItem | null)[];
}
export type SearchTagKey = string;
export interface TagValue {
    key?: string | undefined;
    value?: string | undefined;
}
export type TagFilter = {
    equalTo: TagValue;
};
export type CaseFilterList = CaseFilter[];
export type CaseFilter = {
    field: FieldFilter;
    not?: undefined;
    tag?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    field?: undefined;
    not: CaseFilter;
    tag?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    field?: undefined;
    not?: undefined;
    tag: TagFilter;
    andAll?: undefined;
    orAll?: undefined;
} | {
    field?: undefined;
    not?: undefined;
    tag?: undefined;
    andAll: CaseFilter[];
    orAll?: undefined;
} | {
    field?: undefined;
    not?: undefined;
    tag?: undefined;
    andAll?: undefined;
    orAll: CaseFilter[];
};
export interface Sort {
    fieldId: string;
    sortOrder: string;
}
export type SortList = Sort[];
export interface SearchCasesRequest {
    domainId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    searchTerm?: string | undefined;
    filter?: CaseFilter | undefined;
    sorts?: Sort[] | undefined;
    fields?: FieldIdentifier[] | undefined;
}
export interface SearchCasesResponseItem {
    caseId: string;
    templateId: string;
    fields: FieldValue[];
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
}
export type SearchCasesResponseItemList = (SearchCasesResponseItem | null)[];
export type TotalCount = number;
export interface SearchCasesResponse {
    nextToken?: string | undefined;
    cases: (SearchCasesResponseItem | null)[];
    totalCount?: number | undefined;
}
export interface SearchRelatedItemsRequest {
    domainId: string;
    caseId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: RelatedItemTypeFilter[] | undefined;
}
export interface SearchRelatedItemsResponseItem {
    relatedItemId: string;
    type: string;
    associationTime: Date;
    content: RelatedItemContent;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    performedBy?: UserUnion | undefined;
}
export type SearchRelatedItemsResponseItemList = (SearchRelatedItemsResponseItem | null)[];
export interface SearchRelatedItemsResponse {
    nextToken?: string | undefined;
    relatedItems: (SearchRelatedItemsResponseItem | null)[];
}
export interface FieldsConfiguration {
    fieldIds: FieldIdentifier[];
    sourceCaseId: string;
}
export type FieldsConfigurationList = FieldsConfiguration[];
export interface RelatedItemsConfiguration {
    comment?: boolean | undefined;
    connectCase?: boolean | undefined;
    contact?: boolean | undefined;
    custom?: boolean | undefined;
}
export interface StartMergeCasesRequest {
    domainId: string;
    caseId: string;
    secondaryCaseIds: string[];
    fieldsConfiguration?: FieldsConfiguration[] | undefined;
    relatedItemsConfiguration?: RelatedItemsConfiguration | undefined;
    performedBy?: UserUnion | undefined;
}
export interface StartMergeCasesResponse {
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | null | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKey = string;
export type TagKeyList = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCaseRequest {
    domainId: string;
    caseId: string;
    fields: FieldValue[];
    performedBy?: UserUnion | undefined;
}
export interface UpdateCaseResponse {
}
export interface UpdateCaseRuleRequest {
    domainId: string;
    caseRuleId: string;
    name?: string | undefined;
    description?: string | undefined;
    rule?: CaseRuleDetails | undefined;
}
export interface UpdateCaseRuleResponse {
}
export interface UpdateFieldRequest {
    domainId: string;
    fieldId: string;
    name?: string | undefined;
    description?: string | undefined;
    attributes?: FieldAttributes | undefined;
}
export interface UpdateFieldResponse {
}
export interface UpdateLayoutRequest {
    domainId: string;
    layoutId: string;
    name?: string | undefined;
    content?: LayoutContent | undefined;
}
export interface UpdateLayoutResponse {
}
export interface CommentUpdateContent {
    body: string;
    contentType: string;
}
export interface CustomUpdateContent {
    fields: FieldValue[];
}
export type RelatedItemUpdateContent = {
    comment: CommentUpdateContent;
    custom?: undefined;
} | {
    comment?: undefined;
    custom: CustomUpdateContent;
};
export interface UpdateRelatedItemRequest {
    domainId: string;
    caseId: string;
    relatedItemId: string;
    content: RelatedItemUpdateContent;
    performedBy?: UserUnion | undefined;
}
export interface UpdateRelatedItemResponse {
    relatedItemId: string;
    relatedItemArn: string;
    type: string;
    content: RelatedItemContent;
    associationTime: Date;
    tags?: {
        [key: string]: string | null | undefined;
    } | undefined;
    lastUpdatedUser?: UserUnion | undefined;
    createdBy?: UserUnion | undefined;
}
export interface UpdateTemplateRequest {
    domainId: string;
    templateId: string;
    name?: string | undefined;
    description?: string | undefined;
    layoutConfiguration?: LayoutConfiguration | undefined;
    requiredFields?: RequiredField[] | undefined;
    status?: string | undefined;
    rules?: TemplateRule[] | undefined;
    tagPropagationConfigurations?: TagPropagationConfiguration[] | undefined;
}
export interface UpdateTemplateResponse {
}
export type BatchCreateRelatedItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a comment and associates it with multiple cases in a single request. All cases must belong to the same domain. This operation supports only the Comment related item type.
 *
 * Each case is processed independently. If some cases fail, the remaining cases still receive the related item. To determine whether individual items failed, inspect the `failedItems` array in the response.
 *
 * The entire request fails, and no related items are created, in the following cases:
 *
 * - The specified domain doesn't exist.
 *
 * - A reference ID doesn't match any case in the domain.
 *
 * - The request contains duplicate case IDs.
 *
 * - The content isn't comment content.
 *
 * This operation uses the same IAM action as CreateRelatedItem (`cases:CreateRelatedItem`). You can use the `cases:IsBatchAction` condition key in IAM policies to allow or deny batch operations independently from single-case operations.
 *
 * If you provide a value for `performedBy.userArn`, you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const batchCreateRelatedItem: API.OperationMethod<BatchCreateRelatedItemRequest & RegionInput, BatchCreateRelatedItemResponse, BatchCreateRelatedItemError, Credentials | HttpClient.HttpClient>;
export type BatchGetCaseRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a batch of case rules. In the Connect Customer admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const batchGetCaseRule: API.OperationMethod<BatchGetCaseRuleRequest & RegionInput, BatchGetCaseRuleResponse, BatchGetCaseRuleError, Credentials | HttpClient.HttpClient>;
export type BatchGetFieldError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the description for the list of fields in the request parameters.
 */
export declare const batchGetField: API.OperationMethod<BatchGetFieldRequest & RegionInput, BatchGetFieldResponse, BatchGetFieldError, Credentials | HttpClient.HttpClient>;
export type BatchPutFieldOptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates and updates a set of field options for a single select field in a Cases domain.
 */
export declare const batchPutFieldOptions: API.OperationMethod<BatchPutFieldOptionsRequest & RegionInput, BatchPutFieldOptionsResponse, BatchPutFieldOptionsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates fields on multiple cases in a single request. All cases must belong to the same domain. Set the title, status, and customer ID through the top-level `title`, `status`, and `customerId` parameters, and set other fields through the `fields` array.
 *
 * Each case is processed independently. If some cases fail, the remaining cases are still updated. To determine whether individual cases failed, inspect the `failedCases` array in the response.
 *
 * The entire request fails, and no cases are updated, in the following cases:
 *
 * - The specified domain doesn't exist.
 *
 * - A reference ID doesn't match any case in the domain.
 *
 * - The request contains duplicate case IDs.
 *
 * - The request doesn't specify any update. Provide at least one entry in `fields`, or a `title`, `status`, or `customerId`.
 *
 * - A field identifier in `fields` doesn't resolve to a field in the domain, for example, an unknown field name.
 *
 * - A field name contains a pipe (`|`) or comma (`,`) character.
 *
 * - `fields` includes `title`, `status`, or `customerId`.
 *
 * This operation uses the same IAM action as UpdateCase (`cases:UpdateCase`). You can use the `cases:IsBatchAction` condition key in IAM policies to allow or deny batch operations independently from single-case operations.
 *
 * If you provide a value for `performedBy.userArn`, you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const batchUpdateCase: API.OperationMethod<BatchUpdateCaseRequest & RegionInput, BatchUpdateCaseResponse, BatchUpdateCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * If you provide a value for `PerformedBy.UserArn`, you must also have the connect:DescribeUser permission on the user ARN that you provide.
 *
 * Creates a case in the specified Cases domain. Case system and custom fields are taken as an array id/value pairs with a declared data types.
 *
 * When creating a case from a template that has tag propagation configurations, the specified tags are automatically applied to the case.
 *
 * The following field is always required when creating a case:
 *
 * - `title`
 *
 * The following field may be required depending on the template configuration:
 *
 * - `customer_id` - Required only if the template's `requiredFields` list includes `customer_id`. When required, provide the full customer profile ARN in this format: `arn:aws:profile:your_AWS_Region:your_AWS_account_ID:domains/your_profiles_domain_name/profiles/profile_ID`. When not required, the field is optional and can be omitted, added, changed, or removed after case creation.
 */
export declare const createCase: API.OperationMethod<CreateCaseRequest & RegionInput, CreateCaseResponse, CreateCaseError, Credentials | HttpClient.HttpClient>;
export type CreateCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new case rule. In the Connect Customer admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const createCaseRule: API.OperationMethod<CreateCaseRuleRequest & RegionInput, CreateCaseRuleResponse, CreateCaseRuleError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain, which is a container for all case data, such as cases, fields, templates and layouts. Each Connect Customer instance can be associated with only one Cases domain.
 *
 * This will not associate your connect instance to Cases domain. Instead, use the Connect Customer CreateIntegrationAssociation API. You need specific IAM permissions to successfully associate the Cases domain. For more information, see Onboard to Cases.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a field in the Cases domain. This field is used to define the case object model (that is, defines what data can be captured on cases) in a Cases domain.
 */
export declare const createField: API.OperationMethod<CreateFieldRequest & RegionInput, CreateFieldResponse, CreateFieldError, Credentials | HttpClient.HttpClient>;
export type CreateLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a layout in the Cases domain. Layouts define the following configuration in the top section and More Info tab of the Cases user interface:
 *
 * - Fields to display to the users
 *
 * - Field ordering
 *
 * Title and Status fields cannot be part of layouts since they are not configurable.
 */
export declare const createLayout: API.OperationMethod<CreateLayoutRequest & RegionInput, CreateLayoutResponse, CreateLayoutError, Credentials | HttpClient.HttpClient>;
export type CreateRelatedItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a related item (comments, tasks, and contacts) and associates it with a case.
 *
 * There's a quota for the number of fields allowed in a Custom type related item. See Connect Customer Cases quotas.
 *
 * **Use cases**
 *
 * Following are examples of related items that you may want to associate with a case:
 *
 * - Related contacts, such as calls, chats, emails tasks
 *
 * - Comments, for agent notes
 *
 * - SLAs, to capture target resolution goals
 *
 * - Cases, to capture related Connect Customer Cases
 *
 * - Files, such as policy documentation or customer-provided attachments
 *
 * - Custom related items, which provide flexibility for you to define related items that such as bookings, orders, products, notices, and more
 *
 * **Important things to know**
 *
 * - If you are associating a contact to a case by passing in `Contact` for a `type`, you must have DescribeContact permission on the ARN of the contact that you provide in `content.contact.contactArn`.
 *
 * - A Related Item is a resource that is associated with a case. It may or may not have an external identifier linking it to an external resource (for example, a `contactArn`). All Related Items have their own internal identifier, the `relatedItemArn`. Examples of related items include `comments` and `contacts`.
 *
 * - If you provide a value for `performedBy.userArn`, you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * - If the case is the secondary case of a merge that is running, the request fails with a `ConflictException`. For more information, see StartMergeCases.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const createRelatedItem: API.OperationMethod<CreateRelatedItemRequest & RegionInput, CreateRelatedItemResponse, CreateRelatedItemError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a template in the Cases domain. This template is used to define the case object model (that is, to define what data can be captured on cases) in a Cases domain. A template must have a unique name within a domain, and it must reference existing field IDs and layout IDs. Additionally, multiple fields with same IDs are not allowed within the same Template. A template can be either Active or Inactive, as indicated by its status. Inactive templates cannot be used to create cases.
 *
 * Other template APIs are:
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - ListTemplates
 *
 * - UpdateTemplate
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest & RegionInput, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The DeleteCase API permanently deletes a case and all its associated resources from the cases data store. After a successful deletion, you cannot:
 *
 * - Retrieve related items
 *
 * - Access audit history
 *
 * - Perform any operations that require the CaseID
 *
 * You can't delete a case while it's part of a merge that is running, as either the primary or the secondary case. The request fails with a `ConflictException`. For more information, see StartMergeCases.
 *
 * This action is irreversible. After you delete a case, you cannot recover its data.
 */
export declare const deleteCase: API.OperationMethod<DeleteCaseRequest & RegionInput, DeleteCaseResponse, DeleteCaseError, Credentials | HttpClient.HttpClient>;
export type DeleteCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a case rule. In the Connect Customer admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const deleteCaseRule: API.OperationMethod<DeleteCaseRuleRequest & RegionInput, DeleteCaseRuleResponse, DeleteCaseRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Cases domain.
 *
 * After deleting your domain you must disassociate the deleted domain from your Connect Customer instance with another API call before being able to use Cases again with this Connect Customer instance. See DeleteIntegrationAssociation.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a field from a Cases template.
 *
 * After a field is deleted:
 *
 * - You can still retrieve the field by calling `BatchGetField`.
 *
 * - You cannot update a deleted field by calling `UpdateField`; it throws a `ValidationException`.
 *
 * - Deleted fields are not included in the `ListFields` response.
 *
 * - Calling `CreateCase` with a deleted field throws a `ValidationException` denoting which field identifiers in the request have been deleted.
 *
 * - Calling `GetCase` with a deleted field identifier returns the deleted field's value if one exists.
 *
 * - Calling `UpdateCase` with a deleted field ID throws a `ValidationException` if the case does not already contain a value for the deleted field. Otherwise it succeeds, allowing you to update or remove (using `emptyValue: {}`) the field's value from the case.
 *
 * - `GetTemplate` does not return field IDs for deleted fields.
 *
 * - `GetLayout` does not return field IDs for deleted fields.
 *
 * - Calling `SearchCases` with the deleted field ID as a filter returns any cases that have a value for the deleted field that matches the filter criteria.
 *
 * - Calling `SearchCases` with a `searchTerm` value that matches a deleted field's value on a case returns the case in the response.
 *
 * - Calling `BatchPutFieldOptions` with a deleted field ID throw a `ValidationException`.
 *
 * - Calling `GetCaseEventConfiguration` does not return field IDs for deleted fields.
 */
export declare const deleteField: API.OperationMethod<DeleteFieldRequest & RegionInput, DeleteFieldResponse, DeleteFieldError, Credentials | HttpClient.HttpClient>;
export type DeleteLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a layout from a Cases template. You can delete up to 100 layouts per domain.
 *
 * After a layout is deleted:
 *
 * - You can still retrieve the layout by calling `GetLayout`.
 *
 * - You cannot update a deleted layout by calling `UpdateLayout`; it throws a `ValidationException`.
 *
 * - Deleted layouts are not included in the `ListLayouts` response.
 */
export declare const deleteLayout: API.OperationMethod<DeleteLayoutRequest & RegionInput, DeleteLayoutResponse, DeleteLayoutError, Credentials | HttpClient.HttpClient>;
export type DeleteRelatedItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the related item resource under a case.
 *
 * This API cannot be used on a FILE type related attachment. To delete this type of file, use the DeleteAttachedFile API
 *
 * If the case is the secondary case of a merge that is running, the request fails with a `ConflictException`. For more information, see StartMergeCases.
 */
export declare const deleteRelatedItem: API.OperationMethod<DeleteRelatedItemRequest & RegionInput, DeleteRelatedItemResponse, DeleteRelatedItemError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Cases template. You can delete up to 100 templates per domain.
 *
 * After a Cases template is deleted:
 *
 * - You can still retrieve the template by calling `GetTemplate`.
 *
 * - You cannot update the template.
 *
 * - You cannot create a case by using the deleted template.
 *
 * - Deleted templates are not included in the `ListTemplates` response.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest & RegionInput, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific case if it exists.
 */
export declare const getCase: API.PaginatedOperationMethod<GetCaseRequest & RegionInput, GetCaseResponse, GetCaseError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCaseAuditEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the audit history about a specific case if it exists.
 */
export declare const getCaseAuditEvents: API.PaginatedOperationMethod<GetCaseAuditEventsRequest & RegionInput, GetCaseAuditEventsResponse, GetCaseAuditEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCaseEventConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the case event publishing configuration.
 */
export declare const getCaseEventConfiguration: API.OperationMethod<GetCaseEventConfigurationRequest & RegionInput, GetCaseEventConfigurationResponse, GetCaseEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific domain if it exists.
 */
export declare const getDomain: API.OperationMethod<GetDomainRequest & RegionInput, GetDomainResponse, GetDomainError, Credentials | HttpClient.HttpClient>;
export type GetLayoutError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details for the requested layout.
 */
export declare const getLayout: API.OperationMethod<GetLayoutRequest & RegionInput, GetLayoutResponse, GetLayoutError, Credentials | HttpClient.HttpClient>;
export type GetMergeCasesStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the merge status of a case. Use this operation to track a merge that you started with StartMergeCases, or to check whether a case is part of a merge before you modify it.
 *
 * The operation returns the following, depending on the case:
 *
 * - For the primary case or the secondary case of a merge that is running, it returns `IN_PROGRESS`.
 *
 * - For a case that was merged into another case as the secondary case, it returns `COMPLETED`.
 *
 * - For any other case, it returns a `ResourceNotFoundException`. This includes the primary case after its merge finishes.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const getMergeCasesStatus: API.OperationMethod<GetMergeCasesStatusRequest & RegionInput, GetMergeCasesStatusResponse, GetMergeCasesStatusError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details for the requested template. Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - ListTemplates
 *
 * - UpdateTemplate
 */
export declare const getTemplate: API.OperationMethod<GetTemplateRequest & RegionInput, GetTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type ListCaseRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all case rules in a Cases domain. In the Connect Customer admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const listCaseRules: API.PaginatedOperationMethod<ListCaseRulesRequest & RegionInput, ListCaseRulesResponse, ListCaseRulesError, Credentials | HttpClient.HttpClient, CaseRuleSummary>;
export type ListCasesForContactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists cases for a given contact.
 */
export declare const listCasesForContact: API.PaginatedOperationMethod<ListCasesForContactRequest & RegionInput, ListCasesForContactResponse, ListCasesForContactError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all cases domains in the Amazon Web Services account. Each list item is a condensed summary object of the domain.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest & RegionInput, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFieldOptionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the field options for a field identifier in the domain.
 */
export declare const listFieldOptions: API.PaginatedOperationMethod<ListFieldOptionsRequest & RegionInput, ListFieldOptionsResponse, ListFieldOptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFieldsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all fields in a Cases domain.
 */
export declare const listFields: API.PaginatedOperationMethod<ListFieldsRequest & RegionInput, ListFieldsResponse, ListFieldsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLayoutsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all layouts in the given cases domain. Each list item is a condensed summary object of the layout.
 */
export declare const listLayouts: API.PaginatedOperationMethod<ListLayoutsRequest & RegionInput, ListLayoutsResponse, ListLayoutsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the templates in a Cases domain. Each list item is a condensed summary object of the template.
 *
 * Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - UpdateTemplate
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListTemplatesRequest & RegionInput, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutCaseEventConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds case event publishing configuration. For a complete list of fields you can add to the event message, see Create case fields in the *Connect Customer Administrator Guide*.
 */
export declare const putCaseEventConfiguration: API.OperationMethod<PutCaseEventConfigurationRequest & RegionInput, PutCaseEventConfigurationResponse, PutCaseEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type SearchAllRelatedItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for related items across all cases within a domain. This is a global search operation that returns related items from multiple cases, unlike the case-specific SearchRelatedItems API.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Find cases with similar issues across the domain. For example, search for all cases containing comments about "product defect" to identify patterns and existing solutions.
 *
 * - Locate all cases associated with specific contacts or orders. For example, find all cases linked to a contactArn to understand the complete customer journey.
 *
 * - Monitor SLA compliance across cases. For example, search for all cases with "Active" SLA status to prioritize remediation efforts.
 *
 * **Important things to know**
 *
 * - This API returns case identifiers, not complete case objects. To retrieve full case details, you must make additional calls to the GetCase API for each returned case ID.
 *
 * - This API searches across related items content, not case fields. Use the SearchCases API to search within case field values.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchAllRelatedItems: API.PaginatedOperationMethod<SearchAllRelatedItemsRequest & RegionInput, SearchAllRelatedItemsResponse, SearchAllRelatedItemsError, Credentials | HttpClient.HttpClient, SearchAllRelatedItemsResponseItem>;
export type SearchCasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for cases within their associated Cases domain. Search results are returned as a paginated list of abridged case documents.
 *
 * For `customer_id` you must provide the full customer profile ARN in this format: ` arn:aws:profile:your AWS Region:your AWS account ID:domains/profiles domain name/profiles/profile ID`.
 */
export declare const searchCases: API.PaginatedOperationMethod<SearchCasesRequest & RegionInput, SearchCasesResponse, SearchCasesError, Credentials | HttpClient.HttpClient, SearchCasesResponseItem>;
export type SearchRelatedItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for related items that are associated with a case.
 *
 * If no filters are provided, this returns all related items associated with a case.
 */
export declare const searchRelatedItems: API.PaginatedOperationMethod<SearchRelatedItemsRequest & RegionInput, SearchRelatedItemsResponse, SearchRelatedItemsError, Credentials | HttpClient.HttpClient, SearchRelatedItemsResponseItem>;
export type StartMergeCasesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Merges a secondary case into a primary case. The primary case, which you specify in the request URI, remains active. Both cases must belong to the same domain.
 *
 * The merge runs asynchronously. To track its progress, call GetMergeCasesStatus. When the merge finishes, the selected field values and related items from the secondary case are on the primary case, the two cases are linked, and the secondary case is closed. Both cases record the merge in their audit history. For more information, see GetCaseAuditEvents.
 *
 * **Important things to know**
 *
 * - Both cases must have the same customer, or at least one of them must have no customer.
 *
 * - While the merge runs, you can't modify the secondary case or its related items, and you can't delete the primary case. These requests return a `ConflictException`.
 *
 * - After the merge, the secondary case can be reopened, updated, and deleted, but it can't be merged again.
 *
 * The request fails with a `ValidationException`, and no merge starts, if:
 *
 * - The primary case and the secondary case are the same case.
 *
 * - Either case is closed.
 *
 * - Both cases have a customer, and the customers are different.
 *
 * - `fieldsConfiguration` selects a field that can't be merged, or a field that the secondary case doesn't have.
 *
 * - After the merge, the primary case would have more than 500 field values, or would exceed the maximum case size.
 *
 * The request fails with a `ServiceQuotaExceededException` if, after the merge, either case would exceed the quota for related items per case. For the primary case, the count is its existing related items, plus the related items moved from the secondary case, plus the new case link. See Connect Customer Cases quotas.
 *
 * The request fails with a `ConflictException` if either case is already part of a merge that is running, or was previously merged into another case as the secondary case.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const startMergeCases: API.OperationMethod<StartMergeCasesRequest & RegionInput, StartMergeCasesResponse, StartMergeCasesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untags a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * If you provide a value for `PerformedBy.UserArn`, you must also have the connect:DescribeUser permission on the user ARN that you provide.
 *
 * Updates the values of fields on a case. Fields to be updated are received as an array of id/value pairs identical to the `CreateCase` input.
 *
 * If the case is the secondary case of a merge that is running, the request fails with a `ConflictException`. For more information, see StartMergeCases.
 *
 * If the action is successful, the service sends back an HTTP 200 response with an empty HTTP body.
 */
export declare const updateCase: API.OperationMethod<UpdateCaseRequest & RegionInput, UpdateCaseResponse, UpdateCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCaseRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a case rule. In the Connect Customer admin website, case rules are known as *case field conditions*. For more information about case field conditions, see Add case field conditions to a case template.
 */
export declare const updateCaseRule: API.OperationMethod<UpdateCaseRuleRequest & RegionInput, UpdateCaseRuleResponse, UpdateCaseRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an existing field.
 */
export declare const updateField: API.OperationMethod<UpdateFieldRequest & RegionInput, UpdateFieldResponse, UpdateFieldError, Credentials | HttpClient.HttpClient>;
export type UpdateLayoutError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing layout.
 *
 * If the action is successful, the service sends back an HTTP 200 response with an empty HTTP body.
 *
 * A `ValidationException` is returned when you add non-existent `fieldIds` to a layout.
 *
 * Title and Status fields cannot be part of layouts because they are not configurable.
 */
export declare const updateLayout: API.OperationMethod<UpdateLayoutRequest & RegionInput, UpdateLayoutResponse, UpdateLayoutError, Credentials | HttpClient.HttpClient>;
export type UpdateRelatedItemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the content of a related item associated with a case. The following related item types are supported:
 *
 * - **Comment** - Update the text content of an existing comment
 *
 * - **Custom** - Update the fields of a custom related item. You can add, modify, and remove fields from a custom related item. There's a quota for the number of fields allowed in a Custom type related item. See Connect Customer Cases quotas.
 *
 * **Important things to know**
 *
 * - When updating a Custom related item, all existing and new fields, and their associated values should be included in the request. Fields not included as part of this request will be removed.
 *
 * - If you provide a value for `performedBy.userArn`, you must also have DescribeUser permission on the ARN of the user that you provide.
 *
 * - System case fields cannot be used in a custom related item.
 *
 * - If the case is the secondary case of a merge that is running, the request fails with a `ConflictException`. For more information, see StartMergeCases.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const updateRelatedItem: API.OperationMethod<UpdateRelatedItemRequest & RegionInput, UpdateRelatedItemResponse, UpdateRelatedItemError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the attributes of an existing template. The template attributes that can be modified include `name`, `description`, `layoutConfiguration`, `requiredFields`, and `status`. At least one of these attributes must not be null. If a null value is provided for a given attribute, that attribute is ignored and its current value is preserved.
 *
 * Other template APIs are:
 *
 * - CreateTemplate
 *
 * - DeleteTemplate
 *
 * - GetTemplate
 *
 * - ListTemplates
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest & RegionInput, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcases.d.ts.map