import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CapacityTaskId = string;
export type OutpostIdentifier = string;
export interface CancelCapacityTaskInput {
    CapacityTaskId: string;
    OutpostIdentifier: string;
}
export interface CancelCapacityTaskOutput {
}
export type OrderId = string;
export interface CancelOrderInput {
    OrderId: string;
}
export interface CancelOrderOutput {
}
export type QuoteIdentifier = string;
export type QuoteOptionIdentifier = string;
export type SkuCode = string;
export type LineItemQuantity = number;
export interface LineItemRequest {
    CatalogItemId?: string | undefined;
    Quantity?: number | undefined;
}
export type LineItemRequestListDefinition = LineItemRequest[];
export type PaymentOption = "ALL_UPFRONT" | "NO_UPFRONT" | "PARTIAL_UPFRONT" | (string & {});
export type PaymentTerm = "THREE_YEARS" | "ONE_YEAR" | "FIVE_YEARS" | (string & {});
export interface CreateOrderInput {
    OutpostIdentifier: string;
    QuoteIdentifier?: string | undefined;
    QuoteOptionIdentifier?: string | undefined;
    LineItems?: LineItemRequest[] | undefined;
    PaymentOption: PaymentOption;
    PaymentTerm?: PaymentTerm | undefined;
}
export type OutpostIdOnly = string;
export type OrderStatus = "RECEIVED" | "PENDING" | "PROCESSING" | "INSTALLING" | "FULFILLED" | "CANCELLED" | "PREPARING" | "IN_PROGRESS" | "DELIVERED" | "COMPLETED" | "ERROR" | (string & {});
export type LineItemId = string;
export type LineItemStatus = "PREPARING" | "BUILDING" | "SHIPPED" | "DELIVERED" | "INSTALLING" | "INSTALLED" | "ERROR" | "CANCELLED" | "REPLACED" | (string & {});
export type TrackingId = string;
export type ShipmentCarrier = "DHL" | "DBS" | "FEDEX" | "UPS" | "EXPEDITORS" | (string & {});
export interface ShipmentInformation {
    ShipmentTrackingNumber?: string | undefined;
    ShipmentCarrier?: ShipmentCarrier | undefined;
}
export type AssetId = string;
export type MacAddress = string;
export type MacAddressList = string[];
export interface LineItemAssetInformation {
    AssetId?: string | undefined;
    MacAddressList?: string[] | undefined;
}
export type LineItemAssetInformationList = LineItemAssetInformation[];
export interface LineItem {
    CatalogItemId?: string | undefined;
    LineItemId?: string | undefined;
    Quantity?: number | undefined;
    Status?: LineItemStatus | undefined;
    ShipmentInformation?: ShipmentInformation | undefined;
    AssetInformationList?: LineItemAssetInformation[] | undefined;
    PreviousLineItemId?: string | undefined;
    PreviousOrderId?: string | undefined;
}
export type LineItemListDefinition = LineItem[];
export type ISO8601Timestamp = Date;
export type OrderType = "OUTPOST" | "REPLACEMENT" | (string & {});
export interface Order {
    OutpostId?: string | undefined;
    QuoteIdentifier?: string | undefined;
    QuoteOptionIdentifier?: string | undefined;
    OrderId?: string | undefined;
    Status?: OrderStatus | undefined;
    LineItems?: LineItem[] | undefined;
    PaymentOption?: PaymentOption | undefined;
    OrderSubmissionDate?: Date | undefined;
    OrderFulfilledDate?: Date | undefined;
    PaymentTerm?: PaymentTerm | undefined;
    OrderType?: OrderType | undefined;
}
export interface CreateOrderOutput {
    Order?: Order | undefined;
}
export type OutpostName = string;
export type OutpostDescription = string;
export type SiteId = string;
export type AvailabilityZone = string;
export type AvailabilityZoneId = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type SupportedHardwareType = "RACK" | "SERVER" | (string & {});
export interface CreateOutpostInput {
    Name: string;
    Description?: string | undefined;
    SiteId: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SupportedHardwareType?: SupportedHardwareType | undefined;
}
export type OutpostId = string;
export type OwnerId = string;
export type OutpostArn = string;
export type LifeCycleStatus = string;
export type SiteArn = string;
export type OutpostGeneration = "GENERATION_2" | "GENERATION_1" | (string & {});
export type RackScalingType = "SINGLE_RACK" | "MULTI_RACK" | (string & {});
export interface Outpost {
    OutpostId?: string | undefined;
    OwnerId?: string | undefined;
    OutpostArn?: string | undefined;
    SiteId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    LifeCycleStatus?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SiteArn?: string | undefined;
    SupportedHardwareType?: SupportedHardwareType | undefined;
    Generation?: OutpostGeneration | undefined;
    RackScalingType?: RackScalingType | undefined;
}
export interface CreateOutpostOutput {
    Outpost?: Outpost | undefined;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type VpcEndpointId = string;
export interface VpcInformation {
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    VpcEndpointId?: string | undefined;
}
export type VpcInformationList = VpcInformation[];
export interface CreatePrivateConnectivityConfigInput {
    OutpostId: string;
    VpcInformationList: VpcInformation[];
}
export type RoleArn = string;
export type PrivateConnectivityStatus = "ENABLED" | "DISABLED" | (string & {});
export interface PrivateConnectivityConfig {
    RoleArn?: string | undefined;
    PrivateConnectivityStatus?: PrivateConnectivityStatus | undefined;
    VpcInformationList?: VpcInformation[] | undefined;
    ProvisioningRoleArn?: string | undefined;
}
export interface CreatePrivateConnectivityConfigOutput {
    PrivateConnectivityConfig?: PrivateConnectivityConfig | undefined;
    OutpostId?: string | undefined;
}
export type CountryCode = string;
export type QuoteCapacityType = "EC2" | "EBS" | "S3" | (string & {});
export interface QuoteCapacity {
    QuoteCapacityType?: QuoteCapacityType | undefined;
    Unit?: string | undefined;
    Quantity?: number | undefined;
}
export type QuoteCapacityList = QuoteCapacity[];
export type QuoteConstraintType = "RACK_MAXIMUM" | "RACK_MAX_POWER_KVA" | "RACK_MAX_WEIGHT_LBS" | "RACK_SPACE_CONSTRAINED" | (string & {});
export type ConstraintValue = string;
export interface QuoteConstraint {
    QuoteConstraintType?: QuoteConstraintType | undefined;
    Value?: string | undefined;
}
export type QuoteConstraintList = QuoteConstraint[];
export type PaymentOptionList = PaymentOption[];
export type PaymentTermList = PaymentTerm[];
export type QuoteDescription = string | redacted.Redacted<string>;
export interface CreateQuoteInput {
    OutpostIdentifier?: string | undefined;
    CountryCode: string;
    RequestedCapacities: QuoteCapacity[];
    RequestedConstraints?: QuoteConstraint[] | undefined;
    RequestedPaymentOptions?: PaymentOption[] | undefined;
    RequestedPaymentTerms?: PaymentTerm[] | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type QuoteId = string;
export type AccountId = string;
export type QuoteStatus = "CREATED" | "ORDER_SUBMITTED" | "EXPIRED" | (string & {});
export type StatusMessage = string;
export interface CapacitySummary {
    ExistingCapacities?: QuoteCapacity[] | undefined;
    FinalCapacities?: QuoteCapacity[] | undefined;
    CapacityChange?: QuoteCapacity[] | undefined;
}
export type QuoteSpecificationType = "UPDATED_RACK" | "NEW_RACK" | "EXISTING_RACK" | "SERVER" | (string & {});
export type RackId = string;
export type QuoteRackUseType = "NETWORKING" | "COMPUTE" | (string & {});
export type RackUnitHeight = "HEIGHT_42U" | "HEIGHT_2U" | "HEIGHT_1U" | (string & {});
export type Family = string;
export type MaxSize = string;
export type Quantity = string;
export interface EC2Capacity {
    Family?: string | undefined;
    MaxSize?: string | undefined;
    Quantity?: string | undefined;
}
export type EC2CapacityListDefinition = EC2Capacity[];
export interface RackSpecificationDetails {
    RackId?: string | undefined;
    RackUse?: QuoteRackUseType | undefined;
    RackPowerDrawKva?: number | undefined;
    RackWeightLbs?: number | undefined;
    RackHeightInches?: number | undefined;
    RackWidthInches?: number | undefined;
    RackDepthInches?: number | undefined;
    RackUnitHeight?: RackUnitHeight | undefined;
    EC2Capacities?: EC2Capacity[] | undefined;
}
export interface ServerSpecificationDetails {
    ServerPowerDrawKva?: number | undefined;
    ServerWeightLbs?: number | undefined;
    ServerHeightInches?: number | undefined;
    ServerWidthInches?: number | undefined;
    ServerDepthInches?: number | undefined;
    RackUnitHeight?: RackUnitHeight | undefined;
    EC2Capacities?: EC2Capacity[] | undefined;
}
export interface QuoteSpecification {
    QuoteSpecificationType?: QuoteSpecificationType | undefined;
    ExistingRackSpecificationDetails?: RackSpecificationDetails | undefined;
    FinalRackSpecificationDetails?: RackSpecificationDetails | undefined;
    ServerSpecificationDetails?: ServerSpecificationDetails | undefined;
}
export type QuoteSpecificationList = QuoteSpecification[];
export type QuotePricingType = "SUBSCRIPTION" | (string & {});
export type CurrencyCode = "USD" | (string & {});
export interface SubscriptionPricingDetails {
    PaymentOption?: PaymentOption | undefined;
    PaymentTerm?: PaymentTerm | undefined;
    UpfrontPrice?: number | undefined;
    MonthlyRecurringPrice?: number | undefined;
    Currency?: CurrencyCode | undefined;
}
export interface PricingOption {
    PricingType?: QuotePricingType | undefined;
    SubscriptionPricingDetails?: SubscriptionPricingDetails | undefined;
}
export type PricingOptionList = PricingOption[];
export interface QuoteOption {
    QuoteOptionIdentifier?: string | undefined;
    Capacities?: QuoteCapacity[] | undefined;
    CapacitySummary?: CapacitySummary | undefined;
    Specifications?: QuoteSpecification[] | undefined;
    PricingOptions?: PricingOption[] | undefined;
}
export type QuoteOptionList = QuoteOption[];
export type OrderingRequirementType = "OUTPOST_ACTIVE_CHECK_ERROR" | "MAXIMUM_ALLOWED_ORDERS_CHECK_ERROR" | "VALID_ZIP_CODE_CHECK_ERROR" | "RACK_PHYSICAL_PROPERTIES_CHECK_ERROR" | "OPERATING_ADDRESS_EXISTENCE_CHECK_ERROR" | "SHIPPING_ADDRESS_EXISTENCE_CHECK_ERROR" | "COUNTRY_CODE_MISMATCH_CHECK_ERROR" | "OUTPOST_GENERATION_MISMATCH_ERROR" | "UNSUPPORTED" | "OUTPOST_ID_MISSING_ON_QUOTE_ERROR" | "ENTERPRISE_SUPPORT_ERROR" | "SHIPPING_ADDRESS_MISSING_CONTACT_NAME_ERROR" | "SHIPPING_ADDRESS_MISSING_CONTACT_NUMBER_ERROR" | "SHIPPING_ADDRESS_MISSING_CONTACT_INFO_ERROR" | "OUTPOST_STATE_CHANGED_ERROR" | "OUTPOST_NOT_FOUND_ERROR" | "OUTPOST_RENEWAL_REQUIRED_ERROR" | (string & {});
export type OrderingRequirementStatus = "PASS" | "FAIL" | "EXEMPT" | (string & {});
export interface OrderingRequirement {
    StatusMessage?: string | undefined;
    OrderingRequirementType?: OrderingRequirementType | undefined;
    Status?: OrderingRequirementStatus | undefined;
}
export type OrderingRequirementList = OrderingRequirement[];
export type OrderIdentifier = string;
export interface Quote {
    QuoteId?: string | undefined;
    AccountId?: string | undefined;
    QuoteStatus?: QuoteStatus | undefined;
    StatusMessage?: string | undefined;
    OutpostArn?: string | undefined;
    CountryCode?: string | undefined;
    RequestedCapacities?: QuoteCapacity[] | undefined;
    RequestedConstraints?: QuoteConstraint[] | undefined;
    RequestedPaymentOptions?: PaymentOption[] | undefined;
    RequestedPaymentTerms?: PaymentTerm[] | undefined;
    QuoteOptions?: QuoteOption[] | undefined;
    OrderingRequirements?: OrderingRequirement[] | undefined;
    SubmittedOrderId?: string | undefined;
    CreatedDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export interface CreateQuoteOutput {
    Quote?: Quote | undefined;
}
export type AutoFillIdempotencyToken = string;
export interface CreateRenewalInput {
    PaymentOption: PaymentOption;
    PaymentTerm: PaymentTerm;
    OutpostIdentifier: string;
    ClientToken?: string | undefined;
}
export interface CreateRenewalOutput {
    PaymentOption?: PaymentOption | undefined;
    PaymentTerm?: PaymentTerm | undefined;
    OutpostId?: string | undefined;
    UpfrontPrice?: number | undefined;
    MonthlyRecurringPrice?: number | undefined;
    Currency?: CurrencyCode | undefined;
}
export type SiteName = string;
export type SiteDescription = string;
export type SiteNotes = string;
export type ContactName = string;
export type ContactPhoneNumber = string;
export type AddressLine1 = string;
export type AddressLine2 = string;
export type AddressLine3 = string;
export type City = string;
export type StateOrRegion = string;
export type DistrictOrCounty = string;
export type PostalCode = string;
export type Municipality = string;
export interface Address {
    ContactName: string;
    ContactPhoneNumber: string;
    AddressLine1: string;
    AddressLine2?: string | undefined;
    AddressLine3?: string | undefined;
    City: string;
    StateOrRegion: string;
    DistrictOrCounty?: string | undefined;
    PostalCode: string;
    CountryCode: string;
    Municipality?: string | undefined;
}
export type PowerDrawKva = "POWER_5_KVA" | "POWER_10_KVA" | "POWER_15_KVA" | "POWER_30_KVA" | (string & {});
export type PowerPhase = "SINGLE_PHASE" | "THREE_PHASE" | (string & {});
export type PowerConnector = "L6_30P" | "IEC309" | "AH530P7W" | "AH532P6W" | "CS8365C" | (string & {});
export type PowerFeedDrop = "ABOVE_RACK" | "BELOW_RACK" | (string & {});
export type UplinkGbps = "UPLINK_1G" | "UPLINK_10G" | "UPLINK_40G" | "UPLINK_100G" | (string & {});
export type UplinkCount = "UPLINK_COUNT_1" | "UPLINK_COUNT_2" | "UPLINK_COUNT_3" | "UPLINK_COUNT_4" | "UPLINK_COUNT_5" | "UPLINK_COUNT_6" | "UPLINK_COUNT_7" | "UPLINK_COUNT_8" | "UPLINK_COUNT_12" | "UPLINK_COUNT_16" | (string & {});
export type FiberOpticCableType = "SINGLE_MODE" | "MULTI_MODE" | (string & {});
export type OpticalStandard = "OPTIC_10GBASE_SR" | "OPTIC_10GBASE_IR" | "OPTIC_10GBASE_LR" | "OPTIC_40GBASE_SR" | "OPTIC_40GBASE_ESR" | "OPTIC_40GBASE_IR4_LR4L" | "OPTIC_40GBASE_LR4" | "OPTIC_100GBASE_SR4" | "OPTIC_100GBASE_CWDM4" | "OPTIC_100GBASE_LR4" | "OPTIC_100G_PSM4_MSA" | "OPTIC_1000BASE_LX" | "OPTIC_1000BASE_SX" | (string & {});
export type MaximumSupportedWeightLbs = "NO_LIMIT" | "MAX_1400_LBS" | "MAX_1600_LBS" | "MAX_1800_LBS" | "MAX_2000_LBS" | (string & {});
export interface RackPhysicalProperties {
    PowerDrawKva?: PowerDrawKva | undefined;
    PowerPhase?: PowerPhase | undefined;
    PowerConnector?: PowerConnector | undefined;
    PowerFeedDrop?: PowerFeedDrop | undefined;
    UplinkGbps?: UplinkGbps | undefined;
    UplinkCount?: UplinkCount | undefined;
    FiberOpticCableType?: FiberOpticCableType | undefined;
    OpticalStandard?: OpticalStandard | undefined;
    MaximumSupportedWeightLbs?: MaximumSupportedWeightLbs | undefined;
}
export interface CreateSiteInput {
    Name: string;
    Description?: string | undefined;
    Notes?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    OperatingAddress?: Address | undefined;
    ShippingAddress?: Address | undefined;
    RackPhysicalProperties?: RackPhysicalProperties | undefined;
}
export interface Site {
    SiteId?: string | undefined;
    AccountId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    SiteArn?: string | undefined;
    Notes?: string | undefined;
    OperatingAddressCountryCode?: string | undefined;
    OperatingAddressStateOrRegion?: string | undefined;
    OperatingAddressCity?: string | undefined;
    RackPhysicalProperties?: RackPhysicalProperties | undefined;
}
export interface CreateSiteOutput {
    Site?: Site | undefined;
}
export interface DeleteOutpostInput {
    OutpostId: string;
}
export interface DeleteOutpostOutput {
}
export interface DeleteQuoteInput {
    QuoteIdentifier: string;
}
export interface DeleteQuoteOutput {
}
export interface DeleteSiteInput {
    SiteId: string;
}
export interface DeleteSiteOutput {
}
export interface GetCapacityTaskInput {
    CapacityTaskId: string;
    OutpostIdentifier: string;
}
export type InstanceTypeName = string;
export type InstanceTypeCount = number;
export interface InstanceTypeCapacity {
    InstanceType: string;
    Count: number;
}
export type RequestedInstancePools = InstanceTypeCapacity[];
export type InstanceId = string;
export type InstanceIdList = string[];
export type AccountIdList = string[];
export type AWSServiceName = "AWS" | "EC2" | "EKS" | "ELASTICACHE" | "ELB" | "RDS" | "ROUTE53" | (string & {});
export type AWSServiceNameList = AWSServiceName[];
export interface InstancesToExclude {
    Instances?: string[] | undefined;
    AccountIds?: string[] | undefined;
    Services?: AWSServiceName[] | undefined;
}
export type DryRun = boolean;
export type CapacityTaskStatus = "REQUESTED" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | "WAITING_FOR_EVACUATION" | "CANCELLATION_IN_PROGRESS" | "CANCELLED" | (string & {});
export type CapacityTaskStatusReason = string;
export type CapacityTaskFailureType = "UNSUPPORTED_CAPACITY_CONFIGURATION" | "UNEXPECTED_ASSET_STATE" | "BLOCKING_INSTANCES_NOT_EVACUATED" | "INTERNAL_SERVER_ERROR" | "RESOURCE_NOT_FOUND" | (string & {});
export interface CapacityTaskFailure {
    Reason: string;
    Type?: CapacityTaskFailureType | undefined;
}
export type TaskActionOnBlockingInstances = "WAIT_FOR_EVACUATION" | "FAIL_TASK" | (string & {});
export interface GetCapacityTaskOutput {
    CapacityTaskId?: string | undefined;
    OutpostId?: string | undefined;
    OrderId?: string | undefined;
    AssetId?: string | undefined;
    RequestedInstancePools?: InstanceTypeCapacity[] | undefined;
    InstancesToExclude?: InstancesToExclude | undefined;
    DryRun?: boolean | undefined;
    CapacityTaskStatus?: CapacityTaskStatus | undefined;
    Failed?: CapacityTaskFailure | undefined;
    CreationDate?: Date | undefined;
    CompletionDate?: Date | undefined;
    LastModifiedDate?: Date | undefined;
    TaskActionOnBlockingInstances?: TaskActionOnBlockingInstances | undefined;
}
export interface GetCatalogItemInput {
    CatalogItemId: string;
}
export type CatalogItemStatus = "AVAILABLE" | "DISCONTINUED" | (string & {});
export type CatalogItemPowerKva = number;
export type CatalogItemWeightLbs = number;
export type SupportedUplinkGbps = number;
export type SupportedUplinkGbpsListDefinition = number[];
export type SupportedStorageEnum = "EBS" | "S3" | (string & {});
export type SupportedStorageList = SupportedStorageEnum[];
export interface CatalogItem {
    CatalogItemId?: string | undefined;
    ItemStatus?: CatalogItemStatus | undefined;
    EC2Capacities?: EC2Capacity[] | undefined;
    PowerKva?: number | undefined;
    WeightLbs?: number | undefined;
    SupportedUplinkGbps?: number[] | undefined;
    SupportedStorage?: SupportedStorageEnum[] | undefined;
    RackScalingType?: RackScalingType | undefined;
}
export interface GetCatalogItemOutput {
    CatalogItem?: CatalogItem | undefined;
}
export type ConnectionId = string;
export interface GetConnectionRequest {
    ConnectionId: string;
}
export type WireGuardPublicKey = string;
export type ServerEndpoint = string;
export type CIDR = string;
export type CIDRList = string[];
export interface ConnectionDetails {
    ClientPublicKey?: string | undefined;
    ServerPublicKey?: string | undefined;
    ServerEndpoint?: string | undefined;
    ClientTunnelAddress?: string | undefined;
    ServerTunnelAddress?: string | undefined;
    AllowedIps?: string[] | undefined;
}
export interface GetConnectionResponse {
    ConnectionId?: string | undefined;
    ConnectionDetails?: ConnectionDetails | undefined;
}
export interface GetOrderInput {
    OrderId: string;
}
export interface GetOrderOutput {
    Order?: Order | undefined;
}
export interface GetOutpostInput {
    OutpostId: string;
}
export interface GetOutpostOutput {
    Outpost?: Outpost | undefined;
}
export type Token = string;
export type MaxResults1000 = number;
export interface GetOutpostBillingInformationInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    OutpostIdentifier: string;
}
export type SubscriptionType = "ORIGINAL" | "RENEWAL" | "CAPACITY_INCREASE" | (string & {});
export type SubscriptionStatus = "ACTIVE" | "PENDING" | "INACTIVE" | "CANCELLED" | (string & {});
export type OrderIdList = string[];
export interface Subscription {
    SubscriptionId?: string | undefined;
    SubscriptionType?: SubscriptionType | undefined;
    SubscriptionStatus?: SubscriptionStatus | undefined;
    OrderIds?: string[] | undefined;
    BeginDate?: Date | undefined;
    EndDate?: Date | undefined;
    Currency?: CurrencyCode | undefined;
    MonthlyRecurringPrice?: number | undefined;
    UpfrontPrice?: number | undefined;
}
export type SubscriptionList = Subscription[];
export interface GetOutpostBillingInformationOutput {
    NextToken?: string | undefined;
    Subscriptions?: Subscription[] | undefined;
    ContractEndDate?: string | undefined;
    PaymentTerm?: PaymentTerm | undefined;
    PaymentOption?: PaymentOption | undefined;
}
export interface GetOutpostInstanceTypesInput {
    OutpostId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type InstanceType = string;
export type VCPUCount = number;
export interface InstanceTypeItem {
    InstanceType?: string | undefined;
    VCPUs?: number | undefined;
}
export type InstanceTypeListDefinition = InstanceTypeItem[];
export interface GetOutpostInstanceTypesOutput {
    InstanceTypes?: InstanceTypeItem[] | undefined;
    NextToken?: string | undefined;
    OutpostId?: string | undefined;
    OutpostArn?: string | undefined;
}
export type AssetIdInput = string;
export interface GetOutpostSupportedInstanceTypesInput {
    OutpostIdentifier: string;
    OrderId?: string | undefined;
    AssetId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetOutpostSupportedInstanceTypesOutput {
    InstanceTypes?: InstanceTypeItem[] | undefined;
    NextToken?: string | undefined;
}
export interface GetPrivateConnectivityConfigInput {
    OutpostId: string;
}
export interface GetPrivateConnectivityConfigOutput {
    PrivateConnectivityConfig?: PrivateConnectivityConfig | undefined;
}
export interface GetQuoteInput {
    QuoteIdentifier: string;
}
export interface GetQuoteOutput {
    Quote?: Quote | undefined;
}
export interface GetRenewalPricingInput {
    OutpostIdentifier: string;
}
export type PricingResult = "PRICED" | "UNABLE_TO_PRICE" | (string & {});
export interface GetRenewalPricingOutput {
    PricingResult?: PricingResult | undefined;
    PricingOptions?: PricingOption[] | undefined;
}
export interface GetSiteInput {
    SiteId: string;
}
export interface GetSiteOutput {
    Site?: Site | undefined;
}
export type AddressType = "SHIPPING_ADDRESS" | "OPERATING_ADDRESS" | (string & {});
export interface GetSiteAddressInput {
    SiteId: string;
    AddressType: AddressType;
}
export interface GetSiteAddressOutput {
    SiteId?: string | undefined;
    AddressType?: AddressType | undefined;
    Address?: Address | undefined;
}
export type AssetIdList = string[];
export type OutpostInstanceType = string;
export type OutpostInstanceTypeList = string[];
export interface ListAssetInstancesInput {
    OutpostIdentifier: string;
    AssetIdFilter?: string[] | undefined;
    InstanceTypeFilter?: string[] | undefined;
    AccountIdFilter?: string[] | undefined;
    AwsServiceFilter?: AWSServiceName[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AssetInstance {
    InstanceId?: string | undefined;
    InstanceType?: string | undefined;
    AssetId?: string | undefined;
    AccountId?: string | undefined;
    AwsServiceName?: AWSServiceName | undefined;
}
export type AssetInstanceList = AssetInstance[];
export interface ListAssetInstancesOutput {
    AssetInstances?: AssetInstance[] | undefined;
    NextToken?: string | undefined;
}
export type HostId = string;
export type HostIdList = string[];
export type AssetState = "ACTIVE" | "RETIRING" | "ISOLATED" | "INSTALLING" | (string & {});
export type StatusList = AssetState[];
export type AssetType = "COMPUTE" | "STORAGE" | "POWERSHELF" | "SWITCH" | "NETWORKING" | (string & {});
export type AssetTypeList = AssetType[];
export interface ListAssetsInput {
    OutpostIdentifier: string;
    HostIdFilter?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    StatusFilter?: AssetState[] | undefined;
    AssetTypeFilter?: AssetType[] | undefined;
}
export type ComputeAssetState = "ACTIVE" | "ISOLATED" | "RETIRING" | "INSTALLING" | (string & {});
export type InstanceFamilyName = string;
export type InstanceFamilies = string[];
export interface AssetInstanceTypeCapacity {
    InstanceType: string;
    Count: number;
}
export type AssetInstanceCapacityList = AssetInstanceTypeCapacity[];
export interface ComputeAttributes {
    HostId?: string | undefined;
    State?: ComputeAssetState | undefined;
    InstanceFamilies?: string[] | undefined;
    InstanceTypeCapacities?: AssetInstanceTypeCapacity[] | undefined;
    MaxVcpus?: number | undefined;
}
export type RackElevation = number;
export interface AssetLocation {
    RackElevation?: number | undefined;
}
export interface AssetInfo {
    AssetId?: string | undefined;
    RackId?: string | undefined;
    AssetType?: AssetType | undefined;
    ComputeAttributes?: ComputeAttributes | undefined;
    AssetLocation?: AssetLocation | undefined;
}
export type AssetListDefinition = AssetInfo[];
export interface ListAssetsOutput {
    Assets?: AssetInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListBlockingInstancesForCapacityTaskInput {
    OutpostIdentifier: string;
    CapacityTaskId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface BlockingInstance {
    InstanceId?: string | undefined;
    AccountId?: string | undefined;
    AwsServiceName?: AWSServiceName | undefined;
}
export type BlockingInstancesList = BlockingInstance[];
export interface ListBlockingInstancesForCapacityTaskOutput {
    BlockingInstances?: BlockingInstance[] | undefined;
    NextToken?: string | undefined;
}
export type CapacityTaskStatusList = CapacityTaskStatus[];
export interface ListCapacityTasksInput {
    OutpostIdentifierFilter?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    CapacityTaskStatusFilter?: CapacityTaskStatus[] | undefined;
}
export interface CapacityTaskSummary {
    CapacityTaskId?: string | undefined;
    OutpostId?: string | undefined;
    OrderId?: string | undefined;
    AssetId?: string | undefined;
    CapacityTaskStatus?: CapacityTaskStatus | undefined;
    CreationDate?: Date | undefined;
    CompletionDate?: Date | undefined;
    LastModifiedDate?: Date | undefined;
}
export type CapacityTaskList = CapacityTaskSummary[];
export interface ListCapacityTasksOutput {
    CapacityTasks?: CapacityTaskSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CatalogItemClass = "RACK" | "SERVER" | (string & {});
export type CatalogItemClassList = CatalogItemClass[];
export type EC2FamilyList = string[];
export interface ListCatalogItemsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ItemClassFilter?: CatalogItemClass[] | undefined;
    SupportedStorageFilter?: SupportedStorageEnum[] | undefined;
    EC2FamilyFilter?: string[] | undefined;
}
export type CatalogItemListDefinition = CatalogItem[];
export interface ListCatalogItemsOutput {
    CatalogItems?: CatalogItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOrderableInstanceTypesInput {
    OutpostGenerationFilter?: OutpostGeneration | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MemoryInMib = number;
export type NetworkPerformance = string;
export type FormFactor = "RACK" | "SERVER" | (string & {});
export interface FormFactorConfig {
    FormFactor?: FormFactor | undefined;
    OutpostGeneration?: OutpostGeneration | undefined;
}
export type FormFactorConfigList = FormFactorConfig[];
export interface DetailedInstanceTypeItem {
    InstanceType?: string | undefined;
    VCPUs?: number | undefined;
    MemoryInMib?: number | undefined;
    NetworkPerformance?: string | undefined;
    FormFactorConfigs?: FormFactorConfig[] | undefined;
}
export type DetailedInstanceTypeListDefinition = DetailedInstanceTypeItem[];
export interface ListOrderableInstanceTypesOutput {
    InstanceTypes?: DetailedInstanceTypeItem[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOrdersInput {
    OutpostIdentifierFilter?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type LineItemStatusCounts = {
    [key in LineItemStatus]?: number | undefined;
};
export interface OrderSummary {
    OutpostId?: string | undefined;
    OrderId?: string | undefined;
    OrderType?: OrderType | undefined;
    Status?: OrderStatus | undefined;
    LineItemCountsByStatus?: {
        [key: string]: number | undefined;
    } | undefined;
    OrderSubmissionDate?: Date | undefined;
    OrderFulfilledDate?: Date | undefined;
}
export type OrderSummaryListDefinition = OrderSummary[];
export interface ListOrdersOutput {
    Orders?: OrderSummary[] | undefined;
    NextToken?: string | undefined;
}
export type LifeCycleStatusList = string[];
export type AvailabilityZoneList = string[];
export type AvailabilityZoneIdList = string[];
export interface ListOutpostsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    LifeCycleStatusFilter?: string[] | undefined;
    AvailabilityZoneFilter?: string[] | undefined;
    AvailabilityZoneIdFilter?: string[] | undefined;
}
export type OutpostListDefinition = Outpost[];
export interface ListOutpostsOutput {
    Outposts?: Outpost[] | undefined;
    NextToken?: string | undefined;
}
export interface ListQuotesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface QuoteSummary {
    QuoteId?: string | undefined;
    AccountId?: string | undefined;
    QuoteStatus?: QuoteStatus | undefined;
    StatusMessage?: string | undefined;
    OutpostArn?: string | undefined;
    CountryCode?: string | undefined;
    RequestedCapacities?: QuoteCapacity[] | undefined;
    RequestedConstraints?: QuoteConstraint[] | undefined;
    RequestedPaymentOptions?: PaymentOption[] | undefined;
    RequestedPaymentTerms?: PaymentTerm[] | undefined;
    QuoteOptions?: QuoteOption[] | undefined;
    SubmittedOrderId?: string | undefined;
    CreatedDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type QuoteSummaryListDefinition = QuoteSummary[];
export interface ListQuotesOutput {
    Quotes?: QuoteSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CountryCodeList = string[];
export type StateOrRegionList = string[];
export type CityList = string[];
export interface ListSitesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    OperatingAddressCountryCodeFilter?: string[] | undefined;
    OperatingAddressStateOrRegionFilter?: string[] | undefined;
    OperatingAddressCityFilter?: string[] | undefined;
}
export type SiteListDefinition = Site[];
export interface ListSitesOutput {
    Sites?: Site[] | undefined;
    NextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartCapacityTaskInput {
    OutpostIdentifier: string;
    OrderId?: string | undefined;
    AssetId?: string | undefined;
    InstancePools: InstanceTypeCapacity[];
    InstancesToExclude?: InstancesToExclude | undefined;
    DryRun?: boolean | undefined;
    TaskActionOnBlockingInstances?: TaskActionOnBlockingInstances | undefined;
}
export interface StartCapacityTaskOutput {
    CapacityTaskId?: string | undefined;
    OutpostId?: string | undefined;
    OrderId?: string | undefined;
    AssetId?: string | undefined;
    RequestedInstancePools?: InstanceTypeCapacity[] | undefined;
    InstancesToExclude?: InstancesToExclude | undefined;
    DryRun?: boolean | undefined;
    CapacityTaskStatus?: CapacityTaskStatus | undefined;
    Failed?: CapacityTaskFailure | undefined;
    CreationDate?: Date | undefined;
    CompletionDate?: Date | undefined;
    LastModifiedDate?: Date | undefined;
    TaskActionOnBlockingInstances?: TaskActionOnBlockingInstances | undefined;
}
export type DeviceSerialNumber = string;
export type NetworkInterfaceDeviceIndex = number;
export interface StartConnectionRequest {
    DeviceSerialNumber?: string | undefined;
    AssetId: string;
    ClientPublicKey: string;
    NetworkInterfaceDeviceIndex: number;
}
export type UnderlayIpAddress = string;
export interface StartConnectionResponse {
    ConnectionId?: string | undefined;
    UnderlayIpAddress?: string | undefined;
}
export type ValidateOnly = boolean;
export interface StartOutpostDecommissionInput {
    OutpostIdentifier: string;
    ValidateOnly?: boolean | undefined;
}
export type DecommissionRequestStatus = "SKIPPED" | "BLOCKED" | "REQUESTED" | (string & {});
export type BlockingResourceType = "EC2_INSTANCE" | "OUTPOST_RAM_SHARE" | "LGW_ROUTING_DOMAIN" | "LGW_ROUTE_TABLE" | "LGW_VIRTUAL_INTERFACE_GROUP" | "OUTPOST_ORDER_CANCELLABLE" | "OUTPOST_ORDER_INTERVENTION_REQUIRED" | (string & {});
export type BlockingResourceTypeList = BlockingResourceType[];
export interface StartOutpostDecommissionOutput {
    Status?: DecommissionRequestStatus | undefined;
    BlockingResourceTypes?: BlockingResourceType[] | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateOutpostInput {
    OutpostId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    SupportedHardwareType?: SupportedHardwareType | undefined;
}
export interface UpdateOutpostOutput {
    Outpost?: Outpost | undefined;
}
export type OutpostIdentifierOrEmpty = string;
export interface UpdateQuoteInput {
    QuoteIdentifier: string;
    OutpostIdentifier?: string | undefined;
    CountryCode?: string | undefined;
    RequestedCapacities?: QuoteCapacity[] | undefined;
    RequestedConstraints?: QuoteConstraint[] | undefined;
    RequestedPaymentOptions?: PaymentOption[] | undefined;
    RequestedPaymentTerms?: PaymentTerm[] | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateQuoteOutput {
    Quote?: Quote | undefined;
}
export interface UpdateSiteInput {
    SiteId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Notes?: string | undefined;
}
export interface UpdateSiteOutput {
    Site?: Site | undefined;
}
export interface UpdateSiteAddressInput {
    SiteId: string;
    AddressType: AddressType;
    Address: Address;
}
export interface UpdateSiteAddressOutput {
    AddressType?: AddressType | undefined;
    Address?: Address | undefined;
}
export interface UpdateSiteRackPhysicalPropertiesInput {
    SiteId: string;
    PowerDrawKva?: PowerDrawKva | undefined;
    PowerPhase?: PowerPhase | undefined;
    PowerConnector?: PowerConnector | undefined;
    PowerFeedDrop?: PowerFeedDrop | undefined;
    UplinkGbps?: UplinkGbps | undefined;
    UplinkCount?: UplinkCount | undefined;
    FiberOpticCableType?: FiberOpticCableType | undefined;
    OpticalStandard?: OpticalStandard | undefined;
    MaximumSupportedWeightLbs?: MaximumSupportedWeightLbs | undefined;
}
export interface UpdateSiteRackPhysicalPropertiesOutput {
    Site?: Site | undefined;
}
export type ErrorMessage = string;
export type ResourceType = "OUTPOST" | "ORDER" | (string & {});
export type CancelCapacityTaskError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Cancels the capacity task.
 */
export declare const cancelCapacityTask: API.OperationMethod<CancelCapacityTaskInput & RegionInput, CancelCapacityTaskOutput, CancelCapacityTaskError, Credentials | HttpClient.HttpClient>;
export type CancelOrderError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Cancels the specified order for an Outpost.
 */
export declare const cancelOrder: API.OperationMethod<CancelOrderInput & RegionInput, CancelOrderOutput, CancelOrderError, Credentials | HttpClient.HttpClient>;
export type CreateOrderError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an order for an Outpost.
 */
export declare const createOrder: API.OperationMethod<CreateOrderInput & RegionInput, CreateOrderOutput, CreateOrderError, Credentials | HttpClient.HttpClient>;
export type CreateOutpostError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an Outpost.
 *
 * You can specify either an Availability one or an AZ ID.
 */
export declare const createOutpost: API.OperationMethod<CreateOutpostInput & RegionInput, CreateOutpostOutput, CreateOutpostError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectivityConfigError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Creates the private connectivity configuration for the specified Outpost. Private
 * connectivity establishes a service link VPN connection between the Outpost and its home
 * Amazon Web Services Region using a VPC and subnet that you specify, which allows the service link traffic
 * to flow through your VPC and minimizes public internet exposure.
 */
export declare const createPrivateConnectivityConfig: API.OperationMethod<CreatePrivateConnectivityConfigInput & RegionInput, CreatePrivateConnectivityConfigOutput, CreatePrivateConnectivityConfigError, Credentials | HttpClient.HttpClient>;
export type CreateQuoteError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Creates a quote for an Outpost. A quote provides pricing and configuration options based
 * on the requested capacity. You can optionally associate the quote with an existing Outpost or
 * create a standalone quote by specifying only the country code and requested capacities.
 */
export declare const createQuote: API.OperationMethod<CreateQuoteInput & RegionInput, CreateQuoteOutput, CreateQuoteError, Credentials | HttpClient.HttpClient>;
export type CreateRenewalError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Creates a renewal contract for the specified Outpost.
 */
export declare const createRenewal: API.OperationMethod<CreateRenewalInput & RegionInput, CreateRenewalOutput, CreateRenewalError, Credentials | HttpClient.HttpClient>;
export type CreateSiteError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a site for an Outpost.
 */
export declare const createSite: API.OperationMethod<CreateSiteInput & RegionInput, CreateSiteOutput, CreateSiteError, Credentials | HttpClient.HttpClient>;
export type DeleteOutpostError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified Outpost.
 */
export declare const deleteOutpost: API.OperationMethod<DeleteOutpostInput & RegionInput, DeleteOutpostOutput, DeleteOutpostError, Credentials | HttpClient.HttpClient>;
export type DeleteQuoteError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified quote.
 */
export declare const deleteQuote: API.OperationMethod<DeleteQuoteInput & RegionInput, DeleteQuoteOutput, DeleteQuoteError, Credentials | HttpClient.HttpClient>;
export type DeleteSiteError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified site.
 */
export declare const deleteSite: API.OperationMethod<DeleteSiteInput & RegionInput, DeleteSiteOutput, DeleteSiteError, Credentials | HttpClient.HttpClient>;
export type GetCapacityTaskError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets details of the specified capacity task.
 */
export declare const getCapacityTask: API.OperationMethod<GetCapacityTaskInput & RegionInput, GetCapacityTaskOutput, GetCapacityTaskError, Credentials | HttpClient.HttpClient>;
export type GetCatalogItemError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified catalog item.
 */
export declare const getCatalogItem: API.OperationMethod<GetCatalogItemInput & RegionInput, GetCatalogItemOutput, GetCatalogItemError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Amazon Web Services uses this action to install Outpost servers.
 *
 * Gets information about the specified connection.
 *
 * Use CloudTrail to monitor this action or Amazon Web Services managed policy for Amazon Web Services Outposts to secure it. For
 * more information, see
 * Amazon Web Services managed policies for Amazon Web Services Outposts and
 * Logging Amazon Web Services Outposts API calls with Amazon Web Services CloudTrail in the *Amazon Web Services Outposts User Guide*.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest & RegionInput, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetOrderError = InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified order.
 */
export declare const getOrder: API.OperationMethod<GetOrderInput & RegionInput, GetOrderOutput, GetOrderError, Credentials | HttpClient.HttpClient>;
export type GetOutpostError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified Outpost.
 */
export declare const getOutpost: API.OperationMethod<GetOutpostInput & RegionInput, GetOutpostOutput, GetOutpostError, Credentials | HttpClient.HttpClient>;
export type GetOutpostBillingInformationError = AccessDeniedException | InternalServerException | NotFoundException | CommonErrors;
/**
 * Gets current and historical billing information about the specified Outpost.
 */
export declare const getOutpostBillingInformation: API.PaginatedOperationMethod<GetOutpostBillingInformationInput & RegionInput, GetOutpostBillingInformationOutput, GetOutpostBillingInformationError, Credentials | HttpClient.HttpClient, Subscription>;
export type GetOutpostInstanceTypesError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets the instance types for the specified Outpost.
 */
export declare const getOutpostInstanceTypes: API.PaginatedOperationMethod<GetOutpostInstanceTypesInput & RegionInput, GetOutpostInstanceTypesOutput, GetOutpostInstanceTypesError, Credentials | HttpClient.HttpClient, InstanceTypeItem>;
export type GetOutpostSupportedInstanceTypesError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets the instance types that an Outpost can support in `InstanceTypeCapacity`.
 * This will generally include instance types that are not currently configured and therefore
 * cannot be launched with the current Outpost capacity configuration.
 */
export declare const getOutpostSupportedInstanceTypes: API.PaginatedOperationMethod<GetOutpostSupportedInstanceTypesInput & RegionInput, GetOutpostSupportedInstanceTypesOutput, GetOutpostSupportedInstanceTypesError, Credentials | HttpClient.HttpClient, InstanceTypeItem>;
export type GetPrivateConnectivityConfigError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets the private connectivity configuration for the specified Outpost.
 */
export declare const getPrivateConnectivityConfig: API.OperationMethod<GetPrivateConnectivityConfigInput & RegionInput, GetPrivateConnectivityConfigOutput, GetPrivateConnectivityConfigError, Credentials | HttpClient.HttpClient>;
export type GetQuoteError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified quote.
 */
export declare const getQuote: API.OperationMethod<GetQuoteInput & RegionInput, GetQuoteOutput, GetQuoteError, Credentials | HttpClient.HttpClient>;
export type GetRenewalPricingError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets all available renewal pricing options for the specified Outpost.
 */
export declare const getRenewalPricing: API.OperationMethod<GetRenewalPricingInput & RegionInput, GetRenewalPricingOutput, GetRenewalPricingError, Credentials | HttpClient.HttpClient>;
export type GetSiteError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about the specified Outpost site.
 */
export declare const getSite: API.OperationMethod<GetSiteInput & RegionInput, GetSiteOutput, GetSiteError, Credentials | HttpClient.HttpClient>;
export type GetSiteAddressError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Gets the site address of the specified site.
 */
export declare const getSiteAddress: API.OperationMethod<GetSiteAddressInput & RegionInput, GetSiteAddressOutput, GetSiteAddressError, Credentials | HttpClient.HttpClient>;
export type ListAssetInstancesError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * A list of Amazon EC2 instances, belonging to all accounts, running on the specified Outpost.
 * Does not include Amazon EBS or Amazon S3 instances.
 */
export declare const listAssetInstances: API.PaginatedOperationMethod<ListAssetInstancesInput & RegionInput, ListAssetInstancesOutput, ListAssetInstancesError, Credentials | HttpClient.HttpClient, AssetInstance>;
export type ListAssetsError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the hardware assets for the specified Outpost.
 *
 * Use filters to return specific results. If you specify multiple filters, the results include only the resources that match
 * all of the specified filters. For a filter where you can specify multiple values, the results include
 * items that match any of the values that you specify for the filter.
 */
export declare const listAssets: API.PaginatedOperationMethod<ListAssetsInput & RegionInput, ListAssetsOutput, ListAssetsError, Credentials | HttpClient.HttpClient, AssetInfo>;
export type ListBlockingInstancesForCapacityTaskError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * A list of Amazon EC2 instances running on the Outpost and belonging to the account that
 * initiated the capacity task. Use this list to specify the instances you cannot stop to free up
 * capacity to run the capacity task.
 */
export declare const listBlockingInstancesForCapacityTask: API.PaginatedOperationMethod<ListBlockingInstancesForCapacityTaskInput & RegionInput, ListBlockingInstancesForCapacityTaskOutput, ListBlockingInstancesForCapacityTaskError, Credentials | HttpClient.HttpClient, BlockingInstance>;
export type ListCapacityTasksError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the capacity tasks for your Amazon Web Services account.
 *
 * Use filters to return specific results. If you specify multiple filters, the results include only the resources that match
 * all of the specified filters. For a filter where you can specify multiple values, the results include
 * items that match any of the values that you specify for the filter.
 */
export declare const listCapacityTasks: API.PaginatedOperationMethod<ListCapacityTasksInput & RegionInput, ListCapacityTasksOutput, ListCapacityTasksError, Credentials | HttpClient.HttpClient, CapacityTaskSummary>;
export type ListCatalogItemsError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the items in the catalog.
 *
 * Use filters to return specific results. If you specify multiple filters, the results include only the resources that match
 * all of the specified filters. For a filter where you can specify multiple values, the results include
 * items that match any of the values that you specify for the filter.
 */
export declare const listCatalogItems: API.PaginatedOperationMethod<ListCatalogItemsInput & RegionInput, ListCatalogItemsOutput, ListCatalogItemsError, Credentials | HttpClient.HttpClient, CatalogItem>;
export type ListOrderableInstanceTypesError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the instance types that can be ordered for an Outpost. You can filter the results
 * by Outpost generation.
 */
export declare const listOrderableInstanceTypes: API.PaginatedOperationMethod<ListOrderableInstanceTypesInput & RegionInput, ListOrderableInstanceTypesOutput, ListOrderableInstanceTypesError, Credentials | HttpClient.HttpClient, DetailedInstanceTypeItem>;
export type ListOrdersError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the Outpost orders for your Amazon Web Services account.
 */
export declare const listOrders: API.PaginatedOperationMethod<ListOrdersInput & RegionInput, ListOrdersOutput, ListOrdersError, Credentials | HttpClient.HttpClient, OrderSummary>;
export type ListOutpostsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Outposts for your Amazon Web Services account.
 *
 * Use filters to return specific results. If you specify multiple filters, the results include only the resources that match
 * all of the specified filters. For a filter where you can specify multiple values, the results include
 * items that match any of the values that you specify for the filter.
 */
export declare const listOutposts: API.PaginatedOperationMethod<ListOutpostsInput & RegionInput, ListOutpostsOutput, ListOutpostsError, Credentials | HttpClient.HttpClient, Outpost>;
export type ListQuotesError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Lists the quotes for your Amazon Web Services account.
 */
export declare const listQuotes: API.PaginatedOperationMethod<ListQuotesInput & RegionInput, ListQuotesOutput, ListQuotesError, Credentials | HttpClient.HttpClient, QuoteSummary>;
export type ListSitesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Outpost sites for your Amazon Web Services account. Use filters to return specific
 * results.
 *
 * Use filters to return specific results. If you specify multiple filters, the results include only the resources that match
 * all of the specified filters. For a filter where you can specify multiple values, the results include
 * items that match any of the values that you specify for the filter.
 */
export declare const listSites: API.PaginatedOperationMethod<ListSitesInput & RegionInput, ListSitesOutput, ListSitesError, Credentials | HttpClient.HttpClient, Site>;
export type ListTagsForResourceError = InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartCapacityTaskError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Starts the specified capacity task. You can have one active capacity task for each order
 * and each Outpost.
 */
export declare const startCapacityTask: API.OperationMethod<StartCapacityTaskInput & RegionInput, StartCapacityTaskOutput, StartCapacityTaskError, Credentials | HttpClient.HttpClient>;
export type StartConnectionError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Amazon Web Services uses this action to install Outpost servers.
 *
 * Starts the connection required for Outpost server installation.
 *
 * Use CloudTrail to monitor this action or Amazon Web Services managed policy for Amazon Web Services Outposts to secure it. For
 * more information, see
 * Amazon Web Services managed policies for Amazon Web Services Outposts and
 * Logging Amazon Web Services Outposts API calls with Amazon Web Services CloudTrail in the *Amazon Web Services Outposts User Guide*.
 */
export declare const startConnection: API.OperationMethod<StartConnectionRequest & RegionInput, StartConnectionResponse, StartConnectionError, Credentials | HttpClient.HttpClient>;
export type StartOutpostDecommissionError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Starts the decommission process to return the Outposts racks or servers.
 */
export declare const startOutpostDecommission: API.OperationMethod<StartOutpostDecommissionInput & RegionInput, StartOutpostDecommissionOutput, StartOutpostDecommissionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Adds tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateOutpostError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Updates an Outpost.
 */
export declare const updateOutpost: API.OperationMethod<UpdateOutpostInput & RegionInput, UpdateOutpostOutput, UpdateOutpostError, Credentials | HttpClient.HttpClient>;
export type UpdateQuoteError = AccessDeniedException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified quote. You can modify the requested capacities, constraints,
 * payment options, payment terms, or Outpost association.
 */
export declare const updateQuote: API.OperationMethod<UpdateQuoteInput & RegionInput, UpdateQuoteOutput, UpdateQuoteError, Credentials | HttpClient.HttpClient>;
export type UpdateSiteError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified site.
 */
export declare const updateSite: API.OperationMethod<UpdateSiteInput & RegionInput, UpdateSiteOutput, UpdateSiteError, Credentials | HttpClient.HttpClient>;
export type UpdateSiteAddressError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Updates the address of the specified site.
 *
 * You can't update a site address if there is an order in progress. You must wait for the
 * order to complete or cancel the order.
 *
 * You can update the operating address before you place an order at the site, or after all
 * Outposts that belong to the site have been deactivated.
 */
export declare const updateSiteAddress: API.OperationMethod<UpdateSiteAddressInput & RegionInput, UpdateSiteAddressOutput, UpdateSiteAddressError, Credentials | HttpClient.HttpClient>;
export type UpdateSiteRackPhysicalPropertiesError = AccessDeniedException | ConflictException | InternalServerException | NotFoundException | ValidationException | CommonErrors;
/**
 * Update the physical and logistical details for a rack at a site. For more information
 * about hardware requirements for racks, see Network
 * readiness checklist in the Amazon Web Services Outposts User Guide.
 *
 * To update a rack at a site with an order of `IN_PROGRESS`, you must wait for
 * the order to complete or cancel the order.
 */
export declare const updateSiteRackPhysicalProperties: API.OperationMethod<UpdateSiteRackPhysicalPropertiesInput & RegionInput, UpdateSiteRackPhysicalPropertiesOutput, UpdateSiteRackPhysicalPropertiesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=outposts.d.ts.map