/**
 * The `com.distilled.telemetry#operation` trait's `inject` and `extract`
 * (format `awsMessageAttributes`): W3C trace context in SQS and SNS
 * message attributes. Generated code imports this only where a trait has
 * one. See `packages/dev/src/codegen/telemetry-traits.md`.
 */
import * as Tracer from "effect/Tracer";
import type { MessageExtract } from "./telemetry.ts";
/** W3C `traceparent` of a span. */
export declare const traceparent: (span: Tracer.AnySpan) => string;
/** The span a W3C `traceparent` names, if it is well formed. */
export declare const parseTraceparent: (value: unknown) => Tracer.ExternalSpan | undefined;
/** Where messages sit: `member` of the value, or of every element of its `list` member. */
export interface MessagePlace {
    readonly member: string;
    readonly list?: string;
}
/**
 * Write the span's `traceparent` into each message's attributes (a map of
 * `{ DataType, StringValue }`, the SQS and SNS shape). Kept: a
 * `traceparent` already there, and a message with 10 attributes. The
 * caller's input object is not changed.
 */
export declare const injectAwsMessageAttributes: (place: MessagePlace) => (span: Tracer.Span, input: unknown) => unknown;
/**
 * Where else a received message can carry trace context, by generated
 * property name (SQS `ReceiveMessage`):
 *
 *   envelope       the body member; an SNS notification delivered without
 *                  raw message delivery is JSON whose `MessageAttributes`
 *                  carry the publisher's `traceparent`
 *   system         the system-attributes member, whose `AWSTraceHeader` is
 *                  an X-Ray trace header (set by X-Ray-instrumented
 *                  producers); `systemRequest` is the input member listing
 *                  system attributes to return
 */
export interface MessageExtractPlace extends MessagePlace {
    readonly request?: string;
    /** The message's id member: each link carries it as `messaging.message.id`. */
    readonly messageId?: string;
    readonly envelope?: string;
    readonly system?: string;
    readonly systemRequest?: string;
}
/**
 * Ask for `traceparent` (and `AWSTraceHeader`) back, unless the input asks
 * for `All` or `.*`, and link the span to every well-formed trace context
 * each message carries: its `traceparent` attribute, else the SNS
 * envelope's, plus its X-Ray `AWSTraceHeader` when that names another span.
 */
export declare const extractAwsMessageAttributes: (place: MessageExtractPlace) => MessageExtract;
//# sourceMappingURL=telemetry-message-context.d.ts.map