import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const MwaaExecutionRoleNotAssumable_base: S.TaggedErrorClass<"MwaaExecutionRoleNotAssumable", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MwaaExecutionRoleNotAssumable extends /*@__PURE__*/ MwaaExecutionRoleNotAssumable_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RestApiClientException_base: S.TaggedErrorClass<"RestApiClientException", {
    readonly RestApiStatusCode: any;
    readonly RestApiResponse: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RestApiClientException extends /*@__PURE__*/ RestApiClientException_base {
}
declare const RestApiServerException_base: S.TaggedErrorClass<"RestApiServerException", {
    readonly RestApiStatusCode: any;
    readonly RestApiResponse: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RestApiServerException extends /*@__PURE__*/ RestApiServerException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentName = string;
export interface CreateCliTokenRequest {
    Name: string;
}
export type Token = string | redacted.Redacted<string>;
export type Hostname = string;
export interface CreateCliTokenResponse {
    CliToken?: string | redacted.Redacted<string> | undefined;
    WebServerHostname?: string | undefined;
}
export type IamRoleArn = string;
export type S3BucketArn = string;
export type RelativePath = string;
export type SubnetId = string;
export type SubnetList = string[];
export type SecurityGroupId = string;
export type SecurityGroupList = string[];
export interface NetworkConfiguration {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export type S3ObjectVersion = string;
export type ConfigKey = string;
export type ConfigValue = string | redacted.Redacted<string>;
export type AirflowConfigurationOptions = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type EnvironmentClass = string;
export type MaxWorkers = number;
export type KmsKey = string;
export type AirflowVersion = string;
export type LoggingEnabled = boolean;
export type LoggingLevel = string;
export interface ModuleLoggingConfigurationInput {
    Enabled: boolean;
    LogLevel: string;
}
export interface LoggingConfigurationInput {
    DagProcessingLogs?: ModuleLoggingConfigurationInput | undefined;
    SchedulerLogs?: ModuleLoggingConfigurationInput | undefined;
    WebserverLogs?: ModuleLoggingConfigurationInput | undefined;
    WorkerLogs?: ModuleLoggingConfigurationInput | undefined;
    TaskLogs?: ModuleLoggingConfigurationInput | undefined;
}
export type WeeklyMaintenanceWindowStart = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type WebserverAccessMode = string;
export type MinWorkers = number;
export type Schedulers = number;
export type EndpointManagement = string;
export type MinWebservers = number;
export type MaxWebservers = number;
export type IdentityCenterStartUrl = string;
export type IdentityCenterIdentityStoreId = string;
export interface IdentityCenterConfiguration {
    StartUrl?: string | undefined;
    IdentityStoreId?: string | undefined;
}
export type TeamNameString = string;
export interface TeamConfig {
    SourceBucketArn: string;
    DagS3Path: string;
}
export type TeamMap = {
    [key: string]: TeamConfig | undefined;
};
export interface CreateEnvironmentInput {
    Name: string;
    ExecutionRoleArn: string;
    SourceBucketArn: string;
    DagS3Path: string;
    NetworkConfiguration: NetworkConfiguration;
    PluginsS3Path?: string | undefined;
    PluginsS3ObjectVersion?: string | undefined;
    RequirementsS3Path?: string | undefined;
    RequirementsS3ObjectVersion?: string | undefined;
    StartupScriptS3Path?: string | undefined;
    StartupScriptS3ObjectVersion?: string | undefined;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    EnvironmentClass?: string | undefined;
    MaxWorkers?: number | undefined;
    KmsKey?: string | undefined;
    AirflowVersion?: string | undefined;
    LoggingConfiguration?: LoggingConfigurationInput | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WebserverAccessMode?: string | undefined;
    MinWorkers?: number | undefined;
    Schedulers?: number | undefined;
    EndpointManagement?: string | undefined;
    MinWebservers?: number | undefined;
    MaxWebservers?: number | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    Teams?: {
        [key: string]: TeamConfig | undefined;
    } | undefined;
}
export type EnvironmentArn = string;
export interface CreateEnvironmentOutput {
    Arn?: string | undefined;
}
export interface CreateWebLoginTokenRequest {
    Name: string;
}
export type IamIdentity = string;
export type AirflowIdentity = string;
export interface CreateWebLoginTokenResponse {
    WebToken?: string | redacted.Redacted<string> | undefined;
    WebServerHostname?: string | undefined;
    IamIdentity?: string | undefined;
    AirflowIdentity?: string | undefined;
}
export interface DeleteEnvironmentInput {
    Name: string;
}
export interface DeleteEnvironmentOutput {
}
export interface GetEnvironmentInput {
    Name: string;
}
export type EnvironmentStatus = string;
export type CreatedAt = Date;
export type WebserverUrl = string;
export type CloudWatchLogGroupArn = string;
export interface ModuleLoggingConfiguration {
    Enabled?: boolean | undefined;
    LogLevel?: string | undefined;
    CloudWatchLogGroupArn?: string | undefined;
}
export interface LoggingConfiguration {
    DagProcessingLogs?: ModuleLoggingConfiguration | undefined;
    SchedulerLogs?: ModuleLoggingConfiguration | undefined;
    WebserverLogs?: ModuleLoggingConfiguration | undefined;
    WorkerLogs?: ModuleLoggingConfiguration | undefined;
    TaskLogs?: ModuleLoggingConfiguration | undefined;
}
export type UpdateStatus = string;
export type UpdateCreatedAt = Date;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface UpdateError {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type UpdateSource = string;
export type WorkerReplacementStrategy = string;
export interface LastUpdate {
    Status?: string | undefined;
    CreatedAt?: Date | undefined;
    Error?: UpdateError | undefined;
    Source?: string | undefined;
    WorkerReplacementStrategy?: string | undefined;
}
export type VpcEndpointServiceName = string;
export type CeleryExecutorQueue = string;
export interface Environment {
    Name?: string | undefined;
    Status?: string | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    WebserverUrl?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    ServiceRoleArn?: string | undefined;
    KmsKey?: string | undefined;
    AirflowVersion?: string | undefined;
    SourceBucketArn?: string | undefined;
    DagS3Path?: string | undefined;
    PluginsS3Path?: string | undefined;
    PluginsS3ObjectVersion?: string | undefined;
    RequirementsS3Path?: string | undefined;
    RequirementsS3ObjectVersion?: string | undefined;
    StartupScriptS3Path?: string | undefined;
    StartupScriptS3ObjectVersion?: string | undefined;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    EnvironmentClass?: string | undefined;
    MaxWorkers?: number | undefined;
    NetworkConfiguration?: NetworkConfiguration | undefined;
    LoggingConfiguration?: LoggingConfiguration | undefined;
    LastUpdate?: LastUpdate | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    WebserverAccessMode?: string | undefined;
    MinWorkers?: number | undefined;
    Schedulers?: number | undefined;
    WebserverVpcEndpointService?: string | undefined;
    DatabaseVpcEndpointService?: string | undefined;
    CeleryExecutorQueue?: string | undefined;
    EndpointManagement?: string | undefined;
    MinWebservers?: number | undefined;
    MaxWebservers?: number | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    Teams?: {
        [key: string]: TeamConfig | undefined;
    } | undefined;
}
export interface GetEnvironmentOutput {
    Environment?: Environment | undefined;
}
export type RestApiPath = string;
export type RestApiMethod = string;
export type RestApiRequestBody = unknown;
export interface InvokeRestApiRequest {
    Name: string;
    Path: string;
    Method: string;
    QueryParameters?: any | undefined;
    Body?: any | undefined;
}
export type RestApiResponse = unknown;
export interface InvokeRestApiResponse {
    RestApiStatusCode?: number | undefined;
    RestApiResponse?: any | undefined;
}
export type NextToken = string;
export interface ListEnvironmentsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EnvironmentList = string[];
export interface ListEnvironmentsOutput {
    Environments: string[];
    NextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Dimension {
    Name: string;
    Value: string;
}
export type Dimensions = Dimension[];
export type Unit = string;
export interface StatisticSet {
    SampleCount?: number | undefined;
    Sum?: number | undefined;
    Minimum?: number | undefined;
    Maximum?: number | undefined;
}
export interface MetricDatum {
    MetricName: string;
    Timestamp: Date;
    Dimensions?: Dimension[] | undefined;
    Value?: number | undefined;
    Unit?: string | undefined;
    StatisticValues?: StatisticSet | undefined;
}
export type MetricData = MetricDatum[];
export interface PublishMetricsInput {
    EnvironmentName: string;
    MetricData: MetricDatum[];
}
export interface PublishMetricsOutput {
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateNetworkConfigurationInput {
    SecurityGroupIds: string[];
}
export type TeamNameList = string[];
export interface UpdateTeamsInput {
    AddOrUpdate?: {
        [key: string]: TeamConfig | undefined;
    } | undefined;
    Remove?: string[] | undefined;
}
export interface UpdateEnvironmentInput {
    Name: string;
    ExecutionRoleArn?: string | undefined;
    AirflowConfigurationOptions?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    AirflowVersion?: string | undefined;
    DagS3Path?: string | undefined;
    EnvironmentClass?: string | undefined;
    LoggingConfiguration?: LoggingConfigurationInput | undefined;
    MaxWorkers?: number | undefined;
    MinWorkers?: number | undefined;
    MaxWebservers?: number | undefined;
    MinWebservers?: number | undefined;
    WorkerReplacementStrategy?: string | undefined;
    NetworkConfiguration?: UpdateNetworkConfigurationInput | undefined;
    PluginsS3Path?: string | undefined;
    PluginsS3ObjectVersion?: string | undefined;
    RequirementsS3Path?: string | undefined;
    RequirementsS3ObjectVersion?: string | undefined;
    Schedulers?: number | undefined;
    SourceBucketArn?: string | undefined;
    StartupScriptS3Path?: string | undefined;
    StartupScriptS3ObjectVersion?: string | undefined;
    WebserverAccessMode?: string | undefined;
    WeeklyMaintenanceWindowStart?: string | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    Teams?: UpdateTeamsInput | undefined;
}
export interface UpdateEnvironmentOutput {
    Arn?: string | undefined;
}
export type CreateCliTokenError = ResourceNotFoundException | CommonErrors;
/**
 * Creates a CLI token for the Airflow CLI. To learn more, see Creating an Apache Airflow CLI token.
 */
export declare const createCliToken: API.OperationMethod<CreateCliTokenRequest & RegionInput, CreateCliTokenResponse, CreateCliTokenError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = InternalServerException | ServiceUnavailableException | ValidationException | MwaaExecutionRoleNotAssumable | CommonErrors;
/**
 * Creates an Amazon Managed Workflows for Apache Airflow (Amazon MWAA) environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentInput & RegionInput, CreateEnvironmentOutput, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateWebLoginTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a web login token for the Airflow Web UI. To learn more, see Creating an Apache Airflow web login token.
 */
export declare const createWebLoginToken: API.OperationMethod<CreateWebLoginTokenRequest & RegionInput, CreateWebLoginTokenResponse, CreateWebLoginTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Managed Workflows for Apache Airflow (Amazon MWAA) environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentInput & RegionInput, DeleteEnvironmentOutput, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentInput & RegionInput, GetEnvironmentOutput, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type InvokeRestApiError = AccessDeniedException | InternalServerException | ResourceNotFoundException | RestApiClientException | RestApiServerException | ValidationException | CommonErrors;
/**
 * Invokes the Apache Airflow REST API on the webserver with the specified inputs. To learn more, see Using the Apache Airflow REST API
 */
export declare const invokeRestApi: API.OperationMethod<InvokeRestApiRequest & RegionInput, InvokeRestApiResponse, InvokeRestApiError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Managed Workflows for Apache Airflow (MWAA) environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsInput & RegionInput, ListEnvironmentsOutput, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentName>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the key-value tag pairs associated to the Amazon Managed Workflows for Apache Airflow (MWAA) environment. For example, `"Environment": "Staging"`.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishMetricsError = InternalServerException | ValidationException | CommonErrors;
/**
 * **Internal only**. Publishes environment health metrics to Amazon CloudWatch.
 */
export declare const publishMetrics: API.OperationMethod<PublishMetricsInput & RegionInput, PublishMetricsOutput, PublishMetricsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates key-value tag pairs to your Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes key-value tag pairs associated to your Amazon Managed Workflows for Apache Airflow (MWAA) environment. For example, `"Environment": "Staging"`.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Managed Workflows for Apache Airflow (MWAA) environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentInput & RegionInput, UpdateEnvironmentOutput, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mwaa.d.ts.map