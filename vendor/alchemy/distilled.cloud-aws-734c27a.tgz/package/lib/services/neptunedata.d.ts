import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const BulkLoadIdNotFoundException_base: S.TaggedErrorClass<"BulkLoadIdNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class BulkLoadIdNotFoundException extends /*@__PURE__*/ BulkLoadIdNotFoundException_base {
}
declare const CancelledByMaintenanceException_base: S.TaggedErrorClass<"CancelledByMaintenanceException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class CancelledByMaintenanceException extends /*@__PURE__*/ CancelledByMaintenanceException_base {
}
declare const CancelledByUserException_base: S.TaggedErrorClass<"CancelledByUserException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class CancelledByUserException extends /*@__PURE__*/ CancelledByUserException_base {
}
declare const ClientTimeoutException_base: S.TaggedErrorClass<"ClientTimeoutException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ClientTimeoutException extends /*@__PURE__*/ ClientTimeoutException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConstraintViolationException_base: S.TaggedErrorClass<"ConstraintViolationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConstraintViolationException extends /*@__PURE__*/ ConstraintViolationException_base {
}
declare const ExpiredStreamException_base: S.TaggedErrorClass<"ExpiredStreamException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredStreamException extends /*@__PURE__*/ ExpiredStreamException_base {
}
declare const FailureByQueryException_base: S.TaggedErrorClass<"FailureByQueryException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class FailureByQueryException extends /*@__PURE__*/ FailureByQueryException_base {
}
declare const IllegalArgumentException_base: S.TaggedErrorClass<"IllegalArgumentException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalArgumentException extends /*@__PURE__*/ IllegalArgumentException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const InvalidNumericDataException_base: S.TaggedErrorClass<"InvalidNumericDataException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNumericDataException extends /*@__PURE__*/ InvalidNumericDataException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const LoadUrlAccessDeniedException_base: S.TaggedErrorClass<"LoadUrlAccessDeniedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LoadUrlAccessDeniedException extends /*@__PURE__*/ LoadUrlAccessDeniedException_base {
}
declare const MalformedQueryException_base: S.TaggedErrorClass<"MalformedQueryException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedQueryException extends /*@__PURE__*/ MalformedQueryException_base {
}
declare const MemoryLimitExceededException_base: S.TaggedErrorClass<"MemoryLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MemoryLimitExceededException extends /*@__PURE__*/ MemoryLimitExceededException_base {
}
declare const MethodNotAllowedException_base: S.TaggedErrorClass<"MethodNotAllowedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const MissingParameterException_base: S.TaggedErrorClass<"MissingParameterException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingParameterException extends /*@__PURE__*/ MissingParameterException_base {
}
declare const MLResourceNotFoundException_base: S.TaggedErrorClass<"MLResourceNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MLResourceNotFoundException extends /*@__PURE__*/ MLResourceNotFoundException_base {
}
declare const ParsingException_base: S.TaggedErrorClass<"ParsingException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParsingException extends /*@__PURE__*/ ParsingException_base {
}
declare const PreconditionsFailedException_base: S.TaggedErrorClass<"PreconditionsFailedException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PreconditionsFailedException extends /*@__PURE__*/ PreconditionsFailedException_base {
}
declare const QueryLimitExceededException_base: S.TaggedErrorClass<"QueryLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class QueryLimitExceededException extends /*@__PURE__*/ QueryLimitExceededException_base {
}
declare const QueryLimitException_base: S.TaggedErrorClass<"QueryLimitException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryLimitException extends /*@__PURE__*/ QueryLimitException_base {
}
declare const QueryTooLargeException_base: S.TaggedErrorClass<"QueryTooLargeException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryTooLargeException extends /*@__PURE__*/ QueryTooLargeException_base {
}
declare const ReadOnlyViolationException_base: S.TaggedErrorClass<"ReadOnlyViolationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReadOnlyViolationException extends /*@__PURE__*/ ReadOnlyViolationException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const S3Exception_base: S.TaggedErrorClass<"S3Exception", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class S3Exception extends /*@__PURE__*/ S3Exception_base {
}
declare const ServerShutdownException_base: S.TaggedErrorClass<"ServerShutdownException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerShutdownException extends /*@__PURE__*/ ServerShutdownException_base {
}
declare const StatisticsNotAvailableException_base: S.TaggedErrorClass<"StatisticsNotAvailableException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StatisticsNotAvailableException extends /*@__PURE__*/ StatisticsNotAvailableException_base {
}
declare const StreamRecordsNotFoundException_base: S.TaggedErrorClass<"StreamRecordsNotFoundException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StreamRecordsNotFoundException extends /*@__PURE__*/ StreamRecordsNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TimeLimitExceededException_base: S.TaggedErrorClass<"TimeLimitExceededException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TimeLimitExceededException extends /*@__PURE__*/ TimeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly detailedMessage: any;
    readonly requestId: any;
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface CancelGremlinQueryInput {
    queryId: string;
}
export interface CancelGremlinQueryOutput {
    status?: string | undefined;
}
export interface CancelIndexRebuildInput {
    rebuildId: string;
}
export type RebuildStatus = "PREPARING" | "REBUILDING" | "COMPLETED" | "FAILED" | "CANCELLED" | "CANCELLING" | (string & {});
export type RebuildConcurrency = number;
export type WriteBufferSize = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface CancelIndexRebuildOutput {
    status: RebuildStatus;
    concurrency: number;
    writeBufferSize: WriteBufferSize;
}
export interface CancelLoaderJobInput {
    loadId: string;
}
export interface CancelLoaderJobOutput {
    status?: string | undefined;
}
export interface CancelMLDataProcessingJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
    clean?: boolean | undefined;
}
export interface CancelMLDataProcessingJobOutput {
    status?: string | undefined;
}
export interface CancelMLModelTrainingJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
    clean?: boolean | undefined;
}
export interface CancelMLModelTrainingJobOutput {
    status?: string | undefined;
}
export interface CancelMLModelTransformJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
    clean?: boolean | undefined;
}
export interface CancelMLModelTransformJobOutput {
    status?: string | undefined;
}
export interface CancelOpenCypherQueryInput {
    queryId: string;
    silent?: boolean | undefined;
}
export interface CancelOpenCypherQueryOutput {
    status?: string | undefined;
    payload?: boolean | undefined;
}
export interface CreateMLEndpointInput {
    id?: string | undefined;
    mlModelTrainingJobId?: string | undefined;
    mlModelTransformJobId?: string | undefined;
    update?: boolean | undefined;
    neptuneIamRoleArn?: string | undefined;
    modelName?: string | undefined;
    instanceType?: string | undefined;
    instanceCount?: number | undefined;
    volumeEncryptionKMSKey?: string | undefined;
}
export interface CreateMLEndpointOutput {
    id?: string | undefined;
    arn?: string | undefined;
    creationTimeInMillis?: number | undefined;
}
export interface DeleteMLEndpointInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
    clean?: boolean | undefined;
}
export interface DeleteMLEndpointOutput {
    status?: string | undefined;
}
export interface DeletePropertygraphStatisticsRequest {
}
export interface DeleteStatisticsValueMap {
    active?: boolean | undefined;
    statisticsId?: string | undefined;
}
export interface DeletePropertygraphStatisticsOutput {
    statusCode?: number | undefined;
    status?: string | undefined;
    payload?: DeleteStatisticsValueMap | undefined;
}
export interface DeleteSparqlStatisticsRequest {
}
export interface DeleteSparqlStatisticsOutput {
    statusCode?: number | undefined;
    status?: string | undefined;
    payload?: DeleteStatisticsValueMap | undefined;
}
export type Action = "initiateDatabaseReset" | "performDatabaseReset" | (string & {});
export interface ExecuteFastResetInput {
    action: Action;
    token?: string | undefined;
}
export interface FastResetToken {
    token?: string | undefined;
}
export interface ExecuteFastResetOutput {
    status: string;
    payload?: FastResetToken | undefined;
}
export interface ExecuteGremlinExplainQueryInput {
    gremlinQuery: string;
}
export interface ExecuteGremlinExplainQueryOutput {
    output?: T.StreamingOutputBody | undefined;
}
export interface ExecuteGremlinProfileQueryInput {
    gremlinQuery: string;
    results?: boolean | undefined;
    chop?: number | undefined;
    serializer?: string | undefined;
    indexOps?: boolean | undefined;
}
export interface ExecuteGremlinProfileQueryOutput {
    output?: T.StreamingOutputBody | undefined;
}
export interface ExecuteGremlinQueryInput {
    gremlinQuery: string;
    serializer?: string | undefined;
}
export interface GremlinQueryStatusAttributes {
    message?: string | undefined;
    code?: number | undefined;
    attributes?: any | undefined;
}
export interface ExecuteGremlinQueryOutput {
    requestId?: string | undefined;
    status?: GremlinQueryStatusAttributes | undefined;
    result?: any | undefined;
    meta?: any | undefined;
}
export type OpenCypherExplainMode = "static" | "dynamic" | "details" | (string & {});
export interface ExecuteOpenCypherExplainQueryInput {
    openCypherQuery: string;
    parameters?: string | undefined;
    explainMode: OpenCypherExplainMode;
}
export interface ExecuteOpenCypherExplainQueryOutput {
    results: Uint8Array;
}
export interface ExecuteOpenCypherQueryInput {
    openCypherQuery: string;
    parameters?: string | undefined;
}
export interface ExecuteOpenCypherQueryOutput {
    results: any;
}
export interface GetEngineStatusRequest {
}
export interface QueryLanguageVersion {
    version: string;
}
export type StringValuedMap = {
    [key: string]: string | undefined;
};
export type DocumentValuedMap = {
    [key: string]: any | undefined;
};
export interface GetEngineStatusOutput {
    status?: string | undefined;
    startTime?: string | undefined;
    dbEngineVersion?: string | undefined;
    role?: string | undefined;
    dfeQueryEngine?: string | undefined;
    gremlin?: QueryLanguageVersion | undefined;
    sparql?: QueryLanguageVersion | undefined;
    opencypher?: QueryLanguageVersion | undefined;
    labMode?: {
        [key: string]: string | undefined;
    } | undefined;
    rollingBackTrxCount?: number | undefined;
    rollingBackTrxEarliestStartTime?: string | undefined;
    features?: {
        [key: string]: any | undefined;
    } | undefined;
    settings?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetGremlinQueryStatusInput {
    queryId: string;
}
export interface QueryEvalStats {
    waited?: number | undefined;
    elapsed?: number | undefined;
    cancelled?: boolean | undefined;
    subqueries?: any | undefined;
}
export interface GetGremlinQueryStatusOutput {
    queryId?: string | undefined;
    queryString?: string | undefined;
    queryEvalStats?: QueryEvalStats | undefined;
}
export interface GetIndexRebuildStatusInput {
    rebuildId: string;
}
export type Scope = "ALL" | "QUADS" | "DICTIONARIES" | (string & {});
export interface GetIndexRebuildStatusOutput {
    status: RebuildStatus;
    scope: Scope;
    concurrency: number;
    writeBufferSize: WriteBufferSize;
    startTime: Date;
    progressPercentage: number;
    estimatedEndTime?: Date | undefined;
    endTime?: Date | undefined;
    failureReason?: string | undefined;
}
export type PositiveInteger = number;
export interface GetLoaderJobStatusInput {
    loadId: string;
    details?: boolean | undefined;
    errors?: boolean | undefined;
    page?: number | undefined;
    errorsPerPage?: number | undefined;
}
export interface GetLoaderJobStatusOutput {
    status: string;
    payload: any;
}
export interface GetMLDataProcessingJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
}
export interface MlResourceDefinition {
    name?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    outputLocation?: string | undefined;
    failureReason?: string | undefined;
    cloudwatchLogUrl?: string | undefined;
}
export interface GetMLDataProcessingJobOutput {
    status?: string | undefined;
    id?: string | undefined;
    processingJob?: MlResourceDefinition | undefined;
}
export interface GetMLEndpointInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
}
export interface MlConfigDefinition {
    name?: string | undefined;
    arn?: string | undefined;
}
export interface GetMLEndpointOutput {
    status?: string | undefined;
    id?: string | undefined;
    endpoint?: MlResourceDefinition | undefined;
    endpointConfig?: MlConfigDefinition | undefined;
}
export interface GetMLModelTrainingJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
}
export type MlModels = MlConfigDefinition[];
export interface GetMLModelTrainingJobOutput {
    status?: string | undefined;
    id?: string | undefined;
    processingJob?: MlResourceDefinition | undefined;
    hpoJob?: MlResourceDefinition | undefined;
    modelTransformJob?: MlResourceDefinition | undefined;
    mlModels?: MlConfigDefinition[] | undefined;
}
export interface GetMLModelTransformJobInput {
    id: string;
    neptuneIamRoleArn?: string | undefined;
}
export type Models = MlConfigDefinition[];
export interface GetMLModelTransformJobOutput {
    status?: string | undefined;
    id?: string | undefined;
    baseProcessingJob?: MlResourceDefinition | undefined;
    remoteModelTransformJob?: MlResourceDefinition | undefined;
    models?: MlConfigDefinition[] | undefined;
}
export interface GetOpenCypherQueryStatusInput {
    queryId: string;
}
export interface GetOpenCypherQueryStatusOutput {
    queryId?: string | undefined;
    queryString?: string | undefined;
    queryEvalStats?: QueryEvalStats | undefined;
}
export interface GetPropertygraphStatisticsRequest {
}
export interface StatisticsSummary {
    signatureCount?: number | undefined;
    instanceCount?: number | undefined;
    predicateCount?: number | undefined;
}
export interface Statistics {
    autoCompute?: boolean | undefined;
    active?: boolean | undefined;
    statisticsId?: string | undefined;
    date?: Date | undefined;
    note?: string | undefined;
    signatureInfo?: StatisticsSummary | undefined;
}
export interface GetPropertygraphStatisticsOutput {
    status: string;
    payload: Statistics;
}
export type IteratorType = "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | "TRIM_HORIZON" | "LATEST" | (string & {});
export type Encoding = "gzip" | (string & {});
export interface GetPropertygraphStreamInput {
    limit?: number | undefined;
    iteratorType?: IteratorType | undefined;
    commitNum?: number | undefined;
    opNum?: number | undefined;
    encoding?: Encoding | undefined;
}
export interface PropertygraphData {
    id: string;
    type: string;
    key: string;
    value: any;
    from?: string | undefined;
    to?: string | undefined;
}
export interface PropertygraphRecord {
    commitTimestampInMillis: number;
    eventId: {
        [key: string]: string | undefined;
    };
    data: PropertygraphData;
    op: string;
    isLastOp?: boolean | undefined;
}
export type PropertygraphRecordsList = PropertygraphRecord[];
export interface GetPropertygraphStreamOutput {
    lastEventId: {
        [key: string]: string | undefined;
    };
    lastTrxTimestampInMillis: number;
    format: string;
    records: PropertygraphRecord[];
    totalRecords: number;
}
export type GraphSummaryType = "basic" | "detailed" | (string & {});
export interface GetPropertygraphSummaryInput {
    mode?: GraphSummaryType | undefined;
}
export type NodeLabels = string[];
export type EdgeLabels = string[];
export type LongValuedMap = {
    [key: string]: number | undefined;
};
export type LongValuedMapList = {
    [key: string]: number | undefined;
}[];
export type NodeProperties = string[];
export type OutgoingEdgeLabels = string[];
export interface NodeStructure {
    count?: number | undefined;
    nodeProperties?: string[] | undefined;
    distinctOutgoingEdgeLabels?: string[] | undefined;
}
export type NodeStructures = NodeStructure[];
export type EdgeProperties = string[];
export interface EdgeStructure {
    count?: number | undefined;
    edgeProperties?: string[] | undefined;
}
export type EdgeStructures = EdgeStructure[];
export interface PropertygraphSummary {
    numNodes?: number | undefined;
    numEdges?: number | undefined;
    numNodeLabels?: number | undefined;
    numEdgeLabels?: number | undefined;
    nodeLabels?: string[] | undefined;
    edgeLabels?: string[] | undefined;
    numNodeProperties?: number | undefined;
    numEdgeProperties?: number | undefined;
    nodeProperties?: {
        [key: string]: number | undefined;
    }[] | undefined;
    edgeProperties?: {
        [key: string]: number | undefined;
    }[] | undefined;
    totalNodePropertyValues?: number | undefined;
    totalEdgePropertyValues?: number | undefined;
    nodeStructures?: NodeStructure[] | undefined;
    edgeStructures?: EdgeStructure[] | undefined;
}
export interface PropertygraphSummaryValueMap {
    version?: string | undefined;
    lastStatisticsComputationTime?: Date | undefined;
    graphSummary?: PropertygraphSummary | undefined;
}
export interface GetPropertygraphSummaryOutput {
    statusCode?: number | undefined;
    payload?: PropertygraphSummaryValueMap | undefined;
}
export interface GetRDFGraphSummaryInput {
    mode?: GraphSummaryType | undefined;
}
export type Classes = string[];
export type Predicates = string[];
export interface SubjectStructure {
    count?: number | undefined;
    predicates?: string[] | undefined;
}
export type SubjectStructures = SubjectStructure[];
export interface RDFGraphSummary {
    numDistinctSubjects?: number | undefined;
    numDistinctPredicates?: number | undefined;
    numQuads?: number | undefined;
    numClasses?: number | undefined;
    classes?: string[] | undefined;
    predicates?: {
        [key: string]: number | undefined;
    }[] | undefined;
    subjectStructures?: SubjectStructure[] | undefined;
}
export interface RDFGraphSummaryValueMap {
    version?: string | undefined;
    lastStatisticsComputationTime?: Date | undefined;
    graphSummary?: RDFGraphSummary | undefined;
}
export interface GetRDFGraphSummaryOutput {
    statusCode?: number | undefined;
    payload?: RDFGraphSummaryValueMap | undefined;
}
export interface GetSparqlStatisticsRequest {
}
export interface GetSparqlStatisticsOutput {
    status: string;
    payload: Statistics;
}
export interface GetSparqlStreamInput {
    limit?: number | undefined;
    iteratorType?: IteratorType | undefined;
    commitNum?: number | undefined;
    opNum?: number | undefined;
    encoding?: Encoding | undefined;
}
export interface SparqlData {
    stmt: string;
}
export interface SparqlRecord {
    commitTimestampInMillis: number;
    eventId: {
        [key: string]: string | undefined;
    };
    data: SparqlData;
    op: string;
    isLastOp?: boolean | undefined;
}
export type SparqlRecordsList = SparqlRecord[];
export interface GetSparqlStreamOutput {
    lastEventId: {
        [key: string]: string | undefined;
    };
    lastTrxTimestampInMillis: number;
    format: string;
    records: SparqlRecord[];
    totalRecords: number;
}
export interface GetStorageInfoRequest {
}
export interface StorageMetrics {
    sizeInBytes: number;
    count: number;
}
export interface QuadsInfo {
    SPOG?: StorageMetrics | undefined;
    POGS?: StorageMetrics | undefined;
    GPSO?: StorageMetrics | undefined;
    OSGP?: StorageMetrics | undefined;
    PZSOG?: StorageMetrics | undefined;
}
export interface QuadsIndexesInfo {
    RDF?: QuadsInfo | undefined;
    PG?: QuadsInfo | undefined;
}
export interface DictionariesInfo {
    total?: StorageMetrics | undefined;
    blobs?: StorageMetrics | undefined;
}
export interface UndoLogsMetrics {
    sizeInBytes: number;
    listSize: number;
}
export interface GetStorageOutput {
    totalStorageBytesUsed?: number | undefined;
    quads?: QuadsIndexesInfo | undefined;
    dictionaries?: DictionariesInfo | undefined;
    undoLogs?: UndoLogsMetrics | undefined;
    streams?: StorageMetrics | undefined;
    dfeStatistics?: StorageMetrics | undefined;
    schema?: StorageMetrics | undefined;
    internals?: StorageMetrics | undefined;
}
export interface ListGremlinQueriesInput {
    includeWaiting?: boolean | undefined;
}
export interface GremlinQueryStatus {
    queryId?: string | undefined;
    queryString?: string | undefined;
    queryEvalStats?: QueryEvalStats | undefined;
}
export type GremlinQueries = GremlinQueryStatus[];
export interface ListGremlinQueriesOutput {
    acceptedQueryCount?: number | undefined;
    runningQueryCount?: number | undefined;
    queries?: GremlinQueryStatus[] | undefined;
}
export interface ListIndexRebuildsRequest {
}
export type RebuildIdList = string[];
export interface ListIndexRebuildsOutput {
    rebuildIds: string[];
}
export interface ListLoaderJobsInput {
    limit?: number | undefined;
    includeQueuedLoads?: boolean | undefined;
}
export type StringList = string[];
export interface LoaderIdResult {
    loadIds?: string[] | undefined;
}
export interface ListLoaderJobsOutput {
    status: string;
    payload: LoaderIdResult;
}
export interface ListMLDataProcessingJobsInput {
    maxItems?: number | undefined;
    neptuneIamRoleArn?: string | undefined;
}
export interface ListMLDataProcessingJobsOutput {
    ids?: string[] | undefined;
}
export interface ListMLEndpointsInput {
    maxItems?: number | undefined;
    neptuneIamRoleArn?: string | undefined;
}
export interface ListMLEndpointsOutput {
    ids?: string[] | undefined;
}
export interface ListMLModelTrainingJobsInput {
    maxItems?: number | undefined;
    neptuneIamRoleArn?: string | undefined;
}
export interface ListMLModelTrainingJobsOutput {
    ids?: string[] | undefined;
}
export interface ListMLModelTransformJobsInput {
    maxItems?: number | undefined;
    neptuneIamRoleArn?: string | undefined;
}
export interface ListMLModelTransformJobsOutput {
    ids?: string[] | undefined;
}
export interface ListOpenCypherQueriesInput {
    includeWaiting?: boolean | undefined;
}
export type OpenCypherQueries = GremlinQueryStatus[];
export interface ListOpenCypherQueriesOutput {
    acceptedQueryCount?: number | undefined;
    runningQueryCount?: number | undefined;
    queries?: GremlinQueryStatus[] | undefined;
}
export type StatisticsAutoGenerationMode = "disableAutoCompute" | "enableAutoCompute" | "refresh" | (string & {});
export interface ManagePropertygraphStatisticsInput {
    mode?: StatisticsAutoGenerationMode | undefined;
}
export interface RefreshStatisticsIdMap {
    statisticsId?: string | undefined;
}
export interface ManagePropertygraphStatisticsOutput {
    status: string;
    payload?: RefreshStatisticsIdMap | undefined;
}
export interface ManageSparqlStatisticsInput {
    mode?: StatisticsAutoGenerationMode | undefined;
}
export interface ManageSparqlStatisticsOutput {
    status: string;
    payload?: RefreshStatisticsIdMap | undefined;
}
export interface StartIndexRebuildInput {
    scope?: Scope | undefined;
    concurrency?: number | undefined;
    writeBufferSize?: WriteBufferSize | undefined;
    clientToken?: string | undefined;
}
export interface StartIndexRebuildOutput {
    status: RebuildStatus;
    rebuildId: string;
    scope: Scope;
    concurrency: number;
    writeBufferSize: WriteBufferSize;
}
export type Format = "csv" | "opencypher" | "ntriples" | "nquads" | "rdfxml" | "turtle" | (string & {});
export type S3BucketRegion = "us-east-1" | "us-east-2" | "us-west-1" | "us-west-2" | "ca-central-1" | "sa-east-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "eu-west-3" | "eu-central-1" | "me-south-1" | "af-south-1" | "ap-east-1" | "ap-northeast-1" | "ap-northeast-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-south-1" | "cn-north-1" | "cn-northwest-1" | "us-gov-west-1" | "us-gov-east-1" | "ca-west-1" | "eu-south-2" | "il-central-1" | "me-central-1" | "ap-northeast-3" | "ap-southeast-3" | "ap-southeast-4" | "ap-southeast-5" | "ap-southeast-7" | "mx-central-1" | "ap-east-2" | "ap-south-2" | "eu-central-2" | (string & {});
export type Mode = "RESUME" | "NEW" | "AUTO" | (string & {});
export type Parallelism = "LOW" | "MEDIUM" | "HIGH" | "OVERSUBSCRIBE" | (string & {});
export interface StartLoaderJobInput {
    source: string;
    format: Format;
    s3BucketRegion: S3BucketRegion;
    iamRoleArn: string;
    mode?: Mode | undefined;
    failOnError?: boolean | undefined;
    parallelism?: Parallelism | undefined;
    parserConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    updateSingleCardinalityProperties?: boolean | undefined;
    queueRequest?: boolean | undefined;
    dependencies?: string[] | undefined;
    userProvidedEdgeIds?: boolean | undefined;
    edgeOnlyLoad?: boolean | undefined;
}
export interface StartLoaderJobOutput {
    status: string;
    payload: {
        [key: string]: string | undefined;
    };
}
export interface StartMLDataProcessingJobInput {
    id?: string | undefined;
    previousDataProcessingJobId?: string | undefined;
    inputDataS3Location: string;
    processedDataS3Location: string;
    sagemakerIamRoleArn?: string | undefined;
    neptuneIamRoleArn?: string | undefined;
    processingInstanceType?: string | undefined;
    processingInstanceVolumeSizeInGB?: number | undefined;
    processingTimeOutInSeconds?: number | undefined;
    modelType?: string | undefined;
    configFileName?: string | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    volumeEncryptionKMSKey?: string | undefined;
    s3OutputEncryptionKMSKey?: string | undefined;
}
export interface StartMLDataProcessingJobOutput {
    id?: string | undefined;
    arn?: string | undefined;
    creationTimeInMillis?: number | undefined;
}
export interface CustomModelTrainingParameters {
    sourceS3DirectoryPath: string;
    trainingEntryPointScript?: string | undefined;
    transformEntryPointScript?: string | undefined;
}
export interface StartMLModelTrainingJobInput {
    id?: string | undefined;
    previousModelTrainingJobId?: string | undefined;
    dataProcessingJobId: string;
    trainModelS3Location: string;
    sagemakerIamRoleArn?: string | undefined;
    neptuneIamRoleArn?: string | undefined;
    baseProcessingInstanceType?: string | undefined;
    trainingInstanceType?: string | undefined;
    trainingInstanceVolumeSizeInGB?: number | undefined;
    trainingTimeOutInSeconds?: number | undefined;
    maxHPONumberOfTrainingJobs?: number | undefined;
    maxHPOParallelTrainingJobs?: number | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    volumeEncryptionKMSKey?: string | undefined;
    s3OutputEncryptionKMSKey?: string | undefined;
    enableManagedSpotTraining?: boolean | undefined;
    customModelTrainingParameters?: CustomModelTrainingParameters | undefined;
}
export interface StartMLModelTrainingJobOutput {
    id?: string | undefined;
    arn?: string | undefined;
    creationTimeInMillis?: number | undefined;
}
export interface CustomModelTransformParameters {
    sourceS3DirectoryPath: string;
    transformEntryPointScript?: string | undefined;
}
export interface StartMLModelTransformJobInput {
    id?: string | undefined;
    dataProcessingJobId?: string | undefined;
    mlModelTrainingJobId?: string | undefined;
    trainingJobName?: string | undefined;
    modelTransformOutputS3Location: string;
    sagemakerIamRoleArn?: string | undefined;
    neptuneIamRoleArn?: string | undefined;
    customModelTransformParameters?: CustomModelTransformParameters | undefined;
    baseProcessingInstanceType?: string | undefined;
    baseProcessingInstanceVolumeSizeInGB?: number | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    volumeEncryptionKMSKey?: string | undefined;
    s3OutputEncryptionKMSKey?: string | undefined;
}
export interface StartMLModelTransformJobOutput {
    id?: string | undefined;
    arn?: string | undefined;
    creationTimeInMillis?: number | undefined;
}
export type CancelGremlinQueryError = BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Gremlin query. See Gremlin query cancellation for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelQuery IAM action in that cluster.
 */
export declare const cancelGremlinQuery: API.OperationMethod<CancelGremlinQueryInput & RegionInput, CancelGremlinQueryOutput, CancelGremlinQueryError, Credentials | HttpClient.HttpClient>;
export type CancelIndexRebuildError = AccessDeniedException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | PreconditionsFailedException | ReadOnlyViolationException | ServerShutdownException | TooManyRequestsException | UnsupportedOperationException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress index rebuild operation.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelIndexRebuild IAM action in that cluster.
 */
export declare const cancelIndexRebuild: API.OperationMethod<CancelIndexRebuildInput & RegionInput, CancelIndexRebuildOutput, CancelIndexRebuildError, Credentials | HttpClient.HttpClient>;
export type CancelLoaderJobError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified load job. This is an HTTP `DELETE` request. See Neptune Loader Get-Status API for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelLoaderJob IAM action in that cluster..
 */
export declare const cancelLoaderJob: API.OperationMethod<CancelLoaderJobInput & RegionInput, CancelLoaderJobOutput, CancelLoaderJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Neptune ML data processing job. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLDataProcessingJob IAM action in that cluster.
 */
export declare const cancelMLDataProcessingJob: API.OperationMethod<CancelMLDataProcessingJobInput & RegionInput, CancelMLDataProcessingJobOutput, CancelMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLModelTrainingJob IAM action in that cluster.
 */
export declare const cancelMLModelTrainingJob: API.OperationMethod<CancelMLModelTrainingJobInput & RegionInput, CancelMLModelTrainingJobOutput, CancelMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type CancelMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelMLModelTransformJob IAM action in that cluster.
 */
export declare const cancelMLModelTransformJob: API.OperationMethod<CancelMLModelTransformJobInput & RegionInput, CancelMLModelTransformJobOutput, CancelMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export type CancelOpenCypherQueryError = BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a specified openCypher query. See Neptune openCypher status endpoint for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CancelQuery IAM action in that cluster.
 */
export declare const cancelOpenCypherQuery: API.OperationMethod<CancelOpenCypherQueryInput & RegionInput, CancelOpenCypherQueryOutput, CancelOpenCypherQueryError, Credentials | HttpClient.HttpClient>;
export type CreateMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML inference endpoint that lets you query one specific model that the model-training process constructed. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:CreateMLEndpoint IAM action in that cluster.
 */
export declare const createMLEndpoint: API.OperationMethod<CreateMLEndpointInput & RegionInput, CreateMLEndpointOutput, CreateMLEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels the creation of a Neptune ML inference endpoint. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteMLEndpoint IAM action in that cluster.
 */
export declare const deleteMLEndpoint: API.OperationMethod<DeleteMLEndpointInput & RegionInput, DeleteMLEndpointOutput, DeleteMLEndpointError, Credentials | HttpClient.HttpClient>;
export type DeletePropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes statistics for Gremlin and openCypher (property graph) data.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteStatistics IAM action in that cluster.
 */
export declare const deletePropertygraphStatistics: API.OperationMethod<DeletePropertygraphStatisticsRequest & RegionInput, DeletePropertygraphStatisticsOutput, DeletePropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type DeleteSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes SPARQL statistics
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:DeleteStatistics IAM action in that cluster.
 */
export declare const deleteSparqlStatistics: API.OperationMethod<DeleteSparqlStatisticsRequest & RegionInput, DeleteSparqlStatisticsOutput, DeleteSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type ExecuteFastResetError = AccessDeniedException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | ServerShutdownException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * The fast reset REST API lets you reset a Neptune graph quicky and easily, removing all of its data.
 *
 * Neptune fast reset is a two-step process. First you call `ExecuteFastReset` with `action` set to `initiateDatabaseReset`. This returns a UUID token which you then include when calling `ExecuteFastReset` again with `action` set to `performDatabaseReset`. See Empty an Amazon Neptune DB cluster using the fast reset API.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ResetDatabase IAM action in that cluster.
 */
export declare const executeFastReset: API.OperationMethod<ExecuteFastResetInput & RegionInput, ExecuteFastResetOutput, ExecuteFastResetError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinExplainQueryError = BadRequestException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes a Gremlin Explain query.
 *
 * Amazon Neptune has added a Gremlin feature named `explain` that provides is a self-service tool for understanding the execution approach being taken by the Neptune engine for the query. You invoke it by adding an `explain` parameter to an HTTP call that submits a Gremlin query.
 *
 * The explain feature provides information about the logical structure of query execution plans. You can use this information to identify potential evaluation and execution bottlenecks and to tune your query, as explained in Tuning Gremlin queries. You can also use query hints to improve query execution plans.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinExplainQuery: API.OperationMethod<ExecuteGremlinExplainQueryInput & RegionInput, ExecuteGremlinExplainQueryOutput, ExecuteGremlinExplainQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinProfileQueryError = BadRequestException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes a Gremlin Profile query, which runs a specified traversal, collects various metrics about the run, and produces a profile report as output. See Gremlin profile API in Neptune for details.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ReadDataViaQuery IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinProfileQuery: API.OperationMethod<ExecuteGremlinProfileQueryInput & RegionInput, ExecuteGremlinProfileQueryOutput, ExecuteGremlinProfileQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteGremlinQueryError = BadRequestException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * This commands executes a Gremlin query. Amazon Neptune is compatible with Apache TinkerPop3 and Gremlin, so you can use the Gremlin traversal language to query the graph, as described under The Graph in the Apache TinkerPop3 documentation. More details can also be found in Accessing a Neptune graph with Gremlin.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that enables one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeGremlinQuery: API.OperationMethod<ExecuteGremlinQueryInput & RegionInput, ExecuteGremlinQueryOutput, ExecuteGremlinQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteOpenCypherExplainQueryError = BadRequestException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes an openCypher `explain` request. See The openCypher explain feature for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ReadDataViaQuery IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeOpenCypherExplainQuery: API.OperationMethod<ExecuteOpenCypherExplainQueryInput & RegionInput, ExecuteOpenCypherExplainQueryOutput, ExecuteOpenCypherExplainQueryError, Credentials | HttpClient.HttpClient>;
export type ExecuteOpenCypherQueryError = BadRequestException | CancelledByMaintenanceException | CancelledByUserException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MalformedQueryException | MemoryLimitExceededException | MissingParameterException | ParsingException | PreconditionsFailedException | QueryLimitExceededException | QueryLimitException | QueryTooLargeException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Executes an openCypher query. See Accessing the Neptune Graph with openCypher for more information.
 *
 * Neptune supports building graph applications using openCypher, which is currently one of the most popular query languages among developers working with graph databases. Developers, business analysts, and data scientists like openCypher's declarative, SQL-inspired syntax because it provides a familiar structure in which to querying property graphs.
 *
 * The openCypher language was originally developed by Neo4j, then open-sourced in 2015 and contributed to the openCypher project under an Apache 2 open-source license.
 *
 * Note that when invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-db:ReadDataViaQuery
 *
 * - neptune-db:WriteDataViaQuery
 *
 * - neptune-db:DeleteDataViaQuery
 *
 * Note also that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const executeOpenCypherQuery: API.OperationMethod<ExecuteOpenCypherQueryInput & RegionInput, ExecuteOpenCypherQueryOutput, ExecuteOpenCypherQueryError, Credentials | HttpClient.HttpClient>;
export type GetEngineStatusError = ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the status of the graph database on the host.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetEngineStatus IAM action in that cluster.
 */
export declare const getEngineStatus: API.OperationMethod<GetEngineStatusRequest & RegionInput, GetEngineStatusOutput, GetEngineStatusError, Credentials | HttpClient.HttpClient>;
export type GetGremlinQueryStatusError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets the status of a specified Gremlin query.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getGremlinQueryStatus: API.OperationMethod<GetGremlinQueryStatusInput & RegionInput, GetGremlinQueryStatusOutput, GetGremlinQueryStatusError, Credentials | HttpClient.HttpClient>;
export type GetIndexRebuildStatusError = AccessDeniedException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | ValidationException | CommonErrors;
/**
 * Retrieves the status of an index rebuild operation.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetIndexRebuildStatus IAM action in that cluster.
 */
export declare const getIndexRebuildStatus: API.OperationMethod<GetIndexRebuildStatusInput & RegionInput, GetIndexRebuildStatusOutput, GetIndexRebuildStatusError, Credentials | HttpClient.HttpClient>;
export type GetLoaderJobStatusError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets status information about a specified load job. Neptune keeps track of the most recent 1,024 bulk load jobs, and stores the last 10,000 error details per job.
 *
 * See Neptune Loader Get-Status API for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetLoaderJobStatus IAM action in that cluster..
 */
export declare const getLoaderJobStatus: API.OperationMethod<GetLoaderJobStatusInput & RegionInput, GetLoaderJobStatusOutput, GetLoaderJobStatusError, Credentials | HttpClient.HttpClient>;
export type GetMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about a specified data processing job. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:neptune-db:GetMLDataProcessingJobStatus IAM action in that cluster.
 */
export declare const getMLDataProcessingJob: API.OperationMethod<GetMLDataProcessingJobInput & RegionInput, GetMLDataProcessingJobOutput, GetMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type GetMLEndpointError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves details about an inference endpoint. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLEndpointStatus IAM action in that cluster.
 */
export declare const getMLEndpoint: API.OperationMethod<GetMLEndpointInput & RegionInput, GetMLEndpointOutput, GetMLEndpointError, Credentials | HttpClient.HttpClient>;
export type GetMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves information about a Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLModelTrainingJobStatus IAM action in that cluster.
 */
export declare const getMLModelTrainingJob: API.OperationMethod<GetMLModelTrainingJobInput & RegionInput, GetMLModelTrainingJobOutput, GetMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type GetMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets information about a specified model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetMLModelTransformJobStatus IAM action in that cluster.
 */
export declare const getMLModelTransformJob: API.OperationMethod<GetMLModelTransformJobInput & RegionInput, GetMLModelTransformJobOutput, GetMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export type GetOpenCypherQueryStatusError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the status of a specified openCypher query.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getOpenCypherQueryStatus: API.OperationMethod<GetOpenCypherQueryStatusInput & RegionInput, GetOpenCypherQueryStatusOutput, GetOpenCypherQueryStatusError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets property graph statistics (Gremlin and openCypher).
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStatisticsStatus IAM action in that cluster.
 */
export declare const getPropertygraphStatistics: API.OperationMethod<GetPropertygraphStatisticsRequest & RegionInput, GetPropertygraphStatisticsOutput, GetPropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphStreamError = ClientTimeoutException | ConstraintViolationException | ExpiredStreamException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MemoryLimitExceededException | PreconditionsFailedException | StreamRecordsNotFoundException | ThrottlingException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a stream for a property graph.
 *
 * With the Neptune Streams feature, you can generate a complete sequence of change-log entries that record every change made to your graph data as it happens. `GetPropertygraphStream` lets you collect these change-log entries for a property graph.
 *
 * The Neptune streams feature needs to be enabled on your Neptune DBcluster. To enable streams, set the neptune_streams DB cluster parameter to `1`.
 *
 * See Capturing graph changes in real time using Neptune streams.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStreamRecords IAM action in that cluster.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that enables one of the following IAM actions, depending on the query:
 *
 * Note that you can restrict property-graph queries using the following IAM context keys:
 *
 * - neptune-db:QueryLanguage:Gremlin
 *
 * - neptune-db:QueryLanguage:OpenCypher
 *
 * See Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getPropertygraphStream: API.OperationMethod<GetPropertygraphStreamInput & RegionInput, GetPropertygraphStreamOutput, GetPropertygraphStreamError, Credentials | HttpClient.HttpClient>;
export type GetPropertygraphSummaryError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a graph summary for a property graph.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetGraphSummary IAM action in that cluster.
 */
export declare const getPropertygraphSummary: API.OperationMethod<GetPropertygraphSummaryInput & RegionInput, GetPropertygraphSummaryOutput, GetPropertygraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetRDFGraphSummaryError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a graph summary for an RDF graph.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetGraphSummary IAM action in that cluster.
 */
export declare const getRDFGraphSummary: API.OperationMethod<GetRDFGraphSummaryInput & RegionInput, GetRDFGraphSummaryOutput, GetRDFGraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets RDF statistics (SPARQL).
 */
export declare const getSparqlStatistics: API.OperationMethod<GetSparqlStatisticsRequest & RegionInput, GetSparqlStatisticsOutput, GetSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetSparqlStreamError = ClientTimeoutException | ConstraintViolationException | ExpiredStreamException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MemoryLimitExceededException | PreconditionsFailedException | StreamRecordsNotFoundException | ThrottlingException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Gets a stream for an RDF graph.
 *
 * With the Neptune Streams feature, you can generate a complete sequence of change-log entries that record every change made to your graph data as it happens. `GetSparqlStream` lets you collect these change-log entries for an RDF graph.
 *
 * The Neptune streams feature needs to be enabled on your Neptune DBcluster. To enable streams, set the neptune_streams DB cluster parameter to `1`.
 *
 * See Capturing graph changes in real time using Neptune streams.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStreamRecords IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Sparql IAM condition key can be used in the policy document to restrict the use of SPARQL queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const getSparqlStream: API.OperationMethod<GetSparqlStreamInput & RegionInput, GetSparqlStreamOutput, GetSparqlStreamError, Credentials | HttpClient.HttpClient>;
export type GetStorageInfoError = AccessDeniedException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | PreconditionsFailedException | ServerShutdownException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves storage information for the Neptune database instance, including approximate total storage used and per-category size and entry counts. Storage categories include:
 *
 * - *Quad indexes* - the indexes that store graph data, for both RDF (SPARQL) and Property Graph (Gremlin/openCypher) models.
 *
 * - *Dictionaries* - the term dictionaries, including total dictionary storage and the portion used by blob (large value) entries.
 *
 * - *Undo logs* - the undo logs, reported as a total size and the number of entries in the undo log list.
 *
 * - *Streams* - the change-log streams.
 *
 * - *Schema* - the schema.
 *
 * - *DFE statistics* - the DFE engine statistics.
 *
 * - *System metadata* - internal system metadata.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetStorageInfo IAM action in that cluster.
 */
export declare const getStorageInfo: API.OperationMethod<GetStorageInfoRequest & RegionInput, GetStorageOutput, GetStorageInfoError, Credentials | HttpClient.HttpClient>;
export type ListGremlinQueriesError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists active Gremlin queries. See Gremlin query status API for details about the output.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:Gremlin IAM condition key can be used in the policy document to restrict the use of Gremlin queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const listGremlinQueries: API.OperationMethod<ListGremlinQueriesInput & RegionInput, ListGremlinQueriesOutput, ListGremlinQueriesError, Credentials | HttpClient.HttpClient>;
export type ListIndexRebuildsError = AccessDeniedException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | MethodNotAllowedException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves a list of all index rebuild operation identifiers.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListIndexRebuilds IAM action in that cluster.
 */
export declare const listIndexRebuilds: API.OperationMethod<ListIndexRebuildsRequest & RegionInput, ListIndexRebuildsOutput, ListIndexRebuildsError, Credentials | HttpClient.HttpClient>;
export type ListLoaderJobsError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves a list of the `loadIds` for all active loader jobs.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListLoaderJobs IAM action in that cluster..
 */
export declare const listLoaderJobs: API.OperationMethod<ListLoaderJobsInput & RegionInput, ListLoaderJobsOutput, ListLoaderJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLDataProcessingJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of Neptune ML data processing jobs. See Listing active data-processing jobs using the Neptune ML dataprocessing command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLDataProcessingJobs IAM action in that cluster.
 */
export declare const listMLDataProcessingJobs: API.OperationMethod<ListMLDataProcessingJobsInput & RegionInput, ListMLDataProcessingJobsOutput, ListMLDataProcessingJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLEndpointsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists existing inference endpoints. See Managing inference endpoints using the endpoints command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLEndpoints IAM action in that cluster.
 */
export declare const listMLEndpoints: API.OperationMethod<ListMLEndpointsInput & RegionInput, ListMLEndpointsOutput, ListMLEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListMLModelTrainingJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists Neptune ML model-training jobs. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:neptune-db:ListMLModelTrainingJobs IAM action in that cluster.
 */
export declare const listMLModelTrainingJobs: API.OperationMethod<ListMLModelTrainingJobsInput & RegionInput, ListMLModelTrainingJobsOutput, ListMLModelTrainingJobsError, Credentials | HttpClient.HttpClient>;
export type ListMLModelTransformJobsError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of model transform job IDs. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ListMLModelTransformJobs IAM action in that cluster.
 */
export declare const listMLModelTransformJobs: API.OperationMethod<ListMLModelTransformJobsInput & RegionInput, ListMLModelTransformJobsOutput, ListMLModelTransformJobsError, Credentials | HttpClient.HttpClient>;
export type ListOpenCypherQueriesError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | FailureByQueryException | IllegalArgumentException | InvalidArgumentException | InvalidNumericDataException | InvalidParameterException | MissingParameterException | ParsingException | PreconditionsFailedException | ReadOnlyViolationException | TimeLimitExceededException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Lists active openCypher queries. See Neptune openCypher status endpoint for more information.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:GetQueryStatus IAM action in that cluster.
 *
 * Note that the neptune-db:QueryLanguage:OpenCypher IAM condition key can be used in the policy document to restrict the use of openCypher queries (see Condition keys available in Neptune IAM data-access policy statements).
 */
export declare const listOpenCypherQueries: API.OperationMethod<ListOpenCypherQueriesInput & RegionInput, ListOpenCypherQueriesOutput, ListOpenCypherQueriesError, Credentials | HttpClient.HttpClient>;
export type ManagePropertygraphStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Manages the generation and use of property graph statistics.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ManageStatistics IAM action in that cluster.
 */
export declare const managePropertygraphStatistics: API.OperationMethod<ManagePropertygraphStatisticsInput & RegionInput, ManagePropertygraphStatisticsOutput, ManagePropertygraphStatisticsError, Credentials | HttpClient.HttpClient>;
export type ManageSparqlStatisticsError = AccessDeniedException | BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | PreconditionsFailedException | ReadOnlyViolationException | StatisticsNotAvailableException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Manages the generation and use of RDF graph statistics.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:ManageStatistics IAM action in that cluster.
 */
export declare const manageSparqlStatistics: API.OperationMethod<ManageSparqlStatisticsInput & RegionInput, ManageSparqlStatisticsOutput, ManageSparqlStatisticsError, Credentials | HttpClient.HttpClient>;
export type StartIndexRebuildError = AccessDeniedException | ClientTimeoutException | ConcurrentModificationException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | MemoryLimitExceededException | MethodNotAllowedException | PreconditionsFailedException | ReadOnlyViolationException | ResourceNotFoundException | ServerShutdownException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Initiates an index rebuild operation to optimize storage and improve query performance. The rebuild operation reorganizes index to reclaim space and improve efficiency.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartIndexRebuild IAM action in that cluster.
 */
export declare const startIndexRebuild: API.OperationMethod<StartIndexRebuildInput & RegionInput, StartIndexRebuildOutput, StartIndexRebuildError, Credentials | HttpClient.HttpClient>;
export type StartLoaderJobError = BadRequestException | BulkLoadIdNotFoundException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InternalFailureException | InvalidArgumentException | InvalidParameterException | LoadUrlAccessDeniedException | MissingParameterException | PreconditionsFailedException | S3Exception | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Starts a Neptune bulk loader job to load data from an Amazon S3 bucket into a Neptune DB instance. See Using the Amazon Neptune Bulk Loader to Ingest Data.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartLoaderJob IAM action in that cluster.
 */
export declare const startLoaderJob: API.OperationMethod<StartLoaderJobInput & RegionInput, StartLoaderJobOutput, StartLoaderJobError, Credentials | HttpClient.HttpClient>;
export type StartMLDataProcessingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML data processing job for processing the graph data exported from Neptune for training. See The `dataprocessing` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelDataProcessingJob IAM action in that cluster.
 */
export declare const startMLDataProcessingJob: API.OperationMethod<StartMLDataProcessingJobInput & RegionInput, StartMLDataProcessingJobOutput, StartMLDataProcessingJobError, Credentials | HttpClient.HttpClient>;
export type StartMLModelTrainingJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new Neptune ML model training job. See Model training using the `modeltraining` command.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelTrainingJob IAM action in that cluster.
 */
export declare const startMLModelTrainingJob: API.OperationMethod<StartMLModelTrainingJobInput & RegionInput, StartMLModelTrainingJobOutput, StartMLModelTrainingJobError, Credentials | HttpClient.HttpClient>;
export type StartMLModelTransformJobError = BadRequestException | ClientTimeoutException | ConstraintViolationException | IllegalArgumentException | InvalidArgumentException | InvalidParameterException | MissingParameterException | MLResourceNotFoundException | PreconditionsFailedException | TooManyRequestsException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new model transform job. See Use a trained model to generate new model artifacts.
 *
 * When invoking this operation in a Neptune cluster that has IAM authentication enabled, the IAM user or role making the request must have a policy attached that allows the neptune-db:StartMLModelTransformJob IAM action in that cluster.
 */
export declare const startMLModelTransformJob: API.OperationMethod<StartMLModelTransformJobInput & RegionInput, StartMLModelTransformJobOutput, StartMLModelTransformJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=neptunedata.d.ts.map