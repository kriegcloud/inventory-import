import * as Effect from "effect/Effect";
import * as Aggregate from "../../Aggregate.ts";
import type * as Compaction from "../../Compaction.ts";
import type * as Rewrite from "../../Rewrite.ts";
import type { Verdict } from "./Check.ts";
import type { Interpreter } from "./Interpreter.ts";
import * as Paths from "./Paths.ts";
import type * as Smt from "./Smt.ts";
import type { Module, Node } from "./Value.ts";
/** What a file passes to `Domain.Compaction` or `Domain.Rewrite`: the object, as written. */
export interface Written {
    readonly module: Module;
    readonly node: Node;
    readonly name: string;
}
/** A compaction's definition, in whichever of the files declares it. */
export declare const compactionIn: (modules: ReadonlyArray<Module>, compaction: Compaction.Any) => Written | undefined;
/** A rewrite's definition, in whichever of the files declares it. */
export declare const rewriteIn: (modules: ReadonlyArray<Module>, rewrite: Rewrite.Any) => Written | undefined;
/** What one roll-up does, from any state the aggregate's rules allow. */
export interface CompactionRow {
    /** The paths through the roll-up that were checked. */
    readonly paths: number;
    /** Whether folding the roll-up from `initial` gives the state back. */
    readonly lossless: Verdict;
    /** Whether folding the roll-up onto the state it was made from leaves that state. */
    readonly standing: Verdict;
}
/**
 * Take a roll-up from any state that satisfies every invariant, along every
 * path through its code, and say whether folding it gives that state back:
 * from `initial`, as an instance read after the compaction folds it, and onto
 * the state itself, as the instance does when it commits it.
 */
export declare const compaction: (solver: Smt.Solver, interpreter: Interpreter, aggregate: Aggregate.Any, definition: Paths.Definition, cls: Compaction.Any, written: Written) => Effect.Effect<CompactionRow, Smt.SolverError, never>;
/** A source of events a rewrite is taken through: a command, or a compaction's roll-up. */
export type Source = {
    readonly _tag: "Command";
    readonly command: Paths.CommandClass;
} | {
    readonly _tag: "Rollup";
    readonly cls: Compaction.Any;
    readonly written: Written;
};
/** What a rewrite does to the events one source records. */
export interface RewriteRow {
    /** The command that records the events, or the compaction whose roll-up they are. */
    readonly step: string;
    /** The paths through it and the rewrite's handlers that were checked. */
    readonly paths: number;
    /** Whether the state the rewritten events fold to is one the state's schema allows. */
    readonly fits: Verdict;
    /** Each invariant, on the state the rewritten events fold to. */
    readonly verdicts: ReadonlyMap<string, Verdict>;
}
/**
 * Take a rewrite through every event an instance can hold. Each command, and
 * each roll-up, records its events from any state the rules allow; the
 * rewrite's handlers are run on them, and what they leave is folded onto the
 * state the rewritten history has reached: any the rules allow that is the
 * recorded one outside the parts the rewrite can change. Where every
 * invariant holds after that, on every path, no history the commands can
 * record is rewritten into one that breaks an invariant.
 */
export declare const rewrite: (solver: Smt.Solver, interpreter: Interpreter, aggregate: Aggregate.Any, definition: Paths.Definition, cls: Rewrite.Any, written: Written, sources: readonly Source[]) => Effect.Effect<{
    rows: RewriteRow[];
    /** The parts of the state the rewrite can leave other than they were. */
    differs: string[] | undefined;
}, Smt.SolverError, never>;
//# sourceMappingURL=History.d.ts.map