import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgentSpaceId = string;
export type ArtifactType = "TXT" | "PNG" | "JPEG" | "MD" | "PDF" | "DOCX" | "DOC" | "JSON" | "YAML" | (string & {});
export interface AddArtifactInput {
    agentSpaceId: string;
    artifactContent: Uint8Array;
    artifactType: ArtifactType;
    fileName: string;
}
export type ArtifactId = string;
export interface AddArtifactOutput {
    artifactId: string;
}
export type SecurityRequirementPackId = string;
export type SecurityRequirementName = string;
export interface CreateSecurityRequirementEntry {
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string | undefined;
}
export type CreateSecurityRequirementEntryList = CreateSecurityRequirementEntry[];
export interface BatchCreateSecurityRequirementsInput {
    packId: string;
    securityRequirements: CreateSecurityRequirementEntry[];
}
export interface BatchCreateSecurityRequirementResult {
    packId: string;
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type BatchCreateSecurityRequirementResultList = BatchCreateSecurityRequirementResult[];
export interface BatchSecurityRequirementError {
    securityRequirementName: string;
    code: string;
    message: string;
}
export type BatchSecurityRequirementErrors = BatchSecurityRequirementError[];
export interface BatchCreateSecurityRequirementsOutput {
    securityRequirements: BatchCreateSecurityRequirementResult[];
    errors: BatchSecurityRequirementError[];
}
export type CodeReviewIdList = string[];
export interface BatchDeleteCodeReviewsInput {
    codeReviewIds: string[];
    agentSpaceId: string;
}
export interface DeleteCodeReviewFailure {
    codeReviewId?: string | undefined;
    reason?: string | undefined;
}
export type DeleteCodeReviewFailureList = DeleteCodeReviewFailure[];
export interface BatchDeleteCodeReviewsOutput {
    deleted?: string[] | undefined;
    failed?: DeleteCodeReviewFailure[] | undefined;
}
export type PentestIdList = string[];
export interface BatchDeletePentestsInput {
    pentestIds: string[];
    agentSpaceId: string;
}
export interface Endpoint {
    uri?: string | undefined;
}
export type EndpointList = Endpoint[];
export type UriList = string[];
export type AuthenticationProviderType = "SECRETS_MANAGER" | "AWS_LAMBDA" | "AWS_IAM_ROLE" | "AWS_INTERNAL" | (string & {});
export interface Authentication {
    providerType?: AuthenticationProviderType | undefined;
    value?: string | undefined;
}
export type SensitiveEmailAddress = string | redacted.Redacted<string>;
export interface Actor {
    identifier?: string | undefined;
    uris?: string[] | undefined;
    authentication?: Authentication | undefined;
    description?: string | undefined;
    enableEmailMfa?: boolean | undefined;
    mfaForwardingAddress?: string | redacted.Redacted<string> | undefined;
}
export type ActorList = Actor[];
export interface IntegratedDocument {
    integrationId: string;
    resourceId: string;
}
export interface DocumentInfo {
    s3Location?: string | undefined;
    artifactId?: string | undefined;
    integratedDocument?: IntegratedDocument | undefined;
}
export type DocumentList = DocumentInfo[];
export interface SourceCodeRepository {
    s3Location?: string | undefined;
}
export type SourceCodeRepositoryList = SourceCodeRepository[];
export interface IntegratedRepository {
    integrationId: string;
    providerResourceId: string;
    branch?: string | undefined;
}
export type IntegratedRepositoryList = IntegratedRepository[];
export type CaCertificatePem = string | redacted.Redacted<string>;
export type CaCertificateSource = {
    inlinePem: string | redacted.Redacted<string>;
    artifactId?: undefined;
    s3Location?: undefined;
} | {
    inlinePem?: undefined;
    artifactId: string;
    s3Location?: undefined;
} | {
    inlinePem?: undefined;
    artifactId?: undefined;
    s3Location: string;
};
export interface TrustedCaCertificate {
    source: CaCertificateSource;
}
export type TrustedCaCertificateList = TrustedCaCertificate[];
export type ClientCertificateName = string;
export type ClientCertificateOriginList = string[];
export interface ClientCertificate {
    name: string;
    secretArn: string;
    origins: string[];
}
export type ClientCertificateList = ClientCertificate[];
export interface Assets {
    endpoints?: Endpoint[] | undefined;
    actors?: Actor[] | undefined;
    documents?: DocumentInfo[] | undefined;
    sourceCode?: SourceCodeRepository[] | undefined;
    integratedRepositories?: IntegratedRepository[] | undefined;
    trustedCaCertificates?: TrustedCaCertificate[] | undefined;
    clientCertificates?: ClientCertificate[] | undefined;
}
export type RiskType = "CROSS_SITE_SCRIPTING" | "DEFAULT_CREDENTIALS" | "INSECURE_DIRECT_OBJECT_REFERENCE" | "PRIVILEGE_ESCALATION" | "SERVER_SIDE_TEMPLATE_INJECTION" | "COMMAND_INJECTION" | "CODE_INJECTION" | "SQL_INJECTION" | "ARBITRARY_FILE_UPLOAD" | "INSECURE_DESERIALIZATION" | "LOCAL_FILE_INCLUSION" | "INFORMATION_DISCLOSURE" | "PATH_TRAVERSAL" | "SERVER_SIDE_REQUEST_FORGERY" | "JSON_WEB_TOKEN_VULNERABILITIES" | "XML_EXTERNAL_ENTITY" | "FILE_DELETION" | "OTHER" | "GRAPHQL_VULNERABILITIES" | "BUSINESS_LOGIC_VULNERABILITIES" | "CRYPTOGRAPHIC_VULNERABILITIES" | "DENIAL_OF_SERVICE" | "FILE_ACCESS" | "FILE_CREATION" | "DATABASE_MODIFICATION" | "DATABASE_ACCESS" | "OUTBOUND_SERVICE_REQUEST" | "UNKNOWN" | (string & {});
export type RiskTypeList = RiskType[];
export type ServiceRole = string;
export interface CloudWatchLog {
    logGroup?: string | undefined;
    logStream?: string | undefined;
}
export type VpcArn = string;
export type SecurityGroupArn = string;
export type SecurityGroupArns = string[];
export type SubnetArn = string;
export type SubnetArns = string[];
export interface VpcConfig {
    vpcArn?: string | undefined;
    securityGroupArns?: string[] | undefined;
    subnetArns?: string[] | undefined;
}
export type NetworkTrafficRuleEffect = "ALLOW" | "DENY" | (string & {});
export type NetworkTrafficRuleType = "URL" | (string & {});
export interface NetworkTrafficRule {
    effect?: NetworkTrafficRuleEffect | undefined;
    pattern?: string | undefined;
    networkTrafficRuleType?: NetworkTrafficRuleType | undefined;
}
export type NetworkTrafficRuleList = NetworkTrafficRule[];
export interface CustomHeader {
    name?: string | undefined;
    value?: string | undefined;
}
export type CustomHeaderList = CustomHeader[];
export interface NetworkTrafficConfig {
    rules?: NetworkTrafficRule[] | undefined;
    customHeaders?: CustomHeader[] | undefined;
}
export type CodeRemediationStrategy = "AUTOMATIC" | "DISABLED" | (string & {});
export type CleanUpStrategy = "BEST_EFFORT_DELETE" | "RETAIN_ALL" | (string & {});
export type SkillType = "FINDING_PERSONALIZATION" | "LOGIN_OPTIMIZATION" | (string & {});
export type SkillTypeList = SkillType[];
export interface ReportDestination {
    integrationId: string;
    containerId: string;
    parentId?: string | undefined;
    documentId?: string | undefined;
}
export type RiskLevel = "UNKNOWN" | "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type RiskLevelFilterList = RiskLevel[];
export type ConfidenceLevel = "FALSE_POSITIVE" | "UNCONFIRMED" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type ConfidenceLevelFilterList = ConfidenceLevel[];
export type FindingStatus = "ACTIVE" | "RESOLVED" | "ACCEPTED" | "FALSE_POSITIVE" | (string & {});
export type FindingStatusFilterList = FindingStatus[];
export type RiskTypeFilterList = RiskType[];
export type ReportFilterValue = string;
export type ReportFilterList = string[];
export type TaskExecutionStatus = "IN_PROGRESS" | "ABORTED" | "COMPLETED" | "INTERNAL_ERROR" | "FAILED" | (string & {});
export type TaskExecutionStatusFilterList = TaskExecutionStatus[];
export interface ReportFilters {
    riskLevels?: RiskLevel[] | undefined;
    confidenceLevels?: ConfidenceLevel[] | undefined;
    statuses?: FindingStatus[] | undefined;
    riskTypes?: RiskType[] | undefined;
    findingTypes?: string[] | undefined;
    taskStatuses?: TaskExecutionStatus[] | undefined;
    annotationNotes?: boolean | undefined;
    complianceReport?: boolean | undefined;
}
export interface CiCdConfiguration {
    enabled?: boolean | undefined;
}
export type TestScopeType = "WEB_APP" | "GENERATIVE_AI_APP" | (string & {});
export interface TestScope {
    type: TestScopeType;
}
export interface Pentest {
    pentestId: string;
    agentSpaceId: string;
    title: string;
    assets: Assets;
    excludeRiskTypes?: RiskType[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    vpcConfig?: VpcConfig | undefined;
    networkTrafficConfig?: NetworkTrafficConfig | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    cleanUpStrategy?: CleanUpStrategy | undefined;
    disableManagedSkills?: SkillType[] | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PentestList = Pentest[];
export interface DeletePentestFailure {
    pentestId?: string | undefined;
    reason?: string | undefined;
}
export type DeletePentestFailureList = DeletePentestFailure[];
export interface BatchDeletePentestsOutput {
    deleted?: Pentest[] | undefined;
    failed?: DeletePentestFailure[] | undefined;
}
export type SecurityRequirementNameList = string[];
export interface BatchDeleteSecurityRequirementsInput {
    packId: string;
    securityRequirementNames: string[];
}
export interface BatchDeleteSecurityRequirementsOutput {
    deletedSecurityRequirementNames: string[];
    errors: BatchSecurityRequirementError[];
}
export type ThreatModelIdList = string[];
export interface BatchDeleteThreatModelsInput {
    threatModelIds: string[];
    agentSpaceId: string;
}
export interface DeleteThreatModelFailure {
    threatModelId?: string | undefined;
    reason?: string | undefined;
}
export type DeleteThreatModelFailureList = DeleteThreatModelFailure[];
export interface BatchDeleteThreatModelsOutput {
    deleted?: string[] | undefined;
    failed?: DeleteThreatModelFailure[] | undefined;
}
export type FindingIdList = string[];
export interface BatchDisassociateFindingIssueInput {
    agentSpaceId: string;
    pentestJobId?: string | undefined;
    codeReviewJobId?: string | undefined;
    findingIds: string[];
}
export type ErrorCode = "CLIENT_ERROR" | "INTERNAL_ERROR" | "STOPPED_BY_USER" | (string & {});
export interface BatchDisassociateFindingIssueError_ {
    findingId: string;
    code: ErrorCode;
    message: string;
}
export type BatchDisassociateFindingIssueErrors = BatchDisassociateFindingIssueError_[];
export interface BatchDisassociateFindingIssueOutput {
    errors: BatchDisassociateFindingIssueError_[];
}
export interface IssueDestination {
    integrationId: string;
    projectKey: string;
}
export interface BatchExportFindingsInput {
    agentSpaceId: string;
    pentestJobId?: string | undefined;
    codeReviewJobId?: string | undefined;
    issueDestination: IssueDestination;
    findingIds: string[];
}
export type Provider = "GITHUB" | "GITLAB" | "BITBUCKET" | "CONFLUENCE" | "AZURE_DEVOPS" | "JIRA" | (string & {});
export interface LinkedIssue {
    provider?: Provider | undefined;
    integrationId?: string | undefined;
    projectKey?: string | undefined;
    issueKey?: string | undefined;
    issueId?: string | undefined;
    issueUrl?: string | undefined;
    siteUrl?: string | undefined;
}
export interface BatchExportFindingResult {
    findingId: string;
    linkedIssue: LinkedIssue;
}
export type BatchExportFindingResultList = BatchExportFindingResult[];
export interface BatchExportFindingError {
    findingId: string;
    code: ErrorCode;
    message: string;
}
export type BatchExportFindingErrorList = BatchExportFindingError[];
export interface BatchExportFindingsOutput {
    results: BatchExportFindingResult[];
    errors: BatchExportFindingError[];
}
export type AgentSpaceIdList = string[];
export interface BatchGetAgentSpacesInput {
    agentSpaceIds: string[];
}
export type VpcConfigs = VpcConfig[];
export type LogGroupArn = string;
export type LogGroupArns = string[];
export type S3BucketArn = string;
export type S3BucketArns = string[];
export type SecretArn = string;
export type SecretArns = string[];
export type LambdaFunctionArn = string;
export type LambdaFunctionArns = string[];
export type IamRoles = string[];
export interface AWSResources {
    vpcs?: VpcConfig[] | undefined;
    logGroups?: string[] | undefined;
    s3Buckets?: string[] | undefined;
    secretArns?: string[] | undefined;
    lambdaFunctionArns?: string[] | undefined;
    iamRoles?: string[] | undefined;
}
export type TargetDomainIdList = string[];
export interface CodeReviewSettings {
    controlsScanning: boolean;
    generalPurposeScanning: boolean;
}
export type KmsKeyId = string;
export interface AgentSpace {
    agentSpaceId: string;
    name: string;
    description?: string | undefined;
    awsResources?: AWSResources | undefined;
    targetDomainIds?: string[] | undefined;
    codeReviewSettings?: CodeReviewSettings | undefined;
    kmsKeyId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type AgentSpaceList = AgentSpace[];
export interface BatchGetAgentSpacesOutput {
    agentSpaces?: AgentSpace[] | undefined;
    notFound?: string[] | undefined;
}
export type ArtifactIds = string[];
export interface BatchGetArtifactMetadataInput {
    agentSpaceId: string;
    artifactIds: string[];
}
export interface ArtifactMetadataItem {
    agentSpaceId: string;
    artifactId: string;
    fileName: string;
    updatedAt: Date;
}
export type ArtifactMetadataList = ArtifactMetadataItem[];
export interface BatchGetArtifactMetadataOutput {
    artifactMetadataList: ArtifactMetadataItem[];
}
export type CodeReviewJobIdList = string[];
export interface BatchGetCodeReviewJobsInput {
    codeReviewJobIds: string[];
    agentSpaceId: string;
}
export type JobStatus = "IN_PROGRESS" | "STOPPING" | "STOPPED" | "FAILED" | "COMPLETED" | (string & {});
export type StepName = "PREFLIGHT" | "STATIC_ANALYSIS" | "PENTEST" | "FINALIZING" | "VALIDATION" | (string & {});
export type StepStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOPPED" | (string & {});
export interface Step {
    name?: StepName | undefined;
    status?: StepStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type StepList = Step[];
export type ContextType = "ERROR" | "CLIENT_ERROR" | "WARNING" | "INFO" | (string & {});
export interface ExecutionContext {
    contextType?: ContextType | undefined;
    context?: string | undefined;
    timestamp?: Date | undefined;
}
export type ExecutionContextList = ExecutionContext[];
export interface ErrorInformation {
    code?: ErrorCode | undefined;
    message?: string | undefined;
}
export interface CodeReviewJob {
    codeReviewJobId?: string | undefined;
    codeReviewId?: string | undefined;
    title?: string | undefined;
    overview?: string | undefined;
    status?: JobStatus | undefined;
    documents?: DocumentInfo[] | undefined;
    sourceCode?: SourceCodeRepository[] | undefined;
    steps?: Step[] | undefined;
    executionContext?: ExecutionContext[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    errorInformation?: ErrorInformation | undefined;
    integratedRepositories?: IntegratedRepository[] | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewJobList = CodeReviewJob[];
export interface BatchGetCodeReviewJobsOutput {
    codeReviewJobs?: CodeReviewJob[] | undefined;
    notFound?: string[] | undefined;
}
export type TaskIdList = string[];
export interface BatchGetCodeReviewJobTasksInput {
    agentSpaceId: string;
    codeReviewJobTaskIds: string[];
}
export interface Category {
    name?: string | undefined;
    isPrimary?: boolean | undefined;
}
export type CategoryList = Category[];
export type LogType = "CLOUDWATCH" | (string & {});
export interface LogLocation {
    logType?: LogType | undefined;
    cloudWatchLog?: CloudWatchLog | undefined;
}
export interface CodeReviewJobTask {
    taskId: string;
    codeReviewId?: string | undefined;
    codeReviewJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    description?: string | undefined;
    categories?: Category[] | undefined;
    riskType?: RiskType | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    logsLocation?: LogLocation | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewJobTaskList = CodeReviewJobTask[];
export interface BatchGetCodeReviewJobTasksOutput {
    codeReviewJobTasks?: CodeReviewJobTask[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetCodeReviewsInput {
    codeReviewIds: string[];
    agentSpaceId: string;
}
export type ValidationMode = "DISABLED" | "SIMULATED" | (string & {});
export interface CodeReview {
    codeReviewId: string;
    agentSpaceId: string;
    title: string;
    assets: Assets;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    validationMode?: ValidationMode | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewList = CodeReview[];
export interface BatchGetCodeReviewsOutput {
    codeReviews?: CodeReview[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetFindingsInput {
    findingIds: string[];
    agentSpaceId: string;
}
export type ValidationStatus = "CONFIRMED" | "NOT_REPRODUCED" | "VALIDATION_FAILED" | "VALIDATING" | "NOT_VALIDATED" | (string & {});
export type CodeRemediationTaskStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface CodeRemediationTaskDetails {
    repoName?: string | undefined;
    codeDiffLink?: string | undefined;
    pullRequestLink?: string | undefined;
}
export type CodeRemediationTaskDetailsList = CodeRemediationTaskDetails[];
export interface CodeRemediationTask {
    status: CodeRemediationTaskStatus;
    statusReason?: string | undefined;
    taskDetails?: CodeRemediationTaskDetails[] | undefined;
}
export interface CodeLocation {
    filePath: string;
    lineStart?: number | undefined;
    lineEnd?: number | undefined;
    label?: string | undefined;
}
export type CodeLocationList = CodeLocation[];
export interface VerificationScriptEnvVar {
    name?: string | undefined;
    value?: string | undefined;
}
export type VerificationScriptEnvVarList = VerificationScriptEnvVar[];
export interface VerificationScript {
    scriptType?: string | undefined;
    scriptUrl?: string | undefined;
    instructions?: string | undefined;
    envVars?: VerificationScriptEnvVar[] | undefined;
}
export type StringList = string[];
export interface Finding {
    findingId: string;
    agentSpaceId: string;
    pentestId?: string | undefined;
    pentestJobId?: string | undefined;
    codeReviewId?: string | undefined;
    codeReviewJobId?: string | undefined;
    taskId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: FindingStatus | undefined;
    riskType?: string | undefined;
    riskLevel?: RiskLevel | undefined;
    riskScore?: string | undefined;
    reasoning?: string | undefined;
    confidence?: ConfidenceLevel | undefined;
    validationStatus?: ValidationStatus | undefined;
    attackScript?: string | undefined;
    remediationCode?: string | undefined;
    codeRemediationTask?: CodeRemediationTask | undefined;
    lastUpdatedBy?: string | undefined;
    customerNote?: string | undefined;
    codeLocations?: CodeLocation[] | undefined;
    verificationScript?: VerificationScript | undefined;
    alignmentRationale?: string | undefined;
    revalidationJobIds?: string[] | undefined;
    originalFindingId?: string | undefined;
    linkedIssue?: LinkedIssue | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type FindingList = Finding[];
export interface BatchGetFindingsOutput {
    findings?: Finding[] | undefined;
    notFound?: string[] | undefined;
}
export type PentestJobIdList = string[];
export interface BatchGetPentestJobsInput {
    pentestJobIds: string[];
    agentSpaceId: string;
}
export type JobType = "FULL" | "REVALIDATION" | "CICD" | (string & {});
export type ScopeDecision = "IN_SCOPE" | "SCOPED_OUT" | "SCOPE_CONFLICT" | (string & {});
export interface ScopeResult {
    decision: ScopeDecision;
    reason: string;
}
export interface ScopeChange {
    integrationId: string;
    providerResourceId: string;
    baseCommitSha?: string | undefined;
    headCommitSha: string;
    triggerRunId?: string | undefined;
}
export type ScopeChangeList = ScopeChange[];
export interface PentestJob {
    pentestJobId?: string | undefined;
    pentestId?: string | undefined;
    title?: string | undefined;
    overview?: string | undefined;
    status?: JobStatus | undefined;
    endpoints?: Endpoint[] | undefined;
    actors?: Actor[] | undefined;
    documents?: DocumentInfo[] | undefined;
    sourceCode?: SourceCodeRepository[] | undefined;
    excludePaths?: Endpoint[] | undefined;
    allowedDomains?: Endpoint[] | undefined;
    excludeRiskTypes?: RiskType[] | undefined;
    steps?: Step[] | undefined;
    executionContext?: ExecutionContext[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    vpcConfig?: VpcConfig | undefined;
    networkTrafficConfig?: NetworkTrafficConfig | undefined;
    errorInformation?: ErrorInformation | undefined;
    integratedRepositories?: IntegratedRepository[] | undefined;
    trustedCaCertificates?: TrustedCaCertificate[] | undefined;
    clientCertificates?: ClientCertificate[] | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    cleanUpStrategy?: CleanUpStrategy | undefined;
    disableManagedSkills?: SkillType[] | undefined;
    maxTaskHours?: number | undefined;
    jobType?: JobType | undefined;
    selectedFindingIds?: string[] | undefined;
    reportDestination?: ReportDestination | undefined;
    reportUrl?: string | undefined;
    scopeResult?: ScopeResult | undefined;
    scopeChanges?: ScopeChange[] | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PentestJobList = PentestJob[];
export interface BatchGetPentestJobsOutput {
    pentestJobs?: PentestJob[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetPentestJobTasksInput {
    agentSpaceId: string;
    taskIds: string[];
}
export interface Task {
    taskId: string;
    pentestId?: string | undefined;
    pentestJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    description?: string | undefined;
    categories?: Category[] | undefined;
    riskType?: RiskType | undefined;
    targetEndpoint?: Endpoint | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    logsLocation?: LogLocation | undefined;
    taskHours?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type TaskList = Task[];
export interface BatchGetPentestJobTasksOutput {
    tasks?: Task[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetPentestsInput {
    pentestIds: string[];
    agentSpaceId: string;
}
export interface BatchGetPentestsOutput {
    pentests?: Pentest[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetSecurityRequirementsInput {
    packId: string;
    securityRequirementNames: string[];
}
export interface BatchGetSecurityRequirementResult {
    packId: string;
    name: string;
    description: string;
    domain: string;
    evaluation: string;
    remediation?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type BatchGetSecurityRequirementResultList = BatchGetSecurityRequirementResult[];
export interface BatchGetSecurityRequirementsOutput {
    securityRequirements: BatchGetSecurityRequirementResult[];
    errors: BatchSecurityRequirementError[];
}
export interface BatchGetTargetDomainsInput {
    targetDomainIds: string[];
}
export type TargetDomainId = string;
export type TargetDomainStatus = "PENDING" | "VERIFIED" | "FAILED" | "UNREACHABLE" | (string & {});
export type DomainVerificationMethod = "DNS_TXT" | "HTTP_ROUTE" | "PRIVATE_VPC" | (string & {});
export type DNSRecordType = "TXT" | (string & {});
export interface DnsVerification {
    token?: string | undefined;
    dnsRecordName?: string | undefined;
    dnsRecordType?: DNSRecordType | undefined;
}
export interface HttpVerification {
    token?: string | undefined;
    routePath?: string | undefined;
}
export interface VerificationDetails {
    method?: DomainVerificationMethod | undefined;
    dnsTxt?: DnsVerification | undefined;
    httpRoute?: HttpVerification | undefined;
}
export interface TargetDomain {
    targetDomainId: string;
    domainName: string;
    verificationStatus?: TargetDomainStatus | undefined;
    verificationStatusReason?: string | undefined;
    verificationDetails?: VerificationDetails | undefined;
    createdAt?: Date | undefined;
    verifiedAt?: Date | undefined;
}
export type TargetDomainList = TargetDomain[];
export interface BatchGetTargetDomainsOutput {
    targetDomains?: TargetDomain[] | undefined;
    notFound?: string[] | undefined;
}
export type ThreatModelJobIdList = string[];
export interface BatchGetThreatModelJobsInput {
    threatModelJobIds: string[];
    agentSpaceId: string;
}
export interface ThreatModelJob {
    threatModelJobId?: string | undefined;
    threatModelId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    executionStartTime?: Date | undefined;
    executionEndTime?: Date | undefined;
    sourceCode?: SourceCodeRepository[] | undefined;
    integratedRepositories?: IntegratedRepository[] | undefined;
    documents?: DocumentInfo[] | undefined;
    scopeDocs?: DocumentInfo[] | undefined;
    errorInformation?: ErrorInformation | undefined;
    systemOverview?: string | undefined;
    reportDestination?: ReportDestination | undefined;
}
export type ThreatModelJobList = ThreatModelJob[];
export interface BatchGetThreatModelJobsOutput {
    threatModelJobs?: ThreatModelJob[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetThreatModelJobTasksInput {
    agentSpaceId: string;
    threatModelJobTaskIds: string[];
}
export interface ThreatModelJobTask {
    taskId: string;
    threatModelId?: string | undefined;
    threatModelJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    description?: string | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    logsLocation?: LogLocation | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatModelJobTaskList = ThreatModelJobTask[];
export interface BatchGetThreatModelJobTasksOutput {
    threatModelJobTasks?: ThreatModelJobTask[] | undefined;
    notFound?: string[] | undefined;
}
export interface BatchGetThreatModelsInput {
    threatModelIds: string[];
    agentSpaceId: string;
}
export interface ThreatModel {
    threatModelId: string;
    agentSpaceId: string;
    title: string;
    description?: string | undefined;
    assets: Assets;
    scopeDocs?: DocumentInfo[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    reportDestination?: ReportDestination | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatModelList = ThreatModel[];
export interface BatchGetThreatModelsOutput {
    threatModels?: ThreatModel[] | undefined;
    notFound?: string[] | undefined;
}
export type ThreatIdList = string[];
export interface BatchGetThreatsInput {
    threatIds: string[];
    agentSpaceId: string;
}
export type ThreatSeverity = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFO" | (string & {});
export type ThreatStatus = "OPEN" | "RESOLVED" | "DISMISSED" | (string & {});
export interface ThreatAnchorShape {
    kind?: string | undefined;
    id?: string | undefined;
    packageId?: string | undefined;
}
export interface ThreatEvidenceShape {
    packageId?: string | undefined;
    path?: string | undefined;
}
export type ThreatEvidenceList = ThreatEvidenceShape[];
export type StrideCategory = "SPOOFING" | "TAMPERING" | "REPUDIATION" | "INFORMATION_DISCLOSURE" | "DENIAL_OF_SERVICE" | "ELEVATION_OF_PRIVILEGE" | (string & {});
export type StrideCategoryList = StrideCategory[];
export type ThreatActor = "CUSTOMER" | "AGENT" | (string & {});
export interface Threat {
    threatId?: string | undefined;
    threatJobId?: string | undefined;
    title?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    status?: ThreatStatus | undefined;
    comments?: string | undefined;
    threatSource?: string | undefined;
    prerequisites?: string | undefined;
    threatAction?: string | undefined;
    threatImpact?: string | undefined;
    impactedGoal?: string[] | undefined;
    impactedAssets?: string[] | undefined;
    anchor?: ThreatAnchorShape | undefined;
    evidence?: ThreatEvidenceShape[] | undefined;
    stride?: StrideCategory[] | undefined;
    recommendation?: string | undefined;
    createdBy?: ThreatActor | undefined;
    updatedBy?: ThreatActor | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatList = Threat[];
export interface BatchGetThreatsOutput {
    threats?: Threat[] | undefined;
    notFound?: string[] | undefined;
}
export interface UpdateSecurityRequirementEntry {
    name: string;
    description?: string | undefined;
    domain?: string | undefined;
    evaluation?: string | undefined;
    remediation?: string | undefined;
}
export type UpdateSecurityRequirementEntryList = UpdateSecurityRequirementEntry[];
export interface BatchUpdateSecurityRequirementsInput {
    packId: string;
    securityRequirements: UpdateSecurityRequirementEntry[];
}
export interface BatchUpdateSecurityRequirementsOutput {
    updatedSecurityRequirementNames: string[];
    errors: BatchSecurityRequirementError[];
}
export type AgentName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAgentSpaceInput {
    name: string;
    description?: string | undefined;
    awsResources?: AWSResources | undefined;
    targetDomainIds?: string[] | undefined;
    codeReviewSettings?: CodeReviewSettings | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAgentSpaceOutput {
    agentSpaceId: string;
    name: string;
    description?: string | undefined;
    awsResources?: AWSResources | undefined;
    targetDomainIds?: string[] | undefined;
    codeReviewSettings?: CodeReviewSettings | undefined;
    kmsKeyId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type IdCInstanceArn = string;
export type RoleArn = string;
export type DefaultKmsKeyId = string;
export interface CreateApplicationRequest {
    idcInstanceArn?: string | undefined;
    roleArn?: string | undefined;
    defaultKmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ApplicationId = string;
export interface CreateApplicationResponse {
    applicationId: string;
}
export interface CreateCodeReviewInput {
    title: string;
    agentSpaceId: string;
    assets: Assets;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    validationMode?: ValidationMode | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
}
export interface CreateCodeReviewOutput {
    codeReviewId: string;
    title?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    assets?: Assets | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    agentSpaceId?: string | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    validationMode?: ValidationMode | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
}
export type AuthCode = string;
export type CsrfState = string;
export type TargetUrl = string;
export interface GitHubIntegrationInput {
    code: string;
    state: string;
    organizationName?: string | undefined;
    targetUrl?: string | undefined;
    installationId?: string | undefined;
}
export type AccessToken = string | redacted.Redacted<string>;
export type GitLabTokenType = "PERSONAL" | "GROUP" | (string & {});
export interface GitLabIntegrationInput {
    accessToken: string | redacted.Redacted<string>;
    targetUrl?: string | undefined;
    tokenType: GitLabTokenType;
    groupId?: string | undefined;
}
export type BitbucketInstallationId = string;
export type BitbucketWorkspace = string;
export interface BitbucketIntegrationInput {
    installationId: string;
    workspace: string;
    code: string;
    state: string;
}
export type ConfluenceInstallationId = string;
export type ConfluenceSiteUrl = string;
export interface ConfluenceIntegrationInput {
    installationId: string;
    code: string;
    state: string;
    siteUrl: string;
}
export interface AzureDevOpsIntegrationInput {
    code: string;
    state: string;
    organizationName: string;
}
export interface BitbucketDataCenterIntegrationInput {
    targetUrl: string;
    code: string;
    state: string;
}
export type JiraInstallationId = string;
export type JiraSiteUrl = string;
export interface JiraIntegrationInput {
    installationId: string;
    code: string;
    state: string;
    siteUrl: string;
}
export type ProviderInput = {
    github: GitHubIntegrationInput;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    bitbucketDataCenter?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab: GitLabIntegrationInput;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    bitbucketDataCenter?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket: BitbucketIntegrationInput;
    confluence?: undefined;
    azureDevOps?: undefined;
    bitbucketDataCenter?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence: ConfluenceIntegrationInput;
    azureDevOps?: undefined;
    bitbucketDataCenter?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps: AzureDevOpsIntegrationInput;
    bitbucketDataCenter?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    bitbucketDataCenter: BitbucketDataCenterIntegrationInput;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    bitbucketDataCenter?: undefined;
    jira: JiraIntegrationInput;
};
export type PrivateConnectionName = string;
export interface CreateIntegrationInput {
    provider: Provider;
    input: ProviderInput;
    integrationDisplayName: string;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    privateConnectionName?: string | undefined;
}
export type IntegrationId = string;
export interface CreateIntegrationOutput {
    integrationId: string;
}
export type MembershipId = string;
export type MembershipType = "USER" | "GROUP" | (string & {});
export type UserRole = "MEMBER" | (string & {});
export interface UserConfig {
    role?: UserRole | undefined;
}
export type MembershipConfig = {
    user: UserConfig;
};
export interface CreateMembershipRequest {
    applicationId: string;
    agentSpaceId: string;
    membershipId: string;
    memberType: MembershipType;
    config?: MembershipConfig | undefined;
}
export interface CreateMembershipResponse {
}
export interface CreatePentestInput {
    title: string;
    agentSpaceId: string;
    assets?: Assets | undefined;
    excludeRiskTypes?: RiskType[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    vpcConfig?: VpcConfig | undefined;
    networkTrafficConfig?: NetworkTrafficConfig | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    cleanUpStrategy?: CleanUpStrategy | undefined;
    disableManagedSkills?: SkillType[] | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
}
export interface CreatePentestOutput {
    pentestId?: string | undefined;
    title?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    assets?: Assets | undefined;
    excludeRiskTypes?: RiskType[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    agentSpaceId?: string | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
}
export type HostAddress = string;
export type PrivateConnectionVpcId = string;
export type PrivateConnectionSubnetId = string;
export type PrivateConnectionSubnetIds = string[];
export type PrivateConnectionSecurityGroupId = string;
export type PrivateConnectionSecurityGroupIds = string[];
export type IpAddressType = "IPV4" | "IPV6" | "DUAL_STACK" | (string & {});
export type MaxIpv4AddressesPerEni = number;
export type PortRange = string;
export type PortRanges = string[];
export type CertificateChain = string | redacted.Redacted<string>;
export type ResourceConfigDnsResolution = "PUBLIC" | "IN_VPC" | (string & {});
export interface ServiceManagedInput {
    hostAddress: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    ipv4AddressesPerEni?: number | undefined;
    portRanges?: string[] | undefined;
    certificate?: string | redacted.Redacted<string> | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
}
export type ResourceConfigurationId = string;
export interface SelfManagedInput {
    resourceConfigurationId: string;
    certificate?: string | redacted.Redacted<string> | undefined;
}
export type PrivateConnectionMode = {
    serviceManaged: ServiceManagedInput;
    selfManaged?: undefined;
} | {
    serviceManaged?: undefined;
    selfManaged: SelfManagedInput;
};
export interface CreatePrivateConnectionInput {
    privateConnectionName: string;
    mode: PrivateConnectionMode;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PrivateConnectionType = "SERVICE_MANAGED" | "SELF_MANAGED" | (string & {});
export type PrivateConnectionStatus = "ACTIVE" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type ResourceGatewayId = string;
export interface CreatePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SecurityRequirementPackName = string;
export type SecurityRequirementPackStatus = "ENABLED" | "DISABLED" | (string & {});
export interface CreateSecurityRequirementPackInput {
    name: string;
    description?: string | undefined;
    status?: SecurityRequirementPackStatus | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSecurityRequirementPackOutput {
    packId: string;
    status: SecurityRequirementPackStatus;
    kmsKeyId?: string | undefined;
}
export interface CreateTargetDomainInput {
    targetDomainName: string;
    verificationMethod: DomainVerificationMethod;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateTargetDomainOutput {
    targetDomainId: string;
    domainName: string;
    verificationStatus: TargetDomainStatus;
    verificationStatusReason?: string | undefined;
    verificationDetails?: VerificationDetails | undefined;
    createdAt?: Date | undefined;
    verifiedAt?: Date | undefined;
}
export interface CreateThreatInput {
    agentSpaceId: string;
    threatJobId: string;
    title?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    comments?: string | undefined;
    stride?: StrideCategory[] | undefined;
    threatSource?: string | undefined;
    prerequisites?: string | undefined;
    threatAction?: string | undefined;
    threatImpact?: string | undefined;
    impactedGoal?: string[] | undefined;
    impactedAssets?: string[] | undefined;
    anchor?: ThreatAnchorShape | undefined;
    evidence?: ThreatEvidenceShape[] | undefined;
    recommendation?: string | undefined;
}
export interface CreateThreatOutput {
    threatId: string;
    threatJobId: string;
    title?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    status?: ThreatStatus | undefined;
    comments?: string | undefined;
    stride?: StrideCategory[] | undefined;
    threatSource?: string | undefined;
    prerequisites?: string | undefined;
    threatAction?: string | undefined;
    threatImpact?: string | undefined;
    impactedGoal?: string[] | undefined;
    impactedAssets?: string[] | undefined;
    anchor?: ThreatAnchorShape | undefined;
    evidence?: ThreatEvidenceShape[] | undefined;
    recommendation?: string | undefined;
    createdBy?: ThreatActor | undefined;
    updatedBy?: ThreatActor | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateThreatModelInput {
    title: string;
    agentSpaceId: string;
    description?: string | undefined;
    assets?: Assets | undefined;
    scopeDocs?: DocumentInfo[] | undefined;
    serviceRole: string;
    logConfig?: CloudWatchLog | undefined;
    reportDestination?: ReportDestination | undefined;
}
export interface CreateThreatModelOutput {
    threatModelId: string;
    title?: string | undefined;
    agentSpaceId?: string | undefined;
    description?: string | undefined;
    assets?: Assets | undefined;
    scopeDocs?: DocumentInfo[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    reportDestination?: ReportDestination | undefined;
}
export interface DeleteAgentSpaceInput {
    agentSpaceId: string;
}
export interface DeleteAgentSpaceOutput {
    agentSpaceId?: string | undefined;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteArtifactInput {
    agentSpaceId: string;
    artifactId: string;
}
export interface DeleteArtifactOutput {
}
export interface DeleteIntegrationInput {
    integrationId: string;
}
export interface DeleteIntegrationOutput {
}
export interface DeleteMembershipRequest {
    applicationId: string;
    agentSpaceId: string;
    membershipId: string;
    memberType?: MembershipType | undefined;
}
export interface DeleteMembershipResponse {
}
export interface DeletePrivateConnectionInput {
    privateConnectionName: string;
}
export interface DeletePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteSecurityRequirementPackInput {
    packId: string;
}
export interface DeleteSecurityRequirementPackOutput {
}
export interface DeleteTargetDomainInput {
    targetDomainId: string;
}
export interface DeleteTargetDomainOutput {
    targetDomainId?: string | undefined;
}
export interface DescribePrivateConnectionInput {
    privateConnectionName: string;
}
export interface DescribePrivateConnectionOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationDomain = string;
export type IdCApplicationArn = string;
export interface IdCConfiguration {
    idcApplicationArn?: string | undefined;
    idcInstanceArn?: string | undefined;
}
export interface GetApplicationResponse {
    applicationId: string;
    domain: string;
    applicationName?: string | undefined;
    idcConfiguration?: IdCConfiguration | undefined;
    roleArn?: string | undefined;
    defaultKmsKeyId?: string | undefined;
}
export interface GetArtifactInput {
    agentSpaceId: string;
    artifactId: string;
}
export interface Artifact {
    contents: string;
    type: ArtifactType;
}
export interface GetArtifactOutput {
    agentSpaceId: string;
    artifactId: string;
    artifact: Artifact;
    fileName: string;
    updatedAt: Date;
}
export interface GetIntegrationInput {
    integrationId: string;
}
export type ProviderType = "SOURCE_CODE" | "DOCUMENTATION" | "ISSUE_TRACKING" | (string & {});
export interface GetIntegrationOutput {
    integrationId: string;
    installationId: string;
    provider: Provider;
    providerType: ProviderType;
    displayName?: string | undefined;
    kmsKeyId?: string | undefined;
    targetUrl?: string | undefined;
    siteUrl?: string | undefined;
    webhookUrl?: string | undefined;
    privateConnectionName?: string | undefined;
}
export interface GetSecurityRequirementPackInput {
    packId: string;
}
export type ManagementType = "AWS_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export type SecurityRequirementPackImportStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export interface GetSecurityRequirementPackOutput {
    packId: string;
    name: string;
    description?: string | undefined;
    vendorName?: string | undefined;
    managementType: ManagementType;
    status: SecurityRequirementPackStatus;
    importStatus?: SecurityRequirementPackImportStatus | undefined;
    createdAt: Date;
    updatedAt: Date;
    kmsKeyId?: string | undefined;
}
export type SecurityRequirementArtifactName = string;
export type SecurityRequirementArtifactFormat = "MD" | "PDF" | "TXT" | "DOCX" | "DOC" | (string & {});
export type SecurityRequirementDocumentContent = Uint8Array | redacted.Redacted<Uint8Array>;
export interface SecurityRequirementArtifact {
    name: string;
    format: SecurityRequirementArtifactFormat;
    content: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type SecurityRequirementArtifactList = SecurityRequirementArtifact[];
export type ImportSource = {
    documents: SecurityRequirementArtifact[];
};
export interface ImportSecurityRequirementsInput {
    packId: string;
    input: ImportSource;
}
export interface ImportSecurityRequirementsOutput {
    packId: string;
    importStatus: SecurityRequirementPackImportStatus;
}
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export interface InitiateProviderRegistrationInput {
    provider: Provider;
    targetUrl?: string | undefined;
    organizationName?: string | undefined;
    clientId?: string | undefined;
    clientSecret?: string | redacted.Redacted<string> | undefined;
}
export type Location = string;
export interface InitiateProviderRegistrationOutput {
    redirectTo: string;
    csrfState: string;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListActorMessagesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    agentSpaceId: string;
    pentestId: string;
    actorIdentifier: string;
}
export type SensitiveMessageSender = string | redacted.Redacted<string>;
export type SensitiveMessageSubject = string | redacted.Redacted<string>;
export type SensitiveMessageBody = string | redacted.Redacted<string>;
export interface ActorMessage {
    sender?: string | redacted.Redacted<string> | undefined;
    subject?: string | redacted.Redacted<string> | undefined;
    body?: string | redacted.Redacted<string> | undefined;
    receivedAt?: Date | undefined;
}
export type ActorMessageList = ActorMessage[];
export interface ListActorMessagesOutput {
    messages?: ActorMessage[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAgentSpacesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AgentSpaceSummary {
    agentSpaceId: string;
    name: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type AgentSpaceSummaryList = AgentSpaceSummary[];
export interface ListAgentSpacesOutput {
    agentSpaceSummaries?: AgentSpaceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListApplicationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ApplicationSummary {
    applicationId: string;
    applicationName: string;
    domain: string;
    defaultKmsKeyId?: string | undefined;
}
export type ApplicationSummaryList = ApplicationSummary[];
export interface ListApplicationsResponse {
    applicationSummaries: ApplicationSummary[];
    nextToken?: string | undefined;
}
export interface ListArtifactsInput {
    agentSpaceId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ArtifactSummary {
    artifactId: string;
    fileName: string;
    artifactType: ArtifactType;
}
export type ArtifactSummaryList = ArtifactSummary[];
export interface ListArtifactsOutput {
    artifactSummaries: ArtifactSummary[];
    nextToken?: string | undefined;
}
export interface ListCodeReviewJobsForCodeReviewInput {
    maxResults?: number | undefined;
    codeReviewId: string;
    agentSpaceId: string;
    nextToken?: string | undefined;
}
export interface CodeReviewJobSummary {
    codeReviewJobId: string;
    codeReviewId: string;
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewJobSummaryList = CodeReviewJobSummary[];
export interface ListCodeReviewJobsForCodeReviewOutput {
    codeReviewJobSummaries?: CodeReviewJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCodeReviewJobTasksInput {
    agentSpaceId: string;
    maxResults?: number | undefined;
    codeReviewJobId?: string | undefined;
    stepName?: StepName | undefined;
    categoryName?: string | undefined;
    nextToken?: string | undefined;
}
export interface CodeReviewJobTaskSummary {
    taskId: string;
    codeReviewId?: string | undefined;
    codeReviewJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    riskType?: RiskType | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewJobTaskSummaryList = CodeReviewJobTaskSummary[];
export interface ListCodeReviewJobTasksOutput {
    codeReviewJobTaskSummaries?: CodeReviewJobTaskSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCodeReviewsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    agentSpaceId: string;
}
export interface CodeReviewSummary {
    codeReviewId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type CodeReviewSummaryList = CodeReviewSummary[];
export interface ListCodeReviewsOutput {
    codeReviewSummaries?: CodeReviewSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDiscoveredEndpointsInput {
    maxResults?: number | undefined;
    pentestJobId: string;
    agentSpaceId: string;
    prefix?: string | undefined;
    nextToken?: string | undefined;
}
export interface DiscoveredEndpoint {
    uri: string;
    pentestJobId: string;
    taskId: string;
    agentSpaceId: string;
    evidence?: string | undefined;
    operation?: string | undefined;
    description?: string | undefined;
}
export type DiscoveredEndpointList = DiscoveredEndpoint[];
export interface ListDiscoveredEndpointsOutput {
    discoveredEndpoints?: DiscoveredEndpoint[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFindingsInput {
    maxResults?: number | undefined;
    pentestJobId?: string | undefined;
    codeReviewJobId?: string | undefined;
    agentSpaceId: string;
    nextToken?: string | undefined;
    riskType?: string | undefined;
    riskLevel?: RiskLevel | undefined;
    status?: FindingStatus | undefined;
    confidence?: ConfidenceLevel | undefined;
    name?: string | undefined;
}
export interface FindingSummary {
    findingId: string;
    agentSpaceId: string;
    pentestId?: string | undefined;
    pentestJobId?: string | undefined;
    codeReviewId?: string | undefined;
    codeReviewJobId?: string | undefined;
    name?: string | undefined;
    status?: FindingStatus | undefined;
    riskType?: string | undefined;
    riskLevel?: RiskLevel | undefined;
    confidence?: ConfidenceLevel | undefined;
    validationStatus?: ValidationStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type FindingSummaryList = FindingSummary[];
export interface ListFindingsOutput {
    findingsSummaries?: FindingSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ResourceType = "CODE_REPOSITORY" | "DOCUMENT" | "PROJECT" | (string & {});
export interface ListIntegratedResourcesInput {
    agentSpaceId: string;
    integrationId?: string | undefined;
    resourceType?: ResourceType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ProviderResourceName = string;
export type ProviderResourceId = string;
export type GitHubOwner = string;
export type AccessType = "PRIVATE" | "PUBLIC" | (string & {});
export interface GitHubRepositoryMetadata {
    name: string;
    providerResourceId: string;
    owner: string;
    accessType?: AccessType | undefined;
}
export type GitLabNamespace = string;
export interface GitLabRepositoryMetadata {
    name: string;
    providerResourceId: string;
    namespace: string;
    accessType?: AccessType | undefined;
}
export interface BitbucketRepositoryMetadata {
    name: string;
    providerResourceId: string;
    workspace: string;
    accessType?: AccessType | undefined;
}
export interface ConfluenceDocumentMetadata {
    name: string;
    providerResourceId: string;
    spaceKey: string;
    pageId: string;
    title?: string | undefined;
    spaceTitle?: string | undefined;
}
export type AzureDevOpsOrganization = string;
export interface AzureDevOpsRepositoryMetadata {
    name: string;
    providerResourceId: string;
    organization: string;
    project?: string | undefined;
    projectId?: string | undefined;
    accessType?: AccessType | undefined;
}
export interface JiraProjectMetadata {
    name: string;
    providerResourceId: string;
    projectKey: string;
    projectId: string;
    projectName?: string | undefined;
}
export type IntegratedResourceMetadata = {
    githubRepository: GitHubRepositoryMetadata;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository: GitLabRepositoryMetadata;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository: BitbucketRepositoryMetadata;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument: ConfluenceDocumentMetadata;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository: AzureDevOpsRepositoryMetadata;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject: JiraProjectMetadata;
};
export type TriggerEvent = "PULL_REQUEST_READY_FOR_REVIEW" | "PULL_REQUEST_DRAFT" | "PULL_REQUEST_LABEL_ADDED" | (string & {});
export type TriggerEventList = TriggerEvent[];
export type TriggerFilterType = "TARGET_BRANCH" | "LABEL" | (string & {});
export type TriggerRegexPattern = string;
export type TriggerRegexPatternList = string[];
export type TriggerFilterMatchMode = "INCLUDE" | "EXCLUDE" | (string & {});
export interface TriggerFilter {
    type: TriggerFilterType;
    patterns: string[];
    matchMode?: TriggerFilterMatchMode | undefined;
}
export type TriggerFilterList = TriggerFilter[];
export interface TriggerFilterGroup {
    events?: TriggerEvent[] | undefined;
    filters?: TriggerFilter[] | undefined;
}
export type TriggerFilterGroups = TriggerFilterGroup[];
export interface GitHubResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[] | undefined;
    leaveComments?: boolean | undefined;
    remediateCode?: boolean | undefined;
}
export interface GitLabResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[] | undefined;
    leaveComments?: boolean | undefined;
    remediateCode?: boolean | undefined;
}
export interface BitbucketResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[] | undefined;
    leaveComments?: boolean | undefined;
    remediateCode?: boolean | undefined;
}
export interface ConfluenceResourceCapabilities {
    fetchDocument?: boolean | undefined;
    createDocument?: boolean | undefined;
    updateDocument?: boolean | undefined;
}
export interface AzureDevOpsResourceCapabilities {
    triggerFilterGroups?: TriggerFilterGroup[] | undefined;
    leaveComments?: boolean | undefined;
    remediateCode?: boolean | undefined;
}
export interface JiraResourceCapabilities {
    createIssue?: boolean | undefined;
    commentIssue?: boolean | undefined;
}
export type ProviderResourceCapabilities = {
    github: GitHubResourceCapabilities;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab: GitLabResourceCapabilities;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket: BitbucketResourceCapabilities;
    confluence?: undefined;
    azureDevOps?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence: ConfluenceResourceCapabilities;
    azureDevOps?: undefined;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps: AzureDevOpsResourceCapabilities;
    jira?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    bitbucket?: undefined;
    confluence?: undefined;
    azureDevOps?: undefined;
    jira: JiraResourceCapabilities;
};
export interface IntegratedResourceSummary {
    integrationId: string;
    resource: IntegratedResourceMetadata;
    capabilities?: ProviderResourceCapabilities | undefined;
}
export type IntegratedResourceSummaryList = IntegratedResourceSummary[];
export interface ListIntegratedResourcesOutput {
    integratedResourceSummaries: IntegratedResourceSummary[];
    nextToken?: string | undefined;
}
export type IntegrationFilter = {
    provider: Provider;
    providerType?: undefined;
} | {
    provider?: undefined;
    providerType: ProviderType;
};
export interface ListIntegrationsInput {
    filter?: IntegrationFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IntegrationSummary {
    integrationId: string;
    installationId: string;
    provider: Provider;
    providerType: ProviderType;
    displayName: string;
    targetUrl?: string | undefined;
    webhookUrl?: string | undefined;
    privateConnectionName?: string | undefined;
}
export type IntegrationSummaryList = IntegrationSummary[];
export interface ListIntegrationsOutput {
    integrationSummaries: IntegrationSummary[];
    nextToken?: string | undefined;
}
export type MembershipTypeFilter = "USER" | "GROUP" | "ALL" | (string & {});
export interface ListMembershipsRequest {
    applicationId: string;
    agentSpaceId: string;
    memberType?: MembershipTypeFilter | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SensitiveEmail = string;
export interface UserMetadata {
    username: string;
    email: string;
}
export interface GroupMetadata {
    displayName?: string | undefined;
    description?: string | undefined;
}
export type MemberMetadata = {
    user: UserMetadata;
    group?: undefined;
} | {
    user?: undefined;
    group: GroupMetadata;
};
export interface MembershipSummary {
    membershipId: string;
    applicationId: string;
    agentSpaceId: string;
    memberType: MembershipType;
    config?: MembershipConfig | undefined;
    metadata?: MemberMetadata | undefined;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    updatedBy: string;
}
export type MembershipSummaryList = MembershipSummary[];
export interface ListMembershipsResponse {
    membershipSummaries: MembershipSummary[];
    nextToken?: string | undefined;
}
export interface ListPentestJobsForPentestInput {
    maxResults?: number | undefined;
    pentestId: string;
    agentSpaceId: string;
    nextToken?: string | undefined;
    jobType?: JobType | undefined;
}
export interface PentestJobSummary {
    pentestJobId: string;
    pentestId: string;
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    jobType?: JobType | undefined;
    reportUrl?: string | undefined;
}
export type PentestJobSummaryList = PentestJobSummary[];
export interface ListPentestJobsForPentestOutput {
    pentestJobSummaries?: PentestJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPentestJobTasksInput {
    agentSpaceId: string;
    maxResults?: number | undefined;
    pentestJobId?: string | undefined;
    stepName?: StepName | undefined;
    categoryName?: string | undefined;
    nextToken?: string | undefined;
}
export interface TaskSummary {
    taskId: string;
    pentestId?: string | undefined;
    pentestJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    riskType?: RiskType | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    taskHours?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type TaskSummaryList = TaskSummary[];
export interface ListPentestJobTasksOutput {
    taskSummaries?: TaskSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPentestsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    agentSpaceId: string;
}
export interface PentestSummary {
    pentestId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PentestSummaryList = PentestSummary[];
export interface ListPentestsOutput {
    pentestSummaries?: PentestSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPrivateConnectionsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PrivateConnectionSummary {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PrivateConnectionList = PrivateConnectionSummary[];
export interface ListPrivateConnectionsOutput {
    privateConnections: PrivateConnectionSummary[];
    nextToken?: string | undefined;
}
export interface ListSecurityRequirementPackFilter {
    managementType?: ManagementType | undefined;
    status?: SecurityRequirementPackStatus | undefined;
}
export interface ListSecurityRequirementPacksInput {
    filter?: ListSecurityRequirementPackFilter | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SecurityRequirementPackSummary {
    packId: string;
    name: string;
    description?: string | undefined;
    vendorName?: string | undefined;
    managementType: ManagementType;
    status: SecurityRequirementPackStatus;
    createdAt: Date;
    updatedAt: Date;
}
export type SecurityRequirementPackSummaryList = SecurityRequirementPackSummary[];
export interface ListSecurityRequirementPacksOutput {
    securityRequirementPackSummaries: SecurityRequirementPackSummary[];
    nextToken?: string | undefined;
}
export interface ListSecurityRequirementsInput {
    packId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SecurityRequirementSummary {
    packId: string;
    name: string;
    description: string;
    createdAt: Date;
    updatedAt: Date;
}
export type SecurityRequirementSummaryList = SecurityRequirementSummary[];
export interface ListSecurityRequirementsOutput {
    securityRequirementSummaries: SecurityRequirementSummary[];
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTargetDomainsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface TargetDomainSummary {
    targetDomainId: string;
    domainName: string;
    verificationStatus?: TargetDomainStatus | undefined;
}
export type TargetDomainSummaryList = TargetDomainSummary[];
export interface ListTargetDomainsOutput {
    targetDomainSummaries?: TargetDomainSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListThreatModelJobsInput {
    maxResults?: number | undefined;
    threatModelId: string;
    agentSpaceId: string;
    nextToken?: string | undefined;
}
export interface ThreatModelJobSummary {
    threatModelJobId: string;
    threatModelId: string;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatModelJobSummaryList = ThreatModelJobSummary[];
export interface ListThreatModelJobsOutput {
    threatModelJobSummaries?: ThreatModelJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListThreatModelJobTasksInput {
    agentSpaceId: string;
    maxResults?: number | undefined;
    threatModelJobId: string;
    nextToken?: string | undefined;
}
export interface ThreatModelJobTaskSummary {
    taskId: string;
    threatModelId?: string | undefined;
    threatModelJobId?: string | undefined;
    agentSpaceId?: string | undefined;
    title?: string | undefined;
    executionStatus?: TaskExecutionStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatModelJobTaskSummaryList = ThreatModelJobTaskSummary[];
export interface ListThreatModelJobTasksOutput {
    threatModelJobTaskSummaries?: ThreatModelJobTaskSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListThreatModelsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    agentSpaceId: string;
}
export interface ThreatModelSummary {
    threatModelId: string;
    agentSpaceId: string;
    title: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatModelSummaryList = ThreatModelSummary[];
export interface ListThreatModelsOutput {
    threatModelSummaries?: ThreatModelSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListThreatsInput {
    threatJobId: string;
    agentSpaceId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ThreatSummary {
    threatId?: string | undefined;
    threatJobId?: string | undefined;
    title?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    status?: ThreatStatus | undefined;
    stride?: StrideCategory[] | undefined;
    createdBy?: ThreatActor | undefined;
    updatedBy?: ThreatActor | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ThreatSummaryList = ThreatSummary[];
export interface ListThreatsOutput {
    threats?: ThreatSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface StartCodeRemediationInput {
    agentSpaceId: string;
    pentestJobId?: string | undefined;
    codeReviewJobId?: string | undefined;
    findingIds: string[];
}
export interface StartCodeRemediationOutput {
}
export type DiffSource = {
    s3Uri: string;
};
export interface StartCodeReviewJobInput {
    agentSpaceId: string;
    codeReviewId: string;
    diffSource?: DiffSource | undefined;
}
export interface StartCodeReviewJobOutput {
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    codeReviewId: string;
    codeReviewJobId: string;
    agentSpaceId?: string | undefined;
}
export interface StartPentestJobInput {
    agentSpaceId: string;
    pentestId: string;
    jobType?: JobType | undefined;
    selectedFindingIds?: string[] | undefined;
    scopeChanges?: ScopeChange[] | undefined;
}
export interface StartPentestJobOutput {
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    pentestId?: string | undefined;
    pentestJobId?: string | undefined;
    agentSpaceId?: string | undefined;
}
export interface StartThreatModelJobInput {
    agentSpaceId: string;
    threatModelId: string;
}
export interface StartThreatModelJobOutput {
    title?: string | undefined;
    status?: JobStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    threatModelId?: string | undefined;
    threatModelJobId: string;
    agentSpaceId?: string | undefined;
}
export interface StopCodeReviewJobInput {
    agentSpaceId: string;
    codeReviewJobId: string;
}
export interface StopCodeReviewJobOutput {
}
export interface StopPentestJobInput {
    agentSpaceId: string;
    pentestJobId: string;
}
export interface StopPentestJobOutput {
}
export interface StopThreatModelJobInput {
    agentSpaceId: string;
    threatModelJobId: string;
}
export interface StopThreatModelJobOutput {
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateAgentSpaceInput {
    agentSpaceId: string;
    name?: string | undefined;
    description?: string | undefined;
    awsResources?: AWSResources | undefined;
    targetDomainIds?: string[] | undefined;
    codeReviewSettings?: CodeReviewSettings | undefined;
}
export interface UpdateAgentSpaceOutput {
    agentSpaceId: string;
    name: string;
    description?: string | undefined;
    awsResources?: AWSResources | undefined;
    targetDomainIds?: string[] | undefined;
    codeReviewSettings?: CodeReviewSettings | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface UpdateApplicationRequest {
    applicationId: string;
    roleArn?: string | undefined;
    defaultKmsKeyId?: string | undefined;
}
export interface UpdateApplicationResponse {
    applicationId: string;
}
export interface UpdateCodeReviewInput {
    codeReviewId: string;
    agentSpaceId: string;
    title?: string | undefined;
    assets?: Assets | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    validationMode?: ValidationMode | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
}
export interface UpdateCodeReviewOutput {
    codeReviewId: string;
    title?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    assets?: Assets | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    agentSpaceId?: string | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    validationMode?: ValidationMode | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
}
export interface UpdateFindingInput {
    findingId: string;
    agentSpaceId: string;
    name?: string | undefined;
    description?: string | undefined;
    riskType?: string | undefined;
    riskLevel?: RiskLevel | undefined;
    riskScore?: string | undefined;
    attackScript?: string | undefined;
    reasoning?: string | undefined;
    status?: FindingStatus | undefined;
    customerNote?: string | undefined;
}
export interface UpdateFindingOutput {
}
export interface GitHubRepositoryResource {
    name: string;
    owner: string;
}
export interface GitLabRepositoryResource {
    name: string;
    namespace: string;
}
export interface BitbucketRepositoryResource {
    name: string;
    workspace: string;
}
export interface ConfluenceDocumentResource {
    name: string;
    spaceKey: string;
    pageId: string;
    title?: string | undefined;
    spaceTitle?: string | undefined;
}
export interface AzureDevOpsRepositoryResource {
    name: string;
    organization: string;
    project?: string | undefined;
}
export interface JiraProjectResource {
    name: string;
    projectKey: string;
    projectId: string;
    projectName?: string | undefined;
}
export type IntegratedResource = {
    githubRepository: GitHubRepositoryResource;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository: GitLabRepositoryResource;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository: BitbucketRepositoryResource;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument: ConfluenceDocumentResource;
    azureDevOpsRepository?: undefined;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository: AzureDevOpsRepositoryResource;
    jiraProject?: undefined;
} | {
    githubRepository?: undefined;
    gitlabRepository?: undefined;
    bitbucketRepository?: undefined;
    confluenceDocument?: undefined;
    azureDevOpsRepository?: undefined;
    jiraProject: JiraProjectResource;
};
export interface IntegratedResourceInputItem {
    resource: IntegratedResource;
    capabilities?: ProviderResourceCapabilities | undefined;
}
export type IntegratedResourceInputItemList = IntegratedResourceInputItem[];
export interface UpdateIntegratedResourcesInput {
    agentSpaceId: string;
    integrationId: string;
    items: IntegratedResourceInputItem[];
}
export interface UpdateIntegratedResourcesOutput {
}
export type WebhookAction = "CREATE_IF_ABSENT" | "ROTATE" | (string & {});
export interface UpdateIntegrationInput {
    integrationId: string;
    webhookAction: WebhookAction;
}
export type WebhookSecret = string | redacted.Redacted<string>;
export interface UpdateIntegrationOutput {
    integrationId: string;
    webhookUrl?: string | undefined;
    secret?: string | redacted.Redacted<string> | undefined;
}
export interface UpdatePentestInput {
    pentestId: string;
    agentSpaceId: string;
    title?: string | undefined;
    assets?: Assets | undefined;
    excludeRiskTypes?: RiskType[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    vpcConfig?: VpcConfig | undefined;
    networkTrafficConfig?: NetworkTrafficConfig | undefined;
    codeRemediationStrategy?: CodeRemediationStrategy | undefined;
    cleanUpStrategy?: CleanUpStrategy | undefined;
    disableManagedSkills?: SkillType[] | undefined;
    maxTaskHours?: number | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
}
export interface UpdatePentestOutput {
    pentestId?: string | undefined;
    title?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    assets?: Assets | undefined;
    excludeRiskTypes?: RiskType[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    agentSpaceId?: string | undefined;
    reportDestination?: ReportDestination | undefined;
    reportFilters?: ReportFilters | undefined;
    cicdConfiguration?: CiCdConfiguration | undefined;
    testScope?: TestScope | undefined;
}
export interface UpdatePrivateConnectionCertificateInput {
    privateConnectionName: string;
    certificate: string | redacted.Redacted<string>;
}
export interface UpdatePrivateConnectionCertificateOutput {
    name: string;
    type: PrivateConnectionType;
    status: PrivateConnectionStatus;
    resourceGatewayId?: string | undefined;
    hostAddress?: string | undefined;
    vpcId?: string | undefined;
    resourceConfigurationId?: string | undefined;
    certificateExpiryTime?: Date | undefined;
    dnsResolution?: ResourceConfigDnsResolution | undefined;
    failureMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSecurityRequirementPackInput {
    packId: string;
    name?: string | undefined;
    description?: string | undefined;
    status?: SecurityRequirementPackStatus | undefined;
}
export interface UpdateSecurityRequirementPackOutput {
    packId: string;
    name?: string | undefined;
    description?: string | undefined;
    status?: SecurityRequirementPackStatus | undefined;
}
export interface UpdateTargetDomainInput {
    targetDomainId: string;
    verificationMethod: DomainVerificationMethod;
}
export interface UpdateTargetDomainOutput {
    targetDomainId: string;
    domainName: string;
    verificationStatus: TargetDomainStatus;
    verificationStatusReason?: string | undefined;
    verificationDetails?: VerificationDetails | undefined;
    createdAt?: Date | undefined;
    verifiedAt?: Date | undefined;
}
export interface UpdateThreatInput {
    threatId: string;
    agentSpaceId: string;
    title?: string | undefined;
    status?: ThreatStatus | undefined;
    comments?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    threatSource?: string | undefined;
    prerequisites?: string | undefined;
    threatAction?: string | undefined;
    threatImpact?: string | undefined;
    impactedGoal?: string[] | undefined;
    impactedAssets?: string[] | undefined;
    anchor?: ThreatAnchorShape | undefined;
    evidence?: ThreatEvidenceShape[] | undefined;
    recommendation?: string | undefined;
}
export interface UpdateThreatOutput {
    threatId: string;
    threatJobId: string;
    title?: string | undefined;
    statement?: string | undefined;
    severity?: ThreatSeverity | undefined;
    status?: ThreatStatus | undefined;
    comments?: string | undefined;
    stride?: StrideCategory[] | undefined;
    threatSource?: string | undefined;
    prerequisites?: string | undefined;
    threatAction?: string | undefined;
    threatImpact?: string | undefined;
    impactedGoal?: string[] | undefined;
    impactedAssets?: string[] | undefined;
    anchor?: ThreatAnchorShape | undefined;
    evidence?: ThreatEvidenceShape[] | undefined;
    recommendation?: string | undefined;
    createdBy?: ThreatActor | undefined;
    updatedBy?: ThreatActor | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface UpdateThreatModelInput {
    threatModelId: string;
    agentSpaceId: string;
    title?: string | undefined;
    description?: string | undefined;
    assets?: Assets | undefined;
    scopeDocs?: DocumentInfo[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    reportDestination?: ReportDestination | undefined;
}
export interface UpdateThreatModelOutput {
    threatModelId: string;
    title?: string | undefined;
    agentSpaceId?: string | undefined;
    description?: string | undefined;
    assets?: Assets | undefined;
    scopeDocs?: DocumentInfo[] | undefined;
    serviceRole?: string | undefined;
    logConfig?: CloudWatchLog | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    reportDestination?: ReportDestination | undefined;
}
export interface VerifyTargetDomainInput {
    targetDomainId: string;
}
export interface VerifyTargetDomainOutput {
    targetDomainId?: string | undefined;
    domainName?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    verifiedAt?: Date | undefined;
    status?: TargetDomainStatus | undefined;
    verificationStatusReason?: string | undefined;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AddArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Uploads an artifact to an agent space. Artifacts provide additional context for security testing, such as architecture diagrams, API specifications, or configuration files.
 */
export declare const addArtifact: API.OperationMethod<AddArtifactInput & RegionInput, AddArtifactOutput, AddArtifactError, Credentials | HttpClient.HttpClient>;
export type BatchCreateSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch creates security requirements in a customer managed pack.
 */
export declare const batchCreateSecurityRequirements: API.OperationMethod<BatchCreateSecurityRequirementsInput & RegionInput, BatchCreateSecurityRequirementsOutput, BatchCreateSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteCodeReviewsError = CommonErrors;
/**
 * Deletes one or more code reviews from an agent space.
 */
export declare const batchDeleteCodeReviews: API.OperationMethod<BatchDeleteCodeReviewsInput & RegionInput, BatchDeleteCodeReviewsOutput, BatchDeleteCodeReviewsError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePentestsError = CommonErrors;
/**
 * Deletes one or more pentests from an agent space.
 */
export declare const batchDeletePentests: API.OperationMethod<BatchDeletePentestsInput & RegionInput, BatchDeletePentestsOutput, BatchDeletePentestsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch deletes security requirements from a customer managed pack.
 */
export declare const batchDeleteSecurityRequirements: API.OperationMethod<BatchDeleteSecurityRequirementsInput & RegionInput, BatchDeleteSecurityRequirementsOutput, BatchDeleteSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteThreatModelsError = CommonErrors;
/**
 * Deletes one or more threat models from an agent space.
 */
export declare const batchDeleteThreatModels: API.OperationMethod<BatchDeleteThreatModelsInput & RegionInput, BatchDeleteThreatModelsOutput, BatchDeleteThreatModelsError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateFindingIssueError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a batch of findings from their linked issues.
 */
export declare const batchDisassociateFindingIssue: API.OperationMethod<BatchDisassociateFindingIssueInput & RegionInput, BatchDisassociateFindingIssueOutput, BatchDisassociateFindingIssueError, Credentials | HttpClient.HttpClient>;
export type BatchExportFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports a batch of findings to the connected issue tracker as issues.
 */
export declare const batchExportFindings: API.OperationMethod<BatchExportFindingsInput & RegionInput, BatchExportFindingsOutput, BatchExportFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAgentSpacesError = CommonErrors;
/**
 * Retrieves information about one or more agent spaces.
 */
export declare const batchGetAgentSpaces: API.OperationMethod<BatchGetAgentSpacesInput & RegionInput, BatchGetAgentSpacesOutput, BatchGetAgentSpacesError, Credentials | HttpClient.HttpClient>;
export type BatchGetArtifactMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for one or more artifacts in an agent space.
 */
export declare const batchGetArtifactMetadata: API.OperationMethod<BatchGetArtifactMetadataInput & RegionInput, BatchGetArtifactMetadataOutput, BatchGetArtifactMetadataError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewJobsError = CommonErrors;
/**
 * Retrieves information about one or more code review jobs in an agent space.
 */
export declare const batchGetCodeReviewJobs: API.OperationMethod<BatchGetCodeReviewJobsInput & RegionInput, BatchGetCodeReviewJobsOutput, BatchGetCodeReviewJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a code review job.
 */
export declare const batchGetCodeReviewJobTasks: API.OperationMethod<BatchGetCodeReviewJobTasksInput & RegionInput, BatchGetCodeReviewJobTasksOutput, BatchGetCodeReviewJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeReviewsError = CommonErrors;
/**
 * Retrieves information about one or more code reviews in an agent space.
 */
export declare const batchGetCodeReviews: API.OperationMethod<BatchGetCodeReviewsInput & RegionInput, BatchGetCodeReviewsOutput, BatchGetCodeReviewsError, Credentials | HttpClient.HttpClient>;
export type BatchGetFindingsError = CommonErrors;
/**
 * Retrieves information about one or more security findings in an agent space.
 */
export declare const batchGetFindings: API.OperationMethod<BatchGetFindingsInput & RegionInput, BatchGetFindingsOutput, BatchGetFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestJobsError = CommonErrors;
/**
 * Retrieves information about one or more pentest jobs in an agent space.
 */
export declare const batchGetPentestJobs: API.OperationMethod<BatchGetPentestJobsInput & RegionInput, BatchGetPentestJobsOutput, BatchGetPentestJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a pentest job.
 */
export declare const batchGetPentestJobTasks: API.OperationMethod<BatchGetPentestJobTasksInput & RegionInput, BatchGetPentestJobTasksOutput, BatchGetPentestJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetPentestsError = CommonErrors;
/**
 * Retrieves information about one or more pentests in an agent space.
 */
export declare const batchGetPentests: API.OperationMethod<BatchGetPentestsInput & RegionInput, BatchGetPentestsOutput, BatchGetPentestsError, Credentials | HttpClient.HttpClient>;
export type BatchGetSecurityRequirementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch retrieves security requirements from a pack.
 */
export declare const batchGetSecurityRequirements: API.OperationMethod<BatchGetSecurityRequirementsInput & RegionInput, BatchGetSecurityRequirementsOutput, BatchGetSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type BatchGetTargetDomainsError = CommonErrors;
/**
 * Retrieves information about one or more target domains.
 */
export declare const batchGetTargetDomains: API.OperationMethod<BatchGetTargetDomainsInput & RegionInput, BatchGetTargetDomainsOutput, BatchGetTargetDomainsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelJobsError = CommonErrors;
/**
 * Retrieves information about one or more threat model jobs in an agent space.
 */
export declare const batchGetThreatModelJobs: API.OperationMethod<BatchGetThreatModelJobsInput & RegionInput, BatchGetThreatModelJobsOutput, BatchGetThreatModelJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelJobTasksError = CommonErrors;
/**
 * Retrieves information about one or more tasks within a threat model job.
 */
export declare const batchGetThreatModelJobTasks: API.OperationMethod<BatchGetThreatModelJobTasksInput & RegionInput, BatchGetThreatModelJobTasksOutput, BatchGetThreatModelJobTasksError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatModelsError = CommonErrors;
/**
 * Retrieves information about one or more threat models in an agent space.
 */
export declare const batchGetThreatModels: API.OperationMethod<BatchGetThreatModelsInput & RegionInput, BatchGetThreatModelsOutput, BatchGetThreatModelsError, Credentials | HttpClient.HttpClient>;
export type BatchGetThreatsError = CommonErrors;
/**
 * Retrieves information about one or more threats.
 */
export declare const batchGetThreats: API.OperationMethod<BatchGetThreatsInput & RegionInput, BatchGetThreatsOutput, BatchGetThreatsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Batch updates security requirements within a customer managed pack.
 */
export declare const batchUpdateSecurityRequirements: API.OperationMethod<BatchUpdateSecurityRequirementsInput & RegionInput, BatchUpdateSecurityRequirementsOutput, BatchUpdateSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type CreateAgentSpaceError = CommonErrors;
/**
 * Creates a new agent space. An agent space is a dedicated workspace for securing a specific application.
 */
export declare const createAgentSpace: API.OperationMethod<CreateAgentSpaceInput & RegionInput, CreateAgentSpaceOutput, CreateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = CommonErrors;
/**
 * Creates a new application. An application is the top-level organizational unit that supports IAM Identity Center integration.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateCodeReviewError = CommonErrors;
/**
 * Creates a new code review configuration in an agent space. A code review defines the parameters for automated security-focused code analysis.
 */
export declare const createCodeReview: API.OperationMethod<CreateCodeReviewInput & RegionInput, CreateCodeReviewOutput, CreateCodeReviewError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new integration with a third-party provider, such as GitHub, for code review and remediation.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationInput & RegionInput, CreateIntegrationOutput, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = CommonErrors;
/**
 * Creates a new membership, granting a user or group access to an agent space within an application.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipRequest & RegionInput, CreateMembershipResponse, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type CreatePentestError = CommonErrors;
/**
 * Creates a new pentest configuration in an agent space. A pentest defines the security test parameters, including target assets, risk type exclusions, and logging configuration.
 */
export declare const createPentest: API.OperationMethod<CreatePentestInput & RegionInput, CreatePentestOutput, CreatePentestError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a private connection for reaching a self-hosted provider instance over private networking using Amazon VPC Lattice.
 */
export declare const createPrivateConnection: API.OperationMethod<CreatePrivateConnectionInput & RegionInput, CreatePrivateConnectionOutput, CreatePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a customer managed security requirement pack.
 */
export declare const createSecurityRequirementPack: API.OperationMethod<CreateSecurityRequirementPackInput & RegionInput, CreateSecurityRequirementPackOutput, CreateSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type CreateTargetDomainError = CommonErrors;
/**
 * Creates a new target domain for penetration testing. A target domain is a web domain that must be registered and verified before it can be tested.
 */
export declare const createTargetDomain: API.OperationMethod<CreateTargetDomainInput & RegionInput, CreateTargetDomainOutput, CreateTargetDomainError, Credentials | HttpClient.HttpClient>;
export type CreateThreatError = CommonErrors;
/**
 * Creates a new threat under a threat model job.
 */
export declare const createThreat: API.OperationMethod<CreateThreatInput & RegionInput, CreateThreatOutput, CreateThreatError, Credentials | HttpClient.HttpClient>;
export type CreateThreatModelError = CommonErrors;
/**
 * Creates a new threat model configuration in an agent space. A threat model defines the parameters for automated threat analysis.
 */
export declare const createThreatModel: API.OperationMethod<CreateThreatModelInput & RegionInput, CreateThreatModelOutput, CreateThreatModelError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentSpaceError = CommonErrors;
/**
 * Deletes an agent space and all of its associated resources, including pentests, findings, and artifacts.
 */
export declare const deleteAgentSpace: API.OperationMethod<DeleteAgentSpaceInput & RegionInput, DeleteAgentSpaceOutput, DeleteAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = CommonErrors;
/**
 * Deletes an application and its associated configuration, including IAM Identity Center settings.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an artifact from an agent space.
 */
export declare const deleteArtifact: API.OperationMethod<DeleteArtifactInput & RegionInput, DeleteArtifactOutput, DeleteArtifactError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an integration with a third-party provider.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationInput & RegionInput, DeleteIntegrationOutput, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteMembershipError = CommonErrors;
/**
 * Deletes a membership, revoking a user's or group's access to an agent space.
 */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipRequest & RegionInput, DeleteMembershipResponse, DeleteMembershipError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a private connection.
 */
export declare const deletePrivateConnection: API.OperationMethod<DeletePrivateConnectionInput & RegionInput, DeletePrivateConnectionOutput, DeletePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a customer managed security requirement pack and all its associated security requirements.
 */
export declare const deleteSecurityRequirementPack: API.OperationMethod<DeleteSecurityRequirementPackInput & RegionInput, DeleteSecurityRequirementPackOutput, DeleteSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetDomainError = CommonErrors;
/**
 * Deletes a target domain registration. After deletion, the domain can no longer be used for penetration testing.
 */
export declare const deleteTargetDomain: API.OperationMethod<DeleteTargetDomainInput & RegionInput, DeleteTargetDomainOutput, DeleteTargetDomainError, Credentials | HttpClient.HttpClient>;
export type DescribePrivateConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a private connection.
 */
export declare const describePrivateConnection: API.OperationMethod<DescribePrivateConnectionInput & RegionInput, DescribePrivateConnectionOutput, DescribePrivateConnectionError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = CommonErrors;
/**
 * Retrieves information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an artifact from an agent space.
 */
export declare const getArtifact: API.OperationMethod<GetArtifactInput & RegionInput, GetArtifactOutput, GetArtifactError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationInput & RegionInput, GetIntegrationOutput, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetSecurityRequirementPackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a security requirement pack.
 */
export declare const getSecurityRequirementPack: API.OperationMethod<GetSecurityRequirementPackInput & RegionInput, GetSecurityRequirementPackOutput, GetSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type ImportSecurityRequirementsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Imports security requirements from uploaded documents into a customer managed security requirement pack. The import process asynchronously extracts and generates structured security requirements from the provided source files.
 */
export declare const importSecurityRequirements: API.OperationMethod<ImportSecurityRequirementsInput & RegionInput, ImportSecurityRequirementsOutput, ImportSecurityRequirementsError, Credentials | HttpClient.HttpClient>;
export type InitiateProviderRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates the OAuth registration flow with a third-party provider. Returns a redirect URL and CSRF state token for completing the authorization.
 */
export declare const initiateProviderRegistration: API.OperationMethod<InitiateProviderRegistrationInput & RegionInput, InitiateProviderRegistrationOutput, InitiateProviderRegistrationError, Credentials | HttpClient.HttpClient>;
export type ListActorMessagesError = CommonErrors;
/**
 * Returns a paginated list of the email MFA messages received for an actor at its server-generated email address, most recent first.
 */
export declare const listActorMessages: API.PaginatedOperationMethod<ListActorMessagesInput & RegionInput, ListActorMessagesOutput, ListActorMessagesError, Credentials | HttpClient.HttpClient, ActorMessage>;
export type ListAgentSpacesError = CommonErrors;
/**
 * Returns a paginated list of agent space summaries in your account.
 */
export declare const listAgentSpaces: API.PaginatedOperationMethod<ListAgentSpacesInput & RegionInput, ListAgentSpacesOutput, ListAgentSpacesError, Credentials | HttpClient.HttpClient, AgentSpaceSummary>;
export type ListApplicationsError = CommonErrors;
/**
 * Returns a paginated list of application summaries in your account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListArtifactsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of artifact summaries for the specified agent space.
 */
export declare const listArtifacts: API.PaginatedOperationMethod<ListArtifactsInput & RegionInput, ListArtifactsOutput, ListArtifactsError, Credentials | HttpClient.HttpClient, ArtifactSummary>;
export type ListCodeReviewJobsForCodeReviewError = CommonErrors;
/**
 * Returns a paginated list of code review job summaries for the specified code review configuration.
 */
export declare const listCodeReviewJobsForCodeReview: API.PaginatedOperationMethod<ListCodeReviewJobsForCodeReviewInput & RegionInput, ListCodeReviewJobsForCodeReviewOutput, ListCodeReviewJobsForCodeReviewError, Credentials | HttpClient.HttpClient, CodeReviewJobSummary>;
export type ListCodeReviewJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified code review job, optionally filtered by step name or category.
 */
export declare const listCodeReviewJobTasks: API.PaginatedOperationMethod<ListCodeReviewJobTasksInput & RegionInput, ListCodeReviewJobTasksOutput, ListCodeReviewJobTasksError, Credentials | HttpClient.HttpClient, CodeReviewJobTaskSummary>;
export type ListCodeReviewsError = CommonErrors;
/**
 * Returns a paginated list of code review summaries for the specified agent space.
 */
export declare const listCodeReviews: API.PaginatedOperationMethod<ListCodeReviewsInput & RegionInput, ListCodeReviewsOutput, ListCodeReviewsError, Credentials | HttpClient.HttpClient, CodeReviewSummary>;
export type ListDiscoveredEndpointsError = CommonErrors;
/**
 * Returns a paginated list of endpoints discovered during a pentest job execution.
 */
export declare const listDiscoveredEndpoints: API.PaginatedOperationMethod<ListDiscoveredEndpointsInput & RegionInput, ListDiscoveredEndpointsOutput, ListDiscoveredEndpointsError, Credentials | HttpClient.HttpClient, DiscoveredEndpoint>;
export type ListFindingsError = CommonErrors;
/**
 * Lists the security findings for a pentest job.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsInput & RegionInput, ListFindingsOutput, ListFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListIntegratedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the integrated resources for an agent space, optionally filtered by integration or resource type.
 */
export declare const listIntegratedResources: API.PaginatedOperationMethod<ListIntegratedResourcesInput & RegionInput, ListIntegratedResourcesOutput, ListIntegratedResourcesError, Credentials | HttpClient.HttpClient, IntegratedResourceSummary>;
export type ListIntegrationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the integrations in your account, optionally filtered by provider or provider type.
 */
export declare const listIntegrations: API.PaginatedOperationMethod<ListIntegrationsInput & RegionInput, ListIntegrationsOutput, ListIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type ListMembershipsError = CommonErrors;
/**
 * Returns a paginated list of membership summaries for the specified agent space within an application.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest & RegionInput, ListMembershipsResponse, ListMembershipsError, Credentials | HttpClient.HttpClient, MembershipSummary>;
export type ListPentestJobsForPentestError = CommonErrors;
/**
 * Returns a paginated list of pentest job summaries for the specified pentest configuration.
 */
export declare const listPentestJobsForPentest: API.PaginatedOperationMethod<ListPentestJobsForPentestInput & RegionInput, ListPentestJobsForPentestOutput, ListPentestJobsForPentestError, Credentials | HttpClient.HttpClient, PentestJobSummary>;
export type ListPentestJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified pentest job, optionally filtered by step name or category.
 */
export declare const listPentestJobTasks: API.PaginatedOperationMethod<ListPentestJobTasksInput & RegionInput, ListPentestJobTasksOutput, ListPentestJobTasksError, Credentials | HttpClient.HttpClient, TaskSummary>;
export type ListPentestsError = CommonErrors;
/**
 * Returns a paginated list of pentest summaries for the specified agent space.
 */
export declare const listPentests: API.PaginatedOperationMethod<ListPentestsInput & RegionInput, ListPentestsOutput, ListPentestsError, Credentials | HttpClient.HttpClient, PentestSummary>;
export type ListPrivateConnectionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the private connections in your account.
 */
export declare const listPrivateConnections: API.PaginatedOperationMethod<ListPrivateConnectionsInput & RegionInput, ListPrivateConnectionsOutput, ListPrivateConnectionsError, Credentials | HttpClient.HttpClient, PrivateConnectionSummary>;
export type ListSecurityRequirementPacksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all security requirement packs in the caller's account.
 */
export declare const listSecurityRequirementPacks: API.PaginatedOperationMethod<ListSecurityRequirementPacksInput & RegionInput, ListSecurityRequirementPacksOutput, ListSecurityRequirementPacksError, Credentials | HttpClient.HttpClient, SecurityRequirementPackSummary>;
export type ListSecurityRequirementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists security requirements within a pack.
 */
export declare const listSecurityRequirements: API.PaginatedOperationMethod<ListSecurityRequirementsInput & RegionInput, ListSecurityRequirementsOutput, ListSecurityRequirementsError, Credentials | HttpClient.HttpClient, SecurityRequirementSummary>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Returns the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetDomainsError = CommonErrors;
/**
 * Returns a paginated list of target domain summaries in your account.
 */
export declare const listTargetDomains: API.PaginatedOperationMethod<ListTargetDomainsInput & RegionInput, ListTargetDomainsOutput, ListTargetDomainsError, Credentials | HttpClient.HttpClient, TargetDomainSummary>;
export type ListThreatModelJobsError = CommonErrors;
/**
 * Returns a paginated list of threat model job summaries for the specified threat model.
 */
export declare const listThreatModelJobs: API.PaginatedOperationMethod<ListThreatModelJobsInput & RegionInput, ListThreatModelJobsOutput, ListThreatModelJobsError, Credentials | HttpClient.HttpClient, ThreatModelJobSummary>;
export type ListThreatModelJobTasksError = CommonErrors;
/**
 * Returns a paginated list of task summaries for the specified threat model job.
 */
export declare const listThreatModelJobTasks: API.PaginatedOperationMethod<ListThreatModelJobTasksInput & RegionInput, ListThreatModelJobTasksOutput, ListThreatModelJobTasksError, Credentials | HttpClient.HttpClient, ThreatModelJobTaskSummary>;
export type ListThreatModelsError = CommonErrors;
/**
 * Returns a paginated list of threat model summaries for the specified agent space.
 */
export declare const listThreatModels: API.PaginatedOperationMethod<ListThreatModelsInput & RegionInput, ListThreatModelsOutput, ListThreatModelsError, Credentials | HttpClient.HttpClient, ThreatModelSummary>;
export type ListThreatsError = CommonErrors;
/**
 * Returns a paginated list of threats for a threat model job.
 */
export declare const listThreats: API.PaginatedOperationMethod<ListThreatsInput & RegionInput, ListThreatsOutput, ListThreatsError, Credentials | HttpClient.HttpClient, ThreatSummary>;
export type StartCodeRemediationError = CommonErrors;
/**
 * Initiates code remediation for one or more security findings. This creates pull requests in integrated repositories to fix the identified vulnerabilities.
 */
export declare const startCodeRemediation: API.OperationMethod<StartCodeRemediationInput & RegionInput, StartCodeRemediationOutput, StartCodeRemediationError, Credentials | HttpClient.HttpClient>;
export type StartCodeReviewJobError = CommonErrors;
/**
 * Starts a new code review job for a code review configuration. The job executes the security-focused code analysis defined in the code review.
 */
export declare const startCodeReviewJob: API.OperationMethod<StartCodeReviewJobInput & RegionInput, StartCodeReviewJobOutput, StartCodeReviewJobError, Credentials | HttpClient.HttpClient>;
export type StartPentestJobError = CommonErrors;
/**
 * Starts a new pentest job for a pentest configuration. The job executes the security tests defined in the pentest.
 */
export declare const startPentestJob: API.OperationMethod<StartPentestJobInput & RegionInput, StartPentestJobOutput, StartPentestJobError, Credentials | HttpClient.HttpClient>;
export type StartThreatModelJobError = CommonErrors;
/**
 * Starts a new threat model job for a threat model configuration.
 */
export declare const startThreatModelJob: API.OperationMethod<StartThreatModelJobInput & RegionInput, StartThreatModelJobOutput, StartThreatModelJobError, Credentials | HttpClient.HttpClient>;
export type StopCodeReviewJobError = CommonErrors;
/**
 * Stops a running code review job. The job transitions to a stopping state and then to stopped after cleanup completes.
 */
export declare const stopCodeReviewJob: API.OperationMethod<StopCodeReviewJobInput & RegionInput, StopCodeReviewJobOutput, StopCodeReviewJobError, Credentials | HttpClient.HttpClient>;
export type StopPentestJobError = CommonErrors;
/**
 * Stops a running pentest job. The job transitions to a stopping state and then to stopped after cleanup completes.
 */
export declare const stopPentestJob: API.OperationMethod<StopPentestJobInput & RegionInput, StopPentestJobOutput, StopPentestJobError, Credentials | HttpClient.HttpClient>;
export type StopThreatModelJobError = CommonErrors;
/**
 * Stops a running threat model job.
 */
export declare const stopThreatModelJob: API.OperationMethod<StopThreatModelJobInput & RegionInput, StopThreatModelJobOutput, StopThreatModelJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentSpaceError = CommonErrors;
/**
 * Updates the configuration of an existing agent space, including its name, description, AWS resources, target domains, and code review settings.
 */
export declare const updateAgentSpace: API.OperationMethod<UpdateAgentSpaceInput & RegionInput, UpdateAgentSpaceOutput, UpdateAgentSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CommonErrors;
/**
 * Updates the configuration of an existing application, including the IAM role and default KMS key.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeReviewError = CommonErrors;
/**
 * Updates an existing code review configuration.
 */
export declare const updateCodeReview: API.OperationMethod<UpdateCodeReviewInput & RegionInput, UpdateCodeReviewOutput, UpdateCodeReviewError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingError = CommonErrors;
/**
 * Updates the status or risk level of a security finding.
 */
export declare const updateFinding: API.OperationMethod<UpdateFindingInput & RegionInput, UpdateFindingOutput, UpdateFindingError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegratedResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the integrated resources for an agent space, including their capabilities.
 */
export declare const updateIntegratedResources: API.OperationMethod<UpdateIntegratedResourcesInput & RegionInput, UpdateIntegratedResourcesOutput, UpdateIntegratedResourcesError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an integration's webhook, or rotates the HMAC signing secret of an existing one. The secret is returned only once, in this response, and cannot be retrieved again.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationInput & RegionInput, UpdateIntegrationOutput, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdatePentestError = CommonErrors;
/**
 * Updates an existing pentest configuration.
 */
export declare const updatePentest: API.OperationMethod<UpdatePentestInput & RegionInput, UpdatePentestOutput, UpdatePentestError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateConnectionCertificateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the certificate associated with a private connection. Certificates can be added or replaced but not removed.
 */
export declare const updatePrivateConnectionCertificate: API.OperationMethod<UpdatePrivateConnectionCertificateInput & RegionInput, UpdatePrivateConnectionCertificateOutput, UpdatePrivateConnectionCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityRequirementPackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a security requirement pack. For customer managed packs, both metadata and status can be updated. For AWS managed packs, only status can be updated.
 */
export declare const updateSecurityRequirementPack: API.OperationMethod<UpdateSecurityRequirementPackInput & RegionInput, UpdateSecurityRequirementPackOutput, UpdateSecurityRequirementPackError, Credentials | HttpClient.HttpClient>;
export type UpdateTargetDomainError = CommonErrors;
/**
 * Updates the verification method for a target domain.
 */
export declare const updateTargetDomain: API.OperationMethod<UpdateTargetDomainInput & RegionInput, UpdateTargetDomainOutput, UpdateTargetDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatError = CommonErrors;
/**
 * Updates a threat.
 */
export declare const updateThreat: API.OperationMethod<UpdateThreatInput & RegionInput, UpdateThreatOutput, UpdateThreatError, Credentials | HttpClient.HttpClient>;
export type UpdateThreatModelError = CommonErrors;
/**
 * Updates an existing threat model configuration.
 */
export declare const updateThreatModel: API.OperationMethod<UpdateThreatModelInput & RegionInput, UpdateThreatModelOutput, UpdateThreatModelError, Credentials | HttpClient.HttpClient>;
export type VerifyTargetDomainError = CommonErrors;
/**
 * Initiates verification of a target domain. This checks whether the domain ownership verification token has been properly configured.
 */
export declare const verifyTargetDomain: API.OperationMethod<VerifyTargetDomainInput & RegionInput, VerifyTargetDomainOutput, VerifyTargetDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=securityagent.d.ts.map