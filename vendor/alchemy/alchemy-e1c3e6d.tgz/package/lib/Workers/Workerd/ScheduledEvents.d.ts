import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type { RuntimeContext } from "../../RuntimeContext.ts";
import type { WorkerdDurableObjectState } from "./DurableObjectState.ts";
export interface ScheduledEvent {
    id: string;
    runAt: Date;
    repeatMs?: number;
    payload: unknown;
}
/**
 * The scheduled-events API over an engine's Durable Object state service.
 *
 * @internal
 */
export declare const makeScheduledEvents: <I>(State: Context.Key<I, WorkerdDurableObjectState>) => {
    scheduleEvent: (id: string, runAt: Date, payload: unknown, repeatMs?: number | undefined) => Effect.Effect<void, never, I | RuntimeContext>;
    cancelEvent: (id: string) => Effect.Effect<void, never, I | RuntimeContext>;
    listEvents: Effect.Effect<ScheduledEvent[], never, I | RuntimeContext>;
    processScheduledEvents: Effect.Effect<ScheduledEvent[], never, I | RuntimeContext>;
};
//# sourceMappingURL=ScheduledEvents.d.ts.map