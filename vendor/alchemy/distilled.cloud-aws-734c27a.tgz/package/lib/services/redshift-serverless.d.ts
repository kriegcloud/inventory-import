import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DryRunException_base: S.TaggedErrorClass<"DryRunException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DryRunException extends /*@__PURE__*/ DryRunException_base {
}
declare const InsufficientCapacityException_base: S.TaggedErrorClass<"InsufficientCapacityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InsufficientCapacityException extends /*@__PURE__*/ InsufficientCapacityException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidPaginationException_base: S.TaggedErrorClass<"InvalidPaginationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationException extends /*@__PURE__*/ InvalidPaginationException_base {
}
declare const Ipv6CidrBlockNotFoundException_base: S.TaggedErrorClass<"Ipv6CidrBlockNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class Ipv6CidrBlockNotFoundException extends /*@__PURE__*/ Ipv6CidrBlockNotFoundException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface ConvertRecoveryPointToSnapshotRequest {
    recoveryPointId: string;
    snapshotName: string;
    retentionPeriod?: number | undefined;
    tags?: Tag[] | undefined;
}
export type SnapshotStatus = string;
export type KmsKeyId = string;
export type AccountIdList = string[];
export interface Snapshot {
    namespaceName?: string | undefined;
    namespaceArn?: string | undefined;
    snapshotName?: string | undefined;
    snapshotCreateTime?: Date | undefined;
    adminUsername?: string | undefined;
    status?: string | undefined;
    kmsKeyId?: string | undefined;
    ownerAccount?: string | undefined;
    totalBackupSizeInMegaBytes?: number | undefined;
    actualIncrementalBackupSizeInMegaBytes?: number | undefined;
    backupProgressInMegaBytes?: number | undefined;
    currentBackupRateInMegaBytesPerSecond?: number | undefined;
    estimatedSecondsToCompletion?: number | undefined;
    elapsedTimeInSeconds?: number | undefined;
    snapshotRetentionPeriod?: number | undefined;
    snapshotRemainingDays?: number | undefined;
    snapshotRetentionStartTime?: Date | undefined;
    snapshotArn?: string | undefined;
    accountsWithRestoreAccess?: string[] | undefined;
    accountsWithProvisionedRestoreAccess?: string[] | undefined;
    adminPasswordSecretArn?: string | undefined;
    adminPasswordSecretKmsKeyId?: string | undefined;
}
export interface ConvertRecoveryPointToSnapshotResponse {
    snapshot?: Snapshot | undefined;
}
export type WorkgroupName = string;
export type CustomDomainName = string;
export type CustomDomainCertificateArnString = string;
export interface CreateCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
    customDomainCertificateArn: string;
}
export interface CreateCustomDomainAssociationResponse {
    customDomainName?: string | undefined;
    workgroupName?: string | undefined;
    customDomainCertificateArn?: string | undefined;
    customDomainCertificateExpiryTime?: Date | undefined;
}
export type SubnetId = string;
export type SubnetIdList = string[];
export type VpcSecurityGroupId = string;
export type VpcSecurityGroupIdList = string[];
export type OwnerAccount = string;
export interface CreateEndpointAccessRequest {
    endpointName: string;
    subnetIds: string[];
    workgroupName: string;
    vpcSecurityGroupIds?: string[] | undefined;
    ownerAccount?: string | undefined;
}
export interface VpcSecurityGroupMembership {
    vpcSecurityGroupId?: string | undefined;
    status?: string | undefined;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface NetworkInterface {
    networkInterfaceId?: string | undefined;
    subnetId?: string | undefined;
    privateIpAddress?: string | undefined;
    availabilityZone?: string | undefined;
    ipv6Address?: string | undefined;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface VpcEndpoint {
    vpcEndpointId?: string | undefined;
    vpcId?: string | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
}
export interface EndpointAccess {
    endpointName?: string | undefined;
    endpointStatus?: string | undefined;
    workgroupName?: string | undefined;
    endpointCreateTime?: Date | undefined;
    port?: number | undefined;
    address?: string | undefined;
    subnetIds?: string[] | undefined;
    vpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    vpcEndpoint?: VpcEndpoint | undefined;
    endpointArn?: string | undefined;
}
export interface CreateEndpointAccessResponse {
    endpoint?: EndpointAccess | undefined;
}
export type NamespaceName = string;
export type DbUser = string | redacted.Redacted<string>;
export type DbPassword = string | redacted.Redacted<string>;
export type IamRoleArn = string;
export type IamRoleArnList = string[];
export type LogExport = string;
export type LogExportList = string[];
export type RedshiftIdcApplicationArn = string;
export interface CreateNamespaceRequest {
    namespaceName: string;
    adminUsername?: string | redacted.Redacted<string> | undefined;
    adminUserPassword?: string | redacted.Redacted<string> | undefined;
    dbName?: string | undefined;
    kmsKeyId?: string | undefined;
    defaultIamRoleArn?: string | undefined;
    iamRoles?: string[] | undefined;
    logExports?: string[] | undefined;
    tags?: Tag[] | undefined;
    manageAdminPassword?: boolean | undefined;
    adminPasswordSecretKmsKeyId?: string | undefined;
    redshiftIdcApplicationArn?: string | undefined;
}
export type NamespaceStatus = string;
export type S3TableName = string;
export type S3TableNameList = string[];
export type S3TableGranularity = string;
export type S3TableLastIngestionTimeMap = {
    [key: string]: string | undefined;
};
export interface S3TablePublishStatus {
    s3Tables?: string[] | undefined;
    s3TableNamespace?: string | undefined;
    s3TableGranularity?: string | undefined;
    enabledAll?: boolean | undefined;
    lastIngestionTimes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Namespace {
    namespaceArn?: string | undefined;
    namespaceId?: string | undefined;
    namespaceName?: string | undefined;
    adminUsername?: string | redacted.Redacted<string> | undefined;
    dbName?: string | undefined;
    kmsKeyId?: string | undefined;
    defaultIamRoleArn?: string | undefined;
    iamRoles?: string[] | undefined;
    logExports?: string[] | undefined;
    status?: string | undefined;
    creationDate?: Date | undefined;
    adminPasswordSecretArn?: string | undefined;
    adminPasswordSecretKmsKeyId?: string | undefined;
    lakehouseRegistrationStatus?: string | undefined;
    catalogArn?: string | undefined;
    s3TablePublishStatus?: S3TablePublishStatus | undefined;
}
export interface CreateNamespaceResponse {
    namespace?: Namespace | undefined;
}
export type Capacity = number;
export type OfferingId = string;
export interface CreateReservationRequest {
    capacity: number;
    offeringId: string;
    clientToken?: string | undefined;
}
export type ReservationId = string;
export type ReservationArn = string;
export type Duration = number;
export type Charge = number;
export type CurrencyCode = string;
export type OfferingType = string;
export interface ReservationOffering {
    offeringId?: string | undefined;
    duration?: number | undefined;
    upfrontCharge?: number | undefined;
    hourlyCharge?: number | undefined;
    currencyCode?: string | undefined;
    offeringType?: string | undefined;
}
export type Status = string;
export interface Reservation {
    reservationId?: string | undefined;
    reservationArn?: string | undefined;
    startDate?: Date | undefined;
    endDate?: Date | undefined;
    capacity?: number | undefined;
    offering?: ReservationOffering | undefined;
    status?: string | undefined;
}
export interface CreateReservationResponse {
    reservation?: Reservation | undefined;
}
export type ScheduledActionName = string;
export type SnapshotNamePrefix = string;
export interface CreateSnapshotScheduleActionParameters {
    namespaceName: string;
    snapshotNamePrefix: string;
    retentionPeriod?: number | undefined;
    tags?: Tag[] | undefined;
}
export type TargetAction = {
    createSnapshot: CreateSnapshotScheduleActionParameters;
};
export type Schedule = {
    at: Date;
    cron?: undefined;
} | {
    at?: undefined;
    cron: string;
};
export interface CreateScheduledActionRequest {
    scheduledActionName: string;
    targetAction: TargetAction;
    schedule: Schedule;
    roleArn: string;
    namespaceName: string;
    enabled?: boolean | undefined;
    scheduledActionDescription?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type NextInvocationsList = Date[];
export type State = string;
export interface ScheduledActionResponse {
    scheduledActionName?: string | undefined;
    schedule?: Schedule | undefined;
    scheduledActionDescription?: string | undefined;
    nextInvocations?: Date[] | undefined;
    roleArn?: string | undefined;
    state?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    targetAction?: TargetAction | undefined;
    namespaceName?: string | undefined;
    scheduledActionUuid?: string | undefined;
}
export interface CreateScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse | undefined;
}
export interface CreateSnapshotRequest {
    namespaceName: string;
    snapshotName: string;
    retentionPeriod?: number | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateSnapshotResponse {
    snapshot?: Snapshot | undefined;
}
export interface CreateSnapshotCopyConfigurationRequest {
    namespaceName: string;
    destinationRegion: string;
    snapshotRetentionPeriod?: number | undefined;
    destinationKmsKeyId?: string | undefined;
}
export interface SnapshotCopyConfiguration {
    snapshotCopyConfigurationId?: string | undefined;
    snapshotCopyConfigurationArn?: string | undefined;
    namespaceName?: string | undefined;
    destinationRegion?: string | undefined;
    snapshotRetentionPeriod?: number | undefined;
    destinationKmsKeyId?: string | undefined;
}
export interface CreateSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export type UsageLimitUsageType = string;
export type UsageLimitPeriod = string;
export type UsageLimitBreachAction = string;
export interface CreateUsageLimitRequest {
    resourceArn: string;
    usageType: string;
    amount: number;
    period?: string | undefined;
    breachAction?: string | undefined;
}
export interface UsageLimit {
    usageLimitId?: string | undefined;
    usageLimitArn?: string | undefined;
    resourceArn?: string | undefined;
    usageType?: string | undefined;
    amount?: number | undefined;
    period?: string | undefined;
    breachAction?: string | undefined;
}
export interface CreateUsageLimitResponse {
    usageLimit?: UsageLimit | undefined;
}
export type ParameterKey = string;
export type ParameterValue = string;
export interface ConfigParameter {
    parameterKey?: string | undefined;
    parameterValue?: string | undefined;
}
export type ConfigParameterList = ConfigParameter[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export type PerformanceTargetStatus = string;
export interface PerformanceTarget {
    status?: string | undefined;
    level?: number | undefined;
}
export type IpAddressType = string;
export type TrackName = string;
export interface CreateWorkgroupRequest {
    workgroupName: string;
    namespaceName: string;
    baseCapacity?: number | undefined;
    enhancedVpcRouting?: boolean | undefined;
    configParameters?: ConfigParameter[] | undefined;
    securityGroupIds?: string[] | undefined;
    subnetIds?: string[] | undefined;
    publiclyAccessible?: boolean | undefined;
    tags?: Tag[] | undefined;
    port?: number | undefined;
    maxCapacity?: number | undefined;
    pricePerformanceTarget?: PerformanceTarget | undefined;
    ipAddressType?: string | undefined;
    trackName?: string | undefined;
    extraComputeForAutomaticOptimization?: boolean | undefined;
}
export type WorkgroupStatus = string;
export type VpcEndpointList = VpcEndpoint[];
export interface Endpoint {
    address?: string | undefined;
    port?: number | undefined;
    vpcEndpoints?: VpcEndpoint[] | undefined;
}
export type VpcIds = string[];
export interface Workgroup {
    workgroupId?: string | undefined;
    workgroupArn?: string | undefined;
    workgroupName?: string | undefined;
    namespaceName?: string | undefined;
    baseCapacity?: number | undefined;
    enhancedVpcRouting?: boolean | undefined;
    configParameters?: ConfigParameter[] | undefined;
    securityGroupIds?: string[] | undefined;
    subnetIds?: string[] | undefined;
    status?: string | undefined;
    endpoint?: Endpoint | undefined;
    publiclyAccessible?: boolean | undefined;
    creationDate?: Date | undefined;
    port?: number | undefined;
    customDomainName?: string | undefined;
    customDomainCertificateArn?: string | undefined;
    customDomainCertificateExpiryTime?: Date | undefined;
    workgroupVersion?: string | undefined;
    patchVersion?: string | undefined;
    maxCapacity?: number | undefined;
    crossAccountVpcs?: string[] | undefined;
    ipAddressType?: string | undefined;
    pricePerformanceTarget?: PerformanceTarget | undefined;
    trackName?: string | undefined;
    pendingTrackName?: string | undefined;
    extraComputeForAutomaticOptimization?: boolean | undefined;
}
export interface CreateWorkgroupResponse {
    workgroup?: Workgroup | undefined;
}
export interface DeleteCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
}
export interface DeleteCustomDomainAssociationResponse {
}
export interface DeleteEndpointAccessRequest {
    endpointName: string;
}
export interface DeleteEndpointAccessResponse {
    endpoint?: EndpointAccess | undefined;
}
export interface DeleteNamespaceRequest {
    namespaceName: string;
    finalSnapshotName?: string | undefined;
    finalSnapshotRetentionPeriod?: number | undefined;
}
export interface DeleteNamespaceResponse {
    namespace: Namespace;
}
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteScheduledActionRequest {
    scheduledActionName: string;
}
export interface DeleteScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse | undefined;
}
export interface DeleteSnapshotRequest {
    snapshotName: string;
}
export interface DeleteSnapshotResponse {
    snapshot?: Snapshot | undefined;
}
export interface DeleteSnapshotCopyConfigurationRequest {
    snapshotCopyConfigurationId: string;
}
export interface DeleteSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export interface DeleteUsageLimitRequest {
    usageLimitId: string;
}
export interface DeleteUsageLimitResponse {
    usageLimit?: UsageLimit | undefined;
}
export interface DeleteWorkgroupRequest {
    workgroupName: string;
}
export interface DeleteWorkgroupResponse {
    workgroup: Workgroup;
}
export type DbName = string;
export interface GetCredentialsRequest {
    dbName?: string | undefined;
    durationSeconds?: number | undefined;
    workgroupName?: string | undefined;
    customDomainName?: string | undefined;
}
export interface GetCredentialsResponse {
    dbUser?: string | redacted.Redacted<string> | undefined;
    dbPassword?: string | redacted.Redacted<string> | undefined;
    expiration?: Date | undefined;
    nextRefreshTime?: Date | undefined;
}
export interface GetCustomDomainAssociationRequest {
    customDomainName: string;
    workgroupName: string;
}
export interface GetCustomDomainAssociationResponse {
    customDomainName?: string | undefined;
    workgroupName?: string | undefined;
    customDomainCertificateArn?: string | undefined;
    customDomainCertificateExpiryTime?: Date | undefined;
}
export interface GetEndpointAccessRequest {
    endpointName: string;
}
export interface GetEndpointAccessResponse {
    endpoint?: EndpointAccess | undefined;
}
export type WorkgroupNameList = string[];
export interface GetIdentityCenterAuthTokenRequest {
    workgroupNames: string[];
}
export interface GetIdentityCenterAuthTokenResponse {
    token?: string | redacted.Redacted<string> | undefined;
    expirationTime?: Date | undefined;
}
export interface GetNamespaceRequest {
    namespaceName: string;
}
export interface GetNamespaceResponse {
    namespace: Namespace;
}
export interface GetRecoveryPointRequest {
    recoveryPointId: string;
}
export interface RecoveryPoint {
    recoveryPointId?: string | undefined;
    recoveryPointCreateTime?: Date | undefined;
    totalSizeInMegaBytes?: number | undefined;
    namespaceName?: string | undefined;
    workgroupName?: string | undefined;
    namespaceArn?: string | undefined;
}
export interface GetRecoveryPointResponse {
    recoveryPoint?: RecoveryPoint | undefined;
}
export interface GetReservationRequest {
    reservationId: string;
}
export interface GetReservationResponse {
    reservation: Reservation;
}
export interface GetReservationOfferingRequest {
    offeringId: string;
}
export interface GetReservationOfferingResponse {
    reservationOffering: ReservationOffering;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export interface ResourcePolicy {
    resourceArn?: string | undefined;
    policy?: string | undefined;
}
export interface GetResourcePolicyResponse {
    resourcePolicy?: ResourcePolicy | undefined;
}
export interface GetScheduledActionRequest {
    scheduledActionName: string;
}
export interface GetScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse | undefined;
}
export interface GetSnapshotRequest {
    snapshotName?: string | undefined;
    ownerAccount?: string | undefined;
    snapshotArn?: string | undefined;
}
export interface GetSnapshotResponse {
    snapshot?: Snapshot | undefined;
}
export interface GetTableRestoreStatusRequest {
    tableRestoreRequestId: string;
}
export interface TableRestoreStatus {
    tableRestoreRequestId?: string | undefined;
    status?: string | undefined;
    message?: string | undefined;
    requestTime?: Date | undefined;
    namespaceName?: string | undefined;
    workgroupName?: string | undefined;
    snapshotName?: string | undefined;
    progressInMegaBytes?: number | undefined;
    totalDataInMegaBytes?: number | undefined;
    sourceDatabaseName?: string | undefined;
    sourceSchemaName?: string | undefined;
    sourceTableName?: string | undefined;
    targetDatabaseName?: string | undefined;
    targetSchemaName?: string | undefined;
    newTableName?: string | undefined;
    recoveryPointId?: string | undefined;
}
export interface GetTableRestoreStatusResponse {
    tableRestoreStatus?: TableRestoreStatus | undefined;
}
export interface GetTrackRequest {
    trackName: string;
}
export interface UpdateTarget {
    trackName?: string | undefined;
    workgroupVersion?: string | undefined;
}
export type UpdateTargetsList = UpdateTarget[];
export interface ServerlessTrack {
    trackName?: string | undefined;
    workgroupVersion?: string | undefined;
    updateTargets?: UpdateTarget[] | undefined;
}
export interface GetTrackResponse {
    track?: ServerlessTrack | undefined;
}
export interface GetUsageLimitRequest {
    usageLimitId: string;
}
export interface GetUsageLimitResponse {
    usageLimit?: UsageLimit | undefined;
}
export interface GetWorkgroupRequest {
    workgroupName: string;
}
export interface GetWorkgroupResponse {
    workgroup: Workgroup;
}
export type PaginationToken = string;
export interface ListCustomDomainAssociationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    customDomainName?: string | undefined;
    customDomainCertificateArn?: string | undefined;
}
export interface Association {
    customDomainCertificateArn?: string | undefined;
    customDomainCertificateExpiryTime?: Date | undefined;
    customDomainName?: string | undefined;
    workgroupName?: string | undefined;
}
export type AssociationList = Association[];
export interface ListCustomDomainAssociationsResponse {
    nextToken?: string | undefined;
    associations?: Association[] | undefined;
}
export interface ListEndpointAccessRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    workgroupName?: string | undefined;
    vpcId?: string | undefined;
    ownerAccount?: string | undefined;
}
export type EndpointAccessList = EndpointAccess[];
export interface ListEndpointAccessResponse {
    nextToken?: string | undefined;
    endpoints: EndpointAccess[];
}
export type SourceArn = string;
export interface ListManagedWorkgroupsRequest {
    sourceArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ManagedWorkgroupName = string;
export type ManagedWorkgroupStatus = "CREATING" | "DELETING" | "MODIFYING" | "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export interface ManagedWorkgroupListItem {
    managedWorkgroupName?: string | undefined;
    managedWorkgroupId?: string | undefined;
    sourceArn?: string | undefined;
    status?: ManagedWorkgroupStatus | undefined;
    creationDate?: Date | undefined;
}
export type ManagedWorkgroups = ManagedWorkgroupListItem[];
export interface ListManagedWorkgroupsResponse {
    nextToken?: string | undefined;
    managedWorkgroups?: ManagedWorkgroupListItem[] | undefined;
}
export interface ListNamespacesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type NamespaceList = Namespace[];
export interface ListNamespacesResponse {
    nextToken?: string | undefined;
    namespaces: Namespace[];
}
export interface ListRecoveryPointsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    namespaceName?: string | undefined;
    namespaceArn?: string | undefined;
}
export type RecoveryPointList = RecoveryPoint[];
export interface ListRecoveryPointsResponse {
    recoveryPoints?: RecoveryPoint[] | undefined;
    nextToken?: string | undefined;
}
export interface ListReservationOfferingsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ReservationOfferingsList = ReservationOffering[];
export interface ListReservationOfferingsResponse {
    reservationOfferingsList: ReservationOffering[];
    nextToken?: string | undefined;
}
export interface ListReservationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ReservationsList = Reservation[];
export interface ListReservationsResponse {
    reservationsList: Reservation[];
    nextToken?: string | undefined;
}
export interface ListScheduledActionsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    namespaceName?: string | undefined;
}
export interface ScheduledActionAssociation {
    namespaceName?: string | undefined;
    scheduledActionName?: string | undefined;
}
export type ScheduledActionsList = ScheduledActionAssociation[];
export interface ListScheduledActionsResponse {
    nextToken?: string | undefined;
    scheduledActions?: ScheduledActionAssociation[] | undefined;
}
export interface ListSnapshotCopyConfigurationsRequest {
    namespaceName?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SnapshotCopyConfigurations = SnapshotCopyConfiguration[];
export interface ListSnapshotCopyConfigurationsResponse {
    nextToken?: string | undefined;
    snapshotCopyConfigurations: SnapshotCopyConfiguration[];
}
export interface ListSnapshotsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    namespaceName?: string | undefined;
    namespaceArn?: string | undefined;
    ownerAccount?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type SnapshotList = Snapshot[];
export interface ListSnapshotsResponse {
    nextToken?: string | undefined;
    snapshots?: Snapshot[] | undefined;
}
export interface ListTableRestoreStatusRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    namespaceName?: string | undefined;
    workgroupName?: string | undefined;
}
export type TableRestoreStatusList = TableRestoreStatus[];
export interface ListTableRestoreStatusResponse {
    nextToken?: string | undefined;
    tableRestoreStatuses?: TableRestoreStatus[] | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface ListTracksRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type TrackList = ServerlessTrack[];
export interface ListTracksResponse {
    tracks?: ServerlessTrack[] | undefined;
    nextToken?: string | undefined;
}
export interface ListUsageLimitsRequest {
    resourceArn?: string | undefined;
    usageType?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type UsageLimits = UsageLimit[];
export interface ListUsageLimitsResponse {
    usageLimits?: UsageLimit[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkgroupsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    ownerAccount?: string | undefined;
}
export type WorkgroupList = Workgroup[];
export interface ListWorkgroupsResponse {
    nextToken?: string | undefined;
    workgroups: Workgroup[];
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
}
export interface PutResourcePolicyResponse {
    resourcePolicy?: ResourcePolicy | undefined;
}
export interface RestoreFromRecoveryPointRequest {
    recoveryPointId: string;
    namespaceName: string;
    workgroupName: string;
    maintainIntegration?: boolean | undefined;
}
export interface RestoreFromRecoveryPointResponse {
    recoveryPointId?: string | undefined;
    namespace?: Namespace | undefined;
}
export interface RestoreFromSnapshotRequest {
    namespaceName: string;
    workgroupName: string;
    snapshotName?: string | undefined;
    snapshotArn?: string | undefined;
    ownerAccount?: string | undefined;
    manageAdminPassword?: boolean | undefined;
    adminPasswordSecretKmsKeyId?: string | undefined;
    maintainIntegration?: boolean | undefined;
}
export interface RestoreFromSnapshotResponse {
    snapshotName?: string | undefined;
    ownerAccount?: string | undefined;
    namespace?: Namespace | undefined;
}
export interface RestoreTableFromRecoveryPointRequest {
    namespaceName: string;
    workgroupName: string;
    recoveryPointId: string;
    sourceDatabaseName: string;
    sourceSchemaName?: string | undefined;
    sourceTableName: string;
    targetDatabaseName?: string | undefined;
    targetSchemaName?: string | undefined;
    newTableName: string;
    activateCaseSensitiveIdentifier?: boolean | undefined;
}
export interface RestoreTableFromRecoveryPointResponse {
    tableRestoreStatus?: TableRestoreStatus | undefined;
}
export interface RestoreTableFromSnapshotRequest {
    namespaceName: string;
    workgroupName: string;
    snapshotName: string;
    sourceDatabaseName: string;
    sourceSchemaName?: string | undefined;
    sourceTableName: string;
    targetDatabaseName?: string | undefined;
    targetSchemaName?: string | undefined;
    newTableName: string;
    activateCaseSensitiveIdentifier?: boolean | undefined;
}
export interface RestoreTableFromSnapshotResponse {
    tableRestoreStatus?: TableRestoreStatus | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCustomDomainAssociationRequest {
    workgroupName: string;
    customDomainName: string;
    customDomainCertificateArn: string;
}
export interface UpdateCustomDomainAssociationResponse {
    customDomainName?: string | undefined;
    workgroupName?: string | undefined;
    customDomainCertificateArn?: string | undefined;
    customDomainCertificateExpiryTime?: Date | undefined;
}
export interface UpdateEndpointAccessRequest {
    endpointName: string;
    vpcSecurityGroupIds?: string[] | undefined;
}
export interface UpdateEndpointAccessResponse {
    endpoint?: EndpointAccess | undefined;
}
export type LakehouseRegistration = string;
export type CatalogNameString = string;
export type LakehouseIdcRegistration = string;
export interface UpdateLakehouseConfigurationRequest {
    namespaceName: string;
    lakehouseRegistration?: string | undefined;
    catalogName?: string | undefined;
    lakehouseIdcRegistration?: string | undefined;
    lakehouseIdcApplicationArn?: string | undefined;
    dryRun?: boolean | undefined;
}
export interface UpdateLakehouseConfigurationResponse {
    namespaceName?: string | undefined;
    lakehouseIdcApplicationArn?: string | undefined;
    lakehouseRegistrationStatus?: string | undefined;
    catalogArn?: string | undefined;
}
export type LogDestinationType = string;
export type S3TableAction = string;
export interface UpdateNamespaceRequest {
    namespaceName: string;
    adminUserPassword?: string | redacted.Redacted<string> | undefined;
    adminUsername?: string | redacted.Redacted<string> | undefined;
    kmsKeyId?: string | undefined;
    defaultIamRoleArn?: string | undefined;
    iamRoles?: string[] | undefined;
    logExports?: string[] | undefined;
    manageAdminPassword?: boolean | undefined;
    adminPasswordSecretKmsKeyId?: string | undefined;
    logDestinationType?: string | undefined;
    s3TableAction?: string | undefined;
    s3TableNames?: string[] | undefined;
    s3TableKmsKeyId?: string | undefined;
    s3TableGranularity?: string | undefined;
}
export interface UpdateNamespaceResponse {
    namespace: Namespace;
}
export interface UpdateScheduledActionRequest {
    scheduledActionName: string;
    targetAction?: TargetAction | undefined;
    schedule?: Schedule | undefined;
    roleArn?: string | undefined;
    enabled?: boolean | undefined;
    scheduledActionDescription?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface UpdateScheduledActionResponse {
    scheduledAction?: ScheduledActionResponse | undefined;
}
export interface UpdateSnapshotRequest {
    snapshotName: string;
    retentionPeriod?: number | undefined;
}
export interface UpdateSnapshotResponse {
    snapshot?: Snapshot | undefined;
}
export interface UpdateSnapshotCopyConfigurationRequest {
    snapshotCopyConfigurationId: string;
    snapshotRetentionPeriod?: number | undefined;
}
export interface UpdateSnapshotCopyConfigurationResponse {
    snapshotCopyConfiguration: SnapshotCopyConfiguration;
}
export interface UpdateUsageLimitRequest {
    usageLimitId: string;
    amount?: number | undefined;
    breachAction?: string | undefined;
}
export interface UpdateUsageLimitResponse {
    usageLimit?: UsageLimit | undefined;
}
export interface UpdateWorkgroupRequest {
    workgroupName: string;
    baseCapacity?: number | undefined;
    enhancedVpcRouting?: boolean | undefined;
    configParameters?: ConfigParameter[] | undefined;
    publiclyAccessible?: boolean | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    port?: number | undefined;
    maxCapacity?: number | undefined;
    ipAddressType?: string | undefined;
    pricePerformanceTarget?: PerformanceTarget | undefined;
    trackName?: string | undefined;
    extraComputeForAutomaticOptimization?: boolean | undefined;
}
export interface UpdateWorkgroupResponse {
    workgroup: Workgroup;
}
export type ConvertRecoveryPointToSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Converts a recovery point to a snapshot. For more information about recovery points and snapshots, see Working with snapshots and recovery points.
 */
export declare const convertRecoveryPointToSnapshot: API.OperationMethod<ConvertRecoveryPointToSnapshotRequest & RegionInput, ConvertRecoveryPointToSnapshotResponse, ConvertRecoveryPointToSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a custom domain association for Amazon Redshift Serverless.
 */
export declare const createCustomDomainAssociation: API.OperationMethod<CreateCustomDomainAssociationRequest & RegionInput, CreateCustomDomainAssociationResponse, CreateCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointAccessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Redshift Serverless managed VPC endpoint.
 */
export declare const createEndpointAccess: API.OperationMethod<CreateEndpointAccessRequest & RegionInput, CreateEndpointAccessResponse, CreateEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CreateNamespaceError = ConflictException | InternalServerException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a namespace in Amazon Redshift Serverless.
 */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest & RegionInput, CreateNamespaceResponse, CreateNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateReservationError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Redshift Serverless reservation, which gives you the option to commit to a specified number of Redshift Processing Units (RPUs) for a year at a discount from Serverless on-demand (OD) rates.
 */
export declare const createReservation: API.OperationMethod<CreateReservationRequest & RegionInput, CreateReservationResponse, CreateReservationError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledActionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a scheduled action. A scheduled action contains a schedule and an Amazon Redshift API action. For example, you can create a schedule of when to run the `CreateSnapshot` API operation.
 */
export declare const createScheduledAction: API.OperationMethod<CreateScheduledActionRequest & RegionInput, CreateScheduledActionResponse, CreateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of all databases in a namespace. For more information about snapshots, see Working with snapshots and recovery points.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest & RegionInput, CreateSnapshotResponse, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a snapshot copy configuration that lets you copy snapshots to another Amazon Web Services Region.
 */
export declare const createSnapshotCopyConfiguration: API.OperationMethod<CreateSnapshotCopyConfigurationRequest & RegionInput, CreateSnapshotCopyConfigurationResponse, CreateSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a usage limit for a specified Amazon Redshift Serverless usage type. The usage limit is identified by the returned usage limit identifier.
 */
export declare const createUsageLimit: API.OperationMethod<CreateUsageLimitRequest & RegionInput, CreateUsageLimitResponse, CreateUsageLimitError, Credentials | HttpClient.HttpClient>;
export type CreateWorkgroupError = ConflictException | InsufficientCapacityException | InternalServerException | Ipv6CidrBlockNotFoundException | ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an workgroup in Amazon Redshift Serverless.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that you own in a Region from reaching or being reached from the internet through internet gateways and egress-only internet gateways. If a workgroup is in an account with VPC BPA turned on, the following capabilities are blocked:
 *
 * - Creating a public access workgroup
 *
 * - Modifying a private workgroup to public
 *
 * - Adding a subnet with VPC BPA turned on to the workgroup when the workgroup is public
 *
 * For more information about VPC BPA, see Block public access to VPCs and subnets in the *Amazon VPC User Guide*.
 */
export declare const createWorkgroup: API.OperationMethod<CreateWorkgroupRequest & RegionInput, CreateWorkgroupResponse, CreateWorkgroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom domain association for Amazon Redshift Serverless.
 */
export declare const deleteCustomDomainAssociation: API.OperationMethod<DeleteCustomDomainAssociationRequest & RegionInput, DeleteCustomDomainAssociationResponse, DeleteCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Redshift Serverless managed VPC endpoint.
 */
export declare const deleteEndpointAccess: API.OperationMethod<DeleteEndpointAccessRequest & RegionInput, DeleteEndpointAccessResponse, DeleteEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a namespace from Amazon Redshift Serverless. Before you delete the namespace, you can create a final snapshot that has all of the data within the namespace.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest & RegionInput, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledActionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a scheduled action.
 */
export declare const deleteScheduledAction: API.OperationMethod<DeleteScheduledActionRequest & RegionInput, DeleteScheduledActionResponse, DeleteScheduledActionError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a snapshot from Amazon Redshift Serverless.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest & RegionInput, DeleteSnapshotResponse, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a snapshot copy configuration
 */
export declare const deleteSnapshotCopyConfiguration: API.OperationMethod<DeleteSnapshotCopyConfigurationRequest & RegionInput, DeleteSnapshotCopyConfigurationResponse, DeleteSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a usage limit from Amazon Redshift Serverless.
 */
export declare const deleteUsageLimit: API.OperationMethod<DeleteUsageLimitRequest & RegionInput, DeleteUsageLimitResponse, DeleteUsageLimitError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkgroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a workgroup.
 */
export declare const deleteWorkgroup: API.OperationMethod<DeleteWorkgroupRequest & RegionInput, DeleteWorkgroupResponse, DeleteWorkgroupError, Credentials | HttpClient.HttpClient>;
export type GetCredentialsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a database user name and temporary password with temporary authorization to log in to Amazon Redshift Serverless.
 *
 * By default, the temporary credentials expire in 900 seconds. You can optionally specify a duration between 900 seconds (15 minutes) and 3600 seconds (60 minutes).
 *
 * The Identity and Access Management (IAM) user or role that runs GetCredentials must have an IAM policy attached that allows access to all necessary actions and resources.
 *
 * If the `DbName` parameter is specified, the IAM policy must allow access to the resource dbname for the specified database name.
 */
export declare const getCredentials: API.OperationMethod<GetCredentialsRequest & RegionInput, GetCredentialsResponse, GetCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific custom domain association.
 */
export declare const getCustomDomainAssociation: API.OperationMethod<GetCustomDomainAssociationRequest & RegionInput, GetCustomDomainAssociationResponse, GetCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type GetEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information, such as the name, about a VPC endpoint.
 */
export declare const getEndpointAccess: API.OperationMethod<GetEndpointAccessRequest & RegionInput, GetEndpointAccessResponse, GetEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type GetIdentityCenterAuthTokenError = AccessDeniedException | ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an Identity Center authentication token for accessing Amazon Redshift Serverless workgroups.
 *
 * The token provides secure access to data within the specified workgroups using Identity Center identity propagation. The token expires after a specified duration and must be refreshed for continued access.
 *
 * The Identity and Access Management (IAM) user or role that runs GetIdentityCenterAuthToken must have appropriate permissions to access the specified workgroups and Identity Center integration must be configured for the workgroups.
 */
export declare const getIdentityCenterAuthToken: API.OperationMethod<GetIdentityCenterAuthTokenRequest & RegionInput, GetIdentityCenterAuthTokenResponse, GetIdentityCenterAuthTokenError, Credentials | HttpClient.HttpClient>;
export type GetNamespaceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a namespace in Amazon Redshift Serverless.
 */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest & RegionInput, GetNamespaceResponse, GetNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a recovery point.
 */
export declare const getRecoveryPoint: API.OperationMethod<GetRecoveryPointRequest & RegionInput, GetRecoveryPointResponse, GetRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type GetReservationError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an Amazon Redshift Serverless reservation. A reservation gives you the option to commit to a specified number of Redshift Processing Units (RPUs) for a year at a discount from Serverless on-demand (OD) rates.
 */
export declare const getReservation: API.OperationMethod<GetReservationRequest & RegionInput, GetReservationResponse, GetReservationError, Credentials | HttpClient.HttpClient>;
export type GetReservationOfferingError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the reservation offering. The offering determines the payment schedule for the reservation.
 */
export declare const getReservationOffering: API.OperationMethod<GetReservationOfferingRequest & RegionInput, GetReservationOfferingResponse, GetReservationOfferingError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a resource policy.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetScheduledActionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a scheduled action.
 */
export declare const getScheduledAction: API.OperationMethod<GetScheduledActionRequest & RegionInput, GetScheduledActionResponse, GetScheduledActionError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specific snapshot.
 */
export declare const getSnapshot: API.OperationMethod<GetSnapshotRequest & RegionInput, GetSnapshotResponse, GetSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetTableRestoreStatusError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a `TableRestoreStatus` object.
 */
export declare const getTableRestoreStatus: API.OperationMethod<GetTableRestoreStatusRequest & RegionInput, GetTableRestoreStatusResponse, GetTableRestoreStatusError, Credentials | HttpClient.HttpClient>;
export type GetTrackError = AccessDeniedException | ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the Redshift Serverless version for a specified track.
 */
export declare const getTrack: API.OperationMethod<GetTrackRequest & RegionInput, GetTrackResponse, GetTrackError, Credentials | HttpClient.HttpClient>;
export type GetUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a usage limit.
 */
export declare const getUsageLimit: API.OperationMethod<GetUsageLimitRequest & RegionInput, GetUsageLimitResponse, GetUsageLimitError, Credentials | HttpClient.HttpClient>;
export type GetWorkgroupError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a specific workgroup.
 */
export declare const getWorkgroup: API.OperationMethod<GetWorkgroupRequest & RegionInput, GetWorkgroupResponse, GetWorkgroupError, Credentials | HttpClient.HttpClient>;
export type ListCustomDomainAssociationsError = AccessDeniedException | InternalServerException | InvalidPaginationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists custom domain associations for Amazon Redshift Serverless.
 */
export declare const listCustomDomainAssociations: API.PaginatedOperationMethod<ListCustomDomainAssociationsRequest & RegionInput, ListCustomDomainAssociationsResponse, ListCustomDomainAssociationsError, Credentials | HttpClient.HttpClient, Association>;
export type ListEndpointAccessError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns an array of `EndpointAccess` objects and relevant information.
 */
export declare const listEndpointAccess: API.PaginatedOperationMethod<ListEndpointAccessRequest & RegionInput, ListEndpointAccessResponse, ListEndpointAccessError, Credentials | HttpClient.HttpClient, EndpointAccess>;
export type ListManagedWorkgroupsError = AccessDeniedException | InternalServerException | CommonErrors;
/**
 * Returns information about a list of specified managed workgroups in your account.
 */
export declare const listManagedWorkgroups: API.PaginatedOperationMethod<ListManagedWorkgroupsRequest & RegionInput, ListManagedWorkgroupsResponse, ListManagedWorkgroupsError, Credentials | HttpClient.HttpClient, ManagedWorkgroupListItem>;
export type ListNamespacesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of specified namespaces.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest & RegionInput, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, Namespace>;
export type ListRecoveryPointsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns an array of recovery points.
 */
export declare const listRecoveryPoints: API.PaginatedOperationMethod<ListRecoveryPointsRequest & RegionInput, ListRecoveryPointsResponse, ListRecoveryPointsError, Credentials | HttpClient.HttpClient, RecoveryPoint>;
export type ListReservationOfferingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the current reservation offerings in your account.
 */
export declare const listReservationOfferings: API.PaginatedOperationMethod<ListReservationOfferingsRequest & RegionInput, ListReservationOfferingsResponse, ListReservationOfferingsError, Credentials | HttpClient.HttpClient, ReservationOffering>;
export type ListReservationsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Reservation objects.
 */
export declare const listReservations: API.PaginatedOperationMethod<ListReservationsRequest & RegionInput, ListReservationsResponse, ListReservationsError, Credentials | HttpClient.HttpClient, Reservation>;
export type ListScheduledActionsError = InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of scheduled actions. You can use the flags to filter the list of returned scheduled actions.
 */
export declare const listScheduledActions: API.PaginatedOperationMethod<ListScheduledActionsRequest & RegionInput, ListScheduledActionsResponse, ListScheduledActionsError, Credentials | HttpClient.HttpClient, ScheduledActionAssociation>;
export type ListSnapshotCopyConfigurationsError = ConflictException | InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of snapshot copy configurations.
 */
export declare const listSnapshotCopyConfigurations: API.PaginatedOperationMethod<ListSnapshotCopyConfigurationsRequest & RegionInput, ListSnapshotCopyConfigurationsResponse, ListSnapshotCopyConfigurationsError, Credentials | HttpClient.HttpClient, SnapshotCopyConfiguration>;
export type ListSnapshotsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of snapshots.
 */
export declare const listSnapshots: API.PaginatedOperationMethod<ListSnapshotsRequest & RegionInput, ListSnapshotsResponse, ListSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type ListTableRestoreStatusError = InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an array of `TableRestoreStatus` objects.
 */
export declare const listTableRestoreStatus: API.PaginatedOperationMethod<ListTableRestoreStatusRequest & RegionInput, ListTableRestoreStatusResponse, ListTableRestoreStatusError, Credentials | HttpClient.HttpClient, TableRestoreStatus>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTracksError = AccessDeniedException | InternalServerException | InvalidPaginationException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the Amazon Redshift Serverless versions.
 */
export declare const listTracks: API.PaginatedOperationMethod<ListTracksRequest & RegionInput, ListTracksResponse, ListTracksError, Credentials | HttpClient.HttpClient, ServerlessTrack>;
export type ListUsageLimitsError = ConflictException | InternalServerException | InvalidPaginationException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all usage limits within Amazon Redshift Serverless.
 */
export declare const listUsageLimits: API.PaginatedOperationMethod<ListUsageLimitsRequest & RegionInput, ListUsageLimitsResponse, ListUsageLimitsError, Credentials | HttpClient.HttpClient, UsageLimit>;
export type ListWorkgroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of specified workgroups.
 */
export declare const listWorkgroups: API.PaginatedOperationMethod<ListWorkgroupsRequest & RegionInput, ListWorkgroupsResponse, ListWorkgroupsError, Credentials | HttpClient.HttpClient, Workgroup>;
export type PutResourcePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource policy. Currently, you can use policies to share snapshots across Amazon Web Services accounts.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RestoreFromRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restore the data from a recovery point.
 */
export declare const restoreFromRecoveryPoint: API.OperationMethod<RestoreFromRecoveryPointRequest & RegionInput, RestoreFromRecoveryPointResponse, RestoreFromRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type RestoreFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Restores a namespace from a snapshot.
 */
export declare const restoreFromSnapshot: API.OperationMethod<RestoreFromSnapshotRequest & RegionInput, RestoreFromSnapshotResponse, RestoreFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreTableFromRecoveryPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restores a table from a recovery point to your Amazon Redshift Serverless instance. You can't use this operation to restore tables with interleaved sort keys.
 */
export declare const restoreTableFromRecoveryPoint: API.OperationMethod<RestoreTableFromRecoveryPointRequest & RegionInput, RestoreTableFromRecoveryPointResponse, RestoreTableFromRecoveryPointError, Credentials | HttpClient.HttpClient>;
export type RestoreTableFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Restores a table from a snapshot to your Amazon Redshift Serverless instance. You can't use this operation to restore tables with interleaved sort keys.
 */
export declare const restoreTableFromSnapshot: API.OperationMethod<RestoreTableFromSnapshotRequest & RegionInput, RestoreTableFromSnapshotResponse, RestoreTableFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or set of tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomDomainAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Redshift Serverless certificate associated with a custom domain.
 */
export declare const updateCustomDomainAssociation: API.OperationMethod<UpdateCustomDomainAssociationRequest & RegionInput, UpdateCustomDomainAssociationResponse, UpdateCustomDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointAccessError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Redshift Serverless managed endpoint.
 */
export declare const updateEndpointAccess: API.OperationMethod<UpdateEndpointAccessRequest & RegionInput, UpdateEndpointAccessResponse, UpdateEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type UpdateLakehouseConfigurationError = ConflictException | DryRunException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the lakehouse configuration for a namespace. This operation allows you to manage Amazon Redshift federated permissions and Amazon Web Services IAM Identity Center trusted identity propagation.
 */
export declare const updateLakehouseConfiguration: API.OperationMethod<UpdateLakehouseConfigurationRequest & RegionInput, UpdateLakehouseConfigurationResponse, UpdateLakehouseConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateNamespaceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a namespace with the specified settings. Unless required, you can't update multiple parameters in one request. For example, you must specify both `adminUsername` and `adminUserPassword` to update either field, but you can't update both `kmsKeyId` and `logExports` in a single request.
 *
 * Similarly, an S3 Tables log-publishing update (a request where `logDestinationType` is `s3table`) cannot be combined with any other namespace configuration change and must be submitted as its own request.
 */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest & RegionInput, UpdateNamespaceResponse, UpdateNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledActionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a scheduled action.
 */
export declare const updateScheduledAction: API.OperationMethod<UpdateScheduledActionRequest & RegionInput, UpdateScheduledActionResponse, UpdateScheduledActionError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a snapshot.
 */
export declare const updateSnapshot: API.OperationMethod<UpdateSnapshotRequest & RegionInput, UpdateSnapshotResponse, UpdateSnapshotError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotCopyConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a snapshot copy configuration.
 */
export declare const updateSnapshotCopyConfiguration: API.OperationMethod<UpdateSnapshotCopyConfigurationRequest & RegionInput, UpdateSnapshotCopyConfigurationResponse, UpdateSnapshotCopyConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageLimitError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Update a usage limit in Amazon Redshift Serverless. You can't update the usage type or period of a usage limit.
 */
export declare const updateUsageLimit: API.OperationMethod<UpdateUsageLimitRequest & RegionInput, UpdateUsageLimitResponse, UpdateUsageLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkgroupError = ConflictException | InsufficientCapacityException | InternalServerException | Ipv6CidrBlockNotFoundException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a workgroup with the specified configuration settings. You can't update multiple parameters in one request. For example, you can update `baseCapacity` or `port` in a single request, but you can't update both in the same request.
 *
 * VPC Block Public Access (BPA) enables you to block resources in VPCs and subnets that you own in a Region from reaching or being reached from the internet through internet gateways and egress-only internet gateways. If a workgroup is in an account with VPC BPA turned on, the following capabilities are blocked:
 *
 * - Creating a public access workgroup
 *
 * - Modifying a private workgroup to public
 *
 * - Adding a subnet with VPC BPA turned on to the workgroup when the workgroup is public
 *
 * For more information about VPC BPA, see Block public access to VPCs and subnets in the *Amazon VPC User Guide*.
 */
export declare const updateWorkgroup: API.OperationMethod<UpdateWorkgroupRequest & RegionInput, UpdateWorkgroupResponse, UpdateWorkgroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=redshift-serverless.d.ts.map