import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Locale = string;
export type ListingId = string;
export interface GetListingInput {
    locale?: string | undefined;
    listingId: string;
}
export type ProductId = string;
export type NonEmptyString = string;
export type SellerProfileId = string;
export interface SellerInformation {
    sellerProfileId: string;
    displayName: string;
}
export interface ProductInformation {
    productId: string;
    productName: string;
    manufacturer: SellerInformation;
}
export type OfferId = string;
export type NullableString = string;
export interface OfferInformation {
    offerId: string;
    offerName?: string | undefined;
    sellerOfRecord: SellerInformation;
}
export interface ListingAssociatedEntity {
    product?: ProductInformation | undefined;
    offer?: OfferInformation | undefined;
}
export type ListingAssociatedEntityList = ListingAssociatedEntity[];
export type ListingBadgeType = "AWS_FREE_TIER" | "FREE_TRIAL" | "DEPLOYED_ON_AWS" | "QUICK_LAUNCH" | "MULTI_PRODUCT" | (string & {});
export interface ListingBadge {
    displayName: string;
    badgeType: ListingBadgeType;
}
export type ListingBadgeList = ListingBadge[];
export type Catalog = string;
export interface Category {
    categoryId: string;
    displayName: string;
}
export type CategoryList = Category[];
export type FulfillmentOptionType = "AMAZON_MACHINE_IMAGE" | "API" | "CLOUDFORMATION_TEMPLATE" | "CONTAINER" | "HELM" | "EKS_ADD_ON" | "EC2_IMAGE_BUILDER_COMPONENT" | "DATA_EXCHANGE" | "PROFESSIONAL_SERVICES" | "SAAS" | "SAGEMAKER_ALGORITHM" | "SAGEMAKER_MODEL" | (string & {});
export interface FulfillmentOptionSummary {
    fulfillmentOptionType: FulfillmentOptionType;
    displayName: string;
}
export type FulfillmentOptionSummaryList = FulfillmentOptionSummary[];
export type HighlightList = string[];
export type URL = string;
export type PricingModelType = "USAGE" | "CONTRACT" | "BYOL" | "FREE" | (string & {});
export interface PricingModel {
    pricingModelType: PricingModelType;
    displayName: string;
}
export type PricingModelList = PricingModel[];
export type PricingUnitType = "USERS" | "HOSTS" | "BANDWIDTH" | "DATA" | "TIERS" | "REQUESTS" | "UNITS" | (string & {});
export interface PricingUnit {
    pricingUnitType: PricingUnitType;
    displayName: string;
}
export type PricingUnitList = PricingUnit[];
export interface PromotionalEmbeddedImage {
    title: string;
    url: string;
    description?: string | undefined;
}
export interface PromotionalEmbeddedVideo {
    title: string;
    url: string;
    preview: string;
    thumbnail: string;
    description?: string | undefined;
}
export type PromotionalMedia = {
    embeddedImage: PromotionalEmbeddedImage;
    embeddedVideo?: undefined;
} | {
    embeddedImage?: undefined;
    embeddedVideo: PromotionalEmbeddedVideo;
};
export type PromotionalMediaList = PromotionalMedia[];
export type ResourceType = "MANUFACTURER_SUPPORT" | "MANUFACTURER_INSTRUCTIONS" | (string & {});
export type ResourceContentType = "EMAIL" | "PHONE_NUMBER" | "LINK" | "OTHER" | (string & {});
export interface Resource {
    resourceType: ResourceType;
    contentType: ResourceContentType;
    value: string;
    displayName?: string | undefined;
}
export type ResourceList = Resource[];
export type ReviewSourceId = "AWS_MARKETPLACE" | "G2" | "PEERSPOT" | (string & {});
export type NonNegativeCount = number;
export interface ReviewSourceSummary {
    sourceName: string;
    sourceId: ReviewSourceId;
    sourceUrl?: string | undefined;
    averageRating: string;
    totalReviews: number;
}
export type ReviewSourceSummaryList = ReviewSourceSummary[];
export interface ReviewSummary {
    reviewSourceSummaries: ReviewSourceSummary[];
}
export type SellerEngagementType = "REQUEST_FOR_PRIVATE_OFFER" | "REQUEST_FOR_DEMO" | (string & {});
export type SellerEngagementContentType = "LINK" | (string & {});
export interface SellerEngagement {
    engagementType: SellerEngagementType;
    contentType: SellerEngagementContentType;
    value: string;
}
export type SellerEngagementList = SellerEngagement[];
export interface UseCase {
    description: string;
    displayName: string;
    value: string;
}
export interface UseCaseEntry {
    useCase: UseCase;
}
export type UseCaseList = UseCaseEntry[];
export interface GetListingOutput {
    locale?: string | undefined;
    associatedEntities: ListingAssociatedEntity[];
    badges: ListingBadge[];
    catalog: string;
    categories: Category[];
    fulfillmentOptionSummaries: FulfillmentOptionSummary[];
    highlights: string[];
    integrationGuide?: string | undefined;
    listingId: string;
    listingName: string;
    logoThumbnailUrl: string;
    longDescription: string;
    pricingModels: PricingModel[];
    pricingUnits: PricingUnit[];
    promotionalMedia: PromotionalMedia[];
    publisher: SellerInformation;
    resources: Resource[];
    reviewSummary?: ReviewSummary | undefined;
    sellerEngagements: SellerEngagement[];
    shortDescription: string;
    useCases: UseCaseEntry[];
}
export interface GetOfferInput {
    locale?: string | undefined;
    offerId: string;
}
export type OfferSetId = string;
export interface OfferSetInformation {
    offerSetId: string;
    sellerOfRecord: SellerInformation;
}
export interface OfferAssociatedEntity {
    product: ProductInformation;
    offerSet?: OfferSetInformation | undefined;
}
export type OfferAssociatedEntityList = OfferAssociatedEntity[];
export type AgreementResourceId = string;
export type PurchaseOptionBadgeType = "PRIVATE_PRICING" | "FUTURE_DATED" | "REPLACEMENT_OFFER" | "AUTO_RENEW" | (string & {});
export interface PurchaseOptionBadge {
    displayName: string;
    badgeType: PurchaseOptionBadgeType;
}
export type PurchaseOptionBadgeList = PurchaseOptionBadge[];
export interface GetOfferOutput {
    locale?: string | undefined;
    offerId: string;
    catalog: string;
    offerName?: string | undefined;
    expirationTime?: Date | undefined;
    availableFromTime?: Date | undefined;
    sellerOfRecord: SellerInformation;
    associatedEntities: OfferAssociatedEntity[];
    agreementProposalId: string;
    replacementAgreementId?: string | undefined;
    pricingModel: PricingModel;
    badges: PurchaseOptionBadge[];
}
export interface GetOfferSetInput {
    locale?: string | undefined;
    offerSetId: string;
}
export interface OfferSetAssociatedEntity {
    product: ProductInformation;
    offer: OfferInformation;
}
export type OfferSetAssociatedEntityList = OfferSetAssociatedEntity[];
export interface GetOfferSetOutput {
    locale?: string | undefined;
    offerSetId: string;
    catalog: string;
    offerSetName?: string | undefined;
    availableFromTime?: Date | undefined;
    expirationTime?: Date | undefined;
    buyerNotes?: string | undefined;
    sellerOfRecord: SellerInformation;
    badges: PurchaseOptionBadge[];
    associatedEntities: OfferSetAssociatedEntity[];
}
export type NextToken = string;
export interface GetOfferTermsInput {
    locale?: string | undefined;
    offerId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TermId = string;
export type TermType = "ByolPricingTerm" | "ConfigurableUpfrontPricingTerm" | "FixedUpfrontPricingTerm" | "UsageBasedPricingTerm" | "FreeTrialPricingTerm" | "LegalTerm" | "PaymentScheduleTerm" | "RecurringPaymentTerm" | "RenewalTerm" | "SupportTerm" | "ValidityTerm" | "VariablePaymentTerm" | "NetPaymentTerm" | (string & {});
export interface ByolPricingTerm {
    id: string;
    type: TermType;
}
export type CurrencyCode = string;
export type SelectorType = "Duration" | (string & {});
export type BoundedString = string;
export interface Selector {
    type: SelectorType;
    value: string;
}
export type RateCardConstraintType = "Allowed" | "Disallowed" | (string & {});
export interface Constraints {
    multipleDimensionSelection: RateCardConstraintType;
    quantityConfiguration: RateCardConstraintType;
}
export type DimensionLabelType = "Region" | "SagemakerOption" | (string & {});
export interface DimensionLabel {
    labelType: DimensionLabelType;
    labelValue: string;
    displayName?: string | undefined;
}
export type DimensionLabelList = DimensionLabel[];
export interface RateCardItem {
    dimensionKey: string;
    displayName: string;
    description?: string | undefined;
    dimensionLabels?: DimensionLabel[] | undefined;
    unit: string;
    price: string;
}
export type RateCardList = RateCardItem[];
export interface ConfigurableUpfrontRateCardItem {
    selector: Selector;
    constraints: Constraints;
    rateCard: RateCardItem[];
}
export type ConfigurableUpfrontRateCardList = ConfigurableUpfrontRateCardItem[];
export interface ConfigurableUpfrontPricingTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    rateCards?: ConfigurableUpfrontRateCardItem[] | undefined;
}
export interface GrantItem {
    dimensionKey: string;
    displayName: string;
    description?: string | undefined;
    dimensionLabels?: DimensionLabel[] | undefined;
    unit: string;
    maxQuantity?: number | undefined;
}
export type GrantList = GrantItem[];
export interface FixedUpfrontPricingTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    duration?: string | undefined;
    price: string;
    grants: GrantItem[];
}
export interface FreeTrialPricingTerm {
    id: string;
    type: TermType;
    duration?: string | undefined;
    grants: GrantItem[];
}
export type LegalDocumentType = "CustomEula" | "CustomDsa" | "EnterpriseEula" | "StandardEula" | "StandardDsa" | (string & {});
export interface DocumentItem {
    type: LegalDocumentType;
    url: string;
    version?: string | undefined;
}
export type DocumentList = DocumentItem[];
export interface LegalTerm {
    id: string;
    type: TermType;
    documents: DocumentItem[];
}
export interface ScheduleItem {
    chargeDate: Date;
    chargeAmount: string;
}
export type ScheduleList = ScheduleItem[];
export interface PaymentScheduleTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    schedule: ScheduleItem[];
}
export type BillingPeriodType = "Monthly" | (string & {});
export interface RecurringPaymentTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    billingPeriod: BillingPeriodType;
    price: string;
}
export interface FixedPercentage {
    percentageValue: string;
}
export interface PercentageRange {
    minimumValue: string;
    maximumValue: string;
    defaultValue: string;
}
export type PriceIncrease = {
    fixedPercentage: FixedPercentage;
    percentageRange?: undefined;
} | {
    fixedPercentage?: undefined;
    percentageRange: PercentageRange;
};
export interface PaymentScheduleEntry {
    chargeDateOffset: string;
    chargePercentage: string;
    dayOfMonth?: number | undefined;
}
export type PaymentScheduleEntryList = PaymentScheduleEntry[];
export interface PaymentScheduleTermTemplate {
    schedule: PaymentScheduleEntry[];
}
export type TermTemplate = {
    paymentScheduleTermTemplate: PaymentScheduleTermTemplate;
};
export type TermTemplateList = TermTemplate[];
export interface RenewalTerm {
    id: string;
    type: TermType;
    maxRenewals?: number | undefined;
    lockoutPeriod?: string | undefined;
    adjustmentDeadline?: string | undefined;
    priceIncrease?: PriceIncrease | undefined;
    termTemplates?: TermTemplate[] | undefined;
}
export interface SupportTerm {
    id: string;
    type: TermType;
    refundPolicy: string;
}
export interface UsageBasedRateCardItem {
    rateCard: RateCardItem[];
}
export type UsageBasedRateCardList = UsageBasedRateCardItem[];
export interface UsageBasedPricingTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    rateCards: UsageBasedRateCardItem[];
}
export interface ValidityTerm {
    id: string;
    type: TermType;
    agreementDuration?: string | undefined;
    agreementEndDate?: Date | undefined;
    agreementStartDate?: Date | undefined;
}
export interface VariablePaymentTerm {
    id: string;
    type: TermType;
    currencyCode: string;
    maxTotalChargeAmount: string;
}
export interface NetPaymentTerm {
    id: string;
    type: TermType;
    paymentDuePeriod: string;
}
export type OfferTerm = {
    byolPricingTerm: ByolPricingTerm;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm: ConfigurableUpfrontPricingTerm;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm: FixedUpfrontPricingTerm;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm: FreeTrialPricingTerm;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm: LegalTerm;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm: PaymentScheduleTerm;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm: RecurringPaymentTerm;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm: RenewalTerm;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm: SupportTerm;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm: UsageBasedPricingTerm;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm: ValidityTerm;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm: VariablePaymentTerm;
    netPaymentTerm?: undefined;
} | {
    byolPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    legalTerm?: undefined;
    paymentScheduleTerm?: undefined;
    recurringPaymentTerm?: undefined;
    renewalTerm?: undefined;
    supportTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    validityTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm: NetPaymentTerm;
};
export type OfferTermsList = OfferTerm[];
export interface GetOfferTermsOutput {
    locale?: string | undefined;
    offerTerms: OfferTerm[];
    nextToken?: string | undefined;
}
export interface GetProductInput {
    locale?: string | undefined;
    productId: string;
}
export type DeployedOnAwsStatus = "DEPLOYED" | "NOT_DEPLOYED" | "NOT_APPLICABLE" | (string & {});
export interface GetProductOutput {
    locale?: string | undefined;
    productId: string;
    catalog: string;
    productName: string;
    manufacturer: SellerInformation;
    deployedOnAws: DeployedOnAwsStatus;
    shortDescription: string;
    longDescription: string;
    logoThumbnailUrl: string;
    fulfillmentOptionSummaries: FulfillmentOptionSummary[];
    categories: Category[];
    highlights: string[];
    promotionalMedia: PromotionalMedia[];
    resources: Resource[];
    sellerEngagements: SellerEngagement[];
    listingId: string;
}
export interface ListFulfillmentOptionsInput {
    locale?: string | undefined;
    productId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AmazonMachineImageOperatingSystem {
    operatingSystemFamilyName: string;
    operatingSystemName: string;
    operatingSystemVersion?: string | undefined;
}
export type AmazonMachineImageOperatingSystemList = AmazonMachineImageOperatingSystem[];
export type AmazonMachineImageCidrIpAddressList = string[];
export interface AmazonMachineImageSecurityGroup {
    protocol: string;
    fromPort: number;
    toPort: number;
    cidrIpAddresses: string[];
}
export type AmazonMachineImageSecurityGroupList = AmazonMachineImageSecurityGroup[];
export interface AmazonMachineImageRecommendation {
    instanceType: string;
    securityGroups?: AmazonMachineImageSecurityGroup[] | undefined;
}
export type AmazonMachineImageEbsVolumeTypeList = string[];
export interface AmazonMachineImageEbsVolume {
    volumeTypes: string[];
    iops?: number | undefined;
}
export interface AmazonMachineImageFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionVersion?: string | undefined;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    operatingSystems: AmazonMachineImageOperatingSystem[];
    recommendation?: AmazonMachineImageRecommendation | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
    availableFromTime?: Date | undefined;
    accessUrlTemplate?: string | undefined;
    architecture: string;
    amiAlias?: string | undefined;
    ebsVolume?: AmazonMachineImageEbsVolume | undefined;
    shortDescription?: string | undefined;
}
export interface AwsSupportedService {
    supportedServiceType: string;
    displayName: string;
    description: string;
}
export type AwsSupportedServiceList = AwsSupportedService[];
export interface ApiFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    usageInstructions?: string | undefined;
    awsSupportedServices: AwsSupportedService[];
}
export interface CloudFormationFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
    availableFromTime?: Date | undefined;
    shortDescription?: string | undefined;
    longDescription?: string | undefined;
}
export interface ContainerOperatingSystem {
    operatingSystemFamilyName: string;
    operatingSystemName: string;
}
export type ContainerOperatingSystemList = ContainerOperatingSystem[];
export interface ContainerFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    operatingSystems?: ContainerOperatingSystem[] | undefined;
    awsSupportedServices?: AwsSupportedService[] | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
}
export interface HelmOperatingSystem {
    operatingSystemFamilyName: string;
    operatingSystemName: string;
}
export type HelmOperatingSystemList = HelmOperatingSystem[];
export interface HelmFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    operatingSystems?: HelmOperatingSystem[] | undefined;
    releaseNotes?: string | undefined;
    awsSupportedServices?: AwsSupportedService[] | undefined;
    usageInstructions?: string | undefined;
}
export interface EksAddOnOperatingSystem {
    operatingSystemFamilyName: string;
    operatingSystemName: string;
}
export type EksAddOnOperatingSystemList = EksAddOnOperatingSystem[];
export interface EksAddOnFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    operatingSystems?: EksAddOnOperatingSystem[] | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
    awsSupportedServices?: AwsSupportedService[] | undefined;
}
export interface Ec2ImageBuilderComponentFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionName: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    operatingSystems?: ContainerOperatingSystem[] | undefined;
    awsSupportedServices?: AwsSupportedService[] | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
}
export interface DataArtifact {
    description?: string | undefined;
    resourceArn?: string | undefined;
    resourceType: string;
    dataClassification: string;
}
export type DataArtifactList = DataArtifact[];
export interface DataExchangeFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    dataArtifacts?: DataArtifact[] | undefined;
}
export interface ProfessionalServicesFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
}
export type SaasQuickLaunchStatus = "ENABLED" | "DISABLED" | (string & {});
export interface SaasFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentUrl?: string | undefined;
    usageInstructions?: string | undefined;
    availableFromTime?: Date | undefined;
    launchUrl?: string | undefined;
    quickLaunch: SaasQuickLaunchStatus;
}
export interface SageMakerAlgorithmRecommendation {
    recommendedBatchTransformInstanceType: string;
    recommendedRealtimeInferenceInstanceType?: string | undefined;
    recommendedTrainingInstanceType: string;
}
export interface SageMakerAlgorithmFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
    recommendation?: SageMakerAlgorithmRecommendation | undefined;
}
export interface SageMakerModelRecommendation {
    recommendedBatchTransformInstanceType: string;
    recommendedRealtimeInferenceInstanceType?: string | undefined;
}
export type SageMakerModelContentTypeList = string[];
export type SageMakerModelResponseMimeTypeList = string[];
export interface SageMakerModelFulfillmentOption {
    fulfillmentOptionId: string;
    fulfillmentOptionType: FulfillmentOptionType;
    fulfillmentOptionDisplayName: string;
    fulfillmentOptionVersion?: string | undefined;
    releaseNotes?: string | undefined;
    usageInstructions?: string | undefined;
    recommendation?: SageMakerModelRecommendation | undefined;
    supportedContentTypes?: string[] | undefined;
    supportedResponseMimeTypes?: string[] | undefined;
}
export type FulfillmentOption = {
    amazonMachineImageFulfillmentOption: AmazonMachineImageFulfillmentOption;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption: ApiFulfillmentOption;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption: CloudFormationFulfillmentOption;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption: ContainerFulfillmentOption;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption: HelmFulfillmentOption;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption: EksAddOnFulfillmentOption;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption: Ec2ImageBuilderComponentFulfillmentOption;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption: DataExchangeFulfillmentOption;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption: ProfessionalServicesFulfillmentOption;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption: SaasFulfillmentOption;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption: SageMakerAlgorithmFulfillmentOption;
    sageMakerModelFulfillmentOption?: undefined;
} | {
    amazonMachineImageFulfillmentOption?: undefined;
    apiFulfillmentOption?: undefined;
    cloudFormationFulfillmentOption?: undefined;
    containerFulfillmentOption?: undefined;
    helmFulfillmentOption?: undefined;
    eksAddOnFulfillmentOption?: undefined;
    ec2ImageBuilderComponentFulfillmentOption?: undefined;
    dataExchangeFulfillmentOption?: undefined;
    professionalServicesFulfillmentOption?: undefined;
    saasFulfillmentOption?: undefined;
    sageMakerAlgorithmFulfillmentOption?: undefined;
    sageMakerModelFulfillmentOption: SageMakerModelFulfillmentOption;
};
export type FulfillmentOptionsList = FulfillmentOption[];
export interface ListFulfillmentOptionsOutput {
    locale?: string | undefined;
    fulfillmentOptions: FulfillmentOption[];
    nextToken?: string | undefined;
}
export type PurchaseOptionFilterType = "PRODUCT_ID" | "SELLER_OF_RECORD_PROFILE_ID" | "PURCHASE_OPTION_TYPE" | "VISIBILITY_SCOPE" | "AVAILABILITY_STATUS" | (string & {});
export type PurchaseOptionFilterValue = string;
export type PurchaseOptionFilterValueList = string[];
export interface PurchaseOptionFilter {
    filterType: PurchaseOptionFilterType;
    filterValues: string[];
}
export type PurchaseOptionFilterList = PurchaseOptionFilter[];
export type MaxResults = number;
export interface ListPurchaseOptionsInput {
    locale?: string | undefined;
    filters?: PurchaseOptionFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type PurchaseOptionType = "OFFER" | "OFFERSET" | (string & {});
export interface PurchaseOptionAssociatedEntity {
    product: ProductInformation;
    offer: OfferInformation;
    offerSet?: OfferSetInformation | undefined;
}
export type PurchaseOptionAssociatedEntityList = PurchaseOptionAssociatedEntity[];
export interface PurchaseOptionSummary {
    purchaseOptionId: string;
    catalog: string;
    purchaseOptionType: PurchaseOptionType;
    purchaseOptionName?: string | undefined;
    availableFromTime?: Date | undefined;
    expirationTime?: Date | undefined;
    sellerOfRecord: SellerInformation;
    badges?: PurchaseOptionBadge[] | undefined;
    associatedEntities: PurchaseOptionAssociatedEntity[];
}
export type PurchaseOptionSummaryList = PurchaseOptionSummary[];
export interface ListPurchaseOptionsOutput {
    purchaseOptions?: PurchaseOptionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SearchText = string;
export type SearchFilterType = "MIN_AVERAGE_CUSTOMER_RATING" | "MAX_AVERAGE_CUSTOMER_RATING" | "CATEGORY" | "PUBLISHER" | "FULFILLMENT_OPTION_TYPE" | "PRICING_MODEL" | "PRICING_UNIT" | "DEPLOYED_ON_AWS" | "NUMBER_OF_PRODUCTS" | (string & {});
export type SearchFilterValue = string;
export type SearchFilterValueList = string[];
export interface SearchFilter {
    filterType: SearchFilterType;
    filterValues: string[];
}
export type SearchFilterList = SearchFilter[];
export type SearchFacetType = "AVERAGE_CUSTOMER_RATING" | "CATEGORY" | "PUBLISHER" | "FULFILLMENT_OPTION_TYPE" | "PRICING_MODEL" | "PRICING_UNIT" | "DEPLOYED_ON_AWS" | "NUMBER_OF_PRODUCTS" | (string & {});
export type FacetTypeList = SearchFacetType[];
export interface SearchFacetsInput {
    locale?: string | undefined;
    searchText?: string | undefined;
    filters?: SearchFilter[] | undefined;
    facetTypes?: SearchFacetType[] | undefined;
    nextToken?: string | undefined;
}
export interface ListingFacet {
    value: string;
    displayName: string;
    parent?: string | undefined;
    count: number;
}
export type ListingFacetList = ListingFacet[];
export type TypeToFacetMap = {
    [key in SearchFacetType]?: ListingFacet[] | undefined;
};
export interface SearchFacetsOutput {
    totalResults: number;
    listingFacets: {
        [key: string]: ListingFacet[] | undefined;
    };
    nextToken?: string | undefined;
}
export type SearchListingsSortBy = "RELEVANCE" | "AVERAGE_CUSTOMER_RATING" | (string & {});
export type SearchListingsSortOrder = "DESCENDING" | "ASCENDING" | (string & {});
export interface SearchListingsInput {
    locale?: string | undefined;
    searchText?: string | undefined;
    filters?: SearchFilter[] | undefined;
    maxResults?: number | undefined;
    sortBy?: SearchListingsSortBy | undefined;
    sortOrder?: SearchListingsSortOrder | undefined;
    nextToken?: string | undefined;
}
export interface ListingSummaryAssociatedEntity {
    product?: ProductInformation | undefined;
}
export type ListingSummaryAssociatedEntityList = ListingSummaryAssociatedEntity[];
export interface ListingSummary {
    listingId: string;
    listingName: string;
    publisher: SellerInformation;
    fulfillmentOptionSummaries: FulfillmentOptionSummary[];
    catalog: string;
    shortDescription: string;
    logoThumbnailUrl: string;
    categories: Category[];
    badges: ListingBadge[];
    reviewSummary: ReviewSummary;
    pricingModels: PricingModel[];
    pricingUnits: PricingUnit[];
    associatedEntities: ListingSummaryAssociatedEntity[];
}
export type ListingSummaryList = ListingSummary[];
export interface SearchListingsOutput {
    totalResults: number;
    listingSummaries: ListingSummary[];
    nextToken?: string | undefined;
}
export type ExceptionMessage = string;
export type ValidationExceptionReason = "INVALID_PAGINATION_TOKEN" | "MALFORMED_REQUEST_PARAMETERS" | "PAGINATION_LIMIT_EXCEEDED" | (string & {});
export type GetListingError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides details about a listing, such as descriptions, badges, categories, pricing model summaries, reviews, and associated products and offers.
 */
export declare const getListing: API.OperationMethod<GetListingInput & RegionInput, GetListingOutput, GetListingError, Credentials | HttpClient.HttpClient>;
export type GetOfferError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides details about an offer, such as the pricing model, seller of record, availability dates, badges, and associated products.
 */
export declare const getOffer: API.OperationMethod<GetOfferInput & RegionInput, GetOfferOutput, GetOfferError, Credentials | HttpClient.HttpClient>;
export type GetOfferSetError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides details about an offer set, which is a bundle of offers across multiple products. Includes the seller, availability dates, buyer notes, and associated product-offer pairs.
 */
export declare const getOfferSet: API.OperationMethod<GetOfferSetInput & RegionInput, GetOfferSetOutput, GetOfferSetError, Credentials | HttpClient.HttpClient>;
export type GetOfferTermsError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the terms attached to an offer, such as pricing terms (usage-based, contract, BYOL, free trial), legal terms, payment schedules, validity terms, support terms, and renewal terms.
 */
export declare const getOfferTerms: API.PaginatedOperationMethod<GetOfferTermsInput & RegionInput, GetOfferTermsOutput, GetOfferTermsError, Credentials | HttpClient.HttpClient, OfferTerm>;
export type GetProductError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides details about a product, such as descriptions, highlights, categories, fulfillment option summaries, promotional media, and seller engagement options.
 */
export declare const getProduct: API.OperationMethod<GetProductInput & RegionInput, GetProductOutput, GetProductError, Credentials | HttpClient.HttpClient>;
export type ListFulfillmentOptionsError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the fulfillment options available for a product, including deployment details such as version information, operating systems, usage instructions, and release notes.
 */
export declare const listFulfillmentOptions: API.PaginatedOperationMethod<ListFulfillmentOptionsInput & RegionInput, ListFulfillmentOptionsOutput, ListFulfillmentOptionsError, Credentials | HttpClient.HttpClient, FulfillmentOption>;
export type ListPurchaseOptionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the purchase options (offers and offer sets) available to the buyer. You can filter results by product, seller, purchase option type, visibility scope, and availability status.
 *
 * You must include at least one of the following filters in the request: a `PRODUCT_ID` filter to specify the product for which to retrieve purchase options, or a `VISIBILITY_SCOPE` filter to retrieve purchase options by visibility.
 */
export declare const listPurchaseOptions: API.PaginatedOperationMethod<ListPurchaseOptionsInput & RegionInput, ListPurchaseOptionsOutput, ListPurchaseOptionsError, Credentials | HttpClient.HttpClient, PurchaseOptionSummary>;
export type SearchFacetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns available facet values for filtering listings, such as categories, pricing models, fulfillment option types, publishers, and customer ratings. Each facet value includes a count of matching listings.
 */
export declare const searchFacets: API.PaginatedOperationMethod<SearchFacetsInput & RegionInput, SearchFacetsOutput, SearchFacetsError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchListingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of product listings based on search criteria and filters. You can search by keyword, filter by category, pricing model, fulfillment type, and other attributes, and sort results by relevance or customer rating.
 */
export declare const searchListings: API.PaginatedOperationMethod<SearchListingsInput & RegionInput, SearchListingsOutput, SearchListingsError, Credentials | HttpClient.HttpClient, ListingSummary>;
export {};
//# sourceMappingURL=marketplace-discovery.d.ts.map