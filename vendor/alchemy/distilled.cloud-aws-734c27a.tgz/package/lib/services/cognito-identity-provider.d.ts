import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AliasExistsException_base: S.TaggedErrorClass<"AliasExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AliasExistsException extends /*@__PURE__*/ AliasExistsException_base {
}
declare const CodeDeliveryFailureException_base: S.TaggedErrorClass<"CodeDeliveryFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeDeliveryFailureException extends /*@__PURE__*/ CodeDeliveryFailureException_base {
}
declare const CodeMismatchException_base: S.TaggedErrorClass<"CodeMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeMismatchException extends /*@__PURE__*/ CodeMismatchException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DeviceKeyExistsException_base: S.TaggedErrorClass<"DeviceKeyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DeviceKeyExistsException extends /*@__PURE__*/ DeviceKeyExistsException_base {
}
declare const DuplicateProviderException_base: S.TaggedErrorClass<"DuplicateProviderException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateProviderException extends /*@__PURE__*/ DuplicateProviderException_base {
}
declare const EnableSoftwareTokenMFAException_base: S.TaggedErrorClass<"EnableSoftwareTokenMFAException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EnableSoftwareTokenMFAException extends /*@__PURE__*/ EnableSoftwareTokenMFAException_base {
}
declare const ExpiredCodeException_base: S.TaggedErrorClass<"ExpiredCodeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredCodeException extends /*@__PURE__*/ ExpiredCodeException_base {
}
declare const FeatureUnavailableInTierException_base: S.TaggedErrorClass<"FeatureUnavailableInTierException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class FeatureUnavailableInTierException extends /*@__PURE__*/ FeatureUnavailableInTierException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupExistsException_base: S.TaggedErrorClass<"GroupExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GroupExistsException extends /*@__PURE__*/ GroupExistsException_base {
}
declare const InternalErrorException_base: S.TaggedErrorClass<"InternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidEmailRoleAccessPolicyException_base: S.TaggedErrorClass<"InvalidEmailRoleAccessPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEmailRoleAccessPolicyException extends /*@__PURE__*/ InvalidEmailRoleAccessPolicyException_base {
}
declare const InvalidLambdaResponseException_base: S.TaggedErrorClass<"InvalidLambdaResponseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaResponseException extends /*@__PURE__*/ InvalidLambdaResponseException_base {
}
declare const InvalidOAuthFlowException_base: S.TaggedErrorClass<"InvalidOAuthFlowException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOAuthFlowException extends /*@__PURE__*/ InvalidOAuthFlowException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly reasonCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPasswordException_base: S.TaggedErrorClass<"InvalidPasswordException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPasswordException extends /*@__PURE__*/ InvalidPasswordException_base {
}
declare const InvalidSmsRoleAccessPolicyException_base: S.TaggedErrorClass<"InvalidSmsRoleAccessPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSmsRoleAccessPolicyException extends /*@__PURE__*/ InvalidSmsRoleAccessPolicyException_base {
}
declare const InvalidSmsRoleTrustRelationshipException_base: S.TaggedErrorClass<"InvalidSmsRoleTrustRelationshipException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSmsRoleTrustRelationshipException extends /*@__PURE__*/ InvalidSmsRoleTrustRelationshipException_base {
}
declare const InvalidUserPoolConfigurationException_base: S.TaggedErrorClass<"InvalidUserPoolConfigurationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserPoolConfigurationException extends /*@__PURE__*/ InvalidUserPoolConfigurationException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ManagedLoginBrandingExistsException_base: S.TaggedErrorClass<"ManagedLoginBrandingExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ManagedLoginBrandingExistsException extends /*@__PURE__*/ ManagedLoginBrandingExistsException_base {
}
declare const MFAMethodNotFoundException_base: S.TaggedErrorClass<"MFAMethodNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MFAMethodNotFoundException extends /*@__PURE__*/ MFAMethodNotFoundException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const OperationNotEnabledException_base: S.TaggedErrorClass<"OperationNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotEnabledException extends /*@__PURE__*/ OperationNotEnabledException_base {
}
declare const PasswordHistoryPolicyViolationException_base: S.TaggedErrorClass<"PasswordHistoryPolicyViolationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PasswordHistoryPolicyViolationException extends /*@__PURE__*/ PasswordHistoryPolicyViolationException_base {
}
declare const PasswordResetRequiredException_base: S.TaggedErrorClass<"PasswordResetRequiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PasswordResetRequiredException extends /*@__PURE__*/ PasswordResetRequiredException_base {
}
declare const PreconditionNotMetException_base: S.TaggedErrorClass<"PreconditionNotMetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PreconditionNotMetException extends /*@__PURE__*/ PreconditionNotMetException_base {
}
declare const RefreshTokenReuseException_base: S.TaggedErrorClass<"RefreshTokenReuseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RefreshTokenReuseException extends /*@__PURE__*/ RefreshTokenReuseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ScopeDoesNotExistException_base: S.TaggedErrorClass<"ScopeDoesNotExistException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScopeDoesNotExistException extends /*@__PURE__*/ ScopeDoesNotExistException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SoftwareTokenMFANotFoundException_base: S.TaggedErrorClass<"SoftwareTokenMFANotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SoftwareTokenMFANotFoundException extends /*@__PURE__*/ SoftwareTokenMFANotFoundException_base {
}
declare const TermsExistsException_base: S.TaggedErrorClass<"TermsExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TermsExistsException extends /*@__PURE__*/ TermsExistsException_base {
}
declare const TierChangeNotAllowedException_base: S.TaggedErrorClass<"TierChangeNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class TierChangeNotAllowedException extends /*@__PURE__*/ TierChangeNotAllowedException_base {
}
declare const TooManyFailedAttemptsException_base: S.TaggedErrorClass<"TooManyFailedAttemptsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFailedAttemptsException extends /*@__PURE__*/ TooManyFailedAttemptsException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnexpectedLambdaException_base: S.TaggedErrorClass<"UnexpectedLambdaException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnexpectedLambdaException extends /*@__PURE__*/ UnexpectedLambdaException_base {
}
declare const UnsupportedIdentityProviderException_base: S.TaggedErrorClass<"UnsupportedIdentityProviderException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedIdentityProviderException extends /*@__PURE__*/ UnsupportedIdentityProviderException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const UnsupportedTokenTypeException_base: S.TaggedErrorClass<"UnsupportedTokenTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedTokenTypeException extends /*@__PURE__*/ UnsupportedTokenTypeException_base {
}
declare const UnsupportedUserStateException_base: S.TaggedErrorClass<"UnsupportedUserStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedUserStateException extends /*@__PURE__*/ UnsupportedUserStateException_base {
}
declare const UserImportInProgressException_base: S.TaggedErrorClass<"UserImportInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserImportInProgressException extends /*@__PURE__*/ UserImportInProgressException_base {
}
declare const UserLambdaValidationException_base: S.TaggedErrorClass<"UserLambdaValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserLambdaValidationException extends /*@__PURE__*/ UserLambdaValidationException_base {
}
declare const UsernameExistsException_base: S.TaggedErrorClass<"UsernameExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UsernameExistsException extends /*@__PURE__*/ UsernameExistsException_base {
}
declare const UserNotConfirmedException_base: S.TaggedErrorClass<"UserNotConfirmedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotConfirmedException extends /*@__PURE__*/ UserNotConfirmedException_base {
}
declare const UserNotFoundException_base: S.TaggedErrorClass<"UserNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundException extends /*@__PURE__*/ UserNotFoundException_base {
}
declare const UserPoolAddOnNotEnabledException_base: S.TaggedErrorClass<"UserPoolAddOnNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserPoolAddOnNotEnabledException extends /*@__PURE__*/ UserPoolAddOnNotEnabledException_base {
}
declare const UserPoolTaggingException_base: S.TaggedErrorClass<"UserPoolTaggingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserPoolTaggingException extends /*@__PURE__*/ UserPoolTaggingException_base {
}
declare const WebAuthnChallengeNotFoundException_base: S.TaggedErrorClass<"WebAuthnChallengeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnChallengeNotFoundException extends /*@__PURE__*/ WebAuthnChallengeNotFoundException_base {
}
declare const WebAuthnClientMismatchException_base: S.TaggedErrorClass<"WebAuthnClientMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnClientMismatchException extends /*@__PURE__*/ WebAuthnClientMismatchException_base {
}
declare const WebAuthnConfigurationMissingException_base: S.TaggedErrorClass<"WebAuthnConfigurationMissingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnConfigurationMissingException extends /*@__PURE__*/ WebAuthnConfigurationMissingException_base {
}
declare const WebAuthnCredentialNotSupportedException_base: S.TaggedErrorClass<"WebAuthnCredentialNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnCredentialNotSupportedException extends /*@__PURE__*/ WebAuthnCredentialNotSupportedException_base {
}
declare const WebAuthnNotEnabledException_base: S.TaggedErrorClass<"WebAuthnNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnNotEnabledException extends /*@__PURE__*/ WebAuthnNotEnabledException_base {
}
declare const WebAuthnOriginNotAllowedException_base: S.TaggedErrorClass<"WebAuthnOriginNotAllowedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnOriginNotAllowedException extends /*@__PURE__*/ WebAuthnOriginNotAllowedException_base {
}
declare const WebAuthnRelyingPartyMismatchException_base: S.TaggedErrorClass<"WebAuthnRelyingPartyMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnRelyingPartyMismatchException extends /*@__PURE__*/ WebAuthnRelyingPartyMismatchException_base {
}
export type UserPoolIdType = string;
export type CustomAttributeNameType = string;
export type AttributeDataType = "String" | "Number" | "DateTime" | "Boolean" | (string & {});
export type StringType = string;
export interface NumberAttributeConstraintsType {
    MinValue?: string | undefined;
    MaxValue?: string | undefined;
}
export interface StringAttributeConstraintsType {
    MinLength?: string | undefined;
    MaxLength?: string | undefined;
}
export interface SchemaAttributeType {
    Name?: string | undefined;
    AttributeDataType?: AttributeDataType | undefined;
    DeveloperOnlyAttribute?: boolean | undefined;
    Mutable?: boolean | undefined;
    Required?: boolean | undefined;
    NumberAttributeConstraints?: NumberAttributeConstraintsType | undefined;
    StringAttributeConstraints?: StringAttributeConstraintsType | undefined;
}
export type CustomAttributesListType = SchemaAttributeType[];
export interface AddCustomAttributesRequest {
    UserPoolId: string;
    CustomAttributes: SchemaAttributeType[];
}
export interface AddCustomAttributesResponse {
}
export type ClientIdType = string | redacted.Redacted<string>;
export type ClientSecretType = string | redacted.Redacted<string>;
export interface AddUserPoolClientSecretRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
}
export type ClientSecretIdType = string;
export interface ClientSecretDescriptorType {
    ClientSecretId?: string | undefined;
    ClientSecretValue?: string | redacted.Redacted<string> | undefined;
    ClientSecretCreateDate?: Date | undefined;
}
export interface AddUserPoolClientSecretResponse {
    ClientSecretDescriptor?: ClientSecretDescriptorType | undefined;
}
export type UsernameType = string | redacted.Redacted<string>;
export type GroupNameType = string;
export interface AdminAddUserToGroupRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    GroupName: string;
}
export interface AdminAddUserToGroupResponse {
}
export type ClientMetadataType = {
    [key: string]: string | undefined;
};
export interface AdminConfirmSignUpRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AdminConfirmSignUpResponse {
}
export type AttributeNameType = string;
export type AttributeValueType = string | redacted.Redacted<string>;
export interface AttributeType {
    Name: string;
    Value?: string | redacted.Redacted<string> | undefined;
}
export type AttributeListType = AttributeType[];
export type PasswordType = string | redacted.Redacted<string>;
export type ForceAliasCreation = boolean;
export type MessageActionType = "RESEND" | "SUPPRESS" | (string & {});
export type DeliveryMediumType = "SMS" | "EMAIL" | (string & {});
export type DeliveryMediumListType = DeliveryMediumType[];
export interface AdminCreateUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributes?: AttributeType[] | undefined;
    ValidationData?: AttributeType[] | undefined;
    TemporaryPassword?: string | redacted.Redacted<string> | undefined;
    ForceAliasCreation?: boolean | undefined;
    MessageAction?: MessageActionType | undefined;
    DesiredDeliveryMediums?: DeliveryMediumType[] | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type UserStatusType = "UNCONFIRMED" | "CONFIRMED" | "ARCHIVED" | "COMPROMISED" | "UNKNOWN" | "RESET_REQUIRED" | "FORCE_CHANGE_PASSWORD" | "EXTERNAL_PROVIDER" | (string & {});
export interface MFAOptionType {
    DeliveryMedium?: DeliveryMediumType | undefined;
    AttributeName?: string | undefined;
}
export type MFAOptionListType = MFAOptionType[];
export interface UserType {
    Username?: string | redacted.Redacted<string> | undefined;
    Attributes?: AttributeType[] | undefined;
    UserCreateDate?: Date | undefined;
    UserLastModifiedDate?: Date | undefined;
    Enabled?: boolean | undefined;
    UserStatus?: UserStatusType | undefined;
    MFAOptions?: MFAOptionType[] | undefined;
}
export interface AdminCreateUserResponse {
    User?: UserType | undefined;
}
export interface AdminDeleteSoftwareTokenRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface AdminDeleteSoftwareTokenResponse {
}
export interface AdminDeleteUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface AdminDeleteUserResponse {
}
export type AttributeNameListType = string[];
export interface AdminDeleteUserAttributesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributeNames: string[];
}
export interface AdminDeleteUserAttributesResponse {
}
export type ProviderNameType = string;
export interface ProviderUserIdentifierType {
    ProviderName?: string | undefined;
    ProviderAttributeName?: string | undefined;
    ProviderAttributeValue?: string | undefined;
}
export interface AdminDisableProviderForUserRequest {
    UserPoolId: string;
    User: ProviderUserIdentifierType;
}
export interface AdminDisableProviderForUserResponse {
}
export interface AdminDisableUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface AdminDisableUserResponse {
}
export interface AdminEnableUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface AdminEnableUserResponse {
}
export type DeviceKeyType = string;
export interface AdminForgetDeviceRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    DeviceKey: string;
}
export interface AdminForgetDeviceResponse {
}
export interface AdminGetDeviceRequest {
    DeviceKey: string;
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface DeviceType {
    DeviceKey?: string | undefined;
    DeviceAttributes?: AttributeType[] | undefined;
    DeviceCreateDate?: Date | undefined;
    DeviceLastModifiedDate?: Date | undefined;
    DeviceLastAuthenticatedDate?: Date | undefined;
}
export interface AdminGetDeviceResponse {
    Device: DeviceType;
}
export interface AdminGetUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export type UserMFASettingListType = string[];
export interface AdminGetUserResponse {
    Username: string | redacted.Redacted<string>;
    UserAttributes?: AttributeType[] | undefined;
    UserCreateDate?: Date | undefined;
    UserLastModifiedDate?: Date | undefined;
    Enabled?: boolean | undefined;
    UserStatus?: UserStatusType | undefined;
    MFAOptions?: MFAOptionType[] | undefined;
    PreferredMfaSetting?: string | undefined;
    UserMFASettingList?: string[] | undefined;
}
export interface AdminGetUserAuthFactorsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export type AuthFactorType = "PASSWORD" | "EMAIL_OTP" | "SMS_OTP" | "WEB_AUTHN" | "SOFTWARE_TOKEN" | (string & {});
export type ConfiguredUserAuthFactorsListType = AuthFactorType[];
export interface AdminGetUserAuthFactorsResponse {
    Username: string | redacted.Redacted<string>;
    PreferredMfaSetting?: string | undefined;
    UserMFASettingList?: string[] | undefined;
    ConfiguredUserAuthFactors?: AuthFactorType[] | undefined;
}
export type AuthFlowType = "USER_SRP_AUTH" | "REFRESH_TOKEN_AUTH" | "REFRESH_TOKEN" | "CUSTOM_AUTH" | "ADMIN_NO_SRP_AUTH" | "USER_PASSWORD_AUTH" | "ADMIN_USER_PASSWORD_AUTH" | "USER_AUTH" | (string & {});
export type AuthParametersType = {
    [key: string]: string | undefined;
};
export interface AnalyticsMetadataType {
    AnalyticsEndpointId?: string | undefined;
}
export interface HttpHeader {
    headerName?: string | undefined;
    headerValue?: string | undefined;
}
export type HttpHeaderList = HttpHeader[];
export interface ContextDataType {
    IpAddress: string;
    ServerName: string;
    ServerPath: string;
    HttpHeaders: HttpHeader[];
    EncodedData?: string | undefined;
}
export type SessionType = string | redacted.Redacted<string>;
export interface AdminInitiateAuthRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    AuthFlow: AuthFlowType;
    AuthParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    ContextData?: ContextDataType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export type ChallengeNameType = "SMS_MFA" | "EMAIL_OTP" | "SOFTWARE_TOKEN_MFA" | "SELECT_MFA_TYPE" | "MFA_SETUP" | "PASSWORD_VERIFIER" | "CUSTOM_CHALLENGE" | "SELECT_CHALLENGE" | "DEVICE_SRP_AUTH" | "DEVICE_PASSWORD_VERIFIER" | "ADMIN_NO_SRP_AUTH" | "NEW_PASSWORD_REQUIRED" | "SMS_OTP" | "PASSWORD" | "WEB_AUTHN" | "PASSWORD_SRP" | (string & {});
export type ChallengeParametersType = {
    [key: string]: string | undefined;
};
export type TokenModelType = string | redacted.Redacted<string>;
export type IntegerType = number;
export interface NewDeviceMetadataType {
    DeviceKey?: string | undefined;
    DeviceGroupKey?: string | undefined;
}
export interface AuthenticationResultType {
    AccessToken?: string | redacted.Redacted<string> | undefined;
    ExpiresIn?: number | undefined;
    TokenType?: string | undefined;
    RefreshToken?: string | redacted.Redacted<string> | undefined;
    IdToken?: string | redacted.Redacted<string> | undefined;
    NewDeviceMetadata?: NewDeviceMetadataType | undefined;
}
export type AvailableChallengeListType = ChallengeNameType[];
export interface AdminInitiateAuthResponse {
    ChallengeName?: ChallengeNameType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AuthenticationResult?: AuthenticationResultType | undefined;
    AvailableChallenges?: ChallengeNameType[] | undefined;
}
export interface AdminLinkProviderForUserRequest {
    UserPoolId: string;
    DestinationUser: ProviderUserIdentifierType;
    SourceUser: ProviderUserIdentifierType;
}
export interface AdminLinkProviderForUserResponse {
}
export type QueryLimitType = number;
export type SearchPaginationTokenType = string;
export interface AdminListDevicesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    Limit?: number | undefined;
    PaginationToken?: string | undefined;
}
export type DeviceListType = DeviceType[];
export interface AdminListDevicesResponse {
    Devices?: DeviceType[] | undefined;
    PaginationToken?: string | undefined;
}
export type PaginationKey = string;
export interface AdminListGroupsForUserRequest {
    Username: string | redacted.Redacted<string>;
    UserPoolId: string;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export type DescriptionType = string;
export type ArnType = string;
export type PrecedenceType = number;
export interface GroupType {
    GroupName?: string | undefined;
    UserPoolId?: string | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    Precedence?: number | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
}
export type GroupListType = GroupType[];
export interface AdminListGroupsForUserResponse {
    Groups?: GroupType[] | undefined;
    NextToken?: string | undefined;
}
export interface AdminListUserAuthEventsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type EventType = "SignIn" | "SignUp" | "ForgotPassword" | "PasswordChange" | "ResendCode" | (string & {});
export type EventResponseType = "Pass" | "Fail" | "InProgress" | (string & {});
export type RiskDecisionType = "NoRisk" | "AccountTakeover" | "Block" | (string & {});
export type RiskLevelType = "Low" | "Medium" | "High" | (string & {});
export type WrappedBooleanType = boolean;
export interface EventRiskType {
    RiskDecision?: RiskDecisionType | undefined;
    RiskLevel?: RiskLevelType | undefined;
    CompromisedCredentialsDetected?: boolean | undefined;
}
export type ChallengeName = "Password" | "Mfa" | (string & {});
export type ChallengeResponse = "Success" | "Failure" | (string & {});
export interface ChallengeResponseType {
    ChallengeName?: ChallengeName | undefined;
    ChallengeResponse?: ChallengeResponse | undefined;
}
export type ChallengeResponseListType = ChallengeResponseType[];
export interface EventContextDataType {
    IpAddress?: string | undefined;
    DeviceName?: string | undefined;
    Timezone?: string | undefined;
    City?: string | undefined;
    Country?: string | undefined;
}
export type FeedbackValueType = "Valid" | "Invalid" | (string & {});
export interface EventFeedbackType {
    FeedbackValue: FeedbackValueType;
    Provider: string;
    FeedbackDate?: Date | undefined;
}
export interface AuthEventType {
    EventId?: string | undefined;
    EventType?: EventType | undefined;
    CreationDate?: Date | undefined;
    EventResponse?: EventResponseType | undefined;
    EventRisk?: EventRiskType | undefined;
    ChallengeResponses?: ChallengeResponseType[] | undefined;
    EventContextData?: EventContextDataType | undefined;
    EventFeedback?: EventFeedbackType | undefined;
}
export type AuthEventsType = AuthEventType[];
export interface AdminListUserAuthEventsResponse {
    AuthEvents?: AuthEventType[] | undefined;
    NextToken?: string | undefined;
}
export interface AdminListUserSessionsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    NextToken?: string | undefined;
}
export type SessionIdType = string;
export type SessionTypeType = "TOKEN" | "SSO" | (string & {});
export type SessionDeviceType = string;
export type SessionIpAddressType = string | redacted.Redacted<string>;
export type SessionLocationCityType = string;
export type SessionLocationCountryType = string;
export interface SessionLocationType {
    City?: string | undefined;
    Country?: string | undefined;
}
export interface SessionDescriptionType {
    SessionId?: string | undefined;
    SessionType?: SessionTypeType | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    CreateDate?: Date | undefined;
    LastActiveDate?: Date | undefined;
    DeviceType?: string | undefined;
    LastIPAddress?: string | redacted.Redacted<string> | undefined;
    LastLocation?: SessionLocationType | undefined;
    OriginSessionId?: string | undefined;
    IsCurrentSession?: boolean | undefined;
}
export type SessionsListType = SessionDescriptionType[];
export interface AdminListUserSessionsResponse {
    Sessions?: SessionDescriptionType[] | undefined;
    NextToken?: string | undefined;
}
export interface AdminRemoveUserFromGroupRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    GroupName: string;
}
export interface AdminRemoveUserFromGroupResponse {
}
export interface AdminResetUserPasswordRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AdminResetUserPasswordResponse {
}
export type ChallengeResponsesType = {
    [key: string]: string | undefined;
};
export interface AdminRespondToAuthChallengeRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ChallengeName: ChallengeNameType;
    ChallengeResponses?: {
        [key: string]: string | undefined;
    } | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    ContextData?: ContextDataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AdminRespondToAuthChallengeResponse {
    ChallengeName?: ChallengeNameType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AuthenticationResult?: AuthenticationResultType | undefined;
    AvailableChallenges?: ChallengeNameType[] | undefined;
}
export type RevokeAssociatedSessionsType = "NONE" | "LINKED" | (string & {});
export interface AdminRevokeUserSessionRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    SessionId: string;
    RevokeAssociatedSessions?: RevokeAssociatedSessionsType | undefined;
}
export interface AdminRevokeUserSessionResponse {
}
export interface SMSMfaSettingsType {
    Enabled?: boolean | undefined;
    PreferredMfa?: boolean | undefined;
}
export interface SoftwareTokenMfaSettingsType {
    Enabled?: boolean | undefined;
    PreferredMfa?: boolean | undefined;
}
export interface EmailMfaSettingsType {
    Enabled?: boolean | undefined;
    PreferredMfa?: boolean | undefined;
}
export interface WebAuthnMfaSettingsType {
    Enabled?: boolean | undefined;
}
export interface AdminSetUserMFAPreferenceRequest {
    SMSMfaSettings?: SMSMfaSettingsType | undefined;
    SoftwareTokenMfaSettings?: SoftwareTokenMfaSettingsType | undefined;
    EmailMfaSettings?: EmailMfaSettingsType | undefined;
    WebAuthnMfaSettings?: WebAuthnMfaSettingsType | undefined;
    Username: string | redacted.Redacted<string>;
    UserPoolId: string;
}
export interface AdminSetUserMFAPreferenceResponse {
}
export interface AdminSetUserPasswordRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    Password: string | redacted.Redacted<string>;
    Permanent?: boolean | undefined;
}
export interface AdminSetUserPasswordResponse {
}
export interface AdminSetUserSettingsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    MFAOptions: MFAOptionType[];
}
export interface AdminSetUserSettingsResponse {
}
export type EventIdType = string;
export interface AdminUpdateAuthEventFeedbackRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    EventId: string;
    FeedbackValue: FeedbackValueType;
}
export interface AdminUpdateAuthEventFeedbackResponse {
}
export type DeviceRememberedStatusType = "remembered" | "not_remembered" | (string & {});
export interface AdminUpdateDeviceStatusRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceRememberedStatus?: DeviceRememberedStatusType | undefined;
}
export interface AdminUpdateDeviceStatusResponse {
}
export interface AdminUpdateUserAttributesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributes: AttributeType[];
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface AdminUpdateUserAttributesResponse {
}
export interface AdminUserGlobalSignOutRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export interface AdminUserGlobalSignOutResponse {
}
export interface AssociateSoftwareTokenRequest {
    AccessToken?: string | redacted.Redacted<string> | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export type SecretCodeType = string | redacted.Redacted<string>;
export interface AssociateSoftwareTokenResponse {
    SecretCode?: string | redacted.Redacted<string> | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface ChangePasswordRequest {
    PreviousPassword?: string | redacted.Redacted<string> | undefined;
    ProposedPassword: string | redacted.Redacted<string>;
    AccessToken: string | redacted.Redacted<string>;
}
export interface ChangePasswordResponse {
}
export type Document = unknown;
export interface CompleteWebAuthnRegistrationRequest {
    AccessToken: string | redacted.Redacted<string>;
    Credential: any;
}
export interface CompleteWebAuthnRegistrationResponse {
}
export interface DeviceSecretVerifierConfigType {
    PasswordVerifier?: string | undefined;
    Salt?: string | undefined;
}
export type DeviceNameType = string;
export interface ConfirmDeviceRequest {
    AccessToken: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceSecretVerifierConfig?: DeviceSecretVerifierConfigType | undefined;
    DeviceName?: string | undefined;
}
export interface ConfirmDeviceResponse {
    UserConfirmationNecessary?: boolean | undefined;
}
export type SecretHashType = string | redacted.Redacted<string>;
export type ConfirmationCodeType = string;
export interface UserContextDataType {
    IpAddress?: string | undefined;
    EncodedData?: string | undefined;
}
export interface ConfirmForgotPasswordRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string> | undefined;
    Username: string | redacted.Redacted<string>;
    ConfirmationCode: string;
    Password: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    UserContextData?: UserContextDataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ConfirmForgotPasswordResponse {
}
export interface ConfirmSignUpRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string> | undefined;
    Username: string | redacted.Redacted<string>;
    ConfirmationCode: string;
    ForceAliasCreation?: boolean | undefined;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    UserContextData?: UserContextDataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface ConfirmSignUpResponse {
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface CreateGroupRequest {
    GroupName: string;
    UserPoolId: string;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    Precedence?: number | undefined;
}
export interface CreateGroupResponse {
    Group?: GroupType | undefined;
}
export type ProviderNameTypeV2 = string;
export type IdentityProviderTypeType = "SAML" | "Facebook" | "Google" | "LoginWithAmazon" | "SignInWithApple" | "OIDC" | (string & {});
export type ProviderDetailsType = {
    [key: string]: string | undefined;
};
export type AttributeMappingKeyType = string;
export type AttributeMappingType = {
    [key: string]: string | undefined;
};
export type IdpIdentifierType = string;
export type IdpIdentifiersListType = string[];
export type AcrMappingKeyType = string;
export type AcrValueType = string;
export type AcrMappingType = {
    [key: string]: string | undefined;
};
export interface CreateIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
    ProviderType: IdentityProviderTypeType;
    ProviderDetails: {
        [key: string]: string | undefined;
    };
    AttributeMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    IdpIdentifiers?: string[] | undefined;
    AcrMapping?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface IdentityProviderType {
    UserPoolId?: string | undefined;
    ProviderName?: string | undefined;
    ProviderType?: IdentityProviderTypeType | undefined;
    ProviderDetails?: {
        [key: string]: string | undefined;
    } | undefined;
    AttributeMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    IdpIdentifiers?: string[] | undefined;
    AcrMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
}
export interface CreateIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export type AssetCategoryType = "FAVICON_ICO" | "FAVICON_SVG" | "EMAIL_GRAPHIC" | "SMS_GRAPHIC" | "AUTH_APP_GRAPHIC" | "PASSWORD_GRAPHIC" | "PASSKEY_GRAPHIC" | "PAGE_HEADER_LOGO" | "PAGE_HEADER_BACKGROUND" | "PAGE_FOOTER_LOGO" | "PAGE_FOOTER_BACKGROUND" | "PAGE_BACKGROUND" | "FORM_BACKGROUND" | "FORM_LOGO" | "IDP_BUTTON_ICON" | (string & {});
export type ColorSchemeModeType = "LIGHT" | "DARK" | "DYNAMIC" | (string & {});
export type AssetExtensionType = "ICO" | "JPEG" | "PNG" | "SVG" | "WEBP" | (string & {});
export type AssetBytesType = Uint8Array;
export type ResourceIdType = string;
export interface AssetType {
    Category: AssetCategoryType;
    ColorMode: ColorSchemeModeType;
    Extension: AssetExtensionType;
    Bytes?: Uint8Array | undefined;
    ResourceId?: string | undefined;
}
export type AssetListType = AssetType[];
export interface CreateManagedLoginBrandingRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    UseCognitoProvidedValues?: boolean | undefined;
    Settings?: any | undefined;
    Assets?: AssetType[] | undefined;
}
export type ManagedLoginBrandingIdType = string;
export interface ManagedLoginBrandingType {
    ManagedLoginBrandingId?: string | undefined;
    UserPoolId?: string | undefined;
    UseCognitoProvidedValues?: boolean | undefined;
    Settings?: any | undefined;
    Assets?: AssetType[] | undefined;
    CreationDate?: Date | undefined;
    LastModifiedDate?: Date | undefined;
}
export interface CreateManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType | undefined;
}
export type ResourceServerIdentifierType = string;
export type ResourceServerNameType = string;
export type ResourceServerScopeNameType = string;
export type ResourceServerScopeDescriptionType = string;
export interface ResourceServerScopeType {
    ScopeName: string;
    ScopeDescription: string;
}
export type ResourceServerScopeListType = ResourceServerScopeType[];
export interface CreateResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
    Name: string;
    Scopes?: ResourceServerScopeType[] | undefined;
}
export type ResourceServerManagedByType = "COGNITO" | (string & {});
export interface ResourceServerType {
    UserPoolId?: string | undefined;
    Identifier?: string | undefined;
    Name?: string | undefined;
    Scopes?: ResourceServerScopeType[] | undefined;
    ManagedBy?: ResourceServerManagedByType | undefined;
}
export interface CreateResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export type TermsNameType = string;
export type TermsSourceType = "LINK" | (string & {});
export type TermsEnforcementType = "NONE" | (string & {});
export type LanguageIdType = string;
export type LinkUrlType = string;
export type LinksType = {
    [key: string]: string | undefined;
};
export interface CreateTermsRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    TermsName: string;
    TermsSource: TermsSourceType;
    Enforcement: TermsEnforcementType;
    Links?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TermsIdType = string;
export interface TermsType {
    TermsId: string;
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    TermsName: string;
    TermsSource: TermsSourceType;
    Enforcement: TermsEnforcementType;
    Links: {
        [key: string]: string | undefined;
    };
    CreationDate: Date;
    LastModifiedDate: Date;
}
export interface CreateTermsResponse {
    Terms?: TermsType | undefined;
}
export type UserImportJobNameType = string;
export type PasswordHashingAlgorithmType = "BCRYPT" | "SCRYPT" | "ARGON2ID" | "PBKDF2_SHA256" | (string & {});
export interface CreateUserImportJobRequest {
    JobName: string;
    UserPoolId: string;
    CloudWatchLogsRoleArn: string;
    PasswordHashingAlgorithm?: PasswordHashingAlgorithmType | undefined;
}
export type UserImportJobIdType = string;
export type PreSignedUrlType = string;
export type UserImportJobStatusType = "Created" | "Pending" | "InProgress" | "Stopping" | "Expired" | "Stopped" | "Failed" | "Succeeded" | (string & {});
export type LongType = number;
export type CompletionMessageType = string;
export interface UserImportJobType {
    JobName?: string | undefined;
    JobId?: string | undefined;
    UserPoolId?: string | undefined;
    PreSignedUrl?: string | undefined;
    CreationDate?: Date | undefined;
    StartDate?: Date | undefined;
    CompletionDate?: Date | undefined;
    Status?: UserImportJobStatusType | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    ImportedUsers?: number | undefined;
    SkippedUsers?: number | undefined;
    FailedUsers?: number | undefined;
    CompletionMessage?: string | undefined;
    PasswordHashingAlgorithm?: PasswordHashingAlgorithmType | undefined;
}
export interface CreateUserImportJobResponse {
    UserImportJob?: UserImportJobType | undefined;
}
export type UserPoolNameType = string;
export type PasswordPolicyMinLengthType = number;
export type PasswordHistorySizeType = number;
export type TemporaryPasswordValidityDaysType = number;
export interface PasswordPolicyType {
    MinimumLength?: number | undefined;
    RequireUppercase?: boolean | undefined;
    RequireLowercase?: boolean | undefined;
    RequireNumbers?: boolean | undefined;
    RequireSymbols?: boolean | undefined;
    PasswordHistorySize?: number | undefined;
    TemporaryPasswordValidityDays?: number | undefined;
}
export type AllowedFirstAuthFactorsListType = AuthFactorType[];
export interface SignInPolicyType {
    AllowedFirstAuthFactors?: AuthFactorType[] | undefined;
}
export interface UserPoolPolicyType {
    PasswordPolicy?: PasswordPolicyType | undefined;
    SignInPolicy?: SignInPolicyType | undefined;
}
export type DeletionProtectionType = "ACTIVE" | "INACTIVE" | (string & {});
export type PreTokenGenerationLambdaVersionType = "V1_0" | "V2_0" | "V3_0" | (string & {});
export interface PreTokenGenerationVersionConfigType {
    LambdaVersion: PreTokenGenerationLambdaVersionType;
    LambdaArn: string;
}
export type CustomSMSSenderLambdaVersionType = "V1_0" | (string & {});
export interface CustomSMSLambdaVersionConfigType {
    LambdaVersion: CustomSMSSenderLambdaVersionType;
    LambdaArn: string;
}
export type CustomEmailSenderLambdaVersionType = "V1_0" | (string & {});
export interface CustomEmailLambdaVersionConfigType {
    LambdaVersion: CustomEmailSenderLambdaVersionType;
    LambdaArn: string;
}
export type InboundFederationLambdaVersionType = "V1_0" | (string & {});
export interface InboundFederationLambdaType {
    LambdaVersion: InboundFederationLambdaVersionType;
    LambdaArn: string;
}
export interface LambdaConfigType {
    PreSignUp?: string | undefined;
    CustomMessage?: string | undefined;
    PostConfirmation?: string | undefined;
    PreAuthentication?: string | undefined;
    PostAuthentication?: string | undefined;
    DefineAuthChallenge?: string | undefined;
    CreateAuthChallenge?: string | undefined;
    VerifyAuthChallengeResponse?: string | undefined;
    PreTokenGeneration?: string | undefined;
    UserMigration?: string | undefined;
    PreTokenGenerationConfig?: PreTokenGenerationVersionConfigType | undefined;
    CustomSMSSender?: CustomSMSLambdaVersionConfigType | undefined;
    CustomEmailSender?: CustomEmailLambdaVersionConfigType | undefined;
    KMSKeyID?: string | undefined;
    InboundFederation?: InboundFederationLambdaType | undefined;
}
export type VerifiedAttributeType = "phone_number" | "email" | (string & {});
export type VerifiedAttributesListType = VerifiedAttributeType[];
export type AliasAttributeType = "phone_number" | "email" | "preferred_username" | (string & {});
export type AliasAttributesListType = AliasAttributeType[];
export type UsernameAttributeType = "phone_number" | "email" | (string & {});
export type UsernameAttributesListType = UsernameAttributeType[];
export type SmsVerificationMessageType = string;
export type EmailVerificationMessageType = string;
export type EmailVerificationSubjectType = string;
export type EmailVerificationMessageByLinkType = string;
export type EmailVerificationSubjectByLinkType = string;
export type DefaultEmailOptionType = "CONFIRM_WITH_LINK" | "CONFIRM_WITH_CODE" | (string & {});
export interface VerificationMessageTemplateType {
    SmsMessage?: string | undefined;
    EmailMessage?: string | undefined;
    EmailSubject?: string | undefined;
    EmailMessageByLink?: string | undefined;
    EmailSubjectByLink?: string | undefined;
    DefaultEmailOption?: DefaultEmailOptionType | undefined;
}
export type UserPoolMfaType = "OFF" | "ON" | "OPTIONAL" | (string & {});
export type AttributesRequireVerificationBeforeUpdateType = VerifiedAttributeType[];
export interface UserAttributeUpdateSettingsType {
    AttributesRequireVerificationBeforeUpdate?: VerifiedAttributeType[] | undefined;
}
export interface DeviceConfigurationType {
    ChallengeRequiredOnNewDevice?: boolean | undefined;
    DeviceOnlyRememberedOnUserPrompt?: boolean | undefined;
}
export type EmailAddressType = string;
export type EmailSendingAccountType = "COGNITO_DEFAULT" | "DEVELOPER" | (string & {});
export type SESConfigurationSet = string;
export interface EmailConfigurationType {
    SourceArn?: string | undefined;
    ReplyToEmailAddress?: string | undefined;
    EmailSendingAccount?: EmailSendingAccountType | undefined;
    From?: string | undefined;
    ConfigurationSet?: string | undefined;
}
export type OptionalArnType = string;
export type RegionCodeType = string;
export interface EumsSmsConfigurationType {
    CallerArn: string;
    ExternalId?: string | undefined;
    OriginationIdentity?: string | undefined;
    ConfigurationSetName?: string | undefined;
    InEntityId?: string | undefined;
    InTemplateId?: string | undefined;
    Region?: string | undefined;
}
export interface SmsConfigurationType {
    SnsCallerArn?: string | undefined;
    ExternalId?: string | undefined;
    SnsRegion?: string | undefined;
    EumsSms?: EumsSmsConfigurationType | undefined;
}
export type TagKeysType = string;
export type TagValueType = string;
export type UserPoolTagsType = {
    [key: string]: string | undefined;
};
export type AdminCreateUserUnusedAccountValidityDaysType = number;
export type SmsInviteMessageType = string;
export type EmailInviteMessageType = string;
export interface MessageTemplateType {
    SMSMessage?: string | undefined;
    EmailMessage?: string | undefined;
    EmailSubject?: string | undefined;
}
export interface AdminCreateUserConfigType {
    AllowAdminCreateUserOnly?: boolean | undefined;
    UnusedAccountValidityDays?: number | undefined;
    InviteMessageTemplate?: MessageTemplateType | undefined;
}
export type SchemaAttributesListType = SchemaAttributeType[];
export type AdvancedSecurityModeType = "OFF" | "AUDIT" | "ENFORCED" | (string & {});
export type AdvancedSecurityEnabledModeType = "AUDIT" | "ENFORCED" | (string & {});
export interface AdvancedSecurityAdditionalFlowsType {
    CustomAuthMode?: AdvancedSecurityEnabledModeType | undefined;
}
export interface UserPoolAddOnsType {
    AdvancedSecurityMode: AdvancedSecurityModeType;
    AdvancedSecurityAdditionalFlows?: AdvancedSecurityAdditionalFlowsType | undefined;
}
export type StatusType = "Enabled" | "Disabled" | (string & {});
export type OAuthFlowType = "code" | "implicit" | "client_credentials" | (string & {});
export type OAuthFlowsType = OAuthFlowType[];
export type ScopeType = string;
export type ScopeListType = string[];
export interface DcrConfigurationType {
    EnableStatus?: StatusType | undefined;
    OpenDcrEnabled?: boolean | undefined;
    AuthenticatedGrantTypes?: OAuthFlowType[] | undefined;
    OpenDcrGrantTypes?: OAuthFlowType[] | undefined;
    AllowedScopes?: string[] | undefined;
}
export interface UsernameConfigurationType {
    CaseSensitive: boolean;
}
export type PriorityType = number;
export type RecoveryOptionNameType = "verified_email" | "verified_phone_number" | "admin_only" | (string & {});
export interface RecoveryOptionType {
    Priority: number;
    Name: RecoveryOptionNameType;
}
export type RecoveryMechanismsType = RecoveryOptionType[];
export interface AccountRecoverySettingType {
    RecoveryMechanisms?: RecoveryOptionType[] | undefined;
}
export type UserPoolTierType = "LITE" | "ESSENTIALS" | "PLUS" | (string & {});
export type EncryptionKeyType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export type EncryptionKeyArnType = string;
export interface KeyConfigurationType {
    KeyType?: EncryptionKeyType | undefined;
    KmsKeyArn?: string | undefined;
}
export type IssuerType = "ORIGINAL" | "UPDATED" | (string & {});
export interface IssuerConfigurationType {
    Type?: IssuerType | undefined;
}
export type AcrLevelKeyType = string;
export interface AcrLevelConfigType {
    AcrValue: string;
}
export type AcrConfigurationType = {
    [key: string]: AcrLevelConfigType | undefined;
};
export interface CreateUserPoolRequest {
    PoolName: string;
    Policies?: UserPoolPolicyType | undefined;
    DeletionProtection?: DeletionProtectionType | undefined;
    LambdaConfig?: LambdaConfigType | undefined;
    AutoVerifiedAttributes?: VerifiedAttributeType[] | undefined;
    AliasAttributes?: AliasAttributeType[] | undefined;
    UsernameAttributes?: UsernameAttributeType[] | undefined;
    SmsVerificationMessage?: string | undefined;
    EmailVerificationMessage?: string | undefined;
    EmailVerificationSubject?: string | undefined;
    VerificationMessageTemplate?: VerificationMessageTemplateType | undefined;
    SmsAuthenticationMessage?: string | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType | undefined;
    DeviceConfiguration?: DeviceConfigurationType | undefined;
    EmailConfiguration?: EmailConfigurationType | undefined;
    SmsConfiguration?: SmsConfigurationType | undefined;
    UserPoolTags?: {
        [key: string]: string | undefined;
    } | undefined;
    AdminCreateUserConfig?: AdminCreateUserConfigType | undefined;
    Schema?: SchemaAttributeType[] | undefined;
    UserPoolAddOns?: UserPoolAddOnsType | undefined;
    DcrConfiguration?: DcrConfigurationType | undefined;
    UsernameConfiguration?: UsernameConfigurationType | undefined;
    AccountRecoverySetting?: AccountRecoverySettingType | undefined;
    UserPoolTier?: UserPoolTierType | undefined;
    KeyConfiguration?: KeyConfigurationType | undefined;
    IssuerConfiguration?: IssuerConfigurationType | undefined;
    AcrConfiguration?: {
        [key: string]: AcrLevelConfigType | undefined;
    } | undefined;
}
export type DomainType = string;
export interface UserPoolType {
    Id?: string | undefined;
    Name?: string | undefined;
    Policies?: UserPoolPolicyType | undefined;
    DeletionProtection?: DeletionProtectionType | undefined;
    LambdaConfig?: LambdaConfigType | undefined;
    Status?: StatusType | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
    SchemaAttributes?: SchemaAttributeType[] | undefined;
    AutoVerifiedAttributes?: VerifiedAttributeType[] | undefined;
    AliasAttributes?: AliasAttributeType[] | undefined;
    UsernameAttributes?: UsernameAttributeType[] | undefined;
    SmsVerificationMessage?: string | undefined;
    EmailVerificationMessage?: string | undefined;
    EmailVerificationSubject?: string | undefined;
    VerificationMessageTemplate?: VerificationMessageTemplateType | undefined;
    SmsAuthenticationMessage?: string | undefined;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    DeviceConfiguration?: DeviceConfigurationType | undefined;
    EstimatedNumberOfUsers?: number | undefined;
    EmailConfiguration?: EmailConfigurationType | undefined;
    SmsConfiguration?: SmsConfigurationType | undefined;
    UserPoolTags?: {
        [key: string]: string | undefined;
    } | undefined;
    SmsConfigurationFailure?: string | undefined;
    EmailConfigurationFailure?: string | undefined;
    Domain?: string | undefined;
    CustomDomain?: string | undefined;
    AdminCreateUserConfig?: AdminCreateUserConfigType | undefined;
    UserPoolAddOns?: UserPoolAddOnsType | undefined;
    DcrConfiguration?: DcrConfigurationType | undefined;
    UsernameConfiguration?: UsernameConfigurationType | undefined;
    Arn?: string | undefined;
    AccountRecoverySetting?: AccountRecoverySettingType | undefined;
    UserPoolTier?: UserPoolTierType | undefined;
    KeyConfiguration?: KeyConfigurationType | undefined;
    IssuerConfiguration?: IssuerConfigurationType | undefined;
    AcrConfiguration?: {
        [key: string]: AcrLevelConfigType | undefined;
    } | undefined;
}
export interface CreateUserPoolResponse {
    UserPool?: UserPoolType | undefined;
}
export type ClientNameType = string;
export type GenerateSecret = boolean;
export type RefreshTokenValidityType = number;
export type AccessTokenValidityType = number;
export type IdTokenValidityType = number;
export type TimeUnitsType = "seconds" | "minutes" | "hours" | "days" | (string & {});
export interface TokenValidityUnitsType {
    AccessToken?: TimeUnitsType | undefined;
    IdToken?: TimeUnitsType | undefined;
    RefreshToken?: TimeUnitsType | undefined;
}
export type ClientPermissionType = string;
export type ClientPermissionListType = string[];
export type ExplicitAuthFlowsType = "ADMIN_NO_SRP_AUTH" | "CUSTOM_AUTH_FLOW_ONLY" | "USER_PASSWORD_AUTH" | "ALLOW_ADMIN_USER_PASSWORD_AUTH" | "ALLOW_CUSTOM_AUTH" | "ALLOW_USER_PASSWORD_AUTH" | "ALLOW_USER_SRP_AUTH" | "ALLOW_REFRESH_TOKEN_AUTH" | "ALLOW_USER_AUTH" | (string & {});
export type ExplicitAuthFlowsListType = ExplicitAuthFlowsType[];
export type SupportedIdentityProvidersListType = string[];
export type RedirectUrlType = string;
export type CallbackURLsListType = string[];
export type LogoutURLsListType = string[];
export type HexStringType = string;
export interface AnalyticsConfigurationType {
    ApplicationId?: string | undefined;
    ApplicationArn?: string | undefined;
    RoleArn?: string | undefined;
    ExternalId?: string | undefined;
    UserDataShared?: boolean | undefined;
}
export type PreventUserExistenceErrorTypes = "LEGACY" | "ENABLED" | (string & {});
export type AuthSessionValidityType = number;
export type FeatureType = "ENABLED" | "DISABLED" | (string & {});
export type RetryGracePeriodSecondsType = number;
export interface RefreshTokenRotationType {
    Feature: FeatureType;
    RetryGracePeriodSeconds?: number | undefined;
}
export interface CreateUserPoolClientRequest {
    UserPoolId: string;
    ClientName: string;
    GenerateSecret?: boolean | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    RefreshTokenValidity?: number | undefined;
    AccessTokenValidity?: number | undefined;
    IdTokenValidity?: number | undefined;
    TokenValidityUnits?: TokenValidityUnitsType | undefined;
    ReadAttributes?: string[] | undefined;
    WriteAttributes?: string[] | undefined;
    ExplicitAuthFlows?: ExplicitAuthFlowsType[] | undefined;
    SupportedIdentityProviders?: string[] | undefined;
    CallbackURLs?: string[] | undefined;
    LogoutURLs?: string[] | undefined;
    DefaultRedirectURI?: string | undefined;
    AllowedOAuthFlows?: OAuthFlowType[] | undefined;
    AllowedOAuthScopes?: string[] | undefined;
    AllowedOAuthFlowsUserPoolClient?: boolean | undefined;
    AnalyticsConfiguration?: AnalyticsConfigurationType | undefined;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes | undefined;
    EnableTokenRevocation?: boolean | undefined;
    EnablePropagateAdditionalUserContextData?: boolean | undefined;
    AuthSessionValidity?: number | undefined;
    RefreshTokenRotation?: RefreshTokenRotationType | undefined;
}
export type ClientTypeType = "REGULAR" | "DCR" | (string & {});
export interface UserPoolClientType {
    UserPoolId?: string | undefined;
    ClientName?: string | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
    RefreshTokenValidity?: number | undefined;
    AccessTokenValidity?: number | undefined;
    IdTokenValidity?: number | undefined;
    TokenValidityUnits?: TokenValidityUnitsType | undefined;
    ReadAttributes?: string[] | undefined;
    WriteAttributes?: string[] | undefined;
    ExplicitAuthFlows?: ExplicitAuthFlowsType[] | undefined;
    SupportedIdentityProviders?: string[] | undefined;
    CallbackURLs?: string[] | undefined;
    LogoutURLs?: string[] | undefined;
    DefaultRedirectURI?: string | undefined;
    AllowedOAuthFlows?: OAuthFlowType[] | undefined;
    AllowedOAuthScopes?: string[] | undefined;
    AllowedOAuthFlowsUserPoolClient?: boolean | undefined;
    AnalyticsConfiguration?: AnalyticsConfigurationType | undefined;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes | undefined;
    EnableTokenRevocation?: boolean | undefined;
    EnablePropagateAdditionalUserContextData?: boolean | undefined;
    AuthSessionValidity?: number | undefined;
    RefreshTokenRotation?: RefreshTokenRotationType | undefined;
    ClientType?: ClientTypeType | undefined;
}
export interface CreateUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType | undefined;
}
export type WrappedIntegerType = number;
export type SecurityPolicyType = "TLS_V1" | "TLS_V1_2_2021" | "TLS_V1_3_2025" | (string & {});
export interface CustomDomainConfigType {
    CertificateArn: string;
    SecurityPolicy?: SecurityPolicyType | undefined;
}
export type RegionNameType = string;
export type HealthCheckIdType = string;
export interface FailoverType {
    SecondaryRegion: string;
    PrimaryRoute53HealthCheckId: string;
}
export interface RoutingType {
    Failover?: FailoverType | undefined;
}
export interface CreateUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
    ManagedLoginVersion?: number | undefined;
    CustomDomainConfig?: CustomDomainConfigType | undefined;
    Routing?: RoutingType | undefined;
}
export interface CreateUserPoolDomainResponse {
    ManagedLoginVersion?: number | undefined;
    CloudFrontDomain?: string | undefined;
    Routing?: RoutingType | undefined;
}
export interface CreateUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
    UserPoolTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ReplicaStatusType = "CREATING" | "ACTIVE" | "INACTIVE" | "DELETING" | (string & {});
export type ReplicaRoleType = "PRIMARY" | "SECONDARY" | (string & {});
export interface UserPoolReplicaType {
    RegionName?: string | undefined;
    Status?: ReplicaStatusType | undefined;
    Role?: ReplicaRoleType | undefined;
    UserPoolArn?: string | undefined;
}
export interface CreateUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType | undefined;
}
export interface DeleteGroupRequest {
    GroupName: string;
    UserPoolId: string;
}
export interface DeleteGroupResponse {
}
export interface DeleteIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
}
export interface DeleteIdentityProviderResponse {
}
export interface DeleteManagedLoginBrandingRequest {
    ManagedLoginBrandingId: string;
    UserPoolId: string;
}
export interface DeleteManagedLoginBrandingResponse {
}
export interface DeleteResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
}
export interface DeleteResourceServerResponse {
}
export interface DeleteTermsRequest {
    TermsId: string;
    UserPoolId: string;
}
export interface DeleteTermsResponse {
}
export interface DeleteUserRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export interface DeleteUserResponse {
}
export interface DeleteUserAttributesRequest {
    UserAttributeNames: string[];
    AccessToken: string | redacted.Redacted<string>;
}
export interface DeleteUserAttributesResponse {
}
export interface DeleteUserPoolRequest {
    UserPoolId: string;
}
export interface DeleteUserPoolResponse {
}
export interface DeleteUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
}
export interface DeleteUserPoolClientResponse {
}
export interface DeleteUserPoolClientSecretRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientSecretId: string;
}
export interface DeleteUserPoolClientSecretResponse {
}
export interface DeleteUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
}
export interface DeleteUserPoolDomainResponse {
}
export interface DeleteUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
}
export interface DeleteUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType | undefined;
}
export interface DeleteWebAuthnCredentialRequest {
    AccessToken: string | redacted.Redacted<string>;
    CredentialId: string;
}
export interface DeleteWebAuthnCredentialResponse {
}
export interface DescribeIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
}
export interface DescribeIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export interface DescribeManagedLoginBrandingRequest {
    UserPoolId: string;
    ManagedLoginBrandingId: string;
    ReturnMergedResources?: boolean | undefined;
}
export interface DescribeManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType | undefined;
}
export interface DescribeManagedLoginBrandingByClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ReturnMergedResources?: boolean | undefined;
}
export interface DescribeManagedLoginBrandingByClientResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType | undefined;
}
export interface DescribeResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
}
export interface DescribeResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export interface DescribeRiskConfigurationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string> | undefined;
}
export type EventFilterType = "SIGN_IN" | "PASSWORD_CHANGE" | "SIGN_UP" | (string & {});
export type EventFiltersType = EventFilterType[];
export type CompromisedCredentialsEventActionType = "BLOCK" | "NO_ACTION" | (string & {});
export interface CompromisedCredentialsActionsType {
    EventAction: CompromisedCredentialsEventActionType;
}
export interface CompromisedCredentialsRiskConfigurationType {
    EventFilter?: EventFilterType[] | undefined;
    Actions: CompromisedCredentialsActionsType;
}
export type EmailNotificationSubjectType = string;
export type EmailNotificationBodyType = string;
export interface NotifyEmailType {
    Subject: string;
    HtmlBody?: string | undefined;
    TextBody?: string | undefined;
}
export interface NotifyConfigurationType {
    From?: string | undefined;
    ReplyTo?: string | undefined;
    SourceArn: string;
    BlockEmail?: NotifyEmailType | undefined;
    NoActionEmail?: NotifyEmailType | undefined;
    MfaEmail?: NotifyEmailType | undefined;
}
export type AccountTakeoverActionNotifyType = boolean;
export type AccountTakeoverEventActionType = "BLOCK" | "MFA_IF_CONFIGURED" | "MFA_REQUIRED" | "NO_ACTION" | (string & {});
export interface AccountTakeoverActionType {
    Notify: boolean;
    EventAction: AccountTakeoverEventActionType;
}
export interface AccountTakeoverActionsType {
    LowAction?: AccountTakeoverActionType | undefined;
    MediumAction?: AccountTakeoverActionType | undefined;
    HighAction?: AccountTakeoverActionType | undefined;
}
export interface AccountTakeoverRiskConfigurationType {
    NotifyConfiguration?: NotifyConfigurationType | undefined;
    Actions: AccountTakeoverActionsType;
}
export type BlockedIPRangeListType = string[];
export type SkippedIPRangeListType = string[];
export interface RiskExceptionConfigurationType {
    BlockedIPRangeList?: string[] | undefined;
    SkippedIPRangeList?: string[] | undefined;
}
export interface RiskConfigurationType {
    UserPoolId?: string | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    CompromisedCredentialsRiskConfiguration?: CompromisedCredentialsRiskConfigurationType | undefined;
    AccountTakeoverRiskConfiguration?: AccountTakeoverRiskConfigurationType | undefined;
    RiskExceptionConfiguration?: RiskExceptionConfigurationType | undefined;
    LastModifiedDate?: Date | undefined;
}
export interface DescribeRiskConfigurationResponse {
    RiskConfiguration: RiskConfigurationType;
}
export interface DescribeTermsRequest {
    TermsId: string;
    UserPoolId: string;
}
export interface DescribeTermsResponse {
    Terms?: TermsType | undefined;
}
export interface DescribeTermsByClientRequest {
    ClientId: string | redacted.Redacted<string>;
    UserPoolId: string;
    TermsName: string;
}
export interface DescribeTermsByClientResponse {
    Terms?: TermsType | undefined;
}
export interface DescribeUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export interface DescribeUserImportJobResponse {
    UserImportJob?: UserImportJobType | undefined;
}
export interface DescribeUserPoolRequest {
    UserPoolId: string;
}
export interface DescribeUserPoolResponse {
    UserPool?: UserPoolType | undefined;
}
export interface DescribeUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
}
export interface DescribeUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType | undefined;
}
export interface DescribeUserPoolDomainRequest {
    Domain: string;
}
export type AWSAccountIdType = string;
export type S3BucketType = string;
export type DomainVersionType = string;
export type DomainStatusType = "CREATING" | "DELETING" | "UPDATING" | "ACTIVE" | "FAILED" | (string & {});
export interface DomainDescriptionType {
    UserPoolId?: string | undefined;
    AWSAccountId?: string | undefined;
    Domain?: string | undefined;
    S3Bucket?: string | undefined;
    CloudFrontDistribution?: string | undefined;
    Version?: string | undefined;
    Status?: DomainStatusType | undefined;
    CustomDomainConfig?: CustomDomainConfigType | undefined;
    ManagedLoginVersion?: number | undefined;
    Routing?: RoutingType | undefined;
}
export interface DescribeUserPoolDomainResponse {
    DomainDescription?: DomainDescriptionType | undefined;
}
export interface ForgetDeviceRequest {
    AccessToken?: string | redacted.Redacted<string> | undefined;
    DeviceKey: string;
}
export interface ForgetDeviceResponse {
}
export interface ForgotPasswordRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string> | undefined;
    UserContextData?: UserContextDataType | undefined;
    Username: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CodeDeliveryDetailsType {
    Destination?: string | undefined;
    DeliveryMedium?: DeliveryMediumType | undefined;
    AttributeName?: string | undefined;
}
export interface ForgotPasswordResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType | undefined;
}
export interface GetClientTokenRequest {
    ClientId: string | redacted.Redacted<string>;
    Secret: string | redacted.Redacted<string>;
    Scopes?: string[] | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ClientAuthenticationResultType {
    AccessToken?: string | redacted.Redacted<string> | undefined;
    ExpiresIn?: number | undefined;
    TokenType?: string | undefined;
}
export interface GetClientTokenResponse {
    ClientAuthenticationResult?: ClientAuthenticationResultType | undefined;
}
export interface GetCSVHeaderRequest {
    UserPoolId: string;
}
export type ListOfStringTypes = string[];
export interface GetCSVHeaderResponse {
    UserPoolId?: string | undefined;
    CSVHeader?: string[] | undefined;
}
export interface GetDeviceRequest {
    DeviceKey: string;
    AccessToken?: string | redacted.Redacted<string> | undefined;
}
export interface GetDeviceResponse {
    Device: DeviceType;
}
export interface GetGroupRequest {
    GroupName: string;
    UserPoolId: string;
}
export interface GetGroupResponse {
    Group?: GroupType | undefined;
}
export interface GetIdentityProviderByIdentifierRequest {
    UserPoolId: string;
    IdpIdentifier: string;
}
export interface GetIdentityProviderByIdentifierResponse {
    IdentityProvider: IdentityProviderType;
}
export interface GetLogDeliveryConfigurationRequest {
    UserPoolId: string;
}
export type LogLevel = "ERROR" | "INFO" | (string & {});
export type EventSourceName = "userNotification" | "userAuthEvents" | (string & {});
export interface CloudWatchLogsConfigurationType {
    LogGroupArn?: string | undefined;
}
export type S3ArnType = string;
export interface S3ConfigurationType {
    BucketArn?: string | undefined;
}
export interface FirehoseConfigurationType {
    StreamArn?: string | undefined;
}
export interface LogConfigurationType {
    LogLevel: LogLevel;
    EventSource: EventSourceName;
    CloudWatchLogsConfiguration?: CloudWatchLogsConfigurationType | undefined;
    S3Configuration?: S3ConfigurationType | undefined;
    FirehoseConfiguration?: FirehoseConfigurationType | undefined;
}
export type LogConfigurationListType = LogConfigurationType[];
export interface LogDeliveryConfigurationType {
    UserPoolId: string;
    LogConfigurations: LogConfigurationType[];
}
export interface GetLogDeliveryConfigurationResponse {
    LogDeliveryConfiguration?: LogDeliveryConfigurationType | undefined;
}
export type LimitClass = "API_CATEGORY" | (string & {});
export type StringToStringMapType = {
    [key: string]: string | undefined;
};
export interface LimitDefinitionType {
    LimitClass: LimitClass;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export interface GetProvisionedLimitRequest {
    LimitDefinition: LimitDefinitionType;
}
export interface LimitType {
    LimitDefinition: LimitDefinitionType;
    ProvisionedLimitValue: number;
    FreeLimitValue: number;
}
export interface GetProvisionedLimitResponse {
    Limit: LimitType;
}
export interface GetSigningCertificateRequest {
    UserPoolId: string;
}
export interface GetSigningCertificateResponse {
    Certificate?: string | undefined;
}
export interface GetTokensFromRefreshTokenRequest {
    RefreshToken: string | redacted.Redacted<string>;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    DeviceKey?: string | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetTokensFromRefreshTokenResponse {
    AuthenticationResult?: AuthenticationResultType | undefined;
}
export interface GetUICustomizationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string> | undefined;
}
export type ImageUrlType = string;
export type CSSType = string;
export type CSSVersionType = string;
export interface UICustomizationType {
    UserPoolId?: string | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    ImageUrl?: string | undefined;
    CSS?: string | undefined;
    CSSVersion?: string | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
}
export interface GetUICustomizationResponse {
    UICustomization: UICustomizationType;
}
export interface GetUserRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export interface GetUserResponse {
    Username: string | redacted.Redacted<string>;
    UserAttributes: AttributeType[];
    MFAOptions?: MFAOptionType[] | undefined;
    PreferredMfaSetting?: string | undefined;
    UserMFASettingList?: string[] | undefined;
}
export interface GetUserAttributeVerificationCodeRequest {
    AccessToken: string | redacted.Redacted<string>;
    AttributeName: string;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetUserAttributeVerificationCodeResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType | undefined;
}
export interface GetUserAuthFactorsRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export interface GetUserAuthFactorsResponse {
    Username: string | redacted.Redacted<string>;
    PreferredMfaSetting?: string | undefined;
    UserMFASettingList?: string[] | undefined;
    ConfiguredUserAuthFactors?: AuthFactorType[] | undefined;
}
export interface GetUserPoolClientSessionConfigurationRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
}
export type SSOSessionMaxValidityMinutesType = number;
export interface ClientSSOSessionConfigType {
    MaxValidityMinutes: number;
}
export interface GetUserPoolClientSessionConfigurationResponse {
    UserPoolId?: string | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    SSOSession?: ClientSSOSessionConfigType | undefined;
}
export interface GetUserPoolMfaConfigRequest {
    UserPoolId: string;
}
export interface SmsMfaConfigType {
    SmsAuthenticationMessage?: string | undefined;
    SmsConfiguration?: SmsConfigurationType | undefined;
}
export interface SoftwareTokenMfaConfigType {
    Enabled?: boolean | undefined;
}
export type EmailMfaMessageType = string;
export type EmailMfaSubjectType = string;
export interface EmailMfaConfigType {
    Message?: string | undefined;
    Subject?: string | undefined;
}
export type RelyingPartyIdType = string;
export type UserVerificationType = "required" | "preferred" | (string & {});
export type WebAuthnFactorConfigurationType = "SINGLE_FACTOR" | "MULTI_FACTOR_WITH_USER_VERIFICATION" | (string & {});
export interface WebAuthnConfigurationType {
    RelyingPartyId?: string | undefined;
    UserVerification?: UserVerificationType | undefined;
    FactorConfiguration?: WebAuthnFactorConfigurationType | undefined;
}
export interface GetUserPoolMfaConfigResponse {
    SmsMfaConfiguration?: SmsMfaConfigType | undefined;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType | undefined;
    EmailMfaConfiguration?: EmailMfaConfigType | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    WebAuthnConfiguration?: WebAuthnConfigurationType | undefined;
}
export interface GetUserPoolSessionConfigurationRequest {
    UserPoolId: string;
}
export type UserSessionTrackingType = "ENABLED" | "DISABLED" | (string & {});
export type MaxSessionsPerUserType = number;
export interface UserPoolTokenSessionConfigType {
    MaxPerUser: number;
}
export interface GetUserPoolSessionConfigurationResponse {
    UserPoolId?: string | undefined;
    UserSessionTracking?: UserSessionTrackingType | undefined;
    TokenSession?: UserPoolTokenSessionConfigType | undefined;
}
export interface GlobalSignOutRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export interface GlobalSignOutResponse {
}
export interface InitiateAuthRequest {
    AuthFlow: AuthFlowType;
    AuthParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientId: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    UserContextData?: UserContextDataType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface InitiateAuthResponse {
    ChallengeName?: ChallengeNameType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AuthenticationResult?: AuthenticationResultType | undefined;
    AvailableChallenges?: ChallengeNameType[] | undefined;
}
export interface ListDevicesRequest {
    AccessToken: string | redacted.Redacted<string>;
    Limit?: number | undefined;
    PaginationToken?: string | undefined;
}
export interface ListDevicesResponse {
    Devices?: DeviceType[] | undefined;
    PaginationToken?: string | undefined;
}
export interface ListGroupsRequest {
    UserPoolId: string;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupsResponse {
    Groups?: GroupType[] | undefined;
    NextToken?: string | undefined;
}
export type ListProvidersLimitType = number;
export type PaginationKeyType = string;
export interface ListIdentityProvidersRequest {
    UserPoolId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ProviderDescription {
    ProviderName?: string | undefined;
    ProviderType?: IdentityProviderTypeType | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
}
export type ProvidersListType = ProviderDescription[];
export interface ListIdentityProvidersResponse {
    Providers: ProviderDescription[];
    NextToken?: string | undefined;
}
export type ListResourceServersLimitType = number;
export interface ListResourceServersRequest {
    UserPoolId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourceServersListType = ResourceServerType[];
export interface ListResourceServersResponse {
    ResourceServers: ResourceServerType[];
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListTermsRequestMaxResultsInteger = number;
export interface ListTermsRequest {
    UserPoolId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TermsDescriptionType {
    TermsId: string;
    TermsName: string;
    Enforcement: TermsEnforcementType;
    CreationDate: Date;
    LastModifiedDate: Date;
}
export type TermsDescriptionListType = TermsDescriptionType[];
export interface ListTermsResponse {
    Terms: TermsDescriptionType[];
    NextToken?: string | undefined;
}
export type PoolQueryLimitType = number;
export interface ListUserImportJobsRequest {
    UserPoolId: string;
    MaxResults: number;
    PaginationToken?: string | undefined;
}
export type UserImportJobsListType = UserImportJobType[];
export interface ListUserImportJobsResponse {
    UserImportJobs?: UserImportJobType[] | undefined;
    PaginationToken?: string | undefined;
}
export type QueryLimit = number;
export interface ListUserPoolClientsRequest {
    UserPoolId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ClientType?: ClientTypeType | undefined;
}
export interface UserPoolClientDescription {
    ClientId?: string | redacted.Redacted<string> | undefined;
    UserPoolId?: string | undefined;
    ClientName?: string | undefined;
}
export type UserPoolClientListType = UserPoolClientDescription[];
export interface ListUserPoolClientsResponse {
    UserPoolClients?: UserPoolClientDescription[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUserPoolClientSecretsRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    NextToken?: string | undefined;
}
export type ClientSecretDescriptorListType = ClientSecretDescriptorType[];
export interface ListUserPoolClientSecretsResponse {
    ClientSecrets?: ClientSecretDescriptorType[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUserPoolReplicasRequest {
    UserPoolId: string;
    NextToken?: string | undefined;
}
export type UserPoolReplicaListType = UserPoolReplicaType[];
export interface ListUserPoolReplicasResponse {
    UserPoolReplicas?: UserPoolReplicaType[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUserPoolsRequest {
    NextToken?: string | undefined;
    MaxResults: number;
}
export type ReplicaRegionsType = string[];
export interface UserPoolDescriptionType {
    Id?: string | undefined;
    Name?: string | undefined;
    LambdaConfig?: LambdaConfigType | undefined;
    Status?: StatusType | undefined;
    LastModifiedDate?: Date | undefined;
    CreationDate?: Date | undefined;
    ReplicaRegions?: string[] | undefined;
}
export type UserPoolListType = UserPoolDescriptionType[];
export interface ListUserPoolsResponse {
    UserPools?: UserPoolDescriptionType[] | undefined;
    NextToken?: string | undefined;
}
export type SearchedAttributeNamesListType = string[];
export type UserFilterType = string;
export interface ListUsersRequest {
    UserPoolId: string;
    AttributesToGet?: string[] | undefined;
    Limit?: number | undefined;
    PaginationToken?: string | undefined;
    Filter?: string | undefined;
}
export type UsersListType = UserType[];
export interface ListUsersResponse {
    Users?: UserType[] | undefined;
    PaginationToken?: string | undefined;
}
export interface ListUserSessionsRequest {
    AccessToken: string | redacted.Redacted<string>;
    NextToken?: string | undefined;
}
export interface ListUserSessionsResponse {
    Sessions?: SessionDescriptionType[] | undefined;
    NextToken?: string | undefined;
}
export interface ListUsersInGroupRequest {
    UserPoolId: string;
    GroupName: string;
    Limit?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListUsersInGroupResponse {
    Users?: UserType[] | undefined;
    NextToken?: string | undefined;
}
export type WebAuthnCredentialsQueryLimitType = number;
export interface ListWebAuthnCredentialsRequest {
    AccessToken: string | redacted.Redacted<string>;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type WebAuthnAuthenticatorAttachmentType = string;
export type WebAuthnAuthenticatorTransportType = string;
export type WebAuthnAuthenticatorTransportsList = string[];
export interface WebAuthnCredentialDescription {
    CredentialId: string;
    FriendlyCredentialName: string;
    RelyingPartyId: string;
    AuthenticatorAttachment?: string | undefined;
    AuthenticatorTransports: string[];
    CreatedAt: Date;
}
export type WebAuthnCredentialDescriptionListType = WebAuthnCredentialDescription[];
export interface ListWebAuthnCredentialsResponse {
    Credentials: WebAuthnCredentialDescription[];
    NextToken?: string | undefined;
}
export interface ResendConfirmationCodeRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string> | undefined;
    UserContextData?: UserContextDataType | undefined;
    Username: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ResendConfirmationCodeResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType | undefined;
}
export interface RespondToAuthChallengeRequest {
    ClientId: string | redacted.Redacted<string>;
    ChallengeName: ChallengeNameType;
    Session?: string | redacted.Redacted<string> | undefined;
    ChallengeResponses?: {
        [key: string]: string | undefined;
    } | undefined;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    UserContextData?: UserContextDataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RespondToAuthChallengeResponse {
    ChallengeName?: ChallengeNameType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AuthenticationResult?: AuthenticationResultType | undefined;
    AvailableChallenges?: ChallengeNameType[] | undefined;
}
export interface RevokeTokenRequest {
    Token: string | redacted.Redacted<string>;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    RevokeAssociatedSessions?: RevokeAssociatedSessionsType | undefined;
}
export interface RevokeTokenResponse {
}
export interface RevokeUserSessionRequest {
    AccessToken: string | redacted.Redacted<string>;
    SessionId: string;
    RevokeAssociatedSessions?: RevokeAssociatedSessionsType | undefined;
}
export interface RevokeUserSessionResponse {
}
export interface SetLogDeliveryConfigurationRequest {
    UserPoolId: string;
    LogConfigurations: LogConfigurationType[];
}
export interface SetLogDeliveryConfigurationResponse {
    LogDeliveryConfiguration?: LogDeliveryConfigurationType | undefined;
}
export interface SetRiskConfigurationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string> | undefined;
    CompromisedCredentialsRiskConfiguration?: CompromisedCredentialsRiskConfigurationType | undefined;
    AccountTakeoverRiskConfiguration?: AccountTakeoverRiskConfigurationType | undefined;
    RiskExceptionConfiguration?: RiskExceptionConfigurationType | undefined;
}
export interface SetRiskConfigurationResponse {
    RiskConfiguration: RiskConfigurationType;
}
export type ImageFileType = Uint8Array;
export interface SetUICustomizationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string> | undefined;
    CSS?: string | undefined;
    ImageFile?: Uint8Array | undefined;
}
export interface SetUICustomizationResponse {
    UICustomization: UICustomizationType;
}
export interface SetUserMFAPreferenceRequest {
    SMSMfaSettings?: SMSMfaSettingsType | undefined;
    SoftwareTokenMfaSettings?: SoftwareTokenMfaSettingsType | undefined;
    EmailMfaSettings?: EmailMfaSettingsType | undefined;
    WebAuthnMfaSettings?: WebAuthnMfaSettingsType | undefined;
    AccessToken: string | redacted.Redacted<string>;
}
export interface SetUserMFAPreferenceResponse {
}
export interface SetUserPoolClientSessionConfigurationRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    SSOSession: ClientSSOSessionConfigType;
}
export interface SetUserPoolClientSessionConfigurationResponse {
    UserPoolId?: string | undefined;
    ClientId?: string | redacted.Redacted<string> | undefined;
    SSOSession?: ClientSSOSessionConfigType | undefined;
}
export interface SetUserPoolMfaConfigRequest {
    UserPoolId: string;
    SmsMfaConfiguration?: SmsMfaConfigType | undefined;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType | undefined;
    EmailMfaConfiguration?: EmailMfaConfigType | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    WebAuthnConfiguration?: WebAuthnConfigurationType | undefined;
}
export interface SetUserPoolMfaConfigResponse {
    SmsMfaConfiguration?: SmsMfaConfigType | undefined;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType | undefined;
    EmailMfaConfiguration?: EmailMfaConfigType | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    WebAuthnConfiguration?: WebAuthnConfigurationType | undefined;
}
export interface SetUserPoolSessionConfigurationRequest {
    UserPoolId: string;
    UserSessionTracking: UserSessionTrackingType;
    TokenSession: UserPoolTokenSessionConfigType;
}
export interface SetUserPoolSessionConfigurationResponse {
    UserPoolId?: string | undefined;
    UserSessionTracking?: UserSessionTrackingType | undefined;
    TokenSession?: UserPoolTokenSessionConfigType | undefined;
}
export interface SetUserSettingsRequest {
    AccessToken: string | redacted.Redacted<string>;
    MFAOptions: MFAOptionType[];
}
export interface SetUserSettingsResponse {
}
export interface SignUpRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string> | undefined;
    Username: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string> | undefined;
    UserAttributes?: AttributeType[] | undefined;
    ValidationData?: AttributeType[] | undefined;
    AnalyticsMetadata?: AnalyticsMetadataType | undefined;
    UserContextData?: UserContextDataType | undefined;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SignUpResponse {
    UserConfirmed: boolean;
    CodeDeliveryDetails?: CodeDeliveryDetailsType | undefined;
    UserSub: string;
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface StartUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export interface StartUserImportJobResponse {
    UserImportJob?: UserImportJobType | undefined;
}
export interface StartWebAuthnRegistrationRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export interface StartWebAuthnRegistrationResponse {
    CredentialCreationOptions: any;
}
export interface StopUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export interface StopUserImportJobResponse {
    UserImportJob?: UserImportJobType | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type UserPoolTagsListType = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAuthEventFeedbackRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    EventId: string;
    FeedbackToken: string | redacted.Redacted<string>;
    FeedbackValue: FeedbackValueType;
}
export interface UpdateAuthEventFeedbackResponse {
}
export interface UpdateDeviceStatusRequest {
    AccessToken: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceRememberedStatus?: DeviceRememberedStatusType | undefined;
}
export interface UpdateDeviceStatusResponse {
}
export interface UpdateGroupRequest {
    GroupName: string;
    UserPoolId: string;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    Precedence?: number | undefined;
}
export interface UpdateGroupResponse {
    Group?: GroupType | undefined;
}
export interface UpdateIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
    ProviderDetails?: {
        [key: string]: string | undefined;
    } | undefined;
    AttributeMapping?: {
        [key: string]: string | undefined;
    } | undefined;
    IdpIdentifiers?: string[] | undefined;
    AcrMapping?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export interface UpdateManagedLoginBrandingRequest {
    UserPoolId?: string | undefined;
    ManagedLoginBrandingId?: string | undefined;
    UseCognitoProvidedValues?: boolean | undefined;
    Settings?: any | undefined;
    Assets?: AssetType[] | undefined;
}
export interface UpdateManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType | undefined;
}
export interface UpdateProvisionedLimitRequest {
    LimitDefinition: LimitDefinitionType;
    RequestedLimitValue: number;
}
export interface UpdateProvisionedLimitResponse {
    Limit: LimitType;
}
export interface UpdateResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
    Name: string;
    Scopes?: ResourceServerScopeType[] | undefined;
}
export interface UpdateResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export interface UpdateTermsRequest {
    TermsId: string;
    UserPoolId: string;
    TermsName?: string | undefined;
    TermsSource?: TermsSourceType | undefined;
    Enforcement?: TermsEnforcementType | undefined;
    Links?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateTermsResponse {
    Terms?: TermsType | undefined;
}
export interface UpdateUserAttributesRequest {
    UserAttributes: AttributeType[];
    AccessToken: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CodeDeliveryDetailsListType = CodeDeliveryDetailsType[];
export interface UpdateUserAttributesResponse {
    CodeDeliveryDetailsList?: CodeDeliveryDetailsType[] | undefined;
}
export interface UpdateUserPoolRequest {
    UserPoolId: string;
    Policies?: UserPoolPolicyType | undefined;
    DeletionProtection?: DeletionProtectionType | undefined;
    LambdaConfig?: LambdaConfigType | undefined;
    AutoVerifiedAttributes?: VerifiedAttributeType[] | undefined;
    SmsVerificationMessage?: string | undefined;
    EmailVerificationMessage?: string | undefined;
    EmailVerificationSubject?: string | undefined;
    VerificationMessageTemplate?: VerificationMessageTemplateType | undefined;
    SmsAuthenticationMessage?: string | undefined;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType | undefined;
    MfaConfiguration?: UserPoolMfaType | undefined;
    DeviceConfiguration?: DeviceConfigurationType | undefined;
    EmailConfiguration?: EmailConfigurationType | undefined;
    SmsConfiguration?: SmsConfigurationType | undefined;
    UserPoolTags?: {
        [key: string]: string | undefined;
    } | undefined;
    AdminCreateUserConfig?: AdminCreateUserConfigType | undefined;
    UserPoolAddOns?: UserPoolAddOnsType | undefined;
    DcrConfiguration?: DcrConfigurationType | undefined;
    AccountRecoverySetting?: AccountRecoverySettingType | undefined;
    PoolName?: string | undefined;
    UserPoolTier?: UserPoolTierType | undefined;
    KeyConfiguration?: KeyConfigurationType | undefined;
    IssuerConfiguration?: IssuerConfigurationType | undefined;
    AcrConfiguration?: {
        [key: string]: AcrLevelConfigType | undefined;
    } | undefined;
}
export interface UpdateUserPoolResponse {
}
export interface UpdateUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientName?: string | undefined;
    RefreshTokenValidity?: number | undefined;
    AccessTokenValidity?: number | undefined;
    IdTokenValidity?: number | undefined;
    TokenValidityUnits?: TokenValidityUnitsType | undefined;
    ReadAttributes?: string[] | undefined;
    WriteAttributes?: string[] | undefined;
    ExplicitAuthFlows?: ExplicitAuthFlowsType[] | undefined;
    SupportedIdentityProviders?: string[] | undefined;
    CallbackURLs?: string[] | undefined;
    LogoutURLs?: string[] | undefined;
    DefaultRedirectURI?: string | undefined;
    AllowedOAuthFlows?: OAuthFlowType[] | undefined;
    AllowedOAuthScopes?: string[] | undefined;
    AllowedOAuthFlowsUserPoolClient?: boolean | undefined;
    AnalyticsConfiguration?: AnalyticsConfigurationType | undefined;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes | undefined;
    EnableTokenRevocation?: boolean | undefined;
    EnablePropagateAdditionalUserContextData?: boolean | undefined;
    AuthSessionValidity?: number | undefined;
    RefreshTokenRotation?: RefreshTokenRotationType | undefined;
}
export interface UpdateUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType | undefined;
}
export interface UpdateUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
    ManagedLoginVersion?: number | undefined;
    CustomDomainConfig?: CustomDomainConfigType | undefined;
    Routing?: RoutingType | undefined;
}
export interface UpdateUserPoolDomainResponse {
    ManagedLoginVersion?: number | undefined;
    CloudFrontDomain?: string | undefined;
    Routing?: RoutingType | undefined;
}
export type UpdateReplicaStatusType = "ACTIVE" | "INACTIVE" | (string & {});
export interface UpdateUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
    Status: UpdateReplicaStatusType;
}
export interface UpdateUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType | undefined;
}
export type SoftwareTokenMFAUserCodeType = string | redacted.Redacted<string>;
export interface VerifySoftwareTokenRequest {
    AccessToken?: string | redacted.Redacted<string> | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
    UserCode: string | redacted.Redacted<string>;
    FriendlyDeviceName?: string | undefined;
}
export type VerifySoftwareTokenResponseType = "SUCCESS" | "ERROR" | (string & {});
export interface VerifySoftwareTokenResponse {
    Status?: VerifySoftwareTokenResponseType | undefined;
    Session?: string | redacted.Redacted<string> | undefined;
}
export interface VerifyUserAttributeRequest {
    AccessToken: string | redacted.Redacted<string>;
    AttributeName: string;
    Code: string;
}
export interface VerifyUserAttributeResponse {
}
export type MessageType = string;
export type InvalidParameterExceptionReasonCodeType = string;
export type AddCustomAttributesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserImportInProgressException | CommonErrors;
/**
 * Adds additional user attributes to the user pool schema. Custom attributes can be
 * mutable or immutable and have a `custom:` or `dev:` prefix. For
 * more information, see Custom attributes.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const addCustomAttributes: API.OperationMethod<AddCustomAttributesRequest & RegionInput, AddCustomAttributesResponse, AddCustomAttributesError, Credentials | HttpClient.HttpClient>;
export type AddUserPoolClientSecretError = AccessDeniedException | InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new client secret for an existing confidential user pool app client. Supports up to 2 active secrets per app client for zero-downtime credential rotation workflows.
 */
export declare const addUserPoolClientSecret: API.OperationMethod<AddUserPoolClientSecretRequest & RegionInput, AddUserPoolClientSecretResponse, AddUserPoolClientSecretError, Credentials | HttpClient.HttpClient>;
export type AdminAddUserToGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Adds a user to a group. A user who is in a group can present a preferred-role claim to
 * an identity pool, and populates a `cognito:groups` claim to their access and
 * identity tokens.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminAddUserToGroup: API.OperationMethod<AdminAddUserToGroupRequest & RegionInput, AdminAddUserToGroupResponse, AdminAddUserToGroupError, Credentials | HttpClient.HttpClient>;
export type AdminConfirmSignUpError = InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Confirms user sign-up as an administrator.
 *
 * This request sets a user account active in a user pool that requires confirmation of new user accounts before they can sign in. You can
 * configure your user pool to not send confirmation codes to new users and instead confirm
 * them with this API operation on the back end.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 *
 * To configure your user pool to require administrative confirmation of users, set
 * `AllowAdminCreateUserOnly` to `true` in a
 * `CreateUserPool` or `UpdateUserPool` request.
 */
export declare const adminConfirmSignUp: API.OperationMethod<AdminConfirmSignUpRequest & RegionInput, AdminConfirmSignUpResponse, AdminConfirmSignUpError, Credentials | HttpClient.HttpClient>;
export type AdminCreateUserError = CodeDeliveryFailureException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedUserStateException | UserLambdaValidationException | UsernameExistsException | UserNotFoundException | CommonErrors;
/**
 * Creates a new user in the specified user pool.
 *
 * If `MessageAction` isn't set, the default is to send a welcome message via
 * email or phone (SMS).
 *
 * This message is based on a template that you configured in your call to create or
 * update a user pool. This template includes your custom sign-up instructions and
 * placeholders for user name and temporary password.
 *
 * Alternatively, you can call `AdminCreateUser` with `SUPPRESS`
 * for the `MessageAction` parameter, and Amazon Cognito won't send any email.
 *
 * In either case, if the user has a password, they will be in the
 * `FORCE_CHANGE_PASSWORD` state until they sign in and set their password.
 * Your invitation message template must have the `{####}` password placeholder
 * if your users have passwords. If your template doesn't have this placeholder, Amazon Cognito
 * doesn't deliver the invitation message. In this case, you must update your message
 * template and resend the password with a new `AdminCreateUser` request with a
 * `MessageAction` value of `RESEND`.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminCreateUser: API.OperationMethod<AdminCreateUserRequest & RegionInput, AdminCreateUserResponse, AdminCreateUserError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteSoftwareTokenError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes a user's registered time-based one-time password (TOTP) multi-factor
 * authentication (MFA) factor, also known as a software token. After this operation, the
 * user can no longer sign in with TOTP MFA, and can register a new TOTP factor with
 * `AssociateSoftwareToken`. Use this operation when a user loses access to
 * their TOTP-generating device, for example, a lost or reset phone, and needs to register
 * a new one.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteSoftwareToken: API.OperationMethod<AdminDeleteSoftwareTokenRequest & RegionInput, AdminDeleteSoftwareTokenResponse, AdminDeleteSoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deletes a user profile in your user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteUser: API.OperationMethod<AdminDeleteUserRequest & RegionInput, AdminDeleteUserResponse, AdminDeleteUserError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteUserAttributesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deletes attribute values from a user. This operation doesn't affect tokens for
 * existing user sessions. The next ID token that the user receives will no longer have the
 * deleted attributes.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteUserAttributes: API.OperationMethod<AdminDeleteUserAttributesRequest & RegionInput, AdminDeleteUserAttributesResponse, AdminDeleteUserAttributesError, Credentials | HttpClient.HttpClient>;
export type AdminDisableProviderForUserError = AliasExistsException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Prevents the user from signing in with the specified external (SAML or social)
 * identity provider (IdP). If the user that you want to deactivate is a Amazon Cognito user pools
 * native username + password user, they can't use their password to sign in. If the user
 * to deactivate is a linked external IdP user, any link between that user and an existing
 * user is removed. When the external user signs in again, and the user is no longer
 * attached to the previously linked `DestinationUser`, the user must create a
 * new user account.
 *
 * The value of `ProviderName` must match the name of a user pool IdP.
 *
 * To deactivate a local user, set `ProviderName` to `Cognito` and
 * the `ProviderAttributeName` to `Cognito_Subject`. The
 * `ProviderAttributeValue` must be user's local username.
 *
 * The `ProviderAttributeName` must always be `Cognito_Subject` for
 * social IdPs. The `ProviderAttributeValue` must always be the exact subject
 * that was used when the user was originally linked as a source user.
 *
 * For de-linking a SAML identity, there are two scenarios. If the linked identity has
 * not yet been used to sign in, the `ProviderAttributeName` and
 * `ProviderAttributeValue` must be the same values that were used for the
 * `SourceUser` when the identities were originally linked using
 * AdminLinkProviderForUser call. This is also true if the linking was done with
 * `ProviderAttributeName` set to `Cognito_Subject`. If the user
 * has already signed in, the `ProviderAttributeName` must be
 * `Cognito_Subject` and `ProviderAttributeValue` must be the
 * `NameID` from their SAML assertion.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDisableProviderForUser: API.OperationMethod<AdminDisableProviderForUserRequest & RegionInput, AdminDisableProviderForUserResponse, AdminDisableProviderForUserError, Credentials | HttpClient.HttpClient>;
export type AdminDisableUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deactivates a user profile and revokes all access tokens for the user. A deactivated
 * user can't sign in, but still appears in the responses to `ListUsers`
 * API requests.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDisableUser: API.OperationMethod<AdminDisableUserRequest & RegionInput, AdminDisableUserResponse, AdminDisableUserError, Credentials | HttpClient.HttpClient>;
export type AdminEnableUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Activates sign-in for a user profile that previously had sign-in access
 * disabled.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminEnableUser: API.OperationMethod<AdminEnableUserRequest & RegionInput, AdminEnableUserResponse, AdminEnableUserError, Credentials | HttpClient.HttpClient>;
export type AdminForgetDeviceError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Forgets, or deletes, a remembered device from a user's profile. After you forget
 * the device, the user can no longer complete device authentication with that device and
 * when applicable, must submit MFA codes again. For more information, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminForgetDevice: API.OperationMethod<AdminForgetDeviceRequest & RegionInput, AdminForgetDeviceResponse, AdminForgetDeviceError, Credentials | HttpClient.HttpClient>;
export type AdminGetDeviceError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the device key, returns details for a user's device. For more information,
 * see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetDevice: API.OperationMethod<AdminGetDeviceRequest & RegionInput, AdminGetDeviceResponse, AdminGetDeviceError, Credentials | HttpClient.HttpClient>;
export type AdminGetUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Given a username, returns details about a user profile in a user pool. You can specify
 * alias attributes in the `Username` request parameter.
 *
 * This operation contributes to your monthly active user (MAU) count for the purpose of
 * billing.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetUser: API.OperationMethod<AdminGetUserRequest & RegionInput, AdminGetUserResponse, AdminGetUserError, Credentials | HttpClient.HttpClient>;
export type AdminGetUserAuthFactorsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Lists the authentication options for a user in a user pool. Returns the
 * following:
 *
 * - The user's multi-factor authentication (MFA) preferences.
 *
 * - The user's options for choice-based authentication with the
 * `USER_AUTH` flow.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetUserAuthFactors: API.OperationMethod<AdminGetUserAuthFactorsRequest & RegionInput, AdminGetUserAuthFactorsResponse, AdminGetUserAuthFactorsError, Credentials | HttpClient.HttpClient>;
export type AdminInitiateAuthError = FeatureUnavailableInTierException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedOperationException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Starts sign-in for applications with a server-side component, for example a
 * traditional web application. This operation specifies the authentication flow that
 * you'd like to begin. The authentication flow that you specify must be supported in
 * your app client configuration. For more information about authentication flows, see
 * Authentication flows.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminInitiateAuth: API.OperationMethod<AdminInitiateAuthRequest & RegionInput, AdminInitiateAuthResponse, AdminInitiateAuthError, Credentials | HttpClient.HttpClient>;
export type AdminLinkProviderForUserError = AliasExistsException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Links an existing user account in a user pool, or `DestinationUser`, to an
 * identity from an external IdP, or `SourceUser`, based on a specified
 * attribute name and value from the external IdP.
 *
 * This operation connects a local user profile with a user identity who hasn't yet
 * signed in from their third-party IdP. When the user signs in with their IdP, they get
 * access-control configuration from the local user profile. Linked local users can also
 * sign in with SDK-based API operations like `InitiateAuth` after they sign in
 * at least once through their IdP. For more information, see Linking federated users.
 *
 * The maximum number of federated identities linked to a user is five.
 *
 * Because this API allows a user with an external federated identity to sign in as a
 * local user, it is critical that it only be used with external IdPs and linked
 * attributes that you trust.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminLinkProviderForUser: API.OperationMethod<AdminLinkProviderForUserRequest & RegionInput, AdminLinkProviderForUserResponse, AdminLinkProviderForUserError, Credentials | HttpClient.HttpClient>;
export type AdminListDevicesError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists a user's registered devices. Remembered devices are used in authentication
 * services where you offer a "Remember me" option for users who you want to permit to sign
 * in without MFA from a trusted device. Users can bypass MFA while your application
 * performs device SRP authentication on the back end. For more information, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListDevices: API.OperationMethod<AdminListDevicesRequest & RegionInput, AdminListDevicesResponse, AdminListDevicesError, Credentials | HttpClient.HttpClient>;
export type AdminListGroupsForUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Lists the groups that a user belongs to. User pool groups are identifiers that you can
 * reference from the contents of ID and access tokens, and set preferred IAM roles for
 * identity-pool authentication. For more information, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListGroupsForUser: API.PaginatedOperationMethod<AdminListGroupsForUserRequest & RegionInput, AdminListGroupsForUserResponse, AdminListGroupsForUserError, Credentials | HttpClient.HttpClient, GroupType>;
export type AdminListUserAuthEventsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Requests a history of user activity and any risks detected as part of Amazon Cognito threat
 * protection. For more information, see Viewing user event history.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListUserAuthEvents: API.PaginatedOperationMethod<AdminListUserAuthEventsRequest & RegionInput, AdminListUserAuthEventsResponse, AdminListUserAuthEventsError, Credentials | HttpClient.HttpClient, AuthEventType>;
export type AdminListUserSessionsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Lists the active sessions for a specified user as an administrator. The response
 * includes both token sessions and SSO sessions. Only active sessions are returned;
 * revoked and expired sessions aren't included. Amazon Cognito returns all of a user's sessions in
 * a single page of up to 125 sessions. The results are eventually consistent, and new
 * sessions are typically included within a few seconds.
 */
export declare const adminListUserSessions: API.OperationMethod<AdminListUserSessionsRequest & RegionInput, AdminListUserSessionsResponse, AdminListUserSessionsError, Credentials | HttpClient.HttpClient>;
export type AdminRemoveUserFromGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Given a username and a group name, removes them from the group. User pool groups are
 * identifiers that you can reference from the contents of ID and access tokens, and set
 * preferred IAM roles for identity-pool authentication. For more information, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminRemoveUserFromGroup: API.OperationMethod<AdminRemoveUserFromGroupRequest & RegionInput, AdminRemoveUserFromGroupResponse, AdminRemoveUserFromGroupError, Credentials | HttpClient.HttpClient>;
export type AdminResetUserPasswordError = InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Begins the password reset process. Sets the requested user's account into a
 * `RESET_REQUIRED` status, and sends them a password-reset code. Your user
 * pool also sends the user a notification with a reset code and the information that their
 * password has been reset. At sign-in, your application or the managed login session
 * receives a challenge to complete the reset by confirming the code and setting a new
 * password.
 *
 * To use this API operation, your user pool must have self-service account recovery
 * configured.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminResetUserPassword: API.OperationMethod<AdminResetUserPasswordRequest & RegionInput, AdminResetUserPasswordResponse, AdminResetUserPasswordError, Credentials | HttpClient.HttpClient>;
export type AdminRespondToAuthChallengeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Some API operations in a user pool generate a challenge, like a prompt for an MFA
 * code, for device authentication that bypasses MFA, or for a custom authentication
 * challenge. An `AdminRespondToAuthChallenge` API request provides the answer
 * to that challenge, like a code or a secure remote password (SRP). The parameters of a
 * response to an authentication challenge vary with the type of challenge.
 *
 * For more information about custom authentication challenges, see Custom
 * authentication challenge Lambda triggers.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminRespondToAuthChallenge: API.OperationMethod<AdminRespondToAuthChallengeRequest & RegionInput, AdminRespondToAuthChallengeResponse, AdminRespondToAuthChallengeError, Credentials | HttpClient.HttpClient>;
export type AdminRevokeUserSessionError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Revokes a specific user session as an administrator. Amazon Cognito revokes all refresh and
 * access tokens that are associated with the session and deletes the session record. You
 * can revoke either a token session or an SSO session, and you can optionally cascade the
 * revocation to linked sessions.
 */
export declare const adminRevokeUserSession: API.OperationMethod<AdminRevokeUserSessionRequest & RegionInput, AdminRevokeUserSessionResponse, AdminRevokeUserSessionError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserMFAPreferenceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Sets the user's multi-factor authentication (MFA) preference, including which MFA
 * options are activated, and if any are preferred. Only one factor can be set as
 * preferred. The preferred MFA factor will be used to authenticate a user if multiple
 * factors are activated. If multiple options are activated and no preference is set, a
 * challenge to choose an MFA option will be returned during sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserMFAPreference: API.OperationMethod<AdminSetUserMFAPreferenceRequest & RegionInput, AdminSetUserMFAPreferenceResponse, AdminSetUserMFAPreferenceError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserPasswordError = InternalErrorException | InvalidParameterException | InvalidPasswordException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Sets the specified user's password in a user pool. This operation administratively
 * sets a temporary or permanent password for a user. With this operation, you can bypass
 * self-service password changes and permit immediate sign-in with the password that you
 * set. To do this, set `Permanent` to `true`.
 *
 * You can also set a new temporary password in this request, send it to a user, and
 * require them to choose a new password on their next sign-in. To do this, set
 * `Permanent` to `false`.
 *
 * If the password is temporary, the user's `Status` becomes
 * `FORCE_CHANGE_PASSWORD`. When the user next tries to sign in, the
 * `InitiateAuth` or `AdminInitiateAuth` response includes the
 * `NEW_PASSWORD_REQUIRED` challenge. If the user doesn't sign in
 * before the temporary password expires, they can no longer sign in and you must repeat
 * this operation to set a temporary or permanent password for them.
 *
 * After the user sets a new password, or if you set a permanent password, their status
 * becomes `Confirmed`.
 *
 * `AdminSetUserPassword` can set a password for the user profile that Amazon Cognito
 * creates for third-party federated users. When you set a password, the federated user's
 * status changes from `EXTERNAL_PROVIDER` to `CONFIRMED`. A user in
 * this state can sign in as a federated user, and initiate authentication flows in the API
 * like a linked native user. They can also modify their password and attributes in
 * token-authenticated API requests like `ChangePassword` and
 * `UpdateUserAttributes`. As a best security practice and to keep users in
 * sync with your external IdP, don't set passwords on federated user profiles. To set up a
 * federated user for native sign-in with a linked native user, refer to Linking federated users to an existing user
 * profile.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserPassword: API.OperationMethod<AdminSetUserPasswordRequest & RegionInput, AdminSetUserPasswordResponse, AdminSetUserPasswordError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserSettingsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | UserNotFoundException | CommonErrors;
/**
 * *This action is no longer supported.* You can use it to configure
 * only SMS MFA. You can't use it to configure time-based one-time password (TOTP) software
 * token MFA.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserSettings: API.OperationMethod<AdminSetUserSettingsRequest & RegionInput, AdminSetUserSettingsResponse, AdminSetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateAuthEventFeedbackError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Provides the feedback for an authentication event generated by threat protection
 * features. Your response indicates that you think that the event either was from a valid
 * user or was an unwanted authentication attempt. This feedback improves the risk
 * evaluation decision for the user pool as part of Amazon Cognito threat protection.
 * To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * To train the threat-protection model to recognize trusted and untrusted sign-in
 * characteristics, configure threat protection in audit-only mode and provide a mechanism
 * for users or administrators to submit feedback. Your feedback can tell Amazon Cognito that a risk
 * rating was assigned at a level you don't agree with.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUpdateAuthEventFeedback: API.OperationMethod<AdminUpdateAuthEventFeedbackRequest & RegionInput, AdminUpdateAuthEventFeedbackResponse, AdminUpdateAuthEventFeedbackError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateDeviceStatusError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Updates the status of a user's device so that it is marked as remembered or not
 * remembered for the purpose of device authentication. Device authentication is a
 * "remember me" mechanism that silently completes sign-in from trusted devices with a
 * device key instead of a user-provided MFA code. This operation changes the status of a
 * device without deleting it, so you can enable it again later. For more information about
 * device authentication, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUpdateDeviceStatus: API.OperationMethod<AdminUpdateDeviceStatusRequest & RegionInput, AdminUpdateDeviceStatusResponse, AdminUpdateDeviceStatusError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateUserAttributesError = AliasExistsException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Updates the specified user's attributes. To delete an attribute from your user,
 * submit the attribute in your API request with a blank value.
 *
 * For custom attributes, you must add a `custom:` prefix to the attribute
 * name, for example `custom:department`.
 *
 * This operation can set a user's email address or phone number as verified and
 * permit immediate sign-in in user pools that require verification of these attributes. To
 * do this, set the `email_verified` or `phone_number_verified`
 * attribute to `true`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const adminUpdateUserAttributes: API.OperationMethod<AdminUpdateUserAttributesRequest & RegionInput, AdminUpdateUserAttributesResponse, AdminUpdateUserAttributesError, Credentials | HttpClient.HttpClient>;
export type AdminUserGlobalSignOutError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Invalidates the identity, access, and refresh tokens that Amazon Cognito issued to a user. Call
 * this operation with your administrative credentials when your user signs out of your
 * app. This results in the following behavior.
 *
 * - Amazon Cognito no longer accepts *token-authorized* user operations
 * that you authorize with a signed-out user's access tokens. For more information,
 * see Using the Amazon Cognito user pools API and user pool
 * endpoints.
 *
 * Amazon Cognito returns an `Access Token has been revoked` error when your
 * app attempts to authorize a user pools API request with a revoked access token
 * that contains the scope `aws.cognito.signin.user.admin`.
 *
 * - Amazon Cognito no longer accepts a signed-out user's ID token in a GetId request to an identity pool with
 * `ServerSideTokenCheck` enabled for its user pool IdP
 * configuration in CognitoIdentityProvider.
 *
 * - Amazon Cognito no longer accepts a signed-out user's refresh tokens in refresh
 * requests.
 *
 * Other requests might be valid until your user's token expires. This operation
 * doesn't clear the managed login session cookie. To clear the session for
 * a user who signed in with managed login or the classic hosted UI, direct their browser
 * session to the logout endpoint.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUserGlobalSignOut: API.OperationMethod<AdminUserGlobalSignOutRequest & RegionInput, AdminUserGlobalSignOutResponse, AdminUserGlobalSignOutError, Credentials | HttpClient.HttpClient>;
export type AssociateSoftwareTokenError = ConcurrentModificationException | ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | CommonErrors;
/**
 * Begins setup of time-based one-time password (TOTP) multi-factor authentication (MFA)
 * for a user, with a unique private key that Amazon Cognito generates and returns in the API
 * response. You can authorize an `AssociateSoftwareToken` request with either
 * the user's access token, or a session string from a challenge response that you received
 * from Amazon Cognito.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const associateSoftwareToken: API.OperationMethod<AssociateSoftwareTokenRequest & RegionInput, AssociateSoftwareTokenResponse, AssociateSoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type ChangePasswordError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidPasswordException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Changes the password for the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const changePassword: API.OperationMethod<ChangePasswordRequest & RegionInput, ChangePasswordResponse, ChangePasswordError, Credentials | HttpClient.HttpClient>;
export type CompleteWebAuthnRegistrationError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | WebAuthnChallengeNotFoundException | WebAuthnClientMismatchException | WebAuthnCredentialNotSupportedException | WebAuthnNotEnabledException | WebAuthnOriginNotAllowedException | WebAuthnRelyingPartyMismatchException | CommonErrors;
/**
 * Completes registration of a passkey authenticator for the currently signed-in
 * user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const completeWebAuthnRegistration: API.OperationMethod<CompleteWebAuthnRegistrationRequest & RegionInput, CompleteWebAuthnRegistrationResponse, CompleteWebAuthnRegistrationError, Credentials | HttpClient.HttpClient>;
export type ConfirmDeviceError = DeviceKeyExistsException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UsernameExistsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Confirms a device that a user wants to remember. A remembered device is a "Remember me
 * on this device" option for user pools that perform authentication with the device key of
 * a trusted device in the back end, instead of a user-provided MFA code. For more
 * information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmDevice: API.OperationMethod<ConfirmDeviceRequest & RegionInput, ConfirmDeviceResponse, ConfirmDeviceError, Credentials | HttpClient.HttpClient>;
export type ConfirmForgotPasswordError = CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * This public API operation accepts a confirmation code that Amazon Cognito sent to a user and
 * accepts a new password for that user.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmForgotPassword: API.OperationMethod<ConfirmForgotPasswordRequest & RegionInput, ConfirmForgotPasswordResponse, ConfirmForgotPasswordError, Credentials | HttpClient.HttpClient>;
export type ConfirmSignUpError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Confirms the account of a new user. This public API operation submits a code that
 * Amazon Cognito sent to your user when they signed up in your user pool. After your user enters
 * their code, they confirm ownership of the email address or phone number that they
 * provided, and their user account becomes active. Depending on your user pool
 * configuration, your users will receive their confirmation code in an email or SMS
 * message.
 *
 * Local users who signed up in your user pool are the only type of user who can confirm
 * sign-up with a code. Users who federate through an external identity provider (IdP) have
 * already been confirmed by their IdP.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmSignUp: API.OperationMethod<ConfirmSignUpRequest & RegionInput, ConfirmSignUpResponse, ConfirmSignUpError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = GroupExistsException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new group in the specified user pool. For more information about user pool
 * groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateIdentityProviderError = DuplicateProviderException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds a configuration and trust relationship between a third-party identity provider
 * (IdP) and a user pool. Amazon Cognito accepts sign-in with third-party identity providers through
 * managed login and OIDC relying-party libraries. For more information, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createIdentityProvider: API.OperationMethod<CreateIdentityProviderRequest & RegionInput, CreateIdentityProviderResponse, CreateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | LimitExceededException | ManagedLoginBrandingExistsException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new set of branding settings for a user pool style and associates it with an
 * app client. This operation is the programmatic option for the creation of a new style in
 * the branding editor.
 *
 * Provides values for UI customization in a `Settings` JSON object and image
 * files in an `Assets` array. To send the JSON object `Document`
 * type parameter in `Settings`, you might need to update to the most recent
 * version of your Amazon Web Services SDK. To create a new style with default settings, set
 * `UseCognitoProvidedValues` to `true` and don't provide
 * values for any other options.
 *
 * This operation has a 2-megabyte request-size limit and include the CSS settings and
 * image assets for your app client. Your branding settings might exceed 2MB in size. Amazon Cognito
 * doesn't require that you pass all parameters in one request and preserves existing
 * style settings that you don't specify. If your request is larger than 2MB, separate it
 * into multiple requests, each with a size smaller than the limit.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createManagedLoginBranding: API.OperationMethod<CreateManagedLoginBrandingRequest & RegionInput, CreateManagedLoginBrandingResponse, CreateManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type CreateResourceServerError = InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new OAuth2.0 resource server and defines custom scopes within it. Resource
 * servers are associated with custom scopes and machine-to-machine (M2M) authorization.
 * For more information, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createResourceServer: API.OperationMethod<CreateResourceServerRequest & RegionInput, CreateResourceServerResponse, CreateResourceServerError, Credentials | HttpClient.HttpClient>;
export type CreateTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TermsExistsException | TooManyRequestsException | CommonErrors;
/**
 * Creates terms documents for the requested app client. When Terms and conditions and
 * Privacy policy documents are configured, the app client displays links to them in the
 * sign-up page of managed login for the app client.
 *
 * You can provide URLs for terms documents in the languages that are supported by managed login localization. Amazon Cognito directs users to the terms documents for
 * their current language, with fallback to `default` if no document exists for
 * the language.
 *
 * Each request accepts one type of terms document and a map of language-to-link for that
 * document type. You must provide both types of terms documents in at least one language
 * before Amazon Cognito displays your terms documents. Supply each type in separate
 * requests.
 *
 * For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createTerms: API.OperationMethod<CreateTermsRequest & RegionInput, CreateTermsResponse, CreateTermsError, Credentials | HttpClient.HttpClient>;
export type CreateUserImportJobError = InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a user import job. You can import users into user pools from a comma-separated
 * values (CSV) file without adding Amazon Cognito MAU costs to your Amazon Web Services bill.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserImportJob: API.OperationMethod<CreateUserImportJobRequest & RegionInput, CreateUserImportJobResponse, CreateUserImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolError = FeatureUnavailableInTierException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | TierChangeNotAllowedException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Creates a new Amazon Cognito user pool. This operation sets basic and advanced configuration
 * options.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPool: API.OperationMethod<CreateUserPoolRequest & RegionInput, CreateUserPoolResponse, CreateUserPoolError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolClientError = FeatureUnavailableInTierException | InternalErrorException | InvalidOAuthFlowException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | ScopeDoesNotExistException | TooManyRequestsException | CommonErrors;
/**
 * Creates an app client in a user pool. This operation sets basic and advanced
 * configuration options.
 *
 * Unlike app clients created in the console, Amazon Cognito doesn't automatically assign a
 * branding style to app clients that you configure with this API operation. Managed login and classic hosted UI pages aren't
 * available for your client until after you apply a branding style.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolClient: API.OperationMethod<CreateUserPoolClientRequest & RegionInput, CreateUserPoolClientResponse, CreateUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolDomainError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * A user pool domain hosts managed login, an authorization server and web server for
 * authentication in your application. This operation creates a new user pool prefix domain
 * or custom domain and sets the managed login branding version. Set the branding version
 * to `1` for hosted UI (classic) or `2` for managed login. When you
 * choose a custom domain, you must provide an SSL certificate in the US East (N. Virginia)
 * Amazon Web Services Region in your request.
 *
 * Your prefix domain might take up to one minute to take effect. Your custom domain is
 * online within five minutes, but it can take up to one hour to distribute your SSL
 * certificate.
 *
 * For more information about adding a custom domain to your user pool, see Configuring a user pool domain.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolDomain: API.OperationMethod<CreateUserPoolDomainRequest & RegionInput, CreateUserPoolDomainResponse, CreateUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolReplicaError = FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Creates a replica of an existing user pool in a specified Amazon Web Services Region. The replica
 * enables multi-region replication for high availability and disaster recovery. To create
 * a replica, you must have permissions to create user pools in the target Region.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolReplica: API.OperationMethod<CreateUserPoolReplicaRequest & RegionInput, CreateUserPoolReplicaResponse, CreateUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a group from the specified user pool. When you delete a group, that group no
 * longer contributes to users' `cognito:preferred_group` or
 * `cognito:groups` claims, and no longer influence access-control decision
 * that are based on group membership. For more information about user pool groups, see
 * Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityProviderError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | UnsupportedIdentityProviderException | CommonErrors;
/**
 * Deletes a user pool identity provider (IdP). After you delete an IdP, users can no
 * longer sign in to your user pool through that IdP. For more information about user pool
 * IdPs, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteIdentityProvider: API.OperationMethod<DeleteIdentityProviderRequest & RegionInput, DeleteIdentityProviderResponse, DeleteIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a managed login branding style. When you delete a style, you delete the
 * branding association for an app client. When an app client doesn't have a style
 * assigned, your managed login pages for that app client are nonfunctional until you
 * create a new style or switch the domain branding version.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteManagedLoginBranding: API.OperationMethod<DeleteManagedLoginBrandingRequest & RegionInput, DeleteManagedLoginBrandingResponse, DeleteManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a resource server. After you delete a resource server, users can no longer
 * generate access tokens with scopes that are associate with that resource server.
 *
 * Resource servers are associated with custom scopes and machine-to-machine (M2M)
 * authorization. For more information, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteResourceServer: API.OperationMethod<DeleteResourceServerRequest & RegionInput, DeleteResourceServerResponse, DeleteResourceServerError, Credentials | HttpClient.HttpClient>;
export type DeleteTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the terms documents with the requested ID from your app client.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteTerms: API.OperationMethod<DeleteTermsRequest & RegionInput, DeleteTermsResponse, DeleteTermsError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes the profile of the currently signed-in user. A deleted user profile can no
 * longer be used to sign in and can't be restored.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserAttributesError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes attributes from the currently signed-in user. For example, your application
 * can submit a request to this operation when a user wants to remove their
 * `birthdate` attribute value.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteUserAttributes: API.OperationMethod<DeleteUserAttributesRequest & RegionInput, DeleteUserAttributesResponse, DeleteUserAttributesError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserImportInProgressException | CommonErrors;
/**
 * Deletes a user pool. After you delete a user pool, users can no longer sign in to any
 * associated applications.
 *
 * When you delete a user pool, it's no longer visible or operational in your Amazon Web Services account. Amazon Cognito retains deleted user pools in an inactive state for 14
 * days, then begins a cleanup process that fully removes them from Amazon Web Services systems. In case
 * of accidental deletion, contact Amazon Web Services Support within 14 days for restoration
 * assistance.
 *
 * Amazon Cognito begins full deletion of all resources from deleted user pools after 14 days. In
 * the case of large user pools, the cleanup process might take significant additional time
 * before all user data is permanently deleted.
 */
export declare const deleteUserPool: API.OperationMethod<DeleteUserPoolRequest & RegionInput, DeleteUserPoolResponse, DeleteUserPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolClientError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a user pool app client. After you delete an app client, users can no longer
 * sign in to the associated application.
 */
export declare const deleteUserPoolClient: API.OperationMethod<DeleteUserPoolClientRequest & RegionInput, DeleteUserPoolClientResponse, DeleteUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolClientSecretError = InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a specific client secret from a user pool app client. You cannot delete the last remaining secret for an app client.
 */
export declare const deleteUserPoolClientSecret: API.OperationMethod<DeleteUserPoolClientSecretRequest & RegionInput, DeleteUserPoolClientSecretResponse, DeleteUserPoolClientSecretError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolDomainError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool ID and domain identifier, deletes a user pool domain. After you
 * delete a user pool domain, your managed login pages and authorization server are no
 * longer available.
 */
export declare const deleteUserPoolDomain: API.OperationMethod<DeleteUserPoolDomainRequest & RegionInput, DeleteUserPoolDomainResponse, DeleteUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolReplicaError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a secondary replica user pool. You can only delete replicas that are in the
 * INACTIVE status. This operation must be called from the primary Region.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteUserPoolReplica: API.OperationMethod<DeleteUserPoolReplicaRequest & RegionInput, DeleteUserPoolReplicaResponse, DeleteUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type DeleteWebAuthnCredentialError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a registered passkey, or WebAuthn, authenticator for the currently signed-in
 * user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteWebAuthnCredential: API.OperationMethod<DeleteWebAuthnCredentialRequest & RegionInput, DeleteWebAuthnCredentialResponse, DeleteWebAuthnCredentialError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityProviderError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and identity provider (IdP) name, returns details about the
 * IdP.
 */
export declare const describeIdentityProvider: API.OperationMethod<DescribeIdentityProviderRequest & RegionInput, DescribeIdentityProviderResponse, DescribeIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedLoginBrandingError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the ID of a managed login branding style, returns detailed information about the
 * style.
 */
export declare const describeManagedLoginBranding: API.OperationMethod<DescribeManagedLoginBrandingRequest & RegionInput, DescribeManagedLoginBrandingResponse, DescribeManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedLoginBrandingByClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the ID of a user pool app client, returns detailed information about the style
 * assigned to the app client.
 */
export declare const describeManagedLoginBrandingByClient: API.OperationMethod<DescribeManagedLoginBrandingByClientRequest & RegionInput, DescribeManagedLoginBrandingByClientResponse, DescribeManagedLoginBrandingByClientError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describes a resource server. For more information about resource servers, see Access control with resource servers.
 */
export declare const describeResourceServer: API.OperationMethod<DescribeResourceServerRequest & RegionInput, DescribeResourceServerResponse, DescribeResourceServerError, Credentials | HttpClient.HttpClient>;
export type DescribeRiskConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Given an app client or user pool ID where threat protection is configured, describes
 * the risk configuration. This operation returns details about adaptive authentication,
 * compromised credentials, and IP-address allow- and denylists. For more information about
 * threat protection, see Threat protection.
 */
export declare const describeRiskConfiguration: API.OperationMethod<DescribeRiskConfigurationRequest & RegionInput, DescribeRiskConfigurationResponse, DescribeRiskConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTermsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details for the requested terms documents ID. For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeTerms: API.OperationMethod<DescribeTermsRequest & RegionInput, DescribeTermsResponse, DescribeTermsError, Credentials | HttpClient.HttpClient>;
export type DescribeTermsByClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details for the terms documents that are associated with an app client,
 * identified by the app client ID, user pool ID, and terms name. For
 * more information, see Terms documents.
 *
 * To call `DescribeTermsByClient`, you must have the
 * `cognito-idp:DescribeTermsByClient` Identity and Access Management (IAM) permission. An IAM
 * policy that denies `cognito-idp:DescribeTerms` also denies requests to
 * `DescribeTermsByClient`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeTermsByClient: API.OperationMethod<DescribeTermsByClientRequest & RegionInput, DescribeTermsByClientResponse, DescribeTermsByClientError, Credentials | HttpClient.HttpClient>;
export type DescribeUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describes a user import job. For more information about user CSV import, see Importing users from a CSV file.
 */
export declare const describeUserImportJob: API.OperationMethod<DescribeUserImportJobRequest & RegionInput, DescribeUserImportJobResponse, DescribeUserImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Given a user pool ID, returns configuration information. This operation is useful when
 * you want to inspect an existing user pool and programmatically replicate the
 * configuration to another user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPool: API.OperationMethod<DescribeUserPoolRequest & RegionInput, DescribeUserPoolResponse, DescribeUserPoolError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given an app client ID, returns configuration information. This operation is useful
 * when you want to inspect an existing app client and programmatically replicate the
 * configuration to another app client. For more information about app clients, see App clients.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPoolClient: API.OperationMethod<DescribeUserPoolClientRequest & RegionInput, DescribeUserPoolClientResponse, DescribeUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolDomainError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool domain name, returns information about the domain
 * configuration.
 *
 * This operation doesn't return results when you query a prefix domain in a
 * secondary Region. Prefix domains are Region-specific and can only be described in
 * the Region where they were created. To describe a prefix domain for a replica user
 * pool, make the request to the primary Region's endpoint.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPoolDomain: API.OperationMethod<DescribeUserPoolDomainRequest & RegionInput, DescribeUserPoolDomainResponse, DescribeUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type ForgetDeviceError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given a device key, deletes a remembered device as the currently signed-in user. For
 * more information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const forgetDevice: API.OperationMethod<ForgetDeviceRequest & RegionInput, ForgetDeviceResponse, ForgetDeviceError, Credentials | HttpClient.HttpClient>;
export type ForgotPasswordError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Sends a password-reset confirmation code to the email address or phone number of the
 * requested username. The message delivery method is determined by the user's
 * available attributes and the `AccountRecoverySetting` configuration of the
 * user pool.
 *
 * For the `Username` parameter, you can use the username or an email, phone,
 * or preferred username alias.
 *
 * If neither a verified phone number nor a verified email exists, Amazon Cognito responds with an
 * `InvalidParameterException` error . If your app client has a client
 * secret and you don't provide a `SECRET_HASH` parameter, this API returns
 * `NotAuthorizedException`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const forgotPassword: API.OperationMethod<ForgotPasswordRequest & RegionInput, ForgotPasswordResponse, ForgotPasswordError, Credentials | HttpClient.HttpClient>;
export type GetClientTokenError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Issues an access token for machine-to-machine (M2M) authorization. Your app client
 * provides its client ID and secret, and receives an access token that authorizes requests
 * to your resource servers.
 *
 * To use this operation, you must configure the app client with a client secret and
 * enable the `ALLOW_CLIENT_TOKEN_AUTH` authentication flow. The
 * `ALLOW_CLIENT_TOKEN_AUTH` flow is mutually exclusive with user authentication
 * flows. It must be the only authentication flow that you configure for the app client. For
 * more information, see Scopes, M2M, and resource servers.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getClientToken: API.OperationMethod<GetClientTokenRequest & RegionInput, GetClientTokenResponse, GetClientTokenError, Credentials | HttpClient.HttpClient>;
export type GetCSVHeaderError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, generates a comma-separated value (CSV) list populated with
 * available user attributes in the user pool. This list is the header for the CSV file
 * that determines the users in a user import job. Save the content of
 * `CSVHeader` in the response as a `.csv` file and populate it
 * with the usernames and attributes of users that you want to import. For more information
 * about CSV user import, see Importing users from a CSV file.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getCSVHeader: API.OperationMethod<GetCSVHeaderRequest & RegionInput, GetCSVHeaderResponse, GetCSVHeaderError, Credentials | HttpClient.HttpClient>;
export type GetDeviceError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given a device key, returns information about a remembered device for the current
 * user. For more information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getDevice: API.OperationMethod<GetDeviceRequest & RegionInput, GetDeviceResponse, GetDeviceError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and a group name, returns information about the user
 * group.
 *
 * For more information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest & RegionInput, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetIdentityProviderByIdentifierError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the identifier of an identity provider (IdP), for example
 * `examplecorp`, returns information about the user pool configuration for
 * that IdP. For more information about IdPs, see Third-party IdP sign-in.
 */
export declare const getIdentityProviderByIdentifier: API.OperationMethod<GetIdentityProviderByIdentifierRequest & RegionInput, GetIdentityProviderByIdentifierResponse, GetIdentityProviderByIdentifierError, Credentials | HttpClient.HttpClient>;
export type GetLogDeliveryConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns the logging configuration. User pools can export
 * message-delivery error and threat-protection activity logs to external Amazon Web Services services. For more information, see Exporting user pool logs.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getLogDeliveryConfiguration: API.OperationMethod<GetLogDeliveryConfigurationRequest & RegionInput, GetLogDeliveryConfigurationResponse, GetLogDeliveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedLimitError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the current provisioned limit for a specific API category.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getProvisionedLimit: API.OperationMethod<GetProvisionedLimitRequest & RegionInput, GetProvisionedLimitResponse, GetProvisionedLimitError, Credentials | HttpClient.HttpClient>;
export type GetSigningCertificateError = InternalErrorException | InvalidParameterException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool ID, returns the signing certificate for SAML 2.0 federation.
 *
 * Issued certificates are valid for 10 years from the date of issue. Amazon Cognito issues and
 * assigns a new signing certificate annually. This renewal process returns a new value in
 * the response to `GetSigningCertificate`, but doesn't invalidate the original
 * certificate.
 *
 * For more information, see Signing SAML requests.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getSigningCertificate: API.OperationMethod<GetSigningCertificateRequest & RegionInput, GetSigningCertificateResponse, GetSigningCertificateError, Credentials | HttpClient.HttpClient>;
export type GetTokensFromRefreshTokenError = ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | RefreshTokenReuseException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Given a refresh token, issues new ID, access, and optionally refresh tokens for the
 * user who owns the submitted token. This operation issues a new refresh token and
 * invalidates the original refresh token after an optional grace period when refresh token
 * rotation is enabled. If refresh token rotation is disabled, issues new ID and access
 * tokens only.
 */
export declare const getTokensFromRefreshToken: API.OperationMethod<GetTokensFromRefreshTokenRequest & RegionInput, GetTokensFromRefreshTokenResponse, GetTokensFromRefreshTokenError, Credentials | HttpClient.HttpClient>;
export type GetUICustomizationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID or app client, returns information about classic hosted UI
 * branding that you applied, if any. Returns user-pool level branding information if no
 * app client branding is applied, or if you don't specify an app client ID. Returns
 * an empty object if you haven't applied hosted UI branding to either the client or
 * the user pool. For more information, see Hosted UI (classic) branding.
 */
export declare const getUICustomization: API.OperationMethod<GetUICustomizationRequest & RegionInput, GetUICustomizationResponse, GetUICustomizationError, Credentials | HttpClient.HttpClient>;
export type GetUserError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Gets user attributes and and MFA settings for the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getUser: API.OperationMethod<GetUserRequest & RegionInput, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetUserAttributeVerificationCodeError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given an attribute name, sends a user attribute verification code for the specified
 * attribute name to the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const getUserAttributeVerificationCode: API.OperationMethod<GetUserAttributeVerificationCodeRequest & RegionInput, GetUserAttributeVerificationCodeResponse, GetUserAttributeVerificationCodeError, Credentials | HttpClient.HttpClient>;
export type GetUserAuthFactorsError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Lists the authentication options for the currently signed-in user. Returns the
 * following:
 *
 * - The user's multi-factor authentication (MFA) preferences.
 *
 * - The user's options for choice-based authentication with the
 * `USER_AUTH` flow.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getUserAuthFactors: API.OperationMethod<GetUserAuthFactorsRequest & RegionInput, GetUserAuthFactorsResponse, GetUserAuthFactorsError, Credentials | HttpClient.HttpClient>;
export type GetUserPoolClientSessionConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the session configuration for a user pool app client. If you have never
 * called `SetUserPoolClientSessionConfiguration` for the app client, this
 * operation returns the default SSO session maximum validity of `60`
 * minutes.
 */
export declare const getUserPoolClientSessionConfiguration: API.OperationMethod<GetUserPoolClientSessionConfigurationRequest & RegionInput, GetUserPoolClientSessionConfigurationResponse, GetUserPoolClientSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetUserPoolMfaConfigError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns configuration for sign-in with WebAuthn authenticators
 * and for multi-factor authentication (MFA). This operation describes the
 * following:
 *
 * - The WebAuthn relying party (RP) ID and user-verification settings.
 *
 * - The required, optional, or disabled state of MFA for all user pool
 * users.
 *
 * - The message templates for email and SMS MFA.
 *
 * - The enabled or disabled state of time-based one-time password (TOTP)
 * MFA.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getUserPoolMfaConfig: API.OperationMethod<GetUserPoolMfaConfigRequest & RegionInput, GetUserPoolMfaConfigResponse, GetUserPoolMfaConfigError, Credentials | HttpClient.HttpClient>;
export type GetUserPoolSessionConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the session tracking configuration for a user pool, including whether session
 * tracking is enabled and the pool-wide maximum number of active token sessions for
 * each user. If you have never called `SetUserPoolSessionConfiguration` for the
 * user pool, this operation returns the default values: `UserSessionTracking` as
 * `DISABLED` and a `MaxPerUser` value of `20`.
 */
export declare const getUserPoolSessionConfiguration: API.OperationMethod<GetUserPoolSessionConfigurationRequest & RegionInput, GetUserPoolSessionConfigurationResponse, GetUserPoolSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GlobalSignOutError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | CommonErrors;
/**
 * Invalidates the identity, access, and refresh tokens that Amazon Cognito issued to a user. Call
 * this operation when your user signs out of your app. This results in the following
 * behavior.
 *
 * - Amazon Cognito no longer accepts *token-authorized* user operations
 * that you authorize with a signed-out user's access tokens. For more information,
 * see Using the Amazon Cognito user pools API and user pool
 * endpoints.
 *
 * Amazon Cognito returns an `Access Token has been revoked` error when your
 * app attempts to authorize a user pools API request with a revoked access token
 * that contains the scope `aws.cognito.signin.user.admin`.
 *
 * - Amazon Cognito no longer accepts a signed-out user's ID token in a GetId request to an identity pool with
 * `ServerSideTokenCheck` enabled for its user pool IdP
 * configuration in CognitoIdentityProvider.
 *
 * - Amazon Cognito no longer accepts a signed-out user's refresh tokens in refresh
 * requests.
 *
 * Other requests might be valid until your user's token expires. This operation
 * doesn't clear the managed login session cookie. To clear the session for
 * a user who signed in with managed login or the classic hosted UI, direct their browser
 * session to the logout endpoint.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const globalSignOut: API.OperationMethod<GlobalSignOutRequest & RegionInput, GlobalSignOutResponse, GlobalSignOutError, Credentials | HttpClient.HttpClient>;
export type InitiateAuthError = FeatureUnavailableInTierException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedOperationException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Declares an authentication flow and initiates sign-in for a user in the Amazon Cognito user
 * directory. Amazon Cognito might respond with an additional challenge or an
 * `AuthenticationResult` that contains the outcome of a successful
 * authentication. You can't sign in a user with a federated IdP with
 * `InitiateAuth`. For more information, see Authentication.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const initiateAuth: API.OperationMethod<InitiateAuthRequest & RegionInput, InitiateAuthResponse, InitiateAuthError, Credentials | HttpClient.HttpClient>;
export type ListDevicesError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Lists the devices that Amazon Cognito has registered to the currently signed-in user. For more
 * information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const listDevices: API.OperationMethod<ListDevicesRequest & RegionInput, ListDevicesResponse, ListDevicesError, Credentials | HttpClient.HttpClient>;
export type ListGroupsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns user pool groups and their details.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, GroupType>;
export type ListIdentityProvidersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns information about configured identity providers (IdPs).
 * For more information about IdPs, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listIdentityProviders: API.PaginatedOperationMethod<ListIdentityProvidersRequest & RegionInput, ListIdentityProvidersResponse, ListIdentityProvidersError, Credentials | HttpClient.HttpClient, ProviderDescription>;
export type ListResourceServersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns all resource servers and their details. For more
 * information about resource servers, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listResourceServers: API.PaginatedOperationMethod<ListResourceServersRequest & RegionInput, ListResourceServersResponse, ListResourceServersError, Credentials | HttpClient.HttpClient, ResourceServerType>;
export type ListTagsForResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags that are assigned to an Amazon Cognito user pool. For more information, see
 * Tagging
 * resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTermsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details about all terms documents for the requested user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listTerms: API.OperationMethod<ListTermsRequest & RegionInput, ListTermsResponse, ListTermsError, Credentials | HttpClient.HttpClient>;
export type ListUserImportJobsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns user import jobs and their details. Import jobs are
 * retained in user pool configuration so that you can stage, stop, start, review, and
 * delete them. For more information about user import, see Importing users from a CSV file.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserImportJobs: API.OperationMethod<ListUserImportJobsRequest & RegionInput, ListUserImportJobsResponse, ListUserImportJobsError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolClientsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, lists app clients. App clients are sets of rules for the access
 * that you want a user pool to grant to one application. For more information, see App clients.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPoolClients: API.PaginatedOperationMethod<ListUserPoolClientsRequest & RegionInput, ListUserPoolClientsResponse, ListUserPoolClientsError, Credentials | HttpClient.HttpClient, UserPoolClientDescription>;
export type ListUserPoolClientSecretsError = InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all client secrets associated with a user pool app client. Returns metadata about the secrets. The response does not include pagination tokens as there are only 2 secrets at any given time and we return both with every ListUserPoolClientSecrets call. For security reasons, the response never reveals the actual secret value in ClientSecretValue.
 */
export declare const listUserPoolClientSecrets: API.OperationMethod<ListUserPoolClientSecretsRequest & RegionInput, ListUserPoolClientSecretsResponse, ListUserPoolClientSecretsError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolReplicasError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all replicas for a user pool, including both primary and secondary replicas. We
 * recommend using pagination to ensure that the operation returns quickly and
 * successfully.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPoolReplicas: API.OperationMethod<ListUserPoolReplicasRequest & RegionInput, ListUserPoolReplicasResponse, ListUserPoolReplicasError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | TooManyRequestsException | CommonErrors;
/**
 * Lists user pools and their details in the current Amazon Web Services account.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPools: API.PaginatedOperationMethod<ListUserPoolsRequest & RegionInput, ListUserPoolsResponse, ListUserPoolsError, Credentials | HttpClient.HttpClient, UserPoolDescriptionType>;
export type ListUsersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns a list of users and their basic details in a user
 * pool.
 *
 * This operation is eventually consistent. You might experience a delay before results
 * are up-to-date. To validate the existence or configuration of an individual user, use
 * `AdminGetUser`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, UserType>;
export type ListUserSessionsError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Lists the active sessions for the currently signed-in user. Amazon Cognito authorizes this
 * operation with the user's access token and returns all of the user's active sessions
 * across every app client in the user pool, including both token sessions and SSO
 * sessions. The `IsCurrentSession` field identifies the session that the
 * calling access token belongs to. The results are eventually consistent, and new
 * sessions are typically included within a few seconds.
 */
export declare const listUserSessions: API.OperationMethod<ListUserSessionsRequest & RegionInput, ListUserSessionsResponse, ListUserSessionsError, Credentials | HttpClient.HttpClient>;
export type ListUsersInGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and a group name, returns a list of users in the group. For more
 * information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUsersInGroup: API.PaginatedOperationMethod<ListUsersInGroupRequest & RegionInput, ListUsersInGroupResponse, ListUsersInGroupError, Credentials | HttpClient.HttpClient, UserType>;
export type ListWebAuthnCredentialsError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | CommonErrors;
/**
 * Generates a list of the currently signed-in user's registered passkey, or
 * WebAuthn, credentials.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const listWebAuthnCredentials: API.OperationMethod<ListWebAuthnCredentialsRequest & RegionInput, ListWebAuthnCredentialsResponse, ListWebAuthnCredentialsError, Credentials | HttpClient.HttpClient>;
export type ResendConfirmationCodeError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Resends the code that confirms a new account for a user who has signed up in your user
 * pool. Amazon Cognito sends confirmation codes to the user attribute in the
 * `AutoVerifiedAttributes` property of your user pool. When you prompt new
 * users for the confirmation code, include a "Resend code" option that generates a call to
 * this API operation.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const resendConfirmationCode: API.OperationMethod<ResendConfirmationCodeRequest & RegionInput, ResendConfirmationCodeResponse, ResendConfirmationCodeError, Credentials | HttpClient.HttpClient>;
export type RespondToAuthChallengeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Some API operations in a user pool generate a challenge, like a prompt for an MFA
 * code, for device authentication that bypasses MFA, or for a custom authentication
 * challenge. A `RespondToAuthChallenge` API request provides the answer to that
 * challenge, like a code or a secure remote password (SRP). The parameters of a response
 * to an authentication challenge vary with the type of challenge.
 *
 * For more information about custom authentication challenges, see Custom
 * authentication challenge Lambda triggers.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const respondToAuthChallenge: API.OperationMethod<RespondToAuthChallengeRequest & RegionInput, RespondToAuthChallengeResponse, RespondToAuthChallengeError, Credentials | HttpClient.HttpClient>;
export type RevokeTokenError = ForbiddenException | InternalErrorException | InvalidParameterException | OperationNotEnabledException | TooManyRequestsException | UnauthorizedException | UnsupportedOperationException | UnsupportedTokenTypeException | CommonErrors;
/**
 * Revokes all of the access tokens generated by, and at the same time as, the specified
 * refresh token. After a token is revoked, you can't use the revoked token to access Amazon Cognito
 * user APIs, or to authorize access to your resource server.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const revokeToken: API.OperationMethod<RevokeTokenRequest & RegionInput, RevokeTokenResponse, RevokeTokenError, Credentials | HttpClient.HttpClient>;
export type RevokeUserSessionError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Revokes a specific session for the currently signed-in user. Amazon Cognito authorizes this
 * operation with the user's access token, revokes all refresh and access tokens that are
 * associated with the session, and deletes the session record. You can't revoke the
 * session that the calling access token belongs to.
 */
export declare const revokeUserSession: API.OperationMethod<RevokeUserSessionRequest & RegionInput, RevokeUserSessionResponse, RevokeUserSessionError, Credentials | HttpClient.HttpClient>;
export type SetLogDeliveryConfigurationError = FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets up or modifies the logging configuration of a user pool. User pools can export
 * user notification logs and, when threat protection is active, user-activity logs. For
 * more information, see Exporting user
 * pool logs.
 */
export declare const setLogDeliveryConfiguration: API.OperationMethod<SetLogDeliveryConfigurationRequest & RegionInput, SetLogDeliveryConfigurationResponse, SetLogDeliveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetRiskConfigurationError = CodeDeliveryFailureException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Configures threat protection for a user pool or app client. Sets configuration for the
 * following.
 *
 * - Responses to risks with adaptive authentication
 *
 * - Responses to vulnerable passwords with compromised-credentials
 * detection
 *
 * - Notifications to users who have had risky activity detected
 *
 * - IP-address denylist and allowlist
 *
 * To set the risk configuration for the user pool to defaults, send this request with
 * only the `UserPoolId` parameter. To reset the threat protection settings of
 * an app client to be inherited from the user pool, send `UserPoolId` and
 * `ClientId` parameters only. To change threat protection to audit-only or
 * off, update the value of `UserPoolAddOns` in an `UpdateUserPool`
 * request. To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * In secondary regions for user pools with multi-region replication, only the
 * `SourceARN` and `From` attributes of
 * `NotifyConfiguration` can be modified to configure region-specific SES
 * integration. All other risk configuration settings must match the existing values to
 * maintain consistency across replicas.
 */
export declare const setRiskConfiguration: API.OperationMethod<SetRiskConfigurationRequest & RegionInput, SetRiskConfigurationResponse, SetRiskConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetUICustomizationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Configures UI branding settings for domains with the hosted UI (classic) branding
 * version. Your user pool must have a domain. Configure a domain with .
 *
 * Set the default configuration for all clients with a `ClientId` of
 * `ALL`. When the `ClientId` value is an app client ID, the
 * settings you pass in this request apply to that app client and override the default
 * `ALL` configuration.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const setUICustomization: API.OperationMethod<SetUICustomizationRequest & RegionInput, SetUICustomizationResponse, SetUICustomizationError, Credentials | HttpClient.HttpClient>;
export type SetUserMFAPreferenceError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Set the user's multi-factor authentication (MFA) method preference, including which
 * MFA factors are activated and if any are preferred. Only one factor can be set as
 * preferred. The preferred MFA factor will be used to authenticate a user if multiple
 * factors are activated. If multiple options are activated and no preference is set, a
 * challenge to choose an MFA option will be returned during sign-in. If an MFA type is
 * activated for a user, the user will be prompted for MFA during all sign-in attempts
 * unless device tracking is turned on and the device has been trusted. If you want MFA to
 * be applied selectively based on the assessed risk level of sign-in attempts, deactivate
 * MFA for users and turn on Adaptive Authentication for the user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const setUserMFAPreference: API.OperationMethod<SetUserMFAPreferenceRequest & RegionInput, SetUserMFAPreferenceResponse, SetUserMFAPreferenceError, Credentials | HttpClient.HttpClient>;
export type SetUserPoolClientSessionConfigurationError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets the session configuration for a user pool app client. The configurable
 * client-level setting is the maximum validity period for silent reuse of an SSO session.
 * This operation performs a full replacement of the client-level session configuration;
 * every request parameter is required, and session tracking must be enabled for the user
 * pool. The user pool must be in the Essentials or Plus tier. Otherwise, this operation
 * returns a `FeatureUnavailableInTierException`.
 */
export declare const setUserPoolClientSessionConfiguration: API.OperationMethod<SetUserPoolClientSessionConfigurationRequest & RegionInput, SetUserPoolClientSessionConfigurationResponse, SetUserPoolClientSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetUserPoolMfaConfigError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets user pool multi-factor authentication (MFA) and passkey configuration. For more
 * information about user pool MFA, see Adding MFA. For more information about WebAuthn passkeys see Authentication flows.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const setUserPoolMfaConfig: API.OperationMethod<SetUserPoolMfaConfigRequest & RegionInput, SetUserPoolMfaConfigResponse, SetUserPoolMfaConfigError, Credentials | HttpClient.HttpClient>;
export type SetUserPoolSessionConfigurationError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enables or disables session tracking for a user pool, and sets the pool-wide maximum
 * number of active token sessions that each user can have. This operation performs a
 * full replacement of the pool-level session configuration; every request parameter is
 * required. The user pool must be in the Essentials or Plus tier. Otherwise, this
 * operation returns a `FeatureUnavailableInTierException`.
 */
export declare const setUserPoolSessionConfiguration: API.OperationMethod<SetUserPoolSessionConfigurationRequest & RegionInput, SetUserPoolSessionConfigurationResponse, SetUserPoolSessionConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetUserSettingsError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * *This action is no longer supported.* You can use it to configure
 * only SMS MFA. You can't use it to configure time-based one-time password (TOTP) software
 * token or email MFA.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const setUserSettings: API.OperationMethod<SetUserSettingsRequest & RegionInput, SetUserSettingsResponse, SetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type SignUpError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UsernameExistsException | CommonErrors;
/**
 * Registers a user with an app client and requests a user name, password, and user
 * attributes in the user pool.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * You might receive a `LimitExceeded` exception in response to this request
 * if you have exceeded a rate quota for email or SMS messages, and if your user pool
 * automatically verifies email addresses or phone numbers. When you get this exception in
 * the response, the user is successfully created and is in an `UNCONFIRMED`
 * state.
 */
export declare const signUp: API.OperationMethod<SignUpRequest & RegionInput, SignUpResponse, SignUpError, Credentials | HttpClient.HttpClient>;
export type StartUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Instructs your user pool to start importing users from a CSV file that contains their
 * usernames and attributes. For more information about importing users from a CSV file,
 * see Importing users from a CSV file.
 */
export declare const startUserImportJob: API.OperationMethod<StartUserImportJobRequest & RegionInput, StartUserImportJobResponse, StartUserImportJobError, Credentials | HttpClient.HttpClient>;
export type StartWebAuthnRegistrationError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | WebAuthnConfigurationMissingException | WebAuthnNotEnabledException | CommonErrors;
/**
 * Requests credential creation options from your user pool for the currently signed-in
 * user. Returns information about the user pool, the user profile, and authentication
 * requirements. Users must provide this information in their request to enroll your
 * application with their passkey provider.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const startWebAuthnRegistration: API.OperationMethod<StartWebAuthnRegistrationRequest & RegionInput, StartWebAuthnRegistrationResponse, StartWebAuthnRegistrationError, Credentials | HttpClient.HttpClient>;
export type StopUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Instructs your user pool to stop a running job that's importing users from a CSV
 * file that contains their usernames and attributes. For more information about importing
 * users from a CSV file, see Importing users from a CSV file.
 */
export declare const stopUserImportJob: API.OperationMethod<StopUserImportJobRequest & RegionInput, StopUserImportJobResponse, StopUserImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Assigns a set of tags to an Amazon Cognito user pool. A tag is a label that you can use to
 * categorize and manage user pools in different ways, such as by purpose, owner,
 * environment, or other criteria.
 *
 * Each tag consists of a key and value, both of which you define. A key is a general
 * category for more specific values. For example, if you have two versions of a user pool,
 * one for testing and another for production, you might assign an `Environment`
 * tag key to both user pools. The value of this key might be `Test` for one
 * user pool, and `Production` for the other.
 *
 * Tags are useful for cost tracking and access control. You can activate your tags so
 * that they appear on the Billing and Cost Management console, where you can track the
 * costs associated with your user pools. In an Identity and Access Management policy, you can constrain
 * permissions for user pools based on specific tags or tag values.
 *
 * You can use this action up to 5 times per second, per account. A user pool can have as
 * many as 50 tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given tag IDs that you previously assigned to a user pool, removes them.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthEventFeedbackError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Provides the feedback for an authentication event generated by threat protection
 * features. The user's response indicates that you think that the event either was from a
 * valid user or was an unwanted authentication attempt. This feedback improves the risk
 * evaluation decision for the user pool as part of Amazon Cognito threat protection.
 * To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * This operation requires a `FeedbackToken` that Amazon Cognito generates and adds to
 * notification emails when users have potentially suspicious authentication events. Users
 * invoke this operation when they select the link that corresponds to
 * `{one-click-link-valid}` or `{one-click-link-invalid}` in your
 * notification template. Because `FeedbackToken` is a required parameter, you
 * can't make requests to `UpdateAuthEventFeedback` without the contents of
 * the notification email message.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const updateAuthEventFeedback: API.OperationMethod<UpdateAuthEventFeedbackRequest & RegionInput, UpdateAuthEventFeedbackResponse, UpdateAuthEventFeedbackError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceStatusError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Updates the status of a the currently signed-in user's device so that it is
 * marked as remembered or not remembered for the purpose of device authentication. Device
 * authentication is a "remember me" mechanism that silently completes sign-in from trusted
 * devices with a device key instead of a user-provided MFA code. This operation changes
 * the status of a device without deleting it, so you can enable it again later. For more
 * information about device authentication, see Working with devices.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const updateDeviceStatus: API.OperationMethod<UpdateDeviceStatusRequest & RegionInput, UpdateDeviceStatusResponse, UpdateDeviceStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the name of a user pool group, updates any of the properties for precedence,
 * IAM role, or description. For more information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityProviderError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | UnsupportedIdentityProviderException | CommonErrors;
/**
 * Modifies the configuration and trust relationship between a third-party identity
 * provider (IdP) and a user pool. Amazon Cognito accepts sign-in with third-party identity
 * providers through managed login and OIDC relying-party libraries. For more information,
 * see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateIdentityProvider: API.OperationMethod<UpdateIdentityProviderRequest & RegionInput, UpdateIdentityProviderResponse, UpdateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Configures the branding settings for a user pool style. This operation is the
 * programmatic option for the configuration of a style in the branding editor.
 *
 * Provides values for UI customization in a `Settings` JSON object and image
 * files in an `Assets` array.
 *
 * This operation has a 2-megabyte request-size limit and include the CSS settings and
 * image assets for your app client. Your branding settings might exceed 2MB in size. Amazon Cognito
 * doesn't require that you pass all parameters in one request and preserves existing
 * style settings that you don't specify. If your request is larger than 2MB, separate it
 * into multiple requests, each with a size smaller than the limit.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateManagedLoginBranding: API.OperationMethod<UpdateManagedLoginBrandingRequest & RegionInput, UpdateManagedLoginBrandingResponse, UpdateManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedLimitError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Sets the provisioned limit for a specific API category. The value must be between the
 * default limit and your account-level maximum limit in Service Quotas.
 *
 * Managed login user pools don't support adjustments to the
 * `UserAuthentication` or `UserFederation` categories. To
 * increase these limits, submit a Service Quotas increase request.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateProvisionedLimit: API.OperationMethod<UpdateProvisionedLimitRequest & RegionInput, UpdateProvisionedLimitResponse, UpdateProvisionedLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the name and scopes of a resource server. All other fields are read-only. For
 * more information about resource servers, see Access control with resource servers.
 *
 * If you don't provide a value for an attribute, it is set to the default
 * value.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateResourceServer: API.OperationMethod<UpdateResourceServerRequest & RegionInput, UpdateResourceServerResponse, UpdateResourceServerError, Credentials | HttpClient.HttpClient>;
export type UpdateTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TermsExistsException | TooManyRequestsException | CommonErrors;
/**
 * Modifies existing terms documents for the requested app client. When Terms and
 * conditions and Privacy policy documents are configured, the app client displays links to
 * them in the sign-up page of managed login for the app client.
 *
 * You can provide URLs for terms documents in the languages that are supported by managed login localization. Amazon Cognito directs users to the terms documents for
 * their current language, with fallback to `default` if no document exists for
 * the language.
 *
 * Each request accepts one type of terms document and a map of language-to-link for that
 * document type. You must provide both types of terms documents in at least one language
 * before Amazon Cognito displays your terms documents. Supply each type in separate
 * requests.
 *
 * For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateTerms: API.OperationMethod<UpdateTermsRequest & RegionInput, UpdateTermsResponse, UpdateTermsError, Credentials | HttpClient.HttpClient>;
export type UpdateUserAttributesError = AliasExistsException | CodeDeliveryFailureException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Updates the currently signed-in user's attributes. To delete an attribute from
 * the user, submit the attribute in your API request with a blank value.
 *
 * For custom attributes, you must add a `custom:` prefix to the attribute
 * name, for example `custom:department`.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const updateUserAttributes: API.OperationMethod<UpdateUserAttributesRequest & RegionInput, UpdateUserAttributesResponse, UpdateUserAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TierChangeNotAllowedException | TooManyRequestsException | UserImportInProgressException | UserPoolTaggingException | CommonErrors;
/**
 * Updates the configuration of a user pool. To avoid setting parameters to Amazon Cognito
 * defaults, construct this API request to pass the existing configuration of your user
 * pool, modified to include the changes that you want to make.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * In secondary regions for user pools with multi-region replication, regional
 * configurations for email, SMS, Lambda functions, and tags can be updated. Both global
 * and regional settings must be provided as inputs, with global settings required to match
 * existing values to maintain consistency across replicas.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPool: API.OperationMethod<UpdateUserPoolRequest & RegionInput, UpdateUserPoolResponse, UpdateUserPoolError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolClientError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidOAuthFlowException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | ScopeDoesNotExistException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool app client ID, updates the configuration. To avoid setting
 * parameters to Amazon Cognito defaults, construct this API request to pass the existing
 * configuration of your app client, modified to include the changes that you want to
 * make.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * Unlike app clients created in the console, Amazon Cognito doesn't automatically assign a
 * branding style to app clients that you configure with this API operation. Managed login and classic hosted UI pages aren't
 * available for your client until after you apply a branding style.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolClient: API.OperationMethod<UpdateUserPoolClientRequest & RegionInput, UpdateUserPoolClientResponse, UpdateUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolDomainError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * A user pool domain hosts managed login, an authorization server and web server for
 * authentication in your application. This operation updates the branding version for user
 * pool domains between `1` for hosted UI (classic) and `2` for
 * managed login. It also updates the SSL certificate for user pool custom domains.
 *
 * Changes to the domain branding version take up to one minute to take effect for a
 * prefix domain and up to five minutes for a custom domain.
 *
 * This operation doesn't change the name of your user pool domain. To change your
 * domain, delete it with `DeleteUserPoolDomain` and create a new domain with
 * `CreateUserPoolDomain`.
 *
 * You can pass the ARN of a new Certificate Manager certificate in this request. Typically, ACM
 * certificates automatically renew and you user pool can continue to use the same ARN. But
 * if you generate a new certificate for your custom domain name, replace the original
 * configuration with the new ARN in this request.
 *
 * ACM certificates for custom domains must be in the US East (N. Virginia)
 * Amazon Web Services Region. After you submit your request, Amazon Cognito requires up to 1 hour to distribute
 * your new certificate to your custom domain.
 *
 * For more information about adding a custom domain to your user pool, see Configuring a user pool domain.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolDomain: API.OperationMethod<UpdateUserPoolDomainRequest & RegionInput, UpdateUserPoolDomainResponse, UpdateUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolReplicaError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates replica-specific settings for a user pool replica. You can modify the status
 * to activate or deactivate the replica. This request can be made in both primary and secondary
 * regions of the user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolReplica: API.OperationMethod<UpdateUserPoolReplicaRequest & RegionInput, UpdateUserPoolReplicaResponse, UpdateUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type VerifySoftwareTokenError = CodeMismatchException | EnableSoftwareTokenMFAException | ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Registers the current user's time-based one-time password (TOTP) authenticator
 * with a code generated in their authenticator app from a private key that's supplied
 * by your user pool. Marks the user's software token MFA status as "verified" if
 * successful. The request takes an access token or a session string, but not both.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const verifySoftwareToken: API.OperationMethod<VerifySoftwareTokenRequest & RegionInput, VerifySoftwareTokenResponse, VerifySoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type VerifyUserAttributeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Submits a verification code for a signed-in user who has added or changed a value of
 * an auto-verified attribute. When successful, the user's attribute becomes verified
 * and the attribute `email_verified` or `phone_number_verified`
 * becomes `true`.
 *
 * If your user pool requires verification before Amazon Cognito updates the attribute value,
 * this operation updates the affected attribute to its pending value.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const verifyUserAttribute: API.OperationMethod<VerifyUserAttributeRequest & RegionInput, VerifyUserAttributeResponse, VerifyUserAttributeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cognito-identity-provider.d.ts.map