/**
 * AWS X-Ray trace context, which AWS services read and pass on (the OTel
 * AWS SDK conventions recommend it for AWS calls). Generated code imports
 * this only where the model's `com.distilled.telemetry` traits ask for it:
 * a service's `propagation: "xray"`, an operation's `inject` with format
 * `xrayTraceHeader`. See `packages/dev/src/codegen/telemetry-traits.md`.
 *
 * `Root=1-<8 hex>-<24 hex>;Parent=<16 hex>;Sampled=<0|1>`, from a W3C trace
 * id split after 8 hex digits, as OTel's AWS X-Ray propagator writes it.
 */
import * as Tracer from "effect/Tracer";
export declare const HEADER = "X-Amzn-Trace-Id";
/** The X-Ray trace header of a span. */
export declare const traceHeader: (span: Tracer.AnySpan) => string;
/** The span an X-Ray trace header names, if it has a root and a parent. */
export declare const parseTraceHeader: (value: unknown) => Tracer.ExternalSpan | undefined;
/** `propagation: "xray"`: the `X-Amzn-Trace-Id` request header. */
export declare const propagate: (span: Tracer.AnySpan) => readonly [string, string];
/**
 * Write the span's X-Ray trace header into a string `member` of the input,
 * or of every element of its `list` member (EventBridge `PutEvents`
 * entries' `TraceHeader`). A value the caller set is kept.
 */
export declare const injectTraceHeader: (place: {
    readonly member: string;
    readonly list?: string;
}) => (span: Tracer.Span, input: unknown) => unknown;
//# sourceMappingURL=telemetry-xray.d.ts.map