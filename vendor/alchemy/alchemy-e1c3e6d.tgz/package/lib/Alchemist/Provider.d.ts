import * as Effect from "effect/Effect";
import { type Target } from "./Entrypoint.ts";
import { AlchemistInvalidInput } from "./Errors.ts";
export interface CheckEnvironmentInput extends Target {
    /** Providers to check. Omitted means every registered provider. */
    readonly providers?: ReadonlyArray<string>;
}
export interface EnvironmentCheck {
    readonly provider: string;
    readonly status: "satisfied" | "missing" | "no-contract";
    readonly missing: ReadonlyArray<{
        readonly alternatives: ReadonlyArray<string>;
    }>;
}
export interface EnvironmentCheckResult {
    readonly checks: ReadonlyArray<EnvironmentCheck>;
    readonly satisfied: boolean;
}
/**
 * Verify the environment variables each registered provider's CI contract
 * requires are present.
 */
export declare const checkEnvironment: (input: CheckEnvironmentInput) => Effect.Effect<{
    checks: {
        provider: string;
        status: "missing" | "no-contract" | "satisfied";
        missing: {
            alternatives: ReadonlyArray<string>;
        }[];
    }[];
    satisfied: boolean;
}, AlchemistInvalidInput | import("../Auth/Profile.ts").ProfileError | import("./AuthRegistry.ts").CollectAuthProvidersError, import("./AuthRegistry.ts").CollectAuthProvidersServices>;
//# sourceMappingURL=Provider.d.ts.map