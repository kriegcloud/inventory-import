import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const LibraryIngestionJobsActive_base: S.TaggedErrorClass<"LibraryIngestionJobsActive", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class LibraryIngestionJobsActive extends /*@__PURE__*/ LibraryIngestionJobsActive_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BlueprintArn = string;
export type BlueprintStage = "DEVELOPMENT" | "LIVE" | (string & {});
export type ClientToken = string;
export interface CopyBlueprintStageRequest {
    blueprintArn: string;
    sourceStage: BlueprintStage;
    targetStage: BlueprintStage;
    clientToken?: string | undefined;
}
export interface CopyBlueprintStageResponse {
}
export type BlueprintName = string | redacted.Redacted<string>;
export type Type = "DOCUMENT" | "IMAGE" | "AUDIO" | "VIDEO" | (string & {});
export type BlueprintSchema = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type KmsEncryptionContext = {
    [key: string]: string | undefined;
};
export interface EncryptionConfiguration {
    kmsKeyId: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateBlueprintRequest {
    blueprintName: string | redacted.Redacted<string>;
    type: Type;
    blueprintStage?: BlueprintStage | undefined;
    schema: string | redacted.Redacted<string>;
    clientToken?: string | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export type BlueprintVersion = string;
export type S3Uri = string;
export type S3ObjectVersion = string;
export interface S3Object {
    s3Uri: string;
    version?: string | undefined;
}
export interface BlueprintOptimizationSample {
    assetS3Object: S3Object;
    groundTruthS3Object: S3Object;
}
export type BlueprintOptimizationSamples = BlueprintOptimizationSample[];
export interface Blueprint {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    type: Type;
    creationTime: Date;
    lastModifiedTime: Date;
    blueprintName: string | redacted.Redacted<string>;
    blueprintVersion?: string | undefined;
    blueprintStage?: BlueprintStage | undefined;
    kmsKeyId?: string | undefined;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
    optimizationSamples?: BlueprintOptimizationSample[] | undefined;
    optimizationTime?: Date | undefined;
}
export interface CreateBlueprintResponse {
    blueprint: Blueprint;
}
export interface CreateBlueprintVersionRequest {
    blueprintArn: string;
    clientToken?: string | undefined;
}
export interface CreateBlueprintVersionResponse {
    blueprint: Blueprint;
}
export type DataAutomationLibraryName = string | redacted.Redacted<string>;
export type DataAutomationLibraryDescription = string | redacted.Redacted<string>;
export interface CreateDataAutomationLibraryRequest {
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export type DataAutomationLibraryArn = string;
export type DataAutomationLibraryStatus = "ACTIVE" | "DELETING" | (string & {});
export interface CreateDataAutomationLibraryResponse {
    libraryArn?: string | undefined;
    status?: DataAutomationLibraryStatus | undefined;
}
export type DataAutomationProjectName = string | redacted.Redacted<string>;
export type DataAutomationProjectDescription = string | redacted.Redacted<string>;
export type DataAutomationProjectStage = "DEVELOPMENT" | "LIVE" | (string & {});
export type DataAutomationProjectType = "ASYNC" | "SYNC" | (string & {});
export type DocumentExtractionGranularityType = "DOCUMENT" | "PAGE" | "ELEMENT" | "WORD" | "LINE" | (string & {});
export type DocumentExtractionGranularityTypes = DocumentExtractionGranularityType[];
export interface DocumentExtractionGranularity {
    types?: DocumentExtractionGranularityType[] | undefined;
}
export type State = "ENABLED" | "DISABLED" | (string & {});
export interface DocumentBoundingBox {
    state: State;
}
export interface DocumentStandardExtraction {
    granularity: DocumentExtractionGranularity;
    boundingBox: DocumentBoundingBox;
}
export interface DocumentStandardGenerativeField {
    state: State;
}
export type DocumentOutputTextFormatType = "PLAIN_TEXT" | "MARKDOWN" | "HTML" | "CSV" | (string & {});
export type DocumentOutputTextFormatTypes = DocumentOutputTextFormatType[];
export interface DocumentOutputTextFormat {
    types?: DocumentOutputTextFormatType[] | undefined;
}
export interface DocumentOutputAdditionalFileFormat {
    state: State;
}
export interface DocumentOutputFormat {
    textFormat: DocumentOutputTextFormat;
    additionalFileFormat: DocumentOutputAdditionalFileFormat;
}
export interface DocumentStandardOutputConfiguration {
    extraction?: DocumentStandardExtraction | undefined;
    generativeField?: DocumentStandardGenerativeField | undefined;
    outputFormat?: DocumentOutputFormat | undefined;
}
export type ImageExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "LOGOS" | (string & {});
export type ImageExtractionCategoryTypes = ImageExtractionCategoryType[];
export interface ImageExtractionCategory {
    state: State;
    types?: ImageExtractionCategoryType[] | undefined;
}
export interface ImageBoundingBox {
    state: State;
}
export interface ImageStandardExtraction {
    category: ImageExtractionCategory;
    boundingBox: ImageBoundingBox;
}
export type ImageStandardGenerativeFieldType = "IMAGE_SUMMARY" | "IAB" | (string & {});
export type ImageStandardGenerativeFieldTypes = ImageStandardGenerativeFieldType[];
export interface ImageStandardGenerativeField {
    state: State;
    types?: ImageStandardGenerativeFieldType[] | undefined;
}
export interface ImageStandardOutputConfiguration {
    extraction?: ImageStandardExtraction | undefined;
    generativeField?: ImageStandardGenerativeField | undefined;
}
export type VideoExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "TRANSCRIPT" | "LOGOS" | (string & {});
export type VideoExtractionCategoryTypes = VideoExtractionCategoryType[];
export interface VideoExtractionCategory {
    state: State;
    types?: VideoExtractionCategoryType[] | undefined;
}
export interface VideoBoundingBox {
    state: State;
}
export interface VideoStandardExtraction {
    category: VideoExtractionCategory;
    boundingBox: VideoBoundingBox;
}
export type VideoStandardGenerativeFieldType = "VIDEO_SUMMARY" | "IAB" | "CHAPTER_SUMMARY" | (string & {});
export type VideoStandardGenerativeFieldTypes = VideoStandardGenerativeFieldType[];
export interface VideoStandardGenerativeField {
    state: State;
    types?: VideoStandardGenerativeFieldType[] | undefined;
}
export interface VideoStandardOutputConfiguration {
    extraction?: VideoStandardExtraction | undefined;
    generativeField?: VideoStandardGenerativeField | undefined;
}
export type AudioExtractionCategoryType = "AUDIO_CONTENT_MODERATION" | "TRANSCRIPT" | "TOPIC_CONTENT_MODERATION" | (string & {});
export type AudioExtractionCategoryTypes = AudioExtractionCategoryType[];
export interface SpeakerLabelingConfiguration {
    state: State;
}
export interface ChannelLabelingConfiguration {
    state: State;
}
export interface TranscriptConfiguration {
    speakerLabeling?: SpeakerLabelingConfiguration | undefined;
    channelLabeling?: ChannelLabelingConfiguration | undefined;
}
export interface AudioExtractionCategoryTypeConfiguration {
    transcript?: TranscriptConfiguration | undefined;
}
export interface AudioExtractionCategory {
    state: State;
    types?: AudioExtractionCategoryType[] | undefined;
    typeConfiguration?: AudioExtractionCategoryTypeConfiguration | undefined;
}
export interface AudioStandardExtraction {
    category: AudioExtractionCategory;
}
export type AudioStandardGenerativeFieldType = "AUDIO_SUMMARY" | "IAB" | "TOPIC_SUMMARY" | (string & {});
export type AudioStandardGenerativeFieldTypes = AudioStandardGenerativeFieldType[];
export interface AudioStandardGenerativeField {
    state: State;
    types?: AudioStandardGenerativeFieldType[] | undefined;
}
export interface AudioStandardOutputConfiguration {
    extraction?: AudioStandardExtraction | undefined;
    generativeField?: AudioStandardGenerativeField | undefined;
}
export interface StandardOutputConfiguration {
    document?: DocumentStandardOutputConfiguration | undefined;
    image?: ImageStandardOutputConfiguration | undefined;
    video?: VideoStandardOutputConfiguration | undefined;
    audio?: AudioStandardOutputConfiguration | undefined;
}
export interface BlueprintItem {
    blueprintArn: string;
    blueprintVersion?: string | undefined;
    blueprintStage?: BlueprintStage | undefined;
}
export type BlueprintItems = BlueprintItem[];
export type FallbackBlueprintItems = BlueprintItem[];
export interface DocumentCustomOutputConfiguration {
    fallbackBlueprints?: BlueprintItem[] | undefined;
}
export interface CustomOutputConfiguration {
    blueprints?: BlueprintItem[] | undefined;
    document?: DocumentCustomOutputConfiguration | undefined;
}
export interface SplitterConfiguration {
    state?: State | undefined;
}
export interface ModalityProcessingConfiguration {
    state?: State | undefined;
}
export type SensitiveDataDetectionMode = "DETECTION" | "DETECTION_AND_REDACTION" | (string & {});
export type SensitiveDataDetectionScopeType = "STANDARD" | "CUSTOM" | (string & {});
export type SensitiveDataDetectionScope = SensitiveDataDetectionScopeType[];
export type PIIEntityType = "ALL" | "ADDRESS" | "AGE" | "NAME" | "EMAIL" | "PHONE" | "USERNAME" | "PASSWORD" | "DRIVER_ID" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "PIN" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "IP_ADDRESS" | "MAC_ADDRESS" | "URL" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | (string & {});
export type PIIEntityTypes = PIIEntityType[];
export type PIIRedactionMaskMode = "PII" | "ENTITY_TYPE" | (string & {});
export interface PIIEntitiesConfiguration {
    piiEntityTypes?: PIIEntityType[] | undefined;
    redactionMaskMode?: PIIRedactionMaskMode | undefined;
}
export interface SensitiveDataConfiguration {
    detectionMode: SensitiveDataDetectionMode;
    detectionScope?: SensitiveDataDetectionScopeType[] | undefined;
    piiEntitiesConfiguration?: PIIEntitiesConfiguration | undefined;
}
export interface DocumentOverrideConfiguration {
    splitter?: SplitterConfiguration | undefined;
    modalityProcessing?: ModalityProcessingConfiguration | undefined;
    sensitiveDataConfiguration?: SensitiveDataConfiguration | undefined;
}
export interface ImageOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration | undefined;
    sensitiveDataConfiguration?: SensitiveDataConfiguration | undefined;
}
export interface VideoOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration | undefined;
    sensitiveDataConfiguration?: SensitiveDataConfiguration | undefined;
}
export type Language = "EN" | "DE" | "ES" | "FR" | "IT" | "PT" | "JA" | "KO" | "CN" | "TW" | "HK" | (string & {});
export type AudioInputLanguages = Language[];
export type AudioGenerativeOutputLanguage = "DEFAULT" | "EN" | (string & {});
export interface AudioLanguageConfiguration {
    inputLanguages?: Language[] | undefined;
    generativeOutputLanguage?: AudioGenerativeOutputLanguage | undefined;
    identifyMultipleLanguages?: boolean | undefined;
}
export interface AudioOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration | undefined;
    languageConfiguration?: AudioLanguageConfiguration | undefined;
    sensitiveDataConfiguration?: SensitiveDataConfiguration | undefined;
}
export type DesiredModality = "IMAGE" | "DOCUMENT" | "AUDIO" | "VIDEO" | (string & {});
export interface ModalityRoutingConfiguration {
    jpeg?: DesiredModality | undefined;
    png?: DesiredModality | undefined;
    mp4?: DesiredModality | undefined;
    mov?: DesiredModality | undefined;
}
export interface OverrideConfiguration {
    document?: DocumentOverrideConfiguration | undefined;
    image?: ImageOverrideConfiguration | undefined;
    video?: VideoOverrideConfiguration | undefined;
    audio?: AudioOverrideConfiguration | undefined;
    modalityRouting?: ModalityRoutingConfiguration | undefined;
}
export interface DataAutomationLibraryItem {
    libraryArn: string;
}
export type DataAutomationLibraryItems = DataAutomationLibraryItem[];
export interface DataAutomationLibraryConfiguration {
    libraries?: DataAutomationLibraryItem[] | undefined;
}
export interface CreateDataAutomationProjectRequest {
    projectName: string | redacted.Redacted<string>;
    projectDescription?: string | redacted.Redacted<string> | undefined;
    projectStage?: DataAutomationProjectStage | undefined;
    projectType?: DataAutomationProjectType | undefined;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration | undefined;
    overrideConfiguration?: OverrideConfiguration | undefined;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration | undefined;
    clientToken?: string | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export type DataAutomationProjectArn = string;
export type DataAutomationProjectStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface CreateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
    status?: DataAutomationProjectStatus | undefined;
}
export interface DeleteBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string | undefined;
}
export interface DeleteBlueprintResponse {
}
export interface DeleteDataAutomationLibraryRequest {
    libraryArn: string;
}
export interface DeleteDataAutomationLibraryResponse {
    libraryArn?: string | undefined;
    status?: DataAutomationLibraryStatus | undefined;
}
export interface DeleteDataAutomationProjectRequest {
    projectArn: string;
}
export interface DeleteDataAutomationProjectResponse {
    projectArn: string;
    status?: DataAutomationProjectStatus | undefined;
}
export interface GetBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string | undefined;
    blueprintStage?: BlueprintStage | undefined;
}
export interface GetBlueprintResponse {
    blueprint: Blueprint;
}
export type BlueprintOptimizationInvocationArn = string;
export interface GetBlueprintOptimizationStatusRequest {
    invocationArn: string;
}
export type BlueprintOptimizationJobStatus = "Created" | "InProgress" | "Success" | "ServiceError" | "ClientError" | (string & {});
export interface BlueprintOptimizationOutputConfiguration {
    s3Object: S3Object;
}
export interface GetBlueprintOptimizationStatusResponse {
    status?: BlueprintOptimizationJobStatus | undefined;
    errorType?: string | undefined;
    errorMessage?: string | undefined;
    outputConfiguration?: BlueprintOptimizationOutputConfiguration | undefined;
}
export interface GetDataAutomationLibraryRequest {
    libraryArn: string;
}
export type EntityType = "VOCABULARY" | (string & {});
export type EntityMetadata = string;
export interface EntityTypeInfo {
    entityType: EntityType;
    entityMetadata?: string | undefined;
}
export type EntityTypeInfoList = EntityTypeInfo[];
export interface DataAutomationLibrary {
    libraryArn: string;
    creationTime: Date;
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string> | undefined;
    status: DataAutomationLibraryStatus;
    entityTypes?: EntityTypeInfo[] | undefined;
    kmsKeyId?: string | undefined;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDataAutomationLibraryResponse {
    library?: DataAutomationLibrary | undefined;
}
export type EntityId = string;
export interface GetDataAutomationLibraryEntityRequest {
    libraryArn: string;
    entityType: EntityType;
    entityId: string;
}
export type EntityDescription = string | redacted.Redacted<string>;
export type PhraseText = string | redacted.Redacted<string>;
export type PhraseDisplayAsText = string | redacted.Redacted<string>;
export interface Phrase {
    text: string | redacted.Redacted<string>;
    displayAsText?: string | redacted.Redacted<string> | undefined;
}
export type PhraseList = Phrase[];
export interface VocabularyEntity {
    entityId?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    language?: Language | undefined;
    phrases?: Phrase[] | undefined;
    lastModifiedTime?: Date | undefined;
}
export type EntityDetails = {
    vocabulary: VocabularyEntity;
};
export interface GetDataAutomationLibraryEntityResponse {
    entity?: EntityDetails | undefined;
}
export type DataAutomationLibraryIngestionJobArn = string;
export interface GetDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    jobArn: string;
}
export type LibraryIngestionJobOperationType = "UPSERT" | "DELETE" | (string & {});
export type LibraryIngestionJobStatus = "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export interface OutputConfiguration {
    s3Uri: string;
}
export interface DataAutomationLibraryIngestionJob {
    jobArn: string;
    creationTime: Date;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    jobStatus: LibraryIngestionJobStatus;
    outputConfiguration: OutputConfiguration;
    completionTime?: Date | undefined;
    errorMessage?: string | undefined;
    errorType?: string | undefined;
}
export interface GetDataAutomationLibraryIngestionJobResponse {
    job?: DataAutomationLibraryIngestionJob | undefined;
}
export interface GetDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
}
export interface DataAutomationProject {
    projectArn: string;
    creationTime: Date;
    lastModifiedTime: Date;
    projectName: string | redacted.Redacted<string>;
    projectStage?: DataAutomationProjectStage | undefined;
    projectType?: DataAutomationProjectType | undefined;
    projectDescription?: string | redacted.Redacted<string> | undefined;
    standardOutputConfiguration?: StandardOutputConfiguration | undefined;
    customOutputConfiguration?: CustomOutputConfiguration | undefined;
    overrideConfiguration?: OverrideConfiguration | undefined;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration | undefined;
    status: DataAutomationProjectStatus;
    kmsKeyId?: string | undefined;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDataAutomationProjectResponse {
    project: DataAutomationProject;
}
export interface BlueprintOptimizationObject {
    blueprintArn: string;
    stage?: BlueprintStage | undefined;
}
export type DataAutomationProfileArn = string;
export interface InvokeBlueprintOptimizationAsyncRequest {
    blueprint: BlueprintOptimizationObject;
    samples: BlueprintOptimizationSample[];
    outputConfiguration: BlueprintOptimizationOutputConfiguration;
    dataAutomationProfileArn: string;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export interface InvokeBlueprintOptimizationAsyncResponse {
    invocationArn: string;
}
export interface VocabularyEntityInfo {
    entityId?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    language: Language;
    phrases: Phrase[];
}
export type UpsertEntityInfo = {
    vocabulary: VocabularyEntityInfo;
};
export type UpsertEntitiesInfo = UpsertEntityInfo[];
export type EntityIdList = string[];
export interface DeleteEntitiesInfo {
    entityIds: string[];
}
export type InlinePayload = {
    upsertEntitiesInfo: UpsertEntityInfo[];
    deleteEntitiesInfo?: undefined;
} | {
    upsertEntitiesInfo?: undefined;
    deleteEntitiesInfo: DeleteEntitiesInfo;
};
export interface InputConfiguration {
    s3Object?: S3Object | undefined;
    inlinePayload?: InlinePayload | undefined;
}
export interface EventBridgeConfiguration {
    eventBridgeEnabled: boolean;
}
export interface NotificationConfiguration {
    eventBridgeConfiguration: EventBridgeConfiguration;
}
export interface InvokeDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    clientToken?: string | undefined;
    inputConfiguration: InputConfiguration;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    outputConfiguration: OutputConfiguration;
    notificationConfiguration?: NotificationConfiguration | undefined;
    tags?: Tag[] | undefined;
}
export interface InvokeDataAutomationLibraryIngestionJobResponse {
    jobArn?: string | undefined;
}
export type ResourceOwner = "SERVICE" | "ACCOUNT" | (string & {});
export type BlueprintStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export type MaxResults = number;
export type NextToken = string;
export interface DataAutomationProjectFilter {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
}
export interface ListBlueprintsRequest {
    blueprintArn?: string | undefined;
    resourceOwner?: ResourceOwner | undefined;
    blueprintStageFilter?: BlueprintStageFilter | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    projectFilter?: DataAutomationProjectFilter | undefined;
}
export interface BlueprintSummary {
    blueprintArn: string;
    blueprintVersion?: string | undefined;
    blueprintStage?: BlueprintStage | undefined;
    blueprintName?: string | redacted.Redacted<string> | undefined;
    creationTime: Date;
    lastModifiedTime?: Date | undefined;
}
export type Blueprints = BlueprintSummary[];
export interface ListBlueprintsResponse {
    blueprints: BlueprintSummary[];
    nextToken?: string | undefined;
}
export interface ListDataAutomationLibrariesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    projectFilter?: DataAutomationProjectFilter | undefined;
}
export interface DataAutomationLibrarySummary {
    libraryArn: string;
    libraryName?: string | redacted.Redacted<string> | undefined;
    creationTime: Date;
}
export type DataAutomationLibrarySummaries = DataAutomationLibrarySummary[];
export interface ListDataAutomationLibrariesResponse {
    libraries?: DataAutomationLibrarySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataAutomationLibraryEntitiesRequest {
    libraryArn: string;
    entityType: EntityType;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface VocabularyEntitySummary {
    entityId?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    language?: Language | undefined;
    numOfPhrases?: number | undefined;
    lastModifiedTime?: Date | undefined;
}
export type DataAutomationLibraryEntitySummary = {
    vocabulary: VocabularyEntitySummary;
};
export type DataAutomationLibraryEntitySummaries = DataAutomationLibraryEntitySummary[];
export interface ListDataAutomationLibraryEntitiesResponse {
    entities?: DataAutomationLibraryEntitySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataAutomationLibraryIngestionJobsRequest {
    libraryArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DataAutomationLibraryIngestionJobSummary {
    jobArn: string;
    jobStatus: LibraryIngestionJobStatus;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    creationTime: Date;
    completionTime?: Date | undefined;
}
export type DataAutomationLibraryIngestionJobSummaries = DataAutomationLibraryIngestionJobSummary[];
export interface ListDataAutomationLibraryIngestionJobsResponse {
    jobs?: DataAutomationLibraryIngestionJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export type DataAutomationProjectStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export interface BlueprintFilter {
    blueprintArn: string;
    blueprintVersion?: string | undefined;
    blueprintStage?: BlueprintStage | undefined;
}
export interface DataAutomationLibraryFilter {
    libraryArn: string;
}
export interface ListDataAutomationProjectsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    projectStageFilter?: DataAutomationProjectStageFilter | undefined;
    blueprintFilter?: BlueprintFilter | undefined;
    resourceOwner?: ResourceOwner | undefined;
    libraryFilter?: DataAutomationLibraryFilter | undefined;
}
export interface DataAutomationProjectSummary {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
    projectType?: DataAutomationProjectType | undefined;
    projectName?: string | redacted.Redacted<string> | undefined;
    creationTime: Date;
}
export type DataAutomationProjectSummaries = DataAutomationProjectSummary[];
export interface ListDataAutomationProjectsResponse {
    projects: DataAutomationProjectSummary[];
    nextToken?: string | undefined;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateBlueprintRequest {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    blueprintStage?: BlueprintStage | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateBlueprintResponse {
    blueprint: Blueprint;
}
export interface UpdateDataAutomationLibraryRequest {
    libraryArn: string;
    libraryDescription?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export interface UpdateDataAutomationLibraryResponse {
    libraryArn?: string | undefined;
    status?: DataAutomationLibraryStatus | undefined;
}
export interface UpdateDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
    projectDescription?: string | redacted.Redacted<string> | undefined;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration | undefined;
    overrideConfiguration?: OverrideConfiguration | undefined;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage | undefined;
    status?: DataAutomationProjectStatus | undefined;
}
export type NonBlankString = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CopyBlueprintStageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies a Blueprint from one stage to another
 */
export declare const copyBlueprintStage: API.OperationMethod<CopyBlueprintStageRequest & RegionInput, CopyBlueprintStageResponse, CopyBlueprintStageError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprint: API.OperationMethod<CreateBlueprintRequest & RegionInput, CreateBlueprintResponse, CreateBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new version of an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprintVersion: API.OperationMethod<CreateBlueprintVersionRequest & RegionInput, CreateBlueprintVersionResponse, CreateBlueprintVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Library
 */
export declare const createDataAutomationLibrary: API.OperationMethod<CreateDataAutomationLibraryRequest & RegionInput, CreateDataAutomationLibraryResponse, CreateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Project
 */
export declare const createDataAutomationProject: API.OperationMethod<CreateDataAutomationProjectRequest & RegionInput, CreateDataAutomationProjectResponse, CreateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const deleteBlueprint: API.OperationMethod<DeleteBlueprintRequest & RegionInput, DeleteBlueprintResponse, DeleteBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | LibraryIngestionJobsActive | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Library
 */
export declare const deleteDataAutomationLibrary: API.OperationMethod<DeleteDataAutomationLibraryRequest & RegionInput, DeleteDataAutomationLibraryResponse, DeleteDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Project
 */
export declare const deleteDataAutomationProject: API.OperationMethod<DeleteDataAutomationProjectRequest & RegionInput, DeleteDataAutomationProjectResponse, DeleteDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const getBlueprint: API.OperationMethod<GetBlueprintRequest & RegionInput, GetBlueprintResponse, GetBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintOptimizationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get blueprint optimization status.
 */
export declare const getBlueprintOptimizationStatus: API.OperationMethod<GetBlueprintOptimizationStatusRequest & RegionInput, GetBlueprintOptimizationStatusResponse, GetBlueprintOptimizationStatusError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Library
 */
export declare const getDataAutomationLibrary: API.OperationMethod<GetDataAutomationLibraryRequest & RegionInput, GetDataAutomationLibraryResponse, GetDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryEntityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing entity based on entity type from the library
 */
export declare const getDataAutomationLibraryEntity: API.OperationMethod<GetDataAutomationLibraryEntityRequest & RegionInput, GetDataAutomationLibraryEntityResponse, GetDataAutomationLibraryEntityError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get status of data automation library ingestion job
 */
export declare const getDataAutomationLibraryIngestionJob: API.OperationMethod<GetDataAutomationLibraryIngestionJobRequest & RegionInput, GetDataAutomationLibraryIngestionJobResponse, GetDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Project
 */
export declare const getDataAutomationProject: API.OperationMethod<GetDataAutomationProjectRequest & RegionInput, GetDataAutomationProjectResponse, GetDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type InvokeBlueprintOptimizationAsyncError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke an async job to perform Blueprint Optimization
 */
export declare const invokeBlueprintOptimizationAsync: API.OperationMethod<InvokeBlueprintOptimizationAsyncRequest & RegionInput, InvokeBlueprintOptimizationAsyncResponse, InvokeBlueprintOptimizationAsyncError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationLibraryIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Async API: Invoke data automation library ingestion job
 */
export declare const invokeDataAutomationLibraryIngestionJob: API.OperationMethod<InvokeDataAutomationLibraryIngestionJobRequest & RegionInput, InvokeDataAutomationLibraryIngestionJobResponse, InvokeDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type ListBlueprintsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Blueprints
 */
export declare const listBlueprints: API.PaginatedOperationMethod<ListBlueprintsRequest & RegionInput, ListBlueprintsResponse, ListBlueprintsError, Credentials | HttpClient.HttpClient, BlueprintSummary>;
export type ListDataAutomationLibrariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Libraries
 */
export declare const listDataAutomationLibraries: API.PaginatedOperationMethod<ListDataAutomationLibrariesRequest & RegionInput, ListDataAutomationLibrariesResponse, ListDataAutomationLibrariesError, Credentials | HttpClient.HttpClient, DataAutomationLibrarySummary>;
export type ListDataAutomationLibraryEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all stored entities in the library
 */
export declare const listDataAutomationLibraryEntities: API.PaginatedOperationMethod<ListDataAutomationLibraryEntitiesRequest & RegionInput, ListDataAutomationLibraryEntitiesResponse, ListDataAutomationLibraryEntitiesError, Credentials | HttpClient.HttpClient, DataAutomationLibraryEntitySummary>;
export type ListDataAutomationLibraryIngestionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data automation library ingestion jobs
 */
export declare const listDataAutomationLibraryIngestionJobs: API.PaginatedOperationMethod<ListDataAutomationLibraryIngestionJobsRequest & RegionInput, ListDataAutomationLibraryIngestionJobsResponse, ListDataAutomationLibraryIngestionJobsError, Credentials | HttpClient.HttpClient, DataAutomationLibraryIngestionJobSummary>;
export type ListDataAutomationProjectsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Projects
 */
export declare const listDataAutomationProjects: API.PaginatedOperationMethod<ListDataAutomationProjectsRequest & RegionInput, ListDataAutomationProjectsResponse, ListDataAutomationProjectsError, Credentials | HttpClient.HttpClient, DataAutomationProjectSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for an Amazon Bedrock Data Automation resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag an Amazon Bedrock Data Automation resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag an Amazon Bedrock Data Automation resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const updateBlueprint: API.OperationMethod<UpdateBlueprintRequest & RegionInput, UpdateBlueprintResponse, UpdateBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Library
 */
export declare const updateDataAutomationLibrary: API.OperationMethod<UpdateDataAutomationLibraryRequest & RegionInput, UpdateDataAutomationLibraryResponse, UpdateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Project
 */
export declare const updateDataAutomationProject: API.OperationMethod<UpdateDataAutomationProjectRequest & RegionInput, UpdateDataAutomationProjectResponse, UpdateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-data-automation.d.ts.map