import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type InstanceId = string;
export type ContactId = string;
export type MaxResults = number;
export type NextToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagComparisonType = "EQUALS" | "NOT_EQUALS" | (string & {});
export interface TagCondition {
    TagKey?: string | undefined;
    TagValue?: string | undefined;
    ComparisonType?: TagComparisonType | undefined;
}
export type TagAndConditionList = TagCondition[];
export interface CategoriesAttributeAndCondition {
    TagConditions?: TagCondition[] | undefined;
}
export type CategoriesAttributeOrConditionList = CategoriesAttributeAndCondition[];
export interface CategoriesAttributeFilter {
    OrConditions?: CategoriesAttributeAndCondition[] | undefined;
    AndCondition?: CategoriesAttributeAndCondition | undefined;
    TagCondition?: TagCondition | undefined;
}
export interface RealTimeContactAnalysisSegmentsFilter {
    CategoriesAttributeFilter?: CategoriesAttributeFilter | undefined;
}
export interface ListRealtimeContactAnalysisSegmentsRequest {
    InstanceId?: string | undefined;
    ContactId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ListFilter?: RealTimeContactAnalysisSegmentsFilter | undefined;
}
export type TranscriptId = string;
export type ParticipantId = string;
export type ParticipantRole = string;
export type TranscriptContent = string;
export type OffsetMillis = number;
export type SentimentValue = "POSITIVE" | "NEUTRAL" | "NEGATIVE" | (string & {});
export type CharacterOffset = number;
export interface CharacterOffsets {
    BeginOffsetChar?: number | undefined;
    EndOffsetChar?: number | undefined;
}
export interface IssueDetected {
    CharacterOffsets?: CharacterOffsets | undefined;
}
export type IssuesDetected = IssueDetected[];
export interface Transcript {
    Id?: string | undefined;
    ParticipantId?: string | undefined;
    ParticipantRole?: string | undefined;
    Content?: string | undefined;
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
    Sentiment?: SentimentValue | undefined;
    IssuesDetected?: IssueDetected[] | undefined;
}
export type CategoryName = string;
export type MatchedCategories = string[];
export interface PointOfInterest {
    BeginOffsetMillis?: number | undefined;
    EndOffsetMillis?: number | undefined;
}
export type PointsOfInterest = PointOfInterest[];
export type RuleId = string;
export interface CategoryDetails {
    PointsOfInterest?: PointOfInterest[] | undefined;
    RuleId?: string | undefined;
}
export type MatchedDetails = {
    [key: string]: CategoryDetails | undefined;
};
export interface Categories {
    MatchedCategories?: string[] | undefined;
    MatchedDetails?: {
        [key: string]: CategoryDetails | undefined;
    } | undefined;
}
export type PostContactSummaryContent = string;
export type PostContactSummaryStatus = "FAILED" | "COMPLETED" | (string & {});
export type PostContactSummaryFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INVALID_ANALYSIS_CONFIGURATION" | "INTERNAL_ERROR" | (string & {});
export interface PostContactSummary {
    Content?: string | undefined;
    Status?: PostContactSummaryStatus | undefined;
    FailureCode?: PostContactSummaryFailureCode | undefined;
}
export type ExtractionDefinitionId = string;
export type ExtractionDefinitionName = string;
export type ExtractionDefinitionDisplayLabel = string;
export type ExtractedInformationContent = string;
export interface ExtractedInformationValue {
    Content?: string | undefined;
    PointsOfInterest?: PointOfInterest[] | undefined;
}
export type ExtractedInformationValues = ExtractedInformationValue[];
export type ExtractedInformationFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INTERNAL_ERROR" | "MAX_PACKAGE_FEATURE_ONLY" | (string & {});
export interface ExtractedInformation {
    ExtractionDefinitionId?: string | undefined;
    ExtractionDefinitionName?: string | undefined;
    ExtractionDefinitionDisplayLabel?: string | undefined;
    ExtractedValues?: ExtractedInformationValue[] | undefined;
    FailureCode?: ExtractedInformationFailureCode | undefined;
}
export interface RealtimeContactAnalysisSegment {
    Transcript?: Transcript | undefined;
    Categories?: Categories | undefined;
    PostContactSummary?: PostContactSummary | undefined;
    ExtractedInformation?: ExtractedInformation | undefined;
}
export type RealtimeContactAnalysisSegments = RealtimeContactAnalysisSegment[];
export interface ListRealtimeContactAnalysisSegmentsResponse {
    Segments: (RealtimeContactAnalysisSegment & {
        Transcript: Transcript & {
            Id: TranscriptId;
            ParticipantId: ParticipantId;
            ParticipantRole: ParticipantRole;
            Content: TranscriptContent;
            BeginOffsetMillis: OffsetMillis;
            EndOffsetMillis: OffsetMillis;
            IssuesDetected: (IssueDetected & {
                CharacterOffsets: CharacterOffsets & {
                    BeginOffsetChar: CharacterOffset;
                    EndOffsetChar: CharacterOffset;
                };
            })[];
        };
        Categories: Categories & {
            MatchedCategories: MatchedCategories;
            MatchedDetails: {
                [key: string]: (CategoryDetails & {
                    PointsOfInterest: (PointOfInterest & {
                        BeginOffsetMillis: OffsetMillis;
                        EndOffsetMillis: OffsetMillis;
                    })[];
                }) | undefined;
            };
        };
        PostContactSummary: PostContactSummary & {
            Status: PostContactSummaryStatus;
        };
        ExtractedInformation: ExtractedInformation & {
            ExtractionDefinitionId: ExtractionDefinitionId;
            ExtractionDefinitionName: ExtractionDefinitionName;
            ExtractedValues: (ExtractedInformationValue & {
                Content: ExtractedInformationContent;
                PointsOfInterest: (PointOfInterest & {
                    BeginOffsetMillis: OffsetMillis;
                    EndOffsetMillis: OffsetMillis;
                })[];
            })[];
        };
    })[];
    NextToken?: string | undefined;
}
export type Message = string;
export type ListRealtimeContactAnalysisSegmentsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a list of analysis segments for a real-time analysis session for
 * voice.
 *
 * Voice data is retained for 24 hours. You must invoke this API during that
 * time.
 */
export declare const listRealtimeContactAnalysisSegments: API.PaginatedOperationMethod<ListRealtimeContactAnalysisSegmentsRequest & RegionInput, ListRealtimeContactAnalysisSegmentsResponse, ListRealtimeContactAnalysisSegmentsError, Credentials | HttpClient.HttpClient, unknown>;
export {};
//# sourceMappingURL=connect-contact-lens.d.ts.map