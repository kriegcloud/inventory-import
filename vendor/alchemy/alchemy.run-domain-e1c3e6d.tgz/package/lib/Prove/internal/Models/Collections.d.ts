import * as Compare from "../Compare.ts";
import type { Kit, Models } from "../Kit.ts";
import type { Eval, Site, V } from "../Value.ts";
/**
 * `Array`, `Record`, `Struct` and `Tuple`. An array's items, and an object's
 * keys, are ones the prover sees; what a function gives for an item may be a
 * formula, and then deciding on it splits the path.
 */
export declare const make: (kit: Kit) => {
    models: Models;
    among: (items: ReadonlyArray<V>, wanted: V, site: Site) => Eval<Compare.Known>;
    has: (items: ReadonlyArray<V>, wanted: V, site: Site) => Eval<boolean>;
    dedupe: (items: ReadonlyArray<V>, site: Site, same?: (a: V, b: V) => Eval<boolean>) => Eval<ReadonlyArray<V>>;
};
//# sourceMappingURL=Collections.d.ts.map