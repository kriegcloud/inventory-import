/**
 * MD5 for browsers, in plain JavaScript: WebCrypto has no MD5. Selected
 * through the package's `#md5` import; Node, Bun and Workers keep
 * `node:crypto` (`md5.ts`).
 */
import type { Checksum } from "./checksum.ts";
export declare const getMd5ChecksumAlgorithmFunction: () => new () => Checksum;
//# sourceMappingURL=md5.browser.d.ts.map