import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as Redacted from "effect/Redacted";
import { Docker } from "./Docker.ts";
import * as DockerfileParser from "./DockerfileParser.ts";
import type { CopyInstruction, Instruction, InstructionName, ParsedDockerfile } from "./DockerfileParser.ts";
import { type ImageSourceProps } from "./ImageSource.ts";
import { type ImageRegistry } from "./Registry.ts";
/**
 * A build plan: an image source (`image`, `context` + `dockerfile`, inline
 * `dockerfile`, plus an optional bundled `main`) resolved into data that any
 * builder can consume, Docker or not.
 *
 * Platforms with their own builders (E2B templates, Modal images, Daytona
 * snapshots) lower a plan into their build API; the Docker path can render
 * it back into a Dockerfile and build context. Every platform declares
 * {@link Capabilities}, and a Dockerfile it cannot build fails at plan time
 * with the offending lines, before any upload or remote build.
 */
export interface BuildPlan {
    /** Content hash of everything that determines the image: rebuild only when it changes. */
    readonly hash: string;
    /** Target platform, e.g. `linux/amd64`. */
    readonly platform: string;
    /** Every stage, including the generated `main` layer. */
    readonly dockerfile: ParsedDockerfile;
    /** The final stage's base: an image reference, an earlier stage's name, or `scratch`. */
    readonly base: string;
    /** Credentials for pulling a private base image. */
    readonly pull: ImageRegistry | undefined;
    /** The final stage's instructions. */
    readonly instructions: ReadonlyArray<Instruction>;
    /**
     * Files the build reads from its context: everything a `COPY`/`ADD`
     * source reaches (after `.dockerignore`), plus the bundled `main` under
     * {@link BUNDLE_DIR}. Paths are relative to the context, `/`-separated.
     */
    readonly files: ReadonlyArray<ContextFile>;
    /**
     * Build arguments (`ARG` values) the builder must pass. Empty when the
     * builder takes none ({@link Capabilities.buildArgs}): the values are then
     * written into the `ARG` defaults of {@link dockerfile}.
     */
    readonly args: Readonly<Record<string, string>>;
    /** BuildKit secrets, by id (`RUN --mount=type=secret,id=…`). */
    readonly secrets: Readonly<Record<string, Redacted.Redacted<string>>>;
    /** Instructions the platform ignores (see {@link Capabilities.instructions}). */
    readonly warnings: ReadonlyArray<string>;
}
/** A file in a plan's build context. */
export interface ContextFile {
    /** Context-relative, `/`-separated. */
    readonly path: string;
    /** Permission bits. */
    readonly mode: number;
    readonly size: number;
    /** Hex SHA-256 of the contents. */
    readonly sha256: string;
    readonly source: {
        readonly _tag: "Path";
        readonly absolutePath: string;
    } | {
        readonly _tag: "Bytes";
        readonly bytes: Uint8Array;
    };
}
/**
 * What a builder supports. Anything not listed is supported.
 */
export interface Capabilities {
    /** The resource the plan is for, used in error messages, e.g. `"E2B.Template"`. */
    readonly target: string;
    /** More than one `FROM`, or `COPY --from`. @default true */
    readonly multiStage?: boolean;
    /** `RUN <<EOF` / `COPY <<EOF`. @default true */
    readonly heredocs?: boolean;
    /** `RUN --mount=…` (secrets, caches). @default true */
    readonly runMounts?: boolean;
    /** `ADD <url>`. @default true */
    readonly remoteAdd?: boolean;
    /**
     * Build arguments passed to the builder. When `false`, the plan writes
     * the values into the Dockerfile's `ARG` defaults instead. @default true
     */
    readonly buildArgs?: boolean;
    /** BuildKit secrets (`build.secrets`, `RUN --mount=type=secret`). @default true */
    readonly secrets?: boolean;
    /** Platforms the builder targets, also checked against `FROM --platform=`. @default any */
    readonly platforms?: ReadonlyArray<string>;
    /** Instructions the builder ignores (a warning) or rejects (an error). */
    readonly instructions?: Partial<Record<InstructionName, "ignored" | "unsupported">>;
}
/** One reason a builder cannot build a plan. */
export interface Violation {
    /** 1-based Dockerfile line; `0` for the generated `main` layer or the platform. */
    readonly line: number;
    readonly instruction: string;
    readonly reason: string;
}
declare const UnsupportedDockerfile_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnsupportedDockerfile";
} & Readonly<A>;
/** The Dockerfile uses something the target builder cannot build. */
export declare class UnsupportedDockerfile extends UnsupportedDockerfile_base<{
    readonly target: string;
    readonly violations: ReadonlyArray<Violation>;
    readonly message: string;
}> {
}
declare const BuildPlanError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BuildPlanError";
} & Readonly<A>;
/** The image source cannot be planned (a missing file, an unresolved input, an inline Dockerfile that copies from a context). */
export declare class BuildPlanError extends BuildPlanError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
/** The context directory a plan's bundled `main` files live under. */
export declare const BUNDLE_DIR = "__alchemy__";
/** Default base for a `main` program with no environment: Docker Hub's bun image. */
export declare const DEFAULT_MAIN_BASE = "oven/bun:1";
export interface PlanOptions {
    readonly capabilities: Capabilities;
    /** @default "linux/amd64" */
    readonly platform?: string;
    /** Port a `main` program listens on; written to `ENV PORT`. */
    readonly port?: number;
    /**
     * Bootstrap wrapped around an Effect-native `main` (the host's virtual
     * entry). Omit it to bundle `main` as-is.
     */
    readonly bootstrap?: (importPath: string) => string;
    /** Credentials for pulling a private base image. */
    readonly pull?: ImageRegistry;
    /**
     * Dockerfile lines a host's bindings contribute, e.g. the clients of
     * `alchemy/Mount` capabilities (`mountInstallLines`). They go after the
     * final stage's own instructions and before the bundled `main`, so a
     * program change doesn't reinstall them.
     */
    readonly install?: ReadonlyArray<string>;
}
/** The context files one `COPY`/`ADD` reads. */
export declare const filesFor: (plan: BuildPlan, instruction: CopyInstruction) => ContextFile[];
/** Check a parsed Dockerfile against a builder's capabilities. */
export declare const check: (dockerfile: ParsedDockerfile, capabilities: Capabilities, platform: string) => {
    violations: Violation[];
    warnings: string[];
};
/**
 * Resolve an image source into a {@link BuildPlan} for one builder.
 */
export declare const plan: (source: ImageSourceProps, options: PlanOptions) => Effect.Effect<{
    hash: string;
    platform: string;
    dockerfile: ParsedDockerfile;
    base: string;
    pull: ImageRegistry | undefined;
    instructions: readonly Instruction[];
    files: ContextFile[];
    args: Record<string, string>;
    secrets: Record<string, Redacted.Redacted<string>>;
    warnings: string[];
}, import("./BuildHash.ts").BuildHashInvalidProps | BuildPlanError | import("alchemy/Bundle/Bundle").BundleError | DockerfileParser.DockerfileSyntaxError | import("effect/PlatformError").PlatformError | UnsupportedDockerfile, FileSystem.FileSystem | Path.Path>;
/** A context file's contents. */
export declare const readContextFile: (file: ContextFile) => Effect.Effect<Uint8Array<ArrayBufferLike>, import("effect/PlatformError").PlatformError, FileSystem.FileSystem>;
/** The plan as Dockerfile text. */
export declare const render: (plan: BuildPlan) => string;
/** The plan as one entry per instruction (for APIs that take a list of Dockerfile commands). */
export declare const renderLines: (plan: BuildPlan) => string[];
/**
 * The argv the image starts with, from the final stage's `ENTRYPOINT` and
 * `CMD` (Docker's rules: a shell-form `ENTRYPOINT` ignores `CMD`).
 * `undefined` when the final stage sets neither (the base image's applies).
 */
export declare const startCommand: (plan: BuildPlan) => ReadonlyArray<string> | undefined;
/**
 * Check Dockerfile text against a builder's capabilities, without reading a
 * build context or bundling anything: usable where there is no filesystem
 * (a Worker creating images at run time). Returns the warnings.
 */
export declare const checkContent: (text: string, options: Pick<PlanOptions, "capabilities" | "platform">) => Effect.Effect<string[], DockerfileParser.DockerfileSyntaxError | UnsupportedDockerfile, never>;
/** Where {@link push} publishes a plan. */
export interface PushTarget {
    /** Repository to push to, without a tag, e.g. `ghcr.io/acme/agent`. The plan's hash is the tag. */
    readonly repository: string;
    /** Credentials for the registry the repository lives in. */
    readonly push: ImageRegistry;
}
/**
 * Build a plan with the local Docker engine and push it, for platforms that
 * only pull images (Archil). Tagged with the plan's hash, so an unchanged
 * plan pushes the same tag. Returns the pushed reference, `repository@digest`
 * when the registry reports a digest, else `repository:hash`.
 */
export declare const push: (plan: BuildPlan, target: PushTarget) => Effect.Effect<{
    imageRef: string;
}, import("./RegistryError.ts").DockerImagePublicationError, Docker | FileSystem.FileSystem | Path.Path | import("effect/Scope").Scope>;
export {};
//# sourceMappingURL=BuildPlan.d.ts.map