import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CreateBlobRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The new blob's content. */
    content: string;
    /** The encoding used for `content`. Currently, `"utf-8"` and `"base64"` are supported. */
    encoding?: string | undefined;
}
/** Short Blob */
export interface ShortBlob {
    url: string;
    sha: string;
}
/** The full SHAs of the commits that were the parents of this commit. If omitted or empty, the commit will be written as a root commit. For a single parent, an array of one SHA should be provided; for a merge commit, an array of more than one should be provided. */
export type CreateCommitRequestParentsList = Array<string>;
/** Information about the author of the commit. By default, the `author` will be the authenticated user and the current date. See the `author` and `committer` object below for details. */
export interface CreateCommitRequestAuthor {
    /** The name of the author (or committer) of the commit */
    name: string;
    /** The email of the author (or committer) of the commit */
    email: string;
    /** Indicates when this commit was authored (or committed). This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    date?: string | undefined;
}
/** Information about the person who is making the commit. By default, `committer` will use the information set in `author`. See the `author` and `committer` object below for details. */
export interface CreateCommitRequestCommitter {
    /** The name of the author (or committer) of the commit */
    name?: string | undefined;
    /** The email of the author (or committer) of the commit */
    email?: string | undefined;
    /** Indicates when this commit was authored (or committed). This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    date?: string | undefined;
}
export interface CreateCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit message */
    message: string;
    /** The SHA of the tree object this commit points to */
    tree: string;
    /** The full SHAs of the commits that were the parents of this commit. If omitted or empty, the commit will be written as a root commit. For a single parent, an array of one SHA should be provided; for a merge commit, an array of more than one should be provided. */
    parents?: CreateCommitRequestParentsList | undefined;
    /** Information about the author of the commit. By default, the `author` will be the authenticated user and the current date. See the `author` and `committer` object below for details. */
    author?: CreateCommitRequestAuthor | undefined;
    /** Information about the person who is making the commit. By default, `committer` will use the information set in `author`. See the `author` and `committer` object below for details. */
    committer?: CreateCommitRequestCommitter | undefined;
    /** The [PGP signature](https://en.wikipedia.org/wiki/Pretty_Good_Privacy) of the commit. GitHub adds the signature to the `gpgsig` header of the created commit. For a commit signature to be verifiable by Git or GitHub, it must be an ASCII-armored detached PGP signature over the string commit as it would be written to the object database. To pass a `signature` parameter, you need to first manually create a valid PGP signature, which can be complicated. You may find it easier to [use the command line](https://git-scm.com/book/id/v2/Git-Tools-Signing-Your-Work) to create signed commits. */
    signature?: string | undefined;
}
/** Identifying information for the git-user */
export interface GitCommitAuthor {
    /** Timestamp of the commit */
    date: string;
    /** Git email address of the user */
    email: string;
    /** Name of the git user */
    name: string;
}
/** Identifying information for the git-user */
export type GitCommitCommitter = GitCommitAuthor;
export interface GitCommitTree {
    /** SHA for the commit */
    sha: string;
    url: string;
}
export interface GitCommitParentsItem {
    /** SHA for the commit */
    sha: string;
    url: string;
    html_url: string;
}
export type GitCommitParentsList = Array<GitCommitParentsItem>;
export interface GitCommitVerification {
    verified: boolean;
    reason: string;
    signature: string | null;
    payload: string | null;
    verified_at: string | null;
}
/** Low-level Git commit operations within a repository */
export interface GitCommit {
    /** SHA for the commit */
    sha: string;
    node_id: string;
    url: string;
    /** Identifying information for the git-user */
    author: GitCommitAuthor;
    /** Identifying information for the git-user */
    committer: GitCommitAuthor;
    /** Message describing the purpose of the commit */
    message: string;
    tree: GitCommitTree;
    parents: GitCommitParentsList;
    verification: GitCommitVerification;
    html_url: string;
}
export interface CreateRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the fully qualified reference (ie: `refs/heads/master`). If it doesn't start with 'refs' and have at least two slashes, it will be rejected. */
    ref: string;
    /** The SHA1 value for this reference. */
    sha: string;
}
export interface GitRefObject {
    type: string;
    /** SHA for the reference */
    sha: string;
    url: string;
}
/** Git references within a repository */
export interface GitRef {
    ref: string;
    node_id: string;
    url: string;
    object: GitRefObject;
}
/** The type of the object we're tagging. Normally this is a `commit` but it can also be a `tree` or a `blob`. */
export type CreateTagRequestType = "commit" | "tree" | "blob";
/** An object with information about the individual creating the tag. */
export interface CreateTagRequestTagger {
    /** The name of the author of the tag */
    name: string;
    /** The email of the author of the tag */
    email: string;
    /** When this object was tagged. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    date?: string | undefined;
}
export interface CreateTagRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The tag's name. This is typically a version (e.g., "v0.0.1"). */
    tag: string;
    /** The tag message. */
    message: string;
    /** The SHA of the git object this is tagging. */
    object: string;
    /** The type of the object we're tagging. Normally this is a `commit` but it can also be a `tree` or a `blob`. */
    type: CreateTagRequestType | (string & {});
    /** An object with information about the individual creating the tag. */
    tagger?: CreateTagRequestTagger | undefined;
}
export interface GitTagTagger {
    date: string;
    email: string;
    name: string;
}
export interface GitTagObject {
    sha: string;
    type: string;
    url: string;
}
export interface Verification {
    verified: boolean;
    reason: string;
    payload: string | null;
    signature: string | null;
    verified_at: string | null;
}
/** Metadata for a Git tag */
export interface GitTag {
    node_id: string;
    /** Name of the tag */
    tag: string;
    sha: string;
    /** URL for the tag */
    url: string;
    /** Message describing the purpose of the tag */
    message: string;
    tagger: GitTagTagger;
    object: GitTagObject;
    verification?: Verification | undefined;
}
/** The file mode; one of `100644` for file (blob), `100755` for executable (blob), `040000` for subdirectory (tree), `160000` for submodule (commit), or `120000` for a blob that specifies the path of a symlink. */
export type CreateTreeRequestTreeItemMode = "100644" | "100755" | "040000" | "160000" | "120000";
/** Either `blob`, `tree`, or `commit`. */
export type CreateTreeRequestTreeItemType = "blob" | "tree" | "commit";
export interface CreateTreeRequestTreeItem {
    /** The file referenced in the tree. */
    path?: string | undefined;
    /** The file mode; one of `100644` for file (blob), `100755` for executable (blob), `040000` for subdirectory (tree), `160000` for submodule (commit), or `120000` for a blob that specifies the path of a symlink. */
    mode?: CreateTreeRequestTreeItemMode | (string & {}) | undefined;
    /** Either `blob`, `tree`, or `commit`. */
    type?: CreateTreeRequestTreeItemType | (string & {}) | undefined;
    /** The SHA1 checksum ID of the object in the tree. Also called `tree.sha`. If the value is `null` then the file will be deleted. **Note:** Use either `tree.sha` or `content` to specify the contents of the entry. Using both `tree.sha` and `content` will return an error. */
    sha?: string | null | undefined;
    /** The content you want this file to have. GitHub will write this blob out and use that SHA for this entry. Use either this, or `tree.sha`. **Note:** Use either `tree.sha` or `content` to specify the contents of the entry. Using both `tree.sha` and `content` will return an error. */
    content?: string | undefined;
}
/** Objects (of `path`, `mode`, `type`, and `sha`) specifying a tree structure. */
export type CreateTreeRequestTreeList = Array<CreateTreeRequestTreeItem>;
export interface CreateTreeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Objects (of `path`, `mode`, `type`, and `sha`) specifying a tree structure. */
    tree: CreateTreeRequestTreeList;
    /** The SHA1 of an existing Git tree object which will be used as the base for the new tree. If provided, a new Git tree object will be created from entries in the Git tree object pointed to by `base_tree` and entries defined in the `tree` parameter. Entries defined in the `tree` parameter will overwrite items from `base_tree` with the same `path`. If you're creating new changes on a branch, then normally you'd set `base_tree` to the SHA1 of the Git tree object of the current latest commit on the branch you're working on. If not provided, GitHub will create a new Git tree object from only the entries defined in the `tree` parameter. If you create a new commit pointing to such a tree, then all files which were a part of the parent commit's tree and were not defined in the `tree` parameter will be listed as deleted by the new commit. */
    base_tree?: string | undefined;
}
export interface GitTreeTreeItem {
    path: string;
    mode: string;
    type: string;
    sha: string;
    size?: number | undefined;
    url?: string | undefined;
}
/** Objects specifying a tree structure */
export type GitTreeTreeList = Array<GitTreeTreeItem>;
/** The hierarchy between files in a Git repository. */
export interface GitTree {
    sha: string;
    url?: string | undefined;
    truncated: boolean;
    /** Objects specifying a tree structure */
    tree: GitTreeTreeList;
}
export interface DeleteRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
}
export interface DeleteRefResponse {
}
export interface GetBlobRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    file_sha: string;
}
/** Blob */
export interface Blob {
    content: string;
    encoding: string;
    url: string;
    sha: string;
    size: number | null;
    node_id: string;
    highlighted_content?: string | undefined;
}
export interface GetCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA of the commit. */
    commit_sha: string;
}
export interface GetRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
}
export interface GetTagRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    tag_sha: string;
}
export interface GetTreeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA1 value or ref (branch or tag) name of the tree. */
    tree_sha: string;
    /** Setting this parameter to any value returns the objects or subtrees referenced by the tree specified in `:tree_sha`. For example, setting `recursive` to any of the following will enable returning objects or subtrees: `0`, `1`, `"true"`, and `"false"`. Omit this parameter to prevent recursively returning objects or subtrees. */
    recursive?: string | undefined;
}
export interface ListMatchingRefsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
}
export type ListMatchingRefsResponseBodyList = Array<GitRef>;
export type ListMatchingRefsResponse = ListMatchingRefsResponseBodyList;
export interface UpdateRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** The SHA1 value to set this reference to */
    sha: string;
    /** Indicates whether to force the update or to make sure the update is a fast-forward update. Leaving this out or setting it to `false` will make sure you're not overwriting work. */
    force?: boolean | undefined;
}
export type CreateBlobError = GithubOpError;
/** Create a blob */
export declare const createBlob: API.OperationMethod<CreateBlobRequest, ShortBlob, CreateBlobError, GithubOpContext>;
export type CreateCommitError = GithubOpError;
/** Create a commit Creates a new Git [commit object](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects). **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const createCommit: API.OperationMethod<CreateCommitRequest, GitCommit, CreateCommitError, GithubOpContext>;
export type CreateRefError = GithubOpError;
/** Create a reference Creates a reference for your repository. You are unable to create new references for empty repositories, even if the commit SHA-1 hash used exists. Empty repositories are repositories without branches. */
export declare const createRef: API.OperationMethod<CreateRefRequest, GitRef, CreateRefError, GithubOpContext>;
export type CreateTagError = GithubOpError;
/** Create a tag object Note that creating a tag object does not create the reference that makes a tag in Git. If you want to create an annotated tag in Git, you have to do this call to create the tag object, and then [create](https://docs.github.com/rest/git/refs#create-a-reference) the `refs/tags/[tag]` reference. If you want to create a lightweight tag, you only have to [create](https://docs.github.com/rest/git/refs#create-a-reference) the tag reference - this call would be unnecessary. **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const createTag: API.OperationMethod<CreateTagRequest, GitTag, CreateTagError, GithubOpContext>;
export type CreateTreeError = GithubOpError;
/** Create a tree The tree creation API accepts nested entries. If you specify both a tree and a nested path modifying that tree, this endpoint will overwrite the contents of the tree with the new path contents, and create a new tree structure. If you use this endpoint to add, delete, or modify the file contents in a tree, you will need to commit the tree and then update a branch to point to the commit. For more information see "[Create a commit](https://docs.github.com/rest/git/commits#create-a-commit)" and "[Update a reference](https://docs.github.com/rest/git/refs#update-a-reference)." Returns an error if you try to delete a file that does not exist. */
export declare const createTree: API.OperationMethod<CreateTreeRequest, GitTree, CreateTreeError, GithubOpContext>;
export type DeleteRefError = GithubOpError;
/** Delete a reference Deletes the provided reference. */
export declare const deleteRef: API.OperationMethod<DeleteRefRequest, DeleteRefResponse, DeleteRefError, GithubOpContext>;
export type GetBlobError = GithubOpError;
/** Get a blob The `content` in the response will always be Base64 encoded. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw blob data. - **`application/vnd.github+json`**: Returns a JSON representation of the blob with `content` as a base64 encoded string. This is the default if no media type is specified. **Note** This endpoint supports blobs up to 100 megabytes in size. */
export declare const getBlob: API.OperationMethod<GetBlobRequest, Blob, GetBlobError, GithubOpContext>;
export type GetCommitError = GithubOpError;
/** Get a commit object Gets a Git [commit object](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects). To get the contents of a commit, see "[Get a commit](/rest/commits/commits#get-a-commit)." **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const getCommit: API.OperationMethod<GetCommitRequest, GitCommit, GetCommitError, GithubOpContext>;
export type GetRefError = GithubOpError;
/** Get a reference Returns a single reference from your Git database. The `:ref` in the URL must be formatted as `heads/<branch name>` for branches and `tags/<tag name>` for tags. If the `:ref` doesn't match an existing ref, a `404` is returned. > [!NOTE] > You need to explicitly [request a pull request](https://docs.github.com/rest/pulls/pulls#get-a-pull-request) to trigger a test merge commit, which checks the mergeability of pull requests. For more information, see "[Checking mergeability of pull requests](https://docs.github.com/rest/guides/getting-started-with-the-git-database-api#checking-mergeability-of-pull-requests)". */
export declare const getRef: API.OperationMethod<GetRefRequest, GitRef, GetRefError, GithubOpContext>;
export type GetTagError = GithubOpError;
/** Get a tag **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const getTag: API.OperationMethod<GetTagRequest, GitTag, GetTagError, GithubOpContext>;
export type GetTreeError = GithubOpError;
/** Get a tree Returns a single tree using the SHA1 value or ref name for that tree. If `truncated` is `true` in the response then the number of items in the `tree` array exceeded our maximum limit. If you need to fetch more items, use the non-recursive method of fetching trees, and fetch one sub-tree at a time. > [!NOTE] > The limit for the `tree` array is 100,000 entries with a maximum size of 7 MB when using the `recursive` parameter. */
export declare const getTree: API.OperationMethod<GetTreeRequest, GitTree, GetTreeError, GithubOpContext>;
export type ListMatchingRefsError = GithubOpError;
/** List matching references Returns an array of references from your Git database that match the supplied name. The `:ref` in the URL must be formatted as `heads/<branch name>` for branches and `tags/<tag name>` for tags. If the `:ref` doesn't exist in the repository, but existing refs start with `:ref`, they will be returned as an array. When you use this endpoint without providing a `:ref`, it will return an array of all the references from your Git database, including notes and stashes if they exist on the server. Anything in the namespace is returned, not just `heads` and `tags`. > [!NOTE] > You need to explicitly [request a pull request](https://docs.github.com/rest/pulls/pulls#get-a-pull-request) to trigger a test merge commit, which checks the mergeability of pull requests. For more information, see "[Checking mergeability of pull requests](https://docs.github.com/rest/guides/getting-started-with-the-git-database-api#checking-mergeability-of-pull-requests)". If you request matching references for a branch named `feature` but the branch `feature` doesn't exist, the response can still include other matching head refs that start with the word `feature`, such as `featureA` and `featureB`. */
export declare const listMatchingRefs: API.OperationMethod<ListMatchingRefsRequest, ListMatchingRefsResponse, ListMatchingRefsError, GithubOpContext>;
export type UpdateRefError = GithubOpError;
/** Update a reference Updates the provided reference to point to a new SHA. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
export declare const updateRef: API.OperationMethod<UpdateRefRequest, GitRef, UpdateRefError, GithubOpContext>;
//# sourceMappingURL=git.d.ts.map