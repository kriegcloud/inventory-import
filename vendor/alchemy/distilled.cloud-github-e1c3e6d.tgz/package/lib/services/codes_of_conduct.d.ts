import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetAllCodesOfConductRequest {
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export type GetAllCodesOfConductResponseBodyList = Array<CodeOfConduct>;
export type GetAllCodesOfConductResponse = GetAllCodesOfConductResponseBodyList;
export interface GetConductCodeRequest {
    key: string;
}
export type GetAllCodesOfConductError = GithubOpError;
/** Get all codes of conduct Returns array of all GitHub's codes of conduct. */
export declare const getAllCodesOfConduct: API.OperationMethod<GetAllCodesOfConductRequest, GetAllCodesOfConductResponse, GetAllCodesOfConductError, GithubOpContext>;
export type GetConductCodeError = GithubOpError;
/** Get a code of conduct Returns information about the specified GitHub code of conduct. */
export declare const getConductCode: API.OperationMethod<GetConductCodeRequest, CodeOfConduct, GetConductCodeError, GithubOpContext>;
//# sourceMappingURL=codes_of_conduct.d.ts.map