import { CloudflareEnvironment } from "@alchemy.run/cloudflare/CloudflareEnvironment";
import * as workflows from "@distilled.cloud/cloudflare/workflows";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type { Progress } from "../Backfill.ts";
export interface BackfillProps {
    /** The Domain's Worker: a run starts once the Worker carrying its Workflow is deployed. */
    scriptName: string;
    /** The Workflow, hosted by the Domain's Worker, that starts the runs and waits for them. */
    workflowName: string;
    /**
     * Every view and projection in the model, by target id (`view:Name`, with
     * `#<generation>` once rebuilt). Those new to the Domain are backfilled.
     */
    targets: string[];
    /**
     * What the backfill needs to know of each consumer (the sources it reads, and
     * whether a key reads its one source's log itself), by target id. The
     * deploy passes them to each run, so a run doesn't depend on what an
     * object's code knows.
     */
    plans?: Record<string, {
        sources?: string[];
        singleSource: boolean;
    }>;
    /**
     * How long a deploy waits for the backfill, in seconds. Past it the deploy
     * fails, while the backfill keeps running on Cloudflare; the next deploy
     * waits on the same runs.
     * @default 1800
     */
    timeoutSeconds?: number;
}
export interface BackfillAttrs {
    accountId: string;
    workflowName: string;
    /** The Workflow instance the last deploy waited through. */
    instanceId: string;
    targets: string[];
    /** `complete` once every target's run is complete. */
    status: string;
}
declare const BackfillTypeId = "Cloudflare.Domain.Backfill";
/**
 * The backfill of a Domain's views and projections, run by reconciliation.
 * The Durable Object platform declares it with the model's consumers: you
 * don't declare it yourself. A deploy that adds a view or projection, or
 * bumps a version, waits here until every new consumer has received the
 * history recorded before it, and reports how far each one has got.
 *
 * ### What a deploy waits for <!-- api-prose -->
 *
 * Each consumer generation (a view, or a view after a version bump) has one
 * run, held by one Durable Object of a class only that generation has. The
 * first deploy to reach it starts it; every later start finds it started, so
 * there is never more than one, however many deploys ask. The run lives on
 * Cloudflare and moves on its own: this resource starts it, waits for it,
 * and reports its progress, but holds none of its state.
 *
 * So a deploy is safe to repeat and to interrupt. Run it again after a
 * failure, a timeout or a Ctrl-C, and it waits on the same runs, from where
 * they are; once they are complete it returns at once. A deploy that changes
 * no consumer plans no change here.
 *
 * ### Progress <!-- api-prose -->
 *
 * While it waits, the deploy notes each run's phase and how far through the
 * directory it is:
 *
 * ```sh
 * Backfilling view:Deposits reading history 41% (1,690/4,096 subtrees, 410,211 instances) (48s) ...
 * ```
 *
 * A consumer keyed by its source reads its history in one pass; any other
 * reads it, then applies it once every source's history is in. `refused`
 * counts calls Cloudflare turned down for the account's load: the run backs
 * off and sends them again.
 *
 * ### Rebuilding and cancelling <!-- api-prose -->
 *
 * A run reads the sources its consumer read when it started. A deploy whose
 * consumer reads other sources at the same version (a view that now reads a
 * journal as well as accounts) fails, saying to bump the version: waiting on
 * the run would report a history that misses the new source.
 *
 * To run a backfill again, bump the consumer's version: the new generation is
 * a new class with its own run, and the same Worker upload deletes the old
 * generation's class, data and run. To stop a backfill, remove the consumer
 * from the model and deploy: its classes, and the run with them, are deleted.
 * Either is one Worker upload, so a consumer never has two runs at once.
 *
 * @resource
 * @product Durable Objects
 */
export interface Backfill extends Resource<typeof BackfillTypeId, BackfillProps, BackfillAttrs> {
}
export declare const Backfill: import("alchemy").ResourceClass<Backfill>;
declare const BackfillStillRunning_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BackfillStillRunning";
} & Readonly<A>;
export declare class BackfillStillRunning extends BackfillStillRunning_base<{
    readonly message: string;
    readonly instanceId: string;
}> {
}
declare const BackfillFailed_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BackfillFailed";
} & Readonly<A>;
export declare class BackfillFailed extends BackfillFailed_base<{
    readonly message: string;
    readonly instanceId: string;
    readonly status: string;
}> {
}
/** Each run's progress from the latest check step's output (an array of {@link Progress}). */
export declare const progressOf: (steps: ReadonlyArray<object>) => readonly Progress[] | undefined;
/** One run's progress, as the deploy notes it. */
export declare const describeProgress: (run: Progress) => string;
export declare const BackfillProvider: () => import("effect/Layer").Layer<Provider.Provider<Backfill>, never, import("alchemy").AlchemyContext | CloudflareEnvironment | workflows.CloudflareOpContext>;
export {};
//# sourceMappingURL=Backfill.d.ts.map