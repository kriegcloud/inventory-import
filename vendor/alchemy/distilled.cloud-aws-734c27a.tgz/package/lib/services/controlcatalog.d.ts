import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ControlArn = string;
export interface GetControlRequest {
    ControlArn: string;
}
export type ControlAlias = string;
export type ControlAliases = string[];
export type ControlBehavior = "PREVENTIVE" | "PROACTIVE" | "DETECTIVE" | (string & {});
export type ControlSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type ControlScope = "GLOBAL" | "REGIONAL" | (string & {});
export type RegionCode = string;
export type DeployableRegions = string[];
export interface RegionConfiguration {
    Scope: ControlScope;
    DeployableRegions?: string[] | undefined;
}
export type ImplementationType = string;
export type ImplementationIdentifier = string;
export interface ImplementationDetails {
    Type: string;
    Identifier?: string | undefined;
}
export type ParameterRequirementSummary = "REQUIRED" | "OPTIONAL" | "NONE" | (string & {});
export type ControlParameterRequirement = "REQUIRED" | "OPTIONAL" | (string & {});
export interface ControlParameter {
    Name: string;
    Requirement?: ControlParameterRequirement | undefined;
}
export type ControlParameters = ControlParameter[];
export type GovernedResource = string;
export type GovernedResources = string[];
export type GovernedProvider = string;
export type GovernedProviders = string[];
export interface GetControlResponse {
    Arn: string;
    Aliases?: string[] | undefined;
    Name: string;
    Description: string;
    Behavior: ControlBehavior;
    Severity?: ControlSeverity | undefined;
    RegionConfiguration: RegionConfiguration;
    Implementation?: ImplementationDetails | undefined;
    ParameterRequirementSummary?: ParameterRequirementSummary | undefined;
    Parameters?: ControlParameter[] | undefined;
    CreateTime?: Date | undefined;
    GovernedResources?: string[] | undefined;
    GovernedProviders?: string[] | undefined;
}
export type MaxListCommonControlsResults = number;
export type PaginationToken = string;
export type ObjectiveArn = string;
export interface ObjectiveResourceFilter {
    Arn?: string | undefined;
}
export type ObjectiveResourceFilterList = ObjectiveResourceFilter[];
export interface CommonControlFilter {
    Objectives?: ObjectiveResourceFilter[] | undefined;
}
export interface ListCommonControlsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    CommonControlFilter?: CommonControlFilter | undefined;
}
export type CommonControlArn = string;
export type DomainArn = string;
export interface AssociatedDomainSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export interface AssociatedObjectiveSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export interface CommonControlSummary {
    Arn: string;
    Name: string;
    Description: string;
    Domain: AssociatedDomainSummary;
    Objective: AssociatedObjectiveSummary;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export type CommonControlSummaryList = CommonControlSummary[];
export interface ListCommonControlsResponse {
    CommonControls: CommonControlSummary[];
    NextToken?: string | undefined;
}
export type MaxListControlMappingsResults = number;
export type ControlArnFilterList = string[];
export type CommonControlArnFilterList = string[];
export type MappingType = "FRAMEWORK" | "COMMON_CONTROL" | "RELATED_CONTROL" | (string & {});
export type MappingTypeFilterList = MappingType[];
export interface ControlMappingFilter {
    ControlArns?: string[] | undefined;
    CommonControlArns?: string[] | undefined;
    MappingTypes?: MappingType[] | undefined;
}
export interface ListControlMappingsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: ControlMappingFilter | undefined;
}
export type FrameworkName = string;
export type FrameworkItem = string;
export interface FrameworkMappingDetails {
    Name: string;
    Item: string;
}
export interface CommonControlMappingDetails {
    CommonControlArn: string;
}
export type ControlRelationType = "COMPLEMENTARY" | "ALTERNATIVE" | "MUTUALLY_EXCLUSIVE" | (string & {});
export interface RelatedControlMappingDetails {
    ControlArn?: string | undefined;
    RelationType: ControlRelationType;
}
export type Mapping = {
    Framework: FrameworkMappingDetails;
    CommonControl?: undefined;
    RelatedControl?: undefined;
} | {
    Framework?: undefined;
    CommonControl: CommonControlMappingDetails;
    RelatedControl?: undefined;
} | {
    Framework?: undefined;
    CommonControl?: undefined;
    RelatedControl: RelatedControlMappingDetails;
};
export interface ControlMapping {
    ControlArn: string;
    MappingType: MappingType;
    Mapping: Mapping;
}
export type ControlMappings = ControlMapping[];
export interface ListControlMappingsResponse {
    ControlMappings: ControlMapping[];
    NextToken?: string | undefined;
}
export type MaxListControlsResults = number;
export type ImplementationTypeFilterList = string[];
export type ImplementationIdentifierFilterList = string[];
export interface ImplementationFilter {
    Types?: string[] | undefined;
    Identifiers?: string[] | undefined;
}
export type GovernedProviderFilterList = string[];
export interface ControlFilter {
    Implementations?: ImplementationFilter | undefined;
    GovernedProviders?: string[] | undefined;
}
export interface ListControlsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filter?: ControlFilter | undefined;
}
export interface ImplementationSummary {
    Type: string;
    Identifier?: string | undefined;
}
export interface ControlSummary {
    Arn: string;
    Aliases?: string[] | undefined;
    Name: string;
    Description: string;
    Behavior?: ControlBehavior | undefined;
    Severity?: ControlSeverity | undefined;
    ParameterRequirementSummary?: ParameterRequirementSummary | undefined;
    Implementation?: ImplementationSummary | undefined;
    CreateTime?: Date | undefined;
    GovernedResources?: string[] | undefined;
    GovernedProviders?: string[] | undefined;
}
export type Controls = ControlSummary[];
export interface ListControlsResponse {
    Controls: ControlSummary[];
    NextToken?: string | undefined;
}
export type MaxListDomainsResults = number;
export interface ListDomainsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DomainSummary {
    Arn: string;
    Name: string;
    Description: string;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export type DomainSummaryList = DomainSummary[];
export interface ListDomainsResponse {
    Domains: DomainSummary[];
    NextToken?: string | undefined;
}
export type MaxListObjectivesResults = number;
export interface DomainResourceFilter {
    Arn?: string | undefined;
}
export type DomainResourceFilterList = DomainResourceFilter[];
export interface ObjectiveFilter {
    Domains?: DomainResourceFilter[] | undefined;
}
export interface ListObjectivesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ObjectiveFilter?: ObjectiveFilter | undefined;
}
export interface ObjectiveSummary {
    Arn: string;
    Name: string;
    Description: string;
    Domain: AssociatedDomainSummary;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export type ObjectiveSummaryList = ObjectiveSummary[];
export interface ListObjectivesResponse {
    Objectives: ObjectiveSummary[];
    NextToken?: string | undefined;
}
export type GetControlError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specific control, most notably a list of Amazon Web Services Regions where this control is supported. Input a value for the *ControlArn* parameter, in ARN form. `GetControl` accepts *controltower* or *controlcatalog* control ARNs as input. Returns a *controlcatalog* ARN format.
 *
 * In the API response, controls that have the value `GLOBAL` in the `Scope` field do not show the `DeployableRegions` field, because it does not apply. Controls that have the value `REGIONAL` in the `Scope` field return a value for the `DeployableRegions` field, as shown in the example.
 */
export declare const getControl: API.OperationMethod<GetControlRequest & RegionInput, GetControlResponse, GetControlError, Credentials | HttpClient.HttpClient>;
export type ListCommonControlsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of common controls from the Amazon Web Services Control Catalog.
 *
 * You can apply an optional filter to see common controls that have a specific objective. If you don't provide a filter, the operation returns all common controls.
 */
export declare const listCommonControls: API.PaginatedOperationMethod<ListCommonControlsRequest & RegionInput, ListCommonControlsResponse, ListCommonControlsError, Credentials | HttpClient.HttpClient, CommonControlSummary>;
export type ListControlMappingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of control mappings from the Control Catalog. Control mappings show relationships between controls and other entities, such as common controls or compliance frameworks.
 */
export declare const listControlMappings: API.PaginatedOperationMethod<ListControlMappingsRequest & RegionInput, ListControlMappingsResponse, ListControlMappingsError, Credentials | HttpClient.HttpClient, ControlMapping>;
export type ListControlsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all available controls in the Control Catalog library. Allows you to discover available controls. The list of controls is given as structures of type *controlSummary*. The ARN is returned in the global *controlcatalog* format, as shown in the examples.
 */
export declare const listControls: API.PaginatedOperationMethod<ListControlsRequest & RegionInput, ListControlsResponse, ListControlsError, Credentials | HttpClient.HttpClient, ControlSummary>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of domains from the Control Catalog.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest & RegionInput, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListObjectivesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of objectives from the Control Catalog.
 *
 * You can apply an optional filter to see the objectives that belong to a specific domain. If you don't provide a filter, the operation returns all objectives.
 */
export declare const listObjectives: API.PaginatedOperationMethod<ListObjectivesRequest & RegionInput, ListObjectivesResponse, ListObjectivesError, Credentials | HttpClient.HttpClient, ObjectiveSummary>;
export {};
//# sourceMappingURL=controlcatalog.d.ts.map