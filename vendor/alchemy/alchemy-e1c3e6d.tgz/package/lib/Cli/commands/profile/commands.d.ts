import { Command } from "effect/cli";
import * as Option from "effect/Option";
import * as Alchemist from "../../../Alchemist/index.ts";
import * as Interaction from "../../../Interaction.ts";
import { UserInputError } from "../errors.ts";
export declare const profileCommand: Command.Command<"profile", {
    readonly envFile: Option.Option<string>;
    readonly main: string;
} | {}, {}, Alchemist.AlchemistInvalidInput | Alchemist.AlchemistNotFound | import("../confirm.ts").ConfirmationDeclined | import("../../../Auth/Profile.ts").ProfileError | import("effect/cli/CliError").ShowHelp | UserInputError | import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersError | Interaction.InteractionError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
//# sourceMappingURL=commands.d.ts.map