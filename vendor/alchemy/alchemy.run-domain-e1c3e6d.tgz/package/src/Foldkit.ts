import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import * as Option from "effect/Option";
import type * as Rpc from "effect/rpc/Rpc";
import * as Schema from "effect/Schema";
import * as Stream from "effect/Stream";
import { Command, type Subscription } from "foldkit";
import { defineMessageUnion, type MessageUnion } from "foldkit/message";
import type * as Aggregate from "./Aggregate.ts";
import type * as Api from "./Api.ts";
import type * as DomainCommand from "./Command.ts";
import { sendPayload } from "./internal.ts";
import * as Key from "./Key.ts";
import type * as Middleware from "./Middleware.ts";
import type * as Query from "./Query.ts";
import * as Read from "./Read.ts";
import { nameOf } from "./ReadRpcs.ts";
import type * as DomainStream from "./Stream.ts";
import * as View from "./View.ts";

/** Per-call headers, resolved at execution time and excluded from replayable args. */
export class CommandHeaders extends Context.Service<
  CommandHeaders,
  {
    readonly get: (command: string) => Effect.Effect<Headers.Input>;
  }
>()("@alchemy.run/domain/Foldkit/CommandHeaders") {}

/** Page-local command id state. Give each page load a fresh session in Flags. */
export const CommandIds = Schema.Struct({ session: Schema.String, sent: Schema.Number });
/** Page-local command id state. */
export type CommandIds = typeof CommandIds.Type;

/** Allocate an id without reading time or changing the supplied state. */
export const next = (ids: CommandIds) => ({
  commandId: `${ids.session}:${ids.sent}`,
  commandIds: CommandIds.make({ session: ids.session, sent: ids.sent + 1 }),
});

type Input<C extends DomainCommand.Any> = Omit<C["Type"], "_tag">;
type Reply<C extends DomainCommand.Any> = C["reply"] extends Schema.Top ? C["reply"]["Type"] : void;
type Rejection<C extends DomainCommand.Any> = C["rejects"][number]["Type"];
type Denial<C extends DomainCommand.Any> = C["middleware"][number]["error"]["Type"];

/** A refusal is final; an unknown outcome can be retried with the same id. */
export type Failure<C extends DomainCommand.Any> =
  | Readonly<{ _tag: "Rejected"; rejection: Rejection<C> }>
  | Readonly<{ _tag: "Denied"; error: Denial<C> }>
  | Readonly<{ _tag: "Unknown" }>;

type QueryRejection<Q extends Query.Any> = Aggregate.InstanceOf<
  NonNullable<Q["definition"]["rejects"]>[number]
>;

type QueryRefusal<Q extends Query.Any> =
  | Readonly<{ _tag: "Rejected"; rejection: QueryRejection<Q> }>
  | Readonly<{ _tag: "Denied"; error: Middleware.Errors<Q["middleware"]> }>
  | Readonly<{ _tag: "Unknown" }>;

/**
 * A query refusal (`Rejected`, `Denied`) is final. `TimedOut` (only for a query with
 * `waitsFor`) means its projections did not reach `atLeast` in time; `Unknown` is transport or a defect.
 * Both can be asked again.
 */
export type QueryFailure<Q extends Query.Any> =
  NonNullable<Q["definition"]["waitsFor"]> extends readonly []
    ? QueryRefusal<Q>
    : QueryRefusal<Q> | Readonly<{ _tag: "TimedOut" }>;

type QueryCases<A extends Api.Any> = {
  readonly [Q in Api.QueriesOf<A> as `Succeeded${Q["queryName"]}`]: {
    requestId: typeof Schema.String;
    result: Schema.Schema<Query.ResultOf<Q>>;
  };
} & {
  readonly [Q in Api.QueriesOf<A> as `Failed${Q["queryName"]}`]: {
    requestId: typeof Schema.String;
    failure: Schema.Schema<QueryFailure<Q>>;
  };
};

type Cases<A extends Api.Any> = QueryCases<A> & {
  readonly [C in Api.CommandsOf<A> as `Succeeded${C["tag"]}`]: {
    commandId: typeof Schema.String;
    reply: Schema.Schema<Reply<C>>;
    /** The first stream it committed to: what a read takes as `atLeast`. */
    receipt: typeof Receipt;
    /** Every stream it committed to: more than one for a command a decision implements. */
    commits: Schema.$Array<typeof Receipt>;
  };
} & {
  readonly [C in Api.CommandsOf<A> as `Failed${C["tag"]}`]: {
    commandId: typeof Schema.String;
    failure: Schema.Schema<Failure<C>>;
  };
};

type Args<C extends DomainCommand.Any> = {
  input: Schema.Schema<Input<C>>;
  commandId: typeof Schema.String;
};
type Result<A extends Api.Any, C extends DomainCommand.Any> = Extract<
  MessageUnion<Cases<A>>["Type"],
  { readonly _tag: `Succeeded${C["tag"]}` | `Failed${C["tag"]}` }
>;

type QueryArgs<Q extends Query.Any> = {
  input: Schema.Schema<Query.InputOf<Q>>;
  requestId: typeof Schema.String;
  atLeast: Schema.optional<typeof Receipts>;
  after: Schema.optional<typeof Schema.String>;
  take: Schema.optional<typeof Schema.Number>;
};
type QueryResult<A extends Api.Any, Q extends Query.Any> = Extract<
  MessageUnion<Cases<A>>["Type"],
  { readonly _tag: `Succeeded${Q["queryName"]}` | `Failed${Q["queryName"]}` }
>;

/** Typed Command definitions and their result Message union, derived from an Api. */
type CommandDefinitions<A extends Api.Any> = {
  readonly [Q in Api.QueriesOf<A> as Q["queryName"]]: Command.CommandDefinitionWithArgs<
    Q["queryName"],
    QueryArgs<Q>,
    Effect.Effect<
      QueryResult<A, Q>,
      never,
      // A query client call needs no services of its own (Api.QueryClient).
      A["Client"]["Identifier"]
    >
  >;
} & {
  readonly [C in Api.CommandsOf<A> as C["tag"]]: Command.CommandDefinitionWithArgs<
    C["tag"],
    Args<C>,
    Effect.Effect<
      Result<A, C>,
      never,
      A["Client"]["Identifier"] | Effect.Services<ReturnType<Api.CommandClient<C>>>
    >
  >;
} & { readonly Message: MessageUnion<Cases<A>> };

const Receipt = Schema.Struct({ stream: Schema.String, version: Schema.Number });
/** A query's `atLeast`: one receipt, or one per command. */
const Receipts = Schema.Union([Receipt, Schema.Array(Receipt)]);

/** Build one Foldkit Command per Api command. Provide the Api client at the runtime boundary. */
function commandDefinitions<A extends Api.Any>(api: A): CommandDefinitions<A>;
function commandDefinitions(api: Api.Any): unknown {
  const cases: Record<string, Schema.Struct.Fields> = {};
  for (const command of api.commands) {
    const rejection = Schema.Union(command.rejects);
    const denial = Schema.Union(command.middleware.map((middleware) => middleware.error));
    cases[`Succeeded${command.tag}`] = {
      commandId: Schema.String,
      reply: command.reply ?? Schema.Void,
      receipt: Receipt,
      commits: Schema.Array(Receipt),
    };
    cases[`Failed${command.tag}`] = {
      commandId: Schema.String,
      failure: Schema.Union([
        Schema.TaggedStruct("Rejected", { rejection }),
        Schema.TaggedStruct("Denied", { error: denial }),
        Schema.TaggedStruct("Unknown", {}),
      ]),
    };
  }
  const queries = api.serves.filter((entry): entry is Query.Any => entry.kind === "Query");
  for (const query of queries) {
    const name = query.queryName;
    cases[`Succeeded${name}`] = {
      requestId: Schema.String,
      result: (query.rpc as Rpc.AnyWithProps).successSchema,
    };
    cases[`Failed${name}`] = {
      requestId: Schema.String,
      failure: Schema.Union([
        Schema.TaggedStruct("Rejected", {
          rejection: Schema.Union(query.definition.rejects ?? []),
        }),
        Schema.TaggedStruct("Denied", {
          error: Schema.Union(query.middleware.map((middleware) => middleware.error)),
        }),
        Schema.TaggedStruct("TimedOut", {}),
        Schema.TaggedStruct("Unknown", {}),
      ]),
    };
  }
  const Message = defineMessageUnion(cases);
  const definitions: Record<string, unknown> = { Message };
  for (const query of queries) {
    definitions[query.queryName] = queryDefinition(api, query, Message);
  }
  for (const command of api.commands) {
    const { payloadSchema } = command.rpc as Rpc.AnyWithProps;
    definitions[command.tag] = Command.define(command.tag, {
      args: {
        input: Schema.toType((payloadSchema as Schema.Struct<{ input: Schema.Top }>).fields.input),
        commandId: Schema.String,
      },
      messages: [Message],
      execute: Effect.fn(
        function* (args: { readonly input: unknown; readonly commandId: string }) {
          const { input, commandId } = args;
          const client = (yield* Effect.service(api.Client)) as Record<string, unknown>;
          const headersService = yield* Effect.serviceOption(CommandHeaders);
          const headers =
            headersService._tag === "Some"
              ? yield* headersService.value.get(command.tag)
              : undefined;
          const { reply, ...receipt } = (yield* sendPayload(
            client[command.tag],
            { ...args, input, commandId },
            { headers },
          )) as { reply: unknown; stream?: string; version?: number; commits?: unknown };
          return {
            _tag: `Succeeded${command.tag}`,
            commandId,
            reply,
            receipt: { stream: receipt.stream, version: receipt.version },
            commits: receipt.commits,
          };
        },
        (effect, { commandId }) =>
          effect.pipe(
            Effect.catchCauseIf(
              (cause) => Cause.hasFails(cause) || Cause.hasDies(cause),
              (cause) =>
                Effect.succeed({
                  _tag: `Failed${command.tag}`,
                  commandId,
                  failure: Cause.hasDies(cause)
                    ? { _tag: "Unknown" }
                    : classifyFailure(
                        command,
                        cause.pipe(Cause.findErrorOption, Option.getOrUndefined),
                      ),
                }),
            ),
          ),
      ),
    });
  }
  return definitions;
}

/** One Foldkit Command for one Api query; the reply Message carries the caller's `requestId`. */
const queryDefinition = (api: Api.Any, query: Query.Any, Message: Schema.Top) => {
  const name = query.queryName;
  const { payloadSchema } = query.rpc as Rpc.AnyWithProps;
  return Command.define(name, {
    args: {
      input: Schema.toType((payloadSchema as Schema.Struct<{ input: Schema.Top }>).fields.input),
      requestId: Schema.String,
      atLeast: Schema.optional(Receipts),
      after: Schema.optional(Schema.String),
      take: Schema.optional(Schema.Number),
    },
    messages: [Message],
    execute: Effect.fn(
      function* ({ input, requestId, atLeast, after, take }) {
        const client = (yield* Effect.service(api.Client)) as Record<
          string,
          (
            input: unknown,
            options: Query.RunOptions & { readonly headers?: Headers.Input | undefined },
          ) => Effect.Effect<unknown, unknown>
        >;
        const headersService = yield* Effect.serviceOption(CommandHeaders);
        const headers =
          headersService._tag === "Some" ? yield* headersService.value.get(name) : undefined;
        const result = yield* client[name](input, {
          headers,
          ...(atLeast === undefined ? {} : { atLeast }),
          ...(after === undefined ? {} : { after }),
          ...(take === undefined ? {} : { take }),
        });
        return { _tag: `Succeeded${name}`, requestId, result };
      },
      (effect, { requestId }) =>
        effect.pipe(
          Effect.catchCauseIf(
            (cause) => Cause.hasFails(cause) || Cause.hasDies(cause),
            (cause) =>
              Effect.succeed({
                _tag: `Failed${name}`,
                requestId,
                failure: Cause.hasDies(cause)
                  ? { _tag: "Unknown" }
                  : classifyQueryFailure(
                      query,
                      cause.pipe(Cause.findErrorOption, Option.getOrUndefined),
                    ),
              }),
          ),
        ),
    ),
  });
};

const classifyQueryFailure = (query: Query.Any, error: unknown) => {
  if ((query.definition.rejects ?? []).some((rejection) => Schema.is(rejection)(error))) {
    return { _tag: "Rejected", rejection: error };
  }
  if (query.middleware.some((middleware) => Schema.is(middleware.error)(error))) {
    return { _tag: "Denied", error };
  }
  if (Schema.is(View.ConsistencyTimeout)(error)) return { _tag: "TimedOut" };
  return { _tag: "Unknown" };
};

const classifyFailure = (command: DomainCommand.Any, error: unknown) => {
  if (command.rejects.some((rejection) => Schema.is(rejection)(error))) {
    return { _tag: "Rejected", rejection: error };
  }
  if (command.middleware.some((middleware) => Schema.is(middleware.error)(error))) {
    return { _tag: "Denied", error };
  }
  return { _tag: "Unknown" };
};

type ReadEntry = View.Any | DomainStream.Any;
type Reads<A extends Api.Any> = Extract<A["serves"][number], ReadEntry>;
type ReadName<V extends ReadEntry> = V extends View.Any
  ? V["viewName"]
  : V extends DomainStream.Any
    ? V["streamName"]
    : never;
type ReadClient<V extends ReadEntry> = V extends View.Any
  ? Api.ViewClient<V>
  : V extends DomainStream.Any
    ? Api.StreamClient<V>
    : never;
type ReadKey<V extends ReadEntry> = Parameters<ReadClient<V>["watch"]>[0];
type StateOf<V extends ReadEntry> = Stream.Success<ReturnType<ReadClient<V>["watch"]>>["state"];
type EntryOf<V extends ReadEntry> = Exclude<
  Stream.Success<ReturnType<ReadClient<V>["events"]>>,
  Read.CaughtUp
>;
type ErrorOf<V extends ReadEntry> = Stream.Error<ReturnType<ReadClient<V>["watch"]>>;
type ViewStateSchema<V extends View.Any> = [NonNullable<V["definition"]["state"]>] extends [never]
  ? typeof Schema.Never
  : Extract<NonNullable<V["definition"]["state"]>, Schema.Top>;
type ViewFlags<V extends View.Any> = ReturnType<typeof snapshotFlags<ViewStateSchema<V>>>;

/** A read namespace with Foldkit Subscription entries, bound to one Api entry. */
export interface ReadClientOf<A extends Api.Any, V extends ReadEntry> {
  readonly watch: <Model, Message>(
    options: WatchOptions<Model, Message, V>,
  ) => Subscription.EntryWithoutKeepAlive<
    Model,
    Message,
    { key: ReadKey<V>; isEnabled: boolean },
    A["Client"]["Identifier"]
  >;
  readonly events: <Model, Message>(
    options: EventsOptions<Model, Message, V>,
  ) => EventsSubscription<A, Model, Message, V>;
}

/** Commands and read namespaces computed from the Api's entries. Message is reserved. */
export type ClientOf<A extends Api.Any> = CommandDefinitions<A> & {
  readonly [V in Reads<A> as ReadName<V>]: ReadClientOf<A, V> &
    (V extends View.Any
      ? {
          readonly SnapshotFlags: ViewFlags<V>;
          readonly decodeSnapshotFlags: (flags: unknown) => Option.Option<ViewFlags<V>["Type"]>;
        }
      : {});
};

/** Build the Foldkit Commands and Subscriptions for an Api. The app provides api.layerClient in its runtime resources. */
export function make<A extends Api.Any>(
  api: A & ("Message" extends keyof Api.ClientOf<A> ? never : unknown),
): ClientOf<A>;
export function make(api: Api.Any): unknown {
  // The signature rejects an Api with an entry named Message; the result union is assigned last.
  const definitions = commandDefinitions(api) as Record<string, unknown>;
  const { Message } = definitions;
  for (const entry of api.serves) {
    if (entry.kind !== "View" && entry.kind !== "Stream") {
      continue;
    }
    const name = nameOf(entry);
    const flags =
      entry.kind === "View"
        ? snapshotFlags(
            (entry.definition.state ?? Schema.Never) as Schema.Schema<unknown> & {
              readonly DecodingServices: never;
            },
          )
        : undefined;
    definitions[name] = {
      watch: (options: WatchOptions<unknown, unknown, ReadEntry>) =>
        watchRead(api, entry, name, options),
      events: (options: EventsOptions<unknown, unknown, ReadEntry>) =>
        readEvents(api, entry, name, options),
      ...(flags === undefined
        ? {}
        : {
            SnapshotFlags: flags,
            decodeSnapshotFlags: Schema.decodeUnknownOption(flags),
          }),
    };
  }
  definitions.Message = Message;
  return definitions;
}

const keySchemaOf = (entry: ReadEntry) => entry.definition.key.pipe(Key.idSchemaOf, Schema.toType);

/** A watch Snapshot with explicit absence for Foldkit Models. */
export type Snapshot<State> = Readonly<{
  state: Option.Option<NonNullable<State>>;
  cursor: number;
}>;

/** Callbacks for live read state. Cursor changes do not restart the watch. */
export interface WatchOptions<Model, Message, V extends ReadEntry> {
  readonly key: (model: Model) => ReadKey<V>;
  readonly isEnabled?: (model: Model) => boolean;
  /** The snapshot, and the key it is of: a Model that keeps several keys files it under this one. */
  readonly toMessage: (snapshot: Snapshot<StateOf<V>>, key: ReadKey<V>) => Message;
  readonly onFailure: (error: ErrorOf<V>) => Message;
  /** Handle unexpected read defects. Interruption does not call this callback. */
  readonly onDefect: (cause: Cause.Cause<unknown>) => Message;
}

/** Follow read state and cursor. Pass the result as an entry to Subscription.make. */
function watchRead(
  api: Api.Any,
  entry: ReadEntry,
  name: string,
  options: WatchOptions<unknown, unknown, ReadEntry>,
): unknown {
  return {
    dependenciesSchema: Schema.Struct({
      key: keySchemaOf(entry),
      isEnabled: Schema.Boolean,
    }),
    modelToDependencies: (model: unknown) => ({
      key: options.key(model),
      isEnabled: options.isEnabled?.(model) ?? true,
    }),
    dependenciesToStream: ({ key, isEnabled }: { key: string; isEnabled: boolean }) =>
      isEnabled
        ? Stream.unwrap(
            api.Client.pipe(
              Effect.map((client) =>
                (client as Record<string, ReadClient<ReadEntry>>)[name].watch(key),
              ),
            ),
          ).pipe(
            Stream.map(({ state, cursor }) =>
              options.toMessage({ state: Option.fromNullishOr(state), cursor }, key),
            ),
            Stream.catchCause((cause) => {
              if (Cause.hasDies(cause)) {
                return Stream.succeed(options.onDefect(cause));
              }
              const error = Cause.findErrorOption(cause);
              return Option.isSome(error)
                ? Stream.succeed(options.onFailure(error.value))
                : Stream.failCause(cause);
            }),
          )
        : Stream.empty,
  };
}

/** Callbacks for a resumable event feed. The app stores the cursor after applying each entry. */
export interface EventsOptions<Model, Message, V extends ReadEntry> {
  readonly key: (model: Model) => ReadKey<V>;
  readonly cursor: (model: Model) => Option.Option<number>;
  readonly isEnabled?: (model: Model) => boolean;
  readonly restartKey?: (model: Model) => number;
  readonly onEntry: (entry: EntryOf<V>) => Message;
  /** Every stored entry of `key` has been delivered: what follows is live. */
  readonly onCaughtUp: (cursor: number, key: ReadKey<V>) => Message;
  readonly onFailure: (error: ErrorOf<V>) => Message;
  /** Handle unexpected read defects. Interruption does not call this callback. */
  readonly onDefect: (cause: Cause.Cause<unknown>) => Message;
}

/** Follow event entries after the Model's cursor, without counting sequence gaps. */
type EventsSubscription<A extends Api.Any, Model, Message, V extends ReadEntry> = {
  readonly dependenciesSchema: Schema.Struct<{
    key: Schema.Schema<ReadKey<V>>;
    cursor: Schema.Schema<Option.Option<number>>;
    restartKey: Schema.optional<typeof Schema.Number>;
    isEnabled: typeof Schema.Boolean;
  }>;
  readonly modelToDependencies: (model: Model) => {
    key: ReadKey<V>;
    cursor: Option.Option<number>;
    restartKey?: number;
    isEnabled: boolean;
  };
  readonly keepAliveEquivalence: (
    left: {
      key: ReadKey<V>;
      cursor: Option.Option<number>;
      restartKey?: number;
      isEnabled: boolean;
    },
    right: {
      key: ReadKey<V>;
      cursor: Option.Option<number>;
      restartKey?: number;
      isEnabled: boolean;
    },
  ) => boolean;
  readonly dependenciesToStream: (
    dependencies: {
      key: ReadKey<V>;
      cursor: Option.Option<number>;
      restartKey?: number;
      isEnabled: boolean;
    },
    readDependencies: () => {
      key: ReadKey<V>;
      cursor: Option.Option<number>;
      restartKey?: number;
      isEnabled: boolean;
    },
  ) => Stream.Stream<Message, never, A["Client"]["Identifier"]>;
};
function readEvents(
  api: Api.Any,
  entry: ReadEntry,
  name: string,
  options: EventsOptions<unknown, unknown, ReadEntry>,
): unknown {
  const keySchema = keySchemaOf(entry);
  const sameKey = Schema.toEquivalence(keySchema);
  type Dependencies = {
    key: string;
    cursor: Option.Option<number>;
    restartKey?: number;
    isEnabled: boolean;
  };
  return {
    dependenciesSchema: Schema.Struct({
      key: keySchema,
      cursor: Schema.Option(Schema.Number),
      restartKey: Schema.optional(Schema.Number),
      isEnabled: Schema.Boolean,
    }),
    modelToDependencies: (model: unknown): Dependencies => ({
      key: options.key(model),
      cursor: options.cursor(model),
      restartKey: options.restartKey?.(model),
      isEnabled: options.isEnabled?.(model) ?? true,
    }),
    keepAliveEquivalence: (left: Dependencies, right: Dependencies) =>
      sameKey(left.key, right.key) &&
      left.isEnabled === right.isEnabled &&
      left.restartKey === right.restartKey,
    dependenciesToStream: (_: Dependencies, readDependencies: () => Dependencies) =>
      Stream.suspend(() => {
        const { key, cursor, isEnabled } = readDependencies();
        if (!isEnabled) {
          return Stream.empty;
        }
        let deliveredCursor = Option.getOrElse(cursor, () => 0);
        return Stream.unwrap(
          api.Client.pipe(
            Effect.map((client) =>
              (client as Record<string, ReadClient<ReadEntry>>)[name].events(key, {
                after: Option.getOrUndefined(cursor),
              }),
            ),
          ),
        ).pipe(
          Stream.filter((frame) => {
            if (Read.isCaughtUp(frame)) {
              return true;
            }
            const appliedCursor = Option.getOrElse(readDependencies().cursor, () => 0);
            if (frame.envelope.seq <= Math.max(deliveredCursor, appliedCursor)) {
              return false;
            }
            deliveredCursor = frame.envelope.seq;
            return true;
          }),
          Stream.map((frame) =>
            Read.isCaughtUp(frame) ? options.onCaughtUp(frame.cursor, key) : options.onEntry(frame),
          ),
          Stream.catchCause((cause) => {
            if (Cause.hasDies(cause)) {
              return Stream.succeed(options.onDefect(cause));
            }
            const error = Cause.findErrorOption(cause);
            return Option.isSome(error)
              ? Stream.succeed(options.onFailure(error.value))
              : Stream.failCause(cause);
          }),
        );
      }),
  };
}

/** Decode snapshot wire data in Flags, converting null state to Option.none. */
const snapshotFlags = <State extends Schema.Top>(state: State) =>
  Schema.Struct({
    state: Schema.OptionFromNullOr(state),
    cursor: Schema.Number.check(Schema.isInt(), Schema.isGreaterThanOrEqualTo(0)),
  });
