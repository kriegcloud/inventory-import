import * as Logger from "effect/Logger";
import type * as LogLevel from "effect/LogLevel";
export interface PrettyLoggerOptions {
    /**
     * Color the prefix and resource tag, and keep the styling child processes
     * wrote (vite, workerd); without colors their text is stripped.
     * @default colorsEnabled()
     */
    readonly colors?: boolean;
}
/** One terminal line: `[12:00:00.000] INFO: [Site/Worker] text`. */
export declare const prettyLine: (options: {
    readonly date: Date;
    readonly level: LogLevel.Severity;
    readonly text: string;
    readonly resource?: string;
    readonly colors?: boolean;
}) => string;
/**
 * The terminal rendering of a log record: `log` and `output` records (typed
 * events are drawn by the renderers subscribed to them). The resource tag
 * comes from the record, so producers log plain text and never format it.
 */
export declare const makePlainConsoleSink: (options?: PrettyLoggerOptions) => Logger.Logger<unknown, void>;
//# sourceMappingURL=ConsoleSink.d.ts.map