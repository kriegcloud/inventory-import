import * as Layer from "effect/Layer";
import { KeyWrap } from "./KeyWrap.ts";
/**
 * Keys stored as they are, with no root key over them. Whoever can read the
 * {@link KeyStore} can open what it sealed.
 *
 * @layer
 * @provides Domain.KeyWrap
 */
export declare const NoKeyWrap: Layer.Layer<KeyWrap>;
//# sourceMappingURL=NoKeyWrap.d.ts.map