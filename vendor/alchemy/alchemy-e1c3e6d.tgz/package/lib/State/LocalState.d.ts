import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import { State, type StateService } from "./State.ts";
/**
 * The local store's format record, kept beside the state directory rather
 * than in it: versions from before format records list every entry of the
 * state directory as a stack, and fail on one that isn't a directory.
 */
export declare const LOCAL_STORE_FORMAT_FILE = "state.format.json";
export declare const localState: () => Layer.Layer<State, never, FileSystem.FileSystem | Path.Path>;
export declare const makeLocalState: () => Effect.Effect<StateService, never, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=LocalState.d.ts.map