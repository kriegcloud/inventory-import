import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateFeedbackRequestRequestsByAttribute {
    metric: string;
    requests: number;
}
export type CreateFeedbackRequestRequestsByScoreMap = {
    [key: string]: number | undefined;
};
export type CreateFeedbackRequestRequestsByScoreSrcMap = {
    [key: string]: number | undefined;
};
export type CreateFeedbackRequestType = "false_positive" | "false_negative";
export interface CreateFeedbackRequest {
    /** Identifier. */
    zoneId: string;
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: CreateFeedbackRequestRequestsByScoreMap;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: CreateFeedbackRequestRequestsByScoreSrcMap;
    /** Type of feedback report. */
    type: CreateFeedbackRequestType | (string & {});
    subtype?: string | undefined;
}
export interface CreateFeedbackResponse {
}
export interface GetBotManagementRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResultBotFightModeConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface GetResultBotFightModeConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: GetResultBotFightModeConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: GetResultBotFightModeConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: GetResultBotFightModeConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: GetResultBotFightModeConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: GetResultBotFightModeConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type GetResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export interface GetResultBotFightModeConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null | undefined;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null | undefined;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null | undefined;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null | undefined;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean | null | undefined;
}
export interface GetResultBotFightModeConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: GetResultBotFightModeConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultBotFightModeConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultBotFightModeConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultBotFightModeConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultBotFightModeConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultBotFightModeConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultBotFightModeConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultBotFightModeConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface GetResultSuperBotFightModeDefinitelyConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export interface GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null | undefined;
}
export interface GetResultSuperBotFightModeDefinitelyConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: GetResultSuperBotFightModeDefinitelyConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSuperBotFightModeDefinitelyConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSuperBotFightModeDefinitelyConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSuperBotFightModeDefinitelyConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type GetResultSuperBotFightModeLikelyConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface GetResultSuperBotFightModeLikelyConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: GetResultSuperBotFightModeLikelyConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: GetResultSuperBotFightModeLikelyConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: GetResultSuperBotFightModeLikelyConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: GetResultSuperBotFightModeLikelyConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: GetResultSuperBotFightModeLikelyConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export type GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export interface GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null | undefined;
}
export interface GetResultSuperBotFightModeLikelyConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: GetResultSuperBotFightModeLikelyConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSuperBotFightModeLikelyConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSuperBotFightModeLikelyConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSuperBotFightModeLikelyConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: GetResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: GetResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type GetResultSubscriptionConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface GetResultSubscriptionConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: GetResultSubscriptionConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: GetResultSubscriptionConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: GetResultSubscriptionConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: GetResultSubscriptionConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: GetResultSubscriptionConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type GetResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type GetResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export type GetResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export type GetResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export interface GetResultSubscriptionConfigurationStaleZoneConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | null | undefined;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | null | undefined;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | null | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | null | undefined;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | null | undefined;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | null | undefined;
}
export interface GetResultSubscriptionConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: GetResultSubscriptionConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: GetResultSubscriptionConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: GetResultSubscriptionConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: GetResultSubscriptionConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: GetResultSubscriptionConfigurationAiUser | null | undefined;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null | undefined;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: GetResultSubscriptionConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: GetResultSubscriptionConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: GetResultSubscriptionConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null | undefined;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type GetResult = GetResultBotFightModeConfiguration | GetResultSuperBotFightModeDefinitelyConfiguration | GetResultSuperBotFightModeLikelyConfiguration | GetResultSubscriptionConfiguration;
export type GetBotManagementResponse = GetResult;
export interface ListFeedbackRequest {
    /** Identifier. */
    zoneId: string;
}
export type ListFeedbackResponseRequestsByAttribute = CreateFeedbackRequestRequestsByAttribute;
export type ListFeedbackResponseRequestsByScoreMap = {
    [key: string]: number | undefined;
};
export type ListFeedbackResponseRequestsByScoreSrcMap = {
    [key: string]: number | undefined;
};
export type ListFeedbackResponseType = "false_positive" | "false_negative";
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListFeedbackResponse {
    description: string;
    /** Wirefilter expression describing the traffic being reported. */
    expression: string;
    firstRequestSeenAt: string;
    lastRequestSeenAt: string;
    requests: number;
    /** Top attributes contributing to the feedback sample. Keys include topASNs, topCountries, topHosts, topIPs, topJA3Hashes, topJA4s, topPaths, topUserAgents. */
    requestsByAttribute: CreateFeedbackRequestRequestsByAttribute;
    /** Map of bot scores (1-99) to request counts. Sum must equal `requests`. */
    requestsByScore: ListFeedbackResponseRequestsByScoreMap;
    /** Map of score source to request counts. Sum must equal `requests`. */
    requestsByScoreSrc: ListFeedbackResponseRequestsByScoreSrcMap;
    /** Type of feedback report. */
    type: ListFeedbackResponseType;
    createdAt?: string | null | undefined;
    subtype?: string | null | undefined;
}
export type UpdateRequestAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface UpdateRequestAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: UpdateRequestAiAgentsAnthropicAgent | (string & {}) | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: UpdateRequestAiAgentsGoogleAgent | (string & {}) | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: UpdateRequestAiAgentsInstinct | (string & {}) | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: UpdateRequestAiAgentsMuse | (string & {}) | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: UpdateRequestAiAgentsOpenaiAgent | (string & {}) | undefined;
}
export type UpdateRequestAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateRequestAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateRequestAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateRequestCfRobotsVariant = "off" | "policy_only";
export type UpdateRequestContentBotsProtection = "block" | "disabled";
export type UpdateRequestCrawlerProtection = "enabled" | "disabled";
export interface UpdateRequestStaleZoneConfigurationBotFightModeConfiguration {
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | undefined;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | undefined;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | undefined;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | undefined;
    /** Indicates that the zone's session score tracking is disabled. */
    suppressSessionScore?: boolean | undefined;
}
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | undefined;
}
export interface UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | undefined;
}
export interface UpdateRequestStaleZoneConfigurationSubscriptionConfiguration {
    /** Indicates that the zone's Bot Fight Mode is turned on. */
    fightMode?: boolean | undefined;
    /** Indicates that the zone's wordpress optimization for SBFM is turned on. */
    optimizeWordpress?: boolean | undefined;
    /** Indicates that the zone's definitely automated requests are being blocked or challenged. */
    sbfmDefinitelyAutomated?: string | undefined;
    /** Indicates that the zone's likely automated requests are being blocked or challenged. */
    sbfmLikelyAutomated?: string | undefined;
    /** Indicates that the zone's static resource protection is turned on. */
    sbfmStaticResourceProtection?: string | undefined;
    /** Indicates that the zone's verified bot requests are being blocked. */
    sbfmVerifiedBots?: string | undefined;
}
export type UpdateRequestStaleZoneConfiguration = UpdateRequestStaleZoneConfigurationBotFightModeConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeDefinitelyConfiguration | UpdateRequestStaleZoneConfigurationSuperBotFightModeLikelyConfiguration | UpdateRequestStaleZoneConfigurationSubscriptionConfiguration;
export type UpdateRequestSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateRequestSbfmVerifiedBots = "allow" | "block";
export type UpdateRequestSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export interface PutBotManagementRequest {
    /** Identifier. */
    zoneId: string;
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: UpdateRequestAiAgents | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateRequestAiBotsProtection | (string & {}) | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateRequestAiSearch | (string & {}) | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateRequestAiTraining | (string & {}) | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateRequestAiUser | (string & {}) | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateRequestCfRobotsVariant | (string & {}) | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateRequestContentBotsProtection | (string & {}) | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateRequestCrawlerProtection | (string & {}) | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | undefined;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: UpdateRequestStaleZoneConfiguration | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | undefined;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateRequestSbfmDefinitelyAutomated | (string & {}) | undefined;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateRequestSbfmVerifiedBots | (string & {}) | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateRequestSbfmLikelyAutomated | (string & {}) | undefined;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | undefined;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | undefined;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | undefined;
}
export type UpdateResultBotFightModeConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface UpdateResultBotFightModeConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: UpdateResultBotFightModeConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: UpdateResultBotFightModeConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: UpdateResultBotFightModeConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: UpdateResultBotFightModeConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: UpdateResultBotFightModeConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type UpdateResultBotFightModeConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultBotFightModeConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultBotFightModeConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultBotFightModeConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultBotFightModeConfigurationStaleZoneConfiguration = GetResultBotFightModeConfigurationStaleZoneConfiguration;
export interface UpdateResultBotFightModeConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: UpdateResultBotFightModeConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultBotFightModeConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultBotFightModeConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultBotFightModeConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultBotFightModeConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultBotFightModeConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultBotFightModeConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultBotFightModeConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Whether to enable Bot Fight Mode. */
    fightMode?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultBotFightModeConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots = "allow" | "block";
export type UpdateResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration;
export interface UpdateResultSuperBotFightModeDefinitelyConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSuperBotFightModeDefinitelyConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeDefinitelyConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeDefinitelyConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmDefinitelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeDefinitelyConfigurationSbfmVerifiedBots | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeDefinitelyConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface UpdateResultSuperBotFightModeLikelyConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated = "allow" | "block" | "managed_challenge";
export type UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots = "allow" | "block";
export type UpdateResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration = GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration;
export interface UpdateResultSuperBotFightModeLikelyConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: UpdateResultSuperBotFightModeLikelyConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSuperBotFightModeLikelyConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSuperBotFightModeLikelyConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSuperBotFightModeLikelyConfigurationAiUser | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSuperBotFightModeLikelyConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSuperBotFightModeLikelyConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSuperBotFightModeLikelyConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** Whether to optimize Super Bot Fight Mode protections for Wordpress. */
    optimizeWordpress?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on definitely automated requests. */
    sbfmDefinitelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmDefinitelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on likely automated requests. */
    sbfmLikelyAutomated?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmLikelyAutomated | null | undefined;
    /** Super Bot Fight Mode (SBFM) to enable static resource protection. Enable if static resources on your application need bot protection. Note: Static resource protection can also result in legitimate traffic being blocked. */
    sbfmStaticResourceProtection?: boolean | null | undefined;
    /** Super Bot Fight Mode (SBFM) action to take on verified bots requests. */
    sbfmVerifiedBots?: UpdateResultSuperBotFightModeLikelyConfigurationSbfmVerifiedBots | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSuperBotFightModeLikelyConfigurationStaleZoneConfiguration | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type UpdateResultSubscriptionConfigurationAiAgentsAnthropicAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiAgentsGoogleAgent = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiAgentsInstinct = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiAgentsMuse = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiAgentsOpenaiAgent = "disabled" | "block" | "only_on_ad_pages";
export interface UpdateResultSubscriptionConfigurationAiAgents {
    /** Action to apply to one supported personal AI agent. */
    anthropicAgent?: UpdateResultSubscriptionConfigurationAiAgentsAnthropicAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    googleAgent?: UpdateResultSubscriptionConfigurationAiAgentsGoogleAgent | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    instinct?: UpdateResultSubscriptionConfigurationAiAgentsInstinct | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    muse?: UpdateResultSubscriptionConfigurationAiAgentsMuse | null | undefined;
    /** Action to apply to one supported personal AI agent. */
    openaiAgent?: UpdateResultSubscriptionConfigurationAiAgentsOpenaiAgent | null | undefined;
}
export type UpdateResultSubscriptionConfigurationAiBotsProtection = "block" | "disabled" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiSearch = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiTraining = "disabled" | "disallow" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationAiUser = "disabled" | "block" | "only_on_ad_pages";
export type UpdateResultSubscriptionConfigurationCfRobotsVariant = "off" | "policy_only";
export type UpdateResultSubscriptionConfigurationContentBotsProtection = "block" | "disabled";
export type UpdateResultSubscriptionConfigurationCrawlerProtection = "enabled" | "disabled";
export type UpdateResultSubscriptionConfigurationStaleZoneConfiguration = GetResultSubscriptionConfigurationStaleZoneConfiguration;
export interface UpdateResultSubscriptionConfiguration {
    /** Configure blocking behavior for supported personal AI agents. */
    aiAgents?: UpdateResultSubscriptionConfigurationAiAgents | null | undefined;
    /** Temporary migration flag tracking zones opted out of AI bots managed-rule updates. */
    aiBotsMigrationOptOut?: boolean | null | undefined;
    /** Enable rule to block AI Scrapers and Crawlers. */
    aiBotsProtection?: UpdateResultSubscriptionConfigurationAiBotsProtection | null | undefined;
    /** Configure robots.txt policy for AI search bots. */
    aiSearch?: UpdateResultSubscriptionConfigurationAiSearch | null | undefined;
    /** Configure robots.txt policy for AI model training bots. */
    aiTraining?: UpdateResultSubscriptionConfigurationAiTraining | null | undefined;
    /** Configure robots.txt policy for AI assistant and agent bots. */
    aiUser?: UpdateResultSubscriptionConfigurationAiUser | null | undefined;
    /** Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes) */
    autoUpdateModel?: boolean | null | undefined;
    /** Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true */
    bmCookieEnabled?: boolean | null | undefined;
    /** Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences. */
    botPreferenceSyncEnabled?: boolean | null | undefined;
    /** Specifies the Robots Access Control License variant to use. */
    cfRobotsVariant?: UpdateResultSubscriptionConfigurationCfRobotsVariant | null | undefined;
    /** Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules. */
    contentBotsProtection?: UpdateResultSubscriptionConfigurationContentBotsProtection | null | undefined;
    /** Enable rule to punish AI Scrapers and Crawlers via a link maze. */
    crawlerProtection?: UpdateResultSubscriptionConfigurationCrawlerProtection | null | undefined;
    /** Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/). */
    enableJs?: boolean | null | undefined;
    /** Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt. */
    isRobotsTxtManaged?: boolean | null | undefined;
    /** Whether to use JavaScript Detection results submitted through the API for this zone. */
    jsdApiResultsEnabled?: boolean | null | undefined;
    /** A read-only field that shows which unauthorized settings are currently active on the zone. These settings typically result from upgrades or downgrades. */
    staleZoneConfiguration?: GetResultSubscriptionConfigurationStaleZoneConfiguration | null | undefined;
    /** Whether to disable tracking the highest bot score for a session in the Bot Management cookie. */
    suppressSessionScore?: boolean | null | undefined;
    /** A read-only field that indicates whether the zone currently is running the latest ML model. */
    usingLatestModel?: boolean | null | undefined;
}
export type UpdateResult = UpdateResultBotFightModeConfiguration | UpdateResultSuperBotFightModeDefinitelyConfiguration | UpdateResultSuperBotFightModeLikelyConfiguration | UpdateResultSubscriptionConfiguration;
export type PutBotManagementResponse = UpdateResult;
export type CreateFeedbackError = CloudflareOpError;
/** Submit a feedback report for the specified zone. Use `type` to indicate whether the report is a false positive (good traffic flagged as bot) or a false negative (bot traffic missed). Furthermore, you can also use `expression` as a wirefilter to identify the affected traffic sample. See more accepted API fields and expression types at https://developers.cloudflare.com/bots/concepts/feedback-loop/#api-fields and https://developers.cloudflare.com/bots/concepts/feedback-loop/#expression-fields, respectively. */
export declare const createFeedback: API.OperationMethod<CreateFeedbackRequest, CreateFeedbackResponse, CreateFeedbackError, CloudflareOpContext>;
export type GetBotManagementError = Forbidden | CloudflareOpError;
/** Retrieve a zone's Bot Management Config */
export declare const getBotManagement: API.OperationMethod<GetBotManagementRequest, GetBotManagementResponse, GetBotManagementError, CloudflareOpContext>;
export type ListFeedbackError = CloudflareOpError;
/** Returns all feedback reports previously submitted for the specified zone. Feedback reports help improve detection by sharing samples of traffic that were misclassified as bots or humans. */
export declare const listFeedback: API.OperationMethod<ListFeedbackRequest, ListFeedbackResponse, ListFeedbackError, CloudflareOpContext>;
export type PutBotManagementError = Forbidden | CloudflareOpError;
/** Updates the Bot Management configuration for a zone. This API is used to update: - **Bot Fight Mode** - **Super Bot Fight Mode** - **Bot Management for Enterprise** See [Bot Plans](https://developers.cloudflare.com/bots/plans/) for more information on the different plans If you recently upgraded or downgraded your plan, refer to the following examples to clean up old configurations. Copy and paste the example body to remove old zone configurations based on your current plan. */
export declare const putBotManagement: API.OperationMethod<PutBotManagementRequest, PutBotManagementResponse, PutBotManagementError, CloudflareOpContext>;
//# sourceMappingURL=bot_management.d.ts.map