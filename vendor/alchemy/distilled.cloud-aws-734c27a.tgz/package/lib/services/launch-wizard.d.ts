import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceLimitException_base: S.TaggedErrorClass<"ResourceLimitException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitException extends /*@__PURE__*/ ResourceLimitException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type WorkloadName = string;
export type DeploymentPatternName = string;
export type DeploymentName = string;
export type KeyString = string;
export type ValueString = string;
export type DeploymentSpecifications = {
    [key: string]: string | undefined;
};
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateDeploymentInput {
    workloadName: string;
    deploymentPatternName: string;
    name: string;
    specifications: {
        [key: string]: string | undefined;
    };
    dryRun?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DeploymentId = string;
export interface CreateDeploymentOutput {
    deploymentId?: string | undefined;
}
export interface DeleteDeploymentInput {
    deploymentId: string;
}
export type DeploymentStatus = "COMPLETED" | "CREATING" | "DELETE_IN_PROGRESS" | "DELETE_INITIATING" | "DELETE_FAILED" | "DELETED" | "FAILED" | "IN_PROGRESS" | "VALIDATING" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETED" | "UPDATE_FAILED" | "UPDATE_ROLLBACK_COMPLETED" | "UPDATE_ROLLBACK_FAILED" | (string & {});
export interface DeleteDeploymentOutput {
    status?: DeploymentStatus | undefined;
    statusReason?: string | undefined;
}
export interface GetDeploymentInput {
    deploymentId: string;
}
export interface DeploymentData {
    name?: string | undefined;
    id?: string | undefined;
    workloadName?: string | undefined;
    patternName?: string | undefined;
    status?: DeploymentStatus | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    specifications?: {
        [key: string]: string | undefined;
    } | undefined;
    resourceGroup?: string | undefined;
    deletedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    deploymentArn?: string | undefined;
}
export interface GetDeploymentOutput {
    deployment?: DeploymentData | undefined;
}
export type DeploymentPatternVersionName = string;
export interface GetDeploymentPatternVersionInput {
    workloadName: string;
    deploymentPatternName: string;
    deploymentPatternVersionName: string;
}
export interface DeploymentPatternVersionDataSummary {
    deploymentPatternVersionName?: string | undefined;
    description?: string | undefined;
    documentationUrl?: string | undefined;
    workloadName?: string | undefined;
    deploymentPatternName?: string | undefined;
}
export interface GetDeploymentPatternVersionOutput {
    deploymentPatternVersion?: DeploymentPatternVersionDataSummary | undefined;
}
export interface GetWorkloadInput {
    workloadName: string;
}
export type WorkloadStatus = "ACTIVE" | "INACTIVE" | "DISABLED" | "DELETED" | (string & {});
export interface ManagementAccountConstraint {
}
export type ServicePrincipalType = string;
export interface DelegatedAdminConstraint {
    servicePrincipal: string;
}
export type AccountConstraint = {
    managementAccount: ManagementAccountConstraint;
    delegatedAdmin?: undefined;
} | {
    managementAccount?: undefined;
    delegatedAdmin: DelegatedAdminConstraint;
};
export type AccountConstraintsList = AccountConstraint[];
export interface WorkloadData {
    workloadName?: string | undefined;
    displayName?: string | undefined;
    status?: WorkloadStatus | undefined;
    accountConstraints?: AccountConstraint[] | undefined;
    description?: string | undefined;
    documentationUrl?: string | undefined;
    iconUrl?: string | undefined;
    statusMessage?: string | undefined;
}
export interface GetWorkloadOutput {
    workload?: WorkloadData | undefined;
}
export interface GetWorkloadDeploymentPatternInput {
    workloadName: string;
    deploymentPatternName: string;
}
export type WorkloadVersionName = string;
export type WorkloadDeploymentPatternStatus = "ACTIVE" | "INACTIVE" | "DISABLED" | "DELETED" | (string & {});
export type AllowedValues = string[];
export interface DeploymentConditionalField {
    name?: string | undefined;
    value?: string | undefined;
    comparator?: string | undefined;
}
export type SpecificationsConditionalData = DeploymentConditionalField[];
export interface DeploymentSpecificationsField {
    name?: string | undefined;
    description?: string | undefined;
    allowedValues?: string[] | undefined;
    required?: string | undefined;
    conditionals?: DeploymentConditionalField[] | undefined;
}
export type DeploymentSpecificationsData = DeploymentSpecificationsField[];
export interface WorkloadDeploymentPatternData {
    workloadName?: string | undefined;
    deploymentPatternName?: string | undefined;
    workloadVersionName?: string | undefined;
    deploymentPatternVersionName?: string | undefined;
    displayName?: string | undefined;
    description?: string | undefined;
    status?: WorkloadDeploymentPatternStatus | undefined;
    statusMessage?: string | undefined;
    accountConstraints?: AccountConstraint[] | undefined;
    specifications?: DeploymentSpecificationsField[] | undefined;
}
export interface GetWorkloadDeploymentPatternOutput {
    workloadDeploymentPattern?: WorkloadDeploymentPatternData | undefined;
}
export type MaxDeploymentEventResults = number;
export type NextToken = string;
export interface ListDeploymentEventsInput {
    deploymentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type EventStatus = "CANCELED" | "CANCELING" | "COMPLETED" | "CREATED" | "FAILED" | "IN_PROGRESS" | "PENDING" | "TIMED_OUT" | (string & {});
export type DeploymentEventMetadataKey = string;
export type DeploymentEventMetadataValue = string;
export type DeploymentEventMetadata = {
    [key: string]: string | undefined;
};
export interface DeploymentEventDataSummary {
    name?: string | undefined;
    description?: string | undefined;
    status?: EventStatus | undefined;
    statusReason?: string | undefined;
    timestamp?: Date | undefined;
    metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DeploymentEventDataSummaryList = DeploymentEventDataSummary[];
export interface ListDeploymentEventsOutput {
    deploymentEvents?: DeploymentEventDataSummary[] | undefined;
    nextToken?: string | undefined;
}
export type MaxWorkloadResults = number;
export type DeploymentPatternVersionFilterKey = "updateFromVersion" | (string & {});
export type DeploymentPatternVersionFilterValue = string;
export type DeploymentPatternVersionFilterValues = string[];
export interface DeploymentPatternVersionFilter {
    name: DeploymentPatternVersionFilterKey;
    values: string[];
}
export type FilterList = DeploymentPatternVersionFilter[];
export interface ListDeploymentPatternVersionsInput {
    workloadName: string;
    deploymentPatternName: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: DeploymentPatternVersionFilter[] | undefined;
}
export type DeploymentPatternVersionDataSummaryList = DeploymentPatternVersionDataSummary[];
export interface ListDeploymentPatternVersionsOutput {
    deploymentPatternVersions?: DeploymentPatternVersionDataSummary[] | undefined;
    nextToken?: string | undefined;
}
export type DeploymentFilterKey = "WORKLOAD_NAME" | "DEPLOYMENT_STATUS" | (string & {});
export type DeploymentFilterValue = string;
export type DeploymentFilterValues = string[];
export interface DeploymentFilter {
    name?: DeploymentFilterKey | undefined;
    values?: string[] | undefined;
}
export type DeploymentFilterList = DeploymentFilter[];
export type MaxDeploymentResults = number;
export interface ListDeploymentsInput {
    filters?: DeploymentFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DeploymentDataSummary {
    name?: string | undefined;
    id?: string | undefined;
    workloadName?: string | undefined;
    patternName?: string | undefined;
    status?: DeploymentStatus | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
}
export type DeploymentDataSummaryList = DeploymentDataSummary[];
export interface ListDeploymentsOutput {
    deployments?: DeploymentDataSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MaxWorkloadDeploymentPatternResults = number;
export interface ListWorkloadDeploymentPatternsInput {
    workloadName: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkloadDeploymentPatternDataSummary {
    workloadName?: string | undefined;
    deploymentPatternName?: string | undefined;
    workloadVersionName?: string | undefined;
    deploymentPatternVersionName?: string | undefined;
    displayName?: string | undefined;
    description?: string | undefined;
    status?: WorkloadDeploymentPatternStatus | undefined;
    statusMessage?: string | undefined;
    accountConstraints?: AccountConstraint[] | undefined;
}
export type WorkloadDeploymentPatternDataSummaryList = WorkloadDeploymentPatternDataSummary[];
export interface ListWorkloadDeploymentPatternsOutput {
    workloadDeploymentPatterns?: WorkloadDeploymentPatternDataSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListWorkloadsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface WorkloadDataSummary {
    workloadName?: string | undefined;
    displayName?: string | undefined;
    status?: WorkloadStatus | undefined;
    accountConstraints?: AccountConstraint[] | undefined;
}
export type WorkloadDataSummaryList = WorkloadDataSummary[];
export interface ListWorkloadsOutput {
    workloads?: WorkloadDataSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateDeploymentInput {
    deploymentId: string;
    specifications: {
        [key: string]: string | undefined;
    };
    workloadVersionName?: string | undefined;
    deploymentPatternVersionName?: string | undefined;
    dryRun?: boolean | undefined;
    force?: boolean | undefined;
}
export interface UpdateDeploymentOutput {
    deployment?: DeploymentDataSummary | undefined;
}
export type CreateDeploymentError = InternalServerException | ResourceLimitException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a deployment for the given workload. Deployments created by this operation are not available in the Launch Wizard console to use the `Clone deployment` action on.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentInput & RegionInput, CreateDeploymentOutput, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = InternalServerException | ResourceLimitException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a deployment.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentInput & RegionInput, DeleteDeploymentOutput, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the deployment.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentInput & RegionInput, GetDeploymentOutput, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentPatternVersionError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about a deployment pattern version.
 */
export declare const getDeploymentPatternVersion: API.OperationMethod<GetDeploymentPatternVersionInput & RegionInput, GetDeploymentPatternVersionOutput, GetDeploymentPatternVersionError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a workload.
 */
export declare const getWorkload: API.OperationMethod<GetWorkloadInput & RegionInput, GetWorkloadOutput, GetWorkloadError, Credentials | HttpClient.HttpClient>;
export type GetWorkloadDeploymentPatternError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns details for a given workload and deployment pattern, including the available specifications. You can use the ListWorkloads operation to discover the available workload names and the ListWorkloadDeploymentPatterns operation to discover the available deployment pattern names of a given workload.
 */
export declare const getWorkloadDeploymentPattern: API.OperationMethod<GetWorkloadDeploymentPatternInput & RegionInput, GetWorkloadDeploymentPatternOutput, GetWorkloadDeploymentPatternError, Credentials | HttpClient.HttpClient>;
export type ListDeploymentEventsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the events of a deployment.
 */
export declare const listDeploymentEvents: API.PaginatedOperationMethod<ListDeploymentEventsInput & RegionInput, ListDeploymentEventsOutput, ListDeploymentEventsError, Credentials | HttpClient.HttpClient, DeploymentEventDataSummary>;
export type ListDeploymentPatternVersionsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the deployment pattern versions.
 */
export declare const listDeploymentPatternVersions: API.PaginatedOperationMethod<ListDeploymentPatternVersionsInput & RegionInput, ListDeploymentPatternVersionsOutput, ListDeploymentPatternVersionsError, Credentials | HttpClient.HttpClient, DeploymentPatternVersionDataSummary>;
export type ListDeploymentsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the deployments that have been created.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsInput & RegionInput, ListDeploymentsOutput, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentDataSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadDeploymentPatternsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the workload deployment patterns for a given workload name. You can use the ListWorkloads operation to discover the available workload names.
 */
export declare const listWorkloadDeploymentPatterns: API.PaginatedOperationMethod<ListWorkloadDeploymentPatternsInput & RegionInput, ListWorkloadDeploymentPatternsOutput, ListWorkloadDeploymentPatternsError, Credentials | HttpClient.HttpClient, WorkloadDeploymentPatternDataSummary>;
export type ListWorkloadsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the available workload names. You can use the ListWorkloadDeploymentPatterns operation to discover the available deployment patterns for a given workload.
 */
export declare const listWorkloads: API.PaginatedOperationMethod<ListWorkloadsInput & RegionInput, ListWorkloadsOutput, ListWorkloadsError, Credentials | HttpClient.HttpClient, WorkloadDataSummary>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the given resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the given resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = InternalServerException | ResourceLimitException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a deployment.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentInput & RegionInput, UpdateDeploymentOutput, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=launch-wizard.d.ts.map