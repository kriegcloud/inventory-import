import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import type { HttpEffect } from "./Http.ts";
import type { Output } from "./Output.ts";
export interface BaseRuntimeContext {
    Type: string;
    id: string;
    env: Record<string, any>;
    /**
     * Read a value by its (already-canonical) key. The key is used verbatim;
     * callers must {@link sanitizeKey} first. See {@link sanitizeKey}.
     */
    get<T>(key: string): Effect.Effect<T | undefined>;
    /**
     * Store an output under the given (already-canonical) key, returning the key.
     * The key is used verbatim; callers must {@link sanitizeKey} first.
     */
    set(id: string, output: Output): Effect.Effect<string>;
    exports?: Effect.Effect<Record<string, any>>;
    serve?<Req = never>(handler: HttpEffect<Req>, options?: {
        shape?: Record<string, unknown>;
    }): Effect.Effect<void, never, Req>;
    /**
     * Serve even when the impl shape has no `fetch` handler and no RPC
     * methods. Set by runtimes whose served handler carries routes of its
     * own — e.g. a runtime that routes Durable Object calls itself, so a
     * worker that only hosts Durable Objects still serves.
     */
    alwaysServe?: boolean;
    shape?: () => Record<string, unknown>;
    /** additional services to provide to the plan  */
    planServices?: Layer.Layer<any>;
    /**
     * Services the host provides its init in every phase, built over the
     * instance (e.g. a Cloudflare Worker's `WebhookHost`), so user code
     * doesn't provide them itself.
     */
    hostServices?: Layer.Layer<any, never, any>;
    /**
     * Telemetry exporter Layer registered during init via
     * `Telemetry.layer(...)` / `Telemetry.layerOtlp(...)` (see Telemetry.ts).
     * The runtime bridges build it into every event's request scope,
     * overriding the env-driven default.
     */
    telemetry?: Layer.Layer<never, any, any>;
    /**
     * Set during init by providing the `Workers.InputGate` Layer
     * (`alchemy/Workers`): the Durable Object bridge gives each instance an
     * input gate.
     */
    inputGate?: boolean;
    /**
     * Mint an OIDC ID token for `audience`, signed by the host's platform
     * (a Fly Machine's `/.fly/api`). Present only on hosts whose platform
     * issues them. Bindings exchange it with a cloud's STS instead of
     * holding a key Alchemy created.
     */
    oidcToken?: (audience: string) => Effect.Effect<Redacted.Redacted<string>, OidcTokenError>;
}
declare const OidcTokenError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "OidcTokenError";
} & Readonly<A>;
/** The host's platform did not issue an OIDC token. */
export declare class OidcTokenError extends OidcTokenError_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
/**
 * Keys a Platform's Init captured through {@link BaseRuntimeContext.set}
 * (`yield* Config.x(...)`, `yield* output`). `Platform.make` attaches the
 * runtime context to the resource and merges these values into its
 * `props.env`.
 */
export declare const capturedEnvKeys: (resource: unknown) => string[];
/**
 * Canonicalize a logical key into a key that is safe to use as the name of an
 * environment variable / binding (`[a-zA-Z][a-zA-Z0-9_]*`).
 *
 * `RuntimeContext.set`/`get` are dumb key/value stores: they read and write the
 * key **verbatim**. It is the *caller's* responsibility to hand them a
 * canonical key, since the caller is the one that knows the logical key may
 * contain `.`/`-` (e.g. a dotted config name from `Platform`, or an
 * `Output.toString()` like `"QueueSinkQueue.queueUrl"`). Callers run the key
 * through this before calling `set`/`get` so both sides agree.
 */
export declare const sanitizeKey: (key: string) => string;
/**
 * The wire format `RuntimeContext.set`/`get` use to carry a `Redacted` value
 * through an environment variable. `JSON.stringify(Redacted)` emits the
 * literal string `"<redacted>"` and loses the value, so secrets are
 * serialized as this marker and the runtime `get` path rebuilds the wrapper.
 */
export interface RedactedMarker {
    readonly _tag: "Redacted";
    readonly value: unknown;
}
/**
 * Detect the (already JSON-parsed) {@link RedactedMarker} shape. After
 * `JSON.parse` the marker is a plain object — `Redacted.isRedacted` is
 * always `false` on it — so detection is structural.
 */
export declare const isRedactedMarker: (value: unknown) => value is RedactedMarker;
/**
 * Serialize a binding value for an env var: `Redacted` values are packed as
 * a {@link RedactedMarker}, non-string values as JSON.
 *
 * A plain string is stored **verbatim** whenever `JSON.parse` would reject
 * it — which is almost every real-world string (names, URLs, ids). Packing
 * those too would put `"my-queue"` (quote characters included) on the wire,
 * where anything that consumes the raw binding without going through
 * {@link unpackEnvValue} — the Cloudflare dashboard, a hand-written env
 * read, a queue-name comparison against `MessageBatch.queue` — sees the
 * quoted form and mismatches (#1243). Only ambiguous strings (`"123"`,
 * `"null"`, JSON documents) keep the pack so the read side can't
 * reinterpret them.
 */
export declare const packEnvValue: (value: unknown) => string;
/**
 * The string a deployed process reads for a value in a user's `env` prop: a
 * string as-is (`""` included), a `Redacted` unwrapped, anything else as
 * JSON. `undefined` and `null` mean unset.
 *
 * Every host writes `env` through this, so `process.env` and `Config` read
 * the same string on all of them. A string the runtime context packed when
 * it bound a value is already an env string, so it passes through unchanged.
 */
export declare const envString: (value: unknown) => string | undefined;
/** {@link envString} over a whole `env` record, dropping unset entries. */
export declare const envStrings: (env: Record<string, unknown> | undefined) => Record<string, string>;
/**
 * Like {@link packEnvValue}, but a `Redacted` input keeps its `Redacted`
 * wrapper on the *outside* of the packed string, so deploy-time code can
 * route secrets through a dedicated channel (Cloudflare `secret_text`,
 * Secrets Store) instead of leaking them as plain env vars. The inner
 * payload still carries the marker for the runtime `get` accessor.
 */
export declare const packEnvValueKeepRedacted: (value: unknown) => string | Redacted.Redacted<string>;
/**
 * Parse an env-var string produced by {@link packEnvValue} back into its
 * value: rebuild `Redacted` from the marker, return other JSON values
 * as-is, and fall back to the raw string for non-JSON input (a verbatim
 * string from `packEnvValue`, or an env var the user set directly).
 * `undefined` passes through.
 *
 * Only call this on a key Alchemy wrote with {@link packEnvValue}, read from
 * the raw environment (`process.env[key]` / the platform env object): a string
 * someone else set may parse as JSON and come back changed (`"false"` →
 * `false`), and `Config` reads have already unwrapped the marker. `Config`
 * reads use {@link unwrapRedactedMarker} instead.
 */
export declare const unpackEnvValue: <T>(raw: string | undefined) => T | undefined;
/**
 * If `raw` is a `{"_tag":"Redacted","value":...}` marker, return its value as
 * a string; otherwise return `raw` unchanged, even when it parses as JSON.
 *
 * `Config` reads use this (through `runtimeConfigProvider`): the marker is the
 * only encoding Alchemy puts on a value a `Config` reads. Any other string was
 * set by someone else (a Worker `env` entry, a dashboard, the host), so only
 * they know whether `"false"` meant a string (#2269, #2847, #3497).
 */
export declare const unwrapRedactedMarker: (raw: string) => string;
declare const RuntimeContext_base: Context.ServiceClass<RuntimeContext, "RuntimeContext", BaseRuntimeContext>;
/**
 * Context of the runtime environment.
 *
 * E.g. the context of a running Worker, Task, Process, Function
 */
export declare class RuntimeContext extends RuntimeContext_base {
    static phantom: Layer.Layer<RuntimeContext>;
}
export declare const CurrentRuntimeContext: Effect.Effect<BaseRuntimeContext | undefined, never, never>;
export {};
//# sourceMappingURL=RuntimeContext.d.ts.map