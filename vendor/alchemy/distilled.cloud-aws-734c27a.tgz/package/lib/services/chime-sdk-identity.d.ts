import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.TaggedErrorClass<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
export type NonEmptyResourceName = string | redacted.Redacted<string>;
export type Metadata = string | redacted.Redacted<string>;
export type ClientRequestToken = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateAppInstanceRequest {
    Name: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string> | undefined;
    ClientRequestToken: string;
    Tags?: Tag[] | undefined;
}
export type ChimeArn = string;
export interface CreateAppInstanceResponse {
    AppInstanceArn?: string | undefined;
}
export interface CreateAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export type ResourceName = string | redacted.Redacted<string>;
export interface Identity {
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export interface CreateAppInstanceAdminResponse {
    AppInstanceAdmin?: Identity | undefined;
    AppInstanceArn?: string | undefined;
}
export type RespondsTo = "STANDARD_MESSAGES" | (string & {});
export type StandardMessages = "AUTO" | "ALL" | "MENTIONS" | "NONE" | (string & {});
export type TargetedMessages = "ALL" | "NONE" | (string & {});
export interface InvokedBy {
    StandardMessages: StandardMessages;
    TargetedMessages: TargetedMessages;
}
export type LexBotAliasArn = string;
export type LexIntentName = string;
export interface LexConfiguration {
    RespondsTo?: RespondsTo | undefined;
    InvokedBy?: InvokedBy | undefined;
    LexBotAliasArn: string;
    LocaleId: string;
    WelcomeIntent?: string | undefined;
}
export interface Configuration {
    Lex: LexConfiguration;
}
export interface CreateAppInstanceBotRequest {
    AppInstanceArn: string;
    Name?: string | redacted.Redacted<string> | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
    ClientRequestToken: string;
    Tags?: Tag[] | undefined;
    Configuration: Configuration;
}
export interface CreateAppInstanceBotResponse {
    AppInstanceBotArn?: string | undefined;
}
export type UserId = string | redacted.Redacted<string>;
export type UserName = string | redacted.Redacted<string>;
export type ExpirationDays = number;
export type ExpirationCriterion = "CREATED_TIMESTAMP" | (string & {});
export interface ExpirationSettings {
    ExpirationDays: number;
    ExpirationCriterion: ExpirationCriterion;
}
export interface CreateAppInstanceUserRequest {
    AppInstanceArn: string;
    AppInstanceUserId: string | redacted.Redacted<string>;
    Name: string | redacted.Redacted<string>;
    Metadata?: string | redacted.Redacted<string> | undefined;
    ClientRequestToken: string;
    Tags?: Tag[] | undefined;
    ExpirationSettings?: ExpirationSettings | undefined;
}
export interface CreateAppInstanceUserResponse {
    AppInstanceUserArn?: string | undefined;
}
export interface DeleteAppInstanceRequest {
    AppInstanceArn: string;
}
export interface DeleteAppInstanceResponse {
}
export interface DeleteAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export interface DeleteAppInstanceAdminResponse {
}
export interface DeleteAppInstanceBotRequest {
    AppInstanceBotArn: string;
}
export interface DeleteAppInstanceBotResponse {
}
export interface DeleteAppInstanceUserRequest {
    AppInstanceUserArn: string;
}
export interface DeleteAppInstanceUserResponse {
}
export type String64 = string;
export interface DeregisterAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
}
export interface DeregisterAppInstanceUserEndpointResponse {
}
export interface DescribeAppInstanceRequest {
    AppInstanceArn: string;
}
export interface AppInstance {
    AppInstanceArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
}
export interface DescribeAppInstanceResponse {
    AppInstance?: AppInstance | undefined;
}
export interface DescribeAppInstanceAdminRequest {
    AppInstanceAdminArn: string;
    AppInstanceArn: string;
}
export interface AppInstanceAdmin {
    Admin?: Identity | undefined;
    AppInstanceArn?: string | undefined;
    CreatedTimestamp?: Date | undefined;
}
export interface DescribeAppInstanceAdminResponse {
    AppInstanceAdmin?: AppInstanceAdmin | undefined;
}
export interface DescribeAppInstanceBotRequest {
    AppInstanceBotArn: string;
}
export interface AppInstanceBot {
    AppInstanceBotArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Configuration?: Configuration | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
}
export interface DescribeAppInstanceBotResponse {
    AppInstanceBot?: AppInstanceBot | undefined;
}
export interface DescribeAppInstanceUserRequest {
    AppInstanceUserArn: string;
}
export interface AppInstanceUser {
    AppInstanceUserArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    ExpirationSettings?: ExpirationSettings | undefined;
}
export interface DescribeAppInstanceUserResponse {
    AppInstanceUser?: AppInstanceUser | undefined;
}
export type String1600 = string;
export interface DescribeAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
}
export type SensitiveString1600 = string | redacted.Redacted<string>;
export type AppInstanceUserEndpointType = "APNS" | "APNS_SANDBOX" | "GCM" | (string & {});
export type NonEmptySensitiveString1600 = string | redacted.Redacted<string>;
export interface EndpointAttributes {
    DeviceToken: string | redacted.Redacted<string>;
    VoipDeviceToken?: string | redacted.Redacted<string> | undefined;
}
export type AllowMessages = "ALL" | "NONE" | (string & {});
export type EndpointStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type EndpointStatusReason = "INVALID_DEVICE_TOKEN" | "INVALID_PINPOINT_ARN" | (string & {});
export interface EndpointState {
    Status: EndpointStatus;
    StatusReason?: EndpointStatusReason | undefined;
}
export interface AppInstanceUserEndpoint {
    AppInstanceUserArn?: string | undefined;
    EndpointId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Type?: AppInstanceUserEndpointType | undefined;
    ResourceArn?: string | undefined;
    EndpointAttributes?: EndpointAttributes | undefined;
    CreatedTimestamp?: Date | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    AllowMessages?: AllowMessages | undefined;
    EndpointState?: EndpointState | undefined;
}
export interface DescribeAppInstanceUserEndpointResponse {
    AppInstanceUserEndpoint?: AppInstanceUserEndpoint | undefined;
}
export interface GetAppInstanceRetentionSettingsRequest {
    AppInstanceArn: string;
}
export type RetentionDays = number;
export interface ChannelRetentionSettings {
    RetentionDays?: number | undefined;
}
export interface AppInstanceRetentionSettings {
    ChannelRetentionSettings?: ChannelRetentionSettings | undefined;
}
export interface GetAppInstanceRetentionSettingsResponse {
    AppInstanceRetentionSettings?: AppInstanceRetentionSettings | undefined;
    InitiateDeletionTimestamp?: Date | undefined;
}
export type MaxResults = number;
export type NextToken = string | redacted.Redacted<string>;
export interface ListAppInstanceAdminsRequest {
    AppInstanceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface AppInstanceAdminSummary {
    Admin?: Identity | undefined;
}
export type AppInstanceAdminList = AppInstanceAdminSummary[];
export interface ListAppInstanceAdminsResponse {
    AppInstanceArn?: string | undefined;
    AppInstanceAdmins?: AppInstanceAdminSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListAppInstanceBotsRequest {
    AppInstanceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface AppInstanceBotSummary {
    AppInstanceBotArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
}
export type AppInstanceBotList = AppInstanceBotSummary[];
export interface ListAppInstanceBotsResponse {
    AppInstanceArn?: string | undefined;
    AppInstanceBots?: AppInstanceBotSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListAppInstancesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface AppInstanceSummary {
    AppInstanceArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
}
export type AppInstanceList = AppInstanceSummary[];
export interface ListAppInstancesResponse {
    AppInstances?: AppInstanceSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export type SensitiveChimeArn = string | redacted.Redacted<string>;
export interface ListAppInstanceUserEndpointsRequest {
    AppInstanceUserArn: string | redacted.Redacted<string>;
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface AppInstanceUserEndpointSummary {
    AppInstanceUserArn?: string | undefined;
    EndpointId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Type?: AppInstanceUserEndpointType | undefined;
    AllowMessages?: AllowMessages | undefined;
    EndpointState?: EndpointState | undefined;
}
export type AppInstanceUserEndpointSummaryList = AppInstanceUserEndpointSummary[];
export interface ListAppInstanceUserEndpointsResponse {
    AppInstanceUserEndpoints?: AppInstanceUserEndpointSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListAppInstanceUsersRequest {
    AppInstanceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface AppInstanceUserSummary {
    AppInstanceUserArn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Metadata?: string | redacted.Redacted<string> | undefined;
}
export type AppInstanceUserList = AppInstanceUserSummary[];
export interface ListAppInstanceUsersResponse {
    AppInstanceArn?: string | undefined;
    AppInstanceUsers?: AppInstanceUserSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface PutAppInstanceRetentionSettingsRequest {
    AppInstanceArn: string;
    AppInstanceRetentionSettings: AppInstanceRetentionSettings;
}
export interface PutAppInstanceRetentionSettingsResponse {
    AppInstanceRetentionSettings?: AppInstanceRetentionSettings | undefined;
    InitiateDeletionTimestamp?: Date | undefined;
}
export interface PutAppInstanceUserExpirationSettingsRequest {
    AppInstanceUserArn: string;
    ExpirationSettings?: ExpirationSettings | undefined;
}
export interface PutAppInstanceUserExpirationSettingsResponse {
    AppInstanceUserArn?: string | undefined;
    ExpirationSettings?: ExpirationSettings | undefined;
}
export interface RegisterAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string> | undefined;
    Type: AppInstanceUserEndpointType;
    ResourceArn: string;
    EndpointAttributes: EndpointAttributes;
    ClientRequestToken: string;
    AllowMessages?: AllowMessages | undefined;
}
export interface RegisterAppInstanceUserEndpointResponse {
    AppInstanceUserArn?: string | undefined;
    EndpointId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateAppInstanceRequest {
    AppInstanceArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
}
export interface UpdateAppInstanceResponse {
    AppInstanceArn?: string | undefined;
}
export interface UpdateAppInstanceBotRequest {
    AppInstanceBotArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
    Configuration?: Configuration | undefined;
}
export interface UpdateAppInstanceBotResponse {
    AppInstanceBotArn?: string | undefined;
}
export interface UpdateAppInstanceUserRequest {
    AppInstanceUserArn: string;
    Name: string | redacted.Redacted<string>;
    Metadata: string | redacted.Redacted<string>;
}
export interface UpdateAppInstanceUserResponse {
    AppInstanceUserArn?: string | undefined;
}
export interface UpdateAppInstanceUserEndpointRequest {
    AppInstanceUserArn: string;
    EndpointId: string;
    Name?: string | redacted.Redacted<string> | undefined;
    AllowMessages?: AllowMessages | undefined;
}
export interface UpdateAppInstanceUserEndpointResponse {
    AppInstanceUserArn?: string | undefined;
    EndpointId?: string | undefined;
}
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | (string & {});
export type CreateAppInstanceError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK messaging `AppInstance` under an AWS account.
 * Only SDK messaging customers use this API. `CreateAppInstance` supports
 * idempotency behavior as described in the AWS API Standard.
 *
 * identity
 */
export declare const createAppInstance: API.OperationMethod<CreateAppInstanceRequest & RegionInput, CreateAppInstanceResponse, CreateAppInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceAdminError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Promotes an `AppInstanceUser` or `AppInstanceBot` to an
 * `AppInstanceAdmin`. The
 * promoted entity can perform the following actions.
 *
 * - `ChannelModerator` actions across all channels in the
 * `AppInstance`.
 *
 * - `DeleteChannelMessage` actions.
 *
 * Only an `AppInstanceUser` and `AppInstanceBot` can be promoted to an `AppInstanceAdmin`
 * role.
 */
export declare const createAppInstanceAdmin: API.OperationMethod<CreateAppInstanceAdminRequest & RegionInput, CreateAppInstanceAdminResponse, CreateAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a bot under an Amazon Chime `AppInstance`. The request consists of a
 * unique `Configuration` and `Name` for that bot.
 */
export declare const createAppInstanceBot: API.OperationMethod<CreateAppInstanceBotRequest & RegionInput, CreateAppInstanceBotResponse, CreateAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type CreateAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a user under an Amazon Chime `AppInstance`. The request consists of a
 * unique `appInstanceUserId` and `Name` for that user.
 */
export declare const createAppInstanceUser: API.OperationMethod<CreateAppInstanceUserRequest & RegionInput, CreateAppInstanceUserResponse, CreateAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstance` and all associated data asynchronously.
 */
export declare const deleteAppInstance: API.OperationMethod<DeleteAppInstanceRequest & RegionInput, DeleteAppInstanceResponse, DeleteAppInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceAdminError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Demotes an `AppInstanceAdmin` to an `AppInstanceUser` or
 * `AppInstanceBot`. This action
 * does not delete the user.
 */
export declare const deleteAppInstanceAdmin: API.OperationMethod<DeleteAppInstanceAdminRequest & RegionInput, DeleteAppInstanceAdminResponse, DeleteAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstanceBot`.
 */
export declare const deleteAppInstanceBot: API.OperationMethod<DeleteAppInstanceBotRequest & RegionInput, DeleteAppInstanceBotResponse, DeleteAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type DeleteAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an `AppInstanceUser`.
 */
export declare const deleteAppInstanceUser: API.OperationMethod<DeleteAppInstanceUserRequest & RegionInput, DeleteAppInstanceUserResponse, DeleteAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DeregisterAppInstanceUserEndpointError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deregisters an `AppInstanceUserEndpoint`.
 */
export declare const deregisterAppInstanceUserEndpoint: API.OperationMethod<DeregisterAppInstanceUserEndpointRequest & RegionInput, DeregisterAppInstanceUserEndpointResponse, DeregisterAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstance`.
 */
export declare const describeAppInstance: API.OperationMethod<DescribeAppInstanceRequest & RegionInput, DescribeAppInstanceResponse, DescribeAppInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceAdminError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceAdmin`.
 */
export declare const describeAppInstanceAdmin: API.OperationMethod<DescribeAppInstanceAdminRequest & RegionInput, DescribeAppInstanceAdminResponse, DescribeAppInstanceAdminError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceBotError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * The `AppInstanceBot's` information.
 */
export declare const describeAppInstanceBot: API.OperationMethod<DescribeAppInstanceBotRequest & RegionInput, DescribeAppInstanceBotResponse, DescribeAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceUserError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceUser`.
 */
export declare const describeAppInstanceUser: API.OperationMethod<DescribeAppInstanceUserRequest & RegionInput, DescribeAppInstanceUserResponse, DescribeAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type DescribeAppInstanceUserEndpointError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns the full details of an `AppInstanceUserEndpoint`.
 */
export declare const describeAppInstanceUserEndpoint: API.OperationMethod<DescribeAppInstanceUserEndpointRequest & RegionInput, DescribeAppInstanceUserEndpointResponse, DescribeAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type GetAppInstanceRetentionSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the retention settings for an `AppInstance`.
 */
export declare const getAppInstanceRetentionSettings: API.OperationMethod<GetAppInstanceRetentionSettingsRequest & RegionInput, GetAppInstanceRetentionSettingsResponse, GetAppInstanceRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type ListAppInstanceAdminsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of the administrators in the `AppInstance`.
 */
export declare const listAppInstanceAdmins: API.PaginatedOperationMethod<ListAppInstanceAdminsRequest & RegionInput, ListAppInstanceAdminsResponse, ListAppInstanceAdminsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceBotsError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all `AppInstanceBots` created under a single `AppInstance`.
 */
export declare const listAppInstanceBots: API.PaginatedOperationMethod<ListAppInstanceBotsRequest & RegionInput, ListAppInstanceBotsResponse, ListAppInstanceBotsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstancesError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all Amazon Chime `AppInstance`s created under a single AWS
 * account.
 */
export declare const listAppInstances: API.PaginatedOperationMethod<ListAppInstancesRequest & RegionInput, ListAppInstancesResponse, ListAppInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceUserEndpointsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists all the `AppInstanceUserEndpoints` created under a single `AppInstanceUser`.
 */
export declare const listAppInstanceUserEndpoints: API.PaginatedOperationMethod<ListAppInstanceUserEndpointsRequest & RegionInput, ListAppInstanceUserEndpointsResponse, ListAppInstanceUserEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAppInstanceUsersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * List all `AppInstanceUsers` created under a single
 * `AppInstance`.
 */
export declare const listAppInstanceUsers: API.PaginatedOperationMethod<ListAppInstanceUsersRequest & RegionInput, ListAppInstanceUsersResponse, ListAppInstanceUsersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the tags applied to an Amazon Chime SDK identity resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAppInstanceRetentionSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Sets the amount of time in days that a given `AppInstance` retains
 * data.
 */
export declare const putAppInstanceRetentionSettings: API.OperationMethod<PutAppInstanceRetentionSettingsRequest & RegionInput, PutAppInstanceRetentionSettingsResponse, PutAppInstanceRetentionSettingsError, Credentials | HttpClient.HttpClient>;
export type PutAppInstanceUserExpirationSettingsError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Sets the number of days before the `AppInstanceUser` is automatically deleted.
 *
 * A background process deletes expired `AppInstanceUsers` within 6 hours of expiration.
 * Actual deletion times may vary.
 *
 * Expired `AppInstanceUsers` that have not yet been deleted appear as active, and you can update
 * their expiration settings. The system honors the new settings.
 */
export declare const putAppInstanceUserExpirationSettings: API.OperationMethod<PutAppInstanceUserExpirationSettingsRequest & RegionInput, PutAppInstanceUserExpirationSettingsResponse, PutAppInstanceUserExpirationSettingsError, Credentials | HttpClient.HttpClient>;
export type RegisterAppInstanceUserEndpointError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Registers an endpoint under an Amazon Chime `AppInstanceUser`. The endpoint receives messages for a user. For push notifications, the endpoint is a mobile device used to receive mobile push notifications for a user.
 */
export declare const registerAppInstanceUserEndpoint: API.OperationMethod<RegisterAppInstanceUserEndpointRequest & RegionInput, RegisterAppInstanceUserEndpointResponse, RegisterAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Applies the specified tags to the specified Amazon Chime SDK identity resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Removes the specified tags from the specified Amazon Chime SDK identity resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates `AppInstance` metadata.
 */
export declare const updateAppInstance: API.OperationMethod<UpdateAppInstanceRequest & RegionInput, UpdateAppInstanceResponse, UpdateAppInstanceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceBotError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the name and metadata of an `AppInstanceBot`.
 */
export declare const updateAppInstanceBot: API.OperationMethod<UpdateAppInstanceBotRequest & RegionInput, UpdateAppInstanceBotResponse, UpdateAppInstanceBotError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceUserError = BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of an `AppInstanceUser`. You can update names and
 * metadata.
 */
export declare const updateAppInstanceUser: API.OperationMethod<UpdateAppInstanceUserRequest & RegionInput, UpdateAppInstanceUserResponse, UpdateAppInstanceUserError, Credentials | HttpClient.HttpClient>;
export type UpdateAppInstanceUserEndpointError = BadRequestException | ConflictException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of an `AppInstanceUserEndpoint`. You can update the name and `AllowMessage` values.
 */
export declare const updateAppInstanceUserEndpoint: API.OperationMethod<UpdateAppInstanceUserEndpointRequest & RegionInput, UpdateAppInstanceUserEndpointResponse, UpdateAppInstanceUserEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-identity.d.ts.map