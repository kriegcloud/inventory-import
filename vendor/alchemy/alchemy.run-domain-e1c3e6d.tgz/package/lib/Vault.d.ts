import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import { VaultError } from "./VaultError.ts";
export { VaultError } from "./VaultError.ts";
/**
 * A value encrypted under one subject's key. It names the subject and holds
 * the ciphertext. `decide`, `evolve` and views carry it and can't read it.
 */
export interface Sealed<A> {
    /** Whose key it is encrypted under, such as a customer id. */
    readonly subject: string;
    /** The ciphertext, or the value waiting to be sealed. */
    readonly box: string;
    /** The type of the value inside. Never set. */
    readonly "~sealed"?: A;
}
/** A sealed value as it is stored and sent. */
export declare const SealedJson: Schema.Struct<{
    readonly subject: Schema.String;
    readonly box: Schema.String;
}>;
export type SealedJson = typeof SealedJson.Type;
/** A field that holds a {@link Sealed} value of `S`. */
export type SealedSchema<S extends Schema.Top> = Schema.Codec<Sealed<S["Type"]>, SealedJson> & {
    /** The schema of the value inside. */
    readonly value: S;
    /**
     * A value to be sealed for `subject`. It is plain text until a command
     * carries it into the model, which seals it before anything is stored.
     */
    readonly plain: (subject: string, value: S["Type"]) => Sealed<S["Type"]>;
};
/** Any sealed field. */
export type AnySealed = SealedSchema<Schema.Top>;
/** The prefix of a box sealed with AES-256-GCM. @internal */
export declare const AES = "v1.";
/** Whether a sealed value is still plain text: made with `plain`, and not yet through a command. */
export declare const isPlain: (sealed: SealedJson) => boolean;
/**
 * A field whose value is encrypted under a key kept per subject. Deleting
 * the subject's key makes every copy unreadable, wherever it was stored.
 *
 * ### Declaring a sealed field
 * **Example:** A customer's name
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Schema from "effect/Schema";
import { VaultError } from "./VaultError.ts";

export { VaultError } from "./VaultError.ts";
 *
 * export const Name = Domain.Sealed(Schema.String);
 *
 * export class CustomerRegistered extends Domain.Event("CustomerRegistered", { name: Name }) {}
 * ```
 *
 * ### Sending a value to be sealed
 * A client sends the value with the subject it belongs to. The model seals
 * it when the command arrives, before anything is stored.
 *
 * **Example:** Registering a customer
 * ```typescript
 * yield* bank.RegisterCustomer({ customerId, name: Name.plain(customerId, "Sam") });
 * ```
 *
 * @primitive
 */
export declare const make: <S extends Schema.Top>(value: S) => SealedSchema<S>;
declare const VaultMissing_base: Schema.Class<VaultMissing, Schema.TaggedStruct<"VaultMissing", {
    readonly subject: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * A command carried a value to be sealed, and the model has no Vault. Nothing
 * was stored.
 */
export declare class VaultMissing extends VaultMissing_base {
    get message(): string;
}
declare const Unsealed_base: Schema.Class<Unsealed, Schema.TaggedStruct<"Unsealed", {
    readonly subject: Schema.String;
    readonly event: Schema.String;
}>, import("effect/Cause").YieldableError>;
/** A value reached the model's storage as plain text: it was made with `plain` outside a command. */
export declare class Unsealed extends Unsealed_base {
    get message(): string;
}
declare const Vault_base: Context.ServiceClass<Vault, "alchemy/Domain/Vault", {
    /** Encrypt a value under the subject's key, making the key if the subject has none. */
    readonly seal: <S extends Schema.Top>(sealed: SealedSchema<S>, subject: string, value: S["Type"]) => Effect.Effect<Sealed<S["Type"]>, VaultError>;
    /** The value inside, or `None` once its subject's key is shredded. */
    readonly open: <S extends Schema.Top>(sealed: SealedSchema<S>, value: Sealed<S["Type"]>) => Effect.Effect<Option.Option<S["Type"]>, VaultError>;
    /** Remove the subject's key. Everything sealed for them stays where it is, unreadable. */
    readonly shred: (subject: string) => Effect.Effect<void, VaultError>;
    /** Seal a value made with `plain`; one already sealed is returned as it is. @internal */
    readonly settle: (sealed: SealedJson) => Effect.Effect<SealedJson, VaultError>;
}>;
/**
 * Seals values under a key per subject, opens them, and shreds a subject's
 * key so nothing sealed for them opens again.
 *
 * ### Opening a value
 * A value is opened where it is served, such as a query's handler. It is
 * `None` once its subject is shredded.
 *
 * **Example:** A query that returns a customer's name
 * ```typescript
 * export const CustomerNameLive = CustomerName.toLayer(
 *   Effect.gen(function* () {
 *     const vault = yield* Domain.Vault;
 *     const customers = yield* Customer;
 *     return Effect.fn(function* ({ customerId }) {
 *       const customer = yield* customers.get(customerId);
 *       const name = yield* vault.open(Name, customer.name).pipe(Effect.orDie);
 *       return { name: Option.getOrNull(name) };
 *     });
 *   }),
 * );
 * ```
 *
 * ### Shredding a subject
 * **Example:** Forget a customer
 * ```typescript
 * const vault = yield* Domain.Vault;
 * yield* vault.shred(customerId);
 * ```
 */
export declare class Vault extends Vault_base {
}
/** The schema-aware half of a Vault, over what encrypts and decrypts text. @internal */
export declare const vaultOver: (text: {
    readonly seal: (subject: string, plain: string) => Effect.Effect<string, VaultError>;
    readonly open: (subject: string, box: string) => Effect.Effect<Option.Option<string>, VaultError>;
    readonly shred: (subject: string) => Effect.Effect<void, VaultError>;
}) => Vault["Service"];
/**
 * A sealed value as {@link VaultTest} seals it, for a story to expect.
 *
 * **Example:** The event a registration records
 * ```typescript
 * Story.then(sam, new CustomerRegistered({ name: Domain.sealedInTest(Name, sam.id, "Sam") }));
 * ```
 */
export declare const sealedInTest: <S extends Schema.Top>(sealed: SealedSchema<S>, subject: string, value: S["Type"]) => Sealed<S["Type"]>;
/**
 * A Vault for stories. It encrypts nothing, so the same value always seals
 * to the same box and a story can expect it with {@link sealedInTest}. A
 * shredded subject's values no longer open.
 */
export declare const VaultTest: Layer.Layer<Vault>;
/** The first value in `json` still waiting to be sealed, if any. @internal */
export declare const findPlain: (json: unknown) => SealedJson | undefined;
/**
 * Seal every value in `json` that is waiting to be sealed. `json` itself is
 * returned when nothing in it is. @internal
 */
export declare const settle: (json: unknown, vault: Option.Option<Vault["Service"]>) => Effect.Effect<unknown, VaultError | VaultMissing>;
//# sourceMappingURL=Vault.d.ts.map