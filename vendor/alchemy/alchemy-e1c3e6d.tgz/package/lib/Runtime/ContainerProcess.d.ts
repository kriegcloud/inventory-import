import type { NodeServices } from "@effect/platform-node/NodeServices";
import * as SecureRandom from "effect/crypto/SecureRandom";
import type { HttpClient } from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import type { HttpServer } from "../Http.ts";
import type { Terminals } from "../Terminal.ts";
type ProcessServices = NodeServices | HttpClient | SecureRandom.SecureRandom;
export interface ContainerPlatformLayers<E = never> {
    /** The runtime's platform services, and the `Terminals` sandbox terminals open with. */
    readonly services: Layer.Layer<NodeServices | Terminals, E>;
    readonly httpServer: Layer.Layer<HttpServer, E, ProcessServices>;
}
export type ContainerMode = "server" | "job";
export declare const bootstrap: <Identity, IdentityError, PlatformError>(entrypoint: unknown, platform: ContainerPlatformLayers<PlatformError>, mode: ContainerMode, identity?: Layer.Layer<Identity, IdentityError, ProcessServices>, label?: string) => Promise<void>;
export {};
//# sourceMappingURL=ContainerProcess.d.ts.map