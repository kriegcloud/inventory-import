import * as Provider from "../Provider.ts";
import { Resource } from "../Resource.ts";
import { CommandExecutor, type CommandRunProps } from "./Command.ts";
import { type MemoOptions } from "./Memo.ts";
export interface ExecProps extends CommandRunProps {
    /**
     * Controls which files are hashed to decide whether the command should
     * re-run. By default every non-gitignored file in `cwd` is hashed, plus the
     * nearest lockfile. Provide explicit globs to narrow the scope, or set
     * `false` to disable memoization and re-run on every deploy.
     *
     * @see {@link MemoOptions}
     * @default true
     */
    memo?: MemoOptions | boolean;
}
export interface Exec extends Resource<"Command.Exec", ExecProps, {
    /**
     * Hash of the input files for this command, if memoization is enabled.
     */
    hash: {
        input: string | undefined;
    };
}> {
}
/**
 * An `Exec` runs a shell command purely for its side effects — it has no
 * output contract. Unlike `Build`, it does not produce or track an output
 * asset; `reconcile` runs the command and the resource succeeds as long as the
 * command exits with code `0` (a non-zero exit fails with a `CommandError`).
 *
 * Use it for one-off setup steps — running migrations, seeding data, code
 * generation, or any command whose result lives outside Alchemy's state. By
 * default the input files are content-hashed so the command only re-runs when
 * its inputs (or `command`/`cwd`/`env`) change; set `memo: false` to re-run on
 * every deploy.
 *
 * ### Running a Command
 * **Example:** Run a One-Off Command
 * ```typescript
 * yield* Exec("codegen", {
 *   command: "npm run codegen",
 *   cwd: "./packages/api",
 * });
 * ```
 *
 * ### Running with Custom Environment
 * **Example:** Run Database Migrations
 * ```typescript
 * yield* Exec("migrate", {
 *   command: "npm run db:migrate",
 *   env: {
 *     DATABASE_URL: Redacted.make("postgres://..."),
 *   },
 * });
 * ```
 *
 * ### Memoizing Re-Runs
 * **Example:** Only Re-Run When Inputs Change
 * ```typescript
 * yield* Exec("codegen", {
 *   command: "npm run codegen",
 *   memo: { include: ["schema/**"] },
 * });
 * ```
 *
 * ### Bounding Command Runtime
 * **Example:** Time Out a Migration
 * ```typescript
 * yield* Exec("migrate", {
 *   command: "npm run db:migrate",
 *   timeout: "5 minutes",
 * });
 * ```
 *
 * @resource
 */
export declare const Exec: import("../Resource.ts").ResourceClass<Exec>;
export declare const ExecProvider: () => import("effect/Layer").Layer<Provider.Provider<Exec>, never, CommandExecutor | import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
//# sourceMappingURL=Exec.d.ts.map