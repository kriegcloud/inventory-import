import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnprocessableException_base: S.TaggedErrorClass<"UnprocessableException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableException extends /*@__PURE__*/ UnprocessableException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ExportTaskId = string;
export interface CancelExportTaskInput {
    taskIdentifier: string;
}
export type GraphId = string;
export type RoleArn = string;
export type ExportTaskStatus = "INITIALIZING" | "EXPORTING" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | "DELETED" | (string & {});
export type ExportFormat = "PARQUET" | "CSV" | (string & {});
export type KmsKeyArn = string;
export type ParquetType = "COLUMNAR" | (string & {});
export interface CancelExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType | undefined;
    statusReason?: string | undefined;
}
export type TaskId = string;
export interface CancelImportTaskInput {
    taskIdentifier: string;
}
export type Format = "CSV" | "OPEN_CYPHER" | "PARQUET" | "NTRIPLES" | (string & {});
export type ImportTaskStatus = "INITIALIZING" | "EXPORTING" | "ANALYZING_DATA" | "IMPORTING" | "REPROVISIONING" | "ROLLING_BACK" | "SUCCEEDED" | "FAILED" | "CANCELLING" | "CANCELLED" | "DELETED" | (string & {});
export interface CancelImportTaskOutput {
    graphId?: string | undefined;
    taskId: string;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    roleArn: string;
    status: ImportTaskStatus;
}
export type GraphIdentifier = string;
export interface CancelQueryInput {
    graphIdentifier: string;
    queryId: string;
}
export interface CancelQueryResponse {
}
export type GraphName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type VectorSearchDimension = number;
export interface VectorSearchConfiguration {
    dimension: number;
}
export type ReplicaCount = number;
export type ProvisionedMemory = number;
export interface CreateGraphInput {
    graphName: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    publicConnectivity?: boolean | undefined;
    kmsKeyIdentifier?: string | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    deletionProtection?: boolean | undefined;
    provisionedMemory: number;
}
export type GraphStatus = "CREATING" | "AVAILABLE" | "DELETING" | "RESETTING" | "UPDATING" | "SNAPSHOTTING" | "FAILED" | "IMPORTING" | "STARTING" | "STOPPING" | "STOPPED" | (string & {});
export type SnapshotId = string;
export interface CreateGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export type SnapshotName = string;
export interface CreateGraphSnapshotInput {
    graphIdentifier: string;
    snapshotName: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SnapshotStatus = "CREATING" | "AVAILABLE" | "DELETING" | "FAILED" | (string & {});
export interface CreateGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string | undefined;
    snapshotCreateTime?: Date | undefined;
    status?: SnapshotStatus | undefined;
    kmsKeyIdentifier?: string | undefined;
}
export interface NeptuneImportOptions {
    s3ExportPath: string;
    s3ExportKmsKeyId: string;
    preserveDefaultVertexLabels?: boolean | undefined;
    preserveEdgeIds?: boolean | undefined;
}
export type ImportOptions = {
    neptune: NeptuneImportOptions;
};
export type BlankNodeHandling = "convertToIri" | (string & {});
export interface CreateGraphUsingImportTaskInput {
    graphName: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    publicConnectivity?: boolean | undefined;
    kmsKeyIdentifier?: string | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    deletionProtection?: boolean | undefined;
    importOptions?: ImportOptions | undefined;
    maxProvisionedMemory?: number | undefined;
    minProvisionedMemory?: number | undefined;
    failOnError?: boolean | undefined;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    blankNodeHandling?: BlankNodeHandling | undefined;
    roleArn: string;
}
export interface CreateGraphUsingImportTaskOutput {
    graphId?: string | undefined;
    taskId: string;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions | undefined;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface CreatePrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
}
export type PrivateGraphEndpointStatus = "CREATING" | "AVAILABLE" | "DELETING" | "FAILED" | (string & {});
export type VpcEndpointId = string;
export interface CreatePrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string | undefined;
}
export interface DeleteGraphInput {
    graphIdentifier: string;
    skipSnapshot: boolean;
}
export interface DeleteGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export type SnapshotIdentifier = string;
export interface DeleteGraphSnapshotInput {
    snapshotIdentifier: string;
}
export interface DeleteGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string | undefined;
    snapshotCreateTime?: Date | undefined;
    status?: SnapshotStatus | undefined;
    kmsKeyIdentifier?: string | undefined;
}
export interface DeletePrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId: string;
}
export interface DeletePrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string | undefined;
}
export type QueryLanguage = "OPEN_CYPHER" | (string & {});
export type DocumentValuedMap = {
    [key: string]: any | undefined;
};
export type PlanCacheType = "ENABLED" | "DISABLED" | "AUTO" | (string & {});
export type ExplainMode = "STATIC" | "DETAILS" | (string & {});
export interface ExecuteQueryInput {
    graphIdentifier: string;
    queryString: string;
    language: QueryLanguage;
    parameters?: {
        [key: string]: any | undefined;
    } | undefined;
    planCache?: PlanCacheType | undefined;
    explainMode?: ExplainMode | undefined;
    queryTimeoutMilliseconds?: number | undefined;
}
export interface ExecuteQueryOutput {
    payload: T.StreamingOutputBody;
}
export interface GetExportTaskInput {
    taskIdentifier: string;
}
export interface ExportTaskDetails {
    startTime: Date;
    timeElapsedSeconds: number;
    progressPercentage: number;
    numVerticesWritten?: number | undefined;
    numEdgesWritten?: number | undefined;
}
export type ExportFilterLabel = string;
export type ExportFilterOutputPropertyName = string;
export type ExportFilterOutputDataType = string;
export type ExportFilterSourcePropertyName = string;
export type MultiValueHandlingType = "TO_LIST" | "PICK_FIRST" | (string & {});
export interface ExportFilterPropertyAttributes {
    outputType?: string | undefined;
    sourcePropertyName?: string | undefined;
    multiValueHandling?: MultiValueHandlingType | undefined;
}
export type ExportFilterPropertyMap = {
    [key: string]: ExportFilterPropertyAttributes | undefined;
};
export interface ExportFilterElement {
    properties?: {
        [key: string]: ExportFilterPropertyAttributes | undefined;
    } | undefined;
}
export type ExportFilterPerLabelMap = {
    [key: string]: ExportFilterElement | undefined;
};
export interface ExportFilter {
    vertexFilter?: {
        [key: string]: ExportFilterElement | undefined;
    } | undefined;
    edgeFilter?: {
        [key: string]: ExportFilterElement | undefined;
    } | undefined;
}
export interface GetExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType | undefined;
    statusReason?: string | undefined;
    exportTaskDetails?: ExportTaskDetails | undefined;
    exportFilter?: ExportFilter | undefined;
}
export interface GetGraphInput {
    graphIdentifier: string;
}
export interface GetGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export interface GetGraphSnapshotInput {
    snapshotIdentifier: string;
}
export interface GetGraphSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string | undefined;
    snapshotCreateTime?: Date | undefined;
    status?: SnapshotStatus | undefined;
    kmsKeyIdentifier?: string | undefined;
}
export type GraphSummaryMode = "BASIC" | "DETAILED" | (string & {});
export interface GetGraphSummaryInput {
    graphIdentifier: string;
    mode?: GraphSummaryMode | undefined;
}
export type NodeLabels = string[];
export type EdgeLabels = string[];
export type LongValuedMap = {
    [key: string]: number | undefined;
};
export type LongValuedMapList = {
    [key: string]: number | undefined;
}[];
export type NodeProperties = string[];
export type OutgoingEdgeLabels = string[];
export interface NodeStructure {
    count?: number | undefined;
    nodeProperties?: string[] | undefined;
    distinctOutgoingEdgeLabels?: string[] | undefined;
}
export type NodeStructures = NodeStructure[];
export type EdgeProperties = string[];
export interface EdgeStructure {
    count?: number | undefined;
    edgeProperties?: string[] | undefined;
}
export type EdgeStructures = EdgeStructure[];
export interface GraphDataSummary {
    numNodes?: number | undefined;
    numEdges?: number | undefined;
    numNodeLabels?: number | undefined;
    numEdgeLabels?: number | undefined;
    nodeLabels?: string[] | undefined;
    edgeLabels?: string[] | undefined;
    numNodeProperties?: number | undefined;
    numEdgeProperties?: number | undefined;
    nodeProperties?: {
        [key: string]: number | undefined;
    }[] | undefined;
    edgeProperties?: {
        [key: string]: number | undefined;
    }[] | undefined;
    totalNodePropertyValues?: number | undefined;
    totalEdgePropertyValues?: number | undefined;
    nodeStructures?: NodeStructure[] | undefined;
    edgeStructures?: EdgeStructure[] | undefined;
}
export interface GetGraphSummaryOutput {
    version?: string | undefined;
    lastStatisticsComputationTime?: Date | undefined;
    graphSummary?: GraphDataSummary | undefined;
}
export interface GetImportTaskInput {
    taskIdentifier: string;
}
export interface ImportTaskDetails {
    status: string;
    startTime: Date;
    timeElapsedSeconds: number;
    progressPercentage: number;
    errorCount: number;
    errorDetails?: string | undefined;
    statementCount: number;
    dictionaryEntryCount: number;
}
export interface GetImportTaskOutput {
    graphId?: string | undefined;
    taskId: string;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions | undefined;
    importTaskDetails?: ImportTaskDetails | undefined;
    attemptNumber?: number | undefined;
    statusReason?: string | undefined;
}
export interface GetPrivateGraphEndpointInput {
    graphIdentifier: string;
    vpcId: string;
}
export interface GetPrivateGraphEndpointOutput {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string | undefined;
}
export interface GetQueryInput {
    graphIdentifier: string;
    queryId: string;
}
export type QueryState = "RUNNING" | "WAITING" | "CANCELLING" | (string & {});
export interface GetQueryOutput {
    id?: string | undefined;
    queryString?: string | undefined;
    waited?: number | undefined;
    elapsed?: number | undefined;
    state?: QueryState | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListExportTasksInput {
    graphIdentifier?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ExportTaskSummary {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType | undefined;
    statusReason?: string | undefined;
}
export type ExportTaskSummaryList = ExportTaskSummary[];
export interface ListExportTasksOutput {
    tasks: ExportTaskSummary[];
    nextToken?: string | undefined;
}
export interface ListGraphsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GraphSummary {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    provisionedMemory?: number | undefined;
    publicConnectivity?: boolean | undefined;
    endpoint?: string | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    deletionProtection?: boolean | undefined;
}
export type GraphSummaryList = GraphSummary[];
export interface ListGraphsOutput {
    graphs: GraphSummary[];
    nextToken?: string | undefined;
}
export interface ListGraphSnapshotsInput {
    graphIdentifier?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GraphSnapshotSummary {
    id: string;
    name: string;
    arn: string;
    sourceGraphId?: string | undefined;
    snapshotCreateTime?: Date | undefined;
    status?: SnapshotStatus | undefined;
    kmsKeyIdentifier?: string | undefined;
}
export type GraphSnapshotSummaryList = GraphSnapshotSummary[];
export interface ListGraphSnapshotsOutput {
    graphSnapshots: GraphSnapshotSummary[];
    nextToken?: string | undefined;
}
export interface ListImportTasksInput {
    graphIdentifier?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ImportTaskSummary {
    graphId?: string | undefined;
    taskId: string;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    roleArn: string;
    status: ImportTaskStatus;
}
export type ImportTaskSummaryList = ImportTaskSummary[];
export interface ListImportTasksOutput {
    tasks: ImportTaskSummary[];
    nextToken?: string | undefined;
}
export interface ListPrivateGraphEndpointsInput {
    graphIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PrivateGraphEndpointSummary {
    vpcId: string;
    subnetIds: string[];
    status: PrivateGraphEndpointStatus;
    vpcEndpointId?: string | undefined;
}
export type PrivateGraphEndpointSummaryList = PrivateGraphEndpointSummary[];
export interface ListPrivateGraphEndpointsOutput {
    privateGraphEndpoints: PrivateGraphEndpointSummary[];
    nextToken?: string | undefined;
}
export type QueryStateInput = "ALL" | "RUNNING" | "WAITING" | "CANCELLING" | (string & {});
export interface ListQueriesInput {
    graphIdentifier: string;
    maxResults: number;
    state?: QueryStateInput | undefined;
}
export interface QuerySummary {
    id?: string | undefined;
    queryString?: string | undefined;
    waited?: number | undefined;
    elapsed?: number | undefined;
    state?: QueryState | undefined;
}
export type QuerySummaryList = QuerySummary[];
export interface ListQueriesOutput {
    queries: QuerySummary[];
}
export type Arn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ResetGraphInput {
    graphIdentifier: string;
    skipSnapshot: boolean;
}
export interface ResetGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export interface RestoreGraphFromSnapshotInput {
    snapshotIdentifier: string;
    graphName: string;
    provisionedMemory?: number | undefined;
    deletionProtection?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    replicaCount?: number | undefined;
    publicConnectivity?: boolean | undefined;
}
export interface RestoreGraphFromSnapshotOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export interface StartExportTaskInput {
    graphIdentifier: string;
    roleArn: string;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType | undefined;
    exportFilter?: ExportFilter | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartExportTaskOutput {
    graphId: string;
    roleArn: string;
    taskId: string;
    status: ExportTaskStatus;
    format: ExportFormat;
    destination: string;
    kmsKeyIdentifier: string;
    parquetType?: ParquetType | undefined;
    statusReason?: string | undefined;
    exportFilter?: ExportFilter | undefined;
}
export interface StartGraphInput {
    graphIdentifier: string;
}
export interface StartGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export interface StartImportTaskInput {
    importOptions?: ImportOptions | undefined;
    failOnError?: boolean | undefined;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    blankNodeHandling?: BlankNodeHandling | undefined;
    graphIdentifier: string;
    roleArn: string;
}
export interface StartImportTaskOutput {
    graphId?: string | undefined;
    taskId: string;
    source: string;
    format?: Format | undefined;
    parquetType?: ParquetType | undefined;
    roleArn: string;
    status: ImportTaskStatus;
    importOptions?: ImportOptions | undefined;
}
export interface StopGraphInput {
    graphIdentifier: string;
}
export interface StopGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateGraphInput {
    graphIdentifier: string;
    publicConnectivity?: boolean | undefined;
    provisionedMemory?: number | undefined;
    deletionProtection?: boolean | undefined;
}
export interface UpdateGraphOutput {
    id: string;
    name: string;
    arn: string;
    status?: GraphStatus | undefined;
    statusReason?: string | undefined;
    createTime?: Date | undefined;
    provisionedMemory?: number | undefined;
    endpoint?: string | undefined;
    publicConnectivity?: boolean | undefined;
    vectorSearchConfiguration?: VectorSearchConfiguration | undefined;
    replicaCount?: number | undefined;
    kmsKeyIdentifier?: string | undefined;
    sourceSnapshotId?: string | undefined;
    deletionProtection?: boolean | undefined;
    buildNumber?: string | undefined;
}
export type ConflictExceptionReason = "CONCURRENT_MODIFICATION" | (string & {});
export type ValidationExceptionReason = "CONSTRAINT_VIOLATION" | "ILLEGAL_ARGUMENT" | "MALFORMED_QUERY" | "QUERY_CANCELLED" | "QUERY_TOO_LARGE" | "UNSUPPORTED_OPERATION" | "BAD_REQUEST" | (string & {});
export type UnprocessableExceptionReason = "QUERY_TIMEOUT" | "INTERNAL_LIMIT_EXCEEDED" | "MEMORY_LIMIT_EXCEEDED" | "STORAGE_LIMIT_EXCEEDED" | "PARTITION_FULL" | (string & {});
export type CancelExportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancel the specified export task.
 */
export declare const cancelExportTask: API.OperationMethod<CancelExportTaskInput & RegionInput, CancelExportTaskOutput, CancelExportTaskError, Credentials | HttpClient.HttpClient>;
export type CancelImportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified import task.
 */
export declare const cancelImportTask: API.OperationMethod<CancelImportTaskInput & RegionInput, CancelImportTaskOutput, CancelImportTaskError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a specified query.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryInput & RegionInput, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateGraphError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Neptune Analytics graph.
 */
export declare const createGraph: API.OperationMethod<CreateGraphInput & RegionInput, CreateGraphOutput, CreateGraphError, Credentials | HttpClient.HttpClient>;
export type CreateGraphSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of the specific graph.
 */
export declare const createGraphSnapshot: API.OperationMethod<CreateGraphSnapshotInput & RegionInput, CreateGraphSnapshotOutput, CreateGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateGraphUsingImportTaskError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Neptune Analytics graph and imports data into it, either from Amazon Simple Storage Service (S3) or from a Neptune database or a Neptune database snapshot.
 *
 * The data can be loaded from files in S3 that in either the Gremlin CSV format or the openCypher load format.
 */
export declare const createGraphUsingImportTask: API.OperationMethod<CreateGraphUsingImportTaskInput & RegionInput, CreateGraphUsingImportTaskOutput, CreateGraphUsingImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateGraphEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a private graph endpoint to allow private access to the graph from within a VPC. You can attach security groups to the private graph endpoint.
 *
 * VPC endpoint charges apply.
 */
export declare const createPrivateGraphEndpoint: API.OperationMethod<CreatePrivateGraphEndpointInput & RegionInput, CreatePrivateGraphEndpointOutput, CreatePrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified graph. Graphs cannot be deleted if delete-protection is enabled.
 */
export declare const deleteGraph: API.OperationMethod<DeleteGraphInput & RegionInput, DeleteGraphOutput, DeleteGraphError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified graph snapshot.
 */
export declare const deleteGraphSnapshot: API.OperationMethod<DeleteGraphSnapshotInput & RegionInput, DeleteGraphSnapshotOutput, DeleteGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeletePrivateGraphEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a private graph endpoint.
 */
export declare const deletePrivateGraphEndpoint: API.OperationMethod<DeletePrivateGraphEndpointInput & RegionInput, DeletePrivateGraphEndpointOutput, DeletePrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type ExecuteQueryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | UnprocessableException | ValidationException | CommonErrors;
/**
 * Execute an openCypher query.
 *
 * When invoking this operation in a Neptune Analytics cluster, the IAM user or role making the request must have a policy attached that allows one of the following IAM actions in that cluster, depending on the query:
 *
 * - neptune-graph:ReadDataViaQuery
 *
 * - neptune-graph:WriteDataViaQuery
 *
 * - neptune-graph:DeleteDataViaQuery
 */
export declare const executeQuery: API.OperationMethod<ExecuteQueryInput & RegionInput, ExecuteQueryOutput, ExecuteQueryError, Credentials | HttpClient.HttpClient>;
export type GetExportTaskError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified export task.
 */
export declare const getExportTask: API.OperationMethod<GetExportTaskInput & RegionInput, GetExportTaskOutput, GetExportTaskError, Credentials | HttpClient.HttpClient>;
export type GetGraphError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specified graph.
 */
export declare const getGraph: API.OperationMethod<GetGraphInput & RegionInput, GetGraphOutput, GetGraphError, Credentials | HttpClient.HttpClient>;
export type GetGraphSnapshotError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified graph snapshot.
 */
export declare const getGraphSnapshot: API.OperationMethod<GetGraphSnapshotInput & RegionInput, GetGraphSnapshotOutput, GetGraphSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetGraphSummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a graph summary for a property graph.
 */
export declare const getGraphSummary: API.OperationMethod<GetGraphSummaryInput & RegionInput, GetGraphSummaryOutput, GetGraphSummaryError, Credentials | HttpClient.HttpClient>;
export type GetImportTaskError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified import task.
 */
export declare const getImportTask: API.OperationMethod<GetImportTaskInput & RegionInput, GetImportTaskOutput, GetImportTaskError, Credentials | HttpClient.HttpClient>;
export type GetPrivateGraphEndpointError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specified private endpoint.
 */
export declare const getPrivateGraphEndpoint: API.OperationMethod<GetPrivateGraphEndpointInput & RegionInput, GetPrivateGraphEndpointOutput, GetPrivateGraphEndpointError, Credentials | HttpClient.HttpClient>;
export type GetQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of a specified query.
 *
 * When invoking this operation in a Neptune Analytics cluster, the IAM user or role making the request must have the `neptune-graph:GetQueryStatus` IAM action attached.
 */
export declare const getQuery: API.OperationMethod<GetQueryInput & RegionInput, GetQueryOutput, GetQueryError, Credentials | HttpClient.HttpClient>;
export type ListExportTasksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of export tasks.
 */
export declare const listExportTasks: API.PaginatedOperationMethod<ListExportTasksInput & RegionInput, ListExportTasksOutput, ListExportTasksError, Credentials | HttpClient.HttpClient, ExportTaskSummary>;
export type ListGraphsError = InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists available Neptune Analytics graphs.
 */
export declare const listGraphs: API.PaginatedOperationMethod<ListGraphsInput & RegionInput, ListGraphsOutput, ListGraphsError, Credentials | HttpClient.HttpClient, GraphSummary>;
export type ListGraphSnapshotsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists available snapshots of a specified Neptune Analytics graph.
 */
export declare const listGraphSnapshots: API.PaginatedOperationMethod<ListGraphSnapshotsInput & RegionInput, ListGraphSnapshotsOutput, ListGraphSnapshotsError, Credentials | HttpClient.HttpClient, GraphSnapshotSummary>;
export type ListImportTasksError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists import tasks.
 */
export declare const listImportTasks: API.PaginatedOperationMethod<ListImportTasksInput & RegionInput, ListImportTasksOutput, ListImportTasksError, Credentials | HttpClient.HttpClient, ImportTaskSummary>;
export type ListPrivateGraphEndpointsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists private endpoints for a specified Neptune Analytics graph.
 */
export declare const listPrivateGraphEndpoints: API.PaginatedOperationMethod<ListPrivateGraphEndpointsInput & RegionInput, ListPrivateGraphEndpointsOutput, ListPrivateGraphEndpointsError, Credentials | HttpClient.HttpClient, PrivateGraphEndpointSummary>;
export type ListQueriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists active openCypher queries.
 */
export declare const listQueries: API.OperationMethod<ListQueriesInput & RegionInput, ListQueriesOutput, ListQueriesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tags associated with a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Empties the data from a specified Neptune Analytics graph.
 */
export declare const resetGraph: API.OperationMethod<ResetGraphInput & RegionInput, ResetGraphOutput, ResetGraphError, Credentials | HttpClient.HttpClient>;
export type RestoreGraphFromSnapshotError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores a graph from a snapshot.
 */
export declare const restoreGraphFromSnapshot: API.OperationMethod<RestoreGraphFromSnapshotInput & RegionInput, RestoreGraphFromSnapshotOutput, RestoreGraphFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export data from an existing Neptune Analytics graph to Amazon S3. The graph state should be `AVAILABLE`.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskInput & RegionInput, StartExportTaskOutput, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StartGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specific graph.
 */
export declare const startGraph: API.OperationMethod<StartGraphInput & RegionInput, StartGraphOutput, StartGraphError, Credentials | HttpClient.HttpClient>;
export type StartImportTaskError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Import data into existing Neptune Analytics graph from Amazon Simple Storage Service (S3). The graph needs to be empty and in the AVAILABLE state.
 */
export declare const startImportTask: API.OperationMethod<StartImportTaskInput & RegionInput, StartImportTaskOutput, StartImportTaskError, Credentials | HttpClient.HttpClient>;
export type StopGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specific graph.
 */
export declare const stopGraph: API.OperationMethod<StopGraphInput & RegionInput, StopGraphOutput, StopGraphError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGraphError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a specified Neptune Analytics graph
 */
export declare const updateGraph: API.OperationMethod<UpdateGraphInput & RegionInput, UpdateGraphOutput, UpdateGraphError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=neptune-graph.d.ts.map