import * as kv from "@distilled.cloud/cloudflare/kv";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
export declare const isNamespace: (value: unknown) => value is Namespace;
export type NamespaceProps = {
    /**
     * A human-readable string name for the namespace.
     * If omitted, a unique name will be generated.
     * @default ${app}-${stage}-${id}
     */
    title?: string;
};
/**
 * Props for {@link Namespace.lookup}: find a KV namespace this stack doesn't
 * manage, by its id or its title.
 */
export type NamespaceLookup = {
    /**
     * The Cloudflare-assigned ID of the existing namespace.
     */
    namespaceId: string;
} | {
    /**
     * The title of the existing namespace.
     */
    title: string;
};
export type Namespace = Resource<"Cloudflare.KV.Namespace", NamespaceProps, {
    title: string;
    namespaceId: string;
    supportsUrlEncoding: boolean | undefined;
    accountId: string;
}, never, Providers, NamespaceLookup>;
/**
 * A Cloudflare Workers KV namespace for key-value storage at the edge.
 *
 * KV provides eventually-consistent, low-latency reads with global
 * replication. Create a namespace as a resource, then bind it to a Worker
 * to get/put values at runtime.
 * ### Creating a Namespace
 * **Example:** Basic KV namespace
 * ```typescript
 * const kv = yield* Cloudflare.KV.Namespace("MyKV");
 * ```
 *
 * ### Binding to a Worker
 * **Example:** Using KV inside a Worker
 * ```typescript
 * const kv = yield* Cloudflare.KV.ReadWriteNamespace(MyKV);
 *
 * // Read a value
 * const value = yield* kv.get("my-key");
 *
 * // Write a value
 * yield* kv.put("my-key", "hello world");
 * ```
 *
 * Provide `Cloudflare.KV.ReadWriteNamespaceBinding` (native Worker
 * binding) or `Cloudflare.KV.ReadWriteNamespaceHttp` (scoped HTTP
 * token) in the worker's runtime layer. Use `Cloudflare.KV.ReadNamespace`
 * / `Cloudflare.KV.WriteNamespace` for least-privilege read- or
 * write-only access.
 *
 * ### Looking up an existing namespace
 * `Namespace.lookup` binds a namespace Alchemy doesn't manage (created in the
 * dashboard or by another stack), found by `namespaceId` or `title`. It is
 * read during plan/deploy and never created, updated or deleted.
 *
 * **Example:** By title
 * ```typescript
 * const kv = yield* Cloudflare.KV.ReadWriteNamespace(
 *   Cloudflare.KV.Namespace.lookup({ title: "sessions" }),
 * );
 * ```
 *
 * **Example:** By ID, in an async Worker's `env`
 * ```typescript
 * const worker = yield* Cloudflare.Worker("Worker", {
 *   main: "./src/worker.ts",
 *   env: {
 *     SESSIONS: Cloudflare.KV.Namespace.lookup({
 *       namespaceId: "0f2ac74b498b48028cb68387c421e279",
 *     }),
 *   },
 * });
 * ```
 *
 * @resource
 * @product KV
 * @category Storage & Databases
 */
export declare const Namespace: import("alchemy").ResourceClass<Namespace>;
export declare const ProviderLive: () => import("effect/Layer").Layer<Provider.Provider<Namespace>, never, CloudflareEnvironment | import("alchemy").Stack | import("alchemy").Stage | kv.CloudflareOpContext>;
/**
 * Local (dev) provider — the namespace is purely virtual: a `dev:` id keyed
 * into the local workerd KV simulator. `toRuntimeBinding` lowers a
 * `kv_namespace` binding whose id is `dev:`-prefixed onto the local KV
 * service; data persists under `.alchemy/local/kv`.
 */
export declare const ProviderLocal: () => import("effect/Layer").Layer<Provider.Provider<Namespace>, never, import("alchemy").Stack | import("alchemy").Stage>;
export declare const NamespaceProvider: () => import("effect/Layer").Layer<Provider.Provider<Namespace>, never, import("alchemy").AlchemyContext | CloudflareEnvironment | import("alchemy").Stack | import("alchemy").Stage | kv.CloudflareOpContext>;
//# sourceMappingURL=Namespace.d.ts.map