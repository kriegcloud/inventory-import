import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CoreNetworkPolicyException_base: S.TaggedErrorClass<"CoreNetworkPolicyException", {
    readonly message: any;
    readonly Errors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CoreNetworkPolicyException extends /*@__PURE__*/ CoreNetworkPolicyException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly Context: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly LimitCode: any;
    readonly ServiceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AttachmentId = string;
export interface AcceptAttachmentRequest {
    AttachmentId: string;
}
export type CoreNetworkId = string;
export type CoreNetworkArn = string;
export type AWSAccountId = string;
export type AttachmentType = "CONNECT" | "SITE_TO_SITE_VPN" | "VPC" | "DIRECT_CONNECT_GATEWAY" | "TRANSIT_GATEWAY_ROUTE_TABLE" | (string & {});
export type AttachmentState = "REJECTED" | "PENDING_ATTACHMENT_ACCEPTANCE" | "CREATING" | "FAILED" | "AVAILABLE" | "UPDATING" | "PENDING_NETWORK_UPDATE" | "PENDING_TAG_ACCEPTANCE" | "DELETING" | (string & {});
export type ExternalRegionCode = string;
export type ExternalRegionCodeList = string[];
export type ResourceArn = string;
export type ConstrainedString = string;
export type NetworkFunctionGroupName = string;
export type NatGatewaySupportState = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | "PENDING_ATTACHMENT_ACCEPTANCE" | (string & {});
export type BoxedBoolean = boolean;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface ProposedSegmentChange {
    Tags?: Tag[] | undefined;
    AttachmentPolicyRuleNumber?: number | undefined;
    SegmentName?: string | undefined;
}
export interface ProposedNetworkFunctionGroupChange {
    Tags?: Tag[] | undefined;
    AttachmentPolicyRuleNumber?: number | undefined;
    NetworkFunctionGroupName?: string | undefined;
}
export type AttachmentErrorCode = "VPC_NOT_FOUND" | "SUBNET_NOT_FOUND" | "SUBNET_DUPLICATED_IN_AVAILABILITY_ZONE" | "SUBNET_NO_FREE_ADDRESSES" | "SUBNET_UNSUPPORTED_AVAILABILITY_ZONE" | "SUBNET_NO_IPV6_CIDRS" | "SECURITY_GROUP_REFERENCING_UNSUPPORTED_AVAILABILITY_ZONE" | "VPN_CONNECTION_NOT_FOUND" | "MAXIMUM_NO_ENCAP_LIMIT_EXCEEDED" | "DIRECT_CONNECT_GATEWAY_NOT_FOUND" | "DIRECT_CONNECT_GATEWAY_EXISTING_ATTACHMENTS" | "DIRECT_CONNECT_GATEWAY_NO_PRIVATE_VIF" | "VPN_EXISTING_ASSOCIATIONS" | "VPN_STATIC_ROUTES_NAT_UNSUPPORTED" | "VPC_UNSUPPORTED_FEATURES" | "DIRECT_CONNECT_GATEWAY_TOPOLOGY_RESTRICTIONS" | "CREATION_FAILED" | "UPDATE_FAILED" | "DELETION_FAILED" | (string & {});
export type ServerSideString = string;
export interface AttachmentError {
    Code?: AttachmentErrorCode | undefined;
    Message?: string | undefined;
    ResourceArn?: string | undefined;
    RequestId?: string | undefined;
}
export type AttachmentErrorList = AttachmentError[];
export interface Attachment {
    CoreNetworkId?: string | undefined;
    CoreNetworkArn?: string | undefined;
    AttachmentId?: string | undefined;
    OwnerAccountId?: string | undefined;
    AttachmentType?: AttachmentType | undefined;
    State?: AttachmentState | undefined;
    EdgeLocation?: string | undefined;
    EdgeLocations?: string[] | undefined;
    ResourceArn?: string | undefined;
    AttachmentPolicyRuleNumber?: number | undefined;
    SegmentName?: string | undefined;
    NetworkFunctionGroupName?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportState | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    Tags?: Tag[] | undefined;
    ProposedSegmentChange?: ProposedSegmentChange | undefined;
    ProposedNetworkFunctionGroupChange?: ProposedNetworkFunctionGroupChange | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    LastModificationErrors?: AttachmentError[] | undefined;
}
export interface AcceptAttachmentResponse {
    Attachment?: Attachment | undefined;
}
export type GlobalNetworkId = string;
export type ConnectPeerId = string;
export type DeviceId = string;
export type LinkId = string;
export interface AssociateConnectPeerRequest {
    GlobalNetworkId: string;
    ConnectPeerId: string;
    DeviceId: string;
    LinkId?: string | undefined;
}
export type ConnectPeerAssociationState = "PENDING" | "AVAILABLE" | "DELETING" | "DELETED" | (string & {});
export interface ConnectPeerAssociation {
    ConnectPeerId?: string | undefined;
    GlobalNetworkId?: string | undefined;
    DeviceId?: string | undefined;
    LinkId?: string | undefined;
    State?: ConnectPeerAssociationState | undefined;
}
export interface AssociateConnectPeerResponse {
    ConnectPeerAssociation?: ConnectPeerAssociation | undefined;
}
export type CustomerGatewayArn = string;
export interface AssociateCustomerGatewayRequest {
    CustomerGatewayArn: string;
    GlobalNetworkId: string;
    DeviceId: string;
    LinkId?: string | undefined;
}
export type CustomerGatewayAssociationState = "PENDING" | "AVAILABLE" | "DELETING" | "DELETED" | (string & {});
export interface CustomerGatewayAssociation {
    CustomerGatewayArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    DeviceId?: string | undefined;
    LinkId?: string | undefined;
    State?: CustomerGatewayAssociationState | undefined;
}
export interface AssociateCustomerGatewayResponse {
    CustomerGatewayAssociation?: CustomerGatewayAssociation | undefined;
}
export interface AssociateLinkRequest {
    GlobalNetworkId: string;
    DeviceId: string;
    LinkId: string;
}
export type LinkAssociationState = "PENDING" | "AVAILABLE" | "DELETING" | "DELETED" | (string & {});
export interface LinkAssociation {
    GlobalNetworkId?: string | undefined;
    DeviceId?: string | undefined;
    LinkId?: string | undefined;
    LinkAssociationState?: LinkAssociationState | undefined;
}
export interface AssociateLinkResponse {
    LinkAssociation?: LinkAssociation | undefined;
}
export type TransitGatewayConnectPeerArn = string;
export interface AssociateTransitGatewayConnectPeerRequest {
    GlobalNetworkId: string;
    TransitGatewayConnectPeerArn: string;
    DeviceId: string;
    LinkId?: string | undefined;
}
export type TransitGatewayConnectPeerAssociationState = "PENDING" | "AVAILABLE" | "DELETING" | "DELETED" | (string & {});
export interface TransitGatewayConnectPeerAssociation {
    TransitGatewayConnectPeerArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    DeviceId?: string | undefined;
    LinkId?: string | undefined;
    State?: TransitGatewayConnectPeerAssociationState | undefined;
}
export interface AssociateTransitGatewayConnectPeerResponse {
    TransitGatewayConnectPeerAssociation?: TransitGatewayConnectPeerAssociation | undefined;
}
export type NatGatewaySupportValue = "ENABLE" | "DISABLE" | (string & {});
export type NatRuleNumber = number;
export type IPAddress = string;
export interface NatRuleRequest {
    RuleNumber: number;
    MatchSourceCidr: string;
    NatCidr: string;
}
export type NatRuleRequestList = NatRuleRequest[];
export type TunnelProtocol = "GRE" | "NO_ENCAP" | (string & {});
export interface ConnectAttachmentOptions {
    Protocol?: TunnelProtocol | undefined;
}
export type ClientToken = string;
export interface CreateConnectAttachmentRequest {
    CoreNetworkId: string;
    EdgeLocation: string;
    TransportAttachmentId: string;
    RoutingPolicyLabel?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportValue | undefined;
    NatGatewayRules?: NatRuleRequest[] | undefined;
    Options: ConnectAttachmentOptions;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export interface ConnectAttachment {
    Attachment?: Attachment | undefined;
    TransportAttachmentId?: string | undefined;
    Options?: ConnectAttachmentOptions | undefined;
}
export interface CreateConnectAttachmentResponse {
    ConnectAttachment?: ConnectAttachment | undefined;
}
export interface CreateConnectionRequest {
    GlobalNetworkId: string;
    DeviceId: string;
    ConnectedDeviceId: string;
    LinkId?: string | undefined;
    ConnectedLinkId?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ConnectionId = string;
export type ConnectionArn = string;
export type ConnectionState = "PENDING" | "AVAILABLE" | "DELETING" | "UPDATING" | (string & {});
export interface Connection {
    ConnectionId?: string | undefined;
    ConnectionArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    DeviceId?: string | undefined;
    ConnectedDeviceId?: string | undefined;
    LinkId?: string | undefined;
    ConnectedLinkId?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    State?: ConnectionState | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateConnectionResponse {
    Connection?: Connection | undefined;
}
export interface BgpOptions {
    PeerAsn?: number | undefined;
}
export type ConstrainedStringList = string[];
export type SubnetArn = string;
export interface CreateConnectPeerRequest {
    ConnectAttachmentId: string;
    CoreNetworkAddress?: string | undefined;
    PeerAddress: string;
    BgpOptions?: BgpOptions | undefined;
    InsideCidrBlocks?: string[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
    SubnetArn?: string | undefined;
}
export type ConnectPeerState = "CREATING" | "FAILED" | "AVAILABLE" | "DELETING" | (string & {});
export interface ConnectPeerBgpConfiguration {
    CoreNetworkAsn?: number | undefined;
    PeerAsn?: number | undefined;
    CoreNetworkAddress?: string | undefined;
    PeerAddress?: string | undefined;
}
export type ConnectPeerBgpConfigurationList = ConnectPeerBgpConfiguration[];
export interface ConnectPeerConfiguration {
    CoreNetworkAddress?: string | undefined;
    PeerAddress?: string | undefined;
    InsideCidrBlocks?: string[] | undefined;
    Protocol?: TunnelProtocol | undefined;
    BgpConfigurations?: ConnectPeerBgpConfiguration[] | undefined;
}
export type ConnectPeerErrorCode = "EDGE_LOCATION_NO_FREE_IPS" | "EDGE_LOCATION_PEER_DUPLICATE" | "SUBNET_NOT_FOUND" | "IP_OUTSIDE_SUBNET_CIDR_RANGE" | "INVALID_INSIDE_CIDR_BLOCK" | "NO_ASSOCIATED_CIDR_BLOCK" | "CREATION_FAILED" | "DELETION_FAILED" | (string & {});
export interface ConnectPeerError {
    Code?: ConnectPeerErrorCode | undefined;
    Message?: string | undefined;
    ResourceArn?: string | undefined;
    RequestId?: string | undefined;
}
export type ConnectPeerErrorList = ConnectPeerError[];
export interface ConnectPeer {
    CoreNetworkId?: string | undefined;
    ConnectAttachmentId?: string | undefined;
    ConnectPeerId?: string | undefined;
    EdgeLocation?: string | undefined;
    State?: ConnectPeerState | undefined;
    CreatedAt?: Date | undefined;
    Configuration?: ConnectPeerConfiguration | undefined;
    Tags?: Tag[] | undefined;
    SubnetArn?: string | undefined;
    LastModificationErrors?: ConnectPeerError[] | undefined;
}
export interface CreateConnectPeerResponse {
    ConnectPeer?: ConnectPeer | undefined;
}
export type CoreNetworkPolicyDocument = string;
export interface CreateCoreNetworkRequest {
    GlobalNetworkId: string;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    PolicyDocument?: string | undefined;
    ClientToken?: string | undefined;
}
export type CoreNetworkState = "CREATING" | "UPDATING" | "AVAILABLE" | "DELETING" | (string & {});
export interface CoreNetworkSegment {
    Name?: string | undefined;
    EdgeLocations?: string[] | undefined;
    SharedSegments?: string[] | undefined;
}
export type CoreNetworkSegmentList = CoreNetworkSegment[];
export interface ServiceInsertionSegments {
    SendVia?: string[] | undefined;
    SendTo?: string[] | undefined;
}
export interface CoreNetworkNetworkFunctionGroup {
    Name?: string | undefined;
    EdgeLocations?: string[] | undefined;
    Segments?: ServiceInsertionSegments | undefined;
}
export type CoreNetworkNetworkFunctionGroupList = CoreNetworkNetworkFunctionGroup[];
export interface CoreNetworkEdge {
    EdgeLocation?: string | undefined;
    Asn?: number | undefined;
    InsideCidrBlocks?: string[] | undefined;
}
export type CoreNetworkEdgeList = CoreNetworkEdge[];
export interface CoreNetwork {
    GlobalNetworkId?: string | undefined;
    CoreNetworkId?: string | undefined;
    CoreNetworkArn?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    State?: CoreNetworkState | undefined;
    Segments?: CoreNetworkSegment[] | undefined;
    NetworkFunctionGroups?: CoreNetworkNetworkFunctionGroup[] | undefined;
    Edges?: CoreNetworkEdge[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateCoreNetworkResponse {
    CoreNetwork?: CoreNetwork | undefined;
}
export type PrefixListArn = string;
export interface CreateCoreNetworkPrefixListAssociationRequest {
    CoreNetworkId: string;
    PrefixListArn: string;
    PrefixListAlias: string;
    ClientToken?: string | undefined;
}
export interface CreateCoreNetworkPrefixListAssociationResponse {
    CoreNetworkId?: string | undefined;
    PrefixListArn?: string | undefined;
    PrefixListAlias?: string | undefined;
}
export interface AWSLocation {
    Zone?: string | undefined;
    SubnetArn?: string | undefined;
}
export interface Location {
    Address?: string | undefined;
    Latitude?: string | undefined;
    Longitude?: string | undefined;
}
export type SiteId = string;
export interface CreateDeviceRequest {
    GlobalNetworkId: string;
    AWSLocation?: AWSLocation | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    Vendor?: string | undefined;
    Model?: string | undefined;
    SerialNumber?: string | undefined;
    Location?: Location | undefined;
    SiteId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DeviceArn = string;
export type DeviceState = "PENDING" | "AVAILABLE" | "DELETING" | "UPDATING" | (string & {});
export interface Device {
    DeviceId?: string | undefined;
    DeviceArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    AWSLocation?: AWSLocation | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    Vendor?: string | undefined;
    Model?: string | undefined;
    SerialNumber?: string | undefined;
    Location?: Location | undefined;
    SiteId?: string | undefined;
    CreatedAt?: Date | undefined;
    State?: DeviceState | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDeviceResponse {
    Device?: Device | undefined;
}
export type DirectConnectGatewayArn = string;
export interface CreateDirectConnectGatewayAttachmentRequest {
    CoreNetworkId: string;
    DirectConnectGatewayArn: string;
    RoutingPolicyLabel?: string | undefined;
    EdgeLocations: string[];
    NatGatewaySupport?: NatGatewaySupportValue | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    NatGatewayRules?: NatRuleRequest[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export interface DirectConnectGatewayAttachment {
    Attachment?: Attachment | undefined;
    DirectConnectGatewayArn?: string | undefined;
}
export interface CreateDirectConnectGatewayAttachmentResponse {
    DirectConnectGatewayAttachment?: DirectConnectGatewayAttachment | undefined;
}
export interface CreateGlobalNetworkRequest {
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type GlobalNetworkArn = string;
export type GlobalNetworkState = "PENDING" | "AVAILABLE" | "DELETING" | "UPDATING" | (string & {});
export interface GlobalNetwork {
    GlobalNetworkId?: string | undefined;
    GlobalNetworkArn?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    State?: GlobalNetworkState | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateGlobalNetworkResponse {
    GlobalNetwork?: GlobalNetwork | undefined;
}
export interface Bandwidth {
    UploadSpeed?: number | undefined;
    DownloadSpeed?: number | undefined;
}
export interface CreateLinkRequest {
    GlobalNetworkId: string;
    Description?: string | undefined;
    Type?: string | undefined;
    Bandwidth: Bandwidth;
    Provider?: string | undefined;
    SiteId: string;
    Tags?: Tag[] | undefined;
}
export type LinkArn = string;
export type LinkState = "PENDING" | "AVAILABLE" | "DELETING" | "UPDATING" | (string & {});
export interface Link {
    LinkId?: string | undefined;
    LinkArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    SiteId?: string | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    Bandwidth?: Bandwidth | undefined;
    Provider?: string | undefined;
    CreatedAt?: Date | undefined;
    State?: LinkState | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateLinkResponse {
    Link?: Link | undefined;
}
export interface CreateSiteRequest {
    GlobalNetworkId: string;
    Description?: string | undefined;
    Location?: Location | undefined;
    Tags?: Tag[] | undefined;
}
export type SiteArn = string;
export type SiteState = "PENDING" | "AVAILABLE" | "DELETING" | "UPDATING" | (string & {});
export interface Site {
    SiteId?: string | undefined;
    SiteArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    Description?: string | undefined;
    Location?: Location | undefined;
    CreatedAt?: Date | undefined;
    State?: SiteState | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateSiteResponse {
    Site?: Site | undefined;
}
export type VpnConnectionArn = string;
export interface CreateSiteToSiteVpnAttachmentRequest {
    CoreNetworkId: string;
    VpnConnectionArn: string;
    RoutingPolicyLabel?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportValue | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    NatGatewayRules?: NatRuleRequest[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export interface SiteToSiteVpnAttachment {
    Attachment?: Attachment | undefined;
    VpnConnectionArn?: string | undefined;
}
export interface CreateSiteToSiteVpnAttachmentResponse {
    SiteToSiteVpnAttachment?: SiteToSiteVpnAttachment | undefined;
}
export type TransitGatewayArn = string;
export interface CreateTransitGatewayPeeringRequest {
    CoreNetworkId: string;
    TransitGatewayArn: string;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export type PeeringId = string;
export type PeeringType = "TRANSIT_GATEWAY" | (string & {});
export type PeeringState = "CREATING" | "FAILED" | "AVAILABLE" | "DELETING" | (string & {});
export type PeeringErrorCode = "TRANSIT_GATEWAY_NOT_FOUND" | "TRANSIT_GATEWAY_PEERS_LIMIT_EXCEEDED" | "MISSING_PERMISSIONS" | "INTERNAL_ERROR" | "EDGE_LOCATION_PEER_DUPLICATE" | "INVALID_TRANSIT_GATEWAY_STATE" | "TRANSIT_GATEWAY_ENCRYPTION_NOT_SUPPORTED" | "CREATION_FAILED" | "DELETION_FAILED" | (string & {});
export interface PermissionsErrorContext {
    MissingPermission?: string | undefined;
}
export interface PeeringError {
    Code?: PeeringErrorCode | undefined;
    Message?: string | undefined;
    ResourceArn?: string | undefined;
    RequestId?: string | undefined;
    MissingPermissionsContext?: PermissionsErrorContext | undefined;
}
export type PeeringErrorList = PeeringError[];
export interface Peering {
    CoreNetworkId?: string | undefined;
    CoreNetworkArn?: string | undefined;
    PeeringId?: string | undefined;
    OwnerAccountId?: string | undefined;
    PeeringType?: PeeringType | undefined;
    State?: PeeringState | undefined;
    EdgeLocation?: string | undefined;
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
    CreatedAt?: Date | undefined;
    LastModificationErrors?: PeeringError[] | undefined;
}
export type TransitGatewayPeeringAttachmentId = string;
export interface TransitGatewayPeering {
    Peering?: Peering | undefined;
    TransitGatewayArn?: string | undefined;
    TransitGatewayPeeringAttachmentId?: string | undefined;
}
export interface CreateTransitGatewayPeeringResponse {
    TransitGatewayPeering?: TransitGatewayPeering | undefined;
}
export type TransitGatewayRouteTableArn = string;
export interface CreateTransitGatewayRouteTableAttachmentRequest {
    PeeringId: string;
    TransitGatewayRouteTableArn: string;
    RoutingPolicyLabel?: string | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export interface TransitGatewayRouteTableAttachment {
    Attachment?: Attachment | undefined;
    PeeringId?: string | undefined;
    TransitGatewayRouteTableArn?: string | undefined;
}
export interface CreateTransitGatewayRouteTableAttachmentResponse {
    TransitGatewayRouteTableAttachment?: TransitGatewayRouteTableAttachment | undefined;
}
export type VpcArn = string;
export type SubnetArnList = string[];
export interface VpcOptions {
    Ipv6Support?: boolean | undefined;
    ApplianceModeSupport?: boolean | undefined;
    DnsSupport?: boolean | undefined;
    SecurityGroupReferencingSupport?: boolean | undefined;
}
export interface CreateVpcAttachmentRequest {
    CoreNetworkId: string;
    VpcArn: string;
    SubnetArns: string[];
    Options?: VpcOptions | undefined;
    RoutingPolicyLabel?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportValue | undefined;
    NatGatewayRules?: NatRuleRequest[] | undefined;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export interface VpcAttachment {
    Attachment?: Attachment | undefined;
    SubnetArns?: string[] | undefined;
    Options?: VpcOptions | undefined;
}
export interface CreateVpcAttachmentResponse {
    VpcAttachment?: VpcAttachment | undefined;
}
export interface DeleteAttachmentRequest {
    AttachmentId: string;
}
export interface DeleteAttachmentResponse {
    Attachment?: Attachment | undefined;
}
export interface DeleteConnectionRequest {
    GlobalNetworkId: string;
    ConnectionId: string;
}
export interface DeleteConnectionResponse {
    Connection?: Connection | undefined;
}
export interface DeleteConnectPeerRequest {
    ConnectPeerId: string;
}
export interface DeleteConnectPeerResponse {
    ConnectPeer?: ConnectPeer | undefined;
}
export interface DeleteCoreNetworkRequest {
    CoreNetworkId: string;
}
export interface DeleteCoreNetworkResponse {
    CoreNetwork?: CoreNetwork | undefined;
}
export interface DeleteCoreNetworkPolicyVersionRequest {
    CoreNetworkId: string;
    PolicyVersionId: number;
}
export type CoreNetworkPolicyAlias = "LIVE" | "LATEST" | (string & {});
export type ChangeSetState = "PENDING_GENERATION" | "FAILED_GENERATION" | "READY_TO_EXECUTE" | "EXECUTING" | "EXECUTION_SUCCEEDED" | "OUT_OF_DATE" | (string & {});
export interface CoreNetworkPolicyError {
    ErrorCode: string;
    Message: string;
    Path?: string | undefined;
}
export type CoreNetworkPolicyErrorList = CoreNetworkPolicyError[];
export type SynthesizedJsonCoreNetworkPolicyDocument = string;
export interface CoreNetworkPolicy {
    CoreNetworkId?: string | undefined;
    PolicyVersionId?: number | undefined;
    Alias?: CoreNetworkPolicyAlias | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    ChangeSetState?: ChangeSetState | undefined;
    PolicyErrors?: CoreNetworkPolicyError[] | undefined;
    PolicyDocument?: string | undefined;
}
export interface DeleteCoreNetworkPolicyVersionResponse {
    CoreNetworkPolicy?: CoreNetworkPolicy | undefined;
}
export interface DeleteCoreNetworkPrefixListAssociationRequest {
    CoreNetworkId: string;
    PrefixListArn: string;
}
export interface DeleteCoreNetworkPrefixListAssociationResponse {
    CoreNetworkId?: string | undefined;
    PrefixListArn?: string | undefined;
}
export interface DeleteDeviceRequest {
    GlobalNetworkId: string;
    DeviceId: string;
}
export interface DeleteDeviceResponse {
    Device?: Device | undefined;
}
export interface DeleteGlobalNetworkRequest {
    GlobalNetworkId: string;
}
export interface DeleteGlobalNetworkResponse {
    GlobalNetwork?: GlobalNetwork | undefined;
}
export interface DeleteLinkRequest {
    GlobalNetworkId: string;
    LinkId: string;
}
export interface DeleteLinkResponse {
    Link?: Link | undefined;
}
export interface DeletePeeringRequest {
    PeeringId: string;
}
export interface DeletePeeringResponse {
    Peering?: Peering | undefined;
}
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteSiteRequest {
    GlobalNetworkId: string;
    SiteId: string;
}
export interface DeleteSiteResponse {
    Site?: Site | undefined;
}
export interface DeregisterTransitGatewayRequest {
    GlobalNetworkId: string;
    TransitGatewayArn: string;
}
export type TransitGatewayRegistrationState = "PENDING" | "AVAILABLE" | "DELETING" | "DELETED" | "FAILED" | (string & {});
export interface TransitGatewayRegistrationStateReason {
    Code?: TransitGatewayRegistrationState | undefined;
    Message?: string | undefined;
}
export interface TransitGatewayRegistration {
    GlobalNetworkId?: string | undefined;
    TransitGatewayArn?: string | undefined;
    State?: TransitGatewayRegistrationStateReason | undefined;
}
export interface DeregisterTransitGatewayResponse {
    TransitGatewayRegistration?: TransitGatewayRegistration | undefined;
}
export type GlobalNetworkIdList = string[];
export type MaxResults = number;
export type NextToken = string;
export interface DescribeGlobalNetworksRequest {
    GlobalNetworkIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type GlobalNetworkList = GlobalNetwork[];
export interface DescribeGlobalNetworksResponse {
    GlobalNetworks?: GlobalNetwork[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateConnectPeerRequest {
    GlobalNetworkId: string;
    ConnectPeerId: string;
}
export interface DisassociateConnectPeerResponse {
    ConnectPeerAssociation?: ConnectPeerAssociation | undefined;
}
export interface DisassociateCustomerGatewayRequest {
    GlobalNetworkId: string;
    CustomerGatewayArn: string;
}
export interface DisassociateCustomerGatewayResponse {
    CustomerGatewayAssociation?: CustomerGatewayAssociation | undefined;
}
export interface DisassociateLinkRequest {
    GlobalNetworkId: string;
    DeviceId: string;
    LinkId: string;
}
export interface DisassociateLinkResponse {
    LinkAssociation?: LinkAssociation | undefined;
}
export interface DisassociateTransitGatewayConnectPeerRequest {
    GlobalNetworkId: string;
    TransitGatewayConnectPeerArn: string;
}
export interface DisassociateTransitGatewayConnectPeerResponse {
    TransitGatewayConnectPeerAssociation?: TransitGatewayConnectPeerAssociation | undefined;
}
export interface ExecuteCoreNetworkChangeSetRequest {
    CoreNetworkId: string;
    PolicyVersionId: number;
}
export interface ExecuteCoreNetworkChangeSetResponse {
}
export interface GetConnectAttachmentRequest {
    AttachmentId: string;
}
export interface GetConnectAttachmentResponse {
    ConnectAttachment?: ConnectAttachment | undefined;
}
export type ConnectionIdList = string[];
export interface GetConnectionsRequest {
    GlobalNetworkId: string;
    ConnectionIds?: string[] | undefined;
    DeviceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ConnectionList = Connection[];
export interface GetConnectionsResponse {
    Connections?: Connection[] | undefined;
    NextToken?: string | undefined;
}
export interface GetConnectPeerRequest {
    ConnectPeerId: string;
}
export interface GetConnectPeerResponse {
    ConnectPeer?: ConnectPeer | undefined;
}
export type ConnectPeerIdList = string[];
export interface GetConnectPeerAssociationsRequest {
    GlobalNetworkId: string;
    ConnectPeerIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ConnectPeerAssociationList = ConnectPeerAssociation[];
export interface GetConnectPeerAssociationsResponse {
    ConnectPeerAssociations?: ConnectPeerAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCoreNetworkRequest {
    CoreNetworkId: string;
}
export interface GetCoreNetworkResponse {
    CoreNetwork?: CoreNetwork | undefined;
}
export interface GetCoreNetworkChangeEventsRequest {
    CoreNetworkId: string;
    PolicyVersionId: number;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ChangeType = "CORE_NETWORK_SEGMENT" | "NETWORK_FUNCTION_GROUP" | "CORE_NETWORK_EDGE" | "ATTACHMENT_MAPPING" | "ATTACHMENT_ROUTE_PROPAGATION" | "ATTACHMENT_ROUTE_STATIC" | "ROUTING_POLICY" | "ROUTING_POLICY_SEGMENT_ASSOCIATION" | "ROUTING_POLICY_EDGE_ASSOCIATION" | "ROUTING_POLICY_ATTACHMENT_ASSOCIATION" | "CORE_NETWORK_CONFIGURATION" | "SEGMENTS_CONFIGURATION" | "SEGMENT_ACTIONS_CONFIGURATION" | "ATTACHMENT_POLICIES_CONFIGURATION" | (string & {});
export type ChangeAction = "ADD" | "MODIFY" | "REMOVE" | (string & {});
export type ChangeStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export type RoutingPolicyDirection = "inbound" | "outbound" | (string & {});
export interface RoutingPolicyAssociationDetail {
    RoutingPolicyNames?: string[] | undefined;
    SharedSegments?: string[] | undefined;
}
export type RoutingPolicyAssociationDetailsList = RoutingPolicyAssociationDetail[];
export interface CoreNetworkChangeEventValues {
    EdgeLocation?: string | undefined;
    PeerEdgeLocation?: string | undefined;
    RoutingPolicyDirection?: RoutingPolicyDirection | undefined;
    SegmentName?: string | undefined;
    NetworkFunctionGroupName?: string | undefined;
    AttachmentId?: string | undefined;
    Cidr?: string | undefined;
    RoutingPolicyAssociationDetails?: RoutingPolicyAssociationDetail[] | undefined;
}
export interface CoreNetworkChangeEvent {
    Type?: ChangeType | undefined;
    Action?: ChangeAction | undefined;
    IdentifierPath?: string | undefined;
    EventTime?: Date | undefined;
    Status?: ChangeStatus | undefined;
    Values?: CoreNetworkChangeEventValues | undefined;
}
export type CoreNetworkChangeEventList = CoreNetworkChangeEvent[];
export interface GetCoreNetworkChangeEventsResponse {
    CoreNetworkChangeEvents?: CoreNetworkChangeEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCoreNetworkChangeSetRequest {
    CoreNetworkId: string;
    PolicyVersionId: number;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SegmentActionServiceInsertion = "send-via" | "send-to" | (string & {});
export type SendViaMode = "dual-hop" | "single-hop" | (string & {});
export type WhenSentToSegmentsList = string[];
export interface WhenSentTo {
    WhenSentToSegmentsList?: string[] | undefined;
}
export interface NetworkFunctionGroup {
    Name?: string | undefined;
}
export type NetworkFunctionGroupList = NetworkFunctionGroup[];
export type EdgeSet = string[];
export type EdgeSetList = string[][];
export interface EdgeOverride {
    EdgeSets?: string[][] | undefined;
    UseEdge?: string | undefined;
}
export type WithEdgeOverridesList = EdgeOverride[];
export interface Via {
    NetworkFunctionGroups?: NetworkFunctionGroup[] | undefined;
    WithEdgeOverrides?: EdgeOverride[] | undefined;
}
export interface ServiceInsertionAction {
    Action?: SegmentActionServiceInsertion | undefined;
    Mode?: SendViaMode | undefined;
    WhenSentTo?: WhenSentTo | undefined;
    Via?: Via | undefined;
}
export type ServiceInsertionActionList = ServiceInsertionAction[];
export interface CoreNetworkChangeValues {
    SegmentName?: string | undefined;
    NetworkFunctionGroupName?: string | undefined;
    EdgeLocations?: string[] | undefined;
    Asn?: number | undefined;
    Cidr?: string | undefined;
    DestinationIdentifier?: string | undefined;
    InsideCidrBlocks?: string[] | undefined;
    SharedSegments?: string[] | undefined;
    ServiceInsertionActions?: ServiceInsertionAction[] | undefined;
    VpnEcmpSupport?: boolean | undefined;
    DnsSupport?: boolean | undefined;
    SecurityGroupReferencingSupport?: boolean | undefined;
    RoutingPolicyDirection?: RoutingPolicyDirection | undefined;
    RoutingPolicy?: string | undefined;
    PeerEdgeLocations?: string[] | undefined;
    AttachmentId?: string | undefined;
    RoutingPolicyAssociationDetails?: RoutingPolicyAssociationDetail[] | undefined;
}
export interface CoreNetworkChange {
    Type?: ChangeType | undefined;
    Action?: ChangeAction | undefined;
    Identifier?: string | undefined;
    PreviousValues?: CoreNetworkChangeValues | undefined;
    NewValues?: CoreNetworkChangeValues | undefined;
    IdentifierPath?: string | undefined;
}
export type CoreNetworkChangeList = CoreNetworkChange[];
export interface GetCoreNetworkChangeSetResponse {
    CoreNetworkChanges?: CoreNetworkChange[] | undefined;
    NextToken?: string | undefined;
}
export interface GetCoreNetworkPolicyRequest {
    CoreNetworkId: string;
    PolicyVersionId?: number | undefined;
    Alias?: CoreNetworkPolicyAlias | undefined;
}
export interface GetCoreNetworkPolicyResponse {
    CoreNetworkPolicy?: CoreNetworkPolicy | undefined;
}
export type CustomerGatewayArnList = string[];
export interface GetCustomerGatewayAssociationsRequest {
    GlobalNetworkId: string;
    CustomerGatewayArns?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type CustomerGatewayAssociationList = CustomerGatewayAssociation[];
export interface GetCustomerGatewayAssociationsResponse {
    CustomerGatewayAssociations?: CustomerGatewayAssociation[] | undefined;
    NextToken?: string | undefined;
}
export type DeviceIdList = string[];
export interface GetDevicesRequest {
    GlobalNetworkId: string;
    DeviceIds?: string[] | undefined;
    SiteId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DeviceList = Device[];
export interface GetDevicesResponse {
    Devices?: Device[] | undefined;
    NextToken?: string | undefined;
}
export interface GetDirectConnectGatewayAttachmentRequest {
    AttachmentId: string;
}
export interface GetDirectConnectGatewayAttachmentResponse {
    DirectConnectGatewayAttachment?: DirectConnectGatewayAttachment | undefined;
}
export interface GetLinkAssociationsRequest {
    GlobalNetworkId: string;
    DeviceId?: string | undefined;
    LinkId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LinkAssociationList = LinkAssociation[];
export interface GetLinkAssociationsResponse {
    LinkAssociations?: LinkAssociation[] | undefined;
    NextToken?: string | undefined;
}
export type LinkIdList = string[];
export interface GetLinksRequest {
    GlobalNetworkId: string;
    LinkIds?: string[] | undefined;
    SiteId?: string | undefined;
    Type?: string | undefined;
    Provider?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LinkList = Link[];
export interface GetLinksResponse {
    Links?: Link[] | undefined;
    NextToken?: string | undefined;
}
export interface GetNetworkResourceCountsRequest {
    GlobalNetworkId: string;
    ResourceType?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface NetworkResourceCount {
    ResourceType?: string | undefined;
    Count?: number | undefined;
}
export type NetworkResourceCountList = NetworkResourceCount[];
export interface GetNetworkResourceCountsResponse {
    NetworkResourceCounts?: NetworkResourceCount[] | undefined;
    NextToken?: string | undefined;
}
export interface GetNetworkResourceRelationshipsRequest {
    GlobalNetworkId: string;
    CoreNetworkId?: string | undefined;
    RegisteredGatewayArn?: string | undefined;
    AwsRegion?: string | undefined;
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Relationship {
    From?: string | undefined;
    To?: string | undefined;
}
export type RelationshipList = Relationship[];
export interface GetNetworkResourceRelationshipsResponse {
    Relationships?: Relationship[] | undefined;
    NextToken?: string | undefined;
}
export interface GetNetworkResourcesRequest {
    GlobalNetworkId: string;
    CoreNetworkId?: string | undefined;
    RegisteredGatewayArn?: string | undefined;
    AwsRegion?: string | undefined;
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type NetworkResourceMetadataMap = {
    [key: string]: string | undefined;
};
export interface NetworkResource {
    RegisteredGatewayArn?: string | undefined;
    CoreNetworkId?: string | undefined;
    AwsRegion?: string | undefined;
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    ResourceArn?: string | undefined;
    Definition?: string | undefined;
    DefinitionTimestamp?: Date | undefined;
    Tags?: Tag[] | undefined;
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type NetworkResourceList = NetworkResource[];
export interface GetNetworkResourcesResponse {
    NetworkResources?: NetworkResource[] | undefined;
    NextToken?: string | undefined;
}
export interface CoreNetworkSegmentEdgeIdentifier {
    CoreNetworkId?: string | undefined;
    SegmentName?: string | undefined;
    EdgeLocation?: string | undefined;
}
export interface CoreNetworkNetworkFunctionGroupIdentifier {
    CoreNetworkId?: string | undefined;
    NetworkFunctionGroupName?: string | undefined;
    EdgeLocation?: string | undefined;
}
export interface RouteTableIdentifier {
    TransitGatewayRouteTableArn?: string | undefined;
    CoreNetworkSegmentEdge?: CoreNetworkSegmentEdgeIdentifier | undefined;
    CoreNetworkNetworkFunctionGroup?: CoreNetworkNetworkFunctionGroupIdentifier | undefined;
}
export type RouteState = "ACTIVE" | "BLACKHOLE" | (string & {});
export type RouteStateList = RouteState[];
export type RouteType = "PROPAGATED" | "STATIC" | "SYSTEM" | (string & {});
export type RouteTypeList = RouteType[];
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export type FilterMap = {
    [key: string]: string[] | undefined;
};
export interface GetNetworkRoutesRequest {
    GlobalNetworkId: string;
    RouteTableIdentifier: RouteTableIdentifier;
    ExactCidrMatches?: string[] | undefined;
    LongestPrefixMatches?: string[] | undefined;
    SubnetOfMatches?: string[] | undefined;
    SupernetOfMatches?: string[] | undefined;
    PrefixListIds?: string[] | undefined;
    States?: RouteState[] | undefined;
    Types?: RouteType[] | undefined;
    DestinationFilters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RouteTableType = "TRANSIT_GATEWAY_ROUTE_TABLE" | "CORE_NETWORK_SEGMENT" | "NETWORK_FUNCTION_GROUP" | (string & {});
export type TransitGatewayAttachmentId = string;
export interface NetworkRouteDestination {
    CoreNetworkAttachmentId?: string | undefined;
    TransitGatewayAttachmentId?: string | undefined;
    SegmentName?: string | undefined;
    NetworkFunctionGroupName?: string | undefined;
    EdgeLocation?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
}
export type NetworkRouteDestinationList = NetworkRouteDestination[];
export interface NetworkRoute {
    DestinationCidrBlock?: string | undefined;
    Destinations?: NetworkRouteDestination[] | undefined;
    PrefixListId?: string | undefined;
    State?: RouteState | undefined;
    Type?: RouteType | undefined;
}
export type NetworkRouteList = NetworkRoute[];
export interface GetNetworkRoutesResponse {
    RouteTableArn?: string | undefined;
    CoreNetworkSegmentEdge?: CoreNetworkSegmentEdgeIdentifier | undefined;
    CoreNetworkNetworkFunctionGroup?: CoreNetworkNetworkFunctionGroupIdentifier | undefined;
    RouteTableType?: RouteTableType | undefined;
    RouteTableTimestamp?: Date | undefined;
    NetworkRoutes?: NetworkRoute[] | undefined;
    NextToken?: string | undefined;
}
export interface GetNetworkTelemetryRequest {
    GlobalNetworkId: string;
    CoreNetworkId?: string | undefined;
    RegisteredGatewayArn?: string | undefined;
    AwsRegion?: string | undefined;
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ConnectionType = "BGP" | "IPSEC" | (string & {});
export type ConnectionStatus = "UP" | "DOWN" | (string & {});
export interface ConnectionHealth {
    Type?: ConnectionType | undefined;
    Status?: ConnectionStatus | undefined;
    Timestamp?: Date | undefined;
}
export interface NetworkTelemetry {
    RegisteredGatewayArn?: string | undefined;
    CoreNetworkId?: string | undefined;
    AwsRegion?: string | undefined;
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceId?: string | undefined;
    ResourceArn?: string | undefined;
    Address?: string | undefined;
    Health?: ConnectionHealth | undefined;
}
export type NetworkTelemetryList = NetworkTelemetry[];
export interface GetNetworkTelemetryResponse {
    NetworkTelemetry?: NetworkTelemetry[] | undefined;
    NextToken?: string | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type SynthesizedJsonResourcePolicyDocument = string;
export interface GetResourcePolicyResponse {
    PolicyDocument?: string | undefined;
}
export interface GetRouteAnalysisRequest {
    GlobalNetworkId: string;
    RouteAnalysisId: string;
}
export type RouteAnalysisStatus = "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export type TransitGatewayAttachmentArn = string;
export interface RouteAnalysisEndpointOptions {
    TransitGatewayAttachmentArn?: string | undefined;
    TransitGatewayArn?: string | undefined;
    IpAddress?: string | undefined;
}
export type RouteAnalysisCompletionResultCode = "CONNECTED" | "NOT_CONNECTED" | (string & {});
export type RouteAnalysisCompletionReasonCode = "TRANSIT_GATEWAY_ATTACHMENT_NOT_FOUND" | "TRANSIT_GATEWAY_ATTACHMENT_NOT_IN_TRANSIT_GATEWAY" | "CYCLIC_PATH_DETECTED" | "TRANSIT_GATEWAY_ATTACHMENT_STABLE_ROUTE_TABLE_NOT_FOUND" | "ROUTE_NOT_FOUND" | "BLACKHOLE_ROUTE_FOR_DESTINATION_FOUND" | "INACTIVE_ROUTE_FOR_DESTINATION_FOUND" | "TRANSIT_GATEWAY_ATTACHMENT_ATTACH_ARN_NO_MATCH" | "MAX_HOPS_EXCEEDED" | "POSSIBLE_MIDDLEBOX" | "NO_DESTINATION_ARN_PROVIDED" | (string & {});
export type ReasonContextKey = string;
export type ReasonContextValue = string;
export type ReasonContextMap = {
    [key: string]: string | undefined;
};
export interface RouteAnalysisCompletion {
    ResultCode?: RouteAnalysisCompletionResultCode | undefined;
    ReasonCode?: RouteAnalysisCompletionReasonCode | undefined;
    ReasonContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface NetworkResourceSummary {
    RegisteredGatewayArn?: string | undefined;
    ResourceArn?: string | undefined;
    ResourceType?: string | undefined;
    Definition?: string | undefined;
    NameTag?: string | undefined;
    IsMiddlebox?: boolean | undefined;
}
export interface PathComponent {
    Sequence?: number | undefined;
    Resource?: NetworkResourceSummary | undefined;
    DestinationCidrBlock?: string | undefined;
}
export type PathComponentList = PathComponent[];
export interface RouteAnalysisPath {
    CompletionStatus?: RouteAnalysisCompletion | undefined;
    Path?: PathComponent[] | undefined;
}
export interface RouteAnalysis {
    GlobalNetworkId?: string | undefined;
    OwnerAccountId?: string | undefined;
    RouteAnalysisId?: string | undefined;
    StartTimestamp?: Date | undefined;
    Status?: RouteAnalysisStatus | undefined;
    Source?: RouteAnalysisEndpointOptions | undefined;
    Destination?: RouteAnalysisEndpointOptions | undefined;
    IncludeReturnPath?: boolean | undefined;
    UseMiddleboxes?: boolean | undefined;
    ForwardPath?: RouteAnalysisPath | undefined;
    ReturnPath?: RouteAnalysisPath | undefined;
}
export interface GetRouteAnalysisResponse {
    RouteAnalysis?: RouteAnalysis | undefined;
}
export type SiteIdList = string[];
export interface GetSitesRequest {
    GlobalNetworkId: string;
    SiteIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SiteList = Site[];
export interface GetSitesResponse {
    Sites?: Site[] | undefined;
    NextToken?: string | undefined;
}
export interface GetSiteToSiteVpnAttachmentRequest {
    AttachmentId: string;
}
export interface GetSiteToSiteVpnAttachmentResponse {
    SiteToSiteVpnAttachment?: SiteToSiteVpnAttachment | undefined;
}
export type TransitGatewayConnectPeerArnList = string[];
export interface GetTransitGatewayConnectPeerAssociationsRequest {
    GlobalNetworkId: string;
    TransitGatewayConnectPeerArns?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type TransitGatewayConnectPeerAssociationList = TransitGatewayConnectPeerAssociation[];
export interface GetTransitGatewayConnectPeerAssociationsResponse {
    TransitGatewayConnectPeerAssociations?: TransitGatewayConnectPeerAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTransitGatewayPeeringRequest {
    PeeringId: string;
}
export interface GetTransitGatewayPeeringResponse {
    TransitGatewayPeering?: TransitGatewayPeering | undefined;
}
export type TransitGatewayArnList = string[];
export interface GetTransitGatewayRegistrationsRequest {
    GlobalNetworkId: string;
    TransitGatewayArns?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type TransitGatewayRegistrationList = TransitGatewayRegistration[];
export interface GetTransitGatewayRegistrationsResponse {
    TransitGatewayRegistrations?: TransitGatewayRegistration[] | undefined;
    NextToken?: string | undefined;
}
export interface GetTransitGatewayRouteTableAttachmentRequest {
    AttachmentId: string;
}
export interface GetTransitGatewayRouteTableAttachmentResponse {
    TransitGatewayRouteTableAttachment?: TransitGatewayRouteTableAttachment | undefined;
}
export interface GetVpcAttachmentRequest {
    AttachmentId: string;
}
export interface GetVpcAttachmentResponse {
    VpcAttachment?: VpcAttachment | undefined;
}
export interface ListAttachmentNatConfigurationsRequest {
    CoreNetworkId?: string | undefined;
    AttachmentId?: string | undefined;
    Filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type NatRuleState = "CREATING" | "MODIFYING" | "DELETING" | "ACTIVATED" | "ACTIVATING" | "DEACTIVATED" | "DEACTIVATING" | "FAILED" | "PENDING_ATTACHMENT_ACCEPTANCE" | (string & {});
export interface NatRule {
    RuleNumber?: number | undefined;
    MatchSourceCidr?: string | undefined;
    NatCidr?: string | undefined;
    State?: NatRuleState | undefined;
}
export type NatRuleList = NatRule[];
export interface AttachmentNatConfiguration {
    AttachmentId?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportState | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    NatGatewayRules?: NatRule[] | undefined;
}
export type AttachmentNatConfigurationList = AttachmentNatConfiguration[];
export interface ListAttachmentNatConfigurationsResponse {
    AttachmentNatConfigurations: AttachmentNatConfiguration[];
    NextToken?: string | undefined;
}
export interface ListAttachmentRoutingPolicyAssociationsRequest {
    CoreNetworkId: string;
    AttachmentId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AttachmentRoutingPolicyAssociationSummary {
    AttachmentId?: string | undefined;
    PendingRoutingPolicies?: string[] | undefined;
    AssociatedRoutingPolicies?: string[] | undefined;
    RoutingPolicyLabel?: string | undefined;
}
export type AttachmentRoutingPolicyAssociationsList = AttachmentRoutingPolicyAssociationSummary[];
export interface ListAttachmentRoutingPolicyAssociationsResponse {
    AttachmentRoutingPolicyAssociations?: AttachmentRoutingPolicyAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAttachmentsRequest {
    CoreNetworkId?: string | undefined;
    AttachmentType?: AttachmentType | undefined;
    EdgeLocation?: string | undefined;
    State?: AttachmentState | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AttachmentList = Attachment[];
export interface ListAttachmentsResponse {
    Attachments?: Attachment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConnectPeersRequest {
    CoreNetworkId?: string | undefined;
    ConnectAttachmentId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ConnectPeerSummary {
    CoreNetworkId?: string | undefined;
    ConnectAttachmentId?: string | undefined;
    ConnectPeerId?: string | undefined;
    EdgeLocation?: string | undefined;
    ConnectPeerState?: ConnectPeerState | undefined;
    CreatedAt?: Date | undefined;
    Tags?: Tag[] | undefined;
    SubnetArn?: string | undefined;
}
export type ConnectPeerSummaryList = ConnectPeerSummary[];
export interface ListConnectPeersResponse {
    ConnectPeers?: ConnectPeerSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreNetworkPolicyVersionsRequest {
    CoreNetworkId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface CoreNetworkPolicyVersion {
    CoreNetworkId?: string | undefined;
    PolicyVersionId?: number | undefined;
    Alias?: CoreNetworkPolicyAlias | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    ChangeSetState?: ChangeSetState | undefined;
}
export type CoreNetworkPolicyVersionList = CoreNetworkPolicyVersion[];
export interface ListCoreNetworkPolicyVersionsResponse {
    CoreNetworkPolicyVersions?: CoreNetworkPolicyVersion[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreNetworkPrefixListAssociationsRequest {
    CoreNetworkId: string;
    PrefixListArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface PrefixListAssociation {
    CoreNetworkId?: string | undefined;
    PrefixListArn?: string | undefined;
    PrefixListAlias?: string | undefined;
}
export type PrefixListAssociationList = PrefixListAssociation[];
export interface ListCoreNetworkPrefixListAssociationsResponse {
    PrefixListAssociations?: PrefixListAssociation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreNetworkRoutingInformationRequest {
    CoreNetworkId: string;
    SegmentName: string;
    EdgeLocation: string;
    NextHopFilters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    ExactPrefixMatches?: string[] | undefined;
    LongestPrefixMatches?: string[] | undefined;
    SubnetOfMatches?: string[] | undefined;
    SupernetOfMatches?: string[] | undefined;
    LocalPreferenceMatches?: string[] | undefined;
    ExactAsPathMatches?: string[] | undefined;
    MedMatches?: string[] | undefined;
    CommunityMatches?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RoutingInformationNextHop {
    IpAddress?: string | undefined;
    CoreNetworkAttachmentId?: string | undefined;
    ResourceId?: string | undefined;
    ResourceType?: string | undefined;
    SegmentName?: string | undefined;
    EdgeLocation?: string | undefined;
}
export interface CoreNetworkRoutingInformation {
    Prefix?: string | undefined;
    NextHop?: RoutingInformationNextHop | undefined;
    LocalPreference?: string | undefined;
    Med?: string | undefined;
    AsPath?: string[] | undefined;
    Communities?: string[] | undefined;
}
export type CoreNetworkRoutingInformationList = CoreNetworkRoutingInformation[];
export interface ListCoreNetworkRoutingInformationResponse {
    CoreNetworkRoutingInformation?: CoreNetworkRoutingInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreNetworksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface CoreNetworkSummary {
    CoreNetworkId?: string | undefined;
    CoreNetworkArn?: string | undefined;
    GlobalNetworkId?: string | undefined;
    OwnerAccountId?: string | undefined;
    State?: CoreNetworkState | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type CoreNetworkSummaryList = CoreNetworkSummary[];
export interface ListCoreNetworksResponse {
    CoreNetworks?: CoreNetworkSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOrganizationServiceAccessStatusRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OrganizationId = string;
export type OrganizationAwsServiceAccessStatus = string;
export type SLRDeploymentStatus = string;
export type AccountId = string;
export interface AccountStatus {
    AccountId?: string | undefined;
    SLRDeploymentStatus?: string | undefined;
}
export type AccountStatusList = AccountStatus[];
export interface OrganizationStatus {
    OrganizationId?: string | undefined;
    OrganizationAwsServiceAccessStatus?: string | undefined;
    SLRDeploymentStatus?: string | undefined;
    AccountStatusList?: AccountStatus[] | undefined;
}
export interface ListOrganizationServiceAccessStatusResponse {
    OrganizationStatus?: OrganizationStatus | undefined;
    NextToken?: string | undefined;
}
export interface ListPeeringsRequest {
    CoreNetworkId?: string | undefined;
    PeeringType?: PeeringType | undefined;
    EdgeLocation?: string | undefined;
    State?: PeeringState | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PeeringList = Peering[];
export interface ListPeeringsResponse {
    Peerings?: Peering[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    TagList?: Tag[] | undefined;
}
export interface PutAttachmentRoutingPolicyLabelRequest {
    CoreNetworkId: string;
    AttachmentId: string;
    RoutingPolicyLabel: string;
    ClientToken?: string | undefined;
}
export interface PutAttachmentRoutingPolicyLabelResponse {
    CoreNetworkId?: string | undefined;
    AttachmentId?: string | undefined;
    RoutingPolicyLabel?: string | undefined;
}
export interface PutCoreNetworkPolicyRequest {
    CoreNetworkId: string;
    PolicyDocument: string;
    Description?: string | undefined;
    LatestVersionId?: number | undefined;
    ClientToken?: string | undefined;
}
export interface PutCoreNetworkPolicyResponse {
    CoreNetworkPolicy?: CoreNetworkPolicy | undefined;
}
export interface PutResourcePolicyRequest {
    PolicyDocument: string;
    ResourceArn: string;
}
export interface PutResourcePolicyResponse {
}
export interface RegisterTransitGatewayRequest {
    GlobalNetworkId: string;
    TransitGatewayArn: string;
}
export interface RegisterTransitGatewayResponse {
    TransitGatewayRegistration?: TransitGatewayRegistration | undefined;
}
export interface RejectAttachmentRequest {
    AttachmentId: string;
}
export interface RejectAttachmentResponse {
    Attachment?: Attachment | undefined;
}
export interface RemoveAttachmentRoutingPolicyLabelRequest {
    CoreNetworkId: string;
    AttachmentId: string;
}
export interface RemoveAttachmentRoutingPolicyLabelResponse {
    CoreNetworkId?: string | undefined;
    AttachmentId?: string | undefined;
    RoutingPolicyLabel?: string | undefined;
}
export interface RestoreCoreNetworkPolicyVersionRequest {
    CoreNetworkId: string;
    PolicyVersionId: number;
}
export interface RestoreCoreNetworkPolicyVersionResponse {
    CoreNetworkPolicy?: CoreNetworkPolicy | undefined;
}
export type Action = string;
export interface StartOrganizationServiceAccessUpdateRequest {
    Action: string;
}
export interface StartOrganizationServiceAccessUpdateResponse {
    OrganizationStatus?: OrganizationStatus | undefined;
}
export interface RouteAnalysisEndpointOptionsSpecification {
    TransitGatewayAttachmentArn?: string | undefined;
    IpAddress?: string | undefined;
}
export interface StartRouteAnalysisRequest {
    GlobalNetworkId: string;
    Source: RouteAnalysisEndpointOptionsSpecification;
    Destination: RouteAnalysisEndpointOptionsSpecification;
    IncludeReturnPath?: boolean | undefined;
    UseMiddleboxes?: boolean | undefined;
}
export interface StartRouteAnalysisResponse {
    RouteAnalysis?: RouteAnalysis | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAttachmentNatConfigurationRequest {
    AttachmentId: string;
    NatGatewaySupport?: NatGatewaySupportValue | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    NatGatewayRules?: NatRuleRequest[] | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateAttachmentNatConfigurationResponse {
    AttachmentId?: string | undefined;
    NatGatewaySupport?: NatGatewaySupportState | undefined;
    NatSystemRouteSupport?: boolean | undefined;
    NatGatewayRules?: NatRule[] | undefined;
}
export interface UpdateConnectionRequest {
    GlobalNetworkId: string;
    ConnectionId: string;
    LinkId?: string | undefined;
    ConnectedLinkId?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateConnectionResponse {
    Connection?: Connection | undefined;
}
export interface UpdateCoreNetworkRequest {
    CoreNetworkId: string;
    Description?: string | undefined;
}
export interface UpdateCoreNetworkResponse {
    CoreNetwork?: CoreNetwork | undefined;
}
export interface UpdateDeviceRequest {
    GlobalNetworkId: string;
    DeviceId: string;
    AWSLocation?: AWSLocation | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    Vendor?: string | undefined;
    Model?: string | undefined;
    SerialNumber?: string | undefined;
    Location?: Location | undefined;
    SiteId?: string | undefined;
}
export interface UpdateDeviceResponse {
    Device?: Device | undefined;
}
export interface UpdateDirectConnectGatewayAttachmentRequest {
    AttachmentId: string;
    EdgeLocations?: string[] | undefined;
}
export interface UpdateDirectConnectGatewayAttachmentResponse {
    DirectConnectGatewayAttachment?: DirectConnectGatewayAttachment | undefined;
}
export interface UpdateGlobalNetworkRequest {
    GlobalNetworkId: string;
    Description?: string | undefined;
}
export interface UpdateGlobalNetworkResponse {
    GlobalNetwork?: GlobalNetwork | undefined;
}
export interface UpdateLinkRequest {
    GlobalNetworkId: string;
    LinkId: string;
    Description?: string | undefined;
    Type?: string | undefined;
    Bandwidth?: Bandwidth | undefined;
    Provider?: string | undefined;
}
export interface UpdateLinkResponse {
    Link?: Link | undefined;
}
export interface UpdateNetworkResourceMetadataRequest {
    GlobalNetworkId: string;
    ResourceArn: string;
    Metadata: {
        [key: string]: string | undefined;
    };
}
export interface UpdateNetworkResourceMetadataResponse {
    ResourceArn?: string | undefined;
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateSiteRequest {
    GlobalNetworkId: string;
    SiteId: string;
    Description?: string | undefined;
    Location?: Location | undefined;
}
export interface UpdateSiteResponse {
    Site?: Site | undefined;
}
export interface UpdateVpcAttachmentRequest {
    AttachmentId: string;
    AddSubnetArns?: string[] | undefined;
    RemoveSubnetArns?: string[] | undefined;
    Options?: VpcOptions | undefined;
}
export interface UpdateVpcAttachmentResponse {
    VpcAttachment?: VpcAttachment | undefined;
}
export type RetryAfterSeconds = number;
export type ExceptionContextKey = string;
export type ExceptionContextValue = string;
export type ExceptionContextMap = {
    [key: string]: string | undefined;
};
export type ValidationExceptionReason = "UnknownOperation" | "CannotParse" | "FieldValidationFailed" | "Other" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts a core network attachment request.
 *
 * Once the attachment request is accepted by a core network owner, the attachment is
 * created and connected to a core network.
 */
export declare const acceptAttachment: API.OperationMethod<AcceptAttachmentRequest & RegionInput, AcceptAttachmentResponse, AcceptAttachmentError, Credentials | HttpClient.HttpClient>;
export type AssociateConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a core network Connect peer with a device and optionally, with a link.
 *
 * If you specify a link, it must be associated with the specified device. You can only
 * associate core network Connect peers that have been created on a core network Connect
 * attachment on a core network.
 */
export declare const associateConnectPeer: API.OperationMethod<AssociateConnectPeerRequest & RegionInput, AssociateConnectPeerResponse, AssociateConnectPeerError, Credentials | HttpClient.HttpClient>;
export type AssociateCustomerGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a customer gateway with a device and optionally, with a link. If you
 * specify a link, it must be associated with the specified device.
 *
 * You can only associate customer gateways that are connected to a VPN attachment on a
 * transit gateway or core network registered in your global network. When you register a
 * transit gateway or core network, customer gateways that are connected to the transit
 * gateway are automatically included in the global network. To list customer gateways
 * that are connected to a transit gateway, use the DescribeVpnConnections EC2 API and filter by
 * `transit-gateway-id`.
 *
 * You cannot associate a customer gateway with more than one device and link.
 */
export declare const associateCustomerGateway: API.OperationMethod<AssociateCustomerGatewayRequest & RegionInput, AssociateCustomerGatewayResponse, AssociateCustomerGatewayError, Credentials | HttpClient.HttpClient>;
export type AssociateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a link to a device. A device can be associated to multiple links and a link can be associated to multiple devices. The device and link must be in the same global network and the same site.
 */
export declare const associateLink: API.OperationMethod<AssociateLinkRequest & RegionInput, AssociateLinkResponse, AssociateLinkError, Credentials | HttpClient.HttpClient>;
export type AssociateTransitGatewayConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a transit gateway Connect peer with a device, and optionally, with a link. If you
 * specify a link, it must be associated with the specified device.
 *
 * You can only associate transit gateway Connect peers that have been created on a
 * transit gateway that's registered in your global network.
 *
 * You cannot associate a transit gateway Connect peer with more than one device and link.
 */
export declare const associateTransitGatewayConnectPeer: API.OperationMethod<AssociateTransitGatewayConnectPeerRequest & RegionInput, AssociateTransitGatewayConnectPeerResponse, AssociateTransitGatewayConnectPeerError, Credentials | HttpClient.HttpClient>;
export type CreateConnectAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a core network Connect attachment from a specified core network attachment.
 *
 * A core network Connect attachment is a GRE-based tunnel attachment that you can use to
 * establish a connection between a core network and an appliance. A core network Connect
 * attachment uses an existing VPC attachment as the underlying transport mechanism.
 */
export declare const createConnectAttachment: API.OperationMethod<CreateConnectAttachmentRequest & RegionInput, CreateConnectAttachmentResponse, CreateConnectAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connection between two devices. The devices can be a physical or virtual appliance that connects to a third-party appliance in a VPC, or a physical appliance that connects to another physical appliance in an on-premises network.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest & RegionInput, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a core network Connect peer for a specified core network connect attachment between a core network and an appliance.
 * The peer address and transit gateway address must be the same IP address family (IPv4 or IPv6).
 */
export declare const createConnectPeer: API.OperationMethod<CreateConnectPeerRequest & RegionInput, CreateConnectPeerResponse, CreateConnectPeerError, Credentials | HttpClient.HttpClient>;
export type CreateCoreNetworkError = AccessDeniedException | ConflictException | CoreNetworkPolicyException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a core network as part of your global network, and optionally, with a core network policy.
 */
export declare const createCoreNetwork: API.OperationMethod<CreateCoreNetworkRequest & RegionInput, CreateCoreNetworkResponse, CreateCoreNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateCoreNetworkPrefixListAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an association between a core network and a prefix list for routing control.
 */
export declare const createCoreNetworkPrefixListAssociation: API.OperationMethod<CreateCoreNetworkPrefixListAssociationRequest & RegionInput, CreateCoreNetworkPrefixListAssociationResponse, CreateCoreNetworkPrefixListAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new device in a global network. If you specify both a site ID and a
 * location, the location of the site is used for visualization in the Network Manager console.
 */
export declare const createDevice: API.OperationMethod<CreateDeviceRequest & RegionInput, CreateDeviceResponse, CreateDeviceError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services Direct Connect gateway attachment
 */
export declare const createDirectConnectGatewayAttachment: API.OperationMethod<CreateDirectConnectGatewayAttachmentRequest & RegionInput, CreateDirectConnectGatewayAttachmentResponse, CreateDirectConnectGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalNetworkError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new, empty global network.
 */
export declare const createGlobalNetwork: API.OperationMethod<CreateGlobalNetworkRequest & RegionInput, CreateGlobalNetworkResponse, CreateGlobalNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new link for a specified site.
 */
export declare const createLink: API.OperationMethod<CreateLinkRequest & RegionInput, CreateLinkResponse, CreateLinkError, Credentials | HttpClient.HttpClient>;
export type CreateSiteError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new site in a global network.
 */
export declare const createSite: API.OperationMethod<CreateSiteRequest & RegionInput, CreateSiteResponse, CreateSiteError, Credentials | HttpClient.HttpClient>;
export type CreateSiteToSiteVpnAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Web Services site-to-site VPN attachment on an edge location of a core network.
 */
export declare const createSiteToSiteVpnAttachment: API.OperationMethod<CreateSiteToSiteVpnAttachmentRequest & RegionInput, CreateSiteToSiteVpnAttachmentResponse, CreateSiteToSiteVpnAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateTransitGatewayPeeringError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a transit gateway peering connection.
 */
export declare const createTransitGatewayPeering: API.OperationMethod<CreateTransitGatewayPeeringRequest & RegionInput, CreateTransitGatewayPeeringResponse, CreateTransitGatewayPeeringError, Credentials | HttpClient.HttpClient>;
export type CreateTransitGatewayRouteTableAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a transit gateway route table attachment.
 */
export declare const createTransitGatewayRouteTableAttachment: API.OperationMethod<CreateTransitGatewayRouteTableAttachmentRequest & RegionInput, CreateTransitGatewayRouteTableAttachmentResponse, CreateTransitGatewayRouteTableAttachmentError, Credentials | HttpClient.HttpClient>;
export type CreateVpcAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a VPC attachment on an edge location of a core network.
 */
export declare const createVpcAttachment: API.OperationMethod<CreateVpcAttachmentRequest & RegionInput, CreateVpcAttachmentResponse, CreateVpcAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an attachment. Supports all attachment types.
 */
export declare const deleteAttachment: API.OperationMethod<DeleteAttachmentRequest & RegionInput, DeleteAttachmentResponse, DeleteAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified connection in your global network.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest & RegionInput, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Connect peer.
 */
export declare const deleteConnectPeer: API.OperationMethod<DeleteConnectPeerRequest & RegionInput, DeleteConnectPeerResponse, DeleteConnectPeerError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a core network along with all core network policies. This can only be done if there are no attachments on a core network.
 */
export declare const deleteCoreNetwork: API.OperationMethod<DeleteCoreNetworkRequest & RegionInput, DeleteCoreNetworkResponse, DeleteCoreNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreNetworkPolicyVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a policy version from a core network. You can't delete the current LIVE policy.
 */
export declare const deleteCoreNetworkPolicyVersion: API.OperationMethod<DeleteCoreNetworkPolicyVersionRequest & RegionInput, DeleteCoreNetworkPolicyVersionResponse, DeleteCoreNetworkPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreNetworkPrefixListAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an association between a core network and a prefix list.
 */
export declare const deleteCoreNetworkPrefixListAssociation: API.OperationMethod<DeleteCoreNetworkPrefixListAssociationRequest & RegionInput, DeleteCoreNetworkPrefixListAssociationResponse, DeleteCoreNetworkPrefixListAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing device. You must first disassociate the device from any links and
 * customer gateways.
 */
export declare const deleteDevice: API.OperationMethod<DeleteDeviceRequest & RegionInput, DeleteDeviceResponse, DeleteDeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing global network. You must first delete all global network objects
 * (devices, links, and sites), deregister all transit gateways, and delete any core networks.
 */
export declare const deleteGlobalNetwork: API.OperationMethod<DeleteGlobalNetworkRequest & RegionInput, DeleteGlobalNetworkResponse, DeleteGlobalNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing link. You must first disassociate the link from any devices and
 * customer gateways.
 */
export declare const deleteLink: API.OperationMethod<DeleteLinkRequest & RegionInput, DeleteLinkResponse, DeleteLinkError, Credentials | HttpClient.HttpClient>;
export type DeletePeeringError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing peering connection.
 */
export declare const deletePeering: API.OperationMethod<DeletePeeringRequest & RegionInput, DeletePeeringResponse, DeletePeeringError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a resource policy for the specified resource. This revokes the access of the principals specified in the resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSiteError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing site. The site cannot be associated with any device or link.
 */
export declare const deleteSite: API.OperationMethod<DeleteSiteRequest & RegionInput, DeleteSiteResponse, DeleteSiteError, Credentials | HttpClient.HttpClient>;
export type DeregisterTransitGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters a transit gateway from your global network. This action does not delete
 * your transit gateway, or modify any of its attachments. This action removes any customer gateway associations.
 */
export declare const deregisterTransitGateway: API.OperationMethod<DeregisterTransitGatewayRequest & RegionInput, DeregisterTransitGatewayResponse, DeregisterTransitGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalNetworksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes one or more global networks. By default, all global networks are
 * described. To describe the objects in your global network, you must use the appropriate
 * `Get*` action. For example, to list the transit gateways in your global
 * network, use GetTransitGatewayRegistrations.
 */
export declare const describeGlobalNetworks: API.PaginatedOperationMethod<DescribeGlobalNetworksRequest & RegionInput, DescribeGlobalNetworksResponse, DescribeGlobalNetworksError, Credentials | HttpClient.HttpClient, GlobalNetwork>;
export type DisassociateConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a core network Connect peer from a device and a link.
 */
export declare const disassociateConnectPeer: API.OperationMethod<DisassociateConnectPeerRequest & RegionInput, DisassociateConnectPeerResponse, DisassociateConnectPeerError, Credentials | HttpClient.HttpClient>;
export type DisassociateCustomerGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a customer gateway from a device and a link.
 */
export declare const disassociateCustomerGateway: API.OperationMethod<DisassociateCustomerGatewayRequest & RegionInput, DisassociateCustomerGatewayResponse, DisassociateCustomerGatewayError, Credentials | HttpClient.HttpClient>;
export type DisassociateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an existing device from a link. You must first disassociate any customer
 * gateways that are associated with the link.
 */
export declare const disassociateLink: API.OperationMethod<DisassociateLinkRequest & RegionInput, DisassociateLinkResponse, DisassociateLinkError, Credentials | HttpClient.HttpClient>;
export type DisassociateTransitGatewayConnectPeerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a transit gateway Connect peer from a device and link.
 */
export declare const disassociateTransitGatewayConnectPeer: API.OperationMethod<DisassociateTransitGatewayConnectPeerRequest & RegionInput, DisassociateTransitGatewayConnectPeerResponse, DisassociateTransitGatewayConnectPeerError, Credentials | HttpClient.HttpClient>;
export type ExecuteCoreNetworkChangeSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Executes a change set on your core network. Deploys changes globally based on the policy submitted..
 */
export declare const executeCoreNetworkChangeSet: API.OperationMethod<ExecuteCoreNetworkChangeSetRequest & RegionInput, ExecuteCoreNetworkChangeSetResponse, ExecuteCoreNetworkChangeSetError, Credentials | HttpClient.HttpClient>;
export type GetConnectAttachmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a core network Connect attachment.
 */
export declare const getConnectAttachment: API.OperationMethod<GetConnectAttachmentRequest & RegionInput, GetConnectAttachmentResponse, GetConnectAttachmentError, Credentials | HttpClient.HttpClient>;
export type GetConnectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about one or more of your connections in a global network.
 */
export declare const getConnections: API.PaginatedOperationMethod<GetConnectionsRequest & RegionInput, GetConnectionsResponse, GetConnectionsError, Credentials | HttpClient.HttpClient, Connection>;
export type GetConnectPeerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a core network Connect peer.
 */
export declare const getConnectPeer: API.OperationMethod<GetConnectPeerRequest & RegionInput, GetConnectPeerResponse, GetConnectPeerError, Credentials | HttpClient.HttpClient>;
export type GetConnectPeerAssociationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a core network Connect peer associations.
 */
export declare const getConnectPeerAssociations: API.PaginatedOperationMethod<GetConnectPeerAssociationsRequest & RegionInput, GetConnectPeerAssociationsResponse, GetConnectPeerAssociationsError, Credentials | HttpClient.HttpClient, ConnectPeerAssociation>;
export type GetCoreNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the LIVE policy for a core network.
 */
export declare const getCoreNetwork: API.OperationMethod<GetCoreNetworkRequest & RegionInput, GetCoreNetworkResponse, GetCoreNetworkError, Credentials | HttpClient.HttpClient>;
export type GetCoreNetworkChangeEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a core network change event.
 */
export declare const getCoreNetworkChangeEvents: API.PaginatedOperationMethod<GetCoreNetworkChangeEventsRequest & RegionInput, GetCoreNetworkChangeEventsResponse, GetCoreNetworkChangeEventsError, Credentials | HttpClient.HttpClient, CoreNetworkChangeEvent>;
export type GetCoreNetworkChangeSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a change set between the LIVE core network policy and a submitted policy.
 */
export declare const getCoreNetworkChangeSet: API.PaginatedOperationMethod<GetCoreNetworkChangeSetRequest & RegionInput, GetCoreNetworkChangeSetResponse, GetCoreNetworkChangeSetError, Credentials | HttpClient.HttpClient, CoreNetworkChange>;
export type GetCoreNetworkPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a core network policy. You can get details about your current live policy or any previous policy version.
 */
export declare const getCoreNetworkPolicy: API.OperationMethod<GetCoreNetworkPolicyRequest & RegionInput, GetCoreNetworkPolicyResponse, GetCoreNetworkPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCustomerGatewayAssociationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the association information for customer gateways that are associated with
 * devices and links in your global network.
 */
export declare const getCustomerGatewayAssociations: API.PaginatedOperationMethod<GetCustomerGatewayAssociationsRequest & RegionInput, GetCustomerGatewayAssociationsResponse, GetCustomerGatewayAssociationsError, Credentials | HttpClient.HttpClient, CustomerGatewayAssociation>;
export type GetDevicesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about one or more of your devices in a global network.
 */
export declare const getDevices: API.PaginatedOperationMethod<GetDevicesRequest & RegionInput, GetDevicesResponse, GetDevicesError, Credentials | HttpClient.HttpClient, Device>;
export type GetDirectConnectGatewayAttachmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific Amazon Web Services Direct Connect gateway attachment.
 */
export declare const getDirectConnectGatewayAttachment: API.OperationMethod<GetDirectConnectGatewayAttachmentRequest & RegionInput, GetDirectConnectGatewayAttachmentResponse, GetDirectConnectGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type GetLinkAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the link associations for a device or a link. Either the device ID or the link ID
 * must be specified.
 */
export declare const getLinkAssociations: API.PaginatedOperationMethod<GetLinkAssociationsRequest & RegionInput, GetLinkAssociationsResponse, GetLinkAssociationsError, Credentials | HttpClient.HttpClient, LinkAssociation>;
export type GetLinksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about one or more links in a specified global network.
 *
 * If you specify the site ID, you cannot specify the type or provider in the same request. You can specify the type and provider in the same request.
 */
export declare const getLinks: API.PaginatedOperationMethod<GetLinksRequest & RegionInput, GetLinksResponse, GetLinksError, Credentials | HttpClient.HttpClient, Link>;
export type GetNetworkResourceCountsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the count of network resources, by resource type, for the specified global network.
 */
export declare const getNetworkResourceCounts: API.PaginatedOperationMethod<GetNetworkResourceCountsRequest & RegionInput, GetNetworkResourceCountsResponse, GetNetworkResourceCountsError, Credentials | HttpClient.HttpClient, NetworkResourceCount>;
export type GetNetworkResourceRelationshipsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the network resource relationships for the specified global network.
 */
export declare const getNetworkResourceRelationships: API.PaginatedOperationMethod<GetNetworkResourceRelationshipsRequest & RegionInput, GetNetworkResourceRelationshipsResponse, GetNetworkResourceRelationshipsError, Credentials | HttpClient.HttpClient, Relationship>;
export type GetNetworkResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the network resources for the specified global network.
 *
 * The results include information from the corresponding Describe call for the resource, minus any sensitive information such as pre-shared keys.
 */
export declare const getNetworkResources: API.PaginatedOperationMethod<GetNetworkResourcesRequest & RegionInput, GetNetworkResourcesResponse, GetNetworkResourcesError, Credentials | HttpClient.HttpClient, NetworkResource>;
export type GetNetworkRoutesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the network routes of the specified global network.
 */
export declare const getNetworkRoutes: API.PaginatedOperationMethod<GetNetworkRoutesRequest & RegionInput, GetNetworkRoutesResponse, GetNetworkRoutesError, Credentials | HttpClient.HttpClient, NetworkRoute>;
export type GetNetworkTelemetryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the network telemetry of the specified global network.
 */
export declare const getNetworkTelemetry: API.PaginatedOperationMethod<GetNetworkTelemetryRequest & RegionInput, GetNetworkTelemetryResponse, GetNetworkTelemetryError, Credentials | HttpClient.HttpClient, NetworkTelemetry>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a resource policy.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRouteAnalysisError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about the specified route analysis.
 */
export declare const getRouteAnalysis: API.OperationMethod<GetRouteAnalysisRequest & RegionInput, GetRouteAnalysisResponse, GetRouteAnalysisError, Credentials | HttpClient.HttpClient>;
export type GetSitesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about one or more of your sites in a global network.
 */
export declare const getSites: API.PaginatedOperationMethod<GetSitesRequest & RegionInput, GetSitesResponse, GetSitesError, Credentials | HttpClient.HttpClient, Site>;
export type GetSiteToSiteVpnAttachmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a site-to-site VPN attachment.
 */
export declare const getSiteToSiteVpnAttachment: API.OperationMethod<GetSiteToSiteVpnAttachmentRequest & RegionInput, GetSiteToSiteVpnAttachmentResponse, GetSiteToSiteVpnAttachmentError, Credentials | HttpClient.HttpClient>;
export type GetTransitGatewayConnectPeerAssociationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about one or more of your transit gateway Connect peer associations in a global network.
 */
export declare const getTransitGatewayConnectPeerAssociations: API.PaginatedOperationMethod<GetTransitGatewayConnectPeerAssociationsRequest & RegionInput, GetTransitGatewayConnectPeerAssociationsResponse, GetTransitGatewayConnectPeerAssociationsError, Credentials | HttpClient.HttpClient, TransitGatewayConnectPeerAssociation>;
export type GetTransitGatewayPeeringError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a transit gateway peer.
 */
export declare const getTransitGatewayPeering: API.OperationMethod<GetTransitGatewayPeeringRequest & RegionInput, GetTransitGatewayPeeringResponse, GetTransitGatewayPeeringError, Credentials | HttpClient.HttpClient>;
export type GetTransitGatewayRegistrationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about the transit gateway registrations in a specified
 * global network.
 */
export declare const getTransitGatewayRegistrations: API.PaginatedOperationMethod<GetTransitGatewayRegistrationsRequest & RegionInput, GetTransitGatewayRegistrationsResponse, GetTransitGatewayRegistrationsError, Credentials | HttpClient.HttpClient, TransitGatewayRegistration>;
export type GetTransitGatewayRouteTableAttachmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a transit gateway route table attachment.
 */
export declare const getTransitGatewayRouteTableAttachment: API.OperationMethod<GetTransitGatewayRouteTableAttachmentRequest & RegionInput, GetTransitGatewayRouteTableAttachmentResponse, GetTransitGatewayRouteTableAttachmentError, Credentials | HttpClient.HttpClient>;
export type GetVpcAttachmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a VPC attachment.
 */
export declare const getVpcAttachment: API.OperationMethod<GetVpcAttachmentRequest & RegionInput, GetVpcAttachmentResponse, GetVpcAttachmentError, Credentials | HttpClient.HttpClient>;
export type ListAttachmentNatConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the NAT configurations of core network attachments. You must specify either a core network ID or an attachment ID. Only the core network owner can list NAT configurations.
 */
export declare const listAttachmentNatConfigurations: API.PaginatedOperationMethod<ListAttachmentNatConfigurationsRequest & RegionInput, ListAttachmentNatConfigurationsResponse, ListAttachmentNatConfigurationsError, Credentials | HttpClient.HttpClient, AttachmentNatConfiguration>;
export type ListAttachmentRoutingPolicyAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the routing policy associations for attachments in a core network.
 */
export declare const listAttachmentRoutingPolicyAssociations: API.PaginatedOperationMethod<ListAttachmentRoutingPolicyAssociationsRequest & RegionInput, ListAttachmentRoutingPolicyAssociationsResponse, ListAttachmentRoutingPolicyAssociationsError, Credentials | HttpClient.HttpClient, AttachmentRoutingPolicyAssociationSummary>;
export type ListAttachmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of core network attachments.
 */
export declare const listAttachments: API.PaginatedOperationMethod<ListAttachmentsRequest & RegionInput, ListAttachmentsResponse, ListAttachmentsError, Credentials | HttpClient.HttpClient, Attachment>;
export type ListConnectPeersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of core network Connect peers.
 */
export declare const listConnectPeers: API.PaginatedOperationMethod<ListConnectPeersRequest & RegionInput, ListConnectPeersResponse, ListConnectPeersError, Credentials | HttpClient.HttpClient, ConnectPeerSummary>;
export type ListCoreNetworkPolicyVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of core network policy versions.
 */
export declare const listCoreNetworkPolicyVersions: API.PaginatedOperationMethod<ListCoreNetworkPolicyVersionsRequest & RegionInput, ListCoreNetworkPolicyVersionsResponse, ListCoreNetworkPolicyVersionsError, Credentials | HttpClient.HttpClient, CoreNetworkPolicyVersion>;
export type ListCoreNetworkPrefixListAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the prefix list associations for a core network.
 */
export declare const listCoreNetworkPrefixListAssociations: API.PaginatedOperationMethod<ListCoreNetworkPrefixListAssociationsRequest & RegionInput, ListCoreNetworkPrefixListAssociationsResponse, ListCoreNetworkPrefixListAssociationsError, Credentials | HttpClient.HttpClient, PrefixListAssociation>;
export type ListCoreNetworkRoutingInformationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists routing information for a core network, including routes and their attributes.
 */
export declare const listCoreNetworkRoutingInformation: API.PaginatedOperationMethod<ListCoreNetworkRoutingInformationRequest & RegionInput, ListCoreNetworkRoutingInformationResponse, ListCoreNetworkRoutingInformationError, Credentials | HttpClient.HttpClient, CoreNetworkRoutingInformation>;
export type ListCoreNetworksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of owned and shared core networks.
 */
export declare const listCoreNetworks: API.PaginatedOperationMethod<ListCoreNetworksRequest & RegionInput, ListCoreNetworksResponse, ListCoreNetworksError, Credentials | HttpClient.HttpClient, CoreNetworkSummary>;
export type ListOrganizationServiceAccessStatusError = CommonErrors;
/**
 * Gets the status of the Service Linked Role (SLR) deployment for the accounts in a given Amazon Web Services Organization.
 */
export declare const listOrganizationServiceAccessStatus: API.OperationMethod<ListOrganizationServiceAccessStatusRequest & RegionInput, ListOrganizationServiceAccessStatusResponse, ListOrganizationServiceAccessStatusError, Credentials | HttpClient.HttpClient>;
export type ListPeeringsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the peerings for a core network.
 */
export declare const listPeerings: API.PaginatedOperationMethod<ListPeeringsRequest & RegionInput, ListPeeringsResponse, ListPeeringsError, Credentials | HttpClient.HttpClient, Peering>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAttachmentRoutingPolicyLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Applies a routing policy label to an attachment for traffic routing decisions.
 */
export declare const putAttachmentRoutingPolicyLabel: API.OperationMethod<PutAttachmentRoutingPolicyLabelRequest & RegionInput, PutAttachmentRoutingPolicyLabelResponse, PutAttachmentRoutingPolicyLabelError, Credentials | HttpClient.HttpClient>;
export type PutCoreNetworkPolicyError = AccessDeniedException | ConflictException | CoreNetworkPolicyException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new, immutable version of a core network policy. A subsequent change set is created showing the differences between the LIVE policy and the submitted policy.
 */
export declare const putCoreNetworkPolicy: API.OperationMethod<PutCoreNetworkPolicyRequest & RegionInput, PutCoreNetworkPolicyResponse, PutCoreNetworkPolicyError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource policy.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterTransitGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers a transit gateway in your global network. Not all Regions support transit
 * gateways for global networks. For a list of the supported Regions, see Region Availability in the Amazon Web Services Transit Gateways for Global
 * Networks User Guide. The transit gateway can be in any of the supported
 * Amazon Web Services Regions, but it must be owned by the same Amazon Web Services account that owns the global
 * network. You cannot register a transit gateway in more than one global network.
 */
export declare const registerTransitGateway: API.OperationMethod<RegisterTransitGatewayRequest & RegionInput, RegisterTransitGatewayResponse, RegisterTransitGatewayError, Credentials | HttpClient.HttpClient>;
export type RejectAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rejects a core network attachment request.
 */
export declare const rejectAttachment: API.OperationMethod<RejectAttachmentRequest & RegionInput, RejectAttachmentResponse, RejectAttachmentError, Credentials | HttpClient.HttpClient>;
export type RemoveAttachmentRoutingPolicyLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a routing policy label from an attachment.
 */
export declare const removeAttachmentRoutingPolicyLabel: API.OperationMethod<RemoveAttachmentRoutingPolicyLabelRequest & RegionInput, RemoveAttachmentRoutingPolicyLabelResponse, RemoveAttachmentRoutingPolicyLabelError, Credentials | HttpClient.HttpClient>;
export type RestoreCoreNetworkPolicyVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores a previous policy version as a new, immutable version of a core network policy. A subsequent change set is created showing the differences between the LIVE policy and restored policy.
 */
export declare const restoreCoreNetworkPolicyVersion: API.OperationMethod<RestoreCoreNetworkPolicyVersionRequest & RegionInput, RestoreCoreNetworkPolicyVersionResponse, RestoreCoreNetworkPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type StartOrganizationServiceAccessUpdateError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables the Network Manager service for an Amazon Web Services Organization. This can only be called by a management account within the organization.
 */
export declare const startOrganizationServiceAccessUpdate: API.OperationMethod<StartOrganizationServiceAccessUpdateRequest & RegionInput, StartOrganizationServiceAccessUpdateResponse, StartOrganizationServiceAccessUpdateError, Credentials | HttpClient.HttpClient>;
export type StartRouteAnalysisError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts analyzing the routing path between the specified source and destination. For more information,
 * see Route Analyzer.
 */
export declare const startRouteAnalysis: API.OperationMethod<StartRouteAnalysisRequest & RegionInput, StartRouteAnalysisResponse, StartRouteAnalysisError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAttachmentNatConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the NAT configuration of a core network attachment. You can enable or disable NAT gateway support, specify whether the core network installs system routes for the NAT CIDR blocks, and replace the NAT rules of the attachment. Specify at least one of `NatGatewaySupport`, `NatSystemRouteSupport`, or `NatGatewayRules`.
 *
 * Only the core network owner can update the NAT configuration of an attachment. The attachment must be in the `AVAILABLE`, `PENDING_ATTACHMENT_ACCEPTANCE`, or `PENDING_TAG_ACCEPTANCE` state. Changes are applied asynchronously, and the attachment is in the `UPDATING` state while they are applied. If the attachment is pending acceptance, the NAT configuration is stored and is applied after the attachment is accepted.
 */
export declare const updateAttachmentNatConfiguration: API.OperationMethod<UpdateAttachmentNatConfigurationRequest & RegionInput, UpdateAttachmentNatConfigurationResponse, UpdateAttachmentNatConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the information for an existing connection. To remove information for any of the parameters,
 * specify an empty string.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest & RegionInput, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateCoreNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description of a core network.
 */
export declare const updateCoreNetwork: API.OperationMethod<UpdateCoreNetworkRequest & RegionInput, UpdateCoreNetworkResponse, UpdateCoreNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the details for an existing device. To remove information for any of the
 * parameters, specify an empty string.
 */
export declare const updateDevice: API.OperationMethod<UpdateDeviceRequest & RegionInput, UpdateDeviceResponse, UpdateDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectConnectGatewayAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the edge locations associated with an Amazon Web Services Direct Connect gateway attachment.
 */
export declare const updateDirectConnectGatewayAttachment: API.OperationMethod<UpdateDirectConnectGatewayAttachmentRequest & RegionInput, UpdateDirectConnectGatewayAttachmentResponse, UpdateDirectConnectGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing global network. To remove information for any of the parameters,
 * specify an empty string.
 */
export declare const updateGlobalNetwork: API.OperationMethod<UpdateGlobalNetworkRequest & RegionInput, UpdateGlobalNetworkResponse, UpdateGlobalNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the details for an existing link. To remove information for any of the
 * parameters, specify an empty string.
 */
export declare const updateLink: API.OperationMethod<UpdateLinkRequest & RegionInput, UpdateLinkResponse, UpdateLinkError, Credentials | HttpClient.HttpClient>;
export type UpdateNetworkResourceMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the resource metadata for the specified global network.
 */
export declare const updateNetworkResourceMetadata: API.OperationMethod<UpdateNetworkResourceMetadataRequest & RegionInput, UpdateNetworkResourceMetadataResponse, UpdateNetworkResourceMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateSiteError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the information for an existing site. To remove information for any of the
 * parameters, specify an empty string.
 */
export declare const updateSite: API.OperationMethod<UpdateSiteRequest & RegionInput, UpdateSiteResponse, UpdateSiteError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcAttachmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a VPC attachment.
 */
export declare const updateVpcAttachment: API.OperationMethod<UpdateVpcAttachmentRequest & RegionInput, UpdateVpcAttachmentResponse, UpdateVpcAttachmentError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=networkmanager.d.ts.map