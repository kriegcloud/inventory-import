import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
/**
 * The terminal shows a failed command's friendly message; this keeps its
 * full cause chain in the command's run log.
 */
export declare const logCommandFailure: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/**
 * The pre-command version check. The CLI entrypoint sets it with its
 * services already provided; elsewhere (tests, the API) it does nothing.
 */
export declare const VersionCheck: Context.Reference<Effect.Effect<void, never, never>>;
/**
 * Wraps a command handler as one traced, metered unit. A best-effort check
 * for a newer published version runs first, so its warning prints before
 * any interactive prompt; it is cached for a day and bounded by a short
 * timeout, so this stays fast.
 */
export declare const instrumentCommand: <AttrsArgs = unknown>(command: string, attrs?: (args: AttrsArgs) => Record<string, unknown>) => <Args extends AttrsArgs, A, E, R>(handler: (args: Args) => Effect.Effect<A, E, R>) => ((args: Args) => Effect.Effect<A, E, R>);
//# sourceMappingURL=instrument.d.ts.map