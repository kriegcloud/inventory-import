import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
export declare const ApplyStatus: Schema.Literals<readonly ["attaching", "post-attach", "pending", "pre-creating", "creating", "creating replacement", "created", "updating", "updated", "adopting", "adopted", "deleting", "deleted", "orphaning", "orphaned", "replacing", "replaced", "running", "ran", "skipped", "fail"]>;
export type ApplyStatus = typeof ApplyStatus.Type;
/**
 * How append-only renderers surface a note (the interactive view treats every
 * kind the same): `"status"` is transient spinner text that plain mode folds
 * into the settle line's suffix, `"output"` is verbatim tool output streamed
 * line by line, and absent is a one-shot informational note.
 */
export declare const NoteKind: Schema.Literals<readonly ["status", "output"]>;
export type NoteKind = typeof NoteKind.Type;
/** One binding row on a planned resource. */
export declare const PlannedBinding: Schema.Struct<{
    readonly sid: Schema.String;
    readonly action: Schema.Literals<readonly ["create", "update", "delete", "noop"]>;
}>;
export type PlannedBinding = typeof PlannedBinding.Type;
/** Serializable view of one resource row in a plan. */
export declare const PlannedResource: Schema.Struct<{
    readonly fqn: Schema.String;
    readonly logicalId: Schema.String;
    readonly resourceType: Schema.String;
    /** The action the plan decided for this resource. */
    readonly action: Schema.Literals<readonly ["create", "update", "adopted", "replace", "delete", "orphaned", "noop"]>;
    /** Binding rows the node carries; empty when the resource has none. */
    readonly bindings: Schema.$Array<Schema.Struct<{
        readonly sid: Schema.String;
        readonly action: Schema.Literals<readonly ["create", "update", "delete", "noop"]>;
    }>>;
    /** Mode the node's provider resolved for; absent for mode-agnostic providers. */
    readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    /** On mode-switch replacements: the mode the old generation was created with. */
    readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
}>;
export type PlannedResource = typeof PlannedResource.Type;
/** Serializable view of one stack-action row in a plan. */
export declare const PlannedAction: Schema.Struct<{
    readonly fqn: Schema.String;
    readonly logicalId: Schema.String;
    readonly actionType: Schema.String;
    readonly action: Schema.Literals<readonly ["run", "delete", "noop"]>;
}>;
export type PlannedAction = typeof PlannedAction.Type;
/** Phases a stack plan moves through before it is ready. */
export declare const PlanningPhase: Schema.Literals<readonly ["importing-module", "resolving-services", "loading-state", "computing-plan", "plan-ready"]>;
export type PlanningPhase = typeof PlanningPhase.Type;
/** A note a provider attached to a resource while applying it. */
export declare const ResourceAnnotated: Schema.Struct<{
    readonly type: Schema.Literal<"apply.resource.note">;
    /** Fully-qualified resource or action name used to target its plan row. */
    readonly fqn: Schema.String;
    readonly id: Schema.String;
    readonly message: Schema.String;
    readonly kind: Schema.optionalKey<Schema.Literals<readonly ["status", "output"]>>;
}>;
export type ResourceAnnotated = typeof ResourceAnnotated.Type;
/** A resource or action moved to a new apply status. */
export declare const ResourceStatusChanged: Schema.Struct<{
    readonly type: Schema.Literal<"apply.resource.status">;
    /** Fully-qualified resource or action name used to target its plan row. */
    readonly fqn: Schema.String;
    /** Logical id, e.g. `"api"`. */
    readonly id: Schema.String;
    /** e.g. `"Cloudflare.Worker"`. */
    readonly resourceType: Schema.String;
    readonly status: Schema.Literals<readonly ["attaching", "post-attach", "pending", "pre-creating", "creating", "creating replacement", "created", "updating", "updated", "adopting", "adopted", "deleting", "deleted", "orphaning", "orphaned", "replacing", "replaced", "running", "ran", "skipped", "fail"]>;
    readonly message: Schema.optionalKey<Schema.String>;
    /**
     * The mode this node's provider was resolved for; absent for mode-agnostic
     * providers and for actions.
     */
    readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    /**
     * Set only on mode-switch replacements (local ⇄ live): the mode the OLD
     * generation was created with. Always differs from `providerMode`.
     */
    readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
}>;
export type ResourceStatusChanged = typeof ResourceStatusChanged.Type;
export type ApplyEvent = ResourceAnnotated | ResourceStatusChanged;
/** Every event the engine and the Alchemist operations emit. */
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"plan.phase">;
    readonly phase: Schema.Literals<readonly ["importing-module", "resolving-services", "loading-state", "computing-plan", "plan-ready"]>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"plan.resource.started">;
    readonly fqn: Schema.String;
    readonly logicalId: Schema.String;
    readonly resourceType: Schema.String;
    readonly total: Schema.Number;
}>, Schema.Struct<{
    readonly fqn: Schema.String;
    readonly logicalId: Schema.String;
    readonly resourceType: Schema.String;
    /** The action the plan decided for this resource. */
    readonly action: Schema.Literals<readonly ["create", "update", "adopted", "replace", "delete", "orphaned", "noop"]>;
    /** Binding rows the node carries; empty when the resource has none. */
    readonly bindings: Schema.$Array<Schema.Struct<{
        readonly sid: Schema.String;
        readonly action: Schema.Literals<readonly ["create", "update", "delete", "noop"]>;
    }>>;
    /** Mode the node's provider resolved for; absent for mode-agnostic providers. */
    readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    /** On mode-switch replacements: the mode the old generation was created with. */
    readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    readonly type: Schema.Literal<"plan.resource.completed">;
    readonly completed: Schema.Number;
    readonly total: Schema.Number;
}>, Schema.Struct<{
    readonly fqn: Schema.String;
    readonly logicalId: Schema.String;
    readonly actionType: Schema.String;
    readonly action: Schema.Literals<readonly ["run", "delete", "noop"]>;
    readonly type: Schema.Literal<"plan.action.completed">;
    readonly completed: Schema.Number;
    readonly total: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"apply.resource.note">;
    /** Fully-qualified resource or action name used to target its plan row. */
    readonly fqn: Schema.String;
    readonly id: Schema.String;
    readonly message: Schema.String;
    readonly kind: Schema.optionalKey<Schema.Literals<readonly ["status", "output"]>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"apply.resource.status">;
    /** Fully-qualified resource or action name used to target its plan row. */
    readonly fqn: Schema.String;
    /** Logical id, e.g. `"api"`. */
    readonly id: Schema.String;
    /** e.g. `"Cloudflare.Worker"`. */
    readonly resourceType: Schema.String;
    readonly status: Schema.Literals<readonly ["attaching", "post-attach", "pending", "pre-creating", "creating", "creating replacement", "created", "updating", "updated", "adopting", "adopted", "deleting", "deleted", "orphaning", "orphaned", "replacing", "replaced", "running", "ran", "skipped", "fail"]>;
    readonly message: Schema.optionalKey<Schema.String>;
    /**
     * The mode this node's provider was resolved for; absent for mode-agnostic
     * providers and for actions.
     */
    readonly providerMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
    /**
     * Set only on mode-switch replacements (local ⇄ live): the mode the OLD
     * generation was created with. Always differs from `providerMode`.
     */
    readonly fromProviderMode: Schema.optionalKey<Schema.Literals<readonly ["local", "live"]>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"state.bootstrap.started">;
    readonly store: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"state.bootstrap.completed">;
    readonly store: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"provider.configure.started">;
    readonly provider: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"provider.configure.completed">;
    readonly provider: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"provider.refresh.started">;
    readonly provider: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"provider.refresh.completed">;
    readonly provider: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.scan.started">;
    readonly total: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.scan.provider.started">;
    readonly provider: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.scan.provider.completed">;
    readonly provider: Schema.String;
    readonly resources: Schema.Number;
    readonly error: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.pass.started">;
    readonly pass: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.resource.deleted">;
    readonly provider: Schema.String;
    readonly resource: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"nuke.resource.failed">;
    readonly provider: Schema.String;
    readonly resource: Schema.String;
    readonly message: Schema.String;
}>]>;
export type Event = typeof Event.Type;
/**
 * First human-readable line of a lifecycle failure, for the per-resource
 * `fail` status event. The full cause is still aggregated and raised when
 * the whole run settles — this exists so a failed row explains itself the
 * moment it fails instead of only after every sibling has finished.
 * `undefined` for interrupt-only causes (nothing failed, the run was
 * cancelled).
 */
export declare const failureMessage: (cause: Cause.Cause<unknown>) => string | undefined;
/** Whether `type` names an event this version knows. */
export declare const isKnownEventType: (type: string) => boolean;
/**
 * Emit an event. Events are log records (annotated as events, at Info unless
 * they report a failure), so every logger sees them: the run log and
 * `--log-format json` carry them and renderers subscribe with
 * {@link onEvent}. The pretty console sink skips them, and telemetry does not
 * export them.
 */
export declare const emit: (event: Event) => Effect.Effect<void>;
/**
 * {@link emit} bound to the current loggers, for reporting from contexts
 * that may no longer carry them (provider callbacks, cached operations), so
 * the events still reach the caller's sinks and `onEvent` subscribers.
 */
export declare const captureEmit: Effect.Effect<(event: Event) => Effect.Effect<void>>;
/**
 * Observe the events `effect` emits. The handler runs (with the caller's
 * services) for each event in order, alongside the loggers already
 * installed, and every handler has finished before this returns.
 */
export declare const onEvent: <R = never>(handler: (event: Event) => Effect.Effect<void, never, R>) => <A, E, R2>(effect: Effect.Effect<A, E, R2>) => Effect.Effect<A, E, R | R2>;
//# sourceMappingURL=Events.d.ts.map