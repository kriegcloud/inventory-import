import type { RuntimeContext } from "alchemy/RuntimeContext";
import * as Context from "effect/Context";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Redacted from "effect/Redacted";
import { VaultError } from "./VaultError.ts";
/** A subject's new key: `key` encrypts, and `wrapped` is what a {@link KeyStore} keeps of it. */
export interface WrappedKey {
    /** The AES-256 key, as base64 text. It is never stored. */
    readonly key: string;
    /** The key as it is stored: encrypted under a root key, or as it is. */
    readonly wrapped: string;
}
declare const KeyWrap_base: Context.ServiceClass<KeyWrap, "alchemy/Domain/KeyWrap", {
    /** A new key for a subject, with the text to store for it. */
    readonly make: (subject: string) => Effect.Effect<WrappedKey, VaultError, RuntimeContext>;
    /** The key inside a stored text. It fails when the text was not wrapped for this subject. */
    readonly unwrap: (subject: string, wrapped: string) => Effect.Effect<string, VaultError, RuntimeContext>;
}>;
/**
 * Makes each subject's key, and turns it into the text a {@link KeyStore}
 * keeps. A wrap that encrypts under a root key leaves the store holding
 * nothing that opens a value on its own.
 */
export declare class KeyWrap extends KeyWrap_base {
}
/** @internal */
export declare const toBase64: (bytes: Uint8Array) => string;
/** @internal */
export declare const fromBase64: (text: string) => Uint8Array<ArrayBuffer>;
/** @internal */
export declare const failed: (subject: string, reason: string) => () => VaultError;
/** @internal */
export declare const importAes: (subject: string, key: Uint8Array<ArrayBuffer>) => Effect.Effect<CryptoKey, VaultError, never>;
/** Encrypt `plain` for `subject` under `key`: `<iv>.<ciphertext>`, bound to the subject. */
/** @internal */
export declare const encryptFor: (subject: string, key: CryptoKey, plain: Uint8Array<ArrayBuffer>) => Effect.Effect<string, VaultError, never>;
/** What {@link encryptFor} made, or `None` when `key` is not the one it was made under. */
/** @internal */
export declare const decryptFor: (subject: string, key: CryptoKey, iv: string, sealed: string) => Effect.Effect<Option.Option<Uint8Array<ArrayBuffer>>, never, never>;
/** A new AES-256 key, as base64 text. @internal */
export declare const newKey: Effect.Effect<string, never, never>;
/**
 * A {@link KeyWrap} that encrypts each subject's key with AES-256-GCM under
 * a root key read by `root`. The root key is any high-entropy secret, such as
 * 32 random bytes as text; it is read on each call, so a rotated secret is
 * picked up.
 *
 * @internal
 */
export declare const rootKeyWrap: <E>(root: Effect.Effect<Redacted.Redacted<string>, E, RuntimeContext>) => KeyWrap["Service"];
/** How a KMS key wrap keeps an intermediate key. See `DomainAWS.KmsKeyWrap`. */
export interface IntermediateKeyOptions {
    /**
     * How long a process keeps an intermediate key in memory: the one it wraps
     * new subject keys under, and each one it has unwrapped. A process whose
     * access to KMS is revoked can still read for this long.
     */
    readonly keep: Duration.Input;
}
/**
 * A {@link KeyWrap} that calls a key service once per intermediate key
 * rather than once per subject. A process makes an intermediate key, has the
 * service wrap it, and wraps each new subject key under it locally for
 * `keep`. What is stored for a subject carries the wrapped intermediate key,
 * so any process opens it with one call to the service, and keeps the
 * result for `keep`.
 *
 * @internal
 */
export declare const intermediateKeyWrap: (options: {
    readonly keep: Duration.Input;
    /** A new intermediate key (base64), and what the service wrapped it as (no `.` in it). */
    readonly make: (subject: string) => Effect.Effect<WrappedKey, VaultError>;
    /** The intermediate key (base64) inside what the service wrapped. */
    readonly unwrap: (subject: string, wrapped: string) => Effect.Effect<string, VaultError>;
    /** Unwrap a key stored before the intermediate key was turned on. */
    readonly direct: (subject: string, wrapped: string) => Effect.Effect<string, VaultError>;
}) => {
    readonly make: (subject: string) => Effect.Effect<WrappedKey, VaultError>;
    readonly unwrap: (subject: string, wrapped: string) => Effect.Effect<string, VaultError>;
};
/** Whether a stored key was wrapped under an intermediate key. @internal */
export declare const isIntermediate: (wrapped: string) => boolean;
export {};
//# sourceMappingURL=KeyWrap.d.ts.map