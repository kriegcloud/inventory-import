import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.TaggedErrorClass<"GoneException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ServiceFailureException_base: S.TaggedErrorClass<"ServiceFailureException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceFailureException extends /*@__PURE__*/ ServiceFailureException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottledClientException_base: S.TaggedErrorClass<"ThrottledClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottledClientException extends /*@__PURE__*/ ThrottledClientException_base {
}
declare const UnauthorizedClientException_base: S.TaggedErrorClass<"UnauthorizedClientException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedClientException extends /*@__PURE__*/ UnauthorizedClientException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export type VoiceConnectorId = string;
export type E164PhoneNumber = string | redacted.Redacted<string>;
export type E164PhoneNumberList = (string | redacted.Redacted<string>)[];
export interface AssociatePhoneNumbersWithVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean | undefined;
}
export type SensitiveNonEmptyString = string | redacted.Redacted<string>;
export type ErrorCode = "BadRequest" | "Conflict" | "Forbidden" | "NotFound" | "PreconditionFailed" | "ResourceLimitExceeded" | "ServiceFailure" | "AccessDenied" | "ServiceUnavailable" | "Throttled" | "Throttling" | "Unauthorized" | "Unprocessable" | "VoiceConnectorGroupAssociationsExist" | "PhoneNumberAssociationsExist" | "Gone" | "Validation" | (string & {});
export interface PhoneNumberError {
    PhoneNumberId?: string | redacted.Redacted<string> | undefined;
    ErrorCode?: ErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type PhoneNumberErrorList = PhoneNumberError[];
export interface AssociatePhoneNumbersWithVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export type NonEmptyString = string;
export interface AssociatePhoneNumbersWithVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    ForceAssociate?: boolean | undefined;
}
export interface AssociatePhoneNumbersWithVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export type NonEmptyStringList = string[];
export interface BatchDeletePhoneNumberRequest {
    PhoneNumberIds: string[];
}
export interface BatchDeletePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export type PhoneNumberProductType = "VoiceConnector" | "SipMediaApplicationDialIn" | (string & {});
export type CallingName = string | redacted.Redacted<string>;
export type PhoneNumberName = string | redacted.Redacted<string>;
export interface UpdatePhoneNumberRequestItem {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType | undefined;
    CallingName?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export type UpdatePhoneNumberRequestItemList = UpdatePhoneNumberRequestItem[];
export interface BatchUpdatePhoneNumberRequest {
    UpdatePhoneNumberRequestItems: UpdatePhoneNumberRequestItem[];
}
export interface BatchUpdatePhoneNumberResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export interface CreatePhoneNumberOrderRequest {
    ProductType: PhoneNumberProductType;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string> | undefined;
}
export type GuidString = string;
export type PhoneNumberOrderStatus = "Processing" | "Successful" | "Failed" | "Partial" | "PendingDocuments" | "Submitted" | "FOC" | "ChangeRequested" | "Exception" | "CancelRequested" | "Cancelled" | (string & {});
export type PhoneNumberOrderType = "New" | "Porting" | (string & {});
export type OrderedPhoneNumberStatus = "Processing" | "Acquired" | "Failed" | (string & {});
export interface OrderedPhoneNumber {
    E164PhoneNumber?: string | redacted.Redacted<string> | undefined;
    Status?: OrderedPhoneNumberStatus | undefined;
}
export type OrderedPhoneNumberList = OrderedPhoneNumber[];
export type Iso8601Timestamp = Date;
export interface PhoneNumberOrder {
    PhoneNumberOrderId?: string | undefined;
    ProductType?: PhoneNumberProductType | undefined;
    Status?: PhoneNumberOrderStatus | undefined;
    OrderType?: PhoneNumberOrderType | undefined;
    OrderedPhoneNumbers?: OrderedPhoneNumber[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    FocDate?: string | undefined;
}
export interface CreatePhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder | undefined;
}
export type ParticipantPhoneNumberList = (string | redacted.Redacted<string>)[];
export type ProxySessionNameString = string | redacted.Redacted<string>;
export type PositiveInteger = number;
export type Capability = "Voice" | "SMS" | (string & {});
export type CapabilityList = Capability[];
export type NumberSelectionBehavior = "PreferSticky" | "AvoidSticky" | (string & {});
export type GeoMatchLevel = "Country" | "AreaCode" | (string & {});
export type Country = string;
export type AreaCode = string;
export interface GeoMatchParams {
    Country: string;
    AreaCode: string;
}
export interface CreateProxySessionRequest {
    VoiceConnectorId: string;
    ParticipantPhoneNumbers: (string | redacted.Redacted<string>)[];
    Name?: string | redacted.Redacted<string> | undefined;
    ExpiryMinutes?: number | undefined;
    Capabilities: Capability[];
    NumberSelectionBehavior?: NumberSelectionBehavior | undefined;
    GeoMatchLevel?: GeoMatchLevel | undefined;
    GeoMatchParams?: GeoMatchParams | undefined;
}
export type NonEmptyString128 = string;
export type String128 = string;
export type ProxySessionStatus = "Open" | "InProgress" | "Closed" | (string & {});
export interface Participant {
    PhoneNumber?: string | redacted.Redacted<string> | undefined;
    ProxyPhoneNumber?: string | redacted.Redacted<string> | undefined;
}
export type Participants = Participant[];
export interface ProxySession {
    VoiceConnectorId?: string | undefined;
    ProxySessionId?: string | undefined;
    Name?: string | undefined;
    Status?: ProxySessionStatus | undefined;
    ExpiryMinutes?: number | undefined;
    Capabilities?: Capability[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    EndedTimestamp?: Date | undefined;
    Participants?: Participant[] | undefined;
    NumberSelectionBehavior?: NumberSelectionBehavior | undefined;
    GeoMatchLevel?: GeoMatchLevel | undefined;
    GeoMatchParams?: GeoMatchParams | undefined;
}
export interface CreateProxySessionResponse {
    ProxySession?: ProxySession | undefined;
}
export type SipMediaApplicationName = string;
export type FunctionArn = string | redacted.Redacted<string>;
export interface SipMediaApplicationEndpoint {
    LambdaArn?: string | redacted.Redacted<string> | undefined;
}
export type SipMediaApplicationEndpointList = SipMediaApplicationEndpoint[];
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateSipMediaApplicationRequest {
    AwsRegion: string;
    Name: string;
    Endpoints: SipMediaApplicationEndpoint[];
    Tags?: Tag[] | undefined;
}
export interface SipMediaApplication {
    SipMediaApplicationId?: string | undefined;
    AwsRegion?: string | undefined;
    Name?: string | undefined;
    Endpoints?: SipMediaApplicationEndpoint[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    SipMediaApplicationArn?: string | undefined;
}
export interface CreateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export type SipHeadersMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type SMACreateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface CreateSipMediaApplicationCallRequest {
    FromPhoneNumber: string | redacted.Redacted<string>;
    ToPhoneNumber: string | redacted.Redacted<string>;
    SipMediaApplicationId: string;
    SipHeaders?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    ArgumentsMap?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export interface SipMediaApplicationCall {
    TransactionId?: string | undefined;
}
export interface CreateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall | undefined;
}
export type SipRuleName = string;
export type SipRuleTriggerType = "ToPhoneNumber" | "RequestUriHostname" | (string & {});
export type SipApplicationPriority = number;
export interface SipRuleTargetApplication {
    SipMediaApplicationId?: string | undefined;
    Priority?: number | undefined;
    AwsRegion?: string | undefined;
}
export type SipRuleTargetApplicationList = SipRuleTargetApplication[];
export interface CreateSipRuleRequest {
    Name: string;
    TriggerType: SipRuleTriggerType;
    TriggerValue: string;
    Disabled?: boolean | undefined;
    TargetApplications: SipRuleTargetApplication[];
}
export interface SipRule {
    SipRuleId?: string | undefined;
    Name?: string | undefined;
    Disabled?: boolean | undefined;
    TriggerType?: SipRuleTriggerType | undefined;
    TriggerValue?: string | undefined;
    TargetApplications?: SipRuleTargetApplication[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateSipRuleResponse {
    SipRule?: SipRule | undefined;
}
export type VoiceConnectorName = string;
export type VoiceConnectorAwsRegion = "us-east-1" | "us-west-2" | "ca-central-1" | "eu-central-1" | "eu-west-1" | "eu-west-2" | "ap-northeast-2" | "ap-northeast-1" | "ap-southeast-1" | "ap-southeast-2" | (string & {});
export type VoiceConnectorIntegrationType = "CONNECT_CALL_TRANSFER_CONNECTOR" | "CONNECT_ANALYTICS_CONNECTOR" | (string & {});
export type NetworkType = "IPV4_ONLY" | "DUAL_STACK" | (string & {});
export interface CreateVoiceConnectorRequest {
    Name: string;
    AwsRegion?: VoiceConnectorAwsRegion | undefined;
    RequireEncryption: boolean;
    Tags?: Tag[] | undefined;
    IntegrationType?: VoiceConnectorIntegrationType | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface VoiceConnector {
    VoiceConnectorId?: string | undefined;
    AwsRegion?: VoiceConnectorAwsRegion | undefined;
    Name?: string | undefined;
    OutboundHostName?: string | undefined;
    RequireEncryption?: boolean | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    VoiceConnectorArn?: string | undefined;
    IntegrationType?: VoiceConnectorIntegrationType | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector | undefined;
}
export type VoiceConnectorGroupName = string;
export type VoiceConnectorItemPriority = number;
export interface VoiceConnectorItem {
    VoiceConnectorId: string;
    Priority?: number | undefined;
}
export type VoiceConnectorItemList = VoiceConnectorItem[];
export type CallDistributionType = "PriorityWeightedDistribution" | "LoadBalancedDistribution" | (string & {});
export interface CreateVoiceConnectorGroupRequest {
    Name: string;
    VoiceConnectorItems?: VoiceConnectorItem[] | undefined;
    CallDistributionType?: CallDistributionType | undefined;
}
export interface VoiceConnectorGroup {
    VoiceConnectorGroupId?: string | undefined;
    Name?: string | undefined;
    VoiceConnectorItems?: VoiceConnectorItem[] | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    VoiceConnectorGroupArn?: string | undefined;
    CallDistributionType?: CallDistributionType | undefined;
}
export interface CreateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup | undefined;
}
export type NonEmptyString256 = string;
export interface CreateVoiceProfileRequest {
    SpeakerSearchTaskId: string;
}
export type Arn = string | redacted.Redacted<string>;
export interface VoiceProfile {
    VoiceProfileId?: string | undefined;
    VoiceProfileArn?: string | redacted.Redacted<string> | undefined;
    VoiceProfileDomainId?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    ExpirationTimestamp?: Date | undefined;
}
export interface CreateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile | undefined;
}
export type VoiceProfileDomainName = string;
export type VoiceProfileDomainDescription = string;
export interface ServerSideEncryptionConfiguration {
    KmsKeyArn: string | redacted.Redacted<string>;
}
export type ClientRequestId = string;
export interface CreateVoiceProfileDomainRequest {
    Name: string;
    Description?: string | undefined;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface VoiceProfileDomain {
    VoiceProfileDomainId?: string | undefined;
    VoiceProfileDomainArn?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export interface CreateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain | undefined;
}
export interface DeletePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export interface DeletePhoneNumberResponse {
}
export interface DeleteProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export interface DeleteProxySessionResponse {
}
export interface DeleteSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export interface DeleteSipMediaApplicationResponse {
}
export interface DeleteSipRuleRequest {
    SipRuleId: string;
}
export interface DeleteSipRuleResponse {
}
export interface DeleteVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorResponse {
}
export interface DeleteVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorEmergencyCallingConfigurationResponse {
}
export interface DeleteVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorExternalSystemsConfigurationResponse {
}
export interface DeleteVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export interface DeleteVoiceConnectorGroupResponse {
}
export interface DeleteVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorOriginationResponse {
}
export interface DeleteVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorProxyResponse {
}
export interface DeleteVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorStreamingConfigurationResponse {
}
export interface DeleteVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export interface DeleteVoiceConnectorTerminationResponse {
}
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export interface DeleteVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Usernames: (string | redacted.Redacted<string>)[];
}
export interface DeleteVoiceConnectorTerminationCredentialsResponse {
}
export interface DeleteVoiceProfileRequest {
    VoiceProfileId: string;
}
export interface DeleteVoiceProfileResponse {
}
export interface DeleteVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export interface DeleteVoiceProfileDomainResponse {
}
export interface DisassociatePhoneNumbersFromVoiceConnectorRequest {
    VoiceConnectorId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export interface DisassociatePhoneNumbersFromVoiceConnectorResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    E164PhoneNumbers: (string | redacted.Redacted<string>)[];
}
export interface DisassociatePhoneNumbersFromVoiceConnectorGroupResponse {
    PhoneNumberErrors?: PhoneNumberError[] | undefined;
}
export interface GetGlobalSettingsRequest {
}
export type S3BucketName = string;
export interface VoiceConnectorSettings {
    CdrBucket?: string | undefined;
}
export interface GetGlobalSettingsResponse {
    VoiceConnector?: VoiceConnectorSettings | undefined;
}
export interface GetPhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export type Alpha2CountryCode = string;
export type PhoneNumberType = "Local" | "TollFree" | (string & {});
export type PhoneNumberStatus = "Cancelled" | "PortinCancelRequested" | "PortinInProgress" | "AcquireInProgress" | "AcquireFailed" | "Unassigned" | "Assigned" | "ReleaseInProgress" | "DeleteInProgress" | "ReleaseFailed" | "DeleteFailed" | (string & {});
export interface PhoneNumberCapabilities {
    InboundCall?: boolean | undefined;
    OutboundCall?: boolean | undefined;
    InboundSMS?: boolean | undefined;
    OutboundSMS?: boolean | undefined;
    InboundMMS?: boolean | undefined;
    OutboundMMS?: boolean | undefined;
}
export type PhoneNumberAssociationName = "VoiceConnectorId" | "VoiceConnectorGroupId" | "SipRuleId" | (string & {});
export interface PhoneNumberAssociation {
    Value?: string | undefined;
    Name?: PhoneNumberAssociationName | undefined;
    AssociatedTimestamp?: Date | undefined;
}
export type PhoneNumberAssociationList = PhoneNumberAssociation[];
export type CallingNameStatus = "Unassigned" | "UpdateInProgress" | "UpdateSucceeded" | "UpdateFailed" | (string & {});
export interface PhoneNumber {
    PhoneNumberId?: string | redacted.Redacted<string> | undefined;
    E164PhoneNumber?: string | redacted.Redacted<string> | undefined;
    PhoneNumberArn?: string | undefined;
    Country?: string | undefined;
    Type?: PhoneNumberType | undefined;
    ProductType?: PhoneNumberProductType | undefined;
    Status?: PhoneNumberStatus | undefined;
    Capabilities?: PhoneNumberCapabilities | undefined;
    Associations?: PhoneNumberAssociation[] | undefined;
    CallingName?: string | redacted.Redacted<string> | undefined;
    CallingNameStatus?: CallingNameStatus | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    DeletionTimestamp?: Date | undefined;
    OrderId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export interface GetPhoneNumberResponse {
    PhoneNumber?: PhoneNumber | undefined;
}
export interface GetPhoneNumberOrderRequest {
    PhoneNumberOrderId: string;
}
export interface GetPhoneNumberOrderResponse {
    PhoneNumberOrder?: PhoneNumberOrder | undefined;
}
export interface GetPhoneNumberSettingsRequest {
}
export interface GetPhoneNumberSettingsResponse {
    CallingName?: string | redacted.Redacted<string> | undefined;
    CallingNameUpdatedTimestamp?: Date | undefined;
}
export interface GetProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
}
export interface GetProxySessionResponse {
    ProxySession?: ProxySession | undefined;
}
export interface GetSipMediaApplicationRequest {
    SipMediaApplicationId: string;
}
export interface GetSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication | undefined;
}
export interface GetSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
}
export type AlexaSkillStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type AlexaSkillId = string | redacted.Redacted<string>;
export type AlexaSkillIdList = (string | redacted.Redacted<string>)[];
export interface SipMediaApplicationAlexaSkillConfiguration {
    AlexaSkillStatus: AlexaSkillStatus;
    AlexaSkillIds: (string | redacted.Redacted<string>)[];
}
export interface GetSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration | undefined;
}
export interface GetSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
}
export interface SipMediaApplicationLoggingConfiguration {
    EnableSipMediaApplicationMessageLogs?: boolean | undefined;
}
export interface GetSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration | undefined;
}
export interface GetSipRuleRequest {
    SipRuleId: string;
}
export interface GetSipRuleResponse {
    SipRule?: SipRule | undefined;
}
export interface GetSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export interface CallDetails {
    VoiceConnectorId?: string | undefined;
    TransactionId?: string | undefined;
    IsCaller?: boolean | undefined;
}
export type ConfidenceScore = number;
export interface SpeakerSearchResult {
    ConfidenceScore?: number | undefined;
    VoiceProfileId?: string | undefined;
}
export type SpeakerSearchResultList = SpeakerSearchResult[];
export interface SpeakerSearchDetails {
    Results?: SpeakerSearchResult[] | undefined;
    VoiceprintGenerationStatus?: string | undefined;
}
export interface SpeakerSearchTask {
    SpeakerSearchTaskId?: string | undefined;
    SpeakerSearchTaskStatus?: string | undefined;
    CallDetails?: CallDetails | undefined;
    SpeakerSearchDetails?: SpeakerSearchDetails | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    StartedTimestamp?: Date | undefined;
    StatusMessage?: string | undefined;
}
export interface GetSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask | undefined;
}
export interface GetVoiceConnectorRequest {
    VoiceConnectorId: string;
}
export interface GetVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector | undefined;
}
export interface GetVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface DNISEmergencyCallingConfiguration {
    EmergencyPhoneNumber: string | redacted.Redacted<string>;
    TestPhoneNumber?: string | redacted.Redacted<string> | undefined;
    CallingCountry: string;
}
export type DNISEmergencyCallingConfigurationList = DNISEmergencyCallingConfiguration[];
export interface EmergencyCallingConfiguration {
    DNIS?: DNISEmergencyCallingConfiguration[] | undefined;
}
export interface GetVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration | undefined;
}
export interface GetVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
}
export type SessionBorderControllerType = "RIBBON_SBC" | "ORACLE_ACME_PACKET_SBC" | "AVAYA_SBCE" | "CISCO_UNIFIED_BORDER_ELEMENT" | "AUDIOCODES_MEDIANT_SBC" | (string & {});
export type SessionBorderControllerTypeList = SessionBorderControllerType[];
export type ContactCenterSystemType = "GENESYS_ENGAGE_ON_PREMISES" | "AVAYA_AURA_CALL_CENTER_ELITE" | "AVAYA_AURA_CONTACT_CENTER" | "CISCO_UNIFIED_CONTACT_CENTER_ENTERPRISE" | (string & {});
export type ContactCenterSystemTypeList = ContactCenterSystemType[];
export interface ExternalSystemsConfiguration {
    SessionBorderControllerTypes?: SessionBorderControllerType[] | undefined;
    ContactCenterSystemTypes?: ContactCenterSystemType[] | undefined;
}
export interface GetVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration | undefined;
}
export interface GetVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
}
export interface GetVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup | undefined;
}
export interface GetVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
}
export interface LoggingConfiguration {
    EnableSIPLogs?: boolean | undefined;
    EnableMediaMetricLogs?: boolean | undefined;
}
export interface GetVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration | undefined;
}
export interface GetVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
}
export type Port = number;
export type OriginationRouteProtocol = "TCP" | "UDP" | (string & {});
export type OriginationRoutePriority = number;
export type OriginationRouteWeight = number;
export interface OriginationRoute {
    Host?: string | undefined;
    Port?: number | undefined;
    Protocol?: OriginationRouteProtocol | undefined;
    Priority?: number | undefined;
    Weight?: number | undefined;
}
export type OriginationRouteList = OriginationRoute[];
export interface Origination {
    Routes?: OriginationRoute[] | undefined;
    Disabled?: boolean | undefined;
}
export interface GetVoiceConnectorOriginationResponse {
    Origination?: Origination | undefined;
}
export interface GetVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
}
export type StringList = string[];
export interface Proxy {
    DefaultSessionExpiryMinutes?: number | undefined;
    Disabled?: boolean | undefined;
    FallBackPhoneNumber?: string | redacted.Redacted<string> | undefined;
    PhoneNumberCountries?: string[] | undefined;
}
export interface GetVoiceConnectorProxyResponse {
    Proxy?: Proxy | undefined;
}
export interface GetVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
}
export type DataRetentionInHours = number;
export type NotificationTarget = "EventBridge" | "SNS" | "SQS" | (string & {});
export interface StreamingNotificationTarget {
    NotificationTarget?: NotificationTarget | undefined;
}
export type StreamingNotificationTargetList = StreamingNotificationTarget[];
export interface MediaInsightsConfiguration {
    Disabled?: boolean | undefined;
    ConfigurationArn?: string | redacted.Redacted<string> | undefined;
}
export interface StreamingConfiguration {
    DataRetentionInHours: number;
    Disabled: boolean;
    StreamingNotificationTargets?: StreamingNotificationTarget[] | undefined;
    MediaInsightsConfiguration?: MediaInsightsConfiguration | undefined;
}
export interface GetVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration | undefined;
}
export interface GetVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
}
export type CpsLimit = number;
export type CallingRegion = string;
export type CallingRegionList = string[];
export interface Termination {
    CpsLimit?: number | undefined;
    DefaultPhoneNumber?: string | redacted.Redacted<string> | undefined;
    CallingRegions?: string[] | undefined;
    CidrAllowedList?: string[] | undefined;
    Disabled?: boolean | undefined;
}
export interface GetVoiceConnectorTerminationResponse {
    Termination?: Termination | undefined;
}
export interface GetVoiceConnectorTerminationHealthRequest {
    VoiceConnectorId: string;
}
export interface TerminationHealth {
    Timestamp?: Date | undefined;
    Source?: string | undefined;
}
export interface GetVoiceConnectorTerminationHealthResponse {
    TerminationHealth?: TerminationHealth | undefined;
}
export interface GetVoiceProfileRequest {
    VoiceProfileId: string;
}
export interface GetVoiceProfileResponse {
    VoiceProfile?: VoiceProfile | undefined;
}
export interface GetVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
}
export interface GetVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain | undefined;
}
export interface GetVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
    IsCaller: boolean;
}
export interface VoiceToneAnalysisTask {
    VoiceToneAnalysisTaskId?: string | undefined;
    VoiceToneAnalysisTaskStatus?: string | undefined;
    CallDetails?: CallDetails | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    StartedTimestamp?: Date | undefined;
    StatusMessage?: string | undefined;
}
export interface GetVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask | undefined;
}
export interface ListAvailableVoiceConnectorRegionsRequest {
}
export type VoiceConnectorAwsRegionList = VoiceConnectorAwsRegion[];
export interface ListAvailableVoiceConnectorRegionsResponse {
    VoiceConnectorRegions?: VoiceConnectorAwsRegion[] | undefined;
}
export type NextTokenString = string;
export type ResultMax = number;
export interface ListPhoneNumberOrdersRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PhoneNumberOrderList = PhoneNumberOrder[];
export interface ListPhoneNumberOrdersResponse {
    PhoneNumberOrders?: PhoneNumberOrder[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPhoneNumbersRequest {
    Status?: string | undefined;
    ProductType?: PhoneNumberProductType | undefined;
    FilterName?: PhoneNumberAssociationName | undefined;
    FilterValue?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PhoneNumberList = PhoneNumber[];
export interface ListPhoneNumbersResponse {
    PhoneNumbers?: PhoneNumber[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProxySessionsRequest {
    VoiceConnectorId: string;
    Status?: ProxySessionStatus | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ProxySessions = ProxySession[];
export interface ListProxySessionsResponse {
    ProxySessions?: ProxySession[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSipMediaApplicationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SipMediaApplicationList = SipMediaApplication[];
export interface ListSipMediaApplicationsResponse {
    SipMediaApplications?: SipMediaApplication[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSipRulesRequest {
    SipMediaApplicationId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SipRuleList = SipRule[];
export interface ListSipRulesResponse {
    SipRules?: SipRule[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSupportedPhoneNumberCountriesRequest {
    ProductType: PhoneNumberProductType;
}
export type PhoneNumberTypeList = PhoneNumberType[];
export interface PhoneNumberCountry {
    CountryCode?: string | undefined;
    SupportedPhoneNumberTypes?: PhoneNumberType[] | undefined;
}
export type PhoneNumberCountriesList = PhoneNumberCountry[];
export interface ListSupportedPhoneNumberCountriesResponse {
    PhoneNumberCountries?: PhoneNumberCountry[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListVoiceConnectorGroupsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type VoiceConnectorGroupList = VoiceConnectorGroup[];
export interface ListVoiceConnectorGroupsResponse {
    VoiceConnectorGroups?: VoiceConnectorGroup[] | undefined;
    NextToken?: string | undefined;
}
export interface ListVoiceConnectorsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type VoiceConnectorList = VoiceConnector[];
export interface ListVoiceConnectorsResponse {
    VoiceConnectors?: VoiceConnector[] | undefined;
    NextToken?: string | undefined;
}
export interface ListVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
}
export interface ListVoiceConnectorTerminationCredentialsResponse {
    Usernames?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface ListVoiceProfileDomainsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface VoiceProfileDomainSummary {
    VoiceProfileDomainId?: string | undefined;
    VoiceProfileDomainArn?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
}
export type VoiceProfileDomainSummaryList = VoiceProfileDomainSummary[];
export interface ListVoiceProfileDomainsResponse {
    VoiceProfileDomains?: VoiceProfileDomainSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListVoiceProfilesRequest {
    VoiceProfileDomainId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface VoiceProfileSummary {
    VoiceProfileId?: string | undefined;
    VoiceProfileArn?: string | redacted.Redacted<string> | undefined;
    VoiceProfileDomainId?: string | undefined;
    CreatedTimestamp?: Date | undefined;
    UpdatedTimestamp?: Date | undefined;
    ExpirationTimestamp?: Date | undefined;
}
export type VoiceProfileSummaryList = VoiceProfileSummary[];
export interface ListVoiceProfilesResponse {
    VoiceProfiles?: VoiceProfileSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface PutSipMediaApplicationAlexaSkillConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration | undefined;
}
export interface PutSipMediaApplicationAlexaSkillConfigurationResponse {
    SipMediaApplicationAlexaSkillConfiguration?: SipMediaApplicationAlexaSkillConfiguration | undefined;
}
export interface PutSipMediaApplicationLoggingConfigurationRequest {
    SipMediaApplicationId: string;
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration | undefined;
}
export interface PutSipMediaApplicationLoggingConfigurationResponse {
    SipMediaApplicationLoggingConfiguration?: SipMediaApplicationLoggingConfiguration | undefined;
}
export interface PutVoiceConnectorEmergencyCallingConfigurationRequest {
    VoiceConnectorId: string;
    EmergencyCallingConfiguration: EmergencyCallingConfiguration;
}
export interface PutVoiceConnectorEmergencyCallingConfigurationResponse {
    EmergencyCallingConfiguration?: EmergencyCallingConfiguration | undefined;
}
export interface PutVoiceConnectorExternalSystemsConfigurationRequest {
    VoiceConnectorId: string;
    SessionBorderControllerTypes?: SessionBorderControllerType[] | undefined;
    ContactCenterSystemTypes?: ContactCenterSystemType[] | undefined;
}
export interface PutVoiceConnectorExternalSystemsConfigurationResponse {
    ExternalSystemsConfiguration?: ExternalSystemsConfiguration | undefined;
}
export interface PutVoiceConnectorLoggingConfigurationRequest {
    VoiceConnectorId: string;
    LoggingConfiguration: LoggingConfiguration;
}
export interface PutVoiceConnectorLoggingConfigurationResponse {
    LoggingConfiguration?: LoggingConfiguration | undefined;
}
export interface PutVoiceConnectorOriginationRequest {
    VoiceConnectorId: string;
    Origination: Origination;
}
export interface PutVoiceConnectorOriginationResponse {
    Origination?: Origination | undefined;
}
export type CountryList = string[];
export interface PutVoiceConnectorProxyRequest {
    VoiceConnectorId: string;
    DefaultSessionExpiryMinutes: number;
    PhoneNumberPoolCountries: string[];
    FallBackPhoneNumber?: string | redacted.Redacted<string> | undefined;
    Disabled?: boolean | undefined;
}
export interface PutVoiceConnectorProxyResponse {
    Proxy?: Proxy | undefined;
}
export interface PutVoiceConnectorStreamingConfigurationRequest {
    VoiceConnectorId: string;
    StreamingConfiguration: StreamingConfiguration;
}
export interface PutVoiceConnectorStreamingConfigurationResponse {
    StreamingConfiguration?: StreamingConfiguration | undefined;
}
export interface PutVoiceConnectorTerminationRequest {
    VoiceConnectorId: string;
    Termination: Termination;
}
export interface PutVoiceConnectorTerminationResponse {
    Termination?: Termination | undefined;
}
export interface Credential {
    Username?: string | redacted.Redacted<string> | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export type CredentialList = Credential[];
export interface PutVoiceConnectorTerminationCredentialsRequest {
    VoiceConnectorId: string;
    Credentials?: Credential[] | undefined;
}
export interface PutVoiceConnectorTerminationCredentialsResponse {
}
export interface RestorePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
}
export interface RestorePhoneNumberResponse {
    PhoneNumber?: PhoneNumber | undefined;
}
export type TollFreePrefix = string;
export type PhoneNumberMaxResults = number;
export interface SearchAvailablePhoneNumbersRequest {
    AreaCode?: string | undefined;
    City?: string | undefined;
    Country?: string | undefined;
    State?: string | undefined;
    TollFreePrefix?: string | undefined;
    PhoneNumberType?: PhoneNumberType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SearchAvailablePhoneNumbersResponse {
    E164PhoneNumbers?: (string | redacted.Redacted<string>)[] | undefined;
    NextToken?: string | undefined;
}
export type CallLegType = "Caller" | "Callee" | (string & {});
export interface StartSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    VoiceProfileDomainId: string;
    ClientRequestToken?: string | undefined;
    CallLeg?: CallLegType | undefined;
}
export interface StartSpeakerSearchTaskResponse {
    SpeakerSearchTask?: SpeakerSearchTask | undefined;
}
export type LanguageCode = "en-US" | (string & {});
export interface StartVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    TransactionId: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string | undefined;
}
export interface StartVoiceToneAnalysisTaskResponse {
    VoiceToneAnalysisTask?: VoiceToneAnalysisTask | undefined;
}
export interface StopSpeakerSearchTaskRequest {
    VoiceConnectorId: string;
    SpeakerSearchTaskId: string;
}
export interface StopSpeakerSearchTaskResponse {
}
export interface StopVoiceToneAnalysisTaskRequest {
    VoiceConnectorId: string;
    VoiceToneAnalysisTaskId: string;
}
export interface StopVoiceToneAnalysisTaskResponse {
}
export interface TagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceARN: string | redacted.Redacted<string>;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateGlobalSettingsRequest {
    VoiceConnector: VoiceConnectorSettings;
}
export interface UpdateGlobalSettingsResponse {
}
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string | redacted.Redacted<string>;
    ProductType?: PhoneNumberProductType | undefined;
    CallingName?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export interface UpdatePhoneNumberResponse {
    PhoneNumber?: PhoneNumber | undefined;
}
export interface UpdatePhoneNumberSettingsRequest {
    CallingName: string | redacted.Redacted<string>;
}
export interface UpdatePhoneNumberSettingsResponse {
}
export interface UpdateProxySessionRequest {
    VoiceConnectorId: string;
    ProxySessionId: string;
    Capabilities: Capability[];
    ExpiryMinutes?: number | undefined;
}
export interface UpdateProxySessionResponse {
    ProxySession?: ProxySession | undefined;
}
export interface UpdateSipMediaApplicationRequest {
    SipMediaApplicationId: string;
    Name?: string | undefined;
    Endpoints?: SipMediaApplicationEndpoint[] | undefined;
}
export interface UpdateSipMediaApplicationResponse {
    SipMediaApplication?: SipMediaApplication | undefined;
}
export type SMAUpdateCallArgumentsMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface UpdateSipMediaApplicationCallRequest {
    SipMediaApplicationId: string;
    TransactionId: string;
    Arguments: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export interface UpdateSipMediaApplicationCallResponse {
    SipMediaApplicationCall?: SipMediaApplicationCall | undefined;
}
export interface UpdateSipRuleRequest {
    SipRuleId: string;
    Name: string;
    Disabled?: boolean | undefined;
    TargetApplications?: SipRuleTargetApplication[] | undefined;
}
export interface UpdateSipRuleResponse {
    SipRule?: SipRule | undefined;
}
export interface UpdateVoiceConnectorRequest {
    VoiceConnectorId: string;
    Name: string;
    RequireEncryption: boolean;
}
export interface UpdateVoiceConnectorResponse {
    VoiceConnector?: VoiceConnector | undefined;
}
export interface UpdateVoiceConnectorGroupRequest {
    VoiceConnectorGroupId: string;
    Name: string;
    VoiceConnectorItems: VoiceConnectorItem[];
    CallDistributionType?: CallDistributionType | undefined;
}
export interface UpdateVoiceConnectorGroupResponse {
    VoiceConnectorGroup?: VoiceConnectorGroup | undefined;
}
export interface UpdateVoiceProfileRequest {
    VoiceProfileId: string;
    SpeakerSearchTaskId: string;
}
export interface UpdateVoiceProfileResponse {
    VoiceProfile?: VoiceProfile | undefined;
}
export interface UpdateVoiceProfileDomainRequest {
    VoiceProfileDomainId: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateVoiceProfileDomainResponse {
    VoiceProfileDomain?: VoiceProfileDomain | undefined;
}
export interface ValidateE911AddressRequest {
    AwsAccountId: string;
    StreetNumber: string | redacted.Redacted<string>;
    StreetInfo: string | redacted.Redacted<string>;
    City: string | redacted.Redacted<string>;
    State: string | redacted.Redacted<string>;
    Country: string | redacted.Redacted<string>;
    PostalCode: string | redacted.Redacted<string>;
}
export type ValidationResult = number;
export interface Address {
    streetName?: string | redacted.Redacted<string> | undefined;
    streetSuffix?: string | redacted.Redacted<string> | undefined;
    postDirectional?: string | redacted.Redacted<string> | undefined;
    preDirectional?: string | redacted.Redacted<string> | undefined;
    streetNumber?: string | redacted.Redacted<string> | undefined;
    city?: string | redacted.Redacted<string> | undefined;
    state?: string | redacted.Redacted<string> | undefined;
    postalCode?: string | redacted.Redacted<string> | undefined;
    postalCodePlus4?: string | redacted.Redacted<string> | undefined;
    country?: string | redacted.Redacted<string> | undefined;
}
export interface CandidateAddress {
    streetInfo?: string | redacted.Redacted<string> | undefined;
    streetNumber?: string | redacted.Redacted<string> | undefined;
    city?: string | redacted.Redacted<string> | undefined;
    state?: string | redacted.Redacted<string> | undefined;
    postalCode?: string | redacted.Redacted<string> | undefined;
    postalCodePlus4?: string | redacted.Redacted<string> | undefined;
    country?: string | redacted.Redacted<string> | undefined;
}
export type CandidateAddressList = CandidateAddress[];
export interface ValidateE911AddressResponse {
    ValidationResult?: number | undefined;
    AddressExternalId?: string | undefined;
    Address?: Address | undefined;
    CandidateAddressList?: CandidateAddress[] | undefined;
}
export type AssociatePhoneNumbersWithVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector.
 */
export declare const associatePhoneNumbersWithVoiceConnector: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorRequest & RegionInput, AssociatePhoneNumbersWithVoiceConnectorResponse, AssociatePhoneNumbersWithVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type AssociatePhoneNumbersWithVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Associates phone numbers with the specified Amazon Chime SDK Voice Connector group.
 */
export declare const associatePhoneNumbersWithVoiceConnectorGroup: API.OperationMethod<AssociatePhoneNumbersWithVoiceConnectorGroupRequest & RegionInput, AssociatePhoneNumbersWithVoiceConnectorGroupResponse, AssociatePhoneNumbersWithVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves phone numbers into the
 * **Deletion queue**. Phone numbers must be disassociated from any users or Amazon Chime SDK Voice Connectors before they can be deleted.
 *
 * Phone numbers remain in the
 * **Deletion queue** for 7 days before they are deleted permanently.
 */
export declare const batchDeletePhoneNumber: API.OperationMethod<BatchDeletePhoneNumberRequest & RegionInput, BatchDeletePhoneNumberResponse, BatchDeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number product types, calling names, or phone number names. You can update one attribute at a time for each
 * `UpdatePhoneNumberRequestItem`. For example, you can update the product type, the calling name, or phone name.
 *
 * You cannot have a duplicate `phoneNumberId` in a request.
 */
export declare const batchUpdatePhoneNumber: API.OperationMethod<BatchUpdatePhoneNumberRequest & RegionInput, BatchUpdatePhoneNumberResponse, BatchUpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type CreatePhoneNumberOrderError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an order for phone numbers to be provisioned. For numbers outside the U.S., you must use the Amazon Chime SDK SIP media application dial-in product type.
 */
export declare const createPhoneNumberOrder: API.OperationMethod<CreatePhoneNumberOrderRequest & RegionInput, CreatePhoneNumberOrderResponse, CreatePhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type CreateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a proxy session for the specified Amazon Chime SDK Voice Connector for
 * the specified participant phone numbers.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const createProxySession: API.OperationMethod<CreateProxySessionRequest & RegionInput, CreateProxySessionResponse, CreateProxySessionError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP media application. For more information about SIP media applications, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipMediaApplication: API.OperationMethod<CreateSipMediaApplicationRequest & RegionInput, CreateSipMediaApplicationResponse, CreateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateSipMediaApplicationCallError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an outbound call to a phone number from the phone number specified
 * in the request, and it invokes the endpoint of the specified
 * `sipMediaApplicationId`.
 */
export declare const createSipMediaApplicationCall: API.OperationMethod<CreateSipMediaApplicationCallRequest & RegionInput, CreateSipMediaApplicationCallResponse, CreateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type CreateSipRuleError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a SIP rule, which can be used to run a SIP media application as a target for a specific trigger type. For more information about SIP rules, see Managing SIP media applications
 * and rules in the *Amazon Chime SDK Administrator Guide*.
 */
export declare const createSipRule: API.OperationMethod<CreateSipRuleRequest & RegionInput, CreateSipRuleResponse, CreateSipRuleError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorError = AccessDeniedException | BadRequestException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector. For more information about
 * Voice Connectors,
 * see Managing Amazon Chime SDK Voice Connector groups in the Amazon Chime SDK
 * Administrator Guide.
 */
export declare const createVoiceConnector: API.OperationMethod<CreateVoiceConnectorRequest & RegionInput, CreateVoiceConnectorResponse, CreateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceConnectorGroupError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates an Amazon Chime SDK Voice Connector group under the administrator's
 * AWS account. You can associate Amazon Chime SDK Voice Connectors with the
 * Voice Connector group by including `VoiceConnectorItems` in the
 * request.
 *
 * You can include Voice Connectors from different AWS Regions in your group.
 * This creates a fault tolerant mechanism for fallback in case of availability events.
 */
export declare const createVoiceConnectorGroup: API.OperationMethod<CreateVoiceConnectorGroupRequest & RegionInput, CreateVoiceConnectorGroupResponse, CreateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile, which consists of an enrolled user and their latest voice print.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profiles and voice analytics, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfile: API.OperationMethod<CreateVoiceProfileRequest & RegionInput, CreateVoiceProfileResponse, CreateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Creates a voice profile domain, a collection of voice profiles, their voice prints, and encrypted enrollment audio.
 *
 * Before creating any voice profiles, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 *
 * For more information about voice profile domains, see Using Amazon Chime SDK Voice Analytics
 * in the *Amazon Chime SDK Developer Guide*.
 */
export declare const createVoiceProfileDomain: API.OperationMethod<CreateVoiceProfileDomainRequest & RegionInput, CreateVoiceProfileDomainResponse, CreateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DeletePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Moves the specified phone number into the
 * **Deletion queue**. A phone number must
 * be disassociated from any users or Amazon Chime SDK Voice Connectors before it can be
 * deleted.
 *
 * Deleted phone numbers remain in the
 * **Deletion queue** queue for 7 days before
 * they are deleted permanently.
 */
export declare const deletePhoneNumber: API.OperationMethod<DeletePhoneNumberRequest & RegionInput, DeletePhoneNumberResponse, DeletePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type DeleteProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified proxy session from the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteProxySession: API.OperationMethod<DeleteProxySessionRequest & RegionInput, DeleteProxySessionResponse, DeleteProxySessionError, Credentials | HttpClient.HttpClient>;
export type DeleteSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP media application.
 */
export declare const deleteSipMediaApplication: API.OperationMethod<DeleteSipMediaApplicationRequest & RegionInput, DeleteSipMediaApplicationResponse, DeleteSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a SIP rule.
 */
export declare const deleteSipRule: API.OperationMethod<DeleteSipRuleRequest & RegionInput, DeleteSipRuleResponse, DeleteSipRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector. Any phone numbers associated
 * with the Amazon Chime SDK Voice Connector must be disassociated from it before it
 * can be deleted.
 */
export declare const deleteVoiceConnector: API.OperationMethod<DeleteVoiceConnectorRequest & RegionInput, DeleteVoiceConnectorResponse, DeleteVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the emergency calling details from the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const deleteVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<DeleteVoiceConnectorEmergencyCallingConfigurationRequest & RegionInput, DeleteVoiceConnectorEmergencyCallingConfigurationResponse, DeleteVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the external systems configuration for a Voice Connector.
 */
export declare const deleteVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<DeleteVoiceConnectorExternalSystemsConfigurationRequest & RegionInput, DeleteVoiceConnectorExternalSystemsConfigurationResponse, DeleteVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes an Amazon Chime SDK Voice Connector group. Any `VoiceConnectorItems`
 * and phone numbers associated with the group must be removed before it can be
 * deleted.
 */
export declare const deleteVoiceConnectorGroup: API.OperationMethod<DeleteVoiceConnectorGroupRequest & RegionInput, DeleteVoiceConnectorGroupResponse, DeleteVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the origination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the origination settings.
 */
export declare const deleteVoiceConnectorOrigination: API.OperationMethod<DeleteVoiceConnectorOriginationRequest & RegionInput, DeleteVoiceConnectorOriginationResponse, DeleteVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the proxy configuration from the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const deleteVoiceConnectorProxy: API.OperationMethod<DeleteVoiceConnectorProxyRequest & RegionInput, DeleteVoiceConnectorProxyResponse, DeleteVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a Voice Connector's streaming configuration.
 */
export declare const deleteVoiceConnectorStreamingConfiguration: API.OperationMethod<DeleteVoiceConnectorStreamingConfigurationRequest & RegionInput, DeleteVoiceConnectorStreamingConfigurationResponse, DeleteVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the termination settings for the specified Amazon Chime SDK Voice Connector.
 *
 * If emergency calling is configured for the Voice Connector, it must be
 * deleted prior to deleting the termination settings.
 */
export declare const deleteVoiceConnectorTermination: API.OperationMethod<DeleteVoiceConnectorTerminationRequest & RegionInput, DeleteVoiceConnectorTerminationResponse, DeleteVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes the specified SIP credentials used by your equipment to
 * authenticate during call termination.
 */
export declare const deleteVoiceConnectorTerminationCredentials: API.OperationMethod<DeleteVoiceConnectorTerminationCredentialsRequest & RegionInput, DeleteVoiceConnectorTerminationCredentialsResponse, DeleteVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes a voice profile, including its voice print and enrollment data. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfile: API.OperationMethod<DeleteVoiceProfileRequest & RegionInput, DeleteVoiceProfileResponse, DeleteVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteVoiceProfileDomainError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Deletes all voice profiles in the domain. WARNING: This action is not reversible.
 */
export declare const deleteVoiceProfileDomain: API.OperationMethod<DeleteVoiceProfileDomainRequest & RegionInput, DeleteVoiceProfileDomainResponse, DeleteVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified
 * Amazon Chime SDK Voice Connector.
 */
export declare const disassociatePhoneNumbersFromVoiceConnector: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorRequest & RegionInput, DisassociatePhoneNumbersFromVoiceConnectorResponse, DisassociatePhoneNumbersFromVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type DisassociatePhoneNumbersFromVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Disassociates the specified phone numbers from the specified Amazon Chime SDK Voice
 * Connector group.
 */
export declare const disassociatePhoneNumbersFromVoiceConnectorGroup: API.OperationMethod<DisassociatePhoneNumbersFromVoiceConnectorGroupRequest & RegionInput, DisassociatePhoneNumbersFromVoiceConnectorGroupResponse, DisassociatePhoneNumbersFromVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const getGlobalSettings: API.OperationMethod<GetGlobalSettingsRequest & RegionInput, GetGlobalSettingsResponse, GetGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number ID, such as associations,
 * capabilities, and product type.
 */
export declare const getPhoneNumber: API.OperationMethod<GetPhoneNumberRequest & RegionInput, GetPhoneNumberResponse, GetPhoneNumberError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberOrderError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified phone number order, such as the order
 * creation timestamp, phone numbers in E.164 format, product type, and
 * order status.
 */
export declare const getPhoneNumberOrder: API.OperationMethod<GetPhoneNumberOrderRequest & RegionInput, GetPhoneNumberOrderResponse, GetPhoneNumberOrderError, Credentials | HttpClient.HttpClient>;
export type GetPhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the phone number settings for the administrator's AWS account,
 * such as the default outbound calling name.
 */
export declare const getPhoneNumberSettings: API.OperationMethod<GetPhoneNumberSettingsRequest & RegionInput, GetPhoneNumberSettingsResponse, GetPhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type GetProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the specified proxy session details for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getProxySession: API.OperationMethod<GetProxySessionRequest & RegionInput, GetProxySessionResponse, GetProxySessionError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the information for a SIP media application, including name,
 * AWS Region, and endpoints.
 */
export declare const getSipMediaApplication: API.OperationMethod<GetSipMediaApplicationRequest & RegionInput, GetSipMediaApplicationResponse, GetSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const getSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<GetSipMediaApplicationAlexaSkillConfigurationRequest & RegionInput, GetSipMediaApplicationAlexaSkillConfigurationResponse, GetSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration for the specified SIP media application.
 */
export declare const getSipMediaApplicationLoggingConfiguration: API.OperationMethod<GetSipMediaApplicationLoggingConfigurationRequest & RegionInput, GetSipMediaApplicationLoggingConfigurationResponse, GetSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSipRuleError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a SIP rule, such as the rule ID, name, triggers, and
 * target endpoints.
 */
export declare const getSipRule: API.OperationMethod<GetSipRuleRequest & RegionInput, GetSipRuleResponse, GetSipRuleError, Credentials | HttpClient.HttpClient>;
export type GetSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified speaker search task.
 */
export declare const getSpeakerSearchTask: API.OperationMethod<GetSpeakerSearchTaskRequest & RegionInput, GetSpeakerSearchTaskResponse, GetSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector, such as
 * timestamps,name, outbound host, and encryption requirements.
 */
export declare const getVoiceConnector: API.OperationMethod<GetVoiceConnectorRequest & RegionInput, GetVoiceConnectorResponse, GetVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the emergency calling configuration details for the specified Voice Connector.
 */
export declare const getVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<GetVoiceConnectorEmergencyCallingConfigurationRequest & RegionInput, GetVoiceConnectorEmergencyCallingConfigurationResponse, GetVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Gets information about an external systems configuration for a Voice
 * Connector.
 */
export declare const getVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<GetVoiceConnectorExternalSystemsConfigurationRequest & RegionInput, GetVoiceConnectorExternalSystemsConfigurationResponse, GetVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorGroupError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves details for the specified Amazon Chime SDK Voice Connector group,
 * such as timestamps,name, and associated `VoiceConnectorItems`.
 */
export declare const getVoiceConnectorGroup: API.OperationMethod<GetVoiceConnectorGroupRequest & RegionInput, GetVoiceConnectorGroupResponse, GetVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the logging configuration settings for the specified Voice Connector.
 * Shows whether SIP message logs are enabled for sending to Amazon CloudWatch Logs.
 */
export declare const getVoiceConnectorLoggingConfiguration: API.OperationMethod<GetVoiceConnectorLoggingConfigurationRequest & RegionInput, GetVoiceConnectorLoggingConfigurationResponse, GetVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorOriginationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the origination settings for the specified Voice Connector.
 */
export declare const getVoiceConnectorOrigination: API.OperationMethod<GetVoiceConnectorOriginationRequest & RegionInput, GetVoiceConnectorOriginationResponse, GetVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorProxyError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the proxy configuration details for the specified Amazon Chime SDK Voice
 * Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const getVoiceConnectorProxy: API.OperationMethod<GetVoiceConnectorProxyRequest & RegionInput, GetVoiceConnectorProxyResponse, GetVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the streaming configuration details for the specified Amazon Chime SDK
 * Voice Connector. Shows whether media streaming is enabled for sending to Amazon
 * Kinesis. It also shows the retention period, in hours, for the Amazon Kinesis data.
 */
export declare const getVoiceConnectorStreamingConfiguration: API.OperationMethod<GetVoiceConnectorStreamingConfigurationRequest & RegionInput, GetVoiceConnectorStreamingConfigurationResponse, GetVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the termination setting details for the specified Voice Connector.
 */
export declare const getVoiceConnectorTermination: API.OperationMethod<GetVoiceConnectorTerminationRequest & RegionInput, GetVoiceConnectorTerminationResponse, GetVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type GetVoiceConnectorTerminationHealthError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves information about the last time a `SIP OPTIONS` ping
 * was received from your SIP infrastructure for the specified Amazon Chime SDK Voice
 * Connector.
 */
export declare const getVoiceConnectorTerminationHealth: API.OperationMethod<GetVoiceConnectorTerminationHealthRequest & RegionInput, GetVoiceConnectorTerminationHealthResponse, GetVoiceConnectorTerminationHealthError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile.
 */
export declare const getVoiceProfile: API.OperationMethod<GetVoiceProfileRequest & RegionInput, GetVoiceProfileResponse, GetVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type GetVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of the specified voice profile domain.
 */
export declare const getVoiceProfileDomain: API.OperationMethod<GetVoiceProfileDomainRequest & RegionInput, GetVoiceProfileDomainResponse, GetVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type GetVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Retrieves the details of a voice tone analysis task.
 */
export declare const getVoiceToneAnalysisTask: API.OperationMethod<GetVoiceToneAnalysisTaskRequest & RegionInput, GetVoiceToneAnalysisTaskResponse, GetVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type ListAvailableVoiceConnectorRegionsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the available AWS Regions in which you can create an Amazon Chime SDK Voice Connector.
 */
export declare const listAvailableVoiceConnectorRegions: API.OperationMethod<ListAvailableVoiceConnectorRegionsRequest & RegionInput, ListAvailableVoiceConnectorRegionsResponse, ListAvailableVoiceConnectorRegionsError, Credentials | HttpClient.HttpClient>;
export type ListPhoneNumberOrdersError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for an administrator's Amazon Chime SDK account.
 */
export declare const listPhoneNumberOrders: API.PaginatedOperationMethod<ListPhoneNumberOrdersRequest & RegionInput, ListPhoneNumberOrdersResponse, ListPhoneNumberOrdersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPhoneNumbersError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the phone numbers for the specified Amazon Chime SDK account,
 * Amazon Chime SDK user, Amazon Chime SDK Voice Connector, or Amazon Chime SDK Voice
 * Connector group.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest & RegionInput, ListPhoneNumbersResponse, ListPhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProxySessionsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the proxy sessions for the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const listProxySessions: API.PaginatedOperationMethod<ListProxySessionsRequest & RegionInput, ListProxySessionsResponse, ListProxySessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSipMediaApplicationsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP media applications under the administrator's AWS account.
 */
export declare const listSipMediaApplications: API.PaginatedOperationMethod<ListSipMediaApplicationsRequest & RegionInput, ListSipMediaApplicationsResponse, ListSipMediaApplicationsError, Credentials | HttpClient.HttpClient, SipMediaApplication>;
export type ListSipRulesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP rules under the administrator's AWS account.
 */
export declare const listSipRules: API.PaginatedOperationMethod<ListSipRulesRequest & RegionInput, ListSipRulesResponse, ListSipRulesError, Credentials | HttpClient.HttpClient, SipRule>;
export type ListSupportedPhoneNumberCountriesError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the countries that you can order phone numbers from.
 */
export declare const listSupportedPhoneNumberCountries: API.OperationMethod<ListSupportedPhoneNumberCountriesRequest & RegionInput, ListSupportedPhoneNumberCountriesResponse, ListSupportedPhoneNumberCountriesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Returns a list of the tags in a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVoiceConnectorGroupsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connector groups in the administrator's AWS
 * account.
 */
export declare const listVoiceConnectorGroups: API.PaginatedOperationMethod<ListVoiceConnectorGroupsRequest & RegionInput, ListVoiceConnectorGroupsResponse, ListVoiceConnectorGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the Amazon Chime SDK Voice Connectors in the administrators
 * AWS account.
 */
export declare const listVoiceConnectors: API.PaginatedOperationMethod<ListVoiceConnectorsRequest & RegionInput, ListVoiceConnectorsResponse, ListVoiceConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the SIP credentials for the specified Amazon Chime SDK Voice Connector.
 */
export declare const listVoiceConnectorTerminationCredentials: API.OperationMethod<ListVoiceConnectorTerminationCredentialsRequest & RegionInput, ListVoiceConnectorTerminationCredentialsResponse, ListVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type ListVoiceProfileDomainsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the specified voice profile domains in the administrator's AWS account.
 */
export declare const listVoiceProfileDomains: API.PaginatedOperationMethod<ListVoiceProfileDomainsRequest & RegionInput, ListVoiceProfileDomainsResponse, ListVoiceProfileDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVoiceProfilesError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Lists the voice profiles in a voice profile domain.
 */
export declare const listVoiceProfiles: API.PaginatedOperationMethod<ListVoiceProfilesRequest & RegionInput, ListVoiceProfilesResponse, ListVoiceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type PutSipMediaApplicationAlexaSkillConfigurationError = BadRequestException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the Alexa Skill configuration for the SIP media application.
 *
 * Due to changes made by the Amazon Alexa service, this API is no longer available for use. For more information, refer to
 * the Alexa Smart Properties page.
 */
export declare const putSipMediaApplicationAlexaSkillConfiguration: API.OperationMethod<PutSipMediaApplicationAlexaSkillConfigurationRequest & RegionInput, PutSipMediaApplicationAlexaSkillConfigurationResponse, PutSipMediaApplicationAlexaSkillConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutSipMediaApplicationLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the logging configuration for the specified SIP media application.
 */
export declare const putSipMediaApplicationLoggingConfiguration: API.OperationMethod<PutSipMediaApplicationLoggingConfigurationRequest & RegionInput, PutSipMediaApplicationLoggingConfigurationResponse, PutSipMediaApplicationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorEmergencyCallingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's emergency calling configuration.
 */
export declare const putVoiceConnectorEmergencyCallingConfiguration: API.OperationMethod<PutVoiceConnectorEmergencyCallingConfigurationRequest & RegionInput, PutVoiceConnectorEmergencyCallingConfigurationResponse, PutVoiceConnectorEmergencyCallingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorExternalSystemsConfigurationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Adds an external systems configuration to a Voice Connector.
 */
export declare const putVoiceConnectorExternalSystemsConfiguration: API.OperationMethod<PutVoiceConnectorExternalSystemsConfigurationRequest & RegionInput, PutVoiceConnectorExternalSystemsConfigurationResponse, PutVoiceConnectorExternalSystemsConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorLoggingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's logging configuration.
 */
export declare const putVoiceConnectorLoggingConfiguration: API.OperationMethod<PutVoiceConnectorLoggingConfigurationRequest & RegionInput, PutVoiceConnectorLoggingConfigurationResponse, PutVoiceConnectorLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorOriginationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's origination settings.
 */
export declare const putVoiceConnectorOrigination: API.OperationMethod<PutVoiceConnectorOriginationRequest & RegionInput, PutVoiceConnectorOriginationResponse, PutVoiceConnectorOriginationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorProxyError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Puts the specified proxy configuration to the specified Amazon Chime SDK Voice Connector.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const putVoiceConnectorProxy: API.OperationMethod<PutVoiceConnectorProxyRequest & RegionInput, PutVoiceConnectorProxyResponse, PutVoiceConnectorProxyError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorStreamingConfigurationError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's streaming configuration settings.
 */
export declare const putVoiceConnectorStreamingConfiguration: API.OperationMethod<PutVoiceConnectorStreamingConfigurationRequest & RegionInput, PutVoiceConnectorStreamingConfigurationResponse, PutVoiceConnectorStreamingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination settings.
 */
export declare const putVoiceConnectorTermination: API.OperationMethod<PutVoiceConnectorTerminationRequest & RegionInput, PutVoiceConnectorTerminationResponse, PutVoiceConnectorTerminationError, Credentials | HttpClient.HttpClient>;
export type PutVoiceConnectorTerminationCredentialsError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates a Voice Connector's termination credentials.
 */
export declare const putVoiceConnectorTerminationCredentials: API.OperationMethod<PutVoiceConnectorTerminationCredentialsRequest & RegionInput, PutVoiceConnectorTerminationCredentialsResponse, PutVoiceConnectorTerminationCredentialsError, Credentials | HttpClient.HttpClient>;
export type RestorePhoneNumberError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Restores a deleted phone number.
 */
export declare const restorePhoneNumber: API.OperationMethod<RestorePhoneNumberRequest & RegionInput, RestorePhoneNumberResponse, RestorePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Searches the provisioned phone numbers in an organization.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest & RegionInput, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Credentials | HttpClient.HttpClient, unknown>;
export type StartSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a speaker search task.
 *
 * Before starting any speaker search tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startSpeakerSearchTask: API.OperationMethod<StartSpeakerSearchTaskRequest & RegionInput, StartSpeakerSearchTaskResponse, StartSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StartVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Starts a voice tone analysis task. For more information about voice tone analysis, see
 * Using Amazon Chime SDK voice analytics
 * in the *Amazon Chime SDK Developer Guide*.
 *
 * Before starting any voice tone analysis tasks, you must provide all notices and obtain all consents from the speaker as required under applicable privacy and biometrics laws, and as required under the
 * AWS service terms for the Amazon Chime SDK.
 */
export declare const startVoiceToneAnalysisTask: API.OperationMethod<StartVoiceToneAnalysisTaskRequest & RegionInput, StartVoiceToneAnalysisTaskResponse, StartVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type StopSpeakerSearchTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a speaker search task.
 */
export declare const stopSpeakerSearchTask: API.OperationMethod<StopSpeakerSearchTaskRequest & RegionInput, StopSpeakerSearchTaskResponse, StopSpeakerSearchTaskError, Credentials | HttpClient.HttpClient>;
export type StopVoiceToneAnalysisTaskError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | UnprocessableEntityException | CommonErrors;
/**
 * Stops a voice tone analysis task.
 */
export declare const stopVoiceToneAnalysisTask: API.OperationMethod<StopVoiceToneAnalysisTaskRequest & RegionInput, StopVoiceToneAnalysisTaskResponse, StopVoiceToneAnalysisTaskError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Adds a tag to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | UnauthorizedClientException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates global settings for the Amazon Chime SDK Voice Connectors in an AWS account.
 */
export declare const updateGlobalSettings: API.OperationMethod<UpdateGlobalSettingsRequest & RegionInput, UpdateGlobalSettingsResponse, UpdateGlobalSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates phone number details, such as product type, calling name, or phone number name for the
 * specified phone number ID. You can update one phone number detail at a time. For
 * example, you can update either the product type, calling name, or phone number name in one action.
 *
 * For numbers outside the U.S., you must use the Amazon Chime SDK SIP Media
 * Application Dial-In product type.
 *
 * Updates to outbound calling names can take 72 hours to complete. Pending
 * updates to outbound calling names must be complete before you can request another
 * update.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest & RegionInput, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Credentials | HttpClient.HttpClient>;
export type UpdatePhoneNumberSettingsError = BadRequestException | ForbiddenException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the phone number settings for the administrator's AWS account, such
 * as the default outbound calling name. You can update the default outbound calling
 * name once every seven days. Outbound calling names can take up to 72 hours to
 * update.
 */
export declare const updatePhoneNumberSettings: API.OperationMethod<UpdatePhoneNumberSettingsRequest & RegionInput, UpdatePhoneNumberSettingsResponse, UpdatePhoneNumberSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateProxySessionError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified proxy session details, such as voice or SMS capabilities.
 *
 * End of support notice: On April 7, 2026, AWS will end support for Amazon Chime SDK proxy sessions.
 */
export declare const updateProxySession: API.OperationMethod<UpdateProxySessionRequest & RegionInput, UpdateProxySessionResponse, UpdateProxySessionError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP media application.
 */
export declare const updateSipMediaApplication: API.OperationMethod<UpdateSipMediaApplicationRequest & RegionInput, UpdateSipMediaApplicationResponse, UpdateSipMediaApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateSipMediaApplicationCallError = BadRequestException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Invokes the AWS Lambda function associated with the SIP media application and
 * transaction ID in an update request. The Lambda function can then return a new set
 * of actions.
 */
export declare const updateSipMediaApplicationCall: API.OperationMethod<UpdateSipMediaApplicationCallRequest & RegionInput, UpdateSipMediaApplicationCallResponse, UpdateSipMediaApplicationCallError, Credentials | HttpClient.HttpClient>;
export type UpdateSipRuleError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ResourceLimitExceededException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details of the specified SIP rule.
 */
export declare const updateSipRule: API.OperationMethod<UpdateSipRuleRequest & RegionInput, UpdateSipRuleResponse, UpdateSipRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorError = BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the details for the specified Amazon Chime SDK Voice Connector.
 */
export declare const updateVoiceConnector: API.OperationMethod<UpdateVoiceConnectorRequest & RegionInput, UpdateVoiceConnectorResponse, UpdateVoiceConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceConnectorGroupError = BadRequestException | ConflictException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified Amazon Chime SDK Voice Connector group.
 */
export declare const updateVoiceConnectorGroup: API.OperationMethod<UpdateVoiceConnectorGroupRequest & RegionInput, UpdateVoiceConnectorGroupResponse, UpdateVoiceConnectorGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileError = AccessDeniedException | BadRequestException | ConflictException | ForbiddenException | GoneException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the specified voice profile's voice print and refreshes its expiration timestamp.
 *
 * As a condition of using this feature, you acknowledge that the collection, use, storage, and retention of
 * your caller's biometric identifiers and biometric information ("biometric data") in the form of a digital voiceprint
 * requires the caller's informed consent via a written release. Such consent is required under various state laws,
 * including biometrics laws in Illinois, Texas, Washington and other state privacy laws.
 *
 * You must provide a written release to each caller through a process that clearly reflects each caller's informed
 * consent before using Amazon Chime SDK Voice Insights service, as required under the terms of your agreement
 * with AWS governing your use of the service.
 */
export declare const updateVoiceProfile: API.OperationMethod<UpdateVoiceProfileRequest & RegionInput, UpdateVoiceProfileResponse, UpdateVoiceProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateVoiceProfileDomainError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Updates the settings for the specified voice profile domain.
 */
export declare const updateVoiceProfileDomain: API.OperationMethod<UpdateVoiceProfileDomainRequest & RegionInput, UpdateVoiceProfileDomainResponse, UpdateVoiceProfileDomainError, Credentials | HttpClient.HttpClient>;
export type ValidateE911AddressError = AccessDeniedException | BadRequestException | ForbiddenException | NotFoundException | ServiceFailureException | ServiceUnavailableException | ThrottledClientException | UnauthorizedClientException | CommonErrors;
/**
 * Validates an address to be used for 911 calls made with Amazon Chime SDK Voice
 * Connectors. You can use validated addresses in a Presence Information Data Format
 * Location Object file that you include in SIP requests. That helps ensure that addresses
 * are routed to the appropriate Public Safety Answering Point.
 */
export declare const validateE911Address: API.OperationMethod<ValidateE911AddressRequest & RegionInput, ValidateE911AddressResponse, ValidateE911AddressError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=chime-sdk-voice.d.ts.map