/** The host of `url` (no port); `""` when it has none. */
export declare const hostOf: (url: string) => string;
/**
 * The bounded server hint of a response: `x-amz-retry-after` or
 * `x-distilled-retry-after` in milliseconds, the larger when both are set.
 */
export declare const boundedHintOf: (headers: Readonly<Record<string, string | undefined>>) => number | undefined;
/** Record that the current fiber is sending a request to `url`. */
export declare const recordRequest: (url: string) => void;
/** Record the response to the current fiber's last request. */
export declare const recordResponse: (status: number, headers: Readonly<Record<string, string | undefined>>) => void;
/**
 * The current fiber's last request, removed so that a later failure that
 * sent nothing cannot reuse its hint.
 */
export declare const takeLastRequest: () => {
    readonly host: string;
    readonly hintMs?: number;
};
/** Successful responses from `host` so far in this process. */
export declare const successesOf: (host: string) => number;
//# sourceMappingURL=retry-state.d.ts.map