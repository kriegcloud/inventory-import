import * as Layer from "effect/Layer";
import { SqlClient } from "effect/sql/SqlClient";
import { KeyStore } from "./KeyStore.ts";
/** Options for {@link SqlKeyStore}. */
export interface SqlKeyStoreOptions {
    /**
     * The table that holds one row per subject. It is created on first use.
     * @default "vault_keys"
     */
    readonly table?: string;
}
/**
 * A Vault's keys in a SQL database, one row per subject, over the
 * `SqlClient` you provide, on Postgres. Use a database whose backups
 * you control: a restored backup brings shredded keys back.
 *
 * ### Keeping keys in Postgres
 * **Example:** Keys in a database of their own
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import { SqlKeyStore } from "@alchemy.run/domain/SqlKeyStore";
 * import { PgClient } from "@effect/sql-pg";
 * import * as Config from "effect/Config";
 * import * as Layer from "effect/Layer";
 *
 * export const Sealing = Domain.VaultLive.pipe(
 *   Layer.provide(SqlKeyStore()),
 *   Layer.provide(Domain.RootKeyWrap(Config.Redacted("VAULT_ROOT_KEY"))),
 *   Layer.provide(PgClient.layerConfig({ url: Config.Redacted("VAULT_DATABASE_URL") })),
 * );
 * ```
 *
 * @layer
 * @provides Domain.KeyStore
 */
export declare const SqlKeyStore: (options?: SqlKeyStoreOptions) => Layer.Layer<KeyStore, never, SqlClient>;
//# sourceMappingURL=SqlKeyStore.d.ts.map