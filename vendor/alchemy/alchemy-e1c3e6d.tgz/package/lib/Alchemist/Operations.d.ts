import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Tracer from "effect/Tracer";
import { AdoptPolicy } from "../AdoptPolicy.ts";
import { AlchemyContext } from "../AlchemyContext.ts";
import * as Apply from "../Apply.ts";
import { ArtifactStore } from "../Artifacts.ts";
import { type PlannedAction, type PlannedResource } from "../Events.ts";
import * as Plan from "../Plan.ts";
import type { ResourceSelection, SelectionOutput } from "../ResourceSelection.ts";
import * as Stack from "../Stack.ts";
import { Stage } from "../Stage.ts";
import type { State } from "../State/State.ts";
/** Which credentials and config a stack build sees. */
export interface ConfigOptions {
    /** `.env` file layered under the process environment. */
    readonly envFile?: string;
    /** Profile whose credentials the run uses. Falls back to the active profile. */
    readonly profile?: string;
}
export interface BuildOptions extends ConfigOptions {
    readonly stage: string;
    /** Run local (emulated) providers instead of the real cloud. */
    readonly dev?: boolean;
    /** Adopt pre-existing cloud resources instead of failing on conflict. */
    readonly adopt?: boolean;
    /** Upgrade an out-of-date state store without prompting. */
    readonly updateStateStore?: boolean;
}
/** Config services shared by every stack build. */
export declare const configServices: (options: ConfigOptions) => Effect.Effect<Layer.Layer<never, never, never>, import("effect/PlatformError").PlatformError, import("effect/FileSystem").FileSystem>;
/**
 * Build a stack's providers and state store and run its program.
 *
 * @internal used by {@link plan} and `Logs`.
 */
export declare const buildStack: <Output, Req>(stack: Stack.ConfiguredStack<Output, Req>, options: BuildOptions) => Effect.Effect<{
    stack: Stack.CompiledStack<Output, any>;
    /** The stack's own providers and state store over the build's services. */
    context: Context.Context<any>;
}, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError, AlchemyContext | import("effect/FileSystem").FileSystem | import("effect/Scope").Scope>;
/**
 * Build a stack's providers and state store without running its program:
 * all that destroy, drift, and state access need, and safe when the
 * program itself no longer runs.
 *
 * @internal used by {@link plan}, `Drift.scan`, and `State.store`.
 */
export declare const buildWithoutProgram: <Req>(stack: Stack.ConfiguredStack<unknown, Req>, options: BuildOptions) => Effect.Effect<{
    stack: {
        name: string;
        stage: string;
        resources: {
            [logicalId: string]: import("../Resource.ts").ResourceLike;
        };
        bindings: {
            [logicalId: string]: import("../Resource.ts").ResourceBinding[];
        };
        actions: {
            [logicalId: string]: import("../Action.ts").ActionLike;
        };
        output: undefined;
    };
    context: Context.Context<AdoptPolicy | AlchemyContext | ArtifactStore | import("../index.ts").AuthProviders | Stack.Stack | Stage | State | Exclude<Extract<Req, Stack.ProviderServices>, Tracer.ParentSpan>>;
}, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError, AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
export interface PlanSummary {
    readonly create: number;
    readonly update: number;
    readonly adopted: number;
    readonly replace: number;
    readonly delete: number;
    readonly orphaned: number;
    /** Actions that will run. */
    readonly run: number;
    readonly noop: number;
}
/** Whether a plan or drift scan proposes any cloud mutations (i.e. approval-worthy work). */
export declare const hasChanges: ({ summary }: {
    readonly summary: PlanSummary;
}) => boolean;
export declare const summarize: (plan: Plan.Plan) => PlanSummary;
/** The services a stack plan is applied under. */
type StackContext = Context.Context<State | Stack.Stack | Stage>;
/**
 * A deploy or destroy plan: what will change, and the built stack it was
 * planned against so {@link apply} runs without rebuilding.
 */
export interface StackPlan<Output = unknown> {
    readonly stack: {
        readonly name: string;
        readonly stage: string;
    };
    readonly summary: PlanSummary;
    /** Serializable resource rows (including orphan deletions). */
    readonly resources: ReadonlyArray<PlannedResource>;
    /** Serializable stack-action rows. */
    readonly actions: ReadonlyArray<PlannedAction>;
    /**
     * The engine plan `apply` executes, for renderers.
     * @internal its shape may change.
     */
    readonly native: Plan.Plan<Output>;
    /**
     * The stack services the plan was computed under; they live in the caller's `Scope`.
     * @internal `apply` runs in them.
     */
    readonly context: StackContext;
}
/** Describe an engine plan computed on a built stack. */
export declare const describeStackPlan: <Output>(built: {
    readonly stack: {
        readonly name: string;
        readonly stage: string;
    };
    readonly context: StackContext;
}, native: Plan.Plan<Output>) => Effect.Effect<{
    resources: ReadonlyArray<PlannedResource>;
    actions: ReadonlyArray<PlannedAction>;
    stack: {
        name: string;
        stage: string;
    };
    summary: PlanSummary;
    native: Plan.Plan<Output>;
    context: StackContext;
}, never, never>;
/**
 * Run the stack's program and plan what to create, update, replace, and
 * delete so the stage matches it.
 */
export interface DeployPlanOptions extends BuildOptions, ResourceSelection {
    readonly operation: "deploy";
    /** Re-run every Action regardless of input drift. */
    readonly force?: boolean;
}
/**
 * Plan deleting everything the stage owns. The program never runs, so this
 * works even when it no longer does. Always the whole stage.
 */
export interface DestroyPlanOptions extends BuildOptions {
    readonly operation: "destroy";
}
export type PlanOptions = DeployPlanOptions | DestroyPlanOptions;
/** What applying a plan made with `O` returns. */
export type PlanOutput<Output, O extends PlanOptions> = O extends {
    readonly operation: "destroy";
} ? undefined : SelectionOutput<Output, O>;
/**
 * Plan a deploy or a destroy of `stack`. A filtered deploy plan applies to
 * `undefined` and leaves the persisted stack output untouched. The build,
 * and the stage's state-store lease, stay open until the surrounding
 * `Scope` closes.
 */
export declare const plan: <Output, Req, const O extends PlanOptions>(input: O & {
    readonly stack: Stack.ConfiguredStack<Output, Req>;
}) => Effect.Effect<StackPlan<PlanOutput<Output, O>>, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError, AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
/** Run a plan; a deploy returns the stack's output. */
export declare const apply: <Output>(plan: StackPlan<Output>) => Effect.Effect<import("../Input.ts").Input.Resolve<Output>, import("../Auth/AuthProvider.ts").AuthError | import("effect/Config").ConfigError | import("../Auth/Demand.ts").CredentialsRequired | Apply.DestroyError | import("../Output.ts").InvalidReferenceError | import("../Output.ts").MissingSourceError | import("../Auth/AuthProvider.ts").NeedsReauth | import("effect/PlatformError").PlatformError | import("../State/State.ts").StateStoreError, never>;
/** Stage used when a stack's providers are built without addressing a deployment. */
export declare const PLACEHOLDER_STAGE = "placeholder";
/**
 * Build a stack's providers and state store without running its program or
 * addressing a stage: what account-wide operations like `Nuke.scan` need.
 */
export declare const buildProviders: <Req>(stack: Stack.ConfiguredStack<unknown, Req>, options?: ConfigOptions) => Effect.Effect<Context.Context<AdoptPolicy | AlchemyContext | ArtifactStore | import("../index.ts").AuthProviders | Stack.Stack | Stage | State | Exclude<Extract<Req, Stack.ProviderServices>, Tracer.ParentSpan>>, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError, AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
export {};
//# sourceMappingURL=Operations.d.ts.map