import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ServiceIdentifier = string;
export type ListenerIdentifier = string;
export type RuleIdentifier = string;
export type HttpMethod = string;
export type PathMatchExact = string;
export type PathMatchPrefix = string;
export type PathMatchType = {
    exact: string;
    prefix?: undefined;
} | {
    exact?: undefined;
    prefix: string;
};
export interface PathMatch {
    match: PathMatchType;
    caseSensitive?: boolean | undefined;
}
export type HeaderMatchName = string;
export type HeaderMatchExact = string;
export type HeaderMatchPrefix = string;
export type HeaderMatchContains = string;
export type HeaderMatchType = {
    exact: string;
    prefix?: undefined;
    contains?: undefined;
} | {
    exact?: undefined;
    prefix: string;
    contains?: undefined;
} | {
    exact?: undefined;
    prefix?: undefined;
    contains: string;
};
export interface HeaderMatch {
    name: string;
    match: HeaderMatchType;
    caseSensitive?: boolean | undefined;
}
export type HeaderMatchList = HeaderMatch[];
export interface HttpMatch {
    method?: string | undefined;
    pathMatch?: PathMatch | undefined;
    headerMatches?: HeaderMatch[] | undefined;
}
export type RuleMatch = {
    httpMatch: HttpMatch;
};
export type RulePriority = number;
export type TargetGroupIdentifier = string;
export type TargetGroupWeight = number;
export interface WeightedTargetGroup {
    targetGroupIdentifier: string;
    weight?: number | undefined;
}
export type WeightedTargetGroupList = WeightedTargetGroup[];
export interface ForwardAction {
    targetGroups: WeightedTargetGroup[];
}
export type HttpStatusCode = number;
export interface FixedResponseAction {
    statusCode: number;
}
export type RuleAction = {
    forward: ForwardAction;
    fixedResponse?: undefined;
} | {
    forward?: undefined;
    fixedResponse: FixedResponseAction;
};
export interface RuleUpdate {
    ruleIdentifier: string;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
}
export type RuleUpdateList = RuleUpdate[];
export interface BatchUpdateRuleRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    rules: RuleUpdate[];
}
export type RuleArn = string;
export type RuleId = string;
export type RuleName = string;
export interface RuleUpdateSuccess {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    isDefault?: boolean | undefined;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
}
export type RuleUpdateSuccessList = RuleUpdateSuccess[];
export type FailureCode = string;
export type FailureMessage = string;
export interface RuleUpdateFailure {
    ruleIdentifier?: string | undefined;
    failureCode?: string | undefined;
    failureMessage?: string | undefined;
}
export type RuleUpdateFailureList = RuleUpdateFailure[];
export interface BatchUpdateRuleResponse {
    successful?: RuleUpdateSuccess[] | undefined;
    unsuccessful?: RuleUpdateFailure[] | undefined;
}
export type ClientToken = string;
export type ResourceIdentifier = string;
export type AccessLogDestinationArn = string;
export type ServiceNetworkLogType = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAccessLogSubscriptionRequest {
    clientToken?: string | undefined;
    resourceIdentifier: string;
    destinationArn: string;
    serviceNetworkLogType?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AccessLogSubscriptionId = string;
export type AccessLogSubscriptionArn = string;
export type ResourceId = string;
export type ResourceArn = string;
export interface CreateAccessLogSubscriptionResponse {
    id: string;
    arn: string;
    resourceId: string;
    resourceArn: string;
    serviceNetworkLogType?: string | undefined;
    destinationArn: string;
}
export type ListenerName = string;
export type ListenerProtocol = string;
export type Port = number;
export interface CreateListenerRequest {
    serviceIdentifier: string;
    name: string;
    protocol: string;
    port?: number | undefined;
    defaultAction: RuleAction;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListenerArn = string;
export type ListenerId = string;
export type ServiceArn = string;
export type ServiceId = string;
export interface CreateListenerResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    protocol?: string | undefined;
    port?: number | undefined;
    serviceArn?: string | undefined;
    serviceId?: string | undefined;
    defaultAction?: RuleAction | undefined;
}
export type ResourceConfigurationName = string;
export type ResourceConfigurationType = "GROUP" | "CHILD" | "SINGLE" | "ARN" | "CIDR" | (string & {});
export type PortRange = string;
export type PortRangeList = string[];
export type ProtocolType = "TCP" | "TCP_UDP" | (string & {});
export type ResourceGatewayIdentifier = string;
export type ResourceConfigurationIdentifier = string;
export type DomainName = string;
export type ResourceConfigurationIpAddressType = string;
export interface DnsResource {
    domainName?: string | undefined;
    ipAddressType?: string | undefined;
}
export type IpAddress = string;
export interface IpResource {
    ipAddress?: string | undefined;
}
export type WildcardArn = string;
export interface ArnResource {
    arn?: string | undefined;
}
export type CidrRange = string;
export type CidrRangeList = string[];
export interface CidrResource {
    cidrRanges?: string[] | undefined;
}
export type ResourceConfigurationDefinition = {
    dnsResource: DnsResource;
    ipResource?: undefined;
    arnResource?: undefined;
    cidrResource?: undefined;
} | {
    dnsResource?: undefined;
    ipResource: IpResource;
    arnResource?: undefined;
    cidrResource?: undefined;
} | {
    dnsResource?: undefined;
    ipResource?: undefined;
    arnResource: ArnResource;
    cidrResource?: undefined;
} | {
    dnsResource?: undefined;
    ipResource?: undefined;
    arnResource?: undefined;
    cidrResource: CidrResource;
};
export type DomainVerificationIdentifier = string;
export interface CreateResourceConfigurationRequest {
    name: string;
    type: ResourceConfigurationType;
    portRanges?: string[] | undefined;
    protocol?: ProtocolType | undefined;
    resourceGatewayIdentifier?: string | undefined;
    resourceConfigurationGroupIdentifier?: string | undefined;
    resourceConfigurationDefinition?: ResourceConfigurationDefinition | undefined;
    allowAssociationToShareableServiceNetwork?: boolean | undefined;
    customDomainName?: string | undefined;
    groupDomain?: string | undefined;
    domainVerificationIdentifier?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResourceConfigurationId = string;
export type ResourceConfigurationArn = string;
export type ResourceGatewayId = string;
export type ResourceConfigurationStatus = string;
export type DomainVerificationId = string;
export type DomainVerificationArn = string;
export interface CreateResourceConfigurationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    resourceGatewayId?: string | undefined;
    resourceConfigurationGroupId?: string | undefined;
    type?: ResourceConfigurationType | undefined;
    portRanges?: string[] | undefined;
    protocol?: ProtocolType | undefined;
    status?: string | undefined;
    resourceConfigurationDefinition?: ResourceConfigurationDefinition | undefined;
    allowAssociationToShareableServiceNetwork?: boolean | undefined;
    createdAt?: Date | undefined;
    failureReason?: string | undefined;
    customDomainName?: string | undefined;
    domainVerificationId?: string | undefined;
    groupDomain?: string | undefined;
    domainVerificationArn?: string | undefined;
}
export type ResourceGatewayName = string;
export type VpcId = string;
export type SubnetId = string;
export type SubnetList = string[];
export type SecurityGroupId = string;
export type SecurityGroupList = string[];
export type ResourceGatewayIpAddressType = string;
export type Ipv4AddressesPerEni = number;
export type ResourceConfigDnsResolution = string;
export interface CreateResourceGatewayRequest {
    clientToken?: string | undefined;
    name: string;
    vpcIdentifier?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    ipAddressType?: string | undefined;
    ipv4AddressesPerEni?: number | undefined;
    resourceConfigDnsResolution?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResourceGatewayArn = string;
export type ResourceGatewayStatus = string;
export interface CreateResourceGatewayResponse {
    name?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    vpcIdentifier?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    ipAddressType?: string | undefined;
    ipv4AddressesPerEni?: number | undefined;
    resourceConfigDnsResolution?: string | undefined;
}
export interface CreateRuleRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    name: string;
    match: RuleMatch;
    priority: number;
    action: RuleAction;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateRuleResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
}
export type ServiceName = string;
export type ServiceCustomDomainName = string;
export type CertificateArn = string;
export type AuthType = string;
export type IdleTimeoutSeconds = number;
export interface CreateServiceRequest {
    clientToken?: string | undefined;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    customDomainName?: string | undefined;
    certificateArn?: string | undefined;
    authType?: string | undefined;
    idleTimeoutSeconds?: number | undefined;
}
export type ServiceStatus = string;
export interface DnsEntry {
    domainName?: string | undefined;
    hostedZoneId?: string | undefined;
}
export interface CreateServiceResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    customDomainName?: string | undefined;
    certificateArn?: string | undefined;
    status?: string | undefined;
    authType?: string | undefined;
    idleTimeoutSeconds?: number | undefined;
    dnsEntry?: DnsEntry | undefined;
}
export type ServiceNetworkName = string;
export interface SharingConfig {
    enabled?: boolean | undefined;
}
export interface CreateServiceNetworkRequest {
    clientToken?: string | undefined;
    name: string;
    authType?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    sharingConfig?: SharingConfig | undefined;
}
export type ServiceNetworkId = string;
export type ServiceNetworkArn = string;
export interface CreateServiceNetworkResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    sharingConfig?: SharingConfig | undefined;
    authType?: string | undefined;
}
export type ServiceNetworkIdentifierWithoutRegex = string;
export interface CreateServiceNetworkResourceAssociationRequest {
    clientToken?: string | undefined;
    resourceConfigurationIdentifier: string;
    serviceNetworkIdentifier: string;
    privateDnsEnabled?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ServiceNetworkResourceAssociationId = string;
export type ServiceNetworkResourceAssociationArn = string;
export type ServiceNetworkResourceAssociationStatus = string;
export type AccountId = string;
export interface CreateServiceNetworkResourceAssociationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    createdBy?: string | undefined;
    privateDnsEnabled?: boolean | undefined;
}
export type ServiceNetworkIdentifier = string;
export interface CreateServiceNetworkServiceAssociationRequest {
    clientToken?: string | undefined;
    serviceIdentifier: string;
    serviceNetworkIdentifier: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ServiceNetworkServiceAssociationIdentifier = string;
export type ServiceNetworkServiceAssociationStatus = string;
export type ServiceNetworkServiceAssociationArn = string;
export interface CreateServiceNetworkServiceAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    createdBy?: string | undefined;
    customDomainName?: string | undefined;
    dnsEntry?: DnsEntry | undefined;
}
export type PrivateDnsPreference = string;
export type PrivateDnsSpecifiedDomain = string;
export type PrivateDnsSpecifiedDomainsList = string[];
export interface DnsOptions {
    privateDnsPreference?: string | undefined;
    privateDnsSpecifiedDomains?: string[] | undefined;
}
export interface CreateServiceNetworkVpcAssociationRequest {
    clientToken?: string | undefined;
    serviceNetworkIdentifier: string;
    vpcIdentifier: string;
    privateDnsEnabled?: boolean | undefined;
    securityGroupIds?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    dnsOptions?: DnsOptions | undefined;
}
export type ServiceNetworkVpcAssociationId = string;
export type ServiceNetworkVpcAssociationStatus = string;
export type ServiceNetworkVpcAssociationArn = string;
export interface CreateServiceNetworkVpcAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    createdBy?: string | undefined;
    securityGroupIds?: string[] | undefined;
    privateDnsEnabled?: boolean | undefined;
    dnsOptions?: DnsOptions | undefined;
}
export type TargetGroupName = string;
export type TargetGroupType = string;
export type TargetGroupProtocol = string;
export type TargetGroupProtocolVersion = string;
export type IpAddressType = string;
export type HealthCheckProtocolVersion = string;
export type HealthCheckPort = number;
export type HealthCheckPath = string;
export type HealthCheckIntervalSeconds = number;
export type HealthCheckTimeoutSeconds = number;
export type HealthyThresholdCount = number;
export type UnhealthyThresholdCount = number;
export type HttpCodeMatcher = string;
export type Matcher = {
    httpCode: string;
};
export interface HealthCheckConfig {
    enabled?: boolean | undefined;
    protocol?: string | undefined;
    protocolVersion?: string | undefined;
    port?: number | undefined;
    path?: string | undefined;
    healthCheckIntervalSeconds?: number | undefined;
    healthCheckTimeoutSeconds?: number | undefined;
    healthyThresholdCount?: number | undefined;
    unhealthyThresholdCount?: number | undefined;
    matcher?: Matcher | undefined;
}
export type LambdaEventStructureVersion = string;
export interface TargetGroupConfig {
    port?: number | undefined;
    protocol?: string | undefined;
    protocolVersion?: string | undefined;
    ipAddressType?: string | undefined;
    vpcIdentifier?: string | undefined;
    healthCheck?: HealthCheckConfig | undefined;
    lambdaEventStructureVersion?: string | undefined;
}
export interface CreateTargetGroupRequest {
    name: string;
    type: string;
    config?: TargetGroupConfig | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TargetGroupId = string;
export type TargetGroupArn = string;
export type TargetGroupStatus = string;
export interface CreateTargetGroupResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    type?: string | undefined;
    config?: TargetGroupConfig | undefined;
    status?: string | undefined;
}
export type AccessLogSubscriptionIdentifier = string;
export interface DeleteAccessLogSubscriptionRequest {
    accessLogSubscriptionIdentifier: string;
}
export interface DeleteAccessLogSubscriptionResponse {
}
export interface DeleteAuthPolicyRequest {
    resourceIdentifier: string;
}
export interface DeleteAuthPolicyResponse {
}
export interface DeleteDomainVerificationRequest {
    domainVerificationIdentifier: string;
}
export interface DeleteDomainVerificationResponse {
}
export interface DeleteListenerRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
}
export interface DeleteListenerResponse {
}
export interface DeleteResourceConfigurationRequest {
    resourceConfigurationIdentifier: string;
}
export interface DeleteResourceConfigurationResponse {
}
export type ResourceEndpointAssociationIdentifier = string;
export interface DeleteResourceEndpointAssociationRequest {
    resourceEndpointAssociationIdentifier: string;
}
export type ResourceEndpointAssociationId = string;
export type ResourceEndpointAssociationArn = string;
export type VpcEndpointId = string;
export interface DeleteResourceEndpointAssociationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    resourceConfigurationId?: string | undefined;
    resourceConfigurationArn?: string | undefined;
    vpcEndpointId?: string | undefined;
}
export interface DeleteResourceGatewayRequest {
    resourceGatewayIdentifier: string;
}
export interface DeleteResourceGatewayResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteRuleRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    ruleIdentifier: string;
}
export interface DeleteRuleResponse {
}
export interface DeleteServiceRequest {
    serviceIdentifier: string;
}
export interface DeleteServiceResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export interface DeleteServiceNetworkRequest {
    serviceNetworkIdentifier: string;
}
export interface DeleteServiceNetworkResponse {
}
export type ServiceNetworkResourceAssociationIdentifier = string;
export interface DeleteServiceNetworkResourceAssociationRequest {
    serviceNetworkResourceAssociationIdentifier: string;
}
export interface DeleteServiceNetworkResourceAssociationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
}
export interface DeleteServiceNetworkServiceAssociationRequest {
    serviceNetworkServiceAssociationIdentifier: string;
}
export interface DeleteServiceNetworkServiceAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
}
export type ServiceNetworkVpcAssociationIdentifier = string;
export interface DeleteServiceNetworkVpcAssociationRequest {
    serviceNetworkVpcAssociationIdentifier: string;
}
export interface DeleteServiceNetworkVpcAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
}
export interface DeleteTargetGroupRequest {
    targetGroupIdentifier: string;
}
export interface DeleteTargetGroupResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
}
export interface Target {
    id: string;
    port?: number | undefined;
}
export type TargetList = Target[];
export interface DeregisterTargetsRequest {
    targetGroupIdentifier: string;
    targets: Target[];
}
export interface TargetFailure {
    id?: string | undefined;
    port?: number | undefined;
    failureCode?: string | undefined;
    failureMessage?: string | undefined;
}
export type TargetFailureList = TargetFailure[];
export interface DeregisterTargetsResponse {
    successful?: Target[] | undefined;
    unsuccessful?: TargetFailure[] | undefined;
}
export interface GetAccessLogSubscriptionRequest {
    accessLogSubscriptionIdentifier: string;
}
export interface GetAccessLogSubscriptionResponse {
    id: string;
    arn: string;
    resourceId: string;
    resourceArn: string;
    destinationArn: string;
    serviceNetworkLogType?: string | undefined;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export interface GetAuthPolicyRequest {
    resourceIdentifier: string;
}
export type AuthPolicyString = string;
export type AuthPolicyState = string;
export interface GetAuthPolicyResponse {
    policy?: string | undefined;
    state?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetDomainVerificationRequest {
    domainVerificationIdentifier: string;
}
export type VerificationStatus = string;
export interface TxtMethodConfig {
    value: string;
    name: string;
}
export interface GetDomainVerificationResponse {
    id: string;
    arn: string;
    domainName: string;
    status: string;
    txtMethodConfig?: TxtMethodConfig | undefined;
    createdAt: Date;
    lastVerifiedTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetListenerRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
}
export interface GetListenerResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    protocol?: string | undefined;
    port?: number | undefined;
    serviceArn?: string | undefined;
    serviceId?: string | undefined;
    defaultAction?: RuleAction | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetResourceConfigurationRequest {
    resourceConfigurationIdentifier: string;
}
export interface GetResourceConfigurationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    resourceGatewayId?: string | undefined;
    resourceConfigurationGroupId?: string | undefined;
    type?: ResourceConfigurationType | undefined;
    allowAssociationToShareableServiceNetwork?: boolean | undefined;
    portRanges?: string[] | undefined;
    protocol?: ProtocolType | undefined;
    customDomainName?: string | undefined;
    status?: string | undefined;
    resourceConfigurationDefinition?: ResourceConfigurationDefinition | undefined;
    createdAt?: Date | undefined;
    amazonManaged?: boolean | undefined;
    failureReason?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    domainVerificationId?: string | undefined;
    domainVerificationArn?: string | undefined;
    domainVerificationStatus?: string | undefined;
    groupDomain?: string | undefined;
}
export interface GetResourceGatewayRequest {
    resourceGatewayIdentifier: string;
}
export interface GetResourceGatewayResponse {
    name?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    serviceManaged?: boolean | undefined;
    managedBy?: string | undefined;
    securityGroupIds?: string[] | undefined;
    ipAddressType?: string | undefined;
    ipv4AddressesPerEni?: number | undefined;
    resourceConfigDnsResolution?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type PolicyString = string;
export interface GetResourcePolicyResponse {
    policy?: string | undefined;
}
export interface GetRuleRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    ruleIdentifier: string;
}
export interface GetRuleResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    isDefault?: boolean | undefined;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetServiceRequest {
    serviceIdentifier: string;
}
export interface GetServiceResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    dnsEntry?: DnsEntry | undefined;
    customDomainName?: string | undefined;
    certificateArn?: string | undefined;
    status?: string | undefined;
    authType?: string | undefined;
    idleTimeoutSeconds?: number | undefined;
    failureCode?: string | undefined;
    failureMessage?: string | undefined;
}
export interface GetServiceNetworkRequest {
    serviceNetworkIdentifier: string;
}
export interface GetServiceNetworkResponse {
    id?: string | undefined;
    name?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    arn?: string | undefined;
    authType?: string | undefined;
    sharingConfig?: SharingConfig | undefined;
    numberOfAssociatedVPCs?: number | undefined;
    numberOfAssociatedServices?: number | undefined;
}
export interface GetServiceNetworkResourceAssociationRequest {
    serviceNetworkResourceAssociationIdentifier: string;
}
export type ServiceNetworkNameWithoutRegex = string;
export interface GetServiceNetworkResourceAssociationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    resourceConfigurationId?: string | undefined;
    resourceConfigurationArn?: string | undefined;
    resourceConfigurationName?: string | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkArn?: string | undefined;
    serviceNetworkName?: string | undefined;
    failureReason?: string | undefined;
    failureCode?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    privateDnsEntry?: DnsEntry | undefined;
    privateDnsEnabled?: boolean | undefined;
    dnsEntry?: DnsEntry | undefined;
    isManagedAssociation?: boolean | undefined;
    domainVerificationStatus?: string | undefined;
}
export interface GetServiceNetworkServiceAssociationRequest {
    serviceNetworkServiceAssociationIdentifier: string;
}
export interface GetServiceNetworkServiceAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    serviceId?: string | undefined;
    serviceName?: string | undefined;
    serviceArn?: string | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkName?: string | undefined;
    serviceNetworkArn?: string | undefined;
    dnsEntry?: DnsEntry | undefined;
    customDomainName?: string | undefined;
    failureMessage?: string | undefined;
    failureCode?: string | undefined;
}
export interface GetServiceNetworkVpcAssociationRequest {
    serviceNetworkVpcAssociationIdentifier: string;
}
export interface GetServiceNetworkVpcAssociationResponse {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkName?: string | undefined;
    serviceNetworkArn?: string | undefined;
    vpcId?: string | undefined;
    securityGroupIds?: string[] | undefined;
    privateDnsEnabled?: boolean | undefined;
    failureMessage?: string | undefined;
    failureCode?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    dnsOptions?: DnsOptions | undefined;
}
export interface GetTargetGroupRequest {
    targetGroupIdentifier: string;
}
export type ServiceArnList = string[];
export interface GetTargetGroupResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    type?: string | undefined;
    config?: TargetGroupConfig | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    status?: string | undefined;
    serviceArns?: string[] | undefined;
    failureMessage?: string | undefined;
    failureCode?: string | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAccessLogSubscriptionsRequest {
    resourceIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AccessLogSubscriptionSummary {
    id: string;
    arn: string;
    resourceId: string;
    resourceArn: string;
    destinationArn: string;
    serviceNetworkLogType?: string | undefined;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type AccessLogSubscriptionList = AccessLogSubscriptionSummary[];
export interface ListAccessLogSubscriptionsResponse {
    items: AccessLogSubscriptionSummary[];
    nextToken?: string | undefined;
}
export interface ListDomainVerificationsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DomainVerificationSummary {
    id: string;
    arn: string;
    domainName: string;
    status: string;
    txtMethodConfig?: TxtMethodConfig | undefined;
    createdAt: Date;
    lastVerifiedTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DomainVerificationList = DomainVerificationSummary[];
export interface ListDomainVerificationsResponse {
    items: DomainVerificationSummary[];
    nextToken?: string | undefined;
}
export interface ListListenersRequest {
    serviceIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListenerSummary {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    protocol?: string | undefined;
    port?: number | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type ListenerSummaryList = ListenerSummary[];
export interface ListListenersResponse {
    items: ListenerSummary[];
    nextToken?: string | undefined;
}
export interface ListResourceConfigurationsRequest {
    resourceGatewayIdentifier?: string | undefined;
    resourceConfigurationGroupIdentifier?: string | undefined;
    domainVerificationIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ResourceConfigurationSummary {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    resourceGatewayId?: string | undefined;
    resourceConfigurationGroupId?: string | undefined;
    type?: ResourceConfigurationType | undefined;
    status?: string | undefined;
    amazonManaged?: boolean | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    customDomainName?: string | undefined;
    domainVerificationId?: string | undefined;
    groupDomain?: string | undefined;
}
export type ResourceConfigurationSummaryList = ResourceConfigurationSummary[];
export interface ListResourceConfigurationsResponse {
    items?: ResourceConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type VpcEndpointOwner = string;
export interface ListResourceEndpointAssociationsRequest {
    resourceConfigurationIdentifier: string;
    resourceEndpointAssociationIdentifier?: string | undefined;
    vpcEndpointId?: string | undefined;
    vpcEndpointOwner?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type PayerResponsibilityScope = "ResourceGatewayCharges" | (string & {});
export type PayerResponsibilityPayer = "VpcEndpointAccount" | "ResourceGatewayAccount" | (string & {});
export interface PayerResponsibilityEntry {
    scope?: PayerResponsibilityScope | undefined;
    payerResponsibilityType?: PayerResponsibilityPayer | undefined;
}
export type PayerResponsibilityList = PayerResponsibilityEntry[];
export interface ResourceEndpointAssociationSummary {
    id?: string | undefined;
    arn?: string | undefined;
    resourceConfigurationId?: string | undefined;
    resourceConfigurationArn?: string | undefined;
    resourceConfigurationName?: string | undefined;
    vpcEndpointId?: string | undefined;
    vpcEndpointOwner?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    payerResponsibility?: PayerResponsibilityEntry[] | undefined;
}
export type ResourceEndpointAssociationList = ResourceEndpointAssociationSummary[];
export interface ListResourceEndpointAssociationsResponse {
    items: ResourceEndpointAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListResourceGatewaysRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ResourceGatewaySummary {
    name?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    vpcIdentifier?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    ipAddressType?: string | undefined;
    ipv4AddressesPerEni?: number | undefined;
    resourceConfigDnsResolution?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type ResourceGatewayList = ResourceGatewaySummary[];
export interface ListResourceGatewaysResponse {
    items?: ResourceGatewaySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRulesRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RuleSummary {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    isDefault?: boolean | undefined;
    priority?: number | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type RuleSummaryList = RuleSummary[];
export interface ListRulesResponse {
    items: RuleSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceNetworkResourceAssociationsRequest {
    serviceNetworkIdentifier?: string | undefined;
    resourceConfigurationIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    includeChildren?: boolean | undefined;
}
export type ServiceNetworkArnWithoutRegex = string;
export interface ServiceNetworkResourceAssociationSummary {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    resourceConfigurationId?: string | undefined;
    resourceConfigurationArn?: string | undefined;
    resourceConfigurationName?: string | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkArn?: string | undefined;
    serviceNetworkName?: string | undefined;
    dnsEntry?: DnsEntry | undefined;
    privateDnsEntry?: DnsEntry | undefined;
    isManagedAssociation?: boolean | undefined;
    failureCode?: string | undefined;
    privateDnsEnabled?: boolean | undefined;
}
export type ServiceNetworkResourceAssociationList = ServiceNetworkResourceAssociationSummary[];
export interface ListServiceNetworkResourceAssociationsResponse {
    items: ServiceNetworkResourceAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceNetworksRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceNetworkSummary {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    numberOfAssociatedVPCs?: number | undefined;
    numberOfAssociatedServices?: number | undefined;
    numberOfAssociatedResourceConfigurations?: number | undefined;
}
export type ServiceNetworkList = ServiceNetworkSummary[];
export interface ListServiceNetworksResponse {
    items: ServiceNetworkSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceNetworkServiceAssociationsRequest {
    serviceNetworkIdentifier?: string | undefined;
    serviceIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceNetworkServiceAssociationSummary {
    id?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    serviceId?: string | undefined;
    serviceName?: string | undefined;
    serviceArn?: string | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkName?: string | undefined;
    serviceNetworkArn?: string | undefined;
    dnsEntry?: DnsEntry | undefined;
    customDomainName?: string | undefined;
}
export type ServiceNetworkServiceAssociationList = ServiceNetworkServiceAssociationSummary[];
export interface ListServiceNetworkServiceAssociationsResponse {
    items: ServiceNetworkServiceAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceNetworkVpcAssociationsRequest {
    serviceNetworkIdentifier?: string | undefined;
    vpcIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceNetworkVpcAssociationSummary {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    createdBy?: string | undefined;
    createdAt?: Date | undefined;
    serviceNetworkId?: string | undefined;
    serviceNetworkName?: string | undefined;
    serviceNetworkArn?: string | undefined;
    privateDnsEnabled?: boolean | undefined;
    dnsOptions?: DnsOptions | undefined;
    vpcId?: string | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type ServiceNetworkVpcAssociationList = ServiceNetworkVpcAssociationSummary[];
export interface ListServiceNetworkVpcAssociationsResponse {
    items: ServiceNetworkVpcAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceNetworkVpcEndpointAssociationsRequest {
    serviceNetworkIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceNetworkEndpointAssociation {
    vpcEndpointId?: string | undefined;
    vpcId?: string | undefined;
    vpcEndpointOwnerId?: string | undefined;
    id?: string | undefined;
    state?: string | undefined;
    serviceNetworkArn?: string | undefined;
    createdAt?: Date | undefined;
}
export type ServiceNetworkVpcEndpointAssociationList = ServiceNetworkEndpointAssociation[];
export interface ListServiceNetworkVpcEndpointAssociationsResponse {
    items: ServiceNetworkEndpointAssociation[];
    nextToken?: string | undefined;
}
export interface ListServicesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceSummary {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    dnsEntry?: DnsEntry | undefined;
    customDomainName?: string | undefined;
    status?: string | undefined;
}
export type ServiceList = ServiceSummary[];
export interface ListServicesResponse {
    items?: ServiceSummary[] | undefined;
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTargetGroupsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    vpcIdentifier?: string | undefined;
    targetGroupType?: string | undefined;
}
export interface TargetGroupSummary {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    type?: string | undefined;
    createdAt?: Date | undefined;
    port?: number | undefined;
    protocol?: string | undefined;
    ipAddressType?: string | undefined;
    vpcIdentifier?: string | undefined;
    lastUpdatedAt?: Date | undefined;
    status?: string | undefined;
    serviceArns?: string[] | undefined;
    lambdaEventStructureVersion?: string | undefined;
}
export type TargetGroupList = TargetGroupSummary[];
export interface ListTargetGroupsResponse {
    items?: TargetGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTargetsRequest {
    targetGroupIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    targets?: Target[] | undefined;
}
export type TargetStatus = string;
export interface TargetSummary {
    id?: string | undefined;
    port?: number | undefined;
    status?: string | undefined;
    reasonCode?: string | undefined;
}
export type TargetSummaryList = TargetSummary[];
export interface ListTargetsResponse {
    items: TargetSummary[];
    nextToken?: string | undefined;
}
export interface PutAuthPolicyRequest {
    resourceIdentifier: string;
    policy: string;
}
export interface PutAuthPolicyResponse {
    policy?: string | undefined;
    state?: string | undefined;
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
}
export interface PutResourcePolicyResponse {
}
export interface RegisterTargetsRequest {
    targetGroupIdentifier: string;
    targets: Target[];
}
export interface RegisterTargetsResponse {
    successful?: Target[] | undefined;
    unsuccessful?: TargetFailure[] | undefined;
}
export interface StartDomainVerificationRequest {
    clientToken?: string | undefined;
    domainName: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartDomainVerificationResponse {
    id: string;
    arn: string;
    domainName: string;
    status: string;
    txtMethodConfig?: TxtMethodConfig | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessLogSubscriptionRequest {
    accessLogSubscriptionIdentifier: string;
    destinationArn: string;
}
export interface UpdateAccessLogSubscriptionResponse {
    id: string;
    arn: string;
    resourceId: string;
    resourceArn: string;
    destinationArn: string;
}
export interface UpdateListenerRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    defaultAction: RuleAction;
}
export interface UpdateListenerResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    protocol?: string | undefined;
    port?: number | undefined;
    serviceArn?: string | undefined;
    serviceId?: string | undefined;
    defaultAction?: RuleAction | undefined;
}
export interface UpdateResourceConfigurationRequest {
    resourceConfigurationIdentifier: string;
    resourceConfigurationDefinition?: ResourceConfigurationDefinition | undefined;
    allowAssociationToShareableServiceNetwork?: boolean | undefined;
    portRanges?: string[] | undefined;
}
export interface UpdateResourceConfigurationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    resourceGatewayId?: string | undefined;
    resourceConfigurationGroupId?: string | undefined;
    type?: ResourceConfigurationType | undefined;
    portRanges?: string[] | undefined;
    allowAssociationToShareableServiceNetwork?: boolean | undefined;
    protocol?: ProtocolType | undefined;
    status?: string | undefined;
    resourceConfigurationDefinition?: ResourceConfigurationDefinition | undefined;
}
export interface UpdateResourceGatewayRequest {
    resourceGatewayIdentifier: string;
    securityGroupIds?: string[] | undefined;
    resourceConfigDnsResolution?: string | undefined;
}
export interface UpdateResourceGatewayResponse {
    name?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    ipAddressType?: string | undefined;
    resourceConfigDnsResolution?: string | undefined;
}
export interface UpdateRuleRequest {
    serviceIdentifier: string;
    listenerIdentifier: string;
    ruleIdentifier: string;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
}
export interface UpdateRuleResponse {
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    isDefault?: boolean | undefined;
    match?: RuleMatch | undefined;
    priority?: number | undefined;
    action?: RuleAction | undefined;
}
export interface UpdateServiceRequest {
    serviceIdentifier: string;
    certificateArn?: string | undefined;
    authType?: string | undefined;
    idleTimeoutSeconds?: number | undefined;
}
export interface UpdateServiceResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    customDomainName?: string | undefined;
    certificateArn?: string | undefined;
    authType?: string | undefined;
    idleTimeoutSeconds?: number | undefined;
}
export interface UpdateServiceNetworkRequest {
    serviceNetworkIdentifier: string;
    authType: string;
}
export interface UpdateServiceNetworkResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    authType?: string | undefined;
}
export interface UpdateServiceNetworkVpcAssociationRequest {
    serviceNetworkVpcAssociationIdentifier: string;
    securityGroupIds?: string[] | undefined;
    privateDnsEnabled?: boolean | undefined;
    dnsOptions?: DnsOptions | undefined;
}
export interface UpdateServiceNetworkVpcAssociationResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    createdBy?: string | undefined;
    securityGroupIds?: string[] | undefined;
    privateDnsEnabled?: boolean | undefined;
    dnsOptions?: DnsOptions | undefined;
}
export interface UpdateTargetGroupRequest {
    targetGroupIdentifier: string;
    healthCheck: HealthCheckConfig;
}
export interface UpdateTargetGroupResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    type?: string | undefined;
    config?: TargetGroupConfig | undefined;
    status?: string | undefined;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchUpdateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the listener rules in a batch. You can use this operation to change the priority of listener rules. This can be useful when bulk updating or swapping rule priority.
 *
 * **Required permissions:** `vpc-lattice:UpdateRule`
 *
 * For more information, see How Amazon VPC Lattice works with IAM in the *Amazon VPC Lattice User Guide*.
 */
export declare const batchUpdateRule: API.OperationMethod<BatchUpdateRuleRequest & RegionInput, BatchUpdateRuleResponse, BatchUpdateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAccessLogSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables access logs to be sent to Amazon CloudWatch, Amazon S3, and Amazon Kinesis Data Firehose. The service network owner can use the access logs to audit the services in the network. The service network owner can only see access logs from clients and services that are associated with their service network. Access log entries represent traffic originated from VPCs associated with that network. For more information, see Access logs in the *Amazon VPC Lattice User Guide*.
 */
export declare const createAccessLogSubscription: API.OperationMethod<CreateAccessLogSubscriptionRequest & RegionInput, CreateAccessLogSubscriptionResponse, CreateAccessLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateListenerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a listener for a service. Before you start using your Amazon VPC Lattice service, you must add one or more listeners. A listener is a process that checks for connection requests to your services. For more information, see Listeners in the *Amazon VPC Lattice User Guide*.
 */
export declare const createListener: API.OperationMethod<CreateListenerRequest & RegionInput, CreateListenerResponse, CreateListenerError, Credentials | HttpClient.HttpClient>;
export type CreateResourceConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a resource configuration. A resource configuration defines a specific resource. You can associate a resource configuration with a service network or a VPC endpoint.
 */
export declare const createResourceConfiguration: API.OperationMethod<CreateResourceConfigurationRequest & RegionInput, CreateResourceConfigurationResponse, CreateResourceConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateResourceGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A resource gateway is a point of ingress into the VPC where a resource resides. It spans multiple Availability Zones. For your resource to be accessible from all Availability Zones, you should create your resource gateways to span as many Availability Zones as possible. A VPC can have multiple resource gateways.
 */
export declare const createResourceGateway: API.OperationMethod<CreateResourceGatewayRequest & RegionInput, CreateResourceGatewayResponse, CreateResourceGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a listener rule. Each listener has a default rule for checking connection requests, but you can define additional rules. Each rule consists of a priority, one or more actions, and one or more conditions. For more information, see Listener rules in the *Amazon VPC Lattice User Guide*.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest & RegionInput, CreateRuleResponse, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service. A service is any software application that can run on instances containers, or serverless functions within an account or virtual private cloud (VPC).
 *
 * For more information, see Services in the *Amazon VPC Lattice User Guide*.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest & RegionInput, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateServiceNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a service network. A service network is a logical boundary for a collection of services. You can associate services and VPCs with a service network.
 *
 * For more information, see Service networks in the *Amazon VPC Lattice User Guide*.
 */
export declare const createServiceNetwork: API.OperationMethod<CreateServiceNetworkRequest & RegionInput, CreateServiceNetworkResponse, CreateServiceNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateServiceNetworkResourceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the specified service network with the specified resource configuration. This allows the resource configuration to receive connections through the service network, including through a service network VPC endpoint.
 */
export declare const createServiceNetworkResourceAssociation: API.OperationMethod<CreateServiceNetworkResourceAssociationRequest & RegionInput, CreateServiceNetworkResourceAssociationResponse, CreateServiceNetworkResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceNetworkServiceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the specified service with the specified service network. For more information, see Manage service associations in the *Amazon VPC Lattice User Guide*.
 *
 * You can't use this operation if the service and service network are already associated or if there is a disassociation or deletion in progress. If the association fails, you can retry the operation by deleting the association and recreating it.
 *
 * You cannot associate a service and service network that are shared with a caller. The caller must own either the service or the service network.
 *
 * As a result of this operation, the association is created in the service network account and the association owner account.
 */
export declare const createServiceNetworkServiceAssociation: API.OperationMethod<CreateServiceNetworkServiceAssociationRequest & RegionInput, CreateServiceNetworkServiceAssociationResponse, CreateServiceNetworkServiceAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceNetworkVpcAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a VPC with a service network. When you associate a VPC with the service network, it enables all the resources within that VPC to be clients and communicate with other services in the service network. For more information, see Manage VPC associations in the *Amazon VPC Lattice User Guide*.
 *
 * You can't use this operation if there is a disassociation in progress. If the association fails, retry by deleting the association and recreating it.
 *
 * As a result of this operation, the association gets created in the service network account and the VPC owner account.
 *
 * If you add a security group to the service network and VPC association, the association must continue to always have at least one security group. You can add or edit security groups at any time. However, to remove all security groups, you must first delete the association and recreate it without security groups.
 */
export declare const createServiceNetworkVpcAssociation: API.OperationMethod<CreateServiceNetworkVpcAssociationRequest & RegionInput, CreateServiceNetworkVpcAssociationResponse, CreateServiceNetworkVpcAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateTargetGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a target group. A target group is a collection of targets, or compute resources, that run your application or service. A target group can only be used by a single service.
 *
 * For more information, see Target groups in the *Amazon VPC Lattice User Guide*.
 */
export declare const createTargetGroup: API.OperationMethod<CreateTargetGroupRequest & RegionInput, CreateTargetGroupResponse, CreateTargetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessLogSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified access log subscription.
 */
export declare const deleteAccessLogSubscription: API.OperationMethod<DeleteAccessLogSubscriptionRequest & RegionInput, DeleteAccessLogSubscriptionResponse, DeleteAccessLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified auth policy. If an auth is set to `AWS_IAM` and the auth policy is deleted, all requests are denied. If you are trying to remove the auth policy completely, you must set the auth type to `NONE`. If auth is enabled on the resource, but no auth policy is set, all requests are denied.
 */
export declare const deleteAuthPolicy: API.OperationMethod<DeleteAuthPolicyRequest & RegionInput, DeleteAuthPolicyResponse, DeleteAuthPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainVerificationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified domain verification.
 */
export declare const deleteDomainVerification: API.OperationMethod<DeleteDomainVerificationRequest & RegionInput, DeleteDomainVerificationResponse, DeleteDomainVerificationError, Credentials | HttpClient.HttpClient>;
export type DeleteListenerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified listener.
 */
export declare const deleteListener: API.OperationMethod<DeleteListenerRequest & RegionInput, DeleteListenerResponse, DeleteListenerError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified resource configuration.
 */
export declare const deleteResourceConfiguration: API.OperationMethod<DeleteResourceConfigurationRequest & RegionInput, DeleteResourceConfigurationResponse, DeleteResourceConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceEndpointAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the resource configuration from the resource VPC endpoint.
 */
export declare const deleteResourceEndpointAssociation: API.OperationMethod<DeleteResourceEndpointAssociationRequest & RegionInput, DeleteResourceEndpointAssociationResponse, DeleteResourceEndpointAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified resource gateway.
 */
export declare const deleteResourceGateway: API.OperationMethod<DeleteResourceGatewayRequest & RegionInput, DeleteResourceGatewayResponse, DeleteResourceGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a listener rule. Each listener has a default rule for checking connection requests, but you can define additional rules. Each rule consists of a priority, one or more actions, and one or more conditions. You can delete additional listener rules, but you cannot delete the default rule.
 *
 * For more information, see Listener rules in the *Amazon VPC Lattice User Guide*.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest & RegionInput, DeleteRuleResponse, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a service. A service can't be deleted if it's associated with a service network. If you delete a service, all resources related to the service, such as the resource policy, auth policy, listeners, listener rules, and access log subscriptions, are also deleted. For more information, see Delete a service in the *Amazon VPC Lattice User Guide*.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest & RegionInput, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a service network. You can only delete the service network if there are no services, VPCs, resource configurations, or service network endpoints associated with it. Only the owner of a service network endpoint can remove it from the service network, by deleting the endpoint. If you delete a service network, all resources related to the service network, such as the resource policy, auth policy, and access log subscriptions, are also deleted. For more information, see Delete a service network in the *Amazon VPC Lattice User Guide*.
 */
export declare const deleteServiceNetwork: API.OperationMethod<DeleteServiceNetworkRequest & RegionInput, DeleteServiceNetworkResponse, DeleteServiceNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceNetworkResourceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the association between a service network and a resource configuration.
 */
export declare const deleteServiceNetworkResourceAssociation: API.OperationMethod<DeleteServiceNetworkResourceAssociationRequest & RegionInput, DeleteServiceNetworkResourceAssociationResponse, DeleteServiceNetworkResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceNetworkServiceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the association between a service and a service network. This operation fails if an association is still in progress.
 */
export declare const deleteServiceNetworkServiceAssociation: API.OperationMethod<DeleteServiceNetworkServiceAssociationRequest & RegionInput, DeleteServiceNetworkServiceAssociationResponse, DeleteServiceNetworkServiceAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceNetworkVpcAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the VPC from the service network. You can't disassociate the VPC if there is a create or update association in progress.
 */
export declare const deleteServiceNetworkVpcAssociation: API.OperationMethod<DeleteServiceNetworkVpcAssociationRequest & RegionInput, DeleteServiceNetworkVpcAssociationResponse, DeleteServiceNetworkVpcAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteTargetGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a target group. You can't delete a target group if it is used in a listener rule or if the target group creation is in progress.
 */
export declare const deleteTargetGroup: API.OperationMethod<DeleteTargetGroupRequest & RegionInput, DeleteTargetGroupResponse, DeleteTargetGroupError, Credentials | HttpClient.HttpClient>;
export type DeregisterTargetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters the specified targets from the specified target group.
 */
export declare const deregisterTargets: API.OperationMethod<DeregisterTargetsRequest & RegionInput, DeregisterTargetsResponse, DeregisterTargetsError, Credentials | HttpClient.HttpClient>;
export type GetAccessLogSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified access log subscription.
 */
export declare const getAccessLogSubscription: API.OperationMethod<GetAccessLogSubscriptionRequest & RegionInput, GetAccessLogSubscriptionResponse, GetAccessLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetAuthPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the auth policy for the specified service or service network.
 */
export declare const getAuthPolicy: API.OperationMethod<GetAuthPolicyRequest & RegionInput, GetAuthPolicyResponse, GetAuthPolicyError, Credentials | HttpClient.HttpClient>;
export type GetDomainVerificationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a domain verification.ß
 */
export declare const getDomainVerification: API.OperationMethod<GetDomainVerificationRequest & RegionInput, GetDomainVerificationResponse, GetDomainVerificationError, Credentials | HttpClient.HttpClient>;
export type GetListenerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified listener for the specified service.
 */
export declare const getListener: API.OperationMethod<GetListenerRequest & RegionInput, GetListenerResponse, GetListenerError, Credentials | HttpClient.HttpClient>;
export type GetResourceConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified resource configuration.
 */
export declare const getResourceConfiguration: API.OperationMethod<GetResourceConfigurationRequest & RegionInput, GetResourceConfigurationResponse, GetResourceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetResourceGatewayError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified resource gateway.
 */
export declare const getResourceGateway: API.OperationMethod<GetResourceGatewayRequest & RegionInput, GetResourceGatewayResponse, GetResourceGatewayError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified resource policy. The resource policy is an IAM policy created on behalf of the resource owner when they share a resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified listener rules. You can also retrieve information about the default listener rule. For more information, see Listener rules in the *Amazon VPC Lattice User Guide*.
 */
export declare const getRule: API.OperationMethod<GetRuleRequest & RegionInput, GetRuleResponse, GetRuleError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified service.
 */
export declare const getService: API.OperationMethod<GetServiceRequest & RegionInput, GetServiceResponse, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetServiceNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified service network.
 */
export declare const getServiceNetwork: API.OperationMethod<GetServiceNetworkRequest & RegionInput, GetServiceNetworkResponse, GetServiceNetworkError, Credentials | HttpClient.HttpClient>;
export type GetServiceNetworkResourceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified association between a service network and a resource configuration.
 */
export declare const getServiceNetworkResourceAssociation: API.OperationMethod<GetServiceNetworkResourceAssociationRequest & RegionInput, GetServiceNetworkResourceAssociationResponse, GetServiceNetworkResourceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetServiceNetworkServiceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified association between a service network and a service.
 */
export declare const getServiceNetworkServiceAssociation: API.OperationMethod<GetServiceNetworkServiceAssociationRequest & RegionInput, GetServiceNetworkServiceAssociationResponse, GetServiceNetworkServiceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetServiceNetworkVpcAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified association between a service network and a VPC.
 */
export declare const getServiceNetworkVpcAssociation: API.OperationMethod<GetServiceNetworkVpcAssociationRequest & RegionInput, GetServiceNetworkVpcAssociationResponse, GetServiceNetworkVpcAssociationError, Credentials | HttpClient.HttpClient>;
export type GetTargetGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified target group.
 */
export declare const getTargetGroup: API.OperationMethod<GetTargetGroupRequest & RegionInput, GetTargetGroupResponse, GetTargetGroupError, Credentials | HttpClient.HttpClient>;
export type ListAccessLogSubscriptionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the access log subscriptions for the specified service network or service.
 */
export declare const listAccessLogSubscriptions: API.PaginatedOperationMethod<ListAccessLogSubscriptionsRequest & RegionInput, ListAccessLogSubscriptionsResponse, ListAccessLogSubscriptionsError, Credentials | HttpClient.HttpClient, AccessLogSubscriptionSummary>;
export type ListDomainVerificationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the domain verifications.
 */
export declare const listDomainVerifications: API.PaginatedOperationMethod<ListDomainVerificationsRequest & RegionInput, ListDomainVerificationsResponse, ListDomainVerificationsError, Credentials | HttpClient.HttpClient, DomainVerificationSummary>;
export type ListListenersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the listeners for the specified service.
 */
export declare const listListeners: API.PaginatedOperationMethod<ListListenersRequest & RegionInput, ListListenersResponse, ListListenersError, Credentials | HttpClient.HttpClient, ListenerSummary>;
export type ListResourceConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the resource configurations owned by or shared with this account.
 */
export declare const listResourceConfigurations: API.PaginatedOperationMethod<ListResourceConfigurationsRequest & RegionInput, ListResourceConfigurationsResponse, ListResourceConfigurationsError, Credentials | HttpClient.HttpClient, ResourceConfigurationSummary>;
export type ListResourceEndpointAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations for the specified VPC endpoint.
 */
export declare const listResourceEndpointAssociations: API.PaginatedOperationMethod<ListResourceEndpointAssociationsRequest & RegionInput, ListResourceEndpointAssociationsResponse, ListResourceEndpointAssociationsError, Credentials | HttpClient.HttpClient, ResourceEndpointAssociationSummary>;
export type ListResourceGatewaysError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the resource gateways that you own or that were shared with you.
 */
export declare const listResourceGateways: API.PaginatedOperationMethod<ListResourceGatewaysRequest & RegionInput, ListResourceGatewaysResponse, ListResourceGatewaysError, Credentials | HttpClient.HttpClient, ResourceGatewaySummary>;
export type ListRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the rules for the specified listener.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest & RegionInput, ListRulesResponse, ListRulesError, Credentials | HttpClient.HttpClient, RuleSummary>;
export type ListServiceNetworkResourceAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between a service network and a resource configuration.
 */
export declare const listServiceNetworkResourceAssociations: API.PaginatedOperationMethod<ListServiceNetworkResourceAssociationsRequest & RegionInput, ListServiceNetworkResourceAssociationsResponse, ListServiceNetworkResourceAssociationsError, Credentials | HttpClient.HttpClient, ServiceNetworkResourceAssociationSummary>;
export type ListServiceNetworksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the service networks owned by or shared with this account. The account ID in the ARN shows which account owns the service network.
 */
export declare const listServiceNetworks: API.PaginatedOperationMethod<ListServiceNetworksRequest & RegionInput, ListServiceNetworksResponse, ListServiceNetworksError, Credentials | HttpClient.HttpClient, ServiceNetworkSummary>;
export type ListServiceNetworkServiceAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between a service network and a service. You can filter the list either by service or service network. You must provide either the service network identifier or the service identifier.
 *
 * Every association in Amazon VPC Lattice has a unique Amazon Resource Name (ARN), such as when a service network is associated with a VPC or when a service is associated with a service network. If the association is for a resource is shared with another account, the association includes the local account ID as the prefix in the ARN.
 */
export declare const listServiceNetworkServiceAssociations: API.PaginatedOperationMethod<ListServiceNetworkServiceAssociationsRequest & RegionInput, ListServiceNetworkServiceAssociationsResponse, ListServiceNetworkServiceAssociationsError, Credentials | HttpClient.HttpClient, ServiceNetworkServiceAssociationSummary>;
export type ListServiceNetworkVpcAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between a service network and a VPC. You can filter the list either by VPC or service network. You must provide either the ID of the service network identifier or the ID of the VPC.
 */
export declare const listServiceNetworkVpcAssociations: API.PaginatedOperationMethod<ListServiceNetworkVpcAssociationsRequest & RegionInput, ListServiceNetworkVpcAssociationsResponse, ListServiceNetworkVpcAssociationsError, Credentials | HttpClient.HttpClient, ServiceNetworkVpcAssociationSummary>;
export type ListServiceNetworkVpcEndpointAssociationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between a service network and a VPC endpoint.
 */
export declare const listServiceNetworkVpcEndpointAssociations: API.PaginatedOperationMethod<ListServiceNetworkVpcEndpointAssociationsRequest & RegionInput, ListServiceNetworkVpcEndpointAssociationsResponse, ListServiceNetworkVpcEndpointAssociationsError, Credentials | HttpClient.HttpClient, ServiceNetworkEndpointAssociation>;
export type ListServicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the services owned by the caller account or shared with the caller account.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest & RegionInput, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your target groups. You can narrow your search by using the filters below in your request.
 */
export declare const listTargetGroups: API.PaginatedOperationMethod<ListTargetGroupsRequest & RegionInput, ListTargetGroupsResponse, ListTargetGroupsError, Credentials | HttpClient.HttpClient, TargetGroupSummary>;
export type ListTargetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the targets for the target group. By default, all targets are included. You can use this API to check the health status of targets. You can also U+FB01lter the results by target.
 */
export declare const listTargets: API.PaginatedOperationMethod<ListTargetsRequest & RegionInput, ListTargetsResponse, ListTargetsError, Credentials | HttpClient.HttpClient, TargetSummary>;
export type PutAuthPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the auth policy. The policy string in JSON must not contain newlines or blank lines.
 *
 * For more information, see Auth policies in the *Amazon VPC Lattice User Guide*.
 */
export declare const putAuthPolicy: API.OperationMethod<PutAuthPolicyRequest & RegionInput, PutAuthPolicyResponse, PutAuthPolicyError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches a resource-based permission policy to a service or service network. The policy must contain the same actions and condition statements as the Amazon Web Services Resource Access Manager permission for sharing services and service networks.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterTargetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers the targets with the target group. If it's a Lambda target, you can only have one target in a target group.
 */
export declare const registerTargets: API.OperationMethod<RegisterTargetsRequest & RegionInput, RegisterTargetsResponse, RegisterTargetsError, Credentials | HttpClient.HttpClient>;
export type StartDomainVerificationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the domain verification process for a custom domain name.
 */
export declare const startDomainVerification: API.OperationMethod<StartDomainVerificationRequest & RegionInput, StartDomainVerificationResponse, StartDomainVerificationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessLogSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified access log subscription.
 */
export declare const updateAccessLogSubscription: API.OperationMethod<UpdateAccessLogSubscriptionRequest & RegionInput, UpdateAccessLogSubscriptionResponse, UpdateAccessLogSubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateListenerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified listener for the specified service.
 */
export declare const updateListener: API.OperationMethod<UpdateListenerRequest & RegionInput, UpdateListenerResponse, UpdateListenerError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified resource configuration.
 */
export declare const updateResourceConfiguration: API.OperationMethod<UpdateResourceConfigurationRequest & RegionInput, UpdateResourceConfigurationResponse, UpdateResourceConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceGatewayError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified resource gateway.
 */
export declare const updateResourceGateway: API.OperationMethod<UpdateResourceGatewayRequest & RegionInput, UpdateResourceGatewayResponse, UpdateResourceGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a specified rule for the listener. You can't modify a default listener rule. To modify a default listener rule, use `UpdateListener`.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest & RegionInput, UpdateRuleResponse, UpdateRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest & RegionInput, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified service network.
 */
export declare const updateServiceNetwork: API.OperationMethod<UpdateServiceNetworkRequest & RegionInput, UpdateServiceNetworkResponse, UpdateServiceNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceNetworkVpcAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the service network and VPC association. If you add a security group to the service network and VPC association, the association must continue to have at least one security group. You can add or edit security groups at any time. However, to remove all security groups, you must first delete the association and then recreate it without security groups.
 */
export declare const updateServiceNetworkVpcAssociation: API.OperationMethod<UpdateServiceNetworkVpcAssociationRequest & RegionInput, UpdateServiceNetworkVpcAssociationResponse, UpdateServiceNetworkVpcAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateTargetGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified target group.
 */
export declare const updateTargetGroup: API.OperationMethod<UpdateTargetGroupRequest & RegionInput, UpdateTargetGroupResponse, UpdateTargetGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=vpc-lattice.d.ts.map