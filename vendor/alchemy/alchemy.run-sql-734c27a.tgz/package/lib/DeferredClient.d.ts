import * as Effect from "effect/Effect";
import type * as Scope from "effect/Scope";
import * as SqlClient from "effect/sql/SqlClient";
import { SqlError } from "effect/sql/SqlError";
import * as Statement from "effect/sql/Statement";
type TransformRows = (<A extends object>(rows: ReadonlyArray<A>) => ReadonlyArray<A>) | undefined;
/**
 * What a driver supplies to {@link makeDeferredClient}.
 */
export interface DeferredClientOptions<Client extends SqlClient.SqlClient, E, R> {
    /** The driver name, exposed as `SqlClient.driver`. */
    readonly driver: string;
    /** The driver's statement compiler. Building one is pure, so it exists at Construction phase. */
    readonly compiler: Statement.Compiler;
    /** The driver's result transform (`transformResultNames`), if configured. */
    readonly transformRows?: TransformRows;
    /** Attributes for each statement's span. Only what is known before connecting. */
    readonly spanAttributes: ReadonlyArray<readonly [string, unknown]>;
    /**
     * Opens the driver's real client. Runs at most once per execution, with
     * that execution's `Scope`, so the pool closes when the execution settles.
     */
    readonly connect: Effect.Effect<Client, E, R | Scope.Scope>;
}
/**
 * A `SqlClient` that exists before its database does.
 */
export interface DeferredClient<Client extends SqlClient.SqlClient> {
    /**
     * A real `SqlClient`: statements, fragments and helpers are built and
     * compiled by the driver's own compiler. Only running one reaches the
     * database.
     */
    readonly client: SqlClient.SqlClient;
    /**
     * This execution's real client, opened on first use. A driver forwards its
     * own extras (`PgClient.listen`, `D1Client.batch`) through it.
     */
    readonly connected: Effect.Effect<Client, SqlError>;
}
/**
 * Build a `SqlClient` at Construction phase for a database that can only be
 * reached while handling an event.
 *
 * A Runtime resolves its clients once, at Construction phase, and uses them
 * in every handler. No connection can exist yet: the connection string comes
 * from the Runtime's environment, and a socket belongs to the event that
 * opened it. So the client is split at the one place it does I/O. Everything
 * that builds a query (`` sql`...` ``, `sql.insert`, `sql.and`, an ORM on
 * top) is the driver's real, synchronous code. The `Connection` underneath
 * forwards each compiled statement to the real client, which `connect` opens
 * once per execution.
 *
 * ```typescript
 * const { client, connected } = yield* makeDeferredClient({
 *   driver: "pg",
 *   compiler: PgClient.makeCompiler(),
 *   spanAttributes: [["db.system.name", "postgresql"]],
 *   connect: Effect.flatMap(url, (url) => PgClient.make({ url })),
 * });
 * ```
 *
 * A statement inside `client.withTransaction` runs on the real client's
 * transaction connection, and a nested `withTransaction` is a savepoint on
 * it. A failure of `connect` that isn't a `SqlError` becomes one with a
 * `ConnectionError` reason, because a statement can fail with nothing else.
 *
 * `connect` needs an execution `Scope`, so running a statement outside one
 * is a defect. A `stream` opens its own scope, and so its own client, which
 * closes when the stream ends.
 */
export declare const makeDeferredClient: <Client extends SqlClient.SqlClient, E, R>(options: DeferredClientOptions<Client, E, R>) => Effect.Effect<{
    client: SqlClient.SqlClient;
    connected: Effect.Effect<Client, SqlError, never>;
}, never, never>;
export {};
//# sourceMappingURL=DeferredClient.d.ts.map