import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}>;
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly message: any;
}>;
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const NotAuthorizedException_base: S.TaggedErrorClass<"NotAuthorizedException", {
    readonly message: any;
}>;
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
export type ServiceType = "RDS" | "DOCDB" | (string & {});
export type IdentifierString = string;
export type ISOTimestamp = Date;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreatePerformanceAnalysisReportRequest {
    ServiceType: ServiceType;
    Identifier: string;
    StartTime: Date;
    EndTime?: Date | undefined;
    Tags?: Tag[] | undefined;
}
export type AnalysisReportId = string;
export interface CreatePerformanceAnalysisReportResponse {
    AnalysisReportId?: string | undefined;
}
export interface DeletePerformanceAnalysisReportRequest {
    ServiceType: ServiceType;
    Identifier: string;
    AnalysisReportId: string;
}
export interface DeletePerformanceAnalysisReportResponse {
}
export type RequestString = string;
export type SanitizedString = string;
export type SanitizedStringList = string[];
export type Limit = number;
export interface DimensionGroup {
    Group: string;
    Dimensions?: string[] | undefined;
    Limit?: number | undefined;
}
export type AdditionalMetricsList = string[];
export type MetricQueryFilterMap = {
    [key: string]: string | undefined;
};
export type MaxResults = number;
export type NextToken = string;
export interface DescribeDimensionKeysRequest {
    ServiceType: ServiceType;
    Identifier: string;
    StartTime: Date;
    EndTime: Date;
    Metric: string;
    PeriodInSeconds?: number | undefined;
    GroupBy: DimensionGroup;
    AdditionalMetrics?: string[] | undefined;
    PartitionBy?: DimensionGroup | undefined;
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DimensionMap = {
    [key: string]: string | undefined;
};
export interface ResponsePartitionKey {
    Dimensions: {
        [key: string]: string | undefined;
    };
}
export type ResponsePartitionKeyList = ResponsePartitionKey[];
export type AdditionalMetricsMap = {
    [key: string]: number | undefined;
};
export type MetricValuesList = number[];
export interface DimensionKeyDescription {
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    Total?: number | undefined;
    AdditionalMetrics?: {
        [key: string]: number | undefined;
    } | undefined;
    Partitions?: number[] | undefined;
}
export type DimensionKeyDescriptionList = DimensionKeyDescription[];
export interface DescribeDimensionKeysResponse {
    AlignedStartTime?: Date | undefined;
    AlignedEndTime?: Date | undefined;
    PartitionKeys?: ResponsePartitionKey[] | undefined;
    Keys?: DimensionKeyDescription[] | undefined;
    NextToken?: string | undefined;
}
export type RequestedDimensionList = string[];
export interface GetDimensionKeyDetailsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    Group: string;
    GroupIdentifier: string;
    RequestedDimensions?: string[] | undefined;
}
export type DetailStatus = "AVAILABLE" | "PROCESSING" | "UNAVAILABLE" | (string & {});
export interface DimensionKeyDetail {
    Value?: string | undefined;
    Dimension?: string | undefined;
    Status?: DetailStatus | undefined;
}
export type DimensionKeyDetailList = DimensionKeyDetail[];
export interface GetDimensionKeyDetailsResponse {
    Dimensions?: DimensionKeyDetail[] | undefined;
}
export type TextFormat = "PLAIN_TEXT" | "MARKDOWN" | (string & {});
export type AcceptLanguage = "EN_US" | (string & {});
export interface GetPerformanceAnalysisReportRequest {
    ServiceType: ServiceType;
    Identifier: string;
    AnalysisReportId: string;
    TextFormat?: TextFormat | undefined;
    AcceptLanguage?: AcceptLanguage | undefined;
}
export type AnalysisStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export type ContextType = "CAUSAL" | "CONTEXTUAL" | (string & {});
export type Severity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type MarkdownString = string | redacted.Redacted<string>;
export interface Recommendation {
    RecommendationId?: string | undefined;
    RecommendationDescription?: string | redacted.Redacted<string> | undefined;
    RecommendationDetails?: string | redacted.Redacted<string> | undefined;
}
export type RecommendationList = Recommendation[];
export type DescriptiveString = string;
export type DescriptiveMap = {
    [key: string]: string | undefined;
};
export interface PerformanceInsightsMetric {
    Metric?: string | undefined;
    DisplayName?: string | undefined;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
    Value?: number | undefined;
}
export interface Data {
    PerformanceInsightsMetric?: PerformanceInsightsMetric | undefined;
}
export type DataList = Data[];
export interface Insight {
    InsightId: string;
    InsightType?: string | undefined;
    Context?: ContextType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Severity?: Severity | undefined;
    SupportingInsights?: Insight[] | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Recommendations?: Recommendation[] | undefined;
    InsightData?: Data[] | undefined;
    BaselineData?: Data[] | undefined;
}
export type InsightList = Insight[];
export interface AnalysisReport {
    AnalysisReportId: string;
    Identifier?: string | undefined;
    ServiceType?: ServiceType | undefined;
    CreateTime?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Status?: AnalysisStatus | undefined;
    Insights?: Insight[] | undefined;
}
export interface GetPerformanceAnalysisReportResponse {
    AnalysisReport?: AnalysisReport | undefined;
}
export interface GetResourceMetadataRequest {
    ServiceType: ServiceType;
    Identifier: string;
}
export type FeatureStatus = "ENABLED" | "DISABLED" | "UNSUPPORTED" | "ENABLED_PENDING_REBOOT" | "DISABLED_PENDING_REBOOT" | "UNKNOWN" | (string & {});
export interface FeatureMetadata {
    Status?: FeatureStatus | undefined;
}
export type FeatureMetadataMap = {
    [key: string]: FeatureMetadata | undefined;
};
export interface GetResourceMetadataResponse {
    Identifier?: string | undefined;
    Features?: {
        [key: string]: FeatureMetadata | undefined;
    } | undefined;
}
export interface MetricQuery {
    Metric: string;
    GroupBy?: DimensionGroup | undefined;
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MetricQueryList = MetricQuery[];
export type PeriodAlignment = "END_TIME" | "START_TIME" | (string & {});
export interface GetResourceMetricsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    MetricQueries: MetricQuery[];
    StartTime: Date;
    EndTime: Date;
    PeriodInSeconds?: number | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    PeriodAlignment?: PeriodAlignment | undefined;
}
export interface ResponseResourceMetricKey {
    Metric: string;
    Dimensions?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DataPoint {
    Timestamp: Date;
    Value: number;
}
export type DataPointsList = DataPoint[];
export interface MetricKeyDataPoints {
    Key?: ResponseResourceMetricKey | undefined;
    DataPoints?: DataPoint[] | undefined;
}
export type MetricKeyDataPointsList = MetricKeyDataPoints[];
export interface GetResourceMetricsResponse {
    AlignedStartTime?: Date | undefined;
    AlignedEndTime?: Date | undefined;
    Identifier?: string | undefined;
    MetricList?: MetricKeyDataPoints[] | undefined;
    NextToken?: string | undefined;
}
export type DimensionsMetricList = string[];
export type FineGrainedAction = "DescribeDimensionKeys" | "GetDimensionKeyDetails" | "GetResourceMetrics" | (string & {});
export type AuthorizedActionsList = FineGrainedAction[];
export interface ListAvailableResourceDimensionsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    Metrics: string[];
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AuthorizedActions?: FineGrainedAction[] | undefined;
}
export interface DimensionDetail {
    Identifier?: string | undefined;
}
export type DimensionDetailList = DimensionDetail[];
export interface DimensionGroupDetail {
    Group?: string | undefined;
    Dimensions?: DimensionDetail[] | undefined;
}
export type DimensionGroupDetailList = DimensionGroupDetail[];
export interface MetricDimensionGroups {
    Metric?: string | undefined;
    Groups?: DimensionGroupDetail[] | undefined;
}
export type MetricDimensionsList = MetricDimensionGroups[];
export interface ListAvailableResourceDimensionsResponse {
    MetricDimensions?: MetricDimensionGroups[] | undefined;
    NextToken?: string | undefined;
}
export type MetricTypeList = string[];
export interface ListAvailableResourceMetricsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    MetricTypes: string[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Description = string;
export interface ResponseResourceMetric {
    Metric?: string | undefined;
    Description?: string | undefined;
    Unit?: string | undefined;
}
export type ResponseResourceMetricList = ResponseResourceMetric[];
export interface ListAvailableResourceMetricsResponse {
    Metrics?: ResponseResourceMetric[] | undefined;
    NextToken?: string | undefined;
}
export type RecommendationIdList = string[];
export interface ListPerformanceAnalysisReportRecommendationsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    AnalysisReportId: string;
    RecommendationIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListPerformanceAnalysisReportRecommendationsResponse {
    Recommendations?: Recommendation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPerformanceAnalysisReportsRequest {
    ServiceType: ServiceType;
    Identifier: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ListTags?: boolean | undefined;
}
export interface AnalysisReportSummary {
    AnalysisReportId?: string | undefined;
    CreateTime?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Status?: AnalysisStatus | undefined;
    Tags?: Tag[] | undefined;
}
export type AnalysisReportSummaryList = AnalysisReportSummary[];
export interface ListPerformanceAnalysisReportsResponse {
    AnalysisReports?: AnalysisReportSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ServiceType: ServiceType;
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface TagResourceRequest {
    ServiceType: ServiceType;
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ServiceType: ServiceType;
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ErrorString = string;
export type CreatePerformanceAnalysisReportError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Creates a new performance analysis report for a specific time period for the
 * DB instance.
 */
export declare const createPerformanceAnalysisReport: API.OperationMethod<CreatePerformanceAnalysisReportRequest & RegionInput, CreatePerformanceAnalysisReportResponse, CreatePerformanceAnalysisReportError, Credentials | HttpClient.HttpClient>;
export type DeletePerformanceAnalysisReportError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Deletes a performance analysis report.
 */
export declare const deletePerformanceAnalysisReport: API.OperationMethod<DeletePerformanceAnalysisReportRequest & RegionInput, DeletePerformanceAnalysisReportResponse, DeletePerformanceAnalysisReportError, Credentials | HttpClient.HttpClient>;
export type DescribeDimensionKeysError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * For a specific time period, retrieve the top `N` dimension keys for a metric.
 *
 * Each response element returns a maximum of 500 bytes. For larger elements, such as SQL statements,
 * only the first 500 bytes are returned.
 */
export declare const describeDimensionKeys: API.PaginatedOperationMethod<DescribeDimensionKeysRequest & RegionInput, DescribeDimensionKeysResponse, DescribeDimensionKeysError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDimensionKeyDetailsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Get the attributes of the specified dimension group for a DB instance or data source. For example, if you specify a SQL ID,
 * `GetDimensionKeyDetails` retrieves the full text of the dimension `db.sql.statement` associated with this ID.
 * This operation is useful because `GetResourceMetrics` and `DescribeDimensionKeys` don't support retrieval of large
 * SQL statement text, lock snapshots, and execution plans.
 */
export declare const getDimensionKeyDetails: API.OperationMethod<GetDimensionKeyDetailsRequest & RegionInput, GetDimensionKeyDetailsResponse, GetDimensionKeyDetailsError, Credentials | HttpClient.HttpClient>;
export type GetPerformanceAnalysisReportError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieves the report including the report ID, status, time details, and the insights
 * with recommendations. The report status can be `RUNNING`,
 * `SUCCEEDED`, or `FAILED`. The insights include the
 * `description` and `recommendation` fields.
 */
export declare const getPerformanceAnalysisReport: API.OperationMethod<GetPerformanceAnalysisReportRequest & RegionInput, GetPerformanceAnalysisReportResponse, GetPerformanceAnalysisReportError, Credentials | HttpClient.HttpClient>;
export type GetResourceMetadataError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieve the metadata for different features. For example, the metadata might indicate
 * that a feature is turned on or off on a specific DB instance.
 */
export declare const getResourceMetadata: API.OperationMethod<GetResourceMetadataRequest & RegionInput, GetResourceMetadataResponse, GetResourceMetadataError, Credentials | HttpClient.HttpClient>;
export type GetResourceMetricsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieve Performance Insights metrics for a set of data sources over a time period. You can provide
 * specific dimension groups and dimensions, and provide filtering criteria for each group. You must specify an aggregate function for
 * each metric.
 *
 * Each response element returns a maximum of 500 bytes. For larger elements, such as SQL statements,
 * only the first 500 bytes are returned.
 */
export declare const getResourceMetrics: API.PaginatedOperationMethod<GetResourceMetricsRequest & RegionInput, GetResourceMetricsResponse, GetResourceMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAvailableResourceDimensionsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieve the dimensions that can be queried for each specified metric type on a specified DB instance.
 */
export declare const listAvailableResourceDimensions: API.PaginatedOperationMethod<ListAvailableResourceDimensionsRequest & RegionInput, ListAvailableResourceDimensionsResponse, ListAvailableResourceDimensionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAvailableResourceMetricsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieve metrics of the specified types that can be queried for a specified DB instance.
 */
export declare const listAvailableResourceMetrics: API.PaginatedOperationMethod<ListAvailableResourceMetricsRequest & RegionInput, ListAvailableResourceMetricsResponse, ListAvailableResourceMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPerformanceAnalysisReportRecommendationsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieves recommendations for a performance analysis report.
 */
export declare const listPerformanceAnalysisReportRecommendations: API.PaginatedOperationMethod<ListPerformanceAnalysisReportRecommendationsRequest & RegionInput, ListPerformanceAnalysisReportRecommendationsResponse, ListPerformanceAnalysisReportRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type ListPerformanceAnalysisReportsError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Lists all the analysis reports created for the DB instance. The reports are sorted based on the start time of each report.
 */
export declare const listPerformanceAnalysisReports: API.PaginatedOperationMethod<ListPerformanceAnalysisReportsRequest & RegionInput, ListPerformanceAnalysisReportsResponse, ListPerformanceAnalysisReportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Retrieves all the metadata tags associated with Amazon RDS Performance Insights resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Adds metadata tags to the Amazon RDS Performance Insights resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | InvalidArgumentException | NotAuthorizedException | CommonErrors;
/**
 * Deletes the metadata tags from the Amazon RDS Performance Insights resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pi.d.ts.map