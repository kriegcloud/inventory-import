export * from "@distilled.cloud/s3/Traits";
export * from "./protocol-traits.ts";
//# sourceMappingURL=traits.d.ts.map