import type { Kit, Model } from "../Kit.ts";
import type { V } from "../Value.ts";
/**
 * Strings: the methods of a string, and `effect/String`, which is the same
 * methods as functions. A string the prover knows is computed as JavaScript
 * computes it; one an input holds is the solver's, which knows what a string
 * starts with, ends with and holds, how long it is, and parts of it.
 */
export declare const make: (kit: Kit) => {
    models: Readonly<Record<string, Model>>;
    values: Record<string, V>;
    member: (self: V, key: string) => V | undefined;
    names: string[];
};
//# sourceMappingURL=Strings.d.ts.map