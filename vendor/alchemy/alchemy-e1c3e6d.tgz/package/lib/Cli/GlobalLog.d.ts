import * as GlobalFlag from "effect/cli/GlobalFlag";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Logger from "effect/Logger";
import * as LogLevel from "effect/LogLevel";
import * as Option from "effect/Option";
import { Path } from "effect/Path";
/**
 * `--log-level`: the lowest level printed on the console. Registered on the
 * CLI root in place of Effect's built-in flag, which also lowers the
 * minimum log level and so would drop records from the run log; the run
 * log records Debug whatever the console shows.
 */
export declare const LogLevelFlag: GlobalFlag.Setting<"log-level", Option.Option<LogLevel.LogLevel>>;
/** How the terminal shows log records. */
export type LogFormat = "pretty" | "json";
/**
 * `--log-format pretty|json`: `json` prints one {@link LogRecord} per line
 * on stdout and leaves rendering to the reader; errors stay text on stderr. Registered on the CLI root;
 * the console logger reads the parsed value (see {@link consoleSettings}).
 */
export declare const LogFormatFlag: GlobalFlag.Setting<"log-format", Option.Option<"json" | "pretty">>;
/** What the console shows, and how. */
export interface ConsoleSettings {
    /** Records below this level stay in the run log only. */
    readonly floor: LogLevel.LogLevel;
    readonly format: LogFormat;
}
/**
 * The console settings in `context`: the parsed `--log-level` and
 * `--log-format` flags inside a command, and otherwise (before the command
 * line is parsed, or in a child process that never sees it) the `ALCHEMY_LOG_*` environment variables. The console keeps its
 * usual Info+ noise floor by default; the run log captures Debug regardless
 * (#1231).
 */
export declare const consoleSettings: (context: Context.Context<never>) => ConsoleSettings;
/** The current fiber's {@link consoleSettings}. */
export declare const currentConsoleSettings: Effect.Effect<ConsoleSettings>;
/** {@link ConsoleSettings} as environment, for a child process that renders the run's logs. */
export declare const consoleSettingsEnv: (settings: ConsoleSettings) => Record<string, string>;
/**
 * Terminal sink: forwards records at or above the logging fiber's
 * {@link consoleSettings} floor to `sink`, or to the sink its settings
 * select.
 */
export declare const makeConsoleLogger: (sink?: Logger.Logger<unknown, void>) => Logger.Logger<unknown, void>;
/** Shared terminal logger for CLI entrypoints that do not need a run file. */
export declare const ConsoleLogLive: Layer.Layer<never, never, never>;
/**
 * The run log's file logger alone. The run log is the only log file: the
 * top-level CLI process writes it, and records its children already showed
 * on the terminal (the `alchemy dev` exec child's) go here without being
 * printed again.
 */
export declare const RunLog: Context.Reference<Logger.Logger<unknown, void>>;
/**
 * A run log file that is created on its first record, so a run that sends
 * nothing to it leaves nothing behind (and a `profile` command run outside
 * a project never creates a `.alchemy` there). The file starts with a `run`
 * record describing the run, so it reads standalone.
 *
 * A logger is called synchronously but the file is written asynchronously,
 * so the logger only queues each record as a JSON line, and one writer fiber
 * creates the file on the first line and appends the rest. Closing the log
 * ends the queue and waits for the writer, so no queued record is lost.
 *
 * @internal exported for tests.
 */
export declare const lazyRunLog: (dir: string, name: string, scope: "global" | "project") => Effect.Effect<Logger.Logger<unknown, void>, never, FileSystem.FileSystem | Path | import("effect/Scope").Scope>;
/**
 * The two run logs: records scoped `global` (the state store, auth,
 * profiles; see `globalLogs`) go to `~/.alchemy/logs` (relocated by
 * `ALCHEMY_HOME`), everything else to the project's `.alchemy/log`. Every
 * run writes `{timestamp}-pid{pid}.ndjson` (NDJSON log records) at Debug
 * level — failures record their full causes there even though the terminal
 * only shows the friendly message. Console output stays at Info+ unless
 * `--log-level` lowers the floor (see {@link consoleSettings}).
 *
 * Only the top-level CLI process writes them; its children's records reach
 * them through it. Commands that install their own loggers with
 * `mergeWithExisting: true` compose with these; a replacing `Logger.layer`
 * scopes them out for that subtree only.
 */
export declare const GlobalLogLive: Layer.Layer<never, never, FileSystem.FileSystem | Path>;
//# sourceMappingURL=GlobalLog.d.ts.map