/**
 * The `Credentials` service every operation signs with (from
 * `@distilled.cloud/s3`), the errors AWS's providers can fail with, and
 * `createLazyProvider`, which turns a credential source into a cached
 * `Credentials` layer. Each provider under `credential-providers/` builds its
 * layer from this module.
 */
import { Credentials, type ResolvedCredentials } from "@distilled.cloud/s3/Credentials";
import type { SourceError } from "effect/ConfigProvider";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type { HttpClientError } from "effect/http/HttpClientError";
import * as Layer from "effect/Layer";
import type { PlatformError } from "effect/PlatformError";
import type { CredentialSource } from "./credential-providers/credential-source.ts";
import { MissingRegion } from "./region.ts";
import type { RegionName } from "./region.ts";
export * from "@distilled.cloud/s3/Credentials";
/**
 * AWS credentials as a credential source returns them -- the same shape as
 * `AwsCredentialIdentity` in `@smithy/types`, so identities from the AWS SDK
 * are accepted as they are.
 */
export interface AwsCredentialIdentity {
    readonly accessKeyId: string;
    readonly secretAccessKey: string;
    readonly sessionToken?: string;
    readonly credentialScope?: string;
    readonly accountId?: string;
    /** When the credentials stop being accepted. */
    readonly expiration?: Date;
}
export interface AwsCredentials {
    readonly accessKeyId: string;
    readonly secretAccessKey: string;
    readonly sessionToken?: string;
}
/**
 * Error types that can occur during credential resolution.
 */
export type CredentialsError = AwsCredentialProviderError | MissingRegion | ProfileNotFound | SharedConfigError | InvalidSSOProfile | InvalidSSOToken | ExpiredSSOToken | ConflictingSSORegion | ConflictingSSOStartUrl | SsoPortalError | HttpClientError | PlatformError;
declare module "@distilled.cloud/s3/Credentials" {
    interface ProviderErrors {
        aws: CredentialsError | SourceError;
    }
}
export declare const mock: Layer.Layer<Credentials, never, never>;
/**
 * Create resolved credentials from an AWS credential identity.
 *
 * The identity carries no region -- `AwsCredentialIdentity` never has one --
 * so the provider that resolved it supplies the region it authenticated
 * against.
 */
export declare const fromAwsCredentialIdentity: (identity: AwsCredentialIdentity, region: RegionName) => ResolvedCredentials;
export { MissingRegion };
/**
 * The region a credentials provider authenticated against, from the
 * environment. Node providers that read a profile override this with the
 * profile's own region.
 */
export declare const regionFromEnv: Effect.Effect<RegionName, MissingRegion, never>;
/**
 * Create a credentials effect with lazy resolution and expiration-aware caching.
 * Uses Effect.cachedWithTTL where the TTL is computed from the credentials' expiration.
 */
export declare const createCachedCredentialsEffect: <E, R>(resolve: Effect.Effect<ResolvedCredentials, E, R>) => Effect.Effect<ResolvedCredentials, E, R>;
/**
 * Create a lazy, cached credentials layer from a credential source.
 * Credentials are resolved on first access and cached based on their expiration time.
 */
export declare const createLazyProvider: (source: CredentialSource, providerName: string, 
/** What to tell the caller when the source fails. */
hints: ReadonlyArray<string>, 
/**
 * Where this provider's region comes from. Defaults to the environment;
 * providers that read a profile pass the profile's region instead.
 */
region?: Effect.Effect<RegionName, CredentialsError>) => Layer.Layer<Credentials>;
export declare const ssoRegion: (region: string) => Layer.Layer<SsoRegion, never, never>;
declare const SsoRegion_base: Context.ServiceClass<SsoRegion, "AWS::SsoRegion", string>;
export declare class SsoRegion extends /*@__PURE__*/ SsoRegion_base {
}
declare const SsoStartUrl_base: Context.ServiceClass<SsoStartUrl, "AWS::SsoStartUrl", string>;
export declare class SsoStartUrl extends /*@__PURE__*/ SsoStartUrl_base {
}
declare const ProfileNotFound_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ProfileNotFound";
} & Readonly<A>;
export declare class ProfileNotFound extends /*@__PURE__*/ ProfileNotFound_base<{
    message: string;
    profile: string;
}> {
}
declare const SharedConfigError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::SharedConfigError";
} & Readonly<A>;
/** A shared config or credentials file exists but cannot be read or parsed. */
export declare class SharedConfigError extends /*@__PURE__*/ SharedConfigError_base<{
    message: string;
    path: string;
    cause?: unknown;
}> {
}
declare const ConflictingSSORegion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ConflictingSSORegion";
} & Readonly<A>;
export declare class ConflictingSSORegion extends /*@__PURE__*/ ConflictingSSORegion_base<{
    message: string;
    ssoRegion: string;
    profile: string;
}> {
}
declare const ConflictingSSOStartUrl_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ConflictingSSOStartUrl";
} & Readonly<A>;
export declare class ConflictingSSOStartUrl extends /*@__PURE__*/ ConflictingSSOStartUrl_base<{
    message: string;
    ssoStartUrl: string;
    profile: string;
}> {
}
declare const InvalidSSOProfile_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::InvalidSSOProfile";
} & Readonly<A>;
export declare class InvalidSSOProfile extends /*@__PURE__*/ InvalidSSOProfile_base<{
    message: string;
    profile: string;
    missingFields: string[];
}> {
}
declare const InvalidSSOToken_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::InvalidSSOToken";
} & Readonly<A>;
export declare class InvalidSSOToken extends /*@__PURE__*/ InvalidSSOToken_base<{
    message: string;
    sso_session: string;
}> {
}
declare const ExpiredSSOToken_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::ExpiredSSOToken";
} & Readonly<A>;
export declare class ExpiredSSOToken extends /*@__PURE__*/ ExpiredSSOToken_base<{
    message: string;
    profile: string;
    /** The failed SSO OIDC refresh, when one was attempted. */
    cause?: unknown;
}> {
}
declare const AwsCredentialProviderError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AWS::CredentialProviderError";
} & Readonly<A>;
export declare class AwsCredentialProviderError extends /*@__PURE__*/ AwsCredentialProviderError_base<{
    message: string;
    provider: string;
    cause?: unknown;
    hints?: ReadonlyArray<string>;
}> {
}
declare const SsoPortalError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Alchemy::AWS::SsoPortalError";
} & Readonly<A>;
/**
 * The AWS SSO portal returned a response with no `roleCredentials`, e.g. a
 * `ForbiddenException` when an IAM Identity Center role assignment is in a
 * stale state.
 */
export declare class SsoPortalError extends /*@__PURE__*/ SsoPortalError_base<{
    message: string;
    profile: string;
    account_id?: string;
    role_name?: string;
    status?: number;
}> {
}
//# sourceMappingURL=credentials-service.d.ts.map