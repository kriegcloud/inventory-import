import type * as cf from "@cloudflare/workers-types";
import * as Effect from "effect/Effect";
declare const UnsupportedAlarmSchemaVersion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "UnsupportedAlarmSchemaVersion";
} & Readonly<A>;
export declare class UnsupportedAlarmSchemaVersion extends UnsupportedAlarmSchemaVersion_base<{
    readonly version: number;
    readonly supportedVersion: number;
}> {
}
export declare const ensureAlarmTables: (storage: cf.DurableObjectStorage) => Effect.Effect<void, never, never>;
export declare const reconcileDurableObjectAlarm: (storage: cf.DurableObjectStorage) => Effect.Effect<void, never, never>;
export {};
//# sourceMappingURL=DurableObjectAlarmStorage.d.ts.map