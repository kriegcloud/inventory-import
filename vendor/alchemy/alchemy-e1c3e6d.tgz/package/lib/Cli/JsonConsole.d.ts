import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
/** `effect` with stdout captured as log records, when the console is JSON. */
export declare const captureStdoutAround: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/**
 * The JSON renderer ({@link selectRenderer}), with stdout captured, over
 * whatever renderer is already provided, when the console is JSON. Effect CLI provides parsed flags to
 * command handlers only, so the CLI provides this on its root command
 * (`Command.provide`), where `--log-format` and the CLI's loggers are known.
 */
export declare const override: Layer.Layer<never, never, import("effect/cli/Prompt").Environment>;
//# sourceMappingURL=JsonConsole.d.ts.map