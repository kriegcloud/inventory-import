/**
 * The workerd flavor of the Durable Object bridge, shared by every engine
 * whose objects follow the Workers API (Cloudflare today): the exported
 * `DurableObject` subclass that turns workerd's lifecycle and JSRPC calls
 * into Effect calls on the engine-invariant instance core.
 *
 * @internal
 */
import type * as cf from "@cloudflare/workers-types";
import * as Context from "effect/Context";
import * as Option from "effect/Option";
import type * as Tracer from "effect/Tracer";
import type { DurableObjectExport } from "../DurableObject.ts";
import type { Pin, WorkerBuild } from "../Worker.ts";
/** workerd's `DurableObject` base class. */
export type WorkerdDurableObjectClass = abstract new (state: any, env: any) => object;
export interface DurableObjectBridgeOptions {
    /**
     * How RPC reaches the instance. `"proxy"` (workerd) resolves methods
     * through the class's `Proxy`; `"static"` materializes them as real
     * methods and serves fetch-RPC over the object's own `fetch`. See
     * `DurableObjectInstanceOptions.dispatch`.
     * @default "proxy"
     */
    readonly dispatch?: "proxy" | "static";
}
export interface WorkerdDurableObjectBridgeOptions {
    /** Resolve a class export against the engine's shared build. */
    readonly getExport: (className: string) => {
        readonly build: (pin: Pin) => Promise<WorkerBuild<DurableObjectExport, any>>;
    };
    /** The engine's Durable Object state service for one instance. */
    readonly services: (state: cf.DurableObjectState, env: Record<string, unknown>) => Context.Context<never>;
    /**
     * Split what the engine's stubs append to an RPC call's arguments (the
     * caller's trace context) off the arguments, returning the call's parent
     * span when there is one.
     */
    readonly rpcArgs?: (args: ReadonlyArray<unknown>) => readonly [args: ReadonlyArray<unknown>, parent: Option.Option<Tracer.AnySpan>];
}
/**
 * Create a DurableObjectBridge class that proxies RPC method calls through
 * the Effect runtime, encoding success/fail/stream results as RPC envelopes.
 */
export declare const makeDurableObjectBridge: (DurableObject: WorkerdDurableObjectClass, adapter: WorkerdDurableObjectBridgeOptions) => (className: string, options?: DurableObjectBridgeOptions) => any;
//# sourceMappingURL=DurableObjectBridge.d.ts.map