import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly errorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceName: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceName: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type AwsAccountId = string;
export type AccountList = string[];
export type Region = string;
export type RegionList = string[];
export type AwsLogSourceName = "ROUTE53" | "VPC_FLOW" | "SH_FINDINGS" | "CLOUD_TRAIL_MGMT" | "LAMBDA_EXECUTION" | "S3_DATA" | "EKS_AUDIT" | "WAF" | (string & {});
export type AwsLogSourceVersion = string;
export interface AwsLogSourceConfiguration {
    accounts?: string[] | undefined;
    regions: string[];
    sourceName: AwsLogSourceName;
    sourceVersion?: string | undefined;
}
export type AwsLogSourceConfigurationList = AwsLogSourceConfiguration[];
export interface CreateAwsLogSourceRequest {
    sources: AwsLogSourceConfiguration[];
}
export interface CreateAwsLogSourceResponse {
    failed?: string[] | undefined;
}
export type CustomLogSourceName = string;
export type CustomLogSourceVersion = string;
export type OcsfEventClass = string;
export type OcsfEventClassList = string[];
export type RoleArn = string;
export interface CustomLogSourceCrawlerConfiguration {
    roleArn: string;
}
export type AwsPrincipal = string;
export type ExternalId = string;
export interface AwsIdentity {
    principal: string;
    externalId: string;
}
export interface CustomLogSourceConfiguration {
    crawlerConfiguration: CustomLogSourceCrawlerConfiguration;
    providerIdentity: AwsIdentity;
}
export interface CreateCustomLogSourceRequest {
    sourceName: string;
    sourceVersion?: string | undefined;
    eventClasses?: string[] | undefined;
    configuration: CustomLogSourceConfiguration;
}
export type S3URI = string;
export interface CustomLogSourceProvider {
    roleArn?: string | undefined;
    location?: string | undefined;
}
export type AmazonResourceName = string;
export interface CustomLogSourceAttributes {
    crawlerArn?: string | undefined;
    databaseArn?: string | undefined;
    tableArn?: string | undefined;
}
export interface CustomLogSourceResource {
    sourceName?: string | undefined;
    sourceVersion?: string | undefined;
    provider?: CustomLogSourceProvider | undefined;
    attributes?: CustomLogSourceAttributes | undefined;
}
export interface CreateCustomLogSourceResponse {
    source?: CustomLogSourceResource | undefined;
}
export interface DataLakeEncryptionConfiguration {
    kmsKeyId?: string | undefined;
}
export interface DataLakeLifecycleExpiration {
    days?: number | undefined;
}
export type DataLakeStorageClass = string;
export interface DataLakeLifecycleTransition {
    storageClass?: string | undefined;
    days?: number | undefined;
}
export type DataLakeLifecycleTransitionList = DataLakeLifecycleTransition[];
export interface DataLakeLifecycleConfiguration {
    expiration?: DataLakeLifecycleExpiration | undefined;
    transitions?: DataLakeLifecycleTransition[] | undefined;
}
export interface DataLakeReplicationConfiguration {
    regions?: string[] | undefined;
    roleArn?: string | undefined;
}
export interface DataLakeConfiguration {
    region: string;
    encryptionConfiguration?: DataLakeEncryptionConfiguration | undefined;
    lifecycleConfiguration?: DataLakeLifecycleConfiguration | undefined;
    replicationConfiguration?: DataLakeReplicationConfiguration | undefined;
}
export type DataLakeConfigurationList = DataLakeConfiguration[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateDataLakeRequest {
    configurations: DataLakeConfiguration[];
    metaStoreManagerRoleArn: string;
    tags?: Tag[] | undefined;
}
export type S3BucketArn = string;
export type DataLakeStatus = "INITIALIZED" | "PENDING" | "COMPLETED" | "FAILED" | (string & {});
export interface DataLakeUpdateException {
    reason?: string | undefined;
    code?: string | undefined;
}
export interface DataLakeUpdateStatus {
    requestId?: string | undefined;
    status?: DataLakeStatus | undefined;
    exception?: DataLakeUpdateException | undefined;
}
export interface DataLakeResource {
    dataLakeArn: string;
    region: string;
    s3BucketArn?: string | undefined;
    encryptionConfiguration?: DataLakeEncryptionConfiguration | undefined;
    lifecycleConfiguration?: DataLakeLifecycleConfiguration | undefined;
    replicationConfiguration?: DataLakeReplicationConfiguration | undefined;
    createStatus?: DataLakeStatus | undefined;
    updateStatus?: DataLakeUpdateStatus | undefined;
}
export type DataLakeResourceList = DataLakeResource[];
export interface CreateDataLakeResponse {
    dataLakes?: DataLakeResource[] | undefined;
}
export type SubscriptionProtocol = string;
export type SafeString = string;
export interface CreateDataLakeExceptionSubscriptionRequest {
    subscriptionProtocol: string;
    notificationEndpoint: string;
    exceptionTimeToLive?: number | undefined;
}
export interface CreateDataLakeExceptionSubscriptionResponse {
}
export interface AwsLogSourceResource {
    sourceName?: AwsLogSourceName | undefined;
    sourceVersion?: string | undefined;
}
export type AwsLogSourceResourceList = AwsLogSourceResource[];
export interface DataLakeAutoEnableNewAccountConfiguration {
    region: string;
    sources: AwsLogSourceResource[];
}
export type DataLakeAutoEnableNewAccountConfigurationList = DataLakeAutoEnableNewAccountConfiguration[];
export interface CreateDataLakeOrganizationConfigurationRequest {
    autoEnableNewAccount?: DataLakeAutoEnableNewAccountConfiguration[] | undefined;
}
export interface CreateDataLakeOrganizationConfigurationResponse {
}
export type DescriptionString = string;
export type LogSourceResource = {
    awsLogSource: AwsLogSourceResource;
    customLogSource?: undefined;
} | {
    awsLogSource?: undefined;
    customLogSource: CustomLogSourceResource;
};
export type LogSourceResourceList = LogSourceResource[];
export type AccessType = "LAKEFORMATION" | "S3" | (string & {});
export type AccessTypeList = AccessType[];
export interface CreateSubscriberRequest {
    subscriberIdentity: AwsIdentity;
    subscriberName: string;
    subscriberDescription?: string | undefined;
    sources: LogSourceResource[];
    accessTypes?: AccessType[] | undefined;
    tags?: Tag[] | undefined;
}
export type UUID = string;
export type SubscriberStatus = "ACTIVE" | "DEACTIVATED" | "PENDING" | "READY" | (string & {});
export type ResourceShareArn = string;
export type ResourceShareName = string;
export interface SubscriberResource {
    subscriberId: string;
    subscriberArn: string;
    subscriberIdentity: AwsIdentity;
    subscriberName: string;
    subscriberDescription?: string | undefined;
    sources: LogSourceResource[];
    accessTypes?: AccessType[] | undefined;
    roleArn?: string | undefined;
    s3BucketArn?: string | undefined;
    subscriberEndpoint?: string | undefined;
    subscriberStatus?: SubscriberStatus | undefined;
    resourceShareArn?: string | undefined;
    resourceShareName?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateSubscriberResponse {
    subscriber?: SubscriberResource | undefined;
}
export interface SqsNotificationConfiguration {
}
export type HttpMethod = "POST" | "PUT" | (string & {});
export interface HttpsNotificationConfiguration {
    endpoint: string;
    authorizationApiKeyName?: string | undefined;
    authorizationApiKeyValue?: string | redacted.Redacted<string> | undefined;
    httpMethod?: HttpMethod | undefined;
    targetRoleArn: string;
}
export type NotificationConfiguration = {
    sqsNotificationConfiguration: SqsNotificationConfiguration;
    httpsNotificationConfiguration?: undefined;
} | {
    sqsNotificationConfiguration?: undefined;
    httpsNotificationConfiguration: HttpsNotificationConfiguration;
};
export interface CreateSubscriberNotificationRequest {
    subscriberId: string;
    configuration: NotificationConfiguration;
}
export interface CreateSubscriberNotificationResponse {
    subscriberEndpoint?: string | undefined;
}
export interface DeleteAwsLogSourceRequest {
    sources: AwsLogSourceConfiguration[];
}
export interface DeleteAwsLogSourceResponse {
    failed?: string[] | undefined;
}
export interface DeleteCustomLogSourceRequest {
    sourceName: string;
    sourceVersion?: string | undefined;
}
export interface DeleteCustomLogSourceResponse {
}
export interface DeleteDataLakeRequest {
    regions: string[];
}
export interface DeleteDataLakeResponse {
}
export interface DeleteDataLakeExceptionSubscriptionRequest {
}
export interface DeleteDataLakeExceptionSubscriptionResponse {
}
export interface DeleteDataLakeOrganizationConfigurationRequest {
    autoEnableNewAccount?: DataLakeAutoEnableNewAccountConfiguration[] | undefined;
}
export interface DeleteDataLakeOrganizationConfigurationResponse {
}
export interface DeleteSubscriberRequest {
    subscriberId: string;
}
export interface DeleteSubscriberResponse {
}
export interface DeleteSubscriberNotificationRequest {
    subscriberId: string;
}
export interface DeleteSubscriberNotificationResponse {
}
export interface DeregisterDataLakeDelegatedAdministratorRequest {
}
export interface DeregisterDataLakeDelegatedAdministratorResponse {
}
export interface GetDataLakeExceptionSubscriptionRequest {
}
export interface GetDataLakeExceptionSubscriptionResponse {
    subscriptionProtocol?: string | undefined;
    notificationEndpoint?: string | undefined;
    exceptionTimeToLive?: number | undefined;
}
export interface GetDataLakeOrganizationConfigurationRequest {
}
export interface GetDataLakeOrganizationConfigurationResponse {
    autoEnableNewAccount?: DataLakeAutoEnableNewAccountConfiguration[] | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface GetDataLakeSourcesRequest {
    accounts?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SourceCollectionStatus = "COLLECTING" | "MISCONFIGURED" | "NOT_COLLECTING" | (string & {});
export interface DataLakeSourceStatus {
    resource?: string | undefined;
    status?: SourceCollectionStatus | undefined;
}
export type DataLakeSourceStatusList = DataLakeSourceStatus[];
export interface DataLakeSource {
    account?: string | undefined;
    sourceName?: string | undefined;
    eventClasses?: string[] | undefined;
    sourceStatuses?: DataLakeSourceStatus[] | undefined;
}
export type DataLakeSourceList = DataLakeSource[];
export interface GetDataLakeSourcesResponse {
    dataLakeArn?: string | undefined;
    dataLakeSources?: DataLakeSource[] | undefined;
    nextToken?: string | undefined;
}
export interface GetSubscriberRequest {
    subscriberId: string;
}
export interface GetSubscriberResponse {
    subscriber?: SubscriberResource | undefined;
}
export interface ListDataLakeExceptionsRequest {
    regions?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DataLakeException {
    region?: string | undefined;
    exception?: string | undefined;
    remediation?: string | undefined;
    timestamp?: Date | undefined;
}
export type DataLakeExceptionList = DataLakeException[];
export interface ListDataLakeExceptionsResponse {
    exceptions?: DataLakeException[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataLakesRequest {
    regions?: string[] | undefined;
}
export interface ListDataLakesResponse {
    dataLakes?: DataLakeResource[] | undefined;
}
export interface ListLogSourcesRequest {
    accounts?: string[] | undefined;
    regions?: string[] | undefined;
    sources?: LogSourceResource[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface LogSource {
    account?: string | undefined;
    region?: string | undefined;
    sources?: LogSourceResource[] | undefined;
}
export type LogSourceList = LogSource[];
export interface ListLogSourcesResponse {
    sources?: LogSource[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSubscribersRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SubscriberResourceList = SubscriberResource[];
export interface ListSubscribersResponse {
    subscribers?: SubscriberResource[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface RegisterDataLakeDelegatedAdministratorRequest {
    accountId: string;
}
export interface RegisterDataLakeDelegatedAdministratorResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDataLakeRequest {
    configurations: DataLakeConfiguration[];
    metaStoreManagerRoleArn?: string | undefined;
}
export interface UpdateDataLakeResponse {
    dataLakes?: DataLakeResource[] | undefined;
}
export interface UpdateDataLakeExceptionSubscriptionRequest {
    subscriptionProtocol: string;
    notificationEndpoint: string;
    exceptionTimeToLive?: number | undefined;
}
export interface UpdateDataLakeExceptionSubscriptionResponse {
}
export interface UpdateSubscriberRequest {
    subscriberId: string;
    subscriberIdentity?: AwsIdentity | undefined;
    subscriberName?: string | undefined;
    subscriberDescription?: string | undefined;
    sources?: LogSourceResource[] | undefined;
}
export interface UpdateSubscriberResponse {
    subscriber?: SubscriberResource | undefined;
}
export interface UpdateSubscriberNotificationRequest {
    subscriberId: string;
    configuration: NotificationConfiguration;
}
export interface UpdateSubscriberNotificationResponse {
    subscriberEndpoint?: string | undefined;
}
export type CreateAwsLogSourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds a natively supported Amazon Web Services service as an Amazon Security Lake source. Enables
 * source types for member accounts in required Amazon Web Services Regions, based on the
 * parameters you specify. You can choose any source type in any Region for either accounts
 * that are part of a trusted organization or standalone accounts. Once you add an Amazon Web Services service as a source, Security Lake starts collecting logs and events from it.
 *
 * You can use this API only to enable natively supported Amazon Web Services services as a
 * source. Use `CreateCustomLogSource` to enable data collection from a custom
 * source.
 */
export declare const createAwsLogSource: API.OperationMethod<CreateAwsLogSourceRequest & RegionInput, CreateAwsLogSourceResponse, CreateAwsLogSourceError, Credentials | HttpClient.HttpClient>;
export type CreateCustomLogSourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds a third-party custom source in Amazon Security Lake, from the Amazon Web Services Region
 * where you want to create a custom source. Security Lake can collect logs and events from
 * third-party custom sources. After creating the appropriate IAM role to
 * invoke Glue crawler, use this API to add a custom source name in Security Lake. This
 * operation creates a partition in the Amazon S3 bucket for Security Lake as the target
 * location for log files from the custom source. In addition, this operation also creates an
 * associated Glue table and an Glue crawler.
 */
export declare const createCustomLogSource: API.OperationMethod<CreateCustomLogSourceRequest & RegionInput, CreateCustomLogSourceResponse, CreateCustomLogSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDataLakeError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Initializes an Amazon Security Lake instance with the provided (or default) configuration. You
 * can enable Security Lake in Amazon Web Services Regions with customized settings before enabling
 * log collection in Regions. To specify particular Regions, configure these Regions using the
 * `configurations` parameter. If you have already enabled Security Lake in a Region
 * when you call this command, the command will update the Region if you provide new
 * configuration parameters. If you have not already enabled Security Lake in the Region when you
 * call this API, it will set up the data lake in the Region with the specified
 * configurations.
 *
 * When you enable Security Lake, it starts ingesting security data after the
 * `CreateAwsLogSource` call and after you create subscribers using the `CreateSubscriber` API. This includes ingesting security data from
 * sources, storing data, and making data accessible to subscribers. Security Lake also enables
 * all the existing settings and resources that it stores or maintains for your Amazon Web Services account in the current Region, including security log and event data. For
 * more information, see the Amazon Security Lake User
 * Guide.
 */
export declare const createDataLake: API.OperationMethod<CreateDataLakeRequest & RegionInput, CreateDataLakeResponse, CreateDataLakeError, Credentials | HttpClient.HttpClient>;
export type CreateDataLakeExceptionSubscriptionError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates the specified notification subscription in Amazon Security Lake for the organization
 * you specify. The notification subscription is created for exceptions that cannot be resolved by Security Lake automatically.
 */
export declare const createDataLakeExceptionSubscription: API.OperationMethod<CreateDataLakeExceptionSubscriptionRequest & RegionInput, CreateDataLakeExceptionSubscriptionResponse, CreateDataLakeExceptionSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateDataLakeOrganizationConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Automatically enables Amazon Security Lake for new member accounts in your organization.
 * Security Lake is not automatically enabled for any existing member accounts in your
 * organization.
 *
 * This operation merges the new data lake organization configuration with the existing configuration for Security Lake in your organization. If you want to create a new data lake organization configuration, you must delete the existing one using DeleteDataLakeOrganizationConfiguration.
 */
export declare const createDataLakeOrganizationConfiguration: API.OperationMethod<CreateDataLakeOrganizationConfigurationRequest & RegionInput, CreateDataLakeOrganizationConfigurationResponse, CreateDataLakeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriberError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Creates a subscriber for accounts that are already enabled in Amazon Security Lake. You can
 * create a subscriber with access to data in the current Amazon Web Services Region.
 */
export declare const createSubscriber: API.OperationMethod<CreateSubscriberRequest & RegionInput, CreateSubscriberResponse, CreateSubscriberError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriberNotificationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Notifies the subscriber when new data is written to the data lake for the sources that
 * the subscriber consumes in Security Lake. You can create only one subscriber notification per
 * subscriber.
 */
export declare const createSubscriberNotification: API.OperationMethod<CreateSubscriberNotificationRequest & RegionInput, CreateSubscriberNotificationResponse, CreateSubscriberNotificationError, Credentials | HttpClient.HttpClient>;
export type DeleteAwsLogSourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes a natively supported Amazon Web Services service as an Amazon Security Lake source. You
 * can remove a source for one or more Regions. When you remove the source, Security Lake stops
 * collecting data from that source in the specified Regions and accounts, and subscribers can
 * no longer consume new data from the source. However, subscribers can still consume data
 * that Security Lake collected from the source before removal.
 *
 * You can choose any source type in any Amazon Web Services Region for either accounts that
 * are part of a trusted organization or standalone accounts.
 */
export declare const deleteAwsLogSource: API.OperationMethod<DeleteAwsLogSourceRequest & RegionInput, DeleteAwsLogSourceResponse, DeleteAwsLogSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomLogSourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes a custom log source from Amazon Security Lake, to stop sending data from the custom
 * source to Security Lake.
 */
export declare const deleteCustomLogSource: API.OperationMethod<DeleteCustomLogSourceRequest & RegionInput, DeleteCustomLogSourceResponse, DeleteCustomLogSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDataLakeError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * When you disable Amazon Security Lake from your account, Security Lake is disabled in all Amazon Web Services Regions and it stops collecting data from your sources. Also, this API
 * automatically takes steps to remove the account from Security Lake. However, Security Lake retains
 * all of your existing settings and the resources that it created in your Amazon Web Services
 * account in the current Amazon Web Services Region.
 *
 * The `DeleteDataLake` operation does not delete the data that is stored in
 * your Amazon S3 bucket, which is owned by your Amazon Web Services account. For more
 * information, see the Amazon Security Lake User
 * Guide.
 */
export declare const deleteDataLake: API.OperationMethod<DeleteDataLakeRequest & RegionInput, DeleteDataLakeResponse, DeleteDataLakeError, Credentials | HttpClient.HttpClient>;
export type DeleteDataLakeExceptionSubscriptionError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified notification subscription in Amazon Security Lake for the organization
 * you specify.
 */
export declare const deleteDataLakeExceptionSubscription: API.OperationMethod<DeleteDataLakeExceptionSubscriptionRequest & RegionInput, DeleteDataLakeExceptionSubscriptionResponse, DeleteDataLakeExceptionSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataLakeOrganizationConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Turns off automatic enablement of Amazon Security Lake for member accounts that are added to an organization in Organizations. Only the delegated
 * Security Lake administrator for an organization can perform this operation. If the delegated Security Lake administrator performs this operation, new member
 * accounts won't automatically contribute data to the data lake.
 */
export declare const deleteDataLakeOrganizationConfiguration: API.OperationMethod<DeleteDataLakeOrganizationConfigurationRequest & RegionInput, DeleteDataLakeOrganizationConfigurationResponse, DeleteDataLakeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriberError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the subscription permission and all notification settings for accounts that are
 * already enabled in Amazon Security Lake. When you run `DeleteSubscriber`, the
 * subscriber will no longer consume data from Security Lake and the subscriber is removed. This
 * operation deletes the subscriber and removes access to data in the current Amazon Web Services Region.
 */
export declare const deleteSubscriber: API.OperationMethod<DeleteSubscriberRequest & RegionInput, DeleteSubscriberResponse, DeleteSubscriberError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriberNotificationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified subscription notification in Amazon Security Lake for the organization
 * you specify.
 */
export declare const deleteSubscriberNotification: API.OperationMethod<DeleteSubscriberNotificationRequest & RegionInput, DeleteSubscriberNotificationResponse, DeleteSubscriberNotificationError, Credentials | HttpClient.HttpClient>;
export type DeregisterDataLakeDelegatedAdministratorError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the Amazon Security Lake delegated administrator account for the organization. This API
 * can only be called by the organization management account. The organization management
 * account cannot be the delegated administrator account.
 */
export declare const deregisterDataLakeDelegatedAdministrator: API.OperationMethod<DeregisterDataLakeDelegatedAdministratorRequest & RegionInput, DeregisterDataLakeDelegatedAdministratorResponse, DeregisterDataLakeDelegatedAdministratorError, Credentials | HttpClient.HttpClient>;
export type GetDataLakeExceptionSubscriptionError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the protocol and endpoint that were provided when subscribing to Amazon SNS topics for exception notifications.
 */
export declare const getDataLakeExceptionSubscription: API.OperationMethod<GetDataLakeExceptionSubscriptionRequest & RegionInput, GetDataLakeExceptionSubscriptionResponse, GetDataLakeExceptionSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetDataLakeOrganizationConfigurationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the configuration that will be automatically set up for accounts added to the
 * organization after the organization has onboarded to Amazon Security Lake. This API does not take
 * input parameters.
 */
export declare const getDataLakeOrganizationConfiguration: API.OperationMethod<GetDataLakeOrganizationConfigurationRequest & RegionInput, GetDataLakeOrganizationConfigurationResponse, GetDataLakeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataLakeSourcesError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a snapshot of the current Region, including whether Amazon Security Lake is enabled
 * for those accounts and which sources Security Lake is collecting data from.
 */
export declare const getDataLakeSources: API.PaginatedOperationMethod<GetDataLakeSourcesRequest & RegionInput, GetDataLakeSourcesResponse, GetDataLakeSourcesError, Credentials | HttpClient.HttpClient, DataLakeSource>;
export type GetSubscriberError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the subscription information for the specified subscription ID. You can get
 * information about a specific subscriber.
 */
export declare const getSubscriber: API.OperationMethod<GetSubscriberRequest & RegionInput, GetSubscriberResponse, GetSubscriberError, Credentials | HttpClient.HttpClient>;
export type ListDataLakeExceptionsError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists the Amazon Security Lake exceptions that you can use to find the source of problems and
 * fix them.
 */
export declare const listDataLakeExceptions: API.PaginatedOperationMethod<ListDataLakeExceptionsRequest & RegionInput, ListDataLakeExceptionsResponse, ListDataLakeExceptionsError, Credentials | HttpClient.HttpClient, DataLakeException>;
export type ListDataLakesError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the Amazon Security Lake configuration object for the specified Amazon Web Services Regions. You can use this operation to determine whether
 * Security Lake is enabled for a Region.
 */
export declare const listDataLakes: API.OperationMethod<ListDataLakesRequest & RegionInput, ListDataLakesResponse, ListDataLakesError, Credentials | HttpClient.HttpClient>;
export type ListLogSourcesError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the log sources.
 */
export declare const listLogSources: API.PaginatedOperationMethod<ListLogSourcesRequest & RegionInput, ListLogSourcesResponse, ListLogSourcesError, Credentials | HttpClient.HttpClient, LogSource>;
export type ListSubscribersError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Lists all subscribers for the specific Amazon Security Lake account ID. You can retrieve a list
 * of subscriptions associated with a specific organization or Amazon Web Services account.
 */
export declare const listSubscribers: API.PaginatedOperationMethod<ListSubscribersRequest & RegionInput, ListSubscribersResponse, ListSubscribersError, Credentials | HttpClient.HttpClient, SubscriberResource>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the tags (keys and values) that are associated with an Amazon Security Lake resource: a subscriber, or the data lake configuration for
 * your Amazon Web Services account in a particular Amazon Web Services Region.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterDataLakeDelegatedAdministratorError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Designates the Amazon Security Lake delegated administrator account for the organization. This
 * API can only be called by the organization management account. The organization management
 * account cannot be the delegated administrator account.
 */
export declare const registerDataLakeDelegatedAdministrator: API.OperationMethod<RegisterDataLakeDelegatedAdministratorRequest & RegionInput, RegisterDataLakeDelegatedAdministratorResponse, RegisterDataLakeDelegatedAdministratorError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Adds or updates one or more tags that are associated with an Amazon Security Lake resource: a subscriber, or the data lake configuration for your
 * Amazon Web Services account in a particular Amazon Web Services Region. A *tag* is a label that you can define and associate with
 * Amazon Web Services resources. Each tag consists of a required *tag key* and an associated *tag value*. A
 * *tag key* is a general label that acts as a category for a more specific tag value. A *tag value* acts as a
 * descriptor for a tag key. Tags can help you identify, categorize, and manage resources in different ways, such as by owner, environment, or other
 * criteria. For more information, see
 * Tagging Amazon Security Lake resources in the
 * *Amazon Security Lake User Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Removes one or more tags (keys and values) from an Amazon Security Lake resource: a subscriber, or the data lake configuration for your
 * Amazon Web Services account in a particular Amazon Web Services Region.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataLakeError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * You can use `UpdateDataLake` to specify where to store your security data, how it should
 * be encrypted at rest and for how long. You can add a Rollup
 * Region to consolidate data from multiple Amazon Web Services Regions, replace
 * default encryption (SSE-S3) with Customer Manged Key,
 * or specify transition and expiration actions through storage Lifecycle management. The `UpdateDataLake` API works as an "upsert" operation that performs an insert if the specified item or record does not exist, or an update if it
 * already exists. Security Lake securely stores your data at rest using Amazon Web Services encryption solutions. For more details, see Data protection in Amazon Security Lake.
 *
 * For example, omitting the key `encryptionConfiguration` from a Region that is
 * included in an update call that currently uses KMS will leave that Region's KMS key in
 * place, but specifying `encryptionConfiguration: {kmsKeyId: 'S3_MANAGED_KEY'}`
 * for that same Region will reset the key to `S3-managed`.
 *
 * For more details about lifecycle management and how to update retention settings for one or more Regions after enabling Security Lake, see the Amazon Security Lake User Guide.
 */
export declare const updateDataLake: API.OperationMethod<UpdateDataLakeRequest & RegionInput, UpdateDataLakeResponse, UpdateDataLakeError, Credentials | HttpClient.HttpClient>;
export type UpdateDataLakeExceptionSubscriptionError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified notification subscription in Amazon Security Lake for the organization
 * you specify.
 */
export declare const updateDataLakeExceptionSubscription: API.OperationMethod<UpdateDataLakeExceptionSubscriptionRequest & RegionInput, UpdateDataLakeExceptionSubscriptionResponse, UpdateDataLakeExceptionSubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriberError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing subscription for the given Amazon Security Lake account ID. You can update
 * a subscriber by changing the sources that the subscriber consumes data from.
 */
export declare const updateSubscriber: API.OperationMethod<UpdateSubscriberRequest & RegionInput, UpdateSubscriberResponse, UpdateSubscriberError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriberNotificationError = AccessDeniedException | BadRequestException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing notification method for the subscription (SQS or HTTPs endpoint) or
 * switches the notification subscription endpoint for a subscriber.
 */
export declare const updateSubscriberNotification: API.OperationMethod<UpdateSubscriberNotificationRequest & RegionInput, UpdateSubscriberNotificationResponse, UpdateSubscriberNotificationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=securitylake.d.ts.map