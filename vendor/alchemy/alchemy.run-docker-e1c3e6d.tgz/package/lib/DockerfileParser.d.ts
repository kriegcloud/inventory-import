import * as Effect from "effect/Effect";
declare const DockerfileSyntaxError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DockerfileSyntaxError";
} & Readonly<A>;
/**
 * A Dockerfile parsed into stages and instructions, with the line each one
 * starts on. Builders that are not Docker (E2B, Modal, Daytona) lower this
 * structure into their own build steps instead of running `docker build`.
 *
 * The parser is a port of BuildKit's (`frontend/dockerfile/parser` and the
 * checks in `instructions`), and is tested against it: parser directives,
 * line continuations, heredocs, exec and shell forms, `--flag[=value]`
 * options, Docker's quoting, and the files BuildKit rejects. It does not
 * expand variables: lowering decides whether a builder expands them or
 * Alchemy does.
 */
/** The Dockerfile could not be parsed. */
export declare class DockerfileSyntaxError extends DockerfileSyntaxError_base<{
    readonly message: string;
    /** 1-based line the error was found on. */
    readonly line: number;
}> {
}
/** A `--name` or `--name=value` option on an instruction. */
export interface Flag {
    readonly name: string;
    readonly value: string | undefined;
}
/** A heredoc attached to an instruction (`RUN <<EOF … EOF`). */
export interface Heredoc {
    /** The delimiter word, e.g. `EOF`. */
    readonly name: string;
    /** The body, without the closing delimiter line. */
    readonly content: string;
    /** `<<-`: leading tabs were stripped from the body. */
    readonly stripTabs: boolean;
    /** A quoted delimiter (`<<"EOF"`): the body is not expanded. */
    readonly quoted: boolean;
}
/** The exec form (`["bun", "index.mjs"]`) or the shell form (`bun index.mjs`). */
export type Command = {
    readonly form: "exec";
    readonly argv: ReadonlyArray<string>;
} | {
    readonly form: "shell";
    readonly script: string;
};
interface InstructionBase {
    /** 1-based line the instruction starts on. */
    readonly line: number;
    /** The instruction as written: the joined logical line, plus heredoc bodies. */
    readonly raw: string;
    readonly flags: ReadonlyArray<Flag>;
}
export interface RunInstruction extends InstructionBase {
    readonly _tag: "RUN";
    readonly command: Command;
    readonly heredocs: ReadonlyArray<Heredoc>;
}
export interface CopyInstruction extends InstructionBase {
    readonly _tag: "COPY" | "ADD";
    /** Context-relative sources, URLs (ADD), or `<<NAME` heredoc references. */
    readonly sources: ReadonlyArray<string>;
    readonly destination: string;
    readonly heredocs: ReadonlyArray<Heredoc>;
}
export interface EnvInstruction extends InstructionBase {
    readonly _tag: "ENV";
    readonly vars: ReadonlyArray<readonly [name: string, value: string]>;
}
export interface ArgInstruction extends InstructionBase {
    readonly _tag: "ARG";
    readonly vars: ReadonlyArray<readonly [name: string, defaultValue: string | undefined]>;
}
export interface ValueInstruction extends InstructionBase {
    readonly _tag: "WORKDIR" | "USER" | "STOPSIGNAL";
    readonly value: string;
}
export interface CommandInstruction extends InstructionBase {
    readonly _tag: "CMD" | "ENTRYPOINT" | "SHELL";
    readonly command: Command;
}
export interface OtherInstruction extends InstructionBase {
    readonly _tag: "EXPOSE" | "LABEL" | "HEALTHCHECK" | "VOLUME" | "ONBUILD" | "MAINTAINER";
    /** Everything after the instruction name and its flags. */
    readonly args: string;
}
export type Instruction = RunInstruction | CopyInstruction | EnvInstruction | ArgInstruction | ValueInstruction | CommandInstruction | OtherInstruction;
export type InstructionName = Instruction["_tag"] | "FROM";
/** One `FROM` and the instructions after it. */
export interface Stage {
    /** 1-based line of the `FROM`. */
    readonly line: number;
    /** The `FROM` line as written. */
    readonly raw: string;
    /** The base: an image reference, an earlier stage's name, or `scratch`. */
    readonly image: string;
    /** `FROM … AS name`. */
    readonly name: string | undefined;
    readonly flags: ReadonlyArray<Flag>;
    readonly instructions: ReadonlyArray<Instruction>;
}
export interface ParsedDockerfile {
    /** Parser directives, e.g. `{ syntax: "docker/dockerfile:1", escape: "\\" }`. */
    readonly directives: Readonly<Record<string, string>>;
    /** `ARG`s declared before the first `FROM`. */
    readonly globalArgs: ReadonlyArray<ArgInstruction>;
    readonly stages: ReadonlyArray<Stage>;
}
/**
 * Parse Dockerfile text into stages and instructions, as BuildKit reads it:
 * the same directives, continuations, heredocs, word splitting and quoting,
 * and the same files rejected. Values have their quotes and escapes
 * resolved; variables are left as written for the builder to expand.
 */
export declare const parse: (text: string) => Effect.Effect<ParsedDockerfile, DockerfileSyntaxError>;
/**
 * Render a parsed Dockerfile back to text, one instruction per entry, each
 * exactly as written (continuations and heredoc bodies included).
 */
export declare const renderLines: (dockerfile: ParsedDockerfile) => string[];
/** Render a parsed Dockerfile back to text. */
export declare const render: (dockerfile: ParsedDockerfile) => string;
export {};
//# sourceMappingURL=DockerfileParser.d.ts.map