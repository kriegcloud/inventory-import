export * from "@distilled.cloud/s3/Sensitive";
//# sourceMappingURL=sensitive.d.ts.map