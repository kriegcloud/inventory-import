import type { ConfigError } from "effect/Config";
import * as Context from "effect/Context";
import type { Digest } from "effect/crypto/Digest";
import type { SecureRandom } from "effect/crypto/SecureRandom";
import * as Effect from "effect/Effect";
import { FileSystem } from "effect/FileSystem";
import type { HttpClient } from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import { Path } from "effect/Path";
import type { ChildProcessSpawner } from "effect/process/ChildProcessSpawner";
import type * as Scope from "effect/Scope";
import type { ActionLike } from "./Action.ts";
import type { AlchemyContext } from "./AlchemyContext.ts";
import type { ArtifactStore } from "./Artifacts.ts";
import type { CredentialsStore } from "./Auth/Credentials.ts";
import type { ProfileStore } from "./Auth/Profile.ts";
import { type AuthProviders } from "./Auth/Registry.ts";
import type { Input, InputProps } from "./Input.ts";
import type { Interaction } from "./Interaction.ts";
import * as Output from "./Output.ts";
import type { Provider, ProviderCollectionLike } from "./Provider.ts";
import type { ResourceBinding, ResourceLike } from "./Resource.ts";
import type { SecretsEntry, SecretsOption } from "./Secrets/Provider.ts";
import { Stage } from "./Stage.ts";
import type { State } from "./State/State.ts";
import type { PlatformServices } from "./Util/PlatformServices.ts";
export type StackServices = Stack | Stage | Scope.Scope | FileSystem | Digest | SecureRandom | Path | AlchemyContext | HttpClient | ChildProcessSpawner | AuthProviders | ProfileStore | ArtifactStore | CredentialsStore | Interaction;
export type ProviderServices = ProviderCollectionLike | Provider<any> | EnvironmentLike | CredentialsLike | DockerLike;
export interface EnvironmentLike {
    readonly kind: "Environment";
}
export interface CredentialsLike {
    readonly kind: "Credentials";
}
export interface DockerLike {
    readonly key: "@alchemy/Docker";
}
export type StackEffect<A, Err = never, Req = never> = Effect.Effect<A, Err, PlatformServices | HttpClient | Scope.Scope | AuthProviders | AlchemyContext | Interaction | ProfileStore | CredentialsStore | ArtifactStore | State | Req>;
export type Stack = Context.ServiceClass.Shape<"Stack", Omit<StackSpec, "output">>;
/**
 * Where a stack's configuration comes from: a ConfigProvider layer, or a
 * list of them applied in order, later ones overriding earlier ones.
 *
 * The process environment implicitly closes every list, so the shell
 * overrides every provider. List `Secrets.ProcessEnv()` yourself to rank it
 * elsewhere, or `Secrets.ProcessEnv({ disabled: true })` to leave it out.
 * Omitting `secrets` preserves the existing ConfigProvider and CLI dotenv behavior.
 *
 * ```ts
 * secrets: [
 *   Doppler.Secrets({ project: "app", config: "dev" }),
 *   Secrets.DotEnv(),
 *   Secrets.ProcessEnv(),
 * ]
 * ```
 */
export type SecretProviders = SecretsEntry | ReadonlyArray<SecretsEntry>;
/**
 * The `secrets` option: providers, or a callback that picks them from the
 * stage, so one stack can read `.env` locally and a secrets manager
 * elsewhere:
 *
 * ```ts
 * secrets: ({ stage }) =>
 *   stage === "dev"
 *     ? Secrets.DotEnv()
 *     : Doppler.Secrets({ project: "app", config: stage }),
 * ```
 */
export type StackSecrets = SecretsOption<SecretProviders>;
export interface StackProps<Req> {
    providers: Layer.Layer<Extract<Req, ProviderServices>, never, StackServices>;
    state: Layer.Layer<State, never, StackServices>;
    /** Opt in to secret providers. When omitted, existing configuration is preserved. */
    secrets?: StackSecrets;
}
/**
 * Runtime fields the Stack factory attaches to a configured stack effect.
 * Class-reference forms expose only `stackName` until `.make(...)`.
 */
export type ConfiguredStackMeta<Req = never> = {
    readonly stackName: string;
} & StackProps<Req>;
/**
 * What `Alchemy.Stack(...)` returns, and what an `alchemy.run.ts`
 * default-exports: the stack program, not yet run, with its providers,
 * state store, and secrets attached.
 */
export type ConfiguredStack<Output, Req> = Effect.Effect<CompiledStack<Output>, ConfigError> & ConfiguredStackMeta<Req>;
export declare const Stack: Context.ServiceClass<Stack, "Stack", Omit<StackSpec, "output">> & {
    make<A, Req>(stack: {
        Shape: A;
    }, effect: Effect.Effect<NoInfer<A extends object ? InputProps<A> : Input<A>>, ConfigError, Req>): Effect.Effect<CompiledStack<A>, ConfigError>;
    <Self>(): {
        <A, Req>(stackName: string, options: StackProps<NoInfer<Req>>, eff: Effect.Effect<A, ConfigError, Req>): Effect.Effect<Self, ConfigError> & {
            new (_: never): A extends object ? A : {};
            readonly stackName: string;
            stage: {
                [stage: string]: Effect.Effect<Self>;
            };
        };
    };
    <Self, Shape, Stages extends string = string>(): {
        (stackName: string): Effect.Effect<Self> & {
            new (_: never): Output.ToOutput<Shape>;
            readonly stackName: string;
            make: <A, Req>(options: StackProps<NoInfer<Req>>, effect: Effect.Effect<A, ConfigError, Req>) => ConfiguredStack<A, NoInfer<Req>>;
            stage: {
                readonly [S in Stages]: Effect.Effect<Self>;
            };
        };
    };
    <A, Req extends StackServices | ProviderServices = never>(stackName: string, options: StackProps<NoInfer<Req>>, eff: Effect.Effect<A, ConfigError, Req>): ConfiguredStack<A, NoInfer<Req>>;
};
export interface StackSpec<Output = any> {
    name: string;
    stage: string;
    resources: {
        [logicalId: string]: ResourceLike;
    };
    bindings: {
        [logicalId: string]: ResourceBinding[];
    };
    /** Tasks registered on the stack, keyed by FQN. */
    actions: {
        [logicalId: string]: ActionLike;
    };
    output: Output;
}
export interface CompiledStack<Output = any, Services = any> extends StackSpec<Output> {
    services: Context.Context<Services>;
}
export declare const StackName: Effect.Effect<string, never, Stack>;
export interface MakeStackProps<ROut = never> {
    name: string;
    /** Required; {@link make} dies with setup guidance when it is missing. */
    providers?: Layer.Layer<ROut, never, StackServices>;
    /** Required; {@link make} dies with setup guidance when it is missing. */
    state?: Layer.Layer<State, never, StackServices>;
    /** Opt in to secret providers. When omitted, existing configuration is preserved. */
    secrets?: StackSecrets;
    /** @internal */
    stack?: StackSpec;
}
declare const StateScope_base: Context.ServiceClass<StateScope, "alchemy/Stack/StateScope", Scope.Scope>;
/**
 * The scope a stack's state store is built into when it must close sooner
 * than the rest of the stack. A store holds its stack's lease until its scope
 * closes, so `evalStack` (`EvalStack.ts`) gives it one per call even when the caller
 * keeps providers alive in a longer scope.
 */
export declare class StateScope extends StateScope_base {
}
/**
 * Build a stack's providers, state store, secrets config and `Stack` spec,
 * without running its program. Destroy needs nothing more: it plans from state
 * alone, and every row records the provider mode that deletes it.
 */
export declare const build: <ROut = never>(options: MakeStackProps<ROut>) => Effect.Effect<Context.Context<ROut | AuthProviders | Stack | State>, ConfigError, AlchemyContext | ArtifactStore | ChildProcessSpawner | CredentialsStore | Digest | FileSystem | HttpClient | Interaction | Path | ProfileStore | Scope.Scope | SecureRandom | Stage>;
/** Build a stack's services with {@link build}, then run its program under them. */
export declare const make: <ROut = never>(options: MakeStackProps<ROut>) => <A, Err = never, Req extends ROut | StackServices = never>(effect: Effect.Effect<A, Err, Req>) => Effect.Effect<CompiledStack<A, ROut | StackServices>, Err | ConfigError, AlchemyContext | ArtifactStore | ChildProcessSpawner | CredentialsStore | Digest | FileSystem | HttpClient | Interaction | Path | ProfileStore | Scope.Scope | SecureRandom | Stage | Exclude<ROut, ROut | AuthProviders | Stack | State> | Exclude<Req, ROut | AuthProviders | Stack | State> | Exclude<AlchemyContext, ROut | AuthProviders | Stack | State> | Exclude<ArtifactStore, ROut | AuthProviders | Stack | State> | Exclude<AuthProviders, ROut | AuthProviders | Stack | State> | Exclude<ChildProcessSpawner, ROut | AuthProviders | Stack | State> | Exclude<CredentialsStore, ROut | AuthProviders | Stack | State> | Exclude<Digest, ROut | AuthProviders | Stack | State> | Exclude<FileSystem, ROut | AuthProviders | Stack | State> | Exclude<HttpClient, ROut | AuthProviders | Stack | State> | Exclude<Interaction, ROut | AuthProviders | Stack | State> | Exclude<Path, ROut | AuthProviders | Stack | State> | Exclude<ProfileStore, ROut | AuthProviders | Stack | State> | Exclude<Scope.Scope, ROut | AuthProviders | Stack | State> | Exclude<SecureRandom, ROut | AuthProviders | Stack | State> | Exclude<Stack, ROut | AuthProviders | Stack | State> | Exclude<Stage, ROut | AuthProviders | Stack | State>>;
/** What `Alchemy.Stack(...)` attaches to the stack it returns: everything but its program. */
export interface StackDefinition<ROut = never> {
    readonly stackName: string;
    readonly providers?: Layer.Layer<ROut, never, StackServices>;
    readonly state?: Layer.Layer<State, never, StackServices>;
    readonly secrets?: StackSecrets;
}
export declare const CurrentStack: Effect.Effect<Omit<StackSpec<any>, "output"> | undefined, never, never>;
export {};
//# sourceMappingURL=Stack.d.ts.map