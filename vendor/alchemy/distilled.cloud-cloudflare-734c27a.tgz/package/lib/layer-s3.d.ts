import type * as S3Credentials from "@distilled.cloud/s3/Credentials";
import type * as S3Endpoint from "@distilled.cloud/s3/Endpoint";
import type * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import { Credentials } from "./credentials.ts";
declare const S3CredentialsError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "CloudflareR2S3CredentialsError";
} & Readonly<A>;
/** The Cloudflare credentials could not be turned into R2 S3 keys or an endpoint. */
export declare class S3CredentialsError extends /*@__PURE__*/ S3CredentialsError_base<{
    message: string;
    cause?: unknown;
}> {
}
declare module "@distilled.cloud/s3/Credentials" {
    interface ProviderErrors {
        cloudflare: S3CredentialsError;
    }
}
/**
 * `@distilled.cloud/s3`'s `Credentials` (region `auto`) and `Endpoint` for
 * the R2 buckets of the account the Cloudflare `Credentials` act on.
 */
export declare const layerS3: () => Layer.Layer<S3Credentials.Credentials | S3Endpoint.Endpoint, S3CredentialsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=layer-s3.d.ts.map