import * as Cause from "effect/Cause";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import type { PlatformError } from "effect/PlatformError";
import * as Scope from "effect/Scope";
import { AuthError } from "../Auth/AuthProvider.ts";
import type { ContributionError } from "../Contributions.ts";
import { UserFacingError } from "../UserFacingError.ts";
import type { Services } from "./Runtime.ts";
/** What collecting an auth registry can fail with. */
export type CollectAuthProvidersError = AuthError | AuthProviderImportError | ContributionError | PlatformError;
/** What collecting an auth registry runs under. */
export type CollectAuthProvidersServices = Services | Scope.Scope;
export interface CollectAuthProvidersOptions {
    readonly main: string;
    readonly envFile: Option.Option<string>;
    readonly profile: string;
}
declare const AuthProviderImportError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "AuthProviderImportError";
} & Readonly<A>;
/** The stack entrypoint failed to load, so its auth providers can't be registered. */
export declare class AuthProviderImportError extends AuthProviderImportError_base<{
    readonly main: string;
    readonly cause: unknown;
}> {
    readonly [UserFacingError] = true;
    get message(): string;
}
/**
 * Memoize auth registries for one command or API runtime: profile flows
 * collect them repeatedly, and concurrent collections of the same project
 * share one. Registries are built in this layer's scope, so a cached one
 * never outlives the services its providers captured. Failures are not
 * cached.
 */
export declare const authRegistryLayer: Layer.Layer<never, never, never>;
export declare const collectAuthProviders: (options: CollectAuthProvidersOptions) => Effect.Effect<{
    [providerName: string]: import("../Auth/AuthProvider.ts").AuthProvider<{
        method: string;
    }, unknown>;
}, CollectAuthProvidersError, CollectAuthProvidersServices>;
export {};
//# sourceMappingURL=AuthRegistry.d.ts.map