import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InsufficientCapacityException_base: S.TaggedErrorClass<"InsufficientCapacityException", {
    readonly message: any;
}>;
export declare class InsufficientCapacityException extends /*@__PURE__*/ InsufficientCapacityException_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidResourcePolicyException_base: S.TaggedErrorClass<"InvalidResourcePolicyException", {
    readonly message: any;
}>;
export declare class InvalidResourcePolicyException extends /*@__PURE__*/ InvalidResourcePolicyException_base {
}
declare const InvalidTokenException_base: S.TaggedErrorClass<"InvalidTokenException", {
    readonly message: any;
}>;
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LogDestinationPermissionException_base: S.TaggedErrorClass<"LogDestinationPermissionException", {
    readonly message: any;
}>;
export declare class LogDestinationPermissionException extends /*@__PURE__*/ LogDestinationPermissionException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceOwnerCheckException_base: S.TaggedErrorClass<"ResourceOwnerCheckException", {
    readonly message: any;
}>;
export declare class ResourceOwnerCheckException extends /*@__PURE__*/ ResourceOwnerCheckException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type TransitGatewayAttachmentId = string;
export interface AcceptNetworkFirewallTransitGatewayAttachmentRequest {
    TransitGatewayAttachmentId: string;
}
export type TransitGatewayAttachmentStatus = "CREATING" | "DELETING" | "DELETED" | "FAILED" | "ERROR" | "READY" | "PENDING_ACCEPTANCE" | "REJECTING" | "REJECTED" | (string & {});
export interface AcceptNetworkFirewallTransitGatewayAttachmentResponse {
    TransitGatewayAttachmentId: string;
    TransitGatewayAttachmentStatus: TransitGatewayAttachmentStatus;
}
export type UpdateToken = string;
export type ResourceArn = string;
export type ResourceName = string;
export type AvailabilityZoneMappingString = string;
export interface AvailabilityZoneMapping {
    AvailabilityZone: string;
}
export type AvailabilityZoneMappings = AvailabilityZoneMapping[];
export interface AssociateAvailabilityZonesRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneMappings: AvailabilityZoneMapping[];
}
export interface AssociateAvailabilityZonesResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneMappings?: AvailabilityZoneMapping[] | undefined;
    UpdateToken?: string | undefined;
}
export interface AssociateFirewallPolicyRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    FirewallPolicyArn: string;
}
export interface AssociateFirewallPolicyResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    FirewallPolicyArn?: string | undefined;
    UpdateToken?: string | undefined;
}
export type CollectionMember_String = string;
export type IPAddressType = "DUALSTACK" | "IPV4" | "IPV6" | (string & {});
export interface SubnetMapping {
    SubnetId: string;
    IPAddressType?: IPAddressType | undefined;
}
export type SubnetMappings = SubnetMapping[];
export type NatGatewayAllocationIdList = string[];
export type NatGatewayPrivateIpList = string[];
export interface NatGatewayCreateMapping {
    SubnetId: string;
    AllocationIds?: string[] | undefined;
    PrivateIps?: string[] | undefined;
}
export type NatGatewayCreateMappingsList = NatGatewayCreateMapping[];
export interface AssociateSubnetsRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetMappings: SubnetMapping[];
    NatGatewayCreateMappings?: NatGatewayCreateMapping[] | undefined;
}
export interface AssociateSubnetsResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetMappings?: SubnetMapping[] | undefined;
    UpdateToken?: string | undefined;
}
export type Description = string;
export type ContainerMonitoringType = "ECS" | "EKS" | (string & {});
export type ContainerAttributeKey = string;
export type ContainerAttributeValue = string;
export interface ContainerAttribute {
    Key: string;
    Value: string;
}
export type ContainerAttributes = ContainerAttribute[];
export interface ContainerMonitoringConfiguration {
    ClusterArn: string;
    AttributeFilters?: ContainerAttribute[] | undefined;
}
export type ContainerMonitoringConfigurations = ContainerMonitoringConfiguration[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateContainerAssociationRequest {
    ContainerAssociationName: string;
    Description?: string | undefined;
    Type: ContainerMonitoringType;
    ContainerMonitoringConfigurations: ContainerMonitoringConfiguration[];
    Tags?: Tag[] | undefined;
}
export type ContainerAssociationStatus = "ACTIVE" | "CREATING" | "DELETING" | "UPDATING" | (string & {});
export interface CreateContainerAssociationResponse {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
    Description?: string | undefined;
    Type?: ContainerMonitoringType | undefined;
    ContainerMonitoringConfigurations?: ContainerMonitoringConfiguration[] | undefined;
    Status?: ContainerAssociationStatus | undefined;
    Tags?: Tag[] | undefined;
    UpdateToken?: string | undefined;
}
export type VpcId = string;
export type KeyId = string;
export type EncryptionType = "CUSTOMER_KMS" | "AWS_OWNED_KMS_KEY" | (string & {});
export interface EncryptionConfiguration {
    KeyId?: string | undefined;
    Type: EncryptionType;
}
export type EnabledAnalysisType = "TLS_SNI" | "HTTP_HOST" | (string & {});
export type EnabledAnalysisTypes = EnabledAnalysisType[];
export type TransitGatewayId = string;
export type NatGatewayPort = number;
export type ListenerPropertyType = "HTTP" | "HTTPS" | (string & {});
export interface ListenerProperty {
    Port?: number | undefined;
    Type?: ListenerPropertyType | undefined;
}
export type ListenerProperties = ListenerProperty[];
export type ProxyDomainName = string;
export interface ProxySettings {
    ListenerProperties: ListenerProperty[];
    CertificateArn?: string | undefined;
    DomainName?: string | undefined;
}
export interface VpcEndpoint {
    VpcId: string;
    SubnetMappings: SubnetMapping[];
}
export type TransparentFilteringNatScope = "NAT_ALL" | "NAT_NONE" | (string & {});
export interface CreateFirewallRequest {
    FirewallName: string;
    FirewallPolicyArn: string;
    VpcId?: string | undefined;
    SubnetMappings?: SubnetMapping[] | undefined;
    DeleteProtection?: boolean | undefined;
    SubnetChangeProtection?: boolean | undefined;
    FirewallPolicyChangeProtection?: boolean | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    EnabledAnalysisTypes?: EnabledAnalysisType[] | undefined;
    TransitGatewayId?: string | undefined;
    AvailabilityZoneMappings?: AvailabilityZoneMapping[] | undefined;
    AvailabilityZoneChangeProtection?: boolean | undefined;
    NatGatewayCreateMappings?: NatGatewayCreateMapping[] | undefined;
    ProxySettings?: ProxySettings | undefined;
    VpcEndpoint?: VpcEndpoint | undefined;
    TransparentFilteringNatScope?: TransparentFilteringNatScope | undefined;
}
export type ResourceId = string;
export type NumberOfAssociations = number;
export type AWSAccountId = string;
export interface Firewall {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallPolicyArn: string;
    VpcId: string;
    SubnetMappings: SubnetMapping[];
    DeleteProtection?: boolean | undefined;
    SubnetChangeProtection?: boolean | undefined;
    FirewallPolicyChangeProtection?: boolean | undefined;
    Description?: string | undefined;
    FirewallId: string;
    Tags?: Tag[] | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    NumberOfAssociations?: number | undefined;
    EnabledAnalysisTypes?: EnabledAnalysisType[] | undefined;
    TransitGatewayId?: string | undefined;
    TransitGatewayOwnerAccountId?: string | undefined;
    AvailabilityZoneMappings?: AvailabilityZoneMapping[] | undefined;
    AvailabilityZoneChangeProtection?: boolean | undefined;
    NatGatewayCreateMappings?: NatGatewayCreateMapping[] | undefined;
    ProxySettings?: ProxySettings | undefined;
    VpcEndpoint?: VpcEndpoint | undefined;
    TransparentFilteringNatScope?: TransparentFilteringNatScope | undefined;
}
export type FirewallStatusValue = "PROVISIONING" | "DELETING" | "READY" | "FAILED" | (string & {});
export type ConfigurationSyncState = "PENDING" | "IN_SYNC" | "CAPACITY_CONSTRAINED" | (string & {});
export type AvailabilityZone = string;
export type AzSubnet = string;
export type EndpointId = string;
export type AttachmentStatus = "CREATING" | "DELETING" | "FAILED" | "ERROR" | "SCALING" | "READY" | (string & {});
export type StatusMessage = string;
export type DnsName = string;
export interface Attachment {
    SubnetId?: string | undefined;
    EndpointId?: string | undefined;
    Status?: AttachmentStatus | undefined;
    StatusMessage?: string | undefined;
    DnsName?: string | undefined;
}
export type PerObjectSyncStatus = "PENDING" | "IN_SYNC" | "CAPACITY_CONSTRAINED" | "NOT_SUBSCRIBED" | "DEPRECATED" | (string & {});
export interface PerObjectStatus {
    SyncStatus?: PerObjectSyncStatus | undefined;
    UpdateToken?: string | undefined;
}
export type SyncStateConfig = {
    [key: string]: PerObjectStatus | undefined;
};
export type NatGatewayId = string;
export type NatGatewayAttachmentStatus = "CREATING" | "READY" | "UPDATING" | "FAILED" | "DELETING" | (string & {});
export type StatusReason = string;
export interface NatGatewayAttachment {
    NatGatewayId: string;
    Status: NatGatewayAttachmentStatus;
    StatusMessage?: string | undefined;
    DnsName?: string | undefined;
}
export type NatGatewayAttachmentsList = NatGatewayAttachment[];
export interface SyncState {
    Attachment?: Attachment | undefined;
    Config?: {
        [key: string]: PerObjectStatus | undefined;
    } | undefined;
    NatGatewayAttachments?: NatGatewayAttachment[] | undefined;
}
export type SyncStates = {
    [key: string]: SyncState | undefined;
};
export type CIDRCount = number;
export type IPSetArn = string;
export interface IPSetMetadata {
    ResolvedCIDRCount?: number | undefined;
}
export type IPSetMetadataMap = {
    [key: string]: IPSetMetadata | undefined;
};
export interface CIDRSummary {
    AvailableCIDRCount?: number | undefined;
    UtilizedCIDRCount?: number | undefined;
    IPSetReferences?: {
        [key: string]: IPSetMetadata | undefined;
    } | undefined;
}
export interface CapacityUsageSummary {
    CIDRs?: CIDRSummary | undefined;
}
export type AttachmentId = string;
export type TransitGatewayAttachmentSyncStateMessage = string;
export interface TransitGatewayAttachmentSyncState {
    AttachmentId?: string | undefined;
    TransitGatewayAttachmentStatus?: TransitGatewayAttachmentStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface FirewallStatus {
    Status: FirewallStatusValue;
    ConfigurationSyncStateSummary: ConfigurationSyncState;
    SyncStates?: {
        [key: string]: SyncState | undefined;
    } | undefined;
    CapacityUsageSummary?: CapacityUsageSummary | undefined;
    TransitGatewayAttachmentSyncState?: TransitGatewayAttachmentSyncState | undefined;
}
export interface CreateFirewallResponse {
    Firewall?: Firewall | undefined;
    FirewallStatus?: FirewallStatus | undefined;
}
export type Priority = number;
export interface StatelessRuleGroupReference {
    ResourceArn: string;
    Priority: number;
}
export type StatelessRuleGroupReferences = StatelessRuleGroupReference[];
export type StatelessActions = string[];
export type ActionName = string;
export type DimensionValue = string;
export interface Dimension {
    Value: string;
}
export type Dimensions = Dimension[];
export interface PublishMetricAction {
    Dimensions: Dimension[];
}
export interface ActionDefinition {
    PublishMetricAction?: PublishMetricAction | undefined;
}
export interface CustomAction {
    ActionName: string;
    ActionDefinition: ActionDefinition;
}
export type CustomActions = CustomAction[];
export type OverrideAction = "DROP_TO_ALERT" | (string & {});
export interface StatefulRuleGroupOverride {
    Action?: OverrideAction | undefined;
}
export type DeepThreatInspection = boolean;
export interface StatefulRuleGroupReference {
    ResourceArn: string;
    Priority?: number | undefined;
    Override?: StatefulRuleGroupOverride | undefined;
    DeepThreatInspection?: boolean | undefined;
}
export type StatefulRuleGroupReferences = StatefulRuleGroupReference[];
export type StatefulActions = string[];
export type RuleOrder = "DEFAULT_ACTION_ORDER" | "STRICT_ORDER" | (string & {});
export type StreamExceptionPolicy = "DROP" | "CONTINUE" | "REJECT" | (string & {});
export type TcpIdleTimeoutRangeBound = number;
export interface FlowTimeouts {
    TcpIdleTimeoutSeconds?: number | undefined;
}
export interface StatefulEngineOptions {
    RuleOrder?: RuleOrder | undefined;
    StreamExceptionPolicy?: StreamExceptionPolicy | undefined;
    FlowTimeouts?: FlowTimeouts | undefined;
}
export type RuleVariableName = string;
export type VariableDefinition = string;
export type VariableDefinitionList = string[];
export interface IPSet {
    Definition: string[];
}
export type IPSets = {
    [key: string]: IPSet | undefined;
};
export interface PolicyVariables {
    RuleVariables?: {
        [key: string]: IPSet | undefined;
    } | undefined;
}
export type EnableTLSSessionHolding = boolean;
export type Route53ResolvedIPValidationAction = "REJECT" | "DROP" | "ALERT" | (string & {});
export type DNSFirewallRuleGroupId = string;
export type DNSExpiryExceptionPolicy = "REJECT" | "DROP" | "CONTINUE" | (string & {});
export type AddressDefinition = string;
export interface Address {
    AddressDefinition: string;
}
export type Route53ResolvedIPValidationAddresses = Address[];
export interface Route53ResolvedIPValidation {
    Action: Route53ResolvedIPValidationAction;
    DNSFirewallRuleGroupId: string;
    DNSExpiryExceptionPolicy: DNSExpiryExceptionPolicy;
    BypassDestinationValidationIPRanges?: Address[] | undefined;
    SourceIPRanges?: Address[] | undefined;
}
export interface FirewallPolicy {
    StatelessRuleGroupReferences?: StatelessRuleGroupReference[] | undefined;
    StatelessDefaultActions: string[];
    StatelessFragmentDefaultActions: string[];
    StatelessCustomActions?: CustomAction[] | undefined;
    StatefulRuleGroupReferences?: StatefulRuleGroupReference[] | undefined;
    StatefulDefaultActions?: string[] | undefined;
    StatefulEngineOptions?: StatefulEngineOptions | undefined;
    TLSInspectionConfigurationArn?: string | undefined;
    PolicyVariables?: PolicyVariables | undefined;
    EnableTLSSessionHolding?: boolean | undefined;
    Route53ResolvedIPValidation?: Route53ResolvedIPValidation | undefined;
}
export interface CreateFirewallPolicyRequest {
    FirewallPolicyName: string;
    FirewallPolicy: FirewallPolicy;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export type ResourceStatus = "ACTIVE" | "DELETING" | "ERROR" | "UPDATING" | (string & {});
export type ResourceStatusMessage = string;
export type RuleCapacity = number;
export type FirewallPolicyErrorCode = "DNS_FIREWALL_RULE_GROUP_UNAVAILABLE" | "ROUTE53_RESOLVED_IP_VALIDATION_MISSING" | (string & {});
export type FirewallPolicyErrorResourceId = string;
export interface FirewallPolicyError {
    Code: FirewallPolicyErrorCode;
    Message: string;
    ResourceId?: string | undefined;
}
export type FirewallPolicyErrors = FirewallPolicyError[];
export type LastUpdateTime = Date;
export interface FirewallPolicyResponse {
    FirewallPolicyName: string;
    FirewallPolicyArn: string;
    FirewallPolicyId: string;
    Description?: string | undefined;
    FirewallPolicyStatus?: ResourceStatus | undefined;
    StatusMessage?: string | undefined;
    Tags?: Tag[] | undefined;
    ConsumedStatelessRuleCapacity?: number | undefined;
    ConsumedStatefulRuleCapacity?: number | undefined;
    ConsumedStatefulDomainCapacity?: number | undefined;
    NumberOfAssociations?: number | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    Errors?: FirewallPolicyError[] | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface CreateFirewallPolicyResponse {
    UpdateToken: string;
    FirewallPolicyResponse: FirewallPolicyResponse;
}
export type RulesString = string;
export type FirewallRuleAction = "ACCEPT" | "DROP" | "REJECT" | "REJECT_DST" | "REJECT_BOTH" | (string & {});
export type ActionScope = "FLOW" | "TX" | "HOOK" | "PACKET" | (string & {});
export type HookKey = "TCP_ALL" | "TCP_FLOW_START" | "TCP_PRE_FLOW" | "TCP_PRE_STREAM" | "SCTP_ALL" | "SCTP_FLOW_START" | "SCTP_PRE_FLOW" | "SCTP_PRE_STREAM" | "IPV6_ALL" | "IPV6_FLOW_START" | "IPV6_PRE_FLOW" | "IPV6_PRE_STREAM" | "ICMPV6_ALL" | "ICMPV6_FLOW_START" | "ICMPV6_PRE_FLOW" | "ICMPV6_PRE_STREAM" | "UDP_ALL" | "UDP_FLOW_START" | "UDP_PRE_FLOW" | "UDP_PRE_STREAM" | "ICMP_ALL" | "ICMP_FLOW_START" | "ICMP_PRE_FLOW" | "ICMP_PRE_STREAM" | "ICMPV4_ALL" | "ICMPV4_FLOW_START" | "ICMPV4_PRE_FLOW" | "ICMPV4_PRE_STREAM" | "IP_ALL" | "IP_FLOW_START" | "IP_PRE_FLOW" | "IP_PRE_STREAM" | "IPV4_ALL" | "IPV4_FLOW_START" | "IPV4_PRE_FLOW" | "IPV4_PRE_STREAM" | "TLS_CLIENT_STARTED" | "TLS_CLIENT_HELLO" | "TLS_CLIENT_CERT" | "TLS_CLIENT_DATA" | "TLS_CLIENT_FINISHED" | "TLS_SERVER_STARTED" | "TLS_SERVER_HELLO" | "TLS_SERVER_CERT" | "TLS_SERVER_DATA" | "TLS_SERVER_FINISHED" | "HTTP1_REQUEST_STARTED" | "HTTP1_REQUEST_LINE" | "HTTP1_REQUEST_HEADERS" | "HTTP1_REQUEST_BODY" | "HTTP1_REQUEST_TRAILER" | "HTTP1_REQUEST_COMPLETE" | "HTTP1_RESPONSE_STARTED" | "HTTP1_RESPONSE_LINE" | "HTTP1_RESPONSE_HEADERS" | "HTTP1_RESPONSE_BODY" | "HTTP1_RESPONSE_TRAILER" | "HTTP1_RESPONSE_COMPLETE" | "HTTP2_STREAM_REQUEST_STARTED" | "HTTP2_STREAM_REQUEST_HEADERS" | "HTTP2_STREAM_REQUEST_DATA" | "HTTP2_STREAM_REQUEST_CLOSED" | "HTTP2_STREAM_REQUEST_COMPLETE" | "HTTP2_STREAM_RESPONSE_STARTED" | "HTTP2_STREAM_RESPONSE_HEADERS" | "HTTP2_STREAM_RESPONSE_DATA" | "HTTP2_STREAM_RESPONSE_CLOSED" | "HTTP2_STREAM_RESPONSE_COMPLETE" | "HTTP2_GLOBAL_REQUEST_STARTED" | "HTTP2_GLOBAL_REQUEST_COMPLETE" | "HTTP2_GLOBAL_RESPONSE_STARTED" | "HTTP2_GLOBAL_RESPONSE_COMPLETE" | "DOH2_STREAM_REQUEST_STARTED" | "DOH2_STREAM_REQUEST_HEADERS" | "DOH2_STREAM_REQUEST_DATA" | "DOH2_STREAM_REQUEST_CLOSED" | "DOH2_STREAM_REQUEST_COMPLETE" | "DOH2_STREAM_RESPONSE_STARTED" | "DOH2_STREAM_RESPONSE_HEADERS" | "DOH2_STREAM_RESPONSE_DATA" | "DOH2_STREAM_RESPONSE_CLOSED" | "DOH2_STREAM_RESPONSE_COMPLETE" | "DOH2_GLOBAL_REQUEST_STARTED" | "DOH2_GLOBAL_REQUEST_COMPLETE" | "DOH2_GLOBAL_RESPONSE_STARTED" | "DOH2_GLOBAL_RESPONSE_COMPLETE" | "DNS_REQUEST_STARTED" | "DNS_REQUEST_COMPLETE" | "DNS_RESPONSE_STARTED" | "DNS_RESPONSE_COMPLETE" | "SMTP_REQUEST_STARTED" | "SMTP_REQUEST_DATA" | "SMTP_REQUEST_COMPLETE" | "SMTP_RESPONSE_STARTED" | "SMTP_RESPONSE_DATA" | "SMTP_RESPONSE_COMPLETE" | "FTP_REQUEST_STARTED" | "FTP_REQUEST_COMPLETE" | "FTP_RESPONSE_STARTED" | "FTP_RESPONSE_COMPLETE" | "FTP_DATA_REQUEST_STARTED" | "FTP_DATA_REQUEST_COMPLETE" | "FTP_DATA_RESPONSE_STARTED" | "FTP_DATA_RESPONSE_COMPLETE" | "SMB_REQUEST_STARTED" | "SMB_REQUEST_COMPLETE" | "SMB_RESPONSE_STARTED" | "SMB_RESPONSE_COMPLETE" | "DCERPC_REQUEST_STARTED" | "DCERPC_REQUEST_COMPLETE" | "DCERPC_RESPONSE_STARTED" | "DCERPC_RESPONSE_COMPLETE" | "NFS_REQUEST_STARTED" | "NFS_REQUEST_COMPLETE" | "NFS_RESPONSE_STARTED" | "NFS_RESPONSE_COMPLETE" | "KRB5_REQUEST_STARTED" | "KRB5_REQUEST_COMPLETE" | "KRB5_RESPONSE_STARTED" | "KRB5_RESPONSE_COMPLETE" | "IKE_REQUEST_STARTED" | "IKE_REQUEST_COMPLETE" | "IKE_RESPONSE_STARTED" | "IKE_RESPONSE_COMPLETE" | "TFTP_REQUEST_STARTED" | "TFTP_REQUEST_COMPLETE" | "TFTP_RESPONSE_STARTED" | "TFTP_RESPONSE_COMPLETE" | "DHCP_REQUEST_STARTED" | "DHCP_REQUEST_COMPLETE" | "DHCP_RESPONSE_STARTED" | "DHCP_RESPONSE_COMPLETE" | "QUIC_REQUEST_STARTED" | "QUIC_REQUEST_COMPLETE" | "QUIC_RESPONSE_STARTED" | "QUIC_RESPONSE_COMPLETE" | "RDP_REQUEST_STARTED" | "RDP_REQUEST_COMPLETE" | "RDP_RESPONSE_STARTED" | "RDP_RESPONSE_COMPLETE" | "RFB_REQUEST_STARTED" | "RFB_REQUEST_COMPLETE" | "RFB_RESPONSE_STARTED" | "RFB_RESPONSE_COMPLETE" | "MQTT_REQUEST_STARTED" | "MQTT_REQUEST_COMPLETE" | "MQTT_RESPONSE_STARTED" | "MQTT_RESPONSE_COMPLETE" | "PGSQL_REQUEST_STARTED" | "PGSQL_REQUEST_COMPLETE" | "PGSQL_RESPONSE_STARTED" | "PGSQL_RESPONSE_COMPLETE" | "SNMP_REQUEST_STARTED" | "SNMP_REQUEST_COMPLETE" | "SNMP_RESPONSE_STARTED" | "SNMP_RESPONSE_COMPLETE" | "NTP_REQUEST_STARTED" | "NTP_REQUEST_COMPLETE" | "NTP_RESPONSE_STARTED" | "NTP_RESPONSE_COMPLETE" | "TELNET_REQUEST_STARTED" | "TELNET_REQUEST_COMPLETE" | "TELNET_RESPONSE_STARTED" | "TELNET_RESPONSE_COMPLETE" | "WEBSOCKET_REQUEST_STARTED" | "WEBSOCKET_REQUEST_COMPLETE" | "WEBSOCKET_RESPONSE_STARTED" | "WEBSOCKET_RESPONSE_COMPLETE" | "LDAP_REQUEST_STARTED" | "LDAP_REQUEST_COMPLETE" | "LDAP_RESPONSE_STARTED" | "LDAP_RESPONSE_COMPLETE" | "POP3_REQUEST_STARTED" | "POP3_REQUEST_COMPLETE" | "POP3_RESPONSE_STARTED" | "POP3_RESPONSE_COMPLETE" | "MDNS_REQUEST_STARTED" | "MDNS_REQUEST_COMPLETE" | "MDNS_RESPONSE_STARTED" | "MDNS_RESPONSE_COMPLETE" | "BITTORRENT_DHT_REQUEST_STARTED" | "BITTORRENT_DHT_REQUEST_COMPLETE" | "BITTORRENT_DHT_RESPONSE_STARTED" | "BITTORRENT_DHT_RESPONSE_COMPLETE" | "DNP3_REQUEST_STARTED" | "DNP3_REQUEST_COMPLETE" | "DNP3_RESPONSE_STARTED" | "DNP3_RESPONSE_COMPLETE" | "SSH_REQUEST_IN_PROGRESS" | "SSH_REQUEST_BANNER_WAIT_EOL" | "SSH_REQUEST_BANNER_DONE" | "SSH_REQUEST_FINISHED" | "SSH_RESPONSE_IN_PROGRESS" | "SSH_RESPONSE_BANNER_WAIT_EOL" | "SSH_RESPONSE_BANNER_DONE" | "SSH_RESPONSE_FINISHED" | (string & {});
export type FirewallRuleProtocol = "IP" | "TCP" | "UDP" | "ICMP" | "HTTP" | "FTP" | "TLS" | "SMB" | "DNS" | "DCERPC" | "SSH" | "SMTP" | "MSN" | "KRB5" | "IKEV2" | "TFTP" | "NTP" | "DHCP" | "HTTP2" | "QUIC" | "ICMPV4" | "ICMPV6" | "SCTP" | "IPV4" | "IPV6" | "DOH2" | "FTP_DATA" | "NFS" | "RDP" | "RFB" | "MQTT" | "PGSQL" | "SNMP" | "TELNET" | "WEBSOCKET" | "LDAP" | "POP3" | "MDNS" | "BITTORRENT_DHT" | "DNP3" | (string & {});
export type Source = string;
export type Destination = string;
export type Port = string;
export type Keyword = string;
export type Setting = string;
export type Settings = string[];
export interface RuleOption {
    Keyword: string;
    Settings?: string[] | undefined;
}
export type RuleOptions = RuleOption[];
export type AcceptPriorHooks = boolean;
export type AlertEnabled = boolean;
export type BypassIPSEnabled = boolean;
export type RuleEnabled = boolean;
export type RuleDescriptionText = string;
export interface RuleMetadata {
    RuleEnabled?: boolean | undefined;
    RuleDescription?: string | undefined;
}
export interface FirewallRule {
    Action: FirewallRuleAction;
    ActionScope: ActionScope;
    Hook: HookKey;
    Protocol: FirewallRuleProtocol;
    SourceIPs?: string | undefined;
    DestIPs?: string | undefined;
    SourcePorts?: string | undefined;
    DestPorts?: string | undefined;
    RuleOptions?: RuleOption[] | undefined;
    AcceptPriorHooks?: boolean | undefined;
    AlertEnabled?: boolean | undefined;
    BypassIPSEnabled?: boolean | undefined;
    RuleMetadata?: RuleMetadata | undefined;
}
export type FirewallRules = FirewallRule[];
export type RuleTargets = string[];
export type TargetType = "TLS_SNI" | "HTTP_HOST" | "AWS_ROUTE_53_RESOLVED_DOMAIN" | (string & {});
export type TargetTypes = TargetType[];
export type GeneratedRulesType = "ALLOWLIST" | "DENYLIST" | "REJECTLIST" | "ALERTLIST" | (string & {});
export interface RulesSourceList {
    Targets: string[];
    TargetTypes: TargetType[];
    GeneratedRulesType: GeneratedRulesType;
}
export interface FirewallRulesSource {
    RulesString?: string | undefined;
    FirewallRules?: FirewallRule[] | undefined;
    RulesSourceList?: RulesSourceList | undefined;
}
export interface PortSet {
    Definition?: string[] | undefined;
}
export type PortSets = {
    [key: string]: PortSet | undefined;
};
export interface RuleVariables {
    IPSets?: {
        [key: string]: IPSet | undefined;
    } | undefined;
    PortSets?: {
        [key: string]: PortSet | undefined;
    } | undefined;
}
export type IPSetReferenceName = string;
export interface IPSetReference {
    ReferenceArn?: string | undefined;
}
export type IPSetReferenceMap = {
    [key: string]: IPSetReference | undefined;
};
export interface ReferenceSets {
    IPSetReferences?: {
        [key: string]: IPSetReference | undefined;
    } | undefined;
}
export interface FirewallRuleGroup {
    RulesSource: FirewallRulesSource;
    RuleVariables?: RuleVariables | undefined;
    ReferenceSets?: ReferenceSets | undefined;
}
export interface FirewallRuleGroupEntry {
    Priority?: number | undefined;
    ResourceArn?: string | undefined;
    InlineRuleGroup?: FirewallRuleGroup | undefined;
}
export type FirewallRuleGroupEntries = FirewallRuleGroupEntry[];
export interface IpsRulesSource {
    RulesString?: string | undefined;
}
export interface IpsRuleGroup {
    RulesSource: IpsRulesSource;
    RuleVariables?: RuleVariables | undefined;
    ReferenceSets?: ReferenceSets | undefined;
}
export interface IpsRuleGroupOverride {
    Action?: OverrideAction | undefined;
}
export interface IpsRuleGroupEntry {
    ResourceArn?: string | undefined;
    InlineRuleGroup?: IpsRuleGroup | undefined;
    Override?: IpsRuleGroupOverride | undefined;
}
export type IpsRuleGroupEntries = IpsRuleGroupEntry[];
export type PolicyMode = "ENFORCE" | "MONITOR" | (string & {});
export type PolicyDefaultAction = "DROP" | "ACCEPT" | "REJECT" | "ALERT" | (string & {});
export type StreamExceptionPolicyV2 = "DROP" | "REJECT" | (string & {});
export interface StatefulEngineOptionsV2 {
    StreamExceptionPolicy?: StreamExceptionPolicyV2 | undefined;
    FlowTimeouts?: FlowTimeouts | undefined;
}
export interface FirewallPolicyV2 {
    FirewallRuleGroupEntries?: FirewallRuleGroupEntry[] | undefined;
    IpsRuleGroupEntries?: IpsRuleGroupEntry[] | undefined;
    PolicyMode?: PolicyMode | undefined;
    FirewallDefaultAction?: PolicyDefaultAction | undefined;
    StatefulEngineOptions?: StatefulEngineOptionsV2 | undefined;
    TLSInspectionConfigurationArn?: string | undefined;
    PolicyVariables?: PolicyVariables | undefined;
    Route53ResolvedIPValidation?: Route53ResolvedIPValidation | undefined;
}
export interface CreateFirewallPolicyV2Request {
    FirewallPolicyV2Name: string;
    FirewallPolicyV2: FirewallPolicyV2;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface FirewallPolicyV2Response {
    FirewallPolicyV2Name: string;
    FirewallPolicyV2Arn: string;
    FirewallPolicyV2Id: string;
    Description?: string | undefined;
    FirewallPolicyV2Status?: ResourceStatus | undefined;
    StatusMessage?: string | undefined;
    Tags?: Tag[] | undefined;
    ConsumedFirewallRuleCapacity?: number | undefined;
    ConsumedIpsRuleCapacity?: number | undefined;
    ConsumedIpsDomainCapacity?: number | undefined;
    NumberOfAssociations?: number | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    Errors?: FirewallPolicyError[] | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface CreateFirewallPolicyV2Response {
    UpdateToken: string;
    FirewallPolicyV2Response: FirewallPolicyV2Response;
}
export type StatefulAction = "PASS" | "DROP" | "ALERT" | "REJECT" | (string & {});
export type StatefulRuleProtocol = "IP" | "TCP" | "UDP" | "ICMP" | "HTTP" | "FTP" | "TLS" | "SMB" | "DNS" | "DCERPC" | "SSH" | "SMTP" | "IMAP" | "MSN" | "KRB5" | "IKEV2" | "TFTP" | "NTP" | "DHCP" | "HTTP2" | "QUIC" | (string & {});
export type StatefulRuleDirection = "FORWARD" | "ANY" | (string & {});
export interface Header {
    Protocol: StatefulRuleProtocol;
    Source: string;
    SourcePort: string;
    Direction: StatefulRuleDirection;
    Destination: string;
    DestinationPort: string;
}
export interface StatefulRule {
    Action: StatefulAction;
    Header: Header;
    RuleOptions: RuleOption[];
}
export type StatefulRules = StatefulRule[];
export type Addresses = Address[];
export type PortRangeBound = number;
export interface PortRange {
    FromPort: number;
    ToPort: number;
}
export type PortRanges = PortRange[];
export type ProtocolNumber = number;
export type ProtocolNumbers = number[];
export type TCPFlag = "FIN" | "SYN" | "RST" | "PSH" | "ACK" | "URG" | "ECE" | "CWR" | (string & {});
export type Flags = TCPFlag[];
export interface TCPFlagField {
    Flags: TCPFlag[];
    Masks?: TCPFlag[] | undefined;
}
export type TCPFlags = TCPFlagField[];
export interface MatchAttributes {
    Sources?: Address[] | undefined;
    Destinations?: Address[] | undefined;
    SourcePorts?: PortRange[] | undefined;
    DestinationPorts?: PortRange[] | undefined;
    Protocols?: number[] | undefined;
    TCPFlags?: TCPFlagField[] | undefined;
}
export interface RuleDefinition {
    MatchAttributes: MatchAttributes;
    Actions: string[];
}
export interface StatelessRule {
    RuleDefinition: RuleDefinition;
    Priority: number;
}
export type StatelessRules = StatelessRule[];
export interface StatelessRulesAndCustomActions {
    StatelessRules: StatelessRule[];
    CustomActions?: CustomAction[] | undefined;
}
export interface RulesSource {
    RulesString?: string | undefined;
    RulesSourceList?: RulesSourceList | undefined;
    StatefulRules?: StatefulRule[] | undefined;
    StatelessRulesAndCustomActions?: StatelessRulesAndCustomActions | undefined;
}
export interface StatefulRuleOptions {
    RuleOrder?: RuleOrder | undefined;
}
export interface RuleGroup {
    RuleVariables?: RuleVariables | undefined;
    ReferenceSets?: ReferenceSets | undefined;
    RulesSource: RulesSource;
    StatefulRuleOptions?: StatefulRuleOptions | undefined;
}
export type RuleGroupType = "STATELESS" | "STATEFUL" | "STATEFUL_DOMAIN" | "FIREWALL" | "IPS" | (string & {});
export interface SourceMetadata {
    SourceArn?: string | undefined;
    SourceUpdateToken?: string | undefined;
}
export type SummaryRuleOption = "SID" | "MSG" | "METADATA" | (string & {});
export type SummaryRuleOptions = SummaryRuleOption[];
export interface SummaryConfiguration {
    RuleOptions?: SummaryRuleOption[] | undefined;
}
export interface CreateRuleGroupRequest {
    RuleGroupName: string;
    RuleGroup?: RuleGroup | undefined;
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
    IpsRuleGroup?: IpsRuleGroup | undefined;
    Rules?: string | undefined;
    Type: RuleGroupType;
    Description?: string | undefined;
    Capacity: number;
    Tags?: Tag[] | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    SourceMetadata?: SourceMetadata | undefined;
    AnalyzeRuleGroup?: boolean | undefined;
    SummaryConfiguration?: SummaryConfiguration | undefined;
}
export type RuleIdList = string[];
export type IdentifiedType = "STATELESS_RULE_FORWARDING_ASYMMETRICALLY" | "STATELESS_RULE_CONTAINS_TCP_FLAGS" | (string & {});
export interface AnalysisResult {
    IdentifiedRuleIds?: string[] | undefined;
    IdentifiedType?: IdentifiedType | undefined;
    AnalysisDetail?: string | undefined;
}
export type AnalysisResultList = AnalysisResult[];
export interface RuleGroupResponse {
    RuleGroupArn: string;
    RuleGroupName: string;
    RuleGroupId: string;
    Description?: string | undefined;
    Type?: RuleGroupType | undefined;
    Capacity?: number | undefined;
    RuleGroupStatus?: ResourceStatus | undefined;
    Tags?: Tag[] | undefined;
    ConsumedCapacity?: number | undefined;
    NumberOfAssociations?: number | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    SourceMetadata?: SourceMetadata | undefined;
    SnsTopic?: string | undefined;
    LastModifiedTime?: Date | undefined;
    AnalysisResults?: AnalysisResult[] | undefined;
    SummaryConfiguration?: SummaryConfiguration | undefined;
}
export interface CreateRuleGroupResponse {
    UpdateToken: string;
    RuleGroupResponse: RuleGroupResponse;
}
export interface ServerCertificate {
    ResourceArn?: string | undefined;
}
export type ServerCertificates = ServerCertificate[];
export type TLSInspectionDomain = string;
export type TLSInspectionDomains = string[];
export interface DomainMatch {
    Domains: string[];
}
export type DecryptionAction = "DECRYPT" | "BYPASS" | (string & {});
export type TLSInspectionScopeDeploymentMode = "TRANSPARENT_FIREWALL_ONLY" | "EXPLICIT_PROXY_ONLY" | "ALL" | (string & {});
export interface ServerCertificateScope {
    Sources?: Address[] | undefined;
    Destinations?: Address[] | undefined;
    SourcePorts?: PortRange[] | undefined;
    DestinationPorts?: PortRange[] | undefined;
    Protocols?: number[] | undefined;
    DomainMatch?: DomainMatch | undefined;
    DecryptionAction?: DecryptionAction | undefined;
    DeploymentMode?: TLSInspectionScopeDeploymentMode | undefined;
}
export type ServerCertificateScopes = ServerCertificateScope[];
export type RevocationCheckAction = "PASS" | "DROP" | "REJECT" | (string & {});
export interface CheckCertificateRevocationStatusActions {
    RevokedStatusAction?: RevocationCheckAction | undefined;
    UnknownStatusAction?: RevocationCheckAction | undefined;
}
export interface ServerCertificateConfiguration {
    ServerCertificates?: ServerCertificate[] | undefined;
    Scopes?: ServerCertificateScope[] | undefined;
    CertificateAuthorityArn?: string | undefined;
    CheckCertificateRevocationStatus?: CheckCertificateRevocationStatusActions | undefined;
    DefaultDecryptionBehavior?: DecryptionAction | undefined;
}
export type ServerCertificateConfigurations = ServerCertificateConfiguration[];
export interface TLSInspectionConfiguration {
    ServerCertificateConfigurations?: ServerCertificateConfiguration[] | undefined;
}
export interface CreateTLSInspectionConfigurationRequest {
    TLSInspectionConfigurationName: string;
    TLSInspectionConfiguration: TLSInspectionConfiguration;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface TlsCertificateData {
    CertificateArn?: string | undefined;
    CertificateSerial?: string | undefined;
    Status?: string | undefined;
    StatusMessage?: string | undefined;
}
export type Certificates = TlsCertificateData[];
export interface TLSInspectionConfigurationResponse {
    TLSInspectionConfigurationArn: string;
    TLSInspectionConfigurationName: string;
    TLSInspectionConfigurationId: string;
    TLSInspectionConfigurationStatus?: ResourceStatus | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    LastModifiedTime?: Date | undefined;
    NumberOfAssociations?: number | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    Certificates?: TlsCertificateData[] | undefined;
    CertificateAuthority?: TlsCertificateData | undefined;
}
export interface CreateTLSInspectionConfigurationResponse {
    UpdateToken: string;
    TLSInspectionConfigurationResponse: TLSInspectionConfigurationResponse;
}
export interface CreateVpcEndpointAssociationRequest {
    FirewallArn: string;
    VpcId: string;
    SubnetMapping: SubnetMapping;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface VpcEndpointAssociation {
    VpcEndpointAssociationId?: string | undefined;
    VpcEndpointAssociationArn: string;
    FirewallArn: string;
    VpcId: string;
    SubnetMapping: SubnetMapping;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface AZSyncState {
    Attachment?: Attachment | undefined;
}
export type AssociationSyncState = {
    [key: string]: AZSyncState | undefined;
};
export interface VpcEndpointAssociationStatus {
    Status: FirewallStatusValue;
    AssociationSyncState?: {
        [key: string]: AZSyncState | undefined;
    } | undefined;
}
export interface CreateVpcEndpointAssociationResponse {
    VpcEndpointAssociation?: VpcEndpointAssociation | undefined;
    VpcEndpointAssociationStatus?: VpcEndpointAssociationStatus | undefined;
}
export interface DeleteContainerAssociationRequest {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
}
export interface DeleteContainerAssociationResponse {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
    Status?: ContainerAssociationStatus | undefined;
}
export interface DeleteFirewallRequest {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
    DeleteAssociatedNatGateways?: boolean | undefined;
}
export interface DeleteFirewallResponse {
    Firewall?: Firewall | undefined;
    FirewallStatus?: FirewallStatus | undefined;
}
export interface DeleteFirewallPolicyRequest {
    FirewallPolicyName?: string | undefined;
    FirewallPolicyArn?: string | undefined;
}
export interface DeleteFirewallPolicyResponse {
    FirewallPolicyResponse: FirewallPolicyResponse;
}
export interface DeleteFirewallPolicyV2Request {
    FirewallPolicyV2Arn?: string | undefined;
    FirewallPolicyV2Name?: string | undefined;
}
export interface DeleteFirewallPolicyV2Response {
    FirewallPolicyV2Response: FirewallPolicyV2Response;
}
export interface DeleteNetworkFirewallTransitGatewayAttachmentRequest {
    TransitGatewayAttachmentId: string;
}
export interface DeleteNetworkFirewallTransitGatewayAttachmentResponse {
    TransitGatewayAttachmentId: string;
    TransitGatewayAttachmentStatus: TransitGatewayAttachmentStatus;
}
export interface DeleteProxyRequest {
    NatGatewayId: string;
    ProxyName?: string | undefined;
    ProxyArn?: string | undefined;
}
export interface DeleteProxyResponse {
    NatGatewayId?: string | undefined;
    ProxyName?: string | undefined;
    ProxyArn?: string | undefined;
}
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteRuleGroupRequest {
    RuleGroupName?: string | undefined;
    RuleGroupArn?: string | undefined;
    Type?: RuleGroupType | undefined;
}
export interface DeleteRuleGroupResponse {
    RuleGroupResponse: RuleGroupResponse;
}
export interface DeleteTLSInspectionConfigurationRequest {
    TLSInspectionConfigurationArn?: string | undefined;
    TLSInspectionConfigurationName?: string | undefined;
}
export interface DeleteTLSInspectionConfigurationResponse {
    TLSInspectionConfigurationResponse: TLSInspectionConfigurationResponse;
}
export interface DeleteVpcEndpointAssociationRequest {
    VpcEndpointAssociationArn: string;
}
export interface DeleteVpcEndpointAssociationResponse {
    VpcEndpointAssociation?: VpcEndpointAssociation | undefined;
    VpcEndpointAssociationStatus?: VpcEndpointAssociationStatus | undefined;
}
export interface DescribeContainerAssociationRequest {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
}
export type ContainerAssociationLastUpdatedTime = Date;
export interface DescribeContainerAssociationResponse {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
    Description?: string | undefined;
    Type?: ContainerMonitoringType | undefined;
    ContainerMonitoringConfigurations?: ContainerMonitoringConfiguration[] | undefined;
    Status?: ContainerAssociationStatus | undefined;
    ResolvedCidrCount?: number | undefined;
    LastUpdatedTime?: Date | undefined;
    Tags?: Tag[] | undefined;
    UpdateToken?: string | undefined;
}
export interface DescribeFirewallRequest {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
}
export interface DescribeFirewallResponse {
    UpdateToken?: string | undefined;
    Firewall?: Firewall | undefined;
    FirewallStatus?: FirewallStatus | undefined;
}
export interface DescribeFirewallMetadataRequest {
    FirewallArn?: string | undefined;
}
export interface AvailabilityZoneMetadata {
    IPAddressType?: IPAddressType | undefined;
}
export type SupportedAvailabilityZones = {
    [key: string]: AvailabilityZoneMetadata | undefined;
};
export interface DescribeFirewallMetadataResponse {
    FirewallArn?: string | undefined;
    FirewallPolicyArn?: string | undefined;
    Description?: string | undefined;
    Status?: FirewallStatusValue | undefined;
    SupportedAvailabilityZones?: {
        [key: string]: AvailabilityZoneMetadata | undefined;
    } | undefined;
    TransitGatewayAttachmentId?: string | undefined;
}
export interface DescribeFirewallPolicyRequest {
    FirewallPolicyName?: string | undefined;
    FirewallPolicyArn?: string | undefined;
}
export interface DescribeFirewallPolicyResponse {
    UpdateToken: string;
    FirewallPolicyResponse: FirewallPolicyResponse;
    FirewallPolicy?: FirewallPolicy | undefined;
}
export type RuleOutputFormat = "FIREWALL_RULES" | "RULES_STRING" | (string & {});
export interface DescribeFirewallPolicyV2Request {
    FirewallPolicyV2Arn?: string | undefined;
    FirewallPolicyV2Name?: string | undefined;
    RuleOutputFormat?: RuleOutputFormat | undefined;
}
export interface DescribeFirewallPolicyV2Response {
    UpdateToken: string;
    FirewallPolicyV2Response: FirewallPolicyV2Response;
    FirewallPolicyV2?: FirewallPolicyV2 | undefined;
}
export type AvailabilityZoneId = string;
export type VpcEndpointId = string;
export type FlowOperationId = string;
export interface DescribeFlowOperationRequest {
    FirewallArn: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    FlowOperationId: string;
}
export type FlowOperationType = "FLOW_FLUSH" | "FLOW_CAPTURE" | (string & {});
export type FlowOperationStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | "COMPLETED_WITH_ERRORS" | (string & {});
export type FlowRequestTimestamp = Date;
export type Age = number;
export type ProtocolString = string;
export type ProtocolStrings = string[];
export interface FlowFilter {
    SourceAddress?: Address | undefined;
    DestinationAddress?: Address | undefined;
    SourcePort?: string | undefined;
    DestinationPort?: string | undefined;
    Protocols?: string[] | undefined;
}
export type FlowFilters = FlowFilter[];
export interface FlowOperation {
    MinimumFlowAgeInSeconds?: number | undefined;
    FlowFilters?: FlowFilter[] | undefined;
}
export interface DescribeFlowOperationResponse {
    FirewallArn?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    FlowOperationId?: string | undefined;
    FlowOperationType?: FlowOperationType | undefined;
    FlowOperationStatus?: FlowOperationStatus | undefined;
    StatusMessage?: string | undefined;
    FlowRequestTimestamp?: Date | undefined;
    FlowOperation?: FlowOperation | undefined;
}
export interface DescribeLoggingConfigurationRequest {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
}
export type LogType = "ALERT" | "FLOW" | "TLS" | (string & {});
export type LogDestinationType = "S3" | "CloudWatchLogs" | "KinesisDataFirehose" | (string & {});
export type HashMapKey = string;
export type HashMapValue = string;
export type LogDestinationMap = {
    [key: string]: string | undefined;
};
export interface LogDestinationConfig {
    LogType: LogType;
    LogDestinationType: LogDestinationType;
    LogDestination: {
        [key: string]: string | undefined;
    };
}
export type LogDestinationConfigs = LogDestinationConfig[];
export interface LoggingConfiguration {
    LogDestinationConfigs: LogDestinationConfig[];
}
export type EnableMonitoringDashboard = boolean;
export interface DescribeLoggingConfigurationResponse {
    FirewallArn?: string | undefined;
    LoggingConfiguration?: LoggingConfiguration | undefined;
    EnableMonitoringDashboard?: boolean | undefined;
}
export interface DescribeProxyRequest {
    ProxyName?: string | undefined;
    ProxyArn?: string | undefined;
}
export type ProxyState = "ATTACHING" | "ATTACHED" | "DETACHING" | "DETACHED" | "ATTACH_FAILED" | "DETACH_FAILED" | (string & {});
export type ProxyModifyState = "MODIFYING" | "COMPLETED" | "FAILED" | (string & {});
export type TlsInterceptMode = "ENABLED" | "DISABLED" | (string & {});
export interface TlsInterceptProperties {
    PcaArn?: string | undefined;
    TlsInterceptMode?: TlsInterceptMode | undefined;
}
export type VpcEndpointServiceName = string;
export type PrivateDNSName = string;
export type CreateTime = Date;
export type DeleteTime = Date;
export type UpdateTime = Date;
export type FailureCode = string;
export type FailureMessage = string;
export interface DescribeProxyResource {
    ProxyName?: string | undefined;
    ProxyArn?: string | undefined;
    ProxyConfigurationName?: string | undefined;
    ProxyConfigurationArn?: string | undefined;
    NatGatewayId?: string | undefined;
    ProxyState?: ProxyState | undefined;
    ProxyModifyState?: ProxyModifyState | undefined;
    ListenerProperties?: ListenerProperty[] | undefined;
    TlsInterceptProperties?: TlsInterceptProperties | undefined;
    VpcEndpointServiceName?: string | undefined;
    PrivateDNSName?: string | undefined;
    CreateTime?: Date | undefined;
    DeleteTime?: Date | undefined;
    UpdateTime?: Date | undefined;
    FailureCode?: string | undefined;
    FailureMessage?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeProxyResponse {
    Proxy?: DescribeProxyResource | undefined;
    UpdateToken?: string | undefined;
}
export interface DescribeResourcePolicyRequest {
    ResourceArn: string;
}
export type PolicyString = string;
export interface DescribeResourcePolicyResponse {
    Policy?: string | undefined;
}
export interface DescribeRuleGroupRequest {
    RuleGroupName?: string | undefined;
    RuleGroupArn?: string | undefined;
    Type?: RuleGroupType | undefined;
    AnalyzeRuleGroup?: boolean | undefined;
    RuleOutputFormat?: RuleOutputFormat | undefined;
}
export interface DescribeRuleGroupResponse {
    UpdateToken: string;
    RuleGroup?: RuleGroup | undefined;
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
    IpsRuleGroup?: IpsRuleGroup | undefined;
    RuleGroupResponse: RuleGroupResponse;
}
export interface DescribeRuleGroupMetadataRequest {
    RuleGroupName?: string | undefined;
    RuleGroupArn?: string | undefined;
    Type?: RuleGroupType | undefined;
}
export type VendorName = string;
export type ProductId = string;
export type ListingName = string;
export interface DescribeRuleGroupMetadataResponse {
    RuleGroupArn: string;
    RuleGroupName: string;
    Description?: string | undefined;
    Type?: RuleGroupType | undefined;
    Capacity?: number | undefined;
    StatefulRuleOptions?: StatefulRuleOptions | undefined;
    LastModifiedTime?: Date | undefined;
    VendorName?: string | undefined;
    ProductId?: string | undefined;
    ListingName?: string | undefined;
}
export interface DescribeRuleGroupSummaryRequest {
    RuleGroupName?: string | undefined;
    RuleGroupArn?: string | undefined;
    Type?: RuleGroupType | undefined;
}
export interface RuleSummary {
    SID?: string | undefined;
    Msg?: string | undefined;
    Metadata?: string | undefined;
}
export type RuleSummaries = RuleSummary[];
export interface Summary {
    RuleSummaries?: RuleSummary[] | undefined;
}
export interface DescribeRuleGroupSummaryResponse {
    RuleGroupName: string;
    Description?: string | undefined;
    Summary?: Summary | undefined;
}
export interface DescribeTLSInspectionConfigurationRequest {
    TLSInspectionConfigurationArn?: string | undefined;
    TLSInspectionConfigurationName?: string | undefined;
}
export interface DescribeTLSInspectionConfigurationResponse {
    UpdateToken: string;
    TLSInspectionConfiguration?: TLSInspectionConfiguration | undefined;
    TLSInspectionConfigurationResponse: TLSInspectionConfigurationResponse;
}
export interface DescribeVpcEndpointAssociationRequest {
    VpcEndpointAssociationArn: string;
}
export interface DescribeVpcEndpointAssociationResponse {
    VpcEndpointAssociation?: VpcEndpointAssociation | undefined;
    VpcEndpointAssociationStatus?: VpcEndpointAssociationStatus | undefined;
}
export interface DisassociateAvailabilityZonesRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneMappings: AvailabilityZoneMapping[];
}
export interface DisassociateAvailabilityZonesResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneMappings?: AvailabilityZoneMapping[] | undefined;
    UpdateToken?: string | undefined;
}
export type AzSubnets = string[];
export interface DisassociateSubnetsRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetIds: string[];
}
export interface DisassociateSubnetsResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetMappings?: SubnetMapping[] | undefined;
    UpdateToken?: string | undefined;
}
export type AnalysisReportId = string;
export type AnalysisReportNextToken = string;
export type PaginationMaxResults = number;
export interface GetAnalysisReportResultsRequest {
    FirewallName?: string | undefined;
    AnalysisReportId: string;
    FirewallArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Status = string;
export type StartTime = Date;
export type EndTime = Date;
export type ReportTime = Date;
export type FirstAccessed = Date;
export type LastAccessed = Date;
export type Domain = string;
export type Count = number;
export interface Hits {
    Count?: number | undefined;
}
export interface UniqueSources {
    Count?: number | undefined;
}
export interface AnalysisTypeReportResult {
    Protocol?: string | undefined;
    FirstAccessed?: Date | undefined;
    LastAccessed?: Date | undefined;
    Domain?: string | undefined;
    Hits?: Hits | undefined;
    UniqueSources?: UniqueSources | undefined;
}
export type AnalysisReportResults = AnalysisTypeReportResult[];
export interface GetAnalysisReportResultsResponse {
    Status?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ReportTime?: Date | undefined;
    AnalysisType?: EnabledAnalysisType | undefined;
    NextToken?: string | undefined;
    AnalysisReportResults?: AnalysisTypeReportResult[] | undefined;
}
export type PaginationToken = string;
export interface ListAnalysisReportsRequest {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AnalysisReport {
    AnalysisReportId?: string | undefined;
    AnalysisType?: EnabledAnalysisType | undefined;
    ReportTime?: Date | undefined;
    Status?: string | undefined;
}
export type AnalysisReports = AnalysisReport[];
export interface ListAnalysisReportsResponse {
    AnalysisReports?: AnalysisReport[] | undefined;
    NextToken?: string | undefined;
}
export interface ListContainerAssociationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ContainerAssociationSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export type ContainerAssociations = ContainerAssociationSummary[];
export interface ListContainerAssociationsResponse {
    ContainerAssociations?: ContainerAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFirewallPoliciesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FirewallPolicyMetadata {
    Name?: string | undefined;
    Arn?: string | undefined;
}
export type FirewallPolicies = FirewallPolicyMetadata[];
export interface ListFirewallPoliciesResponse {
    NextToken?: string | undefined;
    FirewallPolicies?: FirewallPolicyMetadata[] | undefined;
}
export interface ListFirewallPoliciesV2Request {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FirewallPolicyV2Metadata {
    Name?: string | undefined;
    Arn?: string | undefined;
}
export type FirewallPoliciesV2 = FirewallPolicyV2Metadata[];
export interface ListFirewallPoliciesV2Response {
    NextToken?: string | undefined;
    FirewallPoliciesV2: FirewallPolicyV2Metadata[];
}
export type VpcIds = string[];
export interface ListFirewallsRequest {
    NextToken?: string | undefined;
    VpcIds?: string[] | undefined;
    MaxResults?: number | undefined;
}
export interface FirewallMetadata {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
    TransitGatewayAttachmentId?: string | undefined;
}
export type Firewalls = FirewallMetadata[];
export interface ListFirewallsResponse {
    NextToken?: string | undefined;
    Firewalls?: FirewallMetadata[] | undefined;
}
export interface ListFlowOperationResultsRequest {
    FirewallArn: string;
    FlowOperationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
}
export type PacketCount = number;
export type ByteCount = number;
export interface Flow {
    SourceAddress?: Address | undefined;
    DestinationAddress?: Address | undefined;
    SourcePort?: string | undefined;
    DestinationPort?: string | undefined;
    Protocol?: string | undefined;
    Age?: number | undefined;
    PacketCount?: number | undefined;
    ByteCount?: number | undefined;
}
export type Flows = Flow[];
export interface ListFlowOperationResultsResponse {
    FirewallArn?: string | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    FlowOperationId?: string | undefined;
    FlowOperationStatus?: FlowOperationStatus | undefined;
    StatusMessage?: string | undefined;
    FlowRequestTimestamp?: Date | undefined;
    Flows?: Flow[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFlowOperationsRequest {
    FirewallArn: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    FlowOperationType?: FlowOperationType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FlowOperationMetadata {
    FlowOperationId?: string | undefined;
    FlowOperationType?: FlowOperationType | undefined;
    FlowRequestTimestamp?: Date | undefined;
    FlowOperationStatus?: FlowOperationStatus | undefined;
}
export type FlowOperations = FlowOperationMetadata[];
export interface ListFlowOperationsResponse {
    FlowOperations?: FlowOperationMetadata[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceManagedStatus = "MANAGED" | "ACCOUNT" | (string & {});
export type ResourceManagedType = "AWS_MANAGED_THREAT_SIGNATURES" | "AWS_MANAGED_DOMAIN_LISTS" | "ACTIVE_THREAT_DEFENSE" | "PARTNER_MANAGED" | (string & {});
export type SubscriptionStatus = "NOT_SUBSCRIBED" | "SUBSCRIBED" | (string & {});
export interface ListRuleGroupsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Scope?: ResourceManagedStatus | undefined;
    ManagedType?: ResourceManagedType | undefined;
    SubscriptionStatus?: SubscriptionStatus | undefined;
    Type?: RuleGroupType | undefined;
}
export interface RuleGroupMetadata {
    Name?: string | undefined;
    Arn?: string | undefined;
    VendorName?: string | undefined;
}
export type RuleGroups = RuleGroupMetadata[];
export interface ListRuleGroupsResponse {
    NextToken?: string | undefined;
    RuleGroups?: RuleGroupMetadata[] | undefined;
}
export type TagsPaginationMaxResults = number;
export interface ListTagsForResourceRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    NextToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ListTLSInspectionConfigurationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TLSInspectionConfigurationMetadata {
    Name?: string | undefined;
    Arn?: string | undefined;
}
export type TLSInspectionConfigurations = TLSInspectionConfigurationMetadata[];
export interface ListTLSInspectionConfigurationsResponse {
    NextToken?: string | undefined;
    TLSInspectionConfigurations?: TLSInspectionConfigurationMetadata[] | undefined;
}
export interface ListVpcEndpointAssociationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    FirewallArn?: string | undefined;
}
export interface VpcEndpointAssociationMetadata {
    VpcEndpointAssociationArn?: string | undefined;
}
export type VpcEndpointAssociations = VpcEndpointAssociationMetadata[];
export interface ListVpcEndpointAssociationsResponse {
    NextToken?: string | undefined;
    VpcEndpointAssociations?: VpcEndpointAssociationMetadata[] | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export interface PutResourcePolicyResponse {
}
export interface RejectNetworkFirewallTransitGatewayAttachmentRequest {
    TransitGatewayAttachmentId: string;
}
export interface RejectNetworkFirewallTransitGatewayAttachmentResponse {
    TransitGatewayAttachmentId: string;
    TransitGatewayAttachmentStatus: TransitGatewayAttachmentStatus;
}
export interface StartAnalysisReportRequest {
    FirewallName?: string | undefined;
    FirewallArn?: string | undefined;
    AnalysisType: EnabledAnalysisType;
}
export interface StartAnalysisReportResponse {
    AnalysisReportId: string;
}
export interface StartFlowCaptureRequest {
    FirewallArn: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    MinimumFlowAgeInSeconds?: number | undefined;
    FlowFilters: FlowFilter[];
}
export interface StartFlowCaptureResponse {
    FirewallArn?: string | undefined;
    FlowOperationId?: string | undefined;
    FlowOperationStatus?: FlowOperationStatus | undefined;
}
export interface StartFlowFlushRequest {
    FirewallArn: string;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    VpcEndpointAssociationArn?: string | undefined;
    VpcEndpointId?: string | undefined;
    MinimumFlowAgeInSeconds?: number | undefined;
    FlowFilters: FlowFilter[];
}
export interface StartFlowFlushResponse {
    FirewallArn?: string | undefined;
    FlowOperationId?: string | undefined;
    FlowOperationStatus?: FlowOperationStatus | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAvailabilityZoneChangeProtectionRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneChangeProtection: boolean;
}
export interface UpdateAvailabilityZoneChangeProtectionResponse {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    AvailabilityZoneChangeProtection?: boolean | undefined;
}
export interface UpdateContainerAssociationRequest {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
    Description?: string | undefined;
    Type: ContainerMonitoringType;
    ContainerMonitoringConfigurations: ContainerMonitoringConfiguration[];
    Tags?: Tag[] | undefined;
    UpdateToken: string;
}
export interface UpdateContainerAssociationResponse {
    ContainerAssociationName?: string | undefined;
    ContainerAssociationArn?: string | undefined;
    Description?: string | undefined;
    Type?: ContainerMonitoringType | undefined;
    ContainerMonitoringConfigurations?: ContainerMonitoringConfiguration[] | undefined;
    Status?: ContainerAssociationStatus | undefined;
    Tags?: Tag[] | undefined;
    UpdateToken?: string | undefined;
}
export interface UpdateFirewallAnalysisSettingsRequest {
    EnabledAnalysisTypes?: EnabledAnalysisType[] | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    UpdateToken?: string | undefined;
}
export interface UpdateFirewallAnalysisSettingsResponse {
    EnabledAnalysisTypes?: EnabledAnalysisType[] | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    UpdateToken?: string | undefined;
}
export interface UpdateFirewallDeleteProtectionRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    DeleteProtection: boolean;
}
export interface UpdateFirewallDeleteProtectionResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    DeleteProtection?: boolean | undefined;
    UpdateToken?: string | undefined;
}
export interface UpdateFirewallDescriptionRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateFirewallDescriptionResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    Description?: string | undefined;
    UpdateToken?: string | undefined;
}
export interface UpdateFirewallEncryptionConfigurationRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateFirewallEncryptionConfigurationResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    UpdateToken?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateFirewallPolicyRequest {
    UpdateToken: string;
    FirewallPolicyArn?: string | undefined;
    FirewallPolicyName?: string | undefined;
    FirewallPolicy: FirewallPolicy;
    Description?: string | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateFirewallPolicyResponse {
    UpdateToken: string;
    FirewallPolicyResponse: FirewallPolicyResponse;
}
export interface UpdateFirewallPolicyChangeProtectionRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    FirewallPolicyChangeProtection: boolean;
}
export interface UpdateFirewallPolicyChangeProtectionResponse {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    FirewallPolicyChangeProtection?: boolean | undefined;
}
export interface UpdateFirewallPolicyV2Request {
    UpdateToken: string;
    FirewallPolicyV2Arn?: string | undefined;
    FirewallPolicyV2Name?: string | undefined;
    FirewallPolicyV2: FirewallPolicyV2;
    Description?: string | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
}
export interface UpdateFirewallPolicyV2Response {
    UpdateToken: string;
    FirewallPolicyV2Response: FirewallPolicyV2Response;
}
export interface UpdateLoggingConfigurationRequest {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    LoggingConfiguration?: LoggingConfiguration | undefined;
    EnableMonitoringDashboard?: boolean | undefined;
}
export interface UpdateLoggingConfigurationResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    LoggingConfiguration?: LoggingConfiguration | undefined;
    EnableMonitoringDashboard?: boolean | undefined;
}
export interface UpdateProxySettingsRequest {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    UpdateToken?: string | undefined;
    ProxySettings?: ProxySettings | undefined;
}
export interface UpdateProxySettingsResponse {
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    UpdateToken?: string | undefined;
    ProxySettings?: ProxySettings | undefined;
}
export interface UpdateRuleGroupRequest {
    UpdateToken: string;
    RuleGroupArn?: string | undefined;
    RuleGroupName?: string | undefined;
    RuleGroup?: RuleGroup | undefined;
    FirewallRuleGroup?: FirewallRuleGroup | undefined;
    IpsRuleGroup?: IpsRuleGroup | undefined;
    Rules?: string | undefined;
    Type?: RuleGroupType | undefined;
    Description?: string | undefined;
    DryRun?: boolean | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    SourceMetadata?: SourceMetadata | undefined;
    AnalyzeRuleGroup?: boolean | undefined;
    SummaryConfiguration?: SummaryConfiguration | undefined;
}
export interface UpdateRuleGroupResponse {
    UpdateToken: string;
    RuleGroupResponse: RuleGroupResponse;
}
export interface UpdateSubnetChangeProtectionRequest {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetChangeProtection: boolean;
}
export interface UpdateSubnetChangeProtectionResponse {
    UpdateToken?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallName?: string | undefined;
    SubnetChangeProtection?: boolean | undefined;
}
export interface UpdateTLSInspectionConfigurationRequest {
    TLSInspectionConfigurationArn?: string | undefined;
    TLSInspectionConfigurationName?: string | undefined;
    TLSInspectionConfiguration: TLSInspectionConfiguration;
    Description?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    UpdateToken: string;
}
export interface UpdateTLSInspectionConfigurationResponse {
    UpdateToken: string;
    TLSInspectionConfigurationResponse: TLSInspectionConfigurationResponse;
}
export type ErrorMessage = string;
export type AcceptNetworkFirewallTransitGatewayAttachmentError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Accepts a transit gateway attachment request for Network Firewall. When you accept the attachment request, Network Firewall creates the necessary routing components to enable traffic flow between the transit gateway and firewall endpoints.
 *
 * You must accept a transit gateway attachment to complete the creation of a transit gateway-attached firewall, unless auto-accept is enabled on the transit gateway. After acceptance, use DescribeFirewall to verify the firewall status.
 *
 * To reject an attachment instead of accepting it, use RejectNetworkFirewallTransitGatewayAttachment.
 *
 * It can take several minutes for the attachment acceptance to complete and the firewall to become available.
 */
export declare const acceptNetworkFirewallTransitGatewayAttachment: API.OperationMethod<AcceptNetworkFirewallTransitGatewayAttachmentRequest & RegionInput, AcceptNetworkFirewallTransitGatewayAttachmentResponse, AcceptNetworkFirewallTransitGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type AssociateAvailabilityZonesError = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates the specified Availability Zones with a transit gateway-attached firewall. For each Availability Zone, Network Firewall creates a firewall endpoint to process traffic. You can specify one or more Availability Zones where you want to deploy the firewall.
 *
 * After adding Availability Zones, you must update your transit gateway route tables to direct traffic through the new firewall endpoints. Use DescribeFirewall to monitor the status of the new endpoints.
 */
export declare const associateAvailabilityZones: API.OperationMethod<AssociateAvailabilityZonesRequest & RegionInput, AssociateAvailabilityZonesResponse, AssociateAvailabilityZonesError, Credentials | HttpClient.HttpClient>;
export type AssociateFirewallPolicyError = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a FirewallPolicy to a Firewall.
 *
 * A firewall policy defines how to monitor and manage your VPC network traffic, using a
 * collection of inspection rule groups and other settings. Each firewall requires one
 * firewall policy association, and you can use the same firewall policy for multiple
 * firewalls.
 */
export declare const associateFirewallPolicy: API.OperationMethod<AssociateFirewallPolicyRequest & RegionInput, AssociateFirewallPolicyResponse, AssociateFirewallPolicyError, Credentials | HttpClient.HttpClient>;
export type AssociateSubnetsError = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates the specified subnets in the Amazon VPC to the firewall. You can specify one
 * subnet for each of the Availability Zones that the VPC spans.
 *
 * This request creates an Network Firewall firewall endpoint in each of the subnets. To
 * enable the firewall's protections, you must also modify the VPC's route tables for each
 * subnet's Availability Zone, to redirect the traffic that's coming into and going out of the
 * zone through the firewall endpoint.
 *
 * For a proxy mode firewall, use this operation to add Availability Zones to the firewall. For each subnet, specify a NAT gateway in `NatGatewayCreateMappings` in the same Availability Zone. You can't add an Availability Zone that the firewall already uses. The firewall keeps working in its other Availability Zones while Network Firewall sets up the new one. If Network Firewall can't set up the new Availability Zone, it removes the Availability Zone from the firewall. It also deletes the NAT gateway that it created there. The Availability Zone's `Attachment` status shows the reason. You can then add the Availability Zone again.
 */
export declare const associateSubnets: API.OperationMethod<AssociateSubnetsRequest & RegionInput, AssociateSubnetsResponse, AssociateSubnetsError, Credentials | HttpClient.HttpClient>;
export type CreateContainerAssociationError = InsufficientCapacityException | InternalServerError | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a Network Firewall container association. The association monitors container lifecycle events in your
 * Amazon ECS or Amazon EKS clusters and resolves running container addresses for use in firewall rules.
 */
export declare const createContainerAssociation: API.OperationMethod<CreateContainerAssociationRequest & RegionInput, CreateContainerAssociationResponse, CreateContainerAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallError = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an Network Firewall Firewall and accompanying FirewallStatus for a VPC.
 *
 * The firewall defines the configuration settings for an Network Firewall firewall. The settings that you can define at creation include the firewall policy, the subnets in your VPC to use for the firewall endpoints, and any tags that are attached to the firewall Amazon Web Services resource.
 *
 * After you create a firewall, you can provide additional settings, like the logging configuration.
 *
 * To update the settings for a firewall, you use the operations that apply to the settings
 * themselves, for example UpdateLoggingConfiguration, AssociateSubnets, and UpdateFirewallDeleteProtection.
 *
 * To manage a firewall's tags, use the standard Amazon Web Services resource tagging operations, ListTagsForResource, TagResource, and UntagResource.
 *
 * To retrieve information about firewalls, use ListFirewalls and DescribeFirewall.
 *
 * To generate a report on the last 30 days of traffic monitored by a firewall, use StartAnalysisReport.
 *
 * To create a proxy mode firewall, specify `VpcEndpoint` and `NatGatewayCreateMappings` instead of `VpcId` and `SubnetMappings`. A proxy mode firewall is an explicit forward proxy. Your clients send HTTP and HTTPS proxy requests to the firewall's proxy DNS name, which `DescribeFirewall` returns in each Availability Zone's `Attachment`. The firewall evaluates proxy traffic with the stateful rules in its firewall policy, and sends allowed traffic out through the NAT gateway in the same Availability Zone. Your clients don't need route table changes. In each Availability Zone, the firewall has one endpoint and one NAT gateway, which Network Firewall creates for you.
 */
export declare const createFirewall: API.OperationMethod<CreateFirewallRequest & RegionInput, CreateFirewallResponse, CreateFirewallError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallPolicyError = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates the firewall policy for the firewall according to the specifications.
 *
 * An Network Firewall firewall policy defines the behavior of a firewall, in a collection of
 * stateless and stateful rule groups and other settings. You can use one firewall policy for
 * multiple firewalls.
 */
export declare const createFirewallPolicy: API.OperationMethod<CreateFirewallPolicyRequest & RegionInput, CreateFirewallPolicyResponse, CreateFirewallPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateFirewallPolicyV2Error = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a Next Generation policy according to the specifications.
 *
 * A Next Generation policy defines the behavior of a firewall in a collection of firewall engine and IPS engine rule groups and other settings. You can use one firewall policy for multiple firewalls. For more information, see Next Generation policies in the *Network Firewall Developer Guide*.
 */
export declare const createFirewallPolicyV2: API.OperationMethod<CreateFirewallPolicyV2Request & RegionInput, CreateFirewallPolicyV2Response, CreateFirewallPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type CreateRuleGroupError = InsufficientCapacityException | InternalServerError | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates the specified stateless or stateful rule group, which includes the rules for
 * network traffic inspection, a capacity setting, and tags.
 *
 * You provide your rule group specification in your request using either
 * `RuleGroup` or `Rules`.
 */
export declare const createRuleGroup: API.OperationMethod<CreateRuleGroupRequest & RegionInput, CreateRuleGroupResponse, CreateRuleGroupError, Credentials | HttpClient.HttpClient>;
export type CreateTLSInspectionConfigurationError = InsufficientCapacityException | InternalServerError | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an Network Firewall TLS inspection configuration. Network Firewall uses TLS inspection configurations to decrypt your firewall's inbound and outbound SSL/TLS traffic. After decryption, Network Firewall inspects the traffic according to your firewall policy's stateful rules, and then re-encrypts it before sending it to its destination. You can enable inspection of your firewall's inbound traffic, outbound traffic, or both. To use TLS inspection with your firewall, you must first import or provision certificates using ACM, create a TLS inspection configuration, add that configuration to a new firewall policy, and then associate that policy with your firewall.
 *
 * To update the settings for a TLS inspection configuration, use UpdateTLSInspectionConfiguration.
 *
 * To manage a TLS inspection configuration's tags, use the standard Amazon Web Services resource tagging operations, ListTagsForResource, TagResource, and UntagResource.
 *
 * To retrieve information about TLS inspection configurations, use ListTLSInspectionConfigurations and DescribeTLSInspectionConfiguration.
 *
 * For more information about TLS inspection configurations, see Inspecting SSL/TLS traffic with TLS
 * inspection configurations in the *Network Firewall Developer Guide*.
 */
export declare const createTLSInspectionConfiguration: API.OperationMethod<CreateTLSInspectionConfigurationRequest & RegionInput, CreateTLSInspectionConfigurationResponse, CreateTLSInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointAssociationError = InsufficientCapacityException | InternalServerError | InvalidOperationException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a firewall endpoint for an Network Firewall firewall. This type of firewall endpoint is independent of the firewall endpoints that you specify in the `Firewall` itself, and you define it in addition to those endpoints after the firewall has been created. You can define a VPC endpoint association using a different VPC than the one you used in the firewall specifications.
 */
export declare const createVpcEndpointAssociation: API.OperationMethod<CreateVpcEndpointAssociationRequest & RegionInput, CreateVpcEndpointAssociationResponse, CreateVpcEndpointAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteContainerAssociationError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a container association. The resource transitions to a `DELETING` state. Deletion is
 * asynchronous - Network Firewall returns immediately while cleanup proceeds in the background. You can't delete a
 * container association while a rule group references it.
 */
export declare const deleteContainerAssociation: API.OperationMethod<DeleteContainerAssociationRequest & RegionInput, DeleteContainerAssociationResponse, DeleteContainerAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified Firewall and its FirewallStatus.
 * This operation requires the firewall's `DeleteProtection` flag to be
 * `FALSE`. You can't revert this operation.
 *
 * You can check whether a firewall is
 * in use by reviewing the route tables for the Availability Zones where you have
 * firewall subnet mappings. Retrieve the subnet mappings by calling DescribeFirewall.
 * You define and update the route tables through Amazon VPC. As needed, update the route tables for the
 * zones to remove the firewall endpoints. When the route tables no longer use the firewall endpoints,
 * you can remove the firewall safely.
 *
 * To delete a firewall, remove the delete protection if you need to using UpdateFirewallDeleteProtection,
 * then delete the firewall by calling DeleteFirewall.
 *
 * Deleting a proxy mode firewall detaches its NAT gateways. To also delete the NAT gateways that Network Firewall created for the firewall, specify `DeleteAssociatedNatGateways`.
 */
export declare const deleteFirewall: API.OperationMethod<DeleteFirewallRequest & RegionInput, DeleteFirewallResponse, DeleteFirewallError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallPolicyError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified FirewallPolicy.
 */
export declare const deleteFirewallPolicy: API.OperationMethod<DeleteFirewallPolicyRequest & RegionInput, DeleteFirewallPolicyResponse, DeleteFirewallPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteFirewallPolicyV2Error = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified FirewallPolicyV2.
 */
export declare const deleteFirewallPolicyV2: API.OperationMethod<DeleteFirewallPolicyV2Request & RegionInput, DeleteFirewallPolicyV2Response, DeleteFirewallPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteNetworkFirewallTransitGatewayAttachmentError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a transit gateway attachment from a Network Firewall. Either the firewall owner or the transit gateway owner can delete the attachment.
 *
 * After you delete a transit gateway attachment, traffic will no longer flow through the firewall endpoints.
 *
 * After you initiate the delete operation, use DescribeFirewall to monitor the deletion status.
 */
export declare const deleteNetworkFirewallTransitGatewayAttachment: API.OperationMethod<DeleteNetworkFirewallTransitGatewayAttachmentRequest & RegionInput, DeleteNetworkFirewallTransitGatewayAttachmentResponse, DeleteNetworkFirewallTransitGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteProxyError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified proxy.
 *
 * Detaches a Proxy configuration from a NAT Gateway.
 */
export declare const deleteProxy: API.OperationMethod<DeleteProxyRequest & RegionInput, DeleteProxyResponse, DeleteProxyError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerError | InvalidRequestException | InvalidResourcePolicyException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a resource policy that you created in a PutResourcePolicy request.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleGroupError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified RuleGroup.
 */
export declare const deleteRuleGroup: API.OperationMethod<DeleteRuleGroupRequest & RegionInput, DeleteRuleGroupResponse, DeleteRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTLSInspectionConfigurationError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified TLSInspectionConfiguration.
 */
export declare const deleteTLSInspectionConfiguration: API.OperationMethod<DeleteTLSInspectionConfigurationRequest & RegionInput, DeleteTLSInspectionConfigurationResponse, DeleteTLSInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointAssociationError = InternalServerError | InvalidOperationException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified VpcEndpointAssociation.
 *
 * You can check whether an endpoint association is
 * in use by reviewing the route tables for the Availability Zones where you have the endpoint subnet mapping.
 * You can retrieve the subnet mapping by calling DescribeVpcEndpointAssociation.
 * You define and update the route tables through Amazon VPC. As needed, update the route tables for the
 * Availability Zone to remove the firewall endpoint for the association. When the route tables no longer use the firewall endpoint,
 * you can remove the endpoint association safely.
 */
export declare const deleteVpcEndpointAssociation: API.OperationMethod<DeleteVpcEndpointAssociationRequest & RegionInput, DeleteVpcEndpointAssociationResponse, DeleteVpcEndpointAssociationError, Credentials | HttpClient.HttpClient>;
export type DescribeContainerAssociationError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the configuration and status of a container association.
 */
export declare const describeContainerAssociation: API.OperationMethod<DescribeContainerAssociationRequest & RegionInput, DescribeContainerAssociationResponse, DescribeContainerAssociationError, Credentials | HttpClient.HttpClient>;
export type DescribeFirewallError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified firewall.
 */
export declare const describeFirewall: API.OperationMethod<DescribeFirewallRequest & RegionInput, DescribeFirewallResponse, DescribeFirewallError, Credentials | HttpClient.HttpClient>;
export type DescribeFirewallMetadataError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the high-level information about a firewall, including the Availability Zones where the Firewall is
 * currently in use.
 */
export declare const describeFirewallMetadata: API.OperationMethod<DescribeFirewallMetadataRequest & RegionInput, DescribeFirewallMetadataResponse, DescribeFirewallMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeFirewallPolicyError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified firewall policy.
 */
export declare const describeFirewallPolicy: API.OperationMethod<DescribeFirewallPolicyRequest & RegionInput, DescribeFirewallPolicyResponse, DescribeFirewallPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeFirewallPolicyV2Error = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified Next Generation policy.
 */
export declare const describeFirewallPolicyV2: API.OperationMethod<DescribeFirewallPolicyV2Request & RegionInput, DescribeFirewallPolicyV2Response, DescribeFirewallPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeFlowOperationError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns key information about a specific flow operation.
 */
export declare const describeFlowOperation: API.OperationMethod<DescribeFlowOperationRequest & RegionInput, DescribeFlowOperationResponse, DescribeFlowOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingConfigurationError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the logging configuration for the specified firewall.
 */
export declare const describeLoggingConfiguration: API.OperationMethod<DescribeLoggingConfigurationRequest & RegionInput, DescribeLoggingConfigurationResponse, DescribeLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeProxyError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified proxy.
 */
export declare const describeProxy: API.OperationMethod<DescribeProxyRequest & RegionInput, DescribeProxyResponse, DescribeProxyError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a resource policy that you created in a PutResourcePolicy request.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleGroupError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified rule group.
 */
export declare const describeRuleGroup: API.OperationMethod<DescribeRuleGroupRequest & RegionInput, DescribeRuleGroupResponse, DescribeRuleGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleGroupMetadataError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * High-level information about a rule group, returned by operations like create and describe.
 * You can use the information provided in the metadata to retrieve and manage a rule group.
 * You can retrieve all objects for a rule group by calling DescribeRuleGroup.
 */
export declare const describeRuleGroupMetadata: API.OperationMethod<DescribeRuleGroupMetadataRequest & RegionInput, DescribeRuleGroupMetadataResponse, DescribeRuleGroupMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleGroupSummaryError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information for a stateful rule group.
 *
 * For active threat defense Amazon Web Services managed rule groups, this operation provides insight into the protections enabled by the rule group, based on Suricata rule metadata fields. Summaries are available for rule groups you manage and for active threat defense Amazon Web Services managed rule groups.
 *
 * To modify how threat information appears in summaries, use the `SummaryConfiguration` parameter in UpdateRuleGroup.
 */
export declare const describeRuleGroupSummary: API.OperationMethod<DescribeRuleGroupSummaryRequest & RegionInput, DescribeRuleGroupSummaryResponse, DescribeRuleGroupSummaryError, Credentials | HttpClient.HttpClient>;
export type DescribeTLSInspectionConfigurationError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data objects for the specified TLS inspection configuration.
 */
export declare const describeTLSInspectionConfiguration: API.OperationMethod<DescribeTLSInspectionConfigurationRequest & RegionInput, DescribeTLSInspectionConfigurationResponse, DescribeTLSInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeVpcEndpointAssociationError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the data object for the specified VPC endpoint association.
 */
export declare const describeVpcEndpointAssociation: API.OperationMethod<DescribeVpcEndpointAssociationRequest & RegionInput, DescribeVpcEndpointAssociationResponse, DescribeVpcEndpointAssociationError, Credentials | HttpClient.HttpClient>;
export type DisassociateAvailabilityZonesError = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified Availability Zone associations from a transit gateway-attached firewall. This removes the firewall endpoints from these Availability Zones and stops traffic filtering in those zones. Before removing an Availability Zone, ensure you've updated your transit gateway route tables to redirect traffic appropriately.
 *
 * If `AvailabilityZoneChangeProtection` is enabled, you must first disable it using UpdateAvailabilityZoneChangeProtection.
 *
 * To verify the status of your Availability Zone changes, use DescribeFirewall.
 */
export declare const disassociateAvailabilityZones: API.OperationMethod<DisassociateAvailabilityZonesRequest & RegionInput, DisassociateAvailabilityZonesResponse, DisassociateAvailabilityZonesError, Credentials | HttpClient.HttpClient>;
export type DisassociateSubnetsError = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified subnet associations from the firewall. This removes the
 * firewall endpoints from the subnets and removes any network filtering protections that the endpoints
 * were providing.
 *
 * For a proxy mode firewall, this also removes the firewall's proxy DNS record in the Availability Zone and detaches the Availability Zone's NAT gateway from the firewall. Network Firewall keeps the NAT gateway. You can't remove the firewall's last Availability Zone. To do that, delete the firewall. If a VPC endpoint association exists in the Availability Zone, delete it first.
 */
export declare const disassociateSubnets: API.OperationMethod<DisassociateSubnetsRequest & RegionInput, DisassociateSubnetsResponse, DisassociateSubnetsError, Credentials | HttpClient.HttpClient>;
export type GetAnalysisReportResultsError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The results of a `COMPLETED` analysis report generated with StartAnalysisReport.
 *
 * For more information, see AnalysisTypeReportResult.
 */
export declare const getAnalysisReportResults: API.PaginatedOperationMethod<GetAnalysisReportResultsRequest & RegionInput, GetAnalysisReportResultsResponse, GetAnalysisReportResultsError, Credentials | HttpClient.HttpClient, AnalysisTypeReportResult>;
export type ListAnalysisReportsError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all traffic analysis reports generated within the last 30 days.
 */
export declare const listAnalysisReports: API.PaginatedOperationMethod<ListAnalysisReportsRequest & RegionInput, ListAnalysisReportsResponse, ListAnalysisReportsError, Credentials | HttpClient.HttpClient, AnalysisReport>;
export type ListContainerAssociationsError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the container associations in your account and Region. Use the `NextToken`
 * parameter in subsequent requests to retrieve additional results.
 */
export declare const listContainerAssociations: API.PaginatedOperationMethod<ListContainerAssociationsRequest & RegionInput, ListContainerAssociationsResponse, ListContainerAssociationsError, Credentials | HttpClient.HttpClient, ContainerAssociationSummary>;
export type ListFirewallPoliciesError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the firewall policies that you have defined. Depending on
 * your setting for max results and the number of firewall policies, a single call might not
 * return the full list.
 */
export declare const listFirewallPolicies: API.PaginatedOperationMethod<ListFirewallPoliciesRequest & RegionInput, ListFirewallPoliciesResponse, ListFirewallPoliciesError, Credentials | HttpClient.HttpClient, FirewallPolicyMetadata>;
export type ListFirewallPoliciesV2Error = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the Next Generation policies that you have defined. Depending on your setting for max results and the number of firewall policies, a single call might not return the full list.
 */
export declare const listFirewallPoliciesV2: API.PaginatedOperationMethod<ListFirewallPoliciesV2Request & RegionInput, ListFirewallPoliciesV2Response, ListFirewallPoliciesV2Error, Credentials | HttpClient.HttpClient, FirewallPolicyV2Metadata>;
export type ListFirewallsError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the firewalls that you have defined. If you provide VPC
 * identifiers in your request, this returns only the firewalls for those VPCs.
 *
 * Depending on your setting for max results and the number of firewalls, a single call
 * might not return the full list.
 */
export declare const listFirewalls: API.PaginatedOperationMethod<ListFirewallsRequest & RegionInput, ListFirewallsResponse, ListFirewallsError, Credentials | HttpClient.HttpClient, FirewallMetadata>;
export type ListFlowOperationResultsError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the results of a specific flow operation.
 *
 * Flow operations let you manage the flows tracked in the flow table, also known as the firewall table.
 *
 * A flow is network traffic that is monitored by a firewall, either by stateful or stateless rules.
 * For traffic to be considered part of a flow, it must share Destination, DestinationPort, Direction, Protocol, Source, and SourcePort.
 */
export declare const listFlowOperationResults: API.PaginatedOperationMethod<ListFlowOperationResultsRequest & RegionInput, ListFlowOperationResultsResponse, ListFlowOperationResultsError, Credentials | HttpClient.HttpClient, Flow>;
export type ListFlowOperationsError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all flow operations ran in a specific firewall.
 * You can optionally narrow the request scope by specifying the operation type or Availability Zone associated with a firewall's flow operations.
 *
 * Flow operations let you manage the flows tracked in the flow table, also known as the firewall table.
 *
 * A flow is network traffic that is monitored by a firewall, either by stateful or stateless rules.
 * For traffic to be considered part of a flow, it must share Destination, DestinationPort, Direction, Protocol, Source, and SourcePort.
 */
export declare const listFlowOperations: API.PaginatedOperationMethod<ListFlowOperationsRequest & RegionInput, ListFlowOperationsResponse, ListFlowOperationsError, Credentials | HttpClient.HttpClient, FlowOperationMetadata>;
export type ListRuleGroupsError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the rule groups that you have defined. Depending on your
 * setting for max results and the number of rule groups, a single call might not return the
 * full list.
 */
export declare const listRuleGroups: API.PaginatedOperationMethod<ListRuleGroupsRequest & RegionInput, ListRuleGroupsResponse, ListRuleGroupsError, Credentials | HttpClient.HttpClient, RuleGroupMetadata>;
export type ListTagsForResourceError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the tags associated with the specified resource. Tags are key:value pairs that
 * you can use to categorize and manage your resources, for purposes like billing. For
 * example, you might set the tag key to "customer" and the value to the customer name or ID.
 * You can specify one or more tags to add to each Amazon Web Services resource, up to 50 tags for a
 * resource.
 *
 * You can tag the Amazon Web Services resources that you manage through Network Firewall: firewalls, firewall
 * policies, and rule groups.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListTLSInspectionConfigurationsError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the TLS inspection configurations that you have defined. Depending on your setting for max results and the number of TLS inspection configurations, a single call might not return the full list.
 */
export declare const listTLSInspectionConfigurations: API.PaginatedOperationMethod<ListTLSInspectionConfigurationsRequest & RegionInput, ListTLSInspectionConfigurationsResponse, ListTLSInspectionConfigurationsError, Credentials | HttpClient.HttpClient, TLSInspectionConfigurationMetadata>;
export type ListVpcEndpointAssociationsError = InternalServerError | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for the VPC endpoint associations that you have defined. If you specify a fireawll,
 * this returns only the endpoint associations for that firewall.
 *
 * Depending on your setting for max results and the number of associations, a single call
 * might not return the full list.
 */
export declare const listVpcEndpointAssociations: API.PaginatedOperationMethod<ListVpcEndpointAssociationsRequest & RegionInput, ListVpcEndpointAssociationsResponse, ListVpcEndpointAssociationsError, Credentials | HttpClient.HttpClient, VpcEndpointAssociationMetadata>;
export type PutResourcePolicyError = InternalServerError | InvalidRequestException | InvalidResourcePolicyException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an IAM policy for your rule group, firewall policy, or firewall. Use this to share these resources between accounts. This operation works in conjunction with the Amazon Web Services Resource Access Manager (RAM) service to manage resource sharing for Network Firewall.
 *
 * For information about using sharing with Network Firewall resources, see
 * Sharing Network Firewall resources in the *Network Firewall Developer Guide*.
 *
 * Use this operation to create or update a resource policy for your Network Firewall rule group, firewall policy, or firewall. In the resource policy, you specify the accounts that you want to share the Network Firewall resource with and the operations that you want the accounts to be able to perform.
 *
 * When you add an account in the resource policy, you then run the following Resource Access Manager (RAM) operations to access and accept the shared resource.
 *
 * - GetResourceShareInvitations - Returns the Amazon Resource Names (ARNs) of the resource share invitations.
 *
 * - AcceptResourceShareInvitation - Accepts the share invitation for a specified resource share.
 *
 * For additional information about resource sharing using RAM, see Resource Access Manager User Guide.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RejectNetworkFirewallTransitGatewayAttachmentError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Rejects a transit gateway attachment request for Network Firewall. When you reject the attachment request, Network Firewall cancels the creation of routing components between the transit gateway and firewall endpoints.
 *
 * Only the transit gateway owner can reject the attachment. After rejection, no traffic will flow through the firewall endpoints for this attachment.
 *
 * Use DescribeFirewall to monitor the rejection status. To accept the attachment instead of rejecting it, use AcceptNetworkFirewallTransitGatewayAttachment.
 *
 * Once rejected, you cannot reverse this action. To establish connectivity, you must create a new transit gateway-attached firewall.
 */
export declare const rejectNetworkFirewallTransitGatewayAttachment: API.OperationMethod<RejectNetworkFirewallTransitGatewayAttachmentRequest & RegionInput, RejectNetworkFirewallTransitGatewayAttachmentResponse, RejectNetworkFirewallTransitGatewayAttachmentError, Credentials | HttpClient.HttpClient>;
export type StartAnalysisReportError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Generates a traffic analysis report for the timeframe and traffic type you specify.
 *
 * For information on the contents of a traffic analysis report, see AnalysisReport.
 */
export declare const startAnalysisReport: API.OperationMethod<StartAnalysisReportRequest & RegionInput, StartAnalysisReportResponse, StartAnalysisReportError, Credentials | HttpClient.HttpClient>;
export type StartFlowCaptureError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Begins capturing the flows in a firewall, according to the filters you define.
 * Captures are similar, but not identical to snapshots. Capture operations provide visibility into flows that are not closed and are tracked by a firewall's flow table.
 * Unlike snapshots, captures are a time-boxed view.
 *
 * A flow is network traffic that is monitored by a firewall, either by stateful or stateless rules.
 * For traffic to be considered part of a flow, it must share Destination, DestinationPort, Direction, Protocol, Source, and SourcePort.
 *
 * To avoid encountering operation limits, you should avoid starting captures with broad filters, like wide IP ranges.
 * Instead, we recommend you define more specific criteria with `FlowFilters`, like narrow IP ranges, ports, or protocols.
 */
export declare const startFlowCapture: API.OperationMethod<StartFlowCaptureRequest & RegionInput, StartFlowCaptureResponse, StartFlowCaptureError, Credentials | HttpClient.HttpClient>;
export type StartFlowFlushError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Begins the flushing of traffic from the firewall, according to the filters you define.
 * When the operation starts, impacted flows are temporarily marked as timed out before the Suricata engine prunes,
 * or flushes, the flows from the firewall table.
 *
 * While the flush completes, impacted flows are processed as midstream traffic. This may result in a
 * temporary increase in midstream traffic metrics. We recommend that you double check your stream exception policy
 * before you perform a flush operation.
 */
export declare const startFlowFlush: API.OperationMethod<StartFlowFlushRequest & RegionInput, StartFlowFlushResponse, StartFlowFlushError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds the specified tags to the specified resource. Tags are key:value pairs that you can
 * use to categorize and manage your resources, for purposes like billing. For example, you
 * might set the tag key to "customer" and the value to the customer name or ID. You can
 * specify one or more tags to add to each Amazon Web Services resource, up to 50 tags for a resource.
 *
 * You can tag the Amazon Web Services resources that you manage through Network Firewall: firewalls, firewall
 * policies, and rule groups.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the tags with the specified keys from the specified resource. Tags are key:value
 * pairs that you can use to categorize and manage your resources, for purposes like billing.
 * For example, you might set the tag key to "customer" and the value to the customer name or
 * ID. You can specify one or more tags to add to each Amazon Web Services resource, up to 50 tags for a
 * resource.
 *
 * You can manage tags for the Amazon Web Services resources that you manage through Network Firewall:
 * firewalls, firewall policies, and rule groups.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAvailabilityZoneChangeProtectionError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 * Modifies the `AvailabilityZoneChangeProtection` setting for a transit gateway-attached firewall. When enabled, this setting prevents accidental changes to the firewall's Availability Zone configuration. This helps protect against disrupting traffic flow in production environments.
 *
 * When enabled, you must disable this protection before using AssociateAvailabilityZones or DisassociateAvailabilityZones to modify the firewall's Availability Zone configuration.
 */
export declare const updateAvailabilityZoneChangeProtection: API.OperationMethod<UpdateAvailabilityZoneChangeProtectionRequest & RegionInput, UpdateAvailabilityZoneChangeProtectionResponse, UpdateAvailabilityZoneChangeProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateContainerAssociationError = InternalServerError | InvalidRequestException | InvalidTokenException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the monitoring configurations and description of a container association. You can't change the container
 * type after creation. Provide an update token to enable optimistic concurrency control.
 */
export declare const updateContainerAssociation: API.OperationMethod<UpdateContainerAssociationRequest & RegionInput, UpdateContainerAssociationResponse, UpdateContainerAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallAnalysisSettingsError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Enables specific types of firewall analysis on a specific firewall you define.
 */
export declare const updateFirewallAnalysisSettings: API.OperationMethod<UpdateFirewallAnalysisSettingsRequest & RegionInput, UpdateFirewallAnalysisSettingsResponse, UpdateFirewallAnalysisSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallDeleteProtectionError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 * Modifies the flag, `DeleteProtection`, which indicates whether it is possible
 * to delete the firewall. If the flag is set to `TRUE`, the firewall is protected
 * against deletion. This setting helps protect against accidentally deleting a firewall
 * that's in use.
 */
export declare const updateFirewallDeleteProtection: API.OperationMethod<UpdateFirewallDeleteProtectionRequest & RegionInput, UpdateFirewallDeleteProtectionResponse, UpdateFirewallDeleteProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallDescriptionError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Modifies the description for the specified firewall. Use the description to help you
 * identify the firewall when you're working with it.
 */
export declare const updateFirewallDescription: API.OperationMethod<UpdateFirewallDescriptionRequest & RegionInput, UpdateFirewallDescriptionResponse, UpdateFirewallDescriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallEncryptionConfigurationError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 * A complex type that contains settings for encryption of your firewall resources.
 */
export declare const updateFirewallEncryptionConfiguration: API.OperationMethod<UpdateFirewallEncryptionConfigurationRequest & RegionInput, UpdateFirewallEncryptionConfigurationResponse, UpdateFirewallEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallPolicyError = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of the specified firewall policy.
 */
export declare const updateFirewallPolicy: API.OperationMethod<UpdateFirewallPolicyRequest & RegionInput, UpdateFirewallPolicyResponse, UpdateFirewallPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallPolicyChangeProtectionError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 * Modifies the flag, `ChangeProtection`, which indicates whether it
 * is possible to change the firewall. If the flag is set to `TRUE`, the firewall is protected
 * from changes. This setting helps protect against accidentally changing a firewall that's in use.
 */
export declare const updateFirewallPolicyChangeProtection: API.OperationMethod<UpdateFirewallPolicyChangeProtectionRequest & RegionInput, UpdateFirewallPolicyChangeProtectionResponse, UpdateFirewallPolicyChangeProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateFirewallPolicyV2Error = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of the specified Next Generation policy.
 */
export declare const updateFirewallPolicyV2: API.OperationMethod<UpdateFirewallPolicyV2Request & RegionInput, UpdateFirewallPolicyV2Response, UpdateFirewallPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateLoggingConfigurationError = InternalServerError | InvalidRequestException | InvalidTokenException | LogDestinationPermissionException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sets the logging configuration for the specified firewall.
 *
 * To change the logging configuration, retrieve the LoggingConfiguration by calling DescribeLoggingConfiguration, then change it and provide
 * the modified object to this update call. You must change the logging configuration one
 * LogDestinationConfig at a time inside the retrieved LoggingConfiguration object.
 *
 * You can perform only one of the following actions in any call to
 * `UpdateLoggingConfiguration`:
 *
 * - Create a new log destination object by adding a single
 * `LogDestinationConfig` array element to
 * `LogDestinationConfigs`.
 *
 * - Delete a log destination object by removing a single
 * `LogDestinationConfig` array element from
 * `LogDestinationConfigs`.
 *
 * - Change the `LogDestination` setting in a single
 * `LogDestinationConfig` array element.
 *
 * You can't change the `LogDestinationType` or `LogType` in a
 * `LogDestinationConfig`. To change these settings, delete the existing
 * `LogDestinationConfig` object and create a new one, using two separate calls
 * to this update operation.
 */
export declare const updateLoggingConfiguration: API.OperationMethod<UpdateLoggingConfigurationRequest & RegionInput, UpdateLoggingConfigurationResponse, UpdateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateProxySettingsError = InternalServerError | InvalidOperationException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 * Modifies the proxy settings of a proxy mode firewall. Use this operation to change the ports and protocols on which the firewall's proxy listens for traffic. The new listeners take effect without recreating the firewall.
 *
 * The `ProxySettings` that you provide replace the firewall's current proxy settings. If you created the firewall with your own `CertificateArn` and `DomainName`, you must specify the same values in every request. You can't change or remove them.
 */
export declare const updateProxySettings: API.OperationMethod<UpdateProxySettingsRequest & RegionInput, UpdateProxySettingsResponse, UpdateProxySettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleGroupError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the rule settings for the specified rule group. You use a rule group by
 * reference in one or more firewall policies. When you modify a rule group, you modify all
 * firewall policies that use the rule group.
 *
 * To update a rule group, first call DescribeRuleGroup to retrieve the
 * current RuleGroup object, update the object as needed, and then provide
 * the updated object to this call.
 */
export declare const updateRuleGroup: API.OperationMethod<UpdateRuleGroupRequest & RegionInput, UpdateRuleGroupResponse, UpdateRuleGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateSubnetChangeProtectionError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ResourceOwnerCheckException | ThrottlingException | CommonErrors;
/**
 *
 */
export declare const updateSubnetChangeProtection: API.OperationMethod<UpdateSubnetChangeProtectionRequest & RegionInput, UpdateSubnetChangeProtectionResponse, UpdateSubnetChangeProtectionError, Credentials | HttpClient.HttpClient>;
export type UpdateTLSInspectionConfigurationError = InternalServerError | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the TLS inspection configuration settings for the specified TLS inspection configuration. You use a TLS inspection configuration by
 * referencing it in one or more firewall policies. When you modify a TLS inspection configuration, you modify all
 * firewall policies that use the TLS inspection configuration.
 *
 * To update a TLS inspection configuration, first call DescribeTLSInspectionConfiguration to retrieve the
 * current TLSInspectionConfiguration object, update the object as needed, and then provide
 * the updated object to this call.
 */
export declare const updateTLSInspectionConfiguration: API.OperationMethod<UpdateTLSInspectionConfigurationRequest & RegionInput, UpdateTLSInspectionConfigurationResponse, UpdateTLSInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=network-firewall.d.ts.map