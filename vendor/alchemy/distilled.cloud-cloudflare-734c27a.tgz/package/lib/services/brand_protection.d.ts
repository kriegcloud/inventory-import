import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export type QueriesBulkRequestQueriesItemMap = {
    [key: string]: unknown | undefined;
};
export type QueriesBulkRequestQueriesList = Array<QueriesBulkRequestQueriesItemMap>;
export interface BulkQueryRequest {
    accountId: string;
    queries?: QueriesBulkRequestQueriesList | undefined;
}
export interface BulkQueryResponse {
}
export interface CreateLogoRequest {
    accountId: string;
    matchType?: string | undefined;
    tag?: string | undefined;
    threshold?: number | undefined;
    image?: unknown | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateLogoResponse {
    id?: number | null | undefined;
    tag?: string | null | undefined;
    uploadPath?: string | null | undefined;
}
export interface QueriesCreateRequestStringMatchesItem {
    pattern: string;
    maxEditDistance?: number | undefined;
}
export type QueriesCreateRequestStringMatchesList = Array<QueriesCreateRequestStringMatchesItem>;
export interface CreateQueryRequest {
    accountId: string;
    id?: string | undefined;
    scan?: boolean | undefined;
    tag?: string | undefined;
    maxTime?: string | undefined;
    minTime?: string | undefined;
    stringMatches?: QueriesCreateRequestStringMatchesList | undefined;
    bodyScan?: boolean | undefined;
    bodyTag?: string | undefined;
}
export interface CreateQueryResponse {
}
export interface CreateV2LogoRequest {
    accountId: string;
    /** Base64 encoded image data. Can include data URI prefix (e.g., 'data:image/png;base64,...') or just the base64 string. Supported formats: PNG, JPEG, GIF, WebP, BMP, and SVG. ICO is also accepted when the data includes a `data:image/x-icon;base64,` prefix. */
    imageData: string;
    /** Minimum similarity score (0-1) required for visual matches */
    similarityThreshold: number;
    /** Name of the logo query. Must be unique among the account's logo queries. */
    tag: string;
    /** If true, also search previously scanned images for matches above the similarity threshold. Defaults to `true`. */
    searchLookback?: boolean | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateV2LogoResponse {
    message: string;
    /** ID of the created logo query. */
    queryId?: number | null | undefined;
}
export interface DeleteLogoRequest {
    accountId: string;
    logoId: string;
}
export interface DeleteLogoResponse {
}
export interface DeleteQueryRequest {
    accountId: string;
    id?: string | undefined;
    scan?: boolean | undefined;
    tag?: string | undefined;
}
export interface DeleteQueryResponse {
}
export interface DeleteV2LogoRequest {
    accountId: string;
    /** ID of the logo query. */
    queryId: string;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteV2LogoResponse {
    message: string;
}
export type LogoMatchesDownloadRequestLogoIdList = Array<string>;
export interface DownloadLogoMatchRequest {
    accountId: string;
    limit?: string | undefined;
    logoId?: LogoMatchesDownloadRequestLogoIdList | undefined;
    offset?: string | undefined;
}
export type LogoMatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type LogoMatchesDownloadResponseMatchesList = Array<LogoMatchesDownloadResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadLogoMatchResponse {
    matches?: LogoMatchesDownloadResponseMatchesList | null | undefined;
    total?: number | null | undefined;
}
export interface DownloadMatchRequest {
    accountId: string;
    id?: string | undefined;
    includeDismissed?: boolean | undefined;
    includeDomainId?: boolean | undefined;
    limit?: number | undefined;
    offset?: number | undefined;
}
export type MatchesDownloadResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type MatchesDownloadResponseMatchesList = Array<MatchesDownloadResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DownloadMatchResponse {
    matches?: MatchesDownloadResponseMatchesList | null | undefined;
    total?: number | null | undefined;
}
export type LogoMatchesGetRequestLogoIdList = Array<string>;
export interface GetLogoMatchRequest {
    accountId: string;
    limit?: string | undefined;
    logoId?: LogoMatchesGetRequestLogoIdList | undefined;
    offset?: string | undefined;
}
export type LogoMatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type LogoMatchesGetResponseMatchesList = Array<LogoMatchesGetResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetLogoMatchResponse {
    matches?: LogoMatchesGetResponseMatchesList | null | undefined;
    total?: number | null | undefined;
}
export interface GetMatchRequest {
    accountId: string;
    id?: string | undefined;
    includeDismissed?: boolean | undefined;
    includeDomainId?: boolean | undefined;
    limit?: number | undefined;
    offset?: number | undefined;
}
export type MatchesGetResponseMatchesItemMap = {
    [key: string]: unknown | undefined;
};
export type MatchesGetResponseMatchesList = Array<MatchesGetResponseMatchesItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetMatchResponse {
    matches?: MatchesGetResponseMatchesList | null | undefined;
    total?: number | null | undefined;
}
export interface GetV2LogoRequest {
    accountId: string;
    /** ID of a logo query. When set, `result` is that single query object instead of an array. */
    id?: string | undefined;
    /** Set to `true` to include each logo image as base64 data in `image_data`, with its MIME type in `content_type`. */
    download?: string | undefined;
}
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoResponse {
    /** ID of the logo query. */
    id: number;
    r2Path: string;
    /** Minimum similarity score (0-1) required for a visual match. */
    similarityThreshold: number;
    /** Name of the logo query. */
    tag: string;
    /** When the logo was uploaded. */
    uploadedAt: string;
    /** MIME type of the image (only present when download=true) */
    contentType?: string | null | undefined;
    /** Base64-encoded image data (only present when download=true) */
    imageData?: string | null | undefined;
}
export type V2LogoMatchesGetRequestOrder = "asc" | "desc";
export type V2LogoMatchesGetRequestOrderBy = "matchedAt" | "domain" | "similarityScore" | "registrar";
export interface GetV2LogoMatchRequest {
    accountId: string;
    /** ID of the logo query whose matches to list. */
    queryId: string;
    /** Set to `true` to include each matched image as base64 data in `image_data`, with its MIME type in `content_type`. */
    download?: string | undefined;
    /** Maximum number of matches to return. Defaults to 50. */
    limit?: string | undefined;
    /** Number of matches to skip, for pagination. Defaults to 0. */
    offset?: string | undefined;
    /** Sort direction: `asc` or `desc`. Defaults to `desc`. */
    order?: V2LogoMatchesGetRequestOrder | (string & {}) | undefined;
    /** Field to sort by: `matchedAt`, `domain`, `similarityScore`, or `registrar`. Defaults to `matchedAt`. */
    orderBy?: V2LogoMatchesGetRequestOrderBy | (string & {}) | undefined;
}
export interface V2LogoMatchesGetResponseMatchesItem {
    /** ID of the logo match. */
    id: number;
    /** Domain where the matching image was found, if known. */
    domain: string;
    /** When the match was recorded. */
    matchedAt: string;
    /** ID of the logo query that produced this match. */
    queryId: number;
    /** Registrar of `domain`, if known. */
    registrar: string;
    /** Visual similarity between the matched image and the query logo. Higher is closer. */
    similarityScore: number;
    urlScanId: string;
    /** MIME type of the matched image (only present when download=true) */
    contentType?: string | null | undefined;
    /** Base64-encoded matched image (only present when download=true) */
    imageData?: string | null | undefined;
}
export type V2LogoMatchesGetResponseMatchesList = Array<V2LogoMatchesGetResponseMatchesItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2LogoMatchResponse {
    matches: V2LogoMatchesGetResponseMatchesList;
    total: number;
}
export type V2MatchesGetRequestQueryIdList = Array<string>;
export type V2MatchesGetRequestOrder = "asc" | "desc";
export type V2MatchesGetRequestOrderBy = "domain" | "first_seen" | "registrar";
export interface GetV2MatchRequest {
    accountId: string;
    /** ID of a domain query, or a comma-separated list of domain query IDs. When you pass several IDs, matches are deduplicated by domain and each match includes a `match_details` array with per-query metadata and dismissed state. */
    queryId: V2MatchesGetRequestQueryIdList;
    /** Return only matches whose domain contains this text (case-insensitive). */
    domainSearch?: string | undefined;
    /** Set to `false` to exclude dismissed matches. Dismissed matches are included when this is omitted or `true`. */
    includeDismissed?: string | undefined;
    /** Set to `true` to include `domain_id` on each match. Required to dismiss or undismiss a match. Defaults to `false`. */
    includeDomainId?: string | undefined;
    /** Maximum number of matches to return. Defaults to 50. */
    limit?: string | undefined;
    /** Number of matches to skip, for pagination. Defaults to 0. */
    offset?: string | undefined;
    /** Sort direction: `asc` or `desc`. Defaults to `desc`. For single-query requests, `asc` applies only when `orderBy` is set. */
    order?: V2MatchesGetRequestOrder | (string & {}) | undefined;
    /** Field to sort by: `domain`, `first_seen`, or `registrar`. Defaults to `first_seen`. */
    orderBy?: V2MatchesGetRequestOrderBy | (string & {}) | undefined;
}
export interface V2MatchesGetResponseMatchesItemPublicScans {
    submissionId: string;
}
export interface V2MatchesGetResponseMatchesItemMatchDetailsItem {
    /** Individual dismissed state for this specific match. */
    dismissed: boolean;
    /** ID of the match. Accepted by the legacy `match_ids` format. */
    matchId: number;
    /** ID of the domain query that produced this match. */
    queryId: number;
    /** Tag associated with the query, if one exists. */
    queryTag: string;
}
export type V2MatchesGetResponseMatchesItemMatchDetailsList = Array<V2MatchesGetResponseMatchesItemMatchDetailsItem>;
export interface V2MatchesGetResponseMatchesItem {
    /** The matched domain name. */
    domain: string;
    /** When the domain was matched. For multi-query requests, the most recent match time across the requested queries. */
    firstSeen: string;
    publicScans: V2MatchesGetResponseMatchesItemPublicScans;
    /** Registrar of the matched domain, if known. */
    registrar: string;
    scanStatus: string;
    scanSubmissionId: number;
    source: string;
    /** Whether the match is dismissed. Only present for single-query requests. For multi-query requests, use the dismissed field in each match_details entry. */
    dismissed?: boolean | null | undefined;
    /** ID of the matched domain. Present only when `include_domain_id=true`. Use it with `query_id` to dismiss or undismiss the match. */
    domainId?: number | null | undefined;
    /** Per-match detail objects with query metadata and individual dismissed state. Only present when multiple query_ids are requested. */
    matchDetails?: V2MatchesGetResponseMatchesItemMatchDetailsList | null | undefined;
}
export type V2MatchesGetResponseMatchesList = Array<V2MatchesGetResponseMatchesItem>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetV2MatchResponse {
    matches: V2MatchesGetResponseMatchesList;
    /** Number of matching domains available for pagination. For requests with several `query_id` values, matches are deduplicated from at most 5,000 query-domain rows, so `total` can be lower than the actual number of matches. */
    total: number;
}
export interface GetV2QueryRequest {
    accountId: string;
    /** ID of a domain query. When set, `result` is that single query object instead of an array, and `page` and `per_page` are ignored. */
    id?: string | undefined;
    /** Page number for paginated list requests. Defaults to 1 when only per_page is supplied. Omit page and per_page to return every query. */
    page?: number | undefined;
    /** Number of queries per page for paginated list requests. Defaults to 100 when only page is supplied. Maximum 100. Omit page and per_page to return every query. */
    perPage?: number | undefined;
}
export interface V2QueriesGetResultCase0ItemParametersStringMatchesItem {
    pattern: string;
}
export type V2QueriesGetResultCase0ItemParametersStringMatchesList = Array<V2QueriesGetResultCase0ItemParametersStringMatchesItem>;
export interface V2QueriesGetResultCase0ItemParameters {
    stringMatches: V2QueriesGetResultCase0ItemParametersStringMatchesList;
    maxTime?: string | null | undefined;
    minTime?: string | null | undefined;
}
export interface V2QueriesGetResultCase0Item {
    created: string;
    parameters: V2QueriesGetResultCase0ItemParameters;
    queryId: number;
    queryTag: string;
    scan: boolean;
    updated: string;
}
export type V2QueriesGetResultCase0List = Array<V2QueriesGetResultCase0Item>;
export type V2QueriesGetResultCase1ParametersStringMatchesItem = V2QueriesGetResultCase0ItemParametersStringMatchesItem;
export type V2QueriesGetResultCase1ParametersStringMatchesList = Array<V2QueriesGetResultCase0ItemParametersStringMatchesItem>;
export interface V2QueriesGetResultCase1Parameters {
    stringMatches: V2QueriesGetResultCase1ParametersStringMatchesList;
    maxTime?: string | null | undefined;
    minTime?: string | null | undefined;
}
export interface V2QueriesGetResultCase1 {
    created: string;
    parameters: V2QueriesGetResultCase1Parameters;
    queryId: number;
    queryTag: string;
    scan: boolean;
    updated: string;
}
export type V2QueriesGetResult = V2QueriesGetResultCase0List | V2QueriesGetResultCase1;
export type GetV2QueryResponse = V2QueriesGetResult;
export interface SubmitBrandProtectionRequest {
    accountId: string;
}
export type SubmitResponseSkippedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export type SubmitResponseSkippedUrlsList = Array<SubmitResponseSkippedUrlsItemMap>;
export type SubmitResponseSubmittedUrlsItemMap = {
    [key: string]: unknown | undefined;
};
export type SubmitResponseSubmittedUrlsList = Array<SubmitResponseSubmittedUrlsItemMap>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface SubmitBrandProtectionResponse {
    skippedUrls?: SubmitResponseSkippedUrlsList | null | undefined;
    submittedUrls?: SubmitResponseSubmittedUrlsList | null | undefined;
}
export interface UrlInfoBrandProtectionRequest {
    accountId: string;
}
export type UrlInfoResultItemMap = {
    [key: string]: unknown | undefined;
};
export type UrlInfoResultList = Array<UrlInfoResultItemMap>;
export interface UrlInfoBrandProtectionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UrlInfoResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type BulkQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries in bulk. */
export declare const bulkQuery: API.OperationMethod<BulkQueryRequest, BulkQueryResponse, BulkQueryError, CloudflareOpContext>;
export type CreateLogoError = CloudflareOpError;
/** Return new saved logo queries created from image files. */
export declare const createLogo: API.OperationMethod<CreateLogoRequest, CreateLogoResponse, CreateLogoError, CloudflareOpContext>;
export type CreateQueryError = CloudflareOpError;
/** Return a success message after creating new saved string queries. */
export declare const createQuery: API.OperationMethod<CreateQueryRequest, CreateQueryResponse, CreateQueryError, CloudflareOpContext>;
export type CreateV2LogoError = CloudflareOpError;
/** Uploads a logo and creates a saved logo query that finds visually similar images on scanned websites. The tag must be unique among the account's logo queries. By default, the new query also searches previously scanned images (see `search_lookback`). Creation fails when the account has reached its Brand Protection query limit, which counts domain and logo queries together. */
export declare const createV2Logo: API.OperationMethod<CreateV2LogoRequest, CreateV2LogoResponse, CreateV2LogoError, CloudflareOpContext>;
export type DeleteLogoError = CloudflareOpError;
/** Return a success message after deleting saved logo queries by ID. */
export declare const deleteLogo: API.OperationMethod<DeleteLogoRequest, DeleteLogoResponse, DeleteLogoError, CloudflareOpContext>;
export type DeleteQueryError = CloudflareOpError;
/** Return a success message after deleting saved string queries by ID. */
export declare const deleteQuery: API.OperationMethod<DeleteQueryRequest, DeleteQueryResponse, DeleteQueryError, CloudflareOpContext>;
export type DeleteV2LogoError = CloudflareOpError;
/** Permanently deletes a saved logo query and all of its matches. If the query does not exist in this account, the request fails with error code 404. */
export declare const deleteV2Logo: API.OperationMethod<DeleteV2LogoRequest, DeleteV2LogoResponse, DeleteV2LogoError, CloudflareOpContext>;
export type DownloadLogoMatchError = CloudflareOpError;
/** Return matches as CSV for logo queries based on ID. */
export declare const downloadLogoMatch: API.OperationMethod<DownloadLogoMatchRequest, DownloadLogoMatchResponse, DownloadLogoMatchError, CloudflareOpContext>;
export type DownloadMatchError = CloudflareOpError;
/** Return matches as CSV for string queries based on ID. */
export declare const downloadMatch: API.OperationMethod<DownloadMatchRequest, DownloadMatchResponse, DownloadMatchError, CloudflareOpContext>;
export type GetLogoMatchError = CloudflareOpError;
/** Return matches for logo queries based on ID. */
export declare const getLogoMatch: API.OperationMethod<GetLogoMatchRequest, GetLogoMatchResponse, GetLogoMatchError, CloudflareOpContext>;
export type GetMatchError = CloudflareOpError;
/** Return matches for string queries based on ID. */
export declare const getMatch: API.OperationMethod<GetMatchRequest, GetMatchResponse, GetMatchError, CloudflareOpContext>;
export type GetV2LogoError = CloudflareOpError;
/** Lists the account's saved logo queries. Set `id` to return a single query object instead of an array. Set `download=true` to include each logo image as base64 data. */
export declare const getV2Logo: API.OperationMethod<GetV2LogoRequest, GetV2LogoResponse, GetV2LogoError, CloudflareOpContext>;
export type GetV2LogoMatchError = CloudflareOpError;
/** Lists images that matched a saved logo query, most recently matched first by default. Set `download=true` to include each matched image as base64 data. */
export declare const getV2LogoMatch: API.OperationMethod<GetV2LogoMatchRequest, GetV2LogoMatchResponse, GetV2LogoMatchError, CloudflareOpContext>;
export type GetV2MatchError = CloudflareOpError;
/** Lists domains that matched one or more saved domain queries, most recently matched first by default. When you pass several comma-separated `query_id` values, matches are deduplicated by domain and each match includes a `match_details` array with per-query dismissed state. Set `include_domain_id=true` to get the `domain_id` needed to dismiss or undismiss a match. */
export declare const getV2Match: API.OperationMethod<GetV2MatchRequest, GetV2MatchResponse, GetV2MatchError, CloudflareOpContext>;
export type GetV2QueryError = CloudflareOpError;
/** Lists the account's saved domain queries, most recently updated first. Set `id` to return a single query object instead of an array. Set `page` or `per_page` to paginate the list; the response then includes `result_info`. Without them, every query is returned. */
export declare const getV2Query: API.OperationMethod<GetV2QueryRequest, GetV2QueryResponse, GetV2QueryError, CloudflareOpContext>;
export type SubmitBrandProtectionError = CloudflareOpError;
/** Return new URL submissions. */
export declare const submitBrandProtection: API.OperationMethod<SubmitBrandProtectionRequest, SubmitBrandProtectionResponse, SubmitBrandProtectionError, CloudflareOpContext>;
export type UrlInfoBrandProtectionError = CloudflareOpError;
/** Return submitted URLs based on ID. */
export declare const urlInfoBrandProtection: API.PaginatedOperationMethod<UrlInfoBrandProtectionRequest, UrlInfoBrandProtectionResponse, UrlInfoBrandProtectionError, CloudflareOpContext, UrlInfoResultItemMap>;
//# sourceMappingURL=brand_protection.d.ts.map