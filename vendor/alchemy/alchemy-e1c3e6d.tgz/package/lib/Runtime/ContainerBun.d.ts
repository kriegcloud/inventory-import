import { BunServices } from "@effect/platform-bun";
import * as Layer from "effect/Layer";
export declare const services: Layer.Layer<import("../Terminal.ts").Terminals | BunServices.BunServices, never, never>;
export declare const httpServer: Layer.Layer<import("../Http.ts").HttpServer, never, never>;
//# sourceMappingURL=ContainerBun.d.ts.map