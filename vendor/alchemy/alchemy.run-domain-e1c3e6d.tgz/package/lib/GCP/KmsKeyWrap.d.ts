import type { CryptoKey } from "@alchemy.run/gcp/KMS/CryptoKey";
import { Decrypt } from "@alchemy.run/gcp/KMS/Decrypt";
import { Encrypt } from "@alchemy.run/gcp/KMS/Encrypt";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { type IntermediateKeyOptions, KeyWrap } from "../KeyWrap.ts";
/** Options for {@link KmsKeyWrap}. */
export interface KmsKeyWrapOptions {
    /**
     * Call Cloud KMS once per intermediate key instead of once per seal and
     * open. Each process makes an intermediate key, has KMS wrap it, keeps it
     * in memory for `keep`, and wraps subject keys under it locally.
     *
     * It trades cost for exposure: an intermediate key is in the process's
     * memory, KMS logs one call per intermediate key rather than one per
     * subject, and a process cut off from KMS reads on for up to `keep`.
     * Shredding is unchanged: each subject keeps a key of its own.
     *
     * @default undefined (every seal and open is one KMS call)
     */
    readonly intermediateKey?: IntermediateKeyOptions;
}
/**
 * Wrap each subject's key under a Cloud KMS key. KMS encrypts and decrypts
 * the subject's key with the subject as additional authenticated data, so a
 * stored key unwraps only for the subject it was made for. The root key
 * never leaves KMS.
 *
 * Every seal and open is one `Decrypt` call.
 *
 * ### Wrapping keys under Cloud KMS
 * **Example:** A Cloud KMS key over keys in Firestore
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as DomainGCP from "@alchemy.run/domain/GCP";
 * import * as GCP from "@alchemy.run/gcp";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 *
 * export const Keys = GCP.Firestore.Database("VaultKeys", {
 *   location: "us-central1",
 *   type: "FIRESTORE_NATIVE",
 * });
 * export const RootKey = Effect.gen(function* () {
 *   const keyRing = yield* GCP.KMS.KeyRing("Vault", { location: "us-central1" });
 *   return yield* GCP.KMS.CryptoKey("VaultRootKey", { keyRing: keyRing.name });
 * });
 *
 * export const Sealing = Domain.VaultLive.pipe(
 *   Layer.provide(DomainGCP.FirestoreKeyStore(Keys)),
 *   Layer.provide(DomainGCP.KmsKeyWrap(RootKey)),
 *   Layer.provide(
 *     Layer.mergeAll(
 *       GCP.Firestore.GetDocumentHttp,
 *       GCP.Firestore.PatchDocumentHttp,
 *       GCP.Firestore.DeleteDocumentHttp,
 *       GCP.KMS.EncryptHttp,
 *       GCP.KMS.DecryptHttp,
 *     ),
 *   ),
 * );
 * ```
 *
 * ### Calling Cloud KMS less often
 * `intermediateKey` has each process keep one intermediate key in memory
 * and wrap subject keys under it locally, so Cloud KMS is called once per
 * intermediate key instead of once per seal and open. The intermediate key
 * is in the process's memory, Cloud KMS no longer logs each subject's access,
 * and a process cut off from Cloud KMS reads on for up to `keep`. Shredding is
 * unchanged.
 *
 * **Example:** One Cloud KMS call per process every five minutes
 * ```typescript
 * DomainGCP.KmsKeyWrap(RootKey, { intermediateKey: { keep: "5 minutes" } });
 * ```
 *
 * @layer
 * @provides Domain.KeyWrap
 */
export declare const KmsKeyWrap: <E = never, R = never>(key: CryptoKey | Effect.Effect<CryptoKey, E, R>, options?: KmsKeyWrapOptions) => Layer.Layer<KeyWrap, E, R | Encrypt | Decrypt>;
//# sourceMappingURL=KmsKeyWrap.d.ts.map