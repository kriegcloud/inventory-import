/**
 * CRC32 checksum in plain JavaScript, for runtimes without Node's
 * `zlib.crc32` (browsers; Node before 20.15).
 */
import type { Checksum } from "./checksum.ts";
export declare const checksumBytes: (checksum: number) => Uint8Array;
export declare class Crc32 implements Checksum {
    private checksum;
    update(data: Uint8Array): void;
    digest(): Uint8Array;
    reset(): void;
}
//# sourceMappingURL=crc32-portable.d.ts.map