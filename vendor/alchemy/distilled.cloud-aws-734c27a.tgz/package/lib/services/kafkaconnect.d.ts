import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type __integerMin1Max8 = number;
export type __integerMin1Max100 = number;
export interface ScaleInPolicy {
    cpuUtilizationPercentage: number;
}
export interface ScaleOutPolicy {
    cpuUtilizationPercentage: number;
}
export interface AutoScaling {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy?: ScaleInPolicy | undefined;
    scaleOutPolicy?: ScaleOutPolicy | undefined;
    maxAutoscalingTaskCount?: number | undefined;
}
export interface ProvisionedCapacity {
    mcuCount: number;
    workerCount: number;
}
export interface Capacity {
    autoScaling?: AutoScaling | undefined;
    provisionedCapacity?: ProvisionedCapacity | undefined;
}
export type ConnectorConfiguration = {
    [key: string]: string | undefined;
};
export type __stringMax1024 = string;
export type __stringMin1Max128 = string;
export type __listOf__string = string[];
export interface Vpc {
    securityGroups?: string[] | undefined;
    subnets: string[];
}
export interface ApacheKafkaCluster {
    bootstrapServers: string;
    vpc: Vpc;
}
export interface KafkaCluster {
    apacheKafkaCluster: ApacheKafkaCluster;
}
export type KafkaClusterClientAuthenticationType = string;
export interface KafkaClusterClientAuthentication {
    authenticationType: string;
}
export type KafkaClusterEncryptionInTransitType = string;
export interface KafkaClusterEncryptionInTransit {
    encryptionType: string;
}
export interface CloudWatchLogsLogDelivery {
    enabled: boolean;
    logGroup?: string | undefined;
}
export interface FirehoseLogDelivery {
    deliveryStream?: string | undefined;
    enabled: boolean;
}
export interface S3LogDelivery {
    bucket?: string | undefined;
    enabled: boolean;
    prefix?: string | undefined;
}
export interface WorkerLogDelivery {
    cloudWatchLogs?: CloudWatchLogsLogDelivery | undefined;
    firehose?: FirehoseLogDelivery | undefined;
    s3?: S3LogDelivery | undefined;
}
export interface LogDelivery {
    workerLogDelivery: WorkerLogDelivery;
}
export type NetworkType = string;
export type __longMin1 = number;
export interface CustomPlugin {
    customPluginArn: string;
    revision: number;
}
export interface Plugin {
    customPlugin: CustomPlugin;
}
export type __listOfPlugin = Plugin[];
export interface WorkerConfiguration {
    revision: number;
    workerConfigurationArn: string;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateConnectorRequest {
    capacity: Capacity;
    connectorConfiguration: {
        [key: string]: string | undefined;
    };
    connectorDescription?: string | undefined;
    connectorName: string;
    kafkaCluster: KafkaCluster;
    kafkaClusterClientAuthentication: KafkaClusterClientAuthentication;
    kafkaClusterEncryptionInTransit: KafkaClusterEncryptionInTransit;
    kafkaConnectVersion: string;
    logDelivery?: LogDelivery | undefined;
    networkType?: string | undefined;
    plugins: Plugin[];
    serviceExecutionRoleArn: string;
    workerConfiguration?: WorkerConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConnectorState = string;
export interface CreateConnectorResponse {
    connectorArn?: string | undefined;
    connectorName?: string | undefined;
    connectorState?: string | undefined;
}
export type CustomPluginContentType = string;
export interface S3Location {
    bucketArn: string;
    fileKey: string;
    objectVersion?: string | undefined;
}
export interface CustomPluginLocation {
    s3Location: S3Location;
}
export interface CreateCustomPluginRequest {
    contentType: string;
    description?: string | undefined;
    location: CustomPluginLocation;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CustomPluginState = string;
export interface CreateCustomPluginResponse {
    customPluginArn?: string | undefined;
    customPluginState?: string | undefined;
    name?: string | undefined;
    revision?: number | undefined;
}
export type __sensitiveString = string | redacted.Redacted<string>;
export interface CreateWorkerConfigurationRequest {
    description?: string | undefined;
    name: string;
    propertiesFileContent: string | redacted.Redacted<string>;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __timestampIso8601 = Date;
export interface WorkerConfigurationRevisionSummary {
    creationTime?: Date | undefined;
    description?: string | undefined;
    revision?: number | undefined;
}
export type WorkerConfigurationState = string;
export interface CreateWorkerConfigurationResponse {
    creationTime?: Date | undefined;
    latestRevision?: WorkerConfigurationRevisionSummary | undefined;
    name?: string | undefined;
    workerConfigurationArn?: string | undefined;
    workerConfigurationState?: string | undefined;
}
export interface DeleteConnectorRequest {
    connectorArn: string;
    currentVersion?: string | undefined;
}
export interface DeleteConnectorResponse {
    connectorArn?: string | undefined;
    connectorState?: string | undefined;
}
export interface DeleteCustomPluginRequest {
    customPluginArn: string;
}
export interface DeleteCustomPluginResponse {
    customPluginArn?: string | undefined;
    customPluginState?: string | undefined;
}
export interface DeleteWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export interface DeleteWorkerConfigurationResponse {
    workerConfigurationArn?: string | undefined;
    workerConfigurationState?: string | undefined;
}
export interface DescribeConnectorRequest {
    connectorArn: string;
}
export interface ScaleInPolicyDescription {
    cpuUtilizationPercentage?: number | undefined;
}
export interface ScaleOutPolicyDescription {
    cpuUtilizationPercentage?: number | undefined;
}
export interface AutoScalingDescription {
    maxWorkerCount?: number | undefined;
    mcuCount?: number | undefined;
    minWorkerCount?: number | undefined;
    scaleInPolicy?: ScaleInPolicyDescription | undefined;
    scaleOutPolicy?: ScaleOutPolicyDescription | undefined;
    maxAutoscalingTaskCount?: number | undefined;
}
export interface ProvisionedCapacityDescription {
    mcuCount?: number | undefined;
    workerCount?: number | undefined;
}
export interface CapacityDescription {
    autoScaling?: AutoScalingDescription | undefined;
    provisionedCapacity?: ProvisionedCapacityDescription | undefined;
}
export interface VpcDescription {
    securityGroups?: string[] | undefined;
    subnets?: string[] | undefined;
}
export interface ApacheKafkaClusterDescription {
    bootstrapServers?: string | undefined;
    vpc?: VpcDescription | undefined;
}
export interface KafkaClusterDescription {
    apacheKafkaCluster?: ApacheKafkaClusterDescription | undefined;
}
export interface KafkaClusterClientAuthenticationDescription {
    authenticationType?: string | undefined;
}
export interface KafkaClusterEncryptionInTransitDescription {
    encryptionType?: string | undefined;
}
export interface CloudWatchLogsLogDeliveryDescription {
    enabled?: boolean | undefined;
    logGroup?: string | undefined;
}
export interface FirehoseLogDeliveryDescription {
    deliveryStream?: string | undefined;
    enabled?: boolean | undefined;
}
export interface S3LogDeliveryDescription {
    bucket?: string | undefined;
    enabled?: boolean | undefined;
    prefix?: string | undefined;
}
export interface WorkerLogDeliveryDescription {
    cloudWatchLogs?: CloudWatchLogsLogDeliveryDescription | undefined;
    firehose?: FirehoseLogDeliveryDescription | undefined;
    s3?: S3LogDeliveryDescription | undefined;
}
export interface LogDeliveryDescription {
    workerLogDelivery?: WorkerLogDeliveryDescription | undefined;
}
export interface CustomPluginDescription {
    customPluginArn?: string | undefined;
    revision?: number | undefined;
}
export interface PluginDescription {
    customPlugin?: CustomPluginDescription | undefined;
}
export type __listOfPluginDescription = PluginDescription[];
export interface WorkerConfigurationDescription {
    revision?: number | undefined;
    workerConfigurationArn?: string | undefined;
}
export interface StateDescription {
    code?: string | undefined;
    message?: string | undefined;
}
export interface DescribeConnectorResponse {
    capacity?: CapacityDescription | undefined;
    connectorArn?: string | undefined;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    connectorDescription?: string | undefined;
    connectorName?: string | undefined;
    connectorState?: string | undefined;
    creationTime?: Date | undefined;
    currentVersion?: string | undefined;
    kafkaCluster?: KafkaClusterDescription | undefined;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription | undefined;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription | undefined;
    kafkaConnectVersion?: string | undefined;
    logDelivery?: LogDeliveryDescription | undefined;
    networkType?: string | undefined;
    plugins?: PluginDescription[] | undefined;
    serviceExecutionRoleArn?: string | undefined;
    workerConfiguration?: WorkerConfigurationDescription | undefined;
    stateDescription?: StateDescription | undefined;
}
export interface DescribeConnectorOperationRequest {
    connectorOperationArn: string;
}
export type ConnectorOperationState = string;
export type ConnectorOperationType = string;
export type ConnectorOperationStepType = string;
export type ConnectorOperationStepState = string;
export interface ConnectorOperationStep {
    stepType?: string | undefined;
    stepState?: string | undefined;
}
export type __listOfConnectorOperationStep = ConnectorOperationStep[];
export interface WorkerSetting {
    capacity?: CapacityDescription | undefined;
    plugins?: PluginDescription[] | undefined;
    workerConfiguration?: WorkerConfigurationDescription | undefined;
    useDefaultWorkerConfiguration?: boolean | undefined;
}
export interface DescribeConnectorOperationResponse {
    connectorArn?: string | undefined;
    connectorOperationArn?: string | undefined;
    connectorOperationState?: string | undefined;
    connectorOperationType?: string | undefined;
    operationSteps?: ConnectorOperationStep[] | undefined;
    originWorkerSetting?: WorkerSetting | undefined;
    originConnectorConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    targetWorkerSetting?: WorkerSetting | undefined;
    targetConnectorConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    errorInfo?: StateDescription | undefined;
    creationTime?: Date | undefined;
    endTime?: Date | undefined;
}
export interface DescribeCustomPluginRequest {
    customPluginArn: string;
}
export interface CustomPluginFileDescription {
    fileMd5?: string | undefined;
    fileSize?: number | undefined;
}
export interface S3LocationDescription {
    bucketArn?: string | undefined;
    fileKey?: string | undefined;
    objectVersion?: string | undefined;
}
export interface CustomPluginLocationDescription {
    s3Location?: S3LocationDescription | undefined;
}
export interface CustomPluginRevisionSummary {
    contentType?: string | undefined;
    creationTime?: Date | undefined;
    description?: string | undefined;
    fileDescription?: CustomPluginFileDescription | undefined;
    location?: CustomPluginLocationDescription | undefined;
    revision?: number | undefined;
}
export interface DescribeCustomPluginResponse {
    creationTime?: Date | undefined;
    customPluginArn?: string | undefined;
    customPluginState?: string | undefined;
    description?: string | undefined;
    latestRevision?: CustomPluginRevisionSummary | undefined;
    name?: string | undefined;
    stateDescription?: StateDescription | undefined;
}
export interface DescribeWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export interface WorkerConfigurationRevisionDescription {
    creationTime?: Date | undefined;
    description?: string | undefined;
    propertiesFileContent?: string | redacted.Redacted<string> | undefined;
    revision?: number | undefined;
}
export interface DescribeWorkerConfigurationResponse {
    creationTime?: Date | undefined;
    description?: string | undefined;
    latestRevision?: WorkerConfigurationRevisionDescription | undefined;
    name?: string | undefined;
    workerConfigurationArn?: string | undefined;
    workerConfigurationState?: string | undefined;
}
export type MaxResults = number;
export interface ListConnectorOperationsRequest {
    connectorArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ConnectorOperationSummary {
    connectorOperationArn?: string | undefined;
    connectorOperationType?: string | undefined;
    connectorOperationState?: string | undefined;
    creationTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type __listOfConnectorOperationSummary = ConnectorOperationSummary[];
export interface ListConnectorOperationsResponse {
    connectorOperations?: ConnectorOperationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListConnectorsRequest {
    connectorNamePrefix?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ConnectorSummary {
    capacity?: CapacityDescription | undefined;
    connectorArn?: string | undefined;
    connectorDescription?: string | undefined;
    connectorName?: string | undefined;
    connectorState?: string | undefined;
    creationTime?: Date | undefined;
    currentVersion?: string | undefined;
    kafkaCluster?: KafkaClusterDescription | undefined;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription | undefined;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription | undefined;
    kafkaConnectVersion?: string | undefined;
    logDelivery?: LogDeliveryDescription | undefined;
    networkType?: string | undefined;
    plugins?: PluginDescription[] | undefined;
    serviceExecutionRoleArn?: string | undefined;
    workerConfiguration?: WorkerConfigurationDescription | undefined;
}
export type __listOfConnectorSummary = ConnectorSummary[];
export interface ListConnectorsResponse {
    connectors?: ConnectorSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCustomPluginsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    namePrefix?: string | undefined;
}
export interface CustomPluginSummary {
    creationTime?: Date | undefined;
    customPluginArn?: string | undefined;
    customPluginState?: string | undefined;
    description?: string | undefined;
    latestRevision?: CustomPluginRevisionSummary | undefined;
    name?: string | undefined;
}
export type __listOfCustomPluginSummary = CustomPluginSummary[];
export interface ListCustomPluginsResponse {
    customPlugins?: CustomPluginSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListWorkerConfigurationsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    namePrefix?: string | undefined;
}
export interface WorkerConfigurationSummary {
    creationTime?: Date | undefined;
    description?: string | undefined;
    latestRevision?: WorkerConfigurationRevisionSummary | undefined;
    name?: string | undefined;
    workerConfigurationArn?: string | undefined;
    workerConfigurationState?: string | undefined;
}
export type __listOfWorkerConfigurationSummary = WorkerConfigurationSummary[];
export interface ListWorkerConfigurationsResponse {
    nextToken?: string | undefined;
    workerConfigurations?: WorkerConfigurationSummary[] | undefined;
}
export interface PauseConnectorRequest {
    connectorArn: string;
}
export interface PauseConnectorResponse {
    connectorArn?: string | undefined;
    connectorOperationArn?: string | undefined;
}
export interface RestartConnectorRequest {
    connectorArn: string;
    onlyFailedTasks?: boolean | undefined;
}
export interface RestartConnectorResponse {
    connectorArn?: string | undefined;
    connectorOperationArn?: string | undefined;
}
export interface ResumeConnectorRequest {
    connectorArn: string;
}
export interface ResumeConnectorResponse {
    connectorArn?: string | undefined;
    connectorOperationArn?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface ScaleInPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export interface ScaleOutPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export interface AutoScalingUpdate {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy: ScaleInPolicyUpdate;
    scaleOutPolicy: ScaleOutPolicyUpdate;
    maxAutoscalingTaskCount?: number | undefined;
}
export interface ProvisionedCapacityUpdate {
    mcuCount: number;
    workerCount: number;
}
export interface CapacityUpdate {
    autoScaling?: AutoScalingUpdate | undefined;
    provisionedCapacity?: ProvisionedCapacityUpdate | undefined;
}
export type ConnectorConfigurationUpdate = {
    [key: string]: string | undefined;
};
export interface CustomPluginUpdate {
    customPluginArn: string;
    revision: number;
}
export interface PluginUpdate {
    customPlugin: CustomPluginUpdate;
}
export type __listOfPluginUpdate = PluginUpdate[];
export interface WorkerConfigurationUpdate {
    revision: number;
    workerConfigurationArn: string;
}
export interface UpdateConnectorRequest {
    capacity?: CapacityUpdate | undefined;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    skipHealthValidation?: boolean | undefined;
    connectorArn: string;
    currentVersion: string;
    plugins?: PluginUpdate[] | undefined;
    workerConfiguration?: WorkerConfigurationUpdate | undefined;
    useDefaultWorkerConfiguration?: boolean | undefined;
}
export interface UpdateConnectorResponse {
    connectorArn?: string | undefined;
    connectorState?: string | undefined;
    connectorOperationArn?: string | undefined;
}
export type CreateConnectorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a connector using the specified properties.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest & RegionInput, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateCustomPluginError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom plugin using the specified properties.
 */
export declare const createCustomPlugin: API.OperationMethod<CreateCustomPluginRequest & RegionInput, CreateCustomPluginResponse, CreateCustomPluginError, Credentials | HttpClient.HttpClient>;
export type CreateWorkerConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a worker configuration using the specified properties.
 */
export declare const createWorkerConfiguration: API.OperationMethod<CreateWorkerConfigurationRequest & RegionInput, CreateWorkerConfigurationResponse, CreateWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest & RegionInput, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a custom plugin.
 */
export declare const deleteCustomPlugin: API.OperationMethod<DeleteCustomPluginRequest & RegionInput, DeleteCustomPluginResponse, DeleteCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified worker configuration.
 */
export declare const deleteWorkerConfiguration: API.OperationMethod<DeleteWorkerConfigurationRequest & RegionInput, DeleteWorkerConfigurationResponse, DeleteWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns summary information about the connector.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest & RegionInput, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about the specified connector's operations.
 */
export declare const describeConnectorOperation: API.OperationMethod<DescribeConnectorOperationRequest & RegionInput, DescribeConnectorOperationResponse, DescribeConnectorOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A summary description of the custom plugin.
 */
export declare const describeCustomPlugin: API.OperationMethod<DescribeCustomPluginRequest & RegionInput, DescribeCustomPluginResponse, DescribeCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about a worker configuration.
 */
export declare const describeWorkerConfiguration: API.OperationMethod<DescribeWorkerConfigurationRequest & RegionInput, DescribeWorkerConfigurationResponse, DescribeWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListConnectorOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a connector's operation(s).
 */
export declare const listConnectorOperations: API.PaginatedOperationMethod<ListConnectorOperationsRequest & RegionInput, ListConnectorOperationsResponse, ListConnectorOperationsError, Credentials | HttpClient.HttpClient, ConnectorOperationSummary>;
export type ListConnectorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the connectors in this account and Region. The list is limited to connectors whose name starts with the specified prefix. The response also includes a description of each of the listed connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListCustomPluginsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the custom plugins in this account and Region.
 */
export declare const listCustomPlugins: API.PaginatedOperationMethod<ListCustomPluginsRequest & RegionInput, ListCustomPluginsResponse, ListCustomPluginsError, Credentials | HttpClient.HttpClient, CustomPluginSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists all the tags attached to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkerConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the worker configurations in this account and Region.
 */
export declare const listWorkerConfigurations: API.PaginatedOperationMethod<ListWorkerConfigurationsRequest & RegionInput, ListWorkerConfigurationsResponse, ListWorkerConfigurationsError, Credentials | HttpClient.HttpClient, WorkerConfigurationSummary>;
export type PauseConnectorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Pauses the specified connector. The operation runs asynchronously. To track the pause, pass the connector operation ARN from the response to `DescribeConnectorOperation`.
 */
export declare const pauseConnector: API.OperationMethod<PauseConnectorRequest & RegionInput, PauseConnectorResponse, PauseConnectorError, Credentials | HttpClient.HttpClient>;
export type RestartConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Restarts the specified connector. By default, this operation restarts the connector and all of its tasks. This operation is asynchronous and returns a connector operation ARN that you can pass to `DescribeConnectorOperation` to track the state of the restart.
 */
export declare const restartConnector: API.OperationMethod<RestartConnectorRequest & RegionInput, RestartConnectorResponse, RestartConnectorError, Credentials | HttpClient.HttpClient>;
export type ResumeConnectorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Resumes the specified paused connector. The operation runs asynchronously. To track the resume, pass the connector operation ARN from the response to `DescribeConnectorOperation`.
 */
export declare const resumeConnector: API.OperationMethod<ResumeConnectorRequest & RegionInput, ResumeConnectorResponse, ResumeConnectorError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Attaches tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified connector. In the request body, you can update either the connector's worker setting or its connector configuration, but not both in the same request. To update the worker setting, specify one or more of `capacity`, `plugins`, `workerConfiguration`, or `useDefaultWorkerConfiguration`. To update the connector configuration, specify only `connectorConfiguration`.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest & RegionInput, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafkaconnect.d.ts.map