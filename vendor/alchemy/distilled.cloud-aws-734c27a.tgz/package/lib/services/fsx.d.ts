import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessPointAlreadyOwnedByYou_base: S.TaggedErrorClass<"AccessPointAlreadyOwnedByYou", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class AccessPointAlreadyOwnedByYou extends /*@__PURE__*/ AccessPointAlreadyOwnedByYou_base {
}
declare const ActiveDirectoryError_base: S.TaggedErrorClass<"ActiveDirectoryError", {
    readonly ActiveDirectoryId: any;
    readonly Type: any;
    readonly message: any;
}>;
export declare class ActiveDirectoryError extends /*@__PURE__*/ ActiveDirectoryError_base {
}
declare const BackupBeingCopied_base: S.TaggedErrorClass<"BackupBeingCopied", {
    readonly message: any;
    readonly BackupId: any;
}>;
export declare class BackupBeingCopied extends /*@__PURE__*/ BackupBeingCopied_base {
}
declare const BackupInProgress_base: S.TaggedErrorClass<"BackupInProgress", {
    readonly message: any;
}>;
export declare class BackupInProgress extends /*@__PURE__*/ BackupInProgress_base {
}
declare const BackupNotFound_base: S.TaggedErrorClass<"BackupNotFound", {
    readonly message: any;
}>;
export declare class BackupNotFound extends /*@__PURE__*/ BackupNotFound_base {
}
declare const BackupRestoring_base: S.TaggedErrorClass<"BackupRestoring", {
    readonly message: any;
    readonly FileSystemId: any;
}>;
export declare class BackupRestoring extends /*@__PURE__*/ BackupRestoring_base {
}
declare const BadRequest_base: S.TaggedErrorClass<"BadRequest", {
    readonly message: any;
}>;
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const DataRepositoryAssociationNotFound_base: S.TaggedErrorClass<"DataRepositoryAssociationNotFound", {
    readonly message: any;
}>;
export declare class DataRepositoryAssociationNotFound extends /*@__PURE__*/ DataRepositoryAssociationNotFound_base {
}
declare const DataRepositoryTaskEnded_base: S.TaggedErrorClass<"DataRepositoryTaskEnded", {
    readonly message: any;
}>;
export declare class DataRepositoryTaskEnded extends /*@__PURE__*/ DataRepositoryTaskEnded_base {
}
declare const DataRepositoryTaskExecuting_base: S.TaggedErrorClass<"DataRepositoryTaskExecuting", {
    readonly message: any;
}>;
export declare class DataRepositoryTaskExecuting extends /*@__PURE__*/ DataRepositoryTaskExecuting_base {
}
declare const DataRepositoryTaskNotFound_base: S.TaggedErrorClass<"DataRepositoryTaskNotFound", {
    readonly message: any;
}>;
export declare class DataRepositoryTaskNotFound extends /*@__PURE__*/ DataRepositoryTaskNotFound_base {
}
declare const FileCacheNotFound_base: S.TaggedErrorClass<"FileCacheNotFound", {
    readonly message: any;
}>;
export declare class FileCacheNotFound extends /*@__PURE__*/ FileCacheNotFound_base {
}
declare const FileSystemNotFound_base: S.TaggedErrorClass<"FileSystemNotFound", {
    readonly message: any;
}>;
export declare class FileSystemNotFound extends /*@__PURE__*/ FileSystemNotFound_base {
}
declare const IncompatibleParameterError_base: S.TaggedErrorClass<"IncompatibleParameterError", {
    readonly Parameter: any;
    readonly message: any;
}>;
export declare class IncompatibleParameterError extends /*@__PURE__*/ IncompatibleParameterError_base {
}
declare const IncompatibleRegionForMultiAZ_base: S.TaggedErrorClass<"IncompatibleRegionForMultiAZ", {
    readonly message: any;
}>;
export declare class IncompatibleRegionForMultiAZ extends /*@__PURE__*/ IncompatibleRegionForMultiAZ_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidAccessPoint_base: S.TaggedErrorClass<"InvalidAccessPoint", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccessPoint extends /*@__PURE__*/ InvalidAccessPoint_base {
}
declare const InvalidDataRepositoryType_base: S.TaggedErrorClass<"InvalidDataRepositoryType", {
    readonly message: any;
}>;
export declare class InvalidDataRepositoryType extends /*@__PURE__*/ InvalidDataRepositoryType_base {
}
declare const InvalidDestinationKmsKey_base: S.TaggedErrorClass<"InvalidDestinationKmsKey", {
    readonly message: any;
}>;
export declare class InvalidDestinationKmsKey extends /*@__PURE__*/ InvalidDestinationKmsKey_base {
}
declare const InvalidExportPath_base: S.TaggedErrorClass<"InvalidExportPath", {
    readonly message: any;
}>;
export declare class InvalidExportPath extends /*@__PURE__*/ InvalidExportPath_base {
}
declare const InvalidImportPath_base: S.TaggedErrorClass<"InvalidImportPath", {
    readonly message: any;
}>;
export declare class InvalidImportPath extends /*@__PURE__*/ InvalidImportPath_base {
}
declare const InvalidNetworkSettings_base: S.TaggedErrorClass<"InvalidNetworkSettings", {
    readonly message: any;
    readonly InvalidSubnetId: any;
    readonly InvalidSecurityGroupId: any;
    readonly InvalidRouteTableId: any;
}>;
export declare class InvalidNetworkSettings extends /*@__PURE__*/ InvalidNetworkSettings_base {
}
declare const InvalidPerUnitStorageThroughput_base: S.TaggedErrorClass<"InvalidPerUnitStorageThroughput", {
    readonly message: any;
}>;
export declare class InvalidPerUnitStorageThroughput extends /*@__PURE__*/ InvalidPerUnitStorageThroughput_base {
}
declare const InvalidRegion_base: S.TaggedErrorClass<"InvalidRegion", {
    readonly message: any;
}>;
export declare class InvalidRegion extends /*@__PURE__*/ InvalidRegion_base {
}
declare const InvalidRequest_base: S.TaggedErrorClass<"InvalidRequest", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
declare const InvalidSourceKmsKey_base: S.TaggedErrorClass<"InvalidSourceKmsKey", {
    readonly message: any;
}>;
export declare class InvalidSourceKmsKey extends /*@__PURE__*/ InvalidSourceKmsKey_base {
}
declare const MissingFileCacheConfiguration_base: S.TaggedErrorClass<"MissingFileCacheConfiguration", {
    readonly message: any;
}>;
export declare class MissingFileCacheConfiguration extends /*@__PURE__*/ MissingFileCacheConfiguration_base {
}
declare const MissingFileSystemConfiguration_base: S.TaggedErrorClass<"MissingFileSystemConfiguration", {
    readonly message: any;
}>;
export declare class MissingFileSystemConfiguration extends /*@__PURE__*/ MissingFileSystemConfiguration_base {
}
declare const MissingVolumeConfiguration_base: S.TaggedErrorClass<"MissingVolumeConfiguration", {
    readonly message: any;
}>;
export declare class MissingVolumeConfiguration extends /*@__PURE__*/ MissingVolumeConfiguration_base {
}
declare const NotServiceResourceError_base: S.TaggedErrorClass<"NotServiceResourceError", {
    readonly ResourceARN: any;
    readonly message: any;
}>;
export declare class NotServiceResourceError extends /*@__PURE__*/ NotServiceResourceError_base {
}
declare const ResourceDoesNotSupportTagging_base: S.TaggedErrorClass<"ResourceDoesNotSupportTagging", {
    readonly ResourceARN: any;
    readonly message: any;
}>;
export declare class ResourceDoesNotSupportTagging extends /*@__PURE__*/ ResourceDoesNotSupportTagging_base {
}
declare const ResourceNotFound_base: S.TaggedErrorClass<"ResourceNotFound", {
    readonly ResourceARN: any;
    readonly message: any;
}>;
export declare class ResourceNotFound extends /*@__PURE__*/ ResourceNotFound_base {
}
declare const RestoreSnapshotNotFound_base: S.TaggedErrorClass<"RestoreSnapshotNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class RestoreSnapshotNotFound extends /*@__PURE__*/ RestoreSnapshotNotFound_base {
}
declare const S3AccessPointAttachmentNotFound_base: S.TaggedErrorClass<"S3AccessPointAttachmentNotFound", {
    readonly message: any;
}>;
export declare class S3AccessPointAttachmentNotFound extends /*@__PURE__*/ S3AccessPointAttachmentNotFound_base {
}
declare const ServiceLimitExceeded_base: S.TaggedErrorClass<"ServiceLimitExceeded", {
    readonly Limit: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ServiceLimitExceeded extends /*@__PURE__*/ ServiceLimitExceeded_base {
}
declare const SnapshotNotFound_base: S.TaggedErrorClass<"SnapshotNotFound", {
    readonly message: any;
}>;
export declare class SnapshotNotFound extends /*@__PURE__*/ SnapshotNotFound_base {
}
declare const SnapshotVolumeNotFound_base: S.TaggedErrorClass<"SnapshotVolumeNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SnapshotVolumeNotFound extends /*@__PURE__*/ SnapshotVolumeNotFound_base {
}
declare const SourceBackupUnavailable_base: S.TaggedErrorClass<"SourceBackupUnavailable", {
    readonly message: any;
    readonly BackupId: any;
}>;
export declare class SourceBackupUnavailable extends /*@__PURE__*/ SourceBackupUnavailable_base {
}
declare const SourceSnapshotNotFound_base: S.TaggedErrorClass<"SourceSnapshotNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SourceSnapshotNotFound extends /*@__PURE__*/ SourceSnapshotNotFound_base {
}
declare const StorageVirtualMachineNotFound_base: S.TaggedErrorClass<"StorageVirtualMachineNotFound", {
    readonly message: any;
}>;
export declare class StorageVirtualMachineNotFound extends /*@__PURE__*/ StorageVirtualMachineNotFound_base {
}
declare const TooManyAccessPoints_base: S.TaggedErrorClass<"TooManyAccessPoints", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyAccessPoints extends /*@__PURE__*/ TooManyAccessPoints_base {
}
declare const UnsupportedOperation_base: S.TaggedErrorClass<"UnsupportedOperation", {
    readonly message: any;
}>;
export declare class UnsupportedOperation extends /*@__PURE__*/ UnsupportedOperation_base {
}
declare const UpdateSnapshotNotFound_base: S.TaggedErrorClass<"UpdateSnapshotNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class UpdateSnapshotNotFound extends /*@__PURE__*/ UpdateSnapshotNotFound_base {
}
declare const VolumeNotFound_base: S.TaggedErrorClass<"VolumeNotFound", {
    readonly message: any;
}>;
export declare class VolumeNotFound extends /*@__PURE__*/ VolumeNotFound_base {
}
export type ClientRequestToken = string;
export type FileSystemId = string;
export type AlternateDNSName = string;
export type AlternateDNSNames = string[];
export interface AssociateFileSystemAliasesRequest {
    ClientRequestToken?: string | undefined;
    FileSystemId?: string | undefined;
    Aliases?: string[] | undefined;
}
export type AliasLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "CREATE_FAILED" | "DELETE_FAILED" | (string & {});
export interface Alias {
    Name?: string | undefined;
    Lifecycle?: AliasLifecycle | undefined;
}
export type Aliases = Alias[];
export interface AssociateFileSystemAliasesResponse {
    Aliases?: Alias[] | undefined;
}
export type TaskId = string;
export interface CancelDataRepositoryTaskRequest {
    TaskId?: string | undefined;
}
export type DataRepositoryTaskLifecycle = "PENDING" | "EXECUTING" | "FAILED" | "SUCCEEDED" | "CANCELED" | "CANCELING" | (string & {});
export interface CancelDataRepositoryTaskResponse {
    Lifecycle?: DataRepositoryTaskLifecycle | undefined;
    TaskId?: string | undefined;
}
export type SourceBackupId = string;
export type Region = string;
export type KmsKeyId = string;
export type Flag = boolean;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type Tags = Tag[];
export interface CopyBackupRequest {
    ClientRequestToken?: string | undefined;
    SourceBackupId?: string | undefined;
    SourceRegion?: string | undefined;
    KmsKeyId?: string | undefined;
    CopyTags?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type BackupId = string;
export type BackupLifecycle = "AVAILABLE" | "CREATING" | "TRANSFERRING" | "DELETED" | "FAILED" | "PENDING" | "COPYING" | (string & {});
export type ErrorMessage = string;
export interface BackupFailureDetails {
    Message?: string | undefined;
}
export type BackupType = "AUTOMATIC" | "USER_INITIATED" | "AWS_BACKUP" | (string & {});
export type ProgressPercent = number;
export type CreationTime = Date;
export type ResourceARN = string;
export type AWSAccountId = string;
export type FileSystemType = "WINDOWS" | "LUSTRE" | "ONTAP" | "OPENZFS" | (string & {});
export type FileSystemLifecycle = "AVAILABLE" | "CREATING" | "FAILED" | "DELETING" | "MISCONFIGURED" | "UPDATING" | "MISCONFIGURED_UNAVAILABLE" | (string & {});
export interface FileSystemFailureDetails {
    Message?: string | undefined;
}
export type StorageCapacity = number;
export type StorageType = "SSD" | "HDD" | "INTELLIGENT_TIERING" | (string & {});
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type NetworkInterfaceId = string;
export type NetworkInterfaceIds = string[];
export type DNSName = string;
export type DirectoryId = string;
export type ActiveDirectoryFullyQualifiedName = string;
export type OrganizationalUnitDistinguishedName = string;
export type FileSystemAdministratorsGroupName = string;
export type DirectoryUserName = string;
export type IpAddress = string;
export type DnsIps = string[];
export type CustomerSecretsManagerARN = string;
export interface SelfManagedActiveDirectoryAttributes {
    DomainName?: string | undefined;
    OrganizationalUnitDistinguishedName?: string | undefined;
    FileSystemAdministratorsGroup?: string | undefined;
    UserName?: string | undefined;
    DnsIps?: string[] | undefined;
    DomainJoinServiceAccountSecret?: string | undefined;
}
export type WindowsDeploymentType = "MULTI_AZ_1" | "SINGLE_AZ_1" | "SINGLE_AZ_2" | (string & {});
export type MegabytesPerSecond = number;
export type FileSystemMaintenanceOperation = "PATCHING" | "BACKING_UP" | (string & {});
export type FileSystemMaintenanceOperations = FileSystemMaintenanceOperation[];
export type WeeklyTime = string;
export type DailyTime = string;
export type AutomaticBackupRetentionDays = number;
export type WindowsAccessAuditLogLevel = "DISABLED" | "SUCCESS_ONLY" | "FAILURE_ONLY" | "SUCCESS_AND_FAILURE" | (string & {});
export type GeneralARN = string;
export interface WindowsAuditLogConfiguration {
    FileAccessAuditLogLevel?: WindowsAccessAuditLogLevel | undefined;
    FileShareAccessAuditLogLevel?: WindowsAccessAuditLogLevel | undefined;
    AuditLogDestination?: string | undefined;
}
export type DiskIopsConfigurationMode = "AUTOMATIC" | "USER_PROVISIONED" | (string & {});
export type Iops = number;
export interface DiskIopsConfiguration {
    Mode?: DiskIopsConfigurationMode | undefined;
    Iops?: number | undefined;
}
export interface WindowsFsrmConfiguration {
    FsrmServiceEnabled?: boolean | undefined;
    EventLogDestination?: string | undefined;
}
export interface WindowsFileSystemConfiguration {
    ActiveDirectoryId?: string | undefined;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryAttributes | undefined;
    DeploymentType?: WindowsDeploymentType | undefined;
    RemoteAdministrationEndpoint?: string | undefined;
    PreferredSubnetId?: string | undefined;
    PreferredFileServerIp?: string | undefined;
    ThroughputCapacity?: number | undefined;
    MaintenanceOperationsInProgress?: FileSystemMaintenanceOperation[] | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    Aliases?: Alias[] | undefined;
    AuditLogConfiguration?: WindowsAuditLogConfiguration | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    PreferredFileServerIpv6?: string | undefined;
    FsrmConfiguration?: WindowsFsrmConfiguration | undefined;
}
export type DataRepositoryLifecycle = "CREATING" | "AVAILABLE" | "MISCONFIGURED" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type ArchivePath = string;
export type Megabytes = number;
export type AutoImportPolicyType = "NONE" | "NEW" | "NEW_CHANGED" | "NEW_CHANGED_DELETED" | (string & {});
export interface DataRepositoryFailureDetails {
    Message?: string | undefined;
}
export interface DataRepositoryConfiguration {
    Lifecycle?: DataRepositoryLifecycle | undefined;
    ImportPath?: string | undefined;
    ExportPath?: string | undefined;
    ImportedFileChunkSize?: number | undefined;
    AutoImportPolicy?: AutoImportPolicyType | undefined;
    FailureDetails?: DataRepositoryFailureDetails | undefined;
}
export type LustreDeploymentType = "SCRATCH_1" | "SCRATCH_2" | "PERSISTENT_1" | "PERSISTENT_2" | (string & {});
export type PerUnitStorageThroughput = number;
export type LustreFileSystemMountName = string;
export type DriveCacheType = "NONE" | "READ" | (string & {});
export type DataCompressionType = "NONE" | "LZ4" | (string & {});
export type LustreAccessAuditLogLevel = "DISABLED" | "WARN_ONLY" | "ERROR_ONLY" | "WARN_ERROR" | (string & {});
export interface LustreLogConfiguration {
    Level?: LustreAccessAuditLogLevel | undefined;
    Destination?: string | undefined;
}
export type LustreRootSquash = string;
export type LustreNoSquashNid = string;
export type LustreNoSquashNids = string[];
export interface LustreRootSquashConfiguration {
    RootSquash?: string | undefined;
    NoSquashNids?: string[] | undefined;
}
export type MetadataIops = number;
export type MetadataConfigurationMode = "AUTOMATIC" | "USER_PROVISIONED" | (string & {});
export interface FileSystemLustreMetadataConfiguration {
    Iops?: number | undefined;
    Mode?: MetadataConfigurationMode | undefined;
}
export type ThroughputCapacityMbps = number;
export type LustreReadCacheSizingMode = "NO_CACHE" | "USER_PROVISIONED" | "PROPORTIONAL_TO_THROUGHPUT_CAPACITY" | (string & {});
export interface LustreReadCacheConfiguration {
    SizingMode?: LustreReadCacheSizingMode | undefined;
    SizeGiB?: number | undefined;
}
export interface LustreFileSystemConfiguration {
    WeeklyMaintenanceStartTime?: string | undefined;
    DataRepositoryConfiguration?: DataRepositoryConfiguration | undefined;
    DeploymentType?: LustreDeploymentType | undefined;
    PerUnitStorageThroughput?: number | undefined;
    MountName?: string | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    DriveCacheType?: DriveCacheType | undefined;
    DataCompressionType?: DataCompressionType | undefined;
    LogConfiguration?: LustreLogConfiguration | undefined;
    RootSquashConfiguration?: LustreRootSquashConfiguration | undefined;
    MetadataConfiguration?: FileSystemLustreMetadataConfiguration | undefined;
    EfaEnabled?: boolean | undefined;
    ThroughputCapacity?: number | undefined;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration | undefined;
}
export type AdministrativeActionType = "FILE_SYSTEM_UPDATE" | "STORAGE_OPTIMIZATION" | "FILE_SYSTEM_ALIAS_ASSOCIATION" | "FILE_SYSTEM_ALIAS_DISASSOCIATION" | "VOLUME_UPDATE" | "SNAPSHOT_UPDATE" | "RELEASE_NFS_V3_LOCKS" | "VOLUME_RESTORE" | "THROUGHPUT_OPTIMIZATION" | "IOPS_OPTIMIZATION" | "STORAGE_TYPE_OPTIMIZATION" | "MISCONFIGURED_STATE_RECOVERY" | "VOLUME_UPDATE_WITH_SNAPSHOT" | "VOLUME_INITIALIZE_WITH_SNAPSHOT" | "DOWNLOAD_DATA_FROM_BACKUP" | (string & {});
export type RequestTime = Date;
export type Status = "FAILED" | "IN_PROGRESS" | "PENDING" | "COMPLETED" | "UPDATED_OPTIMIZING" | "OPTIMIZING" | "PAUSED" | "CANCELLED" | (string & {});
export interface AdministrativeActionFailureDetails {
    Message?: string | undefined;
}
export type VolumeLifecycle = "CREATING" | "CREATED" | "DELETING" | "FAILED" | "MISCONFIGURED" | "PENDING" | "AVAILABLE" | (string & {});
export type VolumeName = string;
export type FlexCacheEndpointType = "NONE" | "ORIGIN" | "CACHE" | (string & {});
export type JunctionPath = string;
export type SecurityStyle = "UNIX" | "NTFS" | "MIXED" | (string & {});
export type VolumeCapacity = number;
export type StorageVirtualMachineId = string;
export type CoolingPeriod = number;
export type TieringPolicyName = "SNAPSHOT_ONLY" | "AUTO" | "ALL" | "NONE" | (string & {});
export interface TieringPolicy {
    CoolingPeriod?: number | undefined;
    Name?: TieringPolicyName | undefined;
}
export type UUID = string;
export type OntapVolumeType = "RW" | "DP" | "LS" | (string & {});
export type SnapshotPolicy = string;
export type AutocommitPeriodType = "MINUTES" | "HOURS" | "DAYS" | "MONTHS" | "YEARS" | "NONE" | (string & {});
export type AutocommitPeriodValue = number;
export interface AutocommitPeriod {
    Type?: AutocommitPeriodType | undefined;
    Value?: number | undefined;
}
export type PrivilegedDelete = "DISABLED" | "ENABLED" | "PERMANENTLY_DISABLED" | (string & {});
export type RetentionPeriodType = "SECONDS" | "MINUTES" | "HOURS" | "DAYS" | "MONTHS" | "YEARS" | "INFINITE" | "UNSPECIFIED" | (string & {});
export type RetentionPeriodValue = number;
export interface RetentionPeriod {
    Type?: RetentionPeriodType | undefined;
    Value?: number | undefined;
}
export interface SnaplockRetentionPeriod {
    DefaultRetention?: RetentionPeriod | undefined;
    MinimumRetention?: RetentionPeriod | undefined;
    MaximumRetention?: RetentionPeriod | undefined;
}
export type SnaplockType = "COMPLIANCE" | "ENTERPRISE" | (string & {});
export interface SnaplockConfiguration {
    AuditLogVolume?: boolean | undefined;
    AutocommitPeriod?: AutocommitPeriod | undefined;
    PrivilegedDelete?: PrivilegedDelete | undefined;
    RetentionPeriod?: SnaplockRetentionPeriod | undefined;
    SnaplockType?: SnaplockType | undefined;
    VolumeAppendModeEnabled?: boolean | undefined;
}
export type VolumeStyle = "FLEXVOL" | "FLEXGROUP" | (string & {});
export type Aggregate = string;
export type Aggregates = string[];
export type TotalConstituents = number;
export interface AggregateConfiguration {
    Aggregates?: string[] | undefined;
    TotalConstituents?: number | undefined;
}
export type VolumeCapacityBytes = number;
export interface OntapVolumeConfiguration {
    FlexCacheEndpointType?: FlexCacheEndpointType | undefined;
    JunctionPath?: string | undefined;
    SecurityStyle?: SecurityStyle | undefined;
    SizeInMegabytes?: number | undefined;
    StorageEfficiencyEnabled?: boolean | undefined;
    StorageVirtualMachineId?: string | undefined;
    StorageVirtualMachineRoot?: boolean | undefined;
    TieringPolicy?: TieringPolicy | undefined;
    UUID?: string | undefined;
    OntapVolumeType?: OntapVolumeType | undefined;
    SnapshotPolicy?: string | undefined;
    CopyTagsToBackups?: boolean | undefined;
    SnaplockConfiguration?: SnaplockConfiguration | undefined;
    VolumeStyle?: VolumeStyle | undefined;
    AggregateConfiguration?: AggregateConfiguration | undefined;
    SizeInBytes?: number | undefined;
}
export type VolumeId = string;
export type VolumeType = "ONTAP" | "OPENZFS" | (string & {});
export interface LifecycleTransitionReason {
    Message?: string | undefined;
}
export type VolumePath = string;
export type IntegerNoMax = number;
export type IntegerRecordSizeKiB = number;
export type OpenZFSDataCompressionType = "NONE" | "ZSTD" | "LZ4" | (string & {});
export type OpenZFSCopyStrategy = "CLONE" | "FULL_COPY" | "INCREMENTAL_COPY" | (string & {});
export interface OpenZFSOriginSnapshotConfiguration {
    SnapshotARN?: string | undefined;
    CopyStrategy?: OpenZFSCopyStrategy | undefined;
}
export type ReadOnly = boolean;
export type OpenZFSClients = string;
export type OpenZFSNfsExportOption = string;
export type OpenZFSNfsExportOptions = string[];
export interface OpenZFSClientConfiguration {
    Clients?: string | undefined;
    Options?: string[] | undefined;
}
export type OpenZFSClientConfigurations = OpenZFSClientConfiguration[];
export interface OpenZFSNfsExport {
    ClientConfigurations?: OpenZFSClientConfiguration[] | undefined;
}
export type OpenZFSNfsExports = OpenZFSNfsExport[];
export type OpenZFSQuotaType = "USER" | "GROUP" | (string & {});
export interface OpenZFSUserOrGroupQuota {
    Type?: OpenZFSQuotaType | undefined;
    Id?: number | undefined;
    StorageCapacityQuotaGiB?: number | undefined;
}
export type OpenZFSUserAndGroupQuotas = OpenZFSUserOrGroupQuota[];
export type SnapshotId = string;
export interface OpenZFSVolumeConfiguration {
    ParentVolumeId?: string | undefined;
    VolumePath?: string | undefined;
    StorageCapacityReservationGiB?: number | undefined;
    StorageCapacityQuotaGiB?: number | undefined;
    RecordSizeKiB?: number | undefined;
    DataCompressionType?: OpenZFSDataCompressionType | undefined;
    CopyTagsToSnapshots?: boolean | undefined;
    OriginSnapshot?: OpenZFSOriginSnapshotConfiguration | undefined;
    ReadOnly?: boolean | undefined;
    NfsExports?: OpenZFSNfsExport[] | undefined;
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[] | undefined;
    RestoreToSnapshot?: string | undefined;
    DeleteIntermediateSnaphots?: boolean | undefined;
    DeleteClonedVolumes?: boolean | undefined;
    DeleteIntermediateData?: boolean | undefined;
    SourceSnapshotARN?: string | undefined;
    DestinationSnapshot?: string | undefined;
    CopyStrategy?: OpenZFSCopyStrategy | undefined;
}
export interface Volume {
    CreationTime?: Date | undefined;
    FileSystemId?: string | undefined;
    Lifecycle?: VolumeLifecycle | undefined;
    Name?: string | undefined;
    OntapConfiguration?: OntapVolumeConfiguration | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
    VolumeId?: string | undefined;
    VolumeType?: VolumeType | undefined;
    LifecycleTransitionReason?: LifecycleTransitionReason | undefined;
    AdministrativeActions?: AdministrativeAction[] | undefined;
    OpenZFSConfiguration?: OpenZFSVolumeConfiguration | undefined;
}
export type SnapshotName = string;
export type SnapshotLifecycle = "PENDING" | "CREATING" | "DELETING" | "AVAILABLE" | (string & {});
export interface Snapshot {
    ResourceARN?: string | undefined;
    SnapshotId?: string | undefined;
    Name?: string | undefined;
    VolumeId?: string | undefined;
    CreationTime?: Date | undefined;
    Lifecycle?: SnapshotLifecycle | undefined;
    LifecycleTransitionReason?: LifecycleTransitionReason | undefined;
    Tags?: Tag[] | undefined;
    AdministrativeActions?: AdministrativeAction[] | undefined;
}
export type TotalTransferBytes = number;
export type RemainingTransferBytes = number;
export interface AdministrativeAction {
    AdministrativeActionType?: AdministrativeActionType | undefined;
    ProgressPercent?: number | undefined;
    RequestTime?: Date | undefined;
    Status?: Status | undefined;
    TargetFileSystemValues?: FileSystem | undefined;
    FailureDetails?: AdministrativeActionFailureDetails | undefined;
    TargetVolumeValues?: Volume | undefined;
    TargetSnapshotValues?: Snapshot | undefined;
    TotalTransferBytes?: number | undefined;
    RemainingTransferBytes?: number | undefined;
    Message?: string | undefined;
}
export type AdministrativeActions = AdministrativeAction[];
export type OntapDeploymentType = "MULTI_AZ_1" | "SINGLE_AZ_1" | "SINGLE_AZ_2" | "MULTI_AZ_2" | (string & {});
export type IpAddressRange = string;
export type OntapEndpointIpAddresses = string[];
export interface FileSystemEndpoint {
    DNSName?: string | undefined;
    IpAddresses?: string[] | undefined;
    Ipv6Addresses?: string[] | undefined;
}
export interface FileSystemEndpoints {
    Intercluster?: FileSystemEndpoint | undefined;
    Management?: FileSystemEndpoint | undefined;
}
export type RouteTableId = string;
export type RouteTableIds = string[];
export type AdminPassword = string | redacted.Redacted<string>;
export type HAPairs = number;
export type ThroughputCapacityPerHAPair = number;
export type Ipv6AddressRange = string;
export interface OntapFileSystemConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    DeploymentType?: OntapDeploymentType | undefined;
    EndpointIpAddressRange?: string | undefined;
    Endpoints?: FileSystemEndpoints | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    PreferredSubnetId?: string | undefined;
    RouteTableIds?: string[] | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    FsxAdminPassword?: string | redacted.Redacted<string> | undefined;
    HAPairs?: number | undefined;
    ThroughputCapacityPerHAPair?: number | undefined;
    EndpointIpv6AddressRange?: string | undefined;
}
export type FileSystemTypeVersion = string;
export type OpenZFSDeploymentType = "SINGLE_AZ_1" | "SINGLE_AZ_2" | "SINGLE_AZ_HA_1" | "SINGLE_AZ_HA_2" | "MULTI_AZ_1" | (string & {});
export type OpenZFSReadCacheSizingMode = "NO_CACHE" | "USER_PROVISIONED" | "PROPORTIONAL_TO_THROUGHPUT_CAPACITY" | (string & {});
export interface OpenZFSReadCacheConfiguration {
    SizingMode?: OpenZFSReadCacheSizingMode | undefined;
    SizeGiB?: number | undefined;
}
export interface OpenZFSFileSystemConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    CopyTagsToVolumes?: boolean | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    DeploymentType?: OpenZFSDeploymentType | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    RootVolumeId?: string | undefined;
    PreferredSubnetId?: string | undefined;
    EndpointIpAddressRange?: string | undefined;
    EndpointIpv6AddressRange?: string | undefined;
    RouteTableIds?: string[] | undefined;
    EndpointIpAddress?: string | undefined;
    EndpointIpv6Address?: string | undefined;
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration | undefined;
}
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export interface FileSystem {
    OwnerId?: string | undefined;
    CreationTime?: Date | undefined;
    FileSystemId?: string | undefined;
    FileSystemType?: FileSystemType | undefined;
    Lifecycle?: FileSystemLifecycle | undefined;
    FailureDetails?: FileSystemFailureDetails | undefined;
    StorageCapacity?: number | undefined;
    StorageType?: StorageType | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    NetworkInterfaceIds?: string[] | undefined;
    DNSName?: string | undefined;
    KmsKeyId?: string | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
    WindowsConfiguration?: WindowsFileSystemConfiguration | undefined;
    LustreConfiguration?: LustreFileSystemConfiguration | undefined;
    AdministrativeActions?: AdministrativeAction[] | undefined;
    OntapConfiguration?: OntapFileSystemConfiguration | undefined;
    FileSystemTypeVersion?: string | undefined;
    OpenZFSConfiguration?: OpenZFSFileSystemConfiguration | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface ActiveDirectoryBackupAttributes {
    DomainName?: string | undefined;
    ActiveDirectoryId?: string | undefined;
    ResourceARN?: string | undefined;
}
export type ResourceType = "FILE_SYSTEM" | "VOLUME" | (string & {});
export type SizeInBytes = number;
export interface Backup {
    BackupId?: string | undefined;
    Lifecycle?: BackupLifecycle | undefined;
    FailureDetails?: BackupFailureDetails | undefined;
    Type?: BackupType | undefined;
    ProgressPercent?: number | undefined;
    CreationTime?: Date | undefined;
    KmsKeyId?: string | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
    FileSystem?: FileSystem | undefined;
    DirectoryInformation?: ActiveDirectoryBackupAttributes | undefined;
    OwnerId?: string | undefined;
    SourceBackupId?: string | undefined;
    SourceBackupRegion?: string | undefined;
    ResourceType?: ResourceType | undefined;
    Volume?: Volume | undefined;
    SizeInBytes?: number | undefined;
}
export interface CopyBackupResponse {
    Backup?: (Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    }) | undefined;
}
export type UpdateOpenZFSVolumeOption = "DELETE_INTERMEDIATE_SNAPSHOTS" | "DELETE_CLONED_VOLUMES" | "DELETE_INTERMEDIATE_DATA" | (string & {});
export type UpdateOpenZFSVolumeOptions = UpdateOpenZFSVolumeOption[];
export interface CopySnapshotAndUpdateVolumeRequest {
    ClientRequestToken?: string | undefined;
    VolumeId?: string | undefined;
    SourceSnapshotARN?: string | undefined;
    CopyStrategy?: OpenZFSCopyStrategy | undefined;
    Options?: UpdateOpenZFSVolumeOption[] | undefined;
}
export interface CopySnapshotAndUpdateVolumeResponse {
    VolumeId?: string | undefined;
    Lifecycle?: VolumeLifecycle | undefined;
    AdministrativeActions?: (AdministrativeAction & {
        TargetFileSystemValues: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
        };
        TargetVolumeValues: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
        TargetSnapshotValues: Snapshot & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
    })[] | undefined;
}
export type S3AccessPointAttachmentName = string;
export type S3AccessPointAttachmentType = "OPENZFS" | "ONTAP" | (string & {});
export type OpenZFSFileSystemUserType = "POSIX" | (string & {});
export type FileSystemUID = number;
export type FileSystemGID = number;
export type FileSystemSecondaryGIDs = number[];
export interface OpenZFSPosixFileSystemUser {
    Uid?: number | undefined;
    Gid?: number | undefined;
    SecondaryGids?: number[] | undefined;
}
export interface OpenZFSFileSystemIdentity {
    Type?: OpenZFSFileSystemUserType | undefined;
    PosixUser?: OpenZFSPosixFileSystemUser | undefined;
}
export interface CreateAndAttachS3AccessPointOpenZFSConfiguration {
    VolumeId?: string | undefined;
    FileSystemIdentity?: OpenZFSFileSystemIdentity | undefined;
}
export type OntapFileSystemUserType = "UNIX" | "WINDOWS" | (string & {});
export type OntapFileSystemUserName = string;
export interface OntapUnixFileSystemUser {
    Name?: string | undefined;
}
export interface OntapWindowsFileSystemUser {
    Name?: string | undefined;
}
export interface OntapFileSystemIdentity {
    Type?: OntapFileSystemUserType | undefined;
    UnixUser?: OntapUnixFileSystemUser | undefined;
    WindowsUser?: OntapWindowsFileSystemUser | undefined;
}
export interface CreateAndAttachS3AccessPointOntapConfiguration {
    VolumeId?: string | undefined;
    FileSystemIdentity?: OntapFileSystemIdentity | undefined;
}
export interface S3AccessPointVpcConfiguration {
    VpcId?: string | undefined;
}
export type AccessPointPolicy = string;
export interface CreateAndAttachS3AccessPointS3Configuration {
    VpcConfiguration?: S3AccessPointVpcConfiguration | undefined;
    Policy?: string | undefined;
}
export interface CreateAndAttachS3AccessPointRequest {
    ClientRequestToken?: string | undefined;
    Name?: string | undefined;
    Type?: S3AccessPointAttachmentType | undefined;
    OpenZFSConfiguration?: CreateAndAttachS3AccessPointOpenZFSConfiguration | undefined;
    OntapConfiguration?: CreateAndAttachS3AccessPointOntapConfiguration | undefined;
    S3AccessPoint?: CreateAndAttachS3AccessPointS3Configuration | undefined;
}
export type S3AccessPointAttachmentLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "UPDATING" | "FAILED" | "MISCONFIGURED" | (string & {});
export interface S3AccessPointOpenZFSConfiguration {
    VolumeId?: string | undefined;
    FileSystemIdentity?: OpenZFSFileSystemIdentity | undefined;
}
export interface S3AccessPointOntapConfiguration {
    VolumeId?: string | undefined;
    FileSystemIdentity?: OntapFileSystemIdentity | undefined;
}
export type S3AccessPointAlias = string;
export interface S3AccessPoint {
    ResourceARN?: string | undefined;
    Alias?: string | undefined;
    VpcConfiguration?: S3AccessPointVpcConfiguration | undefined;
}
export interface S3AccessPointAttachment {
    Lifecycle?: S3AccessPointAttachmentLifecycle | undefined;
    LifecycleTransitionReason?: LifecycleTransitionReason | undefined;
    CreationTime?: Date | undefined;
    Name?: string | undefined;
    Type?: S3AccessPointAttachmentType | undefined;
    OpenZFSConfiguration?: S3AccessPointOpenZFSConfiguration | undefined;
    OntapConfiguration?: S3AccessPointOntapConfiguration | undefined;
    S3AccessPoint?: S3AccessPoint | undefined;
}
export interface CreateAndAttachS3AccessPointResponse {
    S3AccessPointAttachment?: (S3AccessPointAttachment & {
        OpenZFSConfiguration: S3AccessPointOpenZFSConfiguration & {
            FileSystemIdentity: OpenZFSFileSystemIdentity & {
                Type: OpenZFSFileSystemUserType;
                PosixUser: OpenZFSPosixFileSystemUser & {
                    Uid: FileSystemUID;
                    Gid: FileSystemGID;
                };
            };
        };
        OntapConfiguration: S3AccessPointOntapConfiguration & {
            FileSystemIdentity: OntapFileSystemIdentity & {
                Type: OntapFileSystemUserType;
                UnixUser: OntapUnixFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
                WindowsUser: OntapWindowsFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
            };
        };
    }) | undefined;
}
export interface CreateBackupRequest {
    FileSystemId?: string | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
    VolumeId?: string | undefined;
}
export interface CreateBackupResponse {
    Backup?: (Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    }) | undefined;
}
export type Namespace = string;
export type BatchImportMetaDataOnCreate = boolean;
export type EventType = "NEW" | "CHANGED" | "DELETED" | (string & {});
export type EventTypes = EventType[];
export interface AutoImportPolicy {
    Events?: EventType[] | undefined;
}
export interface AutoExportPolicy {
    Events?: EventType[] | undefined;
}
export interface S3DataRepositoryConfiguration {
    AutoImportPolicy?: AutoImportPolicy | undefined;
    AutoExportPolicy?: AutoExportPolicy | undefined;
}
export interface CreateDataRepositoryAssociationRequest {
    FileSystemId?: string | undefined;
    FileSystemPath?: string | undefined;
    DataRepositoryPath?: string | undefined;
    BatchImportMetaDataOnCreate?: boolean | undefined;
    ImportedFileChunkSize?: number | undefined;
    S3?: S3DataRepositoryConfiguration | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DataRepositoryAssociationId = string;
export type FileCacheId = string;
export type SubDirectoriesPaths = string[];
export type NfsVersion = "NFS3" | (string & {});
export type RepositoryDnsIps = string[];
export interface NFSDataRepositoryConfiguration {
    Version?: NfsVersion | undefined;
    DnsIps?: string[] | undefined;
    AutoExportPolicy?: AutoExportPolicy | undefined;
}
export interface DataRepositoryAssociation {
    AssociationId?: string | undefined;
    ResourceARN?: string | undefined;
    FileSystemId?: string | undefined;
    Lifecycle?: DataRepositoryLifecycle | undefined;
    FailureDetails?: DataRepositoryFailureDetails | undefined;
    FileSystemPath?: string | undefined;
    DataRepositoryPath?: string | undefined;
    BatchImportMetaDataOnCreate?: boolean | undefined;
    ImportedFileChunkSize?: number | undefined;
    S3?: S3DataRepositoryConfiguration | undefined;
    Tags?: Tag[] | undefined;
    CreationTime?: Date | undefined;
    FileCacheId?: string | undefined;
    FileCachePath?: string | undefined;
    DataRepositorySubdirectories?: string[] | undefined;
    NFS?: NFSDataRepositoryConfiguration | undefined;
}
export interface CreateDataRepositoryAssociationResponse {
    Association?: (DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    }) | undefined;
}
export type DataRepositoryTaskType = "EXPORT_TO_REPOSITORY" | "IMPORT_METADATA_FROM_REPOSITORY" | "RELEASE_DATA_FROM_FILESYSTEM" | "AUTO_RELEASE_DATA" | (string & {});
export type DataRepositoryTaskPath = string;
export type DataRepositoryTaskPaths = string[];
export type ReportFormat = "REPORT_CSV_20191124" | (string & {});
export type ReportScope = "FAILED_FILES_ONLY" | (string & {});
export interface CompletionReport {
    Enabled?: boolean | undefined;
    Path?: string | undefined;
    Format?: ReportFormat | undefined;
    Scope?: ReportScope | undefined;
}
export type CapacityToRelease = number;
export type Unit = "DAYS" | (string & {});
export type Value = number;
export interface DurationSinceLastAccess {
    Unit?: Unit | undefined;
    Value?: number | undefined;
}
export interface ReleaseConfiguration {
    DurationSinceLastAccess?: DurationSinceLastAccess | undefined;
}
export interface CreateDataRepositoryTaskRequest {
    Type?: DataRepositoryTaskType | undefined;
    Paths?: string[] | undefined;
    FileSystemId?: string | undefined;
    Report?: CompletionReport | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
    CapacityToRelease?: number | undefined;
    ReleaseConfiguration?: ReleaseConfiguration | undefined;
}
export type StartTime = Date;
export type EndTime = Date;
export interface DataRepositoryTaskFailureDetails {
    Message?: string | undefined;
}
export type TotalCount = number;
export type SucceededCount = number;
export type FailedCount = number;
export type LastUpdatedTime = Date;
export type ReleasedCapacity = number;
export interface DataRepositoryTaskStatus {
    TotalCount?: number | undefined;
    SucceededCount?: number | undefined;
    FailedCount?: number | undefined;
    LastUpdatedTime?: Date | undefined;
    ReleasedCapacity?: number | undefined;
}
export interface DataRepositoryTask {
    TaskId?: string | undefined;
    Lifecycle?: DataRepositoryTaskLifecycle | undefined;
    Type?: DataRepositoryTaskType | undefined;
    CreationTime?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
    FileSystemId?: string | undefined;
    Paths?: string[] | undefined;
    FailureDetails?: DataRepositoryTaskFailureDetails | undefined;
    Status?: DataRepositoryTaskStatus | undefined;
    Report?: CompletionReport | undefined;
    CapacityToRelease?: number | undefined;
    FileCacheId?: string | undefined;
    ReleaseConfiguration?: ReleaseConfiguration | undefined;
}
export interface CreateDataRepositoryTaskResponse {
    DataRepositoryTask?: (DataRepositoryTask & {
        TaskId: TaskId;
        Lifecycle: DataRepositoryTaskLifecycle;
        Type: DataRepositoryTaskType;
        CreationTime: CreationTime;
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Report: CompletionReport & {
            Enabled: Flag;
        };
    }) | undefined;
}
export type FileCacheType = "LUSTRE" | (string & {});
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type CopyTagsToDataRepositoryAssociations = boolean;
export type FileCacheLustreDeploymentType = "CACHE_1" | (string & {});
export type MetadataStorageCapacity = number;
export interface FileCacheLustreMetadataConfiguration {
    StorageCapacity?: number | undefined;
}
export interface CreateFileCacheLustreConfiguration {
    PerUnitStorageThroughput?: number | undefined;
    DeploymentType?: FileCacheLustreDeploymentType | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    MetadataConfiguration?: FileCacheLustreMetadataConfiguration | undefined;
}
export interface FileCacheNFSConfiguration {
    Version?: NfsVersion | undefined;
    DnsIps?: string[] | undefined;
}
export interface FileCacheDataRepositoryAssociation {
    FileCachePath?: string | undefined;
    DataRepositoryPath?: string | undefined;
    DataRepositorySubdirectories?: string[] | undefined;
    NFS?: FileCacheNFSConfiguration | undefined;
}
export type CreateFileCacheDataRepositoryAssociations = FileCacheDataRepositoryAssociation[];
export interface CreateFileCacheRequest {
    ClientRequestToken?: string | undefined;
    FileCacheType?: FileCacheType | undefined;
    FileCacheTypeVersion?: string | undefined;
    StorageCapacity?: number | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    CopyTagsToDataRepositoryAssociations?: boolean | undefined;
    KmsKeyId?: string | undefined;
    LustreConfiguration?: CreateFileCacheLustreConfiguration | undefined;
    DataRepositoryAssociations?: FileCacheDataRepositoryAssociation[] | undefined;
}
export type FileCacheLifecycle = "AVAILABLE" | "CREATING" | "DELETING" | "UPDATING" | "FAILED" | (string & {});
export interface FileCacheFailureDetails {
    Message?: string | undefined;
}
export interface FileCacheLustreConfiguration {
    PerUnitStorageThroughput?: number | undefined;
    DeploymentType?: FileCacheLustreDeploymentType | undefined;
    MountName?: string | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    MetadataConfiguration?: FileCacheLustreMetadataConfiguration | undefined;
    LogConfiguration?: LustreLogConfiguration | undefined;
}
export type DataRepositoryAssociationIds = string[];
export interface FileCacheCreating {
    OwnerId?: string | undefined;
    CreationTime?: Date | undefined;
    FileCacheId?: string | undefined;
    FileCacheType?: FileCacheType | undefined;
    FileCacheTypeVersion?: string | undefined;
    Lifecycle?: FileCacheLifecycle | undefined;
    FailureDetails?: FileCacheFailureDetails | undefined;
    StorageCapacity?: number | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    NetworkInterfaceIds?: string[] | undefined;
    DNSName?: string | undefined;
    KmsKeyId?: string | undefined;
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
    CopyTagsToDataRepositoryAssociations?: boolean | undefined;
    LustreConfiguration?: FileCacheLustreConfiguration | undefined;
    DataRepositoryAssociationIds?: string[] | undefined;
}
export interface CreateFileCacheResponse {
    FileCache?: (FileCacheCreating & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    }) | undefined;
}
export type DirectoryPassword = string | redacted.Redacted<string>;
export interface SelfManagedActiveDirectoryConfiguration {
    DomainName?: string | undefined;
    OrganizationalUnitDistinguishedName?: string | undefined;
    FileSystemAdministratorsGroup?: string | undefined;
    UserName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    DnsIps?: string[] | undefined;
    DomainJoinServiceAccountSecret?: string | undefined;
}
export interface WindowsAuditLogCreateConfiguration {
    FileAccessAuditLogLevel?: WindowsAccessAuditLogLevel | undefined;
    FileShareAccessAuditLogLevel?: WindowsAccessAuditLogLevel | undefined;
    AuditLogDestination?: string | undefined;
}
export interface CreateFileSystemWindowsConfiguration {
    ActiveDirectoryId?: string | undefined;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfiguration | undefined;
    DeploymentType?: WindowsDeploymentType | undefined;
    PreferredSubnetId?: string | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    Aliases?: string[] | undefined;
    AuditLogConfiguration?: WindowsAuditLogCreateConfiguration | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    FsrmConfiguration?: WindowsFsrmConfiguration | undefined;
}
export interface LustreLogCreateConfiguration {
    Level?: LustreAccessAuditLogLevel | undefined;
    Destination?: string | undefined;
}
export interface CreateFileSystemLustreMetadataConfiguration {
    Iops?: number | undefined;
    Mode?: MetadataConfigurationMode | undefined;
}
export interface CreateFileSystemLustreConfiguration {
    WeeklyMaintenanceStartTime?: string | undefined;
    ImportPath?: string | undefined;
    ExportPath?: string | undefined;
    ImportedFileChunkSize?: number | undefined;
    DeploymentType?: LustreDeploymentType | undefined;
    AutoImportPolicy?: AutoImportPolicyType | undefined;
    PerUnitStorageThroughput?: number | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    DriveCacheType?: DriveCacheType | undefined;
    DataCompressionType?: DataCompressionType | undefined;
    EfaEnabled?: boolean | undefined;
    LogConfiguration?: LustreLogCreateConfiguration | undefined;
    RootSquashConfiguration?: LustreRootSquashConfiguration | undefined;
    MetadataConfiguration?: CreateFileSystemLustreMetadataConfiguration | undefined;
    ThroughputCapacity?: number | undefined;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration | undefined;
}
export interface CreateFileSystemOntapConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    DeploymentType?: OntapDeploymentType | undefined;
    EndpointIpAddressRange?: string | undefined;
    FsxAdminPassword?: string | redacted.Redacted<string> | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    PreferredSubnetId?: string | undefined;
    RouteTableIds?: string[] | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    HAPairs?: number | undefined;
    ThroughputCapacityPerHAPair?: number | undefined;
    EndpointIpv6AddressRange?: string | undefined;
}
export interface OpenZFSCreateRootVolumeConfiguration {
    RecordSizeKiB?: number | undefined;
    DataCompressionType?: OpenZFSDataCompressionType | undefined;
    NfsExports?: OpenZFSNfsExport[] | undefined;
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[] | undefined;
    CopyTagsToSnapshots?: boolean | undefined;
    ReadOnly?: boolean | undefined;
}
export interface CreateFileSystemOpenZFSConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    CopyTagsToVolumes?: boolean | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    DeploymentType?: OpenZFSDeploymentType | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    RootVolumeConfiguration?: OpenZFSCreateRootVolumeConfiguration | undefined;
    PreferredSubnetId?: string | undefined;
    EndpointIpAddressRange?: string | undefined;
    EndpointIpv6AddressRange?: string | undefined;
    RouteTableIds?: string[] | undefined;
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration | undefined;
}
export interface CreateFileSystemRequest {
    ClientRequestToken?: string | undefined;
    FileSystemType?: FileSystemType | undefined;
    StorageCapacity?: number | undefined;
    StorageType?: StorageType | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    WindowsConfiguration?: CreateFileSystemWindowsConfiguration | undefined;
    LustreConfiguration?: CreateFileSystemLustreConfiguration | undefined;
    OntapConfiguration?: CreateFileSystemOntapConfiguration | undefined;
    FileSystemTypeVersion?: string | undefined;
    OpenZFSConfiguration?: CreateFileSystemOpenZFSConfiguration | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateFileSystemResponse {
    FileSystem?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    }) | undefined;
}
export interface CreateFileSystemFromBackupRequest {
    BackupId?: string | undefined;
    ClientRequestToken?: string | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    WindowsConfiguration?: CreateFileSystemWindowsConfiguration | undefined;
    LustreConfiguration?: CreateFileSystemLustreConfiguration | undefined;
    StorageType?: StorageType | undefined;
    KmsKeyId?: string | undefined;
    FileSystemTypeVersion?: string | undefined;
    OpenZFSConfiguration?: CreateFileSystemOpenZFSConfiguration | undefined;
    StorageCapacity?: number | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface CreateFileSystemFromBackupResponse {
    FileSystem?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    }) | undefined;
}
export interface CreateSnapshotRequest {
    ClientRequestToken?: string | undefined;
    Name?: string | undefined;
    VolumeId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateSnapshotResponse {
    Snapshot?: (Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    }) | undefined;
}
export type NetBiosAlias = string;
export interface CreateSvmActiveDirectoryConfiguration {
    NetBiosName?: string | undefined;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfiguration | undefined;
}
export type StorageVirtualMachineName = string;
export type StorageVirtualMachineRootVolumeSecurityStyle = "UNIX" | "NTFS" | "MIXED" | (string & {});
export interface CreateStorageVirtualMachineRequest {
    ActiveDirectoryConfiguration?: CreateSvmActiveDirectoryConfiguration | undefined;
    ClientRequestToken?: string | undefined;
    FileSystemId?: string | undefined;
    Name?: string | undefined;
    SvmAdminPassword?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
    RootVolumeSecurityStyle?: StorageVirtualMachineRootVolumeSecurityStyle | undefined;
}
export interface SvmActiveDirectoryConfiguration {
    NetBiosName?: string | undefined;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryAttributes | undefined;
}
export interface SvmEndpoint {
    DNSName?: string | undefined;
    IpAddresses?: string[] | undefined;
    Ipv6Addresses?: string[] | undefined;
}
export interface SvmEndpoints {
    Iscsi?: SvmEndpoint | undefined;
    Management?: SvmEndpoint | undefined;
    Nfs?: SvmEndpoint | undefined;
    Smb?: SvmEndpoint | undefined;
}
export type StorageVirtualMachineLifecycle = "CREATED" | "CREATING" | "DELETING" | "FAILED" | "MISCONFIGURED" | "PENDING" | (string & {});
export type StorageVirtualMachineSubtype = "DEFAULT" | "DP_DESTINATION" | "SYNC_DESTINATION" | "SYNC_SOURCE" | (string & {});
export interface StorageVirtualMachine {
    ActiveDirectoryConfiguration?: SvmActiveDirectoryConfiguration | undefined;
    CreationTime?: Date | undefined;
    Endpoints?: SvmEndpoints | undefined;
    FileSystemId?: string | undefined;
    Lifecycle?: StorageVirtualMachineLifecycle | undefined;
    Name?: string | undefined;
    ResourceARN?: string | undefined;
    StorageVirtualMachineId?: string | undefined;
    Subtype?: StorageVirtualMachineSubtype | undefined;
    UUID?: string | undefined;
    Tags?: Tag[] | undefined;
    LifecycleTransitionReason?: LifecycleTransitionReason | undefined;
    RootVolumeSecurityStyle?: StorageVirtualMachineRootVolumeSecurityStyle | undefined;
}
export interface CreateStorageVirtualMachineResponse {
    StorageVirtualMachine?: (StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
}
export type InputOntapVolumeType = "RW" | "DP" | (string & {});
export interface CreateSnaplockConfiguration {
    AuditLogVolume?: boolean | undefined;
    AutocommitPeriod?: AutocommitPeriod | undefined;
    PrivilegedDelete?: PrivilegedDelete | undefined;
    RetentionPeriod?: SnaplockRetentionPeriod | undefined;
    SnaplockType?: SnaplockType | undefined;
    VolumeAppendModeEnabled?: boolean | undefined;
}
export type AggregateListMultiplier = number;
export interface CreateAggregateConfiguration {
    Aggregates?: string[] | undefined;
    ConstituentsPerAggregate?: number | undefined;
}
export interface CreateOntapVolumeConfiguration {
    JunctionPath?: string | undefined;
    SecurityStyle?: SecurityStyle | undefined;
    SizeInMegabytes?: number | undefined;
    StorageEfficiencyEnabled?: boolean | undefined;
    StorageVirtualMachineId?: string | undefined;
    TieringPolicy?: TieringPolicy | undefined;
    OntapVolumeType?: InputOntapVolumeType | undefined;
    SnapshotPolicy?: string | undefined;
    CopyTagsToBackups?: boolean | undefined;
    SnaplockConfiguration?: CreateSnaplockConfiguration | undefined;
    VolumeStyle?: VolumeStyle | undefined;
    AggregateConfiguration?: CreateAggregateConfiguration | undefined;
    SizeInBytes?: number | undefined;
}
export type IntegerNoMaxFromNegativeOne = number;
export interface CreateOpenZFSOriginSnapshotConfiguration {
    SnapshotARN?: string | undefined;
    CopyStrategy?: OpenZFSCopyStrategy | undefined;
}
export interface CreateOpenZFSVolumeConfiguration {
    ParentVolumeId?: string | undefined;
    StorageCapacityReservationGiB?: number | undefined;
    StorageCapacityQuotaGiB?: number | undefined;
    RecordSizeKiB?: number | undefined;
    DataCompressionType?: OpenZFSDataCompressionType | undefined;
    CopyTagsToSnapshots?: boolean | undefined;
    OriginSnapshot?: CreateOpenZFSOriginSnapshotConfiguration | undefined;
    ReadOnly?: boolean | undefined;
    NfsExports?: OpenZFSNfsExport[] | undefined;
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[] | undefined;
}
export interface CreateVolumeRequest {
    ClientRequestToken?: string | undefined;
    VolumeType?: VolumeType | undefined;
    Name?: string | undefined;
    OntapConfiguration?: CreateOntapVolumeConfiguration | undefined;
    Tags?: Tag[] | undefined;
    OpenZFSConfiguration?: CreateOpenZFSVolumeConfiguration | undefined;
}
export interface CreateVolumeResponse {
    Volume?: (Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    }) | undefined;
}
export interface CreateVolumeFromBackupRequest {
    BackupId?: string | undefined;
    ClientRequestToken?: string | undefined;
    Name?: string | undefined;
    OntapConfiguration?: CreateOntapVolumeConfiguration | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateVolumeFromBackupResponse {
    Volume?: (Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    }) | undefined;
}
export interface DeleteBackupRequest {
    BackupId?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface DeleteBackupResponse {
    BackupId?: string | undefined;
    Lifecycle?: BackupLifecycle | undefined;
}
export type DeleteDataInFileSystem = boolean;
export interface DeleteDataRepositoryAssociationRequest {
    AssociationId?: string | undefined;
    ClientRequestToken?: string | undefined;
    DeleteDataInFileSystem?: boolean | undefined;
}
export interface DeleteDataRepositoryAssociationResponse {
    AssociationId?: string | undefined;
    Lifecycle?: DataRepositoryLifecycle | undefined;
    DeleteDataInFileSystem?: boolean | undefined;
}
export interface DeleteFileCacheRequest {
    FileCacheId?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface DeleteFileCacheResponse {
    FileCacheId?: string | undefined;
    Lifecycle?: FileCacheLifecycle | undefined;
}
export interface DeleteFileSystemWindowsConfiguration {
    SkipFinalBackup?: boolean | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export interface DeleteFileSystemLustreConfiguration {
    SkipFinalBackup?: boolean | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export type DeleteFileSystemOpenZFSOption = "DELETE_CHILD_VOLUMES_AND_SNAPSHOTS" | (string & {});
export type DeleteFileSystemOpenZFSOptions = DeleteFileSystemOpenZFSOption[];
export interface DeleteFileSystemOpenZFSConfiguration {
    SkipFinalBackup?: boolean | undefined;
    FinalBackupTags?: Tag[] | undefined;
    Options?: DeleteFileSystemOpenZFSOption[] | undefined;
}
export interface DeleteFileSystemRequest {
    FileSystemId?: string | undefined;
    ClientRequestToken?: string | undefined;
    WindowsConfiguration?: DeleteFileSystemWindowsConfiguration | undefined;
    LustreConfiguration?: DeleteFileSystemLustreConfiguration | undefined;
    OpenZFSConfiguration?: DeleteFileSystemOpenZFSConfiguration | undefined;
}
export interface DeleteFileSystemWindowsResponse {
    FinalBackupId?: string | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export interface DeleteFileSystemLustreResponse {
    FinalBackupId?: string | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export interface DeleteFileSystemOpenZFSResponse {
    FinalBackupId?: string | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export interface DeleteFileSystemResponse {
    FileSystemId?: string | undefined;
    Lifecycle?: FileSystemLifecycle | undefined;
    WindowsResponse?: (DeleteFileSystemWindowsResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
    LustreResponse?: (DeleteFileSystemLustreResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
    OpenZFSResponse?: (DeleteFileSystemOpenZFSResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
}
export interface DeleteSnapshotRequest {
    ClientRequestToken?: string | undefined;
    SnapshotId?: string | undefined;
}
export interface DeleteSnapshotResponse {
    SnapshotId?: string | undefined;
    Lifecycle?: SnapshotLifecycle | undefined;
}
export interface DeleteStorageVirtualMachineRequest {
    ClientRequestToken?: string | undefined;
    StorageVirtualMachineId?: string | undefined;
}
export interface DeleteStorageVirtualMachineResponse {
    StorageVirtualMachineId?: string | undefined;
    Lifecycle?: StorageVirtualMachineLifecycle | undefined;
}
export interface DeleteVolumeOntapConfiguration {
    SkipFinalBackup?: boolean | undefined;
    FinalBackupTags?: Tag[] | undefined;
    BypassSnaplockEnterpriseRetention?: boolean | undefined;
}
export type DeleteOpenZFSVolumeOption = "DELETE_CHILD_VOLUMES_AND_SNAPSHOTS" | (string & {});
export type DeleteOpenZFSVolumeOptions = DeleteOpenZFSVolumeOption[];
export interface DeleteVolumeOpenZFSConfiguration {
    Options?: DeleteOpenZFSVolumeOption[] | undefined;
}
export interface DeleteVolumeRequest {
    ClientRequestToken?: string | undefined;
    VolumeId?: string | undefined;
    OntapConfiguration?: DeleteVolumeOntapConfiguration | undefined;
    OpenZFSConfiguration?: DeleteVolumeOpenZFSConfiguration | undefined;
}
export interface DeleteVolumeOntapResponse {
    FinalBackupId?: string | undefined;
    FinalBackupTags?: Tag[] | undefined;
}
export interface DeleteVolumeResponse {
    VolumeId?: string | undefined;
    Lifecycle?: VolumeLifecycle | undefined;
    OntapResponse?: (DeleteVolumeOntapResponse & {
        FinalBackupTags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
}
export type BackupIds = string[];
export type FilterName = "file-system-id" | "backup-type" | "file-system-type" | "volume-id" | "data-repository-type" | "file-cache-id" | "file-cache-type" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    Name?: FilterName | undefined;
    Values?: string[] | undefined;
}
export type Filters = Filter[];
export type MaxResults = number;
export type NextToken = string;
export interface DescribeBackupsRequest {
    BackupIds?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type Backups = Backup[];
export interface DescribeBackupsResponse {
    Backups?: (Backup & {
        BackupId: BackupId;
        Lifecycle: BackupLifecycle;
        Type: BackupType;
        CreationTime: CreationTime;
        FileSystem: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
            AdministrativeActions: (AdministrativeAction & {
                TargetVolumeValues: Volume & {
                    OntapConfiguration: OntapVolumeConfiguration & {
                        SnaplockConfiguration: SnaplockConfiguration & {
                            AutocommitPeriod: AutocommitPeriod & {
                                Type: AutocommitPeriodType;
                            };
                            RetentionPeriod: SnaplockRetentionPeriod & {
                                DefaultRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MinimumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                                MaximumRetention: RetentionPeriod & {
                                    Type: RetentionPeriodType;
                                };
                            };
                        };
                    };
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                        NfsExports: (OpenZFSNfsExport & {
                            ClientConfigurations: (OpenZFSClientConfiguration & {
                                Clients: OpenZFSClients;
                                Options: OpenZFSNfsExportOptions;
                            })[];
                        })[];
                        UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                            Type: OpenZFSQuotaType;
                            Id: IntegerNoMax;
                            StorageCapacityQuotaGiB: IntegerNoMax;
                        })[];
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Volume: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            AdministrativeActions: (AdministrativeAction & {
                TargetFileSystemValues: FileSystem & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                    WindowsConfiguration: WindowsFileSystemConfiguration & {
                        AuditLogConfiguration: WindowsAuditLogConfiguration & {
                            FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                            FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        };
                        FsrmConfiguration: WindowsFsrmConfiguration & {
                            FsrmServiceEnabled: Flag;
                        };
                    };
                    LustreConfiguration: LustreFileSystemConfiguration & {
                        LogConfiguration: LustreLogConfiguration & {
                            Level: LustreAccessAuditLogLevel;
                        };
                        MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                            Mode: MetadataConfigurationMode;
                        };
                    };
                };
                TargetSnapshotValues: Snapshot & {
                    Tags: (Tag & {
                        Key: TagKey;
                        Value: TagValue;
                    })[];
                };
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type LimitedMaxResults = number;
export interface DescribeDataRepositoryAssociationsRequest {
    AssociationIds?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DataRepositoryAssociations = DataRepositoryAssociation[];
export interface DescribeDataRepositoryAssociationsResponse {
    Associations?: (DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type TaskIds = string[];
export type DataRepositoryTaskFilterName = "file-system-id" | "task-lifecycle" | "data-repository-association-id" | "file-cache-id" | (string & {});
export type DataRepositoryTaskFilterValue = string;
export type DataRepositoryTaskFilterValues = string[];
export interface DataRepositoryTaskFilter {
    Name?: DataRepositoryTaskFilterName | undefined;
    Values?: string[] | undefined;
}
export type DataRepositoryTaskFilters = DataRepositoryTaskFilter[];
export interface DescribeDataRepositoryTasksRequest {
    TaskIds?: string[] | undefined;
    Filters?: DataRepositoryTaskFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DataRepositoryTasks = DataRepositoryTask[];
export interface DescribeDataRepositoryTasksResponse {
    DataRepositoryTasks?: (DataRepositoryTask & {
        TaskId: TaskId;
        Lifecycle: DataRepositoryTaskLifecycle;
        Type: DataRepositoryTaskType;
        CreationTime: CreationTime;
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        Report: CompletionReport & {
            Enabled: Flag;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type FileCacheIds = string[];
export interface DescribeFileCachesRequest {
    FileCacheIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FileCache {
    OwnerId?: string | undefined;
    CreationTime?: Date | undefined;
    FileCacheId?: string | undefined;
    FileCacheType?: FileCacheType | undefined;
    FileCacheTypeVersion?: string | undefined;
    Lifecycle?: FileCacheLifecycle | undefined;
    FailureDetails?: FileCacheFailureDetails | undefined;
    StorageCapacity?: number | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    NetworkInterfaceIds?: string[] | undefined;
    DNSName?: string | undefined;
    KmsKeyId?: string | undefined;
    ResourceARN?: string | undefined;
    LustreConfiguration?: FileCacheLustreConfiguration | undefined;
    DataRepositoryAssociationIds?: string[] | undefined;
}
export type FileCaches = FileCache[];
export interface DescribeFileCachesResponse {
    FileCaches?: (FileCache & {
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFileSystemAliasesRequest {
    ClientRequestToken?: string | undefined;
    FileSystemId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFileSystemAliasesResponse {
    Aliases?: Alias[] | undefined;
    NextToken?: string | undefined;
}
export type FileSystemIds = string[];
export interface DescribeFileSystemsRequest {
    FileSystemIds?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type FileSystems = FileSystem[];
export interface DescribeFileSystemsResponse {
    FileSystems?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type S3AccessPointAttachmentNames = string[];
export type S3AccessPointAttachmentsFilterName = "file-system-id" | "volume-id" | "type" | (string & {});
export type S3AccessPointAttachmentsFilterValue = string;
export type S3AccessPointAttachmentsFilterValues = string[];
export interface S3AccessPointAttachmentsFilter {
    Name?: S3AccessPointAttachmentsFilterName | undefined;
    Values?: string[] | undefined;
}
export type S3AccessPointAttachmentsFilters = S3AccessPointAttachmentsFilter[];
export interface DescribeS3AccessPointAttachmentsRequest {
    Names?: string[] | undefined;
    Filters?: S3AccessPointAttachmentsFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type S3AccessPointAttachments = S3AccessPointAttachment[];
export interface DescribeS3AccessPointAttachmentsResponse {
    S3AccessPointAttachments?: (S3AccessPointAttachment & {
        OpenZFSConfiguration: S3AccessPointOpenZFSConfiguration & {
            FileSystemIdentity: OpenZFSFileSystemIdentity & {
                Type: OpenZFSFileSystemUserType;
                PosixUser: OpenZFSPosixFileSystemUser & {
                    Uid: FileSystemUID;
                    Gid: FileSystemGID;
                };
            };
        };
        OntapConfiguration: S3AccessPointOntapConfiguration & {
            FileSystemIdentity: OntapFileSystemIdentity & {
                Type: OntapFileSystemUserType;
                UnixUser: OntapUnixFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
                WindowsUser: OntapWindowsFileSystemUser & {
                    Name: OntapFileSystemUserName;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeSharedVpcConfigurationRequest {
}
export type VerboseFlag = string;
export interface DescribeSharedVpcConfigurationResponse {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string | undefined;
}
export type SnapshotIds = string[];
export type SnapshotFilterName = "file-system-id" | "volume-id" | (string & {});
export type SnapshotFilterValue = string;
export type SnapshotFilterValues = string[];
export interface SnapshotFilter {
    Name?: SnapshotFilterName | undefined;
    Values?: string[] | undefined;
}
export type SnapshotFilters = SnapshotFilter[];
export type IncludeShared = boolean;
export interface DescribeSnapshotsRequest {
    SnapshotIds?: string[] | undefined;
    Filters?: SnapshotFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    IncludeShared?: boolean | undefined;
}
export type Snapshots = Snapshot[];
export interface DescribeSnapshotsResponse {
    Snapshots?: (Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type StorageVirtualMachineIds = string[];
export type StorageVirtualMachineFilterName = "file-system-id" | (string & {});
export type StorageVirtualMachineFilterValue = string;
export type StorageVirtualMachineFilterValues = string[];
export interface StorageVirtualMachineFilter {
    Name?: StorageVirtualMachineFilterName | undefined;
    Values?: string[] | undefined;
}
export type StorageVirtualMachineFilters = StorageVirtualMachineFilter[];
export interface DescribeStorageVirtualMachinesRequest {
    StorageVirtualMachineIds?: string[] | undefined;
    Filters?: StorageVirtualMachineFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type StorageVirtualMachines = StorageVirtualMachine[];
export interface DescribeStorageVirtualMachinesResponse {
    StorageVirtualMachines?: (StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type VolumeIds = string[];
export type VolumeFilterName = "file-system-id" | "storage-virtual-machine-id" | (string & {});
export type VolumeFilterValue = string;
export type VolumeFilterValues = string[];
export interface VolumeFilter {
    Name?: VolumeFilterName | undefined;
    Values?: string[] | undefined;
}
export type VolumeFilters = VolumeFilter[];
export interface DescribeVolumesRequest {
    VolumeIds?: string[] | undefined;
    Filters?: VolumeFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type Volumes = Volume[];
export interface DescribeVolumesResponse {
    Volumes?: (Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DetachAndDeleteS3AccessPointRequest {
    ClientRequestToken?: string | undefined;
    Name?: string | undefined;
}
export interface DetachAndDeleteS3AccessPointResponse {
    Lifecycle?: S3AccessPointAttachmentLifecycle | undefined;
    Name?: string | undefined;
}
export interface DisassociateFileSystemAliasesRequest {
    ClientRequestToken?: string | undefined;
    FileSystemId?: string | undefined;
    Aliases?: string[] | undefined;
}
export interface DisassociateFileSystemAliasesResponse {
    Aliases?: Alias[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ReleaseFileSystemNfsV3LocksRequest {
    FileSystemId?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface ReleaseFileSystemNfsV3LocksResponse {
    FileSystem?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    }) | undefined;
}
export type RestoreOpenZFSVolumeOption = "DELETE_INTERMEDIATE_SNAPSHOTS" | "DELETE_CLONED_VOLUMES" | (string & {});
export type RestoreOpenZFSVolumeOptions = RestoreOpenZFSVolumeOption[];
export interface RestoreVolumeFromSnapshotRequest {
    ClientRequestToken?: string | undefined;
    VolumeId?: string | undefined;
    SnapshotId?: string | undefined;
    Options?: RestoreOpenZFSVolumeOption[] | undefined;
}
export interface RestoreVolumeFromSnapshotResponse {
    VolumeId?: string | undefined;
    Lifecycle?: VolumeLifecycle | undefined;
    AdministrativeActions?: (AdministrativeAction & {
        TargetFileSystemValues: FileSystem & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            WindowsConfiguration: WindowsFileSystemConfiguration & {
                AuditLogConfiguration: WindowsAuditLogConfiguration & {
                    FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                };
                FsrmConfiguration: WindowsFsrmConfiguration & {
                    FsrmServiceEnabled: Flag;
                };
            };
            LustreConfiguration: LustreFileSystemConfiguration & {
                LogConfiguration: LustreLogConfiguration & {
                    Level: LustreAccessAuditLogLevel;
                };
                MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                    Mode: MetadataConfigurationMode;
                };
            };
        };
        TargetVolumeValues: Volume & {
            OntapConfiguration: OntapVolumeConfiguration & {
                SnaplockConfiguration: SnaplockConfiguration & {
                    AutocommitPeriod: AutocommitPeriod & {
                        Type: AutocommitPeriodType;
                    };
                    RetentionPeriod: SnaplockRetentionPeriod & {
                        DefaultRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MinimumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                        MaximumRetention: RetentionPeriod & {
                            Type: RetentionPeriodType;
                        };
                    };
                };
            };
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
            OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                NfsExports: (OpenZFSNfsExport & {
                    ClientConfigurations: (OpenZFSClientConfiguration & {
                        Clients: OpenZFSClients;
                        Options: OpenZFSNfsExportOptions;
                    })[];
                })[];
                UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                    Type: OpenZFSQuotaType;
                    Id: IntegerNoMax;
                    StorageCapacityQuotaGiB: IntegerNoMax;
                })[];
            };
        };
        TargetSnapshotValues: Snapshot & {
            Tags: (Tag & {
                Key: TagKey;
                Value: TagValue;
            })[];
        };
    })[] | undefined;
}
export interface StartMisconfiguredStateRecoveryRequest {
    ClientRequestToken?: string | undefined;
    FileSystemId?: string | undefined;
}
export interface StartMisconfiguredStateRecoveryResponse {
    FileSystem?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    }) | undefined;
}
export interface TagResourceRequest {
    ResourceARN?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceARN?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateDataRepositoryAssociationRequest {
    AssociationId?: string | undefined;
    ClientRequestToken?: string | undefined;
    ImportedFileChunkSize?: number | undefined;
    S3?: S3DataRepositoryConfiguration | undefined;
}
export interface UpdateDataRepositoryAssociationResponse {
    Association?: (DataRepositoryAssociation & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        NFS: NFSDataRepositoryConfiguration & {
            Version: NfsVersion;
        };
    }) | undefined;
}
export interface UpdateFileCacheLustreConfiguration {
    WeeklyMaintenanceStartTime?: string | undefined;
}
export interface UpdateFileCacheRequest {
    FileCacheId?: string | undefined;
    ClientRequestToken?: string | undefined;
    LustreConfiguration?: UpdateFileCacheLustreConfiguration | undefined;
}
export interface UpdateFileCacheResponse {
    FileCache?: (FileCache & {
        LustreConfiguration: FileCacheLustreConfiguration & {
            MetadataConfiguration: FileCacheLustreMetadataConfiguration & {
                StorageCapacity: MetadataStorageCapacity;
            };
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
        };
    }) | undefined;
}
export interface SelfManagedActiveDirectoryConfigurationUpdates {
    UserName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    DnsIps?: string[] | undefined;
    DomainName?: string | undefined;
    OrganizationalUnitDistinguishedName?: string | undefined;
    FileSystemAdministratorsGroup?: string | undefined;
    DomainJoinServiceAccountSecret?: string | undefined;
}
export interface UpdateFileSystemWindowsConfiguration {
    WeeklyMaintenanceStartTime?: string | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    ThroughputCapacity?: number | undefined;
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfigurationUpdates | undefined;
    AuditLogConfiguration?: WindowsAuditLogCreateConfiguration | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    FsrmConfiguration?: WindowsFsrmConfiguration | undefined;
}
export interface UpdateFileSystemLustreMetadataConfiguration {
    Iops?: number | undefined;
    Mode?: MetadataConfigurationMode | undefined;
}
export interface UpdateFileSystemLustreConfiguration {
    WeeklyMaintenanceStartTime?: string | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    AutomaticBackupRetentionDays?: number | undefined;
    AutoImportPolicy?: AutoImportPolicyType | undefined;
    DataCompressionType?: DataCompressionType | undefined;
    LogConfiguration?: LustreLogCreateConfiguration | undefined;
    RootSquashConfiguration?: LustreRootSquashConfiguration | undefined;
    PerUnitStorageThroughput?: number | undefined;
    MetadataConfiguration?: UpdateFileSystemLustreMetadataConfiguration | undefined;
    ThroughputCapacity?: number | undefined;
    DataReadCacheConfiguration?: LustreReadCacheConfiguration | undefined;
}
export interface UpdateFileSystemOntapConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    FsxAdminPassword?: string | redacted.Redacted<string> | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    ThroughputCapacity?: number | undefined;
    AddRouteTableIds?: string[] | undefined;
    RemoveRouteTableIds?: string[] | undefined;
    ThroughputCapacityPerHAPair?: number | undefined;
    HAPairs?: number | undefined;
    EndpointIpv6AddressRange?: string | undefined;
}
export interface UpdateFileSystemOpenZFSConfiguration {
    AutomaticBackupRetentionDays?: number | undefined;
    CopyTagsToBackups?: boolean | undefined;
    CopyTagsToVolumes?: boolean | undefined;
    DailyAutomaticBackupStartTime?: string | undefined;
    ThroughputCapacity?: number | undefined;
    WeeklyMaintenanceStartTime?: string | undefined;
    DiskIopsConfiguration?: DiskIopsConfiguration | undefined;
    AddRouteTableIds?: string[] | undefined;
    RemoveRouteTableIds?: string[] | undefined;
    ReadCacheConfiguration?: OpenZFSReadCacheConfiguration | undefined;
    EndpointIpv6AddressRange?: string | undefined;
}
export interface UpdateFileSystemRequest {
    FileSystemId?: string | undefined;
    ClientRequestToken?: string | undefined;
    StorageCapacity?: number | undefined;
    WindowsConfiguration?: UpdateFileSystemWindowsConfiguration | undefined;
    LustreConfiguration?: UpdateFileSystemLustreConfiguration | undefined;
    OntapConfiguration?: UpdateFileSystemOntapConfiguration | undefined;
    OpenZFSConfiguration?: UpdateFileSystemOpenZFSConfiguration | undefined;
    StorageType?: StorageType | undefined;
    FileSystemTypeVersion?: string | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface UpdateFileSystemResponse {
    FileSystem?: (FileSystem & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        WindowsConfiguration: WindowsFileSystemConfiguration & {
            AuditLogConfiguration: WindowsAuditLogConfiguration & {
                FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
            };
            FsrmConfiguration: WindowsFsrmConfiguration & {
                FsrmServiceEnabled: Flag;
            };
        };
        LustreConfiguration: LustreFileSystemConfiguration & {
            LogConfiguration: LustreLogConfiguration & {
                Level: LustreAccessAuditLogLevel;
            };
            MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                Mode: MetadataConfigurationMode;
            };
        };
        AdministrativeActions: (AdministrativeAction & {
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
    }) | undefined;
}
export interface UpdateSharedVpcConfigurationRequest {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface UpdateSharedVpcConfigurationResponse {
    EnableFsxRouteTableUpdatesFromParticipantAccounts?: string | undefined;
}
export interface UpdateSnapshotRequest {
    ClientRequestToken?: string | undefined;
    Name?: string | undefined;
    SnapshotId?: string | undefined;
}
export interface UpdateSnapshotResponse {
    Snapshot?: (Snapshot & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetVolumeValues: Volume & {
                OntapConfiguration: OntapVolumeConfiguration & {
                    SnaplockConfiguration: SnaplockConfiguration & {
                        AutocommitPeriod: AutocommitPeriod & {
                            Type: AutocommitPeriodType;
                        };
                        RetentionPeriod: SnaplockRetentionPeriod & {
                            DefaultRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MinimumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                            MaximumRetention: RetentionPeriod & {
                                Type: RetentionPeriodType;
                            };
                        };
                    };
                };
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
                    NfsExports: (OpenZFSNfsExport & {
                        ClientConfigurations: (OpenZFSClientConfiguration & {
                            Clients: OpenZFSClients;
                            Options: OpenZFSNfsExportOptions;
                        })[];
                    })[];
                    UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                        Type: OpenZFSQuotaType;
                        Id: IntegerNoMax;
                        StorageCapacityQuotaGiB: IntegerNoMax;
                    })[];
                };
            };
        })[];
    }) | undefined;
}
export interface UpdateSvmActiveDirectoryConfiguration {
    SelfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfigurationUpdates | undefined;
    NetBiosName?: string | undefined;
}
export interface UpdateStorageVirtualMachineRequest {
    ActiveDirectoryConfiguration?: UpdateSvmActiveDirectoryConfiguration | undefined;
    ClientRequestToken?: string | undefined;
    StorageVirtualMachineId?: string | undefined;
    SvmAdminPassword?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateStorageVirtualMachineResponse {
    StorageVirtualMachine?: (StorageVirtualMachine & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
}
export interface UpdateSnaplockConfiguration {
    AuditLogVolume?: boolean | undefined;
    AutocommitPeriod?: AutocommitPeriod | undefined;
    PrivilegedDelete?: PrivilegedDelete | undefined;
    RetentionPeriod?: SnaplockRetentionPeriod | undefined;
    VolumeAppendModeEnabled?: boolean | undefined;
}
export interface UpdateOntapVolumeConfiguration {
    JunctionPath?: string | undefined;
    SecurityStyle?: SecurityStyle | undefined;
    SizeInMegabytes?: number | undefined;
    StorageEfficiencyEnabled?: boolean | undefined;
    TieringPolicy?: TieringPolicy | undefined;
    SnapshotPolicy?: string | undefined;
    CopyTagsToBackups?: boolean | undefined;
    SnaplockConfiguration?: UpdateSnaplockConfiguration | undefined;
    SizeInBytes?: number | undefined;
}
export interface UpdateOpenZFSVolumeConfiguration {
    StorageCapacityReservationGiB?: number | undefined;
    StorageCapacityQuotaGiB?: number | undefined;
    RecordSizeKiB?: number | undefined;
    DataCompressionType?: OpenZFSDataCompressionType | undefined;
    NfsExports?: OpenZFSNfsExport[] | undefined;
    UserAndGroupQuotas?: OpenZFSUserOrGroupQuota[] | undefined;
    ReadOnly?: boolean | undefined;
}
export interface UpdateVolumeRequest {
    ClientRequestToken?: string | undefined;
    VolumeId?: string | undefined;
    OntapConfiguration?: UpdateOntapVolumeConfiguration | undefined;
    Name?: string | undefined;
    OpenZFSConfiguration?: UpdateOpenZFSVolumeConfiguration | undefined;
}
export interface UpdateVolumeResponse {
    Volume?: (Volume & {
        OntapConfiguration: OntapVolumeConfiguration & {
            SnaplockConfiguration: SnaplockConfiguration & {
                AutocommitPeriod: AutocommitPeriod & {
                    Type: AutocommitPeriodType;
                };
                RetentionPeriod: SnaplockRetentionPeriod & {
                    DefaultRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MinimumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                    MaximumRetention: RetentionPeriod & {
                        Type: RetentionPeriodType;
                    };
                };
            };
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        AdministrativeActions: (AdministrativeAction & {
            TargetFileSystemValues: FileSystem & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
                WindowsConfiguration: WindowsFileSystemConfiguration & {
                    AuditLogConfiguration: WindowsAuditLogConfiguration & {
                        FileAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                        FileShareAccessAuditLogLevel: WindowsAccessAuditLogLevel;
                    };
                    FsrmConfiguration: WindowsFsrmConfiguration & {
                        FsrmServiceEnabled: Flag;
                    };
                };
                LustreConfiguration: LustreFileSystemConfiguration & {
                    LogConfiguration: LustreLogConfiguration & {
                        Level: LustreAccessAuditLogLevel;
                    };
                    MetadataConfiguration: FileSystemLustreMetadataConfiguration & {
                        Mode: MetadataConfigurationMode;
                    };
                };
            };
            TargetSnapshotValues: Snapshot & {
                Tags: (Tag & {
                    Key: TagKey;
                    Value: TagValue;
                })[];
            };
        })[];
        OpenZFSConfiguration: OpenZFSVolumeConfiguration & {
            NfsExports: (OpenZFSNfsExport & {
                ClientConfigurations: (OpenZFSClientConfiguration & {
                    Clients: OpenZFSClients;
                    Options: OpenZFSNfsExportOptions;
                })[];
            })[];
            UserAndGroupQuotas: (OpenZFSUserOrGroupQuota & {
                Type: OpenZFSQuotaType;
                Id: IntegerNoMax;
                StorageCapacityQuotaGiB: IntegerNoMax;
            })[];
        };
    }) | undefined;
}
export type Parameter = string;
export type ServiceLimit = "FILE_SYSTEM_COUNT" | "TOTAL_THROUGHPUT_CAPACITY" | "TOTAL_STORAGE" | "TOTAL_USER_INITIATED_BACKUPS" | "TOTAL_USER_TAGS" | "TOTAL_IN_PROGRESS_COPY_BACKUPS" | "STORAGE_VIRTUAL_MACHINES_PER_FILE_SYSTEM" | "VOLUMES_PER_FILE_SYSTEM" | "TOTAL_SSD_IOPS" | "FILE_CACHE_COUNT" | (string & {});
export type ErrorCode = string;
export type ActiveDirectoryErrorType = "DOMAIN_NOT_FOUND" | "INCOMPATIBLE_DOMAIN_MODE" | "WRONG_VPC" | "INVALID_NETWORK_TYPE" | "INVALID_DOMAIN_STAGE" | (string & {});
export type AssociateFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Use this action to associate one or more Domain Name Server (DNS) aliases with an existing Amazon FSx for Windows File Server file system.
 * A file system can have a maximum of 50 DNS aliases associated with it at any one time. If you try to
 * associate a DNS alias that is already associated with the file system, FSx takes no action on that alias in the request.
 * For more information, see Working with DNS Aliases and
 * Walkthrough 5: Using DNS aliases to access your file system, including
 * additional steps you must take to be able to access your file system using a DNS alias.
 *
 * The system response shows the DNS aliases that
 * Amazon FSx is attempting to associate with the file system.
 * Use the API
 * operation to monitor the status of the aliases Amazon FSx is
 * associating with the file system.
 */
export declare const associateFileSystemAliases: API.OperationMethod<AssociateFileSystemAliasesRequest & RegionInput, AssociateFileSystemAliasesResponse, AssociateFileSystemAliasesError, Credentials | HttpClient.HttpClient>;
export type CancelDataRepositoryTaskError = BadRequest | DataRepositoryTaskEnded | DataRepositoryTaskNotFound | InternalServerError | UnsupportedOperation | CommonErrors;
/**
 * Cancels an existing Amazon FSx for Lustre data repository task if that task is in either the
 * `PENDING` or `EXECUTING` state. When you cancel an export task, Amazon FSx
 * does the following.
 *
 * - Any files that FSx has already exported are not reverted.
 *
 * - FSx continues to export any files that are in-flight when the cancel operation is received.
 *
 * - FSx does not export any files that have not yet been exported.
 *
 * For a release task, Amazon FSx will stop releasing files upon cancellation. Any files that
 * have already been released will remain in the released state.
 */
export declare const cancelDataRepositoryTask: API.OperationMethod<CancelDataRepositoryTaskRequest & RegionInput, CancelDataRepositoryTaskResponse, CancelDataRepositoryTaskError, Credentials | HttpClient.HttpClient>;
export type CopyBackupError = BackupNotFound | BadRequest | IncompatibleParameterError | IncompatibleRegionForMultiAZ | InternalServerError | InvalidDestinationKmsKey | InvalidRegion | InvalidSourceKmsKey | ServiceLimitExceeded | SourceBackupUnavailable | UnsupportedOperation | CommonErrors;
/**
 * Copies an existing backup within the same Amazon Web Services account to another Amazon Web Services Region
 * (cross-Region copy) or within the same Amazon Web Services Region (in-Region copy). You can have up to five
 * backup copy requests in progress to a single destination Region per account.
 *
 * You can use cross-Region backup copies for cross-Region disaster recovery. You can
 * periodically take backups and copy them to another Region so that in the event of a
 * disaster in the primary Region, you can restore from backup and recover availability
 * quickly in the other Region. You can make cross-Region copies only within your Amazon Web Services partition. A partition is a grouping of Regions. Amazon Web Services currently
 * has three partitions: `aws` (Standard Regions), `aws-cn` (China
 * Regions), and `aws-us-gov` (Amazon Web Services GovCloud [US] Regions).
 *
 * You can also use backup copies to clone your file dataset to another Region or within
 * the same Region.
 *
 * You can use the `SourceRegion` parameter to specify the Amazon Web Services Region
 * from which the backup will be copied. For example, if you make the call from the
 * `us-west-1` Region and want to copy a backup from the `us-east-2`
 * Region, you specify `us-east-2` in the `SourceRegion` parameter
 * to make a cross-Region copy. If you don't specify a Region, the backup copy is
 * created in the same Region where the request is sent from (in-Region copy).
 *
 * For more information about creating backup copies, see Copying backups
 * in the *Amazon FSx for Windows User Guide*, Copying backups in the Amazon FSx for Lustre User
 * Guide, and Copying backups in the Amazon FSx for OpenZFS User
 * Guide.
 */
export declare const copyBackup: API.OperationMethod<CopyBackupRequest & RegionInput, CopyBackupResponse, CopyBackupError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotAndUpdateVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | SourceSnapshotNotFound | CommonErrors;
/**
 * Updates an existing volume by using a snapshot from another Amazon FSx for OpenZFS file system. For more information, see on-demand data replication in the Amazon FSx for OpenZFS User
 * Guide.
 */
export declare const copySnapshotAndUpdateVolume: API.OperationMethod<CopySnapshotAndUpdateVolumeRequest & RegionInput, CopySnapshotAndUpdateVolumeResponse, CopySnapshotAndUpdateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateAndAttachS3AccessPointError = AccessPointAlreadyOwnedByYou | BadRequest | IncompatibleParameterError | InternalServerError | InvalidAccessPoint | InvalidRequest | TooManyAccessPoints | UnsupportedOperation | VolumeNotFound | CommonErrors;
/**
 * Creates an S3 access point and attaches it to an Amazon FSx volume. For FSx for OpenZFS file systems, the
 * volume must be hosted on a high-availability file system, either Single-AZ or Multi-AZ. For more information,
 * see Accessing your data using Amazon S3 access points.
 * in the Amazon FSx for OpenZFS User Guide.
 *
 * The requester requires the following permissions to perform these actions:
 *
 * - `fsx:CreateAndAttachS3AccessPoint`
 *
 * - `s3:CreateAccessPoint`
 *
 * - `s3:GetAccessPoint`
 *
 * - `s3:PutAccessPointPolicy`
 *
 * - `s3:DeleteAccessPoint`
 *
 * The following actions are related to `CreateAndAttachS3AccessPoint`:
 *
 * - DescribeS3AccessPointAttachments
 *
 * - DetachAndDeleteS3AccessPoint
 */
export declare const createAndAttachS3AccessPoint: API.OperationMethod<CreateAndAttachS3AccessPointRequest & RegionInput, CreateAndAttachS3AccessPointResponse, CreateAndAttachS3AccessPointError, Credentials | HttpClient.HttpClient>;
export type CreateBackupError = BackupInProgress | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | VolumeNotFound | CommonErrors;
/**
 * Creates a backup of an existing Amazon FSx for Windows File Server file
 * system, Amazon FSx for Lustre file system, Amazon FSx for NetApp ONTAP
 * volume, or Amazon FSx for OpenZFS file system. We recommend creating regular
 * backups so that you can restore a file system or volume from a backup if an issue arises
 * with the original file system or volume.
 *
 * For Amazon FSx for Lustre file systems, you can create a backup only for file
 * systems that have the following configuration:
 *
 * - A Persistent deployment type
 *
 * - Are *not* linked to a data repository
 *
 * For more information about backups, see the following:
 *
 * - For Amazon FSx for Lustre, see Working with FSx for
 * Lustre backups.
 *
 * - For Amazon FSx for Windows, see Working with FSx for
 * Windows backups.
 *
 * - For Amazon FSx for NetApp ONTAP, see Working with FSx for NetApp
 * ONTAP backups.
 *
 * - For Amazon FSx for OpenZFS, see Working with FSx for OpenZFS backups.
 *
 * If a backup with the specified client request token exists and the parameters match,
 * this operation returns the description of the existing backup. If a backup with the
 * specified client request token exists and the parameters don't match, this operation
 * returns `IncompatibleParameterError`. If a backup with the specified client
 * request token doesn't exist, `CreateBackup` does the following:
 *
 * - Creates a new Amazon FSx backup with an assigned ID, and an initial
 * lifecycle state of `CREATING`.
 *
 * - Returns the description of the backup.
 *
 * By using the idempotent operation, you can retry a `CreateBackup`
 * operation without the risk of creating an extra backup. This approach can be useful when
 * an initial call fails in a way that makes it unclear whether a backup was created. If
 * you use the same client request token and the initial call created a backup, the
 * operation returns a successful result because all the parameters are the same.
 *
 * The `CreateBackup` operation returns while the backup's lifecycle state is
 * still `CREATING`. You can check the backup creation status by calling the
 * DescribeBackups operation, which returns the backup state along with other
 * information.
 */
export declare const createBackup: API.OperationMethod<CreateBackupRequest & RegionInput, CreateBackupResponse, CreateBackupError, Credentials | HttpClient.HttpClient>;
export type CreateDataRepositoryAssociationError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates an Amazon FSx for Lustre data repository association (DRA). A data
 * repository association is a link between a directory on the file system and
 * an Amazon S3 bucket or prefix. You can have a maximum of 8 data repository
 * associations on a file system. Data repository associations are supported
 * on all FSx for Lustre 2.12 and 2.15 file systems, excluding
 * `scratch_1` deployment type.
 *
 * Each data repository association must have a unique Amazon FSx file
 * system directory and a unique S3 bucket or prefix associated with it. You
 * can configure a data repository association for automatic import only,
 * for automatic export only, or for both. To learn more about linking a
 * data repository to your file system, see
 * Linking your file system to an S3 bucket.
 *
 * `CreateDataRepositoryAssociation` isn't supported
 * on Amazon File Cache resources. To create a DRA on Amazon File Cache,
 * use the `CreateFileCache` operation.
 */
export declare const createDataRepositoryAssociation: API.OperationMethod<CreateDataRepositoryAssociationRequest & RegionInput, CreateDataRepositoryAssociationResponse, CreateDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateDataRepositoryTaskError = BadRequest | DataRepositoryTaskExecuting | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates an Amazon FSx for Lustre data repository task.
 * A `CreateDataRepositoryTask` operation will fail if a data
 * repository is not linked to the FSx file system.
 *
 * You use import and export data repository tasks to perform bulk operations between your
 * FSx for Lustre file system and its linked data repositories. An example of a data repository
 * task is exporting any data and metadata changes, including POSIX metadata, to files, directories,
 * and symbolic links (symlinks) from your FSx file system to a linked data repository.
 *
 * You use release data repository tasks to release data from your file system for files that
 * are exported to S3. The metadata of released files remains on the file system so users or applications
 * can still access released files by reading the files again, which will restore data from
 * Amazon S3 to the FSx for Lustre file system.
 *
 * To learn more about data repository tasks, see
 * Data Repository Tasks.
 * To learn more about linking a data repository to your file system, see
 * Linking your file system to an S3 bucket.
 */
export declare const createDataRepositoryTask: API.OperationMethod<CreateDataRepositoryTaskRequest & RegionInput, CreateDataRepositoryTaskResponse, CreateDataRepositoryTaskError, Credentials | HttpClient.HttpClient>;
export type CreateFileCacheError = BadRequest | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileCacheConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new Amazon File Cache resource.
 *
 * You can use this operation with a client request token in the request that
 * Amazon File Cache uses to ensure idempotent creation.
 * If a cache with the specified client request token exists and the parameters
 * match, `CreateFileCache` returns the description of the existing
 * cache. If a cache with the specified client request token exists and the
 * parameters don't match, this call returns `IncompatibleParameterError`.
 * If a file cache with the specified client request token doesn't exist,
 * `CreateFileCache` does the following:
 *
 * - Creates a new, empty Amazon File Cache resource with an assigned ID, and
 * an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the cache in JSON format.
 *
 * The `CreateFileCache` call returns while the cache's lifecycle
 * state is still `CREATING`. You can check the cache creation status
 * by calling the DescribeFileCaches operation, which returns the cache state
 * along with other information.
 */
export declare const createFileCache: API.OperationMethod<CreateFileCacheRequest & RegionInput, CreateFileCacheResponse, CreateFileCacheError, Credentials | HttpClient.HttpClient>;
export type CreateFileSystemError = ActiveDirectoryError | BadRequest | IncompatibleParameterError | InternalServerError | InvalidExportPath | InvalidImportPath | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileSystemConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new, empty Amazon FSx file system. You can create the following supported
 * Amazon FSx file systems using the `CreateFileSystem` API operation:
 *
 * - Amazon FSx for Lustre
 *
 * - Amazon FSx for NetApp ONTAP
 *
 * - Amazon FSx for OpenZFS
 *
 * - Amazon FSx for Windows File Server
 *
 * This operation requires a client request token in the request that Amazon FSx uses
 * to ensure idempotent creation. This means that calling the operation multiple times with
 * the same client request token has no effect. By using the idempotent operation, you can
 * retry a `CreateFileSystem` operation without the risk of creating an extra
 * file system. This approach can be useful when an initial call fails in a way that makes
 * it unclear whether a file system was created. Examples are if a transport level timeout
 * occurred, or your connection was reset. If you use the same client request token and the
 * initial call created a file system, the client receives success as long as the
 * parameters are the same.
 *
 * If a file system with the specified client request token exists and the parameters
 * match, `CreateFileSystem` returns the description of the existing file
 * system. If a file system with the specified client request token exists and the
 * parameters don't match, this call returns `IncompatibleParameterError`. If a
 * file system with the specified client request token doesn't exist,
 * `CreateFileSystem` does the following:
 *
 * - Creates a new, empty Amazon FSx file system with an assigned ID, and
 * an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the file system in JSON format.
 *
 * The `CreateFileSystem` call returns while the file system's lifecycle
 * state is still `CREATING`. You can check the file-system creation status
 * by calling the DescribeFileSystems operation, which returns the file system state
 * along with other information.
 */
export declare const createFileSystem: API.OperationMethod<CreateFileSystemRequest & RegionInput, CreateFileSystemResponse, CreateFileSystemError, Credentials | HttpClient.HttpClient>;
export type CreateFileSystemFromBackupError = ActiveDirectoryError | BackupNotFound | BadRequest | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | InvalidPerUnitStorageThroughput | MissingFileSystemConfiguration | ServiceLimitExceeded | CommonErrors;
/**
 * Creates a new Amazon FSx for Lustre, Amazon FSx for Windows File
 * Server, or Amazon FSx for OpenZFS file system from an existing Amazon FSx backup.
 *
 * If a file system with the specified client request token exists and the parameters
 * match, this operation returns the description of the file system. If a file system
 * with the specified client request token exists but the parameters don't match, this
 * call returns `IncompatibleParameterError`. If a file system with the
 * specified client request token doesn't exist, this operation does the following:
 *
 * - Creates a new Amazon FSx file system from backup with an assigned ID,
 * and an initial lifecycle state of `CREATING`.
 *
 * - Returns the description of the file system.
 *
 * Parameters like the Active Directory, default share name, automatic backup, and backup
 * settings default to the parameters of the file system that was backed up, unless
 * overridden. You can explicitly supply other settings.
 *
 * By using the idempotent operation, you can retry a
 * `CreateFileSystemFromBackup` call without the risk of creating an extra
 * file system. This approach can be useful when an initial call fails in a way that makes
 * it unclear whether a file system was created. Examples are if a transport level timeout
 * occurred, or your connection was reset. If you use the same client request token and the
 * initial call created a file system, the client receives a success message as long as the
 * parameters are the same.
 *
 * The `CreateFileSystemFromBackup` call returns while the file system's
 * lifecycle state is still `CREATING`. You can check the file-system
 * creation status by calling the
 * DescribeFileSystems operation, which returns the file system state along
 * with other information.
 */
export declare const createFileSystemFromBackup: API.OperationMethod<CreateFileSystemFromBackupRequest & RegionInput, CreateFileSystemFromBackupResponse, CreateFileSystemFromBackupError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = BadRequest | InternalServerError | ServiceLimitExceeded | VolumeNotFound | SnapshotVolumeNotFound | CommonErrors;
/**
 * Creates a snapshot of an existing Amazon FSx for OpenZFS volume. With
 * snapshots, you can easily undo file changes and compare file versions by restoring the
 * volume to a previous version.
 *
 * If a snapshot with the specified client request token exists, and the parameters
 * match, this operation returns the description of the existing snapshot. If a snapshot
 * with the specified client request token exists, and the parameters don't match, this
 * operation returns `IncompatibleParameterError`. If a snapshot with the
 * specified client request token doesn't exist, `CreateSnapshot` does the
 * following:
 *
 * - Creates a new OpenZFS snapshot with an assigned ID, and an initial lifecycle
 * state of `CREATING`.
 *
 * - Returns the description of the snapshot.
 *
 * By using the idempotent operation, you can retry a `CreateSnapshot`
 * operation without the risk of creating an extra snapshot. This approach can be useful
 * when an initial call fails in a way that makes it unclear whether a snapshot was
 * created. If you use the same client request token and the initial call created a
 * snapshot, the operation returns a successful result because all the parameters are the
 * same.
 *
 * The `CreateSnapshot` operation returns while the snapshot's lifecycle state
 * is still `CREATING`. You can check the snapshot creation status by calling
 * the DescribeSnapshots operation, which returns the snapshot state along with
 * other information.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotRequest & RegionInput, CreateSnapshotResponse, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateStorageVirtualMachineError = ActiveDirectoryError | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Creates a storage virtual machine (SVM) for an Amazon FSx for ONTAP file system.
 */
export declare const createStorageVirtualMachine: API.OperationMethod<CreateStorageVirtualMachineRequest & RegionInput, CreateStorageVirtualMachineResponse, CreateStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type CreateVolumeError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | ServiceLimitExceeded | StorageVirtualMachineNotFound | UnsupportedOperation | CommonErrors;
/**
 * Creates an FSx for ONTAP or Amazon FSx for OpenZFS storage volume.
 */
export declare const createVolume: API.OperationMethod<CreateVolumeRequest & RegionInput, CreateVolumeResponse, CreateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateVolumeFromBackupError = BackupNotFound | BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | ServiceLimitExceeded | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Creates a new Amazon FSx for NetApp ONTAP volume from an
 * existing Amazon FSx volume backup.
 */
export declare const createVolumeFromBackup: API.OperationMethod<CreateVolumeFromBackupRequest & RegionInput, CreateVolumeFromBackupResponse, CreateVolumeFromBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupError = BackupBeingCopied | BackupInProgress | BackupNotFound | BackupRestoring | BadRequest | IncompatibleParameterError | InternalServerError | CommonErrors;
/**
 * Deletes an Amazon FSx backup. After deletion, the backup no longer exists, and
 * its data is gone.
 *
 * The `DeleteBackup` call returns instantly. The backup won't show up in
 * later `DescribeBackups` calls.
 *
 * The data in a deleted backup is also deleted and can't be recovered by any
 * means.
 */
export declare const deleteBackup: API.OperationMethod<DeleteBackupRequest & RegionInput, DeleteBackupResponse, DeleteBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDataRepositoryAssociationError = BadRequest | DataRepositoryAssociationNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes a data repository association on an Amazon FSx for Lustre
 * file system. Deleting the data repository association unlinks the
 * file system from the Amazon S3 bucket. When deleting a data repository
 * association, you have the option of deleting the data in the file system
 * that corresponds to the data repository association. Data repository
 * associations are supported on all FSx for Lustre 2.12 and 2.15 file
 * systems, excluding `scratch_1` deployment type.
 */
export declare const deleteDataRepositoryAssociation: API.OperationMethod<DeleteDataRepositoryAssociationRequest & RegionInput, DeleteDataRepositoryAssociationResponse, DeleteDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteFileCacheError = BadRequest | FileCacheNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes an Amazon File Cache resource. After deletion, the cache no longer exists, and its data
 * is gone.
 *
 * The `DeleteFileCache` operation returns while the cache has the
 * `DELETING` status. You can check the cache deletion status by
 * calling the DescribeFileCaches operation, which returns a list of caches in your
 * account. If you pass the cache ID for a deleted cache, the
 * `DescribeFileCaches` operation returns a `FileCacheNotFound`
 * error.
 *
 * The data in a deleted cache is also deleted and can't be recovered by
 * any means.
 */
export declare const deleteFileCache: API.OperationMethod<DeleteFileCacheRequest & RegionInput, DeleteFileCacheResponse, DeleteFileCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteFileSystemError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Deletes a file system. After deletion, the file system no longer exists, and its data
 * is gone. Any existing automatic backups and snapshots are also deleted.
 *
 * To delete an Amazon FSx for NetApp ONTAP file system, first delete all the
 * volumes and storage virtual machines (SVMs) on the file system. Then provide a
 * `FileSystemId` value to the `DeleteFileSystem` operation.
 *
 * Before deleting an Amazon FSx for OpenZFS file system, make sure that there aren't
 * any Amazon S3 access points attached to any volume. For more information on how to list S3
 * access points that are attached to volumes, see
 * Listing S3 access point attachments.
 * For more information on how to delete S3 access points, see
 * Deleting an S3 access point attachment.
 *
 * By default, when you delete an Amazon FSx for Windows File Server file system,
 * a final backup is created upon deletion. This final backup isn't subject to the file
 * system's retention policy, and must be manually deleted.
 *
 * To delete an Amazon FSx for Lustre file system, first
 * unmount
 * it from every connected Amazon EC2 instance, then provide a `FileSystemId`
 * value to the `DeleteFileSystem` operation. By default, Amazon FSx will not
 * take a final backup when the `DeleteFileSystem` operation is invoked. On file systems
 * not linked to an Amazon S3 bucket, set `SkipFinalBackup` to `false`
 * to take a final backup of the file system you are deleting. Backups cannot be enabled on S3-linked
 * file systems. To ensure all of your data is written back to S3 before deleting your file system,
 * you can either monitor for the
 * AgeOfOldestQueuedMessage
 * metric to be zero (if using automatic export) or you can run an
 * export data repository task.
 * If you have automatic export enabled and want to use an export data repository task, you have
 * to disable automatic export before executing the export data repository task.
 *
 * The `DeleteFileSystem` operation returns while the file system has the
 * `DELETING` status. You can check the file system deletion status by
 * calling the DescribeFileSystems operation, which returns a list of file systems in your
 * account. If you pass the file system ID for a deleted file system, the
 * `DescribeFileSystems` operation returns a `FileSystemNotFound`
 * error.
 *
 * If a data repository task is in a `PENDING` or `EXECUTING` state,
 * deleting an Amazon FSx for Lustre file system will fail with an HTTP status
 * code 400 (Bad Request).
 *
 * The data in a deleted file system is also deleted and can't be recovered by
 * any means.
 */
export declare const deleteFileSystem: API.OperationMethod<DeleteFileSystemRequest & RegionInput, DeleteFileSystemResponse, DeleteFileSystemError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = BadRequest | InternalServerError | SnapshotNotFound | CommonErrors;
/**
 * Deletes an Amazon FSx for OpenZFS snapshot. After deletion, the snapshot no longer
 * exists, and its data is gone. Deleting a snapshot doesn't affect snapshots stored in a
 * file system backup.
 *
 * The `DeleteSnapshot` operation returns instantly. The snapshot appears with
 * the lifecycle status of `DELETING` until the deletion is complete.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotRequest & RegionInput, DeleteSnapshotResponse, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteStorageVirtualMachineError = BadRequest | IncompatibleParameterError | InternalServerError | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Deletes an existing Amazon FSx for ONTAP storage virtual machine (SVM). Prior
 * to deleting an SVM, you must delete all non-root volumes in the SVM, otherwise the operation will fail.
 */
export declare const deleteStorageVirtualMachine: API.OperationMethod<DeleteStorageVirtualMachineRequest & RegionInput, DeleteStorageVirtualMachineResponse, DeleteStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type DeleteVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | VolumeNotFound | CommonErrors;
/**
 * Deletes an Amazon FSx for NetApp ONTAP or Amazon FSx for OpenZFS
 * volume.
 */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeRequest & RegionInput, DeleteVolumeResponse, DeleteVolumeError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupsError = BackupNotFound | BadRequest | FileSystemNotFound | InternalServerError | VolumeNotFound | CommonErrors;
/**
 * Returns the description of a specific Amazon FSx backup, if a
 * `BackupIds` value is provided for that backup. Otherwise, it returns all
 * backups owned by your Amazon Web Services account in the Amazon Web Services Region of the
 * endpoint that you're calling.
 *
 * When retrieving all backups, you can optionally specify the `MaxResults`
 * parameter to limit the number of backups in a response. If more backups remain, Amazon FSx returns a `NextToken` value in the response. In this case,
 * send a later request with the `NextToken` request parameter set to the value
 * of the `NextToken` value from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your backups.
 * `DescribeBackups` is called first without a `NextToken` value.
 * Then the operation continues to be called with the `NextToken` parameter set
 * to the value of the last `NextToken` value until a response has no
 * `NextToken` value.
 *
 * When using this operation, keep the following in mind:
 *
 * - The operation might return fewer than the `MaxResults` value of
 * backup descriptions while still including a `NextToken`
 * value.
 *
 * - The order of the backups returned in the response of one
 * `DescribeBackups` call and the order of the backups returned
 * across the responses of a multi-call iteration is unspecified.
 */
export declare const describeBackups: API.PaginatedOperationMethod<DescribeBackupsRequest & RegionInput, DescribeBackupsResponse, DescribeBackupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDataRepositoryAssociationsError = BadRequest | DataRepositoryAssociationNotFound | FileSystemNotFound | InternalServerError | InvalidDataRepositoryType | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for Lustre or Amazon File Cache
 * data repository associations, if one or more `AssociationIds` values
 * are provided in the request, or if filters are used in the request. Data repository
 * associations are supported on Amazon File Cache resources and all FSx for Lustre
 * 2.12 and 2,15 file systems, excluding `scratch_1` deployment type.
 *
 * You can use filters to narrow the response to include just data repository
 * associations for specific file systems (use the `file-system-id` filter with
 * the ID of the file system) or caches (use the `file-cache-id` filter with
 * the ID of the cache), or data repository associations for a specific repository type
 * (use the `data-repository-type` filter with a value of `S3`
 * or `NFS`). If you don't use filters, the response returns all data
 * repository associations owned by your Amazon Web Services account in the Amazon Web Services Region
 * of the endpoint that you're calling.
 *
 * When retrieving all data repository associations, you can paginate the response by using
 * the optional `MaxResults` parameter to limit the number of data repository associations
 * returned in a response. If more data repository associations remain, a
 * `NextToken` value is returned in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 */
export declare const describeDataRepositoryAssociations: API.PaginatedOperationMethod<DescribeDataRepositoryAssociationsRequest & RegionInput, DescribeDataRepositoryAssociationsResponse, DescribeDataRepositoryAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDataRepositoryTasksError = BadRequest | DataRepositoryTaskNotFound | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for Lustre or Amazon File Cache data repository tasks, if
 * one or more `TaskIds` values are provided in the request, or if filters are used in the request.
 * You can use filters to narrow the response to include just tasks for specific file systems or caches,
 * or tasks in a specific lifecycle state. Otherwise, it returns all data repository tasks owned
 * by your Amazon Web Services account in the Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all tasks, you can paginate the response by using the optional `MaxResults`
 * parameter to limit the number of tasks returned in a response. If more tasks remain,
 * a `NextToken` value is returned in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 */
export declare const describeDataRepositoryTasks: API.PaginatedOperationMethod<DescribeDataRepositoryTasksRequest & RegionInput, DescribeDataRepositoryTasksResponse, DescribeDataRepositoryTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileCachesError = BadRequest | FileCacheNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of a specific Amazon File Cache resource, if a
 * `FileCacheIds` value is provided for that cache. Otherwise, it
 * returns descriptions of all caches owned by your Amazon Web Services account in the
 * Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all cache descriptions, you can optionally specify the
 * `MaxResults` parameter to limit the number of descriptions in a response.
 * If more cache descriptions remain, the operation returns a
 * `NextToken` value in the response. In this case, send a later request
 * with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your cache
 * descriptions. `DescribeFileCaches` is called first without a
 * `NextToken`value. Then the operation continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this operation, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults`
 * cache descriptions while still including a `NextToken`
 * value.
 *
 * - The order of caches returned in the response of one
 * `DescribeFileCaches` call and the order of caches returned
 * across the responses of a multicall iteration is unspecified.
 */
export declare const describeFileCaches: API.PaginatedOperationMethod<DescribeFileCachesRequest & RegionInput, DescribeFileCachesResponse, DescribeFileCachesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the DNS aliases that are associated with the specified Amazon FSx for Windows File Server file system. A history of
 * all DNS aliases that have been associated with and disassociated from the file system is available in the list of AdministrativeAction
 * provided in the DescribeFileSystems operation response.
 */
export declare const describeFileSystemAliases: API.PaginatedOperationMethod<DescribeFileSystemAliasesRequest & RegionInput, DescribeFileSystemAliasesResponse, DescribeFileSystemAliasesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFileSystemsError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Returns the description of specific Amazon FSx file systems, if a
 * `FileSystemIds` value is provided for that file system. Otherwise, it
 * returns descriptions of all file systems owned by your Amazon Web Services account in the
 * Amazon Web Services Region of the endpoint that you're calling.
 *
 * When retrieving all file system descriptions, you can optionally specify the
 * `MaxResults` parameter to limit the number of descriptions in a response.
 * If more file system descriptions remain, Amazon FSx returns a
 * `NextToken` value in the response. In this case, send a later request
 * with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This operation is used in an iterative process to retrieve a list of your file system
 * descriptions. `DescribeFileSystems` is called first without a
 * `NextToken`value. Then the operation continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this operation, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults` file
 * system descriptions while still including a `NextToken`
 * value.
 *
 * - The order of file systems returned in the response of one
 * `DescribeFileSystems` call and the order of file systems returned
 * across the responses of a multicall iteration is unspecified.
 */
export declare const describeFileSystems: API.PaginatedOperationMethod<DescribeFileSystemsRequest & RegionInput, DescribeFileSystemsResponse, DescribeFileSystemsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeS3AccessPointAttachmentsError = BadRequest | InternalServerError | S3AccessPointAttachmentNotFound | UnsupportedOperation | CommonErrors;
/**
 * Describes one or more S3 access points attached to Amazon FSx volumes.
 *
 * The requester requires the following permission to perform this action:
 *
 * - `fsx:DescribeS3AccessPointAttachments`
 */
export declare const describeS3AccessPointAttachments: API.PaginatedOperationMethod<DescribeS3AccessPointAttachmentsRequest & RegionInput, DescribeS3AccessPointAttachmentsResponse, DescribeS3AccessPointAttachmentsError, Credentials | HttpClient.HttpClient, S3AccessPointAttachment>;
export type DescribeSharedVpcConfigurationError = BadRequest | InternalServerError | CommonErrors;
/**
 * Indicates whether participant accounts in your organization can create Amazon FSx for NetApp ONTAP Multi-AZ file systems in subnets that are shared by a virtual
 * private cloud (VPC) owner. For more information, see Creating FSx for ONTAP file systems in shared subnets.
 */
export declare const describeSharedVpcConfiguration: API.OperationMethod<DescribeSharedVpcConfigurationRequest & RegionInput, DescribeSharedVpcConfigurationResponse, DescribeSharedVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeSnapshotsError = BadRequest | InternalServerError | SnapshotNotFound | CommonErrors;
/**
 * Returns the description of specific Amazon FSx for OpenZFS snapshots, if a
 * `SnapshotIds` value is provided. Otherwise, this operation returns all
 * snapshots owned by your Amazon Web Services account in the Amazon Web Services Region of
 * the endpoint that you're calling.
 *
 * When retrieving all snapshots, you can optionally specify the `MaxResults`
 * parameter to limit the number of snapshots in a response. If more backups remain,
 * Amazon FSx returns a `NextToken` value in the response. In this
 * case, send a later request with the `NextToken` request parameter set to the
 * value of `NextToken` from the last response.
 *
 * Use this operation in an iterative process to retrieve a list of your snapshots.
 * `DescribeSnapshots` is called first without a `NextToken`
 * value. Then the operation continues to be called with the `NextToken`
 * parameter set to the value of the last `NextToken` value until a response has
 * no `NextToken` value.
 *
 * When using this operation, keep the following in mind:
 *
 * - The operation might return fewer than the `MaxResults` value of
 * snapshot descriptions while still including a `NextToken`
 * value.
 *
 * - The order of snapshots returned in the response of one
 * `DescribeSnapshots` call and the order of backups returned across
 * the responses of a multi-call iteration is unspecified.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsRequest & RegionInput, DescribeSnapshotsResponse, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeStorageVirtualMachinesError = BadRequest | InternalServerError | StorageVirtualMachineNotFound | CommonErrors;
/**
 * Describes one or more Amazon FSx for NetApp ONTAP storage virtual machines (SVMs).
 */
export declare const describeStorageVirtualMachines: API.PaginatedOperationMethod<DescribeStorageVirtualMachinesRequest & RegionInput, DescribeStorageVirtualMachinesResponse, DescribeStorageVirtualMachinesError, Credentials | HttpClient.HttpClient, StorageVirtualMachine>;
export type DescribeVolumesError = BadRequest | InternalServerError | VolumeNotFound | CommonErrors;
/**
 * Describes one or more Amazon FSx for NetApp ONTAP or Amazon FSx for
 * OpenZFS volumes.
 */
export declare const describeVolumes: API.PaginatedOperationMethod<DescribeVolumesRequest & RegionInput, DescribeVolumesResponse, DescribeVolumesError, Credentials | HttpClient.HttpClient, Volume>;
export type DetachAndDeleteS3AccessPointError = BadRequest | IncompatibleParameterError | InternalServerError | S3AccessPointAttachmentNotFound | UnsupportedOperation | CommonErrors;
/**
 * Detaches an S3 access point from an Amazon FSx volume and deletes the S3 access point.
 *
 * The requester requires the following permission to perform this action:
 *
 * - `fsx:DetachAndDeleteS3AccessPoint`
 *
 * - `s3:DeleteAccessPoint`
 */
export declare const detachAndDeleteS3AccessPoint: API.OperationMethod<DetachAndDeleteS3AccessPointRequest & RegionInput, DetachAndDeleteS3AccessPointResponse, DetachAndDeleteS3AccessPointError, Credentials | HttpClient.HttpClient>;
export type DisassociateFileSystemAliasesError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * Use this action to disassociate, or remove, one or more Domain Name Service (DNS) aliases
 * from an Amazon FSx for Windows File Server file system. If you attempt to disassociate a DNS alias that is not
 * associated with the file system, Amazon FSx responds with an HTTP status code 400 (Bad Request). For more information, see
 * Working with DNS Aliases.
 *
 * The system generated response showing the DNS aliases that
 * Amazon FSx is attempting to disassociate from the file system.
 * Use the API
 * operation to monitor the status of the aliases Amazon FSx is
 * disassociating with the file system.
 */
export declare const disassociateFileSystemAliases: API.OperationMethod<DisassociateFileSystemAliasesRequest & RegionInput, DisassociateFileSystemAliasesResponse, DisassociateFileSystemAliasesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * Lists tags for Amazon FSx resources.
 *
 * When retrieving all tags, you can optionally specify the `MaxResults`
 * parameter to limit the number of tags in a response. If more tags remain, Amazon FSx
 * returns a `NextToken` value in the response. In this case, send a later
 * request with the `NextToken` request parameter set to the value of
 * `NextToken` from the last response.
 *
 * This action is used in an iterative process to retrieve a list of your tags.
 * `ListTagsForResource` is called first without a
 * `NextToken`value. Then the action continues to be called with the
 * `NextToken` parameter set to the value of the last `NextToken`
 * value until a response has no `NextToken`.
 *
 * When using this action, keep the following in mind:
 *
 * - The implementation might return fewer than `MaxResults` file
 * system descriptions while still including a `NextToken`
 * value.
 *
 * - The order of tags returned in the response of one
 * `ListTagsForResource` call and the order of tags returned across
 * the responses of a multi-call iteration is unspecified.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type ReleaseFileSystemNfsV3LocksError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Releases the file system lock from an Amazon FSx for OpenZFS file
 * system.
 */
export declare const releaseFileSystemNfsV3Locks: API.OperationMethod<ReleaseFileSystemNfsV3LocksRequest & RegionInput, ReleaseFileSystemNfsV3LocksResponse, ReleaseFileSystemNfsV3LocksError, Credentials | HttpClient.HttpClient>;
export type RestoreVolumeFromSnapshotError = BadRequest | InternalServerError | VolumeNotFound | RestoreSnapshotNotFound | CommonErrors;
/**
 * Returns an Amazon FSx for OpenZFS volume to the state saved by the specified
 * snapshot.
 */
export declare const restoreVolumeFromSnapshot: API.OperationMethod<RestoreVolumeFromSnapshotRequest & RegionInput, RestoreVolumeFromSnapshotResponse, RestoreVolumeFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type StartMisconfiguredStateRecoveryError = BadRequest | FileSystemNotFound | InternalServerError | CommonErrors;
/**
 * After performing steps to repair the Active Directory configuration of an FSx for Windows File Server file system, use this action to
 * initiate the process of Amazon FSx attempting to reconnect to the file system.
 */
export declare const startMisconfiguredStateRecovery: API.OperationMethod<StartMisconfiguredStateRecoveryRequest & RegionInput, StartMisconfiguredStateRecoveryResponse, StartMisconfiguredStateRecoveryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * Tags an Amazon FSx resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequest | InternalServerError | NotServiceResourceError | ResourceDoesNotSupportTagging | ResourceNotFound | CommonErrors;
/**
 * This action removes a tag from an Amazon FSx resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataRepositoryAssociationError = BadRequest | DataRepositoryAssociationNotFound | IncompatibleParameterError | InternalServerError | ServiceLimitExceeded | CommonErrors;
/**
 * Updates the configuration of an existing data repository association
 * on an Amazon FSx for Lustre file system. Data repository associations
 * are supported on all FSx for Lustre 2.12 and 2.15 file systems,
 * excluding `scratch_1` deployment type.
 */
export declare const updateDataRepositoryAssociation: API.OperationMethod<UpdateDataRepositoryAssociationRequest & RegionInput, UpdateDataRepositoryAssociationResponse, UpdateDataRepositoryAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateFileCacheError = BadRequest | FileCacheNotFound | IncompatibleParameterError | InternalServerError | MissingFileCacheConfiguration | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Updates the configuration of an existing Amazon File Cache resource.
 * You can update multiple properties in a single request.
 */
export declare const updateFileCache: API.OperationMethod<UpdateFileCacheRequest & RegionInput, UpdateFileCacheResponse, UpdateFileCacheError, Credentials | HttpClient.HttpClient>;
export type UpdateFileSystemError = BadRequest | FileSystemNotFound | IncompatibleParameterError | InternalServerError | InvalidNetworkSettings | MissingFileSystemConfiguration | ServiceLimitExceeded | UnsupportedOperation | CommonErrors;
/**
 * Use this operation to update the configuration of an existing Amazon FSx file
 * system. You can update multiple properties in a single request.
 *
 * For FSx for Windows File Server file systems, you can update the following
 * properties:
 *
 * - `AuditLogConfiguration`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `SelfManagedActiveDirectoryConfiguration`
 *
 * - `StorageCapacity`
 *
 * - `StorageType`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for Lustre file systems, you can update the following
 * properties:
 *
 * - `AutoImportPolicy`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DataCompressionType`
 *
 * - `FileSystemTypeVersion`
 *
 * - `LogConfiguration`
 *
 * - `LustreReadCacheConfiguration`
 *
 * - `LustreRootSquashConfiguration`
 *
 * - `MetadataConfiguration`
 *
 * - `PerUnitStorageThroughput`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for ONTAP file systems, you can update the following
 * properties:
 *
 * - `AddRouteTableIds`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `EndpointIpv6AddressRange`
 *
 * - `FsxAdminPassword`
 *
 * - `HAPairs`
 *
 * - `RemoveRouteTableIds`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `ThroughputCapacityPerHAPair`
 *
 * - `WeeklyMaintenanceStartTime`
 *
 * For FSx for OpenZFS file systems, you can update the following
 * properties:
 *
 * - `AddRouteTableIds`
 *
 * - `AutomaticBackupRetentionDays`
 *
 * - `CopyTagsToBackups`
 *
 * - `CopyTagsToVolumes`
 *
 * - `DailyAutomaticBackupStartTime`
 *
 * - `DiskIopsConfiguration`
 *
 * - `EndpointIpv6AddressRange`
 *
 * - `ReadCacheConfiguration`
 *
 * - `RemoveRouteTableIds`
 *
 * - `StorageCapacity`
 *
 * - `ThroughputCapacity`
 *
 * - `WeeklyMaintenanceStartTime`
 */
export declare const updateFileSystem: API.OperationMethod<UpdateFileSystemRequest & RegionInput, UpdateFileSystemResponse, UpdateFileSystemError, Credentials | HttpClient.HttpClient>;
export type UpdateSharedVpcConfigurationError = BadRequest | IncompatibleParameterError | InternalServerError | CommonErrors;
/**
 * Configures whether participant accounts in your organization can create Amazon FSx for NetApp ONTAP Multi-AZ file systems in subnets that are shared by a virtual
 * private cloud (VPC) owner. For more information, see the Amazon FSx for NetApp ONTAP User
 * Guide.
 *
 * We strongly recommend that participant-created Multi-AZ file systems in the shared
 * VPC are deleted before you disable this feature. Once the feature is disabled, these
 * file systems will enter a `MISCONFIGURED` state and behave like Single-AZ
 * file systems. For more information, see Important considerations before disabling shared VPC support for Multi-AZ file
 * systems.
 */
export declare const updateSharedVpcConfiguration: API.OperationMethod<UpdateSharedVpcConfigurationRequest & RegionInput, UpdateSharedVpcConfigurationResponse, UpdateSharedVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSnapshotError = BadRequest | InternalServerError | SnapshotNotFound | UpdateSnapshotNotFound | CommonErrors;
/**
 * Updates the name of an Amazon FSx for OpenZFS snapshot.
 */
export declare const updateSnapshot: API.OperationMethod<UpdateSnapshotRequest & RegionInput, UpdateSnapshotResponse, UpdateSnapshotError, Credentials | HttpClient.HttpClient>;
export type UpdateStorageVirtualMachineError = BadRequest | IncompatibleParameterError | InternalServerError | StorageVirtualMachineNotFound | UnsupportedOperation | CommonErrors;
/**
 * Updates an FSx for ONTAP storage virtual machine (SVM).
 */
export declare const updateStorageVirtualMachine: API.OperationMethod<UpdateStorageVirtualMachineRequest & RegionInput, UpdateStorageVirtualMachineResponse, UpdateStorageVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type UpdateVolumeError = BadRequest | IncompatibleParameterError | InternalServerError | MissingVolumeConfiguration | VolumeNotFound | CommonErrors;
/**
 * Updates the configuration of an Amazon FSx for NetApp ONTAP or Amazon FSx for OpenZFS volume.
 */
export declare const updateVolume: API.OperationMethod<UpdateVolumeRequest & RegionInput, UpdateVolumeResponse, UpdateVolumeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=fsx.d.ts.map